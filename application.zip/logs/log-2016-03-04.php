<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-04 00:02:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 00:02:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 00:02:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 00:02:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 00:02:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 00:02:05 --> Final output sent to browser
DEBUG - 2016-03-04 00:02:05 --> Total execution time: 1.2373
INFO - 2016-03-04 00:03:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 00:03:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 00:03:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 00:03:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 00:03:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 00:03:26 --> Final output sent to browser
DEBUG - 2016-03-04 00:03:26 --> Total execution time: 1.2058
INFO - 2016-03-04 00:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 00:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 00:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 00:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 00:04:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 00:04:05 --> Final output sent to browser
DEBUG - 2016-03-04 00:04:05 --> Total execution time: 1.2140
INFO - 2016-03-04 00:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 00:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 00:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 00:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 00:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 00:04:22 --> Final output sent to browser
DEBUG - 2016-03-04 00:04:22 --> Total execution time: 1.2014
INFO - 2016-03-04 00:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 00:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 00:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 00:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 00:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 00:04:31 --> Final output sent to browser
DEBUG - 2016-03-04 00:04:31 --> Total execution time: 1.1787
INFO - 2016-03-04 00:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 00:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 00:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 00:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 00:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 00:05:55 --> Final output sent to browser
DEBUG - 2016-03-04 00:05:55 --> Total execution time: 1.2657
INFO - 2016-03-04 00:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 00:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 00:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 00:06:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-04 00:06:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-04 00:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 00:06:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 00:06:45 --> Final output sent to browser
DEBUG - 2016-03-04 00:06:45 --> Total execution time: 1.1134
INFO - 2016-03-04 05:42:13 --> Config Class Initialized
INFO - 2016-03-04 05:42:13 --> Hooks Class Initialized
DEBUG - 2016-03-04 05:42:13 --> UTF-8 Support Enabled
INFO - 2016-03-04 05:42:13 --> Utf8 Class Initialized
INFO - 2016-03-04 05:42:13 --> URI Class Initialized
DEBUG - 2016-03-04 05:42:13 --> No URI present. Default controller set.
INFO - 2016-03-04 05:42:13 --> Router Class Initialized
INFO - 2016-03-04 05:42:13 --> Output Class Initialized
INFO - 2016-03-04 05:42:13 --> Security Class Initialized
DEBUG - 2016-03-04 05:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 05:42:13 --> Input Class Initialized
INFO - 2016-03-04 05:42:13 --> Language Class Initialized
INFO - 2016-03-04 05:42:13 --> Loader Class Initialized
INFO - 2016-03-04 05:42:13 --> Helper loaded: url_helper
INFO - 2016-03-04 05:42:13 --> Helper loaded: file_helper
INFO - 2016-03-04 05:42:13 --> Helper loaded: date_helper
INFO - 2016-03-04 05:42:13 --> Helper loaded: form_helper
INFO - 2016-03-04 05:42:13 --> Database Driver Class Initialized
INFO - 2016-03-04 05:42:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 05:42:14 --> Controller Class Initialized
INFO - 2016-03-04 05:42:14 --> Model Class Initialized
INFO - 2016-03-04 05:42:14 --> Model Class Initialized
INFO - 2016-03-04 05:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 05:42:14 --> Pagination Class Initialized
INFO - 2016-03-04 05:42:14 --> Helper loaded: text_helper
INFO - 2016-03-04 05:42:14 --> Helper loaded: cookie_helper
INFO - 2016-03-04 08:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 08:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 08:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 08:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 08:42:14 --> Final output sent to browser
DEBUG - 2016-03-04 08:42:14 --> Total execution time: 1.1676
INFO - 2016-03-04 05:47:00 --> Config Class Initialized
INFO - 2016-03-04 05:47:00 --> Hooks Class Initialized
DEBUG - 2016-03-04 05:47:00 --> UTF-8 Support Enabled
INFO - 2016-03-04 05:47:00 --> Utf8 Class Initialized
INFO - 2016-03-04 05:47:00 --> URI Class Initialized
INFO - 2016-03-04 05:47:00 --> Router Class Initialized
INFO - 2016-03-04 05:47:00 --> Output Class Initialized
INFO - 2016-03-04 05:47:00 --> Security Class Initialized
DEBUG - 2016-03-04 05:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 05:47:00 --> Input Class Initialized
INFO - 2016-03-04 05:47:00 --> Language Class Initialized
INFO - 2016-03-04 05:47:00 --> Loader Class Initialized
INFO - 2016-03-04 05:47:00 --> Helper loaded: url_helper
INFO - 2016-03-04 05:47:00 --> Helper loaded: file_helper
INFO - 2016-03-04 05:47:00 --> Helper loaded: date_helper
INFO - 2016-03-04 05:47:00 --> Helper loaded: form_helper
INFO - 2016-03-04 05:47:00 --> Database Driver Class Initialized
INFO - 2016-03-04 05:47:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 05:47:01 --> Controller Class Initialized
INFO - 2016-03-04 05:47:01 --> Model Class Initialized
INFO - 2016-03-04 05:47:01 --> Model Class Initialized
INFO - 2016-03-04 05:47:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 05:47:01 --> Pagination Class Initialized
INFO - 2016-03-04 05:47:01 --> Helper loaded: text_helper
INFO - 2016-03-04 05:47:01 --> Helper loaded: cookie_helper
INFO - 2016-03-04 08:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 08:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 08:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 08:47:01 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-04 08:47:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-04 08:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 08:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 08:47:01 --> Final output sent to browser
DEBUG - 2016-03-04 08:47:01 --> Total execution time: 1.1413
INFO - 2016-03-04 06:01:02 --> Config Class Initialized
INFO - 2016-03-04 06:01:02 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:01:02 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:01:02 --> Utf8 Class Initialized
INFO - 2016-03-04 06:01:02 --> URI Class Initialized
INFO - 2016-03-04 06:01:02 --> Router Class Initialized
INFO - 2016-03-04 06:01:02 --> Output Class Initialized
INFO - 2016-03-04 06:01:02 --> Security Class Initialized
DEBUG - 2016-03-04 06:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:01:02 --> Input Class Initialized
INFO - 2016-03-04 06:01:02 --> Language Class Initialized
INFO - 2016-03-04 06:01:02 --> Loader Class Initialized
INFO - 2016-03-04 06:01:02 --> Helper loaded: url_helper
INFO - 2016-03-04 06:01:02 --> Helper loaded: file_helper
INFO - 2016-03-04 06:01:02 --> Helper loaded: date_helper
INFO - 2016-03-04 06:01:02 --> Helper loaded: form_helper
INFO - 2016-03-04 06:01:02 --> Database Driver Class Initialized
INFO - 2016-03-04 06:01:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:01:03 --> Controller Class Initialized
INFO - 2016-03-04 06:01:03 --> Model Class Initialized
INFO - 2016-03-04 06:01:03 --> Model Class Initialized
INFO - 2016-03-04 06:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:01:03 --> Pagination Class Initialized
INFO - 2016-03-04 06:01:03 --> Helper loaded: text_helper
INFO - 2016-03-04 06:01:03 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:01:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:01:04 --> Final output sent to browser
DEBUG - 2016-03-04 09:01:04 --> Total execution time: 1.1368
INFO - 2016-03-04 06:01:06 --> Config Class Initialized
INFO - 2016-03-04 06:01:06 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:01:06 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:01:06 --> Utf8 Class Initialized
INFO - 2016-03-04 06:01:06 --> URI Class Initialized
INFO - 2016-03-04 06:01:06 --> Router Class Initialized
INFO - 2016-03-04 06:01:06 --> Output Class Initialized
INFO - 2016-03-04 06:01:06 --> Security Class Initialized
DEBUG - 2016-03-04 06:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:01:06 --> Input Class Initialized
INFO - 2016-03-04 06:01:06 --> Language Class Initialized
INFO - 2016-03-04 06:01:06 --> Loader Class Initialized
INFO - 2016-03-04 06:01:06 --> Helper loaded: url_helper
INFO - 2016-03-04 06:01:06 --> Helper loaded: file_helper
INFO - 2016-03-04 06:01:06 --> Helper loaded: date_helper
INFO - 2016-03-04 06:01:06 --> Helper loaded: form_helper
INFO - 2016-03-04 06:01:06 --> Database Driver Class Initialized
INFO - 2016-03-04 06:01:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:01:07 --> Controller Class Initialized
INFO - 2016-03-04 06:01:07 --> Model Class Initialized
INFO - 2016-03-04 06:01:07 --> Model Class Initialized
INFO - 2016-03-04 06:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:01:07 --> Pagination Class Initialized
INFO - 2016-03-04 06:01:07 --> Helper loaded: text_helper
INFO - 2016-03-04 06:01:07 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:01:07 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-04 09:01:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-04 09:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:01:07 --> Final output sent to browser
DEBUG - 2016-03-04 09:01:07 --> Total execution time: 1.1296
INFO - 2016-03-04 06:09:48 --> Config Class Initialized
INFO - 2016-03-04 06:09:48 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:09:48 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:09:48 --> Utf8 Class Initialized
INFO - 2016-03-04 06:09:48 --> URI Class Initialized
INFO - 2016-03-04 06:09:48 --> Router Class Initialized
INFO - 2016-03-04 06:09:48 --> Output Class Initialized
INFO - 2016-03-04 06:09:48 --> Security Class Initialized
DEBUG - 2016-03-04 06:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:09:48 --> Input Class Initialized
INFO - 2016-03-04 06:09:48 --> Language Class Initialized
INFO - 2016-03-04 06:09:48 --> Loader Class Initialized
INFO - 2016-03-04 06:09:48 --> Helper loaded: url_helper
INFO - 2016-03-04 06:09:48 --> Helper loaded: file_helper
INFO - 2016-03-04 06:09:48 --> Helper loaded: date_helper
INFO - 2016-03-04 06:09:48 --> Helper loaded: form_helper
INFO - 2016-03-04 06:09:48 --> Database Driver Class Initialized
INFO - 2016-03-04 06:09:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:09:49 --> Controller Class Initialized
INFO - 2016-03-04 06:09:49 --> Model Class Initialized
INFO - 2016-03-04 06:09:49 --> Model Class Initialized
INFO - 2016-03-04 06:09:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:09:49 --> Pagination Class Initialized
INFO - 2016-03-04 06:09:49 --> Helper loaded: text_helper
INFO - 2016-03-04 06:09:49 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:09:49 --> Final output sent to browser
DEBUG - 2016-03-04 09:09:49 --> Total execution time: 1.2103
INFO - 2016-03-04 06:14:30 --> Config Class Initialized
INFO - 2016-03-04 06:14:30 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:14:30 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:14:30 --> Utf8 Class Initialized
INFO - 2016-03-04 06:14:30 --> URI Class Initialized
INFO - 2016-03-04 06:14:30 --> Router Class Initialized
INFO - 2016-03-04 06:14:30 --> Output Class Initialized
INFO - 2016-03-04 06:14:30 --> Security Class Initialized
DEBUG - 2016-03-04 06:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:14:30 --> Input Class Initialized
INFO - 2016-03-04 06:14:30 --> Language Class Initialized
INFO - 2016-03-04 06:14:30 --> Loader Class Initialized
INFO - 2016-03-04 06:14:30 --> Helper loaded: url_helper
INFO - 2016-03-04 06:14:30 --> Helper loaded: file_helper
INFO - 2016-03-04 06:14:30 --> Helper loaded: date_helper
INFO - 2016-03-04 06:14:30 --> Helper loaded: form_helper
INFO - 2016-03-04 06:14:30 --> Database Driver Class Initialized
INFO - 2016-03-04 06:14:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:14:32 --> Controller Class Initialized
INFO - 2016-03-04 06:14:32 --> Model Class Initialized
INFO - 2016-03-04 06:14:32 --> Model Class Initialized
INFO - 2016-03-04 06:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:14:32 --> Pagination Class Initialized
INFO - 2016-03-04 06:14:32 --> Helper loaded: text_helper
INFO - 2016-03-04 06:14:32 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:14:32 --> Final output sent to browser
DEBUG - 2016-03-04 09:14:32 --> Total execution time: 1.2192
INFO - 2016-03-04 06:15:01 --> Config Class Initialized
INFO - 2016-03-04 06:15:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:15:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:15:01 --> Utf8 Class Initialized
INFO - 2016-03-04 06:15:01 --> URI Class Initialized
INFO - 2016-03-04 06:15:01 --> Router Class Initialized
INFO - 2016-03-04 06:15:01 --> Output Class Initialized
INFO - 2016-03-04 06:15:01 --> Security Class Initialized
DEBUG - 2016-03-04 06:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:15:01 --> Input Class Initialized
INFO - 2016-03-04 06:15:01 --> Language Class Initialized
INFO - 2016-03-04 06:15:01 --> Loader Class Initialized
INFO - 2016-03-04 06:15:01 --> Helper loaded: url_helper
INFO - 2016-03-04 06:15:01 --> Helper loaded: file_helper
INFO - 2016-03-04 06:15:01 --> Helper loaded: date_helper
INFO - 2016-03-04 06:15:01 --> Helper loaded: form_helper
INFO - 2016-03-04 06:15:01 --> Database Driver Class Initialized
INFO - 2016-03-04 06:15:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:15:02 --> Controller Class Initialized
INFO - 2016-03-04 06:15:02 --> Model Class Initialized
INFO - 2016-03-04 06:15:02 --> Model Class Initialized
INFO - 2016-03-04 06:15:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:15:02 --> Pagination Class Initialized
INFO - 2016-03-04 06:15:02 --> Helper loaded: text_helper
INFO - 2016-03-04 06:15:02 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:15:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:15:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:15:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:15:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:15:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:15:03 --> Final output sent to browser
DEBUG - 2016-03-04 09:15:03 --> Total execution time: 1.1625
INFO - 2016-03-04 06:15:33 --> Config Class Initialized
INFO - 2016-03-04 06:15:33 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:15:33 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:15:33 --> Utf8 Class Initialized
INFO - 2016-03-04 06:15:33 --> URI Class Initialized
INFO - 2016-03-04 06:15:33 --> Router Class Initialized
INFO - 2016-03-04 06:15:33 --> Output Class Initialized
INFO - 2016-03-04 06:15:33 --> Security Class Initialized
DEBUG - 2016-03-04 06:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:15:33 --> Input Class Initialized
INFO - 2016-03-04 06:15:33 --> Language Class Initialized
INFO - 2016-03-04 06:15:33 --> Loader Class Initialized
INFO - 2016-03-04 06:15:33 --> Helper loaded: url_helper
INFO - 2016-03-04 06:15:33 --> Helper loaded: file_helper
INFO - 2016-03-04 06:15:33 --> Helper loaded: date_helper
INFO - 2016-03-04 06:15:33 --> Helper loaded: form_helper
INFO - 2016-03-04 06:15:33 --> Database Driver Class Initialized
INFO - 2016-03-04 06:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:15:34 --> Controller Class Initialized
INFO - 2016-03-04 06:15:34 --> Model Class Initialized
INFO - 2016-03-04 06:15:34 --> Model Class Initialized
INFO - 2016-03-04 06:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:15:34 --> Pagination Class Initialized
INFO - 2016-03-04 06:15:34 --> Helper loaded: text_helper
INFO - 2016-03-04 06:15:34 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:15:34 --> Final output sent to browser
DEBUG - 2016-03-04 09:15:34 --> Total execution time: 1.1428
INFO - 2016-03-04 06:16:29 --> Config Class Initialized
INFO - 2016-03-04 06:16:29 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:16:29 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:16:29 --> Utf8 Class Initialized
INFO - 2016-03-04 06:16:29 --> URI Class Initialized
INFO - 2016-03-04 06:16:29 --> Router Class Initialized
INFO - 2016-03-04 06:16:29 --> Output Class Initialized
INFO - 2016-03-04 06:16:29 --> Security Class Initialized
DEBUG - 2016-03-04 06:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:16:29 --> Input Class Initialized
INFO - 2016-03-04 06:16:29 --> Language Class Initialized
INFO - 2016-03-04 06:16:29 --> Loader Class Initialized
INFO - 2016-03-04 06:16:29 --> Helper loaded: url_helper
INFO - 2016-03-04 06:16:29 --> Helper loaded: file_helper
INFO - 2016-03-04 06:16:29 --> Helper loaded: date_helper
INFO - 2016-03-04 06:16:29 --> Helper loaded: form_helper
INFO - 2016-03-04 06:16:29 --> Database Driver Class Initialized
INFO - 2016-03-04 06:16:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:16:31 --> Controller Class Initialized
INFO - 2016-03-04 06:16:31 --> Model Class Initialized
INFO - 2016-03-04 06:16:31 --> Model Class Initialized
INFO - 2016-03-04 06:16:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:16:31 --> Pagination Class Initialized
INFO - 2016-03-04 06:16:31 --> Helper loaded: text_helper
INFO - 2016-03-04 06:16:31 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:16:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:16:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:16:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:16:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:16:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:16:31 --> Final output sent to browser
DEBUG - 2016-03-04 09:16:31 --> Total execution time: 1.1941
INFO - 2016-03-04 06:16:54 --> Config Class Initialized
INFO - 2016-03-04 06:16:54 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:16:54 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:16:54 --> Utf8 Class Initialized
INFO - 2016-03-04 06:16:54 --> URI Class Initialized
INFO - 2016-03-04 06:16:54 --> Router Class Initialized
INFO - 2016-03-04 06:16:54 --> Output Class Initialized
INFO - 2016-03-04 06:16:54 --> Security Class Initialized
DEBUG - 2016-03-04 06:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:16:54 --> Input Class Initialized
INFO - 2016-03-04 06:16:54 --> Language Class Initialized
INFO - 2016-03-04 06:16:54 --> Loader Class Initialized
INFO - 2016-03-04 06:16:54 --> Helper loaded: url_helper
INFO - 2016-03-04 06:16:54 --> Helper loaded: file_helper
INFO - 2016-03-04 06:16:54 --> Helper loaded: date_helper
INFO - 2016-03-04 06:16:54 --> Helper loaded: form_helper
INFO - 2016-03-04 06:16:54 --> Database Driver Class Initialized
INFO - 2016-03-04 06:16:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:16:55 --> Controller Class Initialized
INFO - 2016-03-04 06:16:55 --> Model Class Initialized
INFO - 2016-03-04 06:16:55 --> Model Class Initialized
INFO - 2016-03-04 06:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:16:55 --> Pagination Class Initialized
INFO - 2016-03-04 06:16:55 --> Helper loaded: text_helper
INFO - 2016-03-04 06:16:55 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:16:55 --> Final output sent to browser
DEBUG - 2016-03-04 09:16:55 --> Total execution time: 1.1722
INFO - 2016-03-04 06:17:14 --> Config Class Initialized
INFO - 2016-03-04 06:17:14 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:17:14 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:17:14 --> Utf8 Class Initialized
INFO - 2016-03-04 06:17:14 --> URI Class Initialized
INFO - 2016-03-04 06:17:14 --> Router Class Initialized
INFO - 2016-03-04 06:17:14 --> Output Class Initialized
INFO - 2016-03-04 06:17:14 --> Security Class Initialized
DEBUG - 2016-03-04 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:17:14 --> Input Class Initialized
INFO - 2016-03-04 06:17:14 --> Language Class Initialized
INFO - 2016-03-04 06:17:14 --> Loader Class Initialized
INFO - 2016-03-04 06:17:14 --> Helper loaded: url_helper
INFO - 2016-03-04 06:17:14 --> Helper loaded: file_helper
INFO - 2016-03-04 06:17:14 --> Helper loaded: date_helper
INFO - 2016-03-04 06:17:14 --> Helper loaded: form_helper
INFO - 2016-03-04 06:17:14 --> Database Driver Class Initialized
INFO - 2016-03-04 06:17:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:17:15 --> Controller Class Initialized
INFO - 2016-03-04 06:17:15 --> Model Class Initialized
INFO - 2016-03-04 06:17:15 --> Model Class Initialized
INFO - 2016-03-04 06:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:17:15 --> Pagination Class Initialized
INFO - 2016-03-04 06:17:15 --> Helper loaded: text_helper
INFO - 2016-03-04 06:17:15 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:17:15 --> Final output sent to browser
DEBUG - 2016-03-04 09:17:15 --> Total execution time: 1.2120
INFO - 2016-03-04 06:18:22 --> Config Class Initialized
INFO - 2016-03-04 06:18:22 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:18:22 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:18:22 --> Utf8 Class Initialized
INFO - 2016-03-04 06:18:22 --> URI Class Initialized
INFO - 2016-03-04 06:18:22 --> Router Class Initialized
INFO - 2016-03-04 06:18:22 --> Output Class Initialized
INFO - 2016-03-04 06:18:22 --> Security Class Initialized
DEBUG - 2016-03-04 06:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:18:22 --> Input Class Initialized
INFO - 2016-03-04 06:18:22 --> Language Class Initialized
INFO - 2016-03-04 06:18:22 --> Loader Class Initialized
INFO - 2016-03-04 06:18:22 --> Helper loaded: url_helper
INFO - 2016-03-04 06:18:22 --> Helper loaded: file_helper
INFO - 2016-03-04 06:18:22 --> Helper loaded: date_helper
INFO - 2016-03-04 06:18:22 --> Helper loaded: form_helper
INFO - 2016-03-04 06:18:22 --> Database Driver Class Initialized
INFO - 2016-03-04 06:18:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:18:23 --> Controller Class Initialized
INFO - 2016-03-04 06:18:23 --> Model Class Initialized
INFO - 2016-03-04 06:18:23 --> Model Class Initialized
INFO - 2016-03-04 06:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:18:23 --> Pagination Class Initialized
INFO - 2016-03-04 06:18:23 --> Helper loaded: text_helper
INFO - 2016-03-04 06:18:23 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:18:23 --> Final output sent to browser
DEBUG - 2016-03-04 09:18:23 --> Total execution time: 1.1729
INFO - 2016-03-04 06:18:41 --> Config Class Initialized
INFO - 2016-03-04 06:18:41 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:18:41 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:18:41 --> Utf8 Class Initialized
INFO - 2016-03-04 06:18:41 --> URI Class Initialized
INFO - 2016-03-04 06:18:41 --> Router Class Initialized
INFO - 2016-03-04 06:18:41 --> Output Class Initialized
INFO - 2016-03-04 06:18:41 --> Security Class Initialized
DEBUG - 2016-03-04 06:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:18:41 --> Input Class Initialized
INFO - 2016-03-04 06:18:41 --> Language Class Initialized
INFO - 2016-03-04 06:18:41 --> Loader Class Initialized
INFO - 2016-03-04 06:18:41 --> Helper loaded: url_helper
INFO - 2016-03-04 06:18:41 --> Helper loaded: file_helper
INFO - 2016-03-04 06:18:41 --> Helper loaded: date_helper
INFO - 2016-03-04 06:18:41 --> Helper loaded: form_helper
INFO - 2016-03-04 06:18:41 --> Database Driver Class Initialized
INFO - 2016-03-04 06:18:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:18:42 --> Controller Class Initialized
INFO - 2016-03-04 06:18:42 --> Model Class Initialized
INFO - 2016-03-04 06:18:42 --> Model Class Initialized
INFO - 2016-03-04 06:18:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:18:42 --> Pagination Class Initialized
INFO - 2016-03-04 06:18:42 --> Helper loaded: text_helper
INFO - 2016-03-04 06:18:42 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:18:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:18:42 --> Final output sent to browser
DEBUG - 2016-03-04 09:18:42 --> Total execution time: 1.2266
INFO - 2016-03-04 06:19:02 --> Config Class Initialized
INFO - 2016-03-04 06:19:02 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:19:02 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:19:02 --> Utf8 Class Initialized
INFO - 2016-03-04 06:19:02 --> URI Class Initialized
INFO - 2016-03-04 06:19:02 --> Router Class Initialized
INFO - 2016-03-04 06:19:02 --> Output Class Initialized
INFO - 2016-03-04 06:19:02 --> Security Class Initialized
DEBUG - 2016-03-04 06:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:19:02 --> Input Class Initialized
INFO - 2016-03-04 06:19:02 --> Language Class Initialized
INFO - 2016-03-04 06:19:02 --> Loader Class Initialized
INFO - 2016-03-04 06:19:02 --> Helper loaded: url_helper
INFO - 2016-03-04 06:19:02 --> Helper loaded: file_helper
INFO - 2016-03-04 06:19:02 --> Helper loaded: date_helper
INFO - 2016-03-04 06:19:03 --> Helper loaded: form_helper
INFO - 2016-03-04 06:19:03 --> Database Driver Class Initialized
INFO - 2016-03-04 06:19:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:19:04 --> Controller Class Initialized
INFO - 2016-03-04 06:19:04 --> Model Class Initialized
INFO - 2016-03-04 06:19:04 --> Model Class Initialized
INFO - 2016-03-04 06:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:19:04 --> Pagination Class Initialized
INFO - 2016-03-04 06:19:04 --> Helper loaded: text_helper
INFO - 2016-03-04 06:19:04 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 09:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 09:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:19:04 --> Final output sent to browser
DEBUG - 2016-03-04 09:19:04 --> Total execution time: 1.2260
INFO - 2016-03-04 06:29:57 --> Config Class Initialized
INFO - 2016-03-04 06:29:57 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:29:58 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:29:58 --> Utf8 Class Initialized
INFO - 2016-03-04 06:29:58 --> URI Class Initialized
INFO - 2016-03-04 06:29:58 --> Router Class Initialized
INFO - 2016-03-04 06:29:58 --> Output Class Initialized
INFO - 2016-03-04 06:29:58 --> Security Class Initialized
DEBUG - 2016-03-04 06:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:29:58 --> Input Class Initialized
INFO - 2016-03-04 06:29:58 --> Language Class Initialized
INFO - 2016-03-04 06:29:58 --> Loader Class Initialized
INFO - 2016-03-04 06:29:58 --> Helper loaded: url_helper
INFO - 2016-03-04 06:29:58 --> Helper loaded: file_helper
INFO - 2016-03-04 06:29:58 --> Helper loaded: date_helper
INFO - 2016-03-04 06:29:58 --> Helper loaded: form_helper
INFO - 2016-03-04 06:29:58 --> Database Driver Class Initialized
INFO - 2016-03-04 06:29:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:29:59 --> Controller Class Initialized
INFO - 2016-03-04 06:29:59 --> Model Class Initialized
INFO - 2016-03-04 06:29:59 --> Model Class Initialized
INFO - 2016-03-04 06:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:29:59 --> Pagination Class Initialized
INFO - 2016-03-04 06:29:59 --> Helper loaded: text_helper
INFO - 2016-03-04 06:29:59 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:29:59 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-04 09:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-04 09:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:29:59 --> Final output sent to browser
DEBUG - 2016-03-04 09:29:59 --> Total execution time: 1.1261
INFO - 2016-03-04 06:32:06 --> Config Class Initialized
INFO - 2016-03-04 06:32:06 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:32:06 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:32:06 --> Utf8 Class Initialized
INFO - 2016-03-04 06:32:06 --> URI Class Initialized
INFO - 2016-03-04 06:32:06 --> Router Class Initialized
INFO - 2016-03-04 06:32:06 --> Output Class Initialized
INFO - 2016-03-04 06:32:06 --> Security Class Initialized
DEBUG - 2016-03-04 06:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:32:06 --> Input Class Initialized
INFO - 2016-03-04 06:32:06 --> Language Class Initialized
INFO - 2016-03-04 06:32:06 --> Loader Class Initialized
INFO - 2016-03-04 06:32:06 --> Helper loaded: url_helper
INFO - 2016-03-04 06:32:06 --> Helper loaded: file_helper
INFO - 2016-03-04 06:32:06 --> Helper loaded: date_helper
INFO - 2016-03-04 06:32:06 --> Helper loaded: form_helper
INFO - 2016-03-04 06:32:06 --> Database Driver Class Initialized
INFO - 2016-03-04 06:32:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:32:07 --> Controller Class Initialized
INFO - 2016-03-04 06:32:07 --> Model Class Initialized
INFO - 2016-03-04 06:32:07 --> Model Class Initialized
INFO - 2016-03-04 06:32:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:32:07 --> Pagination Class Initialized
INFO - 2016-03-04 06:32:07 --> Helper loaded: text_helper
INFO - 2016-03-04 06:32:07 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:32:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:32:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:32:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:32:07 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:32:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:32:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:32:07 --> Final output sent to browser
DEBUG - 2016-03-04 09:32:07 --> Total execution time: 1.1163
INFO - 2016-03-04 06:32:44 --> Config Class Initialized
INFO - 2016-03-04 06:32:44 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:32:44 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:32:44 --> Utf8 Class Initialized
INFO - 2016-03-04 06:32:44 --> URI Class Initialized
INFO - 2016-03-04 06:32:44 --> Router Class Initialized
INFO - 2016-03-04 06:32:44 --> Output Class Initialized
INFO - 2016-03-04 06:32:44 --> Security Class Initialized
DEBUG - 2016-03-04 06:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:32:44 --> Input Class Initialized
INFO - 2016-03-04 06:32:44 --> Language Class Initialized
INFO - 2016-03-04 06:32:44 --> Loader Class Initialized
INFO - 2016-03-04 06:32:44 --> Helper loaded: url_helper
INFO - 2016-03-04 06:32:44 --> Helper loaded: file_helper
INFO - 2016-03-04 06:32:44 --> Helper loaded: date_helper
INFO - 2016-03-04 06:32:44 --> Helper loaded: form_helper
INFO - 2016-03-04 06:32:44 --> Database Driver Class Initialized
INFO - 2016-03-04 06:32:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:32:45 --> Controller Class Initialized
INFO - 2016-03-04 06:32:45 --> Model Class Initialized
INFO - 2016-03-04 06:32:45 --> Model Class Initialized
INFO - 2016-03-04 06:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:32:45 --> Pagination Class Initialized
INFO - 2016-03-04 06:32:45 --> Helper loaded: text_helper
INFO - 2016-03-04 06:32:45 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:32:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:32:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:32:45 --> Final output sent to browser
DEBUG - 2016-03-04 09:32:45 --> Total execution time: 1.1419
INFO - 2016-03-04 06:33:10 --> Config Class Initialized
INFO - 2016-03-04 06:33:10 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:33:10 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:33:10 --> Utf8 Class Initialized
INFO - 2016-03-04 06:33:10 --> URI Class Initialized
DEBUG - 2016-03-04 06:33:10 --> No URI present. Default controller set.
INFO - 2016-03-04 06:33:10 --> Router Class Initialized
INFO - 2016-03-04 06:33:10 --> Output Class Initialized
INFO - 2016-03-04 06:33:10 --> Security Class Initialized
DEBUG - 2016-03-04 06:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:33:10 --> Input Class Initialized
INFO - 2016-03-04 06:33:10 --> Language Class Initialized
INFO - 2016-03-04 06:33:10 --> Loader Class Initialized
INFO - 2016-03-04 06:33:10 --> Helper loaded: url_helper
INFO - 2016-03-04 06:33:10 --> Helper loaded: file_helper
INFO - 2016-03-04 06:33:10 --> Helper loaded: date_helper
INFO - 2016-03-04 06:33:10 --> Helper loaded: form_helper
INFO - 2016-03-04 06:33:10 --> Database Driver Class Initialized
INFO - 2016-03-04 06:33:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:33:11 --> Controller Class Initialized
INFO - 2016-03-04 06:33:11 --> Model Class Initialized
INFO - 2016-03-04 06:33:11 --> Model Class Initialized
INFO - 2016-03-04 06:33:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:33:11 --> Pagination Class Initialized
INFO - 2016-03-04 06:33:11 --> Helper loaded: text_helper
INFO - 2016-03-04 06:33:11 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 09:33:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:33:11 --> Final output sent to browser
DEBUG - 2016-03-04 09:33:11 --> Total execution time: 1.1674
INFO - 2016-03-04 06:33:14 --> Config Class Initialized
INFO - 2016-03-04 06:33:14 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:33:14 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:33:14 --> Utf8 Class Initialized
INFO - 2016-03-04 06:33:14 --> URI Class Initialized
INFO - 2016-03-04 06:33:14 --> Router Class Initialized
INFO - 2016-03-04 06:33:14 --> Output Class Initialized
INFO - 2016-03-04 06:33:14 --> Security Class Initialized
DEBUG - 2016-03-04 06:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:33:14 --> Input Class Initialized
INFO - 2016-03-04 06:33:14 --> Language Class Initialized
INFO - 2016-03-04 06:33:14 --> Loader Class Initialized
INFO - 2016-03-04 06:33:14 --> Helper loaded: url_helper
INFO - 2016-03-04 06:33:14 --> Helper loaded: file_helper
INFO - 2016-03-04 06:33:14 --> Helper loaded: date_helper
INFO - 2016-03-04 06:33:14 --> Helper loaded: form_helper
INFO - 2016-03-04 06:33:14 --> Database Driver Class Initialized
INFO - 2016-03-04 06:33:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:33:15 --> Controller Class Initialized
INFO - 2016-03-04 06:33:15 --> Model Class Initialized
INFO - 2016-03-04 06:33:15 --> Model Class Initialized
INFO - 2016-03-04 06:33:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:33:15 --> Pagination Class Initialized
INFO - 2016-03-04 06:33:15 --> Helper loaded: text_helper
INFO - 2016-03-04 06:33:15 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:33:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:33:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:33:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:33:15 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:33:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:33:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:33:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:33:15 --> Final output sent to browser
DEBUG - 2016-03-04 09:33:15 --> Total execution time: 1.1252
INFO - 2016-03-04 06:35:35 --> Config Class Initialized
INFO - 2016-03-04 06:35:35 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:35:35 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:35:35 --> Utf8 Class Initialized
INFO - 2016-03-04 06:35:35 --> URI Class Initialized
INFO - 2016-03-04 06:35:35 --> Router Class Initialized
INFO - 2016-03-04 06:35:35 --> Output Class Initialized
INFO - 2016-03-04 06:35:35 --> Security Class Initialized
DEBUG - 2016-03-04 06:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:35:35 --> Input Class Initialized
INFO - 2016-03-04 06:35:35 --> Language Class Initialized
INFO - 2016-03-04 06:35:35 --> Loader Class Initialized
INFO - 2016-03-04 06:35:35 --> Helper loaded: url_helper
INFO - 2016-03-04 06:35:35 --> Helper loaded: file_helper
INFO - 2016-03-04 06:35:35 --> Helper loaded: date_helper
INFO - 2016-03-04 06:35:35 --> Helper loaded: form_helper
INFO - 2016-03-04 06:35:35 --> Database Driver Class Initialized
INFO - 2016-03-04 06:35:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:35:36 --> Controller Class Initialized
INFO - 2016-03-04 06:35:36 --> Model Class Initialized
INFO - 2016-03-04 06:35:36 --> Model Class Initialized
INFO - 2016-03-04 06:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:35:36 --> Pagination Class Initialized
INFO - 2016-03-04 06:35:36 --> Helper loaded: text_helper
INFO - 2016-03-04 06:35:36 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:35:36 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:35:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:35:36 --> Final output sent to browser
DEBUG - 2016-03-04 09:35:36 --> Total execution time: 1.1471
INFO - 2016-03-04 06:37:16 --> Config Class Initialized
INFO - 2016-03-04 06:37:16 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:37:16 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:37:16 --> Utf8 Class Initialized
INFO - 2016-03-04 06:37:16 --> URI Class Initialized
INFO - 2016-03-04 06:37:16 --> Router Class Initialized
INFO - 2016-03-04 06:37:16 --> Output Class Initialized
INFO - 2016-03-04 06:37:16 --> Security Class Initialized
DEBUG - 2016-03-04 06:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:37:16 --> Input Class Initialized
INFO - 2016-03-04 06:37:16 --> Language Class Initialized
INFO - 2016-03-04 06:37:16 --> Loader Class Initialized
INFO - 2016-03-04 06:37:16 --> Helper loaded: url_helper
INFO - 2016-03-04 06:37:16 --> Helper loaded: file_helper
INFO - 2016-03-04 06:37:16 --> Helper loaded: date_helper
INFO - 2016-03-04 06:37:16 --> Helper loaded: form_helper
INFO - 2016-03-04 06:37:16 --> Database Driver Class Initialized
INFO - 2016-03-04 06:37:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:37:17 --> Controller Class Initialized
INFO - 2016-03-04 06:37:17 --> Model Class Initialized
INFO - 2016-03-04 06:37:17 --> Model Class Initialized
INFO - 2016-03-04 06:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:37:17 --> Pagination Class Initialized
INFO - 2016-03-04 06:37:17 --> Helper loaded: text_helper
INFO - 2016-03-04 06:37:17 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:37:17 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:37:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:37:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:37:17 --> Final output sent to browser
DEBUG - 2016-03-04 09:37:17 --> Total execution time: 1.1374
INFO - 2016-03-04 06:38:04 --> Config Class Initialized
INFO - 2016-03-04 06:38:04 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:38:04 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:38:04 --> Utf8 Class Initialized
INFO - 2016-03-04 06:38:04 --> URI Class Initialized
INFO - 2016-03-04 06:38:04 --> Router Class Initialized
INFO - 2016-03-04 06:38:04 --> Output Class Initialized
INFO - 2016-03-04 06:38:04 --> Security Class Initialized
DEBUG - 2016-03-04 06:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:38:04 --> Input Class Initialized
INFO - 2016-03-04 06:38:04 --> Language Class Initialized
INFO - 2016-03-04 06:38:04 --> Loader Class Initialized
INFO - 2016-03-04 06:38:04 --> Helper loaded: url_helper
INFO - 2016-03-04 06:38:04 --> Helper loaded: file_helper
INFO - 2016-03-04 06:38:04 --> Helper loaded: date_helper
INFO - 2016-03-04 06:38:04 --> Helper loaded: form_helper
INFO - 2016-03-04 06:38:04 --> Database Driver Class Initialized
INFO - 2016-03-04 06:38:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:38:05 --> Controller Class Initialized
INFO - 2016-03-04 06:38:05 --> Model Class Initialized
INFO - 2016-03-04 06:38:05 --> Model Class Initialized
INFO - 2016-03-04 06:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:38:05 --> Pagination Class Initialized
INFO - 2016-03-04 06:38:05 --> Helper loaded: text_helper
INFO - 2016-03-04 06:38:05 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:38:05 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:38:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:38:05 --> Final output sent to browser
DEBUG - 2016-03-04 09:38:05 --> Total execution time: 1.1507
INFO - 2016-03-04 06:38:44 --> Config Class Initialized
INFO - 2016-03-04 06:38:44 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:38:44 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:38:44 --> Utf8 Class Initialized
INFO - 2016-03-04 06:38:44 --> URI Class Initialized
INFO - 2016-03-04 06:38:44 --> Router Class Initialized
INFO - 2016-03-04 06:38:44 --> Output Class Initialized
INFO - 2016-03-04 06:38:44 --> Security Class Initialized
DEBUG - 2016-03-04 06:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:38:44 --> Input Class Initialized
INFO - 2016-03-04 06:38:44 --> Language Class Initialized
INFO - 2016-03-04 06:38:44 --> Loader Class Initialized
INFO - 2016-03-04 06:38:44 --> Helper loaded: url_helper
INFO - 2016-03-04 06:38:44 --> Helper loaded: file_helper
INFO - 2016-03-04 06:38:44 --> Helper loaded: date_helper
INFO - 2016-03-04 06:38:44 --> Helper loaded: form_helper
INFO - 2016-03-04 06:38:44 --> Database Driver Class Initialized
INFO - 2016-03-04 06:38:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:38:45 --> Controller Class Initialized
INFO - 2016-03-04 06:38:45 --> Model Class Initialized
INFO - 2016-03-04 06:38:45 --> Model Class Initialized
INFO - 2016-03-04 06:38:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:38:45 --> Pagination Class Initialized
INFO - 2016-03-04 06:38:45 --> Helper loaded: text_helper
INFO - 2016-03-04 06:38:45 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:38:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:38:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:38:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:38:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:38:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:38:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:38:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:38:45 --> Final output sent to browser
DEBUG - 2016-03-04 09:38:45 --> Total execution time: 1.1154
INFO - 2016-03-04 06:38:57 --> Config Class Initialized
INFO - 2016-03-04 06:38:57 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:38:57 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:38:57 --> Utf8 Class Initialized
INFO - 2016-03-04 06:38:57 --> URI Class Initialized
INFO - 2016-03-04 06:38:57 --> Router Class Initialized
INFO - 2016-03-04 06:38:57 --> Output Class Initialized
INFO - 2016-03-04 06:38:57 --> Security Class Initialized
DEBUG - 2016-03-04 06:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:38:57 --> Input Class Initialized
INFO - 2016-03-04 06:38:57 --> Language Class Initialized
INFO - 2016-03-04 06:38:57 --> Loader Class Initialized
INFO - 2016-03-04 06:38:57 --> Helper loaded: url_helper
INFO - 2016-03-04 06:38:57 --> Helper loaded: file_helper
INFO - 2016-03-04 06:38:57 --> Helper loaded: date_helper
INFO - 2016-03-04 06:38:57 --> Helper loaded: form_helper
INFO - 2016-03-04 06:38:57 --> Database Driver Class Initialized
INFO - 2016-03-04 06:38:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:38:58 --> Controller Class Initialized
INFO - 2016-03-04 06:38:58 --> Model Class Initialized
INFO - 2016-03-04 06:38:58 --> Model Class Initialized
INFO - 2016-03-04 06:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:38:58 --> Pagination Class Initialized
INFO - 2016-03-04 06:38:58 --> Helper loaded: text_helper
INFO - 2016-03-04 06:38:58 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:38:58 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:38:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:38:58 --> Final output sent to browser
DEBUG - 2016-03-04 09:38:58 --> Total execution time: 1.2574
INFO - 2016-03-04 06:39:11 --> Config Class Initialized
INFO - 2016-03-04 06:39:11 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:39:11 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:39:11 --> Utf8 Class Initialized
INFO - 2016-03-04 06:39:11 --> URI Class Initialized
INFO - 2016-03-04 06:39:11 --> Router Class Initialized
INFO - 2016-03-04 06:39:11 --> Output Class Initialized
INFO - 2016-03-04 06:39:11 --> Security Class Initialized
DEBUG - 2016-03-04 06:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:39:11 --> Input Class Initialized
INFO - 2016-03-04 06:39:11 --> Language Class Initialized
INFO - 2016-03-04 06:39:11 --> Loader Class Initialized
INFO - 2016-03-04 06:39:11 --> Helper loaded: url_helper
INFO - 2016-03-04 06:39:11 --> Helper loaded: file_helper
INFO - 2016-03-04 06:39:11 --> Helper loaded: date_helper
INFO - 2016-03-04 06:39:11 --> Helper loaded: form_helper
INFO - 2016-03-04 06:39:11 --> Database Driver Class Initialized
INFO - 2016-03-04 06:39:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:39:12 --> Controller Class Initialized
INFO - 2016-03-04 06:39:12 --> Model Class Initialized
INFO - 2016-03-04 06:39:12 --> Model Class Initialized
INFO - 2016-03-04 06:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:39:12 --> Pagination Class Initialized
INFO - 2016-03-04 06:39:12 --> Helper loaded: text_helper
INFO - 2016-03-04 06:39:12 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:39:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:39:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:39:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:39:12 --> Final output sent to browser
DEBUG - 2016-03-04 09:39:12 --> Total execution time: 1.1155
INFO - 2016-03-04 06:39:21 --> Config Class Initialized
INFO - 2016-03-04 06:39:21 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:39:21 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:39:21 --> Utf8 Class Initialized
INFO - 2016-03-04 06:39:21 --> URI Class Initialized
INFO - 2016-03-04 06:39:21 --> Router Class Initialized
INFO - 2016-03-04 06:39:21 --> Output Class Initialized
INFO - 2016-03-04 06:39:21 --> Security Class Initialized
DEBUG - 2016-03-04 06:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:39:21 --> Input Class Initialized
INFO - 2016-03-04 06:39:21 --> Language Class Initialized
INFO - 2016-03-04 06:39:21 --> Loader Class Initialized
INFO - 2016-03-04 06:39:21 --> Helper loaded: url_helper
INFO - 2016-03-04 06:39:21 --> Helper loaded: file_helper
INFO - 2016-03-04 06:39:21 --> Helper loaded: date_helper
INFO - 2016-03-04 06:39:21 --> Helper loaded: form_helper
INFO - 2016-03-04 06:39:21 --> Database Driver Class Initialized
INFO - 2016-03-04 06:39:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:39:22 --> Controller Class Initialized
INFO - 2016-03-04 06:39:22 --> Model Class Initialized
INFO - 2016-03-04 06:39:22 --> Model Class Initialized
INFO - 2016-03-04 06:39:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:39:22 --> Pagination Class Initialized
INFO - 2016-03-04 06:39:22 --> Helper loaded: text_helper
INFO - 2016-03-04 06:39:22 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:39:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:39:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:39:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:39:22 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:39:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:39:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:39:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:39:22 --> Final output sent to browser
DEBUG - 2016-03-04 09:39:22 --> Total execution time: 1.1197
INFO - 2016-03-04 06:39:26 --> Config Class Initialized
INFO - 2016-03-04 06:39:26 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:39:26 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:39:26 --> Utf8 Class Initialized
INFO - 2016-03-04 06:39:26 --> URI Class Initialized
INFO - 2016-03-04 06:39:26 --> Router Class Initialized
INFO - 2016-03-04 06:39:26 --> Output Class Initialized
INFO - 2016-03-04 06:39:26 --> Security Class Initialized
DEBUG - 2016-03-04 06:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:39:26 --> Input Class Initialized
INFO - 2016-03-04 06:39:26 --> Language Class Initialized
INFO - 2016-03-04 06:39:26 --> Loader Class Initialized
INFO - 2016-03-04 06:39:26 --> Helper loaded: url_helper
INFO - 2016-03-04 06:39:26 --> Helper loaded: file_helper
INFO - 2016-03-04 06:39:26 --> Helper loaded: date_helper
INFO - 2016-03-04 06:39:26 --> Helper loaded: form_helper
INFO - 2016-03-04 06:39:26 --> Database Driver Class Initialized
INFO - 2016-03-04 06:39:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:39:27 --> Controller Class Initialized
INFO - 2016-03-04 06:39:27 --> Model Class Initialized
INFO - 2016-03-04 06:39:27 --> Model Class Initialized
INFO - 2016-03-04 06:39:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:39:27 --> Pagination Class Initialized
INFO - 2016-03-04 06:39:27 --> Helper loaded: text_helper
INFO - 2016-03-04 06:39:27 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:39:27 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:39:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:39:27 --> Final output sent to browser
DEBUG - 2016-03-04 09:39:27 --> Total execution time: 1.1177
INFO - 2016-03-04 06:39:43 --> Config Class Initialized
INFO - 2016-03-04 06:39:43 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:39:43 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:39:43 --> Utf8 Class Initialized
INFO - 2016-03-04 06:39:43 --> URI Class Initialized
INFO - 2016-03-04 06:39:43 --> Router Class Initialized
INFO - 2016-03-04 06:39:43 --> Output Class Initialized
INFO - 2016-03-04 06:39:43 --> Security Class Initialized
DEBUG - 2016-03-04 06:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:39:43 --> Input Class Initialized
INFO - 2016-03-04 06:39:43 --> Language Class Initialized
INFO - 2016-03-04 06:39:43 --> Loader Class Initialized
INFO - 2016-03-04 06:39:43 --> Helper loaded: url_helper
INFO - 2016-03-04 06:39:43 --> Helper loaded: file_helper
INFO - 2016-03-04 06:39:43 --> Helper loaded: date_helper
INFO - 2016-03-04 06:39:43 --> Helper loaded: form_helper
INFO - 2016-03-04 06:39:43 --> Database Driver Class Initialized
INFO - 2016-03-04 06:39:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:39:44 --> Controller Class Initialized
INFO - 2016-03-04 06:39:45 --> Model Class Initialized
INFO - 2016-03-04 06:39:45 --> Model Class Initialized
INFO - 2016-03-04 06:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:39:45 --> Pagination Class Initialized
INFO - 2016-03-04 06:39:45 --> Helper loaded: text_helper
INFO - 2016-03-04 06:39:45 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:39:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:39:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:39:45 --> Final output sent to browser
DEBUG - 2016-03-04 09:39:45 --> Total execution time: 1.1237
INFO - 2016-03-04 06:39:53 --> Config Class Initialized
INFO - 2016-03-04 06:39:53 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:39:53 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:39:53 --> Utf8 Class Initialized
INFO - 2016-03-04 06:39:53 --> URI Class Initialized
INFO - 2016-03-04 06:39:53 --> Router Class Initialized
INFO - 2016-03-04 06:39:53 --> Output Class Initialized
INFO - 2016-03-04 06:39:53 --> Security Class Initialized
DEBUG - 2016-03-04 06:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:39:53 --> Input Class Initialized
INFO - 2016-03-04 06:39:53 --> Language Class Initialized
INFO - 2016-03-04 06:39:53 --> Loader Class Initialized
INFO - 2016-03-04 06:39:53 --> Helper loaded: url_helper
INFO - 2016-03-04 06:39:53 --> Helper loaded: file_helper
INFO - 2016-03-04 06:39:53 --> Helper loaded: date_helper
INFO - 2016-03-04 06:39:53 --> Helper loaded: form_helper
INFO - 2016-03-04 06:39:53 --> Database Driver Class Initialized
INFO - 2016-03-04 06:39:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:39:54 --> Controller Class Initialized
INFO - 2016-03-04 06:39:54 --> Model Class Initialized
INFO - 2016-03-04 06:39:54 --> Model Class Initialized
INFO - 2016-03-04 06:39:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:39:54 --> Pagination Class Initialized
INFO - 2016-03-04 06:39:54 --> Helper loaded: text_helper
INFO - 2016-03-04 06:39:54 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:39:54 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:39:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:39:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:39:54 --> Final output sent to browser
DEBUG - 2016-03-04 09:39:54 --> Total execution time: 1.1301
INFO - 2016-03-04 06:40:01 --> Config Class Initialized
INFO - 2016-03-04 06:40:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:40:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:40:01 --> Utf8 Class Initialized
INFO - 2016-03-04 06:40:01 --> URI Class Initialized
INFO - 2016-03-04 06:40:01 --> Router Class Initialized
INFO - 2016-03-04 06:40:01 --> Output Class Initialized
INFO - 2016-03-04 06:40:01 --> Security Class Initialized
DEBUG - 2016-03-04 06:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:40:01 --> Input Class Initialized
INFO - 2016-03-04 06:40:01 --> Language Class Initialized
INFO - 2016-03-04 06:40:01 --> Loader Class Initialized
INFO - 2016-03-04 06:40:01 --> Helper loaded: url_helper
INFO - 2016-03-04 06:40:01 --> Helper loaded: file_helper
INFO - 2016-03-04 06:40:01 --> Helper loaded: date_helper
INFO - 2016-03-04 06:40:01 --> Helper loaded: form_helper
INFO - 2016-03-04 06:40:01 --> Database Driver Class Initialized
INFO - 2016-03-04 06:40:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:40:03 --> Controller Class Initialized
INFO - 2016-03-04 06:40:03 --> Model Class Initialized
INFO - 2016-03-04 06:40:03 --> Model Class Initialized
INFO - 2016-03-04 06:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:40:03 --> Pagination Class Initialized
INFO - 2016-03-04 06:40:03 --> Helper loaded: text_helper
INFO - 2016-03-04 06:40:03 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:40:03 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:40:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:40:03 --> Final output sent to browser
DEBUG - 2016-03-04 09:40:03 --> Total execution time: 1.1363
INFO - 2016-03-04 06:41:12 --> Config Class Initialized
INFO - 2016-03-04 06:41:12 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:41:12 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:41:12 --> Utf8 Class Initialized
INFO - 2016-03-04 06:41:12 --> URI Class Initialized
INFO - 2016-03-04 06:41:12 --> Router Class Initialized
INFO - 2016-03-04 06:41:12 --> Output Class Initialized
INFO - 2016-03-04 06:41:12 --> Security Class Initialized
DEBUG - 2016-03-04 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:41:12 --> Input Class Initialized
INFO - 2016-03-04 06:41:12 --> Language Class Initialized
INFO - 2016-03-04 06:41:12 --> Loader Class Initialized
INFO - 2016-03-04 06:41:12 --> Helper loaded: url_helper
INFO - 2016-03-04 06:41:13 --> Helper loaded: file_helper
INFO - 2016-03-04 06:41:13 --> Helper loaded: date_helper
INFO - 2016-03-04 06:41:13 --> Helper loaded: form_helper
INFO - 2016-03-04 06:41:13 --> Database Driver Class Initialized
INFO - 2016-03-04 06:41:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:41:14 --> Controller Class Initialized
INFO - 2016-03-04 06:41:14 --> Model Class Initialized
INFO - 2016-03-04 06:41:14 --> Model Class Initialized
INFO - 2016-03-04 06:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:41:14 --> Pagination Class Initialized
INFO - 2016-03-04 06:41:14 --> Helper loaded: text_helper
INFO - 2016-03-04 06:41:14 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:41:14 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:41:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:41:14 --> Final output sent to browser
DEBUG - 2016-03-04 09:41:14 --> Total execution time: 1.1249
INFO - 2016-03-04 06:42:37 --> Config Class Initialized
INFO - 2016-03-04 06:42:37 --> Hooks Class Initialized
DEBUG - 2016-03-04 06:42:37 --> UTF-8 Support Enabled
INFO - 2016-03-04 06:42:37 --> Utf8 Class Initialized
INFO - 2016-03-04 06:42:37 --> URI Class Initialized
INFO - 2016-03-04 06:42:37 --> Router Class Initialized
INFO - 2016-03-04 06:42:37 --> Output Class Initialized
INFO - 2016-03-04 06:42:37 --> Security Class Initialized
DEBUG - 2016-03-04 06:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 06:42:37 --> Input Class Initialized
INFO - 2016-03-04 06:42:37 --> Language Class Initialized
INFO - 2016-03-04 06:42:37 --> Loader Class Initialized
INFO - 2016-03-04 06:42:37 --> Helper loaded: url_helper
INFO - 2016-03-04 06:42:37 --> Helper loaded: file_helper
INFO - 2016-03-04 06:42:37 --> Helper loaded: date_helper
INFO - 2016-03-04 06:42:37 --> Helper loaded: form_helper
INFO - 2016-03-04 06:42:37 --> Database Driver Class Initialized
INFO - 2016-03-04 06:42:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 06:42:38 --> Controller Class Initialized
INFO - 2016-03-04 06:42:38 --> Model Class Initialized
INFO - 2016-03-04 06:42:38 --> Model Class Initialized
INFO - 2016-03-04 06:42:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 06:42:38 --> Pagination Class Initialized
INFO - 2016-03-04 06:42:38 --> Helper loaded: text_helper
INFO - 2016-03-04 06:42:38 --> Helper loaded: cookie_helper
INFO - 2016-03-04 09:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 09:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 09:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 09:42:38 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 09:42:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 09:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 09:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 09:42:38 --> Final output sent to browser
DEBUG - 2016-03-04 09:42:38 --> Total execution time: 1.1208
INFO - 2016-03-04 07:18:13 --> Config Class Initialized
INFO - 2016-03-04 07:18:13 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:18:13 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:18:13 --> Utf8 Class Initialized
INFO - 2016-03-04 07:18:13 --> URI Class Initialized
INFO - 2016-03-04 07:18:13 --> Router Class Initialized
INFO - 2016-03-04 07:18:13 --> Output Class Initialized
INFO - 2016-03-04 07:18:13 --> Security Class Initialized
DEBUG - 2016-03-04 07:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:18:13 --> Input Class Initialized
INFO - 2016-03-04 07:18:13 --> Language Class Initialized
INFO - 2016-03-04 07:18:13 --> Loader Class Initialized
INFO - 2016-03-04 07:18:13 --> Helper loaded: url_helper
INFO - 2016-03-04 07:18:13 --> Helper loaded: file_helper
INFO - 2016-03-04 07:18:13 --> Helper loaded: date_helper
INFO - 2016-03-04 07:18:13 --> Helper loaded: form_helper
INFO - 2016-03-04 07:18:13 --> Database Driver Class Initialized
INFO - 2016-03-04 07:18:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:18:14 --> Controller Class Initialized
INFO - 2016-03-04 07:18:14 --> Model Class Initialized
INFO - 2016-03-04 07:18:14 --> Model Class Initialized
INFO - 2016-03-04 07:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:18:14 --> Pagination Class Initialized
INFO - 2016-03-04 07:18:14 --> Helper loaded: text_helper
INFO - 2016-03-04 07:18:14 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 10:18:14 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 10:18:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 10:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 10:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:18:14 --> Final output sent to browser
DEBUG - 2016-03-04 10:18:14 --> Total execution time: 1.1502
INFO - 2016-03-04 07:21:32 --> Config Class Initialized
INFO - 2016-03-04 07:21:32 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:21:32 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:21:32 --> Utf8 Class Initialized
INFO - 2016-03-04 07:21:32 --> URI Class Initialized
INFO - 2016-03-04 07:21:32 --> Router Class Initialized
INFO - 2016-03-04 07:21:32 --> Output Class Initialized
INFO - 2016-03-04 07:21:32 --> Security Class Initialized
DEBUG - 2016-03-04 07:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:21:32 --> Input Class Initialized
INFO - 2016-03-04 07:21:32 --> Language Class Initialized
INFO - 2016-03-04 07:21:32 --> Loader Class Initialized
INFO - 2016-03-04 07:21:32 --> Helper loaded: url_helper
INFO - 2016-03-04 07:21:32 --> Helper loaded: file_helper
INFO - 2016-03-04 07:21:32 --> Helper loaded: date_helper
INFO - 2016-03-04 07:21:32 --> Helper loaded: form_helper
INFO - 2016-03-04 07:21:32 --> Database Driver Class Initialized
INFO - 2016-03-04 07:21:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:21:33 --> Controller Class Initialized
INFO - 2016-03-04 07:21:33 --> Model Class Initialized
INFO - 2016-03-04 07:21:33 --> Model Class Initialized
INFO - 2016-03-04 07:21:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:21:33 --> Pagination Class Initialized
INFO - 2016-03-04 07:21:33 --> Helper loaded: text_helper
INFO - 2016-03-04 07:21:33 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 10:21:33 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 10:21:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 10:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 10:21:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:21:33 --> Final output sent to browser
DEBUG - 2016-03-04 10:21:33 --> Total execution time: 1.1510
INFO - 2016-03-04 07:22:06 --> Config Class Initialized
INFO - 2016-03-04 07:22:06 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:22:06 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:22:06 --> Utf8 Class Initialized
INFO - 2016-03-04 07:22:06 --> URI Class Initialized
DEBUG - 2016-03-04 07:22:06 --> No URI present. Default controller set.
INFO - 2016-03-04 07:22:06 --> Router Class Initialized
INFO - 2016-03-04 07:22:06 --> Output Class Initialized
INFO - 2016-03-04 07:22:06 --> Security Class Initialized
DEBUG - 2016-03-04 07:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:22:06 --> Input Class Initialized
INFO - 2016-03-04 07:22:06 --> Language Class Initialized
INFO - 2016-03-04 07:22:06 --> Loader Class Initialized
INFO - 2016-03-04 07:22:06 --> Helper loaded: url_helper
INFO - 2016-03-04 07:22:06 --> Helper loaded: file_helper
INFO - 2016-03-04 07:22:06 --> Helper loaded: date_helper
INFO - 2016-03-04 07:22:06 --> Helper loaded: form_helper
INFO - 2016-03-04 07:22:06 --> Database Driver Class Initialized
INFO - 2016-03-04 07:22:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:22:07 --> Controller Class Initialized
INFO - 2016-03-04 07:22:07 --> Model Class Initialized
INFO - 2016-03-04 07:22:07 --> Model Class Initialized
INFO - 2016-03-04 07:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:22:08 --> Pagination Class Initialized
INFO - 2016-03-04 07:22:08 --> Helper loaded: text_helper
INFO - 2016-03-04 07:22:08 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:22:08 --> Final output sent to browser
DEBUG - 2016-03-04 10:22:08 --> Total execution time: 1.1697
INFO - 2016-03-04 07:24:59 --> Config Class Initialized
INFO - 2016-03-04 07:24:59 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:24:59 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:24:59 --> Utf8 Class Initialized
INFO - 2016-03-04 07:24:59 --> URI Class Initialized
DEBUG - 2016-03-04 07:24:59 --> No URI present. Default controller set.
INFO - 2016-03-04 07:24:59 --> Router Class Initialized
INFO - 2016-03-04 07:24:59 --> Output Class Initialized
INFO - 2016-03-04 07:24:59 --> Security Class Initialized
DEBUG - 2016-03-04 07:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:24:59 --> Input Class Initialized
INFO - 2016-03-04 07:24:59 --> Language Class Initialized
INFO - 2016-03-04 07:24:59 --> Loader Class Initialized
INFO - 2016-03-04 07:24:59 --> Helper loaded: url_helper
INFO - 2016-03-04 07:24:59 --> Helper loaded: file_helper
INFO - 2016-03-04 07:25:00 --> Helper loaded: date_helper
INFO - 2016-03-04 07:25:00 --> Helper loaded: form_helper
INFO - 2016-03-04 07:25:00 --> Database Driver Class Initialized
INFO - 2016-03-04 07:25:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:25:01 --> Controller Class Initialized
INFO - 2016-03-04 07:25:01 --> Model Class Initialized
INFO - 2016-03-04 07:25:01 --> Model Class Initialized
INFO - 2016-03-04 07:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:25:01 --> Pagination Class Initialized
INFO - 2016-03-04 07:25:01 --> Helper loaded: text_helper
INFO - 2016-03-04 07:25:01 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:25:01 --> Final output sent to browser
DEBUG - 2016-03-04 10:25:01 --> Total execution time: 1.1420
INFO - 2016-03-04 07:25:22 --> Config Class Initialized
INFO - 2016-03-04 07:25:22 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:25:22 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:25:22 --> Utf8 Class Initialized
INFO - 2016-03-04 07:25:22 --> URI Class Initialized
DEBUG - 2016-03-04 07:25:22 --> No URI present. Default controller set.
INFO - 2016-03-04 07:25:22 --> Router Class Initialized
INFO - 2016-03-04 07:25:22 --> Output Class Initialized
INFO - 2016-03-04 07:25:22 --> Security Class Initialized
DEBUG - 2016-03-04 07:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:25:22 --> Input Class Initialized
INFO - 2016-03-04 07:25:22 --> Language Class Initialized
INFO - 2016-03-04 07:25:22 --> Loader Class Initialized
INFO - 2016-03-04 07:25:22 --> Helper loaded: url_helper
INFO - 2016-03-04 07:25:22 --> Helper loaded: file_helper
INFO - 2016-03-04 07:25:22 --> Helper loaded: date_helper
INFO - 2016-03-04 07:25:22 --> Helper loaded: form_helper
INFO - 2016-03-04 07:25:22 --> Database Driver Class Initialized
INFO - 2016-03-04 07:25:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:25:23 --> Controller Class Initialized
INFO - 2016-03-04 07:25:23 --> Model Class Initialized
INFO - 2016-03-04 07:25:23 --> Model Class Initialized
INFO - 2016-03-04 07:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:25:23 --> Pagination Class Initialized
INFO - 2016-03-04 07:25:23 --> Helper loaded: text_helper
INFO - 2016-03-04 07:25:23 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:25:23 --> Final output sent to browser
DEBUG - 2016-03-04 10:25:23 --> Total execution time: 1.1860
INFO - 2016-03-04 07:25:47 --> Config Class Initialized
INFO - 2016-03-04 07:25:47 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:25:47 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:25:47 --> Utf8 Class Initialized
INFO - 2016-03-04 07:25:47 --> URI Class Initialized
DEBUG - 2016-03-04 07:25:47 --> No URI present. Default controller set.
INFO - 2016-03-04 07:25:47 --> Router Class Initialized
INFO - 2016-03-04 07:25:47 --> Output Class Initialized
INFO - 2016-03-04 07:25:47 --> Security Class Initialized
DEBUG - 2016-03-04 07:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:25:47 --> Input Class Initialized
INFO - 2016-03-04 07:25:47 --> Language Class Initialized
INFO - 2016-03-04 07:25:47 --> Loader Class Initialized
INFO - 2016-03-04 07:25:47 --> Helper loaded: url_helper
INFO - 2016-03-04 07:25:47 --> Helper loaded: file_helper
INFO - 2016-03-04 07:25:47 --> Helper loaded: date_helper
INFO - 2016-03-04 07:25:47 --> Helper loaded: form_helper
INFO - 2016-03-04 07:25:47 --> Database Driver Class Initialized
INFO - 2016-03-04 07:25:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:25:48 --> Controller Class Initialized
INFO - 2016-03-04 07:25:48 --> Model Class Initialized
INFO - 2016-03-04 07:25:48 --> Model Class Initialized
INFO - 2016-03-04 07:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:25:48 --> Pagination Class Initialized
INFO - 2016-03-04 07:25:48 --> Helper loaded: text_helper
INFO - 2016-03-04 07:25:48 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:25:48 --> Final output sent to browser
DEBUG - 2016-03-04 10:25:48 --> Total execution time: 1.1149
INFO - 2016-03-04 07:29:41 --> Config Class Initialized
INFO - 2016-03-04 07:29:41 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:29:41 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:29:41 --> Utf8 Class Initialized
INFO - 2016-03-04 07:29:41 --> URI Class Initialized
DEBUG - 2016-03-04 07:29:41 --> No URI present. Default controller set.
INFO - 2016-03-04 07:29:41 --> Router Class Initialized
INFO - 2016-03-04 07:29:41 --> Output Class Initialized
INFO - 2016-03-04 07:29:41 --> Security Class Initialized
DEBUG - 2016-03-04 07:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:29:41 --> Input Class Initialized
INFO - 2016-03-04 07:29:41 --> Language Class Initialized
INFO - 2016-03-04 07:29:41 --> Loader Class Initialized
INFO - 2016-03-04 07:29:41 --> Helper loaded: url_helper
INFO - 2016-03-04 07:29:41 --> Helper loaded: file_helper
INFO - 2016-03-04 07:29:41 --> Helper loaded: date_helper
INFO - 2016-03-04 07:29:41 --> Helper loaded: form_helper
INFO - 2016-03-04 07:29:41 --> Database Driver Class Initialized
INFO - 2016-03-04 07:29:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:29:42 --> Controller Class Initialized
INFO - 2016-03-04 07:29:42 --> Model Class Initialized
INFO - 2016-03-04 07:29:42 --> Model Class Initialized
INFO - 2016-03-04 07:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:29:42 --> Pagination Class Initialized
INFO - 2016-03-04 07:29:42 --> Helper loaded: text_helper
INFO - 2016-03-04 07:29:42 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:29:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:29:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:29:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:29:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:29:42 --> Final output sent to browser
DEBUG - 2016-03-04 10:29:42 --> Total execution time: 1.2065
INFO - 2016-03-04 07:30:25 --> Config Class Initialized
INFO - 2016-03-04 07:30:25 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:30:25 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:30:25 --> Utf8 Class Initialized
INFO - 2016-03-04 07:30:25 --> URI Class Initialized
DEBUG - 2016-03-04 07:30:25 --> No URI present. Default controller set.
INFO - 2016-03-04 07:30:25 --> Router Class Initialized
INFO - 2016-03-04 07:30:25 --> Output Class Initialized
INFO - 2016-03-04 07:30:25 --> Security Class Initialized
DEBUG - 2016-03-04 07:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:30:25 --> Input Class Initialized
INFO - 2016-03-04 07:30:25 --> Language Class Initialized
INFO - 2016-03-04 07:30:25 --> Loader Class Initialized
INFO - 2016-03-04 07:30:25 --> Helper loaded: url_helper
INFO - 2016-03-04 07:30:25 --> Helper loaded: file_helper
INFO - 2016-03-04 07:30:25 --> Helper loaded: date_helper
INFO - 2016-03-04 07:30:25 --> Helper loaded: form_helper
INFO - 2016-03-04 07:30:25 --> Database Driver Class Initialized
INFO - 2016-03-04 07:30:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:30:26 --> Controller Class Initialized
INFO - 2016-03-04 07:30:26 --> Model Class Initialized
INFO - 2016-03-04 07:30:26 --> Model Class Initialized
INFO - 2016-03-04 07:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:30:26 --> Pagination Class Initialized
INFO - 2016-03-04 07:30:26 --> Helper loaded: text_helper
INFO - 2016-03-04 07:30:26 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:30:26 --> Final output sent to browser
DEBUG - 2016-03-04 10:30:26 --> Total execution time: 1.1517
INFO - 2016-03-04 07:32:03 --> Config Class Initialized
INFO - 2016-03-04 07:32:03 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:32:03 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:32:03 --> Utf8 Class Initialized
INFO - 2016-03-04 07:32:03 --> URI Class Initialized
DEBUG - 2016-03-04 07:32:03 --> No URI present. Default controller set.
INFO - 2016-03-04 07:32:03 --> Router Class Initialized
INFO - 2016-03-04 07:32:03 --> Output Class Initialized
INFO - 2016-03-04 07:32:03 --> Security Class Initialized
DEBUG - 2016-03-04 07:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:32:03 --> Input Class Initialized
INFO - 2016-03-04 07:32:03 --> Language Class Initialized
INFO - 2016-03-04 07:32:03 --> Loader Class Initialized
INFO - 2016-03-04 07:32:03 --> Helper loaded: url_helper
INFO - 2016-03-04 07:32:03 --> Helper loaded: file_helper
INFO - 2016-03-04 07:32:03 --> Helper loaded: date_helper
INFO - 2016-03-04 07:32:03 --> Helper loaded: form_helper
INFO - 2016-03-04 07:32:03 --> Database Driver Class Initialized
INFO - 2016-03-04 07:32:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:32:04 --> Controller Class Initialized
INFO - 2016-03-04 07:32:04 --> Model Class Initialized
INFO - 2016-03-04 07:32:04 --> Model Class Initialized
INFO - 2016-03-04 07:32:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:32:04 --> Pagination Class Initialized
INFO - 2016-03-04 07:32:04 --> Helper loaded: text_helper
INFO - 2016-03-04 07:32:04 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:32:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:32:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:32:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:32:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:32:04 --> Final output sent to browser
DEBUG - 2016-03-04 10:32:04 --> Total execution time: 1.1635
INFO - 2016-03-04 07:32:17 --> Config Class Initialized
INFO - 2016-03-04 07:32:17 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:32:17 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:32:17 --> Utf8 Class Initialized
INFO - 2016-03-04 07:32:17 --> URI Class Initialized
DEBUG - 2016-03-04 07:32:17 --> No URI present. Default controller set.
INFO - 2016-03-04 07:32:17 --> Router Class Initialized
INFO - 2016-03-04 07:32:17 --> Output Class Initialized
INFO - 2016-03-04 07:32:17 --> Security Class Initialized
DEBUG - 2016-03-04 07:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:32:17 --> Input Class Initialized
INFO - 2016-03-04 07:32:17 --> Language Class Initialized
INFO - 2016-03-04 07:32:17 --> Loader Class Initialized
INFO - 2016-03-04 07:32:17 --> Helper loaded: url_helper
INFO - 2016-03-04 07:32:17 --> Helper loaded: file_helper
INFO - 2016-03-04 07:32:17 --> Helper loaded: date_helper
INFO - 2016-03-04 07:32:17 --> Helper loaded: form_helper
INFO - 2016-03-04 07:32:17 --> Database Driver Class Initialized
INFO - 2016-03-04 07:32:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:32:18 --> Controller Class Initialized
INFO - 2016-03-04 07:32:18 --> Model Class Initialized
INFO - 2016-03-04 07:32:18 --> Model Class Initialized
INFO - 2016-03-04 07:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:32:18 --> Pagination Class Initialized
INFO - 2016-03-04 07:32:18 --> Helper loaded: text_helper
INFO - 2016-03-04 07:32:18 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:32:18 --> Final output sent to browser
DEBUG - 2016-03-04 10:32:18 --> Total execution time: 1.1646
INFO - 2016-03-04 07:32:36 --> Config Class Initialized
INFO - 2016-03-04 07:32:36 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:32:36 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:32:36 --> Utf8 Class Initialized
INFO - 2016-03-04 07:32:36 --> URI Class Initialized
DEBUG - 2016-03-04 07:32:36 --> No URI present. Default controller set.
INFO - 2016-03-04 07:32:36 --> Router Class Initialized
INFO - 2016-03-04 07:32:36 --> Output Class Initialized
INFO - 2016-03-04 07:32:36 --> Security Class Initialized
DEBUG - 2016-03-04 07:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:32:36 --> Input Class Initialized
INFO - 2016-03-04 07:32:36 --> Language Class Initialized
INFO - 2016-03-04 07:32:36 --> Loader Class Initialized
INFO - 2016-03-04 07:32:36 --> Helper loaded: url_helper
INFO - 2016-03-04 07:32:36 --> Helper loaded: file_helper
INFO - 2016-03-04 07:32:36 --> Helper loaded: date_helper
INFO - 2016-03-04 07:32:36 --> Helper loaded: form_helper
INFO - 2016-03-04 07:32:36 --> Database Driver Class Initialized
INFO - 2016-03-04 07:32:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:32:37 --> Controller Class Initialized
INFO - 2016-03-04 07:32:37 --> Model Class Initialized
INFO - 2016-03-04 07:32:37 --> Model Class Initialized
INFO - 2016-03-04 07:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:32:37 --> Pagination Class Initialized
INFO - 2016-03-04 07:32:37 --> Helper loaded: text_helper
INFO - 2016-03-04 07:32:37 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:32:37 --> Final output sent to browser
DEBUG - 2016-03-04 10:32:37 --> Total execution time: 1.1309
INFO - 2016-03-04 07:33:04 --> Config Class Initialized
INFO - 2016-03-04 07:33:04 --> Hooks Class Initialized
DEBUG - 2016-03-04 07:33:04 --> UTF-8 Support Enabled
INFO - 2016-03-04 07:33:04 --> Utf8 Class Initialized
INFO - 2016-03-04 07:33:04 --> URI Class Initialized
DEBUG - 2016-03-04 07:33:04 --> No URI present. Default controller set.
INFO - 2016-03-04 07:33:04 --> Router Class Initialized
INFO - 2016-03-04 07:33:04 --> Output Class Initialized
INFO - 2016-03-04 07:33:04 --> Security Class Initialized
DEBUG - 2016-03-04 07:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 07:33:04 --> Input Class Initialized
INFO - 2016-03-04 07:33:04 --> Language Class Initialized
INFO - 2016-03-04 07:33:04 --> Loader Class Initialized
INFO - 2016-03-04 07:33:04 --> Helper loaded: url_helper
INFO - 2016-03-04 07:33:04 --> Helper loaded: file_helper
INFO - 2016-03-04 07:33:04 --> Helper loaded: date_helper
INFO - 2016-03-04 07:33:04 --> Helper loaded: form_helper
INFO - 2016-03-04 07:33:04 --> Database Driver Class Initialized
INFO - 2016-03-04 07:33:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 07:33:05 --> Controller Class Initialized
INFO - 2016-03-04 07:33:05 --> Model Class Initialized
INFO - 2016-03-04 07:33:05 --> Model Class Initialized
INFO - 2016-03-04 07:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 07:33:05 --> Pagination Class Initialized
INFO - 2016-03-04 07:33:05 --> Helper loaded: text_helper
INFO - 2016-03-04 07:33:05 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 10:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 10:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 10:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 10:33:05 --> Final output sent to browser
DEBUG - 2016-03-04 10:33:05 --> Total execution time: 1.1358
INFO - 2016-03-04 08:17:54 --> Config Class Initialized
INFO - 2016-03-04 08:17:54 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:17:54 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:17:54 --> Utf8 Class Initialized
INFO - 2016-03-04 08:17:54 --> URI Class Initialized
DEBUG - 2016-03-04 08:17:54 --> No URI present. Default controller set.
INFO - 2016-03-04 08:17:54 --> Router Class Initialized
INFO - 2016-03-04 08:17:54 --> Output Class Initialized
INFO - 2016-03-04 08:17:54 --> Security Class Initialized
DEBUG - 2016-03-04 08:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:17:54 --> Input Class Initialized
INFO - 2016-03-04 08:17:54 --> Language Class Initialized
INFO - 2016-03-04 08:17:54 --> Loader Class Initialized
INFO - 2016-03-04 08:17:54 --> Helper loaded: url_helper
INFO - 2016-03-04 08:17:54 --> Helper loaded: file_helper
INFO - 2016-03-04 08:17:54 --> Helper loaded: date_helper
INFO - 2016-03-04 08:17:54 --> Helper loaded: form_helper
INFO - 2016-03-04 08:17:54 --> Database Driver Class Initialized
INFO - 2016-03-04 08:17:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:17:55 --> Controller Class Initialized
INFO - 2016-03-04 08:17:55 --> Model Class Initialized
INFO - 2016-03-04 08:17:55 --> Model Class Initialized
INFO - 2016-03-04 08:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:17:55 --> Pagination Class Initialized
INFO - 2016-03-04 08:17:55 --> Helper loaded: text_helper
INFO - 2016-03-04 08:17:55 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 11:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:17:55 --> Final output sent to browser
DEBUG - 2016-03-04 11:17:55 --> Total execution time: 1.3784
INFO - 2016-03-04 08:18:11 --> Config Class Initialized
INFO - 2016-03-04 08:18:11 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:18:11 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:18:11 --> Utf8 Class Initialized
INFO - 2016-03-04 08:18:11 --> URI Class Initialized
INFO - 2016-03-04 08:18:11 --> Router Class Initialized
INFO - 2016-03-04 08:18:11 --> Output Class Initialized
INFO - 2016-03-04 08:18:11 --> Security Class Initialized
DEBUG - 2016-03-04 08:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:18:11 --> Input Class Initialized
INFO - 2016-03-04 08:18:11 --> Language Class Initialized
INFO - 2016-03-04 08:18:11 --> Loader Class Initialized
INFO - 2016-03-04 08:18:11 --> Helper loaded: url_helper
INFO - 2016-03-04 08:18:11 --> Helper loaded: file_helper
INFO - 2016-03-04 08:18:11 --> Helper loaded: date_helper
INFO - 2016-03-04 08:18:11 --> Helper loaded: form_helper
INFO - 2016-03-04 08:18:11 --> Database Driver Class Initialized
INFO - 2016-03-04 08:18:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:18:12 --> Controller Class Initialized
INFO - 2016-03-04 08:18:12 --> Model Class Initialized
INFO - 2016-03-04 08:18:12 --> Model Class Initialized
INFO - 2016-03-04 08:18:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:18:12 --> Pagination Class Initialized
INFO - 2016-03-04 08:18:12 --> Helper loaded: text_helper
INFO - 2016-03-04 08:18:12 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:18:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:18:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:18:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:18:12 --> Final output sent to browser
DEBUG - 2016-03-04 11:18:12 --> Total execution time: 1.2841
INFO - 2016-03-04 08:18:43 --> Config Class Initialized
INFO - 2016-03-04 08:18:43 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:18:43 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:18:43 --> Utf8 Class Initialized
INFO - 2016-03-04 08:18:43 --> URI Class Initialized
INFO - 2016-03-04 08:18:43 --> Router Class Initialized
INFO - 2016-03-04 08:18:43 --> Output Class Initialized
INFO - 2016-03-04 08:18:43 --> Security Class Initialized
DEBUG - 2016-03-04 08:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:18:43 --> Input Class Initialized
INFO - 2016-03-04 08:18:43 --> Language Class Initialized
INFO - 2016-03-04 08:18:43 --> Loader Class Initialized
INFO - 2016-03-04 08:18:43 --> Helper loaded: url_helper
INFO - 2016-03-04 08:18:43 --> Helper loaded: file_helper
INFO - 2016-03-04 08:18:43 --> Helper loaded: date_helper
INFO - 2016-03-04 08:18:43 --> Helper loaded: form_helper
INFO - 2016-03-04 08:18:43 --> Database Driver Class Initialized
INFO - 2016-03-04 08:18:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:18:44 --> Controller Class Initialized
INFO - 2016-03-04 08:18:44 --> Model Class Initialized
INFO - 2016-03-04 08:18:44 --> Model Class Initialized
INFO - 2016-03-04 08:18:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:18:44 --> Pagination Class Initialized
INFO - 2016-03-04 08:18:44 --> Helper loaded: text_helper
INFO - 2016-03-04 08:18:44 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:18:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:18:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:18:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 11:18:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 11:18:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:18:45 --> Final output sent to browser
DEBUG - 2016-03-04 11:18:45 --> Total execution time: 1.2527
INFO - 2016-03-04 08:31:28 --> Config Class Initialized
INFO - 2016-03-04 08:31:28 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:31:28 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:31:28 --> Utf8 Class Initialized
INFO - 2016-03-04 08:31:28 --> URI Class Initialized
INFO - 2016-03-04 08:31:28 --> Router Class Initialized
INFO - 2016-03-04 08:31:28 --> Output Class Initialized
INFO - 2016-03-04 08:31:28 --> Security Class Initialized
DEBUG - 2016-03-04 08:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:31:28 --> Input Class Initialized
INFO - 2016-03-04 08:31:28 --> Language Class Initialized
INFO - 2016-03-04 08:31:28 --> Loader Class Initialized
INFO - 2016-03-04 08:31:28 --> Helper loaded: url_helper
INFO - 2016-03-04 08:31:28 --> Helper loaded: file_helper
INFO - 2016-03-04 08:31:28 --> Helper loaded: date_helper
INFO - 2016-03-04 08:31:28 --> Helper loaded: form_helper
INFO - 2016-03-04 08:31:28 --> Database Driver Class Initialized
INFO - 2016-03-04 08:31:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:31:29 --> Controller Class Initialized
INFO - 2016-03-04 08:31:29 --> Model Class Initialized
INFO - 2016-03-04 08:31:29 --> Model Class Initialized
INFO - 2016-03-04 08:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:31:29 --> Pagination Class Initialized
INFO - 2016-03-04 08:31:29 --> Helper loaded: text_helper
INFO - 2016-03-04 08:31:29 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 11:31:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:31:29 --> Final output sent to browser
DEBUG - 2016-03-04 11:31:29 --> Total execution time: 1.2796
INFO - 2016-03-04 08:39:14 --> Config Class Initialized
INFO - 2016-03-04 08:39:14 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:39:14 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:39:14 --> Utf8 Class Initialized
INFO - 2016-03-04 08:39:14 --> URI Class Initialized
INFO - 2016-03-04 08:39:14 --> Router Class Initialized
INFO - 2016-03-04 08:39:14 --> Output Class Initialized
INFO - 2016-03-04 08:39:14 --> Security Class Initialized
DEBUG - 2016-03-04 08:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:39:14 --> Input Class Initialized
INFO - 2016-03-04 08:39:14 --> Language Class Initialized
INFO - 2016-03-04 08:39:14 --> Loader Class Initialized
INFO - 2016-03-04 08:39:14 --> Helper loaded: url_helper
INFO - 2016-03-04 08:39:14 --> Helper loaded: file_helper
INFO - 2016-03-04 08:39:14 --> Helper loaded: date_helper
INFO - 2016-03-04 08:39:14 --> Helper loaded: form_helper
INFO - 2016-03-04 08:39:14 --> Database Driver Class Initialized
INFO - 2016-03-04 08:39:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:39:15 --> Controller Class Initialized
INFO - 2016-03-04 08:39:15 --> Model Class Initialized
INFO - 2016-03-04 08:39:15 --> Model Class Initialized
INFO - 2016-03-04 08:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:39:15 --> Pagination Class Initialized
INFO - 2016-03-04 08:39:15 --> Helper loaded: text_helper
INFO - 2016-03-04 08:39:15 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:39:15 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:39:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:39:15 --> Final output sent to browser
DEBUG - 2016-03-04 11:39:15 --> Total execution time: 1.1471
INFO - 2016-03-04 08:44:56 --> Config Class Initialized
INFO - 2016-03-04 08:44:56 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:44:56 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:44:56 --> Utf8 Class Initialized
INFO - 2016-03-04 08:44:56 --> URI Class Initialized
INFO - 2016-03-04 08:44:56 --> Router Class Initialized
INFO - 2016-03-04 08:44:56 --> Output Class Initialized
INFO - 2016-03-04 08:44:56 --> Security Class Initialized
DEBUG - 2016-03-04 08:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:44:56 --> Input Class Initialized
INFO - 2016-03-04 08:44:56 --> Language Class Initialized
INFO - 2016-03-04 08:44:56 --> Loader Class Initialized
INFO - 2016-03-04 08:44:56 --> Helper loaded: url_helper
INFO - 2016-03-04 08:44:56 --> Helper loaded: file_helper
INFO - 2016-03-04 08:44:56 --> Helper loaded: date_helper
INFO - 2016-03-04 08:44:56 --> Helper loaded: form_helper
INFO - 2016-03-04 08:44:56 --> Database Driver Class Initialized
INFO - 2016-03-04 08:44:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:44:57 --> Controller Class Initialized
INFO - 2016-03-04 08:44:57 --> Model Class Initialized
INFO - 2016-03-04 08:44:57 --> Model Class Initialized
INFO - 2016-03-04 08:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:44:57 --> Pagination Class Initialized
INFO - 2016-03-04 08:44:57 --> Helper loaded: text_helper
INFO - 2016-03-04 08:44:57 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:44:57 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:44:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:44:57 --> Final output sent to browser
DEBUG - 2016-03-04 11:44:57 --> Total execution time: 1.1229
INFO - 2016-03-04 08:45:36 --> Config Class Initialized
INFO - 2016-03-04 08:45:36 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:45:36 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:45:36 --> Utf8 Class Initialized
INFO - 2016-03-04 08:45:36 --> URI Class Initialized
INFO - 2016-03-04 08:45:36 --> Router Class Initialized
INFO - 2016-03-04 08:45:36 --> Output Class Initialized
INFO - 2016-03-04 08:45:36 --> Security Class Initialized
DEBUG - 2016-03-04 08:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:45:36 --> Input Class Initialized
INFO - 2016-03-04 08:45:36 --> Language Class Initialized
INFO - 2016-03-04 08:45:36 --> Loader Class Initialized
INFO - 2016-03-04 08:45:36 --> Helper loaded: url_helper
INFO - 2016-03-04 08:45:36 --> Helper loaded: file_helper
INFO - 2016-03-04 08:45:36 --> Helper loaded: date_helper
INFO - 2016-03-04 08:45:36 --> Helper loaded: form_helper
INFO - 2016-03-04 08:45:36 --> Database Driver Class Initialized
INFO - 2016-03-04 08:45:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:45:37 --> Controller Class Initialized
INFO - 2016-03-04 08:45:37 --> Model Class Initialized
INFO - 2016-03-04 08:45:37 --> Model Class Initialized
INFO - 2016-03-04 08:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:45:37 --> Pagination Class Initialized
INFO - 2016-03-04 08:45:37 --> Helper loaded: text_helper
INFO - 2016-03-04 08:45:37 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:45:37 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:45:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:45:37 --> Final output sent to browser
DEBUG - 2016-03-04 11:45:37 --> Total execution time: 1.1299
INFO - 2016-03-04 08:46:25 --> Config Class Initialized
INFO - 2016-03-04 08:46:25 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:46:25 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:46:25 --> Utf8 Class Initialized
INFO - 2016-03-04 08:46:25 --> URI Class Initialized
INFO - 2016-03-04 08:46:25 --> Router Class Initialized
INFO - 2016-03-04 08:46:25 --> Output Class Initialized
INFO - 2016-03-04 08:46:25 --> Security Class Initialized
DEBUG - 2016-03-04 08:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:46:25 --> Input Class Initialized
INFO - 2016-03-04 08:46:25 --> Language Class Initialized
INFO - 2016-03-04 08:46:25 --> Loader Class Initialized
INFO - 2016-03-04 08:46:25 --> Helper loaded: url_helper
INFO - 2016-03-04 08:46:25 --> Helper loaded: file_helper
INFO - 2016-03-04 08:46:25 --> Helper loaded: date_helper
INFO - 2016-03-04 08:46:25 --> Helper loaded: form_helper
INFO - 2016-03-04 08:46:25 --> Database Driver Class Initialized
INFO - 2016-03-04 08:46:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:46:26 --> Controller Class Initialized
INFO - 2016-03-04 08:46:26 --> Model Class Initialized
INFO - 2016-03-04 08:46:26 --> Model Class Initialized
INFO - 2016-03-04 08:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:46:26 --> Pagination Class Initialized
INFO - 2016-03-04 08:46:26 --> Helper loaded: text_helper
INFO - 2016-03-04 08:46:26 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:46:26 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:46:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:46:26 --> Final output sent to browser
DEBUG - 2016-03-04 11:46:26 --> Total execution time: 1.1299
INFO - 2016-03-04 08:46:51 --> Config Class Initialized
INFO - 2016-03-04 08:46:51 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:46:51 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:46:51 --> Utf8 Class Initialized
INFO - 2016-03-04 08:46:51 --> URI Class Initialized
INFO - 2016-03-04 08:46:51 --> Router Class Initialized
INFO - 2016-03-04 08:46:51 --> Output Class Initialized
INFO - 2016-03-04 08:46:51 --> Security Class Initialized
DEBUG - 2016-03-04 08:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:46:51 --> Input Class Initialized
INFO - 2016-03-04 08:46:51 --> Language Class Initialized
INFO - 2016-03-04 08:46:51 --> Loader Class Initialized
INFO - 2016-03-04 08:46:51 --> Helper loaded: url_helper
INFO - 2016-03-04 08:46:51 --> Helper loaded: file_helper
INFO - 2016-03-04 08:46:51 --> Helper loaded: date_helper
INFO - 2016-03-04 08:46:51 --> Helper loaded: form_helper
INFO - 2016-03-04 08:46:51 --> Database Driver Class Initialized
INFO - 2016-03-04 08:46:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:46:52 --> Controller Class Initialized
INFO - 2016-03-04 08:46:52 --> Model Class Initialized
INFO - 2016-03-04 08:46:52 --> Model Class Initialized
INFO - 2016-03-04 08:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:46:52 --> Pagination Class Initialized
INFO - 2016-03-04 08:46:52 --> Helper loaded: text_helper
INFO - 2016-03-04 08:46:52 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:46:52 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:46:52 --> Final output sent to browser
DEBUG - 2016-03-04 11:46:52 --> Total execution time: 1.0996
INFO - 2016-03-04 08:47:28 --> Config Class Initialized
INFO - 2016-03-04 08:47:28 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:47:28 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:47:28 --> Utf8 Class Initialized
INFO - 2016-03-04 08:47:28 --> URI Class Initialized
INFO - 2016-03-04 08:47:29 --> Router Class Initialized
INFO - 2016-03-04 08:47:29 --> Output Class Initialized
INFO - 2016-03-04 08:47:29 --> Security Class Initialized
DEBUG - 2016-03-04 08:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:47:29 --> Input Class Initialized
INFO - 2016-03-04 08:47:29 --> Language Class Initialized
INFO - 2016-03-04 08:47:29 --> Loader Class Initialized
INFO - 2016-03-04 08:47:29 --> Helper loaded: url_helper
INFO - 2016-03-04 08:47:29 --> Helper loaded: file_helper
INFO - 2016-03-04 08:47:29 --> Helper loaded: date_helper
INFO - 2016-03-04 08:47:29 --> Helper loaded: form_helper
INFO - 2016-03-04 08:47:29 --> Database Driver Class Initialized
INFO - 2016-03-04 08:47:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:47:30 --> Controller Class Initialized
INFO - 2016-03-04 08:47:30 --> Model Class Initialized
INFO - 2016-03-04 08:47:30 --> Model Class Initialized
INFO - 2016-03-04 08:47:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:47:30 --> Pagination Class Initialized
INFO - 2016-03-04 08:47:30 --> Helper loaded: text_helper
INFO - 2016-03-04 08:47:30 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:47:30 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:47:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:47:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:47:30 --> Final output sent to browser
DEBUG - 2016-03-04 11:47:30 --> Total execution time: 1.1341
INFO - 2016-03-04 08:47:44 --> Config Class Initialized
INFO - 2016-03-04 08:47:44 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:47:44 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:47:44 --> Utf8 Class Initialized
INFO - 2016-03-04 08:47:44 --> URI Class Initialized
INFO - 2016-03-04 08:47:44 --> Router Class Initialized
INFO - 2016-03-04 08:47:44 --> Output Class Initialized
INFO - 2016-03-04 08:47:44 --> Security Class Initialized
DEBUG - 2016-03-04 08:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:47:44 --> Input Class Initialized
INFO - 2016-03-04 08:47:44 --> Language Class Initialized
INFO - 2016-03-04 08:47:44 --> Loader Class Initialized
INFO - 2016-03-04 08:47:44 --> Helper loaded: url_helper
INFO - 2016-03-04 08:47:44 --> Helper loaded: file_helper
INFO - 2016-03-04 08:47:44 --> Helper loaded: date_helper
INFO - 2016-03-04 08:47:44 --> Helper loaded: form_helper
INFO - 2016-03-04 08:47:44 --> Database Driver Class Initialized
INFO - 2016-03-04 08:47:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:47:45 --> Controller Class Initialized
INFO - 2016-03-04 08:47:45 --> Model Class Initialized
INFO - 2016-03-04 08:47:45 --> Model Class Initialized
INFO - 2016-03-04 08:47:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:47:45 --> Pagination Class Initialized
INFO - 2016-03-04 08:47:45 --> Helper loaded: text_helper
INFO - 2016-03-04 08:47:45 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:47:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:47:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:47:45 --> Final output sent to browser
DEBUG - 2016-03-04 11:47:45 --> Total execution time: 1.2144
INFO - 2016-03-04 08:48:19 --> Config Class Initialized
INFO - 2016-03-04 08:48:19 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:48:19 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:48:19 --> Utf8 Class Initialized
INFO - 2016-03-04 08:48:19 --> URI Class Initialized
INFO - 2016-03-04 08:48:19 --> Router Class Initialized
INFO - 2016-03-04 08:48:19 --> Output Class Initialized
INFO - 2016-03-04 08:48:19 --> Security Class Initialized
DEBUG - 2016-03-04 08:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:48:19 --> Input Class Initialized
INFO - 2016-03-04 08:48:19 --> Language Class Initialized
INFO - 2016-03-04 08:48:19 --> Loader Class Initialized
INFO - 2016-03-04 08:48:19 --> Helper loaded: url_helper
INFO - 2016-03-04 08:48:19 --> Helper loaded: file_helper
INFO - 2016-03-04 08:48:19 --> Helper loaded: date_helper
INFO - 2016-03-04 08:48:19 --> Helper loaded: form_helper
INFO - 2016-03-04 08:48:19 --> Database Driver Class Initialized
INFO - 2016-03-04 08:48:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:48:20 --> Controller Class Initialized
INFO - 2016-03-04 08:48:20 --> Model Class Initialized
INFO - 2016-03-04 08:48:20 --> Model Class Initialized
INFO - 2016-03-04 08:48:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:48:20 --> Pagination Class Initialized
INFO - 2016-03-04 08:48:20 --> Helper loaded: text_helper
INFO - 2016-03-04 08:48:20 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:48:20 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:48:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:48:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:48:20 --> Final output sent to browser
DEBUG - 2016-03-04 11:48:20 --> Total execution time: 1.1307
INFO - 2016-03-04 08:50:16 --> Config Class Initialized
INFO - 2016-03-04 08:50:16 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:50:16 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:50:16 --> Utf8 Class Initialized
INFO - 2016-03-04 08:50:16 --> URI Class Initialized
INFO - 2016-03-04 08:50:16 --> Router Class Initialized
INFO - 2016-03-04 08:50:16 --> Output Class Initialized
INFO - 2016-03-04 08:50:16 --> Security Class Initialized
DEBUG - 2016-03-04 08:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:50:16 --> Input Class Initialized
INFO - 2016-03-04 08:50:16 --> Language Class Initialized
INFO - 2016-03-04 08:50:16 --> Loader Class Initialized
INFO - 2016-03-04 08:50:16 --> Helper loaded: url_helper
INFO - 2016-03-04 08:50:16 --> Helper loaded: file_helper
INFO - 2016-03-04 08:50:16 --> Helper loaded: date_helper
INFO - 2016-03-04 08:50:16 --> Helper loaded: form_helper
INFO - 2016-03-04 08:50:16 --> Database Driver Class Initialized
INFO - 2016-03-04 08:50:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:50:17 --> Controller Class Initialized
INFO - 2016-03-04 08:50:17 --> Model Class Initialized
INFO - 2016-03-04 08:50:17 --> Model Class Initialized
INFO - 2016-03-04 08:50:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:50:17 --> Pagination Class Initialized
INFO - 2016-03-04 08:50:17 --> Helper loaded: text_helper
INFO - 2016-03-04 08:50:17 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:50:17 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:50:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:50:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:50:17 --> Final output sent to browser
DEBUG - 2016-03-04 11:50:17 --> Total execution time: 1.1844
INFO - 2016-03-04 08:50:33 --> Config Class Initialized
INFO - 2016-03-04 08:50:33 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:50:33 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:50:33 --> Utf8 Class Initialized
INFO - 2016-03-04 08:50:33 --> URI Class Initialized
INFO - 2016-03-04 08:50:33 --> Router Class Initialized
INFO - 2016-03-04 08:50:33 --> Output Class Initialized
INFO - 2016-03-04 08:50:33 --> Security Class Initialized
DEBUG - 2016-03-04 08:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:50:33 --> Input Class Initialized
INFO - 2016-03-04 08:50:33 --> Language Class Initialized
INFO - 2016-03-04 08:50:33 --> Loader Class Initialized
INFO - 2016-03-04 08:50:33 --> Helper loaded: url_helper
INFO - 2016-03-04 08:50:33 --> Helper loaded: file_helper
INFO - 2016-03-04 08:50:33 --> Helper loaded: date_helper
INFO - 2016-03-04 08:50:33 --> Helper loaded: form_helper
INFO - 2016-03-04 08:50:33 --> Database Driver Class Initialized
INFO - 2016-03-04 08:50:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:50:34 --> Controller Class Initialized
INFO - 2016-03-04 08:50:34 --> Model Class Initialized
INFO - 2016-03-04 08:50:34 --> Model Class Initialized
INFO - 2016-03-04 08:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:50:34 --> Pagination Class Initialized
INFO - 2016-03-04 08:50:34 --> Helper loaded: text_helper
INFO - 2016-03-04 08:50:34 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:50:34 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:50:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:50:34 --> Final output sent to browser
DEBUG - 2016-03-04 11:50:34 --> Total execution time: 1.1309
INFO - 2016-03-04 08:52:50 --> Config Class Initialized
INFO - 2016-03-04 08:52:50 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:52:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:52:50 --> Utf8 Class Initialized
INFO - 2016-03-04 08:52:50 --> URI Class Initialized
INFO - 2016-03-04 08:52:50 --> Router Class Initialized
INFO - 2016-03-04 08:52:50 --> Output Class Initialized
INFO - 2016-03-04 08:52:50 --> Security Class Initialized
DEBUG - 2016-03-04 08:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:52:50 --> Input Class Initialized
INFO - 2016-03-04 08:52:50 --> Language Class Initialized
INFO - 2016-03-04 08:52:50 --> Loader Class Initialized
INFO - 2016-03-04 08:52:51 --> Helper loaded: url_helper
INFO - 2016-03-04 08:52:51 --> Helper loaded: file_helper
INFO - 2016-03-04 08:52:51 --> Helper loaded: date_helper
INFO - 2016-03-04 08:52:51 --> Helper loaded: form_helper
INFO - 2016-03-04 08:52:51 --> Database Driver Class Initialized
INFO - 2016-03-04 08:52:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:52:52 --> Controller Class Initialized
INFO - 2016-03-04 08:52:52 --> Model Class Initialized
INFO - 2016-03-04 08:52:52 --> Model Class Initialized
INFO - 2016-03-04 08:52:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:52:52 --> Pagination Class Initialized
INFO - 2016-03-04 08:52:52 --> Helper loaded: text_helper
INFO - 2016-03-04 08:52:52 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:52:52 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:52:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:52:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:52:52 --> Final output sent to browser
DEBUG - 2016-03-04 11:52:52 --> Total execution time: 1.1119
INFO - 2016-03-04 08:54:32 --> Config Class Initialized
INFO - 2016-03-04 08:54:32 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:54:32 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:54:32 --> Utf8 Class Initialized
INFO - 2016-03-04 08:54:32 --> URI Class Initialized
INFO - 2016-03-04 08:54:32 --> Router Class Initialized
INFO - 2016-03-04 08:54:32 --> Output Class Initialized
INFO - 2016-03-04 08:54:32 --> Security Class Initialized
DEBUG - 2016-03-04 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:54:32 --> Input Class Initialized
INFO - 2016-03-04 08:54:32 --> Language Class Initialized
INFO - 2016-03-04 08:54:32 --> Loader Class Initialized
INFO - 2016-03-04 08:54:32 --> Helper loaded: url_helper
INFO - 2016-03-04 08:54:32 --> Helper loaded: file_helper
INFO - 2016-03-04 08:54:32 --> Helper loaded: date_helper
INFO - 2016-03-04 08:54:32 --> Helper loaded: form_helper
INFO - 2016-03-04 08:54:32 --> Database Driver Class Initialized
INFO - 2016-03-04 08:54:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:54:33 --> Controller Class Initialized
INFO - 2016-03-04 08:54:33 --> Model Class Initialized
INFO - 2016-03-04 08:54:33 --> Model Class Initialized
INFO - 2016-03-04 08:54:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:54:33 --> Pagination Class Initialized
INFO - 2016-03-04 08:54:33 --> Helper loaded: text_helper
INFO - 2016-03-04 08:54:33 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:54:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:54:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:54:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:54:33 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:54:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:54:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:54:33 --> Final output sent to browser
DEBUG - 2016-03-04 11:54:33 --> Total execution time: 1.1572
INFO - 2016-03-04 08:54:52 --> Config Class Initialized
INFO - 2016-03-04 08:54:52 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:54:52 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:54:52 --> Utf8 Class Initialized
INFO - 2016-03-04 08:54:52 --> URI Class Initialized
INFO - 2016-03-04 08:54:52 --> Router Class Initialized
INFO - 2016-03-04 08:54:52 --> Output Class Initialized
INFO - 2016-03-04 08:54:52 --> Security Class Initialized
DEBUG - 2016-03-04 08:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:54:52 --> Input Class Initialized
INFO - 2016-03-04 08:54:52 --> Language Class Initialized
INFO - 2016-03-04 08:54:52 --> Loader Class Initialized
INFO - 2016-03-04 08:54:52 --> Helper loaded: url_helper
INFO - 2016-03-04 08:54:52 --> Helper loaded: file_helper
INFO - 2016-03-04 08:54:52 --> Helper loaded: date_helper
INFO - 2016-03-04 08:54:52 --> Helper loaded: form_helper
INFO - 2016-03-04 08:54:52 --> Database Driver Class Initialized
INFO - 2016-03-04 08:54:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:54:53 --> Controller Class Initialized
INFO - 2016-03-04 08:54:53 --> Model Class Initialized
INFO - 2016-03-04 08:54:53 --> Model Class Initialized
INFO - 2016-03-04 08:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:54:53 --> Pagination Class Initialized
INFO - 2016-03-04 08:54:53 --> Helper loaded: text_helper
INFO - 2016-03-04 08:54:53 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:54:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:54:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:54:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:54:53 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:54:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:54:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:54:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:54:53 --> Final output sent to browser
DEBUG - 2016-03-04 11:54:53 --> Total execution time: 1.1351
INFO - 2016-03-04 08:56:51 --> Config Class Initialized
INFO - 2016-03-04 08:56:51 --> Hooks Class Initialized
DEBUG - 2016-03-04 08:56:51 --> UTF-8 Support Enabled
INFO - 2016-03-04 08:56:51 --> Utf8 Class Initialized
INFO - 2016-03-04 08:56:51 --> URI Class Initialized
INFO - 2016-03-04 08:56:51 --> Router Class Initialized
INFO - 2016-03-04 08:56:51 --> Output Class Initialized
INFO - 2016-03-04 08:56:51 --> Security Class Initialized
DEBUG - 2016-03-04 08:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 08:56:51 --> Input Class Initialized
INFO - 2016-03-04 08:56:51 --> Language Class Initialized
INFO - 2016-03-04 08:56:51 --> Loader Class Initialized
INFO - 2016-03-04 08:56:51 --> Helper loaded: url_helper
INFO - 2016-03-04 08:56:51 --> Helper loaded: file_helper
INFO - 2016-03-04 08:56:51 --> Helper loaded: date_helper
INFO - 2016-03-04 08:56:51 --> Helper loaded: form_helper
INFO - 2016-03-04 08:56:51 --> Database Driver Class Initialized
INFO - 2016-03-04 08:56:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 08:56:52 --> Controller Class Initialized
INFO - 2016-03-04 08:56:52 --> Model Class Initialized
INFO - 2016-03-04 08:56:52 --> Model Class Initialized
INFO - 2016-03-04 08:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 08:56:52 --> Pagination Class Initialized
INFO - 2016-03-04 08:56:52 --> Helper loaded: text_helper
INFO - 2016-03-04 08:56:52 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:56:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 11:56:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 11:56:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 11:56:52 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 11:56:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 11:56:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 11:56:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 11:56:52 --> Final output sent to browser
DEBUG - 2016-03-04 11:56:52 --> Total execution time: 1.1420
INFO - 2016-03-04 09:58:45 --> Config Class Initialized
INFO - 2016-03-04 09:58:46 --> Hooks Class Initialized
DEBUG - 2016-03-04 09:58:46 --> UTF-8 Support Enabled
INFO - 2016-03-04 09:58:46 --> Utf8 Class Initialized
INFO - 2016-03-04 09:58:46 --> URI Class Initialized
INFO - 2016-03-04 09:58:46 --> Router Class Initialized
INFO - 2016-03-04 09:58:46 --> Output Class Initialized
INFO - 2016-03-04 09:58:46 --> Security Class Initialized
DEBUG - 2016-03-04 09:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 09:58:46 --> Input Class Initialized
INFO - 2016-03-04 09:58:46 --> Language Class Initialized
INFO - 2016-03-04 09:58:46 --> Loader Class Initialized
INFO - 2016-03-04 09:58:46 --> Helper loaded: url_helper
INFO - 2016-03-04 09:58:46 --> Helper loaded: file_helper
INFO - 2016-03-04 09:58:46 --> Helper loaded: date_helper
INFO - 2016-03-04 09:58:46 --> Helper loaded: form_helper
INFO - 2016-03-04 09:58:46 --> Database Driver Class Initialized
INFO - 2016-03-04 09:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 09:58:47 --> Controller Class Initialized
INFO - 2016-03-04 09:58:47 --> Model Class Initialized
INFO - 2016-03-04 09:58:47 --> Model Class Initialized
INFO - 2016-03-04 09:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 09:58:47 --> Pagination Class Initialized
INFO - 2016-03-04 09:58:47 --> Helper loaded: text_helper
INFO - 2016-03-04 09:58:47 --> Helper loaded: cookie_helper
INFO - 2016-03-04 12:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 12:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 12:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 12:58:47 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 12:58:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 12:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 12:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 12:58:47 --> Final output sent to browser
DEBUG - 2016-03-04 12:58:47 --> Total execution time: 1.9463
INFO - 2016-03-04 09:59:19 --> Config Class Initialized
INFO - 2016-03-04 09:59:19 --> Hooks Class Initialized
DEBUG - 2016-03-04 09:59:19 --> UTF-8 Support Enabled
INFO - 2016-03-04 09:59:19 --> Utf8 Class Initialized
INFO - 2016-03-04 09:59:19 --> URI Class Initialized
DEBUG - 2016-03-04 09:59:19 --> No URI present. Default controller set.
INFO - 2016-03-04 09:59:19 --> Router Class Initialized
INFO - 2016-03-04 09:59:19 --> Output Class Initialized
INFO - 2016-03-04 09:59:19 --> Security Class Initialized
DEBUG - 2016-03-04 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 09:59:19 --> Input Class Initialized
INFO - 2016-03-04 09:59:19 --> Language Class Initialized
INFO - 2016-03-04 09:59:19 --> Loader Class Initialized
INFO - 2016-03-04 09:59:19 --> Helper loaded: url_helper
INFO - 2016-03-04 09:59:19 --> Helper loaded: file_helper
INFO - 2016-03-04 09:59:19 --> Helper loaded: date_helper
INFO - 2016-03-04 09:59:19 --> Helper loaded: form_helper
INFO - 2016-03-04 09:59:19 --> Database Driver Class Initialized
INFO - 2016-03-04 09:59:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 09:59:20 --> Controller Class Initialized
INFO - 2016-03-04 09:59:20 --> Model Class Initialized
INFO - 2016-03-04 09:59:20 --> Model Class Initialized
INFO - 2016-03-04 09:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 09:59:20 --> Pagination Class Initialized
INFO - 2016-03-04 09:59:20 --> Helper loaded: text_helper
INFO - 2016-03-04 09:59:20 --> Helper loaded: cookie_helper
INFO - 2016-03-04 12:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 12:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 12:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 12:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 12:59:20 --> Final output sent to browser
DEBUG - 2016-03-04 12:59:20 --> Total execution time: 1.4265
INFO - 2016-03-04 10:00:01 --> Config Class Initialized
INFO - 2016-03-04 10:00:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:00:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:00:01 --> Utf8 Class Initialized
INFO - 2016-03-04 10:00:01 --> URI Class Initialized
INFO - 2016-03-04 10:00:01 --> Router Class Initialized
INFO - 2016-03-04 10:00:01 --> Output Class Initialized
INFO - 2016-03-04 10:00:01 --> Security Class Initialized
DEBUG - 2016-03-04 10:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:00:01 --> Input Class Initialized
INFO - 2016-03-04 10:00:01 --> Language Class Initialized
INFO - 2016-03-04 10:00:01 --> Loader Class Initialized
INFO - 2016-03-04 10:00:01 --> Helper loaded: url_helper
INFO - 2016-03-04 10:00:01 --> Helper loaded: file_helper
INFO - 2016-03-04 10:00:01 --> Helper loaded: date_helper
INFO - 2016-03-04 10:00:01 --> Helper loaded: form_helper
INFO - 2016-03-04 10:00:01 --> Database Driver Class Initialized
INFO - 2016-03-04 10:00:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:00:02 --> Controller Class Initialized
INFO - 2016-03-04 10:00:02 --> Model Class Initialized
INFO - 2016-03-04 10:00:02 --> Model Class Initialized
INFO - 2016-03-04 10:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:00:02 --> Pagination Class Initialized
INFO - 2016-03-04 10:00:02 --> Helper loaded: text_helper
INFO - 2016-03-04 10:00:02 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:00:02 --> Email Class Initialized
ERROR - 2016-03-04 13:00:02 --> Severity: Notice --> Undefined property: Jboard::$form_validation C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 577
ERROR - 2016-03-04 13:00:02 --> Severity: Error --> Call to a member function set_rules() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 577
INFO - 2016-03-04 10:01:10 --> Config Class Initialized
INFO - 2016-03-04 10:01:10 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:01:10 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:01:10 --> Utf8 Class Initialized
INFO - 2016-03-04 10:01:10 --> URI Class Initialized
DEBUG - 2016-03-04 10:01:10 --> No URI present. Default controller set.
INFO - 2016-03-04 10:01:10 --> Router Class Initialized
INFO - 2016-03-04 10:01:10 --> Output Class Initialized
INFO - 2016-03-04 10:01:10 --> Security Class Initialized
DEBUG - 2016-03-04 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:01:10 --> Input Class Initialized
INFO - 2016-03-04 10:01:10 --> Language Class Initialized
INFO - 2016-03-04 10:01:10 --> Loader Class Initialized
INFO - 2016-03-04 10:01:10 --> Helper loaded: url_helper
INFO - 2016-03-04 10:01:10 --> Helper loaded: file_helper
INFO - 2016-03-04 10:01:10 --> Helper loaded: date_helper
INFO - 2016-03-04 10:01:10 --> Helper loaded: form_helper
INFO - 2016-03-04 10:01:10 --> Database Driver Class Initialized
INFO - 2016-03-04 10:01:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:01:11 --> Controller Class Initialized
INFO - 2016-03-04 10:01:11 --> Model Class Initialized
INFO - 2016-03-04 10:01:11 --> Model Class Initialized
INFO - 2016-03-04 10:01:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:01:11 --> Pagination Class Initialized
INFO - 2016-03-04 10:01:11 --> Helper loaded: text_helper
INFO - 2016-03-04 10:01:11 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:01:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:01:11 --> Final output sent to browser
DEBUG - 2016-03-04 13:01:11 --> Total execution time: 1.1712
INFO - 2016-03-04 10:01:48 --> Config Class Initialized
INFO - 2016-03-04 10:01:48 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:01:48 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:01:48 --> Utf8 Class Initialized
INFO - 2016-03-04 10:01:48 --> URI Class Initialized
INFO - 2016-03-04 10:01:48 --> Router Class Initialized
INFO - 2016-03-04 10:01:48 --> Output Class Initialized
INFO - 2016-03-04 10:01:48 --> Security Class Initialized
DEBUG - 2016-03-04 10:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:01:48 --> Input Class Initialized
INFO - 2016-03-04 10:01:48 --> Language Class Initialized
INFO - 2016-03-04 10:01:48 --> Loader Class Initialized
INFO - 2016-03-04 10:01:48 --> Helper loaded: url_helper
INFO - 2016-03-04 10:01:48 --> Helper loaded: file_helper
INFO - 2016-03-04 10:01:48 --> Helper loaded: date_helper
INFO - 2016-03-04 10:01:48 --> Helper loaded: form_helper
INFO - 2016-03-04 10:01:48 --> Database Driver Class Initialized
INFO - 2016-03-04 10:01:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:01:49 --> Controller Class Initialized
INFO - 2016-03-04 10:01:49 --> Model Class Initialized
INFO - 2016-03-04 10:01:49 --> Model Class Initialized
INFO - 2016-03-04 10:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:01:49 --> Pagination Class Initialized
INFO - 2016-03-04 10:01:49 --> Helper loaded: text_helper
INFO - 2016-03-04 10:01:49 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:01:50 --> Form Validation Class Initialized
INFO - 2016-03-04 13:01:50 --> Email Class Initialized
INFO - 2016-03-04 13:01:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-04 13:01:50 --> Unable to find validation rule: xss_clean
ERROR - 2016-03-04 13:01:50 --> Could not find the language line "form_validation_xss_clean"
INFO - 2016-03-04 13:01:50 --> Final output sent to browser
DEBUG - 2016-03-04 13:01:50 --> Total execution time: 1.2150
INFO - 2016-03-04 10:02:17 --> Config Class Initialized
INFO - 2016-03-04 10:02:17 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:02:17 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:02:17 --> Utf8 Class Initialized
INFO - 2016-03-04 10:02:17 --> URI Class Initialized
DEBUG - 2016-03-04 10:02:17 --> No URI present. Default controller set.
INFO - 2016-03-04 10:02:17 --> Router Class Initialized
INFO - 2016-03-04 10:02:17 --> Output Class Initialized
INFO - 2016-03-04 10:02:17 --> Security Class Initialized
DEBUG - 2016-03-04 10:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:02:17 --> Input Class Initialized
INFO - 2016-03-04 10:02:17 --> Language Class Initialized
INFO - 2016-03-04 10:02:17 --> Loader Class Initialized
INFO - 2016-03-04 10:02:17 --> Helper loaded: url_helper
INFO - 2016-03-04 10:02:17 --> Helper loaded: file_helper
INFO - 2016-03-04 10:02:17 --> Helper loaded: date_helper
INFO - 2016-03-04 10:02:17 --> Helper loaded: form_helper
INFO - 2016-03-04 10:02:17 --> Database Driver Class Initialized
INFO - 2016-03-04 10:02:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:02:18 --> Controller Class Initialized
INFO - 2016-03-04 10:02:18 --> Model Class Initialized
INFO - 2016-03-04 10:02:18 --> Model Class Initialized
INFO - 2016-03-04 10:02:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:02:18 --> Pagination Class Initialized
INFO - 2016-03-04 10:02:18 --> Helper loaded: text_helper
INFO - 2016-03-04 10:02:18 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:02:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:02:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:02:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:02:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:02:18 --> Final output sent to browser
DEBUG - 2016-03-04 13:02:18 --> Total execution time: 1.1692
INFO - 2016-03-04 10:02:31 --> Config Class Initialized
INFO - 2016-03-04 10:02:31 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:02:31 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:02:31 --> Utf8 Class Initialized
INFO - 2016-03-04 10:02:31 --> URI Class Initialized
INFO - 2016-03-04 10:02:31 --> Router Class Initialized
INFO - 2016-03-04 10:02:31 --> Output Class Initialized
INFO - 2016-03-04 10:02:31 --> Security Class Initialized
DEBUG - 2016-03-04 10:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:02:31 --> Input Class Initialized
INFO - 2016-03-04 10:02:31 --> Language Class Initialized
INFO - 2016-03-04 10:02:31 --> Loader Class Initialized
INFO - 2016-03-04 10:02:31 --> Helper loaded: url_helper
INFO - 2016-03-04 10:02:31 --> Helper loaded: file_helper
INFO - 2016-03-04 10:02:31 --> Helper loaded: date_helper
INFO - 2016-03-04 10:02:31 --> Helper loaded: form_helper
INFO - 2016-03-04 10:02:31 --> Database Driver Class Initialized
INFO - 2016-03-04 10:02:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:02:32 --> Controller Class Initialized
INFO - 2016-03-04 10:02:32 --> Model Class Initialized
INFO - 2016-03-04 10:02:32 --> Model Class Initialized
INFO - 2016-03-04 10:02:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:02:32 --> Pagination Class Initialized
INFO - 2016-03-04 10:02:32 --> Helper loaded: text_helper
INFO - 2016-03-04 10:02:32 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:02:32 --> Form Validation Class Initialized
INFO - 2016-03-04 13:02:32 --> Email Class Initialized
INFO - 2016-03-04 13:02:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-04 13:02:32 --> Severity: Notice --> Undefined variable: comment C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 620
INFO - 2016-03-04 13:02:32 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 10:02:34 --> Config Class Initialized
INFO - 2016-03-04 10:02:34 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:02:34 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:02:34 --> Utf8 Class Initialized
INFO - 2016-03-04 10:02:34 --> URI Class Initialized
INFO - 2016-03-04 10:02:34 --> Router Class Initialized
INFO - 2016-03-04 10:02:34 --> Output Class Initialized
INFO - 2016-03-04 10:02:34 --> Security Class Initialized
DEBUG - 2016-03-04 10:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:02:34 --> Input Class Initialized
INFO - 2016-03-04 10:02:34 --> Language Class Initialized
ERROR - 2016-03-04 10:02:34 --> 404 Page Not Found: Contactform/index
INFO - 2016-03-04 10:03:31 --> Config Class Initialized
INFO - 2016-03-04 10:03:31 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:03:31 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:03:31 --> Utf8 Class Initialized
INFO - 2016-03-04 10:03:31 --> URI Class Initialized
DEBUG - 2016-03-04 10:03:31 --> No URI present. Default controller set.
INFO - 2016-03-04 10:03:31 --> Router Class Initialized
INFO - 2016-03-04 10:03:31 --> Output Class Initialized
INFO - 2016-03-04 10:03:31 --> Security Class Initialized
DEBUG - 2016-03-04 10:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:03:31 --> Input Class Initialized
INFO - 2016-03-04 10:03:31 --> Language Class Initialized
INFO - 2016-03-04 10:03:31 --> Loader Class Initialized
INFO - 2016-03-04 10:03:31 --> Helper loaded: url_helper
INFO - 2016-03-04 10:03:31 --> Helper loaded: file_helper
INFO - 2016-03-04 10:03:31 --> Helper loaded: date_helper
INFO - 2016-03-04 10:03:31 --> Helper loaded: form_helper
INFO - 2016-03-04 10:03:31 --> Database Driver Class Initialized
INFO - 2016-03-04 10:03:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:03:32 --> Controller Class Initialized
INFO - 2016-03-04 10:03:32 --> Model Class Initialized
INFO - 2016-03-04 10:03:32 --> Model Class Initialized
INFO - 2016-03-04 10:03:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:03:32 --> Pagination Class Initialized
INFO - 2016-03-04 10:03:32 --> Helper loaded: text_helper
INFO - 2016-03-04 10:03:32 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:03:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:03:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:03:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:03:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:03:32 --> Final output sent to browser
DEBUG - 2016-03-04 13:03:32 --> Total execution time: 1.1662
INFO - 2016-03-04 10:05:52 --> Config Class Initialized
INFO - 2016-03-04 10:05:52 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:05:52 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:05:52 --> Utf8 Class Initialized
INFO - 2016-03-04 10:05:52 --> URI Class Initialized
DEBUG - 2016-03-04 10:05:52 --> No URI present. Default controller set.
INFO - 2016-03-04 10:05:52 --> Router Class Initialized
INFO - 2016-03-04 10:05:52 --> Output Class Initialized
INFO - 2016-03-04 10:05:52 --> Security Class Initialized
DEBUG - 2016-03-04 10:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:05:52 --> Input Class Initialized
INFO - 2016-03-04 10:05:52 --> Language Class Initialized
INFO - 2016-03-04 10:05:52 --> Loader Class Initialized
INFO - 2016-03-04 10:05:52 --> Helper loaded: url_helper
INFO - 2016-03-04 10:05:52 --> Helper loaded: file_helper
INFO - 2016-03-04 10:05:52 --> Helper loaded: date_helper
INFO - 2016-03-04 10:05:52 --> Helper loaded: form_helper
INFO - 2016-03-04 10:05:52 --> Database Driver Class Initialized
INFO - 2016-03-04 10:05:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:05:53 --> Controller Class Initialized
INFO - 2016-03-04 10:05:53 --> Model Class Initialized
INFO - 2016-03-04 10:05:53 --> Model Class Initialized
INFO - 2016-03-04 10:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:05:53 --> Pagination Class Initialized
INFO - 2016-03-04 10:05:53 --> Helper loaded: text_helper
INFO - 2016-03-04 10:05:53 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:05:53 --> Final output sent to browser
DEBUG - 2016-03-04 13:05:53 --> Total execution time: 1.0991
INFO - 2016-03-04 10:06:29 --> Config Class Initialized
INFO - 2016-03-04 10:06:29 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:06:29 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:06:29 --> Utf8 Class Initialized
INFO - 2016-03-04 10:06:29 --> URI Class Initialized
INFO - 2016-03-04 10:06:29 --> Router Class Initialized
INFO - 2016-03-04 10:06:29 --> Output Class Initialized
INFO - 2016-03-04 10:06:29 --> Security Class Initialized
DEBUG - 2016-03-04 10:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:06:29 --> Input Class Initialized
INFO - 2016-03-04 10:06:29 --> Language Class Initialized
ERROR - 2016-03-04 10:06:29 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 625
INFO - 2016-03-04 10:06:40 --> Config Class Initialized
INFO - 2016-03-04 10:06:40 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:06:40 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:06:40 --> Utf8 Class Initialized
INFO - 2016-03-04 10:06:40 --> URI Class Initialized
DEBUG - 2016-03-04 10:06:40 --> No URI present. Default controller set.
INFO - 2016-03-04 10:06:40 --> Router Class Initialized
INFO - 2016-03-04 10:06:41 --> Output Class Initialized
INFO - 2016-03-04 10:06:41 --> Security Class Initialized
DEBUG - 2016-03-04 10:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:06:41 --> Input Class Initialized
INFO - 2016-03-04 10:06:41 --> Language Class Initialized
INFO - 2016-03-04 10:06:41 --> Loader Class Initialized
INFO - 2016-03-04 10:06:41 --> Helper loaded: url_helper
INFO - 2016-03-04 10:06:41 --> Helper loaded: file_helper
INFO - 2016-03-04 10:06:41 --> Helper loaded: date_helper
INFO - 2016-03-04 10:06:41 --> Helper loaded: form_helper
INFO - 2016-03-04 10:06:41 --> Database Driver Class Initialized
INFO - 2016-03-04 10:06:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:06:42 --> Controller Class Initialized
INFO - 2016-03-04 10:06:42 --> Model Class Initialized
INFO - 2016-03-04 10:06:42 --> Model Class Initialized
INFO - 2016-03-04 10:06:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:06:42 --> Pagination Class Initialized
INFO - 2016-03-04 10:06:42 --> Helper loaded: text_helper
INFO - 2016-03-04 10:06:42 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:06:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:06:42 --> Final output sent to browser
DEBUG - 2016-03-04 13:06:42 --> Total execution time: 1.0964
INFO - 2016-03-04 10:07:02 --> Config Class Initialized
INFO - 2016-03-04 10:07:02 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:07:02 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:07:02 --> Utf8 Class Initialized
INFO - 2016-03-04 10:07:02 --> URI Class Initialized
INFO - 2016-03-04 10:07:02 --> Router Class Initialized
INFO - 2016-03-04 10:07:02 --> Output Class Initialized
INFO - 2016-03-04 10:07:02 --> Security Class Initialized
DEBUG - 2016-03-04 10:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:07:02 --> Input Class Initialized
INFO - 2016-03-04 10:07:02 --> Language Class Initialized
INFO - 2016-03-04 10:07:02 --> Loader Class Initialized
INFO - 2016-03-04 10:07:02 --> Helper loaded: url_helper
INFO - 2016-03-04 10:07:03 --> Helper loaded: file_helper
INFO - 2016-03-04 10:07:03 --> Helper loaded: date_helper
INFO - 2016-03-04 10:07:03 --> Helper loaded: form_helper
INFO - 2016-03-04 10:07:03 --> Database Driver Class Initialized
INFO - 2016-03-04 10:07:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:07:04 --> Controller Class Initialized
INFO - 2016-03-04 10:07:04 --> Model Class Initialized
INFO - 2016-03-04 10:07:04 --> Model Class Initialized
INFO - 2016-03-04 10:07:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:07:04 --> Pagination Class Initialized
INFO - 2016-03-04 10:07:04 --> Helper loaded: text_helper
INFO - 2016-03-04 10:07:04 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:07:04 --> Form Validation Class Initialized
INFO - 2016-03-04 13:07:04 --> Email Class Initialized
INFO - 2016-03-04 13:07:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 13:07:04 --> Final output sent to browser
DEBUG - 2016-03-04 13:07:04 --> Total execution time: 1.1471
INFO - 2016-03-04 10:07:28 --> Config Class Initialized
INFO - 2016-03-04 10:07:28 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:07:28 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:07:28 --> Utf8 Class Initialized
INFO - 2016-03-04 10:07:28 --> URI Class Initialized
DEBUG - 2016-03-04 10:07:28 --> No URI present. Default controller set.
INFO - 2016-03-04 10:07:28 --> Router Class Initialized
INFO - 2016-03-04 10:07:28 --> Output Class Initialized
INFO - 2016-03-04 10:07:28 --> Security Class Initialized
DEBUG - 2016-03-04 10:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:07:28 --> Input Class Initialized
INFO - 2016-03-04 10:07:28 --> Language Class Initialized
INFO - 2016-03-04 10:07:28 --> Loader Class Initialized
INFO - 2016-03-04 10:07:28 --> Helper loaded: url_helper
INFO - 2016-03-04 10:07:28 --> Helper loaded: file_helper
INFO - 2016-03-04 10:07:28 --> Helper loaded: date_helper
INFO - 2016-03-04 10:07:28 --> Helper loaded: form_helper
INFO - 2016-03-04 10:07:28 --> Database Driver Class Initialized
INFO - 2016-03-04 10:07:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:07:29 --> Controller Class Initialized
INFO - 2016-03-04 10:07:29 --> Model Class Initialized
INFO - 2016-03-04 10:07:29 --> Model Class Initialized
INFO - 2016-03-04 10:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:07:29 --> Pagination Class Initialized
INFO - 2016-03-04 10:07:29 --> Helper loaded: text_helper
INFO - 2016-03-04 10:07:29 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:07:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:07:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:07:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:07:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:07:29 --> Final output sent to browser
DEBUG - 2016-03-04 13:07:29 --> Total execution time: 1.1389
INFO - 2016-03-04 10:07:46 --> Config Class Initialized
INFO - 2016-03-04 10:07:46 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:07:46 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:07:46 --> Utf8 Class Initialized
INFO - 2016-03-04 10:07:46 --> URI Class Initialized
INFO - 2016-03-04 10:07:46 --> Router Class Initialized
INFO - 2016-03-04 10:07:46 --> Output Class Initialized
INFO - 2016-03-04 10:07:46 --> Security Class Initialized
DEBUG - 2016-03-04 10:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:07:46 --> Input Class Initialized
INFO - 2016-03-04 10:07:46 --> Language Class Initialized
INFO - 2016-03-04 10:07:46 --> Loader Class Initialized
INFO - 2016-03-04 10:07:46 --> Helper loaded: url_helper
INFO - 2016-03-04 10:07:46 --> Helper loaded: file_helper
INFO - 2016-03-04 10:07:46 --> Helper loaded: date_helper
INFO - 2016-03-04 10:07:46 --> Helper loaded: form_helper
INFO - 2016-03-04 10:07:46 --> Database Driver Class Initialized
INFO - 2016-03-04 10:07:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:07:47 --> Controller Class Initialized
INFO - 2016-03-04 10:07:47 --> Model Class Initialized
INFO - 2016-03-04 10:07:47 --> Model Class Initialized
INFO - 2016-03-04 10:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:07:47 --> Pagination Class Initialized
INFO - 2016-03-04 10:07:47 --> Helper loaded: text_helper
INFO - 2016-03-04 10:07:47 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:07:47 --> Form Validation Class Initialized
INFO - 2016-03-04 13:07:47 --> Email Class Initialized
INFO - 2016-03-04 13:07:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-04 13:07:47 --> Severity: Notice --> Undefined variable: to_email C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 618
INFO - 2016-03-04 13:07:47 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 13:07:47 --> Final output sent to browser
DEBUG - 2016-03-04 13:07:47 --> Total execution time: 1.6366
INFO - 2016-03-04 10:08:17 --> Config Class Initialized
INFO - 2016-03-04 10:08:17 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:08:17 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:08:17 --> Utf8 Class Initialized
INFO - 2016-03-04 10:08:17 --> URI Class Initialized
DEBUG - 2016-03-04 10:08:17 --> No URI present. Default controller set.
INFO - 2016-03-04 10:08:17 --> Router Class Initialized
INFO - 2016-03-04 10:08:17 --> Output Class Initialized
INFO - 2016-03-04 10:08:17 --> Security Class Initialized
DEBUG - 2016-03-04 10:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:08:17 --> Input Class Initialized
INFO - 2016-03-04 10:08:17 --> Language Class Initialized
INFO - 2016-03-04 10:08:17 --> Loader Class Initialized
INFO - 2016-03-04 10:08:17 --> Helper loaded: url_helper
INFO - 2016-03-04 10:08:17 --> Helper loaded: file_helper
INFO - 2016-03-04 10:08:17 --> Helper loaded: date_helper
INFO - 2016-03-04 10:08:17 --> Helper loaded: form_helper
INFO - 2016-03-04 10:08:17 --> Database Driver Class Initialized
INFO - 2016-03-04 10:08:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:08:18 --> Controller Class Initialized
INFO - 2016-03-04 10:08:18 --> Model Class Initialized
INFO - 2016-03-04 10:08:18 --> Model Class Initialized
INFO - 2016-03-04 10:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:08:18 --> Pagination Class Initialized
INFO - 2016-03-04 10:08:18 --> Helper loaded: text_helper
INFO - 2016-03-04 10:08:18 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:08:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:08:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:08:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:08:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:08:18 --> Final output sent to browser
DEBUG - 2016-03-04 13:08:18 --> Total execution time: 1.1531
INFO - 2016-03-04 10:08:43 --> Config Class Initialized
INFO - 2016-03-04 10:08:43 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:08:43 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:08:43 --> Utf8 Class Initialized
INFO - 2016-03-04 10:08:43 --> URI Class Initialized
INFO - 2016-03-04 10:08:43 --> Router Class Initialized
INFO - 2016-03-04 10:08:43 --> Output Class Initialized
INFO - 2016-03-04 10:08:43 --> Security Class Initialized
DEBUG - 2016-03-04 10:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:08:43 --> Input Class Initialized
INFO - 2016-03-04 10:08:43 --> Language Class Initialized
INFO - 2016-03-04 10:08:43 --> Loader Class Initialized
INFO - 2016-03-04 10:08:43 --> Helper loaded: url_helper
INFO - 2016-03-04 10:08:43 --> Helper loaded: file_helper
INFO - 2016-03-04 10:08:43 --> Helper loaded: date_helper
INFO - 2016-03-04 10:08:43 --> Helper loaded: form_helper
INFO - 2016-03-04 10:08:43 --> Database Driver Class Initialized
INFO - 2016-03-04 10:08:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:08:44 --> Controller Class Initialized
INFO - 2016-03-04 10:08:44 --> Model Class Initialized
INFO - 2016-03-04 10:08:44 --> Model Class Initialized
INFO - 2016-03-04 10:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:08:44 --> Pagination Class Initialized
INFO - 2016-03-04 10:08:44 --> Helper loaded: text_helper
INFO - 2016-03-04 10:08:44 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:08:44 --> Form Validation Class Initialized
INFO - 2016-03-04 13:08:44 --> Email Class Initialized
INFO - 2016-03-04 13:08:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 13:08:45 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 13:08:47 --> Final output sent to browser
DEBUG - 2016-03-04 13:08:47 --> Total execution time: 3.2791
INFO - 2016-03-04 10:08:57 --> Config Class Initialized
INFO - 2016-03-04 10:08:57 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:08:57 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:08:57 --> Utf8 Class Initialized
INFO - 2016-03-04 10:08:57 --> URI Class Initialized
DEBUG - 2016-03-04 10:08:57 --> No URI present. Default controller set.
INFO - 2016-03-04 10:08:57 --> Router Class Initialized
INFO - 2016-03-04 10:08:57 --> Output Class Initialized
INFO - 2016-03-04 10:08:57 --> Security Class Initialized
DEBUG - 2016-03-04 10:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:08:57 --> Input Class Initialized
INFO - 2016-03-04 10:08:57 --> Language Class Initialized
INFO - 2016-03-04 10:08:57 --> Loader Class Initialized
INFO - 2016-03-04 10:08:57 --> Helper loaded: url_helper
INFO - 2016-03-04 10:08:57 --> Helper loaded: file_helper
INFO - 2016-03-04 10:08:57 --> Helper loaded: date_helper
INFO - 2016-03-04 10:08:57 --> Helper loaded: form_helper
INFO - 2016-03-04 10:08:57 --> Database Driver Class Initialized
INFO - 2016-03-04 10:08:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:08:58 --> Controller Class Initialized
INFO - 2016-03-04 10:08:58 --> Model Class Initialized
INFO - 2016-03-04 10:08:58 --> Model Class Initialized
INFO - 2016-03-04 10:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:08:58 --> Pagination Class Initialized
INFO - 2016-03-04 10:08:58 --> Helper loaded: text_helper
INFO - 2016-03-04 10:08:58 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:08:58 --> Final output sent to browser
DEBUG - 2016-03-04 13:08:58 --> Total execution time: 1.1388
INFO - 2016-03-04 10:36:10 --> Config Class Initialized
INFO - 2016-03-04 10:36:10 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:36:10 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:36:10 --> Utf8 Class Initialized
INFO - 2016-03-04 10:36:10 --> URI Class Initialized
INFO - 2016-03-04 10:36:10 --> Router Class Initialized
INFO - 2016-03-04 10:36:10 --> Output Class Initialized
INFO - 2016-03-04 10:36:10 --> Security Class Initialized
DEBUG - 2016-03-04 10:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:36:10 --> Input Class Initialized
INFO - 2016-03-04 10:36:10 --> Language Class Initialized
INFO - 2016-03-04 10:36:10 --> Loader Class Initialized
INFO - 2016-03-04 10:36:10 --> Helper loaded: url_helper
INFO - 2016-03-04 10:36:10 --> Helper loaded: file_helper
INFO - 2016-03-04 10:36:10 --> Helper loaded: date_helper
INFO - 2016-03-04 10:36:10 --> Helper loaded: form_helper
INFO - 2016-03-04 10:36:10 --> Database Driver Class Initialized
INFO - 2016-03-04 10:36:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:36:12 --> Controller Class Initialized
INFO - 2016-03-04 10:36:12 --> Model Class Initialized
INFO - 2016-03-04 10:36:12 --> Model Class Initialized
INFO - 2016-03-04 10:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:36:12 --> Pagination Class Initialized
INFO - 2016-03-04 10:36:12 --> Helper loaded: text_helper
INFO - 2016-03-04 10:36:12 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:36:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:36:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:36:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 13:36:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 13:36:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 13:36:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 13:36:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:36:12 --> Final output sent to browser
DEBUG - 2016-03-04 13:36:12 --> Total execution time: 1.1255
INFO - 2016-03-04 10:36:41 --> Config Class Initialized
INFO - 2016-03-04 10:36:41 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:36:41 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:36:41 --> Utf8 Class Initialized
INFO - 2016-03-04 10:36:41 --> URI Class Initialized
INFO - 2016-03-04 10:36:41 --> Router Class Initialized
INFO - 2016-03-04 10:36:41 --> Output Class Initialized
INFO - 2016-03-04 10:36:41 --> Security Class Initialized
DEBUG - 2016-03-04 10:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:36:41 --> Input Class Initialized
INFO - 2016-03-04 10:36:41 --> Language Class Initialized
INFO - 2016-03-04 10:36:41 --> Loader Class Initialized
INFO - 2016-03-04 10:36:41 --> Helper loaded: url_helper
INFO - 2016-03-04 10:36:41 --> Helper loaded: file_helper
INFO - 2016-03-04 10:36:41 --> Helper loaded: date_helper
INFO - 2016-03-04 10:36:41 --> Helper loaded: form_helper
INFO - 2016-03-04 10:36:41 --> Database Driver Class Initialized
INFO - 2016-03-04 10:36:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:36:42 --> Controller Class Initialized
INFO - 2016-03-04 10:36:42 --> Model Class Initialized
INFO - 2016-03-04 10:36:42 --> Model Class Initialized
INFO - 2016-03-04 10:36:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:36:42 --> Pagination Class Initialized
INFO - 2016-03-04 10:36:42 --> Helper loaded: text_helper
INFO - 2016-03-04 10:36:42 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:36:42 --> Form Validation Class Initialized
INFO - 2016-03-04 13:36:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-04 13:36:42 --> Severity: Notice --> Undefined property: Jboard::$email C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 613
ERROR - 2016-03-04 13:36:42 --> Severity: Error --> Call to a member function initialize() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 613
INFO - 2016-03-04 10:38:50 --> Config Class Initialized
INFO - 2016-03-04 10:38:50 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:38:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:38:50 --> Utf8 Class Initialized
INFO - 2016-03-04 10:38:50 --> URI Class Initialized
INFO - 2016-03-04 10:38:50 --> Router Class Initialized
INFO - 2016-03-04 10:38:50 --> Output Class Initialized
INFO - 2016-03-04 10:38:50 --> Security Class Initialized
DEBUG - 2016-03-04 10:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:38:50 --> Input Class Initialized
INFO - 2016-03-04 10:38:50 --> Language Class Initialized
INFO - 2016-03-04 10:38:50 --> Loader Class Initialized
INFO - 2016-03-04 10:38:50 --> Helper loaded: url_helper
INFO - 2016-03-04 10:38:50 --> Helper loaded: file_helper
INFO - 2016-03-04 10:38:50 --> Helper loaded: date_helper
INFO - 2016-03-04 10:38:50 --> Helper loaded: form_helper
INFO - 2016-03-04 10:38:50 --> Database Driver Class Initialized
INFO - 2016-03-04 10:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:38:51 --> Controller Class Initialized
INFO - 2016-03-04 10:38:51 --> Model Class Initialized
INFO - 2016-03-04 10:38:51 --> Model Class Initialized
INFO - 2016-03-04 10:38:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:38:51 --> Pagination Class Initialized
INFO - 2016-03-04 10:38:51 --> Helper loaded: text_helper
INFO - 2016-03-04 10:38:51 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 13:38:51 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 13:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 13:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 13:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:38:51 --> Final output sent to browser
DEBUG - 2016-03-04 13:38:51 --> Total execution time: 1.1442
INFO - 2016-03-04 10:39:09 --> Config Class Initialized
INFO - 2016-03-04 10:39:09 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:39:09 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:39:09 --> Utf8 Class Initialized
INFO - 2016-03-04 10:39:09 --> URI Class Initialized
INFO - 2016-03-04 10:39:09 --> Router Class Initialized
INFO - 2016-03-04 10:39:09 --> Output Class Initialized
INFO - 2016-03-04 10:39:09 --> Security Class Initialized
DEBUG - 2016-03-04 10:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:39:09 --> Input Class Initialized
INFO - 2016-03-04 10:39:09 --> Language Class Initialized
INFO - 2016-03-04 10:39:09 --> Loader Class Initialized
INFO - 2016-03-04 10:39:09 --> Helper loaded: url_helper
INFO - 2016-03-04 10:39:09 --> Helper loaded: file_helper
INFO - 2016-03-04 10:39:09 --> Helper loaded: date_helper
INFO - 2016-03-04 10:39:09 --> Helper loaded: form_helper
INFO - 2016-03-04 10:39:09 --> Database Driver Class Initialized
INFO - 2016-03-04 10:39:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:39:10 --> Controller Class Initialized
INFO - 2016-03-04 10:39:10 --> Model Class Initialized
INFO - 2016-03-04 10:39:10 --> Model Class Initialized
INFO - 2016-03-04 10:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:39:10 --> Pagination Class Initialized
INFO - 2016-03-04 10:39:10 --> Helper loaded: text_helper
INFO - 2016-03-04 10:39:10 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:39:10 --> Form Validation Class Initialized
INFO - 2016-03-04 13:39:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-04 13:39:10 --> Severity: Notice --> Undefined property: Jboard::$email C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 613
ERROR - 2016-03-04 13:39:10 --> Severity: Error --> Call to a member function initialize() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 613
INFO - 2016-03-04 10:39:47 --> Config Class Initialized
INFO - 2016-03-04 10:39:47 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:39:47 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:39:47 --> Utf8 Class Initialized
INFO - 2016-03-04 10:39:47 --> URI Class Initialized
INFO - 2016-03-04 10:39:47 --> Router Class Initialized
INFO - 2016-03-04 10:39:47 --> Output Class Initialized
INFO - 2016-03-04 10:39:47 --> Security Class Initialized
DEBUG - 2016-03-04 10:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:39:47 --> Input Class Initialized
INFO - 2016-03-04 10:39:47 --> Language Class Initialized
INFO - 2016-03-04 10:39:47 --> Loader Class Initialized
INFO - 2016-03-04 10:39:47 --> Helper loaded: url_helper
INFO - 2016-03-04 10:39:47 --> Helper loaded: file_helper
INFO - 2016-03-04 10:39:47 --> Helper loaded: date_helper
INFO - 2016-03-04 10:39:47 --> Helper loaded: form_helper
INFO - 2016-03-04 10:39:47 --> Database Driver Class Initialized
INFO - 2016-03-04 10:39:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:39:48 --> Controller Class Initialized
INFO - 2016-03-04 10:39:48 --> Model Class Initialized
INFO - 2016-03-04 10:39:48 --> Model Class Initialized
INFO - 2016-03-04 10:39:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:39:48 --> Pagination Class Initialized
INFO - 2016-03-04 10:39:48 --> Helper loaded: text_helper
INFO - 2016-03-04 10:39:48 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:39:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:39:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:39:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 13:39:48 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 13:39:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 13:39:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 13:39:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:39:48 --> Final output sent to browser
DEBUG - 2016-03-04 13:39:48 --> Total execution time: 1.1092
INFO - 2016-03-04 10:40:09 --> Config Class Initialized
INFO - 2016-03-04 10:40:09 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:40:09 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:40:09 --> Utf8 Class Initialized
INFO - 2016-03-04 10:40:09 --> URI Class Initialized
INFO - 2016-03-04 10:40:09 --> Router Class Initialized
INFO - 2016-03-04 10:40:09 --> Output Class Initialized
INFO - 2016-03-04 10:40:09 --> Security Class Initialized
DEBUG - 2016-03-04 10:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:40:09 --> Input Class Initialized
INFO - 2016-03-04 10:40:09 --> Language Class Initialized
INFO - 2016-03-04 10:40:09 --> Loader Class Initialized
INFO - 2016-03-04 10:40:09 --> Helper loaded: url_helper
INFO - 2016-03-04 10:40:09 --> Helper loaded: file_helper
INFO - 2016-03-04 10:40:09 --> Helper loaded: date_helper
INFO - 2016-03-04 10:40:09 --> Helper loaded: form_helper
INFO - 2016-03-04 10:40:09 --> Database Driver Class Initialized
INFO - 2016-03-04 10:40:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:40:10 --> Controller Class Initialized
INFO - 2016-03-04 10:40:10 --> Model Class Initialized
INFO - 2016-03-04 10:40:10 --> Model Class Initialized
INFO - 2016-03-04 10:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:40:10 --> Pagination Class Initialized
INFO - 2016-03-04 10:40:10 --> Helper loaded: text_helper
INFO - 2016-03-04 10:40:10 --> Helper loaded: cookie_helper
INFO - 2016-03-04 10:40:10 --> Form Validation Class Initialized
INFO - 2016-03-04 13:40:10 --> Email Class Initialized
INFO - 2016-03-04 13:40:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 13:40:11 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 13:40:13 --> Final output sent to browser
DEBUG - 2016-03-04 13:40:13 --> Total execution time: 3.1959
INFO - 2016-03-04 10:40:39 --> Config Class Initialized
INFO - 2016-03-04 10:40:39 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:40:39 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:40:39 --> Utf8 Class Initialized
INFO - 2016-03-04 10:40:39 --> URI Class Initialized
INFO - 2016-03-04 10:40:39 --> Router Class Initialized
INFO - 2016-03-04 10:40:39 --> Output Class Initialized
INFO - 2016-03-04 10:40:39 --> Security Class Initialized
DEBUG - 2016-03-04 10:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:40:39 --> Input Class Initialized
INFO - 2016-03-04 10:40:39 --> Language Class Initialized
INFO - 2016-03-04 10:40:39 --> Loader Class Initialized
INFO - 2016-03-04 10:40:39 --> Helper loaded: url_helper
INFO - 2016-03-04 10:40:39 --> Helper loaded: file_helper
INFO - 2016-03-04 10:40:39 --> Helper loaded: date_helper
INFO - 2016-03-04 10:40:39 --> Helper loaded: form_helper
INFO - 2016-03-04 10:40:39 --> Database Driver Class Initialized
INFO - 2016-03-04 10:40:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:40:40 --> Controller Class Initialized
INFO - 2016-03-04 10:40:40 --> Model Class Initialized
INFO - 2016-03-04 10:40:40 --> Model Class Initialized
INFO - 2016-03-04 10:40:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:40:40 --> Pagination Class Initialized
INFO - 2016-03-04 10:40:40 --> Helper loaded: text_helper
INFO - 2016-03-04 10:40:40 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 13:40:40 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 13:40:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 13:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:40:40 --> Final output sent to browser
DEBUG - 2016-03-04 13:40:40 --> Total execution time: 1.1001
INFO - 2016-03-04 10:44:42 --> Config Class Initialized
INFO - 2016-03-04 10:44:42 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:44:42 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:44:42 --> Utf8 Class Initialized
INFO - 2016-03-04 10:44:42 --> URI Class Initialized
INFO - 2016-03-04 10:44:42 --> Router Class Initialized
INFO - 2016-03-04 10:44:42 --> Output Class Initialized
INFO - 2016-03-04 10:44:42 --> Security Class Initialized
DEBUG - 2016-03-04 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:44:42 --> Input Class Initialized
INFO - 2016-03-04 10:44:42 --> Language Class Initialized
INFO - 2016-03-04 10:44:42 --> Loader Class Initialized
INFO - 2016-03-04 10:44:42 --> Helper loaded: url_helper
INFO - 2016-03-04 10:44:42 --> Helper loaded: file_helper
INFO - 2016-03-04 10:44:42 --> Helper loaded: date_helper
INFO - 2016-03-04 10:44:42 --> Helper loaded: form_helper
INFO - 2016-03-04 10:44:42 --> Database Driver Class Initialized
INFO - 2016-03-04 10:44:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:44:43 --> Controller Class Initialized
INFO - 2016-03-04 10:44:43 --> Model Class Initialized
INFO - 2016-03-04 10:44:43 --> Model Class Initialized
INFO - 2016-03-04 10:44:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:44:43 --> Pagination Class Initialized
INFO - 2016-03-04 10:44:43 --> Helper loaded: text_helper
INFO - 2016-03-04 10:44:43 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 13:44:43 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 13:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 13:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 13:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:44:43 --> Final output sent to browser
DEBUG - 2016-03-04 13:44:43 --> Total execution time: 1.1984
INFO - 2016-03-04 10:49:56 --> Config Class Initialized
INFO - 2016-03-04 10:49:56 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:49:56 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:49:56 --> Utf8 Class Initialized
INFO - 2016-03-04 10:49:56 --> URI Class Initialized
DEBUG - 2016-03-04 10:49:56 --> No URI present. Default controller set.
INFO - 2016-03-04 10:49:56 --> Router Class Initialized
INFO - 2016-03-04 10:49:56 --> Output Class Initialized
INFO - 2016-03-04 10:49:56 --> Security Class Initialized
DEBUG - 2016-03-04 10:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:49:56 --> Input Class Initialized
INFO - 2016-03-04 10:49:56 --> Language Class Initialized
INFO - 2016-03-04 10:49:56 --> Loader Class Initialized
INFO - 2016-03-04 10:49:56 --> Helper loaded: url_helper
INFO - 2016-03-04 10:49:56 --> Helper loaded: file_helper
INFO - 2016-03-04 10:49:56 --> Helper loaded: date_helper
INFO - 2016-03-04 10:49:56 --> Helper loaded: form_helper
INFO - 2016-03-04 10:49:56 --> Database Driver Class Initialized
INFO - 2016-03-04 10:49:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:49:57 --> Controller Class Initialized
INFO - 2016-03-04 10:49:57 --> Model Class Initialized
INFO - 2016-03-04 10:49:57 --> Model Class Initialized
INFO - 2016-03-04 10:49:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:49:57 --> Pagination Class Initialized
INFO - 2016-03-04 10:49:57 --> Helper loaded: text_helper
INFO - 2016-03-04 10:49:57 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:49:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:49:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:49:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:49:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:49:57 --> Final output sent to browser
DEBUG - 2016-03-04 13:49:57 --> Total execution time: 1.1165
INFO - 2016-03-04 10:51:07 --> Config Class Initialized
INFO - 2016-03-04 10:51:07 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:51:07 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:51:07 --> Utf8 Class Initialized
INFO - 2016-03-04 10:51:07 --> URI Class Initialized
DEBUG - 2016-03-04 10:51:07 --> No URI present. Default controller set.
INFO - 2016-03-04 10:51:07 --> Router Class Initialized
INFO - 2016-03-04 10:51:07 --> Output Class Initialized
INFO - 2016-03-04 10:51:07 --> Security Class Initialized
DEBUG - 2016-03-04 10:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:51:07 --> Input Class Initialized
INFO - 2016-03-04 10:51:07 --> Language Class Initialized
INFO - 2016-03-04 10:51:07 --> Loader Class Initialized
INFO - 2016-03-04 10:51:07 --> Helper loaded: url_helper
INFO - 2016-03-04 10:51:07 --> Helper loaded: file_helper
INFO - 2016-03-04 10:51:07 --> Helper loaded: date_helper
INFO - 2016-03-04 10:51:07 --> Helper loaded: form_helper
INFO - 2016-03-04 10:51:07 --> Database Driver Class Initialized
INFO - 2016-03-04 10:51:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:51:08 --> Controller Class Initialized
INFO - 2016-03-04 10:51:08 --> Model Class Initialized
INFO - 2016-03-04 10:51:08 --> Model Class Initialized
INFO - 2016-03-04 10:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:51:08 --> Pagination Class Initialized
INFO - 2016-03-04 10:51:08 --> Helper loaded: text_helper
INFO - 2016-03-04 10:51:08 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 13:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:51:08 --> Final output sent to browser
DEBUG - 2016-03-04 13:51:08 --> Total execution time: 1.1237
INFO - 2016-03-04 10:51:16 --> Config Class Initialized
INFO - 2016-03-04 10:51:16 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:51:16 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:51:16 --> Utf8 Class Initialized
INFO - 2016-03-04 10:51:16 --> URI Class Initialized
INFO - 2016-03-04 10:51:16 --> Router Class Initialized
INFO - 2016-03-04 10:51:16 --> Output Class Initialized
INFO - 2016-03-04 10:51:16 --> Security Class Initialized
DEBUG - 2016-03-04 10:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:51:16 --> Input Class Initialized
INFO - 2016-03-04 10:51:16 --> Language Class Initialized
INFO - 2016-03-04 10:51:16 --> Loader Class Initialized
INFO - 2016-03-04 10:51:16 --> Helper loaded: url_helper
INFO - 2016-03-04 10:51:16 --> Helper loaded: file_helper
INFO - 2016-03-04 10:51:16 --> Helper loaded: date_helper
INFO - 2016-03-04 10:51:16 --> Helper loaded: form_helper
INFO - 2016-03-04 10:51:16 --> Database Driver Class Initialized
INFO - 2016-03-04 10:51:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:51:17 --> Controller Class Initialized
INFO - 2016-03-04 10:51:17 --> Model Class Initialized
INFO - 2016-03-04 10:51:18 --> Model Class Initialized
INFO - 2016-03-04 10:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:51:18 --> Pagination Class Initialized
INFO - 2016-03-04 10:51:18 --> Helper loaded: text_helper
INFO - 2016-03-04 10:51:18 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 13:51:18 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 13:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 13:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 13:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:51:18 --> Final output sent to browser
DEBUG - 2016-03-04 13:51:18 --> Total execution time: 1.1108
INFO - 2016-03-04 10:51:21 --> Config Class Initialized
INFO - 2016-03-04 10:51:21 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:51:21 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:51:21 --> Utf8 Class Initialized
INFO - 2016-03-04 10:51:21 --> URI Class Initialized
INFO - 2016-03-04 10:51:21 --> Router Class Initialized
INFO - 2016-03-04 10:51:21 --> Output Class Initialized
INFO - 2016-03-04 10:51:21 --> Security Class Initialized
DEBUG - 2016-03-04 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:51:21 --> Input Class Initialized
INFO - 2016-03-04 10:51:21 --> Language Class Initialized
INFO - 2016-03-04 10:51:21 --> Loader Class Initialized
INFO - 2016-03-04 10:51:21 --> Helper loaded: url_helper
INFO - 2016-03-04 10:51:21 --> Helper loaded: file_helper
INFO - 2016-03-04 10:51:21 --> Helper loaded: date_helper
INFO - 2016-03-04 10:51:21 --> Helper loaded: form_helper
INFO - 2016-03-04 10:51:21 --> Database Driver Class Initialized
INFO - 2016-03-04 10:51:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:51:22 --> Controller Class Initialized
INFO - 2016-03-04 10:51:22 --> Model Class Initialized
INFO - 2016-03-04 10:51:22 --> Model Class Initialized
INFO - 2016-03-04 10:51:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:51:22 --> Pagination Class Initialized
INFO - 2016-03-04 10:51:22 --> Helper loaded: text_helper
INFO - 2016-03-04 10:51:22 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:51:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:51:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:51:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 13:51:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 13:51:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:51:22 --> Final output sent to browser
DEBUG - 2016-03-04 13:51:22 --> Total execution time: 1.1330
INFO - 2016-03-04 10:52:14 --> Config Class Initialized
INFO - 2016-03-04 10:52:14 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:52:14 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:52:14 --> Utf8 Class Initialized
INFO - 2016-03-04 10:52:14 --> URI Class Initialized
INFO - 2016-03-04 10:52:14 --> Router Class Initialized
INFO - 2016-03-04 10:52:14 --> Output Class Initialized
INFO - 2016-03-04 10:52:14 --> Security Class Initialized
DEBUG - 2016-03-04 10:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:52:14 --> Input Class Initialized
INFO - 2016-03-04 10:52:14 --> Language Class Initialized
INFO - 2016-03-04 10:52:14 --> Loader Class Initialized
INFO - 2016-03-04 10:52:14 --> Helper loaded: url_helper
INFO - 2016-03-04 10:52:14 --> Helper loaded: file_helper
INFO - 2016-03-04 10:52:14 --> Helper loaded: date_helper
INFO - 2016-03-04 10:52:14 --> Helper loaded: form_helper
INFO - 2016-03-04 10:52:14 --> Database Driver Class Initialized
INFO - 2016-03-04 10:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:52:15 --> Controller Class Initialized
INFO - 2016-03-04 10:52:15 --> Model Class Initialized
INFO - 2016-03-04 10:52:15 --> Model Class Initialized
INFO - 2016-03-04 10:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:52:15 --> Pagination Class Initialized
INFO - 2016-03-04 10:52:15 --> Helper loaded: text_helper
INFO - 2016-03-04 10:52:15 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 13:52:15 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 13:52:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 13:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 13:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:52:15 --> Final output sent to browser
DEBUG - 2016-03-04 13:52:15 --> Total execution time: 1.1228
INFO - 2016-03-04 10:52:17 --> Config Class Initialized
INFO - 2016-03-04 10:52:17 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:52:17 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:52:17 --> Utf8 Class Initialized
INFO - 2016-03-04 10:52:17 --> URI Class Initialized
INFO - 2016-03-04 10:52:17 --> Router Class Initialized
INFO - 2016-03-04 10:52:17 --> Output Class Initialized
INFO - 2016-03-04 10:52:17 --> Security Class Initialized
DEBUG - 2016-03-04 10:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:52:17 --> Input Class Initialized
INFO - 2016-03-04 10:52:17 --> Language Class Initialized
INFO - 2016-03-04 10:52:17 --> Loader Class Initialized
INFO - 2016-03-04 10:52:17 --> Helper loaded: url_helper
INFO - 2016-03-04 10:52:17 --> Helper loaded: file_helper
INFO - 2016-03-04 10:52:17 --> Helper loaded: date_helper
INFO - 2016-03-04 10:52:17 --> Helper loaded: form_helper
INFO - 2016-03-04 10:52:18 --> Database Driver Class Initialized
INFO - 2016-03-04 10:52:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:52:19 --> Controller Class Initialized
INFO - 2016-03-04 10:52:19 --> Model Class Initialized
INFO - 2016-03-04 10:52:19 --> Model Class Initialized
INFO - 2016-03-04 10:52:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:52:19 --> Pagination Class Initialized
INFO - 2016-03-04 10:52:19 --> Helper loaded: text_helper
INFO - 2016-03-04 10:52:19 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 13:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 13:52:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:52:19 --> Final output sent to browser
DEBUG - 2016-03-04 13:52:19 --> Total execution time: 1.1194
INFO - 2016-03-04 10:53:28 --> Config Class Initialized
INFO - 2016-03-04 10:53:28 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:53:28 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:53:29 --> Utf8 Class Initialized
INFO - 2016-03-04 10:53:29 --> URI Class Initialized
INFO - 2016-03-04 10:53:29 --> Router Class Initialized
INFO - 2016-03-04 10:53:29 --> Output Class Initialized
INFO - 2016-03-04 10:53:29 --> Security Class Initialized
DEBUG - 2016-03-04 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:53:29 --> Input Class Initialized
INFO - 2016-03-04 10:53:29 --> Language Class Initialized
INFO - 2016-03-04 10:53:29 --> Loader Class Initialized
INFO - 2016-03-04 10:53:29 --> Helper loaded: url_helper
INFO - 2016-03-04 10:53:29 --> Helper loaded: file_helper
INFO - 2016-03-04 10:53:29 --> Helper loaded: date_helper
INFO - 2016-03-04 10:53:29 --> Helper loaded: form_helper
INFO - 2016-03-04 10:53:29 --> Database Driver Class Initialized
INFO - 2016-03-04 10:53:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:53:30 --> Controller Class Initialized
INFO - 2016-03-04 10:53:30 --> Model Class Initialized
INFO - 2016-03-04 10:53:30 --> Model Class Initialized
INFO - 2016-03-04 10:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:53:30 --> Pagination Class Initialized
INFO - 2016-03-04 10:53:30 --> Helper loaded: text_helper
INFO - 2016-03-04 10:53:30 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 13:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 13:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:53:30 --> Final output sent to browser
DEBUG - 2016-03-04 13:53:30 --> Total execution time: 1.2065
INFO - 2016-03-04 10:53:50 --> Config Class Initialized
INFO - 2016-03-04 10:53:50 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:53:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:53:50 --> Utf8 Class Initialized
INFO - 2016-03-04 10:53:50 --> URI Class Initialized
INFO - 2016-03-04 10:53:50 --> Router Class Initialized
INFO - 2016-03-04 10:53:50 --> Output Class Initialized
INFO - 2016-03-04 10:53:50 --> Security Class Initialized
DEBUG - 2016-03-04 10:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:53:50 --> Input Class Initialized
INFO - 2016-03-04 10:53:50 --> Language Class Initialized
INFO - 2016-03-04 10:53:50 --> Loader Class Initialized
INFO - 2016-03-04 10:53:50 --> Helper loaded: url_helper
INFO - 2016-03-04 10:53:50 --> Helper loaded: file_helper
INFO - 2016-03-04 10:53:50 --> Helper loaded: date_helper
INFO - 2016-03-04 10:53:50 --> Helper loaded: form_helper
INFO - 2016-03-04 10:53:50 --> Database Driver Class Initialized
INFO - 2016-03-04 10:53:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:53:51 --> Controller Class Initialized
INFO - 2016-03-04 10:53:51 --> Model Class Initialized
INFO - 2016-03-04 10:53:51 --> Model Class Initialized
INFO - 2016-03-04 10:53:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:53:51 --> Pagination Class Initialized
INFO - 2016-03-04 10:53:51 --> Helper loaded: text_helper
INFO - 2016-03-04 10:53:51 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 13:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 13:53:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:53:51 --> Final output sent to browser
DEBUG - 2016-03-04 13:53:51 --> Total execution time: 1.1944
INFO - 2016-03-04 10:54:54 --> Config Class Initialized
INFO - 2016-03-04 10:54:54 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:54:54 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:54:54 --> Utf8 Class Initialized
INFO - 2016-03-04 10:54:54 --> URI Class Initialized
INFO - 2016-03-04 10:54:54 --> Router Class Initialized
INFO - 2016-03-04 10:54:54 --> Output Class Initialized
INFO - 2016-03-04 10:54:54 --> Security Class Initialized
DEBUG - 2016-03-04 10:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:54:54 --> Input Class Initialized
INFO - 2016-03-04 10:54:54 --> Language Class Initialized
INFO - 2016-03-04 10:54:54 --> Loader Class Initialized
INFO - 2016-03-04 10:54:54 --> Helper loaded: url_helper
INFO - 2016-03-04 10:54:54 --> Helper loaded: file_helper
INFO - 2016-03-04 10:54:54 --> Helper loaded: date_helper
INFO - 2016-03-04 10:54:54 --> Helper loaded: form_helper
INFO - 2016-03-04 10:54:54 --> Database Driver Class Initialized
INFO - 2016-03-04 10:54:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:54:55 --> Controller Class Initialized
INFO - 2016-03-04 10:54:55 --> Model Class Initialized
INFO - 2016-03-04 10:54:55 --> Model Class Initialized
INFO - 2016-03-04 10:54:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:54:55 --> Pagination Class Initialized
INFO - 2016-03-04 10:54:55 --> Helper loaded: text_helper
INFO - 2016-03-04 10:54:55 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 13:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 13:54:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:54:55 --> Final output sent to browser
DEBUG - 2016-03-04 13:54:55 --> Total execution time: 1.3348
INFO - 2016-03-04 10:55:40 --> Config Class Initialized
INFO - 2016-03-04 10:55:40 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:55:40 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:55:40 --> Utf8 Class Initialized
INFO - 2016-03-04 10:55:40 --> URI Class Initialized
INFO - 2016-03-04 10:55:40 --> Router Class Initialized
INFO - 2016-03-04 10:55:40 --> Output Class Initialized
INFO - 2016-03-04 10:55:40 --> Security Class Initialized
DEBUG - 2016-03-04 10:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:55:40 --> Input Class Initialized
INFO - 2016-03-04 10:55:40 --> Language Class Initialized
INFO - 2016-03-04 10:55:40 --> Loader Class Initialized
INFO - 2016-03-04 10:55:40 --> Helper loaded: url_helper
INFO - 2016-03-04 10:55:40 --> Helper loaded: file_helper
INFO - 2016-03-04 10:55:40 --> Helper loaded: date_helper
INFO - 2016-03-04 10:55:40 --> Helper loaded: form_helper
INFO - 2016-03-04 10:55:40 --> Database Driver Class Initialized
INFO - 2016-03-04 10:55:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:55:41 --> Controller Class Initialized
INFO - 2016-03-04 10:55:41 --> Model Class Initialized
INFO - 2016-03-04 10:55:41 --> Model Class Initialized
INFO - 2016-03-04 10:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:55:41 --> Pagination Class Initialized
INFO - 2016-03-04 10:55:41 --> Helper loaded: text_helper
INFO - 2016-03-04 10:55:41 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 13:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 13:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:55:41 --> Final output sent to browser
DEBUG - 2016-03-04 13:55:41 --> Total execution time: 1.1704
INFO - 2016-03-04 10:55:51 --> Config Class Initialized
INFO - 2016-03-04 10:55:51 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:55:51 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:55:51 --> Utf8 Class Initialized
INFO - 2016-03-04 10:55:51 --> URI Class Initialized
INFO - 2016-03-04 10:55:51 --> Router Class Initialized
INFO - 2016-03-04 10:55:51 --> Output Class Initialized
INFO - 2016-03-04 10:55:51 --> Security Class Initialized
DEBUG - 2016-03-04 10:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:55:51 --> Input Class Initialized
INFO - 2016-03-04 10:55:51 --> Language Class Initialized
INFO - 2016-03-04 10:55:51 --> Loader Class Initialized
INFO - 2016-03-04 10:55:51 --> Helper loaded: url_helper
INFO - 2016-03-04 10:55:51 --> Helper loaded: file_helper
INFO - 2016-03-04 10:55:51 --> Helper loaded: date_helper
INFO - 2016-03-04 10:55:51 --> Helper loaded: form_helper
INFO - 2016-03-04 10:55:51 --> Database Driver Class Initialized
INFO - 2016-03-04 10:55:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:55:52 --> Controller Class Initialized
INFO - 2016-03-04 10:55:52 --> Model Class Initialized
INFO - 2016-03-04 10:55:52 --> Model Class Initialized
INFO - 2016-03-04 10:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:55:52 --> Pagination Class Initialized
INFO - 2016-03-04 10:55:52 --> Helper loaded: text_helper
INFO - 2016-03-04 10:55:52 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 13:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 13:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:55:52 --> Final output sent to browser
DEBUG - 2016-03-04 13:55:52 --> Total execution time: 1.2125
INFO - 2016-03-04 10:55:56 --> Config Class Initialized
INFO - 2016-03-04 10:55:56 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:55:56 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:55:56 --> Utf8 Class Initialized
INFO - 2016-03-04 10:55:56 --> URI Class Initialized
INFO - 2016-03-04 10:55:56 --> Router Class Initialized
INFO - 2016-03-04 10:55:56 --> Output Class Initialized
INFO - 2016-03-04 10:55:56 --> Security Class Initialized
DEBUG - 2016-03-04 10:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:55:56 --> Input Class Initialized
INFO - 2016-03-04 10:55:56 --> Language Class Initialized
INFO - 2016-03-04 10:55:56 --> Loader Class Initialized
INFO - 2016-03-04 10:55:56 --> Helper loaded: url_helper
INFO - 2016-03-04 10:55:56 --> Helper loaded: file_helper
INFO - 2016-03-04 10:55:56 --> Helper loaded: date_helper
INFO - 2016-03-04 10:55:56 --> Helper loaded: form_helper
INFO - 2016-03-04 10:55:56 --> Database Driver Class Initialized
INFO - 2016-03-04 10:55:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:55:57 --> Controller Class Initialized
INFO - 2016-03-04 10:55:57 --> Model Class Initialized
INFO - 2016-03-04 10:55:57 --> Model Class Initialized
INFO - 2016-03-04 10:55:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:55:57 --> Pagination Class Initialized
INFO - 2016-03-04 10:55:57 --> Helper loaded: text_helper
INFO - 2016-03-04 10:55:57 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 13:55:57 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 13:55:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 13:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 13:55:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:55:57 --> Final output sent to browser
DEBUG - 2016-03-04 13:55:57 --> Total execution time: 1.1607
INFO - 2016-03-04 10:55:59 --> Config Class Initialized
INFO - 2016-03-04 10:55:59 --> Hooks Class Initialized
DEBUG - 2016-03-04 10:55:59 --> UTF-8 Support Enabled
INFO - 2016-03-04 10:55:59 --> Utf8 Class Initialized
INFO - 2016-03-04 10:55:59 --> URI Class Initialized
INFO - 2016-03-04 10:55:59 --> Router Class Initialized
INFO - 2016-03-04 10:55:59 --> Output Class Initialized
INFO - 2016-03-04 10:55:59 --> Security Class Initialized
DEBUG - 2016-03-04 10:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 10:55:59 --> Input Class Initialized
INFO - 2016-03-04 10:55:59 --> Language Class Initialized
INFO - 2016-03-04 10:55:59 --> Loader Class Initialized
INFO - 2016-03-04 10:55:59 --> Helper loaded: url_helper
INFO - 2016-03-04 10:55:59 --> Helper loaded: file_helper
INFO - 2016-03-04 10:55:59 --> Helper loaded: date_helper
INFO - 2016-03-04 10:55:59 --> Helper loaded: form_helper
INFO - 2016-03-04 10:55:59 --> Database Driver Class Initialized
INFO - 2016-03-04 10:56:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 10:56:00 --> Controller Class Initialized
INFO - 2016-03-04 10:56:00 --> Model Class Initialized
INFO - 2016-03-04 10:56:00 --> Model Class Initialized
INFO - 2016-03-04 10:56:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 10:56:00 --> Pagination Class Initialized
INFO - 2016-03-04 10:56:00 --> Helper loaded: text_helper
INFO - 2016-03-04 10:56:00 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 13:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 13:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 13:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 13:56:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 13:56:00 --> Final output sent to browser
DEBUG - 2016-03-04 13:56:00 --> Total execution time: 1.1816
INFO - 2016-03-04 11:02:19 --> Config Class Initialized
INFO - 2016-03-04 11:02:19 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:02:19 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:02:19 --> Utf8 Class Initialized
INFO - 2016-03-04 11:02:19 --> URI Class Initialized
INFO - 2016-03-04 11:02:19 --> Router Class Initialized
INFO - 2016-03-04 11:02:19 --> Output Class Initialized
INFO - 2016-03-04 11:02:19 --> Security Class Initialized
DEBUG - 2016-03-04 11:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:02:19 --> Input Class Initialized
INFO - 2016-03-04 11:02:19 --> Language Class Initialized
INFO - 2016-03-04 11:02:19 --> Loader Class Initialized
INFO - 2016-03-04 11:02:19 --> Helper loaded: url_helper
INFO - 2016-03-04 11:02:19 --> Helper loaded: file_helper
INFO - 2016-03-04 11:02:19 --> Helper loaded: date_helper
INFO - 2016-03-04 11:02:19 --> Helper loaded: form_helper
INFO - 2016-03-04 11:02:19 --> Database Driver Class Initialized
INFO - 2016-03-04 11:02:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:02:20 --> Controller Class Initialized
INFO - 2016-03-04 11:02:20 --> Model Class Initialized
INFO - 2016-03-04 11:02:20 --> Model Class Initialized
INFO - 2016-03-04 11:02:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:02:20 --> Pagination Class Initialized
INFO - 2016-03-04 11:02:20 --> Helper loaded: text_helper
INFO - 2016-03-04 11:02:20 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:02:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:02:20 --> Final output sent to browser
DEBUG - 2016-03-04 14:02:20 --> Total execution time: 1.2381
INFO - 2016-03-04 11:04:21 --> Config Class Initialized
INFO - 2016-03-04 11:04:21 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:04:21 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:04:21 --> Utf8 Class Initialized
INFO - 2016-03-04 11:04:21 --> URI Class Initialized
INFO - 2016-03-04 11:04:21 --> Router Class Initialized
INFO - 2016-03-04 11:04:21 --> Output Class Initialized
INFO - 2016-03-04 11:04:21 --> Security Class Initialized
DEBUG - 2016-03-04 11:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:04:21 --> Input Class Initialized
INFO - 2016-03-04 11:04:21 --> Language Class Initialized
INFO - 2016-03-04 11:04:21 --> Loader Class Initialized
INFO - 2016-03-04 11:04:21 --> Helper loaded: url_helper
INFO - 2016-03-04 11:04:21 --> Helper loaded: file_helper
INFO - 2016-03-04 11:04:21 --> Helper loaded: date_helper
INFO - 2016-03-04 11:04:21 --> Helper loaded: form_helper
INFO - 2016-03-04 11:04:21 --> Database Driver Class Initialized
INFO - 2016-03-04 11:04:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:04:22 --> Controller Class Initialized
INFO - 2016-03-04 11:04:22 --> Model Class Initialized
INFO - 2016-03-04 11:04:22 --> Model Class Initialized
INFO - 2016-03-04 11:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:04:22 --> Pagination Class Initialized
INFO - 2016-03-04 11:04:22 --> Helper loaded: text_helper
INFO - 2016-03-04 11:04:22 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:04:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:04:22 --> Final output sent to browser
DEBUG - 2016-03-04 14:04:22 --> Total execution time: 1.1574
INFO - 2016-03-04 11:06:23 --> Config Class Initialized
INFO - 2016-03-04 11:06:23 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:06:23 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:06:23 --> Utf8 Class Initialized
INFO - 2016-03-04 11:06:23 --> URI Class Initialized
INFO - 2016-03-04 11:06:23 --> Router Class Initialized
INFO - 2016-03-04 11:06:23 --> Output Class Initialized
INFO - 2016-03-04 11:06:23 --> Security Class Initialized
DEBUG - 2016-03-04 11:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:06:23 --> Input Class Initialized
INFO - 2016-03-04 11:06:23 --> Language Class Initialized
INFO - 2016-03-04 11:06:23 --> Loader Class Initialized
INFO - 2016-03-04 11:06:23 --> Helper loaded: url_helper
INFO - 2016-03-04 11:06:23 --> Helper loaded: file_helper
INFO - 2016-03-04 11:06:23 --> Helper loaded: date_helper
INFO - 2016-03-04 11:06:23 --> Helper loaded: form_helper
INFO - 2016-03-04 11:06:23 --> Database Driver Class Initialized
INFO - 2016-03-04 11:06:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:06:24 --> Controller Class Initialized
INFO - 2016-03-04 11:06:24 --> Model Class Initialized
INFO - 2016-03-04 11:06:24 --> Model Class Initialized
INFO - 2016-03-04 11:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:06:24 --> Pagination Class Initialized
INFO - 2016-03-04 11:06:24 --> Helper loaded: text_helper
INFO - 2016-03-04 11:06:24 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:06:24 --> Final output sent to browser
DEBUG - 2016-03-04 14:06:24 --> Total execution time: 1.1779
INFO - 2016-03-04 11:06:42 --> Config Class Initialized
INFO - 2016-03-04 11:06:42 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:06:42 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:06:42 --> Utf8 Class Initialized
INFO - 2016-03-04 11:06:42 --> URI Class Initialized
INFO - 2016-03-04 11:06:42 --> Router Class Initialized
INFO - 2016-03-04 11:06:42 --> Output Class Initialized
INFO - 2016-03-04 11:06:42 --> Security Class Initialized
DEBUG - 2016-03-04 11:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:06:42 --> Input Class Initialized
INFO - 2016-03-04 11:06:42 --> Language Class Initialized
INFO - 2016-03-04 11:06:42 --> Loader Class Initialized
INFO - 2016-03-04 11:06:42 --> Helper loaded: url_helper
INFO - 2016-03-04 11:06:42 --> Helper loaded: file_helper
INFO - 2016-03-04 11:06:42 --> Helper loaded: date_helper
INFO - 2016-03-04 11:06:42 --> Helper loaded: form_helper
INFO - 2016-03-04 11:06:42 --> Database Driver Class Initialized
INFO - 2016-03-04 11:06:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:06:43 --> Controller Class Initialized
INFO - 2016-03-04 11:06:43 --> Model Class Initialized
INFO - 2016-03-04 11:06:43 --> Model Class Initialized
INFO - 2016-03-04 11:06:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:06:43 --> Pagination Class Initialized
INFO - 2016-03-04 11:06:43 --> Helper loaded: text_helper
INFO - 2016-03-04 11:06:43 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:06:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:06:43 --> Final output sent to browser
DEBUG - 2016-03-04 14:06:43 --> Total execution time: 1.2665
INFO - 2016-03-04 11:07:18 --> Config Class Initialized
INFO - 2016-03-04 11:07:18 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:07:18 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:07:18 --> Utf8 Class Initialized
INFO - 2016-03-04 11:07:18 --> URI Class Initialized
INFO - 2016-03-04 11:07:18 --> Router Class Initialized
INFO - 2016-03-04 11:07:18 --> Output Class Initialized
INFO - 2016-03-04 11:07:18 --> Security Class Initialized
DEBUG - 2016-03-04 11:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:07:18 --> Input Class Initialized
INFO - 2016-03-04 11:07:18 --> Language Class Initialized
INFO - 2016-03-04 11:07:18 --> Loader Class Initialized
INFO - 2016-03-04 11:07:18 --> Helper loaded: url_helper
INFO - 2016-03-04 11:07:18 --> Helper loaded: file_helper
INFO - 2016-03-04 11:07:18 --> Helper loaded: date_helper
INFO - 2016-03-04 11:07:18 --> Helper loaded: form_helper
INFO - 2016-03-04 11:07:18 --> Database Driver Class Initialized
INFO - 2016-03-04 11:07:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:07:19 --> Controller Class Initialized
INFO - 2016-03-04 11:07:19 --> Model Class Initialized
INFO - 2016-03-04 11:07:19 --> Model Class Initialized
INFO - 2016-03-04 11:07:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:07:19 --> Pagination Class Initialized
INFO - 2016-03-04 11:07:19 --> Helper loaded: text_helper
INFO - 2016-03-04 11:07:19 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:07:19 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:07:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:07:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:07:19 --> Final output sent to browser
DEBUG - 2016-03-04 14:07:19 --> Total execution time: 1.1264
INFO - 2016-03-04 11:07:29 --> Config Class Initialized
INFO - 2016-03-04 11:07:29 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:07:29 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:07:29 --> Utf8 Class Initialized
INFO - 2016-03-04 11:07:29 --> URI Class Initialized
INFO - 2016-03-04 11:07:29 --> Router Class Initialized
INFO - 2016-03-04 11:07:29 --> Output Class Initialized
INFO - 2016-03-04 11:07:29 --> Security Class Initialized
DEBUG - 2016-03-04 11:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:07:29 --> Input Class Initialized
INFO - 2016-03-04 11:07:29 --> Language Class Initialized
INFO - 2016-03-04 11:07:29 --> Loader Class Initialized
INFO - 2016-03-04 11:07:29 --> Helper loaded: url_helper
INFO - 2016-03-04 11:07:29 --> Helper loaded: file_helper
INFO - 2016-03-04 11:07:29 --> Helper loaded: date_helper
INFO - 2016-03-04 11:07:29 --> Helper loaded: form_helper
INFO - 2016-03-04 11:07:29 --> Database Driver Class Initialized
INFO - 2016-03-04 11:07:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:07:30 --> Controller Class Initialized
INFO - 2016-03-04 11:07:30 --> Model Class Initialized
INFO - 2016-03-04 11:07:30 --> Model Class Initialized
INFO - 2016-03-04 11:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:07:30 --> Pagination Class Initialized
INFO - 2016-03-04 11:07:30 --> Helper loaded: text_helper
INFO - 2016-03-04 11:07:30 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:07:30 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:07:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:07:30 --> Final output sent to browser
DEBUG - 2016-03-04 14:07:30 --> Total execution time: 1.0949
INFO - 2016-03-04 11:07:41 --> Config Class Initialized
INFO - 2016-03-04 11:07:41 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:07:41 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:07:41 --> Utf8 Class Initialized
INFO - 2016-03-04 11:07:41 --> URI Class Initialized
INFO - 2016-03-04 11:07:41 --> Router Class Initialized
INFO - 2016-03-04 11:07:41 --> Output Class Initialized
INFO - 2016-03-04 11:07:41 --> Security Class Initialized
DEBUG - 2016-03-04 11:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:07:41 --> Input Class Initialized
INFO - 2016-03-04 11:07:41 --> Language Class Initialized
INFO - 2016-03-04 11:07:41 --> Loader Class Initialized
INFO - 2016-03-04 11:07:41 --> Helper loaded: url_helper
INFO - 2016-03-04 11:07:41 --> Helper loaded: file_helper
INFO - 2016-03-04 11:07:41 --> Helper loaded: date_helper
INFO - 2016-03-04 11:07:41 --> Helper loaded: form_helper
INFO - 2016-03-04 11:07:41 --> Database Driver Class Initialized
INFO - 2016-03-04 11:07:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:07:42 --> Controller Class Initialized
INFO - 2016-03-04 11:07:42 --> Model Class Initialized
INFO - 2016-03-04 11:07:42 --> Model Class Initialized
INFO - 2016-03-04 11:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:07:42 --> Pagination Class Initialized
INFO - 2016-03-04 11:07:42 --> Helper loaded: text_helper
INFO - 2016-03-04 11:07:42 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:07:42 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:07:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:07:42 --> Final output sent to browser
DEBUG - 2016-03-04 14:07:42 --> Total execution time: 1.1474
INFO - 2016-03-04 11:07:52 --> Config Class Initialized
INFO - 2016-03-04 11:07:52 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:07:52 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:07:52 --> Utf8 Class Initialized
INFO - 2016-03-04 11:07:52 --> URI Class Initialized
INFO - 2016-03-04 11:07:52 --> Router Class Initialized
INFO - 2016-03-04 11:07:52 --> Output Class Initialized
INFO - 2016-03-04 11:07:52 --> Security Class Initialized
DEBUG - 2016-03-04 11:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:07:52 --> Input Class Initialized
INFO - 2016-03-04 11:07:52 --> Language Class Initialized
INFO - 2016-03-04 11:07:52 --> Loader Class Initialized
INFO - 2016-03-04 11:07:52 --> Helper loaded: url_helper
INFO - 2016-03-04 11:07:52 --> Helper loaded: file_helper
INFO - 2016-03-04 11:07:52 --> Helper loaded: date_helper
INFO - 2016-03-04 11:07:52 --> Helper loaded: form_helper
INFO - 2016-03-04 11:07:52 --> Database Driver Class Initialized
INFO - 2016-03-04 11:07:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:07:53 --> Controller Class Initialized
INFO - 2016-03-04 11:07:53 --> Model Class Initialized
INFO - 2016-03-04 11:07:53 --> Model Class Initialized
INFO - 2016-03-04 11:07:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:07:53 --> Pagination Class Initialized
INFO - 2016-03-04 11:07:53 --> Helper loaded: text_helper
INFO - 2016-03-04 11:07:53 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:07:53 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:07:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:07:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:07:53 --> Final output sent to browser
DEBUG - 2016-03-04 14:07:53 --> Total execution time: 1.1299
INFO - 2016-03-04 11:08:03 --> Config Class Initialized
INFO - 2016-03-04 11:08:03 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:08:03 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:08:03 --> Utf8 Class Initialized
INFO - 2016-03-04 11:08:03 --> URI Class Initialized
DEBUG - 2016-03-04 11:08:03 --> No URI present. Default controller set.
INFO - 2016-03-04 11:08:03 --> Router Class Initialized
INFO - 2016-03-04 11:08:03 --> Output Class Initialized
INFO - 2016-03-04 11:08:03 --> Security Class Initialized
DEBUG - 2016-03-04 11:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:08:03 --> Input Class Initialized
INFO - 2016-03-04 11:08:03 --> Language Class Initialized
INFO - 2016-03-04 11:08:03 --> Loader Class Initialized
INFO - 2016-03-04 11:08:03 --> Helper loaded: url_helper
INFO - 2016-03-04 11:08:03 --> Helper loaded: file_helper
INFO - 2016-03-04 11:08:03 --> Helper loaded: date_helper
INFO - 2016-03-04 11:08:03 --> Helper loaded: form_helper
INFO - 2016-03-04 11:08:03 --> Database Driver Class Initialized
INFO - 2016-03-04 11:08:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:08:04 --> Controller Class Initialized
INFO - 2016-03-04 11:08:04 --> Model Class Initialized
INFO - 2016-03-04 11:08:04 --> Model Class Initialized
INFO - 2016-03-04 11:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:08:04 --> Pagination Class Initialized
INFO - 2016-03-04 11:08:04 --> Helper loaded: text_helper
INFO - 2016-03-04 11:08:04 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:08:04 --> Final output sent to browser
DEBUG - 2016-03-04 14:08:04 --> Total execution time: 1.0996
INFO - 2016-03-04 11:08:11 --> Config Class Initialized
INFO - 2016-03-04 11:08:11 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:08:11 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:08:11 --> Utf8 Class Initialized
INFO - 2016-03-04 11:08:11 --> URI Class Initialized
INFO - 2016-03-04 11:08:11 --> Router Class Initialized
INFO - 2016-03-04 11:08:11 --> Output Class Initialized
INFO - 2016-03-04 11:08:11 --> Security Class Initialized
DEBUG - 2016-03-04 11:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:08:11 --> Input Class Initialized
INFO - 2016-03-04 11:08:11 --> Language Class Initialized
INFO - 2016-03-04 11:08:11 --> Loader Class Initialized
INFO - 2016-03-04 11:08:11 --> Helper loaded: url_helper
INFO - 2016-03-04 11:08:11 --> Helper loaded: file_helper
INFO - 2016-03-04 11:08:11 --> Helper loaded: date_helper
INFO - 2016-03-04 11:08:11 --> Helper loaded: form_helper
INFO - 2016-03-04 11:08:11 --> Database Driver Class Initialized
INFO - 2016-03-04 11:08:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:08:12 --> Controller Class Initialized
INFO - 2016-03-04 11:08:12 --> Model Class Initialized
INFO - 2016-03-04 11:08:12 --> Model Class Initialized
INFO - 2016-03-04 11:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:08:12 --> Pagination Class Initialized
INFO - 2016-03-04 11:08:12 --> Helper loaded: text_helper
INFO - 2016-03-04 11:08:12 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:08:13 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:08:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:08:13 --> Final output sent to browser
DEBUG - 2016-03-04 14:08:13 --> Total execution time: 1.1659
INFO - 2016-03-04 11:08:14 --> Config Class Initialized
INFO - 2016-03-04 11:08:14 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:08:14 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:08:14 --> Utf8 Class Initialized
INFO - 2016-03-04 11:08:14 --> URI Class Initialized
INFO - 2016-03-04 11:08:14 --> Router Class Initialized
INFO - 2016-03-04 11:08:14 --> Output Class Initialized
INFO - 2016-03-04 11:08:14 --> Security Class Initialized
DEBUG - 2016-03-04 11:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:08:14 --> Input Class Initialized
INFO - 2016-03-04 11:08:14 --> Language Class Initialized
INFO - 2016-03-04 11:08:14 --> Loader Class Initialized
INFO - 2016-03-04 11:08:14 --> Helper loaded: url_helper
INFO - 2016-03-04 11:08:14 --> Helper loaded: file_helper
INFO - 2016-03-04 11:08:14 --> Helper loaded: date_helper
INFO - 2016-03-04 11:08:14 --> Helper loaded: form_helper
INFO - 2016-03-04 11:08:14 --> Database Driver Class Initialized
INFO - 2016-03-04 11:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:08:15 --> Controller Class Initialized
INFO - 2016-03-04 11:08:15 --> Model Class Initialized
INFO - 2016-03-04 11:08:15 --> Model Class Initialized
INFO - 2016-03-04 11:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:08:15 --> Pagination Class Initialized
INFO - 2016-03-04 11:08:15 --> Helper loaded: text_helper
INFO - 2016-03-04 11:08:15 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:08:15 --> Final output sent to browser
DEBUG - 2016-03-04 14:08:15 --> Total execution time: 1.1893
INFO - 2016-03-04 11:09:51 --> Config Class Initialized
INFO - 2016-03-04 11:09:51 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:09:51 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:09:51 --> Utf8 Class Initialized
INFO - 2016-03-04 11:09:51 --> URI Class Initialized
INFO - 2016-03-04 11:09:51 --> Router Class Initialized
INFO - 2016-03-04 11:09:51 --> Output Class Initialized
INFO - 2016-03-04 11:09:51 --> Security Class Initialized
DEBUG - 2016-03-04 11:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:09:51 --> Input Class Initialized
INFO - 2016-03-04 11:09:51 --> Language Class Initialized
INFO - 2016-03-04 11:09:51 --> Loader Class Initialized
INFO - 2016-03-04 11:09:51 --> Helper loaded: url_helper
INFO - 2016-03-04 11:09:51 --> Helper loaded: file_helper
INFO - 2016-03-04 11:09:51 --> Helper loaded: date_helper
INFO - 2016-03-04 11:09:51 --> Helper loaded: form_helper
INFO - 2016-03-04 11:09:51 --> Database Driver Class Initialized
INFO - 2016-03-04 11:09:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:09:52 --> Controller Class Initialized
INFO - 2016-03-04 11:09:52 --> Model Class Initialized
INFO - 2016-03-04 11:09:52 --> Model Class Initialized
INFO - 2016-03-04 11:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:09:52 --> Pagination Class Initialized
INFO - 2016-03-04 11:09:52 --> Helper loaded: text_helper
INFO - 2016-03-04 11:09:52 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:09:52 --> Final output sent to browser
DEBUG - 2016-03-04 14:09:52 --> Total execution time: 1.1342
INFO - 2016-03-04 11:12:03 --> Config Class Initialized
INFO - 2016-03-04 11:12:03 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:12:03 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:12:03 --> Utf8 Class Initialized
INFO - 2016-03-04 11:12:03 --> URI Class Initialized
DEBUG - 2016-03-04 11:12:03 --> No URI present. Default controller set.
INFO - 2016-03-04 11:12:03 --> Router Class Initialized
INFO - 2016-03-04 11:12:03 --> Output Class Initialized
INFO - 2016-03-04 11:12:03 --> Security Class Initialized
DEBUG - 2016-03-04 11:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:12:03 --> Input Class Initialized
INFO - 2016-03-04 11:12:03 --> Language Class Initialized
INFO - 2016-03-04 11:12:03 --> Loader Class Initialized
INFO - 2016-03-04 11:12:03 --> Helper loaded: url_helper
INFO - 2016-03-04 11:12:03 --> Helper loaded: file_helper
INFO - 2016-03-04 11:12:03 --> Helper loaded: date_helper
INFO - 2016-03-04 11:12:03 --> Helper loaded: form_helper
INFO - 2016-03-04 11:12:03 --> Database Driver Class Initialized
INFO - 2016-03-04 11:12:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:12:05 --> Controller Class Initialized
INFO - 2016-03-04 11:12:05 --> Model Class Initialized
INFO - 2016-03-04 11:12:05 --> Model Class Initialized
INFO - 2016-03-04 11:12:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:12:05 --> Pagination Class Initialized
INFO - 2016-03-04 11:12:05 --> Helper loaded: text_helper
INFO - 2016-03-04 11:12:05 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:12:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:12:05 --> Final output sent to browser
DEBUG - 2016-03-04 14:12:05 --> Total execution time: 1.1454
INFO - 2016-03-04 11:12:08 --> Config Class Initialized
INFO - 2016-03-04 11:12:08 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:12:08 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:12:08 --> Utf8 Class Initialized
INFO - 2016-03-04 11:12:08 --> URI Class Initialized
INFO - 2016-03-04 11:12:08 --> Router Class Initialized
INFO - 2016-03-04 11:12:08 --> Output Class Initialized
INFO - 2016-03-04 11:12:08 --> Security Class Initialized
DEBUG - 2016-03-04 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:12:08 --> Input Class Initialized
INFO - 2016-03-04 11:12:08 --> Language Class Initialized
INFO - 2016-03-04 11:12:08 --> Loader Class Initialized
INFO - 2016-03-04 11:12:08 --> Helper loaded: url_helper
INFO - 2016-03-04 11:12:08 --> Helper loaded: file_helper
INFO - 2016-03-04 11:12:08 --> Helper loaded: date_helper
INFO - 2016-03-04 11:12:08 --> Helper loaded: form_helper
INFO - 2016-03-04 11:12:08 --> Database Driver Class Initialized
INFO - 2016-03-04 11:12:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:12:09 --> Controller Class Initialized
INFO - 2016-03-04 11:12:09 --> Model Class Initialized
INFO - 2016-03-04 11:12:09 --> Model Class Initialized
INFO - 2016-03-04 11:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:12:09 --> Pagination Class Initialized
INFO - 2016-03-04 11:12:09 --> Helper loaded: text_helper
INFO - 2016-03-04 11:12:09 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:12:09 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:12:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:12:09 --> Final output sent to browser
DEBUG - 2016-03-04 14:12:09 --> Total execution time: 1.1070
INFO - 2016-03-04 11:12:11 --> Config Class Initialized
INFO - 2016-03-04 11:12:11 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:12:11 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:12:11 --> Utf8 Class Initialized
INFO - 2016-03-04 11:12:11 --> URI Class Initialized
INFO - 2016-03-04 11:12:11 --> Router Class Initialized
INFO - 2016-03-04 11:12:11 --> Output Class Initialized
INFO - 2016-03-04 11:12:11 --> Security Class Initialized
DEBUG - 2016-03-04 11:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:12:11 --> Input Class Initialized
INFO - 2016-03-04 11:12:11 --> Language Class Initialized
INFO - 2016-03-04 11:12:11 --> Loader Class Initialized
INFO - 2016-03-04 11:12:11 --> Helper loaded: url_helper
INFO - 2016-03-04 11:12:11 --> Helper loaded: file_helper
INFO - 2016-03-04 11:12:11 --> Helper loaded: date_helper
INFO - 2016-03-04 11:12:11 --> Helper loaded: form_helper
INFO - 2016-03-04 11:12:11 --> Database Driver Class Initialized
INFO - 2016-03-04 11:12:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:12:12 --> Controller Class Initialized
INFO - 2016-03-04 11:12:12 --> Model Class Initialized
INFO - 2016-03-04 11:12:12 --> Model Class Initialized
INFO - 2016-03-04 11:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:12:12 --> Pagination Class Initialized
INFO - 2016-03-04 11:12:12 --> Helper loaded: text_helper
INFO - 2016-03-04 11:12:12 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:12:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:12:12 --> Final output sent to browser
DEBUG - 2016-03-04 14:12:12 --> Total execution time: 1.1194
INFO - 2016-03-04 11:12:14 --> Config Class Initialized
INFO - 2016-03-04 11:12:14 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:12:14 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:12:14 --> Utf8 Class Initialized
INFO - 2016-03-04 11:12:14 --> URI Class Initialized
INFO - 2016-03-04 11:12:14 --> Router Class Initialized
INFO - 2016-03-04 11:12:14 --> Output Class Initialized
INFO - 2016-03-04 11:12:14 --> Security Class Initialized
DEBUG - 2016-03-04 11:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:12:14 --> Input Class Initialized
INFO - 2016-03-04 11:12:14 --> Language Class Initialized
INFO - 2016-03-04 11:12:14 --> Loader Class Initialized
INFO - 2016-03-04 11:12:14 --> Helper loaded: url_helper
INFO - 2016-03-04 11:12:14 --> Helper loaded: file_helper
INFO - 2016-03-04 11:12:14 --> Helper loaded: date_helper
INFO - 2016-03-04 11:12:14 --> Helper loaded: form_helper
INFO - 2016-03-04 11:12:14 --> Database Driver Class Initialized
INFO - 2016-03-04 11:12:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:12:15 --> Controller Class Initialized
INFO - 2016-03-04 11:12:15 --> Model Class Initialized
INFO - 2016-03-04 11:12:15 --> Model Class Initialized
INFO - 2016-03-04 11:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:12:15 --> Pagination Class Initialized
INFO - 2016-03-04 11:12:15 --> Helper loaded: text_helper
INFO - 2016-03-04 11:12:15 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:12:15 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-04 14:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:12:15 --> Final output sent to browser
DEBUG - 2016-03-04 14:12:15 --> Total execution time: 1.1578
INFO - 2016-03-04 11:13:01 --> Config Class Initialized
INFO - 2016-03-04 11:13:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:13:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:13:01 --> Utf8 Class Initialized
INFO - 2016-03-04 11:13:01 --> URI Class Initialized
INFO - 2016-03-04 11:13:01 --> Router Class Initialized
INFO - 2016-03-04 11:13:01 --> Output Class Initialized
INFO - 2016-03-04 11:13:01 --> Security Class Initialized
DEBUG - 2016-03-04 11:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:13:01 --> Input Class Initialized
INFO - 2016-03-04 11:13:01 --> Language Class Initialized
INFO - 2016-03-04 11:13:01 --> Loader Class Initialized
INFO - 2016-03-04 11:13:01 --> Helper loaded: url_helper
INFO - 2016-03-04 11:13:01 --> Helper loaded: file_helper
INFO - 2016-03-04 11:13:01 --> Helper loaded: date_helper
INFO - 2016-03-04 11:13:01 --> Helper loaded: form_helper
INFO - 2016-03-04 11:13:01 --> Database Driver Class Initialized
INFO - 2016-03-04 11:13:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:13:02 --> Controller Class Initialized
INFO - 2016-03-04 11:13:02 --> Model Class Initialized
INFO - 2016-03-04 11:13:02 --> Model Class Initialized
INFO - 2016-03-04 11:13:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:13:02 --> Pagination Class Initialized
INFO - 2016-03-04 11:13:02 --> Helper loaded: text_helper
INFO - 2016-03-04 11:13:02 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:13:02 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:13:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-04 14:13:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:13:02 --> Final output sent to browser
DEBUG - 2016-03-04 14:13:02 --> Total execution time: 1.1316
INFO - 2016-03-04 11:13:04 --> Config Class Initialized
INFO - 2016-03-04 11:13:04 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:13:04 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:13:04 --> Utf8 Class Initialized
INFO - 2016-03-04 11:13:04 --> URI Class Initialized
DEBUG - 2016-03-04 11:13:04 --> No URI present. Default controller set.
INFO - 2016-03-04 11:13:04 --> Router Class Initialized
INFO - 2016-03-04 11:13:04 --> Output Class Initialized
INFO - 2016-03-04 11:13:04 --> Security Class Initialized
DEBUG - 2016-03-04 11:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:13:04 --> Input Class Initialized
INFO - 2016-03-04 11:13:04 --> Language Class Initialized
INFO - 2016-03-04 11:13:04 --> Loader Class Initialized
INFO - 2016-03-04 11:13:04 --> Helper loaded: url_helper
INFO - 2016-03-04 11:13:04 --> Helper loaded: file_helper
INFO - 2016-03-04 11:13:04 --> Helper loaded: date_helper
INFO - 2016-03-04 11:13:04 --> Helper loaded: form_helper
INFO - 2016-03-04 11:13:04 --> Database Driver Class Initialized
INFO - 2016-03-04 11:13:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:13:05 --> Controller Class Initialized
INFO - 2016-03-04 11:13:05 --> Model Class Initialized
INFO - 2016-03-04 11:13:05 --> Model Class Initialized
INFO - 2016-03-04 11:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:13:05 --> Pagination Class Initialized
INFO - 2016-03-04 11:13:05 --> Helper loaded: text_helper
INFO - 2016-03-04 11:13:05 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:13:05 --> Final output sent to browser
DEBUG - 2016-03-04 14:13:05 --> Total execution time: 1.1393
INFO - 2016-03-04 11:13:06 --> Config Class Initialized
INFO - 2016-03-04 11:13:06 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:13:06 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:13:06 --> Utf8 Class Initialized
INFO - 2016-03-04 11:13:06 --> URI Class Initialized
INFO - 2016-03-04 11:13:06 --> Router Class Initialized
INFO - 2016-03-04 11:13:06 --> Output Class Initialized
INFO - 2016-03-04 11:13:06 --> Security Class Initialized
DEBUG - 2016-03-04 11:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:13:06 --> Input Class Initialized
INFO - 2016-03-04 11:13:06 --> Language Class Initialized
INFO - 2016-03-04 11:13:06 --> Loader Class Initialized
INFO - 2016-03-04 11:13:06 --> Helper loaded: url_helper
INFO - 2016-03-04 11:13:06 --> Helper loaded: file_helper
INFO - 2016-03-04 11:13:06 --> Helper loaded: date_helper
INFO - 2016-03-04 11:13:06 --> Helper loaded: form_helper
INFO - 2016-03-04 11:13:06 --> Database Driver Class Initialized
INFO - 2016-03-04 11:13:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:13:07 --> Controller Class Initialized
INFO - 2016-03-04 11:13:07 --> Model Class Initialized
INFO - 2016-03-04 11:13:07 --> Model Class Initialized
INFO - 2016-03-04 11:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:13:07 --> Pagination Class Initialized
INFO - 2016-03-04 11:13:07 --> Helper loaded: text_helper
INFO - 2016-03-04 11:13:07 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:13:07 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:13:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:13:07 --> Final output sent to browser
DEBUG - 2016-03-04 14:13:07 --> Total execution time: 1.1007
INFO - 2016-03-04 11:13:37 --> Config Class Initialized
INFO - 2016-03-04 11:13:37 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:13:37 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:13:37 --> Utf8 Class Initialized
INFO - 2016-03-04 11:13:37 --> URI Class Initialized
INFO - 2016-03-04 11:13:37 --> Router Class Initialized
INFO - 2016-03-04 11:13:37 --> Output Class Initialized
INFO - 2016-03-04 11:13:37 --> Security Class Initialized
DEBUG - 2016-03-04 11:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:13:37 --> Input Class Initialized
INFO - 2016-03-04 11:13:37 --> Language Class Initialized
INFO - 2016-03-04 11:13:37 --> Loader Class Initialized
INFO - 2016-03-04 11:13:37 --> Helper loaded: url_helper
INFO - 2016-03-04 11:13:37 --> Helper loaded: file_helper
INFO - 2016-03-04 11:13:37 --> Helper loaded: date_helper
INFO - 2016-03-04 11:13:37 --> Helper loaded: form_helper
INFO - 2016-03-04 11:13:37 --> Database Driver Class Initialized
INFO - 2016-03-04 11:13:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:13:38 --> Controller Class Initialized
INFO - 2016-03-04 11:13:38 --> Model Class Initialized
INFO - 2016-03-04 11:13:38 --> Model Class Initialized
INFO - 2016-03-04 11:13:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:13:38 --> Pagination Class Initialized
INFO - 2016-03-04 11:13:38 --> Helper loaded: text_helper
INFO - 2016-03-04 11:13:38 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:13:38 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:13:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:13:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:13:38 --> Final output sent to browser
DEBUG - 2016-03-04 14:13:38 --> Total execution time: 1.1386
INFO - 2016-03-04 11:14:23 --> Config Class Initialized
INFO - 2016-03-04 11:14:23 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:14:23 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:14:23 --> Utf8 Class Initialized
INFO - 2016-03-04 11:14:23 --> URI Class Initialized
INFO - 2016-03-04 11:14:23 --> Router Class Initialized
INFO - 2016-03-04 11:14:23 --> Output Class Initialized
INFO - 2016-03-04 11:14:23 --> Security Class Initialized
DEBUG - 2016-03-04 11:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:14:23 --> Input Class Initialized
INFO - 2016-03-04 11:14:23 --> Language Class Initialized
INFO - 2016-03-04 11:14:23 --> Loader Class Initialized
INFO - 2016-03-04 11:14:23 --> Helper loaded: url_helper
INFO - 2016-03-04 11:14:23 --> Helper loaded: file_helper
INFO - 2016-03-04 11:14:23 --> Helper loaded: date_helper
INFO - 2016-03-04 11:14:23 --> Helper loaded: form_helper
INFO - 2016-03-04 11:14:23 --> Database Driver Class Initialized
INFO - 2016-03-04 11:14:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:14:24 --> Controller Class Initialized
INFO - 2016-03-04 11:14:24 --> Model Class Initialized
INFO - 2016-03-04 11:14:24 --> Model Class Initialized
INFO - 2016-03-04 11:14:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:14:24 --> Pagination Class Initialized
INFO - 2016-03-04 11:14:24 --> Helper loaded: text_helper
INFO - 2016-03-04 11:14:24 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:14:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:14:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:14:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:14:24 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:14:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:14:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:14:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:14:24 --> Final output sent to browser
DEBUG - 2016-03-04 14:14:24 --> Total execution time: 1.1618
INFO - 2016-03-04 11:14:25 --> Config Class Initialized
INFO - 2016-03-04 11:14:25 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:14:25 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:14:25 --> Utf8 Class Initialized
INFO - 2016-03-04 11:14:25 --> URI Class Initialized
DEBUG - 2016-03-04 11:14:25 --> No URI present. Default controller set.
INFO - 2016-03-04 11:14:25 --> Router Class Initialized
INFO - 2016-03-04 11:14:25 --> Output Class Initialized
INFO - 2016-03-04 11:14:25 --> Security Class Initialized
DEBUG - 2016-03-04 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:14:25 --> Input Class Initialized
INFO - 2016-03-04 11:14:25 --> Language Class Initialized
INFO - 2016-03-04 11:14:25 --> Loader Class Initialized
INFO - 2016-03-04 11:14:25 --> Helper loaded: url_helper
INFO - 2016-03-04 11:14:25 --> Helper loaded: file_helper
INFO - 2016-03-04 11:14:25 --> Helper loaded: date_helper
INFO - 2016-03-04 11:14:25 --> Helper loaded: form_helper
INFO - 2016-03-04 11:14:25 --> Database Driver Class Initialized
INFO - 2016-03-04 11:14:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:14:26 --> Controller Class Initialized
INFO - 2016-03-04 11:14:26 --> Model Class Initialized
INFO - 2016-03-04 11:14:26 --> Model Class Initialized
INFO - 2016-03-04 11:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:14:26 --> Pagination Class Initialized
INFO - 2016-03-04 11:14:26 --> Helper loaded: text_helper
INFO - 2016-03-04 11:14:26 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:14:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:14:26 --> Final output sent to browser
DEBUG - 2016-03-04 14:14:26 --> Total execution time: 1.1342
INFO - 2016-03-04 11:14:31 --> Config Class Initialized
INFO - 2016-03-04 11:14:31 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:14:31 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:14:31 --> Utf8 Class Initialized
INFO - 2016-03-04 11:14:31 --> URI Class Initialized
INFO - 2016-03-04 11:14:31 --> Router Class Initialized
INFO - 2016-03-04 11:14:31 --> Output Class Initialized
INFO - 2016-03-04 11:14:31 --> Security Class Initialized
DEBUG - 2016-03-04 11:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:14:31 --> Input Class Initialized
INFO - 2016-03-04 11:14:31 --> Language Class Initialized
INFO - 2016-03-04 11:14:32 --> Loader Class Initialized
INFO - 2016-03-04 11:14:32 --> Helper loaded: url_helper
INFO - 2016-03-04 11:14:32 --> Helper loaded: file_helper
INFO - 2016-03-04 11:14:32 --> Helper loaded: date_helper
INFO - 2016-03-04 11:14:32 --> Helper loaded: form_helper
INFO - 2016-03-04 11:14:32 --> Database Driver Class Initialized
INFO - 2016-03-04 11:14:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:14:33 --> Controller Class Initialized
INFO - 2016-03-04 11:14:33 --> Model Class Initialized
INFO - 2016-03-04 11:14:33 --> Model Class Initialized
INFO - 2016-03-04 11:14:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:14:33 --> Pagination Class Initialized
INFO - 2016-03-04 11:14:33 --> Helper loaded: text_helper
INFO - 2016-03-04 11:14:33 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:14:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:14:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:14:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:14:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:14:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:14:33 --> Final output sent to browser
DEBUG - 2016-03-04 14:14:33 --> Total execution time: 1.1622
INFO - 2016-03-04 11:14:42 --> Config Class Initialized
INFO - 2016-03-04 11:14:42 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:14:42 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:14:42 --> Utf8 Class Initialized
INFO - 2016-03-04 11:14:42 --> URI Class Initialized
INFO - 2016-03-04 11:14:42 --> Router Class Initialized
INFO - 2016-03-04 11:14:42 --> Output Class Initialized
INFO - 2016-03-04 11:14:42 --> Security Class Initialized
DEBUG - 2016-03-04 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:14:42 --> Input Class Initialized
INFO - 2016-03-04 11:14:42 --> Language Class Initialized
INFO - 2016-03-04 11:14:42 --> Loader Class Initialized
INFO - 2016-03-04 11:14:42 --> Helper loaded: url_helper
INFO - 2016-03-04 11:14:42 --> Helper loaded: file_helper
INFO - 2016-03-04 11:14:42 --> Helper loaded: date_helper
INFO - 2016-03-04 11:14:42 --> Helper loaded: form_helper
INFO - 2016-03-04 11:14:42 --> Database Driver Class Initialized
INFO - 2016-03-04 11:14:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:14:43 --> Controller Class Initialized
INFO - 2016-03-04 11:14:43 --> Model Class Initialized
INFO - 2016-03-04 11:14:43 --> Model Class Initialized
INFO - 2016-03-04 11:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:14:43 --> Pagination Class Initialized
INFO - 2016-03-04 11:14:43 --> Helper loaded: text_helper
INFO - 2016-03-04 11:14:43 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:14:43 --> Final output sent to browser
DEBUG - 2016-03-04 14:14:43 --> Total execution time: 1.1631
INFO - 2016-03-04 11:15:30 --> Config Class Initialized
INFO - 2016-03-04 11:15:30 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:15:30 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:15:30 --> Utf8 Class Initialized
INFO - 2016-03-04 11:15:30 --> URI Class Initialized
INFO - 2016-03-04 11:15:30 --> Router Class Initialized
INFO - 2016-03-04 11:15:30 --> Output Class Initialized
INFO - 2016-03-04 11:15:30 --> Security Class Initialized
DEBUG - 2016-03-04 11:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:15:30 --> Input Class Initialized
INFO - 2016-03-04 11:15:30 --> Language Class Initialized
INFO - 2016-03-04 11:15:30 --> Loader Class Initialized
INFO - 2016-03-04 11:15:30 --> Helper loaded: url_helper
INFO - 2016-03-04 11:15:30 --> Helper loaded: file_helper
INFO - 2016-03-04 11:15:30 --> Helper loaded: date_helper
INFO - 2016-03-04 11:15:30 --> Helper loaded: form_helper
INFO - 2016-03-04 11:15:30 --> Database Driver Class Initialized
INFO - 2016-03-04 11:15:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:15:31 --> Controller Class Initialized
INFO - 2016-03-04 11:15:31 --> Model Class Initialized
INFO - 2016-03-04 11:15:31 --> Model Class Initialized
INFO - 2016-03-04 11:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:15:31 --> Pagination Class Initialized
INFO - 2016-03-04 11:15:31 --> Helper loaded: text_helper
INFO - 2016-03-04 11:15:31 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:15:31 --> Final output sent to browser
DEBUG - 2016-03-04 14:15:31 --> Total execution time: 1.2115
INFO - 2016-03-04 11:15:33 --> Config Class Initialized
INFO - 2016-03-04 11:15:33 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:15:33 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:15:33 --> Utf8 Class Initialized
INFO - 2016-03-04 11:15:33 --> URI Class Initialized
INFO - 2016-03-04 11:15:33 --> Router Class Initialized
INFO - 2016-03-04 11:15:33 --> Output Class Initialized
INFO - 2016-03-04 11:15:33 --> Security Class Initialized
DEBUG - 2016-03-04 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:15:33 --> Input Class Initialized
INFO - 2016-03-04 11:15:33 --> Language Class Initialized
INFO - 2016-03-04 11:15:33 --> Loader Class Initialized
INFO - 2016-03-04 11:15:33 --> Helper loaded: url_helper
INFO - 2016-03-04 11:15:33 --> Helper loaded: file_helper
INFO - 2016-03-04 11:15:33 --> Helper loaded: date_helper
INFO - 2016-03-04 11:15:33 --> Helper loaded: form_helper
INFO - 2016-03-04 11:15:33 --> Database Driver Class Initialized
INFO - 2016-03-04 11:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:15:34 --> Controller Class Initialized
INFO - 2016-03-04 11:15:34 --> Model Class Initialized
INFO - 2016-03-04 11:15:34 --> Model Class Initialized
INFO - 2016-03-04 11:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:15:34 --> Pagination Class Initialized
INFO - 2016-03-04 11:15:34 --> Helper loaded: text_helper
INFO - 2016-03-04 11:15:34 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:15:34 --> Final output sent to browser
DEBUG - 2016-03-04 14:15:34 --> Total execution time: 1.1608
INFO - 2016-03-04 11:15:59 --> Config Class Initialized
INFO - 2016-03-04 11:15:59 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:15:59 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:15:59 --> Utf8 Class Initialized
INFO - 2016-03-04 11:15:59 --> URI Class Initialized
INFO - 2016-03-04 11:15:59 --> Router Class Initialized
INFO - 2016-03-04 11:15:59 --> Output Class Initialized
INFO - 2016-03-04 11:15:59 --> Security Class Initialized
DEBUG - 2016-03-04 11:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:15:59 --> Input Class Initialized
INFO - 2016-03-04 11:15:59 --> Language Class Initialized
INFO - 2016-03-04 11:15:59 --> Loader Class Initialized
INFO - 2016-03-04 11:15:59 --> Helper loaded: url_helper
INFO - 2016-03-04 11:15:59 --> Helper loaded: file_helper
INFO - 2016-03-04 11:15:59 --> Helper loaded: date_helper
INFO - 2016-03-04 11:15:59 --> Helper loaded: form_helper
INFO - 2016-03-04 11:15:59 --> Database Driver Class Initialized
INFO - 2016-03-04 11:16:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:16:00 --> Controller Class Initialized
INFO - 2016-03-04 11:16:00 --> Model Class Initialized
INFO - 2016-03-04 11:16:00 --> Model Class Initialized
INFO - 2016-03-04 11:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:16:00 --> Pagination Class Initialized
INFO - 2016-03-04 11:16:00 --> Helper loaded: text_helper
INFO - 2016-03-04 11:16:00 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:16:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:16:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:16:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:16:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:16:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:16:01 --> Final output sent to browser
DEBUG - 2016-03-04 14:16:01 --> Total execution time: 1.1745
INFO - 2016-03-04 11:16:02 --> Config Class Initialized
INFO - 2016-03-04 11:16:02 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:16:02 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:16:02 --> Utf8 Class Initialized
INFO - 2016-03-04 11:16:02 --> URI Class Initialized
INFO - 2016-03-04 11:16:02 --> Router Class Initialized
INFO - 2016-03-04 11:16:02 --> Output Class Initialized
INFO - 2016-03-04 11:16:02 --> Security Class Initialized
DEBUG - 2016-03-04 11:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:16:02 --> Input Class Initialized
INFO - 2016-03-04 11:16:02 --> Language Class Initialized
INFO - 2016-03-04 11:16:02 --> Loader Class Initialized
INFO - 2016-03-04 11:16:02 --> Helper loaded: url_helper
INFO - 2016-03-04 11:16:02 --> Helper loaded: file_helper
INFO - 2016-03-04 11:16:02 --> Helper loaded: date_helper
INFO - 2016-03-04 11:16:02 --> Helper loaded: form_helper
INFO - 2016-03-04 11:16:02 --> Database Driver Class Initialized
INFO - 2016-03-04 11:16:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:16:03 --> Controller Class Initialized
INFO - 2016-03-04 11:16:03 --> Model Class Initialized
INFO - 2016-03-04 11:16:03 --> Model Class Initialized
INFO - 2016-03-04 11:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:16:03 --> Pagination Class Initialized
INFO - 2016-03-04 11:16:03 --> Helper loaded: text_helper
INFO - 2016-03-04 11:16:03 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:16:03 --> Final output sent to browser
DEBUG - 2016-03-04 14:16:03 --> Total execution time: 1.1891
INFO - 2016-03-04 11:16:15 --> Config Class Initialized
INFO - 2016-03-04 11:16:15 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:16:15 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:16:15 --> Utf8 Class Initialized
INFO - 2016-03-04 11:16:15 --> URI Class Initialized
INFO - 2016-03-04 11:16:15 --> Router Class Initialized
INFO - 2016-03-04 11:16:15 --> Output Class Initialized
INFO - 2016-03-04 11:16:15 --> Security Class Initialized
DEBUG - 2016-03-04 11:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:16:15 --> Input Class Initialized
INFO - 2016-03-04 11:16:15 --> Language Class Initialized
INFO - 2016-03-04 11:16:15 --> Loader Class Initialized
INFO - 2016-03-04 11:16:15 --> Helper loaded: url_helper
INFO - 2016-03-04 11:16:15 --> Helper loaded: file_helper
INFO - 2016-03-04 11:16:15 --> Helper loaded: date_helper
INFO - 2016-03-04 11:16:15 --> Helper loaded: form_helper
INFO - 2016-03-04 11:16:15 --> Database Driver Class Initialized
INFO - 2016-03-04 11:16:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:16:16 --> Controller Class Initialized
INFO - 2016-03-04 11:16:16 --> Model Class Initialized
INFO - 2016-03-04 11:16:16 --> Model Class Initialized
INFO - 2016-03-04 11:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:16:16 --> Pagination Class Initialized
INFO - 2016-03-04 11:16:16 --> Helper loaded: text_helper
INFO - 2016-03-04 11:16:16 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:16:16 --> Final output sent to browser
DEBUG - 2016-03-04 14:16:16 --> Total execution time: 1.2378
INFO - 2016-03-04 11:16:18 --> Config Class Initialized
INFO - 2016-03-04 11:16:18 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:16:18 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:16:18 --> Utf8 Class Initialized
INFO - 2016-03-04 11:16:18 --> URI Class Initialized
INFO - 2016-03-04 11:16:18 --> Router Class Initialized
INFO - 2016-03-04 11:16:18 --> Output Class Initialized
INFO - 2016-03-04 11:16:19 --> Security Class Initialized
DEBUG - 2016-03-04 11:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:16:19 --> Input Class Initialized
INFO - 2016-03-04 11:16:19 --> Language Class Initialized
INFO - 2016-03-04 11:16:19 --> Loader Class Initialized
INFO - 2016-03-04 11:16:19 --> Helper loaded: url_helper
INFO - 2016-03-04 11:16:19 --> Helper loaded: file_helper
INFO - 2016-03-04 11:16:19 --> Helper loaded: date_helper
INFO - 2016-03-04 11:16:19 --> Helper loaded: form_helper
INFO - 2016-03-04 11:16:19 --> Database Driver Class Initialized
INFO - 2016-03-04 11:16:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:16:20 --> Controller Class Initialized
INFO - 2016-03-04 11:16:20 --> Model Class Initialized
INFO - 2016-03-04 11:16:20 --> Model Class Initialized
INFO - 2016-03-04 11:16:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:16:20 --> Pagination Class Initialized
INFO - 2016-03-04 11:16:20 --> Helper loaded: text_helper
INFO - 2016-03-04 11:16:20 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 14:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 14:16:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:16:20 --> Final output sent to browser
DEBUG - 2016-03-04 14:16:20 --> Total execution time: 1.1625
INFO - 2016-03-04 11:16:54 --> Config Class Initialized
INFO - 2016-03-04 11:16:54 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:16:54 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:16:54 --> Utf8 Class Initialized
INFO - 2016-03-04 11:16:54 --> URI Class Initialized
DEBUG - 2016-03-04 11:16:54 --> No URI present. Default controller set.
INFO - 2016-03-04 11:16:54 --> Router Class Initialized
INFO - 2016-03-04 11:16:54 --> Output Class Initialized
INFO - 2016-03-04 11:16:54 --> Security Class Initialized
DEBUG - 2016-03-04 11:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:16:54 --> Input Class Initialized
INFO - 2016-03-04 11:16:54 --> Language Class Initialized
INFO - 2016-03-04 11:16:54 --> Loader Class Initialized
INFO - 2016-03-04 11:16:54 --> Helper loaded: url_helper
INFO - 2016-03-04 11:16:54 --> Helper loaded: file_helper
INFO - 2016-03-04 11:16:54 --> Helper loaded: date_helper
INFO - 2016-03-04 11:16:54 --> Helper loaded: form_helper
INFO - 2016-03-04 11:16:54 --> Database Driver Class Initialized
INFO - 2016-03-04 11:16:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:16:55 --> Controller Class Initialized
INFO - 2016-03-04 11:16:55 --> Model Class Initialized
INFO - 2016-03-04 11:16:55 --> Model Class Initialized
INFO - 2016-03-04 11:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:16:55 --> Pagination Class Initialized
INFO - 2016-03-04 11:16:55 --> Helper loaded: text_helper
INFO - 2016-03-04 11:16:55 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:16:55 --> Final output sent to browser
DEBUG - 2016-03-04 14:16:55 --> Total execution time: 1.1772
INFO - 2016-03-04 11:20:19 --> Config Class Initialized
INFO - 2016-03-04 11:20:19 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:20:19 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:20:19 --> Utf8 Class Initialized
INFO - 2016-03-04 11:20:19 --> URI Class Initialized
INFO - 2016-03-04 11:20:19 --> Router Class Initialized
INFO - 2016-03-04 11:20:19 --> Output Class Initialized
INFO - 2016-03-04 11:20:19 --> Security Class Initialized
DEBUG - 2016-03-04 11:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:20:19 --> Input Class Initialized
INFO - 2016-03-04 11:20:19 --> Language Class Initialized
INFO - 2016-03-04 11:20:19 --> Loader Class Initialized
INFO - 2016-03-04 11:20:19 --> Helper loaded: url_helper
INFO - 2016-03-04 11:20:19 --> Helper loaded: file_helper
INFO - 2016-03-04 11:20:19 --> Helper loaded: date_helper
INFO - 2016-03-04 11:20:19 --> Helper loaded: form_helper
INFO - 2016-03-04 11:20:19 --> Database Driver Class Initialized
INFO - 2016-03-04 11:20:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:20:20 --> Controller Class Initialized
INFO - 2016-03-04 11:20:20 --> Model Class Initialized
INFO - 2016-03-04 11:20:20 --> Model Class Initialized
INFO - 2016-03-04 11:20:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:20:20 --> Pagination Class Initialized
INFO - 2016-03-04 11:20:20 --> Helper loaded: text_helper
INFO - 2016-03-04 11:20:20 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:20:20 --> Form Validation Class Initialized
INFO - 2016-03-04 14:20:20 --> Email Class Initialized
INFO - 2016-03-04 14:20:20 --> Final output sent to browser
DEBUG - 2016-03-04 14:20:20 --> Total execution time: 1.1379
INFO - 2016-03-04 11:21:38 --> Config Class Initialized
INFO - 2016-03-04 11:21:38 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:21:38 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:21:38 --> Utf8 Class Initialized
INFO - 2016-03-04 11:21:38 --> URI Class Initialized
INFO - 2016-03-04 11:21:38 --> Router Class Initialized
INFO - 2016-03-04 11:21:38 --> Output Class Initialized
INFO - 2016-03-04 11:21:38 --> Security Class Initialized
DEBUG - 2016-03-04 11:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:21:38 --> Input Class Initialized
INFO - 2016-03-04 11:21:38 --> Language Class Initialized
INFO - 2016-03-04 11:21:38 --> Loader Class Initialized
INFO - 2016-03-04 11:21:38 --> Helper loaded: url_helper
INFO - 2016-03-04 11:21:38 --> Helper loaded: file_helper
INFO - 2016-03-04 11:21:38 --> Helper loaded: date_helper
INFO - 2016-03-04 11:21:38 --> Helper loaded: form_helper
INFO - 2016-03-04 11:21:38 --> Database Driver Class Initialized
INFO - 2016-03-04 11:21:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:21:39 --> Controller Class Initialized
INFO - 2016-03-04 11:21:39 --> Model Class Initialized
INFO - 2016-03-04 11:21:39 --> Model Class Initialized
INFO - 2016-03-04 11:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:21:39 --> Pagination Class Initialized
INFO - 2016-03-04 11:21:39 --> Helper loaded: text_helper
INFO - 2016-03-04 11:21:39 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:21:39 --> Form Validation Class Initialized
INFO - 2016-03-04 14:21:39 --> Email Class Initialized
INFO - 2016-03-04 14:21:39 --> Final output sent to browser
DEBUG - 2016-03-04 14:21:39 --> Total execution time: 1.1141
INFO - 2016-03-04 11:21:50 --> Config Class Initialized
INFO - 2016-03-04 11:21:50 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:21:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:21:50 --> Utf8 Class Initialized
INFO - 2016-03-04 11:21:50 --> URI Class Initialized
DEBUG - 2016-03-04 11:21:50 --> No URI present. Default controller set.
INFO - 2016-03-04 11:21:50 --> Router Class Initialized
INFO - 2016-03-04 11:21:50 --> Output Class Initialized
INFO - 2016-03-04 11:21:50 --> Security Class Initialized
DEBUG - 2016-03-04 11:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:21:50 --> Input Class Initialized
INFO - 2016-03-04 11:21:50 --> Language Class Initialized
INFO - 2016-03-04 11:21:50 --> Loader Class Initialized
INFO - 2016-03-04 11:21:50 --> Helper loaded: url_helper
INFO - 2016-03-04 11:21:50 --> Helper loaded: file_helper
INFO - 2016-03-04 11:21:50 --> Helper loaded: date_helper
INFO - 2016-03-04 11:21:50 --> Helper loaded: form_helper
INFO - 2016-03-04 11:21:50 --> Database Driver Class Initialized
INFO - 2016-03-04 11:21:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:21:51 --> Controller Class Initialized
INFO - 2016-03-04 11:21:51 --> Model Class Initialized
INFO - 2016-03-04 11:21:51 --> Model Class Initialized
INFO - 2016-03-04 11:21:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:21:51 --> Pagination Class Initialized
INFO - 2016-03-04 11:21:51 --> Helper loaded: text_helper
INFO - 2016-03-04 11:21:51 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:21:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:21:51 --> Final output sent to browser
DEBUG - 2016-03-04 14:21:51 --> Total execution time: 1.1193
INFO - 2016-03-04 11:22:15 --> Config Class Initialized
INFO - 2016-03-04 11:22:15 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:22:15 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:22:15 --> Utf8 Class Initialized
INFO - 2016-03-04 11:22:15 --> URI Class Initialized
INFO - 2016-03-04 11:22:15 --> Router Class Initialized
INFO - 2016-03-04 11:22:15 --> Output Class Initialized
INFO - 2016-03-04 11:22:15 --> Security Class Initialized
DEBUG - 2016-03-04 11:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:22:15 --> Input Class Initialized
INFO - 2016-03-04 11:22:15 --> Language Class Initialized
INFO - 2016-03-04 11:22:15 --> Loader Class Initialized
INFO - 2016-03-04 11:22:15 --> Helper loaded: url_helper
INFO - 2016-03-04 11:22:15 --> Helper loaded: file_helper
INFO - 2016-03-04 11:22:15 --> Helper loaded: date_helper
INFO - 2016-03-04 11:22:15 --> Helper loaded: form_helper
INFO - 2016-03-04 11:22:15 --> Database Driver Class Initialized
INFO - 2016-03-04 11:22:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:22:16 --> Controller Class Initialized
INFO - 2016-03-04 11:22:16 --> Model Class Initialized
INFO - 2016-03-04 11:22:16 --> Model Class Initialized
INFO - 2016-03-04 11:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:22:16 --> Pagination Class Initialized
INFO - 2016-03-04 11:22:16 --> Helper loaded: text_helper
INFO - 2016-03-04 11:22:16 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:22:16 --> Form Validation Class Initialized
INFO - 2016-03-04 14:22:16 --> Email Class Initialized
INFO - 2016-03-04 14:22:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 14:22:16 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 14:22:18 --> Final output sent to browser
DEBUG - 2016-03-04 14:22:18 --> Total execution time: 3.3876
INFO - 2016-03-04 11:23:40 --> Config Class Initialized
INFO - 2016-03-04 11:23:40 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:23:40 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:23:40 --> Utf8 Class Initialized
INFO - 2016-03-04 11:23:40 --> URI Class Initialized
DEBUG - 2016-03-04 11:23:40 --> No URI present. Default controller set.
INFO - 2016-03-04 11:23:40 --> Router Class Initialized
INFO - 2016-03-04 11:23:40 --> Output Class Initialized
INFO - 2016-03-04 11:23:40 --> Security Class Initialized
DEBUG - 2016-03-04 11:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:23:40 --> Input Class Initialized
INFO - 2016-03-04 11:23:40 --> Language Class Initialized
INFO - 2016-03-04 11:23:40 --> Loader Class Initialized
INFO - 2016-03-04 11:23:40 --> Helper loaded: url_helper
INFO - 2016-03-04 11:23:40 --> Helper loaded: file_helper
INFO - 2016-03-04 11:23:40 --> Helper loaded: date_helper
INFO - 2016-03-04 11:23:40 --> Helper loaded: form_helper
INFO - 2016-03-04 11:23:40 --> Database Driver Class Initialized
INFO - 2016-03-04 11:23:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:23:41 --> Controller Class Initialized
INFO - 2016-03-04 11:23:41 --> Model Class Initialized
INFO - 2016-03-04 11:23:41 --> Model Class Initialized
INFO - 2016-03-04 11:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:23:41 --> Pagination Class Initialized
INFO - 2016-03-04 11:23:41 --> Helper loaded: text_helper
INFO - 2016-03-04 11:23:41 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:23:41 --> Final output sent to browser
DEBUG - 2016-03-04 14:23:41 --> Total execution time: 1.1501
INFO - 2016-03-04 11:27:48 --> Config Class Initialized
INFO - 2016-03-04 11:27:48 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:27:48 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:27:48 --> Utf8 Class Initialized
INFO - 2016-03-04 11:27:48 --> URI Class Initialized
DEBUG - 2016-03-04 11:27:48 --> No URI present. Default controller set.
INFO - 2016-03-04 11:27:48 --> Router Class Initialized
INFO - 2016-03-04 11:27:48 --> Output Class Initialized
INFO - 2016-03-04 11:27:48 --> Security Class Initialized
DEBUG - 2016-03-04 11:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:27:48 --> Input Class Initialized
INFO - 2016-03-04 11:27:48 --> Language Class Initialized
INFO - 2016-03-04 11:27:48 --> Loader Class Initialized
INFO - 2016-03-04 11:27:48 --> Helper loaded: url_helper
INFO - 2016-03-04 11:27:48 --> Helper loaded: file_helper
INFO - 2016-03-04 11:27:48 --> Helper loaded: date_helper
INFO - 2016-03-04 11:27:48 --> Helper loaded: form_helper
INFO - 2016-03-04 11:27:48 --> Database Driver Class Initialized
INFO - 2016-03-04 11:27:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:27:49 --> Controller Class Initialized
INFO - 2016-03-04 11:27:49 --> Model Class Initialized
INFO - 2016-03-04 11:27:49 --> Model Class Initialized
INFO - 2016-03-04 11:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:27:49 --> Pagination Class Initialized
INFO - 2016-03-04 11:27:49 --> Helper loaded: text_helper
INFO - 2016-03-04 11:27:49 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:27:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:27:49 --> Final output sent to browser
DEBUG - 2016-03-04 14:27:49 --> Total execution time: 1.1505
INFO - 2016-03-04 11:28:12 --> Config Class Initialized
INFO - 2016-03-04 11:28:12 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:28:12 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:28:12 --> Utf8 Class Initialized
INFO - 2016-03-04 11:28:12 --> URI Class Initialized
DEBUG - 2016-03-04 11:28:12 --> No URI present. Default controller set.
INFO - 2016-03-04 11:28:12 --> Router Class Initialized
INFO - 2016-03-04 11:28:12 --> Output Class Initialized
INFO - 2016-03-04 11:28:12 --> Security Class Initialized
DEBUG - 2016-03-04 11:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:28:12 --> Input Class Initialized
INFO - 2016-03-04 11:28:12 --> Language Class Initialized
INFO - 2016-03-04 11:28:12 --> Loader Class Initialized
INFO - 2016-03-04 11:28:12 --> Helper loaded: url_helper
INFO - 2016-03-04 11:28:12 --> Helper loaded: file_helper
INFO - 2016-03-04 11:28:12 --> Helper loaded: date_helper
INFO - 2016-03-04 11:28:12 --> Helper loaded: form_helper
INFO - 2016-03-04 11:28:12 --> Database Driver Class Initialized
INFO - 2016-03-04 11:28:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:28:13 --> Controller Class Initialized
INFO - 2016-03-04 11:28:13 --> Model Class Initialized
INFO - 2016-03-04 11:28:13 --> Model Class Initialized
INFO - 2016-03-04 11:28:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:28:13 --> Pagination Class Initialized
INFO - 2016-03-04 11:28:13 --> Helper loaded: text_helper
INFO - 2016-03-04 11:28:13 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:28:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:28:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:28:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:28:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:28:13 --> Final output sent to browser
DEBUG - 2016-03-04 14:28:13 --> Total execution time: 1.1276
INFO - 2016-03-04 11:28:28 --> Config Class Initialized
INFO - 2016-03-04 11:28:28 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:28:28 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:28:28 --> Utf8 Class Initialized
INFO - 2016-03-04 11:28:28 --> URI Class Initialized
DEBUG - 2016-03-04 11:28:28 --> No URI present. Default controller set.
INFO - 2016-03-04 11:28:28 --> Router Class Initialized
INFO - 2016-03-04 11:28:28 --> Output Class Initialized
INFO - 2016-03-04 11:28:28 --> Security Class Initialized
DEBUG - 2016-03-04 11:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:28:28 --> Input Class Initialized
INFO - 2016-03-04 11:28:28 --> Language Class Initialized
INFO - 2016-03-04 11:28:28 --> Loader Class Initialized
INFO - 2016-03-04 11:28:28 --> Helper loaded: url_helper
INFO - 2016-03-04 11:28:28 --> Helper loaded: file_helper
INFO - 2016-03-04 11:28:28 --> Helper loaded: date_helper
INFO - 2016-03-04 11:28:28 --> Helper loaded: form_helper
INFO - 2016-03-04 11:28:28 --> Database Driver Class Initialized
INFO - 2016-03-04 11:28:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:28:29 --> Controller Class Initialized
INFO - 2016-03-04 11:28:29 --> Model Class Initialized
INFO - 2016-03-04 11:28:29 --> Model Class Initialized
INFO - 2016-03-04 11:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:28:29 --> Pagination Class Initialized
INFO - 2016-03-04 11:28:29 --> Helper loaded: text_helper
INFO - 2016-03-04 11:28:29 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:28:29 --> Final output sent to browser
DEBUG - 2016-03-04 14:28:29 --> Total execution time: 1.1022
INFO - 2016-03-04 11:29:45 --> Config Class Initialized
INFO - 2016-03-04 11:29:45 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:29:45 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:29:45 --> Utf8 Class Initialized
INFO - 2016-03-04 11:29:45 --> URI Class Initialized
DEBUG - 2016-03-04 11:29:45 --> No URI present. Default controller set.
INFO - 2016-03-04 11:29:45 --> Router Class Initialized
INFO - 2016-03-04 11:29:45 --> Output Class Initialized
INFO - 2016-03-04 11:29:45 --> Security Class Initialized
DEBUG - 2016-03-04 11:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:29:45 --> Input Class Initialized
INFO - 2016-03-04 11:29:45 --> Language Class Initialized
INFO - 2016-03-04 11:29:45 --> Loader Class Initialized
INFO - 2016-03-04 11:29:45 --> Helper loaded: url_helper
INFO - 2016-03-04 11:29:45 --> Helper loaded: file_helper
INFO - 2016-03-04 11:29:45 --> Helper loaded: date_helper
INFO - 2016-03-04 11:29:45 --> Helper loaded: form_helper
INFO - 2016-03-04 11:29:45 --> Database Driver Class Initialized
INFO - 2016-03-04 11:29:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:29:46 --> Controller Class Initialized
INFO - 2016-03-04 11:29:46 --> Model Class Initialized
INFO - 2016-03-04 11:29:46 --> Model Class Initialized
INFO - 2016-03-04 11:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:29:46 --> Pagination Class Initialized
INFO - 2016-03-04 11:29:46 --> Helper loaded: text_helper
INFO - 2016-03-04 11:29:46 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:29:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:29:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:29:47 --> Final output sent to browser
DEBUG - 2016-03-04 14:29:47 --> Total execution time: 1.1448
INFO - 2016-03-04 11:30:15 --> Config Class Initialized
INFO - 2016-03-04 11:30:15 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:30:15 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:30:15 --> Utf8 Class Initialized
INFO - 2016-03-04 11:30:15 --> URI Class Initialized
DEBUG - 2016-03-04 11:30:15 --> No URI present. Default controller set.
INFO - 2016-03-04 11:30:15 --> Router Class Initialized
INFO - 2016-03-04 11:30:15 --> Output Class Initialized
INFO - 2016-03-04 11:30:15 --> Security Class Initialized
DEBUG - 2016-03-04 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:30:15 --> Input Class Initialized
INFO - 2016-03-04 11:30:15 --> Language Class Initialized
INFO - 2016-03-04 11:30:15 --> Loader Class Initialized
INFO - 2016-03-04 11:30:15 --> Helper loaded: url_helper
INFO - 2016-03-04 11:30:15 --> Helper loaded: file_helper
INFO - 2016-03-04 11:30:15 --> Helper loaded: date_helper
INFO - 2016-03-04 11:30:15 --> Helper loaded: form_helper
INFO - 2016-03-04 11:30:15 --> Database Driver Class Initialized
INFO - 2016-03-04 11:30:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:30:16 --> Controller Class Initialized
INFO - 2016-03-04 11:30:16 --> Model Class Initialized
INFO - 2016-03-04 11:30:16 --> Model Class Initialized
INFO - 2016-03-04 11:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:30:16 --> Pagination Class Initialized
INFO - 2016-03-04 11:30:16 --> Helper loaded: text_helper
INFO - 2016-03-04 11:30:16 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:30:16 --> Final output sent to browser
DEBUG - 2016-03-04 14:30:16 --> Total execution time: 1.1129
INFO - 2016-03-04 11:30:47 --> Config Class Initialized
INFO - 2016-03-04 11:30:47 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:30:47 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:30:47 --> Utf8 Class Initialized
INFO - 2016-03-04 11:30:47 --> URI Class Initialized
DEBUG - 2016-03-04 11:30:48 --> No URI present. Default controller set.
INFO - 2016-03-04 11:30:48 --> Router Class Initialized
INFO - 2016-03-04 11:30:48 --> Output Class Initialized
INFO - 2016-03-04 11:30:48 --> Security Class Initialized
DEBUG - 2016-03-04 11:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:30:48 --> Input Class Initialized
INFO - 2016-03-04 11:30:48 --> Language Class Initialized
INFO - 2016-03-04 11:30:48 --> Loader Class Initialized
INFO - 2016-03-04 11:30:48 --> Helper loaded: url_helper
INFO - 2016-03-04 11:30:48 --> Helper loaded: file_helper
INFO - 2016-03-04 11:30:48 --> Helper loaded: date_helper
INFO - 2016-03-04 11:30:48 --> Helper loaded: form_helper
INFO - 2016-03-04 11:30:48 --> Database Driver Class Initialized
INFO - 2016-03-04 11:30:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:30:49 --> Controller Class Initialized
INFO - 2016-03-04 11:30:49 --> Model Class Initialized
INFO - 2016-03-04 11:30:49 --> Model Class Initialized
INFO - 2016-03-04 11:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:30:49 --> Pagination Class Initialized
INFO - 2016-03-04 11:30:49 --> Helper loaded: text_helper
INFO - 2016-03-04 11:30:49 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:30:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:30:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:30:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:30:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:30:49 --> Final output sent to browser
DEBUG - 2016-03-04 14:30:49 --> Total execution time: 1.1532
INFO - 2016-03-04 11:32:52 --> Config Class Initialized
INFO - 2016-03-04 11:32:52 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:32:52 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:32:52 --> Utf8 Class Initialized
INFO - 2016-03-04 11:32:52 --> URI Class Initialized
DEBUG - 2016-03-04 11:32:52 --> No URI present. Default controller set.
INFO - 2016-03-04 11:32:52 --> Router Class Initialized
INFO - 2016-03-04 11:32:52 --> Output Class Initialized
INFO - 2016-03-04 11:32:52 --> Security Class Initialized
DEBUG - 2016-03-04 11:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:32:52 --> Input Class Initialized
INFO - 2016-03-04 11:32:52 --> Language Class Initialized
INFO - 2016-03-04 11:32:52 --> Loader Class Initialized
INFO - 2016-03-04 11:32:52 --> Helper loaded: url_helper
INFO - 2016-03-04 11:32:52 --> Helper loaded: file_helper
INFO - 2016-03-04 11:32:52 --> Helper loaded: date_helper
INFO - 2016-03-04 11:32:52 --> Helper loaded: form_helper
INFO - 2016-03-04 11:32:52 --> Database Driver Class Initialized
INFO - 2016-03-04 11:32:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:32:53 --> Controller Class Initialized
INFO - 2016-03-04 11:32:53 --> Model Class Initialized
INFO - 2016-03-04 11:32:53 --> Model Class Initialized
INFO - 2016-03-04 11:32:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:32:53 --> Pagination Class Initialized
INFO - 2016-03-04 11:32:53 --> Helper loaded: text_helper
INFO - 2016-03-04 11:32:53 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:32:53 --> Final output sent to browser
DEBUG - 2016-03-04 14:32:53 --> Total execution time: 1.1999
INFO - 2016-03-04 11:33:20 --> Config Class Initialized
INFO - 2016-03-04 11:33:20 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:33:20 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:33:20 --> Utf8 Class Initialized
INFO - 2016-03-04 11:33:20 --> URI Class Initialized
DEBUG - 2016-03-04 11:33:20 --> No URI present. Default controller set.
INFO - 2016-03-04 11:33:20 --> Router Class Initialized
INFO - 2016-03-04 11:33:20 --> Output Class Initialized
INFO - 2016-03-04 11:33:21 --> Security Class Initialized
DEBUG - 2016-03-04 11:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:33:21 --> Input Class Initialized
INFO - 2016-03-04 11:33:21 --> Language Class Initialized
INFO - 2016-03-04 11:33:21 --> Loader Class Initialized
INFO - 2016-03-04 11:33:21 --> Helper loaded: url_helper
INFO - 2016-03-04 11:33:21 --> Helper loaded: file_helper
INFO - 2016-03-04 11:33:21 --> Helper loaded: date_helper
INFO - 2016-03-04 11:33:21 --> Helper loaded: form_helper
INFO - 2016-03-04 11:33:21 --> Database Driver Class Initialized
INFO - 2016-03-04 11:33:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:33:22 --> Controller Class Initialized
INFO - 2016-03-04 11:33:22 --> Model Class Initialized
INFO - 2016-03-04 11:33:22 --> Model Class Initialized
INFO - 2016-03-04 11:33:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:33:22 --> Pagination Class Initialized
INFO - 2016-03-04 11:33:22 --> Helper loaded: text_helper
INFO - 2016-03-04 11:33:22 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:33:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:33:22 --> Final output sent to browser
DEBUG - 2016-03-04 14:33:22 --> Total execution time: 1.1546
INFO - 2016-03-04 11:35:01 --> Config Class Initialized
INFO - 2016-03-04 11:35:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:35:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:35:01 --> Utf8 Class Initialized
INFO - 2016-03-04 11:35:01 --> URI Class Initialized
DEBUG - 2016-03-04 11:35:01 --> No URI present. Default controller set.
INFO - 2016-03-04 11:35:01 --> Router Class Initialized
INFO - 2016-03-04 11:35:01 --> Output Class Initialized
INFO - 2016-03-04 11:35:01 --> Security Class Initialized
DEBUG - 2016-03-04 11:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:35:01 --> Input Class Initialized
INFO - 2016-03-04 11:35:01 --> Language Class Initialized
INFO - 2016-03-04 11:35:01 --> Loader Class Initialized
INFO - 2016-03-04 11:35:01 --> Helper loaded: url_helper
INFO - 2016-03-04 11:35:01 --> Helper loaded: file_helper
INFO - 2016-03-04 11:35:01 --> Helper loaded: date_helper
INFO - 2016-03-04 11:35:01 --> Helper loaded: form_helper
INFO - 2016-03-04 11:35:01 --> Database Driver Class Initialized
INFO - 2016-03-04 11:35:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:35:02 --> Controller Class Initialized
INFO - 2016-03-04 11:35:02 --> Model Class Initialized
INFO - 2016-03-04 11:35:02 --> Model Class Initialized
INFO - 2016-03-04 11:35:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:35:02 --> Pagination Class Initialized
INFO - 2016-03-04 11:35:02 --> Helper loaded: text_helper
INFO - 2016-03-04 11:35:02 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:35:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:35:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:35:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:35:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:35:02 --> Final output sent to browser
DEBUG - 2016-03-04 14:35:02 --> Total execution time: 1.1355
INFO - 2016-03-04 11:35:29 --> Config Class Initialized
INFO - 2016-03-04 11:35:29 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:35:29 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:35:29 --> Utf8 Class Initialized
INFO - 2016-03-04 11:35:29 --> URI Class Initialized
DEBUG - 2016-03-04 11:35:29 --> No URI present. Default controller set.
INFO - 2016-03-04 11:35:29 --> Router Class Initialized
INFO - 2016-03-04 11:35:29 --> Output Class Initialized
INFO - 2016-03-04 11:35:29 --> Security Class Initialized
DEBUG - 2016-03-04 11:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:35:29 --> Input Class Initialized
INFO - 2016-03-04 11:35:29 --> Language Class Initialized
INFO - 2016-03-04 11:35:29 --> Loader Class Initialized
INFO - 2016-03-04 11:35:29 --> Helper loaded: url_helper
INFO - 2016-03-04 11:35:29 --> Helper loaded: file_helper
INFO - 2016-03-04 11:35:29 --> Helper loaded: date_helper
INFO - 2016-03-04 11:35:29 --> Helper loaded: form_helper
INFO - 2016-03-04 11:35:29 --> Database Driver Class Initialized
INFO - 2016-03-04 11:35:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:35:30 --> Controller Class Initialized
INFO - 2016-03-04 11:35:30 --> Model Class Initialized
INFO - 2016-03-04 11:35:30 --> Model Class Initialized
INFO - 2016-03-04 11:35:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:35:30 --> Pagination Class Initialized
INFO - 2016-03-04 11:35:30 --> Helper loaded: text_helper
INFO - 2016-03-04 11:35:30 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:35:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:35:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:35:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:35:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:35:30 --> Final output sent to browser
DEBUG - 2016-03-04 14:35:30 --> Total execution time: 1.1123
INFO - 2016-03-04 11:36:39 --> Config Class Initialized
INFO - 2016-03-04 11:36:39 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:36:39 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:36:39 --> Utf8 Class Initialized
INFO - 2016-03-04 11:36:39 --> URI Class Initialized
DEBUG - 2016-03-04 11:36:39 --> No URI present. Default controller set.
INFO - 2016-03-04 11:36:39 --> Router Class Initialized
INFO - 2016-03-04 11:36:39 --> Output Class Initialized
INFO - 2016-03-04 11:36:39 --> Security Class Initialized
DEBUG - 2016-03-04 11:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:36:39 --> Input Class Initialized
INFO - 2016-03-04 11:36:39 --> Language Class Initialized
INFO - 2016-03-04 11:36:39 --> Loader Class Initialized
INFO - 2016-03-04 11:36:39 --> Helper loaded: url_helper
INFO - 2016-03-04 11:36:39 --> Helper loaded: file_helper
INFO - 2016-03-04 11:36:39 --> Helper loaded: date_helper
INFO - 2016-03-04 11:36:39 --> Helper loaded: form_helper
INFO - 2016-03-04 11:36:39 --> Database Driver Class Initialized
INFO - 2016-03-04 11:36:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:36:40 --> Controller Class Initialized
INFO - 2016-03-04 11:36:40 --> Model Class Initialized
INFO - 2016-03-04 11:36:40 --> Model Class Initialized
INFO - 2016-03-04 11:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:36:40 --> Pagination Class Initialized
INFO - 2016-03-04 11:36:40 --> Helper loaded: text_helper
INFO - 2016-03-04 11:36:40 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:36:40 --> Final output sent to browser
DEBUG - 2016-03-04 14:36:40 --> Total execution time: 1.1600
INFO - 2016-03-04 11:36:47 --> Config Class Initialized
INFO - 2016-03-04 11:36:47 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:36:47 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:36:47 --> Utf8 Class Initialized
INFO - 2016-03-04 11:36:47 --> URI Class Initialized
DEBUG - 2016-03-04 11:36:47 --> No URI present. Default controller set.
INFO - 2016-03-04 11:36:47 --> Router Class Initialized
INFO - 2016-03-04 11:36:47 --> Output Class Initialized
INFO - 2016-03-04 11:36:47 --> Security Class Initialized
DEBUG - 2016-03-04 11:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:36:48 --> Input Class Initialized
INFO - 2016-03-04 11:36:48 --> Language Class Initialized
INFO - 2016-03-04 11:36:48 --> Loader Class Initialized
INFO - 2016-03-04 11:36:48 --> Helper loaded: url_helper
INFO - 2016-03-04 11:36:48 --> Helper loaded: file_helper
INFO - 2016-03-04 11:36:48 --> Helper loaded: date_helper
INFO - 2016-03-04 11:36:48 --> Helper loaded: form_helper
INFO - 2016-03-04 11:36:48 --> Database Driver Class Initialized
INFO - 2016-03-04 11:36:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:36:49 --> Controller Class Initialized
INFO - 2016-03-04 11:36:49 --> Model Class Initialized
INFO - 2016-03-04 11:36:49 --> Model Class Initialized
INFO - 2016-03-04 11:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:36:49 --> Pagination Class Initialized
INFO - 2016-03-04 11:36:49 --> Helper loaded: text_helper
INFO - 2016-03-04 11:36:49 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:36:49 --> Final output sent to browser
DEBUG - 2016-03-04 14:36:49 --> Total execution time: 1.1307
INFO - 2016-03-04 11:37:05 --> Config Class Initialized
INFO - 2016-03-04 11:37:05 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:37:05 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:37:05 --> Utf8 Class Initialized
INFO - 2016-03-04 11:37:05 --> URI Class Initialized
INFO - 2016-03-04 11:37:05 --> Router Class Initialized
INFO - 2016-03-04 11:37:05 --> Output Class Initialized
INFO - 2016-03-04 11:37:05 --> Security Class Initialized
DEBUG - 2016-03-04 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:37:05 --> Input Class Initialized
INFO - 2016-03-04 11:37:05 --> Language Class Initialized
INFO - 2016-03-04 11:37:05 --> Loader Class Initialized
INFO - 2016-03-04 11:37:05 --> Helper loaded: url_helper
INFO - 2016-03-04 11:37:05 --> Helper loaded: file_helper
INFO - 2016-03-04 11:37:05 --> Helper loaded: date_helper
INFO - 2016-03-04 11:37:05 --> Helper loaded: form_helper
INFO - 2016-03-04 11:37:05 --> Database Driver Class Initialized
INFO - 2016-03-04 11:37:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:37:06 --> Controller Class Initialized
INFO - 2016-03-04 11:37:06 --> Model Class Initialized
INFO - 2016-03-04 11:37:06 --> Model Class Initialized
INFO - 2016-03-04 11:37:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:37:06 --> Pagination Class Initialized
INFO - 2016-03-04 11:37:06 --> Helper loaded: text_helper
INFO - 2016-03-04 11:37:06 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:37:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:37:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:37:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:37:06 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:37:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:37:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:37:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:37:06 --> Final output sent to browser
DEBUG - 2016-03-04 14:37:06 --> Total execution time: 1.1108
INFO - 2016-03-04 11:37:31 --> Config Class Initialized
INFO - 2016-03-04 11:37:31 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:37:31 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:37:31 --> Utf8 Class Initialized
INFO - 2016-03-04 11:37:31 --> URI Class Initialized
INFO - 2016-03-04 11:37:31 --> Router Class Initialized
INFO - 2016-03-04 11:37:31 --> Output Class Initialized
INFO - 2016-03-04 11:37:31 --> Security Class Initialized
DEBUG - 2016-03-04 11:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:37:31 --> Input Class Initialized
INFO - 2016-03-04 11:37:31 --> Language Class Initialized
INFO - 2016-03-04 11:37:31 --> Loader Class Initialized
INFO - 2016-03-04 11:37:31 --> Helper loaded: url_helper
INFO - 2016-03-04 11:37:31 --> Helper loaded: file_helper
INFO - 2016-03-04 11:37:31 --> Helper loaded: date_helper
INFO - 2016-03-04 11:37:31 --> Helper loaded: form_helper
INFO - 2016-03-04 11:37:31 --> Database Driver Class Initialized
INFO - 2016-03-04 11:37:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:37:32 --> Controller Class Initialized
INFO - 2016-03-04 11:37:32 --> Model Class Initialized
INFO - 2016-03-04 11:37:32 --> Model Class Initialized
INFO - 2016-03-04 11:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:37:32 --> Pagination Class Initialized
INFO - 2016-03-04 11:37:32 --> Helper loaded: text_helper
INFO - 2016-03-04 11:37:32 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:37:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:37:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:37:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 14:37:32 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 14:37:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 14:37:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 14:37:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:37:32 --> Final output sent to browser
DEBUG - 2016-03-04 14:37:32 --> Total execution time: 1.1402
INFO - 2016-03-04 11:37:34 --> Config Class Initialized
INFO - 2016-03-04 11:37:34 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:37:34 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:37:34 --> Utf8 Class Initialized
INFO - 2016-03-04 11:37:34 --> URI Class Initialized
DEBUG - 2016-03-04 11:37:34 --> No URI present. Default controller set.
INFO - 2016-03-04 11:37:34 --> Router Class Initialized
INFO - 2016-03-04 11:37:34 --> Output Class Initialized
INFO - 2016-03-04 11:37:34 --> Security Class Initialized
DEBUG - 2016-03-04 11:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:37:34 --> Input Class Initialized
INFO - 2016-03-04 11:37:34 --> Language Class Initialized
INFO - 2016-03-04 11:37:34 --> Loader Class Initialized
INFO - 2016-03-04 11:37:34 --> Helper loaded: url_helper
INFO - 2016-03-04 11:37:34 --> Helper loaded: file_helper
INFO - 2016-03-04 11:37:34 --> Helper loaded: date_helper
INFO - 2016-03-04 11:37:34 --> Helper loaded: form_helper
INFO - 2016-03-04 11:37:34 --> Database Driver Class Initialized
INFO - 2016-03-04 11:37:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:37:35 --> Controller Class Initialized
INFO - 2016-03-04 11:37:35 --> Model Class Initialized
INFO - 2016-03-04 11:37:35 --> Model Class Initialized
INFO - 2016-03-04 11:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:37:35 --> Pagination Class Initialized
INFO - 2016-03-04 11:37:35 --> Helper loaded: text_helper
INFO - 2016-03-04 11:37:35 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:37:35 --> Final output sent to browser
DEBUG - 2016-03-04 14:37:35 --> Total execution time: 1.1785
INFO - 2016-03-04 11:39:12 --> Config Class Initialized
INFO - 2016-03-04 11:39:12 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:39:12 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:39:12 --> Utf8 Class Initialized
INFO - 2016-03-04 11:39:12 --> URI Class Initialized
DEBUG - 2016-03-04 11:39:12 --> No URI present. Default controller set.
INFO - 2016-03-04 11:39:12 --> Router Class Initialized
INFO - 2016-03-04 11:39:12 --> Output Class Initialized
INFO - 2016-03-04 11:39:12 --> Security Class Initialized
DEBUG - 2016-03-04 11:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:39:12 --> Input Class Initialized
INFO - 2016-03-04 11:39:12 --> Language Class Initialized
INFO - 2016-03-04 11:39:12 --> Loader Class Initialized
INFO - 2016-03-04 11:39:12 --> Helper loaded: url_helper
INFO - 2016-03-04 11:39:12 --> Helper loaded: file_helper
INFO - 2016-03-04 11:39:12 --> Helper loaded: date_helper
INFO - 2016-03-04 11:39:12 --> Helper loaded: form_helper
INFO - 2016-03-04 11:39:12 --> Database Driver Class Initialized
INFO - 2016-03-04 11:39:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:39:13 --> Controller Class Initialized
INFO - 2016-03-04 11:39:13 --> Model Class Initialized
INFO - 2016-03-04 11:39:13 --> Model Class Initialized
INFO - 2016-03-04 11:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:39:13 --> Pagination Class Initialized
INFO - 2016-03-04 11:39:13 --> Helper loaded: text_helper
INFO - 2016-03-04 11:39:13 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:39:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:39:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:39:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:39:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:39:13 --> Final output sent to browser
DEBUG - 2016-03-04 14:39:13 --> Total execution time: 1.1042
INFO - 2016-03-04 11:39:43 --> Config Class Initialized
INFO - 2016-03-04 11:39:43 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:39:43 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:39:43 --> Utf8 Class Initialized
INFO - 2016-03-04 11:39:43 --> URI Class Initialized
INFO - 2016-03-04 11:39:43 --> Router Class Initialized
INFO - 2016-03-04 11:39:43 --> Output Class Initialized
INFO - 2016-03-04 11:39:43 --> Security Class Initialized
DEBUG - 2016-03-04 11:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:39:43 --> Input Class Initialized
INFO - 2016-03-04 11:39:43 --> Language Class Initialized
INFO - 2016-03-04 11:39:43 --> Loader Class Initialized
INFO - 2016-03-04 11:39:43 --> Helper loaded: url_helper
INFO - 2016-03-04 11:39:43 --> Helper loaded: file_helper
INFO - 2016-03-04 11:39:43 --> Helper loaded: date_helper
INFO - 2016-03-04 11:39:43 --> Helper loaded: form_helper
INFO - 2016-03-04 11:39:43 --> Database Driver Class Initialized
INFO - 2016-03-04 11:39:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:39:44 --> Controller Class Initialized
INFO - 2016-03-04 11:39:44 --> Model Class Initialized
INFO - 2016-03-04 11:39:44 --> Model Class Initialized
INFO - 2016-03-04 11:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:39:44 --> Pagination Class Initialized
INFO - 2016-03-04 11:39:44 --> Helper loaded: text_helper
INFO - 2016-03-04 11:39:44 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:39:44 --> Form Validation Class Initialized
INFO - 2016-03-04 14:39:44 --> Email Class Initialized
INFO - 2016-03-04 14:39:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 14:39:44 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 14:39:46 --> Final output sent to browser
DEBUG - 2016-03-04 14:39:46 --> Total execution time: 3.0924
INFO - 2016-03-04 11:43:10 --> Config Class Initialized
INFO - 2016-03-04 11:43:10 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:43:10 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:43:10 --> Utf8 Class Initialized
INFO - 2016-03-04 11:43:10 --> URI Class Initialized
DEBUG - 2016-03-04 11:43:10 --> No URI present. Default controller set.
INFO - 2016-03-04 11:43:10 --> Router Class Initialized
INFO - 2016-03-04 11:43:10 --> Output Class Initialized
INFO - 2016-03-04 11:43:10 --> Security Class Initialized
DEBUG - 2016-03-04 11:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:43:10 --> Input Class Initialized
INFO - 2016-03-04 11:43:10 --> Language Class Initialized
INFO - 2016-03-04 11:43:10 --> Loader Class Initialized
INFO - 2016-03-04 11:43:10 --> Helper loaded: url_helper
INFO - 2016-03-04 11:43:10 --> Helper loaded: file_helper
INFO - 2016-03-04 11:43:10 --> Helper loaded: date_helper
INFO - 2016-03-04 11:43:10 --> Helper loaded: form_helper
INFO - 2016-03-04 11:43:10 --> Database Driver Class Initialized
INFO - 2016-03-04 11:43:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:43:11 --> Controller Class Initialized
INFO - 2016-03-04 11:43:11 --> Model Class Initialized
INFO - 2016-03-04 11:43:11 --> Model Class Initialized
INFO - 2016-03-04 11:43:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:43:11 --> Pagination Class Initialized
INFO - 2016-03-04 11:43:11 --> Helper loaded: text_helper
INFO - 2016-03-04 11:43:11 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:43:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:43:11 --> Final output sent to browser
DEBUG - 2016-03-04 14:43:11 --> Total execution time: 1.1214
INFO - 2016-03-04 11:43:35 --> Config Class Initialized
INFO - 2016-03-04 11:43:35 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:43:35 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:43:35 --> Utf8 Class Initialized
INFO - 2016-03-04 11:43:35 --> URI Class Initialized
INFO - 2016-03-04 11:43:35 --> Router Class Initialized
INFO - 2016-03-04 11:43:35 --> Output Class Initialized
INFO - 2016-03-04 11:43:35 --> Security Class Initialized
DEBUG - 2016-03-04 11:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:43:35 --> Input Class Initialized
INFO - 2016-03-04 11:43:35 --> Language Class Initialized
INFO - 2016-03-04 11:43:35 --> Loader Class Initialized
INFO - 2016-03-04 11:43:35 --> Helper loaded: url_helper
INFO - 2016-03-04 11:43:35 --> Helper loaded: file_helper
INFO - 2016-03-04 11:43:35 --> Helper loaded: date_helper
INFO - 2016-03-04 11:43:35 --> Helper loaded: form_helper
INFO - 2016-03-04 11:43:35 --> Database Driver Class Initialized
INFO - 2016-03-04 11:43:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:43:36 --> Controller Class Initialized
INFO - 2016-03-04 11:43:36 --> Model Class Initialized
INFO - 2016-03-04 11:43:36 --> Model Class Initialized
INFO - 2016-03-04 11:43:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:43:36 --> Pagination Class Initialized
INFO - 2016-03-04 11:43:36 --> Helper loaded: text_helper
INFO - 2016-03-04 11:43:36 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:43:36 --> Form Validation Class Initialized
INFO - 2016-03-04 14:43:36 --> Email Class Initialized
INFO - 2016-03-04 14:43:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 14:43:37 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 14:43:38 --> Final output sent to browser
DEBUG - 2016-03-04 14:43:38 --> Total execution time: 3.1519
INFO - 2016-03-04 11:44:01 --> Config Class Initialized
INFO - 2016-03-04 11:44:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:44:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:44:01 --> Utf8 Class Initialized
INFO - 2016-03-04 11:44:01 --> URI Class Initialized
DEBUG - 2016-03-04 11:44:01 --> No URI present. Default controller set.
INFO - 2016-03-04 11:44:01 --> Router Class Initialized
INFO - 2016-03-04 11:44:01 --> Output Class Initialized
INFO - 2016-03-04 11:44:01 --> Security Class Initialized
DEBUG - 2016-03-04 11:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:44:01 --> Input Class Initialized
INFO - 2016-03-04 11:44:01 --> Language Class Initialized
INFO - 2016-03-04 11:44:01 --> Loader Class Initialized
INFO - 2016-03-04 11:44:01 --> Helper loaded: url_helper
INFO - 2016-03-04 11:44:01 --> Helper loaded: file_helper
INFO - 2016-03-04 11:44:01 --> Helper loaded: date_helper
INFO - 2016-03-04 11:44:01 --> Helper loaded: form_helper
INFO - 2016-03-04 11:44:01 --> Database Driver Class Initialized
INFO - 2016-03-04 11:44:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:44:02 --> Controller Class Initialized
INFO - 2016-03-04 11:44:02 --> Model Class Initialized
INFO - 2016-03-04 11:44:02 --> Model Class Initialized
INFO - 2016-03-04 11:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:44:02 --> Pagination Class Initialized
INFO - 2016-03-04 11:44:02 --> Helper loaded: text_helper
INFO - 2016-03-04 11:44:02 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:44:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:44:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:44:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:44:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:44:02 --> Final output sent to browser
DEBUG - 2016-03-04 14:44:02 --> Total execution time: 1.1305
INFO - 2016-03-04 11:44:29 --> Config Class Initialized
INFO - 2016-03-04 11:44:29 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:44:29 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:44:29 --> Utf8 Class Initialized
INFO - 2016-03-04 11:44:29 --> URI Class Initialized
INFO - 2016-03-04 11:44:29 --> Router Class Initialized
INFO - 2016-03-04 11:44:29 --> Output Class Initialized
INFO - 2016-03-04 11:44:29 --> Security Class Initialized
DEBUG - 2016-03-04 11:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:44:29 --> Input Class Initialized
INFO - 2016-03-04 11:44:29 --> Language Class Initialized
INFO - 2016-03-04 11:44:29 --> Loader Class Initialized
INFO - 2016-03-04 11:44:29 --> Helper loaded: url_helper
INFO - 2016-03-04 11:44:29 --> Helper loaded: file_helper
INFO - 2016-03-04 11:44:29 --> Helper loaded: date_helper
INFO - 2016-03-04 11:44:29 --> Helper loaded: form_helper
INFO - 2016-03-04 11:44:29 --> Database Driver Class Initialized
INFO - 2016-03-04 11:44:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:44:30 --> Controller Class Initialized
INFO - 2016-03-04 11:44:30 --> Model Class Initialized
INFO - 2016-03-04 11:44:30 --> Model Class Initialized
INFO - 2016-03-04 11:44:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:44:30 --> Pagination Class Initialized
INFO - 2016-03-04 11:44:30 --> Helper loaded: text_helper
INFO - 2016-03-04 11:44:30 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:44:30 --> Form Validation Class Initialized
INFO - 2016-03-04 14:44:30 --> Email Class Initialized
INFO - 2016-03-04 14:44:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 14:44:31 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 14:44:32 --> Final output sent to browser
DEBUG - 2016-03-04 14:44:32 --> Total execution time: 3.0927
INFO - 2016-03-04 11:46:18 --> Config Class Initialized
INFO - 2016-03-04 11:46:18 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:46:18 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:46:18 --> Utf8 Class Initialized
INFO - 2016-03-04 11:46:18 --> URI Class Initialized
DEBUG - 2016-03-04 11:46:18 --> No URI present. Default controller set.
INFO - 2016-03-04 11:46:18 --> Router Class Initialized
INFO - 2016-03-04 11:46:18 --> Output Class Initialized
INFO - 2016-03-04 11:46:18 --> Security Class Initialized
DEBUG - 2016-03-04 11:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:46:18 --> Input Class Initialized
INFO - 2016-03-04 11:46:18 --> Language Class Initialized
INFO - 2016-03-04 11:46:18 --> Loader Class Initialized
INFO - 2016-03-04 11:46:18 --> Helper loaded: url_helper
INFO - 2016-03-04 11:46:18 --> Helper loaded: file_helper
INFO - 2016-03-04 11:46:18 --> Helper loaded: date_helper
INFO - 2016-03-04 11:46:18 --> Helper loaded: form_helper
INFO - 2016-03-04 11:46:18 --> Database Driver Class Initialized
INFO - 2016-03-04 11:46:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:46:19 --> Controller Class Initialized
INFO - 2016-03-04 11:46:19 --> Model Class Initialized
INFO - 2016-03-04 11:46:19 --> Model Class Initialized
INFO - 2016-03-04 11:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:46:19 --> Pagination Class Initialized
INFO - 2016-03-04 11:46:19 --> Helper loaded: text_helper
INFO - 2016-03-04 11:46:19 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:46:19 --> Final output sent to browser
DEBUG - 2016-03-04 14:46:19 --> Total execution time: 1.1312
INFO - 2016-03-04 11:46:52 --> Config Class Initialized
INFO - 2016-03-04 11:46:52 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:46:52 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:46:52 --> Utf8 Class Initialized
INFO - 2016-03-04 11:46:52 --> URI Class Initialized
DEBUG - 2016-03-04 11:46:52 --> No URI present. Default controller set.
INFO - 2016-03-04 11:46:52 --> Router Class Initialized
INFO - 2016-03-04 11:46:52 --> Output Class Initialized
INFO - 2016-03-04 11:46:52 --> Security Class Initialized
DEBUG - 2016-03-04 11:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:46:52 --> Input Class Initialized
INFO - 2016-03-04 11:46:52 --> Language Class Initialized
INFO - 2016-03-04 11:46:52 --> Loader Class Initialized
INFO - 2016-03-04 11:46:52 --> Helper loaded: url_helper
INFO - 2016-03-04 11:46:52 --> Helper loaded: file_helper
INFO - 2016-03-04 11:46:52 --> Helper loaded: date_helper
INFO - 2016-03-04 11:46:52 --> Helper loaded: form_helper
INFO - 2016-03-04 11:46:52 --> Database Driver Class Initialized
INFO - 2016-03-04 11:46:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:46:53 --> Controller Class Initialized
INFO - 2016-03-04 11:46:53 --> Model Class Initialized
INFO - 2016-03-04 11:46:53 --> Model Class Initialized
INFO - 2016-03-04 11:46:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:46:53 --> Pagination Class Initialized
INFO - 2016-03-04 11:46:53 --> Helper loaded: text_helper
INFO - 2016-03-04 11:46:53 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:46:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:46:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:46:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:46:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:46:53 --> Final output sent to browser
DEBUG - 2016-03-04 14:46:53 --> Total execution time: 1.1324
INFO - 2016-03-04 11:47:12 --> Config Class Initialized
INFO - 2016-03-04 11:47:12 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:47:12 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:47:12 --> Utf8 Class Initialized
INFO - 2016-03-04 11:47:12 --> URI Class Initialized
INFO - 2016-03-04 11:47:12 --> Router Class Initialized
INFO - 2016-03-04 11:47:12 --> Output Class Initialized
INFO - 2016-03-04 11:47:12 --> Security Class Initialized
DEBUG - 2016-03-04 11:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:47:12 --> Input Class Initialized
INFO - 2016-03-04 11:47:12 --> Language Class Initialized
INFO - 2016-03-04 11:47:12 --> Loader Class Initialized
INFO - 2016-03-04 11:47:12 --> Helper loaded: url_helper
INFO - 2016-03-04 11:47:12 --> Helper loaded: file_helper
INFO - 2016-03-04 11:47:12 --> Helper loaded: date_helper
INFO - 2016-03-04 11:47:12 --> Helper loaded: form_helper
INFO - 2016-03-04 11:47:12 --> Database Driver Class Initialized
INFO - 2016-03-04 11:47:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:47:13 --> Controller Class Initialized
INFO - 2016-03-04 11:47:13 --> Model Class Initialized
INFO - 2016-03-04 11:47:13 --> Model Class Initialized
INFO - 2016-03-04 11:47:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:47:13 --> Pagination Class Initialized
INFO - 2016-03-04 11:47:13 --> Helper loaded: text_helper
INFO - 2016-03-04 11:47:13 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:47:13 --> Form Validation Class Initialized
INFO - 2016-03-04 14:47:13 --> Email Class Initialized
INFO - 2016-03-04 14:47:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 14:47:13 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 14:47:15 --> Final output sent to browser
DEBUG - 2016-03-04 14:47:15 --> Total execution time: 3.0978
INFO - 2016-03-04 11:48:13 --> Config Class Initialized
INFO - 2016-03-04 11:48:13 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:48:13 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:48:13 --> Utf8 Class Initialized
INFO - 2016-03-04 11:48:13 --> URI Class Initialized
DEBUG - 2016-03-04 11:48:13 --> No URI present. Default controller set.
INFO - 2016-03-04 11:48:13 --> Router Class Initialized
INFO - 2016-03-04 11:48:13 --> Output Class Initialized
INFO - 2016-03-04 11:48:13 --> Security Class Initialized
DEBUG - 2016-03-04 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:48:13 --> Input Class Initialized
INFO - 2016-03-04 11:48:13 --> Language Class Initialized
INFO - 2016-03-04 11:48:13 --> Loader Class Initialized
INFO - 2016-03-04 11:48:13 --> Helper loaded: url_helper
INFO - 2016-03-04 11:48:13 --> Helper loaded: file_helper
INFO - 2016-03-04 11:48:13 --> Helper loaded: date_helper
INFO - 2016-03-04 11:48:13 --> Helper loaded: form_helper
INFO - 2016-03-04 11:48:13 --> Database Driver Class Initialized
INFO - 2016-03-04 11:48:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:48:14 --> Controller Class Initialized
INFO - 2016-03-04 11:48:14 --> Model Class Initialized
INFO - 2016-03-04 11:48:14 --> Model Class Initialized
INFO - 2016-03-04 11:48:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:48:14 --> Pagination Class Initialized
INFO - 2016-03-04 11:48:14 --> Helper loaded: text_helper
INFO - 2016-03-04 11:48:14 --> Helper loaded: cookie_helper
INFO - 2016-03-04 14:48:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 14:48:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 14:48:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 14:48:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 14:48:14 --> Final output sent to browser
DEBUG - 2016-03-04 14:48:14 --> Total execution time: 1.1251
INFO - 2016-03-04 11:48:43 --> Config Class Initialized
INFO - 2016-03-04 11:48:43 --> Hooks Class Initialized
DEBUG - 2016-03-04 11:48:43 --> UTF-8 Support Enabled
INFO - 2016-03-04 11:48:43 --> Utf8 Class Initialized
INFO - 2016-03-04 11:48:43 --> URI Class Initialized
INFO - 2016-03-04 11:48:43 --> Router Class Initialized
INFO - 2016-03-04 11:48:43 --> Output Class Initialized
INFO - 2016-03-04 11:48:43 --> Security Class Initialized
DEBUG - 2016-03-04 11:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 11:48:43 --> Input Class Initialized
INFO - 2016-03-04 11:48:43 --> Language Class Initialized
INFO - 2016-03-04 11:48:43 --> Loader Class Initialized
INFO - 2016-03-04 11:48:43 --> Helper loaded: url_helper
INFO - 2016-03-04 11:48:43 --> Helper loaded: file_helper
INFO - 2016-03-04 11:48:43 --> Helper loaded: date_helper
INFO - 2016-03-04 11:48:43 --> Helper loaded: form_helper
INFO - 2016-03-04 11:48:43 --> Database Driver Class Initialized
INFO - 2016-03-04 11:48:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 11:48:44 --> Controller Class Initialized
INFO - 2016-03-04 11:48:44 --> Model Class Initialized
INFO - 2016-03-04 11:48:44 --> Model Class Initialized
INFO - 2016-03-04 11:48:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 11:48:44 --> Pagination Class Initialized
INFO - 2016-03-04 11:48:44 --> Helper loaded: text_helper
INFO - 2016-03-04 11:48:44 --> Helper loaded: cookie_helper
INFO - 2016-03-04 11:48:44 --> Form Validation Class Initialized
INFO - 2016-03-04 14:48:44 --> Email Class Initialized
INFO - 2016-03-04 14:48:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 14:48:44 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 14:48:46 --> Final output sent to browser
DEBUG - 2016-03-04 14:48:46 --> Total execution time: 3.0957
INFO - 2016-03-04 12:14:46 --> Config Class Initialized
INFO - 2016-03-04 12:14:46 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:14:46 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:14:46 --> Utf8 Class Initialized
INFO - 2016-03-04 12:14:46 --> URI Class Initialized
INFO - 2016-03-04 12:14:46 --> Router Class Initialized
INFO - 2016-03-04 12:14:46 --> Output Class Initialized
INFO - 2016-03-04 12:14:46 --> Security Class Initialized
DEBUG - 2016-03-04 12:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:14:46 --> Input Class Initialized
INFO - 2016-03-04 12:14:46 --> Language Class Initialized
INFO - 2016-03-04 12:14:46 --> Loader Class Initialized
INFO - 2016-03-04 12:14:46 --> Helper loaded: url_helper
INFO - 2016-03-04 12:14:46 --> Helper loaded: file_helper
INFO - 2016-03-04 12:14:46 --> Helper loaded: date_helper
INFO - 2016-03-04 12:14:46 --> Helper loaded: form_helper
INFO - 2016-03-04 12:14:46 --> Database Driver Class Initialized
INFO - 2016-03-04 12:14:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:14:47 --> Controller Class Initialized
INFO - 2016-03-04 12:14:47 --> Model Class Initialized
INFO - 2016-03-04 12:14:47 --> Model Class Initialized
INFO - 2016-03-04 12:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:14:47 --> Pagination Class Initialized
INFO - 2016-03-04 12:14:47 --> Helper loaded: text_helper
INFO - 2016-03-04 12:14:47 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:14:47 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:14:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:14:47 --> Final output sent to browser
DEBUG - 2016-03-04 15:14:47 --> Total execution time: 1.1180
INFO - 2016-03-04 12:21:29 --> Config Class Initialized
INFO - 2016-03-04 12:21:29 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:21:29 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:21:29 --> Utf8 Class Initialized
INFO - 2016-03-04 12:21:29 --> URI Class Initialized
DEBUG - 2016-03-04 12:21:29 --> No URI present. Default controller set.
INFO - 2016-03-04 12:21:29 --> Router Class Initialized
INFO - 2016-03-04 12:21:29 --> Output Class Initialized
INFO - 2016-03-04 12:21:29 --> Security Class Initialized
DEBUG - 2016-03-04 12:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:21:29 --> Input Class Initialized
INFO - 2016-03-04 12:21:29 --> Language Class Initialized
INFO - 2016-03-04 12:21:29 --> Loader Class Initialized
INFO - 2016-03-04 12:21:29 --> Helper loaded: url_helper
INFO - 2016-03-04 12:21:29 --> Helper loaded: file_helper
INFO - 2016-03-04 12:21:29 --> Helper loaded: date_helper
INFO - 2016-03-04 12:21:29 --> Helper loaded: form_helper
INFO - 2016-03-04 12:21:29 --> Database Driver Class Initialized
INFO - 2016-03-04 12:21:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:21:30 --> Controller Class Initialized
INFO - 2016-03-04 12:21:30 --> Model Class Initialized
INFO - 2016-03-04 12:21:30 --> Model Class Initialized
INFO - 2016-03-04 12:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:21:30 --> Pagination Class Initialized
INFO - 2016-03-04 12:21:30 --> Helper loaded: text_helper
INFO - 2016-03-04 12:21:30 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 15:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:21:30 --> Final output sent to browser
DEBUG - 2016-03-04 15:21:30 --> Total execution time: 1.1451
INFO - 2016-03-04 12:22:34 --> Config Class Initialized
INFO - 2016-03-04 12:22:34 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:22:34 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:22:34 --> Utf8 Class Initialized
INFO - 2016-03-04 12:22:34 --> URI Class Initialized
DEBUG - 2016-03-04 12:22:34 --> No URI present. Default controller set.
INFO - 2016-03-04 12:22:34 --> Router Class Initialized
INFO - 2016-03-04 12:22:34 --> Output Class Initialized
INFO - 2016-03-04 12:22:34 --> Security Class Initialized
DEBUG - 2016-03-04 12:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:22:34 --> Input Class Initialized
INFO - 2016-03-04 12:22:34 --> Language Class Initialized
INFO - 2016-03-04 12:22:34 --> Loader Class Initialized
INFO - 2016-03-04 12:22:34 --> Helper loaded: url_helper
INFO - 2016-03-04 12:22:34 --> Helper loaded: file_helper
INFO - 2016-03-04 12:22:34 --> Helper loaded: date_helper
INFO - 2016-03-04 12:22:34 --> Helper loaded: form_helper
INFO - 2016-03-04 12:22:34 --> Database Driver Class Initialized
INFO - 2016-03-04 12:22:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:22:35 --> Controller Class Initialized
INFO - 2016-03-04 12:22:35 --> Model Class Initialized
INFO - 2016-03-04 12:22:35 --> Model Class Initialized
INFO - 2016-03-04 12:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:22:35 --> Pagination Class Initialized
INFO - 2016-03-04 12:22:35 --> Helper loaded: text_helper
INFO - 2016-03-04 12:22:35 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 15:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:22:35 --> Final output sent to browser
DEBUG - 2016-03-04 15:22:35 --> Total execution time: 1.1524
INFO - 2016-03-04 12:24:30 --> Config Class Initialized
INFO - 2016-03-04 12:24:30 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:24:30 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:24:30 --> Utf8 Class Initialized
INFO - 2016-03-04 12:24:30 --> URI Class Initialized
DEBUG - 2016-03-04 12:24:30 --> No URI present. Default controller set.
INFO - 2016-03-04 12:24:30 --> Router Class Initialized
INFO - 2016-03-04 12:24:30 --> Output Class Initialized
INFO - 2016-03-04 12:24:30 --> Security Class Initialized
DEBUG - 2016-03-04 12:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:24:30 --> Input Class Initialized
INFO - 2016-03-04 12:24:30 --> Language Class Initialized
INFO - 2016-03-04 12:24:30 --> Loader Class Initialized
INFO - 2016-03-04 12:24:30 --> Helper loaded: url_helper
INFO - 2016-03-04 12:24:30 --> Helper loaded: file_helper
INFO - 2016-03-04 12:24:30 --> Helper loaded: date_helper
INFO - 2016-03-04 12:24:30 --> Helper loaded: form_helper
INFO - 2016-03-04 12:24:30 --> Database Driver Class Initialized
INFO - 2016-03-04 12:24:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:24:31 --> Controller Class Initialized
INFO - 2016-03-04 12:24:31 --> Model Class Initialized
INFO - 2016-03-04 12:24:31 --> Model Class Initialized
INFO - 2016-03-04 12:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:24:31 --> Pagination Class Initialized
INFO - 2016-03-04 12:24:31 --> Helper loaded: text_helper
INFO - 2016-03-04 12:24:31 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 15:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:24:31 --> Final output sent to browser
DEBUG - 2016-03-04 15:24:31 --> Total execution time: 1.1533
INFO - 2016-03-04 12:24:37 --> Config Class Initialized
INFO - 2016-03-04 12:24:37 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:24:37 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:24:37 --> Utf8 Class Initialized
INFO - 2016-03-04 12:24:37 --> URI Class Initialized
DEBUG - 2016-03-04 12:24:37 --> No URI present. Default controller set.
INFO - 2016-03-04 12:24:37 --> Router Class Initialized
INFO - 2016-03-04 12:24:37 --> Output Class Initialized
INFO - 2016-03-04 12:24:37 --> Security Class Initialized
DEBUG - 2016-03-04 12:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:24:37 --> Input Class Initialized
INFO - 2016-03-04 12:24:37 --> Language Class Initialized
INFO - 2016-03-04 12:24:37 --> Loader Class Initialized
INFO - 2016-03-04 12:24:37 --> Helper loaded: url_helper
INFO - 2016-03-04 12:24:37 --> Helper loaded: file_helper
INFO - 2016-03-04 12:24:37 --> Helper loaded: date_helper
INFO - 2016-03-04 12:24:37 --> Helper loaded: form_helper
INFO - 2016-03-04 12:24:37 --> Database Driver Class Initialized
INFO - 2016-03-04 12:24:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:24:38 --> Controller Class Initialized
INFO - 2016-03-04 12:24:38 --> Model Class Initialized
INFO - 2016-03-04 12:24:38 --> Model Class Initialized
INFO - 2016-03-04 12:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:24:38 --> Pagination Class Initialized
INFO - 2016-03-04 12:24:38 --> Helper loaded: text_helper
INFO - 2016-03-04 12:24:38 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 15:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:24:38 --> Final output sent to browser
DEBUG - 2016-03-04 15:24:38 --> Total execution time: 1.1806
INFO - 2016-03-04 12:28:26 --> Config Class Initialized
INFO - 2016-03-04 12:28:26 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:28:26 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:28:26 --> Utf8 Class Initialized
INFO - 2016-03-04 12:28:26 --> URI Class Initialized
INFO - 2016-03-04 12:28:26 --> Router Class Initialized
INFO - 2016-03-04 12:28:26 --> Output Class Initialized
INFO - 2016-03-04 12:28:26 --> Security Class Initialized
DEBUG - 2016-03-04 12:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:28:26 --> Input Class Initialized
INFO - 2016-03-04 12:28:26 --> Language Class Initialized
INFO - 2016-03-04 12:28:26 --> Loader Class Initialized
INFO - 2016-03-04 12:28:26 --> Helper loaded: url_helper
INFO - 2016-03-04 12:28:26 --> Helper loaded: file_helper
INFO - 2016-03-04 12:28:26 --> Helper loaded: date_helper
INFO - 2016-03-04 12:28:26 --> Helper loaded: form_helper
INFO - 2016-03-04 12:28:26 --> Database Driver Class Initialized
INFO - 2016-03-04 12:28:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:28:27 --> Controller Class Initialized
INFO - 2016-03-04 12:28:27 --> Model Class Initialized
INFO - 2016-03-04 12:28:27 --> Model Class Initialized
INFO - 2016-03-04 12:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:28:27 --> Pagination Class Initialized
INFO - 2016-03-04 12:28:27 --> Helper loaded: text_helper
INFO - 2016-03-04 12:28:27 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:28:27 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:28:27 --> Final output sent to browser
DEBUG - 2016-03-04 15:28:27 --> Total execution time: 1.1403
INFO - 2016-03-04 12:30:13 --> Config Class Initialized
INFO - 2016-03-04 12:30:13 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:30:13 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:30:13 --> Utf8 Class Initialized
INFO - 2016-03-04 12:30:13 --> URI Class Initialized
INFO - 2016-03-04 12:30:13 --> Router Class Initialized
INFO - 2016-03-04 12:30:13 --> Output Class Initialized
INFO - 2016-03-04 12:30:13 --> Security Class Initialized
DEBUG - 2016-03-04 12:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:30:13 --> Input Class Initialized
INFO - 2016-03-04 12:30:13 --> Language Class Initialized
INFO - 2016-03-04 12:30:13 --> Loader Class Initialized
INFO - 2016-03-04 12:30:13 --> Helper loaded: url_helper
INFO - 2016-03-04 12:30:13 --> Helper loaded: file_helper
INFO - 2016-03-04 12:30:13 --> Helper loaded: date_helper
INFO - 2016-03-04 12:30:13 --> Helper loaded: form_helper
INFO - 2016-03-04 12:30:13 --> Database Driver Class Initialized
INFO - 2016-03-04 12:30:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:30:14 --> Controller Class Initialized
INFO - 2016-03-04 12:30:14 --> Model Class Initialized
INFO - 2016-03-04 12:30:14 --> Model Class Initialized
INFO - 2016-03-04 12:30:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:30:14 --> Pagination Class Initialized
INFO - 2016-03-04 12:30:14 --> Helper loaded: text_helper
INFO - 2016-03-04 12:30:14 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:30:14 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:30:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:30:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:30:14 --> Final output sent to browser
DEBUG - 2016-03-04 15:30:14 --> Total execution time: 1.1415
INFO - 2016-03-04 12:30:49 --> Config Class Initialized
INFO - 2016-03-04 12:30:49 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:30:49 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:30:49 --> Utf8 Class Initialized
INFO - 2016-03-04 12:30:49 --> URI Class Initialized
INFO - 2016-03-04 12:30:49 --> Router Class Initialized
INFO - 2016-03-04 12:30:49 --> Output Class Initialized
INFO - 2016-03-04 12:30:49 --> Security Class Initialized
DEBUG - 2016-03-04 12:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:30:49 --> Input Class Initialized
INFO - 2016-03-04 12:30:49 --> Language Class Initialized
INFO - 2016-03-04 12:30:49 --> Loader Class Initialized
INFO - 2016-03-04 12:30:49 --> Helper loaded: url_helper
INFO - 2016-03-04 12:30:49 --> Helper loaded: file_helper
INFO - 2016-03-04 12:30:49 --> Helper loaded: date_helper
INFO - 2016-03-04 12:30:49 --> Helper loaded: form_helper
INFO - 2016-03-04 12:30:49 --> Database Driver Class Initialized
INFO - 2016-03-04 12:30:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:30:50 --> Controller Class Initialized
INFO - 2016-03-04 12:30:50 --> Model Class Initialized
INFO - 2016-03-04 12:30:50 --> Model Class Initialized
INFO - 2016-03-04 12:30:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:30:50 --> Pagination Class Initialized
INFO - 2016-03-04 12:30:50 --> Helper loaded: text_helper
INFO - 2016-03-04 12:30:50 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:30:50 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:30:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:30:50 --> Final output sent to browser
DEBUG - 2016-03-04 15:30:50 --> Total execution time: 1.1264
INFO - 2016-03-04 12:31:00 --> Config Class Initialized
INFO - 2016-03-04 12:31:00 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:31:00 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:31:00 --> Utf8 Class Initialized
INFO - 2016-03-04 12:31:00 --> URI Class Initialized
INFO - 2016-03-04 12:31:00 --> Router Class Initialized
INFO - 2016-03-04 12:31:00 --> Output Class Initialized
INFO - 2016-03-04 12:31:00 --> Security Class Initialized
DEBUG - 2016-03-04 12:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:31:00 --> Input Class Initialized
INFO - 2016-03-04 12:31:00 --> Language Class Initialized
INFO - 2016-03-04 12:31:00 --> Loader Class Initialized
INFO - 2016-03-04 12:31:00 --> Helper loaded: url_helper
INFO - 2016-03-04 12:31:00 --> Helper loaded: file_helper
INFO - 2016-03-04 12:31:00 --> Helper loaded: date_helper
INFO - 2016-03-04 12:31:00 --> Helper loaded: form_helper
INFO - 2016-03-04 12:31:00 --> Database Driver Class Initialized
INFO - 2016-03-04 12:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:31:01 --> Controller Class Initialized
INFO - 2016-03-04 12:31:01 --> Model Class Initialized
INFO - 2016-03-04 12:31:01 --> Model Class Initialized
INFO - 2016-03-04 12:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:31:01 --> Pagination Class Initialized
INFO - 2016-03-04 12:31:01 --> Helper loaded: text_helper
INFO - 2016-03-04 12:31:01 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:31:01 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:31:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:31:01 --> Final output sent to browser
DEBUG - 2016-03-04 15:31:01 --> Total execution time: 1.1709
INFO - 2016-03-04 12:33:57 --> Config Class Initialized
INFO - 2016-03-04 12:33:57 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:33:57 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:33:57 --> Utf8 Class Initialized
INFO - 2016-03-04 12:33:57 --> URI Class Initialized
INFO - 2016-03-04 12:33:57 --> Router Class Initialized
INFO - 2016-03-04 12:33:57 --> Output Class Initialized
INFO - 2016-03-04 12:33:57 --> Security Class Initialized
DEBUG - 2016-03-04 12:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:33:57 --> Input Class Initialized
INFO - 2016-03-04 12:33:57 --> Language Class Initialized
INFO - 2016-03-04 12:33:57 --> Loader Class Initialized
INFO - 2016-03-04 12:33:57 --> Helper loaded: url_helper
INFO - 2016-03-04 12:33:57 --> Helper loaded: file_helper
INFO - 2016-03-04 12:33:57 --> Helper loaded: date_helper
INFO - 2016-03-04 12:33:57 --> Helper loaded: form_helper
INFO - 2016-03-04 12:33:57 --> Database Driver Class Initialized
INFO - 2016-03-04 12:33:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:33:58 --> Controller Class Initialized
INFO - 2016-03-04 12:33:58 --> Model Class Initialized
INFO - 2016-03-04 12:33:58 --> Model Class Initialized
INFO - 2016-03-04 12:33:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:33:58 --> Pagination Class Initialized
INFO - 2016-03-04 12:33:58 --> Helper loaded: text_helper
INFO - 2016-03-04 12:33:58 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:33:58 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:33:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:33:58 --> Final output sent to browser
DEBUG - 2016-03-04 15:33:58 --> Total execution time: 1.0992
INFO - 2016-03-04 12:36:37 --> Config Class Initialized
INFO - 2016-03-04 12:36:37 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:36:37 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:36:37 --> Utf8 Class Initialized
INFO - 2016-03-04 12:36:37 --> URI Class Initialized
INFO - 2016-03-04 12:36:37 --> Router Class Initialized
INFO - 2016-03-04 12:36:37 --> Output Class Initialized
INFO - 2016-03-04 12:36:37 --> Security Class Initialized
DEBUG - 2016-03-04 12:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:36:37 --> Input Class Initialized
INFO - 2016-03-04 12:36:37 --> Language Class Initialized
INFO - 2016-03-04 12:36:37 --> Loader Class Initialized
INFO - 2016-03-04 12:36:37 --> Helper loaded: url_helper
INFO - 2016-03-04 12:36:37 --> Helper loaded: file_helper
INFO - 2016-03-04 12:36:37 --> Helper loaded: date_helper
INFO - 2016-03-04 12:36:37 --> Helper loaded: form_helper
INFO - 2016-03-04 12:36:37 --> Database Driver Class Initialized
INFO - 2016-03-04 12:36:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:36:38 --> Controller Class Initialized
INFO - 2016-03-04 12:36:38 --> Model Class Initialized
INFO - 2016-03-04 12:36:38 --> Model Class Initialized
INFO - 2016-03-04 12:36:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:36:38 --> Pagination Class Initialized
INFO - 2016-03-04 12:36:38 --> Helper loaded: text_helper
INFO - 2016-03-04 12:36:38 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:36:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:36:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:36:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:36:38 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:36:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:36:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:36:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:36:38 --> Final output sent to browser
DEBUG - 2016-03-04 15:36:38 --> Total execution time: 1.1057
INFO - 2016-03-04 12:36:43 --> Config Class Initialized
INFO - 2016-03-04 12:36:43 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:36:43 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:36:43 --> Utf8 Class Initialized
INFO - 2016-03-04 12:36:43 --> URI Class Initialized
INFO - 2016-03-04 12:36:43 --> Router Class Initialized
INFO - 2016-03-04 12:36:43 --> Output Class Initialized
INFO - 2016-03-04 12:36:43 --> Security Class Initialized
DEBUG - 2016-03-04 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:36:43 --> Input Class Initialized
INFO - 2016-03-04 12:36:43 --> Language Class Initialized
INFO - 2016-03-04 12:36:43 --> Loader Class Initialized
INFO - 2016-03-04 12:36:43 --> Helper loaded: url_helper
INFO - 2016-03-04 12:36:43 --> Helper loaded: file_helper
INFO - 2016-03-04 12:36:43 --> Helper loaded: date_helper
INFO - 2016-03-04 12:36:43 --> Helper loaded: form_helper
INFO - 2016-03-04 12:36:43 --> Database Driver Class Initialized
INFO - 2016-03-04 12:36:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:36:44 --> Controller Class Initialized
INFO - 2016-03-04 12:36:44 --> Model Class Initialized
INFO - 2016-03-04 12:36:44 --> Model Class Initialized
INFO - 2016-03-04 12:36:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:36:44 --> Pagination Class Initialized
INFO - 2016-03-04 12:36:44 --> Helper loaded: text_helper
INFO - 2016-03-04 12:36:44 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:36:44 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:36:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:36:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:36:44 --> Final output sent to browser
DEBUG - 2016-03-04 15:36:44 --> Total execution time: 1.1061
INFO - 2016-03-04 12:36:47 --> Config Class Initialized
INFO - 2016-03-04 12:36:47 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:36:47 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:36:47 --> Utf8 Class Initialized
INFO - 2016-03-04 12:36:47 --> URI Class Initialized
INFO - 2016-03-04 12:36:47 --> Router Class Initialized
INFO - 2016-03-04 12:36:47 --> Output Class Initialized
INFO - 2016-03-04 12:36:47 --> Security Class Initialized
DEBUG - 2016-03-04 12:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:36:47 --> Input Class Initialized
INFO - 2016-03-04 12:36:47 --> Language Class Initialized
INFO - 2016-03-04 12:36:47 --> Loader Class Initialized
INFO - 2016-03-04 12:36:47 --> Helper loaded: url_helper
INFO - 2016-03-04 12:36:47 --> Helper loaded: file_helper
INFO - 2016-03-04 12:36:47 --> Helper loaded: date_helper
INFO - 2016-03-04 12:36:47 --> Helper loaded: form_helper
INFO - 2016-03-04 12:36:47 --> Database Driver Class Initialized
INFO - 2016-03-04 12:36:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:36:48 --> Controller Class Initialized
INFO - 2016-03-04 12:36:48 --> Model Class Initialized
INFO - 2016-03-04 12:36:48 --> Model Class Initialized
INFO - 2016-03-04 12:36:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:36:48 --> Pagination Class Initialized
INFO - 2016-03-04 12:36:48 --> Helper loaded: text_helper
INFO - 2016-03-04 12:36:48 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:36:48 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:36:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:36:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:36:48 --> Final output sent to browser
DEBUG - 2016-03-04 15:36:48 --> Total execution time: 1.0961
INFO - 2016-03-04 12:36:50 --> Config Class Initialized
INFO - 2016-03-04 12:36:50 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:36:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:36:50 --> Utf8 Class Initialized
INFO - 2016-03-04 12:36:50 --> URI Class Initialized
INFO - 2016-03-04 12:36:50 --> Router Class Initialized
INFO - 2016-03-04 12:36:50 --> Output Class Initialized
INFO - 2016-03-04 12:36:50 --> Security Class Initialized
DEBUG - 2016-03-04 12:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:36:50 --> Input Class Initialized
INFO - 2016-03-04 12:36:50 --> Language Class Initialized
INFO - 2016-03-04 12:36:50 --> Loader Class Initialized
INFO - 2016-03-04 12:36:50 --> Helper loaded: url_helper
INFO - 2016-03-04 12:36:50 --> Helper loaded: file_helper
INFO - 2016-03-04 12:36:50 --> Helper loaded: date_helper
INFO - 2016-03-04 12:36:50 --> Helper loaded: form_helper
INFO - 2016-03-04 12:36:50 --> Database Driver Class Initialized
INFO - 2016-03-04 12:36:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:36:51 --> Controller Class Initialized
INFO - 2016-03-04 12:36:51 --> Model Class Initialized
INFO - 2016-03-04 12:36:51 --> Model Class Initialized
INFO - 2016-03-04 12:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:36:51 --> Pagination Class Initialized
INFO - 2016-03-04 12:36:51 --> Helper loaded: text_helper
INFO - 2016-03-04 12:36:51 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:36:51 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:36:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:36:51 --> Final output sent to browser
DEBUG - 2016-03-04 15:36:51 --> Total execution time: 1.1062
INFO - 2016-03-04 12:36:53 --> Config Class Initialized
INFO - 2016-03-04 12:36:53 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:36:53 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:36:53 --> Utf8 Class Initialized
INFO - 2016-03-04 12:36:53 --> URI Class Initialized
INFO - 2016-03-04 12:36:53 --> Router Class Initialized
INFO - 2016-03-04 12:36:53 --> Output Class Initialized
INFO - 2016-03-04 12:36:53 --> Security Class Initialized
DEBUG - 2016-03-04 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:36:53 --> Input Class Initialized
INFO - 2016-03-04 12:36:53 --> Language Class Initialized
INFO - 2016-03-04 12:36:53 --> Loader Class Initialized
INFO - 2016-03-04 12:36:53 --> Helper loaded: url_helper
INFO - 2016-03-04 12:36:53 --> Helper loaded: file_helper
INFO - 2016-03-04 12:36:53 --> Helper loaded: date_helper
INFO - 2016-03-04 12:36:53 --> Helper loaded: form_helper
INFO - 2016-03-04 12:36:53 --> Database Driver Class Initialized
INFO - 2016-03-04 12:36:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:36:54 --> Controller Class Initialized
INFO - 2016-03-04 12:36:54 --> Model Class Initialized
INFO - 2016-03-04 12:36:54 --> Model Class Initialized
INFO - 2016-03-04 12:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:36:54 --> Pagination Class Initialized
INFO - 2016-03-04 12:36:54 --> Helper loaded: text_helper
INFO - 2016-03-04 12:36:54 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:36:54 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:36:54 --> Final output sent to browser
DEBUG - 2016-03-04 15:36:54 --> Total execution time: 1.1042
INFO - 2016-03-04 12:36:55 --> Config Class Initialized
INFO - 2016-03-04 12:36:55 --> Hooks Class Initialized
DEBUG - 2016-03-04 12:36:55 --> UTF-8 Support Enabled
INFO - 2016-03-04 12:36:55 --> Utf8 Class Initialized
INFO - 2016-03-04 12:36:55 --> URI Class Initialized
INFO - 2016-03-04 12:36:55 --> Router Class Initialized
INFO - 2016-03-04 12:36:55 --> Output Class Initialized
INFO - 2016-03-04 12:36:55 --> Security Class Initialized
DEBUG - 2016-03-04 12:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 12:36:55 --> Input Class Initialized
INFO - 2016-03-04 12:36:55 --> Language Class Initialized
INFO - 2016-03-04 12:36:55 --> Loader Class Initialized
INFO - 2016-03-04 12:36:55 --> Helper loaded: url_helper
INFO - 2016-03-04 12:36:55 --> Helper loaded: file_helper
INFO - 2016-03-04 12:36:55 --> Helper loaded: date_helper
INFO - 2016-03-04 12:36:55 --> Helper loaded: form_helper
INFO - 2016-03-04 12:36:55 --> Database Driver Class Initialized
INFO - 2016-03-04 12:36:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 12:36:56 --> Controller Class Initialized
INFO - 2016-03-04 12:36:56 --> Model Class Initialized
INFO - 2016-03-04 12:36:56 --> Model Class Initialized
INFO - 2016-03-04 12:36:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 12:36:56 --> Pagination Class Initialized
INFO - 2016-03-04 12:36:56 --> Helper loaded: text_helper
INFO - 2016-03-04 12:36:56 --> Helper loaded: cookie_helper
INFO - 2016-03-04 15:36:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 15:36:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 15:36:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 15:36:56 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 15:36:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 15:36:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 15:36:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 15:36:56 --> Final output sent to browser
DEBUG - 2016-03-04 15:36:56 --> Total execution time: 1.1040
INFO - 2016-03-04 13:11:01 --> Config Class Initialized
INFO - 2016-03-04 13:11:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:11:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:11:01 --> Utf8 Class Initialized
INFO - 2016-03-04 13:11:01 --> URI Class Initialized
INFO - 2016-03-04 13:11:01 --> Router Class Initialized
INFO - 2016-03-04 13:11:01 --> Output Class Initialized
INFO - 2016-03-04 13:11:01 --> Security Class Initialized
DEBUG - 2016-03-04 13:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:11:01 --> Input Class Initialized
INFO - 2016-03-04 13:11:01 --> Language Class Initialized
INFO - 2016-03-04 13:11:01 --> Loader Class Initialized
INFO - 2016-03-04 13:11:01 --> Helper loaded: url_helper
INFO - 2016-03-04 13:11:01 --> Helper loaded: file_helper
INFO - 2016-03-04 13:11:01 --> Helper loaded: date_helper
INFO - 2016-03-04 13:11:01 --> Helper loaded: form_helper
INFO - 2016-03-04 13:11:01 --> Database Driver Class Initialized
INFO - 2016-03-04 13:11:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:11:02 --> Controller Class Initialized
INFO - 2016-03-04 13:11:02 --> Model Class Initialized
INFO - 2016-03-04 13:11:02 --> Model Class Initialized
INFO - 2016-03-04 13:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:11:02 --> Pagination Class Initialized
INFO - 2016-03-04 13:11:02 --> Helper loaded: text_helper
INFO - 2016-03-04 13:11:02 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 16:11:02 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 16:11:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 16:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 16:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:11:02 --> Final output sent to browser
DEBUG - 2016-03-04 16:11:02 --> Total execution time: 1.1413
INFO - 2016-03-04 13:11:21 --> Config Class Initialized
INFO - 2016-03-04 13:11:21 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:11:21 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:11:21 --> Utf8 Class Initialized
INFO - 2016-03-04 13:11:21 --> URI Class Initialized
INFO - 2016-03-04 13:11:21 --> Router Class Initialized
INFO - 2016-03-04 13:11:21 --> Output Class Initialized
INFO - 2016-03-04 13:11:21 --> Security Class Initialized
DEBUG - 2016-03-04 13:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:11:21 --> Input Class Initialized
INFO - 2016-03-04 13:11:21 --> Language Class Initialized
INFO - 2016-03-04 13:11:21 --> Loader Class Initialized
INFO - 2016-03-04 13:11:21 --> Helper loaded: url_helper
INFO - 2016-03-04 13:11:21 --> Helper loaded: file_helper
INFO - 2016-03-04 13:11:21 --> Helper loaded: date_helper
INFO - 2016-03-04 13:11:21 --> Helper loaded: form_helper
INFO - 2016-03-04 13:11:21 --> Database Driver Class Initialized
INFO - 2016-03-04 13:11:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:11:22 --> Controller Class Initialized
INFO - 2016-03-04 13:11:22 --> Model Class Initialized
INFO - 2016-03-04 13:11:22 --> Model Class Initialized
INFO - 2016-03-04 13:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:11:22 --> Pagination Class Initialized
INFO - 2016-03-04 13:11:22 --> Helper loaded: text_helper
INFO - 2016-03-04 13:11:22 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:11:22 --> Form Validation Class Initialized
INFO - 2016-03-04 16:11:22 --> Email Class Initialized
INFO - 2016-03-04 16:11:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 16:11:22 --> Final output sent to browser
DEBUG - 2016-03-04 16:11:22 --> Total execution time: 1.1456
INFO - 2016-03-04 13:12:13 --> Config Class Initialized
INFO - 2016-03-04 13:12:13 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:12:13 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:12:13 --> Utf8 Class Initialized
INFO - 2016-03-04 13:12:13 --> URI Class Initialized
INFO - 2016-03-04 13:12:13 --> Router Class Initialized
INFO - 2016-03-04 13:12:13 --> Output Class Initialized
INFO - 2016-03-04 13:12:13 --> Security Class Initialized
DEBUG - 2016-03-04 13:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:12:13 --> Input Class Initialized
INFO - 2016-03-04 13:12:13 --> Language Class Initialized
INFO - 2016-03-04 13:12:13 --> Loader Class Initialized
INFO - 2016-03-04 13:12:13 --> Helper loaded: url_helper
INFO - 2016-03-04 13:12:13 --> Helper loaded: file_helper
INFO - 2016-03-04 13:12:13 --> Helper loaded: date_helper
INFO - 2016-03-04 13:12:13 --> Helper loaded: form_helper
INFO - 2016-03-04 13:12:13 --> Database Driver Class Initialized
INFO - 2016-03-04 13:12:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:12:14 --> Controller Class Initialized
INFO - 2016-03-04 13:12:14 --> Model Class Initialized
INFO - 2016-03-04 13:12:14 --> Model Class Initialized
INFO - 2016-03-04 13:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:12:14 --> Pagination Class Initialized
INFO - 2016-03-04 13:12:14 --> Helper loaded: text_helper
INFO - 2016-03-04 13:12:14 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 16:12:14 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 16:12:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 16:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 16:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:12:14 --> Final output sent to browser
DEBUG - 2016-03-04 16:12:14 --> Total execution time: 1.2423
INFO - 2016-03-04 13:12:47 --> Config Class Initialized
INFO - 2016-03-04 13:12:47 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:12:47 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:12:47 --> Utf8 Class Initialized
INFO - 2016-03-04 13:12:47 --> URI Class Initialized
INFO - 2016-03-04 13:12:47 --> Router Class Initialized
INFO - 2016-03-04 13:12:47 --> Output Class Initialized
INFO - 2016-03-04 13:12:47 --> Security Class Initialized
DEBUG - 2016-03-04 13:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:12:47 --> Input Class Initialized
INFO - 2016-03-04 13:12:47 --> Language Class Initialized
INFO - 2016-03-04 13:12:47 --> Loader Class Initialized
INFO - 2016-03-04 13:12:47 --> Helper loaded: url_helper
INFO - 2016-03-04 13:12:47 --> Helper loaded: file_helper
INFO - 2016-03-04 13:12:47 --> Helper loaded: date_helper
INFO - 2016-03-04 13:12:47 --> Helper loaded: form_helper
INFO - 2016-03-04 13:12:47 --> Database Driver Class Initialized
INFO - 2016-03-04 13:12:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:12:49 --> Controller Class Initialized
INFO - 2016-03-04 13:12:49 --> Model Class Initialized
INFO - 2016-03-04 13:12:49 --> Model Class Initialized
INFO - 2016-03-04 13:12:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:12:49 --> Pagination Class Initialized
INFO - 2016-03-04 13:12:49 --> Helper loaded: text_helper
INFO - 2016-03-04 13:12:49 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 16:12:49 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 16:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 16:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 16:12:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:12:49 --> Final output sent to browser
DEBUG - 2016-03-04 16:12:49 --> Total execution time: 1.1169
INFO - 2016-03-04 13:13:05 --> Config Class Initialized
INFO - 2016-03-04 13:13:05 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:13:05 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:13:05 --> Utf8 Class Initialized
INFO - 2016-03-04 13:13:05 --> URI Class Initialized
INFO - 2016-03-04 13:13:05 --> Router Class Initialized
INFO - 2016-03-04 13:13:05 --> Output Class Initialized
INFO - 2016-03-04 13:13:05 --> Security Class Initialized
DEBUG - 2016-03-04 13:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:13:05 --> Input Class Initialized
INFO - 2016-03-04 13:13:05 --> Language Class Initialized
INFO - 2016-03-04 13:13:05 --> Loader Class Initialized
INFO - 2016-03-04 13:13:05 --> Helper loaded: url_helper
INFO - 2016-03-04 13:13:05 --> Helper loaded: file_helper
INFO - 2016-03-04 13:13:05 --> Helper loaded: date_helper
INFO - 2016-03-04 13:13:05 --> Helper loaded: form_helper
INFO - 2016-03-04 13:13:05 --> Database Driver Class Initialized
INFO - 2016-03-04 13:13:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:13:06 --> Controller Class Initialized
INFO - 2016-03-04 13:13:06 --> Model Class Initialized
INFO - 2016-03-04 13:13:06 --> Model Class Initialized
INFO - 2016-03-04 13:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:13:06 --> Pagination Class Initialized
INFO - 2016-03-04 13:13:06 --> Helper loaded: text_helper
INFO - 2016-03-04 13:13:06 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:13:06 --> Form Validation Class Initialized
INFO - 2016-03-04 16:13:06 --> Email Class Initialized
INFO - 2016-03-04 16:13:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 16:13:06 --> Final output sent to browser
DEBUG - 2016-03-04 16:13:06 --> Total execution time: 1.1172
INFO - 2016-03-04 13:13:36 --> Config Class Initialized
INFO - 2016-03-04 13:13:36 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:13:36 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:13:36 --> Utf8 Class Initialized
INFO - 2016-03-04 13:13:36 --> URI Class Initialized
INFO - 2016-03-04 13:13:36 --> Router Class Initialized
INFO - 2016-03-04 13:13:36 --> Output Class Initialized
INFO - 2016-03-04 13:13:36 --> Security Class Initialized
DEBUG - 2016-03-04 13:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:13:36 --> Input Class Initialized
INFO - 2016-03-04 13:13:36 --> Language Class Initialized
INFO - 2016-03-04 13:13:36 --> Loader Class Initialized
INFO - 2016-03-04 13:13:36 --> Helper loaded: url_helper
INFO - 2016-03-04 13:13:36 --> Helper loaded: file_helper
INFO - 2016-03-04 13:13:36 --> Helper loaded: date_helper
INFO - 2016-03-04 13:13:36 --> Helper loaded: form_helper
INFO - 2016-03-04 13:13:36 --> Database Driver Class Initialized
INFO - 2016-03-04 13:13:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:13:37 --> Controller Class Initialized
INFO - 2016-03-04 13:13:37 --> Model Class Initialized
INFO - 2016-03-04 13:13:37 --> Model Class Initialized
INFO - 2016-03-04 13:13:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:13:37 --> Pagination Class Initialized
INFO - 2016-03-04 13:13:37 --> Helper loaded: text_helper
INFO - 2016-03-04 13:13:37 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 16:13:37 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 16:13:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 16:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 16:13:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:13:37 --> Final output sent to browser
DEBUG - 2016-03-04 16:13:37 --> Total execution time: 1.1695
INFO - 2016-03-04 13:13:53 --> Config Class Initialized
INFO - 2016-03-04 13:13:53 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:13:53 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:13:53 --> Utf8 Class Initialized
INFO - 2016-03-04 13:13:53 --> URI Class Initialized
INFO - 2016-03-04 13:13:53 --> Router Class Initialized
INFO - 2016-03-04 13:13:53 --> Output Class Initialized
INFO - 2016-03-04 13:13:53 --> Security Class Initialized
DEBUG - 2016-03-04 13:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:13:53 --> Input Class Initialized
INFO - 2016-03-04 13:13:53 --> Language Class Initialized
INFO - 2016-03-04 13:13:53 --> Loader Class Initialized
INFO - 2016-03-04 13:13:53 --> Helper loaded: url_helper
INFO - 2016-03-04 13:13:53 --> Helper loaded: file_helper
INFO - 2016-03-04 13:13:53 --> Helper loaded: date_helper
INFO - 2016-03-04 13:13:53 --> Helper loaded: form_helper
INFO - 2016-03-04 13:13:53 --> Database Driver Class Initialized
INFO - 2016-03-04 13:13:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:13:54 --> Controller Class Initialized
INFO - 2016-03-04 13:13:54 --> Model Class Initialized
INFO - 2016-03-04 13:13:54 --> Model Class Initialized
INFO - 2016-03-04 13:13:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:13:54 --> Pagination Class Initialized
INFO - 2016-03-04 13:13:54 --> Helper loaded: text_helper
INFO - 2016-03-04 13:13:54 --> Helper loaded: cookie_helper
INFO - 2016-03-04 13:13:54 --> Form Validation Class Initialized
INFO - 2016-03-04 16:13:54 --> Email Class Initialized
INFO - 2016-03-04 16:13:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 16:13:54 --> Final output sent to browser
DEBUG - 2016-03-04 16:13:54 --> Total execution time: 1.1132
INFO - 2016-03-04 13:17:29 --> Config Class Initialized
INFO - 2016-03-04 13:17:29 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:17:29 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:17:29 --> Utf8 Class Initialized
INFO - 2016-03-04 13:17:29 --> URI Class Initialized
INFO - 2016-03-04 13:17:29 --> Router Class Initialized
INFO - 2016-03-04 13:17:29 --> Output Class Initialized
INFO - 2016-03-04 13:17:29 --> Security Class Initialized
DEBUG - 2016-03-04 13:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:17:29 --> Input Class Initialized
INFO - 2016-03-04 13:17:29 --> Language Class Initialized
INFO - 2016-03-04 13:17:29 --> Loader Class Initialized
INFO - 2016-03-04 13:17:29 --> Helper loaded: url_helper
INFO - 2016-03-04 13:17:29 --> Helper loaded: file_helper
INFO - 2016-03-04 13:17:29 --> Helper loaded: date_helper
INFO - 2016-03-04 13:17:29 --> Helper loaded: form_helper
INFO - 2016-03-04 13:17:29 --> Database Driver Class Initialized
INFO - 2016-03-04 13:17:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:17:30 --> Controller Class Initialized
INFO - 2016-03-04 13:17:30 --> Model Class Initialized
INFO - 2016-03-04 13:17:30 --> Model Class Initialized
INFO - 2016-03-04 13:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:17:30 --> Pagination Class Initialized
INFO - 2016-03-04 13:17:30 --> Helper loaded: text_helper
INFO - 2016-03-04 13:17:30 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 16:17:30 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 16:17:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 16:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 16:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:17:30 --> Final output sent to browser
DEBUG - 2016-03-04 16:17:30 --> Total execution time: 1.1412
INFO - 2016-03-04 13:17:33 --> Config Class Initialized
INFO - 2016-03-04 13:17:33 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:17:33 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:17:33 --> Utf8 Class Initialized
INFO - 2016-03-04 13:17:33 --> URI Class Initialized
INFO - 2016-03-04 13:17:33 --> Router Class Initialized
INFO - 2016-03-04 13:17:33 --> Output Class Initialized
INFO - 2016-03-04 13:17:33 --> Security Class Initialized
DEBUG - 2016-03-04 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:17:33 --> Input Class Initialized
INFO - 2016-03-04 13:17:33 --> Language Class Initialized
INFO - 2016-03-04 13:17:33 --> Loader Class Initialized
INFO - 2016-03-04 13:17:33 --> Helper loaded: url_helper
INFO - 2016-03-04 13:17:33 --> Helper loaded: file_helper
INFO - 2016-03-04 13:17:33 --> Helper loaded: date_helper
INFO - 2016-03-04 13:17:33 --> Helper loaded: form_helper
INFO - 2016-03-04 13:17:33 --> Database Driver Class Initialized
INFO - 2016-03-04 13:17:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:17:34 --> Controller Class Initialized
INFO - 2016-03-04 13:17:34 --> Model Class Initialized
INFO - 2016-03-04 13:17:34 --> Model Class Initialized
INFO - 2016-03-04 13:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:17:34 --> Pagination Class Initialized
INFO - 2016-03-04 13:17:34 --> Helper loaded: text_helper
INFO - 2016-03-04 13:17:34 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:17:34 --> Final output sent to browser
DEBUG - 2016-03-04 16:17:34 --> Total execution time: 1.1523
INFO - 2016-03-04 13:17:37 --> Config Class Initialized
INFO - 2016-03-04 13:17:37 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:17:37 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:17:37 --> Utf8 Class Initialized
INFO - 2016-03-04 13:17:37 --> URI Class Initialized
DEBUG - 2016-03-04 13:17:37 --> No URI present. Default controller set.
INFO - 2016-03-04 13:17:37 --> Router Class Initialized
INFO - 2016-03-04 13:17:37 --> Output Class Initialized
INFO - 2016-03-04 13:17:37 --> Security Class Initialized
DEBUG - 2016-03-04 13:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:17:37 --> Input Class Initialized
INFO - 2016-03-04 13:17:37 --> Language Class Initialized
INFO - 2016-03-04 13:17:37 --> Loader Class Initialized
INFO - 2016-03-04 13:17:37 --> Helper loaded: url_helper
INFO - 2016-03-04 13:17:37 --> Helper loaded: file_helper
INFO - 2016-03-04 13:17:37 --> Helper loaded: date_helper
INFO - 2016-03-04 13:17:37 --> Helper loaded: form_helper
INFO - 2016-03-04 13:17:37 --> Database Driver Class Initialized
INFO - 2016-03-04 13:17:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:17:38 --> Controller Class Initialized
INFO - 2016-03-04 13:17:38 --> Model Class Initialized
INFO - 2016-03-04 13:17:38 --> Model Class Initialized
INFO - 2016-03-04 13:17:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:17:38 --> Pagination Class Initialized
INFO - 2016-03-04 13:17:38 --> Helper loaded: text_helper
INFO - 2016-03-04 13:17:38 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:17:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:17:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:17:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 16:17:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:17:38 --> Final output sent to browser
DEBUG - 2016-03-04 16:17:38 --> Total execution time: 1.1053
INFO - 2016-03-04 13:17:41 --> Config Class Initialized
INFO - 2016-03-04 13:17:41 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:17:41 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:17:41 --> Utf8 Class Initialized
INFO - 2016-03-04 13:17:41 --> URI Class Initialized
DEBUG - 2016-03-04 13:17:41 --> No URI present. Default controller set.
INFO - 2016-03-04 13:17:41 --> Router Class Initialized
INFO - 2016-03-04 13:17:41 --> Output Class Initialized
INFO - 2016-03-04 13:17:41 --> Security Class Initialized
DEBUG - 2016-03-04 13:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:17:41 --> Input Class Initialized
INFO - 2016-03-04 13:17:41 --> Language Class Initialized
INFO - 2016-03-04 13:17:41 --> Loader Class Initialized
INFO - 2016-03-04 13:17:41 --> Helper loaded: url_helper
INFO - 2016-03-04 13:17:41 --> Helper loaded: file_helper
INFO - 2016-03-04 13:17:41 --> Helper loaded: date_helper
INFO - 2016-03-04 13:17:41 --> Helper loaded: form_helper
INFO - 2016-03-04 13:17:41 --> Database Driver Class Initialized
INFO - 2016-03-04 13:17:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:17:42 --> Controller Class Initialized
INFO - 2016-03-04 13:17:42 --> Model Class Initialized
INFO - 2016-03-04 13:17:42 --> Model Class Initialized
INFO - 2016-03-04 13:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:17:42 --> Pagination Class Initialized
INFO - 2016-03-04 13:17:42 --> Helper loaded: text_helper
INFO - 2016-03-04 13:17:42 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 16:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:17:42 --> Final output sent to browser
DEBUG - 2016-03-04 16:17:42 --> Total execution time: 1.0999
INFO - 2016-03-04 13:17:48 --> Config Class Initialized
INFO - 2016-03-04 13:17:48 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:17:48 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:17:48 --> Utf8 Class Initialized
INFO - 2016-03-04 13:17:48 --> URI Class Initialized
INFO - 2016-03-04 13:17:48 --> Router Class Initialized
INFO - 2016-03-04 13:17:48 --> Output Class Initialized
INFO - 2016-03-04 13:17:48 --> Security Class Initialized
DEBUG - 2016-03-04 13:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:17:48 --> Input Class Initialized
INFO - 2016-03-04 13:17:48 --> Language Class Initialized
INFO - 2016-03-04 13:17:48 --> Loader Class Initialized
INFO - 2016-03-04 13:17:48 --> Helper loaded: url_helper
INFO - 2016-03-04 13:17:48 --> Helper loaded: file_helper
INFO - 2016-03-04 13:17:48 --> Helper loaded: date_helper
INFO - 2016-03-04 13:17:48 --> Helper loaded: form_helper
INFO - 2016-03-04 13:17:48 --> Database Driver Class Initialized
INFO - 2016-03-04 13:17:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 13:17:49 --> Controller Class Initialized
INFO - 2016-03-04 13:17:49 --> Model Class Initialized
INFO - 2016-03-04 13:17:49 --> Model Class Initialized
INFO - 2016-03-04 13:17:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 13:17:49 --> Pagination Class Initialized
INFO - 2016-03-04 13:17:49 --> Helper loaded: text_helper
INFO - 2016-03-04 13:17:49 --> Helper loaded: cookie_helper
INFO - 2016-03-04 16:17:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 16:17:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 16:17:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 16:17:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 16:17:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 16:17:49 --> Final output sent to browser
DEBUG - 2016-03-04 16:17:49 --> Total execution time: 1.1430
INFO - 2016-03-04 13:18:15 --> Config Class Initialized
INFO - 2016-03-04 13:18:15 --> Hooks Class Initialized
DEBUG - 2016-03-04 13:18:15 --> UTF-8 Support Enabled
INFO - 2016-03-04 13:18:15 --> Utf8 Class Initialized
INFO - 2016-03-04 13:18:15 --> URI Class Initialized
INFO - 2016-03-04 13:18:15 --> Router Class Initialized
INFO - 2016-03-04 13:18:15 --> Output Class Initialized
INFO - 2016-03-04 13:18:15 --> Security Class Initialized
DEBUG - 2016-03-04 13:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 13:18:15 --> Input Class Initialized
INFO - 2016-03-04 13:18:15 --> Language Class Initialized
ERROR - 2016-03-04 13:18:15 --> 404 Page Not Found: Wall/80
INFO - 2016-03-04 14:30:01 --> Config Class Initialized
INFO - 2016-03-04 14:30:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:30:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:30:01 --> Utf8 Class Initialized
INFO - 2016-03-04 14:30:01 --> URI Class Initialized
INFO - 2016-03-04 14:30:01 --> Router Class Initialized
INFO - 2016-03-04 14:30:01 --> Output Class Initialized
INFO - 2016-03-04 14:30:01 --> Security Class Initialized
DEBUG - 2016-03-04 14:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:30:01 --> Input Class Initialized
INFO - 2016-03-04 14:30:01 --> Language Class Initialized
ERROR - 2016-03-04 14:30:01 --> 404 Page Not Found: Wall/80
INFO - 2016-03-04 14:38:22 --> Config Class Initialized
INFO - 2016-03-04 14:38:22 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:38:22 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:22 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:22 --> URI Class Initialized
INFO - 2016-03-04 14:38:22 --> Router Class Initialized
INFO - 2016-03-04 14:38:22 --> Output Class Initialized
INFO - 2016-03-04 14:38:22 --> Security Class Initialized
DEBUG - 2016-03-04 14:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:22 --> Input Class Initialized
INFO - 2016-03-04 14:38:22 --> Language Class Initialized
ERROR - 2016-03-04 14:38:22 --> 404 Page Not Found: Wall/80
INFO - 2016-03-04 14:38:24 --> Config Class Initialized
INFO - 2016-03-04 14:38:24 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:38:24 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:24 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:24 --> URI Class Initialized
INFO - 2016-03-04 14:38:24 --> Router Class Initialized
INFO - 2016-03-04 14:38:24 --> Output Class Initialized
INFO - 2016-03-04 14:38:24 --> Security Class Initialized
DEBUG - 2016-03-04 14:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:24 --> Input Class Initialized
INFO - 2016-03-04 14:38:24 --> Language Class Initialized
INFO - 2016-03-04 14:38:24 --> Loader Class Initialized
INFO - 2016-03-04 14:38:24 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:24 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:24 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:24 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:24 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:25 --> Controller Class Initialized
INFO - 2016-03-04 14:38:25 --> Model Class Initialized
INFO - 2016-03-04 14:38:25 --> Model Class Initialized
INFO - 2016-03-04 14:38:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 14:38:25 --> Pagination Class Initialized
INFO - 2016-03-04 14:38:25 --> Helper loaded: text_helper
INFO - 2016-03-04 14:38:25 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 17:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 17:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 17:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 17:38:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 17:38:25 --> Final output sent to browser
DEBUG - 2016-03-04 17:38:25 --> Total execution time: 1.2081
INFO - 2016-03-04 14:38:49 --> Config Class Initialized
INFO - 2016-03-04 14:38:49 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:38:49 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:49 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:49 --> URI Class Initialized
INFO - 2016-03-04 14:38:49 --> Router Class Initialized
INFO - 2016-03-04 14:38:49 --> Output Class Initialized
INFO - 2016-03-04 14:38:49 --> Security Class Initialized
DEBUG - 2016-03-04 14:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:49 --> Input Class Initialized
INFO - 2016-03-04 14:38:49 --> Language Class Initialized
INFO - 2016-03-04 14:38:49 --> Loader Class Initialized
INFO - 2016-03-04 14:38:49 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:49 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:49 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:49 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:49 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:50 --> Controller Class Initialized
INFO - 2016-03-04 14:38:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:50 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:50 --> Total execution time: 1.0863
INFO - 2016-03-04 14:38:50 --> Config Class Initialized
INFO - 2016-03-04 14:38:50 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:38:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:50 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:50 --> Config Class Initialized
INFO - 2016-03-04 14:38:50 --> URI Class Initialized
INFO - 2016-03-04 14:38:50 --> Hooks Class Initialized
INFO - 2016-03-04 14:38:50 --> Router Class Initialized
DEBUG - 2016-03-04 14:38:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:50 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:50 --> Config Class Initialized
INFO - 2016-03-04 14:38:50 --> Output Class Initialized
INFO - 2016-03-04 14:38:50 --> URI Class Initialized
INFO - 2016-03-04 14:38:50 --> Hooks Class Initialized
INFO - 2016-03-04 14:38:50 --> Router Class Initialized
INFO - 2016-03-04 14:38:50 --> Security Class Initialized
DEBUG - 2016-03-04 14:38:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:50 --> Output Class Initialized
INFO - 2016-03-04 14:38:50 --> Utf8 Class Initialized
DEBUG - 2016-03-04 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:50 --> Security Class Initialized
INFO - 2016-03-04 14:38:50 --> URI Class Initialized
INFO - 2016-03-04 14:38:50 --> Input Class Initialized
INFO - 2016-03-04 14:38:50 --> Language Class Initialized
DEBUG - 2016-03-04 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:50 --> Router Class Initialized
INFO - 2016-03-04 14:38:50 --> Input Class Initialized
INFO - 2016-03-04 14:38:50 --> Loader Class Initialized
INFO - 2016-03-04 14:38:50 --> Config Class Initialized
INFO - 2016-03-04 14:38:50 --> Language Class Initialized
INFO - 2016-03-04 14:38:50 --> Output Class Initialized
INFO - 2016-03-04 14:38:50 --> Hooks Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:50 --> Security Class Initialized
INFO - 2016-03-04 14:38:50 --> Loader Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: file_helper
DEBUG - 2016-03-04 14:38:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:50 --> Helper loaded: url_helper
DEBUG - 2016-03-04 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:50 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:50 --> Input Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:50 --> URI Class Initialized
INFO - 2016-03-04 14:38:50 --> Config Class Initialized
INFO - 2016-03-04 14:38:50 --> Language Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:50 --> Config Class Initialized
INFO - 2016-03-04 14:38:50 --> Hooks Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:50 --> Hooks Class Initialized
INFO - 2016-03-04 14:38:50 --> Router Class Initialized
INFO - 2016-03-04 14:38:50 --> Loader Class Initialized
DEBUG - 2016-03-04 14:38:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:50 --> Output Class Initialized
INFO - 2016-03-04 14:38:50 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: form_helper
DEBUG - 2016-03-04 14:38:50 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:50 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:50 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:50 --> Security Class Initialized
INFO - 2016-03-04 14:38:50 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:50 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:50 --> URI Class Initialized
DEBUG - 2016-03-04 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:50 --> URI Class Initialized
INFO - 2016-03-04 14:38:50 --> Input Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:50 --> Language Class Initialized
INFO - 2016-03-04 14:38:50 --> Router Class Initialized
INFO - 2016-03-04 14:38:50 --> Router Class Initialized
INFO - 2016-03-04 14:38:50 --> Output Class Initialized
INFO - 2016-03-04 14:38:50 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:50 --> Output Class Initialized
INFO - 2016-03-04 14:38:50 --> Loader Class Initialized
INFO - 2016-03-04 14:38:50 --> Security Class Initialized
INFO - 2016-03-04 14:38:50 --> Security Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: url_helper
DEBUG - 2016-03-04 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:50 --> Helper loaded: file_helper
DEBUG - 2016-03-04 14:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:50 --> Input Class Initialized
INFO - 2016-03-04 14:38:50 --> Input Class Initialized
INFO - 2016-03-04 14:38:50 --> Language Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:50 --> Language Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:50 --> Loader Class Initialized
INFO - 2016-03-04 14:38:50 --> Loader Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:50 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:50 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:50 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:50 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:50 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:50 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:50 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:50 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:50 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:50 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:51 --> Controller Class Initialized
INFO - 2016-03-04 14:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:51 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:51 --> Total execution time: 1.1408
INFO - 2016-03-04 14:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:51 --> Controller Class Initialized
INFO - 2016-03-04 14:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:51 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:51 --> Total execution time: 1.1802
INFO - 2016-03-04 14:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:51 --> Controller Class Initialized
INFO - 2016-03-04 14:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:51 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:51 --> Total execution time: 1.2159
INFO - 2016-03-04 14:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:51 --> Controller Class Initialized
INFO - 2016-03-04 14:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:51 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:51 --> Total execution time: 1.2375
INFO - 2016-03-04 14:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:51 --> Controller Class Initialized
INFO - 2016-03-04 14:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:51 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:51 --> Total execution time: 1.2727
INFO - 2016-03-04 14:38:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:51 --> Controller Class Initialized
INFO - 2016-03-04 14:38:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:51 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:51 --> Total execution time: 1.3022
INFO - 2016-03-04 14:38:52 --> Config Class Initialized
INFO - 2016-03-04 14:38:52 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:38:52 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:52 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:52 --> URI Class Initialized
INFO - 2016-03-04 14:38:52 --> Router Class Initialized
INFO - 2016-03-04 14:38:52 --> Output Class Initialized
INFO - 2016-03-04 14:38:52 --> Security Class Initialized
DEBUG - 2016-03-04 14:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:52 --> Input Class Initialized
INFO - 2016-03-04 14:38:52 --> Language Class Initialized
INFO - 2016-03-04 14:38:52 --> Loader Class Initialized
INFO - 2016-03-04 14:38:52 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:52 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:52 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:52 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:52 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:53 --> Controller Class Initialized
INFO - 2016-03-04 14:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:53 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:53 --> Total execution time: 1.0722
INFO - 2016-03-04 14:38:53 --> Config Class Initialized
INFO - 2016-03-04 14:38:53 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:38:53 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:53 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:53 --> URI Class Initialized
INFO - 2016-03-04 14:38:53 --> Router Class Initialized
INFO - 2016-03-04 14:38:53 --> Output Class Initialized
INFO - 2016-03-04 14:38:53 --> Security Class Initialized
DEBUG - 2016-03-04 14:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:53 --> Input Class Initialized
INFO - 2016-03-04 14:38:53 --> Language Class Initialized
INFO - 2016-03-04 14:38:53 --> Loader Class Initialized
INFO - 2016-03-04 14:38:53 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:53 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:53 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:53 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:53 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:54 --> Controller Class Initialized
INFO - 2016-03-04 14:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\not_found.php
INFO - 2016-03-04 14:38:54 --> Final output sent to browser
DEBUG - 2016-03-04 14:38:54 --> Total execution time: 1.0676
INFO - 2016-03-04 14:38:57 --> Config Class Initialized
INFO - 2016-03-04 14:38:57 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:38:57 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:38:57 --> Utf8 Class Initialized
INFO - 2016-03-04 14:38:57 --> URI Class Initialized
INFO - 2016-03-04 14:38:57 --> Router Class Initialized
INFO - 2016-03-04 14:38:57 --> Output Class Initialized
INFO - 2016-03-04 14:38:57 --> Security Class Initialized
DEBUG - 2016-03-04 14:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:38:57 --> Input Class Initialized
INFO - 2016-03-04 14:38:57 --> Language Class Initialized
INFO - 2016-03-04 14:38:57 --> Loader Class Initialized
INFO - 2016-03-04 14:38:57 --> Helper loaded: url_helper
INFO - 2016-03-04 14:38:57 --> Helper loaded: file_helper
INFO - 2016-03-04 14:38:57 --> Helper loaded: date_helper
INFO - 2016-03-04 14:38:57 --> Helper loaded: form_helper
INFO - 2016-03-04 14:38:57 --> Database Driver Class Initialized
INFO - 2016-03-04 14:38:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:38:58 --> Controller Class Initialized
INFO - 2016-03-04 14:38:58 --> Model Class Initialized
INFO - 2016-03-04 14:38:58 --> Model Class Initialized
INFO - 2016-03-04 14:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 14:38:58 --> Pagination Class Initialized
INFO - 2016-03-04 14:38:58 --> Helper loaded: text_helper
INFO - 2016-03-04 14:38:58 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 17:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 17:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 17:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 17:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 17:38:58 --> Final output sent to browser
DEBUG - 2016-03-04 17:38:58 --> Total execution time: 1.1393
INFO - 2016-03-04 14:43:18 --> Config Class Initialized
INFO - 2016-03-04 14:43:18 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:43:18 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:43:18 --> Utf8 Class Initialized
INFO - 2016-03-04 14:43:18 --> URI Class Initialized
INFO - 2016-03-04 14:43:18 --> Router Class Initialized
INFO - 2016-03-04 14:43:18 --> Output Class Initialized
INFO - 2016-03-04 14:43:18 --> Security Class Initialized
DEBUG - 2016-03-04 14:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:43:18 --> Input Class Initialized
INFO - 2016-03-04 14:43:18 --> Language Class Initialized
INFO - 2016-03-04 14:43:18 --> Loader Class Initialized
INFO - 2016-03-04 14:43:18 --> Helper loaded: url_helper
INFO - 2016-03-04 14:43:18 --> Helper loaded: file_helper
INFO - 2016-03-04 14:43:18 --> Helper loaded: date_helper
INFO - 2016-03-04 14:43:18 --> Helper loaded: form_helper
INFO - 2016-03-04 14:43:18 --> Database Driver Class Initialized
INFO - 2016-03-04 14:43:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:43:20 --> Controller Class Initialized
INFO - 2016-03-04 14:43:20 --> Model Class Initialized
INFO - 2016-03-04 14:43:20 --> Model Class Initialized
INFO - 2016-03-04 14:43:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 14:43:20 --> Pagination Class Initialized
INFO - 2016-03-04 14:43:20 --> Helper loaded: text_helper
INFO - 2016-03-04 14:43:20 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:43:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 17:43:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 17:43:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 17:43:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 17:43:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 17:43:20 --> Final output sent to browser
DEBUG - 2016-03-04 17:43:20 --> Total execution time: 1.2132
INFO - 2016-03-04 14:43:25 --> Config Class Initialized
INFO - 2016-03-04 14:43:25 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:43:25 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:43:25 --> Utf8 Class Initialized
INFO - 2016-03-04 14:43:25 --> URI Class Initialized
INFO - 2016-03-04 14:43:25 --> Router Class Initialized
INFO - 2016-03-04 14:43:25 --> Output Class Initialized
INFO - 2016-03-04 14:43:25 --> Security Class Initialized
DEBUG - 2016-03-04 14:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:43:25 --> Input Class Initialized
INFO - 2016-03-04 14:43:25 --> Language Class Initialized
INFO - 2016-03-04 14:43:25 --> Loader Class Initialized
INFO - 2016-03-04 14:43:25 --> Helper loaded: url_helper
INFO - 2016-03-04 14:43:25 --> Helper loaded: file_helper
INFO - 2016-03-04 14:43:25 --> Helper loaded: date_helper
INFO - 2016-03-04 14:43:25 --> Helper loaded: form_helper
INFO - 2016-03-04 14:43:25 --> Database Driver Class Initialized
INFO - 2016-03-04 14:43:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:43:26 --> Controller Class Initialized
INFO - 2016-03-04 14:43:26 --> User Agent Class Initialized
INFO - 2016-03-04 14:43:26 --> Final output sent to browser
DEBUG - 2016-03-04 14:43:26 --> Total execution time: 1.2457
INFO - 2016-03-04 14:43:39 --> Config Class Initialized
INFO - 2016-03-04 14:43:39 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:43:39 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:43:39 --> Utf8 Class Initialized
INFO - 2016-03-04 14:43:39 --> URI Class Initialized
INFO - 2016-03-04 14:43:39 --> Router Class Initialized
INFO - 2016-03-04 14:43:39 --> Output Class Initialized
INFO - 2016-03-04 14:43:39 --> Security Class Initialized
DEBUG - 2016-03-04 14:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:43:39 --> Input Class Initialized
INFO - 2016-03-04 14:43:39 --> Language Class Initialized
INFO - 2016-03-04 14:43:39 --> Loader Class Initialized
INFO - 2016-03-04 14:43:39 --> Helper loaded: url_helper
INFO - 2016-03-04 14:43:39 --> Helper loaded: file_helper
INFO - 2016-03-04 14:43:39 --> Helper loaded: date_helper
INFO - 2016-03-04 14:43:39 --> Helper loaded: form_helper
INFO - 2016-03-04 14:43:39 --> Database Driver Class Initialized
INFO - 2016-03-04 14:43:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:43:40 --> Controller Class Initialized
INFO - 2016-03-04 14:43:40 --> Model Class Initialized
INFO - 2016-03-04 14:43:40 --> Model Class Initialized
INFO - 2016-03-04 14:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 14:43:40 --> Pagination Class Initialized
INFO - 2016-03-04 14:43:40 --> Helper loaded: text_helper
INFO - 2016-03-04 14:43:40 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 17:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 17:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 17:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 17:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 17:43:40 --> Final output sent to browser
DEBUG - 2016-03-04 17:43:40 --> Total execution time: 1.2792
INFO - 2016-03-04 14:43:47 --> Config Class Initialized
INFO - 2016-03-04 14:43:47 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:43:47 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:43:47 --> Utf8 Class Initialized
INFO - 2016-03-04 14:43:47 --> URI Class Initialized
INFO - 2016-03-04 14:43:47 --> Router Class Initialized
INFO - 2016-03-04 14:43:47 --> Output Class Initialized
INFO - 2016-03-04 14:43:47 --> Security Class Initialized
DEBUG - 2016-03-04 14:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:43:47 --> Input Class Initialized
INFO - 2016-03-04 14:43:47 --> Language Class Initialized
INFO - 2016-03-04 14:43:47 --> Loader Class Initialized
INFO - 2016-03-04 14:43:47 --> Helper loaded: url_helper
INFO - 2016-03-04 14:43:47 --> Helper loaded: file_helper
INFO - 2016-03-04 14:43:47 --> Helper loaded: date_helper
INFO - 2016-03-04 14:43:47 --> Helper loaded: form_helper
INFO - 2016-03-04 14:43:47 --> Database Driver Class Initialized
INFO - 2016-03-04 14:43:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:43:48 --> Controller Class Initialized
INFO - 2016-03-04 14:43:48 --> User Agent Class Initialized
INFO - 2016-03-04 14:43:48 --> Final output sent to browser
DEBUG - 2016-03-04 14:43:48 --> Total execution time: 1.1252
INFO - 2016-03-04 14:44:10 --> Config Class Initialized
INFO - 2016-03-04 14:44:10 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:44:10 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:44:10 --> Utf8 Class Initialized
INFO - 2016-03-04 14:44:10 --> URI Class Initialized
INFO - 2016-03-04 14:44:10 --> Router Class Initialized
INFO - 2016-03-04 14:44:10 --> Output Class Initialized
INFO - 2016-03-04 14:44:10 --> Security Class Initialized
DEBUG - 2016-03-04 14:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:44:10 --> Input Class Initialized
INFO - 2016-03-04 14:44:10 --> Language Class Initialized
INFO - 2016-03-04 14:44:10 --> Loader Class Initialized
INFO - 2016-03-04 14:44:10 --> Helper loaded: url_helper
INFO - 2016-03-04 14:44:10 --> Helper loaded: file_helper
INFO - 2016-03-04 14:44:10 --> Helper loaded: date_helper
INFO - 2016-03-04 14:44:10 --> Helper loaded: form_helper
INFO - 2016-03-04 14:44:10 --> Database Driver Class Initialized
INFO - 2016-03-04 14:44:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:44:11 --> Controller Class Initialized
INFO - 2016-03-04 14:44:11 --> Model Class Initialized
INFO - 2016-03-04 14:44:11 --> Model Class Initialized
INFO - 2016-03-04 14:44:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 14:44:11 --> Pagination Class Initialized
INFO - 2016-03-04 14:44:11 --> Helper loaded: text_helper
INFO - 2016-03-04 14:44:11 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:44:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 17:44:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 17:44:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 17:44:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 17:44:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 17:44:11 --> Final output sent to browser
DEBUG - 2016-03-04 17:44:11 --> Total execution time: 1.3889
INFO - 2016-03-04 14:44:15 --> Config Class Initialized
INFO - 2016-03-04 14:44:15 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:44:15 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:44:15 --> Utf8 Class Initialized
INFO - 2016-03-04 14:44:15 --> URI Class Initialized
INFO - 2016-03-04 14:44:15 --> Router Class Initialized
INFO - 2016-03-04 14:44:15 --> Output Class Initialized
INFO - 2016-03-04 14:44:15 --> Security Class Initialized
DEBUG - 2016-03-04 14:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:44:15 --> Input Class Initialized
INFO - 2016-03-04 14:44:15 --> Language Class Initialized
ERROR - 2016-03-04 14:44:15 --> 404 Page Not Found: Wall/80
INFO - 2016-03-04 14:44:53 --> Config Class Initialized
INFO - 2016-03-04 14:44:53 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:44:53 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:44:53 --> Utf8 Class Initialized
INFO - 2016-03-04 14:44:53 --> URI Class Initialized
INFO - 2016-03-04 14:44:53 --> Router Class Initialized
INFO - 2016-03-04 14:44:53 --> Output Class Initialized
INFO - 2016-03-04 14:44:53 --> Security Class Initialized
DEBUG - 2016-03-04 14:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:44:53 --> Input Class Initialized
INFO - 2016-03-04 14:44:53 --> Language Class Initialized
INFO - 2016-03-04 14:44:53 --> Loader Class Initialized
INFO - 2016-03-04 14:44:53 --> Helper loaded: url_helper
INFO - 2016-03-04 14:44:53 --> Helper loaded: file_helper
INFO - 2016-03-04 14:44:53 --> Helper loaded: date_helper
INFO - 2016-03-04 14:44:53 --> Helper loaded: form_helper
INFO - 2016-03-04 14:44:53 --> Database Driver Class Initialized
INFO - 2016-03-04 14:44:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:44:54 --> Controller Class Initialized
INFO - 2016-03-04 14:44:54 --> Model Class Initialized
INFO - 2016-03-04 14:44:54 --> Model Class Initialized
INFO - 2016-03-04 14:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 14:44:54 --> Pagination Class Initialized
INFO - 2016-03-04 14:44:54 --> Helper loaded: text_helper
INFO - 2016-03-04 14:44:54 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:44:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 17:44:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 17:44:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 17:44:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 17:44:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 17:44:54 --> Final output sent to browser
DEBUG - 2016-03-04 17:44:54 --> Total execution time: 1.2104
INFO - 2016-03-04 14:44:58 --> Config Class Initialized
INFO - 2016-03-04 14:44:58 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:44:58 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:44:58 --> Utf8 Class Initialized
INFO - 2016-03-04 14:44:58 --> URI Class Initialized
INFO - 2016-03-04 14:44:58 --> Router Class Initialized
INFO - 2016-03-04 14:44:58 --> Output Class Initialized
INFO - 2016-03-04 14:44:58 --> Security Class Initialized
DEBUG - 2016-03-04 14:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:44:58 --> Input Class Initialized
INFO - 2016-03-04 14:44:58 --> Language Class Initialized
INFO - 2016-03-04 14:44:58 --> Loader Class Initialized
INFO - 2016-03-04 14:44:58 --> Helper loaded: url_helper
INFO - 2016-03-04 14:44:58 --> Helper loaded: file_helper
INFO - 2016-03-04 14:44:58 --> Helper loaded: date_helper
INFO - 2016-03-04 14:44:58 --> Helper loaded: form_helper
INFO - 2016-03-04 14:44:58 --> Database Driver Class Initialized
INFO - 2016-03-04 14:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:44:59 --> Controller Class Initialized
INFO - 2016-03-04 14:44:59 --> User Agent Class Initialized
INFO - 2016-03-04 14:44:59 --> Final output sent to browser
DEBUG - 2016-03-04 14:44:59 --> Total execution time: 1.2350
INFO - 2016-03-04 14:47:13 --> Config Class Initialized
INFO - 2016-03-04 14:47:13 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:47:13 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:47:13 --> Utf8 Class Initialized
INFO - 2016-03-04 14:47:13 --> URI Class Initialized
INFO - 2016-03-04 14:47:13 --> Router Class Initialized
INFO - 2016-03-04 14:47:13 --> Output Class Initialized
INFO - 2016-03-04 14:47:13 --> Security Class Initialized
DEBUG - 2016-03-04 14:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:47:13 --> Input Class Initialized
INFO - 2016-03-04 14:47:13 --> Language Class Initialized
INFO - 2016-03-04 14:47:13 --> Loader Class Initialized
INFO - 2016-03-04 14:47:13 --> Helper loaded: url_helper
INFO - 2016-03-04 14:47:13 --> Helper loaded: file_helper
INFO - 2016-03-04 14:47:13 --> Helper loaded: date_helper
INFO - 2016-03-04 14:47:13 --> Helper loaded: form_helper
INFO - 2016-03-04 14:47:13 --> Database Driver Class Initialized
INFO - 2016-03-04 14:47:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:47:14 --> Controller Class Initialized
INFO - 2016-03-04 14:47:14 --> Model Class Initialized
INFO - 2016-03-04 14:47:14 --> Model Class Initialized
INFO - 2016-03-04 14:47:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 14:47:14 --> Pagination Class Initialized
INFO - 2016-03-04 14:47:14 --> Helper loaded: text_helper
INFO - 2016-03-04 14:47:14 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:47:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 17:47:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 17:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 17:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 17:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 17:47:15 --> Final output sent to browser
DEBUG - 2016-03-04 17:47:15 --> Total execution time: 1.2586
INFO - 2016-03-04 14:47:17 --> Config Class Initialized
INFO - 2016-03-04 14:47:17 --> Hooks Class Initialized
DEBUG - 2016-03-04 14:47:17 --> UTF-8 Support Enabled
INFO - 2016-03-04 14:47:17 --> Utf8 Class Initialized
INFO - 2016-03-04 14:47:17 --> URI Class Initialized
DEBUG - 2016-03-04 14:47:17 --> No URI present. Default controller set.
INFO - 2016-03-04 14:47:17 --> Router Class Initialized
INFO - 2016-03-04 14:47:17 --> Output Class Initialized
INFO - 2016-03-04 14:47:17 --> Security Class Initialized
DEBUG - 2016-03-04 14:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 14:47:17 --> Input Class Initialized
INFO - 2016-03-04 14:47:17 --> Language Class Initialized
INFO - 2016-03-04 14:47:17 --> Loader Class Initialized
INFO - 2016-03-04 14:47:17 --> Helper loaded: url_helper
INFO - 2016-03-04 14:47:17 --> Helper loaded: file_helper
INFO - 2016-03-04 14:47:17 --> Helper loaded: date_helper
INFO - 2016-03-04 14:47:17 --> Helper loaded: form_helper
INFO - 2016-03-04 14:47:17 --> Database Driver Class Initialized
INFO - 2016-03-04 14:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 14:47:19 --> Controller Class Initialized
INFO - 2016-03-04 14:47:19 --> Model Class Initialized
INFO - 2016-03-04 14:47:19 --> Model Class Initialized
INFO - 2016-03-04 14:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 14:47:19 --> Pagination Class Initialized
INFO - 2016-03-04 14:47:19 --> Helper loaded: text_helper
INFO - 2016-03-04 14:47:19 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 17:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 17:47:19 --> Final output sent to browser
DEBUG - 2016-03-04 17:47:19 --> Total execution time: 1.2688
INFO - 2016-03-04 17:10:35 --> Config Class Initialized
INFO - 2016-03-04 17:10:35 --> Hooks Class Initialized
DEBUG - 2016-03-04 17:10:35 --> UTF-8 Support Enabled
INFO - 2016-03-04 17:10:35 --> Utf8 Class Initialized
INFO - 2016-03-04 17:10:35 --> URI Class Initialized
DEBUG - 2016-03-04 17:10:35 --> No URI present. Default controller set.
INFO - 2016-03-04 17:10:35 --> Router Class Initialized
INFO - 2016-03-04 17:10:35 --> Output Class Initialized
INFO - 2016-03-04 17:10:35 --> Security Class Initialized
DEBUG - 2016-03-04 17:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 17:10:35 --> Input Class Initialized
INFO - 2016-03-04 17:10:35 --> Language Class Initialized
INFO - 2016-03-04 17:10:35 --> Loader Class Initialized
INFO - 2016-03-04 17:10:35 --> Helper loaded: url_helper
INFO - 2016-03-04 17:10:35 --> Helper loaded: file_helper
INFO - 2016-03-04 17:10:35 --> Helper loaded: date_helper
INFO - 2016-03-04 17:10:35 --> Helper loaded: form_helper
INFO - 2016-03-04 17:10:35 --> Database Driver Class Initialized
INFO - 2016-03-04 17:10:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 17:10:36 --> Controller Class Initialized
INFO - 2016-03-04 17:10:36 --> Model Class Initialized
INFO - 2016-03-04 17:10:36 --> Model Class Initialized
INFO - 2016-03-04 17:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 17:10:36 --> Pagination Class Initialized
INFO - 2016-03-04 17:10:36 --> Helper loaded: text_helper
INFO - 2016-03-04 17:10:36 --> Helper loaded: cookie_helper
INFO - 2016-03-04 20:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 20:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 20:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 20:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 20:10:36 --> Final output sent to browser
DEBUG - 2016-03-04 20:10:36 --> Total execution time: 1.1318
INFO - 2016-03-04 17:11:20 --> Config Class Initialized
INFO - 2016-03-04 17:11:20 --> Hooks Class Initialized
DEBUG - 2016-03-04 17:11:20 --> UTF-8 Support Enabled
INFO - 2016-03-04 17:11:20 --> Utf8 Class Initialized
INFO - 2016-03-04 17:11:20 --> URI Class Initialized
INFO - 2016-03-04 17:11:20 --> Router Class Initialized
INFO - 2016-03-04 17:11:20 --> Output Class Initialized
INFO - 2016-03-04 17:11:20 --> Security Class Initialized
DEBUG - 2016-03-04 17:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 17:11:20 --> Input Class Initialized
INFO - 2016-03-04 17:11:20 --> Language Class Initialized
INFO - 2016-03-04 17:11:20 --> Loader Class Initialized
INFO - 2016-03-04 17:11:20 --> Helper loaded: url_helper
INFO - 2016-03-04 17:11:20 --> Helper loaded: file_helper
INFO - 2016-03-04 17:11:20 --> Helper loaded: date_helper
INFO - 2016-03-04 17:11:20 --> Helper loaded: form_helper
INFO - 2016-03-04 17:11:20 --> Database Driver Class Initialized
INFO - 2016-03-04 17:11:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 17:11:21 --> Controller Class Initialized
INFO - 2016-03-04 17:11:21 --> Model Class Initialized
INFO - 2016-03-04 17:11:21 --> Model Class Initialized
INFO - 2016-03-04 17:11:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 17:11:21 --> Pagination Class Initialized
INFO - 2016-03-04 17:11:21 --> Helper loaded: text_helper
INFO - 2016-03-04 17:11:21 --> Helper loaded: cookie_helper
INFO - 2016-03-04 17:11:21 --> Form Validation Class Initialized
INFO - 2016-03-04 20:11:21 --> Email Class Initialized
INFO - 2016-03-04 20:11:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-04 20:11:21 --> Language file loaded: language/english/email_lang.php
INFO - 2016-03-04 20:11:23 --> Final output sent to browser
DEBUG - 2016-03-04 20:11:23 --> Total execution time: 3.4372
INFO - 2016-03-04 17:11:57 --> Config Class Initialized
INFO - 2016-03-04 17:11:57 --> Hooks Class Initialized
DEBUG - 2016-03-04 17:11:57 --> UTF-8 Support Enabled
INFO - 2016-03-04 17:11:57 --> Utf8 Class Initialized
INFO - 2016-03-04 17:11:57 --> URI Class Initialized
DEBUG - 2016-03-04 17:11:57 --> No URI present. Default controller set.
INFO - 2016-03-04 17:11:57 --> Router Class Initialized
INFO - 2016-03-04 17:11:57 --> Output Class Initialized
INFO - 2016-03-04 17:11:57 --> Security Class Initialized
DEBUG - 2016-03-04 17:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 17:11:57 --> Input Class Initialized
INFO - 2016-03-04 17:11:57 --> Language Class Initialized
INFO - 2016-03-04 17:11:57 --> Loader Class Initialized
INFO - 2016-03-04 17:11:57 --> Helper loaded: url_helper
INFO - 2016-03-04 17:11:57 --> Helper loaded: file_helper
INFO - 2016-03-04 17:11:57 --> Helper loaded: date_helper
INFO - 2016-03-04 17:11:57 --> Helper loaded: form_helper
INFO - 2016-03-04 17:11:57 --> Database Driver Class Initialized
INFO - 2016-03-04 17:11:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 17:11:58 --> Controller Class Initialized
INFO - 2016-03-04 17:11:58 --> Model Class Initialized
INFO - 2016-03-04 17:11:58 --> Model Class Initialized
INFO - 2016-03-04 17:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 17:11:58 --> Pagination Class Initialized
INFO - 2016-03-04 17:11:58 --> Helper loaded: text_helper
INFO - 2016-03-04 17:11:58 --> Helper loaded: cookie_helper
INFO - 2016-03-04 20:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 20:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 20:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 20:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 20:11:58 --> Final output sent to browser
DEBUG - 2016-03-04 20:11:58 --> Total execution time: 1.1037
INFO - 2016-03-04 17:12:01 --> Config Class Initialized
INFO - 2016-03-04 17:12:01 --> Hooks Class Initialized
DEBUG - 2016-03-04 17:12:01 --> UTF-8 Support Enabled
INFO - 2016-03-04 17:12:01 --> Utf8 Class Initialized
INFO - 2016-03-04 17:12:01 --> URI Class Initialized
DEBUG - 2016-03-04 17:12:01 --> No URI present. Default controller set.
INFO - 2016-03-04 17:12:01 --> Router Class Initialized
INFO - 2016-03-04 17:12:01 --> Output Class Initialized
INFO - 2016-03-04 17:12:01 --> Security Class Initialized
DEBUG - 2016-03-04 17:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 17:12:01 --> Input Class Initialized
INFO - 2016-03-04 17:12:01 --> Language Class Initialized
INFO - 2016-03-04 17:12:01 --> Loader Class Initialized
INFO - 2016-03-04 17:12:01 --> Helper loaded: url_helper
INFO - 2016-03-04 17:12:01 --> Helper loaded: file_helper
INFO - 2016-03-04 17:12:01 --> Helper loaded: date_helper
INFO - 2016-03-04 17:12:01 --> Helper loaded: form_helper
INFO - 2016-03-04 17:12:01 --> Database Driver Class Initialized
INFO - 2016-03-04 17:12:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 17:12:02 --> Controller Class Initialized
INFO - 2016-03-04 17:12:02 --> Model Class Initialized
INFO - 2016-03-04 17:12:02 --> Model Class Initialized
INFO - 2016-03-04 17:12:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 17:12:02 --> Pagination Class Initialized
INFO - 2016-03-04 17:12:02 --> Helper loaded: text_helper
INFO - 2016-03-04 17:12:02 --> Helper loaded: cookie_helper
INFO - 2016-03-04 20:12:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 20:12:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 20:12:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 20:12:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 20:12:02 --> Final output sent to browser
DEBUG - 2016-03-04 20:12:02 --> Total execution time: 1.1181
INFO - 2016-03-04 17:12:05 --> Config Class Initialized
INFO - 2016-03-04 17:12:05 --> Hooks Class Initialized
DEBUG - 2016-03-04 17:12:05 --> UTF-8 Support Enabled
INFO - 2016-03-04 17:12:05 --> Utf8 Class Initialized
INFO - 2016-03-04 17:12:05 --> URI Class Initialized
INFO - 2016-03-04 17:12:05 --> Router Class Initialized
INFO - 2016-03-04 17:12:05 --> Output Class Initialized
INFO - 2016-03-04 17:12:05 --> Security Class Initialized
DEBUG - 2016-03-04 17:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 17:12:05 --> Input Class Initialized
INFO - 2016-03-04 17:12:05 --> Language Class Initialized
INFO - 2016-03-04 17:12:05 --> Loader Class Initialized
INFO - 2016-03-04 17:12:05 --> Helper loaded: url_helper
INFO - 2016-03-04 17:12:05 --> Helper loaded: file_helper
INFO - 2016-03-04 17:12:05 --> Helper loaded: date_helper
INFO - 2016-03-04 17:12:05 --> Helper loaded: form_helper
INFO - 2016-03-04 17:12:05 --> Database Driver Class Initialized
INFO - 2016-03-04 17:12:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 17:12:06 --> Controller Class Initialized
INFO - 2016-03-04 17:12:06 --> Model Class Initialized
INFO - 2016-03-04 17:12:06 --> Model Class Initialized
INFO - 2016-03-04 17:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 17:12:06 --> Pagination Class Initialized
INFO - 2016-03-04 17:12:06 --> Helper loaded: text_helper
INFO - 2016-03-04 17:12:06 --> Helper loaded: cookie_helper
INFO - 2016-03-04 20:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 20:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 20:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 20:12:06 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 20:12:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 20:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 20:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 20:12:06 --> Final output sent to browser
DEBUG - 2016-03-04 20:12:06 --> Total execution time: 1.1960
INFO - 2016-03-04 17:12:29 --> Config Class Initialized
INFO - 2016-03-04 17:12:29 --> Hooks Class Initialized
DEBUG - 2016-03-04 17:12:29 --> UTF-8 Support Enabled
INFO - 2016-03-04 17:12:29 --> Utf8 Class Initialized
INFO - 2016-03-04 17:12:29 --> URI Class Initialized
DEBUG - 2016-03-04 17:12:29 --> No URI present. Default controller set.
INFO - 2016-03-04 17:12:29 --> Router Class Initialized
INFO - 2016-03-04 17:12:29 --> Output Class Initialized
INFO - 2016-03-04 17:12:29 --> Security Class Initialized
DEBUG - 2016-03-04 17:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 17:12:29 --> Input Class Initialized
INFO - 2016-03-04 17:12:29 --> Language Class Initialized
INFO - 2016-03-04 17:12:29 --> Loader Class Initialized
INFO - 2016-03-04 17:12:29 --> Helper loaded: url_helper
INFO - 2016-03-04 17:12:29 --> Helper loaded: file_helper
INFO - 2016-03-04 17:12:29 --> Helper loaded: date_helper
INFO - 2016-03-04 17:12:29 --> Helper loaded: form_helper
INFO - 2016-03-04 17:12:29 --> Database Driver Class Initialized
INFO - 2016-03-04 17:12:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 17:12:30 --> Controller Class Initialized
INFO - 2016-03-04 17:12:30 --> Model Class Initialized
INFO - 2016-03-04 17:12:30 --> Model Class Initialized
INFO - 2016-03-04 17:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 17:12:30 --> Pagination Class Initialized
INFO - 2016-03-04 17:12:30 --> Helper loaded: text_helper
INFO - 2016-03-04 17:12:30 --> Helper loaded: cookie_helper
INFO - 2016-03-04 20:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 20:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 20:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-04 20:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 20:12:30 --> Final output sent to browser
DEBUG - 2016-03-04 20:12:30 --> Total execution time: 1.1195
INFO - 2016-03-04 17:12:37 --> Config Class Initialized
INFO - 2016-03-04 17:12:37 --> Hooks Class Initialized
DEBUG - 2016-03-04 17:12:37 --> UTF-8 Support Enabled
INFO - 2016-03-04 17:12:37 --> Utf8 Class Initialized
INFO - 2016-03-04 17:12:37 --> URI Class Initialized
INFO - 2016-03-04 17:12:37 --> Router Class Initialized
INFO - 2016-03-04 17:12:37 --> Output Class Initialized
INFO - 2016-03-04 17:12:37 --> Security Class Initialized
DEBUG - 2016-03-04 17:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 17:12:37 --> Input Class Initialized
INFO - 2016-03-04 17:12:37 --> Language Class Initialized
INFO - 2016-03-04 17:12:37 --> Loader Class Initialized
INFO - 2016-03-04 17:12:37 --> Helper loaded: url_helper
INFO - 2016-03-04 17:12:37 --> Helper loaded: file_helper
INFO - 2016-03-04 17:12:37 --> Helper loaded: date_helper
INFO - 2016-03-04 17:12:37 --> Helper loaded: form_helper
INFO - 2016-03-04 17:12:37 --> Database Driver Class Initialized
INFO - 2016-03-04 17:12:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 17:12:38 --> Controller Class Initialized
INFO - 2016-03-04 17:12:38 --> Model Class Initialized
INFO - 2016-03-04 17:12:38 --> Model Class Initialized
INFO - 2016-03-04 17:12:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 17:12:38 --> Pagination Class Initialized
INFO - 2016-03-04 17:12:38 --> Helper loaded: text_helper
INFO - 2016-03-04 17:12:38 --> Helper loaded: cookie_helper
INFO - 2016-03-04 20:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 20:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 20:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-04 20:12:38 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
ERROR - 2016-03-04 20:12:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 25
INFO - 2016-03-04 20:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-04 20:12:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 20:12:38 --> Final output sent to browser
DEBUG - 2016-03-04 20:12:38 --> Total execution time: 1.1212
INFO - 2016-03-04 17:12:45 --> Config Class Initialized
INFO - 2016-03-04 17:12:45 --> Hooks Class Initialized
DEBUG - 2016-03-04 17:12:45 --> UTF-8 Support Enabled
INFO - 2016-03-04 17:12:45 --> Utf8 Class Initialized
INFO - 2016-03-04 17:12:45 --> URI Class Initialized
INFO - 2016-03-04 17:12:45 --> Router Class Initialized
INFO - 2016-03-04 17:12:45 --> Output Class Initialized
INFO - 2016-03-04 17:12:45 --> Security Class Initialized
DEBUG - 2016-03-04 17:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-04 17:12:45 --> Input Class Initialized
INFO - 2016-03-04 17:12:45 --> Language Class Initialized
INFO - 2016-03-04 17:12:45 --> Loader Class Initialized
INFO - 2016-03-04 17:12:45 --> Helper loaded: url_helper
INFO - 2016-03-04 17:12:45 --> Helper loaded: file_helper
INFO - 2016-03-04 17:12:45 --> Helper loaded: date_helper
INFO - 2016-03-04 17:12:45 --> Helper loaded: form_helper
INFO - 2016-03-04 17:12:45 --> Database Driver Class Initialized
INFO - 2016-03-04 17:12:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-04 17:12:46 --> Controller Class Initialized
INFO - 2016-03-04 17:12:46 --> Model Class Initialized
INFO - 2016-03-04 17:12:46 --> Model Class Initialized
INFO - 2016-03-04 17:12:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-04 17:12:46 --> Pagination Class Initialized
INFO - 2016-03-04 17:12:46 --> Helper loaded: text_helper
INFO - 2016-03-04 17:12:46 --> Helper loaded: cookie_helper
INFO - 2016-03-04 20:12:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-04 20:12:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-04 20:12:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-04 20:12:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-04 20:12:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-04 20:12:46 --> Final output sent to browser
DEBUG - 2016-03-04 20:12:46 --> Total execution time: 1.1947
