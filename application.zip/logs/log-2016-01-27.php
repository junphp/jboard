<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-27 06:03:31 --> Config Class Initialized
INFO - 2016-01-27 06:03:31 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:03:31 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:03:31 --> Utf8 Class Initialized
INFO - 2016-01-27 06:03:31 --> URI Class Initialized
INFO - 2016-01-27 06:03:31 --> Router Class Initialized
INFO - 2016-01-27 06:03:31 --> Output Class Initialized
INFO - 2016-01-27 06:03:31 --> Security Class Initialized
DEBUG - 2016-01-27 06:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:03:31 --> Input Class Initialized
INFO - 2016-01-27 06:03:31 --> Language Class Initialized
INFO - 2016-01-27 06:03:31 --> Loader Class Initialized
INFO - 2016-01-27 06:03:31 --> Helper loaded: url_helper
INFO - 2016-01-27 06:03:31 --> Helper loaded: file_helper
INFO - 2016-01-27 06:03:31 --> Helper loaded: date_helper
INFO - 2016-01-27 06:03:31 --> Database Driver Class Initialized
INFO - 2016-01-27 06:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:03:33 --> Controller Class Initialized
INFO - 2016-01-27 06:03:33 --> Model Class Initialized
INFO - 2016-01-27 06:03:33 --> Model Class Initialized
INFO - 2016-01-27 06:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:03:33 --> Pagination Class Initialized
INFO - 2016-01-27 06:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:03:33 --> Final output sent to browser
DEBUG - 2016-01-27 06:03:33 --> Total execution time: 1.8981
INFO - 2016-01-27 06:05:40 --> Config Class Initialized
INFO - 2016-01-27 06:05:40 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:05:40 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:05:40 --> Utf8 Class Initialized
INFO - 2016-01-27 06:05:40 --> URI Class Initialized
INFO - 2016-01-27 06:05:40 --> Router Class Initialized
INFO - 2016-01-27 06:05:40 --> Output Class Initialized
INFO - 2016-01-27 06:05:40 --> Security Class Initialized
DEBUG - 2016-01-27 06:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:05:40 --> Input Class Initialized
INFO - 2016-01-27 06:05:40 --> Language Class Initialized
INFO - 2016-01-27 06:05:40 --> Loader Class Initialized
INFO - 2016-01-27 06:05:40 --> Helper loaded: url_helper
INFO - 2016-01-27 06:05:40 --> Helper loaded: file_helper
INFO - 2016-01-27 06:05:40 --> Helper loaded: date_helper
INFO - 2016-01-27 06:05:40 --> Database Driver Class Initialized
INFO - 2016-01-27 06:05:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:05:41 --> Controller Class Initialized
INFO - 2016-01-27 06:05:41 --> Model Class Initialized
INFO - 2016-01-27 06:05:41 --> Model Class Initialized
INFO - 2016-01-27 06:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:05:41 --> Pagination Class Initialized
INFO - 2016-01-27 06:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:05:41 --> Final output sent to browser
DEBUG - 2016-01-27 06:05:41 --> Total execution time: 1.1289
INFO - 2016-01-27 06:12:34 --> Config Class Initialized
INFO - 2016-01-27 06:12:34 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:12:34 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:12:34 --> Utf8 Class Initialized
INFO - 2016-01-27 06:12:34 --> URI Class Initialized
INFO - 2016-01-27 06:12:34 --> Router Class Initialized
INFO - 2016-01-27 06:12:34 --> Output Class Initialized
INFO - 2016-01-27 06:12:34 --> Security Class Initialized
DEBUG - 2016-01-27 06:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:12:34 --> Input Class Initialized
INFO - 2016-01-27 06:12:34 --> Language Class Initialized
INFO - 2016-01-27 06:12:34 --> Loader Class Initialized
INFO - 2016-01-27 06:12:34 --> Helper loaded: url_helper
INFO - 2016-01-27 06:12:34 --> Helper loaded: file_helper
INFO - 2016-01-27 06:12:34 --> Helper loaded: date_helper
INFO - 2016-01-27 06:12:34 --> Database Driver Class Initialized
INFO - 2016-01-27 06:12:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:12:35 --> Controller Class Initialized
INFO - 2016-01-27 06:12:35 --> Model Class Initialized
INFO - 2016-01-27 06:12:35 --> Model Class Initialized
INFO - 2016-01-27 06:12:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:12:35 --> Pagination Class Initialized
INFO - 2016-01-27 06:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:12:35 --> Final output sent to browser
DEBUG - 2016-01-27 06:12:35 --> Total execution time: 1.1442
INFO - 2016-01-27 06:14:17 --> Config Class Initialized
INFO - 2016-01-27 06:14:17 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:14:17 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:14:17 --> Utf8 Class Initialized
INFO - 2016-01-27 06:14:17 --> URI Class Initialized
INFO - 2016-01-27 06:14:17 --> Router Class Initialized
INFO - 2016-01-27 06:14:17 --> Output Class Initialized
INFO - 2016-01-27 06:14:17 --> Security Class Initialized
DEBUG - 2016-01-27 06:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:14:17 --> Input Class Initialized
INFO - 2016-01-27 06:14:17 --> Language Class Initialized
INFO - 2016-01-27 06:14:17 --> Loader Class Initialized
INFO - 2016-01-27 06:14:17 --> Helper loaded: url_helper
INFO - 2016-01-27 06:14:17 --> Helper loaded: file_helper
INFO - 2016-01-27 06:14:17 --> Helper loaded: date_helper
INFO - 2016-01-27 06:14:17 --> Database Driver Class Initialized
INFO - 2016-01-27 06:14:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:14:18 --> Controller Class Initialized
INFO - 2016-01-27 06:14:18 --> Model Class Initialized
INFO - 2016-01-27 06:14:18 --> Model Class Initialized
INFO - 2016-01-27 06:14:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:14:18 --> Pagination Class Initialized
INFO - 2016-01-27 06:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:14:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:14:18 --> Final output sent to browser
DEBUG - 2016-01-27 06:14:18 --> Total execution time: 1.1183
INFO - 2016-01-27 06:15:12 --> Config Class Initialized
INFO - 2016-01-27 06:15:12 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:15:12 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:15:12 --> Utf8 Class Initialized
INFO - 2016-01-27 06:15:12 --> URI Class Initialized
INFO - 2016-01-27 06:15:12 --> Router Class Initialized
INFO - 2016-01-27 06:15:12 --> Output Class Initialized
INFO - 2016-01-27 06:15:12 --> Security Class Initialized
DEBUG - 2016-01-27 06:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:15:12 --> Input Class Initialized
INFO - 2016-01-27 06:15:12 --> Language Class Initialized
INFO - 2016-01-27 06:15:12 --> Loader Class Initialized
INFO - 2016-01-27 06:15:12 --> Helper loaded: url_helper
INFO - 2016-01-27 06:15:12 --> Helper loaded: file_helper
INFO - 2016-01-27 06:15:12 --> Helper loaded: date_helper
INFO - 2016-01-27 06:15:12 --> Database Driver Class Initialized
INFO - 2016-01-27 06:15:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:15:13 --> Controller Class Initialized
INFO - 2016-01-27 06:15:13 --> Model Class Initialized
INFO - 2016-01-27 06:15:13 --> Model Class Initialized
INFO - 2016-01-27 06:15:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:15:13 --> Pagination Class Initialized
INFO - 2016-01-27 06:15:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:15:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:15:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:15:13 --> Final output sent to browser
DEBUG - 2016-01-27 06:15:13 --> Total execution time: 1.1909
INFO - 2016-01-27 06:17:17 --> Config Class Initialized
INFO - 2016-01-27 06:17:17 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:17:17 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:17:17 --> Utf8 Class Initialized
INFO - 2016-01-27 06:17:17 --> URI Class Initialized
INFO - 2016-01-27 06:17:17 --> Router Class Initialized
INFO - 2016-01-27 06:17:17 --> Output Class Initialized
INFO - 2016-01-27 06:17:17 --> Security Class Initialized
DEBUG - 2016-01-27 06:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:17:17 --> Input Class Initialized
INFO - 2016-01-27 06:17:17 --> Language Class Initialized
INFO - 2016-01-27 06:17:17 --> Loader Class Initialized
INFO - 2016-01-27 06:17:17 --> Helper loaded: url_helper
INFO - 2016-01-27 06:17:17 --> Helper loaded: file_helper
INFO - 2016-01-27 06:17:17 --> Helper loaded: date_helper
INFO - 2016-01-27 06:17:17 --> Database Driver Class Initialized
INFO - 2016-01-27 06:17:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:17:18 --> Controller Class Initialized
INFO - 2016-01-27 06:17:18 --> Model Class Initialized
INFO - 2016-01-27 06:17:18 --> Model Class Initialized
INFO - 2016-01-27 06:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:17:18 --> Pagination Class Initialized
INFO - 2016-01-27 06:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:17:19 --> Final output sent to browser
DEBUG - 2016-01-27 06:17:19 --> Total execution time: 1.2341
INFO - 2016-01-27 06:17:57 --> Config Class Initialized
INFO - 2016-01-27 06:17:57 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:17:57 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:17:57 --> Utf8 Class Initialized
INFO - 2016-01-27 06:17:57 --> URI Class Initialized
INFO - 2016-01-27 06:17:57 --> Router Class Initialized
INFO - 2016-01-27 06:17:57 --> Output Class Initialized
INFO - 2016-01-27 06:17:57 --> Security Class Initialized
DEBUG - 2016-01-27 06:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:17:57 --> Input Class Initialized
INFO - 2016-01-27 06:17:57 --> Language Class Initialized
INFO - 2016-01-27 06:17:57 --> Loader Class Initialized
INFO - 2016-01-27 06:17:57 --> Helper loaded: url_helper
INFO - 2016-01-27 06:17:57 --> Helper loaded: file_helper
INFO - 2016-01-27 06:17:57 --> Helper loaded: date_helper
INFO - 2016-01-27 06:17:57 --> Database Driver Class Initialized
INFO - 2016-01-27 06:17:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:17:58 --> Controller Class Initialized
INFO - 2016-01-27 06:17:58 --> Model Class Initialized
INFO - 2016-01-27 06:17:58 --> Model Class Initialized
INFO - 2016-01-27 06:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:17:58 --> Pagination Class Initialized
INFO - 2016-01-27 06:17:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:17:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:17:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:17:58 --> Final output sent to browser
DEBUG - 2016-01-27 06:17:58 --> Total execution time: 1.1505
INFO - 2016-01-27 06:18:31 --> Config Class Initialized
INFO - 2016-01-27 06:18:31 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:18:31 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:18:31 --> Utf8 Class Initialized
INFO - 2016-01-27 06:18:31 --> URI Class Initialized
INFO - 2016-01-27 06:18:31 --> Router Class Initialized
INFO - 2016-01-27 06:18:31 --> Output Class Initialized
INFO - 2016-01-27 06:18:31 --> Security Class Initialized
DEBUG - 2016-01-27 06:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:18:31 --> Input Class Initialized
INFO - 2016-01-27 06:18:31 --> Language Class Initialized
INFO - 2016-01-27 06:18:31 --> Loader Class Initialized
INFO - 2016-01-27 06:18:31 --> Helper loaded: url_helper
INFO - 2016-01-27 06:18:31 --> Helper loaded: file_helper
INFO - 2016-01-27 06:18:31 --> Helper loaded: date_helper
INFO - 2016-01-27 06:18:31 --> Database Driver Class Initialized
INFO - 2016-01-27 06:18:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:18:32 --> Controller Class Initialized
INFO - 2016-01-27 06:18:32 --> Model Class Initialized
INFO - 2016-01-27 06:18:32 --> Model Class Initialized
INFO - 2016-01-27 06:18:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:18:32 --> Pagination Class Initialized
INFO - 2016-01-27 06:18:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:18:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:18:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:18:32 --> Final output sent to browser
DEBUG - 2016-01-27 06:18:32 --> Total execution time: 1.1560
INFO - 2016-01-27 06:18:57 --> Config Class Initialized
INFO - 2016-01-27 06:18:57 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:18:57 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:18:57 --> Utf8 Class Initialized
INFO - 2016-01-27 06:18:57 --> URI Class Initialized
INFO - 2016-01-27 06:18:57 --> Router Class Initialized
INFO - 2016-01-27 06:18:57 --> Output Class Initialized
INFO - 2016-01-27 06:18:57 --> Security Class Initialized
DEBUG - 2016-01-27 06:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:18:57 --> Input Class Initialized
INFO - 2016-01-27 06:18:57 --> Language Class Initialized
INFO - 2016-01-27 06:18:57 --> Loader Class Initialized
INFO - 2016-01-27 06:18:57 --> Helper loaded: url_helper
INFO - 2016-01-27 06:18:57 --> Helper loaded: file_helper
INFO - 2016-01-27 06:18:57 --> Helper loaded: date_helper
INFO - 2016-01-27 06:18:57 --> Database Driver Class Initialized
INFO - 2016-01-27 06:18:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:18:58 --> Controller Class Initialized
INFO - 2016-01-27 06:18:58 --> Model Class Initialized
INFO - 2016-01-27 06:18:58 --> Model Class Initialized
INFO - 2016-01-27 06:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:18:58 --> Pagination Class Initialized
INFO - 2016-01-27 06:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:18:58 --> Final output sent to browser
DEBUG - 2016-01-27 06:18:58 --> Total execution time: 1.1795
INFO - 2016-01-27 06:19:54 --> Config Class Initialized
INFO - 2016-01-27 06:19:54 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:19:54 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:19:54 --> Utf8 Class Initialized
INFO - 2016-01-27 06:19:54 --> URI Class Initialized
DEBUG - 2016-01-27 06:19:54 --> No URI present. Default controller set.
INFO - 2016-01-27 06:19:54 --> Router Class Initialized
INFO - 2016-01-27 06:19:54 --> Output Class Initialized
INFO - 2016-01-27 06:19:54 --> Security Class Initialized
DEBUG - 2016-01-27 06:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:19:54 --> Input Class Initialized
INFO - 2016-01-27 06:19:54 --> Language Class Initialized
INFO - 2016-01-27 06:19:54 --> Loader Class Initialized
INFO - 2016-01-27 06:19:54 --> Helper loaded: url_helper
INFO - 2016-01-27 06:19:54 --> Helper loaded: file_helper
INFO - 2016-01-27 06:19:54 --> Helper loaded: date_helper
INFO - 2016-01-27 06:19:54 --> Database Driver Class Initialized
INFO - 2016-01-27 06:19:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:19:55 --> Controller Class Initialized
INFO - 2016-01-27 06:19:55 --> Model Class Initialized
INFO - 2016-01-27 06:19:55 --> Model Class Initialized
INFO - 2016-01-27 06:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:19:55 --> Pagination Class Initialized
INFO - 2016-01-27 06:19:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:19:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 06:19:55 --> Final output sent to browser
DEBUG - 2016-01-27 06:19:55 --> Total execution time: 1.3332
INFO - 2016-01-27 06:19:58 --> Config Class Initialized
INFO - 2016-01-27 06:19:58 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:19:58 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:19:58 --> Utf8 Class Initialized
INFO - 2016-01-27 06:19:58 --> URI Class Initialized
INFO - 2016-01-27 06:19:58 --> Router Class Initialized
INFO - 2016-01-27 06:19:58 --> Output Class Initialized
INFO - 2016-01-27 06:19:58 --> Security Class Initialized
DEBUG - 2016-01-27 06:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:19:58 --> Input Class Initialized
INFO - 2016-01-27 06:19:58 --> Language Class Initialized
INFO - 2016-01-27 06:19:58 --> Loader Class Initialized
INFO - 2016-01-27 06:19:58 --> Helper loaded: url_helper
INFO - 2016-01-27 06:19:58 --> Helper loaded: file_helper
INFO - 2016-01-27 06:19:58 --> Helper loaded: date_helper
INFO - 2016-01-27 06:19:58 --> Database Driver Class Initialized
INFO - 2016-01-27 06:19:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:19:59 --> Controller Class Initialized
INFO - 2016-01-27 06:19:59 --> Model Class Initialized
INFO - 2016-01-27 06:19:59 --> Model Class Initialized
INFO - 2016-01-27 06:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:19:59 --> Pagination Class Initialized
INFO - 2016-01-27 06:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:19:59 --> Final output sent to browser
DEBUG - 2016-01-27 06:19:59 --> Total execution time: 1.1394
INFO - 2016-01-27 06:20:30 --> Config Class Initialized
INFO - 2016-01-27 06:20:30 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:20:30 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:20:30 --> Utf8 Class Initialized
INFO - 2016-01-27 06:20:30 --> URI Class Initialized
DEBUG - 2016-01-27 06:20:30 --> No URI present. Default controller set.
INFO - 2016-01-27 06:20:30 --> Router Class Initialized
INFO - 2016-01-27 06:20:30 --> Output Class Initialized
INFO - 2016-01-27 06:20:30 --> Security Class Initialized
DEBUG - 2016-01-27 06:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:20:30 --> Input Class Initialized
INFO - 2016-01-27 06:20:30 --> Language Class Initialized
INFO - 2016-01-27 06:20:30 --> Loader Class Initialized
INFO - 2016-01-27 06:20:30 --> Helper loaded: url_helper
INFO - 2016-01-27 06:20:30 --> Helper loaded: file_helper
INFO - 2016-01-27 06:20:30 --> Helper loaded: date_helper
INFO - 2016-01-27 06:20:30 --> Database Driver Class Initialized
INFO - 2016-01-27 06:20:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:20:31 --> Controller Class Initialized
INFO - 2016-01-27 06:20:31 --> Model Class Initialized
INFO - 2016-01-27 06:20:31 --> Model Class Initialized
INFO - 2016-01-27 06:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:20:31 --> Pagination Class Initialized
INFO - 2016-01-27 06:20:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:20:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 06:20:31 --> Final output sent to browser
DEBUG - 2016-01-27 06:20:31 --> Total execution time: 1.0661
INFO - 2016-01-27 06:20:34 --> Config Class Initialized
INFO - 2016-01-27 06:20:34 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:20:34 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:20:34 --> Utf8 Class Initialized
INFO - 2016-01-27 06:20:34 --> URI Class Initialized
INFO - 2016-01-27 06:20:34 --> Router Class Initialized
INFO - 2016-01-27 06:20:34 --> Output Class Initialized
INFO - 2016-01-27 06:20:34 --> Security Class Initialized
DEBUG - 2016-01-27 06:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:20:34 --> Input Class Initialized
INFO - 2016-01-27 06:20:34 --> Language Class Initialized
INFO - 2016-01-27 06:20:34 --> Loader Class Initialized
INFO - 2016-01-27 06:20:34 --> Helper loaded: url_helper
INFO - 2016-01-27 06:20:34 --> Helper loaded: file_helper
INFO - 2016-01-27 06:20:34 --> Helper loaded: date_helper
INFO - 2016-01-27 06:20:34 --> Database Driver Class Initialized
INFO - 2016-01-27 06:20:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:20:35 --> Controller Class Initialized
INFO - 2016-01-27 06:20:35 --> Model Class Initialized
INFO - 2016-01-27 06:20:35 --> Model Class Initialized
INFO - 2016-01-27 06:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:20:35 --> Pagination Class Initialized
INFO - 2016-01-27 06:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:20:35 --> Final output sent to browser
DEBUG - 2016-01-27 06:20:35 --> Total execution time: 1.1246
INFO - 2016-01-27 06:20:55 --> Config Class Initialized
INFO - 2016-01-27 06:20:55 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:20:55 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:20:55 --> Utf8 Class Initialized
INFO - 2016-01-27 06:20:55 --> URI Class Initialized
DEBUG - 2016-01-27 06:20:55 --> No URI present. Default controller set.
INFO - 2016-01-27 06:20:55 --> Router Class Initialized
INFO - 2016-01-27 06:20:55 --> Output Class Initialized
INFO - 2016-01-27 06:20:55 --> Security Class Initialized
DEBUG - 2016-01-27 06:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:20:55 --> Input Class Initialized
INFO - 2016-01-27 06:20:55 --> Language Class Initialized
INFO - 2016-01-27 06:20:55 --> Loader Class Initialized
INFO - 2016-01-27 06:20:55 --> Helper loaded: url_helper
INFO - 2016-01-27 06:20:55 --> Helper loaded: file_helper
INFO - 2016-01-27 06:20:55 --> Helper loaded: date_helper
INFO - 2016-01-27 06:20:55 --> Database Driver Class Initialized
INFO - 2016-01-27 06:20:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:20:56 --> Controller Class Initialized
INFO - 2016-01-27 06:20:56 --> Model Class Initialized
INFO - 2016-01-27 06:20:56 --> Model Class Initialized
INFO - 2016-01-27 06:20:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:20:56 --> Pagination Class Initialized
INFO - 2016-01-27 06:20:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:20:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 06:20:56 --> Final output sent to browser
DEBUG - 2016-01-27 06:20:56 --> Total execution time: 1.1270
INFO - 2016-01-27 06:20:58 --> Config Class Initialized
INFO - 2016-01-27 06:20:58 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:20:58 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:20:58 --> Utf8 Class Initialized
INFO - 2016-01-27 06:20:58 --> URI Class Initialized
INFO - 2016-01-27 06:20:58 --> Router Class Initialized
INFO - 2016-01-27 06:20:58 --> Output Class Initialized
INFO - 2016-01-27 06:20:58 --> Security Class Initialized
DEBUG - 2016-01-27 06:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:20:58 --> Input Class Initialized
INFO - 2016-01-27 06:20:58 --> Language Class Initialized
INFO - 2016-01-27 06:20:58 --> Loader Class Initialized
INFO - 2016-01-27 06:20:58 --> Helper loaded: url_helper
INFO - 2016-01-27 06:20:58 --> Helper loaded: file_helper
INFO - 2016-01-27 06:20:58 --> Helper loaded: date_helper
INFO - 2016-01-27 06:20:58 --> Database Driver Class Initialized
INFO - 2016-01-27 06:20:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:20:59 --> Controller Class Initialized
INFO - 2016-01-27 06:20:59 --> Model Class Initialized
INFO - 2016-01-27 06:20:59 --> Model Class Initialized
INFO - 2016-01-27 06:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:20:59 --> Pagination Class Initialized
INFO - 2016-01-27 06:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:20:59 --> Final output sent to browser
DEBUG - 2016-01-27 06:20:59 --> Total execution time: 1.1704
INFO - 2016-01-27 06:21:29 --> Config Class Initialized
INFO - 2016-01-27 06:21:29 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:21:29 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:21:29 --> Utf8 Class Initialized
INFO - 2016-01-27 06:21:29 --> URI Class Initialized
INFO - 2016-01-27 06:21:29 --> Router Class Initialized
INFO - 2016-01-27 06:21:29 --> Output Class Initialized
INFO - 2016-01-27 06:21:29 --> Security Class Initialized
DEBUG - 2016-01-27 06:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:21:29 --> Input Class Initialized
INFO - 2016-01-27 06:21:29 --> Language Class Initialized
INFO - 2016-01-27 06:21:29 --> Loader Class Initialized
INFO - 2016-01-27 06:21:29 --> Helper loaded: url_helper
INFO - 2016-01-27 06:21:29 --> Helper loaded: file_helper
INFO - 2016-01-27 06:21:29 --> Helper loaded: date_helper
INFO - 2016-01-27 06:21:29 --> Database Driver Class Initialized
INFO - 2016-01-27 06:21:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:21:30 --> Controller Class Initialized
INFO - 2016-01-27 06:21:30 --> Model Class Initialized
INFO - 2016-01-27 06:21:30 --> Model Class Initialized
INFO - 2016-01-27 06:21:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:21:30 --> Pagination Class Initialized
INFO - 2016-01-27 06:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:21:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:21:30 --> Final output sent to browser
DEBUG - 2016-01-27 06:21:30 --> Total execution time: 1.1700
INFO - 2016-01-27 06:21:42 --> Config Class Initialized
INFO - 2016-01-27 06:21:42 --> Hooks Class Initialized
DEBUG - 2016-01-27 06:21:42 --> UTF-8 Support Enabled
INFO - 2016-01-27 06:21:42 --> Utf8 Class Initialized
INFO - 2016-01-27 06:21:42 --> URI Class Initialized
INFO - 2016-01-27 06:21:42 --> Router Class Initialized
INFO - 2016-01-27 06:21:42 --> Output Class Initialized
INFO - 2016-01-27 06:21:42 --> Security Class Initialized
DEBUG - 2016-01-27 06:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 06:21:42 --> Input Class Initialized
INFO - 2016-01-27 06:21:42 --> Language Class Initialized
INFO - 2016-01-27 06:21:42 --> Loader Class Initialized
INFO - 2016-01-27 06:21:42 --> Helper loaded: url_helper
INFO - 2016-01-27 06:21:42 --> Helper loaded: file_helper
INFO - 2016-01-27 06:21:42 --> Helper loaded: date_helper
INFO - 2016-01-27 06:21:42 --> Database Driver Class Initialized
INFO - 2016-01-27 06:21:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 06:21:43 --> Controller Class Initialized
INFO - 2016-01-27 06:21:43 --> Model Class Initialized
INFO - 2016-01-27 06:21:43 --> Model Class Initialized
INFO - 2016-01-27 06:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 06:21:43 --> Pagination Class Initialized
INFO - 2016-01-27 06:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 06:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 06:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 06:21:43 --> Final output sent to browser
DEBUG - 2016-01-27 06:21:43 --> Total execution time: 1.1077
INFO - 2016-01-27 07:27:49 --> Config Class Initialized
INFO - 2016-01-27 07:27:49 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:27:49 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:27:49 --> Utf8 Class Initialized
INFO - 2016-01-27 07:27:49 --> URI Class Initialized
INFO - 2016-01-27 07:27:49 --> Router Class Initialized
INFO - 2016-01-27 07:27:49 --> Output Class Initialized
INFO - 2016-01-27 07:27:49 --> Security Class Initialized
DEBUG - 2016-01-27 07:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:27:49 --> Input Class Initialized
INFO - 2016-01-27 07:27:49 --> Language Class Initialized
INFO - 2016-01-27 07:27:49 --> Loader Class Initialized
INFO - 2016-01-27 07:27:49 --> Helper loaded: url_helper
INFO - 2016-01-27 07:27:49 --> Helper loaded: file_helper
INFO - 2016-01-27 07:27:49 --> Helper loaded: date_helper
INFO - 2016-01-27 07:27:49 --> Database Driver Class Initialized
INFO - 2016-01-27 07:27:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:27:50 --> Controller Class Initialized
INFO - 2016-01-27 07:27:50 --> Model Class Initialized
INFO - 2016-01-27 07:27:50 --> Model Class Initialized
INFO - 2016-01-27 07:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:27:50 --> Pagination Class Initialized
INFO - 2016-01-27 07:27:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:27:50 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:27:50 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:28:45 --> Config Class Initialized
INFO - 2016-01-27 07:28:45 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:28:45 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:28:45 --> Utf8 Class Initialized
INFO - 2016-01-27 07:28:45 --> URI Class Initialized
INFO - 2016-01-27 07:28:45 --> Router Class Initialized
INFO - 2016-01-27 07:28:45 --> Output Class Initialized
INFO - 2016-01-27 07:28:45 --> Security Class Initialized
DEBUG - 2016-01-27 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:28:45 --> Input Class Initialized
INFO - 2016-01-27 07:28:45 --> Language Class Initialized
INFO - 2016-01-27 07:28:45 --> Loader Class Initialized
INFO - 2016-01-27 07:28:45 --> Helper loaded: url_helper
INFO - 2016-01-27 07:28:45 --> Helper loaded: file_helper
INFO - 2016-01-27 07:28:45 --> Helper loaded: date_helper
INFO - 2016-01-27 07:28:45 --> Database Driver Class Initialized
INFO - 2016-01-27 07:28:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:28:46 --> Controller Class Initialized
INFO - 2016-01-27 07:28:46 --> Model Class Initialized
INFO - 2016-01-27 07:28:46 --> Model Class Initialized
INFO - 2016-01-27 07:28:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:28:46 --> Pagination Class Initialized
INFO - 2016-01-27 07:28:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:28:46 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:28:46 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:32:16 --> Config Class Initialized
INFO - 2016-01-27 07:32:16 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:32:16 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:32:16 --> Utf8 Class Initialized
INFO - 2016-01-27 07:32:16 --> URI Class Initialized
INFO - 2016-01-27 07:32:16 --> Router Class Initialized
INFO - 2016-01-27 07:32:16 --> Output Class Initialized
INFO - 2016-01-27 07:32:16 --> Security Class Initialized
DEBUG - 2016-01-27 07:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:32:16 --> Input Class Initialized
INFO - 2016-01-27 07:32:16 --> Language Class Initialized
INFO - 2016-01-27 07:32:16 --> Loader Class Initialized
INFO - 2016-01-27 07:32:16 --> Helper loaded: url_helper
INFO - 2016-01-27 07:32:16 --> Helper loaded: file_helper
INFO - 2016-01-27 07:32:16 --> Helper loaded: date_helper
INFO - 2016-01-27 07:32:16 --> Database Driver Class Initialized
INFO - 2016-01-27 07:32:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:32:17 --> Controller Class Initialized
INFO - 2016-01-27 07:32:17 --> Model Class Initialized
INFO - 2016-01-27 07:32:17 --> Model Class Initialized
INFO - 2016-01-27 07:32:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:32:17 --> Pagination Class Initialized
INFO - 2016-01-27 07:32:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:32:17 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:32:17 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:34:48 --> Config Class Initialized
INFO - 2016-01-27 07:34:48 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:34:48 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:34:48 --> Utf8 Class Initialized
INFO - 2016-01-27 07:34:48 --> URI Class Initialized
INFO - 2016-01-27 07:34:48 --> Router Class Initialized
INFO - 2016-01-27 07:34:48 --> Output Class Initialized
INFO - 2016-01-27 07:34:48 --> Security Class Initialized
DEBUG - 2016-01-27 07:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:34:48 --> Input Class Initialized
INFO - 2016-01-27 07:34:48 --> Language Class Initialized
INFO - 2016-01-27 07:34:48 --> Loader Class Initialized
INFO - 2016-01-27 07:34:48 --> Helper loaded: url_helper
INFO - 2016-01-27 07:34:48 --> Helper loaded: file_helper
INFO - 2016-01-27 07:34:48 --> Helper loaded: date_helper
INFO - 2016-01-27 07:34:48 --> Database Driver Class Initialized
INFO - 2016-01-27 07:34:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:34:49 --> Controller Class Initialized
INFO - 2016-01-27 07:34:49 --> Model Class Initialized
INFO - 2016-01-27 07:34:49 --> Model Class Initialized
INFO - 2016-01-27 07:34:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:34:49 --> Pagination Class Initialized
INFO - 2016-01-27 07:34:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:34:49 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:34:49 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:36:50 --> Config Class Initialized
INFO - 2016-01-27 07:36:50 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:36:50 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:36:50 --> Utf8 Class Initialized
INFO - 2016-01-27 07:36:50 --> URI Class Initialized
INFO - 2016-01-27 07:36:50 --> Router Class Initialized
INFO - 2016-01-27 07:36:50 --> Output Class Initialized
INFO - 2016-01-27 07:36:50 --> Security Class Initialized
DEBUG - 2016-01-27 07:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:36:50 --> Input Class Initialized
INFO - 2016-01-27 07:36:50 --> Language Class Initialized
INFO - 2016-01-27 07:36:50 --> Loader Class Initialized
INFO - 2016-01-27 07:36:50 --> Helper loaded: url_helper
INFO - 2016-01-27 07:36:50 --> Helper loaded: file_helper
INFO - 2016-01-27 07:36:50 --> Helper loaded: date_helper
INFO - 2016-01-27 07:36:50 --> Database Driver Class Initialized
INFO - 2016-01-27 07:36:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:36:51 --> Controller Class Initialized
INFO - 2016-01-27 07:36:51 --> Model Class Initialized
INFO - 2016-01-27 07:36:51 --> Model Class Initialized
INFO - 2016-01-27 07:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:36:51 --> Pagination Class Initialized
INFO - 2016-01-27 07:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:36:51 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:36:51 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:37:38 --> Config Class Initialized
INFO - 2016-01-27 07:37:38 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:37:38 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:37:38 --> Utf8 Class Initialized
INFO - 2016-01-27 07:37:38 --> URI Class Initialized
INFO - 2016-01-27 07:37:38 --> Router Class Initialized
INFO - 2016-01-27 07:37:38 --> Output Class Initialized
INFO - 2016-01-27 07:37:38 --> Security Class Initialized
DEBUG - 2016-01-27 07:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:37:38 --> Input Class Initialized
INFO - 2016-01-27 07:37:38 --> Language Class Initialized
INFO - 2016-01-27 07:37:38 --> Loader Class Initialized
INFO - 2016-01-27 07:37:38 --> Helper loaded: url_helper
INFO - 2016-01-27 07:37:38 --> Helper loaded: file_helper
INFO - 2016-01-27 07:37:38 --> Helper loaded: date_helper
INFO - 2016-01-27 07:37:38 --> Database Driver Class Initialized
INFO - 2016-01-27 07:37:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:37:39 --> Controller Class Initialized
INFO - 2016-01-27 07:37:39 --> Model Class Initialized
INFO - 2016-01-27 07:37:39 --> Model Class Initialized
INFO - 2016-01-27 07:37:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:37:39 --> Pagination Class Initialized
INFO - 2016-01-27 07:37:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:37:39 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:37:39 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:37:49 --> Config Class Initialized
INFO - 2016-01-27 07:37:49 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:37:49 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:37:49 --> Utf8 Class Initialized
INFO - 2016-01-27 07:37:49 --> URI Class Initialized
INFO - 2016-01-27 07:37:49 --> Router Class Initialized
INFO - 2016-01-27 07:37:49 --> Output Class Initialized
INFO - 2016-01-27 07:37:49 --> Security Class Initialized
DEBUG - 2016-01-27 07:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:37:49 --> Input Class Initialized
INFO - 2016-01-27 07:37:49 --> Language Class Initialized
INFO - 2016-01-27 07:37:49 --> Loader Class Initialized
INFO - 2016-01-27 07:37:49 --> Helper loaded: url_helper
INFO - 2016-01-27 07:37:49 --> Helper loaded: file_helper
INFO - 2016-01-27 07:37:49 --> Helper loaded: date_helper
INFO - 2016-01-27 07:37:49 --> Database Driver Class Initialized
INFO - 2016-01-27 07:37:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:37:50 --> Controller Class Initialized
INFO - 2016-01-27 07:37:50 --> Model Class Initialized
INFO - 2016-01-27 07:37:50 --> Model Class Initialized
INFO - 2016-01-27 07:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:37:50 --> Pagination Class Initialized
INFO - 2016-01-27 07:37:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:37:50 --> Severity: Notice --> Undefined variable: total_comments C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 37
INFO - 2016-01-27 07:37:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 07:37:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 07:37:50 --> Final output sent to browser
DEBUG - 2016-01-27 07:37:50 --> Total execution time: 1.1802
INFO - 2016-01-27 07:38:00 --> Config Class Initialized
INFO - 2016-01-27 07:38:00 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:38:00 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:38:00 --> Utf8 Class Initialized
INFO - 2016-01-27 07:38:00 --> URI Class Initialized
INFO - 2016-01-27 07:38:00 --> Router Class Initialized
INFO - 2016-01-27 07:38:00 --> Output Class Initialized
INFO - 2016-01-27 07:38:00 --> Security Class Initialized
DEBUG - 2016-01-27 07:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:38:00 --> Input Class Initialized
INFO - 2016-01-27 07:38:00 --> Language Class Initialized
INFO - 2016-01-27 07:38:00 --> Loader Class Initialized
INFO - 2016-01-27 07:38:00 --> Helper loaded: url_helper
INFO - 2016-01-27 07:38:00 --> Helper loaded: file_helper
INFO - 2016-01-27 07:38:00 --> Helper loaded: date_helper
INFO - 2016-01-27 07:38:00 --> Database Driver Class Initialized
INFO - 2016-01-27 07:38:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:38:01 --> Controller Class Initialized
INFO - 2016-01-27 07:38:01 --> Model Class Initialized
INFO - 2016-01-27 07:38:01 --> Model Class Initialized
INFO - 2016-01-27 07:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:38:01 --> Pagination Class Initialized
INFO - 2016-01-27 07:38:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:38:01 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:38:01 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:39:34 --> Config Class Initialized
INFO - 2016-01-27 07:39:34 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:39:34 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:39:34 --> Utf8 Class Initialized
INFO - 2016-01-27 07:39:34 --> URI Class Initialized
INFO - 2016-01-27 07:39:34 --> Router Class Initialized
INFO - 2016-01-27 07:39:34 --> Output Class Initialized
INFO - 2016-01-27 07:39:34 --> Security Class Initialized
DEBUG - 2016-01-27 07:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:39:34 --> Input Class Initialized
INFO - 2016-01-27 07:39:34 --> Language Class Initialized
INFO - 2016-01-27 07:39:34 --> Loader Class Initialized
INFO - 2016-01-27 07:39:34 --> Helper loaded: url_helper
INFO - 2016-01-27 07:39:34 --> Helper loaded: file_helper
INFO - 2016-01-27 07:39:34 --> Helper loaded: date_helper
INFO - 2016-01-27 07:39:34 --> Database Driver Class Initialized
INFO - 2016-01-27 07:39:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:39:35 --> Controller Class Initialized
INFO - 2016-01-27 07:39:35 --> Model Class Initialized
INFO - 2016-01-27 07:39:35 --> Model Class Initialized
INFO - 2016-01-27 07:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:39:35 --> Pagination Class Initialized
INFO - 2016-01-27 07:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:39:35 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:39:35 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:42:15 --> Config Class Initialized
INFO - 2016-01-27 07:42:15 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:42:15 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:42:15 --> Utf8 Class Initialized
INFO - 2016-01-27 07:42:15 --> URI Class Initialized
INFO - 2016-01-27 07:42:15 --> Router Class Initialized
INFO - 2016-01-27 07:42:15 --> Output Class Initialized
INFO - 2016-01-27 07:42:15 --> Security Class Initialized
DEBUG - 2016-01-27 07:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:42:15 --> Input Class Initialized
INFO - 2016-01-27 07:42:15 --> Language Class Initialized
INFO - 2016-01-27 07:42:15 --> Loader Class Initialized
INFO - 2016-01-27 07:42:15 --> Helper loaded: url_helper
INFO - 2016-01-27 07:42:15 --> Helper loaded: file_helper
INFO - 2016-01-27 07:42:15 --> Helper loaded: date_helper
INFO - 2016-01-27 07:42:15 --> Database Driver Class Initialized
INFO - 2016-01-27 07:42:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:42:16 --> Controller Class Initialized
INFO - 2016-01-27 07:42:16 --> Model Class Initialized
ERROR - 2016-01-27 07:42:16 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 42
INFO - 2016-01-27 07:42:33 --> Config Class Initialized
INFO - 2016-01-27 07:42:33 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:42:33 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:42:33 --> Utf8 Class Initialized
INFO - 2016-01-27 07:42:33 --> URI Class Initialized
INFO - 2016-01-27 07:42:33 --> Router Class Initialized
INFO - 2016-01-27 07:42:33 --> Output Class Initialized
INFO - 2016-01-27 07:42:33 --> Security Class Initialized
DEBUG - 2016-01-27 07:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:42:33 --> Input Class Initialized
INFO - 2016-01-27 07:42:33 --> Language Class Initialized
INFO - 2016-01-27 07:42:33 --> Loader Class Initialized
INFO - 2016-01-27 07:42:33 --> Helper loaded: url_helper
INFO - 2016-01-27 07:42:33 --> Helper loaded: file_helper
INFO - 2016-01-27 07:42:33 --> Helper loaded: date_helper
INFO - 2016-01-27 07:42:33 --> Database Driver Class Initialized
INFO - 2016-01-27 07:42:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:42:34 --> Controller Class Initialized
INFO - 2016-01-27 07:42:34 --> Model Class Initialized
INFO - 2016-01-27 07:42:34 --> Model Class Initialized
INFO - 2016-01-27 07:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:42:34 --> Pagination Class Initialized
INFO - 2016-01-27 07:42:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:42:34 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:42:34 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 07:45:02 --> Config Class Initialized
INFO - 2016-01-27 07:45:02 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:45:02 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:45:02 --> Utf8 Class Initialized
INFO - 2016-01-27 07:45:02 --> URI Class Initialized
DEBUG - 2016-01-27 07:45:02 --> No URI present. Default controller set.
INFO - 2016-01-27 07:45:02 --> Router Class Initialized
INFO - 2016-01-27 07:45:02 --> Output Class Initialized
INFO - 2016-01-27 07:45:02 --> Security Class Initialized
DEBUG - 2016-01-27 07:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:45:02 --> Input Class Initialized
INFO - 2016-01-27 07:45:02 --> Language Class Initialized
INFO - 2016-01-27 07:45:02 --> Loader Class Initialized
INFO - 2016-01-27 07:45:02 --> Helper loaded: url_helper
INFO - 2016-01-27 07:45:02 --> Helper loaded: file_helper
INFO - 2016-01-27 07:45:02 --> Helper loaded: date_helper
INFO - 2016-01-27 07:45:02 --> Database Driver Class Initialized
INFO - 2016-01-27 07:45:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:45:03 --> Controller Class Initialized
INFO - 2016-01-27 07:45:03 --> Model Class Initialized
INFO - 2016-01-27 07:45:03 --> Model Class Initialized
INFO - 2016-01-27 07:45:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:45:03 --> Pagination Class Initialized
INFO - 2016-01-27 07:45:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:45:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:45:03 --> Final output sent to browser
DEBUG - 2016-01-27 07:45:03 --> Total execution time: 1.1077
INFO - 2016-01-27 07:47:03 --> Config Class Initialized
INFO - 2016-01-27 07:47:03 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:47:03 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:47:03 --> Utf8 Class Initialized
INFO - 2016-01-27 07:47:03 --> URI Class Initialized
DEBUG - 2016-01-27 07:47:03 --> No URI present. Default controller set.
INFO - 2016-01-27 07:47:03 --> Router Class Initialized
INFO - 2016-01-27 07:47:03 --> Output Class Initialized
INFO - 2016-01-27 07:47:03 --> Security Class Initialized
DEBUG - 2016-01-27 07:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:47:03 --> Input Class Initialized
INFO - 2016-01-27 07:47:03 --> Language Class Initialized
INFO - 2016-01-27 07:47:03 --> Loader Class Initialized
INFO - 2016-01-27 07:47:03 --> Helper loaded: url_helper
INFO - 2016-01-27 07:47:03 --> Helper loaded: file_helper
INFO - 2016-01-27 07:47:03 --> Helper loaded: date_helper
INFO - 2016-01-27 07:47:03 --> Database Driver Class Initialized
INFO - 2016-01-27 07:47:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:47:04 --> Controller Class Initialized
INFO - 2016-01-27 07:47:04 --> Model Class Initialized
INFO - 2016-01-27 07:47:04 --> Model Class Initialized
INFO - 2016-01-27 07:47:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:47:04 --> Pagination Class Initialized
INFO - 2016-01-27 07:47:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:47:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:47:05 --> Final output sent to browser
DEBUG - 2016-01-27 07:47:05 --> Total execution time: 1.1440
INFO - 2016-01-27 07:47:18 --> Config Class Initialized
INFO - 2016-01-27 07:47:18 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:47:18 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:47:18 --> Utf8 Class Initialized
INFO - 2016-01-27 07:47:18 --> URI Class Initialized
DEBUG - 2016-01-27 07:47:18 --> No URI present. Default controller set.
INFO - 2016-01-27 07:47:18 --> Router Class Initialized
INFO - 2016-01-27 07:47:18 --> Output Class Initialized
INFO - 2016-01-27 07:47:18 --> Security Class Initialized
DEBUG - 2016-01-27 07:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:47:18 --> Input Class Initialized
INFO - 2016-01-27 07:47:18 --> Language Class Initialized
INFO - 2016-01-27 07:47:18 --> Loader Class Initialized
INFO - 2016-01-27 07:47:18 --> Helper loaded: url_helper
INFO - 2016-01-27 07:47:18 --> Helper loaded: file_helper
INFO - 2016-01-27 07:47:18 --> Helper loaded: date_helper
INFO - 2016-01-27 07:47:18 --> Database Driver Class Initialized
INFO - 2016-01-27 07:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:47:19 --> Controller Class Initialized
INFO - 2016-01-27 07:47:19 --> Model Class Initialized
INFO - 2016-01-27 07:47:19 --> Model Class Initialized
INFO - 2016-01-27 07:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:47:19 --> Pagination Class Initialized
INFO - 2016-01-27 07:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:47:19 --> Final output sent to browser
DEBUG - 2016-01-27 07:47:19 --> Total execution time: 1.0978
INFO - 2016-01-27 07:48:24 --> Config Class Initialized
INFO - 2016-01-27 07:48:24 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:48:24 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:48:24 --> Utf8 Class Initialized
INFO - 2016-01-27 07:48:24 --> URI Class Initialized
DEBUG - 2016-01-27 07:48:24 --> No URI present. Default controller set.
INFO - 2016-01-27 07:48:24 --> Router Class Initialized
INFO - 2016-01-27 07:48:24 --> Output Class Initialized
INFO - 2016-01-27 07:48:24 --> Security Class Initialized
DEBUG - 2016-01-27 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:48:24 --> Input Class Initialized
INFO - 2016-01-27 07:48:24 --> Language Class Initialized
INFO - 2016-01-27 07:48:24 --> Loader Class Initialized
INFO - 2016-01-27 07:48:24 --> Helper loaded: url_helper
INFO - 2016-01-27 07:48:24 --> Helper loaded: file_helper
INFO - 2016-01-27 07:48:24 --> Helper loaded: date_helper
INFO - 2016-01-27 07:48:24 --> Database Driver Class Initialized
INFO - 2016-01-27 07:48:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:48:25 --> Controller Class Initialized
INFO - 2016-01-27 07:48:25 --> Model Class Initialized
INFO - 2016-01-27 07:48:25 --> Model Class Initialized
INFO - 2016-01-27 07:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:48:25 --> Pagination Class Initialized
INFO - 2016-01-27 07:48:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:48:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:48:25 --> Final output sent to browser
DEBUG - 2016-01-27 07:48:25 --> Total execution time: 1.1033
INFO - 2016-01-27 07:49:27 --> Config Class Initialized
INFO - 2016-01-27 07:49:27 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:49:27 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:49:27 --> Utf8 Class Initialized
INFO - 2016-01-27 07:49:27 --> URI Class Initialized
DEBUG - 2016-01-27 07:49:27 --> No URI present. Default controller set.
INFO - 2016-01-27 07:49:27 --> Router Class Initialized
INFO - 2016-01-27 07:49:27 --> Output Class Initialized
INFO - 2016-01-27 07:49:27 --> Security Class Initialized
DEBUG - 2016-01-27 07:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:49:27 --> Input Class Initialized
INFO - 2016-01-27 07:49:27 --> Language Class Initialized
INFO - 2016-01-27 07:49:27 --> Loader Class Initialized
INFO - 2016-01-27 07:49:27 --> Helper loaded: url_helper
INFO - 2016-01-27 07:49:27 --> Helper loaded: file_helper
INFO - 2016-01-27 07:49:27 --> Helper loaded: date_helper
INFO - 2016-01-27 07:49:27 --> Database Driver Class Initialized
INFO - 2016-01-27 07:49:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:49:28 --> Controller Class Initialized
INFO - 2016-01-27 07:49:28 --> Model Class Initialized
INFO - 2016-01-27 07:49:28 --> Model Class Initialized
INFO - 2016-01-27 07:49:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:49:28 --> Pagination Class Initialized
INFO - 2016-01-27 07:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:49:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:49:29 --> Final output sent to browser
DEBUG - 2016-01-27 07:49:29 --> Total execution time: 1.0862
INFO - 2016-01-27 07:49:57 --> Config Class Initialized
INFO - 2016-01-27 07:49:57 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:49:57 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:49:57 --> Utf8 Class Initialized
INFO - 2016-01-27 07:49:57 --> URI Class Initialized
DEBUG - 2016-01-27 07:49:57 --> No URI present. Default controller set.
INFO - 2016-01-27 07:49:57 --> Router Class Initialized
INFO - 2016-01-27 07:49:57 --> Output Class Initialized
INFO - 2016-01-27 07:49:57 --> Security Class Initialized
DEBUG - 2016-01-27 07:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:49:57 --> Input Class Initialized
INFO - 2016-01-27 07:49:57 --> Language Class Initialized
INFO - 2016-01-27 07:49:57 --> Loader Class Initialized
INFO - 2016-01-27 07:49:57 --> Helper loaded: url_helper
INFO - 2016-01-27 07:49:57 --> Helper loaded: file_helper
INFO - 2016-01-27 07:49:57 --> Helper loaded: date_helper
INFO - 2016-01-27 07:49:57 --> Database Driver Class Initialized
INFO - 2016-01-27 07:49:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:49:58 --> Controller Class Initialized
INFO - 2016-01-27 07:49:58 --> Model Class Initialized
INFO - 2016-01-27 07:49:58 --> Model Class Initialized
INFO - 2016-01-27 07:49:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:49:58 --> Pagination Class Initialized
INFO - 2016-01-27 07:49:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:49:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:49:58 --> Final output sent to browser
DEBUG - 2016-01-27 07:49:58 --> Total execution time: 1.1095
INFO - 2016-01-27 07:50:35 --> Config Class Initialized
INFO - 2016-01-27 07:50:35 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:50:35 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:50:35 --> Utf8 Class Initialized
INFO - 2016-01-27 07:50:35 --> URI Class Initialized
DEBUG - 2016-01-27 07:50:35 --> No URI present. Default controller set.
INFO - 2016-01-27 07:50:35 --> Router Class Initialized
INFO - 2016-01-27 07:50:35 --> Output Class Initialized
INFO - 2016-01-27 07:50:35 --> Security Class Initialized
DEBUG - 2016-01-27 07:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:50:35 --> Input Class Initialized
INFO - 2016-01-27 07:50:35 --> Language Class Initialized
INFO - 2016-01-27 07:50:35 --> Loader Class Initialized
INFO - 2016-01-27 07:50:35 --> Helper loaded: url_helper
INFO - 2016-01-27 07:50:35 --> Helper loaded: file_helper
INFO - 2016-01-27 07:50:35 --> Helper loaded: date_helper
INFO - 2016-01-27 07:50:35 --> Database Driver Class Initialized
INFO - 2016-01-27 07:50:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:50:36 --> Controller Class Initialized
INFO - 2016-01-27 07:50:36 --> Model Class Initialized
INFO - 2016-01-27 07:50:36 --> Model Class Initialized
INFO - 2016-01-27 07:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:50:36 --> Pagination Class Initialized
INFO - 2016-01-27 07:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:50:36 --> Final output sent to browser
DEBUG - 2016-01-27 07:50:36 --> Total execution time: 1.0966
INFO - 2016-01-27 07:50:59 --> Config Class Initialized
INFO - 2016-01-27 07:50:59 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:50:59 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:50:59 --> Utf8 Class Initialized
INFO - 2016-01-27 07:50:59 --> URI Class Initialized
DEBUG - 2016-01-27 07:50:59 --> No URI present. Default controller set.
INFO - 2016-01-27 07:50:59 --> Router Class Initialized
INFO - 2016-01-27 07:50:59 --> Output Class Initialized
INFO - 2016-01-27 07:50:59 --> Security Class Initialized
DEBUG - 2016-01-27 07:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:50:59 --> Input Class Initialized
INFO - 2016-01-27 07:50:59 --> Language Class Initialized
INFO - 2016-01-27 07:50:59 --> Loader Class Initialized
INFO - 2016-01-27 07:50:59 --> Helper loaded: url_helper
INFO - 2016-01-27 07:50:59 --> Helper loaded: file_helper
INFO - 2016-01-27 07:50:59 --> Helper loaded: date_helper
INFO - 2016-01-27 07:50:59 --> Database Driver Class Initialized
INFO - 2016-01-27 07:51:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:51:00 --> Controller Class Initialized
INFO - 2016-01-27 07:51:00 --> Model Class Initialized
INFO - 2016-01-27 07:51:00 --> Model Class Initialized
INFO - 2016-01-27 07:51:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:51:00 --> Pagination Class Initialized
INFO - 2016-01-27 07:51:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:51:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:51:00 --> Final output sent to browser
DEBUG - 2016-01-27 07:51:00 --> Total execution time: 1.1065
INFO - 2016-01-27 07:51:38 --> Config Class Initialized
INFO - 2016-01-27 07:51:38 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:51:38 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:51:38 --> Utf8 Class Initialized
INFO - 2016-01-27 07:51:38 --> URI Class Initialized
DEBUG - 2016-01-27 07:51:38 --> No URI present. Default controller set.
INFO - 2016-01-27 07:51:38 --> Router Class Initialized
INFO - 2016-01-27 07:51:38 --> Output Class Initialized
INFO - 2016-01-27 07:51:38 --> Security Class Initialized
DEBUG - 2016-01-27 07:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:51:38 --> Input Class Initialized
INFO - 2016-01-27 07:51:38 --> Language Class Initialized
INFO - 2016-01-27 07:51:38 --> Loader Class Initialized
INFO - 2016-01-27 07:51:38 --> Helper loaded: url_helper
INFO - 2016-01-27 07:51:38 --> Helper loaded: file_helper
INFO - 2016-01-27 07:51:38 --> Helper loaded: date_helper
INFO - 2016-01-27 07:51:38 --> Database Driver Class Initialized
INFO - 2016-01-27 07:51:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:51:39 --> Controller Class Initialized
INFO - 2016-01-27 07:51:39 --> Model Class Initialized
INFO - 2016-01-27 07:51:39 --> Model Class Initialized
INFO - 2016-01-27 07:51:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:51:39 --> Pagination Class Initialized
INFO - 2016-01-27 07:51:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:51:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:51:39 --> Final output sent to browser
DEBUG - 2016-01-27 07:51:39 --> Total execution time: 1.1839
INFO - 2016-01-27 07:52:04 --> Config Class Initialized
INFO - 2016-01-27 07:52:04 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:52:04 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:52:04 --> Utf8 Class Initialized
INFO - 2016-01-27 07:52:04 --> URI Class Initialized
DEBUG - 2016-01-27 07:52:04 --> No URI present. Default controller set.
INFO - 2016-01-27 07:52:04 --> Router Class Initialized
INFO - 2016-01-27 07:52:04 --> Output Class Initialized
INFO - 2016-01-27 07:52:04 --> Security Class Initialized
DEBUG - 2016-01-27 07:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:52:04 --> Input Class Initialized
INFO - 2016-01-27 07:52:04 --> Language Class Initialized
INFO - 2016-01-27 07:52:04 --> Loader Class Initialized
INFO - 2016-01-27 07:52:04 --> Helper loaded: url_helper
INFO - 2016-01-27 07:52:04 --> Helper loaded: file_helper
INFO - 2016-01-27 07:52:04 --> Helper loaded: date_helper
INFO - 2016-01-27 07:52:04 --> Database Driver Class Initialized
INFO - 2016-01-27 07:52:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:52:05 --> Controller Class Initialized
INFO - 2016-01-27 07:52:05 --> Model Class Initialized
INFO - 2016-01-27 07:52:05 --> Model Class Initialized
INFO - 2016-01-27 07:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:52:05 --> Pagination Class Initialized
INFO - 2016-01-27 07:52:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 07:52:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 07:52:05 --> Final output sent to browser
DEBUG - 2016-01-27 07:52:05 --> Total execution time: 1.0755
INFO - 2016-01-27 07:52:06 --> Config Class Initialized
INFO - 2016-01-27 07:52:06 --> Hooks Class Initialized
DEBUG - 2016-01-27 07:52:06 --> UTF-8 Support Enabled
INFO - 2016-01-27 07:52:06 --> Utf8 Class Initialized
INFO - 2016-01-27 07:52:06 --> URI Class Initialized
INFO - 2016-01-27 07:52:06 --> Router Class Initialized
INFO - 2016-01-27 07:52:06 --> Output Class Initialized
INFO - 2016-01-27 07:52:06 --> Security Class Initialized
DEBUG - 2016-01-27 07:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 07:52:06 --> Input Class Initialized
INFO - 2016-01-27 07:52:06 --> Language Class Initialized
INFO - 2016-01-27 07:52:06 --> Loader Class Initialized
INFO - 2016-01-27 07:52:06 --> Helper loaded: url_helper
INFO - 2016-01-27 07:52:06 --> Helper loaded: file_helper
INFO - 2016-01-27 07:52:06 --> Helper loaded: date_helper
INFO - 2016-01-27 07:52:06 --> Database Driver Class Initialized
INFO - 2016-01-27 07:52:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 07:52:07 --> Controller Class Initialized
INFO - 2016-01-27 07:52:07 --> Model Class Initialized
INFO - 2016-01-27 07:52:07 --> Model Class Initialized
INFO - 2016-01-27 07:52:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 07:52:07 --> Pagination Class Initialized
INFO - 2016-01-27 07:52:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 07:52:07 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 07:52:07 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 08:10:19 --> Config Class Initialized
INFO - 2016-01-27 08:10:19 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:10:19 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:10:19 --> Utf8 Class Initialized
INFO - 2016-01-27 08:10:19 --> URI Class Initialized
INFO - 2016-01-27 08:10:19 --> Router Class Initialized
INFO - 2016-01-27 08:10:19 --> Output Class Initialized
INFO - 2016-01-27 08:10:19 --> Security Class Initialized
DEBUG - 2016-01-27 08:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:10:19 --> Input Class Initialized
INFO - 2016-01-27 08:10:19 --> Language Class Initialized
INFO - 2016-01-27 08:10:19 --> Loader Class Initialized
INFO - 2016-01-27 08:10:19 --> Helper loaded: url_helper
INFO - 2016-01-27 08:10:19 --> Helper loaded: file_helper
INFO - 2016-01-27 08:10:19 --> Helper loaded: date_helper
INFO - 2016-01-27 08:10:19 --> Database Driver Class Initialized
INFO - 2016-01-27 08:10:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:10:20 --> Controller Class Initialized
INFO - 2016-01-27 08:10:20 --> Model Class Initialized
INFO - 2016-01-27 08:10:20 --> Model Class Initialized
INFO - 2016-01-27 08:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:10:20 --> Pagination Class Initialized
INFO - 2016-01-27 08:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:10:20 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 08:10:20 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 08:14:46 --> Config Class Initialized
INFO - 2016-01-27 08:14:46 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:14:46 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:14:46 --> Utf8 Class Initialized
INFO - 2016-01-27 08:14:46 --> URI Class Initialized
INFO - 2016-01-27 08:14:46 --> Router Class Initialized
INFO - 2016-01-27 08:14:46 --> Output Class Initialized
INFO - 2016-01-27 08:14:46 --> Security Class Initialized
DEBUG - 2016-01-27 08:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:14:46 --> Input Class Initialized
INFO - 2016-01-27 08:14:46 --> Language Class Initialized
INFO - 2016-01-27 08:14:46 --> Loader Class Initialized
INFO - 2016-01-27 08:14:46 --> Helper loaded: url_helper
INFO - 2016-01-27 08:14:46 --> Helper loaded: file_helper
INFO - 2016-01-27 08:14:46 --> Helper loaded: date_helper
INFO - 2016-01-27 08:14:46 --> Database Driver Class Initialized
INFO - 2016-01-27 08:14:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:14:47 --> Controller Class Initialized
INFO - 2016-01-27 08:14:47 --> Model Class Initialized
INFO - 2016-01-27 08:14:47 --> Model Class Initialized
INFO - 2016-01-27 08:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:14:47 --> Pagination Class Initialized
INFO - 2016-01-27 08:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:14:47 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 08:14:47 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 08:17:01 --> Config Class Initialized
INFO - 2016-01-27 08:17:01 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:17:01 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:17:01 --> Utf8 Class Initialized
INFO - 2016-01-27 08:17:01 --> URI Class Initialized
INFO - 2016-01-27 08:17:01 --> Router Class Initialized
INFO - 2016-01-27 08:17:01 --> Output Class Initialized
INFO - 2016-01-27 08:17:01 --> Security Class Initialized
DEBUG - 2016-01-27 08:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:17:01 --> Input Class Initialized
INFO - 2016-01-27 08:17:01 --> Language Class Initialized
INFO - 2016-01-27 08:17:01 --> Loader Class Initialized
INFO - 2016-01-27 08:17:01 --> Helper loaded: url_helper
INFO - 2016-01-27 08:17:01 --> Helper loaded: file_helper
INFO - 2016-01-27 08:17:01 --> Helper loaded: date_helper
INFO - 2016-01-27 08:17:01 --> Database Driver Class Initialized
INFO - 2016-01-27 08:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:17:02 --> Controller Class Initialized
INFO - 2016-01-27 08:17:02 --> Model Class Initialized
INFO - 2016-01-27 08:17:02 --> Model Class Initialized
INFO - 2016-01-27 08:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:17:02 --> Pagination Class Initialized
INFO - 2016-01-27 08:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:17:02 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 08:17:02 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 08:26:24 --> Config Class Initialized
INFO - 2016-01-27 08:26:24 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:26:24 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:26:24 --> Utf8 Class Initialized
INFO - 2016-01-27 08:26:24 --> URI Class Initialized
INFO - 2016-01-27 08:26:24 --> Router Class Initialized
INFO - 2016-01-27 08:26:24 --> Output Class Initialized
INFO - 2016-01-27 08:26:24 --> Security Class Initialized
DEBUG - 2016-01-27 08:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:26:24 --> Input Class Initialized
INFO - 2016-01-27 08:26:24 --> Language Class Initialized
INFO - 2016-01-27 08:26:24 --> Loader Class Initialized
INFO - 2016-01-27 08:26:24 --> Helper loaded: url_helper
INFO - 2016-01-27 08:26:24 --> Helper loaded: file_helper
INFO - 2016-01-27 08:26:24 --> Helper loaded: date_helper
INFO - 2016-01-27 08:26:24 --> Database Driver Class Initialized
INFO - 2016-01-27 08:26:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:26:25 --> Controller Class Initialized
INFO - 2016-01-27 08:26:25 --> Model Class Initialized
INFO - 2016-01-27 08:26:25 --> Model Class Initialized
INFO - 2016-01-27 08:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:26:25 --> Pagination Class Initialized
INFO - 2016-01-27 08:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:26:25 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 08:26:25 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 08:27:14 --> Config Class Initialized
INFO - 2016-01-27 08:27:14 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:27:14 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:27:14 --> Utf8 Class Initialized
INFO - 2016-01-27 08:27:14 --> URI Class Initialized
INFO - 2016-01-27 08:27:14 --> Router Class Initialized
INFO - 2016-01-27 08:27:14 --> Output Class Initialized
INFO - 2016-01-27 08:27:14 --> Security Class Initialized
DEBUG - 2016-01-27 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:27:14 --> Input Class Initialized
INFO - 2016-01-27 08:27:14 --> Language Class Initialized
INFO - 2016-01-27 08:27:14 --> Loader Class Initialized
INFO - 2016-01-27 08:27:14 --> Helper loaded: url_helper
INFO - 2016-01-27 08:27:14 --> Helper loaded: file_helper
INFO - 2016-01-27 08:27:14 --> Helper loaded: date_helper
INFO - 2016-01-27 08:27:14 --> Database Driver Class Initialized
INFO - 2016-01-27 08:27:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:27:15 --> Controller Class Initialized
INFO - 2016-01-27 08:27:15 --> Model Class Initialized
INFO - 2016-01-27 08:27:15 --> Model Class Initialized
INFO - 2016-01-27 08:27:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:27:15 --> Pagination Class Initialized
INFO - 2016-01-27 08:27:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:27:15 --> Severity: Notice --> Undefined variable: total_comments C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 37
INFO - 2016-01-27 08:27:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 08:27:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 08:27:15 --> Final output sent to browser
DEBUG - 2016-01-27 08:27:15 --> Total execution time: 1.1600
INFO - 2016-01-27 08:29:23 --> Config Class Initialized
INFO - 2016-01-27 08:29:23 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:29:23 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:29:23 --> Utf8 Class Initialized
INFO - 2016-01-27 08:29:23 --> URI Class Initialized
INFO - 2016-01-27 08:29:23 --> Router Class Initialized
INFO - 2016-01-27 08:29:23 --> Output Class Initialized
INFO - 2016-01-27 08:29:23 --> Security Class Initialized
DEBUG - 2016-01-27 08:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:29:23 --> Input Class Initialized
INFO - 2016-01-27 08:29:23 --> Language Class Initialized
ERROR - 2016-01-27 08:29:23 --> Severity: Parsing Error --> syntax error, unexpected '*' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 107
INFO - 2016-01-27 08:29:30 --> Config Class Initialized
INFO - 2016-01-27 08:29:30 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:29:30 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:29:30 --> Utf8 Class Initialized
INFO - 2016-01-27 08:29:30 --> URI Class Initialized
INFO - 2016-01-27 08:29:30 --> Router Class Initialized
INFO - 2016-01-27 08:29:30 --> Output Class Initialized
INFO - 2016-01-27 08:29:30 --> Security Class Initialized
DEBUG - 2016-01-27 08:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:29:30 --> Input Class Initialized
INFO - 2016-01-27 08:29:30 --> Language Class Initialized
INFO - 2016-01-27 08:29:30 --> Loader Class Initialized
INFO - 2016-01-27 08:29:30 --> Helper loaded: url_helper
INFO - 2016-01-27 08:29:30 --> Helper loaded: file_helper
INFO - 2016-01-27 08:29:30 --> Helper loaded: date_helper
INFO - 2016-01-27 08:29:30 --> Database Driver Class Initialized
INFO - 2016-01-27 08:29:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:29:31 --> Controller Class Initialized
INFO - 2016-01-27 08:29:31 --> Model Class Initialized
INFO - 2016-01-27 08:29:31 --> Model Class Initialized
INFO - 2016-01-27 08:29:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:29:31 --> Pagination Class Initialized
INFO - 2016-01-27 08:29:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:29:31 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 08:29:31 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 08:33:55 --> Config Class Initialized
INFO - 2016-01-27 08:33:55 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:33:55 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:33:55 --> Utf8 Class Initialized
INFO - 2016-01-27 08:33:55 --> URI Class Initialized
INFO - 2016-01-27 08:33:55 --> Router Class Initialized
INFO - 2016-01-27 08:33:55 --> Output Class Initialized
INFO - 2016-01-27 08:33:55 --> Security Class Initialized
DEBUG - 2016-01-27 08:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:33:55 --> Input Class Initialized
INFO - 2016-01-27 08:33:55 --> Language Class Initialized
INFO - 2016-01-27 08:33:55 --> Loader Class Initialized
INFO - 2016-01-27 08:33:55 --> Helper loaded: url_helper
INFO - 2016-01-27 08:33:55 --> Helper loaded: file_helper
INFO - 2016-01-27 08:33:55 --> Helper loaded: date_helper
INFO - 2016-01-27 08:33:55 --> Database Driver Class Initialized
INFO - 2016-01-27 08:33:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:33:56 --> Controller Class Initialized
INFO - 2016-01-27 08:33:56 --> Model Class Initialized
INFO - 2016-01-27 08:33:56 --> Model Class Initialized
INFO - 2016-01-27 08:33:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:33:56 --> Pagination Class Initialized
INFO - 2016-01-27 08:33:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:33:56 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 08:33:56 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 08:35:05 --> Config Class Initialized
INFO - 2016-01-27 08:35:05 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:35:05 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:35:05 --> Utf8 Class Initialized
INFO - 2016-01-27 08:35:05 --> URI Class Initialized
INFO - 2016-01-27 08:35:05 --> Router Class Initialized
INFO - 2016-01-27 08:35:05 --> Output Class Initialized
INFO - 2016-01-27 08:35:05 --> Security Class Initialized
DEBUG - 2016-01-27 08:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:35:05 --> Input Class Initialized
INFO - 2016-01-27 08:35:05 --> Language Class Initialized
INFO - 2016-01-27 08:35:05 --> Loader Class Initialized
INFO - 2016-01-27 08:35:05 --> Helper loaded: url_helper
INFO - 2016-01-27 08:35:05 --> Helper loaded: file_helper
INFO - 2016-01-27 08:35:05 --> Helper loaded: date_helper
INFO - 2016-01-27 08:35:05 --> Database Driver Class Initialized
INFO - 2016-01-27 08:35:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:35:06 --> Controller Class Initialized
INFO - 2016-01-27 08:35:06 --> Model Class Initialized
INFO - 2016-01-27 08:35:06 --> Model Class Initialized
INFO - 2016-01-27 08:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:35:06 --> Pagination Class Initialized
INFO - 2016-01-27 08:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:35:06 --> Severity: Notice --> Undefined property: Jboard::$jboard_model C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
ERROR - 2016-01-27 08:35:06 --> Severity: Error --> Call to a member function total_comments() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 105
INFO - 2016-01-27 08:57:20 --> Config Class Initialized
INFO - 2016-01-27 08:57:20 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:57:20 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:57:20 --> Utf8 Class Initialized
INFO - 2016-01-27 08:57:20 --> URI Class Initialized
INFO - 2016-01-27 08:57:20 --> Router Class Initialized
INFO - 2016-01-27 08:57:20 --> Output Class Initialized
INFO - 2016-01-27 08:57:20 --> Security Class Initialized
DEBUG - 2016-01-27 08:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:57:20 --> Input Class Initialized
INFO - 2016-01-27 08:57:20 --> Language Class Initialized
INFO - 2016-01-27 08:57:20 --> Loader Class Initialized
INFO - 2016-01-27 08:57:20 --> Helper loaded: url_helper
INFO - 2016-01-27 08:57:20 --> Helper loaded: file_helper
INFO - 2016-01-27 08:57:20 --> Helper loaded: date_helper
INFO - 2016-01-27 08:57:20 --> Database Driver Class Initialized
INFO - 2016-01-27 08:57:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:57:21 --> Controller Class Initialized
INFO - 2016-01-27 08:57:21 --> Model Class Initialized
INFO - 2016-01-27 08:57:21 --> Model Class Initialized
INFO - 2016-01-27 08:57:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:57:21 --> Pagination Class Initialized
INFO - 2016-01-27 08:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 08:57:21 --> Severity: Notice --> Undefined variable: total_comments C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 37
INFO - 2016-01-27 08:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 08:57:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 08:57:21 --> Final output sent to browser
DEBUG - 2016-01-27 08:57:21 --> Total execution time: 1.2478
INFO - 2016-01-27 08:57:36 --> Config Class Initialized
INFO - 2016-01-27 08:57:36 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:57:36 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:57:36 --> Utf8 Class Initialized
INFO - 2016-01-27 08:57:36 --> URI Class Initialized
INFO - 2016-01-27 08:57:36 --> Router Class Initialized
INFO - 2016-01-27 08:57:36 --> Output Class Initialized
INFO - 2016-01-27 08:57:36 --> Security Class Initialized
DEBUG - 2016-01-27 08:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:57:36 --> Input Class Initialized
INFO - 2016-01-27 08:57:36 --> Language Class Initialized
INFO - 2016-01-27 08:57:36 --> Loader Class Initialized
INFO - 2016-01-27 08:57:36 --> Helper loaded: url_helper
INFO - 2016-01-27 08:57:36 --> Helper loaded: file_helper
INFO - 2016-01-27 08:57:36 --> Helper loaded: date_helper
INFO - 2016-01-27 08:57:36 --> Database Driver Class Initialized
INFO - 2016-01-27 08:57:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:57:37 --> Controller Class Initialized
INFO - 2016-01-27 08:57:37 --> Model Class Initialized
INFO - 2016-01-27 08:57:37 --> Model Class Initialized
INFO - 2016-01-27 08:57:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:57:37 --> Pagination Class Initialized
INFO - 2016-01-27 08:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 08:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 08:57:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 08:57:37 --> Final output sent to browser
DEBUG - 2016-01-27 08:57:37 --> Total execution time: 1.1230
INFO - 2016-01-27 08:57:47 --> Config Class Initialized
INFO - 2016-01-27 08:57:47 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:57:47 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:57:47 --> Utf8 Class Initialized
INFO - 2016-01-27 08:57:47 --> URI Class Initialized
INFO - 2016-01-27 08:57:47 --> Router Class Initialized
INFO - 2016-01-27 08:57:47 --> Output Class Initialized
INFO - 2016-01-27 08:57:47 --> Security Class Initialized
DEBUG - 2016-01-27 08:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:57:47 --> Input Class Initialized
INFO - 2016-01-27 08:57:47 --> Language Class Initialized
INFO - 2016-01-27 08:57:47 --> Loader Class Initialized
INFO - 2016-01-27 08:57:47 --> Helper loaded: url_helper
INFO - 2016-01-27 08:57:47 --> Helper loaded: file_helper
INFO - 2016-01-27 08:57:47 --> Helper loaded: date_helper
INFO - 2016-01-27 08:57:47 --> Database Driver Class Initialized
INFO - 2016-01-27 08:57:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:57:48 --> Controller Class Initialized
INFO - 2016-01-27 08:57:48 --> Model Class Initialized
INFO - 2016-01-27 08:57:48 --> Model Class Initialized
INFO - 2016-01-27 08:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:57:48 --> Pagination Class Initialized
INFO - 2016-01-27 08:57:48 --> Config Class Initialized
INFO - 2016-01-27 08:57:48 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:57:48 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:57:48 --> Utf8 Class Initialized
INFO - 2016-01-27 08:57:48 --> URI Class Initialized
INFO - 2016-01-27 08:57:48 --> Router Class Initialized
INFO - 2016-01-27 08:57:48 --> Output Class Initialized
INFO - 2016-01-27 08:57:49 --> Security Class Initialized
DEBUG - 2016-01-27 08:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:57:49 --> Input Class Initialized
INFO - 2016-01-27 08:57:49 --> Language Class Initialized
INFO - 2016-01-27 08:57:49 --> Loader Class Initialized
INFO - 2016-01-27 08:57:49 --> Helper loaded: url_helper
INFO - 2016-01-27 08:57:49 --> Helper loaded: file_helper
INFO - 2016-01-27 08:57:49 --> Helper loaded: date_helper
INFO - 2016-01-27 08:57:49 --> Database Driver Class Initialized
INFO - 2016-01-27 08:57:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:57:50 --> Controller Class Initialized
INFO - 2016-01-27 08:57:50 --> Model Class Initialized
INFO - 2016-01-27 08:57:50 --> Model Class Initialized
INFO - 2016-01-27 08:57:50 --> Helper loaded: form_helper
INFO - 2016-01-27 08:57:50 --> Form Validation Class Initialized
INFO - 2016-01-27 08:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 08:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-27 08:57:50 --> Final output sent to browser
DEBUG - 2016-01-27 08:57:50 --> Total execution time: 1.2292
INFO - 2016-01-27 08:58:25 --> Config Class Initialized
INFO - 2016-01-27 08:58:25 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:58:25 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:58:25 --> Utf8 Class Initialized
INFO - 2016-01-27 08:58:25 --> URI Class Initialized
INFO - 2016-01-27 08:58:25 --> Router Class Initialized
INFO - 2016-01-27 08:58:25 --> Output Class Initialized
INFO - 2016-01-27 08:58:25 --> Security Class Initialized
DEBUG - 2016-01-27 08:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:58:25 --> Input Class Initialized
INFO - 2016-01-27 08:58:25 --> Language Class Initialized
INFO - 2016-01-27 08:58:25 --> Loader Class Initialized
INFO - 2016-01-27 08:58:25 --> Helper loaded: url_helper
INFO - 2016-01-27 08:58:25 --> Helper loaded: file_helper
INFO - 2016-01-27 08:58:25 --> Helper loaded: date_helper
INFO - 2016-01-27 08:58:25 --> Database Driver Class Initialized
INFO - 2016-01-27 08:58:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:58:26 --> Controller Class Initialized
INFO - 2016-01-27 08:58:26 --> Model Class Initialized
INFO - 2016-01-27 08:58:26 --> Model Class Initialized
INFO - 2016-01-27 08:58:26 --> Helper loaded: form_helper
INFO - 2016-01-27 08:58:26 --> Form Validation Class Initialized
INFO - 2016-01-27 08:58:26 --> Config Class Initialized
INFO - 2016-01-27 08:58:26 --> Hooks Class Initialized
DEBUG - 2016-01-27 08:58:26 --> UTF-8 Support Enabled
INFO - 2016-01-27 08:58:26 --> Utf8 Class Initialized
INFO - 2016-01-27 08:58:26 --> URI Class Initialized
INFO - 2016-01-27 08:58:26 --> Router Class Initialized
INFO - 2016-01-27 08:58:26 --> Output Class Initialized
INFO - 2016-01-27 08:58:26 --> Security Class Initialized
DEBUG - 2016-01-27 08:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 08:58:26 --> Input Class Initialized
INFO - 2016-01-27 08:58:26 --> Language Class Initialized
INFO - 2016-01-27 08:58:26 --> Loader Class Initialized
INFO - 2016-01-27 08:58:26 --> Helper loaded: url_helper
INFO - 2016-01-27 08:58:26 --> Helper loaded: file_helper
INFO - 2016-01-27 08:58:26 --> Helper loaded: date_helper
INFO - 2016-01-27 08:58:26 --> Database Driver Class Initialized
INFO - 2016-01-27 08:58:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 08:58:27 --> Controller Class Initialized
INFO - 2016-01-27 08:58:27 --> Model Class Initialized
INFO - 2016-01-27 08:58:27 --> Model Class Initialized
INFO - 2016-01-27 08:58:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 08:58:27 --> Pagination Class Initialized
INFO - 2016-01-27 08:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 08:58:27 --> Helper loaded: form_helper
INFO - 2016-01-27 08:58:27 --> Form Validation Class Initialized
INFO - 2016-01-27 08:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-01-27 08:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-01-27 08:58:27 --> Final output sent to browser
DEBUG - 2016-01-27 08:58:27 --> Total execution time: 1.1410
INFO - 2016-01-27 09:00:46 --> Config Class Initialized
INFO - 2016-01-27 09:00:46 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:00:46 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:00:46 --> Utf8 Class Initialized
INFO - 2016-01-27 09:00:46 --> URI Class Initialized
INFO - 2016-01-27 09:00:46 --> Router Class Initialized
INFO - 2016-01-27 09:00:46 --> Output Class Initialized
INFO - 2016-01-27 09:00:46 --> Security Class Initialized
DEBUG - 2016-01-27 09:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:00:46 --> Input Class Initialized
INFO - 2016-01-27 09:00:46 --> Language Class Initialized
INFO - 2016-01-27 09:00:46 --> Loader Class Initialized
INFO - 2016-01-27 09:00:46 --> Helper loaded: url_helper
INFO - 2016-01-27 09:00:46 --> Helper loaded: file_helper
INFO - 2016-01-27 09:00:46 --> Helper loaded: date_helper
INFO - 2016-01-27 09:00:46 --> Database Driver Class Initialized
INFO - 2016-01-27 09:00:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:00:47 --> Controller Class Initialized
INFO - 2016-01-27 09:00:47 --> Model Class Initialized
INFO - 2016-01-27 09:00:47 --> Model Class Initialized
INFO - 2016-01-27 09:00:47 --> Helper loaded: form_helper
INFO - 2016-01-27 09:00:47 --> Form Validation Class Initialized
INFO - 2016-01-27 09:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-27 09:00:47 --> Final output sent to browser
DEBUG - 2016-01-27 09:00:47 --> Total execution time: 1.1221
INFO - 2016-01-27 09:00:50 --> Config Class Initialized
INFO - 2016-01-27 09:00:50 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:00:50 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:00:50 --> Utf8 Class Initialized
INFO - 2016-01-27 09:00:50 --> URI Class Initialized
DEBUG - 2016-01-27 09:00:50 --> No URI present. Default controller set.
INFO - 2016-01-27 09:00:50 --> Router Class Initialized
INFO - 2016-01-27 09:00:50 --> Output Class Initialized
INFO - 2016-01-27 09:00:50 --> Security Class Initialized
DEBUG - 2016-01-27 09:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:00:50 --> Input Class Initialized
INFO - 2016-01-27 09:00:50 --> Language Class Initialized
INFO - 2016-01-27 09:00:50 --> Loader Class Initialized
INFO - 2016-01-27 09:00:50 --> Helper loaded: url_helper
INFO - 2016-01-27 09:00:50 --> Helper loaded: file_helper
INFO - 2016-01-27 09:00:50 --> Helper loaded: date_helper
INFO - 2016-01-27 09:00:50 --> Database Driver Class Initialized
INFO - 2016-01-27 09:00:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:00:51 --> Controller Class Initialized
INFO - 2016-01-27 09:00:51 --> Model Class Initialized
INFO - 2016-01-27 09:00:51 --> Model Class Initialized
INFO - 2016-01-27 09:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:00:51 --> Pagination Class Initialized
INFO - 2016-01-27 09:00:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:00:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 09:00:51 --> Final output sent to browser
DEBUG - 2016-01-27 09:00:51 --> Total execution time: 1.1389
INFO - 2016-01-27 09:00:52 --> Config Class Initialized
INFO - 2016-01-27 09:00:52 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:00:52 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:00:52 --> Utf8 Class Initialized
INFO - 2016-01-27 09:00:52 --> URI Class Initialized
INFO - 2016-01-27 09:00:52 --> Router Class Initialized
INFO - 2016-01-27 09:00:52 --> Output Class Initialized
INFO - 2016-01-27 09:00:52 --> Security Class Initialized
DEBUG - 2016-01-27 09:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:00:52 --> Input Class Initialized
INFO - 2016-01-27 09:00:52 --> Language Class Initialized
INFO - 2016-01-27 09:00:52 --> Loader Class Initialized
INFO - 2016-01-27 09:00:52 --> Helper loaded: url_helper
INFO - 2016-01-27 09:00:52 --> Helper loaded: file_helper
INFO - 2016-01-27 09:00:52 --> Helper loaded: date_helper
INFO - 2016-01-27 09:00:52 --> Database Driver Class Initialized
INFO - 2016-01-27 09:00:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:00:53 --> Controller Class Initialized
INFO - 2016-01-27 09:00:53 --> Model Class Initialized
INFO - 2016-01-27 09:00:53 --> Model Class Initialized
INFO - 2016-01-27 09:00:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:00:53 --> Pagination Class Initialized
INFO - 2016-01-27 09:00:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:00:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 09:00:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 09:00:53 --> Final output sent to browser
DEBUG - 2016-01-27 09:00:53 --> Total execution time: 1.1680
INFO - 2016-01-27 09:01:01 --> Config Class Initialized
INFO - 2016-01-27 09:01:01 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:01:01 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:01:01 --> Utf8 Class Initialized
INFO - 2016-01-27 09:01:01 --> URI Class Initialized
INFO - 2016-01-27 09:01:01 --> Router Class Initialized
INFO - 2016-01-27 09:01:01 --> Output Class Initialized
INFO - 2016-01-27 09:01:01 --> Security Class Initialized
DEBUG - 2016-01-27 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:01:01 --> Input Class Initialized
INFO - 2016-01-27 09:01:01 --> Language Class Initialized
INFO - 2016-01-27 09:01:01 --> Loader Class Initialized
INFO - 2016-01-27 09:01:01 --> Helper loaded: url_helper
INFO - 2016-01-27 09:01:01 --> Helper loaded: file_helper
INFO - 2016-01-27 09:01:01 --> Helper loaded: date_helper
INFO - 2016-01-27 09:01:01 --> Database Driver Class Initialized
INFO - 2016-01-27 09:01:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:01:02 --> Controller Class Initialized
INFO - 2016-01-27 09:01:02 --> Model Class Initialized
INFO - 2016-01-27 09:01:02 --> Model Class Initialized
INFO - 2016-01-27 09:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:01:02 --> Pagination Class Initialized
INFO - 2016-01-27 09:01:02 --> Helper loaded: form_helper
INFO - 2016-01-27 09:01:02 --> Form Validation Class Initialized
ERROR - 2016-01-27 09:01:02 --> Severity: Error --> Call to undefined method CI_Input::userdata() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 168
INFO - 2016-01-27 09:01:38 --> Config Class Initialized
INFO - 2016-01-27 09:01:38 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:01:38 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:01:38 --> Utf8 Class Initialized
INFO - 2016-01-27 09:01:38 --> URI Class Initialized
INFO - 2016-01-27 09:01:38 --> Router Class Initialized
INFO - 2016-01-27 09:01:38 --> Output Class Initialized
INFO - 2016-01-27 09:01:38 --> Security Class Initialized
DEBUG - 2016-01-27 09:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:01:38 --> Input Class Initialized
INFO - 2016-01-27 09:01:38 --> Language Class Initialized
INFO - 2016-01-27 09:01:38 --> Loader Class Initialized
INFO - 2016-01-27 09:01:38 --> Helper loaded: url_helper
INFO - 2016-01-27 09:01:38 --> Helper loaded: file_helper
INFO - 2016-01-27 09:01:38 --> Helper loaded: date_helper
INFO - 2016-01-27 09:01:38 --> Database Driver Class Initialized
INFO - 2016-01-27 09:01:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:01:39 --> Controller Class Initialized
INFO - 2016-01-27 09:01:39 --> Model Class Initialized
INFO - 2016-01-27 09:01:40 --> Model Class Initialized
INFO - 2016-01-27 09:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:01:40 --> Pagination Class Initialized
INFO - 2016-01-27 09:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 09:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 09:01:40 --> Final output sent to browser
DEBUG - 2016-01-27 09:01:40 --> Total execution time: 1.1907
INFO - 2016-01-27 09:02:09 --> Config Class Initialized
INFO - 2016-01-27 09:02:09 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:02:09 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:02:09 --> Utf8 Class Initialized
INFO - 2016-01-27 09:02:09 --> URI Class Initialized
INFO - 2016-01-27 09:02:09 --> Router Class Initialized
INFO - 2016-01-27 09:02:09 --> Output Class Initialized
INFO - 2016-01-27 09:02:09 --> Security Class Initialized
DEBUG - 2016-01-27 09:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:02:09 --> Input Class Initialized
INFO - 2016-01-27 09:02:09 --> Language Class Initialized
INFO - 2016-01-27 09:02:09 --> Loader Class Initialized
INFO - 2016-01-27 09:02:09 --> Helper loaded: url_helper
INFO - 2016-01-27 09:02:09 --> Helper loaded: file_helper
INFO - 2016-01-27 09:02:09 --> Helper loaded: date_helper
INFO - 2016-01-27 09:02:09 --> Database Driver Class Initialized
INFO - 2016-01-27 09:02:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:02:10 --> Controller Class Initialized
INFO - 2016-01-27 09:02:10 --> Model Class Initialized
INFO - 2016-01-27 09:02:10 --> Model Class Initialized
INFO - 2016-01-27 09:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:02:10 --> Pagination Class Initialized
INFO - 2016-01-27 09:02:10 --> Helper loaded: form_helper
INFO - 2016-01-27 09:02:10 --> Form Validation Class Initialized
INFO - 2016-01-27 09:02:10 --> Model Class Initialized
ERROR - 2016-01-27 09:02:10 --> Query error: Column 'article' cannot be null - Invalid query: INSERT INTO `comment` (created, `board_id`, `user_id`, `user_name`, `article`) VALUES (NOW(), 0, '15', 'treeburn', NULL)
INFO - 2016-01-27 09:02:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-01-27 09:08:05 --> Config Class Initialized
INFO - 2016-01-27 09:08:05 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:08:05 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:08:05 --> Utf8 Class Initialized
INFO - 2016-01-27 09:08:05 --> URI Class Initialized
INFO - 2016-01-27 09:08:05 --> Router Class Initialized
INFO - 2016-01-27 09:08:05 --> Output Class Initialized
INFO - 2016-01-27 09:08:05 --> Security Class Initialized
DEBUG - 2016-01-27 09:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:08:05 --> Input Class Initialized
INFO - 2016-01-27 09:08:05 --> Language Class Initialized
INFO - 2016-01-27 09:08:05 --> Loader Class Initialized
INFO - 2016-01-27 09:08:05 --> Helper loaded: url_helper
INFO - 2016-01-27 09:08:05 --> Helper loaded: file_helper
INFO - 2016-01-27 09:08:05 --> Helper loaded: date_helper
INFO - 2016-01-27 09:08:05 --> Database Driver Class Initialized
INFO - 2016-01-27 09:08:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:08:06 --> Controller Class Initialized
INFO - 2016-01-27 09:08:06 --> Model Class Initialized
INFO - 2016-01-27 09:08:06 --> Model Class Initialized
INFO - 2016-01-27 09:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:08:06 --> Pagination Class Initialized
INFO - 2016-01-27 09:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:08:06 --> Helper loaded: form_helper
INFO - 2016-01-27 09:08:06 --> Form Validation Class Initialized
INFO - 2016-01-27 09:08:06 --> Model Class Initialized
ERROR - 2016-01-27 09:08:06 --> Query error: Column 'article' cannot be null - Invalid query: INSERT INTO `comment` (created, `board_id`, `user_id`, `user_name`, `article`) VALUES (NOW(), '33', '15', 'treeburn', NULL)
INFO - 2016-01-27 09:08:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-01-27 09:08:20 --> Config Class Initialized
INFO - 2016-01-27 09:08:20 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:08:20 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:08:20 --> Utf8 Class Initialized
INFO - 2016-01-27 09:08:20 --> URI Class Initialized
INFO - 2016-01-27 09:08:20 --> Router Class Initialized
INFO - 2016-01-27 09:08:20 --> Output Class Initialized
INFO - 2016-01-27 09:08:20 --> Security Class Initialized
DEBUG - 2016-01-27 09:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:08:20 --> Input Class Initialized
INFO - 2016-01-27 09:08:20 --> Language Class Initialized
INFO - 2016-01-27 09:08:20 --> Loader Class Initialized
INFO - 2016-01-27 09:08:20 --> Helper loaded: url_helper
INFO - 2016-01-27 09:08:20 --> Helper loaded: file_helper
INFO - 2016-01-27 09:08:20 --> Helper loaded: date_helper
INFO - 2016-01-27 09:08:20 --> Database Driver Class Initialized
INFO - 2016-01-27 09:08:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:08:21 --> Controller Class Initialized
INFO - 2016-01-27 09:08:21 --> Model Class Initialized
INFO - 2016-01-27 09:08:21 --> Model Class Initialized
INFO - 2016-01-27 09:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:08:21 --> Pagination Class Initialized
INFO - 2016-01-27 09:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 09:08:21 --> Final output sent to browser
DEBUG - 2016-01-27 09:08:21 --> Total execution time: 1.0951
INFO - 2016-01-27 09:08:27 --> Config Class Initialized
INFO - 2016-01-27 09:08:27 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:08:27 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:08:27 --> Utf8 Class Initialized
INFO - 2016-01-27 09:08:27 --> URI Class Initialized
INFO - 2016-01-27 09:08:27 --> Router Class Initialized
INFO - 2016-01-27 09:08:27 --> Output Class Initialized
INFO - 2016-01-27 09:08:27 --> Security Class Initialized
DEBUG - 2016-01-27 09:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:08:27 --> Input Class Initialized
INFO - 2016-01-27 09:08:27 --> Language Class Initialized
INFO - 2016-01-27 09:08:27 --> Loader Class Initialized
INFO - 2016-01-27 09:08:27 --> Helper loaded: url_helper
INFO - 2016-01-27 09:08:27 --> Helper loaded: file_helper
INFO - 2016-01-27 09:08:27 --> Helper loaded: date_helper
INFO - 2016-01-27 09:08:27 --> Database Driver Class Initialized
INFO - 2016-01-27 09:08:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:08:28 --> Controller Class Initialized
INFO - 2016-01-27 09:08:28 --> Model Class Initialized
INFO - 2016-01-27 09:08:28 --> Model Class Initialized
INFO - 2016-01-27 09:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:08:28 --> Pagination Class Initialized
INFO - 2016-01-27 09:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:08:28 --> Helper loaded: form_helper
INFO - 2016-01-27 09:08:28 --> Form Validation Class Initialized
INFO - 2016-01-27 09:08:28 --> Model Class Initialized
ERROR - 2016-01-27 09:08:28 --> Query error: Column 'article' cannot be null - Invalid query: INSERT INTO `comment` (created, `board_id`, `user_id`, `user_name`, `article`) VALUES (NOW(), '32', '15', 'treeburn', NULL)
INFO - 2016-01-27 09:08:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-01-27 09:09:44 --> Config Class Initialized
INFO - 2016-01-27 09:09:44 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:09:44 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:09:44 --> Utf8 Class Initialized
INFO - 2016-01-27 09:09:44 --> URI Class Initialized
INFO - 2016-01-27 09:09:44 --> Router Class Initialized
INFO - 2016-01-27 09:09:44 --> Output Class Initialized
INFO - 2016-01-27 09:09:44 --> Security Class Initialized
DEBUG - 2016-01-27 09:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:09:44 --> Input Class Initialized
INFO - 2016-01-27 09:09:44 --> Language Class Initialized
INFO - 2016-01-27 09:09:44 --> Loader Class Initialized
INFO - 2016-01-27 09:09:44 --> Helper loaded: url_helper
INFO - 2016-01-27 09:09:44 --> Helper loaded: file_helper
INFO - 2016-01-27 09:09:44 --> Helper loaded: date_helper
INFO - 2016-01-27 09:09:44 --> Database Driver Class Initialized
INFO - 2016-01-27 09:09:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:09:45 --> Controller Class Initialized
INFO - 2016-01-27 09:09:45 --> Model Class Initialized
INFO - 2016-01-27 09:09:45 --> Model Class Initialized
INFO - 2016-01-27 09:09:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:09:46 --> Pagination Class Initialized
INFO - 2016-01-27 09:09:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:09:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 09:09:46 --> Final output sent to browser
DEBUG - 2016-01-27 09:09:46 --> Total execution time: 1.1572
INFO - 2016-01-27 09:09:49 --> Config Class Initialized
INFO - 2016-01-27 09:09:49 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:09:49 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:09:49 --> Utf8 Class Initialized
INFO - 2016-01-27 09:09:49 --> URI Class Initialized
INFO - 2016-01-27 09:09:49 --> Router Class Initialized
INFO - 2016-01-27 09:09:49 --> Output Class Initialized
INFO - 2016-01-27 09:09:49 --> Security Class Initialized
DEBUG - 2016-01-27 09:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:09:49 --> Input Class Initialized
INFO - 2016-01-27 09:09:49 --> Language Class Initialized
INFO - 2016-01-27 09:09:49 --> Loader Class Initialized
INFO - 2016-01-27 09:09:49 --> Helper loaded: url_helper
INFO - 2016-01-27 09:09:49 --> Helper loaded: file_helper
INFO - 2016-01-27 09:09:49 --> Helper loaded: date_helper
INFO - 2016-01-27 09:09:49 --> Database Driver Class Initialized
INFO - 2016-01-27 09:09:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:09:50 --> Controller Class Initialized
INFO - 2016-01-27 09:09:50 --> Model Class Initialized
INFO - 2016-01-27 09:09:50 --> Model Class Initialized
INFO - 2016-01-27 09:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:09:50 --> Pagination Class Initialized
INFO - 2016-01-27 09:09:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:09:50 --> Helper loaded: form_helper
INFO - 2016-01-27 09:09:50 --> Form Validation Class Initialized
INFO - 2016-01-27 09:09:50 --> Model Class Initialized
INFO - 2016-01-27 09:09:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 09:09:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 09:09:50 --> Final output sent to browser
DEBUG - 2016-01-27 09:09:50 --> Total execution time: 1.2519
INFO - 2016-01-27 09:10:00 --> Config Class Initialized
INFO - 2016-01-27 09:10:00 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:10:00 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:10:00 --> Utf8 Class Initialized
INFO - 2016-01-27 09:10:00 --> URI Class Initialized
INFO - 2016-01-27 09:10:00 --> Router Class Initialized
INFO - 2016-01-27 09:10:00 --> Output Class Initialized
INFO - 2016-01-27 09:10:00 --> Security Class Initialized
DEBUG - 2016-01-27 09:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:10:00 --> Input Class Initialized
INFO - 2016-01-27 09:10:00 --> Language Class Initialized
INFO - 2016-01-27 09:10:00 --> Loader Class Initialized
INFO - 2016-01-27 09:10:00 --> Helper loaded: url_helper
INFO - 2016-01-27 09:10:00 --> Helper loaded: file_helper
INFO - 2016-01-27 09:10:00 --> Helper loaded: date_helper
INFO - 2016-01-27 09:10:00 --> Database Driver Class Initialized
INFO - 2016-01-27 09:10:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:10:01 --> Controller Class Initialized
INFO - 2016-01-27 09:10:01 --> Model Class Initialized
INFO - 2016-01-27 09:10:01 --> Model Class Initialized
INFO - 2016-01-27 09:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:10:01 --> Pagination Class Initialized
INFO - 2016-01-27 09:10:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:10:01 --> Helper loaded: form_helper
INFO - 2016-01-27 09:10:01 --> Form Validation Class Initialized
INFO - 2016-01-27 09:10:01 --> Model Class Initialized
ERROR - 2016-01-27 09:10:01 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-01-27 09:10:01 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-01-27 09:10:01 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-01-27 09:10:01 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-01-27 09:10:01 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-01-27 09:10:01 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 22
INFO - 2016-01-27 09:10:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 09:10:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 09:10:01 --> Final output sent to browser
DEBUG - 2016-01-27 09:10:01 --> Total execution time: 1.1930
INFO - 2016-01-27 09:10:09 --> Config Class Initialized
INFO - 2016-01-27 09:10:09 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:10:09 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:10:09 --> Utf8 Class Initialized
INFO - 2016-01-27 09:10:09 --> URI Class Initialized
INFO - 2016-01-27 09:10:09 --> Router Class Initialized
INFO - 2016-01-27 09:10:09 --> Output Class Initialized
INFO - 2016-01-27 09:10:09 --> Security Class Initialized
DEBUG - 2016-01-27 09:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:10:09 --> Input Class Initialized
INFO - 2016-01-27 09:10:09 --> Language Class Initialized
INFO - 2016-01-27 09:10:09 --> Loader Class Initialized
INFO - 2016-01-27 09:10:09 --> Helper loaded: url_helper
INFO - 2016-01-27 09:10:09 --> Helper loaded: file_helper
INFO - 2016-01-27 09:10:09 --> Helper loaded: date_helper
INFO - 2016-01-27 09:10:09 --> Database Driver Class Initialized
INFO - 2016-01-27 09:10:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:10:10 --> Controller Class Initialized
INFO - 2016-01-27 09:10:10 --> Model Class Initialized
INFO - 2016-01-27 09:10:10 --> Model Class Initialized
INFO - 2016-01-27 09:10:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:10:10 --> Pagination Class Initialized
INFO - 2016-01-27 09:10:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:10:10 --> Helper loaded: form_helper
INFO - 2016-01-27 09:10:10 --> Form Validation Class Initialized
INFO - 2016-01-27 09:10:10 --> Model Class Initialized
INFO - 2016-01-27 09:10:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 09:10:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 09:10:10 --> Final output sent to browser
DEBUG - 2016-01-27 09:10:10 --> Total execution time: 1.2329
INFO - 2016-01-27 09:11:40 --> Config Class Initialized
INFO - 2016-01-27 09:11:40 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:11:40 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:11:40 --> Utf8 Class Initialized
INFO - 2016-01-27 09:11:40 --> URI Class Initialized
DEBUG - 2016-01-27 09:11:40 --> No URI present. Default controller set.
INFO - 2016-01-27 09:11:40 --> Router Class Initialized
INFO - 2016-01-27 09:11:40 --> Output Class Initialized
INFO - 2016-01-27 09:11:40 --> Security Class Initialized
DEBUG - 2016-01-27 09:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:11:40 --> Input Class Initialized
INFO - 2016-01-27 09:11:40 --> Language Class Initialized
INFO - 2016-01-27 09:11:40 --> Loader Class Initialized
INFO - 2016-01-27 09:11:40 --> Helper loaded: url_helper
INFO - 2016-01-27 09:11:40 --> Helper loaded: file_helper
INFO - 2016-01-27 09:11:40 --> Helper loaded: date_helper
INFO - 2016-01-27 09:11:40 --> Database Driver Class Initialized
INFO - 2016-01-27 09:11:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:11:41 --> Controller Class Initialized
INFO - 2016-01-27 09:11:41 --> Model Class Initialized
INFO - 2016-01-27 09:11:41 --> Model Class Initialized
INFO - 2016-01-27 09:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:11:41 --> Pagination Class Initialized
INFO - 2016-01-27 09:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 09:11:41 --> Final output sent to browser
DEBUG - 2016-01-27 09:11:41 --> Total execution time: 1.1132
INFO - 2016-01-27 09:11:45 --> Config Class Initialized
INFO - 2016-01-27 09:11:45 --> Hooks Class Initialized
DEBUG - 2016-01-27 09:11:45 --> UTF-8 Support Enabled
INFO - 2016-01-27 09:11:45 --> Utf8 Class Initialized
INFO - 2016-01-27 09:11:45 --> URI Class Initialized
INFO - 2016-01-27 09:11:45 --> Router Class Initialized
INFO - 2016-01-27 09:11:45 --> Output Class Initialized
INFO - 2016-01-27 09:11:45 --> Security Class Initialized
DEBUG - 2016-01-27 09:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 09:11:45 --> Input Class Initialized
INFO - 2016-01-27 09:11:45 --> Language Class Initialized
INFO - 2016-01-27 09:11:45 --> Loader Class Initialized
INFO - 2016-01-27 09:11:45 --> Helper loaded: url_helper
INFO - 2016-01-27 09:11:45 --> Helper loaded: file_helper
INFO - 2016-01-27 09:11:45 --> Helper loaded: date_helper
INFO - 2016-01-27 09:11:45 --> Database Driver Class Initialized
INFO - 2016-01-27 09:11:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 09:11:46 --> Controller Class Initialized
INFO - 2016-01-27 09:11:46 --> Model Class Initialized
INFO - 2016-01-27 09:11:46 --> Model Class Initialized
INFO - 2016-01-27 09:11:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 09:11:46 --> Pagination Class Initialized
INFO - 2016-01-27 09:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 09:11:46 --> Helper loaded: form_helper
INFO - 2016-01-27 09:11:46 --> Form Validation Class Initialized
INFO - 2016-01-27 09:11:46 --> Model Class Initialized
INFO - 2016-01-27 09:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 09:11:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 09:11:46 --> Final output sent to browser
DEBUG - 2016-01-27 09:11:46 --> Total execution time: 1.2609
INFO - 2016-01-27 10:30:55 --> Config Class Initialized
INFO - 2016-01-27 10:30:55 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:30:55 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:30:55 --> Utf8 Class Initialized
INFO - 2016-01-27 10:30:55 --> URI Class Initialized
DEBUG - 2016-01-27 10:30:55 --> No URI present. Default controller set.
INFO - 2016-01-27 10:30:55 --> Router Class Initialized
INFO - 2016-01-27 10:30:55 --> Output Class Initialized
INFO - 2016-01-27 10:30:55 --> Security Class Initialized
DEBUG - 2016-01-27 10:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:30:55 --> Input Class Initialized
INFO - 2016-01-27 10:30:55 --> Language Class Initialized
INFO - 2016-01-27 10:30:55 --> Loader Class Initialized
INFO - 2016-01-27 10:30:55 --> Helper loaded: url_helper
INFO - 2016-01-27 10:30:55 --> Helper loaded: file_helper
INFO - 2016-01-27 10:30:55 --> Helper loaded: date_helper
INFO - 2016-01-27 10:30:55 --> Database Driver Class Initialized
INFO - 2016-01-27 10:30:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:30:57 --> Controller Class Initialized
INFO - 2016-01-27 10:30:57 --> Model Class Initialized
INFO - 2016-01-27 10:30:57 --> Model Class Initialized
INFO - 2016-01-27 10:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:30:57 --> Pagination Class Initialized
INFO - 2016-01-27 10:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:30:57 --> Final output sent to browser
DEBUG - 2016-01-27 10:30:57 --> Total execution time: 1.1298
INFO - 2016-01-27 10:30:59 --> Config Class Initialized
INFO - 2016-01-27 10:30:59 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:30:59 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:30:59 --> Utf8 Class Initialized
INFO - 2016-01-27 10:30:59 --> URI Class Initialized
INFO - 2016-01-27 10:30:59 --> Router Class Initialized
INFO - 2016-01-27 10:30:59 --> Output Class Initialized
INFO - 2016-01-27 10:30:59 --> Security Class Initialized
DEBUG - 2016-01-27 10:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:30:59 --> Input Class Initialized
INFO - 2016-01-27 10:30:59 --> Language Class Initialized
INFO - 2016-01-27 10:30:59 --> Loader Class Initialized
INFO - 2016-01-27 10:30:59 --> Helper loaded: url_helper
INFO - 2016-01-27 10:30:59 --> Helper loaded: file_helper
INFO - 2016-01-27 10:30:59 --> Helper loaded: date_helper
INFO - 2016-01-27 10:30:59 --> Database Driver Class Initialized
INFO - 2016-01-27 10:31:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:31:00 --> Controller Class Initialized
INFO - 2016-01-27 10:31:00 --> Model Class Initialized
INFO - 2016-01-27 10:31:00 --> Model Class Initialized
INFO - 2016-01-27 10:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:31:00 --> Pagination Class Initialized
INFO - 2016-01-27 10:31:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:31:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:31:00 --> Final output sent to browser
DEBUG - 2016-01-27 10:31:00 --> Total execution time: 1.1160
INFO - 2016-01-27 10:31:04 --> Config Class Initialized
INFO - 2016-01-27 10:31:04 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:31:04 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:31:04 --> Utf8 Class Initialized
INFO - 2016-01-27 10:31:04 --> URI Class Initialized
INFO - 2016-01-27 10:31:04 --> Router Class Initialized
INFO - 2016-01-27 10:31:04 --> Output Class Initialized
INFO - 2016-01-27 10:31:04 --> Security Class Initialized
DEBUG - 2016-01-27 10:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:31:04 --> Input Class Initialized
INFO - 2016-01-27 10:31:04 --> Language Class Initialized
INFO - 2016-01-27 10:31:04 --> Loader Class Initialized
INFO - 2016-01-27 10:31:04 --> Helper loaded: url_helper
INFO - 2016-01-27 10:31:04 --> Helper loaded: file_helper
INFO - 2016-01-27 10:31:04 --> Helper loaded: date_helper
INFO - 2016-01-27 10:31:04 --> Database Driver Class Initialized
INFO - 2016-01-27 10:31:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:31:05 --> Controller Class Initialized
INFO - 2016-01-27 10:31:05 --> Model Class Initialized
INFO - 2016-01-27 10:31:05 --> Model Class Initialized
INFO - 2016-01-27 10:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:31:05 --> Pagination Class Initialized
INFO - 2016-01-27 10:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:31:05 --> Helper loaded: form_helper
INFO - 2016-01-27 10:31:05 --> Form Validation Class Initialized
INFO - 2016-01-27 10:31:05 --> Model Class Initialized
INFO - 2016-01-27 10:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:31:05 --> Final output sent to browser
DEBUG - 2016-01-27 10:31:05 --> Total execution time: 1.2307
INFO - 2016-01-27 10:32:40 --> Config Class Initialized
INFO - 2016-01-27 10:32:40 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:32:40 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:32:40 --> Utf8 Class Initialized
INFO - 2016-01-27 10:32:40 --> URI Class Initialized
INFO - 2016-01-27 10:32:40 --> Router Class Initialized
INFO - 2016-01-27 10:32:40 --> Output Class Initialized
INFO - 2016-01-27 10:32:40 --> Security Class Initialized
DEBUG - 2016-01-27 10:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:32:40 --> Input Class Initialized
INFO - 2016-01-27 10:32:40 --> Language Class Initialized
INFO - 2016-01-27 10:32:40 --> Loader Class Initialized
INFO - 2016-01-27 10:32:40 --> Helper loaded: url_helper
INFO - 2016-01-27 10:32:40 --> Helper loaded: file_helper
INFO - 2016-01-27 10:32:40 --> Helper loaded: date_helper
INFO - 2016-01-27 10:32:40 --> Database Driver Class Initialized
INFO - 2016-01-27 10:32:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:32:41 --> Controller Class Initialized
INFO - 2016-01-27 10:32:41 --> Model Class Initialized
INFO - 2016-01-27 10:32:41 --> Model Class Initialized
INFO - 2016-01-27 10:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:32:41 --> Pagination Class Initialized
INFO - 2016-01-27 10:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:32:41 --> Helper loaded: form_helper
INFO - 2016-01-27 10:32:41 --> Form Validation Class Initialized
INFO - 2016-01-27 10:32:41 --> Model Class Initialized
INFO - 2016-01-27 10:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:32:41 --> Final output sent to browser
DEBUG - 2016-01-27 10:32:41 --> Total execution time: 1.1909
INFO - 2016-01-27 10:34:05 --> Config Class Initialized
INFO - 2016-01-27 10:34:05 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:34:05 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:34:05 --> Utf8 Class Initialized
INFO - 2016-01-27 10:34:05 --> URI Class Initialized
DEBUG - 2016-01-27 10:34:05 --> No URI present. Default controller set.
INFO - 2016-01-27 10:34:05 --> Router Class Initialized
INFO - 2016-01-27 10:34:05 --> Output Class Initialized
INFO - 2016-01-27 10:34:05 --> Security Class Initialized
DEBUG - 2016-01-27 10:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:34:05 --> Input Class Initialized
INFO - 2016-01-27 10:34:05 --> Language Class Initialized
INFO - 2016-01-27 10:34:05 --> Loader Class Initialized
INFO - 2016-01-27 10:34:05 --> Helper loaded: url_helper
INFO - 2016-01-27 10:34:05 --> Helper loaded: file_helper
INFO - 2016-01-27 10:34:05 --> Helper loaded: date_helper
INFO - 2016-01-27 10:34:05 --> Database Driver Class Initialized
INFO - 2016-01-27 10:34:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:34:07 --> Controller Class Initialized
INFO - 2016-01-27 10:34:07 --> Model Class Initialized
INFO - 2016-01-27 10:34:07 --> Model Class Initialized
INFO - 2016-01-27 10:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:34:07 --> Pagination Class Initialized
INFO - 2016-01-27 10:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:34:07 --> Final output sent to browser
DEBUG - 2016-01-27 10:34:07 --> Total execution time: 1.1178
INFO - 2016-01-27 10:34:08 --> Config Class Initialized
INFO - 2016-01-27 10:34:08 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:34:08 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:34:08 --> Utf8 Class Initialized
INFO - 2016-01-27 10:34:08 --> URI Class Initialized
INFO - 2016-01-27 10:34:08 --> Router Class Initialized
INFO - 2016-01-27 10:34:08 --> Output Class Initialized
INFO - 2016-01-27 10:34:08 --> Security Class Initialized
DEBUG - 2016-01-27 10:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:34:08 --> Input Class Initialized
INFO - 2016-01-27 10:34:08 --> Language Class Initialized
INFO - 2016-01-27 10:34:08 --> Loader Class Initialized
INFO - 2016-01-27 10:34:08 --> Helper loaded: url_helper
INFO - 2016-01-27 10:34:08 --> Helper loaded: file_helper
INFO - 2016-01-27 10:34:08 --> Helper loaded: date_helper
INFO - 2016-01-27 10:34:08 --> Database Driver Class Initialized
INFO - 2016-01-27 10:34:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:34:09 --> Controller Class Initialized
INFO - 2016-01-27 10:34:09 --> Model Class Initialized
INFO - 2016-01-27 10:34:09 --> Model Class Initialized
INFO - 2016-01-27 10:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:34:09 --> Pagination Class Initialized
INFO - 2016-01-27 10:34:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:34:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:34:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:34:09 --> Final output sent to browser
DEBUG - 2016-01-27 10:34:09 --> Total execution time: 1.1590
INFO - 2016-01-27 10:35:09 --> Config Class Initialized
INFO - 2016-01-27 10:35:09 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:35:09 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:35:09 --> Utf8 Class Initialized
INFO - 2016-01-27 10:35:09 --> URI Class Initialized
DEBUG - 2016-01-27 10:35:09 --> No URI present. Default controller set.
INFO - 2016-01-27 10:35:09 --> Router Class Initialized
INFO - 2016-01-27 10:35:09 --> Output Class Initialized
INFO - 2016-01-27 10:35:09 --> Security Class Initialized
DEBUG - 2016-01-27 10:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:35:09 --> Input Class Initialized
INFO - 2016-01-27 10:35:09 --> Language Class Initialized
INFO - 2016-01-27 10:35:09 --> Loader Class Initialized
INFO - 2016-01-27 10:35:09 --> Helper loaded: url_helper
INFO - 2016-01-27 10:35:09 --> Helper loaded: file_helper
INFO - 2016-01-27 10:35:09 --> Helper loaded: date_helper
INFO - 2016-01-27 10:35:09 --> Database Driver Class Initialized
INFO - 2016-01-27 10:35:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:35:10 --> Controller Class Initialized
INFO - 2016-01-27 10:35:10 --> Model Class Initialized
INFO - 2016-01-27 10:35:10 --> Model Class Initialized
INFO - 2016-01-27 10:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:35:10 --> Pagination Class Initialized
INFO - 2016-01-27 10:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:35:10 --> Final output sent to browser
DEBUG - 2016-01-27 10:35:10 --> Total execution time: 1.1434
INFO - 2016-01-27 10:35:13 --> Config Class Initialized
INFO - 2016-01-27 10:35:13 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:35:13 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:35:13 --> Utf8 Class Initialized
INFO - 2016-01-27 10:35:13 --> URI Class Initialized
INFO - 2016-01-27 10:35:13 --> Router Class Initialized
INFO - 2016-01-27 10:35:13 --> Output Class Initialized
INFO - 2016-01-27 10:35:13 --> Security Class Initialized
DEBUG - 2016-01-27 10:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:35:13 --> Input Class Initialized
INFO - 2016-01-27 10:35:13 --> Language Class Initialized
INFO - 2016-01-27 10:35:13 --> Loader Class Initialized
INFO - 2016-01-27 10:35:13 --> Helper loaded: url_helper
INFO - 2016-01-27 10:35:13 --> Helper loaded: file_helper
INFO - 2016-01-27 10:35:13 --> Helper loaded: date_helper
INFO - 2016-01-27 10:35:13 --> Database Driver Class Initialized
INFO - 2016-01-27 10:35:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:35:14 --> Controller Class Initialized
INFO - 2016-01-27 10:35:14 --> Model Class Initialized
INFO - 2016-01-27 10:35:14 --> Model Class Initialized
INFO - 2016-01-27 10:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:35:14 --> Pagination Class Initialized
INFO - 2016-01-27 10:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:35:14 --> Final output sent to browser
DEBUG - 2016-01-27 10:35:14 --> Total execution time: 1.1830
INFO - 2016-01-27 10:38:21 --> Config Class Initialized
INFO - 2016-01-27 10:38:21 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:38:21 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:38:21 --> Utf8 Class Initialized
INFO - 2016-01-27 10:38:21 --> URI Class Initialized
INFO - 2016-01-27 10:38:21 --> Router Class Initialized
INFO - 2016-01-27 10:38:21 --> Output Class Initialized
INFO - 2016-01-27 10:38:21 --> Security Class Initialized
DEBUG - 2016-01-27 10:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:38:21 --> Input Class Initialized
INFO - 2016-01-27 10:38:21 --> Language Class Initialized
INFO - 2016-01-27 10:38:21 --> Loader Class Initialized
INFO - 2016-01-27 10:38:21 --> Helper loaded: url_helper
INFO - 2016-01-27 10:38:21 --> Helper loaded: file_helper
INFO - 2016-01-27 10:38:21 --> Helper loaded: date_helper
INFO - 2016-01-27 10:38:21 --> Database Driver Class Initialized
INFO - 2016-01-27 10:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:38:22 --> Controller Class Initialized
INFO - 2016-01-27 10:38:22 --> Model Class Initialized
INFO - 2016-01-27 10:38:22 --> Model Class Initialized
INFO - 2016-01-27 10:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:38:22 --> Pagination Class Initialized
INFO - 2016-01-27 10:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:38:22 --> Final output sent to browser
DEBUG - 2016-01-27 10:38:22 --> Total execution time: 1.1869
INFO - 2016-01-27 10:39:58 --> Config Class Initialized
INFO - 2016-01-27 10:39:58 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:39:58 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:39:58 --> Utf8 Class Initialized
INFO - 2016-01-27 10:39:58 --> URI Class Initialized
INFO - 2016-01-27 10:39:58 --> Router Class Initialized
INFO - 2016-01-27 10:39:58 --> Output Class Initialized
INFO - 2016-01-27 10:39:58 --> Security Class Initialized
DEBUG - 2016-01-27 10:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:39:58 --> Input Class Initialized
INFO - 2016-01-27 10:39:58 --> Language Class Initialized
INFO - 2016-01-27 10:39:58 --> Loader Class Initialized
INFO - 2016-01-27 10:39:58 --> Helper loaded: url_helper
INFO - 2016-01-27 10:39:58 --> Helper loaded: file_helper
INFO - 2016-01-27 10:39:58 --> Helper loaded: date_helper
INFO - 2016-01-27 10:39:58 --> Database Driver Class Initialized
INFO - 2016-01-27 10:39:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:39:59 --> Controller Class Initialized
INFO - 2016-01-27 10:39:59 --> Model Class Initialized
INFO - 2016-01-27 10:39:59 --> Model Class Initialized
INFO - 2016-01-27 10:39:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:39:59 --> Pagination Class Initialized
INFO - 2016-01-27 10:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:39:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:39:59 --> Final output sent to browser
DEBUG - 2016-01-27 10:39:59 --> Total execution time: 1.1428
INFO - 2016-01-27 10:40:28 --> Config Class Initialized
INFO - 2016-01-27 10:40:28 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:40:28 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:40:28 --> Utf8 Class Initialized
INFO - 2016-01-27 10:40:28 --> URI Class Initialized
INFO - 2016-01-27 10:40:28 --> Router Class Initialized
INFO - 2016-01-27 10:40:28 --> Output Class Initialized
INFO - 2016-01-27 10:40:28 --> Security Class Initialized
DEBUG - 2016-01-27 10:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:40:28 --> Input Class Initialized
INFO - 2016-01-27 10:40:28 --> Language Class Initialized
INFO - 2016-01-27 10:40:28 --> Loader Class Initialized
INFO - 2016-01-27 10:40:28 --> Helper loaded: url_helper
INFO - 2016-01-27 10:40:28 --> Helper loaded: file_helper
INFO - 2016-01-27 10:40:28 --> Helper loaded: date_helper
INFO - 2016-01-27 10:40:28 --> Database Driver Class Initialized
INFO - 2016-01-27 10:40:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:40:29 --> Controller Class Initialized
INFO - 2016-01-27 10:40:29 --> Model Class Initialized
INFO - 2016-01-27 10:40:29 --> Model Class Initialized
INFO - 2016-01-27 10:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:40:29 --> Pagination Class Initialized
INFO - 2016-01-27 10:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:40:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:40:29 --> Final output sent to browser
DEBUG - 2016-01-27 10:40:29 --> Total execution time: 1.1463
INFO - 2016-01-27 10:40:48 --> Config Class Initialized
INFO - 2016-01-27 10:40:48 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:40:48 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:40:48 --> Utf8 Class Initialized
INFO - 2016-01-27 10:40:48 --> URI Class Initialized
INFO - 2016-01-27 10:40:48 --> Router Class Initialized
INFO - 2016-01-27 10:40:48 --> Output Class Initialized
INFO - 2016-01-27 10:40:48 --> Security Class Initialized
DEBUG - 2016-01-27 10:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:40:48 --> Input Class Initialized
INFO - 2016-01-27 10:40:48 --> Language Class Initialized
INFO - 2016-01-27 10:40:48 --> Loader Class Initialized
INFO - 2016-01-27 10:40:48 --> Helper loaded: url_helper
INFO - 2016-01-27 10:40:48 --> Helper loaded: file_helper
INFO - 2016-01-27 10:40:48 --> Helper loaded: date_helper
INFO - 2016-01-27 10:40:48 --> Database Driver Class Initialized
INFO - 2016-01-27 10:40:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:40:49 --> Controller Class Initialized
INFO - 2016-01-27 10:40:49 --> Model Class Initialized
INFO - 2016-01-27 10:40:49 --> Model Class Initialized
INFO - 2016-01-27 10:40:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:40:49 --> Pagination Class Initialized
INFO - 2016-01-27 10:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:40:49 --> Final output sent to browser
DEBUG - 2016-01-27 10:40:49 --> Total execution time: 1.1172
INFO - 2016-01-27 10:41:05 --> Config Class Initialized
INFO - 2016-01-27 10:41:05 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:41:05 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:41:05 --> Utf8 Class Initialized
INFO - 2016-01-27 10:41:05 --> URI Class Initialized
INFO - 2016-01-27 10:41:05 --> Router Class Initialized
INFO - 2016-01-27 10:41:05 --> Output Class Initialized
INFO - 2016-01-27 10:41:05 --> Security Class Initialized
DEBUG - 2016-01-27 10:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:41:05 --> Input Class Initialized
INFO - 2016-01-27 10:41:05 --> Language Class Initialized
INFO - 2016-01-27 10:41:05 --> Loader Class Initialized
INFO - 2016-01-27 10:41:05 --> Helper loaded: url_helper
INFO - 2016-01-27 10:41:05 --> Helper loaded: file_helper
INFO - 2016-01-27 10:41:05 --> Helper loaded: date_helper
INFO - 2016-01-27 10:41:05 --> Database Driver Class Initialized
INFO - 2016-01-27 10:41:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:41:06 --> Controller Class Initialized
INFO - 2016-01-27 10:41:06 --> Model Class Initialized
INFO - 2016-01-27 10:41:06 --> Model Class Initialized
INFO - 2016-01-27 10:41:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:41:06 --> Pagination Class Initialized
INFO - 2016-01-27 10:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:41:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:41:06 --> Final output sent to browser
DEBUG - 2016-01-27 10:41:06 --> Total execution time: 1.1372
INFO - 2016-01-27 10:41:17 --> Config Class Initialized
INFO - 2016-01-27 10:41:17 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:41:17 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:41:17 --> Utf8 Class Initialized
INFO - 2016-01-27 10:41:17 --> URI Class Initialized
INFO - 2016-01-27 10:41:17 --> Router Class Initialized
INFO - 2016-01-27 10:41:17 --> Output Class Initialized
INFO - 2016-01-27 10:41:17 --> Security Class Initialized
DEBUG - 2016-01-27 10:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:41:17 --> Input Class Initialized
INFO - 2016-01-27 10:41:17 --> Language Class Initialized
INFO - 2016-01-27 10:41:17 --> Loader Class Initialized
INFO - 2016-01-27 10:41:17 --> Helper loaded: url_helper
INFO - 2016-01-27 10:41:17 --> Helper loaded: file_helper
INFO - 2016-01-27 10:41:17 --> Helper loaded: date_helper
INFO - 2016-01-27 10:41:17 --> Database Driver Class Initialized
INFO - 2016-01-27 10:41:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:41:18 --> Controller Class Initialized
INFO - 2016-01-27 10:41:18 --> Model Class Initialized
INFO - 2016-01-27 10:41:18 --> Model Class Initialized
INFO - 2016-01-27 10:41:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:41:18 --> Pagination Class Initialized
INFO - 2016-01-27 10:41:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:41:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:41:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:41:18 --> Final output sent to browser
DEBUG - 2016-01-27 10:41:18 --> Total execution time: 1.2376
INFO - 2016-01-27 10:41:37 --> Config Class Initialized
INFO - 2016-01-27 10:41:37 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:41:37 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:41:37 --> Utf8 Class Initialized
INFO - 2016-01-27 10:41:37 --> URI Class Initialized
INFO - 2016-01-27 10:41:37 --> Router Class Initialized
INFO - 2016-01-27 10:41:37 --> Output Class Initialized
INFO - 2016-01-27 10:41:37 --> Security Class Initialized
DEBUG - 2016-01-27 10:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:41:37 --> Input Class Initialized
INFO - 2016-01-27 10:41:37 --> Language Class Initialized
INFO - 2016-01-27 10:41:37 --> Loader Class Initialized
INFO - 2016-01-27 10:41:37 --> Helper loaded: url_helper
INFO - 2016-01-27 10:41:37 --> Helper loaded: file_helper
INFO - 2016-01-27 10:41:37 --> Helper loaded: date_helper
INFO - 2016-01-27 10:41:37 --> Database Driver Class Initialized
INFO - 2016-01-27 10:41:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:41:38 --> Controller Class Initialized
INFO - 2016-01-27 10:41:38 --> Model Class Initialized
INFO - 2016-01-27 10:41:38 --> Model Class Initialized
INFO - 2016-01-27 10:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:41:38 --> Pagination Class Initialized
INFO - 2016-01-27 10:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:41:39 --> Final output sent to browser
DEBUG - 2016-01-27 10:41:39 --> Total execution time: 1.1322
INFO - 2016-01-27 10:41:59 --> Config Class Initialized
INFO - 2016-01-27 10:41:59 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:41:59 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:41:59 --> Utf8 Class Initialized
INFO - 2016-01-27 10:41:59 --> URI Class Initialized
DEBUG - 2016-01-27 10:41:59 --> No URI present. Default controller set.
INFO - 2016-01-27 10:41:59 --> Router Class Initialized
INFO - 2016-01-27 10:41:59 --> Output Class Initialized
INFO - 2016-01-27 10:41:59 --> Security Class Initialized
DEBUG - 2016-01-27 10:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:41:59 --> Input Class Initialized
INFO - 2016-01-27 10:41:59 --> Language Class Initialized
INFO - 2016-01-27 10:41:59 --> Loader Class Initialized
INFO - 2016-01-27 10:41:59 --> Helper loaded: url_helper
INFO - 2016-01-27 10:41:59 --> Helper loaded: file_helper
INFO - 2016-01-27 10:41:59 --> Helper loaded: date_helper
INFO - 2016-01-27 10:41:59 --> Database Driver Class Initialized
INFO - 2016-01-27 10:42:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:42:00 --> Controller Class Initialized
INFO - 2016-01-27 10:42:00 --> Model Class Initialized
INFO - 2016-01-27 10:42:00 --> Model Class Initialized
INFO - 2016-01-27 10:42:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:42:00 --> Pagination Class Initialized
INFO - 2016-01-27 10:42:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:42:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:42:00 --> Final output sent to browser
DEBUG - 2016-01-27 10:42:00 --> Total execution time: 1.1145
INFO - 2016-01-27 10:42:02 --> Config Class Initialized
INFO - 2016-01-27 10:42:02 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:42:02 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:42:02 --> Utf8 Class Initialized
INFO - 2016-01-27 10:42:02 --> URI Class Initialized
INFO - 2016-01-27 10:42:02 --> Router Class Initialized
INFO - 2016-01-27 10:42:02 --> Output Class Initialized
INFO - 2016-01-27 10:42:02 --> Security Class Initialized
DEBUG - 2016-01-27 10:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:42:02 --> Input Class Initialized
INFO - 2016-01-27 10:42:02 --> Language Class Initialized
INFO - 2016-01-27 10:42:02 --> Loader Class Initialized
INFO - 2016-01-27 10:42:02 --> Helper loaded: url_helper
INFO - 2016-01-27 10:42:02 --> Helper loaded: file_helper
INFO - 2016-01-27 10:42:02 --> Helper loaded: date_helper
INFO - 2016-01-27 10:42:02 --> Database Driver Class Initialized
INFO - 2016-01-27 10:42:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:42:03 --> Controller Class Initialized
INFO - 2016-01-27 10:42:03 --> Model Class Initialized
INFO - 2016-01-27 10:42:03 --> Model Class Initialized
INFO - 2016-01-27 10:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:42:03 --> Pagination Class Initialized
INFO - 2016-01-27 10:42:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:42:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:42:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:42:03 --> Final output sent to browser
DEBUG - 2016-01-27 10:42:03 --> Total execution time: 1.1531
INFO - 2016-01-27 10:42:42 --> Config Class Initialized
INFO - 2016-01-27 10:42:42 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:42:42 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:42:42 --> Utf8 Class Initialized
INFO - 2016-01-27 10:42:42 --> URI Class Initialized
INFO - 2016-01-27 10:42:42 --> Router Class Initialized
INFO - 2016-01-27 10:42:42 --> Output Class Initialized
INFO - 2016-01-27 10:42:42 --> Security Class Initialized
DEBUG - 2016-01-27 10:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:42:42 --> Input Class Initialized
INFO - 2016-01-27 10:42:42 --> Language Class Initialized
INFO - 2016-01-27 10:42:42 --> Loader Class Initialized
INFO - 2016-01-27 10:42:42 --> Helper loaded: url_helper
INFO - 2016-01-27 10:42:42 --> Helper loaded: file_helper
INFO - 2016-01-27 10:42:42 --> Helper loaded: date_helper
INFO - 2016-01-27 10:42:42 --> Database Driver Class Initialized
INFO - 2016-01-27 10:42:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:42:43 --> Controller Class Initialized
INFO - 2016-01-27 10:42:43 --> Model Class Initialized
INFO - 2016-01-27 10:42:43 --> Model Class Initialized
INFO - 2016-01-27 10:42:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:42:43 --> Pagination Class Initialized
INFO - 2016-01-27 10:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:42:43 --> Final output sent to browser
DEBUG - 2016-01-27 10:42:43 --> Total execution time: 1.1481
INFO - 2016-01-27 10:42:51 --> Config Class Initialized
INFO - 2016-01-27 10:42:51 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:42:51 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:42:51 --> Utf8 Class Initialized
INFO - 2016-01-27 10:42:51 --> URI Class Initialized
INFO - 2016-01-27 10:42:51 --> Router Class Initialized
INFO - 2016-01-27 10:42:51 --> Output Class Initialized
INFO - 2016-01-27 10:42:51 --> Security Class Initialized
DEBUG - 2016-01-27 10:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:42:51 --> Input Class Initialized
INFO - 2016-01-27 10:42:51 --> Language Class Initialized
INFO - 2016-01-27 10:42:51 --> Loader Class Initialized
INFO - 2016-01-27 10:42:51 --> Helper loaded: url_helper
INFO - 2016-01-27 10:42:51 --> Helper loaded: file_helper
INFO - 2016-01-27 10:42:51 --> Helper loaded: date_helper
INFO - 2016-01-27 10:42:51 --> Database Driver Class Initialized
INFO - 2016-01-27 10:42:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:42:52 --> Controller Class Initialized
INFO - 2016-01-27 10:42:52 --> Model Class Initialized
INFO - 2016-01-27 10:42:52 --> Model Class Initialized
INFO - 2016-01-27 10:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:42:52 --> Pagination Class Initialized
INFO - 2016-01-27 10:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:42:52 --> Final output sent to browser
DEBUG - 2016-01-27 10:42:52 --> Total execution time: 1.1211
INFO - 2016-01-27 10:43:00 --> Config Class Initialized
INFO - 2016-01-27 10:43:00 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:43:00 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:43:00 --> Utf8 Class Initialized
INFO - 2016-01-27 10:43:00 --> URI Class Initialized
DEBUG - 2016-01-27 10:43:00 --> No URI present. Default controller set.
INFO - 2016-01-27 10:43:00 --> Router Class Initialized
INFO - 2016-01-27 10:43:00 --> Output Class Initialized
INFO - 2016-01-27 10:43:00 --> Security Class Initialized
DEBUG - 2016-01-27 10:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:43:00 --> Input Class Initialized
INFO - 2016-01-27 10:43:00 --> Language Class Initialized
INFO - 2016-01-27 10:43:00 --> Loader Class Initialized
INFO - 2016-01-27 10:43:00 --> Helper loaded: url_helper
INFO - 2016-01-27 10:43:00 --> Helper loaded: file_helper
INFO - 2016-01-27 10:43:00 --> Helper loaded: date_helper
INFO - 2016-01-27 10:43:00 --> Database Driver Class Initialized
INFO - 2016-01-27 10:43:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:43:01 --> Controller Class Initialized
INFO - 2016-01-27 10:43:01 --> Model Class Initialized
INFO - 2016-01-27 10:43:01 --> Model Class Initialized
INFO - 2016-01-27 10:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:43:01 --> Pagination Class Initialized
INFO - 2016-01-27 10:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:43:01 --> Final output sent to browser
DEBUG - 2016-01-27 10:43:01 --> Total execution time: 1.1048
INFO - 2016-01-27 10:43:03 --> Config Class Initialized
INFO - 2016-01-27 10:43:03 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:43:03 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:43:03 --> Utf8 Class Initialized
INFO - 2016-01-27 10:43:03 --> URI Class Initialized
INFO - 2016-01-27 10:43:03 --> Router Class Initialized
INFO - 2016-01-27 10:43:03 --> Output Class Initialized
INFO - 2016-01-27 10:43:03 --> Security Class Initialized
DEBUG - 2016-01-27 10:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:43:03 --> Input Class Initialized
INFO - 2016-01-27 10:43:03 --> Language Class Initialized
INFO - 2016-01-27 10:43:03 --> Loader Class Initialized
INFO - 2016-01-27 10:43:03 --> Helper loaded: url_helper
INFO - 2016-01-27 10:43:03 --> Helper loaded: file_helper
INFO - 2016-01-27 10:43:03 --> Helper loaded: date_helper
INFO - 2016-01-27 10:43:03 --> Database Driver Class Initialized
INFO - 2016-01-27 10:43:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:43:04 --> Controller Class Initialized
INFO - 2016-01-27 10:43:04 --> Model Class Initialized
INFO - 2016-01-27 10:43:04 --> Model Class Initialized
INFO - 2016-01-27 10:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:43:04 --> Pagination Class Initialized
INFO - 2016-01-27 10:43:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:43:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:43:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:43:04 --> Final output sent to browser
DEBUG - 2016-01-27 10:43:04 --> Total execution time: 1.1583
INFO - 2016-01-27 10:44:07 --> Config Class Initialized
INFO - 2016-01-27 10:44:07 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:44:07 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:44:07 --> Utf8 Class Initialized
INFO - 2016-01-27 10:44:07 --> URI Class Initialized
DEBUG - 2016-01-27 10:44:07 --> No URI present. Default controller set.
INFO - 2016-01-27 10:44:07 --> Router Class Initialized
INFO - 2016-01-27 10:44:07 --> Output Class Initialized
INFO - 2016-01-27 10:44:07 --> Security Class Initialized
DEBUG - 2016-01-27 10:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:44:07 --> Input Class Initialized
INFO - 2016-01-27 10:44:07 --> Language Class Initialized
INFO - 2016-01-27 10:44:07 --> Loader Class Initialized
INFO - 2016-01-27 10:44:07 --> Helper loaded: url_helper
INFO - 2016-01-27 10:44:07 --> Helper loaded: file_helper
INFO - 2016-01-27 10:44:07 --> Helper loaded: date_helper
INFO - 2016-01-27 10:44:07 --> Database Driver Class Initialized
INFO - 2016-01-27 10:44:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:44:08 --> Controller Class Initialized
INFO - 2016-01-27 10:44:08 --> Model Class Initialized
INFO - 2016-01-27 10:44:08 --> Model Class Initialized
INFO - 2016-01-27 10:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:44:08 --> Pagination Class Initialized
INFO - 2016-01-27 10:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:44:08 --> Final output sent to browser
DEBUG - 2016-01-27 10:44:08 --> Total execution time: 1.1170
INFO - 2016-01-27 10:44:11 --> Config Class Initialized
INFO - 2016-01-27 10:44:11 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:44:11 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:44:11 --> Utf8 Class Initialized
INFO - 2016-01-27 10:44:11 --> URI Class Initialized
INFO - 2016-01-27 10:44:11 --> Router Class Initialized
INFO - 2016-01-27 10:44:11 --> Output Class Initialized
INFO - 2016-01-27 10:44:11 --> Security Class Initialized
DEBUG - 2016-01-27 10:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:44:11 --> Input Class Initialized
INFO - 2016-01-27 10:44:11 --> Language Class Initialized
INFO - 2016-01-27 10:44:11 --> Loader Class Initialized
INFO - 2016-01-27 10:44:11 --> Helper loaded: url_helper
INFO - 2016-01-27 10:44:11 --> Helper loaded: file_helper
INFO - 2016-01-27 10:44:11 --> Helper loaded: date_helper
INFO - 2016-01-27 10:44:11 --> Database Driver Class Initialized
INFO - 2016-01-27 10:44:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:44:12 --> Controller Class Initialized
INFO - 2016-01-27 10:44:12 --> Model Class Initialized
INFO - 2016-01-27 10:44:12 --> Model Class Initialized
INFO - 2016-01-27 10:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:44:12 --> Pagination Class Initialized
INFO - 2016-01-27 10:44:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:44:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:44:12 --> Final output sent to browser
DEBUG - 2016-01-27 10:44:12 --> Total execution time: 1.0983
INFO - 2016-01-27 10:44:23 --> Config Class Initialized
INFO - 2016-01-27 10:44:23 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:44:23 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:44:23 --> Utf8 Class Initialized
INFO - 2016-01-27 10:44:23 --> URI Class Initialized
INFO - 2016-01-27 10:44:23 --> Router Class Initialized
INFO - 2016-01-27 10:44:23 --> Output Class Initialized
INFO - 2016-01-27 10:44:23 --> Security Class Initialized
DEBUG - 2016-01-27 10:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:44:23 --> Input Class Initialized
INFO - 2016-01-27 10:44:23 --> Language Class Initialized
INFO - 2016-01-27 10:44:23 --> Loader Class Initialized
INFO - 2016-01-27 10:44:23 --> Helper loaded: url_helper
INFO - 2016-01-27 10:44:23 --> Helper loaded: file_helper
INFO - 2016-01-27 10:44:23 --> Helper loaded: date_helper
INFO - 2016-01-27 10:44:23 --> Database Driver Class Initialized
INFO - 2016-01-27 10:44:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:44:24 --> Controller Class Initialized
INFO - 2016-01-27 10:44:24 --> Model Class Initialized
INFO - 2016-01-27 10:44:24 --> Model Class Initialized
INFO - 2016-01-27 10:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:44:24 --> Pagination Class Initialized
INFO - 2016-01-27 10:44:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:44:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:44:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:44:24 --> Final output sent to browser
DEBUG - 2016-01-27 10:44:24 --> Total execution time: 1.1940
INFO - 2016-01-27 10:45:02 --> Config Class Initialized
INFO - 2016-01-27 10:45:02 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:45:02 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:45:03 --> Utf8 Class Initialized
INFO - 2016-01-27 10:45:03 --> URI Class Initialized
DEBUG - 2016-01-27 10:45:03 --> No URI present. Default controller set.
INFO - 2016-01-27 10:45:03 --> Router Class Initialized
INFO - 2016-01-27 10:45:03 --> Output Class Initialized
INFO - 2016-01-27 10:45:03 --> Security Class Initialized
DEBUG - 2016-01-27 10:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:45:03 --> Input Class Initialized
INFO - 2016-01-27 10:45:03 --> Language Class Initialized
INFO - 2016-01-27 10:45:03 --> Loader Class Initialized
INFO - 2016-01-27 10:45:03 --> Helper loaded: url_helper
INFO - 2016-01-27 10:45:03 --> Helper loaded: file_helper
INFO - 2016-01-27 10:45:03 --> Helper loaded: date_helper
INFO - 2016-01-27 10:45:03 --> Database Driver Class Initialized
INFO - 2016-01-27 10:45:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:45:04 --> Controller Class Initialized
INFO - 2016-01-27 10:45:04 --> Model Class Initialized
INFO - 2016-01-27 10:45:04 --> Model Class Initialized
INFO - 2016-01-27 10:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:45:04 --> Pagination Class Initialized
INFO - 2016-01-27 10:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:45:04 --> Final output sent to browser
DEBUG - 2016-01-27 10:45:04 --> Total execution time: 1.1372
INFO - 2016-01-27 10:45:06 --> Config Class Initialized
INFO - 2016-01-27 10:45:06 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:45:06 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:45:06 --> Utf8 Class Initialized
INFO - 2016-01-27 10:45:06 --> URI Class Initialized
INFO - 2016-01-27 10:45:06 --> Router Class Initialized
INFO - 2016-01-27 10:45:06 --> Output Class Initialized
INFO - 2016-01-27 10:45:06 --> Security Class Initialized
DEBUG - 2016-01-27 10:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:45:06 --> Input Class Initialized
INFO - 2016-01-27 10:45:06 --> Language Class Initialized
INFO - 2016-01-27 10:45:06 --> Loader Class Initialized
INFO - 2016-01-27 10:45:06 --> Helper loaded: url_helper
INFO - 2016-01-27 10:45:06 --> Helper loaded: file_helper
INFO - 2016-01-27 10:45:06 --> Helper loaded: date_helper
INFO - 2016-01-27 10:45:06 --> Database Driver Class Initialized
INFO - 2016-01-27 10:45:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:45:07 --> Controller Class Initialized
INFO - 2016-01-27 10:45:07 --> Model Class Initialized
INFO - 2016-01-27 10:45:07 --> Model Class Initialized
INFO - 2016-01-27 10:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:45:07 --> Pagination Class Initialized
INFO - 2016-01-27 10:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:45:07 --> Final output sent to browser
DEBUG - 2016-01-27 10:45:07 --> Total execution time: 1.1392
INFO - 2016-01-27 10:45:14 --> Config Class Initialized
INFO - 2016-01-27 10:45:14 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:45:14 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:45:14 --> Utf8 Class Initialized
INFO - 2016-01-27 10:45:14 --> URI Class Initialized
INFO - 2016-01-27 10:45:14 --> Router Class Initialized
INFO - 2016-01-27 10:45:14 --> Output Class Initialized
INFO - 2016-01-27 10:45:14 --> Security Class Initialized
DEBUG - 2016-01-27 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:45:14 --> Input Class Initialized
INFO - 2016-01-27 10:45:14 --> Language Class Initialized
INFO - 2016-01-27 10:45:14 --> Loader Class Initialized
INFO - 2016-01-27 10:45:14 --> Helper loaded: url_helper
INFO - 2016-01-27 10:45:14 --> Helper loaded: file_helper
INFO - 2016-01-27 10:45:14 --> Helper loaded: date_helper
INFO - 2016-01-27 10:45:14 --> Database Driver Class Initialized
INFO - 2016-01-27 10:45:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:45:15 --> Controller Class Initialized
INFO - 2016-01-27 10:45:15 --> Model Class Initialized
INFO - 2016-01-27 10:45:15 --> Model Class Initialized
INFO - 2016-01-27 10:45:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:45:15 --> Pagination Class Initialized
INFO - 2016-01-27 10:45:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:45:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:45:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:45:15 --> Final output sent to browser
DEBUG - 2016-01-27 10:45:15 --> Total execution time: 1.1684
INFO - 2016-01-27 10:46:04 --> Config Class Initialized
INFO - 2016-01-27 10:46:04 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:46:04 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:46:04 --> Utf8 Class Initialized
INFO - 2016-01-27 10:46:04 --> URI Class Initialized
INFO - 2016-01-27 10:46:04 --> Router Class Initialized
INFO - 2016-01-27 10:46:04 --> Output Class Initialized
INFO - 2016-01-27 10:46:04 --> Security Class Initialized
DEBUG - 2016-01-27 10:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:46:04 --> Input Class Initialized
INFO - 2016-01-27 10:46:04 --> Language Class Initialized
INFO - 2016-01-27 10:46:04 --> Loader Class Initialized
INFO - 2016-01-27 10:46:04 --> Helper loaded: url_helper
INFO - 2016-01-27 10:46:04 --> Helper loaded: file_helper
INFO - 2016-01-27 10:46:04 --> Helper loaded: date_helper
INFO - 2016-01-27 10:46:04 --> Database Driver Class Initialized
INFO - 2016-01-27 10:46:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:46:05 --> Controller Class Initialized
INFO - 2016-01-27 10:46:05 --> Model Class Initialized
INFO - 2016-01-27 10:46:05 --> Model Class Initialized
INFO - 2016-01-27 10:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:46:05 --> Pagination Class Initialized
INFO - 2016-01-27 10:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:46:05 --> Final output sent to browser
DEBUG - 2016-01-27 10:46:06 --> Total execution time: 1.1496
INFO - 2016-01-27 10:46:08 --> Config Class Initialized
INFO - 2016-01-27 10:46:08 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:46:08 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:46:08 --> Utf8 Class Initialized
INFO - 2016-01-27 10:46:08 --> URI Class Initialized
DEBUG - 2016-01-27 10:46:08 --> No URI present. Default controller set.
INFO - 2016-01-27 10:46:08 --> Router Class Initialized
INFO - 2016-01-27 10:46:08 --> Output Class Initialized
INFO - 2016-01-27 10:46:08 --> Security Class Initialized
DEBUG - 2016-01-27 10:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:46:08 --> Input Class Initialized
INFO - 2016-01-27 10:46:08 --> Language Class Initialized
INFO - 2016-01-27 10:46:08 --> Loader Class Initialized
INFO - 2016-01-27 10:46:08 --> Helper loaded: url_helper
INFO - 2016-01-27 10:46:08 --> Helper loaded: file_helper
INFO - 2016-01-27 10:46:08 --> Helper loaded: date_helper
INFO - 2016-01-27 10:46:08 --> Database Driver Class Initialized
INFO - 2016-01-27 10:46:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:46:09 --> Controller Class Initialized
INFO - 2016-01-27 10:46:09 --> Model Class Initialized
INFO - 2016-01-27 10:46:09 --> Model Class Initialized
INFO - 2016-01-27 10:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:46:09 --> Pagination Class Initialized
INFO - 2016-01-27 10:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:46:09 --> Final output sent to browser
DEBUG - 2016-01-27 10:46:09 --> Total execution time: 1.1006
INFO - 2016-01-27 10:46:12 --> Config Class Initialized
INFO - 2016-01-27 10:46:12 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:46:12 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:46:12 --> Utf8 Class Initialized
INFO - 2016-01-27 10:46:12 --> URI Class Initialized
INFO - 2016-01-27 10:46:12 --> Router Class Initialized
INFO - 2016-01-27 10:46:12 --> Output Class Initialized
INFO - 2016-01-27 10:46:12 --> Security Class Initialized
DEBUG - 2016-01-27 10:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:46:12 --> Input Class Initialized
INFO - 2016-01-27 10:46:12 --> Language Class Initialized
INFO - 2016-01-27 10:46:12 --> Loader Class Initialized
INFO - 2016-01-27 10:46:12 --> Helper loaded: url_helper
INFO - 2016-01-27 10:46:12 --> Helper loaded: file_helper
INFO - 2016-01-27 10:46:12 --> Helper loaded: date_helper
INFO - 2016-01-27 10:46:12 --> Database Driver Class Initialized
INFO - 2016-01-27 10:46:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:46:13 --> Controller Class Initialized
INFO - 2016-01-27 10:46:13 --> Model Class Initialized
INFO - 2016-01-27 10:46:13 --> Model Class Initialized
INFO - 2016-01-27 10:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:46:13 --> Pagination Class Initialized
INFO - 2016-01-27 10:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-27 10:46:13 --> Final output sent to browser
DEBUG - 2016-01-27 10:46:13 --> Total execution time: 1.1029
INFO - 2016-01-27 10:46:16 --> Config Class Initialized
INFO - 2016-01-27 10:46:16 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:46:16 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:46:16 --> Utf8 Class Initialized
INFO - 2016-01-27 10:46:16 --> URI Class Initialized
INFO - 2016-01-27 10:46:16 --> Router Class Initialized
INFO - 2016-01-27 10:46:16 --> Output Class Initialized
INFO - 2016-01-27 10:46:16 --> Security Class Initialized
DEBUG - 2016-01-27 10:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:46:16 --> Input Class Initialized
INFO - 2016-01-27 10:46:16 --> Language Class Initialized
INFO - 2016-01-27 10:46:16 --> Loader Class Initialized
INFO - 2016-01-27 10:46:16 --> Helper loaded: url_helper
INFO - 2016-01-27 10:46:16 --> Helper loaded: file_helper
INFO - 2016-01-27 10:46:16 --> Helper loaded: date_helper
INFO - 2016-01-27 10:46:16 --> Database Driver Class Initialized
INFO - 2016-01-27 10:46:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:46:17 --> Controller Class Initialized
INFO - 2016-01-27 10:46:17 --> Model Class Initialized
INFO - 2016-01-27 10:46:17 --> Model Class Initialized
INFO - 2016-01-27 10:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:46:17 --> Pagination Class Initialized
INFO - 2016-01-27 10:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-27 10:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:46:17 --> Final output sent to browser
DEBUG - 2016-01-27 10:46:17 --> Total execution time: 1.1278
INFO - 2016-01-27 10:46:45 --> Config Class Initialized
INFO - 2016-01-27 10:46:45 --> Hooks Class Initialized
DEBUG - 2016-01-27 10:46:45 --> UTF-8 Support Enabled
INFO - 2016-01-27 10:46:45 --> Utf8 Class Initialized
INFO - 2016-01-27 10:46:45 --> URI Class Initialized
INFO - 2016-01-27 10:46:45 --> Router Class Initialized
INFO - 2016-01-27 10:46:45 --> Output Class Initialized
INFO - 2016-01-27 10:46:45 --> Security Class Initialized
DEBUG - 2016-01-27 10:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-27 10:46:45 --> Input Class Initialized
INFO - 2016-01-27 10:46:45 --> Language Class Initialized
INFO - 2016-01-27 10:46:45 --> Loader Class Initialized
INFO - 2016-01-27 10:46:45 --> Helper loaded: url_helper
INFO - 2016-01-27 10:46:45 --> Helper loaded: file_helper
INFO - 2016-01-27 10:46:45 --> Helper loaded: date_helper
INFO - 2016-01-27 10:46:45 --> Database Driver Class Initialized
INFO - 2016-01-27 10:46:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-27 10:46:46 --> Controller Class Initialized
INFO - 2016-01-27 10:46:46 --> Model Class Initialized
INFO - 2016-01-27 10:46:46 --> Model Class Initialized
INFO - 2016-01-27 10:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-27 10:46:46 --> Pagination Class Initialized
INFO - 2016-01-27 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-27 10:46:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-01-27 10:46:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-01-27 10:46:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-01-27 10:46:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-01-27 10:46:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-01-27 10:46:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 22
INFO - 2016-01-27 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-27 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-27 10:46:46 --> Final output sent to browser
DEBUG - 2016-01-27 10:46:46 --> Total execution time: 1.1323
