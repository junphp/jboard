<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-24 06:30:21 --> Config Class Initialized
INFO - 2016-02-24 06:30:21 --> Hooks Class Initialized
DEBUG - 2016-02-24 06:30:21 --> UTF-8 Support Enabled
INFO - 2016-02-24 06:30:21 --> Utf8 Class Initialized
INFO - 2016-02-24 06:30:21 --> URI Class Initialized
DEBUG - 2016-02-24 06:30:21 --> No URI present. Default controller set.
INFO - 2016-02-24 06:30:21 --> Router Class Initialized
INFO - 2016-02-24 06:30:21 --> Output Class Initialized
INFO - 2016-02-24 06:30:21 --> Security Class Initialized
DEBUG - 2016-02-24 06:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 06:30:21 --> Input Class Initialized
INFO - 2016-02-24 06:30:21 --> Language Class Initialized
INFO - 2016-02-24 06:30:21 --> Loader Class Initialized
INFO - 2016-02-24 06:30:21 --> Helper loaded: url_helper
INFO - 2016-02-24 06:30:21 --> Helper loaded: file_helper
INFO - 2016-02-24 06:30:21 --> Helper loaded: date_helper
INFO - 2016-02-24 06:30:21 --> Helper loaded: form_helper
INFO - 2016-02-24 06:30:21 --> Database Driver Class Initialized
INFO - 2016-02-24 06:30:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 06:30:22 --> Controller Class Initialized
INFO - 2016-02-24 06:30:22 --> Model Class Initialized
INFO - 2016-02-24 06:30:22 --> Model Class Initialized
INFO - 2016-02-24 06:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 06:30:22 --> Pagination Class Initialized
INFO - 2016-02-24 06:30:22 --> Helper loaded: text_helper
INFO - 2016-02-24 06:30:22 --> Helper loaded: cookie_helper
INFO - 2016-02-24 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 09:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 09:30:22 --> Final output sent to browser
DEBUG - 2016-02-24 09:30:22 --> Total execution time: 1.1424
INFO - 2016-02-24 09:57:27 --> Config Class Initialized
INFO - 2016-02-24 09:57:27 --> Hooks Class Initialized
DEBUG - 2016-02-24 09:57:27 --> UTF-8 Support Enabled
INFO - 2016-02-24 09:57:27 --> Utf8 Class Initialized
INFO - 2016-02-24 09:57:27 --> URI Class Initialized
DEBUG - 2016-02-24 09:57:27 --> No URI present. Default controller set.
INFO - 2016-02-24 09:57:27 --> Router Class Initialized
INFO - 2016-02-24 09:57:27 --> Output Class Initialized
INFO - 2016-02-24 09:57:27 --> Security Class Initialized
DEBUG - 2016-02-24 09:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 09:57:27 --> Input Class Initialized
INFO - 2016-02-24 09:57:27 --> Language Class Initialized
INFO - 2016-02-24 09:57:27 --> Loader Class Initialized
INFO - 2016-02-24 09:57:27 --> Helper loaded: url_helper
INFO - 2016-02-24 09:57:27 --> Helper loaded: file_helper
INFO - 2016-02-24 09:57:27 --> Helper loaded: date_helper
INFO - 2016-02-24 09:57:27 --> Helper loaded: form_helper
INFO - 2016-02-24 09:57:27 --> Database Driver Class Initialized
INFO - 2016-02-24 09:57:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 09:57:28 --> Controller Class Initialized
INFO - 2016-02-24 09:57:28 --> Model Class Initialized
INFO - 2016-02-24 09:57:28 --> Model Class Initialized
INFO - 2016-02-24 09:57:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 09:57:28 --> Pagination Class Initialized
INFO - 2016-02-24 09:57:28 --> Helper loaded: text_helper
INFO - 2016-02-24 09:57:28 --> Helper loaded: cookie_helper
INFO - 2016-02-24 12:57:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 12:57:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 12:57:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 12:57:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 12:57:28 --> Final output sent to browser
DEBUG - 2016-02-24 12:57:28 --> Total execution time: 1.1662
INFO - 2016-02-24 09:57:34 --> Config Class Initialized
INFO - 2016-02-24 09:57:34 --> Hooks Class Initialized
DEBUG - 2016-02-24 09:57:34 --> UTF-8 Support Enabled
INFO - 2016-02-24 09:57:34 --> Utf8 Class Initialized
INFO - 2016-02-24 09:57:34 --> URI Class Initialized
INFO - 2016-02-24 09:57:34 --> Router Class Initialized
INFO - 2016-02-24 09:57:34 --> Output Class Initialized
INFO - 2016-02-24 09:57:34 --> Security Class Initialized
DEBUG - 2016-02-24 09:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 09:57:34 --> Input Class Initialized
INFO - 2016-02-24 09:57:34 --> Language Class Initialized
INFO - 2016-02-24 09:57:34 --> Loader Class Initialized
INFO - 2016-02-24 09:57:34 --> Helper loaded: url_helper
INFO - 2016-02-24 09:57:34 --> Helper loaded: file_helper
INFO - 2016-02-24 09:57:34 --> Helper loaded: date_helper
INFO - 2016-02-24 09:57:34 --> Helper loaded: form_helper
INFO - 2016-02-24 09:57:34 --> Database Driver Class Initialized
INFO - 2016-02-24 09:57:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 09:57:35 --> Controller Class Initialized
INFO - 2016-02-24 09:57:35 --> Model Class Initialized
INFO - 2016-02-24 09:57:35 --> Model Class Initialized
INFO - 2016-02-24 09:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 09:57:35 --> Pagination Class Initialized
INFO - 2016-02-24 09:57:35 --> Helper loaded: text_helper
INFO - 2016-02-24 09:57:35 --> Helper loaded: cookie_helper
INFO - 2016-02-24 12:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 12:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 12:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 12:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 12:57:35 --> Final output sent to browser
DEBUG - 2016-02-24 12:57:35 --> Total execution time: 1.0937
INFO - 2016-02-24 09:57:38 --> Config Class Initialized
INFO - 2016-02-24 09:57:38 --> Hooks Class Initialized
DEBUG - 2016-02-24 09:57:38 --> UTF-8 Support Enabled
INFO - 2016-02-24 09:57:38 --> Utf8 Class Initialized
INFO - 2016-02-24 09:57:38 --> URI Class Initialized
INFO - 2016-02-24 09:57:38 --> Router Class Initialized
INFO - 2016-02-24 09:57:38 --> Output Class Initialized
INFO - 2016-02-24 09:57:38 --> Security Class Initialized
DEBUG - 2016-02-24 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 09:57:38 --> Input Class Initialized
INFO - 2016-02-24 09:57:38 --> Language Class Initialized
INFO - 2016-02-24 09:57:38 --> Loader Class Initialized
INFO - 2016-02-24 09:57:38 --> Helper loaded: url_helper
INFO - 2016-02-24 09:57:38 --> Helper loaded: file_helper
INFO - 2016-02-24 09:57:38 --> Helper loaded: date_helper
INFO - 2016-02-24 09:57:38 --> Helper loaded: form_helper
INFO - 2016-02-24 09:57:38 --> Database Driver Class Initialized
INFO - 2016-02-24 09:57:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 09:57:39 --> Controller Class Initialized
INFO - 2016-02-24 09:57:39 --> Model Class Initialized
INFO - 2016-02-24 09:57:39 --> Model Class Initialized
INFO - 2016-02-24 09:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 09:57:39 --> Pagination Class Initialized
INFO - 2016-02-24 09:57:39 --> Helper loaded: text_helper
INFO - 2016-02-24 09:57:39 --> Helper loaded: cookie_helper
INFO - 2016-02-24 12:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 12:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 12:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 12:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 12:57:39 --> Final output sent to browser
DEBUG - 2016-02-24 12:57:39 --> Total execution time: 1.2912
INFO - 2016-02-24 09:57:49 --> Config Class Initialized
INFO - 2016-02-24 09:57:49 --> Hooks Class Initialized
DEBUG - 2016-02-24 09:57:49 --> UTF-8 Support Enabled
INFO - 2016-02-24 09:57:49 --> Utf8 Class Initialized
INFO - 2016-02-24 09:57:49 --> URI Class Initialized
DEBUG - 2016-02-24 09:57:49 --> No URI present. Default controller set.
INFO - 2016-02-24 09:57:49 --> Router Class Initialized
INFO - 2016-02-24 09:57:49 --> Output Class Initialized
INFO - 2016-02-24 09:57:49 --> Security Class Initialized
DEBUG - 2016-02-24 09:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 09:57:49 --> Input Class Initialized
INFO - 2016-02-24 09:57:49 --> Language Class Initialized
INFO - 2016-02-24 09:57:49 --> Loader Class Initialized
INFO - 2016-02-24 09:57:49 --> Helper loaded: url_helper
INFO - 2016-02-24 09:57:49 --> Helper loaded: file_helper
INFO - 2016-02-24 09:57:49 --> Helper loaded: date_helper
INFO - 2016-02-24 09:57:49 --> Helper loaded: form_helper
INFO - 2016-02-24 09:57:49 --> Database Driver Class Initialized
INFO - 2016-02-24 09:57:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 09:57:50 --> Controller Class Initialized
INFO - 2016-02-24 09:57:50 --> Model Class Initialized
INFO - 2016-02-24 09:57:50 --> Model Class Initialized
INFO - 2016-02-24 09:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 09:57:50 --> Pagination Class Initialized
INFO - 2016-02-24 09:57:50 --> Helper loaded: text_helper
INFO - 2016-02-24 09:57:50 --> Helper loaded: cookie_helper
INFO - 2016-02-24 12:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 12:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 12:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 12:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 12:57:50 --> Final output sent to browser
DEBUG - 2016-02-24 12:57:50 --> Total execution time: 1.1177
INFO - 2016-02-24 10:01:08 --> Config Class Initialized
INFO - 2016-02-24 10:01:08 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:01:08 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:01:08 --> Utf8 Class Initialized
INFO - 2016-02-24 10:01:08 --> URI Class Initialized
DEBUG - 2016-02-24 10:01:08 --> No URI present. Default controller set.
INFO - 2016-02-24 10:01:08 --> Router Class Initialized
INFO - 2016-02-24 10:01:08 --> Output Class Initialized
INFO - 2016-02-24 10:01:08 --> Security Class Initialized
DEBUG - 2016-02-24 10:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:01:08 --> Input Class Initialized
INFO - 2016-02-24 10:01:08 --> Language Class Initialized
INFO - 2016-02-24 10:01:08 --> Loader Class Initialized
INFO - 2016-02-24 10:01:08 --> Helper loaded: url_helper
INFO - 2016-02-24 10:01:08 --> Helper loaded: file_helper
INFO - 2016-02-24 10:01:08 --> Helper loaded: date_helper
INFO - 2016-02-24 10:01:08 --> Helper loaded: form_helper
INFO - 2016-02-24 10:01:08 --> Database Driver Class Initialized
INFO - 2016-02-24 10:01:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:01:09 --> Controller Class Initialized
INFO - 2016-02-24 10:01:09 --> Model Class Initialized
INFO - 2016-02-24 10:01:09 --> Model Class Initialized
INFO - 2016-02-24 10:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:01:09 --> Pagination Class Initialized
INFO - 2016-02-24 10:01:09 --> Helper loaded: text_helper
INFO - 2016-02-24 10:01:09 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:01:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:01:10 --> Final output sent to browser
DEBUG - 2016-02-24 13:01:10 --> Total execution time: 1.1643
INFO - 2016-02-24 10:06:23 --> Config Class Initialized
INFO - 2016-02-24 10:06:23 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:06:23 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:06:23 --> Utf8 Class Initialized
INFO - 2016-02-24 10:06:23 --> URI Class Initialized
DEBUG - 2016-02-24 10:06:23 --> No URI present. Default controller set.
INFO - 2016-02-24 10:06:23 --> Router Class Initialized
INFO - 2016-02-24 10:06:23 --> Output Class Initialized
INFO - 2016-02-24 10:06:23 --> Security Class Initialized
DEBUG - 2016-02-24 10:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:06:23 --> Input Class Initialized
INFO - 2016-02-24 10:06:23 --> Language Class Initialized
INFO - 2016-02-24 10:06:23 --> Loader Class Initialized
INFO - 2016-02-24 10:06:23 --> Helper loaded: url_helper
INFO - 2016-02-24 10:06:23 --> Helper loaded: file_helper
INFO - 2016-02-24 10:06:23 --> Helper loaded: date_helper
INFO - 2016-02-24 10:06:23 --> Helper loaded: form_helper
INFO - 2016-02-24 10:06:23 --> Database Driver Class Initialized
INFO - 2016-02-24 10:06:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:06:24 --> Controller Class Initialized
INFO - 2016-02-24 10:06:24 --> Model Class Initialized
INFO - 2016-02-24 10:06:24 --> Model Class Initialized
INFO - 2016-02-24 10:06:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:06:24 --> Pagination Class Initialized
INFO - 2016-02-24 10:06:24 --> Helper loaded: text_helper
INFO - 2016-02-24 10:06:24 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:06:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:06:24 --> Final output sent to browser
DEBUG - 2016-02-24 13:06:24 --> Total execution time: 1.1583
INFO - 2016-02-24 10:10:02 --> Config Class Initialized
INFO - 2016-02-24 10:10:02 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:10:02 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:10:02 --> Utf8 Class Initialized
INFO - 2016-02-24 10:10:02 --> URI Class Initialized
DEBUG - 2016-02-24 10:10:02 --> No URI present. Default controller set.
INFO - 2016-02-24 10:10:02 --> Router Class Initialized
INFO - 2016-02-24 10:10:02 --> Output Class Initialized
INFO - 2016-02-24 10:10:02 --> Security Class Initialized
DEBUG - 2016-02-24 10:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:10:02 --> Input Class Initialized
INFO - 2016-02-24 10:10:02 --> Language Class Initialized
INFO - 2016-02-24 10:10:02 --> Loader Class Initialized
INFO - 2016-02-24 10:10:02 --> Helper loaded: url_helper
INFO - 2016-02-24 10:10:02 --> Helper loaded: file_helper
INFO - 2016-02-24 10:10:02 --> Helper loaded: date_helper
INFO - 2016-02-24 10:10:02 --> Helper loaded: form_helper
INFO - 2016-02-24 10:10:02 --> Database Driver Class Initialized
INFO - 2016-02-24 10:10:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:10:03 --> Controller Class Initialized
INFO - 2016-02-24 10:10:03 --> Model Class Initialized
INFO - 2016-02-24 10:10:03 --> Model Class Initialized
INFO - 2016-02-24 10:10:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:10:03 --> Pagination Class Initialized
INFO - 2016-02-24 10:10:03 --> Helper loaded: text_helper
INFO - 2016-02-24 10:10:03 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:10:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:10:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:10:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:10:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:10:03 --> Final output sent to browser
DEBUG - 2016-02-24 13:10:03 --> Total execution time: 1.1684
INFO - 2016-02-24 10:10:32 --> Config Class Initialized
INFO - 2016-02-24 10:10:32 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:10:32 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:10:32 --> Utf8 Class Initialized
INFO - 2016-02-24 10:10:32 --> URI Class Initialized
DEBUG - 2016-02-24 10:10:32 --> No URI present. Default controller set.
INFO - 2016-02-24 10:10:32 --> Router Class Initialized
INFO - 2016-02-24 10:10:32 --> Output Class Initialized
INFO - 2016-02-24 10:10:32 --> Security Class Initialized
DEBUG - 2016-02-24 10:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:10:32 --> Input Class Initialized
INFO - 2016-02-24 10:10:32 --> Language Class Initialized
INFO - 2016-02-24 10:10:32 --> Loader Class Initialized
INFO - 2016-02-24 10:10:32 --> Helper loaded: url_helper
INFO - 2016-02-24 10:10:32 --> Helper loaded: file_helper
INFO - 2016-02-24 10:10:32 --> Helper loaded: date_helper
INFO - 2016-02-24 10:10:32 --> Helper loaded: form_helper
INFO - 2016-02-24 10:10:32 --> Database Driver Class Initialized
INFO - 2016-02-24 10:10:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:10:33 --> Controller Class Initialized
INFO - 2016-02-24 10:10:33 --> Model Class Initialized
INFO - 2016-02-24 10:10:33 --> Model Class Initialized
INFO - 2016-02-24 10:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:10:33 --> Pagination Class Initialized
INFO - 2016-02-24 10:10:33 --> Helper loaded: text_helper
INFO - 2016-02-24 10:10:33 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:10:33 --> Final output sent to browser
DEBUG - 2016-02-24 13:10:33 --> Total execution time: 1.1345
INFO - 2016-02-24 10:17:32 --> Config Class Initialized
INFO - 2016-02-24 10:17:32 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:17:32 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:17:32 --> Utf8 Class Initialized
INFO - 2016-02-24 10:17:32 --> URI Class Initialized
DEBUG - 2016-02-24 10:17:32 --> No URI present. Default controller set.
INFO - 2016-02-24 10:17:32 --> Router Class Initialized
INFO - 2016-02-24 10:17:32 --> Output Class Initialized
INFO - 2016-02-24 10:17:32 --> Security Class Initialized
DEBUG - 2016-02-24 10:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:17:32 --> Input Class Initialized
INFO - 2016-02-24 10:17:32 --> Language Class Initialized
INFO - 2016-02-24 10:17:32 --> Loader Class Initialized
INFO - 2016-02-24 10:17:32 --> Helper loaded: url_helper
INFO - 2016-02-24 10:17:32 --> Helper loaded: file_helper
INFO - 2016-02-24 10:17:32 --> Helper loaded: date_helper
INFO - 2016-02-24 10:17:32 --> Helper loaded: form_helper
INFO - 2016-02-24 10:17:32 --> Database Driver Class Initialized
INFO - 2016-02-24 10:17:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:17:33 --> Controller Class Initialized
INFO - 2016-02-24 10:17:33 --> Model Class Initialized
INFO - 2016-02-24 10:17:33 --> Model Class Initialized
INFO - 2016-02-24 10:17:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:17:33 --> Pagination Class Initialized
INFO - 2016-02-24 10:17:33 --> Helper loaded: text_helper
INFO - 2016-02-24 10:17:33 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:17:33 --> Final output sent to browser
DEBUG - 2016-02-24 13:17:33 --> Total execution time: 1.1654
INFO - 2016-02-24 10:18:08 --> Config Class Initialized
INFO - 2016-02-24 10:18:08 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:18:08 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:18:08 --> Utf8 Class Initialized
INFO - 2016-02-24 10:18:08 --> URI Class Initialized
DEBUG - 2016-02-24 10:18:08 --> No URI present. Default controller set.
INFO - 2016-02-24 10:18:08 --> Router Class Initialized
INFO - 2016-02-24 10:18:08 --> Output Class Initialized
INFO - 2016-02-24 10:18:08 --> Security Class Initialized
DEBUG - 2016-02-24 10:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:18:08 --> Input Class Initialized
INFO - 2016-02-24 10:18:08 --> Language Class Initialized
INFO - 2016-02-24 10:18:08 --> Loader Class Initialized
INFO - 2016-02-24 10:18:08 --> Helper loaded: url_helper
INFO - 2016-02-24 10:18:08 --> Helper loaded: file_helper
INFO - 2016-02-24 10:18:08 --> Helper loaded: date_helper
INFO - 2016-02-24 10:18:08 --> Helper loaded: form_helper
INFO - 2016-02-24 10:18:08 --> Database Driver Class Initialized
INFO - 2016-02-24 10:18:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:18:09 --> Controller Class Initialized
INFO - 2016-02-24 10:18:09 --> Model Class Initialized
INFO - 2016-02-24 10:18:09 --> Model Class Initialized
INFO - 2016-02-24 10:18:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:18:09 --> Pagination Class Initialized
INFO - 2016-02-24 10:18:09 --> Helper loaded: text_helper
INFO - 2016-02-24 10:18:09 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:18:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:18:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:18:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:18:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:18:09 --> Final output sent to browser
DEBUG - 2016-02-24 13:18:09 --> Total execution time: 1.1797
INFO - 2016-02-24 10:18:32 --> Config Class Initialized
INFO - 2016-02-24 10:18:32 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:18:32 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:18:32 --> Utf8 Class Initialized
INFO - 2016-02-24 10:18:32 --> URI Class Initialized
DEBUG - 2016-02-24 10:18:32 --> No URI present. Default controller set.
INFO - 2016-02-24 10:18:32 --> Router Class Initialized
INFO - 2016-02-24 10:18:32 --> Output Class Initialized
INFO - 2016-02-24 10:18:32 --> Security Class Initialized
DEBUG - 2016-02-24 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:18:32 --> Input Class Initialized
INFO - 2016-02-24 10:18:32 --> Language Class Initialized
INFO - 2016-02-24 10:18:32 --> Loader Class Initialized
INFO - 2016-02-24 10:18:32 --> Helper loaded: url_helper
INFO - 2016-02-24 10:18:32 --> Helper loaded: file_helper
INFO - 2016-02-24 10:18:32 --> Helper loaded: date_helper
INFO - 2016-02-24 10:18:32 --> Helper loaded: form_helper
INFO - 2016-02-24 10:18:32 --> Database Driver Class Initialized
INFO - 2016-02-24 10:18:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:18:33 --> Controller Class Initialized
INFO - 2016-02-24 10:18:33 --> Model Class Initialized
INFO - 2016-02-24 10:18:33 --> Model Class Initialized
INFO - 2016-02-24 10:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:18:33 --> Pagination Class Initialized
INFO - 2016-02-24 10:18:33 --> Helper loaded: text_helper
INFO - 2016-02-24 10:18:33 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:18:33 --> Final output sent to browser
DEBUG - 2016-02-24 13:18:33 --> Total execution time: 1.1012
INFO - 2016-02-24 10:18:55 --> Config Class Initialized
INFO - 2016-02-24 10:18:55 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:18:55 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:18:55 --> Utf8 Class Initialized
INFO - 2016-02-24 10:18:55 --> URI Class Initialized
DEBUG - 2016-02-24 10:18:55 --> No URI present. Default controller set.
INFO - 2016-02-24 10:18:55 --> Router Class Initialized
INFO - 2016-02-24 10:18:55 --> Output Class Initialized
INFO - 2016-02-24 10:18:55 --> Security Class Initialized
DEBUG - 2016-02-24 10:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:18:55 --> Input Class Initialized
INFO - 2016-02-24 10:18:55 --> Language Class Initialized
INFO - 2016-02-24 10:18:55 --> Loader Class Initialized
INFO - 2016-02-24 10:18:55 --> Helper loaded: url_helper
INFO - 2016-02-24 10:18:55 --> Helper loaded: file_helper
INFO - 2016-02-24 10:18:55 --> Helper loaded: date_helper
INFO - 2016-02-24 10:18:55 --> Helper loaded: form_helper
INFO - 2016-02-24 10:18:56 --> Database Driver Class Initialized
INFO - 2016-02-24 10:18:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:18:57 --> Controller Class Initialized
INFO - 2016-02-24 10:18:57 --> Model Class Initialized
INFO - 2016-02-24 10:18:57 --> Model Class Initialized
INFO - 2016-02-24 10:18:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:18:57 --> Pagination Class Initialized
INFO - 2016-02-24 10:18:57 --> Helper loaded: text_helper
INFO - 2016-02-24 10:18:57 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:18:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:18:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:18:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:18:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:18:57 --> Final output sent to browser
DEBUG - 2016-02-24 13:18:57 --> Total execution time: 1.1474
INFO - 2016-02-24 10:28:26 --> Config Class Initialized
INFO - 2016-02-24 10:28:26 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:28:26 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:28:26 --> Utf8 Class Initialized
INFO - 2016-02-24 10:28:26 --> URI Class Initialized
DEBUG - 2016-02-24 10:28:26 --> No URI present. Default controller set.
INFO - 2016-02-24 10:28:26 --> Router Class Initialized
INFO - 2016-02-24 10:28:26 --> Output Class Initialized
INFO - 2016-02-24 10:28:26 --> Security Class Initialized
DEBUG - 2016-02-24 10:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:28:26 --> Input Class Initialized
INFO - 2016-02-24 10:28:26 --> Language Class Initialized
INFO - 2016-02-24 10:28:26 --> Loader Class Initialized
INFO - 2016-02-24 10:28:26 --> Helper loaded: url_helper
INFO - 2016-02-24 10:28:26 --> Helper loaded: file_helper
INFO - 2016-02-24 10:28:26 --> Helper loaded: date_helper
INFO - 2016-02-24 10:28:26 --> Helper loaded: form_helper
INFO - 2016-02-24 10:28:26 --> Database Driver Class Initialized
INFO - 2016-02-24 10:28:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:28:27 --> Controller Class Initialized
INFO - 2016-02-24 10:28:27 --> Model Class Initialized
INFO - 2016-02-24 10:28:27 --> Model Class Initialized
INFO - 2016-02-24 10:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:28:27 --> Pagination Class Initialized
INFO - 2016-02-24 10:28:27 --> Helper loaded: text_helper
INFO - 2016-02-24 10:28:27 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:28:27 --> Final output sent to browser
DEBUG - 2016-02-24 13:28:27 --> Total execution time: 1.1537
INFO - 2016-02-24 10:30:09 --> Config Class Initialized
INFO - 2016-02-24 10:30:09 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:30:09 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:30:09 --> Utf8 Class Initialized
INFO - 2016-02-24 10:30:09 --> URI Class Initialized
DEBUG - 2016-02-24 10:30:09 --> No URI present. Default controller set.
INFO - 2016-02-24 10:30:09 --> Router Class Initialized
INFO - 2016-02-24 10:30:09 --> Output Class Initialized
INFO - 2016-02-24 10:30:09 --> Security Class Initialized
DEBUG - 2016-02-24 10:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:30:09 --> Input Class Initialized
INFO - 2016-02-24 10:30:09 --> Language Class Initialized
INFO - 2016-02-24 10:30:09 --> Loader Class Initialized
INFO - 2016-02-24 10:30:09 --> Helper loaded: url_helper
INFO - 2016-02-24 10:30:09 --> Helper loaded: file_helper
INFO - 2016-02-24 10:30:09 --> Helper loaded: date_helper
INFO - 2016-02-24 10:30:09 --> Helper loaded: form_helper
INFO - 2016-02-24 10:30:09 --> Database Driver Class Initialized
INFO - 2016-02-24 10:30:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:30:10 --> Controller Class Initialized
INFO - 2016-02-24 10:30:10 --> Model Class Initialized
INFO - 2016-02-24 10:30:10 --> Model Class Initialized
INFO - 2016-02-24 10:30:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:30:10 --> Pagination Class Initialized
INFO - 2016-02-24 10:30:10 --> Helper loaded: text_helper
INFO - 2016-02-24 10:30:10 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:30:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:30:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:30:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:30:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:30:10 --> Final output sent to browser
DEBUG - 2016-02-24 13:30:10 --> Total execution time: 1.1254
INFO - 2016-02-24 10:30:30 --> Config Class Initialized
INFO - 2016-02-24 10:30:30 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:30:30 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:30:30 --> Utf8 Class Initialized
INFO - 2016-02-24 10:30:30 --> URI Class Initialized
DEBUG - 2016-02-24 10:30:30 --> No URI present. Default controller set.
INFO - 2016-02-24 10:30:30 --> Router Class Initialized
INFO - 2016-02-24 10:30:30 --> Output Class Initialized
INFO - 2016-02-24 10:30:30 --> Security Class Initialized
DEBUG - 2016-02-24 10:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:30:30 --> Input Class Initialized
INFO - 2016-02-24 10:30:30 --> Language Class Initialized
INFO - 2016-02-24 10:30:30 --> Loader Class Initialized
INFO - 2016-02-24 10:30:30 --> Helper loaded: url_helper
INFO - 2016-02-24 10:30:30 --> Helper loaded: file_helper
INFO - 2016-02-24 10:30:30 --> Helper loaded: date_helper
INFO - 2016-02-24 10:30:30 --> Helper loaded: form_helper
INFO - 2016-02-24 10:30:30 --> Database Driver Class Initialized
INFO - 2016-02-24 10:30:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:30:32 --> Controller Class Initialized
INFO - 2016-02-24 10:30:32 --> Model Class Initialized
INFO - 2016-02-24 10:30:32 --> Model Class Initialized
INFO - 2016-02-24 10:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:30:32 --> Pagination Class Initialized
INFO - 2016-02-24 10:30:32 --> Helper loaded: text_helper
INFO - 2016-02-24 10:30:32 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:30:32 --> Final output sent to browser
DEBUG - 2016-02-24 13:30:32 --> Total execution time: 1.1756
INFO - 2016-02-24 10:37:51 --> Config Class Initialized
INFO - 2016-02-24 10:37:51 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:37:51 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:37:51 --> Utf8 Class Initialized
INFO - 2016-02-24 10:37:51 --> URI Class Initialized
INFO - 2016-02-24 10:37:51 --> Router Class Initialized
INFO - 2016-02-24 10:37:51 --> Output Class Initialized
INFO - 2016-02-24 10:37:51 --> Security Class Initialized
DEBUG - 2016-02-24 10:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:37:51 --> Input Class Initialized
INFO - 2016-02-24 10:37:51 --> Language Class Initialized
INFO - 2016-02-24 10:37:51 --> Loader Class Initialized
INFO - 2016-02-24 10:37:51 --> Helper loaded: url_helper
INFO - 2016-02-24 10:37:51 --> Helper loaded: file_helper
INFO - 2016-02-24 10:37:51 --> Helper loaded: date_helper
INFO - 2016-02-24 10:37:51 --> Helper loaded: form_helper
INFO - 2016-02-24 10:37:51 --> Database Driver Class Initialized
INFO - 2016-02-24 10:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:37:52 --> Controller Class Initialized
INFO - 2016-02-24 10:37:52 --> Model Class Initialized
INFO - 2016-02-24 10:37:52 --> Model Class Initialized
INFO - 2016-02-24 10:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:37:52 --> Pagination Class Initialized
INFO - 2016-02-24 10:37:52 --> Helper loaded: text_helper
INFO - 2016-02-24 10:37:52 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 13:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:37:52 --> Final output sent to browser
DEBUG - 2016-02-24 13:37:52 --> Total execution time: 1.2453
INFO - 2016-02-24 10:37:53 --> Config Class Initialized
INFO - 2016-02-24 10:37:53 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:37:53 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:37:53 --> Utf8 Class Initialized
INFO - 2016-02-24 10:37:53 --> URI Class Initialized
DEBUG - 2016-02-24 10:37:53 --> No URI present. Default controller set.
INFO - 2016-02-24 10:37:53 --> Router Class Initialized
INFO - 2016-02-24 10:37:53 --> Output Class Initialized
INFO - 2016-02-24 10:37:53 --> Security Class Initialized
DEBUG - 2016-02-24 10:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:37:53 --> Input Class Initialized
INFO - 2016-02-24 10:37:53 --> Language Class Initialized
INFO - 2016-02-24 10:37:53 --> Loader Class Initialized
INFO - 2016-02-24 10:37:53 --> Helper loaded: url_helper
INFO - 2016-02-24 10:37:53 --> Helper loaded: file_helper
INFO - 2016-02-24 10:37:53 --> Helper loaded: date_helper
INFO - 2016-02-24 10:37:53 --> Helper loaded: form_helper
INFO - 2016-02-24 10:37:53 --> Database Driver Class Initialized
INFO - 2016-02-24 10:37:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:37:54 --> Controller Class Initialized
INFO - 2016-02-24 10:37:54 --> Model Class Initialized
INFO - 2016-02-24 10:37:54 --> Model Class Initialized
INFO - 2016-02-24 10:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:37:54 --> Pagination Class Initialized
INFO - 2016-02-24 10:37:54 --> Helper loaded: text_helper
INFO - 2016-02-24 10:37:54 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:37:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:37:54 --> Final output sent to browser
DEBUG - 2016-02-24 13:37:54 --> Total execution time: 1.1539
INFO - 2016-02-24 10:37:57 --> Config Class Initialized
INFO - 2016-02-24 10:37:57 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:37:57 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:37:57 --> Utf8 Class Initialized
INFO - 2016-02-24 10:37:57 --> URI Class Initialized
INFO - 2016-02-24 10:37:57 --> Router Class Initialized
INFO - 2016-02-24 10:37:57 --> Output Class Initialized
INFO - 2016-02-24 10:37:57 --> Security Class Initialized
DEBUG - 2016-02-24 10:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:37:57 --> Input Class Initialized
INFO - 2016-02-24 10:37:57 --> Language Class Initialized
INFO - 2016-02-24 10:37:57 --> Loader Class Initialized
INFO - 2016-02-24 10:37:57 --> Helper loaded: url_helper
INFO - 2016-02-24 10:37:57 --> Helper loaded: file_helper
INFO - 2016-02-24 10:37:57 --> Helper loaded: date_helper
INFO - 2016-02-24 10:37:57 --> Helper loaded: form_helper
INFO - 2016-02-24 10:37:57 --> Database Driver Class Initialized
INFO - 2016-02-24 10:37:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:37:58 --> Controller Class Initialized
INFO - 2016-02-24 10:37:58 --> Model Class Initialized
INFO - 2016-02-24 10:37:58 --> Model Class Initialized
INFO - 2016-02-24 10:37:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:37:58 --> Pagination Class Initialized
INFO - 2016-02-24 10:37:58 --> Helper loaded: text_helper
INFO - 2016-02-24 10:37:58 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:37:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:37:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:37:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 13:37:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 13:37:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:37:58 --> Final output sent to browser
DEBUG - 2016-02-24 13:37:58 --> Total execution time: 1.2027
INFO - 2016-02-24 10:46:16 --> Config Class Initialized
INFO - 2016-02-24 10:46:16 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:46:16 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:46:16 --> Utf8 Class Initialized
INFO - 2016-02-24 10:46:16 --> URI Class Initialized
INFO - 2016-02-24 10:46:16 --> Router Class Initialized
INFO - 2016-02-24 10:46:16 --> Output Class Initialized
INFO - 2016-02-24 10:46:16 --> Security Class Initialized
DEBUG - 2016-02-24 10:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:46:16 --> Input Class Initialized
INFO - 2016-02-24 10:46:16 --> Language Class Initialized
INFO - 2016-02-24 10:46:16 --> Loader Class Initialized
INFO - 2016-02-24 10:46:16 --> Helper loaded: url_helper
INFO - 2016-02-24 10:46:16 --> Helper loaded: file_helper
INFO - 2016-02-24 10:46:16 --> Helper loaded: date_helper
INFO - 2016-02-24 10:46:16 --> Helper loaded: form_helper
INFO - 2016-02-24 10:46:16 --> Database Driver Class Initialized
INFO - 2016-02-24 10:46:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:46:17 --> Controller Class Initialized
INFO - 2016-02-24 10:46:17 --> Model Class Initialized
INFO - 2016-02-24 10:46:17 --> Model Class Initialized
INFO - 2016-02-24 10:46:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:46:17 --> Pagination Class Initialized
INFO - 2016-02-24 10:46:17 --> Helper loaded: text_helper
INFO - 2016-02-24 10:46:17 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 13:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 13:46:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:46:17 --> Final output sent to browser
DEBUG - 2016-02-24 13:46:17 --> Total execution time: 1.2188
INFO - 2016-02-24 10:46:58 --> Config Class Initialized
INFO - 2016-02-24 10:46:58 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:46:58 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:46:58 --> Utf8 Class Initialized
INFO - 2016-02-24 10:46:58 --> URI Class Initialized
INFO - 2016-02-24 10:46:58 --> Router Class Initialized
INFO - 2016-02-24 10:46:58 --> Output Class Initialized
INFO - 2016-02-24 10:46:58 --> Security Class Initialized
DEBUG - 2016-02-24 10:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:46:58 --> Input Class Initialized
INFO - 2016-02-24 10:46:58 --> Language Class Initialized
INFO - 2016-02-24 10:46:58 --> Loader Class Initialized
INFO - 2016-02-24 10:46:58 --> Helper loaded: url_helper
INFO - 2016-02-24 10:46:58 --> Helper loaded: file_helper
INFO - 2016-02-24 10:46:58 --> Helper loaded: date_helper
INFO - 2016-02-24 10:46:58 --> Helper loaded: form_helper
INFO - 2016-02-24 10:46:58 --> Database Driver Class Initialized
INFO - 2016-02-24 10:46:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:46:59 --> Controller Class Initialized
INFO - 2016-02-24 10:46:59 --> Model Class Initialized
INFO - 2016-02-24 10:46:59 --> Model Class Initialized
INFO - 2016-02-24 10:46:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:46:59 --> Pagination Class Initialized
INFO - 2016-02-24 10:46:59 --> Helper loaded: text_helper
INFO - 2016-02-24 10:46:59 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:46:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:46:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:46:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 13:46:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 13:46:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:46:59 --> Final output sent to browser
DEBUG - 2016-02-24 13:46:59 --> Total execution time: 1.1718
INFO - 2016-02-24 10:48:07 --> Config Class Initialized
INFO - 2016-02-24 10:48:07 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:48:07 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:48:07 --> Utf8 Class Initialized
INFO - 2016-02-24 10:48:07 --> URI Class Initialized
INFO - 2016-02-24 10:48:07 --> Router Class Initialized
INFO - 2016-02-24 10:48:07 --> Output Class Initialized
INFO - 2016-02-24 10:48:07 --> Security Class Initialized
DEBUG - 2016-02-24 10:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:48:07 --> Input Class Initialized
INFO - 2016-02-24 10:48:07 --> Language Class Initialized
INFO - 2016-02-24 10:48:07 --> Loader Class Initialized
INFO - 2016-02-24 10:48:07 --> Helper loaded: url_helper
INFO - 2016-02-24 10:48:07 --> Helper loaded: file_helper
INFO - 2016-02-24 10:48:07 --> Helper loaded: date_helper
INFO - 2016-02-24 10:48:07 --> Helper loaded: form_helper
INFO - 2016-02-24 10:48:07 --> Database Driver Class Initialized
INFO - 2016-02-24 10:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:48:08 --> Controller Class Initialized
INFO - 2016-02-24 10:48:08 --> Model Class Initialized
INFO - 2016-02-24 10:48:08 --> Model Class Initialized
INFO - 2016-02-24 10:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:48:08 --> Pagination Class Initialized
INFO - 2016-02-24 10:48:08 --> Helper loaded: text_helper
INFO - 2016-02-24 10:48:08 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 13:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 13:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:48:08 --> Final output sent to browser
DEBUG - 2016-02-24 13:48:08 --> Total execution time: 1.2572
INFO - 2016-02-24 10:48:10 --> Config Class Initialized
INFO - 2016-02-24 10:48:10 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:48:10 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:48:10 --> Utf8 Class Initialized
INFO - 2016-02-24 10:48:10 --> URI Class Initialized
INFO - 2016-02-24 10:48:10 --> Router Class Initialized
INFO - 2016-02-24 10:48:10 --> Output Class Initialized
INFO - 2016-02-24 10:48:10 --> Security Class Initialized
DEBUG - 2016-02-24 10:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:48:10 --> Input Class Initialized
INFO - 2016-02-24 10:48:10 --> Language Class Initialized
INFO - 2016-02-24 10:48:10 --> Loader Class Initialized
INFO - 2016-02-24 10:48:10 --> Helper loaded: url_helper
INFO - 2016-02-24 10:48:10 --> Helper loaded: file_helper
INFO - 2016-02-24 10:48:10 --> Helper loaded: date_helper
INFO - 2016-02-24 10:48:10 --> Helper loaded: form_helper
INFO - 2016-02-24 10:48:10 --> Database Driver Class Initialized
INFO - 2016-02-24 10:48:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:48:11 --> Controller Class Initialized
INFO - 2016-02-24 10:48:11 --> Model Class Initialized
INFO - 2016-02-24 10:48:11 --> Model Class Initialized
INFO - 2016-02-24 10:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:48:11 --> Pagination Class Initialized
INFO - 2016-02-24 10:48:11 --> Helper loaded: text_helper
INFO - 2016-02-24 10:48:11 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 13:48:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 13:48:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 13:48:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 13:48:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:48:12 --> Final output sent to browser
DEBUG - 2016-02-24 13:48:12 --> Total execution time: 1.3547
INFO - 2016-02-24 10:48:19 --> Config Class Initialized
INFO - 2016-02-24 10:48:19 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:48:19 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:48:19 --> Utf8 Class Initialized
INFO - 2016-02-24 10:48:19 --> URI Class Initialized
INFO - 2016-02-24 10:48:19 --> Router Class Initialized
INFO - 2016-02-24 10:48:19 --> Output Class Initialized
INFO - 2016-02-24 10:48:19 --> Security Class Initialized
DEBUG - 2016-02-24 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:48:19 --> Input Class Initialized
INFO - 2016-02-24 10:48:20 --> Language Class Initialized
INFO - 2016-02-24 10:48:20 --> Loader Class Initialized
INFO - 2016-02-24 10:48:20 --> Helper loaded: url_helper
INFO - 2016-02-24 10:48:20 --> Helper loaded: file_helper
INFO - 2016-02-24 10:48:20 --> Helper loaded: date_helper
INFO - 2016-02-24 10:48:20 --> Helper loaded: form_helper
INFO - 2016-02-24 10:48:20 --> Database Driver Class Initialized
INFO - 2016-02-24 10:48:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:48:21 --> Controller Class Initialized
INFO - 2016-02-24 10:48:21 --> Model Class Initialized
INFO - 2016-02-24 10:48:21 --> Model Class Initialized
INFO - 2016-02-24 10:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:48:21 --> Pagination Class Initialized
INFO - 2016-02-24 10:48:21 --> Helper loaded: text_helper
INFO - 2016-02-24 10:48:21 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 13:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 13:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 13:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 13:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:48:21 --> Final output sent to browser
DEBUG - 2016-02-24 13:48:21 --> Total execution time: 1.2018
INFO - 2016-02-24 10:48:24 --> Config Class Initialized
INFO - 2016-02-24 10:48:24 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:48:24 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:48:24 --> Utf8 Class Initialized
INFO - 2016-02-24 10:48:24 --> URI Class Initialized
INFO - 2016-02-24 10:48:24 --> Router Class Initialized
INFO - 2016-02-24 10:48:24 --> Output Class Initialized
INFO - 2016-02-24 10:48:24 --> Security Class Initialized
DEBUG - 2016-02-24 10:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:48:24 --> Input Class Initialized
INFO - 2016-02-24 10:48:24 --> Language Class Initialized
INFO - 2016-02-24 10:48:24 --> Loader Class Initialized
INFO - 2016-02-24 10:48:24 --> Helper loaded: url_helper
INFO - 2016-02-24 10:48:24 --> Helper loaded: file_helper
INFO - 2016-02-24 10:48:24 --> Helper loaded: date_helper
INFO - 2016-02-24 10:48:24 --> Helper loaded: form_helper
INFO - 2016-02-24 10:48:24 --> Database Driver Class Initialized
INFO - 2016-02-24 10:48:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:48:25 --> Controller Class Initialized
INFO - 2016-02-24 10:48:25 --> Model Class Initialized
INFO - 2016-02-24 10:48:25 --> Model Class Initialized
INFO - 2016-02-24 10:48:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:48:25 --> Pagination Class Initialized
INFO - 2016-02-24 10:48:25 --> Helper loaded: text_helper
INFO - 2016-02-24 10:48:25 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:48:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:48:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:48:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 13:48:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:48:25 --> Final output sent to browser
DEBUG - 2016-02-24 13:48:25 --> Total execution time: 1.1606
INFO - 2016-02-24 10:48:27 --> Config Class Initialized
INFO - 2016-02-24 10:48:27 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:48:27 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:48:27 --> Utf8 Class Initialized
INFO - 2016-02-24 10:48:27 --> URI Class Initialized
INFO - 2016-02-24 10:48:27 --> Router Class Initialized
INFO - 2016-02-24 10:48:27 --> Output Class Initialized
INFO - 2016-02-24 10:48:27 --> Security Class Initialized
DEBUG - 2016-02-24 10:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:48:27 --> Input Class Initialized
INFO - 2016-02-24 10:48:27 --> Language Class Initialized
INFO - 2016-02-24 10:48:27 --> Loader Class Initialized
INFO - 2016-02-24 10:48:27 --> Helper loaded: url_helper
INFO - 2016-02-24 10:48:27 --> Helper loaded: file_helper
INFO - 2016-02-24 10:48:27 --> Helper loaded: date_helper
INFO - 2016-02-24 10:48:27 --> Helper loaded: form_helper
INFO - 2016-02-24 10:48:27 --> Database Driver Class Initialized
INFO - 2016-02-24 10:48:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:48:28 --> Controller Class Initialized
INFO - 2016-02-24 10:48:28 --> Model Class Initialized
INFO - 2016-02-24 10:48:28 --> Model Class Initialized
INFO - 2016-02-24 10:48:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:48:28 --> Pagination Class Initialized
INFO - 2016-02-24 10:48:28 --> Helper loaded: text_helper
INFO - 2016-02-24 10:48:28 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:48:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:48:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:48:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 13:48:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 13:48:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:48:28 --> Final output sent to browser
DEBUG - 2016-02-24 13:48:28 --> Total execution time: 1.1402
INFO - 2016-02-24 10:48:29 --> Config Class Initialized
INFO - 2016-02-24 10:48:29 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:48:29 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:48:29 --> Utf8 Class Initialized
INFO - 2016-02-24 10:48:29 --> URI Class Initialized
INFO - 2016-02-24 10:48:29 --> Router Class Initialized
INFO - 2016-02-24 10:48:29 --> Output Class Initialized
INFO - 2016-02-24 10:48:29 --> Security Class Initialized
DEBUG - 2016-02-24 10:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:48:29 --> Input Class Initialized
INFO - 2016-02-24 10:48:29 --> Language Class Initialized
INFO - 2016-02-24 10:48:30 --> Loader Class Initialized
INFO - 2016-02-24 10:48:30 --> Helper loaded: url_helper
INFO - 2016-02-24 10:48:30 --> Helper loaded: file_helper
INFO - 2016-02-24 10:48:30 --> Helper loaded: date_helper
INFO - 2016-02-24 10:48:30 --> Helper loaded: form_helper
INFO - 2016-02-24 10:48:30 --> Database Driver Class Initialized
INFO - 2016-02-24 10:48:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:48:31 --> Controller Class Initialized
INFO - 2016-02-24 10:48:31 --> Model Class Initialized
INFO - 2016-02-24 10:48:31 --> Model Class Initialized
INFO - 2016-02-24 10:48:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:48:31 --> Pagination Class Initialized
INFO - 2016-02-24 10:48:31 --> Helper loaded: text_helper
INFO - 2016-02-24 10:48:31 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 13:48:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:48:31 --> Final output sent to browser
DEBUG - 2016-02-24 13:48:31 --> Total execution time: 1.1165
INFO - 2016-02-24 10:50:00 --> Config Class Initialized
INFO - 2016-02-24 10:50:00 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:50:00 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:50:00 --> Utf8 Class Initialized
INFO - 2016-02-24 10:50:00 --> URI Class Initialized
DEBUG - 2016-02-24 10:50:00 --> No URI present. Default controller set.
INFO - 2016-02-24 10:50:00 --> Router Class Initialized
INFO - 2016-02-24 10:50:00 --> Output Class Initialized
INFO - 2016-02-24 10:50:00 --> Security Class Initialized
DEBUG - 2016-02-24 10:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:50:00 --> Input Class Initialized
INFO - 2016-02-24 10:50:00 --> Language Class Initialized
INFO - 2016-02-24 10:50:00 --> Loader Class Initialized
INFO - 2016-02-24 10:50:00 --> Helper loaded: url_helper
INFO - 2016-02-24 10:50:00 --> Helper loaded: file_helper
INFO - 2016-02-24 10:50:00 --> Helper loaded: date_helper
INFO - 2016-02-24 10:50:00 --> Helper loaded: form_helper
INFO - 2016-02-24 10:50:00 --> Database Driver Class Initialized
INFO - 2016-02-24 10:50:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:50:01 --> Controller Class Initialized
INFO - 2016-02-24 10:50:01 --> Model Class Initialized
INFO - 2016-02-24 10:50:01 --> Model Class Initialized
INFO - 2016-02-24 10:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:50:01 --> Pagination Class Initialized
INFO - 2016-02-24 10:50:01 --> Helper loaded: text_helper
INFO - 2016-02-24 10:50:01 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:50:01 --> Final output sent to browser
DEBUG - 2016-02-24 13:50:01 --> Total execution time: 1.1855
INFO - 2016-02-24 10:50:29 --> Config Class Initialized
INFO - 2016-02-24 10:50:29 --> Hooks Class Initialized
DEBUG - 2016-02-24 10:50:29 --> UTF-8 Support Enabled
INFO - 2016-02-24 10:50:29 --> Utf8 Class Initialized
INFO - 2016-02-24 10:50:29 --> URI Class Initialized
DEBUG - 2016-02-24 10:50:29 --> No URI present. Default controller set.
INFO - 2016-02-24 10:50:29 --> Router Class Initialized
INFO - 2016-02-24 10:50:29 --> Output Class Initialized
INFO - 2016-02-24 10:50:29 --> Security Class Initialized
DEBUG - 2016-02-24 10:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 10:50:29 --> Input Class Initialized
INFO - 2016-02-24 10:50:29 --> Language Class Initialized
INFO - 2016-02-24 10:50:29 --> Loader Class Initialized
INFO - 2016-02-24 10:50:29 --> Helper loaded: url_helper
INFO - 2016-02-24 10:50:29 --> Helper loaded: file_helper
INFO - 2016-02-24 10:50:29 --> Helper loaded: date_helper
INFO - 2016-02-24 10:50:29 --> Helper loaded: form_helper
INFO - 2016-02-24 10:50:29 --> Database Driver Class Initialized
INFO - 2016-02-24 10:50:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 10:50:30 --> Controller Class Initialized
INFO - 2016-02-24 10:50:30 --> Model Class Initialized
INFO - 2016-02-24 10:50:30 --> Model Class Initialized
INFO - 2016-02-24 10:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 10:50:30 --> Pagination Class Initialized
INFO - 2016-02-24 10:50:30 --> Helper loaded: text_helper
INFO - 2016-02-24 10:50:30 --> Helper loaded: cookie_helper
INFO - 2016-02-24 13:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 13:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 13:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 13:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 13:50:30 --> Final output sent to browser
DEBUG - 2016-02-24 13:50:30 --> Total execution time: 1.1560
INFO - 2016-02-24 11:12:59 --> Config Class Initialized
INFO - 2016-02-24 11:12:59 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:12:59 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:12:59 --> Utf8 Class Initialized
INFO - 2016-02-24 11:12:59 --> URI Class Initialized
INFO - 2016-02-24 11:12:59 --> Router Class Initialized
INFO - 2016-02-24 11:12:59 --> Output Class Initialized
INFO - 2016-02-24 11:12:59 --> Security Class Initialized
DEBUG - 2016-02-24 11:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:12:59 --> Input Class Initialized
INFO - 2016-02-24 11:12:59 --> Language Class Initialized
INFO - 2016-02-24 11:12:59 --> Loader Class Initialized
INFO - 2016-02-24 11:12:59 --> Helper loaded: url_helper
INFO - 2016-02-24 11:12:59 --> Helper loaded: file_helper
INFO - 2016-02-24 11:12:59 --> Helper loaded: date_helper
INFO - 2016-02-24 11:12:59 --> Helper loaded: form_helper
INFO - 2016-02-24 11:12:59 --> Database Driver Class Initialized
INFO - 2016-02-24 11:13:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:13:00 --> Controller Class Initialized
INFO - 2016-02-24 11:13:00 --> Model Class Initialized
INFO - 2016-02-24 11:13:00 --> Model Class Initialized
INFO - 2016-02-24 11:13:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:13:00 --> Pagination Class Initialized
INFO - 2016-02-24 11:13:00 --> Helper loaded: text_helper
INFO - 2016-02-24 11:13:00 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:13:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:13:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:13:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:13:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:13:00 --> Final output sent to browser
DEBUG - 2016-02-24 14:13:00 --> Total execution time: 1.1123
INFO - 2016-02-24 11:13:03 --> Config Class Initialized
INFO - 2016-02-24 11:13:03 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:13:03 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:13:03 --> Utf8 Class Initialized
INFO - 2016-02-24 11:13:03 --> URI Class Initialized
INFO - 2016-02-24 11:13:03 --> Router Class Initialized
INFO - 2016-02-24 11:13:03 --> Output Class Initialized
INFO - 2016-02-24 11:13:03 --> Security Class Initialized
DEBUG - 2016-02-24 11:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:13:03 --> Input Class Initialized
INFO - 2016-02-24 11:13:03 --> Language Class Initialized
INFO - 2016-02-24 11:13:03 --> Loader Class Initialized
INFO - 2016-02-24 11:13:03 --> Helper loaded: url_helper
INFO - 2016-02-24 11:13:03 --> Helper loaded: file_helper
INFO - 2016-02-24 11:13:03 --> Helper loaded: date_helper
INFO - 2016-02-24 11:13:03 --> Helper loaded: form_helper
INFO - 2016-02-24 11:13:04 --> Database Driver Class Initialized
INFO - 2016-02-24 11:13:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:13:05 --> Controller Class Initialized
INFO - 2016-02-24 11:13:05 --> Model Class Initialized
INFO - 2016-02-24 11:13:05 --> Model Class Initialized
INFO - 2016-02-24 11:13:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:13:05 --> Pagination Class Initialized
INFO - 2016-02-24 11:13:05 --> Helper loaded: text_helper
INFO - 2016-02-24 11:13:05 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 14:13:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:13:05 --> Final output sent to browser
DEBUG - 2016-02-24 14:13:05 --> Total execution time: 1.2308
INFO - 2016-02-24 11:13:11 --> Config Class Initialized
INFO - 2016-02-24 11:13:11 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:13:11 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:13:11 --> Utf8 Class Initialized
INFO - 2016-02-24 11:13:11 --> URI Class Initialized
INFO - 2016-02-24 11:13:11 --> Router Class Initialized
INFO - 2016-02-24 11:13:11 --> Output Class Initialized
INFO - 2016-02-24 11:13:11 --> Security Class Initialized
DEBUG - 2016-02-24 11:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:13:11 --> Input Class Initialized
INFO - 2016-02-24 11:13:11 --> Language Class Initialized
INFO - 2016-02-24 11:13:11 --> Loader Class Initialized
INFO - 2016-02-24 11:13:11 --> Helper loaded: url_helper
INFO - 2016-02-24 11:13:11 --> Helper loaded: file_helper
INFO - 2016-02-24 11:13:11 --> Helper loaded: date_helper
INFO - 2016-02-24 11:13:11 --> Helper loaded: form_helper
INFO - 2016-02-24 11:13:11 --> Database Driver Class Initialized
INFO - 2016-02-24 11:13:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:13:12 --> Controller Class Initialized
INFO - 2016-02-24 11:13:12 --> Model Class Initialized
INFO - 2016-02-24 11:13:12 --> Model Class Initialized
INFO - 2016-02-24 11:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:13:12 --> Pagination Class Initialized
INFO - 2016-02-24 11:13:12 --> Helper loaded: text_helper
INFO - 2016-02-24 11:13:12 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 14:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 14:13:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:13:12 --> Final output sent to browser
DEBUG - 2016-02-24 14:13:12 --> Total execution time: 1.2059
INFO - 2016-02-24 11:13:32 --> Config Class Initialized
INFO - 2016-02-24 11:13:32 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:13:32 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:13:32 --> Utf8 Class Initialized
INFO - 2016-02-24 11:13:32 --> URI Class Initialized
DEBUG - 2016-02-24 11:13:32 --> No URI present. Default controller set.
INFO - 2016-02-24 11:13:32 --> Router Class Initialized
INFO - 2016-02-24 11:13:32 --> Output Class Initialized
INFO - 2016-02-24 11:13:32 --> Security Class Initialized
DEBUG - 2016-02-24 11:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:13:32 --> Input Class Initialized
INFO - 2016-02-24 11:13:32 --> Language Class Initialized
INFO - 2016-02-24 11:13:32 --> Loader Class Initialized
INFO - 2016-02-24 11:13:32 --> Helper loaded: url_helper
INFO - 2016-02-24 11:13:32 --> Helper loaded: file_helper
INFO - 2016-02-24 11:13:32 --> Helper loaded: date_helper
INFO - 2016-02-24 11:13:32 --> Helper loaded: form_helper
INFO - 2016-02-24 11:13:32 --> Database Driver Class Initialized
INFO - 2016-02-24 11:13:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:13:33 --> Controller Class Initialized
INFO - 2016-02-24 11:13:33 --> Model Class Initialized
INFO - 2016-02-24 11:13:33 --> Model Class Initialized
INFO - 2016-02-24 11:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:13:33 --> Pagination Class Initialized
INFO - 2016-02-24 11:13:33 --> Helper loaded: text_helper
INFO - 2016-02-24 11:13:33 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:13:33 --> Final output sent to browser
DEBUG - 2016-02-24 14:13:33 --> Total execution time: 1.1496
INFO - 2016-02-24 11:19:53 --> Config Class Initialized
INFO - 2016-02-24 11:19:53 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:19:53 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:19:53 --> Utf8 Class Initialized
INFO - 2016-02-24 11:19:53 --> URI Class Initialized
INFO - 2016-02-24 11:19:53 --> Router Class Initialized
INFO - 2016-02-24 11:19:53 --> Output Class Initialized
INFO - 2016-02-24 11:19:53 --> Security Class Initialized
DEBUG - 2016-02-24 11:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:19:53 --> Input Class Initialized
INFO - 2016-02-24 11:19:53 --> Language Class Initialized
INFO - 2016-02-24 11:19:53 --> Loader Class Initialized
INFO - 2016-02-24 11:19:53 --> Helper loaded: url_helper
INFO - 2016-02-24 11:19:53 --> Helper loaded: file_helper
INFO - 2016-02-24 11:19:53 --> Helper loaded: date_helper
INFO - 2016-02-24 11:19:53 --> Helper loaded: form_helper
INFO - 2016-02-24 11:19:53 --> Database Driver Class Initialized
INFO - 2016-02-24 11:19:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:19:54 --> Controller Class Initialized
INFO - 2016-02-24 11:19:54 --> Model Class Initialized
INFO - 2016-02-24 11:19:54 --> Model Class Initialized
INFO - 2016-02-24 11:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:19:54 --> Pagination Class Initialized
INFO - 2016-02-24 11:19:54 --> Helper loaded: text_helper
INFO - 2016-02-24 11:19:54 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:19:54 --> Final output sent to browser
DEBUG - 2016-02-24 14:19:54 --> Total execution time: 1.1514
INFO - 2016-02-24 11:20:11 --> Config Class Initialized
INFO - 2016-02-24 11:20:11 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:20:11 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:20:11 --> Utf8 Class Initialized
INFO - 2016-02-24 11:20:11 --> URI Class Initialized
INFO - 2016-02-24 11:20:11 --> Router Class Initialized
INFO - 2016-02-24 11:20:11 --> Output Class Initialized
INFO - 2016-02-24 11:20:11 --> Security Class Initialized
DEBUG - 2016-02-24 11:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:20:11 --> Input Class Initialized
INFO - 2016-02-24 11:20:11 --> Language Class Initialized
INFO - 2016-02-24 11:20:11 --> Loader Class Initialized
INFO - 2016-02-24 11:20:11 --> Helper loaded: url_helper
INFO - 2016-02-24 11:20:11 --> Helper loaded: file_helper
INFO - 2016-02-24 11:20:11 --> Helper loaded: date_helper
INFO - 2016-02-24 11:20:11 --> Helper loaded: form_helper
INFO - 2016-02-24 11:20:11 --> Database Driver Class Initialized
INFO - 2016-02-24 11:20:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:20:12 --> Controller Class Initialized
INFO - 2016-02-24 11:20:12 --> Model Class Initialized
INFO - 2016-02-24 11:20:12 --> Model Class Initialized
INFO - 2016-02-24 11:20:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:20:12 --> Pagination Class Initialized
INFO - 2016-02-24 11:20:12 --> Helper loaded: text_helper
INFO - 2016-02-24 11:20:12 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:20:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:20:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 14:20:12 --> Query error: Table 'jdboard.info_comment' doesn't exist - Invalid query: SELECT *
FROM `info_comment`
WHERE `board_id` = '48'
INFO - 2016-02-24 14:20:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-24 14:20:12 --> Query error: Unknown column 'board_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1456341612
WHERE `board_id` = '48'
AND `id` = '514eb57798c225a9238fa758e5190e8d1f138c5a'
INFO - 2016-02-24 11:20:15 --> Config Class Initialized
INFO - 2016-02-24 11:20:15 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:20:15 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:20:15 --> Utf8 Class Initialized
INFO - 2016-02-24 11:20:15 --> URI Class Initialized
INFO - 2016-02-24 11:20:15 --> Router Class Initialized
INFO - 2016-02-24 11:20:15 --> Output Class Initialized
INFO - 2016-02-24 11:20:15 --> Security Class Initialized
DEBUG - 2016-02-24 11:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:20:15 --> Input Class Initialized
INFO - 2016-02-24 11:20:15 --> Language Class Initialized
INFO - 2016-02-24 11:20:15 --> Loader Class Initialized
INFO - 2016-02-24 11:20:15 --> Helper loaded: url_helper
INFO - 2016-02-24 11:20:15 --> Helper loaded: file_helper
INFO - 2016-02-24 11:20:15 --> Helper loaded: date_helper
INFO - 2016-02-24 11:20:15 --> Helper loaded: form_helper
INFO - 2016-02-24 11:20:15 --> Database Driver Class Initialized
INFO - 2016-02-24 11:20:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:20:16 --> Controller Class Initialized
INFO - 2016-02-24 11:20:16 --> Model Class Initialized
INFO - 2016-02-24 11:20:16 --> Model Class Initialized
INFO - 2016-02-24 11:20:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:20:16 --> Pagination Class Initialized
INFO - 2016-02-24 11:20:16 --> Helper loaded: text_helper
INFO - 2016-02-24 11:20:16 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:20:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:20:16 --> Final output sent to browser
DEBUG - 2016-02-24 14:20:16 --> Total execution time: 1.1380
INFO - 2016-02-24 11:20:17 --> Config Class Initialized
INFO - 2016-02-24 11:20:17 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:20:17 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:20:17 --> Utf8 Class Initialized
INFO - 2016-02-24 11:20:17 --> URI Class Initialized
INFO - 2016-02-24 11:20:17 --> Router Class Initialized
INFO - 2016-02-24 11:20:17 --> Output Class Initialized
INFO - 2016-02-24 11:20:17 --> Security Class Initialized
DEBUG - 2016-02-24 11:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:20:17 --> Input Class Initialized
INFO - 2016-02-24 11:20:17 --> Language Class Initialized
INFO - 2016-02-24 11:20:17 --> Loader Class Initialized
INFO - 2016-02-24 11:20:17 --> Helper loaded: url_helper
INFO - 2016-02-24 11:20:17 --> Helper loaded: file_helper
INFO - 2016-02-24 11:20:17 --> Helper loaded: date_helper
INFO - 2016-02-24 11:20:17 --> Helper loaded: form_helper
INFO - 2016-02-24 11:20:17 --> Database Driver Class Initialized
INFO - 2016-02-24 11:20:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:20:18 --> Controller Class Initialized
INFO - 2016-02-24 11:20:18 --> Model Class Initialized
INFO - 2016-02-24 11:20:18 --> Model Class Initialized
INFO - 2016-02-24 11:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:20:18 --> Pagination Class Initialized
INFO - 2016-02-24 11:20:18 --> Helper loaded: text_helper
INFO - 2016-02-24 11:20:18 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 14:20:18 --> Query error: Table 'jdboard.info_comment' doesn't exist - Invalid query: SELECT *
FROM `info_comment`
WHERE `board_id` = '66'
INFO - 2016-02-24 14:20:18 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-24 14:20:18 --> Query error: Unknown column 'board_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1456341618
WHERE `board_id` = '66'
AND `id` = '514eb57798c225a9238fa758e5190e8d1f138c5a'
INFO - 2016-02-24 11:20:22 --> Config Class Initialized
INFO - 2016-02-24 11:20:22 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:20:22 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:20:22 --> Utf8 Class Initialized
INFO - 2016-02-24 11:20:22 --> URI Class Initialized
INFO - 2016-02-24 11:20:22 --> Router Class Initialized
INFO - 2016-02-24 11:20:22 --> Output Class Initialized
INFO - 2016-02-24 11:20:22 --> Security Class Initialized
DEBUG - 2016-02-24 11:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:20:22 --> Input Class Initialized
INFO - 2016-02-24 11:20:22 --> Language Class Initialized
INFO - 2016-02-24 11:20:22 --> Loader Class Initialized
INFO - 2016-02-24 11:20:22 --> Helper loaded: url_helper
INFO - 2016-02-24 11:20:22 --> Helper loaded: file_helper
INFO - 2016-02-24 11:20:22 --> Helper loaded: date_helper
INFO - 2016-02-24 11:20:22 --> Helper loaded: form_helper
INFO - 2016-02-24 11:20:22 --> Database Driver Class Initialized
INFO - 2016-02-24 11:20:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:20:23 --> Controller Class Initialized
INFO - 2016-02-24 11:20:23 --> Model Class Initialized
INFO - 2016-02-24 11:20:23 --> Model Class Initialized
INFO - 2016-02-24 11:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:20:23 --> Pagination Class Initialized
INFO - 2016-02-24 11:20:23 --> Helper loaded: text_helper
INFO - 2016-02-24 11:20:23 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:20:23 --> Final output sent to browser
DEBUG - 2016-02-24 14:20:23 --> Total execution time: 1.1205
INFO - 2016-02-24 11:20:44 --> Config Class Initialized
INFO - 2016-02-24 11:20:44 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:20:44 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:20:44 --> Utf8 Class Initialized
INFO - 2016-02-24 11:20:44 --> URI Class Initialized
INFO - 2016-02-24 11:20:44 --> Router Class Initialized
INFO - 2016-02-24 11:20:44 --> Output Class Initialized
INFO - 2016-02-24 11:20:44 --> Security Class Initialized
DEBUG - 2016-02-24 11:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:20:44 --> Input Class Initialized
INFO - 2016-02-24 11:20:44 --> Language Class Initialized
INFO - 2016-02-24 11:20:44 --> Loader Class Initialized
INFO - 2016-02-24 11:20:44 --> Helper loaded: url_helper
INFO - 2016-02-24 11:20:44 --> Helper loaded: file_helper
INFO - 2016-02-24 11:20:44 --> Helper loaded: date_helper
INFO - 2016-02-24 11:20:44 --> Helper loaded: form_helper
INFO - 2016-02-24 11:20:44 --> Database Driver Class Initialized
INFO - 2016-02-24 11:20:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:20:45 --> Controller Class Initialized
INFO - 2016-02-24 11:20:45 --> Model Class Initialized
INFO - 2016-02-24 11:20:45 --> Model Class Initialized
INFO - 2016-02-24 11:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:20:45 --> Pagination Class Initialized
INFO - 2016-02-24 11:20:45 --> Helper loaded: text_helper
INFO - 2016-02-24 11:20:45 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:20:45 --> Final output sent to browser
DEBUG - 2016-02-24 14:20:45 --> Total execution time: 1.1305
INFO - 2016-02-24 11:20:47 --> Config Class Initialized
INFO - 2016-02-24 11:20:47 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:20:47 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:20:47 --> Utf8 Class Initialized
INFO - 2016-02-24 11:20:47 --> URI Class Initialized
INFO - 2016-02-24 11:20:47 --> Router Class Initialized
INFO - 2016-02-24 11:20:47 --> Output Class Initialized
INFO - 2016-02-24 11:20:47 --> Security Class Initialized
DEBUG - 2016-02-24 11:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:20:47 --> Input Class Initialized
INFO - 2016-02-24 11:20:47 --> Language Class Initialized
INFO - 2016-02-24 11:20:47 --> Loader Class Initialized
INFO - 2016-02-24 11:20:47 --> Helper loaded: url_helper
INFO - 2016-02-24 11:20:47 --> Helper loaded: file_helper
INFO - 2016-02-24 11:20:47 --> Helper loaded: date_helper
INFO - 2016-02-24 11:20:47 --> Helper loaded: form_helper
INFO - 2016-02-24 11:20:47 --> Database Driver Class Initialized
INFO - 2016-02-24 11:20:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:20:48 --> Controller Class Initialized
INFO - 2016-02-24 11:20:48 --> Model Class Initialized
INFO - 2016-02-24 11:20:48 --> Model Class Initialized
INFO - 2016-02-24 11:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:20:48 --> Pagination Class Initialized
INFO - 2016-02-24 11:20:48 --> Helper loaded: text_helper
INFO - 2016-02-24 11:20:48 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 14:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 14:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:20:48 --> Final output sent to browser
DEBUG - 2016-02-24 14:20:48 --> Total execution time: 1.1550
INFO - 2016-02-24 11:30:05 --> Config Class Initialized
INFO - 2016-02-24 11:30:05 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:30:05 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:30:05 --> Utf8 Class Initialized
INFO - 2016-02-24 11:30:05 --> URI Class Initialized
INFO - 2016-02-24 11:30:05 --> Router Class Initialized
INFO - 2016-02-24 11:30:05 --> Output Class Initialized
INFO - 2016-02-24 11:30:05 --> Security Class Initialized
DEBUG - 2016-02-24 11:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:30:05 --> Input Class Initialized
INFO - 2016-02-24 11:30:05 --> Language Class Initialized
INFO - 2016-02-24 11:30:05 --> Loader Class Initialized
INFO - 2016-02-24 11:30:05 --> Helper loaded: url_helper
INFO - 2016-02-24 11:30:05 --> Helper loaded: file_helper
INFO - 2016-02-24 11:30:05 --> Helper loaded: date_helper
INFO - 2016-02-24 11:30:05 --> Helper loaded: form_helper
INFO - 2016-02-24 11:30:05 --> Database Driver Class Initialized
INFO - 2016-02-24 11:30:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:30:06 --> Controller Class Initialized
INFO - 2016-02-24 11:30:06 --> Model Class Initialized
INFO - 2016-02-24 11:30:06 --> Model Class Initialized
INFO - 2016-02-24 11:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:30:06 --> Pagination Class Initialized
INFO - 2016-02-24 11:30:06 --> Helper loaded: text_helper
INFO - 2016-02-24 11:30:06 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:30:06 --> Final output sent to browser
DEBUG - 2016-02-24 14:30:06 --> Total execution time: 1.1439
INFO - 2016-02-24 11:33:07 --> Config Class Initialized
INFO - 2016-02-24 11:33:07 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:33:07 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:33:07 --> Utf8 Class Initialized
INFO - 2016-02-24 11:33:07 --> URI Class Initialized
INFO - 2016-02-24 11:33:07 --> Router Class Initialized
INFO - 2016-02-24 11:33:07 --> Output Class Initialized
INFO - 2016-02-24 11:33:07 --> Security Class Initialized
DEBUG - 2016-02-24 11:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:33:07 --> Input Class Initialized
INFO - 2016-02-24 11:33:07 --> Language Class Initialized
INFO - 2016-02-24 11:33:07 --> Loader Class Initialized
INFO - 2016-02-24 11:33:07 --> Helper loaded: url_helper
INFO - 2016-02-24 11:33:07 --> Helper loaded: file_helper
INFO - 2016-02-24 11:33:07 --> Helper loaded: date_helper
INFO - 2016-02-24 11:33:07 --> Helper loaded: form_helper
INFO - 2016-02-24 11:33:07 --> Database Driver Class Initialized
INFO - 2016-02-24 11:33:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:33:08 --> Controller Class Initialized
INFO - 2016-02-24 11:33:08 --> Model Class Initialized
INFO - 2016-02-24 11:33:08 --> Model Class Initialized
INFO - 2016-02-24 11:33:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:33:08 --> Pagination Class Initialized
INFO - 2016-02-24 11:33:08 --> Helper loaded: text_helper
INFO - 2016-02-24 11:33:08 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 14:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 14:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:33:08 --> Final output sent to browser
DEBUG - 2016-02-24 14:33:08 --> Total execution time: 1.1957
INFO - 2016-02-24 11:33:08 --> Config Class Initialized
INFO - 2016-02-24 11:33:08 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:33:08 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:33:08 --> Utf8 Class Initialized
INFO - 2016-02-24 11:33:08 --> URI Class Initialized
INFO - 2016-02-24 11:33:08 --> Router Class Initialized
INFO - 2016-02-24 11:33:08 --> Output Class Initialized
INFO - 2016-02-24 11:33:08 --> Security Class Initialized
DEBUG - 2016-02-24 11:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:33:08 --> Input Class Initialized
INFO - 2016-02-24 11:33:08 --> Language Class Initialized
ERROR - 2016-02-24 11:33:08 --> 404 Page Not Found: Static/user
INFO - 2016-02-24 11:34:27 --> Config Class Initialized
INFO - 2016-02-24 11:34:27 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:34:27 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:34:27 --> Utf8 Class Initialized
INFO - 2016-02-24 11:34:27 --> URI Class Initialized
INFO - 2016-02-24 11:34:27 --> Router Class Initialized
INFO - 2016-02-24 11:34:27 --> Output Class Initialized
INFO - 2016-02-24 11:34:27 --> Security Class Initialized
DEBUG - 2016-02-24 11:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:34:27 --> Input Class Initialized
INFO - 2016-02-24 11:34:27 --> Language Class Initialized
INFO - 2016-02-24 11:34:27 --> Loader Class Initialized
INFO - 2016-02-24 11:34:27 --> Helper loaded: url_helper
INFO - 2016-02-24 11:34:27 --> Helper loaded: file_helper
INFO - 2016-02-24 11:34:27 --> Helper loaded: date_helper
INFO - 2016-02-24 11:34:27 --> Helper loaded: form_helper
INFO - 2016-02-24 11:34:27 --> Database Driver Class Initialized
INFO - 2016-02-24 11:34:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:34:28 --> Controller Class Initialized
INFO - 2016-02-24 11:34:28 --> Model Class Initialized
INFO - 2016-02-24 11:34:28 --> Model Class Initialized
INFO - 2016-02-24 11:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:34:28 --> Pagination Class Initialized
INFO - 2016-02-24 11:34:28 --> Helper loaded: text_helper
INFO - 2016-02-24 11:34:28 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:34:28 --> Final output sent to browser
DEBUG - 2016-02-24 14:34:28 --> Total execution time: 1.1657
INFO - 2016-02-24 11:34:40 --> Config Class Initialized
INFO - 2016-02-24 11:34:40 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:34:40 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:34:40 --> Utf8 Class Initialized
INFO - 2016-02-24 11:34:40 --> URI Class Initialized
INFO - 2016-02-24 11:34:40 --> Router Class Initialized
INFO - 2016-02-24 11:34:40 --> Output Class Initialized
INFO - 2016-02-24 11:34:40 --> Security Class Initialized
DEBUG - 2016-02-24 11:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:34:40 --> Input Class Initialized
INFO - 2016-02-24 11:34:40 --> Language Class Initialized
INFO - 2016-02-24 11:34:40 --> Loader Class Initialized
INFO - 2016-02-24 11:34:40 --> Helper loaded: url_helper
INFO - 2016-02-24 11:34:40 --> Helper loaded: file_helper
INFO - 2016-02-24 11:34:40 --> Helper loaded: date_helper
INFO - 2016-02-24 11:34:40 --> Helper loaded: form_helper
INFO - 2016-02-24 11:34:40 --> Database Driver Class Initialized
INFO - 2016-02-24 11:34:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:34:41 --> Controller Class Initialized
INFO - 2016-02-24 11:34:41 --> Model Class Initialized
INFO - 2016-02-24 11:34:41 --> Model Class Initialized
INFO - 2016-02-24 11:34:41 --> Form Validation Class Initialized
INFO - 2016-02-24 11:34:41 --> Helper loaded: text_helper
INFO - 2016-02-24 11:34:41 --> Config Class Initialized
INFO - 2016-02-24 11:34:41 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:34:41 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:34:41 --> Utf8 Class Initialized
INFO - 2016-02-24 11:34:41 --> URI Class Initialized
INFO - 2016-02-24 11:34:41 --> Router Class Initialized
INFO - 2016-02-24 11:34:41 --> Output Class Initialized
INFO - 2016-02-24 11:34:41 --> Security Class Initialized
DEBUG - 2016-02-24 11:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:34:41 --> Input Class Initialized
INFO - 2016-02-24 11:34:42 --> Language Class Initialized
INFO - 2016-02-24 11:34:42 --> Loader Class Initialized
INFO - 2016-02-24 11:34:42 --> Helper loaded: url_helper
INFO - 2016-02-24 11:34:42 --> Helper loaded: file_helper
INFO - 2016-02-24 11:34:42 --> Helper loaded: date_helper
INFO - 2016-02-24 11:34:42 --> Helper loaded: form_helper
INFO - 2016-02-24 11:34:42 --> Database Driver Class Initialized
INFO - 2016-02-24 11:34:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:34:43 --> Controller Class Initialized
INFO - 2016-02-24 11:34:43 --> Model Class Initialized
INFO - 2016-02-24 11:34:43 --> Model Class Initialized
INFO - 2016-02-24 11:34:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:34:43 --> Pagination Class Initialized
INFO - 2016-02-24 11:34:43 --> Helper loaded: text_helper
INFO - 2016-02-24 11:34:43 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:34:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:34:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:34:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:34:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:34:43 --> Final output sent to browser
DEBUG - 2016-02-24 14:34:43 --> Total execution time: 1.1100
INFO - 2016-02-24 11:34:46 --> Config Class Initialized
INFO - 2016-02-24 11:34:46 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:34:46 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:34:46 --> Utf8 Class Initialized
INFO - 2016-02-24 11:34:46 --> URI Class Initialized
INFO - 2016-02-24 11:34:46 --> Router Class Initialized
INFO - 2016-02-24 11:34:46 --> Output Class Initialized
INFO - 2016-02-24 11:34:46 --> Security Class Initialized
DEBUG - 2016-02-24 11:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:34:46 --> Input Class Initialized
INFO - 2016-02-24 11:34:46 --> Language Class Initialized
INFO - 2016-02-24 11:34:46 --> Loader Class Initialized
INFO - 2016-02-24 11:34:46 --> Helper loaded: url_helper
INFO - 2016-02-24 11:34:46 --> Helper loaded: file_helper
INFO - 2016-02-24 11:34:46 --> Helper loaded: date_helper
INFO - 2016-02-24 11:34:46 --> Helper loaded: form_helper
INFO - 2016-02-24 11:34:46 --> Database Driver Class Initialized
INFO - 2016-02-24 11:34:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:34:47 --> Controller Class Initialized
INFO - 2016-02-24 11:34:47 --> Model Class Initialized
INFO - 2016-02-24 11:34:47 --> Model Class Initialized
INFO - 2016-02-24 11:34:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:34:47 --> Pagination Class Initialized
INFO - 2016-02-24 11:34:47 --> Helper loaded: text_helper
INFO - 2016-02-24 11:34:47 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:34:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:34:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:34:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 14:34:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 14:34:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:34:47 --> Final output sent to browser
DEBUG - 2016-02-24 14:34:47 --> Total execution time: 1.1781
INFO - 2016-02-24 11:34:47 --> Config Class Initialized
INFO - 2016-02-24 11:34:47 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:34:47 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:34:47 --> Utf8 Class Initialized
INFO - 2016-02-24 11:34:47 --> URI Class Initialized
INFO - 2016-02-24 11:34:47 --> Router Class Initialized
INFO - 2016-02-24 11:34:47 --> Output Class Initialized
INFO - 2016-02-24 11:34:47 --> Security Class Initialized
DEBUG - 2016-02-24 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:34:47 --> Input Class Initialized
INFO - 2016-02-24 11:34:47 --> Language Class Initialized
ERROR - 2016-02-24 11:34:47 --> 404 Page Not Found: Static/user
INFO - 2016-02-24 11:37:12 --> Config Class Initialized
INFO - 2016-02-24 11:37:12 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:37:12 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:37:12 --> Utf8 Class Initialized
INFO - 2016-02-24 11:37:12 --> URI Class Initialized
DEBUG - 2016-02-24 11:37:12 --> No URI present. Default controller set.
INFO - 2016-02-24 11:37:12 --> Router Class Initialized
INFO - 2016-02-24 11:37:12 --> Output Class Initialized
INFO - 2016-02-24 11:37:12 --> Security Class Initialized
DEBUG - 2016-02-24 11:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:37:12 --> Input Class Initialized
INFO - 2016-02-24 11:37:12 --> Language Class Initialized
INFO - 2016-02-24 11:37:12 --> Loader Class Initialized
INFO - 2016-02-24 11:37:12 --> Helper loaded: url_helper
INFO - 2016-02-24 11:37:12 --> Helper loaded: file_helper
INFO - 2016-02-24 11:37:12 --> Helper loaded: date_helper
INFO - 2016-02-24 11:37:12 --> Helper loaded: form_helper
INFO - 2016-02-24 11:37:12 --> Database Driver Class Initialized
INFO - 2016-02-24 11:37:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:37:13 --> Controller Class Initialized
INFO - 2016-02-24 11:37:13 --> Model Class Initialized
INFO - 2016-02-24 11:37:13 --> Model Class Initialized
INFO - 2016-02-24 11:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:37:13 --> Pagination Class Initialized
INFO - 2016-02-24 11:37:13 --> Helper loaded: text_helper
INFO - 2016-02-24 11:37:13 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:37:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:37:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 14:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 14
INFO - 2016-02-24 14:37:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 14:37:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:37:13 --> Final output sent to browser
DEBUG - 2016-02-24 14:37:13 --> Total execution time: 1.1361
INFO - 2016-02-24 11:37:14 --> Config Class Initialized
INFO - 2016-02-24 11:37:14 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:37:14 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:37:14 --> Utf8 Class Initialized
INFO - 2016-02-24 11:37:14 --> URI Class Initialized
INFO - 2016-02-24 11:37:14 --> Router Class Initialized
INFO - 2016-02-24 11:37:14 --> Output Class Initialized
INFO - 2016-02-24 11:37:14 --> Security Class Initialized
DEBUG - 2016-02-24 11:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:37:14 --> Input Class Initialized
INFO - 2016-02-24 11:37:14 --> Language Class Initialized
INFO - 2016-02-24 11:37:14 --> Loader Class Initialized
INFO - 2016-02-24 11:37:14 --> Helper loaded: url_helper
INFO - 2016-02-24 11:37:14 --> Helper loaded: file_helper
INFO - 2016-02-24 11:37:14 --> Helper loaded: date_helper
INFO - 2016-02-24 11:37:14 --> Helper loaded: form_helper
INFO - 2016-02-24 11:37:14 --> Database Driver Class Initialized
INFO - 2016-02-24 11:37:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:37:15 --> Controller Class Initialized
INFO - 2016-02-24 11:37:15 --> Model Class Initialized
INFO - 2016-02-24 11:37:15 --> Model Class Initialized
INFO - 2016-02-24 11:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:37:15 --> Pagination Class Initialized
INFO - 2016-02-24 11:37:15 --> Helper loaded: text_helper
INFO - 2016-02-24 11:37:15 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 14:37:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-02-24 14:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:37:15 --> Final output sent to browser
DEBUG - 2016-02-24 14:37:15 --> Total execution time: 1.1174
INFO - 2016-02-24 11:37:18 --> Config Class Initialized
INFO - 2016-02-24 11:37:18 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:37:18 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:37:18 --> Utf8 Class Initialized
INFO - 2016-02-24 11:37:18 --> URI Class Initialized
INFO - 2016-02-24 11:37:18 --> Router Class Initialized
INFO - 2016-02-24 11:37:18 --> Output Class Initialized
INFO - 2016-02-24 11:37:18 --> Security Class Initialized
DEBUG - 2016-02-24 11:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:37:18 --> Input Class Initialized
INFO - 2016-02-24 11:37:18 --> Language Class Initialized
INFO - 2016-02-24 11:37:18 --> Loader Class Initialized
INFO - 2016-02-24 11:37:18 --> Helper loaded: url_helper
INFO - 2016-02-24 11:37:18 --> Helper loaded: file_helper
INFO - 2016-02-24 11:37:18 --> Helper loaded: date_helper
INFO - 2016-02-24 11:37:18 --> Helper loaded: form_helper
INFO - 2016-02-24 11:37:18 --> Database Driver Class Initialized
INFO - 2016-02-24 11:37:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:37:19 --> Controller Class Initialized
INFO - 2016-02-24 11:37:19 --> Model Class Initialized
INFO - 2016-02-24 11:37:19 --> Model Class Initialized
INFO - 2016-02-24 11:37:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:37:19 --> Pagination Class Initialized
INFO - 2016-02-24 11:37:19 --> Helper loaded: text_helper
INFO - 2016-02-24 11:37:19 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-24 14:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 14:37:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:37:19 --> Final output sent to browser
DEBUG - 2016-02-24 14:37:19 --> Total execution time: 1.1322
INFO - 2016-02-24 11:53:31 --> Config Class Initialized
INFO - 2016-02-24 11:53:31 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:53:31 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:53:31 --> Utf8 Class Initialized
INFO - 2016-02-24 11:53:31 --> URI Class Initialized
INFO - 2016-02-24 11:53:31 --> Router Class Initialized
INFO - 2016-02-24 11:53:31 --> Output Class Initialized
INFO - 2016-02-24 11:53:31 --> Security Class Initialized
DEBUG - 2016-02-24 11:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:53:31 --> Input Class Initialized
INFO - 2016-02-24 11:53:31 --> Language Class Initialized
INFO - 2016-02-24 11:53:31 --> Loader Class Initialized
INFO - 2016-02-24 11:53:31 --> Helper loaded: url_helper
INFO - 2016-02-24 11:53:31 --> Helper loaded: file_helper
INFO - 2016-02-24 11:53:31 --> Helper loaded: date_helper
INFO - 2016-02-24 11:53:31 --> Helper loaded: form_helper
INFO - 2016-02-24 11:53:31 --> Database Driver Class Initialized
INFO - 2016-02-24 11:53:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:53:32 --> Controller Class Initialized
INFO - 2016-02-24 11:53:32 --> Model Class Initialized
INFO - 2016-02-24 11:53:32 --> Model Class Initialized
INFO - 2016-02-24 11:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:53:32 --> Pagination Class Initialized
INFO - 2016-02-24 11:53:32 --> Helper loaded: text_helper
INFO - 2016-02-24 11:53:32 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:53:32 --> Final output sent to browser
DEBUG - 2016-02-24 14:53:32 --> Total execution time: 1.1959
INFO - 2016-02-24 11:53:51 --> Config Class Initialized
INFO - 2016-02-24 11:53:51 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:53:51 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:53:51 --> Utf8 Class Initialized
INFO - 2016-02-24 11:53:51 --> URI Class Initialized
INFO - 2016-02-24 11:53:51 --> Router Class Initialized
INFO - 2016-02-24 11:53:51 --> Output Class Initialized
INFO - 2016-02-24 11:53:51 --> Security Class Initialized
DEBUG - 2016-02-24 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:53:51 --> Input Class Initialized
INFO - 2016-02-24 11:53:51 --> Language Class Initialized
INFO - 2016-02-24 11:53:51 --> Loader Class Initialized
INFO - 2016-02-24 11:53:51 --> Helper loaded: url_helper
INFO - 2016-02-24 11:53:52 --> Helper loaded: file_helper
INFO - 2016-02-24 11:53:52 --> Helper loaded: date_helper
INFO - 2016-02-24 11:53:52 --> Helper loaded: form_helper
INFO - 2016-02-24 11:53:52 --> Database Driver Class Initialized
INFO - 2016-02-24 11:53:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:53:53 --> Controller Class Initialized
INFO - 2016-02-24 11:53:53 --> Model Class Initialized
INFO - 2016-02-24 11:53:53 --> Model Class Initialized
INFO - 2016-02-24 11:53:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:53:53 --> Pagination Class Initialized
INFO - 2016-02-24 11:53:53 --> Helper loaded: text_helper
INFO - 2016-02-24 11:53:53 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:53:53 --> Final output sent to browser
DEBUG - 2016-02-24 14:53:53 --> Total execution time: 1.1066
INFO - 2016-02-24 11:53:57 --> Config Class Initialized
INFO - 2016-02-24 11:53:57 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:53:57 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:53:57 --> Utf8 Class Initialized
INFO - 2016-02-24 11:53:57 --> URI Class Initialized
INFO - 2016-02-24 11:53:57 --> Router Class Initialized
INFO - 2016-02-24 11:53:57 --> Output Class Initialized
INFO - 2016-02-24 11:53:57 --> Security Class Initialized
DEBUG - 2016-02-24 11:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:53:57 --> Input Class Initialized
INFO - 2016-02-24 11:53:57 --> Language Class Initialized
INFO - 2016-02-24 11:53:57 --> Loader Class Initialized
INFO - 2016-02-24 11:53:57 --> Helper loaded: url_helper
INFO - 2016-02-24 11:53:57 --> Helper loaded: file_helper
INFO - 2016-02-24 11:53:57 --> Helper loaded: date_helper
INFO - 2016-02-24 11:53:57 --> Helper loaded: form_helper
INFO - 2016-02-24 11:53:57 --> Database Driver Class Initialized
INFO - 2016-02-24 11:53:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:53:58 --> Controller Class Initialized
INFO - 2016-02-24 11:53:58 --> Model Class Initialized
INFO - 2016-02-24 11:53:58 --> Model Class Initialized
INFO - 2016-02-24 11:53:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:53:58 --> Pagination Class Initialized
INFO - 2016-02-24 11:53:58 --> Helper loaded: text_helper
INFO - 2016-02-24 11:53:58 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:53:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:53:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:53:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:53:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:53:58 --> Final output sent to browser
DEBUG - 2016-02-24 14:53:58 --> Total execution time: 1.1112
INFO - 2016-02-24 11:54:02 --> Config Class Initialized
INFO - 2016-02-24 11:54:02 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:54:02 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:54:02 --> Utf8 Class Initialized
INFO - 2016-02-24 11:54:02 --> URI Class Initialized
INFO - 2016-02-24 11:54:02 --> Router Class Initialized
INFO - 2016-02-24 11:54:02 --> Output Class Initialized
INFO - 2016-02-24 11:54:02 --> Security Class Initialized
DEBUG - 2016-02-24 11:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:54:02 --> Input Class Initialized
INFO - 2016-02-24 11:54:02 --> Language Class Initialized
INFO - 2016-02-24 11:54:02 --> Loader Class Initialized
INFO - 2016-02-24 11:54:02 --> Helper loaded: url_helper
INFO - 2016-02-24 11:54:02 --> Helper loaded: file_helper
INFO - 2016-02-24 11:54:02 --> Helper loaded: date_helper
INFO - 2016-02-24 11:54:02 --> Helper loaded: form_helper
INFO - 2016-02-24 11:54:02 --> Database Driver Class Initialized
INFO - 2016-02-24 11:54:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:54:03 --> Controller Class Initialized
INFO - 2016-02-24 11:54:03 --> Model Class Initialized
INFO - 2016-02-24 11:54:03 --> Model Class Initialized
INFO - 2016-02-24 11:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:54:03 --> Pagination Class Initialized
INFO - 2016-02-24 11:54:03 --> Helper loaded: text_helper
INFO - 2016-02-24 11:54:03 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 14:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:54:03 --> Final output sent to browser
DEBUG - 2016-02-24 14:54:03 --> Total execution time: 1.1017
INFO - 2016-02-24 11:54:04 --> Config Class Initialized
INFO - 2016-02-24 11:54:04 --> Hooks Class Initialized
DEBUG - 2016-02-24 11:54:04 --> UTF-8 Support Enabled
INFO - 2016-02-24 11:54:04 --> Utf8 Class Initialized
INFO - 2016-02-24 11:54:04 --> URI Class Initialized
INFO - 2016-02-24 11:54:04 --> Router Class Initialized
INFO - 2016-02-24 11:54:04 --> Output Class Initialized
INFO - 2016-02-24 11:54:04 --> Security Class Initialized
DEBUG - 2016-02-24 11:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 11:54:04 --> Input Class Initialized
INFO - 2016-02-24 11:54:04 --> Language Class Initialized
INFO - 2016-02-24 11:54:04 --> Loader Class Initialized
INFO - 2016-02-24 11:54:04 --> Helper loaded: url_helper
INFO - 2016-02-24 11:54:04 --> Helper loaded: file_helper
INFO - 2016-02-24 11:54:04 --> Helper loaded: date_helper
INFO - 2016-02-24 11:54:04 --> Helper loaded: form_helper
INFO - 2016-02-24 11:54:04 --> Database Driver Class Initialized
INFO - 2016-02-24 11:54:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 11:54:05 --> Controller Class Initialized
INFO - 2016-02-24 11:54:05 --> Model Class Initialized
INFO - 2016-02-24 11:54:05 --> Model Class Initialized
INFO - 2016-02-24 11:54:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 11:54:05 --> Pagination Class Initialized
INFO - 2016-02-24 11:54:05 --> Helper loaded: text_helper
INFO - 2016-02-24 11:54:05 --> Helper loaded: cookie_helper
INFO - 2016-02-24 14:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 14:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 14:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 14:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 14:54:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 14:54:05 --> Final output sent to browser
DEBUG - 2016-02-24 14:54:05 --> Total execution time: 1.1859
INFO - 2016-02-24 12:07:48 --> Config Class Initialized
INFO - 2016-02-24 12:07:48 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:07:48 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:07:48 --> Utf8 Class Initialized
INFO - 2016-02-24 12:07:48 --> URI Class Initialized
INFO - 2016-02-24 12:07:48 --> Router Class Initialized
INFO - 2016-02-24 12:07:48 --> Output Class Initialized
INFO - 2016-02-24 12:07:48 --> Security Class Initialized
DEBUG - 2016-02-24 12:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:07:48 --> Input Class Initialized
INFO - 2016-02-24 12:07:48 --> Language Class Initialized
INFO - 2016-02-24 12:07:48 --> Loader Class Initialized
INFO - 2016-02-24 12:07:48 --> Helper loaded: url_helper
INFO - 2016-02-24 12:07:48 --> Helper loaded: file_helper
INFO - 2016-02-24 12:07:48 --> Helper loaded: date_helper
INFO - 2016-02-24 12:07:48 --> Helper loaded: form_helper
INFO - 2016-02-24 12:07:48 --> Database Driver Class Initialized
INFO - 2016-02-24 12:07:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:07:49 --> Controller Class Initialized
INFO - 2016-02-24 12:07:49 --> Model Class Initialized
INFO - 2016-02-24 12:07:49 --> Model Class Initialized
INFO - 2016-02-24 12:07:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:07:49 --> Pagination Class Initialized
INFO - 2016-02-24 12:07:49 --> Helper loaded: text_helper
INFO - 2016-02-24 12:07:49 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:07:50 --> Upload Class Initialized
INFO - 2016-02-24 15:07:50 --> Language file loaded: language/english/upload_lang.php
INFO - 2016-02-24 15:07:50 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2016-02-24 15:07:50 --> Final output sent to browser
DEBUG - 2016-02-24 15:07:50 --> Total execution time: 1.3165
INFO - 2016-02-24 12:08:15 --> Config Class Initialized
INFO - 2016-02-24 12:08:15 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:08:15 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:08:15 --> Utf8 Class Initialized
INFO - 2016-02-24 12:08:15 --> URI Class Initialized
INFO - 2016-02-24 12:08:15 --> Router Class Initialized
INFO - 2016-02-24 12:08:15 --> Output Class Initialized
INFO - 2016-02-24 12:08:15 --> Security Class Initialized
DEBUG - 2016-02-24 12:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:08:15 --> Input Class Initialized
INFO - 2016-02-24 12:08:15 --> Language Class Initialized
INFO - 2016-02-24 12:08:15 --> Loader Class Initialized
INFO - 2016-02-24 12:08:15 --> Helper loaded: url_helper
INFO - 2016-02-24 12:08:15 --> Helper loaded: file_helper
INFO - 2016-02-24 12:08:15 --> Helper loaded: date_helper
INFO - 2016-02-24 12:08:15 --> Helper loaded: form_helper
INFO - 2016-02-24 12:08:15 --> Database Driver Class Initialized
INFO - 2016-02-24 12:08:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:08:17 --> Controller Class Initialized
INFO - 2016-02-24 12:08:17 --> Model Class Initialized
INFO - 2016-02-24 12:08:17 --> Model Class Initialized
INFO - 2016-02-24 12:08:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:08:17 --> Pagination Class Initialized
INFO - 2016-02-24 12:08:17 --> Helper loaded: text_helper
INFO - 2016-02-24 12:08:17 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:08:17 --> Upload Class Initialized
INFO - 2016-02-24 15:08:17 --> Language file loaded: language/english/upload_lang.php
INFO - 2016-02-24 15:08:17 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2016-02-24 15:08:17 --> Final output sent to browser
DEBUG - 2016-02-24 15:08:17 --> Total execution time: 1.0987
INFO - 2016-02-24 12:09:08 --> Config Class Initialized
INFO - 2016-02-24 12:09:08 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:09:08 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:09:08 --> Utf8 Class Initialized
INFO - 2016-02-24 12:09:08 --> URI Class Initialized
INFO - 2016-02-24 12:09:08 --> Router Class Initialized
INFO - 2016-02-24 12:09:08 --> Output Class Initialized
INFO - 2016-02-24 12:09:08 --> Security Class Initialized
DEBUG - 2016-02-24 12:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:09:08 --> Input Class Initialized
INFO - 2016-02-24 12:09:08 --> Language Class Initialized
INFO - 2016-02-24 12:09:08 --> Loader Class Initialized
INFO - 2016-02-24 12:09:08 --> Helper loaded: url_helper
INFO - 2016-02-24 12:09:08 --> Helper loaded: file_helper
INFO - 2016-02-24 12:09:08 --> Helper loaded: date_helper
INFO - 2016-02-24 12:09:08 --> Helper loaded: form_helper
INFO - 2016-02-24 12:09:08 --> Database Driver Class Initialized
INFO - 2016-02-24 12:09:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:09:09 --> Controller Class Initialized
INFO - 2016-02-24 12:09:09 --> Model Class Initialized
INFO - 2016-02-24 12:09:09 --> Model Class Initialized
INFO - 2016-02-24 12:09:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:09:09 --> Pagination Class Initialized
INFO - 2016-02-24 12:09:09 --> Helper loaded: text_helper
INFO - 2016-02-24 12:09:09 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:09:09 --> Upload Class Initialized
INFO - 2016-02-24 15:09:09 --> Language file loaded: language/english/upload_lang.php
INFO - 2016-02-24 15:09:09 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2016-02-24 15:09:09 --> Final output sent to browser
DEBUG - 2016-02-24 15:09:09 --> Total execution time: 1.0984
INFO - 2016-02-24 12:09:55 --> Config Class Initialized
INFO - 2016-02-24 12:09:55 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:09:55 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:09:55 --> Utf8 Class Initialized
INFO - 2016-02-24 12:09:55 --> URI Class Initialized
INFO - 2016-02-24 12:09:55 --> Router Class Initialized
INFO - 2016-02-24 12:09:55 --> Output Class Initialized
INFO - 2016-02-24 12:09:55 --> Security Class Initialized
DEBUG - 2016-02-24 12:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:09:55 --> Input Class Initialized
INFO - 2016-02-24 12:09:55 --> Language Class Initialized
INFO - 2016-02-24 12:09:55 --> Loader Class Initialized
INFO - 2016-02-24 12:09:55 --> Helper loaded: url_helper
INFO - 2016-02-24 12:09:55 --> Helper loaded: file_helper
INFO - 2016-02-24 12:09:55 --> Helper loaded: date_helper
INFO - 2016-02-24 12:09:55 --> Helper loaded: form_helper
INFO - 2016-02-24 12:09:55 --> Database Driver Class Initialized
INFO - 2016-02-24 12:09:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:09:56 --> Controller Class Initialized
INFO - 2016-02-24 12:09:56 --> Model Class Initialized
INFO - 2016-02-24 12:09:56 --> Model Class Initialized
INFO - 2016-02-24 12:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:09:56 --> Pagination Class Initialized
INFO - 2016-02-24 12:09:56 --> Helper loaded: text_helper
INFO - 2016-02-24 12:09:56 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 15:09:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-02-24 15:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:09:56 --> Final output sent to browser
DEBUG - 2016-02-24 15:09:56 --> Total execution time: 1.2182
INFO - 2016-02-24 12:09:58 --> Config Class Initialized
INFO - 2016-02-24 12:09:58 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:09:58 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:09:58 --> Utf8 Class Initialized
INFO - 2016-02-24 12:09:58 --> URI Class Initialized
INFO - 2016-02-24 12:09:58 --> Router Class Initialized
INFO - 2016-02-24 12:09:58 --> Output Class Initialized
INFO - 2016-02-24 12:09:58 --> Security Class Initialized
DEBUG - 2016-02-24 12:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:09:58 --> Input Class Initialized
INFO - 2016-02-24 12:09:58 --> Language Class Initialized
INFO - 2016-02-24 12:09:58 --> Loader Class Initialized
INFO - 2016-02-24 12:09:58 --> Helper loaded: url_helper
INFO - 2016-02-24 12:09:58 --> Helper loaded: file_helper
INFO - 2016-02-24 12:09:58 --> Helper loaded: date_helper
INFO - 2016-02-24 12:09:58 --> Helper loaded: form_helper
INFO - 2016-02-24 12:09:58 --> Database Driver Class Initialized
INFO - 2016-02-24 12:10:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:10:00 --> Controller Class Initialized
INFO - 2016-02-24 12:10:00 --> Model Class Initialized
INFO - 2016-02-24 12:10:00 --> Model Class Initialized
INFO - 2016-02-24 12:10:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:10:00 --> Pagination Class Initialized
INFO - 2016-02-24 12:10:00 --> Helper loaded: text_helper
INFO - 2016-02-24 12:10:00 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:10:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:10:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:10:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-24 15:10:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 15:10:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:10:00 --> Final output sent to browser
DEBUG - 2016-02-24 15:10:00 --> Total execution time: 1.1507
INFO - 2016-02-24 12:10:27 --> Config Class Initialized
INFO - 2016-02-24 12:10:27 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:10:27 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:10:27 --> Utf8 Class Initialized
INFO - 2016-02-24 12:10:27 --> URI Class Initialized
INFO - 2016-02-24 12:10:27 --> Router Class Initialized
INFO - 2016-02-24 12:10:27 --> Output Class Initialized
INFO - 2016-02-24 12:10:27 --> Security Class Initialized
DEBUG - 2016-02-24 12:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:10:27 --> Input Class Initialized
INFO - 2016-02-24 12:10:27 --> Language Class Initialized
INFO - 2016-02-24 12:10:27 --> Loader Class Initialized
INFO - 2016-02-24 12:10:27 --> Helper loaded: url_helper
INFO - 2016-02-24 12:10:27 --> Helper loaded: file_helper
INFO - 2016-02-24 12:10:27 --> Helper loaded: date_helper
INFO - 2016-02-24 12:10:27 --> Helper loaded: form_helper
INFO - 2016-02-24 12:10:27 --> Database Driver Class Initialized
INFO - 2016-02-24 12:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:10:29 --> Controller Class Initialized
INFO - 2016-02-24 12:10:29 --> Model Class Initialized
INFO - 2016-02-24 12:10:29 --> Model Class Initialized
INFO - 2016-02-24 12:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:10:29 --> Pagination Class Initialized
INFO - 2016-02-24 12:10:29 --> Helper loaded: text_helper
INFO - 2016-02-24 12:10:29 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:10:29 --> Upload Class Initialized
INFO - 2016-02-24 15:10:29 --> Language file loaded: language/english/upload_lang.php
INFO - 2016-02-24 15:10:29 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2016-02-24 15:10:29 --> Final output sent to browser
DEBUG - 2016-02-24 15:10:29 --> Total execution time: 1.1384
INFO - 2016-02-24 12:10:42 --> Config Class Initialized
INFO - 2016-02-24 12:10:42 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:10:42 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:10:42 --> Utf8 Class Initialized
INFO - 2016-02-24 12:10:42 --> URI Class Initialized
INFO - 2016-02-24 12:10:42 --> Router Class Initialized
INFO - 2016-02-24 12:10:42 --> Output Class Initialized
INFO - 2016-02-24 12:10:42 --> Security Class Initialized
DEBUG - 2016-02-24 12:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:10:42 --> Input Class Initialized
INFO - 2016-02-24 12:10:42 --> Language Class Initialized
INFO - 2016-02-24 12:10:42 --> Loader Class Initialized
INFO - 2016-02-24 12:10:42 --> Helper loaded: url_helper
INFO - 2016-02-24 12:10:42 --> Helper loaded: file_helper
INFO - 2016-02-24 12:10:42 --> Helper loaded: date_helper
INFO - 2016-02-24 12:10:42 --> Helper loaded: form_helper
INFO - 2016-02-24 12:10:42 --> Database Driver Class Initialized
INFO - 2016-02-24 12:10:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:10:43 --> Controller Class Initialized
INFO - 2016-02-24 12:10:43 --> Model Class Initialized
INFO - 2016-02-24 12:10:43 --> Model Class Initialized
INFO - 2016-02-24 12:10:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:10:43 --> Pagination Class Initialized
INFO - 2016-02-24 12:10:43 --> Helper loaded: text_helper
INFO - 2016-02-24 12:10:43 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-24 15:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 15:10:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:10:43 --> Final output sent to browser
DEBUG - 2016-02-24 15:10:43 --> Total execution time: 1.1009
INFO - 2016-02-24 12:11:02 --> Config Class Initialized
INFO - 2016-02-24 12:11:02 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:11:02 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:11:02 --> Utf8 Class Initialized
INFO - 2016-02-24 12:11:02 --> URI Class Initialized
INFO - 2016-02-24 12:11:02 --> Router Class Initialized
INFO - 2016-02-24 12:11:02 --> Output Class Initialized
INFO - 2016-02-24 12:11:02 --> Security Class Initialized
DEBUG - 2016-02-24 12:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:11:02 --> Input Class Initialized
INFO - 2016-02-24 12:11:02 --> Language Class Initialized
INFO - 2016-02-24 12:11:02 --> Loader Class Initialized
INFO - 2016-02-24 12:11:02 --> Helper loaded: url_helper
INFO - 2016-02-24 12:11:02 --> Helper loaded: file_helper
INFO - 2016-02-24 12:11:02 --> Helper loaded: date_helper
INFO - 2016-02-24 12:11:02 --> Helper loaded: form_helper
INFO - 2016-02-24 12:11:02 --> Database Driver Class Initialized
INFO - 2016-02-24 12:11:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:11:03 --> Controller Class Initialized
INFO - 2016-02-24 12:11:03 --> Model Class Initialized
INFO - 2016-02-24 12:11:03 --> Model Class Initialized
INFO - 2016-02-24 12:11:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:11:03 --> Pagination Class Initialized
INFO - 2016-02-24 12:11:03 --> Helper loaded: text_helper
INFO - 2016-02-24 12:11:03 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:11:03 --> Upload Class Initialized
INFO - 2016-02-24 15:11:03 --> Language file loaded: language/english/upload_lang.php
INFO - 2016-02-24 15:11:03 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
INFO - 2016-02-24 15:11:03 --> Final output sent to browser
DEBUG - 2016-02-24 15:11:03 --> Total execution time: 1.1737
INFO - 2016-02-24 12:12:00 --> Config Class Initialized
INFO - 2016-02-24 12:12:00 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:12:00 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:12:00 --> Utf8 Class Initialized
INFO - 2016-02-24 12:12:00 --> URI Class Initialized
INFO - 2016-02-24 12:12:00 --> Router Class Initialized
INFO - 2016-02-24 12:12:00 --> Output Class Initialized
INFO - 2016-02-24 12:12:00 --> Security Class Initialized
DEBUG - 2016-02-24 12:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:12:00 --> Input Class Initialized
INFO - 2016-02-24 12:12:00 --> Language Class Initialized
INFO - 2016-02-24 12:12:00 --> Loader Class Initialized
INFO - 2016-02-24 12:12:00 --> Helper loaded: url_helper
INFO - 2016-02-24 12:12:00 --> Helper loaded: file_helper
INFO - 2016-02-24 12:12:00 --> Helper loaded: date_helper
INFO - 2016-02-24 12:12:00 --> Helper loaded: form_helper
INFO - 2016-02-24 12:12:00 --> Database Driver Class Initialized
INFO - 2016-02-24 12:12:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:12:01 --> Controller Class Initialized
INFO - 2016-02-24 12:12:01 --> Model Class Initialized
INFO - 2016-02-24 12:12:01 --> Model Class Initialized
INFO - 2016-02-24 12:12:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:12:01 --> Pagination Class Initialized
INFO - 2016-02-24 12:12:01 --> Helper loaded: text_helper
INFO - 2016-02-24 12:12:01 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:12:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:12:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:12:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-24 15:12:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 15:12:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:12:01 --> Final output sent to browser
DEBUG - 2016-02-24 15:12:01 --> Total execution time: 1.1064
INFO - 2016-02-24 12:12:20 --> Config Class Initialized
INFO - 2016-02-24 12:12:20 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:12:20 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:12:20 --> Utf8 Class Initialized
INFO - 2016-02-24 12:12:20 --> URI Class Initialized
INFO - 2016-02-24 12:12:20 --> Router Class Initialized
INFO - 2016-02-24 12:12:20 --> Output Class Initialized
INFO - 2016-02-24 12:12:20 --> Security Class Initialized
DEBUG - 2016-02-24 12:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:12:20 --> Input Class Initialized
INFO - 2016-02-24 12:12:20 --> Language Class Initialized
INFO - 2016-02-24 12:12:20 --> Loader Class Initialized
INFO - 2016-02-24 12:12:20 --> Helper loaded: url_helper
INFO - 2016-02-24 12:12:20 --> Helper loaded: file_helper
INFO - 2016-02-24 12:12:20 --> Helper loaded: date_helper
INFO - 2016-02-24 12:12:20 --> Helper loaded: form_helper
INFO - 2016-02-24 12:12:20 --> Database Driver Class Initialized
INFO - 2016-02-24 12:12:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:12:21 --> Controller Class Initialized
INFO - 2016-02-24 12:12:21 --> Model Class Initialized
INFO - 2016-02-24 12:12:21 --> Model Class Initialized
INFO - 2016-02-24 12:12:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:12:21 --> Pagination Class Initialized
INFO - 2016-02-24 12:12:21 --> Helper loaded: text_helper
INFO - 2016-02-24 12:12:21 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:12:21 --> Upload Class Initialized
INFO - 2016-02-24 15:12:21 --> Final output sent to browser
DEBUG - 2016-02-24 15:12:21 --> Total execution time: 1.1385
INFO - 2016-02-24 12:12:42 --> Config Class Initialized
INFO - 2016-02-24 12:12:42 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:12:42 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:12:42 --> Utf8 Class Initialized
INFO - 2016-02-24 12:12:42 --> URI Class Initialized
INFO - 2016-02-24 12:12:42 --> Router Class Initialized
INFO - 2016-02-24 12:12:42 --> Output Class Initialized
INFO - 2016-02-24 12:12:42 --> Security Class Initialized
DEBUG - 2016-02-24 12:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:12:42 --> Input Class Initialized
INFO - 2016-02-24 12:12:42 --> Language Class Initialized
INFO - 2016-02-24 12:12:42 --> Loader Class Initialized
INFO - 2016-02-24 12:12:42 --> Helper loaded: url_helper
INFO - 2016-02-24 12:12:42 --> Helper loaded: file_helper
INFO - 2016-02-24 12:12:42 --> Helper loaded: date_helper
INFO - 2016-02-24 12:12:42 --> Helper loaded: form_helper
INFO - 2016-02-24 12:12:42 --> Database Driver Class Initialized
INFO - 2016-02-24 12:12:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:12:43 --> Controller Class Initialized
INFO - 2016-02-24 12:12:43 --> Model Class Initialized
INFO - 2016-02-24 12:12:43 --> Model Class Initialized
INFO - 2016-02-24 12:12:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:12:43 --> Pagination Class Initialized
INFO - 2016-02-24 12:12:43 --> Helper loaded: text_helper
INFO - 2016-02-24 12:12:43 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:12:43 --> Upload Class Initialized
INFO - 2016-02-24 15:12:43 --> Final output sent to browser
DEBUG - 2016-02-24 15:12:43 --> Total execution time: 1.0899
INFO - 2016-02-24 12:13:21 --> Config Class Initialized
INFO - 2016-02-24 12:13:21 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:13:21 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:13:21 --> Utf8 Class Initialized
INFO - 2016-02-24 12:13:21 --> URI Class Initialized
INFO - 2016-02-24 12:13:21 --> Router Class Initialized
INFO - 2016-02-24 12:13:21 --> Output Class Initialized
INFO - 2016-02-24 12:13:21 --> Security Class Initialized
DEBUG - 2016-02-24 12:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:13:21 --> Input Class Initialized
INFO - 2016-02-24 12:13:21 --> Language Class Initialized
INFO - 2016-02-24 12:13:21 --> Loader Class Initialized
INFO - 2016-02-24 12:13:21 --> Helper loaded: url_helper
INFO - 2016-02-24 12:13:21 --> Helper loaded: file_helper
INFO - 2016-02-24 12:13:21 --> Helper loaded: date_helper
INFO - 2016-02-24 12:13:21 --> Helper loaded: form_helper
INFO - 2016-02-24 12:13:21 --> Database Driver Class Initialized
INFO - 2016-02-24 12:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:13:22 --> Controller Class Initialized
INFO - 2016-02-24 12:13:22 --> Model Class Initialized
INFO - 2016-02-24 12:13:22 --> Model Class Initialized
INFO - 2016-02-24 12:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:13:22 --> Pagination Class Initialized
INFO - 2016-02-24 12:13:22 --> Helper loaded: text_helper
INFO - 2016-02-24 12:13:22 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:13:22 --> Upload Class Initialized
INFO - 2016-02-24 15:13:22 --> Final output sent to browser
DEBUG - 2016-02-24 15:13:22 --> Total execution time: 1.1046
INFO - 2016-02-24 12:13:30 --> Config Class Initialized
INFO - 2016-02-24 12:13:30 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:13:30 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:13:30 --> Utf8 Class Initialized
INFO - 2016-02-24 12:13:30 --> URI Class Initialized
INFO - 2016-02-24 12:13:30 --> Router Class Initialized
INFO - 2016-02-24 12:13:30 --> Output Class Initialized
INFO - 2016-02-24 12:13:30 --> Security Class Initialized
DEBUG - 2016-02-24 12:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:13:30 --> Input Class Initialized
INFO - 2016-02-24 12:13:30 --> Language Class Initialized
INFO - 2016-02-24 12:13:30 --> Loader Class Initialized
INFO - 2016-02-24 12:13:30 --> Helper loaded: url_helper
INFO - 2016-02-24 12:13:30 --> Helper loaded: file_helper
INFO - 2016-02-24 12:13:30 --> Helper loaded: date_helper
INFO - 2016-02-24 12:13:30 --> Helper loaded: form_helper
INFO - 2016-02-24 12:13:30 --> Database Driver Class Initialized
INFO - 2016-02-24 12:13:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:13:31 --> Controller Class Initialized
INFO - 2016-02-24 12:13:31 --> Model Class Initialized
INFO - 2016-02-24 12:13:31 --> Model Class Initialized
INFO - 2016-02-24 12:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:13:31 --> Pagination Class Initialized
INFO - 2016-02-24 12:13:31 --> Helper loaded: text_helper
INFO - 2016-02-24 12:13:31 --> Helper loaded: cookie_helper
ERROR - 2016-02-24 15:13:31 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 161
INFO - 2016-02-24 15:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:13:31 --> Form Validation Class Initialized
INFO - 2016-02-24 15:13:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-24 12:13:31 --> Config Class Initialized
INFO - 2016-02-24 12:13:31 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:13:31 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:13:31 --> Utf8 Class Initialized
INFO - 2016-02-24 12:13:31 --> URI Class Initialized
INFO - 2016-02-24 12:13:31 --> Router Class Initialized
INFO - 2016-02-24 12:13:31 --> Output Class Initialized
INFO - 2016-02-24 12:13:31 --> Security Class Initialized
DEBUG - 2016-02-24 12:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:13:31 --> Input Class Initialized
INFO - 2016-02-24 12:13:31 --> Language Class Initialized
INFO - 2016-02-24 12:13:31 --> Loader Class Initialized
INFO - 2016-02-24 12:13:31 --> Helper loaded: url_helper
INFO - 2016-02-24 12:13:31 --> Helper loaded: file_helper
INFO - 2016-02-24 12:13:31 --> Helper loaded: date_helper
INFO - 2016-02-24 12:13:31 --> Helper loaded: form_helper
INFO - 2016-02-24 12:13:31 --> Database Driver Class Initialized
INFO - 2016-02-24 12:13:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:13:32 --> Controller Class Initialized
INFO - 2016-02-24 12:13:32 --> Model Class Initialized
INFO - 2016-02-24 12:13:32 --> Model Class Initialized
INFO - 2016-02-24 12:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:13:32 --> Pagination Class Initialized
INFO - 2016-02-24 12:13:32 --> Helper loaded: text_helper
INFO - 2016-02-24 12:13:32 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 15:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 15:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:13:32 --> Final output sent to browser
DEBUG - 2016-02-24 15:13:32 --> Total execution time: 1.2572
INFO - 2016-02-24 12:14:08 --> Config Class Initialized
INFO - 2016-02-24 12:14:08 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:14:08 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:14:08 --> Utf8 Class Initialized
INFO - 2016-02-24 12:14:08 --> URI Class Initialized
INFO - 2016-02-24 12:14:08 --> Router Class Initialized
INFO - 2016-02-24 12:14:08 --> Output Class Initialized
INFO - 2016-02-24 12:14:08 --> Security Class Initialized
DEBUG - 2016-02-24 12:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:14:08 --> Input Class Initialized
INFO - 2016-02-24 12:14:08 --> Language Class Initialized
INFO - 2016-02-24 12:14:08 --> Loader Class Initialized
INFO - 2016-02-24 12:14:08 --> Helper loaded: url_helper
INFO - 2016-02-24 12:14:08 --> Helper loaded: file_helper
INFO - 2016-02-24 12:14:08 --> Helper loaded: date_helper
INFO - 2016-02-24 12:14:08 --> Helper loaded: form_helper
INFO - 2016-02-24 12:14:08 --> Database Driver Class Initialized
INFO - 2016-02-24 12:14:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:14:09 --> Controller Class Initialized
INFO - 2016-02-24 12:14:09 --> Model Class Initialized
INFO - 2016-02-24 12:14:09 --> Model Class Initialized
INFO - 2016-02-24 12:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:14:09 --> Pagination Class Initialized
INFO - 2016-02-24 12:14:09 --> Helper loaded: text_helper
INFO - 2016-02-24 12:14:09 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:14:09 --> Final output sent to browser
DEBUG - 2016-02-24 15:14:09 --> Total execution time: 1.1582
INFO - 2016-02-24 12:18:05 --> Config Class Initialized
INFO - 2016-02-24 12:18:05 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:18:05 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:18:05 --> Utf8 Class Initialized
INFO - 2016-02-24 12:18:05 --> URI Class Initialized
INFO - 2016-02-24 12:18:05 --> Router Class Initialized
INFO - 2016-02-24 12:18:05 --> Output Class Initialized
INFO - 2016-02-24 12:18:05 --> Security Class Initialized
DEBUG - 2016-02-24 12:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:18:05 --> Input Class Initialized
INFO - 2016-02-24 12:18:05 --> Language Class Initialized
INFO - 2016-02-24 12:18:05 --> Loader Class Initialized
INFO - 2016-02-24 12:18:05 --> Helper loaded: url_helper
INFO - 2016-02-24 12:18:05 --> Helper loaded: file_helper
INFO - 2016-02-24 12:18:05 --> Helper loaded: date_helper
INFO - 2016-02-24 12:18:05 --> Helper loaded: form_helper
INFO - 2016-02-24 12:18:05 --> Database Driver Class Initialized
INFO - 2016-02-24 12:18:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:18:06 --> Controller Class Initialized
INFO - 2016-02-24 12:18:06 --> Model Class Initialized
INFO - 2016-02-24 12:18:07 --> Model Class Initialized
INFO - 2016-02-24 12:18:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:18:07 --> Pagination Class Initialized
INFO - 2016-02-24 12:18:07 --> Helper loaded: text_helper
INFO - 2016-02-24 12:18:07 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:18:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:18:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:18:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:18:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 15:18:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:18:07 --> Final output sent to browser
DEBUG - 2016-02-24 15:18:07 --> Total execution time: 1.1844
INFO - 2016-02-24 12:20:07 --> Config Class Initialized
INFO - 2016-02-24 12:20:07 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:20:07 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:20:07 --> Utf8 Class Initialized
INFO - 2016-02-24 12:20:07 --> URI Class Initialized
INFO - 2016-02-24 12:20:07 --> Router Class Initialized
INFO - 2016-02-24 12:20:07 --> Output Class Initialized
INFO - 2016-02-24 12:20:07 --> Security Class Initialized
DEBUG - 2016-02-24 12:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:20:07 --> Input Class Initialized
INFO - 2016-02-24 12:20:07 --> Language Class Initialized
INFO - 2016-02-24 12:20:07 --> Loader Class Initialized
INFO - 2016-02-24 12:20:07 --> Helper loaded: url_helper
INFO - 2016-02-24 12:20:07 --> Helper loaded: file_helper
INFO - 2016-02-24 12:20:07 --> Helper loaded: date_helper
INFO - 2016-02-24 12:20:07 --> Helper loaded: form_helper
INFO - 2016-02-24 12:20:07 --> Database Driver Class Initialized
INFO - 2016-02-24 12:20:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:20:08 --> Controller Class Initialized
INFO - 2016-02-24 12:20:08 --> Model Class Initialized
INFO - 2016-02-24 12:20:08 --> Model Class Initialized
INFO - 2016-02-24 12:20:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:20:08 --> Pagination Class Initialized
INFO - 2016-02-24 12:20:08 --> Helper loaded: text_helper
INFO - 2016-02-24 12:20:08 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:20:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:20:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:20:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:20:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 15:20:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:20:08 --> Final output sent to browser
DEBUG - 2016-02-24 15:20:08 --> Total execution time: 1.1782
INFO - 2016-02-24 12:20:08 --> Config Class Initialized
INFO - 2016-02-24 12:20:08 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:20:08 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:20:08 --> Utf8 Class Initialized
INFO - 2016-02-24 12:20:08 --> URI Class Initialized
INFO - 2016-02-24 12:20:08 --> Router Class Initialized
INFO - 2016-02-24 12:20:08 --> Output Class Initialized
INFO - 2016-02-24 12:20:08 --> Security Class Initialized
DEBUG - 2016-02-24 12:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:20:08 --> Input Class Initialized
INFO - 2016-02-24 12:20:08 --> Language Class Initialized
ERROR - 2016-02-24 12:20:08 --> 404 Page Not Found: Img/wtest.png
INFO - 2016-02-24 12:20:54 --> Config Class Initialized
INFO - 2016-02-24 12:20:54 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:20:54 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:20:54 --> Utf8 Class Initialized
INFO - 2016-02-24 12:20:54 --> URI Class Initialized
INFO - 2016-02-24 12:20:54 --> Router Class Initialized
INFO - 2016-02-24 12:20:54 --> Output Class Initialized
INFO - 2016-02-24 12:20:54 --> Security Class Initialized
DEBUG - 2016-02-24 12:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:20:54 --> Input Class Initialized
INFO - 2016-02-24 12:20:54 --> Language Class Initialized
INFO - 2016-02-24 12:20:54 --> Loader Class Initialized
INFO - 2016-02-24 12:20:54 --> Helper loaded: url_helper
INFO - 2016-02-24 12:20:54 --> Helper loaded: file_helper
INFO - 2016-02-24 12:20:54 --> Helper loaded: date_helper
INFO - 2016-02-24 12:20:54 --> Helper loaded: form_helper
INFO - 2016-02-24 12:20:54 --> Database Driver Class Initialized
INFO - 2016-02-24 12:20:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:20:55 --> Controller Class Initialized
INFO - 2016-02-24 12:20:55 --> Model Class Initialized
INFO - 2016-02-24 12:20:55 --> Model Class Initialized
INFO - 2016-02-24 12:20:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:20:55 --> Pagination Class Initialized
INFO - 2016-02-24 12:20:55 --> Helper loaded: text_helper
INFO - 2016-02-24 12:20:55 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 15:20:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:20:55 --> Final output sent to browser
DEBUG - 2016-02-24 15:20:55 --> Total execution time: 1.1953
INFO - 2016-02-24 12:21:57 --> Config Class Initialized
INFO - 2016-02-24 12:21:57 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:21:57 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:21:57 --> Utf8 Class Initialized
INFO - 2016-02-24 12:21:57 --> URI Class Initialized
INFO - 2016-02-24 12:21:57 --> Router Class Initialized
INFO - 2016-02-24 12:21:57 --> Output Class Initialized
INFO - 2016-02-24 12:21:57 --> Security Class Initialized
DEBUG - 2016-02-24 12:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:21:57 --> Input Class Initialized
INFO - 2016-02-24 12:21:57 --> Language Class Initialized
INFO - 2016-02-24 12:21:57 --> Loader Class Initialized
INFO - 2016-02-24 12:21:57 --> Helper loaded: url_helper
INFO - 2016-02-24 12:21:57 --> Helper loaded: file_helper
INFO - 2016-02-24 12:21:57 --> Helper loaded: date_helper
INFO - 2016-02-24 12:21:57 --> Helper loaded: form_helper
INFO - 2016-02-24 12:21:57 --> Database Driver Class Initialized
INFO - 2016-02-24 12:21:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:21:58 --> Controller Class Initialized
INFO - 2016-02-24 12:21:58 --> Model Class Initialized
INFO - 2016-02-24 12:21:58 --> Model Class Initialized
INFO - 2016-02-24 12:21:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:21:58 --> Pagination Class Initialized
INFO - 2016-02-24 12:21:58 --> Helper loaded: text_helper
INFO - 2016-02-24 12:21:58 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:21:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:21:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:21:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:21:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 15:21:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:21:58 --> Final output sent to browser
DEBUG - 2016-02-24 15:21:58 --> Total execution time: 1.1993
INFO - 2016-02-24 12:30:16 --> Config Class Initialized
INFO - 2016-02-24 12:30:16 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:30:16 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:30:16 --> Utf8 Class Initialized
INFO - 2016-02-24 12:30:16 --> URI Class Initialized
INFO - 2016-02-24 12:30:16 --> Router Class Initialized
INFO - 2016-02-24 12:30:16 --> Output Class Initialized
INFO - 2016-02-24 12:30:16 --> Security Class Initialized
DEBUG - 2016-02-24 12:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:30:16 --> Input Class Initialized
INFO - 2016-02-24 12:30:16 --> Language Class Initialized
INFO - 2016-02-24 12:30:16 --> Loader Class Initialized
INFO - 2016-02-24 12:30:16 --> Helper loaded: url_helper
INFO - 2016-02-24 12:30:16 --> Helper loaded: file_helper
INFO - 2016-02-24 12:30:16 --> Helper loaded: date_helper
INFO - 2016-02-24 12:30:16 --> Helper loaded: form_helper
INFO - 2016-02-24 12:30:16 --> Database Driver Class Initialized
INFO - 2016-02-24 12:30:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:30:17 --> Controller Class Initialized
INFO - 2016-02-24 12:30:17 --> Model Class Initialized
INFO - 2016-02-24 12:30:17 --> Model Class Initialized
INFO - 2016-02-24 12:30:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:30:17 --> Pagination Class Initialized
INFO - 2016-02-24 12:30:17 --> Helper loaded: text_helper
INFO - 2016-02-24 12:30:17 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 15:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:30:17 --> Final output sent to browser
DEBUG - 2016-02-24 15:30:17 --> Total execution time: 1.1296
INFO - 2016-02-24 12:35:50 --> Config Class Initialized
INFO - 2016-02-24 12:35:50 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:35:50 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:35:50 --> Utf8 Class Initialized
INFO - 2016-02-24 12:35:50 --> URI Class Initialized
DEBUG - 2016-02-24 12:35:50 --> No URI present. Default controller set.
INFO - 2016-02-24 12:35:50 --> Router Class Initialized
INFO - 2016-02-24 12:35:50 --> Output Class Initialized
INFO - 2016-02-24 12:35:50 --> Security Class Initialized
DEBUG - 2016-02-24 12:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:35:50 --> Input Class Initialized
INFO - 2016-02-24 12:35:50 --> Language Class Initialized
INFO - 2016-02-24 12:35:50 --> Loader Class Initialized
INFO - 2016-02-24 12:35:50 --> Helper loaded: url_helper
INFO - 2016-02-24 12:35:50 --> Helper loaded: file_helper
INFO - 2016-02-24 12:35:50 --> Helper loaded: date_helper
INFO - 2016-02-24 12:35:50 --> Helper loaded: form_helper
INFO - 2016-02-24 12:35:50 --> Database Driver Class Initialized
INFO - 2016-02-24 12:35:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:35:51 --> Controller Class Initialized
INFO - 2016-02-24 12:35:51 --> Model Class Initialized
INFO - 2016-02-24 12:35:51 --> Model Class Initialized
INFO - 2016-02-24 12:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:35:51 --> Pagination Class Initialized
INFO - 2016-02-24 12:35:51 --> Helper loaded: text_helper
INFO - 2016-02-24 12:35:51 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 15:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:35:51 --> Final output sent to browser
DEBUG - 2016-02-24 15:35:51 --> Total execution time: 1.1373
INFO - 2016-02-24 12:35:56 --> Config Class Initialized
INFO - 2016-02-24 12:35:56 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:35:56 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:35:56 --> Utf8 Class Initialized
INFO - 2016-02-24 12:35:56 --> URI Class Initialized
INFO - 2016-02-24 12:35:56 --> Router Class Initialized
INFO - 2016-02-24 12:35:56 --> Output Class Initialized
INFO - 2016-02-24 12:35:56 --> Security Class Initialized
DEBUG - 2016-02-24 12:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:35:56 --> Input Class Initialized
INFO - 2016-02-24 12:35:56 --> Language Class Initialized
INFO - 2016-02-24 12:35:56 --> Loader Class Initialized
INFO - 2016-02-24 12:35:56 --> Helper loaded: url_helper
INFO - 2016-02-24 12:35:56 --> Helper loaded: file_helper
INFO - 2016-02-24 12:35:56 --> Helper loaded: date_helper
INFO - 2016-02-24 12:35:56 --> Helper loaded: form_helper
INFO - 2016-02-24 12:35:56 --> Database Driver Class Initialized
INFO - 2016-02-24 12:35:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:35:57 --> Controller Class Initialized
INFO - 2016-02-24 12:35:57 --> Model Class Initialized
INFO - 2016-02-24 12:35:57 --> Model Class Initialized
INFO - 2016-02-24 12:35:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:35:57 --> Pagination Class Initialized
INFO - 2016-02-24 12:35:57 --> Helper loaded: text_helper
INFO - 2016-02-24 12:35:57 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:35:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:35:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:35:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:35:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 15:35:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:35:57 --> Final output sent to browser
DEBUG - 2016-02-24 15:35:57 --> Total execution time: 1.1398
INFO - 2016-02-24 12:36:00 --> Config Class Initialized
INFO - 2016-02-24 12:36:00 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:36:00 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:36:00 --> Utf8 Class Initialized
INFO - 2016-02-24 12:36:00 --> URI Class Initialized
INFO - 2016-02-24 12:36:00 --> Router Class Initialized
INFO - 2016-02-24 12:36:00 --> Output Class Initialized
INFO - 2016-02-24 12:36:00 --> Security Class Initialized
DEBUG - 2016-02-24 12:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:36:00 --> Input Class Initialized
INFO - 2016-02-24 12:36:00 --> Language Class Initialized
INFO - 2016-02-24 12:36:00 --> Loader Class Initialized
INFO - 2016-02-24 12:36:00 --> Helper loaded: url_helper
INFO - 2016-02-24 12:36:00 --> Helper loaded: file_helper
INFO - 2016-02-24 12:36:00 --> Helper loaded: date_helper
INFO - 2016-02-24 12:36:00 --> Helper loaded: form_helper
INFO - 2016-02-24 12:36:00 --> Database Driver Class Initialized
INFO - 2016-02-24 12:36:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:36:01 --> Controller Class Initialized
INFO - 2016-02-24 12:36:01 --> Model Class Initialized
INFO - 2016-02-24 12:36:01 --> Model Class Initialized
INFO - 2016-02-24 12:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:36:01 --> Pagination Class Initialized
INFO - 2016-02-24 12:36:01 --> Helper loaded: text_helper
INFO - 2016-02-24 12:36:01 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:36:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:36:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:36:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:36:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 15:36:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:36:01 --> Final output sent to browser
DEBUG - 2016-02-24 15:36:01 --> Total execution time: 1.1568
INFO - 2016-02-24 12:36:34 --> Config Class Initialized
INFO - 2016-02-24 12:36:34 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:36:34 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:36:34 --> Utf8 Class Initialized
INFO - 2016-02-24 12:36:34 --> URI Class Initialized
INFO - 2016-02-24 12:36:34 --> Router Class Initialized
INFO - 2016-02-24 12:36:34 --> Output Class Initialized
INFO - 2016-02-24 12:36:34 --> Security Class Initialized
DEBUG - 2016-02-24 12:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:36:34 --> Input Class Initialized
INFO - 2016-02-24 12:36:34 --> Language Class Initialized
INFO - 2016-02-24 12:36:34 --> Loader Class Initialized
INFO - 2016-02-24 12:36:34 --> Helper loaded: url_helper
INFO - 2016-02-24 12:36:34 --> Helper loaded: file_helper
INFO - 2016-02-24 12:36:34 --> Helper loaded: date_helper
INFO - 2016-02-24 12:36:34 --> Helper loaded: form_helper
INFO - 2016-02-24 12:36:34 --> Database Driver Class Initialized
INFO - 2016-02-24 12:36:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:36:35 --> Controller Class Initialized
INFO - 2016-02-24 12:36:35 --> Model Class Initialized
INFO - 2016-02-24 12:36:35 --> Model Class Initialized
INFO - 2016-02-24 12:36:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:36:35 --> Pagination Class Initialized
INFO - 2016-02-24 12:36:35 --> Helper loaded: text_helper
INFO - 2016-02-24 12:36:35 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 15:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 15:36:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:36:35 --> Final output sent to browser
DEBUG - 2016-02-24 15:36:35 --> Total execution time: 1.1704
INFO - 2016-02-24 12:36:48 --> Config Class Initialized
INFO - 2016-02-24 12:36:48 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:36:48 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:36:48 --> Utf8 Class Initialized
INFO - 2016-02-24 12:36:48 --> URI Class Initialized
INFO - 2016-02-24 12:36:48 --> Router Class Initialized
INFO - 2016-02-24 12:36:48 --> Output Class Initialized
INFO - 2016-02-24 12:36:48 --> Security Class Initialized
DEBUG - 2016-02-24 12:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:36:48 --> Input Class Initialized
INFO - 2016-02-24 12:36:48 --> Language Class Initialized
INFO - 2016-02-24 12:36:48 --> Loader Class Initialized
INFO - 2016-02-24 12:36:48 --> Helper loaded: url_helper
INFO - 2016-02-24 12:36:48 --> Helper loaded: file_helper
INFO - 2016-02-24 12:36:48 --> Helper loaded: date_helper
INFO - 2016-02-24 12:36:48 --> Helper loaded: form_helper
INFO - 2016-02-24 12:36:48 --> Database Driver Class Initialized
INFO - 2016-02-24 12:36:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:36:49 --> Controller Class Initialized
INFO - 2016-02-24 12:36:49 --> Model Class Initialized
INFO - 2016-02-24 12:36:49 --> Model Class Initialized
INFO - 2016-02-24 12:36:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:36:49 --> Pagination Class Initialized
INFO - 2016-02-24 12:36:49 --> Helper loaded: text_helper
INFO - 2016-02-24 12:36:49 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:36:49 --> Final output sent to browser
DEBUG - 2016-02-24 15:36:49 --> Total execution time: 1.1378
INFO - 2016-02-24 12:36:50 --> Config Class Initialized
INFO - 2016-02-24 12:36:50 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:36:50 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:36:50 --> Utf8 Class Initialized
INFO - 2016-02-24 12:36:50 --> URI Class Initialized
DEBUG - 2016-02-24 12:36:50 --> No URI present. Default controller set.
INFO - 2016-02-24 12:36:50 --> Router Class Initialized
INFO - 2016-02-24 12:36:50 --> Output Class Initialized
INFO - 2016-02-24 12:36:50 --> Security Class Initialized
DEBUG - 2016-02-24 12:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:36:50 --> Input Class Initialized
INFO - 2016-02-24 12:36:50 --> Language Class Initialized
INFO - 2016-02-24 12:36:50 --> Loader Class Initialized
INFO - 2016-02-24 12:36:50 --> Helper loaded: url_helper
INFO - 2016-02-24 12:36:50 --> Helper loaded: file_helper
INFO - 2016-02-24 12:36:50 --> Helper loaded: date_helper
INFO - 2016-02-24 12:36:50 --> Helper loaded: form_helper
INFO - 2016-02-24 12:36:50 --> Database Driver Class Initialized
INFO - 2016-02-24 12:36:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:36:51 --> Controller Class Initialized
INFO - 2016-02-24 12:36:51 --> Model Class Initialized
INFO - 2016-02-24 12:36:51 --> Model Class Initialized
INFO - 2016-02-24 12:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:36:51 --> Pagination Class Initialized
INFO - 2016-02-24 12:36:51 --> Helper loaded: text_helper
INFO - 2016-02-24 12:36:51 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 15:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:36:51 --> Final output sent to browser
DEBUG - 2016-02-24 15:36:51 --> Total execution time: 1.1484
INFO - 2016-02-24 12:48:53 --> Config Class Initialized
INFO - 2016-02-24 12:48:53 --> Hooks Class Initialized
DEBUG - 2016-02-24 12:48:53 --> UTF-8 Support Enabled
INFO - 2016-02-24 12:48:53 --> Utf8 Class Initialized
INFO - 2016-02-24 12:48:53 --> URI Class Initialized
INFO - 2016-02-24 12:48:53 --> Router Class Initialized
INFO - 2016-02-24 12:48:53 --> Output Class Initialized
INFO - 2016-02-24 12:48:53 --> Security Class Initialized
DEBUG - 2016-02-24 12:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 12:48:53 --> Input Class Initialized
INFO - 2016-02-24 12:48:53 --> Language Class Initialized
INFO - 2016-02-24 12:48:53 --> Loader Class Initialized
INFO - 2016-02-24 12:48:53 --> Helper loaded: url_helper
INFO - 2016-02-24 12:48:53 --> Helper loaded: file_helper
INFO - 2016-02-24 12:48:53 --> Helper loaded: date_helper
INFO - 2016-02-24 12:48:53 --> Helper loaded: form_helper
INFO - 2016-02-24 12:48:53 --> Database Driver Class Initialized
INFO - 2016-02-24 12:48:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 12:48:54 --> Controller Class Initialized
INFO - 2016-02-24 12:48:54 --> Model Class Initialized
INFO - 2016-02-24 12:48:54 --> Model Class Initialized
INFO - 2016-02-24 12:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 12:48:54 --> Pagination Class Initialized
INFO - 2016-02-24 12:48:54 --> Helper loaded: text_helper
INFO - 2016-02-24 12:48:54 --> Helper loaded: cookie_helper
INFO - 2016-02-24 15:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 15:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 15:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 15:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 15:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 15:48:54 --> Final output sent to browser
DEBUG - 2016-02-24 15:48:54 --> Total execution time: 1.1306
INFO - 2016-02-24 14:11:41 --> Config Class Initialized
INFO - 2016-02-24 14:11:42 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:11:42 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:11:42 --> Utf8 Class Initialized
INFO - 2016-02-24 14:11:42 --> URI Class Initialized
INFO - 2016-02-24 14:11:42 --> Router Class Initialized
INFO - 2016-02-24 14:11:42 --> Output Class Initialized
INFO - 2016-02-24 14:11:42 --> Security Class Initialized
DEBUG - 2016-02-24 14:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:11:42 --> Input Class Initialized
INFO - 2016-02-24 14:11:42 --> Language Class Initialized
INFO - 2016-02-24 14:11:42 --> Loader Class Initialized
INFO - 2016-02-24 14:11:42 --> Helper loaded: url_helper
INFO - 2016-02-24 14:11:42 --> Helper loaded: file_helper
INFO - 2016-02-24 14:11:42 --> Helper loaded: date_helper
INFO - 2016-02-24 14:11:42 --> Helper loaded: form_helper
INFO - 2016-02-24 14:11:42 --> Database Driver Class Initialized
INFO - 2016-02-24 14:11:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:11:43 --> Controller Class Initialized
INFO - 2016-02-24 14:11:43 --> Model Class Initialized
INFO - 2016-02-24 14:11:43 --> Model Class Initialized
INFO - 2016-02-24 14:11:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:11:43 --> Pagination Class Initialized
INFO - 2016-02-24 14:11:43 --> Helper loaded: text_helper
INFO - 2016-02-24 14:11:43 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:11:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:11:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:11:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:11:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:11:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:11:43 --> Final output sent to browser
DEBUG - 2016-02-24 17:11:43 --> Total execution time: 1.3333
INFO - 2016-02-24 14:18:55 --> Config Class Initialized
INFO - 2016-02-24 14:18:55 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:18:55 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:18:55 --> Utf8 Class Initialized
INFO - 2016-02-24 14:18:55 --> URI Class Initialized
INFO - 2016-02-24 14:18:55 --> Router Class Initialized
INFO - 2016-02-24 14:18:55 --> Output Class Initialized
INFO - 2016-02-24 14:18:55 --> Security Class Initialized
DEBUG - 2016-02-24 14:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:18:55 --> Input Class Initialized
INFO - 2016-02-24 14:18:55 --> Language Class Initialized
INFO - 2016-02-24 14:18:55 --> Loader Class Initialized
INFO - 2016-02-24 14:18:55 --> Helper loaded: url_helper
INFO - 2016-02-24 14:18:55 --> Helper loaded: file_helper
INFO - 2016-02-24 14:18:55 --> Helper loaded: date_helper
INFO - 2016-02-24 14:18:55 --> Helper loaded: form_helper
INFO - 2016-02-24 14:18:55 --> Database Driver Class Initialized
INFO - 2016-02-24 14:18:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:18:56 --> Controller Class Initialized
INFO - 2016-02-24 14:18:56 --> Model Class Initialized
INFO - 2016-02-24 14:18:56 --> Model Class Initialized
INFO - 2016-02-24 14:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:18:56 --> Pagination Class Initialized
INFO - 2016-02-24 14:18:56 --> Helper loaded: text_helper
INFO - 2016-02-24 14:18:56 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:18:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:18:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:18:57 --> Final output sent to browser
DEBUG - 2016-02-24 17:18:57 --> Total execution time: 1.1711
INFO - 2016-02-24 14:24:48 --> Config Class Initialized
INFO - 2016-02-24 14:24:48 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:24:48 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:24:48 --> Utf8 Class Initialized
INFO - 2016-02-24 14:24:48 --> URI Class Initialized
DEBUG - 2016-02-24 14:24:48 --> No URI present. Default controller set.
INFO - 2016-02-24 14:24:48 --> Router Class Initialized
INFO - 2016-02-24 14:24:48 --> Output Class Initialized
INFO - 2016-02-24 14:24:48 --> Security Class Initialized
DEBUG - 2016-02-24 14:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:24:48 --> Input Class Initialized
INFO - 2016-02-24 14:24:48 --> Language Class Initialized
INFO - 2016-02-24 14:24:48 --> Loader Class Initialized
INFO - 2016-02-24 14:24:48 --> Helper loaded: url_helper
INFO - 2016-02-24 14:24:48 --> Helper loaded: file_helper
INFO - 2016-02-24 14:24:48 --> Helper loaded: date_helper
INFO - 2016-02-24 14:24:48 --> Helper loaded: form_helper
INFO - 2016-02-24 14:24:48 --> Database Driver Class Initialized
INFO - 2016-02-24 14:24:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:24:49 --> Controller Class Initialized
INFO - 2016-02-24 14:24:49 --> Model Class Initialized
INFO - 2016-02-24 14:24:49 --> Model Class Initialized
INFO - 2016-02-24 14:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:24:49 --> Pagination Class Initialized
INFO - 2016-02-24 14:24:49 --> Helper loaded: text_helper
INFO - 2016-02-24 14:24:49 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 17:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:24:49 --> Final output sent to browser
DEBUG - 2016-02-24 17:24:49 --> Total execution time: 1.1714
INFO - 2016-02-24 14:24:51 --> Config Class Initialized
INFO - 2016-02-24 14:24:51 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:24:51 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:24:51 --> Utf8 Class Initialized
INFO - 2016-02-24 14:24:51 --> URI Class Initialized
INFO - 2016-02-24 14:24:51 --> Router Class Initialized
INFO - 2016-02-24 14:24:51 --> Output Class Initialized
INFO - 2016-02-24 14:24:51 --> Security Class Initialized
DEBUG - 2016-02-24 14:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:24:51 --> Input Class Initialized
INFO - 2016-02-24 14:24:51 --> Language Class Initialized
INFO - 2016-02-24 14:24:51 --> Loader Class Initialized
INFO - 2016-02-24 14:24:51 --> Helper loaded: url_helper
INFO - 2016-02-24 14:24:51 --> Helper loaded: file_helper
INFO - 2016-02-24 14:24:51 --> Helper loaded: date_helper
INFO - 2016-02-24 14:24:51 --> Helper loaded: form_helper
INFO - 2016-02-24 14:24:51 --> Database Driver Class Initialized
INFO - 2016-02-24 14:24:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:24:52 --> Controller Class Initialized
INFO - 2016-02-24 14:24:52 --> Model Class Initialized
INFO - 2016-02-24 14:24:52 --> Model Class Initialized
INFO - 2016-02-24 14:24:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:24:52 --> Pagination Class Initialized
INFO - 2016-02-24 14:24:52 --> Helper loaded: text_helper
INFO - 2016-02-24 14:24:52 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:24:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:24:52 --> Final output sent to browser
DEBUG - 2016-02-24 17:24:52 --> Total execution time: 1.1565
INFO - 2016-02-24 14:24:54 --> Config Class Initialized
INFO - 2016-02-24 14:24:54 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:24:54 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:24:54 --> Utf8 Class Initialized
INFO - 2016-02-24 14:24:54 --> URI Class Initialized
INFO - 2016-02-24 14:24:54 --> Router Class Initialized
INFO - 2016-02-24 14:24:54 --> Output Class Initialized
INFO - 2016-02-24 14:24:54 --> Security Class Initialized
DEBUG - 2016-02-24 14:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:24:54 --> Input Class Initialized
INFO - 2016-02-24 14:24:54 --> Language Class Initialized
INFO - 2016-02-24 14:24:54 --> Loader Class Initialized
INFO - 2016-02-24 14:24:54 --> Helper loaded: url_helper
INFO - 2016-02-24 14:24:54 --> Helper loaded: file_helper
INFO - 2016-02-24 14:24:54 --> Helper loaded: date_helper
INFO - 2016-02-24 14:24:54 --> Helper loaded: form_helper
INFO - 2016-02-24 14:24:54 --> Database Driver Class Initialized
INFO - 2016-02-24 14:24:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:24:55 --> Controller Class Initialized
INFO - 2016-02-24 14:24:55 --> Model Class Initialized
INFO - 2016-02-24 14:24:55 --> Model Class Initialized
INFO - 2016-02-24 14:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:24:55 --> Pagination Class Initialized
INFO - 2016-02-24 14:24:55 --> Helper loaded: text_helper
INFO - 2016-02-24 14:24:55 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:24:55 --> Final output sent to browser
DEBUG - 2016-02-24 17:24:55 --> Total execution time: 1.1555
INFO - 2016-02-24 14:25:03 --> Config Class Initialized
INFO - 2016-02-24 14:25:03 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:03 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:03 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:03 --> URI Class Initialized
INFO - 2016-02-24 14:25:03 --> Router Class Initialized
INFO - 2016-02-24 14:25:03 --> Output Class Initialized
INFO - 2016-02-24 14:25:03 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:03 --> Input Class Initialized
INFO - 2016-02-24 14:25:03 --> Language Class Initialized
INFO - 2016-02-24 14:25:03 --> Loader Class Initialized
INFO - 2016-02-24 14:25:03 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:03 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:03 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:03 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:03 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:04 --> Controller Class Initialized
INFO - 2016-02-24 14:25:04 --> Model Class Initialized
INFO - 2016-02-24 14:25:04 --> Model Class Initialized
INFO - 2016-02-24 14:25:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:04 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:04 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:04 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:25:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:04 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:04 --> Total execution time: 1.1070
INFO - 2016-02-24 14:25:07 --> Config Class Initialized
INFO - 2016-02-24 14:25:07 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:07 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:07 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:07 --> URI Class Initialized
INFO - 2016-02-24 14:25:07 --> Router Class Initialized
INFO - 2016-02-24 14:25:07 --> Output Class Initialized
INFO - 2016-02-24 14:25:07 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:07 --> Input Class Initialized
INFO - 2016-02-24 14:25:07 --> Language Class Initialized
INFO - 2016-02-24 14:25:07 --> Loader Class Initialized
INFO - 2016-02-24 14:25:07 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:07 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:07 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:07 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:07 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:08 --> Controller Class Initialized
INFO - 2016-02-24 14:25:08 --> Model Class Initialized
INFO - 2016-02-24 14:25:08 --> Model Class Initialized
INFO - 2016-02-24 14:25:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:08 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:08 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:08 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:25:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:25:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:08 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:08 --> Total execution time: 1.2175
INFO - 2016-02-24 14:25:12 --> Config Class Initialized
INFO - 2016-02-24 14:25:12 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:12 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:12 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:12 --> URI Class Initialized
INFO - 2016-02-24 14:25:12 --> Router Class Initialized
INFO - 2016-02-24 14:25:12 --> Output Class Initialized
INFO - 2016-02-24 14:25:12 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:12 --> Input Class Initialized
INFO - 2016-02-24 14:25:12 --> Language Class Initialized
INFO - 2016-02-24 14:25:12 --> Loader Class Initialized
INFO - 2016-02-24 14:25:12 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:12 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:12 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:12 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:12 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:13 --> Controller Class Initialized
INFO - 2016-02-24 14:25:13 --> Model Class Initialized
INFO - 2016-02-24 14:25:13 --> Model Class Initialized
INFO - 2016-02-24 14:25:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:13 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:13 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:13 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:25:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:25:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:13 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:13 --> Total execution time: 1.1912
INFO - 2016-02-24 14:25:25 --> Config Class Initialized
INFO - 2016-02-24 14:25:25 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:25 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:25 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:25 --> URI Class Initialized
DEBUG - 2016-02-24 14:25:25 --> No URI present. Default controller set.
INFO - 2016-02-24 14:25:25 --> Router Class Initialized
INFO - 2016-02-24 14:25:25 --> Output Class Initialized
INFO - 2016-02-24 14:25:25 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:25 --> Input Class Initialized
INFO - 2016-02-24 14:25:25 --> Language Class Initialized
INFO - 2016-02-24 14:25:25 --> Loader Class Initialized
INFO - 2016-02-24 14:25:25 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:25 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:25 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:25 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:25 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:26 --> Controller Class Initialized
INFO - 2016-02-24 14:25:26 --> Model Class Initialized
INFO - 2016-02-24 14:25:26 --> Model Class Initialized
INFO - 2016-02-24 14:25:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:26 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:26 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:26 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 17:25:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:26 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:26 --> Total execution time: 1.1593
INFO - 2016-02-24 14:25:28 --> Config Class Initialized
INFO - 2016-02-24 14:25:28 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:28 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:28 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:28 --> URI Class Initialized
INFO - 2016-02-24 14:25:28 --> Router Class Initialized
INFO - 2016-02-24 14:25:28 --> Output Class Initialized
INFO - 2016-02-24 14:25:28 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:28 --> Input Class Initialized
INFO - 2016-02-24 14:25:28 --> Language Class Initialized
INFO - 2016-02-24 14:25:28 --> Loader Class Initialized
INFO - 2016-02-24 14:25:28 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:28 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:28 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:28 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:28 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:29 --> Controller Class Initialized
INFO - 2016-02-24 14:25:29 --> Model Class Initialized
INFO - 2016-02-24 14:25:29 --> Model Class Initialized
INFO - 2016-02-24 14:25:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:29 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:29 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:29 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:29 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:29 --> Total execution time: 1.1306
INFO - 2016-02-24 14:25:31 --> Config Class Initialized
INFO - 2016-02-24 14:25:31 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:31 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:31 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:31 --> URI Class Initialized
INFO - 2016-02-24 14:25:31 --> Router Class Initialized
INFO - 2016-02-24 14:25:31 --> Output Class Initialized
INFO - 2016-02-24 14:25:31 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:31 --> Input Class Initialized
INFO - 2016-02-24 14:25:31 --> Language Class Initialized
INFO - 2016-02-24 14:25:31 --> Loader Class Initialized
INFO - 2016-02-24 14:25:31 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:31 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:31 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:31 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:31 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:32 --> Controller Class Initialized
INFO - 2016-02-24 14:25:32 --> Model Class Initialized
INFO - 2016-02-24 14:25:32 --> Model Class Initialized
INFO - 2016-02-24 14:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:32 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:32 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:32 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:32 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:32 --> Total execution time: 1.1538
INFO - 2016-02-24 14:25:40 --> Config Class Initialized
INFO - 2016-02-24 14:25:40 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:40 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:40 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:40 --> URI Class Initialized
INFO - 2016-02-24 14:25:40 --> Router Class Initialized
INFO - 2016-02-24 14:25:40 --> Output Class Initialized
INFO - 2016-02-24 14:25:40 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:40 --> Input Class Initialized
INFO - 2016-02-24 14:25:40 --> Language Class Initialized
INFO - 2016-02-24 14:25:40 --> Loader Class Initialized
INFO - 2016-02-24 14:25:40 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:40 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:40 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:40 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:40 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:41 --> Controller Class Initialized
INFO - 2016-02-24 14:25:41 --> Model Class Initialized
INFO - 2016-02-24 14:25:41 --> Model Class Initialized
INFO - 2016-02-24 14:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:41 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:41 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:41 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:41 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:41 --> Total execution time: 1.1819
INFO - 2016-02-24 14:25:43 --> Config Class Initialized
INFO - 2016-02-24 14:25:43 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:43 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:43 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:43 --> URI Class Initialized
INFO - 2016-02-24 14:25:43 --> Router Class Initialized
INFO - 2016-02-24 14:25:43 --> Output Class Initialized
INFO - 2016-02-24 14:25:43 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:43 --> Input Class Initialized
INFO - 2016-02-24 14:25:43 --> Language Class Initialized
INFO - 2016-02-24 14:25:43 --> Loader Class Initialized
INFO - 2016-02-24 14:25:43 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:43 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:43 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:43 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:43 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:44 --> Controller Class Initialized
INFO - 2016-02-24 14:25:44 --> Model Class Initialized
INFO - 2016-02-24 14:25:44 --> Model Class Initialized
INFO - 2016-02-24 14:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:44 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:44 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:44 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:44 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:44 --> Total execution time: 1.1430
INFO - 2016-02-24 14:25:45 --> Config Class Initialized
INFO - 2016-02-24 14:25:45 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:25:45 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:25:45 --> Utf8 Class Initialized
INFO - 2016-02-24 14:25:45 --> URI Class Initialized
INFO - 2016-02-24 14:25:45 --> Router Class Initialized
INFO - 2016-02-24 14:25:45 --> Output Class Initialized
INFO - 2016-02-24 14:25:45 --> Security Class Initialized
DEBUG - 2016-02-24 14:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:25:45 --> Input Class Initialized
INFO - 2016-02-24 14:25:45 --> Language Class Initialized
INFO - 2016-02-24 14:25:45 --> Loader Class Initialized
INFO - 2016-02-24 14:25:45 --> Helper loaded: url_helper
INFO - 2016-02-24 14:25:45 --> Helper loaded: file_helper
INFO - 2016-02-24 14:25:45 --> Helper loaded: date_helper
INFO - 2016-02-24 14:25:45 --> Helper loaded: form_helper
INFO - 2016-02-24 14:25:45 --> Database Driver Class Initialized
INFO - 2016-02-24 14:25:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:25:46 --> Controller Class Initialized
INFO - 2016-02-24 14:25:46 --> Model Class Initialized
INFO - 2016-02-24 14:25:46 --> Model Class Initialized
INFO - 2016-02-24 14:25:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:25:46 --> Pagination Class Initialized
INFO - 2016-02-24 14:25:46 --> Helper loaded: text_helper
INFO - 2016-02-24 14:25:46 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:25:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:25:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:25:47 --> Final output sent to browser
DEBUG - 2016-02-24 17:25:47 --> Total execution time: 1.2260
INFO - 2016-02-24 14:27:33 --> Config Class Initialized
INFO - 2016-02-24 14:27:33 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:27:33 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:27:33 --> Utf8 Class Initialized
INFO - 2016-02-24 14:27:33 --> URI Class Initialized
INFO - 2016-02-24 14:27:33 --> Router Class Initialized
INFO - 2016-02-24 14:27:33 --> Output Class Initialized
INFO - 2016-02-24 14:27:33 --> Security Class Initialized
DEBUG - 2016-02-24 14:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:27:33 --> Input Class Initialized
INFO - 2016-02-24 14:27:33 --> Language Class Initialized
INFO - 2016-02-24 14:27:33 --> Loader Class Initialized
INFO - 2016-02-24 14:27:33 --> Helper loaded: url_helper
INFO - 2016-02-24 14:27:33 --> Helper loaded: file_helper
INFO - 2016-02-24 14:27:33 --> Helper loaded: date_helper
INFO - 2016-02-24 14:27:33 --> Helper loaded: form_helper
INFO - 2016-02-24 14:27:33 --> Database Driver Class Initialized
INFO - 2016-02-24 14:27:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:27:34 --> Controller Class Initialized
INFO - 2016-02-24 14:27:34 --> Model Class Initialized
INFO - 2016-02-24 14:27:34 --> Model Class Initialized
INFO - 2016-02-24 14:27:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:27:34 --> Pagination Class Initialized
INFO - 2016-02-24 14:27:34 --> Helper loaded: text_helper
INFO - 2016-02-24 14:27:34 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:27:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:27:34 --> Final output sent to browser
DEBUG - 2016-02-24 17:27:34 --> Total execution time: 1.1412
INFO - 2016-02-24 14:27:36 --> Config Class Initialized
INFO - 2016-02-24 14:27:36 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:27:36 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:27:36 --> Utf8 Class Initialized
INFO - 2016-02-24 14:27:36 --> URI Class Initialized
INFO - 2016-02-24 14:27:36 --> Router Class Initialized
INFO - 2016-02-24 14:27:36 --> Output Class Initialized
INFO - 2016-02-24 14:27:36 --> Security Class Initialized
DEBUG - 2016-02-24 14:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:27:36 --> Input Class Initialized
INFO - 2016-02-24 14:27:36 --> Language Class Initialized
INFO - 2016-02-24 14:27:36 --> Loader Class Initialized
INFO - 2016-02-24 14:27:36 --> Helper loaded: url_helper
INFO - 2016-02-24 14:27:36 --> Helper loaded: file_helper
INFO - 2016-02-24 14:27:36 --> Helper loaded: date_helper
INFO - 2016-02-24 14:27:36 --> Helper loaded: form_helper
INFO - 2016-02-24 14:27:36 --> Database Driver Class Initialized
INFO - 2016-02-24 14:27:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:27:37 --> Controller Class Initialized
INFO - 2016-02-24 14:27:37 --> Model Class Initialized
INFO - 2016-02-24 14:27:37 --> Model Class Initialized
INFO - 2016-02-24 14:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:27:37 --> Pagination Class Initialized
INFO - 2016-02-24 14:27:37 --> Helper loaded: text_helper
INFO - 2016-02-24 14:27:37 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:27:37 --> Final output sent to browser
DEBUG - 2016-02-24 17:27:37 --> Total execution time: 1.1985
INFO - 2016-02-24 14:30:00 --> Config Class Initialized
INFO - 2016-02-24 14:30:00 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:30:00 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:30:00 --> Utf8 Class Initialized
INFO - 2016-02-24 14:30:00 --> URI Class Initialized
DEBUG - 2016-02-24 14:30:00 --> No URI present. Default controller set.
INFO - 2016-02-24 14:30:00 --> Router Class Initialized
INFO - 2016-02-24 14:30:00 --> Output Class Initialized
INFO - 2016-02-24 14:30:00 --> Security Class Initialized
DEBUG - 2016-02-24 14:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:30:00 --> Input Class Initialized
INFO - 2016-02-24 14:30:00 --> Language Class Initialized
INFO - 2016-02-24 14:30:00 --> Loader Class Initialized
INFO - 2016-02-24 14:30:00 --> Helper loaded: url_helper
INFO - 2016-02-24 14:30:00 --> Helper loaded: file_helper
INFO - 2016-02-24 14:30:00 --> Helper loaded: date_helper
INFO - 2016-02-24 14:30:00 --> Helper loaded: form_helper
INFO - 2016-02-24 14:30:00 --> Database Driver Class Initialized
INFO - 2016-02-24 14:30:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:30:01 --> Controller Class Initialized
INFO - 2016-02-24 14:30:01 --> Model Class Initialized
INFO - 2016-02-24 14:30:01 --> Model Class Initialized
INFO - 2016-02-24 14:30:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:30:01 --> Pagination Class Initialized
INFO - 2016-02-24 14:30:01 --> Helper loaded: text_helper
INFO - 2016-02-24 14:30:01 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:30:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:30:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:30:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 17:30:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:30:01 --> Final output sent to browser
DEBUG - 2016-02-24 17:30:01 --> Total execution time: 1.1265
INFO - 2016-02-24 14:30:02 --> Config Class Initialized
INFO - 2016-02-24 14:30:02 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:30:02 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:30:02 --> Utf8 Class Initialized
INFO - 2016-02-24 14:30:02 --> URI Class Initialized
INFO - 2016-02-24 14:30:02 --> Router Class Initialized
INFO - 2016-02-24 14:30:02 --> Output Class Initialized
INFO - 2016-02-24 14:30:02 --> Security Class Initialized
DEBUG - 2016-02-24 14:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:30:02 --> Input Class Initialized
INFO - 2016-02-24 14:30:02 --> Language Class Initialized
INFO - 2016-02-24 14:30:02 --> Loader Class Initialized
INFO - 2016-02-24 14:30:02 --> Helper loaded: url_helper
INFO - 2016-02-24 14:30:02 --> Helper loaded: file_helper
INFO - 2016-02-24 14:30:02 --> Helper loaded: date_helper
INFO - 2016-02-24 14:30:02 --> Helper loaded: form_helper
INFO - 2016-02-24 14:30:02 --> Database Driver Class Initialized
INFO - 2016-02-24 14:30:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:30:03 --> Controller Class Initialized
INFO - 2016-02-24 14:30:03 --> Model Class Initialized
INFO - 2016-02-24 14:30:03 --> Model Class Initialized
INFO - 2016-02-24 14:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:30:03 --> Pagination Class Initialized
INFO - 2016-02-24 14:30:03 --> Helper loaded: text_helper
INFO - 2016-02-24 14:30:03 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:30:03 --> Final output sent to browser
DEBUG - 2016-02-24 17:30:03 --> Total execution time: 1.1084
INFO - 2016-02-24 14:30:05 --> Config Class Initialized
INFO - 2016-02-24 14:30:05 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:30:05 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:30:05 --> Utf8 Class Initialized
INFO - 2016-02-24 14:30:05 --> URI Class Initialized
INFO - 2016-02-24 14:30:05 --> Router Class Initialized
INFO - 2016-02-24 14:30:05 --> Output Class Initialized
INFO - 2016-02-24 14:30:05 --> Security Class Initialized
DEBUG - 2016-02-24 14:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:30:05 --> Input Class Initialized
INFO - 2016-02-24 14:30:05 --> Language Class Initialized
INFO - 2016-02-24 14:30:05 --> Loader Class Initialized
INFO - 2016-02-24 14:30:05 --> Helper loaded: url_helper
INFO - 2016-02-24 14:30:05 --> Helper loaded: file_helper
INFO - 2016-02-24 14:30:05 --> Helper loaded: date_helper
INFO - 2016-02-24 14:30:05 --> Helper loaded: form_helper
INFO - 2016-02-24 14:30:05 --> Database Driver Class Initialized
INFO - 2016-02-24 14:30:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:30:06 --> Controller Class Initialized
INFO - 2016-02-24 14:30:06 --> Model Class Initialized
INFO - 2016-02-24 14:30:06 --> Model Class Initialized
INFO - 2016-02-24 14:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:30:06 --> Pagination Class Initialized
INFO - 2016-02-24 14:30:06 --> Helper loaded: text_helper
INFO - 2016-02-24 14:30:06 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:30:06 --> Final output sent to browser
DEBUG - 2016-02-24 17:30:06 --> Total execution time: 1.1784
INFO - 2016-02-24 14:30:11 --> Config Class Initialized
INFO - 2016-02-24 14:30:11 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:30:11 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:30:11 --> Utf8 Class Initialized
INFO - 2016-02-24 14:30:11 --> URI Class Initialized
INFO - 2016-02-24 14:30:11 --> Router Class Initialized
INFO - 2016-02-24 14:30:11 --> Output Class Initialized
INFO - 2016-02-24 14:30:11 --> Security Class Initialized
DEBUG - 2016-02-24 14:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:30:11 --> Input Class Initialized
INFO - 2016-02-24 14:30:11 --> Language Class Initialized
INFO - 2016-02-24 14:30:11 --> Loader Class Initialized
INFO - 2016-02-24 14:30:11 --> Helper loaded: url_helper
INFO - 2016-02-24 14:30:11 --> Helper loaded: file_helper
INFO - 2016-02-24 14:30:11 --> Helper loaded: date_helper
INFO - 2016-02-24 14:30:11 --> Helper loaded: form_helper
INFO - 2016-02-24 14:30:11 --> Database Driver Class Initialized
INFO - 2016-02-24 14:30:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:30:12 --> Controller Class Initialized
INFO - 2016-02-24 14:30:12 --> Model Class Initialized
INFO - 2016-02-24 14:30:12 --> Model Class Initialized
INFO - 2016-02-24 14:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:30:12 --> Pagination Class Initialized
INFO - 2016-02-24 14:30:12 --> Helper loaded: text_helper
INFO - 2016-02-24 14:30:12 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:30:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:30:12 --> Final output sent to browser
DEBUG - 2016-02-24 17:30:12 --> Total execution time: 1.6980
INFO - 2016-02-24 14:32:42 --> Config Class Initialized
INFO - 2016-02-24 14:32:42 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:32:42 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:32:42 --> Utf8 Class Initialized
INFO - 2016-02-24 14:32:42 --> URI Class Initialized
DEBUG - 2016-02-24 14:32:42 --> No URI present. Default controller set.
INFO - 2016-02-24 14:32:42 --> Router Class Initialized
INFO - 2016-02-24 14:32:42 --> Output Class Initialized
INFO - 2016-02-24 14:32:42 --> Security Class Initialized
DEBUG - 2016-02-24 14:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:32:42 --> Input Class Initialized
INFO - 2016-02-24 14:32:42 --> Language Class Initialized
INFO - 2016-02-24 14:32:42 --> Loader Class Initialized
INFO - 2016-02-24 14:32:42 --> Helper loaded: url_helper
INFO - 2016-02-24 14:32:42 --> Helper loaded: file_helper
INFO - 2016-02-24 14:32:42 --> Helper loaded: date_helper
INFO - 2016-02-24 14:32:42 --> Helper loaded: form_helper
INFO - 2016-02-24 14:32:42 --> Database Driver Class Initialized
INFO - 2016-02-24 14:32:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:32:43 --> Controller Class Initialized
INFO - 2016-02-24 14:32:43 --> Model Class Initialized
INFO - 2016-02-24 14:32:43 --> Model Class Initialized
INFO - 2016-02-24 14:32:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:32:43 --> Pagination Class Initialized
INFO - 2016-02-24 14:32:43 --> Helper loaded: text_helper
INFO - 2016-02-24 14:32:43 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 17:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:32:43 --> Final output sent to browser
DEBUG - 2016-02-24 17:32:43 --> Total execution time: 1.1418
INFO - 2016-02-24 14:32:44 --> Config Class Initialized
INFO - 2016-02-24 14:32:44 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:32:44 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:32:44 --> Utf8 Class Initialized
INFO - 2016-02-24 14:32:44 --> URI Class Initialized
INFO - 2016-02-24 14:32:44 --> Router Class Initialized
INFO - 2016-02-24 14:32:44 --> Output Class Initialized
INFO - 2016-02-24 14:32:44 --> Security Class Initialized
DEBUG - 2016-02-24 14:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:32:44 --> Input Class Initialized
INFO - 2016-02-24 14:32:44 --> Language Class Initialized
INFO - 2016-02-24 14:32:44 --> Loader Class Initialized
INFO - 2016-02-24 14:32:44 --> Helper loaded: url_helper
INFO - 2016-02-24 14:32:44 --> Helper loaded: file_helper
INFO - 2016-02-24 14:32:44 --> Helper loaded: date_helper
INFO - 2016-02-24 14:32:44 --> Helper loaded: form_helper
INFO - 2016-02-24 14:32:44 --> Database Driver Class Initialized
INFO - 2016-02-24 14:32:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:32:45 --> Controller Class Initialized
INFO - 2016-02-24 14:32:45 --> Model Class Initialized
INFO - 2016-02-24 14:32:45 --> Model Class Initialized
INFO - 2016-02-24 14:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:32:45 --> Pagination Class Initialized
INFO - 2016-02-24 14:32:45 --> Helper loaded: text_helper
INFO - 2016-02-24 14:32:45 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:32:45 --> Final output sent to browser
DEBUG - 2016-02-24 17:32:45 --> Total execution time: 1.0962
INFO - 2016-02-24 14:32:47 --> Config Class Initialized
INFO - 2016-02-24 14:32:47 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:32:47 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:32:47 --> Utf8 Class Initialized
INFO - 2016-02-24 14:32:47 --> URI Class Initialized
INFO - 2016-02-24 14:32:47 --> Router Class Initialized
INFO - 2016-02-24 14:32:47 --> Output Class Initialized
INFO - 2016-02-24 14:32:47 --> Security Class Initialized
DEBUG - 2016-02-24 14:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:32:47 --> Input Class Initialized
INFO - 2016-02-24 14:32:47 --> Language Class Initialized
INFO - 2016-02-24 14:32:47 --> Loader Class Initialized
INFO - 2016-02-24 14:32:47 --> Helper loaded: url_helper
INFO - 2016-02-24 14:32:47 --> Helper loaded: file_helper
INFO - 2016-02-24 14:32:47 --> Helper loaded: date_helper
INFO - 2016-02-24 14:32:47 --> Helper loaded: form_helper
INFO - 2016-02-24 14:32:47 --> Database Driver Class Initialized
INFO - 2016-02-24 14:32:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:32:49 --> Controller Class Initialized
INFO - 2016-02-24 14:32:49 --> Model Class Initialized
INFO - 2016-02-24 14:32:49 --> Model Class Initialized
INFO - 2016-02-24 14:32:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:32:49 --> Pagination Class Initialized
INFO - 2016-02-24 14:32:49 --> Helper loaded: text_helper
INFO - 2016-02-24 14:32:49 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:32:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:32:49 --> Final output sent to browser
DEBUG - 2016-02-24 17:32:49 --> Total execution time: 1.1904
INFO - 2016-02-24 14:32:55 --> Config Class Initialized
INFO - 2016-02-24 14:32:55 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:32:55 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:32:55 --> Utf8 Class Initialized
INFO - 2016-02-24 14:32:55 --> URI Class Initialized
INFO - 2016-02-24 14:32:55 --> Router Class Initialized
INFO - 2016-02-24 14:32:55 --> Output Class Initialized
INFO - 2016-02-24 14:32:55 --> Security Class Initialized
DEBUG - 2016-02-24 14:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:32:55 --> Input Class Initialized
INFO - 2016-02-24 14:32:55 --> Language Class Initialized
INFO - 2016-02-24 14:32:55 --> Loader Class Initialized
INFO - 2016-02-24 14:32:55 --> Helper loaded: url_helper
INFO - 2016-02-24 14:32:55 --> Helper loaded: file_helper
INFO - 2016-02-24 14:32:55 --> Helper loaded: date_helper
INFO - 2016-02-24 14:32:55 --> Helper loaded: form_helper
INFO - 2016-02-24 14:32:55 --> Database Driver Class Initialized
INFO - 2016-02-24 14:32:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:32:56 --> Controller Class Initialized
INFO - 2016-02-24 14:32:56 --> Model Class Initialized
INFO - 2016-02-24 14:32:56 --> Model Class Initialized
INFO - 2016-02-24 14:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:32:56 --> Pagination Class Initialized
INFO - 2016-02-24 14:32:56 --> Helper loaded: text_helper
INFO - 2016-02-24 14:32:56 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:32:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:32:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:32:57 --> Final output sent to browser
DEBUG - 2016-02-24 17:32:57 --> Total execution time: 1.1929
INFO - 2016-02-24 14:35:49 --> Config Class Initialized
INFO - 2016-02-24 14:35:49 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:35:49 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:35:49 --> Utf8 Class Initialized
INFO - 2016-02-24 14:35:49 --> URI Class Initialized
INFO - 2016-02-24 14:35:49 --> Router Class Initialized
INFO - 2016-02-24 14:35:49 --> Output Class Initialized
INFO - 2016-02-24 14:35:49 --> Security Class Initialized
DEBUG - 2016-02-24 14:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:35:49 --> Input Class Initialized
INFO - 2016-02-24 14:35:49 --> Language Class Initialized
INFO - 2016-02-24 14:35:49 --> Loader Class Initialized
INFO - 2016-02-24 14:35:49 --> Helper loaded: url_helper
INFO - 2016-02-24 14:35:49 --> Helper loaded: file_helper
INFO - 2016-02-24 14:35:49 --> Helper loaded: date_helper
INFO - 2016-02-24 14:35:49 --> Helper loaded: form_helper
INFO - 2016-02-24 14:35:49 --> Database Driver Class Initialized
INFO - 2016-02-24 14:35:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:35:50 --> Controller Class Initialized
INFO - 2016-02-24 14:35:50 --> Model Class Initialized
INFO - 2016-02-24 14:35:50 --> Model Class Initialized
INFO - 2016-02-24 14:35:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:35:50 --> Pagination Class Initialized
INFO - 2016-02-24 14:35:50 --> Helper loaded: text_helper
INFO - 2016-02-24 14:35:50 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:35:50 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:35:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:35:50 --> Final output sent to browser
DEBUG - 2016-02-24 17:35:50 --> Total execution time: 1.1728
INFO - 2016-02-24 14:41:10 --> Config Class Initialized
INFO - 2016-02-24 14:41:10 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:41:10 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:41:10 --> Utf8 Class Initialized
INFO - 2016-02-24 14:41:10 --> URI Class Initialized
DEBUG - 2016-02-24 14:41:10 --> No URI present. Default controller set.
INFO - 2016-02-24 14:41:10 --> Router Class Initialized
INFO - 2016-02-24 14:41:10 --> Output Class Initialized
INFO - 2016-02-24 14:41:10 --> Security Class Initialized
DEBUG - 2016-02-24 14:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:41:10 --> Input Class Initialized
INFO - 2016-02-24 14:41:10 --> Language Class Initialized
INFO - 2016-02-24 14:41:10 --> Loader Class Initialized
INFO - 2016-02-24 14:41:10 --> Helper loaded: url_helper
INFO - 2016-02-24 14:41:10 --> Helper loaded: file_helper
INFO - 2016-02-24 14:41:10 --> Helper loaded: date_helper
INFO - 2016-02-24 14:41:10 --> Helper loaded: form_helper
INFO - 2016-02-24 14:41:10 --> Database Driver Class Initialized
INFO - 2016-02-24 14:41:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:41:11 --> Controller Class Initialized
INFO - 2016-02-24 14:41:11 --> Model Class Initialized
INFO - 2016-02-24 14:41:11 --> Model Class Initialized
INFO - 2016-02-24 14:41:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:41:11 --> Pagination Class Initialized
INFO - 2016-02-24 14:41:11 --> Helper loaded: text_helper
INFO - 2016-02-24 14:41:11 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 17:41:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:41:11 --> Final output sent to browser
DEBUG - 2016-02-24 17:41:11 --> Total execution time: 1.1326
INFO - 2016-02-24 14:41:13 --> Config Class Initialized
INFO - 2016-02-24 14:41:13 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:41:13 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:41:13 --> Utf8 Class Initialized
INFO - 2016-02-24 14:41:13 --> URI Class Initialized
INFO - 2016-02-24 14:41:13 --> Router Class Initialized
INFO - 2016-02-24 14:41:13 --> Output Class Initialized
INFO - 2016-02-24 14:41:13 --> Security Class Initialized
DEBUG - 2016-02-24 14:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:41:13 --> Input Class Initialized
INFO - 2016-02-24 14:41:13 --> Language Class Initialized
INFO - 2016-02-24 14:41:13 --> Loader Class Initialized
INFO - 2016-02-24 14:41:13 --> Helper loaded: url_helper
INFO - 2016-02-24 14:41:13 --> Helper loaded: file_helper
INFO - 2016-02-24 14:41:13 --> Helper loaded: date_helper
INFO - 2016-02-24 14:41:13 --> Helper loaded: form_helper
INFO - 2016-02-24 14:41:13 --> Database Driver Class Initialized
INFO - 2016-02-24 14:41:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:41:14 --> Controller Class Initialized
INFO - 2016-02-24 14:41:14 --> Model Class Initialized
INFO - 2016-02-24 14:41:14 --> Model Class Initialized
INFO - 2016-02-24 14:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:41:14 --> Pagination Class Initialized
INFO - 2016-02-24 14:41:14 --> Helper loaded: text_helper
INFO - 2016-02-24 14:41:14 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:41:14 --> Final output sent to browser
DEBUG - 2016-02-24 17:41:14 --> Total execution time: 1.1939
INFO - 2016-02-24 14:41:16 --> Config Class Initialized
INFO - 2016-02-24 14:41:16 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:41:16 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:41:16 --> Utf8 Class Initialized
INFO - 2016-02-24 14:41:16 --> URI Class Initialized
INFO - 2016-02-24 14:41:16 --> Router Class Initialized
INFO - 2016-02-24 14:41:16 --> Output Class Initialized
INFO - 2016-02-24 14:41:16 --> Security Class Initialized
DEBUG - 2016-02-24 14:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:41:16 --> Input Class Initialized
INFO - 2016-02-24 14:41:16 --> Language Class Initialized
INFO - 2016-02-24 14:41:16 --> Loader Class Initialized
INFO - 2016-02-24 14:41:16 --> Helper loaded: url_helper
INFO - 2016-02-24 14:41:16 --> Helper loaded: file_helper
INFO - 2016-02-24 14:41:16 --> Helper loaded: date_helper
INFO - 2016-02-24 14:41:16 --> Helper loaded: form_helper
INFO - 2016-02-24 14:41:16 --> Database Driver Class Initialized
INFO - 2016-02-24 14:41:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:41:17 --> Controller Class Initialized
INFO - 2016-02-24 14:41:17 --> Model Class Initialized
INFO - 2016-02-24 14:41:17 --> Model Class Initialized
INFO - 2016-02-24 14:41:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:41:17 --> Pagination Class Initialized
INFO - 2016-02-24 14:41:17 --> Helper loaded: text_helper
INFO - 2016-02-24 14:41:17 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:41:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:41:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:41:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:41:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:41:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:41:17 --> Final output sent to browser
DEBUG - 2016-02-24 17:41:17 --> Total execution time: 1.2377
INFO - 2016-02-24 14:41:22 --> Config Class Initialized
INFO - 2016-02-24 14:41:22 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:41:22 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:41:22 --> Utf8 Class Initialized
INFO - 2016-02-24 14:41:22 --> URI Class Initialized
INFO - 2016-02-24 14:41:22 --> Router Class Initialized
INFO - 2016-02-24 14:41:22 --> Output Class Initialized
INFO - 2016-02-24 14:41:22 --> Security Class Initialized
DEBUG - 2016-02-24 14:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:41:22 --> Input Class Initialized
INFO - 2016-02-24 14:41:22 --> Language Class Initialized
INFO - 2016-02-24 14:41:22 --> Loader Class Initialized
INFO - 2016-02-24 14:41:22 --> Helper loaded: url_helper
INFO - 2016-02-24 14:41:22 --> Helper loaded: file_helper
INFO - 2016-02-24 14:41:22 --> Helper loaded: date_helper
INFO - 2016-02-24 14:41:22 --> Helper loaded: form_helper
INFO - 2016-02-24 14:41:22 --> Database Driver Class Initialized
INFO - 2016-02-24 14:41:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:41:23 --> Controller Class Initialized
INFO - 2016-02-24 14:41:23 --> Model Class Initialized
INFO - 2016-02-24 14:41:23 --> Model Class Initialized
INFO - 2016-02-24 14:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:41:23 --> Pagination Class Initialized
INFO - 2016-02-24 14:41:23 --> Helper loaded: text_helper
INFO - 2016-02-24 14:41:23 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:41:23 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:41:23 --> Final output sent to browser
DEBUG - 2016-02-24 17:41:23 --> Total execution time: 1.1588
INFO - 2016-02-24 14:43:36 --> Config Class Initialized
INFO - 2016-02-24 14:43:36 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:43:36 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:43:36 --> Utf8 Class Initialized
INFO - 2016-02-24 14:43:36 --> URI Class Initialized
DEBUG - 2016-02-24 14:43:36 --> No URI present. Default controller set.
INFO - 2016-02-24 14:43:36 --> Router Class Initialized
INFO - 2016-02-24 14:43:36 --> Output Class Initialized
INFO - 2016-02-24 14:43:36 --> Security Class Initialized
DEBUG - 2016-02-24 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:43:36 --> Input Class Initialized
INFO - 2016-02-24 14:43:36 --> Language Class Initialized
INFO - 2016-02-24 14:43:36 --> Loader Class Initialized
INFO - 2016-02-24 14:43:36 --> Helper loaded: url_helper
INFO - 2016-02-24 14:43:36 --> Helper loaded: file_helper
INFO - 2016-02-24 14:43:36 --> Helper loaded: date_helper
INFO - 2016-02-24 14:43:36 --> Helper loaded: form_helper
INFO - 2016-02-24 14:43:36 --> Database Driver Class Initialized
INFO - 2016-02-24 14:43:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:43:37 --> Controller Class Initialized
INFO - 2016-02-24 14:43:37 --> Model Class Initialized
INFO - 2016-02-24 14:43:37 --> Model Class Initialized
INFO - 2016-02-24 14:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:43:37 --> Pagination Class Initialized
INFO - 2016-02-24 14:43:37 --> Helper loaded: text_helper
INFO - 2016-02-24 14:43:37 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:43:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:43:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:43:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 17:43:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:43:37 --> Final output sent to browser
DEBUG - 2016-02-24 17:43:37 --> Total execution time: 1.1464
INFO - 2016-02-24 14:43:38 --> Config Class Initialized
INFO - 2016-02-24 14:43:38 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:43:38 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:43:38 --> Utf8 Class Initialized
INFO - 2016-02-24 14:43:38 --> URI Class Initialized
INFO - 2016-02-24 14:43:38 --> Router Class Initialized
INFO - 2016-02-24 14:43:38 --> Output Class Initialized
INFO - 2016-02-24 14:43:38 --> Security Class Initialized
DEBUG - 2016-02-24 14:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:43:38 --> Input Class Initialized
INFO - 2016-02-24 14:43:38 --> Language Class Initialized
INFO - 2016-02-24 14:43:38 --> Loader Class Initialized
INFO - 2016-02-24 14:43:38 --> Helper loaded: url_helper
INFO - 2016-02-24 14:43:38 --> Helper loaded: file_helper
INFO - 2016-02-24 14:43:38 --> Helper loaded: date_helper
INFO - 2016-02-24 14:43:38 --> Helper loaded: form_helper
INFO - 2016-02-24 14:43:38 --> Database Driver Class Initialized
INFO - 2016-02-24 14:43:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:43:39 --> Controller Class Initialized
INFO - 2016-02-24 14:43:39 --> Model Class Initialized
INFO - 2016-02-24 14:43:39 --> Model Class Initialized
INFO - 2016-02-24 14:43:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:43:39 --> Pagination Class Initialized
INFO - 2016-02-24 14:43:39 --> Helper loaded: text_helper
INFO - 2016-02-24 14:43:39 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:43:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:43:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:43:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:43:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:43:39 --> Final output sent to browser
DEBUG - 2016-02-24 17:43:39 --> Total execution time: 1.1279
INFO - 2016-02-24 14:43:41 --> Config Class Initialized
INFO - 2016-02-24 14:43:41 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:43:41 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:43:41 --> Utf8 Class Initialized
INFO - 2016-02-24 14:43:41 --> URI Class Initialized
INFO - 2016-02-24 14:43:41 --> Router Class Initialized
INFO - 2016-02-24 14:43:41 --> Output Class Initialized
INFO - 2016-02-24 14:43:41 --> Security Class Initialized
DEBUG - 2016-02-24 14:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:43:41 --> Input Class Initialized
INFO - 2016-02-24 14:43:41 --> Language Class Initialized
INFO - 2016-02-24 14:43:41 --> Loader Class Initialized
INFO - 2016-02-24 14:43:41 --> Helper loaded: url_helper
INFO - 2016-02-24 14:43:41 --> Helper loaded: file_helper
INFO - 2016-02-24 14:43:41 --> Helper loaded: date_helper
INFO - 2016-02-24 14:43:41 --> Helper loaded: form_helper
INFO - 2016-02-24 14:43:41 --> Database Driver Class Initialized
INFO - 2016-02-24 14:43:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:43:42 --> Controller Class Initialized
INFO - 2016-02-24 14:43:42 --> Model Class Initialized
INFO - 2016-02-24 14:43:42 --> Model Class Initialized
INFO - 2016-02-24 14:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:43:42 --> Pagination Class Initialized
INFO - 2016-02-24 14:43:42 --> Helper loaded: text_helper
INFO - 2016-02-24 14:43:42 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:43:42 --> Final output sent to browser
DEBUG - 2016-02-24 17:43:42 --> Total execution time: 1.2556
INFO - 2016-02-24 14:43:47 --> Config Class Initialized
INFO - 2016-02-24 14:43:47 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:43:47 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:43:47 --> Utf8 Class Initialized
INFO - 2016-02-24 14:43:47 --> URI Class Initialized
INFO - 2016-02-24 14:43:47 --> Router Class Initialized
INFO - 2016-02-24 14:43:47 --> Output Class Initialized
INFO - 2016-02-24 14:43:47 --> Security Class Initialized
DEBUG - 2016-02-24 14:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:43:47 --> Input Class Initialized
INFO - 2016-02-24 14:43:47 --> Language Class Initialized
INFO - 2016-02-24 14:43:47 --> Loader Class Initialized
INFO - 2016-02-24 14:43:47 --> Helper loaded: url_helper
INFO - 2016-02-24 14:43:47 --> Helper loaded: file_helper
INFO - 2016-02-24 14:43:47 --> Helper loaded: date_helper
INFO - 2016-02-24 14:43:47 --> Helper loaded: form_helper
INFO - 2016-02-24 14:43:47 --> Database Driver Class Initialized
INFO - 2016-02-24 14:43:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:43:48 --> Controller Class Initialized
INFO - 2016-02-24 14:43:48 --> Model Class Initialized
INFO - 2016-02-24 14:43:48 --> Model Class Initialized
INFO - 2016-02-24 14:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:43:48 --> Pagination Class Initialized
INFO - 2016-02-24 14:43:48 --> Helper loaded: text_helper
INFO - 2016-02-24 14:43:48 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:43:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:43:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:43:48 --> Final output sent to browser
DEBUG - 2016-02-24 17:43:48 --> Total execution time: 1.1518
INFO - 2016-02-24 14:46:06 --> Config Class Initialized
INFO - 2016-02-24 14:46:06 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:46:06 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:46:06 --> Utf8 Class Initialized
INFO - 2016-02-24 14:46:06 --> URI Class Initialized
ERROR - 2016-02-24 14:46:06 --> Severity: 4096 --> Object of class CI_URI could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\config\routes.php 53
INFO - 2016-02-24 14:46:06 --> Router Class Initialized
INFO - 2016-02-24 14:46:06 --> Output Class Initialized
INFO - 2016-02-24 14:46:06 --> Security Class Initialized
DEBUG - 2016-02-24 14:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:46:06 --> Input Class Initialized
INFO - 2016-02-24 14:46:06 --> Language Class Initialized
ERROR - 2016-02-24 14:46:06 --> 404 Page Not Found: <?= ->segment(1);?>/get
INFO - 2016-02-24 14:47:43 --> Config Class Initialized
INFO - 2016-02-24 14:47:43 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:47:43 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:47:43 --> Utf8 Class Initialized
INFO - 2016-02-24 14:47:43 --> URI Class Initialized
INFO - 2016-02-24 14:47:43 --> Router Class Initialized
INFO - 2016-02-24 14:47:43 --> Output Class Initialized
INFO - 2016-02-24 14:47:43 --> Security Class Initialized
DEBUG - 2016-02-24 14:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:47:43 --> Input Class Initialized
INFO - 2016-02-24 14:47:43 --> Language Class Initialized
INFO - 2016-02-24 14:47:43 --> Loader Class Initialized
INFO - 2016-02-24 14:47:43 --> Helper loaded: url_helper
INFO - 2016-02-24 14:47:43 --> Helper loaded: file_helper
INFO - 2016-02-24 14:47:43 --> Helper loaded: date_helper
INFO - 2016-02-24 14:47:43 --> Helper loaded: form_helper
INFO - 2016-02-24 14:47:43 --> Database Driver Class Initialized
INFO - 2016-02-24 14:47:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:47:44 --> Controller Class Initialized
INFO - 2016-02-24 14:47:44 --> Model Class Initialized
INFO - 2016-02-24 14:47:44 --> Model Class Initialized
INFO - 2016-02-24 14:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:47:44 --> Pagination Class Initialized
INFO - 2016-02-24 14:47:44 --> Helper loaded: text_helper
INFO - 2016-02-24 14:47:44 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:47:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:47:44 --> Final output sent to browser
DEBUG - 2016-02-24 17:47:44 --> Total execution time: 1.2147
INFO - 2016-02-24 14:48:10 --> Config Class Initialized
INFO - 2016-02-24 14:48:10 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:48:10 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:48:10 --> Utf8 Class Initialized
INFO - 2016-02-24 14:48:10 --> URI Class Initialized
DEBUG - 2016-02-24 14:48:10 --> No URI present. Default controller set.
INFO - 2016-02-24 14:48:10 --> Router Class Initialized
INFO - 2016-02-24 14:48:10 --> Output Class Initialized
INFO - 2016-02-24 14:48:10 --> Security Class Initialized
DEBUG - 2016-02-24 14:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:48:10 --> Input Class Initialized
INFO - 2016-02-24 14:48:10 --> Language Class Initialized
INFO - 2016-02-24 14:48:10 --> Loader Class Initialized
INFO - 2016-02-24 14:48:10 --> Helper loaded: url_helper
INFO - 2016-02-24 14:48:10 --> Helper loaded: file_helper
INFO - 2016-02-24 14:48:10 --> Helper loaded: date_helper
INFO - 2016-02-24 14:48:10 --> Helper loaded: form_helper
INFO - 2016-02-24 14:48:10 --> Database Driver Class Initialized
INFO - 2016-02-24 14:48:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:48:11 --> Controller Class Initialized
INFO - 2016-02-24 14:48:11 --> Model Class Initialized
INFO - 2016-02-24 14:48:11 --> Model Class Initialized
INFO - 2016-02-24 14:48:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:48:11 --> Pagination Class Initialized
INFO - 2016-02-24 14:48:11 --> Helper loaded: text_helper
INFO - 2016-02-24 14:48:11 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 17:48:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:48:11 --> Final output sent to browser
DEBUG - 2016-02-24 17:48:11 --> Total execution time: 1.1605
INFO - 2016-02-24 14:48:11 --> Config Class Initialized
INFO - 2016-02-24 14:48:11 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:48:11 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:48:11 --> Utf8 Class Initialized
INFO - 2016-02-24 14:48:11 --> URI Class Initialized
INFO - 2016-02-24 14:48:11 --> Router Class Initialized
INFO - 2016-02-24 14:48:11 --> Output Class Initialized
INFO - 2016-02-24 14:48:11 --> Security Class Initialized
DEBUG - 2016-02-24 14:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:48:11 --> Input Class Initialized
INFO - 2016-02-24 14:48:11 --> Language Class Initialized
INFO - 2016-02-24 14:48:11 --> Loader Class Initialized
INFO - 2016-02-24 14:48:11 --> Helper loaded: url_helper
INFO - 2016-02-24 14:48:11 --> Helper loaded: file_helper
INFO - 2016-02-24 14:48:11 --> Helper loaded: date_helper
INFO - 2016-02-24 14:48:11 --> Helper loaded: form_helper
INFO - 2016-02-24 14:48:11 --> Database Driver Class Initialized
INFO - 2016-02-24 14:48:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:48:12 --> Controller Class Initialized
INFO - 2016-02-24 14:48:12 --> Model Class Initialized
INFO - 2016-02-24 14:48:12 --> Model Class Initialized
INFO - 2016-02-24 14:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:48:12 --> Pagination Class Initialized
INFO - 2016-02-24 14:48:12 --> Helper loaded: text_helper
INFO - 2016-02-24 14:48:12 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:48:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:48:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:48:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:48:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:48:12 --> Final output sent to browser
DEBUG - 2016-02-24 17:48:12 --> Total execution time: 1.1215
INFO - 2016-02-24 14:48:16 --> Config Class Initialized
INFO - 2016-02-24 14:48:16 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:48:16 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:48:16 --> Utf8 Class Initialized
INFO - 2016-02-24 14:48:16 --> URI Class Initialized
INFO - 2016-02-24 14:48:16 --> Router Class Initialized
INFO - 2016-02-24 14:48:16 --> Output Class Initialized
INFO - 2016-02-24 14:48:16 --> Security Class Initialized
DEBUG - 2016-02-24 14:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:48:16 --> Input Class Initialized
INFO - 2016-02-24 14:48:16 --> Language Class Initialized
INFO - 2016-02-24 14:48:16 --> Loader Class Initialized
INFO - 2016-02-24 14:48:16 --> Helper loaded: url_helper
INFO - 2016-02-24 14:48:16 --> Helper loaded: file_helper
INFO - 2016-02-24 14:48:16 --> Helper loaded: date_helper
INFO - 2016-02-24 14:48:16 --> Helper loaded: form_helper
INFO - 2016-02-24 14:48:16 --> Database Driver Class Initialized
INFO - 2016-02-24 14:48:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:48:17 --> Controller Class Initialized
INFO - 2016-02-24 14:48:17 --> Model Class Initialized
INFO - 2016-02-24 14:48:17 --> Model Class Initialized
INFO - 2016-02-24 14:48:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:48:17 --> Pagination Class Initialized
INFO - 2016-02-24 14:48:17 --> Helper loaded: text_helper
INFO - 2016-02-24 14:48:17 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:48:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:48:17 --> Final output sent to browser
DEBUG - 2016-02-24 17:48:17 --> Total execution time: 1.1738
INFO - 2016-02-24 14:48:20 --> Config Class Initialized
INFO - 2016-02-24 14:48:20 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:48:20 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:48:20 --> Utf8 Class Initialized
INFO - 2016-02-24 14:48:20 --> URI Class Initialized
INFO - 2016-02-24 14:48:20 --> Router Class Initialized
INFO - 2016-02-24 14:48:20 --> Output Class Initialized
INFO - 2016-02-24 14:48:20 --> Security Class Initialized
DEBUG - 2016-02-24 14:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:48:20 --> Input Class Initialized
INFO - 2016-02-24 14:48:20 --> Language Class Initialized
INFO - 2016-02-24 14:48:20 --> Loader Class Initialized
INFO - 2016-02-24 14:48:20 --> Helper loaded: url_helper
INFO - 2016-02-24 14:48:20 --> Helper loaded: file_helper
INFO - 2016-02-24 14:48:20 --> Helper loaded: date_helper
INFO - 2016-02-24 14:48:20 --> Helper loaded: form_helper
INFO - 2016-02-24 14:48:20 --> Database Driver Class Initialized
INFO - 2016-02-24 14:48:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:48:21 --> Controller Class Initialized
INFO - 2016-02-24 14:48:21 --> Model Class Initialized
INFO - 2016-02-24 14:48:21 --> Model Class Initialized
INFO - 2016-02-24 14:48:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:48:21 --> Pagination Class Initialized
INFO - 2016-02-24 14:48:21 --> Helper loaded: text_helper
INFO - 2016-02-24 14:48:21 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:48:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:48:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:48:21 --> Final output sent to browser
DEBUG - 2016-02-24 17:48:21 --> Total execution time: 1.1966
INFO - 2016-02-24 14:50:34 --> Config Class Initialized
INFO - 2016-02-24 14:50:34 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:50:34 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:50:34 --> Utf8 Class Initialized
INFO - 2016-02-24 14:50:34 --> URI Class Initialized
INFO - 2016-02-24 14:50:34 --> Router Class Initialized
INFO - 2016-02-24 14:50:34 --> Output Class Initialized
INFO - 2016-02-24 14:50:34 --> Security Class Initialized
DEBUG - 2016-02-24 14:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:50:34 --> Input Class Initialized
INFO - 2016-02-24 14:50:34 --> Language Class Initialized
INFO - 2016-02-24 14:50:34 --> Loader Class Initialized
INFO - 2016-02-24 14:50:34 --> Helper loaded: url_helper
INFO - 2016-02-24 14:50:34 --> Helper loaded: file_helper
INFO - 2016-02-24 14:50:34 --> Helper loaded: date_helper
INFO - 2016-02-24 14:50:34 --> Helper loaded: form_helper
INFO - 2016-02-24 14:50:34 --> Database Driver Class Initialized
INFO - 2016-02-24 14:50:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:50:35 --> Controller Class Initialized
INFO - 2016-02-24 14:50:35 --> Model Class Initialized
INFO - 2016-02-24 14:50:35 --> Model Class Initialized
INFO - 2016-02-24 14:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:50:35 --> Pagination Class Initialized
INFO - 2016-02-24 14:50:35 --> Helper loaded: text_helper
INFO - 2016-02-24 14:50:35 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:50:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:50:35 --> Final output sent to browser
DEBUG - 2016-02-24 17:50:35 --> Total execution time: 1.1754
INFO - 2016-02-24 14:50:36 --> Config Class Initialized
INFO - 2016-02-24 14:50:36 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:50:36 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:50:36 --> Utf8 Class Initialized
INFO - 2016-02-24 14:50:36 --> URI Class Initialized
INFO - 2016-02-24 14:50:36 --> Router Class Initialized
INFO - 2016-02-24 14:50:36 --> Output Class Initialized
INFO - 2016-02-24 14:50:36 --> Security Class Initialized
DEBUG - 2016-02-24 14:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:50:36 --> Input Class Initialized
INFO - 2016-02-24 14:50:36 --> Language Class Initialized
INFO - 2016-02-24 14:50:36 --> Loader Class Initialized
INFO - 2016-02-24 14:50:36 --> Helper loaded: url_helper
INFO - 2016-02-24 14:50:37 --> Helper loaded: file_helper
INFO - 2016-02-24 14:50:37 --> Helper loaded: date_helper
INFO - 2016-02-24 14:50:37 --> Helper loaded: form_helper
INFO - 2016-02-24 14:50:37 --> Database Driver Class Initialized
INFO - 2016-02-24 14:50:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:50:38 --> Controller Class Initialized
INFO - 2016-02-24 14:50:38 --> Model Class Initialized
INFO - 2016-02-24 14:50:38 --> Model Class Initialized
INFO - 2016-02-24 14:50:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:50:38 --> Pagination Class Initialized
INFO - 2016-02-24 14:50:38 --> Helper loaded: text_helper
INFO - 2016-02-24 14:50:38 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:50:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:50:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:50:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:50:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:50:38 --> Final output sent to browser
DEBUG - 2016-02-24 17:50:38 --> Total execution time: 1.1857
INFO - 2016-02-24 14:50:39 --> Config Class Initialized
INFO - 2016-02-24 14:50:39 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:50:39 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:50:39 --> Utf8 Class Initialized
INFO - 2016-02-24 14:50:39 --> URI Class Initialized
INFO - 2016-02-24 14:50:39 --> Router Class Initialized
INFO - 2016-02-24 14:50:39 --> Output Class Initialized
INFO - 2016-02-24 14:50:39 --> Security Class Initialized
DEBUG - 2016-02-24 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:50:39 --> Input Class Initialized
INFO - 2016-02-24 14:50:39 --> Language Class Initialized
INFO - 2016-02-24 14:50:39 --> Loader Class Initialized
INFO - 2016-02-24 14:50:39 --> Helper loaded: url_helper
INFO - 2016-02-24 14:50:39 --> Helper loaded: file_helper
INFO - 2016-02-24 14:50:39 --> Helper loaded: date_helper
INFO - 2016-02-24 14:50:39 --> Helper loaded: form_helper
INFO - 2016-02-24 14:50:39 --> Database Driver Class Initialized
INFO - 2016-02-24 14:50:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:50:40 --> Controller Class Initialized
INFO - 2016-02-24 14:50:40 --> Model Class Initialized
INFO - 2016-02-24 14:50:40 --> Model Class Initialized
INFO - 2016-02-24 14:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:50:40 --> Pagination Class Initialized
INFO - 2016-02-24 14:50:40 --> Helper loaded: text_helper
INFO - 2016-02-24 14:50:40 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:50:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:50:40 --> Final output sent to browser
DEBUG - 2016-02-24 17:50:40 --> Total execution time: 1.1970
INFO - 2016-02-24 14:50:44 --> Config Class Initialized
INFO - 2016-02-24 14:50:44 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:50:44 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:50:44 --> Utf8 Class Initialized
INFO - 2016-02-24 14:50:44 --> URI Class Initialized
INFO - 2016-02-24 14:50:44 --> Router Class Initialized
INFO - 2016-02-24 14:50:44 --> Output Class Initialized
INFO - 2016-02-24 14:50:44 --> Security Class Initialized
DEBUG - 2016-02-24 14:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:50:44 --> Input Class Initialized
INFO - 2016-02-24 14:50:44 --> Language Class Initialized
INFO - 2016-02-24 14:50:44 --> Loader Class Initialized
INFO - 2016-02-24 14:50:44 --> Helper loaded: url_helper
INFO - 2016-02-24 14:50:44 --> Helper loaded: file_helper
INFO - 2016-02-24 14:50:44 --> Helper loaded: date_helper
INFO - 2016-02-24 14:50:44 --> Helper loaded: form_helper
INFO - 2016-02-24 14:50:44 --> Database Driver Class Initialized
INFO - 2016-02-24 14:50:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:50:45 --> Controller Class Initialized
INFO - 2016-02-24 14:50:45 --> Model Class Initialized
INFO - 2016-02-24 14:50:45 --> Model Class Initialized
INFO - 2016-02-24 14:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:50:45 --> Pagination Class Initialized
INFO - 2016-02-24 14:50:45 --> Helper loaded: text_helper
INFO - 2016-02-24 14:50:45 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:50:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:50:45 --> Final output sent to browser
DEBUG - 2016-02-24 17:50:45 --> Total execution time: 1.1617
INFO - 2016-02-24 14:52:04 --> Config Class Initialized
INFO - 2016-02-24 14:52:04 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:52:04 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:52:04 --> Utf8 Class Initialized
INFO - 2016-02-24 14:52:04 --> URI Class Initialized
INFO - 2016-02-24 14:52:04 --> Router Class Initialized
INFO - 2016-02-24 14:52:04 --> Output Class Initialized
INFO - 2016-02-24 14:52:04 --> Security Class Initialized
DEBUG - 2016-02-24 14:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:52:04 --> Input Class Initialized
INFO - 2016-02-24 14:52:04 --> Language Class Initialized
INFO - 2016-02-24 14:52:04 --> Loader Class Initialized
INFO - 2016-02-24 14:52:04 --> Helper loaded: url_helper
INFO - 2016-02-24 14:52:04 --> Helper loaded: file_helper
INFO - 2016-02-24 14:52:04 --> Helper loaded: date_helper
INFO - 2016-02-24 14:52:04 --> Helper loaded: form_helper
INFO - 2016-02-24 14:52:04 --> Database Driver Class Initialized
INFO - 2016-02-24 14:52:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:52:05 --> Controller Class Initialized
INFO - 2016-02-24 14:52:05 --> Model Class Initialized
INFO - 2016-02-24 14:52:05 --> Model Class Initialized
INFO - 2016-02-24 14:52:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:52:05 --> Pagination Class Initialized
INFO - 2016-02-24 14:52:05 --> Helper loaded: text_helper
INFO - 2016-02-24 14:52:05 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:52:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:52:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:52:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:52:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:52:05 --> Final output sent to browser
DEBUG - 2016-02-24 17:52:05 --> Total execution time: 1.1549
INFO - 2016-02-24 14:52:34 --> Config Class Initialized
INFO - 2016-02-24 14:52:34 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:52:34 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:52:34 --> Utf8 Class Initialized
INFO - 2016-02-24 14:52:34 --> URI Class Initialized
INFO - 2016-02-24 14:52:34 --> Router Class Initialized
INFO - 2016-02-24 14:52:34 --> Output Class Initialized
INFO - 2016-02-24 14:52:34 --> Security Class Initialized
DEBUG - 2016-02-24 14:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:52:34 --> Input Class Initialized
INFO - 2016-02-24 14:52:34 --> Language Class Initialized
INFO - 2016-02-24 14:52:34 --> Loader Class Initialized
INFO - 2016-02-24 14:52:34 --> Helper loaded: url_helper
INFO - 2016-02-24 14:52:34 --> Helper loaded: file_helper
INFO - 2016-02-24 14:52:34 --> Helper loaded: date_helper
INFO - 2016-02-24 14:52:34 --> Helper loaded: form_helper
INFO - 2016-02-24 14:52:34 --> Database Driver Class Initialized
INFO - 2016-02-24 14:52:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:52:35 --> Controller Class Initialized
INFO - 2016-02-24 14:52:35 --> Model Class Initialized
INFO - 2016-02-24 14:52:35 --> Model Class Initialized
INFO - 2016-02-24 14:52:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:52:35 --> Pagination Class Initialized
INFO - 2016-02-24 14:52:35 --> Helper loaded: text_helper
INFO - 2016-02-24 14:52:35 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:52:35 --> Final output sent to browser
DEBUG - 2016-02-24 17:52:35 --> Total execution time: 1.2042
INFO - 2016-02-24 14:52:38 --> Config Class Initialized
INFO - 2016-02-24 14:52:38 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:52:38 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:52:38 --> Utf8 Class Initialized
INFO - 2016-02-24 14:52:38 --> URI Class Initialized
INFO - 2016-02-24 14:52:38 --> Router Class Initialized
INFO - 2016-02-24 14:52:38 --> Output Class Initialized
INFO - 2016-02-24 14:52:38 --> Security Class Initialized
DEBUG - 2016-02-24 14:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:52:38 --> Input Class Initialized
INFO - 2016-02-24 14:52:38 --> Language Class Initialized
INFO - 2016-02-24 14:52:38 --> Loader Class Initialized
INFO - 2016-02-24 14:52:38 --> Helper loaded: url_helper
INFO - 2016-02-24 14:52:38 --> Helper loaded: file_helper
INFO - 2016-02-24 14:52:38 --> Helper loaded: date_helper
INFO - 2016-02-24 14:52:38 --> Helper loaded: form_helper
INFO - 2016-02-24 14:52:38 --> Database Driver Class Initialized
INFO - 2016-02-24 14:52:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:52:39 --> Controller Class Initialized
INFO - 2016-02-24 14:52:39 --> Model Class Initialized
INFO - 2016-02-24 14:52:39 --> Model Class Initialized
INFO - 2016-02-24 14:52:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:52:39 --> Pagination Class Initialized
INFO - 2016-02-24 14:52:39 --> Helper loaded: text_helper
INFO - 2016-02-24 14:52:39 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 17:52:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 17:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:52:39 --> Final output sent to browser
DEBUG - 2016-02-24 17:52:39 --> Total execution time: 1.1668
INFO - 2016-02-24 14:53:35 --> Config Class Initialized
INFO - 2016-02-24 14:53:35 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:53:35 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:53:35 --> Utf8 Class Initialized
INFO - 2016-02-24 14:53:35 --> URI Class Initialized
DEBUG - 2016-02-24 14:53:35 --> No URI present. Default controller set.
INFO - 2016-02-24 14:53:35 --> Router Class Initialized
INFO - 2016-02-24 14:53:35 --> Output Class Initialized
INFO - 2016-02-24 14:53:35 --> Security Class Initialized
DEBUG - 2016-02-24 14:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:53:35 --> Input Class Initialized
INFO - 2016-02-24 14:53:35 --> Language Class Initialized
INFO - 2016-02-24 14:53:35 --> Loader Class Initialized
INFO - 2016-02-24 14:53:35 --> Helper loaded: url_helper
INFO - 2016-02-24 14:53:35 --> Helper loaded: file_helper
INFO - 2016-02-24 14:53:35 --> Helper loaded: date_helper
INFO - 2016-02-24 14:53:35 --> Helper loaded: form_helper
INFO - 2016-02-24 14:53:35 --> Database Driver Class Initialized
INFO - 2016-02-24 14:53:36 --> Config Class Initialized
INFO - 2016-02-24 14:53:36 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:53:36 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:53:36 --> Utf8 Class Initialized
INFO - 2016-02-24 14:53:36 --> URI Class Initialized
INFO - 2016-02-24 14:53:36 --> Router Class Initialized
INFO - 2016-02-24 14:53:36 --> Output Class Initialized
INFO - 2016-02-24 14:53:36 --> Security Class Initialized
DEBUG - 2016-02-24 14:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:53:36 --> Input Class Initialized
INFO - 2016-02-24 14:53:36 --> Language Class Initialized
INFO - 2016-02-24 14:53:36 --> Loader Class Initialized
INFO - 2016-02-24 14:53:36 --> Helper loaded: url_helper
INFO - 2016-02-24 14:53:36 --> Helper loaded: file_helper
INFO - 2016-02-24 14:53:36 --> Helper loaded: date_helper
INFO - 2016-02-24 14:53:36 --> Helper loaded: form_helper
INFO - 2016-02-24 14:53:36 --> Database Driver Class Initialized
INFO - 2016-02-24 14:53:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:53:36 --> Controller Class Initialized
INFO - 2016-02-24 14:53:36 --> Model Class Initialized
INFO - 2016-02-24 14:53:36 --> Model Class Initialized
INFO - 2016-02-24 14:53:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:53:36 --> Pagination Class Initialized
INFO - 2016-02-24 14:53:36 --> Helper loaded: text_helper
INFO - 2016-02-24 14:53:36 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 17:53:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:53:36 --> Final output sent to browser
DEBUG - 2016-02-24 17:53:36 --> Total execution time: 1.1432
INFO - 2016-02-24 14:53:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:53:37 --> Controller Class Initialized
INFO - 2016-02-24 14:53:37 --> Model Class Initialized
INFO - 2016-02-24 14:53:37 --> Model Class Initialized
INFO - 2016-02-24 14:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:53:37 --> Pagination Class Initialized
INFO - 2016-02-24 14:53:37 --> Helper loaded: text_helper
INFO - 2016-02-24 14:53:37 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:53:37 --> Final output sent to browser
DEBUG - 2016-02-24 17:53:37 --> Total execution time: 1.1210
INFO - 2016-02-24 14:53:38 --> Config Class Initialized
INFO - 2016-02-24 14:53:38 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:53:38 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:53:38 --> Utf8 Class Initialized
INFO - 2016-02-24 14:53:38 --> URI Class Initialized
INFO - 2016-02-24 14:53:38 --> Router Class Initialized
INFO - 2016-02-24 14:53:38 --> Output Class Initialized
INFO - 2016-02-24 14:53:38 --> Security Class Initialized
DEBUG - 2016-02-24 14:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:53:38 --> Input Class Initialized
INFO - 2016-02-24 14:53:38 --> Language Class Initialized
INFO - 2016-02-24 14:53:38 --> Loader Class Initialized
INFO - 2016-02-24 14:53:38 --> Helper loaded: url_helper
INFO - 2016-02-24 14:53:38 --> Helper loaded: file_helper
INFO - 2016-02-24 14:53:38 --> Helper loaded: date_helper
INFO - 2016-02-24 14:53:38 --> Helper loaded: form_helper
INFO - 2016-02-24 14:53:38 --> Database Driver Class Initialized
INFO - 2016-02-24 14:53:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:53:39 --> Controller Class Initialized
INFO - 2016-02-24 14:53:39 --> Model Class Initialized
INFO - 2016-02-24 14:53:39 --> Model Class Initialized
INFO - 2016-02-24 14:53:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:53:39 --> Pagination Class Initialized
INFO - 2016-02-24 14:53:39 --> Helper loaded: text_helper
INFO - 2016-02-24 14:53:39 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:53:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:53:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:53:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:53:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:53:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:53:39 --> Final output sent to browser
DEBUG - 2016-02-24 17:53:39 --> Total execution time: 1.1845
INFO - 2016-02-24 14:53:42 --> Config Class Initialized
INFO - 2016-02-24 14:53:42 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:53:42 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:53:42 --> Utf8 Class Initialized
INFO - 2016-02-24 14:53:42 --> URI Class Initialized
INFO - 2016-02-24 14:53:42 --> Router Class Initialized
INFO - 2016-02-24 14:53:42 --> Output Class Initialized
INFO - 2016-02-24 14:53:42 --> Security Class Initialized
DEBUG - 2016-02-24 14:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:53:42 --> Input Class Initialized
INFO - 2016-02-24 14:53:42 --> Language Class Initialized
ERROR - 2016-02-24 14:53:42 --> 404 Page Not Found: Wall/68
INFO - 2016-02-24 14:53:55 --> Config Class Initialized
INFO - 2016-02-24 14:53:55 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:53:55 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:53:55 --> Utf8 Class Initialized
INFO - 2016-02-24 14:53:55 --> URI Class Initialized
INFO - 2016-02-24 14:53:55 --> Router Class Initialized
INFO - 2016-02-24 14:53:55 --> Output Class Initialized
INFO - 2016-02-24 14:53:55 --> Security Class Initialized
DEBUG - 2016-02-24 14:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:53:55 --> Input Class Initialized
INFO - 2016-02-24 14:53:55 --> Language Class Initialized
INFO - 2016-02-24 14:53:55 --> Loader Class Initialized
INFO - 2016-02-24 14:53:55 --> Helper loaded: url_helper
INFO - 2016-02-24 14:53:55 --> Helper loaded: file_helper
INFO - 2016-02-24 14:53:55 --> Helper loaded: date_helper
INFO - 2016-02-24 14:53:55 --> Helper loaded: form_helper
INFO - 2016-02-24 14:53:55 --> Database Driver Class Initialized
INFO - 2016-02-24 14:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:53:56 --> Controller Class Initialized
INFO - 2016-02-24 14:53:56 --> Model Class Initialized
INFO - 2016-02-24 14:53:56 --> Model Class Initialized
INFO - 2016-02-24 14:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:53:57 --> Pagination Class Initialized
INFO - 2016-02-24 14:53:57 --> Helper loaded: text_helper
INFO - 2016-02-24 14:53:57 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:53:57 --> Final output sent to browser
DEBUG - 2016-02-24 17:53:57 --> Total execution time: 1.1236
INFO - 2016-02-24 14:53:58 --> Config Class Initialized
INFO - 2016-02-24 14:53:58 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:53:58 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:53:58 --> Utf8 Class Initialized
INFO - 2016-02-24 14:53:58 --> URI Class Initialized
INFO - 2016-02-24 14:53:58 --> Router Class Initialized
INFO - 2016-02-24 14:53:58 --> Output Class Initialized
INFO - 2016-02-24 14:53:58 --> Security Class Initialized
DEBUG - 2016-02-24 14:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:53:58 --> Input Class Initialized
INFO - 2016-02-24 14:53:58 --> Language Class Initialized
INFO - 2016-02-24 14:53:58 --> Loader Class Initialized
INFO - 2016-02-24 14:53:58 --> Helper loaded: url_helper
INFO - 2016-02-24 14:53:58 --> Helper loaded: file_helper
INFO - 2016-02-24 14:53:58 --> Helper loaded: date_helper
INFO - 2016-02-24 14:53:58 --> Helper loaded: form_helper
INFO - 2016-02-24 14:53:58 --> Database Driver Class Initialized
INFO - 2016-02-24 14:53:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:53:59 --> Controller Class Initialized
INFO - 2016-02-24 14:53:59 --> Model Class Initialized
INFO - 2016-02-24 14:53:59 --> Model Class Initialized
INFO - 2016-02-24 14:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:53:59 --> Pagination Class Initialized
INFO - 2016-02-24 14:53:59 --> Helper loaded: text_helper
INFO - 2016-02-24 14:53:59 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:53:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:53:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:53:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:53:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:53:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:53:59 --> Final output sent to browser
DEBUG - 2016-02-24 17:53:59 --> Total execution time: 1.1319
INFO - 2016-02-24 14:54:03 --> Config Class Initialized
INFO - 2016-02-24 14:54:03 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:54:03 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:54:03 --> Utf8 Class Initialized
INFO - 2016-02-24 14:54:03 --> URI Class Initialized
INFO - 2016-02-24 14:54:03 --> Router Class Initialized
INFO - 2016-02-24 14:54:03 --> Output Class Initialized
INFO - 2016-02-24 14:54:03 --> Security Class Initialized
DEBUG - 2016-02-24 14:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:54:03 --> Input Class Initialized
INFO - 2016-02-24 14:54:03 --> Language Class Initialized
ERROR - 2016-02-24 14:54:03 --> 404 Page Not Found: Wall/68
INFO - 2016-02-24 14:54:22 --> Config Class Initialized
INFO - 2016-02-24 14:54:22 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:54:22 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:54:22 --> Utf8 Class Initialized
INFO - 2016-02-24 14:54:22 --> URI Class Initialized
INFO - 2016-02-24 14:54:22 --> Router Class Initialized
INFO - 2016-02-24 14:54:22 --> Output Class Initialized
INFO - 2016-02-24 14:54:22 --> Security Class Initialized
DEBUG - 2016-02-24 14:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:54:22 --> Input Class Initialized
INFO - 2016-02-24 14:54:22 --> Language Class Initialized
ERROR - 2016-02-24 14:54:22 --> 404 Page Not Found: Wall/68
INFO - 2016-02-24 14:54:25 --> Config Class Initialized
INFO - 2016-02-24 14:54:25 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:54:25 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:54:25 --> Utf8 Class Initialized
INFO - 2016-02-24 14:54:25 --> URI Class Initialized
INFO - 2016-02-24 14:54:25 --> Router Class Initialized
INFO - 2016-02-24 14:54:25 --> Output Class Initialized
INFO - 2016-02-24 14:54:25 --> Security Class Initialized
DEBUG - 2016-02-24 14:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:54:25 --> Input Class Initialized
INFO - 2016-02-24 14:54:25 --> Language Class Initialized
INFO - 2016-02-24 14:54:25 --> Loader Class Initialized
INFO - 2016-02-24 14:54:25 --> Helper loaded: url_helper
INFO - 2016-02-24 14:54:25 --> Helper loaded: file_helper
INFO - 2016-02-24 14:54:25 --> Helper loaded: date_helper
INFO - 2016-02-24 14:54:25 --> Helper loaded: form_helper
INFO - 2016-02-24 14:54:25 --> Database Driver Class Initialized
INFO - 2016-02-24 14:54:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:54:26 --> Controller Class Initialized
INFO - 2016-02-24 14:54:26 --> Model Class Initialized
INFO - 2016-02-24 14:54:26 --> Model Class Initialized
INFO - 2016-02-24 14:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:54:26 --> Pagination Class Initialized
INFO - 2016-02-24 14:54:26 --> Helper loaded: text_helper
INFO - 2016-02-24 14:54:26 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 17:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:54:26 --> Final output sent to browser
DEBUG - 2016-02-24 17:54:26 --> Total execution time: 1.1581
INFO - 2016-02-24 14:54:28 --> Config Class Initialized
INFO - 2016-02-24 14:54:28 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:54:28 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:54:28 --> Utf8 Class Initialized
INFO - 2016-02-24 14:54:28 --> URI Class Initialized
INFO - 2016-02-24 14:54:28 --> Router Class Initialized
INFO - 2016-02-24 14:54:28 --> Output Class Initialized
INFO - 2016-02-24 14:54:28 --> Security Class Initialized
DEBUG - 2016-02-24 14:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:54:28 --> Input Class Initialized
INFO - 2016-02-24 14:54:28 --> Language Class Initialized
INFO - 2016-02-24 14:54:28 --> Loader Class Initialized
INFO - 2016-02-24 14:54:28 --> Helper loaded: url_helper
INFO - 2016-02-24 14:54:28 --> Helper loaded: file_helper
INFO - 2016-02-24 14:54:28 --> Helper loaded: date_helper
INFO - 2016-02-24 14:54:28 --> Helper loaded: form_helper
INFO - 2016-02-24 14:54:28 --> Database Driver Class Initialized
INFO - 2016-02-24 14:54:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 14:54:29 --> Controller Class Initialized
INFO - 2016-02-24 14:54:29 --> Model Class Initialized
INFO - 2016-02-24 14:54:29 --> Model Class Initialized
INFO - 2016-02-24 14:54:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 14:54:29 --> Pagination Class Initialized
INFO - 2016-02-24 14:54:29 --> Helper loaded: text_helper
INFO - 2016-02-24 14:54:29 --> Helper loaded: cookie_helper
INFO - 2016-02-24 17:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 17:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 17:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 17:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 17:54:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 17:54:29 --> Final output sent to browser
DEBUG - 2016-02-24 17:54:29 --> Total execution time: 1.1776
INFO - 2016-02-24 14:54:32 --> Config Class Initialized
INFO - 2016-02-24 14:54:32 --> Hooks Class Initialized
DEBUG - 2016-02-24 14:54:32 --> UTF-8 Support Enabled
INFO - 2016-02-24 14:54:32 --> Utf8 Class Initialized
INFO - 2016-02-24 14:54:32 --> URI Class Initialized
INFO - 2016-02-24 14:54:32 --> Router Class Initialized
INFO - 2016-02-24 14:54:32 --> Output Class Initialized
INFO - 2016-02-24 14:54:32 --> Security Class Initialized
DEBUG - 2016-02-24 14:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 14:54:32 --> Input Class Initialized
INFO - 2016-02-24 14:54:32 --> Language Class Initialized
ERROR - 2016-02-24 14:54:32 --> 404 Page Not Found: Wall/67
INFO - 2016-02-24 17:42:39 --> Config Class Initialized
INFO - 2016-02-24 17:42:39 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:42:39 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:42:39 --> Utf8 Class Initialized
INFO - 2016-02-24 17:42:39 --> URI Class Initialized
INFO - 2016-02-24 17:42:39 --> Router Class Initialized
INFO - 2016-02-24 17:42:39 --> Output Class Initialized
INFO - 2016-02-24 17:42:39 --> Security Class Initialized
DEBUG - 2016-02-24 17:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:42:39 --> Input Class Initialized
INFO - 2016-02-24 17:42:39 --> Language Class Initialized
INFO - 2016-02-24 17:42:39 --> Loader Class Initialized
INFO - 2016-02-24 17:42:39 --> Helper loaded: url_helper
INFO - 2016-02-24 17:42:39 --> Helper loaded: file_helper
INFO - 2016-02-24 17:42:39 --> Helper loaded: date_helper
INFO - 2016-02-24 17:42:39 --> Helper loaded: form_helper
INFO - 2016-02-24 17:42:39 --> Database Driver Class Initialized
INFO - 2016-02-24 17:42:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:42:40 --> Controller Class Initialized
INFO - 2016-02-24 17:42:40 --> Model Class Initialized
INFO - 2016-02-24 17:42:40 --> Model Class Initialized
INFO - 2016-02-24 17:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:42:40 --> Pagination Class Initialized
INFO - 2016-02-24 17:42:40 --> Helper loaded: text_helper
INFO - 2016-02-24 17:42:40 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:42:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:42:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:42:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 20:42:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:42:40 --> Final output sent to browser
DEBUG - 2016-02-24 20:42:40 --> Total execution time: 1.1477
INFO - 2016-02-24 17:45:20 --> Config Class Initialized
INFO - 2016-02-24 17:45:20 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:45:20 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:45:20 --> Utf8 Class Initialized
INFO - 2016-02-24 17:45:20 --> URI Class Initialized
INFO - 2016-02-24 17:45:20 --> Router Class Initialized
INFO - 2016-02-24 17:45:20 --> Output Class Initialized
INFO - 2016-02-24 17:45:20 --> Security Class Initialized
DEBUG - 2016-02-24 17:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:45:20 --> Input Class Initialized
INFO - 2016-02-24 17:45:20 --> Language Class Initialized
INFO - 2016-02-24 17:45:20 --> Loader Class Initialized
INFO - 2016-02-24 17:45:20 --> Helper loaded: url_helper
INFO - 2016-02-24 17:45:20 --> Helper loaded: file_helper
INFO - 2016-02-24 17:45:20 --> Helper loaded: date_helper
INFO - 2016-02-24 17:45:20 --> Helper loaded: form_helper
INFO - 2016-02-24 17:45:20 --> Database Driver Class Initialized
INFO - 2016-02-24 17:45:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:45:21 --> Controller Class Initialized
INFO - 2016-02-24 17:45:21 --> Model Class Initialized
INFO - 2016-02-24 17:45:21 --> Model Class Initialized
INFO - 2016-02-24 17:45:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:45:21 --> Pagination Class Initialized
INFO - 2016-02-24 17:45:21 --> Helper loaded: text_helper
INFO - 2016-02-24 17:45:21 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 20:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 20:45:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:45:21 --> Final output sent to browser
DEBUG - 2016-02-24 20:45:21 --> Total execution time: 1.2129
INFO - 2016-02-24 17:45:24 --> Config Class Initialized
INFO - 2016-02-24 17:45:24 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:45:24 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:45:24 --> Utf8 Class Initialized
INFO - 2016-02-24 17:45:24 --> URI Class Initialized
INFO - 2016-02-24 17:45:24 --> Router Class Initialized
INFO - 2016-02-24 17:45:24 --> Output Class Initialized
INFO - 2016-02-24 17:45:24 --> Security Class Initialized
DEBUG - 2016-02-24 17:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:45:24 --> Input Class Initialized
INFO - 2016-02-24 17:45:24 --> Language Class Initialized
INFO - 2016-02-24 17:45:24 --> Loader Class Initialized
INFO - 2016-02-24 17:45:24 --> Helper loaded: url_helper
INFO - 2016-02-24 17:45:24 --> Helper loaded: file_helper
INFO - 2016-02-24 17:45:24 --> Helper loaded: date_helper
INFO - 2016-02-24 17:45:24 --> Helper loaded: form_helper
INFO - 2016-02-24 17:45:24 --> Database Driver Class Initialized
INFO - 2016-02-24 17:45:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:45:25 --> Controller Class Initialized
INFO - 2016-02-24 17:45:25 --> Model Class Initialized
INFO - 2016-02-24 17:45:25 --> Model Class Initialized
INFO - 2016-02-24 17:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:45:25 --> Pagination Class Initialized
INFO - 2016-02-24 17:45:25 --> Helper loaded: text_helper
INFO - 2016-02-24 17:45:25 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:45:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:45:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:45:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 20:45:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:45:25 --> Final output sent to browser
DEBUG - 2016-02-24 20:45:25 --> Total execution time: 1.1520
INFO - 2016-02-24 17:45:27 --> Config Class Initialized
INFO - 2016-02-24 17:45:27 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:45:27 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:45:27 --> Utf8 Class Initialized
INFO - 2016-02-24 17:45:27 --> URI Class Initialized
INFO - 2016-02-24 17:45:27 --> Router Class Initialized
INFO - 2016-02-24 17:45:27 --> Output Class Initialized
INFO - 2016-02-24 17:45:27 --> Security Class Initialized
DEBUG - 2016-02-24 17:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:45:27 --> Input Class Initialized
INFO - 2016-02-24 17:45:27 --> Language Class Initialized
INFO - 2016-02-24 17:45:27 --> Loader Class Initialized
INFO - 2016-02-24 17:45:27 --> Helper loaded: url_helper
INFO - 2016-02-24 17:45:27 --> Helper loaded: file_helper
INFO - 2016-02-24 17:45:27 --> Helper loaded: date_helper
INFO - 2016-02-24 17:45:27 --> Helper loaded: form_helper
INFO - 2016-02-24 17:45:27 --> Database Driver Class Initialized
INFO - 2016-02-24 17:45:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:45:28 --> Controller Class Initialized
INFO - 2016-02-24 17:45:28 --> Model Class Initialized
INFO - 2016-02-24 17:45:28 --> Model Class Initialized
INFO - 2016-02-24 17:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:45:28 --> Pagination Class Initialized
INFO - 2016-02-24 17:45:28 --> Helper loaded: text_helper
INFO - 2016-02-24 17:45:28 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 20:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 20:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:45:28 --> Final output sent to browser
DEBUG - 2016-02-24 20:45:28 --> Total execution time: 1.2864
INFO - 2016-02-24 17:45:31 --> Config Class Initialized
INFO - 2016-02-24 17:45:31 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:45:31 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:45:32 --> Utf8 Class Initialized
INFO - 2016-02-24 17:45:32 --> URI Class Initialized
INFO - 2016-02-24 17:45:32 --> Router Class Initialized
INFO - 2016-02-24 17:45:32 --> Output Class Initialized
INFO - 2016-02-24 17:45:32 --> Security Class Initialized
DEBUG - 2016-02-24 17:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:45:32 --> Input Class Initialized
INFO - 2016-02-24 17:45:32 --> Language Class Initialized
ERROR - 2016-02-24 17:45:32 --> 404 Page Not Found: Wall/wall
INFO - 2016-02-24 17:45:50 --> Config Class Initialized
INFO - 2016-02-24 17:45:50 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:45:50 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:45:50 --> Utf8 Class Initialized
INFO - 2016-02-24 17:45:50 --> URI Class Initialized
INFO - 2016-02-24 17:45:50 --> Router Class Initialized
INFO - 2016-02-24 17:45:50 --> Output Class Initialized
INFO - 2016-02-24 17:45:50 --> Security Class Initialized
DEBUG - 2016-02-24 17:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:45:50 --> Input Class Initialized
INFO - 2016-02-24 17:45:50 --> Language Class Initialized
INFO - 2016-02-24 17:45:50 --> Loader Class Initialized
INFO - 2016-02-24 17:45:50 --> Helper loaded: url_helper
INFO - 2016-02-24 17:45:50 --> Helper loaded: file_helper
INFO - 2016-02-24 17:45:50 --> Helper loaded: date_helper
INFO - 2016-02-24 17:45:50 --> Helper loaded: form_helper
INFO - 2016-02-24 17:45:50 --> Database Driver Class Initialized
INFO - 2016-02-24 17:45:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:45:51 --> Controller Class Initialized
INFO - 2016-02-24 17:45:51 --> Model Class Initialized
INFO - 2016-02-24 17:45:51 --> Model Class Initialized
INFO - 2016-02-24 17:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:45:51 --> Pagination Class Initialized
INFO - 2016-02-24 17:45:51 --> Helper loaded: text_helper
INFO - 2016-02-24 17:45:51 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 20:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 20:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:45:51 --> Final output sent to browser
DEBUG - 2016-02-24 20:45:51 --> Total execution time: 1.2353
INFO - 2016-02-24 17:45:55 --> Config Class Initialized
INFO - 2016-02-24 17:45:55 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:45:55 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:45:55 --> Utf8 Class Initialized
INFO - 2016-02-24 17:45:55 --> URI Class Initialized
INFO - 2016-02-24 17:45:55 --> Router Class Initialized
INFO - 2016-02-24 17:45:55 --> Output Class Initialized
INFO - 2016-02-24 17:45:55 --> Security Class Initialized
DEBUG - 2016-02-24 17:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:45:55 --> Input Class Initialized
INFO - 2016-02-24 17:45:55 --> Language Class Initialized
ERROR - 2016-02-24 17:45:55 --> 404 Page Not Found: Wall/wall
INFO - 2016-02-24 17:47:09 --> Config Class Initialized
INFO - 2016-02-24 17:47:09 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:47:09 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:47:09 --> Utf8 Class Initialized
INFO - 2016-02-24 17:47:09 --> URI Class Initialized
INFO - 2016-02-24 17:47:09 --> Router Class Initialized
INFO - 2016-02-24 17:47:09 --> Output Class Initialized
INFO - 2016-02-24 17:47:09 --> Security Class Initialized
DEBUG - 2016-02-24 17:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:47:09 --> Input Class Initialized
INFO - 2016-02-24 17:47:09 --> Language Class Initialized
INFO - 2016-02-24 17:47:09 --> Loader Class Initialized
INFO - 2016-02-24 17:47:09 --> Helper loaded: url_helper
INFO - 2016-02-24 17:47:09 --> Helper loaded: file_helper
INFO - 2016-02-24 17:47:09 --> Helper loaded: date_helper
INFO - 2016-02-24 17:47:09 --> Helper loaded: form_helper
INFO - 2016-02-24 17:47:09 --> Database Driver Class Initialized
INFO - 2016-02-24 17:47:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:47:10 --> Controller Class Initialized
INFO - 2016-02-24 17:47:10 --> Model Class Initialized
INFO - 2016-02-24 17:47:10 --> Model Class Initialized
INFO - 2016-02-24 17:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:47:10 --> Pagination Class Initialized
INFO - 2016-02-24 17:47:10 --> Helper loaded: text_helper
INFO - 2016-02-24 17:47:10 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 20:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 20:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:47:10 --> Final output sent to browser
DEBUG - 2016-02-24 20:47:10 --> Total execution time: 1.1811
INFO - 2016-02-24 17:47:13 --> Config Class Initialized
INFO - 2016-02-24 17:47:13 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:47:13 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:47:13 --> Utf8 Class Initialized
INFO - 2016-02-24 17:47:13 --> URI Class Initialized
INFO - 2016-02-24 17:47:13 --> Router Class Initialized
INFO - 2016-02-24 17:47:13 --> Output Class Initialized
INFO - 2016-02-24 17:47:13 --> Security Class Initialized
DEBUG - 2016-02-24 17:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:47:13 --> Input Class Initialized
INFO - 2016-02-24 17:47:13 --> Language Class Initialized
INFO - 2016-02-24 17:47:13 --> Loader Class Initialized
INFO - 2016-02-24 17:47:13 --> Helper loaded: url_helper
INFO - 2016-02-24 17:47:13 --> Helper loaded: file_helper
INFO - 2016-02-24 17:47:13 --> Helper loaded: date_helper
INFO - 2016-02-24 17:47:13 --> Helper loaded: form_helper
INFO - 2016-02-24 17:47:13 --> Database Driver Class Initialized
INFO - 2016-02-24 17:47:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:47:14 --> Controller Class Initialized
INFO - 2016-02-24 17:47:14 --> Model Class Initialized
INFO - 2016-02-24 17:47:15 --> Model Class Initialized
INFO - 2016-02-24 17:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:47:15 --> Pagination Class Initialized
INFO - 2016-02-24 17:47:15 --> Helper loaded: text_helper
INFO - 2016-02-24 17:47:15 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 20:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:47:15 --> Final output sent to browser
DEBUG - 2016-02-24 20:47:15 --> Total execution time: 1.1404
INFO - 2016-02-24 17:47:16 --> Config Class Initialized
INFO - 2016-02-24 17:47:16 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:47:16 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:47:16 --> Utf8 Class Initialized
INFO - 2016-02-24 17:47:16 --> URI Class Initialized
INFO - 2016-02-24 17:47:16 --> Router Class Initialized
INFO - 2016-02-24 17:47:16 --> Output Class Initialized
INFO - 2016-02-24 17:47:16 --> Security Class Initialized
DEBUG - 2016-02-24 17:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:47:16 --> Input Class Initialized
INFO - 2016-02-24 17:47:16 --> Language Class Initialized
INFO - 2016-02-24 17:47:16 --> Loader Class Initialized
INFO - 2016-02-24 17:47:16 --> Helper loaded: url_helper
INFO - 2016-02-24 17:47:16 --> Helper loaded: file_helper
INFO - 2016-02-24 17:47:16 --> Helper loaded: date_helper
INFO - 2016-02-24 17:47:16 --> Helper loaded: form_helper
INFO - 2016-02-24 17:47:16 --> Database Driver Class Initialized
INFO - 2016-02-24 17:47:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:47:17 --> Controller Class Initialized
INFO - 2016-02-24 17:47:17 --> Model Class Initialized
INFO - 2016-02-24 17:47:17 --> Model Class Initialized
INFO - 2016-02-24 17:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:47:17 --> Pagination Class Initialized
INFO - 2016-02-24 17:47:17 --> Helper loaded: text_helper
INFO - 2016-02-24 17:47:17 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 20:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 20:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:47:17 --> Final output sent to browser
DEBUG - 2016-02-24 20:47:17 --> Total execution time: 1.1595
INFO - 2016-02-24 17:47:20 --> Config Class Initialized
INFO - 2016-02-24 17:47:20 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:47:20 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:47:20 --> Utf8 Class Initialized
INFO - 2016-02-24 17:47:20 --> URI Class Initialized
INFO - 2016-02-24 17:47:20 --> Router Class Initialized
INFO - 2016-02-24 17:47:20 --> Output Class Initialized
INFO - 2016-02-24 17:47:20 --> Security Class Initialized
DEBUG - 2016-02-24 17:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:47:20 --> Input Class Initialized
INFO - 2016-02-24 17:47:20 --> Language Class Initialized
INFO - 2016-02-24 17:47:20 --> Loader Class Initialized
INFO - 2016-02-24 17:47:20 --> Helper loaded: url_helper
INFO - 2016-02-24 17:47:20 --> Helper loaded: file_helper
INFO - 2016-02-24 17:47:20 --> Helper loaded: date_helper
INFO - 2016-02-24 17:47:20 --> Helper loaded: form_helper
INFO - 2016-02-24 17:47:20 --> Database Driver Class Initialized
INFO - 2016-02-24 17:47:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:47:21 --> Controller Class Initialized
INFO - 2016-02-24 17:47:21 --> Model Class Initialized
INFO - 2016-02-24 17:47:21 --> Model Class Initialized
INFO - 2016-02-24 17:47:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:47:21 --> Pagination Class Initialized
INFO - 2016-02-24 17:47:21 --> Helper loaded: text_helper
INFO - 2016-02-24 17:47:21 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:47:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:47:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-24 20:47:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-24 20:47:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 20:47:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 20:47:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:47:21 --> Final output sent to browser
DEBUG - 2016-02-24 20:47:21 --> Total execution time: 1.2075
INFO - 2016-02-24 17:49:38 --> Config Class Initialized
INFO - 2016-02-24 17:49:38 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:49:38 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:49:38 --> Utf8 Class Initialized
INFO - 2016-02-24 17:49:38 --> URI Class Initialized
INFO - 2016-02-24 17:49:38 --> Router Class Initialized
INFO - 2016-02-24 17:49:38 --> Output Class Initialized
INFO - 2016-02-24 17:49:38 --> Security Class Initialized
DEBUG - 2016-02-24 17:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:49:38 --> Input Class Initialized
INFO - 2016-02-24 17:49:38 --> Language Class Initialized
INFO - 2016-02-24 17:49:38 --> Loader Class Initialized
INFO - 2016-02-24 17:49:38 --> Helper loaded: url_helper
INFO - 2016-02-24 17:49:38 --> Helper loaded: file_helper
INFO - 2016-02-24 17:49:38 --> Helper loaded: date_helper
INFO - 2016-02-24 17:49:38 --> Helper loaded: form_helper
INFO - 2016-02-24 17:49:38 --> Database Driver Class Initialized
INFO - 2016-02-24 17:49:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:49:39 --> Controller Class Initialized
INFO - 2016-02-24 17:49:39 --> Model Class Initialized
INFO - 2016-02-24 17:49:39 --> Model Class Initialized
INFO - 2016-02-24 17:49:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:49:39 --> Pagination Class Initialized
INFO - 2016-02-24 17:49:39 --> Helper loaded: text_helper
INFO - 2016-02-24 17:49:39 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-02-24 20:49:39 --> Severity: Notice --> Undefined variable: default_controller C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 107
INFO - 2016-02-24 20:49:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:49:39 --> Final output sent to browser
DEBUG - 2016-02-24 20:49:39 --> Total execution time: 1.1512
INFO - 2016-02-24 17:50:03 --> Config Class Initialized
INFO - 2016-02-24 17:50:03 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:50:03 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:50:03 --> Utf8 Class Initialized
INFO - 2016-02-24 17:50:03 --> URI Class Initialized
INFO - 2016-02-24 17:50:03 --> Router Class Initialized
INFO - 2016-02-24 17:50:03 --> Output Class Initialized
INFO - 2016-02-24 17:50:03 --> Security Class Initialized
DEBUG - 2016-02-24 17:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:50:03 --> Input Class Initialized
INFO - 2016-02-24 17:50:03 --> Language Class Initialized
ERROR - 2016-02-24 17:50:03 --> 404 Page Not Found: Wall/68
INFO - 2016-02-24 17:50:05 --> Config Class Initialized
INFO - 2016-02-24 17:50:05 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:50:05 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:50:05 --> Utf8 Class Initialized
INFO - 2016-02-24 17:50:05 --> URI Class Initialized
INFO - 2016-02-24 17:50:05 --> Router Class Initialized
INFO - 2016-02-24 17:50:05 --> Output Class Initialized
INFO - 2016-02-24 17:50:05 --> Security Class Initialized
DEBUG - 2016-02-24 17:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:50:05 --> Input Class Initialized
INFO - 2016-02-24 17:50:05 --> Language Class Initialized
INFO - 2016-02-24 17:50:05 --> Loader Class Initialized
INFO - 2016-02-24 17:50:05 --> Helper loaded: url_helper
INFO - 2016-02-24 17:50:05 --> Helper loaded: file_helper
INFO - 2016-02-24 17:50:05 --> Helper loaded: date_helper
INFO - 2016-02-24 17:50:05 --> Helper loaded: form_helper
INFO - 2016-02-24 17:50:05 --> Database Driver Class Initialized
INFO - 2016-02-24 17:50:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 17:50:06 --> Controller Class Initialized
INFO - 2016-02-24 17:50:06 --> Model Class Initialized
INFO - 2016-02-24 17:50:06 --> Model Class Initialized
INFO - 2016-02-24 17:50:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 17:50:06 --> Pagination Class Initialized
INFO - 2016-02-24 17:50:06 --> Helper loaded: text_helper
INFO - 2016-02-24 17:50:06 --> Helper loaded: cookie_helper
INFO - 2016-02-24 20:50:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 20:50:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 20:50:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 20:50:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 20:50:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 20:50:06 --> Final output sent to browser
DEBUG - 2016-02-24 20:50:06 --> Total execution time: 1.2277
INFO - 2016-02-24 17:50:09 --> Config Class Initialized
INFO - 2016-02-24 17:50:09 --> Hooks Class Initialized
DEBUG - 2016-02-24 17:50:09 --> UTF-8 Support Enabled
INFO - 2016-02-24 17:50:09 --> Utf8 Class Initialized
INFO - 2016-02-24 17:50:09 --> URI Class Initialized
INFO - 2016-02-24 17:50:09 --> Router Class Initialized
INFO - 2016-02-24 17:50:09 --> Output Class Initialized
INFO - 2016-02-24 17:50:09 --> Security Class Initialized
DEBUG - 2016-02-24 17:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 17:50:09 --> Input Class Initialized
INFO - 2016-02-24 17:50:09 --> Language Class Initialized
ERROR - 2016-02-24 17:50:09 --> 404 Page Not Found: Wall/68
INFO - 2016-02-24 18:03:59 --> Config Class Initialized
INFO - 2016-02-24 18:03:59 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:03:59 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:03:59 --> Utf8 Class Initialized
INFO - 2016-02-24 18:03:59 --> URI Class Initialized
INFO - 2016-02-24 18:03:59 --> Router Class Initialized
INFO - 2016-02-24 18:03:59 --> Output Class Initialized
INFO - 2016-02-24 18:03:59 --> Security Class Initialized
DEBUG - 2016-02-24 18:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:03:59 --> Input Class Initialized
INFO - 2016-02-24 18:03:59 --> Language Class Initialized
INFO - 2016-02-24 18:03:59 --> Loader Class Initialized
INFO - 2016-02-24 18:03:59 --> Helper loaded: url_helper
INFO - 2016-02-24 18:03:59 --> Helper loaded: file_helper
INFO - 2016-02-24 18:03:59 --> Helper loaded: date_helper
INFO - 2016-02-24 18:03:59 --> Helper loaded: form_helper
INFO - 2016-02-24 18:03:59 --> Database Driver Class Initialized
INFO - 2016-02-24 18:04:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:04:00 --> Controller Class Initialized
INFO - 2016-02-24 18:04:00 --> Model Class Initialized
INFO - 2016-02-24 18:04:00 --> Model Class Initialized
INFO - 2016-02-24 18:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:04:00 --> Pagination Class Initialized
INFO - 2016-02-24 18:04:00 --> Helper loaded: text_helper
INFO - 2016-02-24 18:04:00 --> Helper loaded: cookie_helper
ERROR - 2016-02-24 21:04:00 --> Severity: Warning --> Missing argument 1 for Wall::get(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 112 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 122
INFO - 2016-02-24 21:04:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:04:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 21:04:00 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 150
INFO - 2016-02-24 21:04:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:04:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:04:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:04:00 --> Final output sent to browser
DEBUG - 2016-02-24 21:04:00 --> Total execution time: 1.2430
INFO - 2016-02-24 18:04:21 --> Config Class Initialized
INFO - 2016-02-24 18:04:21 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:04:21 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:04:21 --> Utf8 Class Initialized
INFO - 2016-02-24 18:04:21 --> URI Class Initialized
INFO - 2016-02-24 18:04:21 --> Router Class Initialized
INFO - 2016-02-24 18:04:21 --> Output Class Initialized
INFO - 2016-02-24 18:04:21 --> Security Class Initialized
DEBUG - 2016-02-24 18:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:04:21 --> Input Class Initialized
INFO - 2016-02-24 18:04:21 --> Language Class Initialized
INFO - 2016-02-24 18:04:21 --> Loader Class Initialized
INFO - 2016-02-24 18:04:21 --> Helper loaded: url_helper
INFO - 2016-02-24 18:04:21 --> Helper loaded: file_helper
INFO - 2016-02-24 18:04:21 --> Helper loaded: date_helper
INFO - 2016-02-24 18:04:21 --> Helper loaded: form_helper
INFO - 2016-02-24 18:04:21 --> Database Driver Class Initialized
INFO - 2016-02-24 18:04:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:04:22 --> Controller Class Initialized
INFO - 2016-02-24 18:04:22 --> Model Class Initialized
INFO - 2016-02-24 18:04:22 --> Model Class Initialized
INFO - 2016-02-24 18:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:04:22 --> Pagination Class Initialized
INFO - 2016-02-24 18:04:22 --> Helper loaded: text_helper
INFO - 2016-02-24 18:04:22 --> Helper loaded: cookie_helper
ERROR - 2016-02-24 21:04:22 --> Severity: Error --> Call to undefined method Wall::default_method() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 116
INFO - 2016-02-24 18:05:07 --> Config Class Initialized
INFO - 2016-02-24 18:05:07 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:05:07 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:05:07 --> Utf8 Class Initialized
INFO - 2016-02-24 18:05:07 --> URI Class Initialized
INFO - 2016-02-24 18:05:07 --> Router Class Initialized
INFO - 2016-02-24 18:05:07 --> Output Class Initialized
INFO - 2016-02-24 18:05:07 --> Security Class Initialized
DEBUG - 2016-02-24 18:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:05:07 --> Input Class Initialized
INFO - 2016-02-24 18:05:07 --> Language Class Initialized
INFO - 2016-02-24 18:05:07 --> Loader Class Initialized
INFO - 2016-02-24 18:05:07 --> Helper loaded: url_helper
INFO - 2016-02-24 18:05:07 --> Helper loaded: file_helper
INFO - 2016-02-24 18:05:07 --> Helper loaded: date_helper
INFO - 2016-02-24 18:05:07 --> Helper loaded: form_helper
INFO - 2016-02-24 18:05:07 --> Database Driver Class Initialized
INFO - 2016-02-24 18:05:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:05:08 --> Controller Class Initialized
INFO - 2016-02-24 18:05:08 --> Model Class Initialized
INFO - 2016-02-24 18:05:08 --> Model Class Initialized
INFO - 2016-02-24 18:05:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:05:08 --> Pagination Class Initialized
INFO - 2016-02-24 18:05:08 --> Helper loaded: text_helper
INFO - 2016-02-24 18:05:08 --> Helper loaded: cookie_helper
ERROR - 2016-02-24 21:05:08 --> Severity: Warning --> Missing argument 1 for Wall::get(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 112 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 122
INFO - 2016-02-24 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 21:05:08 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 150
INFO - 2016-02-24 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:05:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:05:08 --> Final output sent to browser
DEBUG - 2016-02-24 21:05:08 --> Total execution time: 1.2326
INFO - 2016-02-24 18:05:10 --> Config Class Initialized
INFO - 2016-02-24 18:05:10 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:05:10 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:05:10 --> Utf8 Class Initialized
INFO - 2016-02-24 18:05:10 --> URI Class Initialized
INFO - 2016-02-24 18:05:10 --> Router Class Initialized
INFO - 2016-02-24 18:05:10 --> Output Class Initialized
INFO - 2016-02-24 18:05:10 --> Security Class Initialized
DEBUG - 2016-02-24 18:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:05:10 --> Input Class Initialized
INFO - 2016-02-24 18:05:10 --> Language Class Initialized
INFO - 2016-02-24 18:05:10 --> Loader Class Initialized
INFO - 2016-02-24 18:05:10 --> Helper loaded: url_helper
INFO - 2016-02-24 18:05:10 --> Helper loaded: file_helper
INFO - 2016-02-24 18:05:10 --> Helper loaded: date_helper
INFO - 2016-02-24 18:05:10 --> Helper loaded: form_helper
INFO - 2016-02-24 18:05:10 --> Database Driver Class Initialized
INFO - 2016-02-24 18:05:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:05:11 --> Controller Class Initialized
INFO - 2016-02-24 18:05:11 --> Model Class Initialized
INFO - 2016-02-24 18:05:11 --> Model Class Initialized
INFO - 2016-02-24 18:05:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:05:11 --> Pagination Class Initialized
INFO - 2016-02-24 18:05:11 --> Helper loaded: text_helper
INFO - 2016-02-24 18:05:11 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:05:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:05:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:05:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:05:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 21:05:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:05:11 --> Final output sent to browser
DEBUG - 2016-02-24 21:05:11 --> Total execution time: 1.2008
INFO - 2016-02-24 18:05:12 --> Config Class Initialized
INFO - 2016-02-24 18:05:12 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:05:12 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:05:12 --> Utf8 Class Initialized
INFO - 2016-02-24 18:05:12 --> URI Class Initialized
INFO - 2016-02-24 18:05:12 --> Router Class Initialized
INFO - 2016-02-24 18:05:12 --> Output Class Initialized
INFO - 2016-02-24 18:05:12 --> Security Class Initialized
DEBUG - 2016-02-24 18:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:05:12 --> Input Class Initialized
INFO - 2016-02-24 18:05:12 --> Language Class Initialized
INFO - 2016-02-24 18:05:12 --> Loader Class Initialized
INFO - 2016-02-24 18:05:12 --> Helper loaded: url_helper
INFO - 2016-02-24 18:05:12 --> Helper loaded: file_helper
INFO - 2016-02-24 18:05:12 --> Helper loaded: date_helper
INFO - 2016-02-24 18:05:12 --> Helper loaded: form_helper
INFO - 2016-02-24 18:05:12 --> Database Driver Class Initialized
INFO - 2016-02-24 18:05:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:05:13 --> Controller Class Initialized
INFO - 2016-02-24 18:05:13 --> Model Class Initialized
INFO - 2016-02-24 18:05:13 --> Model Class Initialized
INFO - 2016-02-24 18:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:05:13 --> Pagination Class Initialized
INFO - 2016-02-24 18:05:13 --> Helper loaded: text_helper
INFO - 2016-02-24 18:05:13 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:05:13 --> Final output sent to browser
DEBUG - 2016-02-24 21:05:13 --> Total execution time: 1.1235
INFO - 2016-02-24 18:09:04 --> Config Class Initialized
INFO - 2016-02-24 18:09:04 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:09:04 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:09:04 --> Utf8 Class Initialized
INFO - 2016-02-24 18:09:04 --> URI Class Initialized
INFO - 2016-02-24 18:09:04 --> Router Class Initialized
INFO - 2016-02-24 18:09:04 --> Output Class Initialized
INFO - 2016-02-24 18:09:04 --> Security Class Initialized
DEBUG - 2016-02-24 18:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:09:04 --> Input Class Initialized
INFO - 2016-02-24 18:09:04 --> Language Class Initialized
INFO - 2016-02-24 18:09:04 --> Loader Class Initialized
INFO - 2016-02-24 18:09:04 --> Helper loaded: url_helper
INFO - 2016-02-24 18:09:04 --> Helper loaded: file_helper
INFO - 2016-02-24 18:09:04 --> Helper loaded: date_helper
INFO - 2016-02-24 18:09:04 --> Helper loaded: form_helper
INFO - 2016-02-24 18:09:04 --> Database Driver Class Initialized
INFO - 2016-02-24 18:09:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:09:05 --> Controller Class Initialized
INFO - 2016-02-24 18:09:05 --> Model Class Initialized
INFO - 2016-02-24 18:09:05 --> Model Class Initialized
INFO - 2016-02-24 18:09:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:09:05 --> Pagination Class Initialized
INFO - 2016-02-24 18:09:05 --> Helper loaded: text_helper
INFO - 2016-02-24 18:09:05 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:09:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:09:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:09:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:09:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 21:09:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:09:05 --> Final output sent to browser
DEBUG - 2016-02-24 21:09:05 --> Total execution time: 1.1702
INFO - 2016-02-24 18:09:07 --> Config Class Initialized
INFO - 2016-02-24 18:09:07 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:09:07 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:09:07 --> Utf8 Class Initialized
INFO - 2016-02-24 18:09:07 --> URI Class Initialized
DEBUG - 2016-02-24 18:09:07 --> No URI present. Default controller set.
INFO - 2016-02-24 18:09:07 --> Router Class Initialized
INFO - 2016-02-24 18:09:07 --> Output Class Initialized
INFO - 2016-02-24 18:09:07 --> Security Class Initialized
DEBUG - 2016-02-24 18:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:09:07 --> Input Class Initialized
INFO - 2016-02-24 18:09:07 --> Language Class Initialized
INFO - 2016-02-24 18:09:07 --> Loader Class Initialized
INFO - 2016-02-24 18:09:07 --> Helper loaded: url_helper
INFO - 2016-02-24 18:09:07 --> Helper loaded: file_helper
INFO - 2016-02-24 18:09:07 --> Helper loaded: date_helper
INFO - 2016-02-24 18:09:07 --> Helper loaded: form_helper
INFO - 2016-02-24 18:09:07 --> Database Driver Class Initialized
INFO - 2016-02-24 18:09:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:09:08 --> Controller Class Initialized
INFO - 2016-02-24 18:09:08 --> Model Class Initialized
INFO - 2016-02-24 18:09:08 --> Model Class Initialized
INFO - 2016-02-24 18:09:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:09:08 --> Pagination Class Initialized
INFO - 2016-02-24 18:09:08 --> Helper loaded: text_helper
INFO - 2016-02-24 18:09:08 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 21:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:09:08 --> Final output sent to browser
DEBUG - 2016-02-24 21:09:08 --> Total execution time: 1.1507
INFO - 2016-02-24 18:09:09 --> Config Class Initialized
INFO - 2016-02-24 18:09:09 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:09:09 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:09:09 --> Utf8 Class Initialized
INFO - 2016-02-24 18:09:09 --> URI Class Initialized
INFO - 2016-02-24 18:09:09 --> Router Class Initialized
INFO - 2016-02-24 18:09:09 --> Output Class Initialized
INFO - 2016-02-24 18:09:09 --> Security Class Initialized
DEBUG - 2016-02-24 18:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:09:09 --> Input Class Initialized
INFO - 2016-02-24 18:09:09 --> Language Class Initialized
INFO - 2016-02-24 18:09:09 --> Loader Class Initialized
INFO - 2016-02-24 18:09:09 --> Helper loaded: url_helper
INFO - 2016-02-24 18:09:09 --> Helper loaded: file_helper
INFO - 2016-02-24 18:09:09 --> Helper loaded: date_helper
INFO - 2016-02-24 18:09:09 --> Helper loaded: form_helper
INFO - 2016-02-24 18:09:09 --> Database Driver Class Initialized
INFO - 2016-02-24 18:09:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:09:10 --> Controller Class Initialized
INFO - 2016-02-24 18:09:10 --> Model Class Initialized
INFO - 2016-02-24 18:09:10 --> Model Class Initialized
INFO - 2016-02-24 18:09:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:09:10 --> Pagination Class Initialized
INFO - 2016-02-24 18:09:10 --> Helper loaded: text_helper
INFO - 2016-02-24 18:09:10 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:09:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:09:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:09:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:09:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:09:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:09:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:09:10 --> Final output sent to browser
DEBUG - 2016-02-24 21:09:10 --> Total execution time: 1.1529
INFO - 2016-02-24 18:09:18 --> Config Class Initialized
INFO - 2016-02-24 18:09:18 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:09:18 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:09:18 --> Utf8 Class Initialized
INFO - 2016-02-24 18:09:18 --> URI Class Initialized
INFO - 2016-02-24 18:09:18 --> Router Class Initialized
INFO - 2016-02-24 18:09:18 --> Output Class Initialized
INFO - 2016-02-24 18:09:18 --> Security Class Initialized
DEBUG - 2016-02-24 18:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:09:18 --> Input Class Initialized
INFO - 2016-02-24 18:09:18 --> Language Class Initialized
INFO - 2016-02-24 18:09:18 --> Loader Class Initialized
INFO - 2016-02-24 18:09:18 --> Helper loaded: url_helper
INFO - 2016-02-24 18:09:18 --> Helper loaded: file_helper
INFO - 2016-02-24 18:09:18 --> Helper loaded: date_helper
INFO - 2016-02-24 18:09:18 --> Helper loaded: form_helper
INFO - 2016-02-24 18:09:18 --> Database Driver Class Initialized
INFO - 2016-02-24 18:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:09:19 --> Controller Class Initialized
INFO - 2016-02-24 18:09:19 --> Model Class Initialized
INFO - 2016-02-24 18:09:19 --> Model Class Initialized
INFO - 2016-02-24 18:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:09:19 --> Pagination Class Initialized
INFO - 2016-02-24 18:09:19 --> Helper loaded: text_helper
INFO - 2016-02-24 18:09:19 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 21:09:19 --> Severity: Warning --> Missing argument 1 for Wall::get(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 115 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 124
INFO - 2016-02-24 21:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-24 21:09:19 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 152
INFO - 2016-02-24 21:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:09:19 --> Final output sent to browser
DEBUG - 2016-02-24 21:09:19 --> Total execution time: 1.2113
INFO - 2016-02-24 18:10:19 --> Config Class Initialized
INFO - 2016-02-24 18:10:19 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:10:19 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:10:19 --> Utf8 Class Initialized
INFO - 2016-02-24 18:10:19 --> URI Class Initialized
INFO - 2016-02-24 18:10:19 --> Router Class Initialized
INFO - 2016-02-24 18:10:19 --> Output Class Initialized
INFO - 2016-02-24 18:10:19 --> Security Class Initialized
DEBUG - 2016-02-24 18:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:10:19 --> Input Class Initialized
INFO - 2016-02-24 18:10:19 --> Language Class Initialized
INFO - 2016-02-24 18:10:19 --> Loader Class Initialized
INFO - 2016-02-24 18:10:19 --> Helper loaded: url_helper
INFO - 2016-02-24 18:10:19 --> Helper loaded: file_helper
INFO - 2016-02-24 18:10:19 --> Helper loaded: date_helper
INFO - 2016-02-24 18:10:19 --> Helper loaded: form_helper
INFO - 2016-02-24 18:10:19 --> Database Driver Class Initialized
INFO - 2016-02-24 18:10:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:10:20 --> Controller Class Initialized
INFO - 2016-02-24 18:10:20 --> Model Class Initialized
INFO - 2016-02-24 18:10:20 --> Model Class Initialized
INFO - 2016-02-24 18:10:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:10:20 --> Pagination Class Initialized
INFO - 2016-02-24 18:10:20 --> Helper loaded: text_helper
INFO - 2016-02-24 18:10:20 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:10:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:10:20 --> Final output sent to browser
DEBUG - 2016-02-24 21:10:20 --> Total execution time: 1.1605
INFO - 2016-02-24 18:10:48 --> Config Class Initialized
INFO - 2016-02-24 18:10:48 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:10:48 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:10:48 --> Utf8 Class Initialized
INFO - 2016-02-24 18:10:48 --> URI Class Initialized
INFO - 2016-02-24 18:10:48 --> Router Class Initialized
INFO - 2016-02-24 18:10:48 --> Output Class Initialized
INFO - 2016-02-24 18:10:48 --> Security Class Initialized
DEBUG - 2016-02-24 18:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:10:48 --> Input Class Initialized
INFO - 2016-02-24 18:10:48 --> Language Class Initialized
INFO - 2016-02-24 18:10:49 --> Loader Class Initialized
INFO - 2016-02-24 18:10:49 --> Helper loaded: url_helper
INFO - 2016-02-24 18:10:49 --> Helper loaded: file_helper
INFO - 2016-02-24 18:10:49 --> Helper loaded: date_helper
INFO - 2016-02-24 18:10:49 --> Helper loaded: form_helper
INFO - 2016-02-24 18:10:49 --> Database Driver Class Initialized
INFO - 2016-02-24 18:10:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:10:50 --> Controller Class Initialized
INFO - 2016-02-24 18:10:50 --> Model Class Initialized
INFO - 2016-02-24 18:10:50 --> Model Class Initialized
INFO - 2016-02-24 18:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:10:50 --> Pagination Class Initialized
INFO - 2016-02-24 18:10:50 --> Helper loaded: text_helper
INFO - 2016-02-24 18:10:50 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:10:50 --> Final output sent to browser
DEBUG - 2016-02-24 21:10:50 --> Total execution time: 1.2683
INFO - 2016-02-24 18:10:51 --> Config Class Initialized
INFO - 2016-02-24 18:10:51 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:10:51 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:10:51 --> Utf8 Class Initialized
INFO - 2016-02-24 18:10:51 --> URI Class Initialized
INFO - 2016-02-24 18:10:51 --> Router Class Initialized
INFO - 2016-02-24 18:10:51 --> Output Class Initialized
INFO - 2016-02-24 18:10:51 --> Security Class Initialized
DEBUG - 2016-02-24 18:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:10:51 --> Input Class Initialized
INFO - 2016-02-24 18:10:51 --> Language Class Initialized
INFO - 2016-02-24 18:10:51 --> Loader Class Initialized
INFO - 2016-02-24 18:10:51 --> Helper loaded: url_helper
INFO - 2016-02-24 18:10:51 --> Helper loaded: file_helper
INFO - 2016-02-24 18:10:51 --> Helper loaded: date_helper
INFO - 2016-02-24 18:10:51 --> Helper loaded: form_helper
INFO - 2016-02-24 18:10:51 --> Database Driver Class Initialized
INFO - 2016-02-24 18:10:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:10:52 --> Controller Class Initialized
INFO - 2016-02-24 18:10:52 --> Model Class Initialized
INFO - 2016-02-24 18:10:52 --> Model Class Initialized
INFO - 2016-02-24 18:10:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:10:52 --> Pagination Class Initialized
INFO - 2016-02-24 18:10:52 --> Helper loaded: text_helper
INFO - 2016-02-24 18:10:52 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:10:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:10:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:10:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:10:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:10:52 --> Final output sent to browser
DEBUG - 2016-02-24 21:10:52 --> Total execution time: 1.1402
INFO - 2016-02-24 18:10:54 --> Config Class Initialized
INFO - 2016-02-24 18:10:54 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:10:54 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:10:54 --> Utf8 Class Initialized
INFO - 2016-02-24 18:10:54 --> URI Class Initialized
INFO - 2016-02-24 18:10:54 --> Router Class Initialized
INFO - 2016-02-24 18:10:54 --> Output Class Initialized
INFO - 2016-02-24 18:10:54 --> Security Class Initialized
DEBUG - 2016-02-24 18:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:10:54 --> Input Class Initialized
INFO - 2016-02-24 18:10:54 --> Language Class Initialized
INFO - 2016-02-24 18:10:54 --> Loader Class Initialized
INFO - 2016-02-24 18:10:54 --> Helper loaded: url_helper
INFO - 2016-02-24 18:10:54 --> Helper loaded: file_helper
INFO - 2016-02-24 18:10:54 --> Helper loaded: date_helper
INFO - 2016-02-24 18:10:54 --> Helper loaded: form_helper
INFO - 2016-02-24 18:10:54 --> Database Driver Class Initialized
INFO - 2016-02-24 18:10:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:10:55 --> Controller Class Initialized
INFO - 2016-02-24 18:10:55 --> Model Class Initialized
INFO - 2016-02-24 18:10:55 --> Model Class Initialized
INFO - 2016-02-24 18:10:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:10:55 --> Pagination Class Initialized
INFO - 2016-02-24 18:10:55 --> Helper loaded: text_helper
INFO - 2016-02-24 18:10:55 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:10:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:10:55 --> Final output sent to browser
DEBUG - 2016-02-24 21:10:55 --> Total execution time: 1.1541
INFO - 2016-02-24 18:11:28 --> Config Class Initialized
INFO - 2016-02-24 18:11:28 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:11:28 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:11:28 --> Utf8 Class Initialized
INFO - 2016-02-24 18:11:28 --> URI Class Initialized
DEBUG - 2016-02-24 18:11:28 --> No URI present. Default controller set.
INFO - 2016-02-24 18:11:28 --> Router Class Initialized
INFO - 2016-02-24 18:11:28 --> Output Class Initialized
INFO - 2016-02-24 18:11:28 --> Security Class Initialized
DEBUG - 2016-02-24 18:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:11:28 --> Input Class Initialized
INFO - 2016-02-24 18:11:28 --> Language Class Initialized
INFO - 2016-02-24 18:11:28 --> Loader Class Initialized
INFO - 2016-02-24 18:11:28 --> Helper loaded: url_helper
INFO - 2016-02-24 18:11:28 --> Helper loaded: file_helper
INFO - 2016-02-24 18:11:28 --> Helper loaded: date_helper
INFO - 2016-02-24 18:11:28 --> Helper loaded: form_helper
INFO - 2016-02-24 18:11:28 --> Database Driver Class Initialized
INFO - 2016-02-24 18:11:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:11:29 --> Controller Class Initialized
INFO - 2016-02-24 18:11:29 --> Model Class Initialized
INFO - 2016-02-24 18:11:29 --> Model Class Initialized
INFO - 2016-02-24 18:11:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:11:29 --> Pagination Class Initialized
INFO - 2016-02-24 18:11:29 --> Helper loaded: text_helper
INFO - 2016-02-24 18:11:29 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 21:11:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:11:29 --> Final output sent to browser
DEBUG - 2016-02-24 21:11:29 --> Total execution time: 1.1576
INFO - 2016-02-24 18:11:31 --> Config Class Initialized
INFO - 2016-02-24 18:11:31 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:11:31 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:11:31 --> Utf8 Class Initialized
INFO - 2016-02-24 18:11:31 --> URI Class Initialized
INFO - 2016-02-24 18:11:31 --> Router Class Initialized
INFO - 2016-02-24 18:11:31 --> Output Class Initialized
INFO - 2016-02-24 18:11:31 --> Security Class Initialized
DEBUG - 2016-02-24 18:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:11:31 --> Input Class Initialized
INFO - 2016-02-24 18:11:31 --> Language Class Initialized
INFO - 2016-02-24 18:11:31 --> Loader Class Initialized
INFO - 2016-02-24 18:11:31 --> Helper loaded: url_helper
INFO - 2016-02-24 18:11:31 --> Helper loaded: file_helper
INFO - 2016-02-24 18:11:31 --> Helper loaded: date_helper
INFO - 2016-02-24 18:11:31 --> Helper loaded: form_helper
INFO - 2016-02-24 18:11:31 --> Database Driver Class Initialized
INFO - 2016-02-24 18:11:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:11:32 --> Controller Class Initialized
INFO - 2016-02-24 18:11:32 --> Model Class Initialized
INFO - 2016-02-24 18:11:32 --> Model Class Initialized
INFO - 2016-02-24 18:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:11:32 --> Pagination Class Initialized
INFO - 2016-02-24 18:11:32 --> Helper loaded: text_helper
INFO - 2016-02-24 18:11:32 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:11:32 --> Final output sent to browser
DEBUG - 2016-02-24 21:11:32 --> Total execution time: 1.1672
INFO - 2016-02-24 18:11:33 --> Config Class Initialized
INFO - 2016-02-24 18:11:33 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:11:33 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:11:33 --> Utf8 Class Initialized
INFO - 2016-02-24 18:11:33 --> URI Class Initialized
INFO - 2016-02-24 18:11:33 --> Router Class Initialized
INFO - 2016-02-24 18:11:33 --> Output Class Initialized
INFO - 2016-02-24 18:11:33 --> Security Class Initialized
DEBUG - 2016-02-24 18:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:11:33 --> Input Class Initialized
INFO - 2016-02-24 18:11:33 --> Language Class Initialized
INFO - 2016-02-24 18:11:33 --> Loader Class Initialized
INFO - 2016-02-24 18:11:33 --> Helper loaded: url_helper
INFO - 2016-02-24 18:11:33 --> Helper loaded: file_helper
INFO - 2016-02-24 18:11:33 --> Helper loaded: date_helper
INFO - 2016-02-24 18:11:33 --> Helper loaded: form_helper
INFO - 2016-02-24 18:11:33 --> Database Driver Class Initialized
INFO - 2016-02-24 18:11:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:11:34 --> Controller Class Initialized
INFO - 2016-02-24 18:11:34 --> Model Class Initialized
INFO - 2016-02-24 18:11:34 --> Model Class Initialized
INFO - 2016-02-24 18:11:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:11:34 --> Pagination Class Initialized
INFO - 2016-02-24 18:11:34 --> Helper loaded: text_helper
INFO - 2016-02-24 18:11:34 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:11:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:11:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:11:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:11:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:11:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:11:35 --> Final output sent to browser
DEBUG - 2016-02-24 21:11:35 --> Total execution time: 1.2045
INFO - 2016-02-24 18:11:39 --> Config Class Initialized
INFO - 2016-02-24 18:11:39 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:11:39 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:11:39 --> Utf8 Class Initialized
INFO - 2016-02-24 18:11:39 --> URI Class Initialized
INFO - 2016-02-24 18:11:39 --> Router Class Initialized
INFO - 2016-02-24 18:11:39 --> Output Class Initialized
INFO - 2016-02-24 18:11:39 --> Security Class Initialized
DEBUG - 2016-02-24 18:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:11:39 --> Input Class Initialized
INFO - 2016-02-24 18:11:39 --> Language Class Initialized
INFO - 2016-02-24 18:11:39 --> Loader Class Initialized
INFO - 2016-02-24 18:11:39 --> Helper loaded: url_helper
INFO - 2016-02-24 18:11:39 --> Helper loaded: file_helper
INFO - 2016-02-24 18:11:39 --> Helper loaded: date_helper
INFO - 2016-02-24 18:11:39 --> Helper loaded: form_helper
INFO - 2016-02-24 18:11:39 --> Database Driver Class Initialized
INFO - 2016-02-24 18:11:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:11:41 --> Controller Class Initialized
INFO - 2016-02-24 18:11:41 --> Model Class Initialized
INFO - 2016-02-24 18:11:41 --> Model Class Initialized
INFO - 2016-02-24 18:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:11:41 --> Pagination Class Initialized
INFO - 2016-02-24 18:11:41 --> Helper loaded: text_helper
INFO - 2016-02-24 18:11:41 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:11:41 --> Final output sent to browser
DEBUG - 2016-02-24 21:11:41 --> Total execution time: 1.2012
INFO - 2016-02-24 18:11:44 --> Config Class Initialized
INFO - 2016-02-24 18:11:44 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:11:44 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:11:44 --> Utf8 Class Initialized
INFO - 2016-02-24 18:11:44 --> URI Class Initialized
INFO - 2016-02-24 18:11:44 --> Router Class Initialized
INFO - 2016-02-24 18:11:44 --> Output Class Initialized
INFO - 2016-02-24 18:11:44 --> Security Class Initialized
DEBUG - 2016-02-24 18:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:11:44 --> Input Class Initialized
INFO - 2016-02-24 18:11:44 --> Language Class Initialized
INFO - 2016-02-24 18:11:44 --> Loader Class Initialized
INFO - 2016-02-24 18:11:44 --> Helper loaded: url_helper
INFO - 2016-02-24 18:11:44 --> Helper loaded: file_helper
INFO - 2016-02-24 18:11:44 --> Helper loaded: date_helper
INFO - 2016-02-24 18:11:44 --> Helper loaded: form_helper
INFO - 2016-02-24 18:11:44 --> Database Driver Class Initialized
INFO - 2016-02-24 18:11:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:11:45 --> Controller Class Initialized
INFO - 2016-02-24 18:11:45 --> Model Class Initialized
INFO - 2016-02-24 18:11:45 --> Model Class Initialized
INFO - 2016-02-24 18:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:11:45 --> Pagination Class Initialized
INFO - 2016-02-24 18:11:45 --> Helper loaded: text_helper
INFO - 2016-02-24 18:11:45 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:11:45 --> Final output sent to browser
DEBUG - 2016-02-24 21:11:45 --> Total execution time: 1.1866
INFO - 2016-02-24 18:11:51 --> Config Class Initialized
INFO - 2016-02-24 18:11:51 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:11:51 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:11:51 --> Utf8 Class Initialized
INFO - 2016-02-24 18:11:51 --> URI Class Initialized
INFO - 2016-02-24 18:11:51 --> Router Class Initialized
INFO - 2016-02-24 18:11:51 --> Output Class Initialized
INFO - 2016-02-24 18:11:51 --> Security Class Initialized
DEBUG - 2016-02-24 18:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:11:51 --> Input Class Initialized
INFO - 2016-02-24 18:11:51 --> Language Class Initialized
INFO - 2016-02-24 18:11:51 --> Loader Class Initialized
INFO - 2016-02-24 18:11:51 --> Helper loaded: url_helper
INFO - 2016-02-24 18:11:51 --> Helper loaded: file_helper
INFO - 2016-02-24 18:11:51 --> Helper loaded: date_helper
INFO - 2016-02-24 18:11:51 --> Helper loaded: form_helper
INFO - 2016-02-24 18:11:51 --> Database Driver Class Initialized
INFO - 2016-02-24 18:11:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:11:52 --> Controller Class Initialized
INFO - 2016-02-24 18:11:52 --> Model Class Initialized
INFO - 2016-02-24 18:11:52 --> Model Class Initialized
INFO - 2016-02-24 18:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:11:52 --> Pagination Class Initialized
INFO - 2016-02-24 18:11:52 --> Helper loaded: text_helper
INFO - 2016-02-24 18:11:52 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:11:52 --> Final output sent to browser
DEBUG - 2016-02-24 21:11:52 --> Total execution time: 1.1709
INFO - 2016-02-24 18:12:02 --> Config Class Initialized
INFO - 2016-02-24 18:12:02 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:12:02 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:12:02 --> Utf8 Class Initialized
INFO - 2016-02-24 18:12:02 --> URI Class Initialized
INFO - 2016-02-24 18:12:02 --> Router Class Initialized
INFO - 2016-02-24 18:12:02 --> Output Class Initialized
INFO - 2016-02-24 18:12:02 --> Security Class Initialized
DEBUG - 2016-02-24 18:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:12:02 --> Input Class Initialized
INFO - 2016-02-24 18:12:02 --> Language Class Initialized
INFO - 2016-02-24 18:12:02 --> Loader Class Initialized
INFO - 2016-02-24 18:12:02 --> Helper loaded: url_helper
INFO - 2016-02-24 18:12:02 --> Helper loaded: file_helper
INFO - 2016-02-24 18:12:02 --> Helper loaded: date_helper
INFO - 2016-02-24 18:12:02 --> Helper loaded: form_helper
INFO - 2016-02-24 18:12:02 --> Database Driver Class Initialized
INFO - 2016-02-24 18:12:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:12:03 --> Controller Class Initialized
INFO - 2016-02-24 18:12:03 --> Model Class Initialized
INFO - 2016-02-24 18:12:03 --> Model Class Initialized
INFO - 2016-02-24 18:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:12:03 --> Pagination Class Initialized
INFO - 2016-02-24 18:12:03 --> Helper loaded: text_helper
INFO - 2016-02-24 18:12:03 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:12:03 --> Final output sent to browser
DEBUG - 2016-02-24 21:12:03 --> Total execution time: 1.1606
INFO - 2016-02-24 18:12:05 --> Config Class Initialized
INFO - 2016-02-24 18:12:05 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:12:05 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:12:05 --> Utf8 Class Initialized
INFO - 2016-02-24 18:12:05 --> URI Class Initialized
INFO - 2016-02-24 18:12:05 --> Router Class Initialized
INFO - 2016-02-24 18:12:05 --> Output Class Initialized
INFO - 2016-02-24 18:12:05 --> Security Class Initialized
DEBUG - 2016-02-24 18:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:12:05 --> Input Class Initialized
INFO - 2016-02-24 18:12:05 --> Language Class Initialized
INFO - 2016-02-24 18:12:05 --> Loader Class Initialized
INFO - 2016-02-24 18:12:05 --> Helper loaded: url_helper
INFO - 2016-02-24 18:12:05 --> Helper loaded: file_helper
INFO - 2016-02-24 18:12:05 --> Helper loaded: date_helper
INFO - 2016-02-24 18:12:05 --> Helper loaded: form_helper
INFO - 2016-02-24 18:12:05 --> Database Driver Class Initialized
INFO - 2016-02-24 18:12:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:12:06 --> Controller Class Initialized
INFO - 2016-02-24 18:12:06 --> Model Class Initialized
INFO - 2016-02-24 18:12:06 --> Model Class Initialized
INFO - 2016-02-24 18:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:12:06 --> Pagination Class Initialized
INFO - 2016-02-24 18:12:06 --> Helper loaded: text_helper
INFO - 2016-02-24 18:12:06 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:12:06 --> Final output sent to browser
DEBUG - 2016-02-24 21:12:06 --> Total execution time: 1.2220
INFO - 2016-02-24 18:12:10 --> Config Class Initialized
INFO - 2016-02-24 18:12:10 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:12:10 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:12:10 --> Utf8 Class Initialized
INFO - 2016-02-24 18:12:10 --> URI Class Initialized
INFO - 2016-02-24 18:12:10 --> Router Class Initialized
INFO - 2016-02-24 18:12:10 --> Output Class Initialized
INFO - 2016-02-24 18:12:10 --> Security Class Initialized
DEBUG - 2016-02-24 18:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:12:10 --> Input Class Initialized
INFO - 2016-02-24 18:12:10 --> Language Class Initialized
INFO - 2016-02-24 18:12:10 --> Loader Class Initialized
INFO - 2016-02-24 18:12:10 --> Helper loaded: url_helper
INFO - 2016-02-24 18:12:10 --> Helper loaded: file_helper
INFO - 2016-02-24 18:12:10 --> Helper loaded: date_helper
INFO - 2016-02-24 18:12:10 --> Helper loaded: form_helper
INFO - 2016-02-24 18:12:10 --> Database Driver Class Initialized
INFO - 2016-02-24 18:12:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:12:11 --> Controller Class Initialized
INFO - 2016-02-24 18:12:11 --> Model Class Initialized
INFO - 2016-02-24 18:12:11 --> Model Class Initialized
INFO - 2016-02-24 18:12:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:12:11 --> Pagination Class Initialized
INFO - 2016-02-24 18:12:11 --> Helper loaded: text_helper
INFO - 2016-02-24 18:12:11 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:12:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:12:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:12:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:12:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:12:12 --> Final output sent to browser
DEBUG - 2016-02-24 21:12:12 --> Total execution time: 1.2381
INFO - 2016-02-24 18:12:30 --> Config Class Initialized
INFO - 2016-02-24 18:12:30 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:12:30 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:12:30 --> Utf8 Class Initialized
INFO - 2016-02-24 18:12:30 --> URI Class Initialized
INFO - 2016-02-24 18:12:30 --> Router Class Initialized
INFO - 2016-02-24 18:12:30 --> Output Class Initialized
INFO - 2016-02-24 18:12:30 --> Security Class Initialized
DEBUG - 2016-02-24 18:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:12:30 --> Input Class Initialized
INFO - 2016-02-24 18:12:30 --> Language Class Initialized
INFO - 2016-02-24 18:12:30 --> Loader Class Initialized
INFO - 2016-02-24 18:12:30 --> Helper loaded: url_helper
INFO - 2016-02-24 18:12:30 --> Helper loaded: file_helper
INFO - 2016-02-24 18:12:30 --> Helper loaded: date_helper
INFO - 2016-02-24 18:12:30 --> Helper loaded: form_helper
INFO - 2016-02-24 18:12:30 --> Database Driver Class Initialized
INFO - 2016-02-24 18:12:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:12:31 --> Controller Class Initialized
INFO - 2016-02-24 18:12:31 --> Model Class Initialized
INFO - 2016-02-24 18:12:31 --> Model Class Initialized
INFO - 2016-02-24 18:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:12:31 --> Pagination Class Initialized
INFO - 2016-02-24 18:12:31 --> Helper loaded: text_helper
INFO - 2016-02-24 18:12:31 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:12:31 --> Final output sent to browser
DEBUG - 2016-02-24 21:12:31 --> Total execution time: 1.1133
INFO - 2016-02-24 18:12:33 --> Config Class Initialized
INFO - 2016-02-24 18:12:33 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:12:33 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:12:33 --> Utf8 Class Initialized
INFO - 2016-02-24 18:12:33 --> URI Class Initialized
INFO - 2016-02-24 18:12:33 --> Router Class Initialized
INFO - 2016-02-24 18:12:33 --> Output Class Initialized
INFO - 2016-02-24 18:12:33 --> Security Class Initialized
DEBUG - 2016-02-24 18:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:12:33 --> Input Class Initialized
INFO - 2016-02-24 18:12:33 --> Language Class Initialized
INFO - 2016-02-24 18:12:33 --> Loader Class Initialized
INFO - 2016-02-24 18:12:33 --> Helper loaded: url_helper
INFO - 2016-02-24 18:12:33 --> Helper loaded: file_helper
INFO - 2016-02-24 18:12:33 --> Helper loaded: date_helper
INFO - 2016-02-24 18:12:33 --> Helper loaded: form_helper
INFO - 2016-02-24 18:12:33 --> Database Driver Class Initialized
INFO - 2016-02-24 18:12:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:12:34 --> Controller Class Initialized
INFO - 2016-02-24 18:12:34 --> Model Class Initialized
INFO - 2016-02-24 18:12:34 --> Model Class Initialized
INFO - 2016-02-24 18:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:12:34 --> Pagination Class Initialized
INFO - 2016-02-24 18:12:34 --> Helper loaded: text_helper
INFO - 2016-02-24 18:12:34 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:12:34 --> Final output sent to browser
DEBUG - 2016-02-24 21:12:34 --> Total execution time: 1.2908
INFO - 2016-02-24 18:12:39 --> Config Class Initialized
INFO - 2016-02-24 18:12:39 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:12:39 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:12:39 --> Utf8 Class Initialized
INFO - 2016-02-24 18:12:39 --> URI Class Initialized
INFO - 2016-02-24 18:12:39 --> Router Class Initialized
INFO - 2016-02-24 18:12:39 --> Output Class Initialized
INFO - 2016-02-24 18:12:39 --> Security Class Initialized
DEBUG - 2016-02-24 18:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:12:39 --> Input Class Initialized
INFO - 2016-02-24 18:12:39 --> Language Class Initialized
INFO - 2016-02-24 18:12:39 --> Loader Class Initialized
INFO - 2016-02-24 18:12:39 --> Helper loaded: url_helper
INFO - 2016-02-24 18:12:39 --> Helper loaded: file_helper
INFO - 2016-02-24 18:12:39 --> Helper loaded: date_helper
INFO - 2016-02-24 18:12:39 --> Helper loaded: form_helper
INFO - 2016-02-24 18:12:39 --> Database Driver Class Initialized
INFO - 2016-02-24 18:12:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:12:40 --> Controller Class Initialized
INFO - 2016-02-24 18:12:40 --> Model Class Initialized
INFO - 2016-02-24 18:12:40 --> Model Class Initialized
INFO - 2016-02-24 18:12:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:12:40 --> Pagination Class Initialized
INFO - 2016-02-24 18:12:40 --> Helper loaded: text_helper
INFO - 2016-02-24 18:12:40 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:12:40 --> Final output sent to browser
DEBUG - 2016-02-24 21:12:40 --> Total execution time: 1.1162
INFO - 2016-02-24 18:12:51 --> Config Class Initialized
INFO - 2016-02-24 18:12:51 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:12:51 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:12:51 --> Utf8 Class Initialized
INFO - 2016-02-24 18:12:51 --> URI Class Initialized
INFO - 2016-02-24 18:12:51 --> Router Class Initialized
INFO - 2016-02-24 18:12:51 --> Output Class Initialized
INFO - 2016-02-24 18:12:51 --> Security Class Initialized
DEBUG - 2016-02-24 18:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:12:51 --> Input Class Initialized
INFO - 2016-02-24 18:12:51 --> Language Class Initialized
INFO - 2016-02-24 18:12:51 --> Loader Class Initialized
INFO - 2016-02-24 18:12:51 --> Helper loaded: url_helper
INFO - 2016-02-24 18:12:51 --> Helper loaded: file_helper
INFO - 2016-02-24 18:12:51 --> Helper loaded: date_helper
INFO - 2016-02-24 18:12:51 --> Helper loaded: form_helper
INFO - 2016-02-24 18:12:51 --> Database Driver Class Initialized
INFO - 2016-02-24 18:12:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:12:52 --> Controller Class Initialized
INFO - 2016-02-24 18:12:52 --> Model Class Initialized
INFO - 2016-02-24 18:12:52 --> Model Class Initialized
INFO - 2016-02-24 18:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:12:52 --> Pagination Class Initialized
INFO - 2016-02-24 18:12:52 --> Helper loaded: text_helper
INFO - 2016-02-24 18:12:52 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:12:52 --> Final output sent to browser
DEBUG - 2016-02-24 21:12:52 --> Total execution time: 1.1744
INFO - 2016-02-24 18:12:56 --> Config Class Initialized
INFO - 2016-02-24 18:12:56 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:12:56 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:12:56 --> Utf8 Class Initialized
INFO - 2016-02-24 18:12:56 --> URI Class Initialized
INFO - 2016-02-24 18:12:56 --> Router Class Initialized
INFO - 2016-02-24 18:12:56 --> Output Class Initialized
INFO - 2016-02-24 18:12:56 --> Security Class Initialized
DEBUG - 2016-02-24 18:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:12:56 --> Input Class Initialized
INFO - 2016-02-24 18:12:56 --> Language Class Initialized
INFO - 2016-02-24 18:12:56 --> Loader Class Initialized
INFO - 2016-02-24 18:12:56 --> Helper loaded: url_helper
INFO - 2016-02-24 18:12:56 --> Helper loaded: file_helper
INFO - 2016-02-24 18:12:56 --> Helper loaded: date_helper
INFO - 2016-02-24 18:12:56 --> Helper loaded: form_helper
INFO - 2016-02-24 18:12:56 --> Database Driver Class Initialized
INFO - 2016-02-24 18:12:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:12:57 --> Controller Class Initialized
INFO - 2016-02-24 18:12:57 --> Model Class Initialized
INFO - 2016-02-24 18:12:57 --> Model Class Initialized
INFO - 2016-02-24 18:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:12:57 --> Pagination Class Initialized
INFO - 2016-02-24 18:12:57 --> Helper loaded: text_helper
INFO - 2016-02-24 18:12:57 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:12:57 --> Final output sent to browser
DEBUG - 2016-02-24 21:12:57 --> Total execution time: 1.1452
INFO - 2016-02-24 18:13:02 --> Config Class Initialized
INFO - 2016-02-24 18:13:02 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:13:02 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:13:02 --> Utf8 Class Initialized
INFO - 2016-02-24 18:13:02 --> URI Class Initialized
INFO - 2016-02-24 18:13:02 --> Router Class Initialized
INFO - 2016-02-24 18:13:02 --> Output Class Initialized
INFO - 2016-02-24 18:13:02 --> Security Class Initialized
DEBUG - 2016-02-24 18:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:13:02 --> Input Class Initialized
INFO - 2016-02-24 18:13:02 --> Language Class Initialized
INFO - 2016-02-24 18:13:02 --> Loader Class Initialized
INFO - 2016-02-24 18:13:02 --> Helper loaded: url_helper
INFO - 2016-02-24 18:13:02 --> Helper loaded: file_helper
INFO - 2016-02-24 18:13:02 --> Helper loaded: date_helper
INFO - 2016-02-24 18:13:02 --> Helper loaded: form_helper
INFO - 2016-02-24 18:13:02 --> Database Driver Class Initialized
INFO - 2016-02-24 18:13:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:13:03 --> Controller Class Initialized
INFO - 2016-02-24 18:13:03 --> Model Class Initialized
INFO - 2016-02-24 18:13:03 --> Model Class Initialized
INFO - 2016-02-24 18:13:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:13:03 --> Pagination Class Initialized
INFO - 2016-02-24 18:13:03 --> Helper loaded: text_helper
INFO - 2016-02-24 18:13:03 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:13:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:13:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:13:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:13:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:13:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:13:03 --> Final output sent to browser
DEBUG - 2016-02-24 21:13:03 --> Total execution time: 1.1598
INFO - 2016-02-24 18:13:04 --> Config Class Initialized
INFO - 2016-02-24 18:13:04 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:13:04 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:13:04 --> Utf8 Class Initialized
INFO - 2016-02-24 18:13:04 --> URI Class Initialized
INFO - 2016-02-24 18:13:04 --> Router Class Initialized
INFO - 2016-02-24 18:13:04 --> Output Class Initialized
INFO - 2016-02-24 18:13:04 --> Security Class Initialized
DEBUG - 2016-02-24 18:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:13:04 --> Input Class Initialized
INFO - 2016-02-24 18:13:04 --> Language Class Initialized
INFO - 2016-02-24 18:13:04 --> Loader Class Initialized
INFO - 2016-02-24 18:13:04 --> Helper loaded: url_helper
INFO - 2016-02-24 18:13:04 --> Helper loaded: file_helper
INFO - 2016-02-24 18:13:04 --> Helper loaded: date_helper
INFO - 2016-02-24 18:13:04 --> Helper loaded: form_helper
INFO - 2016-02-24 18:13:04 --> Database Driver Class Initialized
INFO - 2016-02-24 18:13:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:13:06 --> Controller Class Initialized
INFO - 2016-02-24 18:13:06 --> Model Class Initialized
INFO - 2016-02-24 18:13:06 --> Model Class Initialized
INFO - 2016-02-24 18:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:13:06 --> Pagination Class Initialized
INFO - 2016-02-24 18:13:06 --> Helper loaded: text_helper
INFO - 2016-02-24 18:13:06 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:13:06 --> Final output sent to browser
DEBUG - 2016-02-24 21:13:06 --> Total execution time: 1.1432
INFO - 2016-02-24 18:13:07 --> Config Class Initialized
INFO - 2016-02-24 18:13:07 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:13:07 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:13:07 --> Utf8 Class Initialized
INFO - 2016-02-24 18:13:07 --> URI Class Initialized
INFO - 2016-02-24 18:13:07 --> Router Class Initialized
INFO - 2016-02-24 18:13:07 --> Output Class Initialized
INFO - 2016-02-24 18:13:07 --> Security Class Initialized
DEBUG - 2016-02-24 18:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:13:07 --> Input Class Initialized
INFO - 2016-02-24 18:13:07 --> Language Class Initialized
INFO - 2016-02-24 18:13:07 --> Loader Class Initialized
INFO - 2016-02-24 18:13:07 --> Helper loaded: url_helper
INFO - 2016-02-24 18:13:07 --> Helper loaded: file_helper
INFO - 2016-02-24 18:13:07 --> Helper loaded: date_helper
INFO - 2016-02-24 18:13:07 --> Helper loaded: form_helper
INFO - 2016-02-24 18:13:07 --> Database Driver Class Initialized
INFO - 2016-02-24 18:13:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:13:08 --> Controller Class Initialized
INFO - 2016-02-24 18:13:08 --> Model Class Initialized
INFO - 2016-02-24 18:13:08 --> Model Class Initialized
INFO - 2016-02-24 18:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:13:08 --> Pagination Class Initialized
INFO - 2016-02-24 18:13:08 --> Helper loaded: text_helper
INFO - 2016-02-24 18:13:08 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:13:08 --> Final output sent to browser
DEBUG - 2016-02-24 21:13:08 --> Total execution time: 1.2259
INFO - 2016-02-24 18:13:11 --> Config Class Initialized
INFO - 2016-02-24 18:13:11 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:13:11 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:13:11 --> Utf8 Class Initialized
INFO - 2016-02-24 18:13:11 --> URI Class Initialized
INFO - 2016-02-24 18:13:11 --> Router Class Initialized
INFO - 2016-02-24 18:13:11 --> Output Class Initialized
INFO - 2016-02-24 18:13:11 --> Security Class Initialized
DEBUG - 2016-02-24 18:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:13:11 --> Input Class Initialized
INFO - 2016-02-24 18:13:11 --> Language Class Initialized
INFO - 2016-02-24 18:13:11 --> Loader Class Initialized
INFO - 2016-02-24 18:13:11 --> Helper loaded: url_helper
INFO - 2016-02-24 18:13:11 --> Helper loaded: file_helper
INFO - 2016-02-24 18:13:11 --> Helper loaded: date_helper
INFO - 2016-02-24 18:13:11 --> Helper loaded: form_helper
INFO - 2016-02-24 18:13:11 --> Database Driver Class Initialized
INFO - 2016-02-24 18:13:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:13:12 --> Controller Class Initialized
INFO - 2016-02-24 18:13:12 --> Model Class Initialized
INFO - 2016-02-24 18:13:12 --> Model Class Initialized
INFO - 2016-02-24 18:13:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:13:12 --> Pagination Class Initialized
INFO - 2016-02-24 18:13:12 --> Helper loaded: text_helper
INFO - 2016-02-24 18:13:12 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:13:12 --> Final output sent to browser
DEBUG - 2016-02-24 21:13:12 --> Total execution time: 1.1302
INFO - 2016-02-24 18:16:24 --> Config Class Initialized
INFO - 2016-02-24 18:16:24 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:16:24 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:16:24 --> Utf8 Class Initialized
INFO - 2016-02-24 18:16:24 --> URI Class Initialized
INFO - 2016-02-24 18:16:24 --> Router Class Initialized
INFO - 2016-02-24 18:16:24 --> Output Class Initialized
INFO - 2016-02-24 18:16:24 --> Security Class Initialized
DEBUG - 2016-02-24 18:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:16:24 --> Input Class Initialized
INFO - 2016-02-24 18:16:24 --> Language Class Initialized
INFO - 2016-02-24 18:16:24 --> Loader Class Initialized
INFO - 2016-02-24 18:16:24 --> Helper loaded: url_helper
INFO - 2016-02-24 18:16:24 --> Helper loaded: file_helper
INFO - 2016-02-24 18:16:24 --> Helper loaded: date_helper
INFO - 2016-02-24 18:16:24 --> Helper loaded: form_helper
INFO - 2016-02-24 18:16:24 --> Database Driver Class Initialized
INFO - 2016-02-24 18:16:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:16:25 --> Controller Class Initialized
INFO - 2016-02-24 18:16:25 --> Model Class Initialized
INFO - 2016-02-24 18:16:25 --> Model Class Initialized
INFO - 2016-02-24 18:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:16:25 --> Pagination Class Initialized
INFO - 2016-02-24 18:16:25 --> Helper loaded: text_helper
INFO - 2016-02-24 18:16:25 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-24 21:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-24 21:16:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:16:25 --> Final output sent to browser
DEBUG - 2016-02-24 21:16:25 --> Total execution time: 1.1311
INFO - 2016-02-24 18:16:39 --> Config Class Initialized
INFO - 2016-02-24 18:16:39 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:16:39 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:16:39 --> Utf8 Class Initialized
INFO - 2016-02-24 18:16:39 --> URI Class Initialized
INFO - 2016-02-24 18:16:39 --> Router Class Initialized
INFO - 2016-02-24 18:16:39 --> Output Class Initialized
INFO - 2016-02-24 18:16:39 --> Security Class Initialized
DEBUG - 2016-02-24 18:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:16:39 --> Input Class Initialized
INFO - 2016-02-24 18:16:39 --> Language Class Initialized
INFO - 2016-02-24 18:16:39 --> Loader Class Initialized
INFO - 2016-02-24 18:16:39 --> Helper loaded: url_helper
INFO - 2016-02-24 18:16:39 --> Helper loaded: file_helper
INFO - 2016-02-24 18:16:39 --> Helper loaded: date_helper
INFO - 2016-02-24 18:16:39 --> Helper loaded: form_helper
INFO - 2016-02-24 18:16:39 --> Database Driver Class Initialized
INFO - 2016-02-24 18:16:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:16:40 --> Controller Class Initialized
INFO - 2016-02-24 18:16:40 --> Model Class Initialized
INFO - 2016-02-24 18:16:40 --> Model Class Initialized
INFO - 2016-02-24 18:16:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:16:40 --> Pagination Class Initialized
INFO - 2016-02-24 18:16:40 --> Helper loaded: text_helper
INFO - 2016-02-24 18:16:40 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-24 21:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-24 21:16:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:16:40 --> Final output sent to browser
DEBUG - 2016-02-24 21:16:40 --> Total execution time: 1.0952
INFO - 2016-02-24 18:17:13 --> Config Class Initialized
INFO - 2016-02-24 18:17:13 --> Hooks Class Initialized
DEBUG - 2016-02-24 18:17:13 --> UTF-8 Support Enabled
INFO - 2016-02-24 18:17:13 --> Utf8 Class Initialized
INFO - 2016-02-24 18:17:13 --> URI Class Initialized
DEBUG - 2016-02-24 18:17:13 --> No URI present. Default controller set.
INFO - 2016-02-24 18:17:13 --> Router Class Initialized
INFO - 2016-02-24 18:17:13 --> Output Class Initialized
INFO - 2016-02-24 18:17:13 --> Security Class Initialized
DEBUG - 2016-02-24 18:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-24 18:17:13 --> Input Class Initialized
INFO - 2016-02-24 18:17:13 --> Language Class Initialized
INFO - 2016-02-24 18:17:13 --> Loader Class Initialized
INFO - 2016-02-24 18:17:13 --> Helper loaded: url_helper
INFO - 2016-02-24 18:17:13 --> Helper loaded: file_helper
INFO - 2016-02-24 18:17:13 --> Helper loaded: date_helper
INFO - 2016-02-24 18:17:13 --> Helper loaded: form_helper
INFO - 2016-02-24 18:17:13 --> Database Driver Class Initialized
INFO - 2016-02-24 18:17:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-24 18:17:14 --> Controller Class Initialized
INFO - 2016-02-24 18:17:14 --> Model Class Initialized
INFO - 2016-02-24 18:17:14 --> Model Class Initialized
INFO - 2016-02-24 18:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-24 18:17:14 --> Pagination Class Initialized
INFO - 2016-02-24 18:17:14 --> Helper loaded: text_helper
INFO - 2016-02-24 18:17:14 --> Helper loaded: cookie_helper
INFO - 2016-02-24 21:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-24 21:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-24 21:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-24 21:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-24 21:17:14 --> Final output sent to browser
DEBUG - 2016-02-24 21:17:14 --> Total execution time: 1.1061
