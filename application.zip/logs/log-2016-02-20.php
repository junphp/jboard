<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-20 07:14:05 --> Config Class Initialized
INFO - 2016-02-20 07:14:05 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:14:05 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:14:05 --> Utf8 Class Initialized
INFO - 2016-02-20 07:14:05 --> URI Class Initialized
DEBUG - 2016-02-20 07:14:05 --> No URI present. Default controller set.
INFO - 2016-02-20 07:14:05 --> Router Class Initialized
INFO - 2016-02-20 07:14:05 --> Output Class Initialized
INFO - 2016-02-20 07:14:05 --> Security Class Initialized
DEBUG - 2016-02-20 07:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:14:05 --> Input Class Initialized
INFO - 2016-02-20 07:14:05 --> Language Class Initialized
INFO - 2016-02-20 07:14:05 --> Loader Class Initialized
INFO - 2016-02-20 07:14:05 --> Helper loaded: url_helper
INFO - 2016-02-20 07:14:05 --> Helper loaded: file_helper
INFO - 2016-02-20 07:14:05 --> Helper loaded: date_helper
INFO - 2016-02-20 07:14:05 --> Helper loaded: form_helper
INFO - 2016-02-20 07:14:05 --> Database Driver Class Initialized
INFO - 2016-02-20 07:14:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:14:06 --> Controller Class Initialized
INFO - 2016-02-20 07:14:06 --> Model Class Initialized
INFO - 2016-02-20 07:14:06 --> Model Class Initialized
INFO - 2016-02-20 07:14:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:14:06 --> Pagination Class Initialized
INFO - 2016-02-20 07:14:06 --> Helper loaded: text_helper
INFO - 2016-02-20 07:14:06 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:14:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:14:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 10:14:06 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-20 10:14:06 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-20 10:14:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19' at line 2 - Invalid query: SELECT *
FROM 19
INFO - 2016-02-20 10:14:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 07:14:09 --> Config Class Initialized
INFO - 2016-02-20 07:14:09 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:14:09 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:14:09 --> Utf8 Class Initialized
INFO - 2016-02-20 07:14:09 --> URI Class Initialized
INFO - 2016-02-20 07:14:09 --> Router Class Initialized
INFO - 2016-02-20 07:14:09 --> Output Class Initialized
INFO - 2016-02-20 07:14:09 --> Security Class Initialized
DEBUG - 2016-02-20 07:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:14:09 --> Input Class Initialized
INFO - 2016-02-20 07:14:09 --> Language Class Initialized
INFO - 2016-02-20 07:14:09 --> Loader Class Initialized
INFO - 2016-02-20 07:14:09 --> Helper loaded: url_helper
INFO - 2016-02-20 07:14:09 --> Helper loaded: file_helper
INFO - 2016-02-20 07:14:09 --> Helper loaded: date_helper
INFO - 2016-02-20 07:14:09 --> Helper loaded: form_helper
INFO - 2016-02-20 07:14:09 --> Database Driver Class Initialized
INFO - 2016-02-20 07:14:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:14:10 --> Controller Class Initialized
INFO - 2016-02-20 07:14:10 --> Model Class Initialized
INFO - 2016-02-20 07:14:10 --> Model Class Initialized
INFO - 2016-02-20 07:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:14:10 --> Pagination Class Initialized
INFO - 2016-02-20 07:14:10 --> Helper loaded: text_helper
INFO - 2016-02-20 07:14:10 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-20 10:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 10:14:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:14:10 --> Final output sent to browser
DEBUG - 2016-02-20 10:14:10 --> Total execution time: 1.1053
INFO - 2016-02-20 07:14:48 --> Config Class Initialized
INFO - 2016-02-20 07:14:48 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:14:48 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:14:48 --> Utf8 Class Initialized
INFO - 2016-02-20 07:14:48 --> URI Class Initialized
INFO - 2016-02-20 07:14:48 --> Router Class Initialized
INFO - 2016-02-20 07:14:48 --> Output Class Initialized
INFO - 2016-02-20 07:14:48 --> Security Class Initialized
DEBUG - 2016-02-20 07:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:14:48 --> Input Class Initialized
INFO - 2016-02-20 07:14:48 --> Language Class Initialized
INFO - 2016-02-20 07:14:48 --> Loader Class Initialized
INFO - 2016-02-20 07:14:48 --> Helper loaded: url_helper
INFO - 2016-02-20 07:14:48 --> Helper loaded: file_helper
INFO - 2016-02-20 07:14:48 --> Helper loaded: date_helper
INFO - 2016-02-20 07:14:48 --> Helper loaded: form_helper
INFO - 2016-02-20 07:14:49 --> Database Driver Class Initialized
INFO - 2016-02-20 07:14:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:14:50 --> Controller Class Initialized
INFO - 2016-02-20 07:14:50 --> Model Class Initialized
INFO - 2016-02-20 07:14:50 --> Model Class Initialized
INFO - 2016-02-20 07:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:14:50 --> Pagination Class Initialized
INFO - 2016-02-20 07:14:50 --> Helper loaded: text_helper
INFO - 2016-02-20 07:14:50 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:14:50 --> Final output sent to browser
DEBUG - 2016-02-20 10:14:50 --> Total execution time: 1.0892
INFO - 2016-02-20 07:15:22 --> Config Class Initialized
INFO - 2016-02-20 07:15:22 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:15:22 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:15:22 --> Utf8 Class Initialized
INFO - 2016-02-20 07:15:22 --> URI Class Initialized
INFO - 2016-02-20 07:15:22 --> Router Class Initialized
INFO - 2016-02-20 07:15:22 --> Output Class Initialized
INFO - 2016-02-20 07:15:22 --> Security Class Initialized
DEBUG - 2016-02-20 07:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:15:22 --> Input Class Initialized
INFO - 2016-02-20 07:15:22 --> Language Class Initialized
INFO - 2016-02-20 07:15:22 --> Loader Class Initialized
INFO - 2016-02-20 07:15:22 --> Helper loaded: url_helper
INFO - 2016-02-20 07:15:22 --> Helper loaded: file_helper
INFO - 2016-02-20 07:15:22 --> Helper loaded: date_helper
INFO - 2016-02-20 07:15:22 --> Helper loaded: form_helper
INFO - 2016-02-20 07:15:22 --> Database Driver Class Initialized
INFO - 2016-02-20 07:15:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:15:23 --> Controller Class Initialized
INFO - 2016-02-20 07:15:23 --> Model Class Initialized
INFO - 2016-02-20 07:15:23 --> Model Class Initialized
INFO - 2016-02-20 07:15:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:15:23 --> Pagination Class Initialized
INFO - 2016-02-20 07:15:23 --> Helper loaded: text_helper
INFO - 2016-02-20 07:15:23 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:15:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:15:23 --> Final output sent to browser
DEBUG - 2016-02-20 10:15:23 --> Total execution time: 1.1620
INFO - 2016-02-20 07:16:21 --> Config Class Initialized
INFO - 2016-02-20 07:16:21 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:16:21 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:16:21 --> Utf8 Class Initialized
INFO - 2016-02-20 07:16:21 --> URI Class Initialized
INFO - 2016-02-20 07:16:21 --> Router Class Initialized
INFO - 2016-02-20 07:16:21 --> Output Class Initialized
INFO - 2016-02-20 07:16:21 --> Security Class Initialized
DEBUG - 2016-02-20 07:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:16:21 --> Input Class Initialized
INFO - 2016-02-20 07:16:21 --> Language Class Initialized
INFO - 2016-02-20 07:16:21 --> Loader Class Initialized
INFO - 2016-02-20 07:16:21 --> Helper loaded: url_helper
INFO - 2016-02-20 07:16:21 --> Helper loaded: file_helper
INFO - 2016-02-20 07:16:21 --> Helper loaded: date_helper
INFO - 2016-02-20 07:16:21 --> Helper loaded: form_helper
INFO - 2016-02-20 07:16:21 --> Database Driver Class Initialized
INFO - 2016-02-20 07:16:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:16:22 --> Controller Class Initialized
INFO - 2016-02-20 07:16:22 --> Model Class Initialized
INFO - 2016-02-20 07:16:22 --> Model Class Initialized
INFO - 2016-02-20 07:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:16:22 --> Pagination Class Initialized
INFO - 2016-02-20 07:16:22 --> Helper loaded: text_helper
INFO - 2016-02-20 07:16:22 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 10:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 10:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:16:22 --> Final output sent to browser
DEBUG - 2016-02-20 10:16:22 --> Total execution time: 1.1352
INFO - 2016-02-20 07:16:28 --> Config Class Initialized
INFO - 2016-02-20 07:16:28 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:16:28 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:16:28 --> Utf8 Class Initialized
INFO - 2016-02-20 07:16:28 --> URI Class Initialized
INFO - 2016-02-20 07:16:28 --> Router Class Initialized
INFO - 2016-02-20 07:16:28 --> Output Class Initialized
INFO - 2016-02-20 07:16:28 --> Security Class Initialized
DEBUG - 2016-02-20 07:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:16:28 --> Input Class Initialized
INFO - 2016-02-20 07:16:28 --> Language Class Initialized
INFO - 2016-02-20 07:16:28 --> Loader Class Initialized
INFO - 2016-02-20 07:16:28 --> Helper loaded: url_helper
INFO - 2016-02-20 07:16:28 --> Helper loaded: file_helper
INFO - 2016-02-20 07:16:28 --> Helper loaded: date_helper
INFO - 2016-02-20 07:16:28 --> Helper loaded: form_helper
INFO - 2016-02-20 07:16:28 --> Database Driver Class Initialized
INFO - 2016-02-20 07:16:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:16:29 --> Controller Class Initialized
INFO - 2016-02-20 07:16:29 --> Model Class Initialized
INFO - 2016-02-20 07:16:29 --> Model Class Initialized
INFO - 2016-02-20 07:16:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:16:29 --> Pagination Class Initialized
INFO - 2016-02-20 07:16:29 --> Helper loaded: text_helper
INFO - 2016-02-20 07:16:29 --> Helper loaded: cookie_helper
ERROR - 2016-02-20 10:16:29 --> Severity: Warning --> Missing argument 1 for Picture::get() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 107
INFO - 2016-02-20 10:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 127
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 22
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-20 10:16:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
INFO - 2016-02-20 10:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 10:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 10:16:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:16:29 --> Final output sent to browser
DEBUG - 2016-02-20 10:16:29 --> Total execution time: 1.1357
INFO - 2016-02-20 07:16:41 --> Config Class Initialized
INFO - 2016-02-20 07:16:41 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:16:41 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:16:41 --> Utf8 Class Initialized
INFO - 2016-02-20 07:16:41 --> URI Class Initialized
INFO - 2016-02-20 07:16:41 --> Router Class Initialized
INFO - 2016-02-20 07:16:41 --> Output Class Initialized
INFO - 2016-02-20 07:16:41 --> Security Class Initialized
DEBUG - 2016-02-20 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:16:41 --> Input Class Initialized
INFO - 2016-02-20 07:16:41 --> Language Class Initialized
INFO - 2016-02-20 07:16:41 --> Loader Class Initialized
INFO - 2016-02-20 07:16:41 --> Helper loaded: url_helper
INFO - 2016-02-20 07:16:41 --> Helper loaded: file_helper
INFO - 2016-02-20 07:16:41 --> Helper loaded: date_helper
INFO - 2016-02-20 07:16:41 --> Helper loaded: form_helper
INFO - 2016-02-20 07:16:41 --> Database Driver Class Initialized
INFO - 2016-02-20 07:16:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:16:42 --> Controller Class Initialized
INFO - 2016-02-20 07:16:42 --> Model Class Initialized
INFO - 2016-02-20 07:16:42 --> Model Class Initialized
INFO - 2016-02-20 07:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:16:42 --> Pagination Class Initialized
INFO - 2016-02-20 07:16:42 --> Helper loaded: text_helper
INFO - 2016-02-20 07:16:42 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 10:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 10:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:16:42 --> Final output sent to browser
DEBUG - 2016-02-20 10:16:42 --> Total execution time: 1.1855
INFO - 2016-02-20 07:27:28 --> Config Class Initialized
INFO - 2016-02-20 07:27:28 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:27:28 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:27:28 --> Utf8 Class Initialized
INFO - 2016-02-20 07:27:28 --> URI Class Initialized
INFO - 2016-02-20 07:27:28 --> Router Class Initialized
INFO - 2016-02-20 07:27:28 --> Output Class Initialized
INFO - 2016-02-20 07:27:28 --> Security Class Initialized
DEBUG - 2016-02-20 07:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:27:28 --> Input Class Initialized
INFO - 2016-02-20 07:27:28 --> Language Class Initialized
INFO - 2016-02-20 07:27:28 --> Loader Class Initialized
INFO - 2016-02-20 07:27:28 --> Helper loaded: url_helper
INFO - 2016-02-20 07:27:28 --> Helper loaded: file_helper
INFO - 2016-02-20 07:27:28 --> Helper loaded: date_helper
INFO - 2016-02-20 07:27:28 --> Helper loaded: form_helper
INFO - 2016-02-20 07:27:28 --> Database Driver Class Initialized
INFO - 2016-02-20 07:27:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:27:29 --> Controller Class Initialized
INFO - 2016-02-20 07:27:29 --> Model Class Initialized
INFO - 2016-02-20 07:27:29 --> Model Class Initialized
INFO - 2016-02-20 07:27:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:27:29 --> Pagination Class Initialized
INFO - 2016-02-20 07:27:29 --> Helper loaded: text_helper
INFO - 2016-02-20 07:27:29 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:27:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:27:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:27:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:27:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:27:29 --> Final output sent to browser
DEBUG - 2016-02-20 10:27:29 --> Total execution time: 1.1184
INFO - 2016-02-20 07:29:17 --> Config Class Initialized
INFO - 2016-02-20 07:29:17 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:29:17 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:29:17 --> Utf8 Class Initialized
INFO - 2016-02-20 07:29:17 --> URI Class Initialized
DEBUG - 2016-02-20 07:29:17 --> No URI present. Default controller set.
INFO - 2016-02-20 07:29:17 --> Router Class Initialized
INFO - 2016-02-20 07:29:17 --> Output Class Initialized
INFO - 2016-02-20 07:29:17 --> Security Class Initialized
DEBUG - 2016-02-20 07:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:29:17 --> Input Class Initialized
INFO - 2016-02-20 07:29:17 --> Language Class Initialized
INFO - 2016-02-20 07:29:17 --> Loader Class Initialized
INFO - 2016-02-20 07:29:17 --> Helper loaded: url_helper
INFO - 2016-02-20 07:29:17 --> Helper loaded: file_helper
INFO - 2016-02-20 07:29:17 --> Helper loaded: date_helper
INFO - 2016-02-20 07:29:17 --> Helper loaded: form_helper
INFO - 2016-02-20 07:29:17 --> Database Driver Class Initialized
INFO - 2016-02-20 07:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:29:18 --> Controller Class Initialized
INFO - 2016-02-20 07:29:18 --> Model Class Initialized
INFO - 2016-02-20 07:29:18 --> Model Class Initialized
INFO - 2016-02-20 07:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:29:18 --> Pagination Class Initialized
INFO - 2016-02-20 07:29:18 --> Helper loaded: text_helper
INFO - 2016-02-20 07:29:18 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 10:29:18 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-20 10:29:18 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-20 10:29:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19
ORDER BY `id` DESC' at line 2 - Invalid query: SELECT *
FROM 19
ORDER BY `id` DESC
INFO - 2016-02-20 10:29:18 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 07:29:21 --> Config Class Initialized
INFO - 2016-02-20 07:29:21 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:29:21 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:29:21 --> Utf8 Class Initialized
INFO - 2016-02-20 07:29:21 --> URI Class Initialized
INFO - 2016-02-20 07:29:21 --> Router Class Initialized
INFO - 2016-02-20 07:29:21 --> Output Class Initialized
INFO - 2016-02-20 07:29:21 --> Security Class Initialized
DEBUG - 2016-02-20 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:29:21 --> Input Class Initialized
INFO - 2016-02-20 07:29:21 --> Language Class Initialized
INFO - 2016-02-20 07:29:21 --> Loader Class Initialized
INFO - 2016-02-20 07:29:21 --> Helper loaded: url_helper
INFO - 2016-02-20 07:29:21 --> Helper loaded: file_helper
INFO - 2016-02-20 07:29:21 --> Helper loaded: date_helper
INFO - 2016-02-20 07:29:21 --> Helper loaded: form_helper
INFO - 2016-02-20 07:29:21 --> Database Driver Class Initialized
INFO - 2016-02-20 07:29:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:29:22 --> Controller Class Initialized
INFO - 2016-02-20 07:29:22 --> Model Class Initialized
INFO - 2016-02-20 07:29:22 --> Model Class Initialized
INFO - 2016-02-20 07:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:29:22 --> Pagination Class Initialized
INFO - 2016-02-20 07:29:22 --> Helper loaded: text_helper
INFO - 2016-02-20 07:29:22 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:29:22 --> Final output sent to browser
DEBUG - 2016-02-20 10:29:22 --> Total execution time: 1.1354
INFO - 2016-02-20 07:29:41 --> Config Class Initialized
INFO - 2016-02-20 07:29:41 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:29:41 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:29:41 --> Utf8 Class Initialized
INFO - 2016-02-20 07:29:41 --> URI Class Initialized
INFO - 2016-02-20 07:29:41 --> Router Class Initialized
INFO - 2016-02-20 07:29:41 --> Output Class Initialized
INFO - 2016-02-20 07:29:41 --> Security Class Initialized
DEBUG - 2016-02-20 07:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:29:41 --> Input Class Initialized
INFO - 2016-02-20 07:29:41 --> Language Class Initialized
INFO - 2016-02-20 07:29:41 --> Loader Class Initialized
INFO - 2016-02-20 07:29:41 --> Helper loaded: url_helper
INFO - 2016-02-20 07:29:41 --> Helper loaded: file_helper
INFO - 2016-02-20 07:29:41 --> Helper loaded: date_helper
INFO - 2016-02-20 07:29:41 --> Helper loaded: form_helper
INFO - 2016-02-20 07:29:41 --> Database Driver Class Initialized
INFO - 2016-02-20 07:29:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:29:42 --> Controller Class Initialized
INFO - 2016-02-20 07:29:42 --> Model Class Initialized
INFO - 2016-02-20 07:29:42 --> Model Class Initialized
INFO - 2016-02-20 07:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:29:42 --> Pagination Class Initialized
INFO - 2016-02-20 07:29:42 --> Helper loaded: text_helper
INFO - 2016-02-20 07:29:42 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:29:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:29:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:29:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:29:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:29:42 --> Final output sent to browser
DEBUG - 2016-02-20 10:29:42 --> Total execution time: 1.1262
INFO - 2016-02-20 07:31:47 --> Config Class Initialized
INFO - 2016-02-20 07:31:47 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:31:47 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:31:47 --> Utf8 Class Initialized
INFO - 2016-02-20 07:31:47 --> URI Class Initialized
DEBUG - 2016-02-20 07:31:47 --> No URI present. Default controller set.
INFO - 2016-02-20 07:31:47 --> Router Class Initialized
INFO - 2016-02-20 07:31:47 --> Output Class Initialized
INFO - 2016-02-20 07:31:47 --> Security Class Initialized
DEBUG - 2016-02-20 07:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:31:47 --> Input Class Initialized
INFO - 2016-02-20 07:31:47 --> Language Class Initialized
INFO - 2016-02-20 07:31:47 --> Loader Class Initialized
INFO - 2016-02-20 07:31:47 --> Helper loaded: url_helper
INFO - 2016-02-20 07:31:47 --> Helper loaded: file_helper
INFO - 2016-02-20 07:31:47 --> Helper loaded: date_helper
INFO - 2016-02-20 07:31:47 --> Helper loaded: form_helper
INFO - 2016-02-20 07:31:47 --> Database Driver Class Initialized
INFO - 2016-02-20 07:31:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:31:48 --> Controller Class Initialized
INFO - 2016-02-20 07:31:48 --> Model Class Initialized
INFO - 2016-02-20 07:31:48 --> Model Class Initialized
INFO - 2016-02-20 07:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:31:48 --> Pagination Class Initialized
INFO - 2016-02-20 07:31:48 --> Helper loaded: text_helper
INFO - 2016-02-20 07:31:48 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 10:31:48 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-20 10:31:48 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-20 10:31:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19
ORDER BY `id` DESC' at line 2 - Invalid query: SELECT *
FROM 19
ORDER BY `id` DESC
INFO - 2016-02-20 10:31:48 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 07:31:49 --> Config Class Initialized
INFO - 2016-02-20 07:31:49 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:31:49 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:31:49 --> Utf8 Class Initialized
INFO - 2016-02-20 07:31:49 --> URI Class Initialized
INFO - 2016-02-20 07:31:49 --> Router Class Initialized
INFO - 2016-02-20 07:31:49 --> Output Class Initialized
INFO - 2016-02-20 07:31:49 --> Security Class Initialized
DEBUG - 2016-02-20 07:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:31:49 --> Input Class Initialized
INFO - 2016-02-20 07:31:49 --> Language Class Initialized
INFO - 2016-02-20 07:31:49 --> Loader Class Initialized
INFO - 2016-02-20 07:31:49 --> Helper loaded: url_helper
INFO - 2016-02-20 07:31:49 --> Helper loaded: file_helper
INFO - 2016-02-20 07:31:49 --> Helper loaded: date_helper
INFO - 2016-02-20 07:31:49 --> Helper loaded: form_helper
INFO - 2016-02-20 07:31:49 --> Database Driver Class Initialized
INFO - 2016-02-20 07:31:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:31:51 --> Controller Class Initialized
INFO - 2016-02-20 07:31:51 --> Model Class Initialized
INFO - 2016-02-20 07:31:51 --> Model Class Initialized
INFO - 2016-02-20 07:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:31:51 --> Pagination Class Initialized
INFO - 2016-02-20 07:31:51 --> Helper loaded: text_helper
INFO - 2016-02-20 07:31:51 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:31:51 --> Final output sent to browser
DEBUG - 2016-02-20 10:31:51 --> Total execution time: 1.1562
INFO - 2016-02-20 07:32:40 --> Config Class Initialized
INFO - 2016-02-20 07:32:40 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:32:40 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:32:40 --> Utf8 Class Initialized
INFO - 2016-02-20 07:32:40 --> URI Class Initialized
INFO - 2016-02-20 07:32:40 --> Router Class Initialized
INFO - 2016-02-20 07:32:40 --> Output Class Initialized
INFO - 2016-02-20 07:32:40 --> Security Class Initialized
DEBUG - 2016-02-20 07:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:32:40 --> Input Class Initialized
INFO - 2016-02-20 07:32:40 --> Language Class Initialized
INFO - 2016-02-20 07:32:40 --> Loader Class Initialized
INFO - 2016-02-20 07:32:40 --> Helper loaded: url_helper
INFO - 2016-02-20 07:32:40 --> Helper loaded: file_helper
INFO - 2016-02-20 07:32:40 --> Helper loaded: date_helper
INFO - 2016-02-20 07:32:40 --> Helper loaded: form_helper
INFO - 2016-02-20 07:32:40 --> Database Driver Class Initialized
INFO - 2016-02-20 07:32:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:32:41 --> Controller Class Initialized
INFO - 2016-02-20 07:32:41 --> Model Class Initialized
INFO - 2016-02-20 07:32:41 --> Model Class Initialized
INFO - 2016-02-20 07:32:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:32:41 --> Pagination Class Initialized
INFO - 2016-02-20 07:32:41 --> Helper loaded: text_helper
INFO - 2016-02-20 07:32:41 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:32:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:32:41 --> Final output sent to browser
DEBUG - 2016-02-20 10:32:41 --> Total execution time: 1.1165
INFO - 2016-02-20 07:32:42 --> Config Class Initialized
INFO - 2016-02-20 07:32:42 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:32:42 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:32:42 --> Utf8 Class Initialized
INFO - 2016-02-20 07:32:42 --> URI Class Initialized
INFO - 2016-02-20 07:32:42 --> Router Class Initialized
INFO - 2016-02-20 07:32:42 --> Output Class Initialized
INFO - 2016-02-20 07:32:42 --> Security Class Initialized
DEBUG - 2016-02-20 07:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:32:42 --> Input Class Initialized
INFO - 2016-02-20 07:32:42 --> Language Class Initialized
INFO - 2016-02-20 07:32:42 --> Loader Class Initialized
INFO - 2016-02-20 07:32:42 --> Helper loaded: url_helper
INFO - 2016-02-20 07:32:42 --> Helper loaded: file_helper
INFO - 2016-02-20 07:32:42 --> Helper loaded: date_helper
INFO - 2016-02-20 07:32:42 --> Helper loaded: form_helper
INFO - 2016-02-20 07:32:42 --> Database Driver Class Initialized
INFO - 2016-02-20 07:32:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:32:43 --> Controller Class Initialized
INFO - 2016-02-20 07:32:43 --> Model Class Initialized
INFO - 2016-02-20 07:32:43 --> Model Class Initialized
INFO - 2016-02-20 07:32:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:32:43 --> Pagination Class Initialized
INFO - 2016-02-20 07:32:43 --> Helper loaded: text_helper
INFO - 2016-02-20 07:32:43 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:32:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 10:32:43 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 95 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-02-20 10:32:43 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
ERROR - 2016-02-20 10:32:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '19
ORDER BY `id` DESC' at line 2 - Invalid query: SELECT *
FROM 19
ORDER BY `id` DESC
INFO - 2016-02-20 10:32:43 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 07:34:55 --> Config Class Initialized
INFO - 2016-02-20 07:34:55 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:34:55 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:34:55 --> Utf8 Class Initialized
INFO - 2016-02-20 07:34:55 --> URI Class Initialized
INFO - 2016-02-20 07:34:55 --> Router Class Initialized
INFO - 2016-02-20 07:34:55 --> Output Class Initialized
INFO - 2016-02-20 07:34:55 --> Security Class Initialized
DEBUG - 2016-02-20 07:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:34:55 --> Input Class Initialized
INFO - 2016-02-20 07:34:55 --> Language Class Initialized
INFO - 2016-02-20 07:34:55 --> Loader Class Initialized
INFO - 2016-02-20 07:34:55 --> Helper loaded: url_helper
INFO - 2016-02-20 07:34:55 --> Helper loaded: file_helper
INFO - 2016-02-20 07:34:55 --> Helper loaded: date_helper
INFO - 2016-02-20 07:34:55 --> Helper loaded: form_helper
INFO - 2016-02-20 07:34:55 --> Database Driver Class Initialized
INFO - 2016-02-20 07:34:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:34:56 --> Controller Class Initialized
INFO - 2016-02-20 07:34:56 --> Model Class Initialized
INFO - 2016-02-20 07:34:56 --> Model Class Initialized
INFO - 2016-02-20 07:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:34:56 --> Pagination Class Initialized
INFO - 2016-02-20 07:34:56 --> Helper loaded: text_helper
INFO - 2016-02-20 07:34:56 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 10:34:56 --> Query error: Table 'jdboard.jboard' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `jboard`
INFO - 2016-02-20 10:34:56 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 07:35:28 --> Config Class Initialized
INFO - 2016-02-20 07:35:28 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:35:28 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:35:28 --> Utf8 Class Initialized
INFO - 2016-02-20 07:35:28 --> URI Class Initialized
INFO - 2016-02-20 07:35:28 --> Router Class Initialized
INFO - 2016-02-20 07:35:28 --> Output Class Initialized
INFO - 2016-02-20 07:35:28 --> Security Class Initialized
DEBUG - 2016-02-20 07:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:35:28 --> Input Class Initialized
INFO - 2016-02-20 07:35:28 --> Language Class Initialized
INFO - 2016-02-20 07:35:28 --> Loader Class Initialized
INFO - 2016-02-20 07:35:28 --> Helper loaded: url_helper
INFO - 2016-02-20 07:35:28 --> Helper loaded: file_helper
INFO - 2016-02-20 07:35:28 --> Helper loaded: date_helper
INFO - 2016-02-20 07:35:28 --> Helper loaded: form_helper
INFO - 2016-02-20 07:35:28 --> Database Driver Class Initialized
INFO - 2016-02-20 07:35:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:35:29 --> Controller Class Initialized
INFO - 2016-02-20 07:35:29 --> Model Class Initialized
INFO - 2016-02-20 07:35:29 --> Model Class Initialized
INFO - 2016-02-20 07:35:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:35:29 --> Pagination Class Initialized
INFO - 2016-02-20 07:35:29 --> Helper loaded: text_helper
INFO - 2016-02-20 07:35:29 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:35:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:35:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:35:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:35:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:35:29 --> Final output sent to browser
DEBUG - 2016-02-20 10:35:30 --> Total execution time: 1.1624
INFO - 2016-02-20 07:35:31 --> Config Class Initialized
INFO - 2016-02-20 07:35:31 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:35:31 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:35:31 --> Utf8 Class Initialized
INFO - 2016-02-20 07:35:31 --> URI Class Initialized
INFO - 2016-02-20 07:35:31 --> Router Class Initialized
INFO - 2016-02-20 07:35:31 --> Output Class Initialized
INFO - 2016-02-20 07:35:31 --> Security Class Initialized
DEBUG - 2016-02-20 07:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:35:31 --> Input Class Initialized
INFO - 2016-02-20 07:35:31 --> Language Class Initialized
INFO - 2016-02-20 07:35:31 --> Loader Class Initialized
INFO - 2016-02-20 07:35:31 --> Helper loaded: url_helper
INFO - 2016-02-20 07:35:31 --> Helper loaded: file_helper
INFO - 2016-02-20 07:35:31 --> Helper loaded: date_helper
INFO - 2016-02-20 07:35:31 --> Helper loaded: form_helper
INFO - 2016-02-20 07:35:31 --> Database Driver Class Initialized
INFO - 2016-02-20 07:35:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:35:32 --> Controller Class Initialized
INFO - 2016-02-20 07:35:32 --> Model Class Initialized
INFO - 2016-02-20 07:35:32 --> Model Class Initialized
INFO - 2016-02-20 07:35:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:35:32 --> Pagination Class Initialized
INFO - 2016-02-20 07:35:32 --> Helper loaded: text_helper
INFO - 2016-02-20 07:35:32 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:35:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 10:35:32 --> Query error: Table 'jdboard.jboard' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `jboard`
INFO - 2016-02-20 10:35:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 07:38:51 --> Config Class Initialized
INFO - 2016-02-20 07:38:51 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:38:51 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:38:51 --> Utf8 Class Initialized
INFO - 2016-02-20 07:38:51 --> URI Class Initialized
INFO - 2016-02-20 07:38:51 --> Router Class Initialized
INFO - 2016-02-20 07:38:51 --> Output Class Initialized
INFO - 2016-02-20 07:38:51 --> Security Class Initialized
DEBUG - 2016-02-20 07:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:38:51 --> Input Class Initialized
INFO - 2016-02-20 07:38:51 --> Language Class Initialized
INFO - 2016-02-20 07:38:51 --> Loader Class Initialized
INFO - 2016-02-20 07:38:51 --> Helper loaded: url_helper
INFO - 2016-02-20 07:38:51 --> Helper loaded: file_helper
INFO - 2016-02-20 07:38:51 --> Helper loaded: date_helper
INFO - 2016-02-20 07:38:51 --> Helper loaded: form_helper
INFO - 2016-02-20 07:38:51 --> Database Driver Class Initialized
INFO - 2016-02-20 07:38:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:38:52 --> Controller Class Initialized
INFO - 2016-02-20 07:38:52 --> Model Class Initialized
INFO - 2016-02-20 07:38:52 --> Model Class Initialized
INFO - 2016-02-20 07:38:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:38:52 --> Pagination Class Initialized
INFO - 2016-02-20 07:38:52 --> Helper loaded: text_helper
INFO - 2016-02-20 07:38:52 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:38:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:38:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:38:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:38:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:38:52 --> Final output sent to browser
DEBUG - 2016-02-20 10:38:52 --> Total execution time: 1.6430
INFO - 2016-02-20 07:47:45 --> Config Class Initialized
INFO - 2016-02-20 07:47:45 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:47:45 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:47:45 --> Utf8 Class Initialized
INFO - 2016-02-20 07:47:45 --> URI Class Initialized
INFO - 2016-02-20 07:47:45 --> Router Class Initialized
INFO - 2016-02-20 07:47:45 --> Output Class Initialized
INFO - 2016-02-20 07:47:45 --> Security Class Initialized
DEBUG - 2016-02-20 07:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:47:45 --> Input Class Initialized
INFO - 2016-02-20 07:47:45 --> Language Class Initialized
INFO - 2016-02-20 07:47:45 --> Loader Class Initialized
INFO - 2016-02-20 07:47:45 --> Helper loaded: url_helper
INFO - 2016-02-20 07:47:45 --> Helper loaded: file_helper
INFO - 2016-02-20 07:47:45 --> Helper loaded: date_helper
INFO - 2016-02-20 07:47:45 --> Helper loaded: form_helper
INFO - 2016-02-20 07:47:45 --> Database Driver Class Initialized
INFO - 2016-02-20 07:47:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:47:46 --> Controller Class Initialized
INFO - 2016-02-20 07:47:46 --> Model Class Initialized
INFO - 2016-02-20 07:47:46 --> Model Class Initialized
INFO - 2016-02-20 07:47:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:47:46 --> Pagination Class Initialized
INFO - 2016-02-20 07:47:46 --> Helper loaded: text_helper
INFO - 2016-02-20 07:47:46 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:47:46 --> Final output sent to browser
DEBUG - 2016-02-20 10:47:46 --> Total execution time: 1.1459
INFO - 2016-02-20 07:47:48 --> Config Class Initialized
INFO - 2016-02-20 07:47:48 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:47:48 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:47:48 --> Utf8 Class Initialized
INFO - 2016-02-20 07:47:48 --> URI Class Initialized
INFO - 2016-02-20 07:47:48 --> Router Class Initialized
INFO - 2016-02-20 07:47:48 --> Output Class Initialized
INFO - 2016-02-20 07:47:48 --> Security Class Initialized
DEBUG - 2016-02-20 07:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:47:48 --> Input Class Initialized
INFO - 2016-02-20 07:47:48 --> Language Class Initialized
INFO - 2016-02-20 07:47:48 --> Loader Class Initialized
INFO - 2016-02-20 07:47:48 --> Helper loaded: url_helper
INFO - 2016-02-20 07:47:48 --> Helper loaded: file_helper
INFO - 2016-02-20 07:47:48 --> Helper loaded: date_helper
INFO - 2016-02-20 07:47:48 --> Helper loaded: form_helper
INFO - 2016-02-20 07:47:48 --> Database Driver Class Initialized
INFO - 2016-02-20 07:47:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:47:49 --> Controller Class Initialized
INFO - 2016-02-20 07:47:49 --> Model Class Initialized
INFO - 2016-02-20 07:47:49 --> Model Class Initialized
INFO - 2016-02-20 07:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:47:49 --> Pagination Class Initialized
INFO - 2016-02-20 07:47:49 --> Helper loaded: text_helper
INFO - 2016-02-20 07:47:49 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:47:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:47:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:47:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:47:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:47:49 --> Final output sent to browser
DEBUG - 2016-02-20 10:47:49 --> Total execution time: 1.2377
INFO - 2016-02-20 07:54:15 --> Config Class Initialized
INFO - 2016-02-20 07:54:15 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:54:15 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:54:15 --> Utf8 Class Initialized
INFO - 2016-02-20 07:54:15 --> URI Class Initialized
INFO - 2016-02-20 07:54:15 --> Router Class Initialized
INFO - 2016-02-20 07:54:15 --> Output Class Initialized
INFO - 2016-02-20 07:54:15 --> Security Class Initialized
DEBUG - 2016-02-20 07:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:54:15 --> Input Class Initialized
INFO - 2016-02-20 07:54:15 --> Language Class Initialized
INFO - 2016-02-20 07:54:15 --> Loader Class Initialized
INFO - 2016-02-20 07:54:15 --> Helper loaded: url_helper
INFO - 2016-02-20 07:54:15 --> Helper loaded: file_helper
INFO - 2016-02-20 07:54:15 --> Helper loaded: date_helper
INFO - 2016-02-20 07:54:15 --> Helper loaded: form_helper
INFO - 2016-02-20 07:54:15 --> Database Driver Class Initialized
INFO - 2016-02-20 07:54:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:54:16 --> Controller Class Initialized
INFO - 2016-02-20 07:54:16 --> Model Class Initialized
INFO - 2016-02-20 07:54:16 --> Model Class Initialized
INFO - 2016-02-20 07:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:54:16 --> Pagination Class Initialized
INFO - 2016-02-20 07:54:16 --> Helper loaded: text_helper
INFO - 2016-02-20 07:54:16 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 10:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:54:16 --> Final output sent to browser
DEBUG - 2016-02-20 10:54:16 --> Total execution time: 1.1157
INFO - 2016-02-20 07:54:17 --> Config Class Initialized
INFO - 2016-02-20 07:54:17 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:54:17 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:54:17 --> Utf8 Class Initialized
INFO - 2016-02-20 07:54:17 --> URI Class Initialized
INFO - 2016-02-20 07:54:17 --> Router Class Initialized
INFO - 2016-02-20 07:54:17 --> Output Class Initialized
INFO - 2016-02-20 07:54:17 --> Security Class Initialized
DEBUG - 2016-02-20 07:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:54:17 --> Input Class Initialized
INFO - 2016-02-20 07:54:17 --> Language Class Initialized
INFO - 2016-02-20 07:54:17 --> Loader Class Initialized
INFO - 2016-02-20 07:54:17 --> Helper loaded: url_helper
INFO - 2016-02-20 07:54:17 --> Helper loaded: file_helper
INFO - 2016-02-20 07:54:17 --> Helper loaded: date_helper
INFO - 2016-02-20 07:54:17 --> Helper loaded: form_helper
INFO - 2016-02-20 07:54:17 --> Database Driver Class Initialized
INFO - 2016-02-20 07:54:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:54:18 --> Controller Class Initialized
INFO - 2016-02-20 07:54:18 --> Model Class Initialized
INFO - 2016-02-20 07:54:18 --> Model Class Initialized
INFO - 2016-02-20 07:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:54:18 --> Pagination Class Initialized
INFO - 2016-02-20 07:54:18 --> Helper loaded: text_helper
INFO - 2016-02-20 07:54:18 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:54:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:54:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 10:54:19 --> Severity: Warning --> Missing argument 2 for Jboard_model::updateview(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 118 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 152
ERROR - 2016-02-20 10:54:19 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 154
ERROR - 2016-02-20 10:54:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '51 SET view = view + 1
WHERE `id` IS NULL' at line 1 - Invalid query: UPDATE 51 SET view = view + 1
WHERE `id` IS NULL
INFO - 2016-02-20 10:54:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 07:55:02 --> Config Class Initialized
INFO - 2016-02-20 07:55:02 --> Hooks Class Initialized
DEBUG - 2016-02-20 07:55:02 --> UTF-8 Support Enabled
INFO - 2016-02-20 07:55:02 --> Utf8 Class Initialized
INFO - 2016-02-20 07:55:02 --> URI Class Initialized
INFO - 2016-02-20 07:55:02 --> Router Class Initialized
INFO - 2016-02-20 07:55:02 --> Output Class Initialized
INFO - 2016-02-20 07:55:02 --> Security Class Initialized
DEBUG - 2016-02-20 07:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 07:55:02 --> Input Class Initialized
INFO - 2016-02-20 07:55:02 --> Language Class Initialized
INFO - 2016-02-20 07:55:02 --> Loader Class Initialized
INFO - 2016-02-20 07:55:02 --> Helper loaded: url_helper
INFO - 2016-02-20 07:55:02 --> Helper loaded: file_helper
INFO - 2016-02-20 07:55:02 --> Helper loaded: date_helper
INFO - 2016-02-20 07:55:02 --> Helper loaded: form_helper
INFO - 2016-02-20 07:55:02 --> Database Driver Class Initialized
INFO - 2016-02-20 07:55:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 07:55:03 --> Controller Class Initialized
INFO - 2016-02-20 07:55:03 --> Model Class Initialized
INFO - 2016-02-20 07:55:03 --> Model Class Initialized
INFO - 2016-02-20 07:55:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 07:55:03 --> Pagination Class Initialized
INFO - 2016-02-20 07:55:03 --> Helper loaded: text_helper
INFO - 2016-02-20 07:55:03 --> Helper loaded: cookie_helper
INFO - 2016-02-20 10:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 10:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 10:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 10:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 10:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 10:55:03 --> Final output sent to browser
DEBUG - 2016-02-20 10:55:03 --> Total execution time: 1.2739
INFO - 2016-02-20 08:00:08 --> Config Class Initialized
INFO - 2016-02-20 08:00:08 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:00:08 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:00:08 --> Utf8 Class Initialized
INFO - 2016-02-20 08:00:08 --> URI Class Initialized
INFO - 2016-02-20 08:00:08 --> Router Class Initialized
INFO - 2016-02-20 08:00:08 --> Output Class Initialized
INFO - 2016-02-20 08:00:08 --> Security Class Initialized
DEBUG - 2016-02-20 08:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:00:08 --> Input Class Initialized
INFO - 2016-02-20 08:00:08 --> Language Class Initialized
INFO - 2016-02-20 08:00:08 --> Loader Class Initialized
INFO - 2016-02-20 08:00:08 --> Helper loaded: url_helper
INFO - 2016-02-20 08:00:08 --> Helper loaded: file_helper
INFO - 2016-02-20 08:00:08 --> Helper loaded: date_helper
INFO - 2016-02-20 08:00:08 --> Helper loaded: form_helper
INFO - 2016-02-20 08:00:08 --> Database Driver Class Initialized
INFO - 2016-02-20 08:00:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:00:09 --> Controller Class Initialized
INFO - 2016-02-20 08:00:09 --> Model Class Initialized
INFO - 2016-02-20 08:00:09 --> Model Class Initialized
INFO - 2016-02-20 08:00:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:00:09 --> Pagination Class Initialized
INFO - 2016-02-20 08:00:09 --> Helper loaded: text_helper
INFO - 2016-02-20 08:00:09 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:00:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:00:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:00:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 11:00:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:00:09 --> Final output sent to browser
DEBUG - 2016-02-20 11:00:09 --> Total execution time: 1.1787
INFO - 2016-02-20 08:00:11 --> Config Class Initialized
INFO - 2016-02-20 08:00:11 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:00:11 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:00:11 --> Utf8 Class Initialized
INFO - 2016-02-20 08:00:11 --> URI Class Initialized
INFO - 2016-02-20 08:00:11 --> Router Class Initialized
INFO - 2016-02-20 08:00:11 --> Output Class Initialized
INFO - 2016-02-20 08:00:11 --> Security Class Initialized
DEBUG - 2016-02-20 08:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:00:11 --> Input Class Initialized
INFO - 2016-02-20 08:00:11 --> Language Class Initialized
INFO - 2016-02-20 08:00:11 --> Loader Class Initialized
INFO - 2016-02-20 08:00:11 --> Helper loaded: url_helper
INFO - 2016-02-20 08:00:11 --> Helper loaded: file_helper
INFO - 2016-02-20 08:00:11 --> Helper loaded: date_helper
INFO - 2016-02-20 08:00:11 --> Helper loaded: form_helper
INFO - 2016-02-20 08:00:11 --> Database Driver Class Initialized
INFO - 2016-02-20 08:00:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:00:12 --> Controller Class Initialized
INFO - 2016-02-20 08:00:12 --> Model Class Initialized
INFO - 2016-02-20 08:00:12 --> Model Class Initialized
INFO - 2016-02-20 08:00:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:00:12 --> Pagination Class Initialized
INFO - 2016-02-20 08:00:12 --> Helper loaded: text_helper
INFO - 2016-02-20 08:00:12 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:00:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:00:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:00:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 11:00:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 11:00:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:00:12 --> Final output sent to browser
DEBUG - 2016-02-20 11:00:12 --> Total execution time: 1.2757
INFO - 2016-02-20 08:00:36 --> Config Class Initialized
INFO - 2016-02-20 08:00:36 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:00:36 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:00:36 --> Utf8 Class Initialized
INFO - 2016-02-20 08:00:36 --> URI Class Initialized
INFO - 2016-02-20 08:00:36 --> Router Class Initialized
INFO - 2016-02-20 08:00:36 --> Output Class Initialized
INFO - 2016-02-20 08:00:36 --> Security Class Initialized
DEBUG - 2016-02-20 08:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:00:36 --> Input Class Initialized
INFO - 2016-02-20 08:00:36 --> Language Class Initialized
INFO - 2016-02-20 08:00:36 --> Loader Class Initialized
INFO - 2016-02-20 08:00:36 --> Helper loaded: url_helper
INFO - 2016-02-20 08:00:36 --> Helper loaded: file_helper
INFO - 2016-02-20 08:00:36 --> Helper loaded: date_helper
INFO - 2016-02-20 08:00:36 --> Helper loaded: form_helper
INFO - 2016-02-20 08:00:36 --> Database Driver Class Initialized
INFO - 2016-02-20 08:00:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:00:37 --> Controller Class Initialized
INFO - 2016-02-20 08:00:37 --> Model Class Initialized
INFO - 2016-02-20 08:00:37 --> Model Class Initialized
INFO - 2016-02-20 08:00:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:00:37 --> Pagination Class Initialized
INFO - 2016-02-20 08:00:37 --> Helper loaded: text_helper
INFO - 2016-02-20 08:00:37 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 11:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:00:37 --> Final output sent to browser
DEBUG - 2016-02-20 11:00:37 --> Total execution time: 1.1631
INFO - 2016-02-20 08:00:38 --> Config Class Initialized
INFO - 2016-02-20 08:00:38 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:00:38 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:00:38 --> Utf8 Class Initialized
INFO - 2016-02-20 08:00:38 --> URI Class Initialized
INFO - 2016-02-20 08:00:38 --> Router Class Initialized
INFO - 2016-02-20 08:00:38 --> Output Class Initialized
INFO - 2016-02-20 08:00:38 --> Security Class Initialized
DEBUG - 2016-02-20 08:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:00:38 --> Input Class Initialized
INFO - 2016-02-20 08:00:38 --> Language Class Initialized
INFO - 2016-02-20 08:00:38 --> Loader Class Initialized
INFO - 2016-02-20 08:00:38 --> Helper loaded: url_helper
INFO - 2016-02-20 08:00:38 --> Helper loaded: file_helper
INFO - 2016-02-20 08:00:38 --> Helper loaded: date_helper
INFO - 2016-02-20 08:00:38 --> Helper loaded: form_helper
INFO - 2016-02-20 08:00:38 --> Database Driver Class Initialized
INFO - 2016-02-20 08:00:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:00:40 --> Controller Class Initialized
INFO - 2016-02-20 08:00:40 --> Model Class Initialized
INFO - 2016-02-20 08:00:40 --> Model Class Initialized
INFO - 2016-02-20 08:00:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:00:40 --> Pagination Class Initialized
INFO - 2016-02-20 08:00:40 --> Helper loaded: text_helper
INFO - 2016-02-20 08:00:40 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 11:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 11:00:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:00:40 --> Final output sent to browser
DEBUG - 2016-02-20 11:00:40 --> Total execution time: 1.3000
INFO - 2016-02-20 08:01:11 --> Config Class Initialized
INFO - 2016-02-20 08:01:11 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:01:11 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:01:11 --> Utf8 Class Initialized
INFO - 2016-02-20 08:01:11 --> URI Class Initialized
INFO - 2016-02-20 08:01:11 --> Router Class Initialized
INFO - 2016-02-20 08:01:11 --> Output Class Initialized
INFO - 2016-02-20 08:01:11 --> Security Class Initialized
DEBUG - 2016-02-20 08:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:01:11 --> Input Class Initialized
INFO - 2016-02-20 08:01:11 --> Language Class Initialized
INFO - 2016-02-20 08:01:11 --> Loader Class Initialized
INFO - 2016-02-20 08:01:11 --> Helper loaded: url_helper
INFO - 2016-02-20 08:01:11 --> Helper loaded: file_helper
INFO - 2016-02-20 08:01:11 --> Helper loaded: date_helper
INFO - 2016-02-20 08:01:11 --> Helper loaded: form_helper
INFO - 2016-02-20 08:01:11 --> Database Driver Class Initialized
INFO - 2016-02-20 08:01:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:01:12 --> Controller Class Initialized
INFO - 2016-02-20 08:01:12 --> Model Class Initialized
INFO - 2016-02-20 08:01:12 --> Model Class Initialized
INFO - 2016-02-20 08:01:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:01:12 --> Pagination Class Initialized
INFO - 2016-02-20 08:01:12 --> Helper loaded: text_helper
INFO - 2016-02-20 08:01:12 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:01:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:01:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 11:01:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 11:01:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:01:13 --> Final output sent to browser
DEBUG - 2016-02-20 11:01:13 --> Total execution time: 1.2548
INFO - 2016-02-20 08:02:55 --> Config Class Initialized
INFO - 2016-02-20 08:02:55 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:02:55 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:02:55 --> Utf8 Class Initialized
INFO - 2016-02-20 08:02:55 --> URI Class Initialized
INFO - 2016-02-20 08:02:55 --> Router Class Initialized
INFO - 2016-02-20 08:02:55 --> Output Class Initialized
INFO - 2016-02-20 08:02:55 --> Security Class Initialized
DEBUG - 2016-02-20 08:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:02:55 --> Input Class Initialized
INFO - 2016-02-20 08:02:55 --> Language Class Initialized
ERROR - 2016-02-20 08:02:55 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 124
INFO - 2016-02-20 08:03:04 --> Config Class Initialized
INFO - 2016-02-20 08:03:04 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:03:04 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:03:04 --> Utf8 Class Initialized
INFO - 2016-02-20 08:03:04 --> URI Class Initialized
INFO - 2016-02-20 08:03:04 --> Router Class Initialized
INFO - 2016-02-20 08:03:04 --> Output Class Initialized
INFO - 2016-02-20 08:03:04 --> Security Class Initialized
DEBUG - 2016-02-20 08:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:03:04 --> Input Class Initialized
INFO - 2016-02-20 08:03:04 --> Language Class Initialized
INFO - 2016-02-20 08:03:04 --> Loader Class Initialized
INFO - 2016-02-20 08:03:04 --> Helper loaded: url_helper
INFO - 2016-02-20 08:03:04 --> Helper loaded: file_helper
INFO - 2016-02-20 08:03:04 --> Helper loaded: date_helper
INFO - 2016-02-20 08:03:04 --> Helper loaded: form_helper
INFO - 2016-02-20 08:03:04 --> Database Driver Class Initialized
INFO - 2016-02-20 08:03:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:03:05 --> Controller Class Initialized
INFO - 2016-02-20 08:03:05 --> Model Class Initialized
INFO - 2016-02-20 08:03:05 --> Model Class Initialized
INFO - 2016-02-20 08:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:03:05 --> Pagination Class Initialized
INFO - 2016-02-20 08:03:05 --> Helper loaded: text_helper
INFO - 2016-02-20 08:03:05 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:03:05 --> Final output sent to browser
DEBUG - 2016-02-20 11:03:05 --> Total execution time: 1.2368
INFO - 2016-02-20 08:24:08 --> Config Class Initialized
INFO - 2016-02-20 08:24:08 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:24:08 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:24:08 --> Utf8 Class Initialized
INFO - 2016-02-20 08:24:08 --> URI Class Initialized
INFO - 2016-02-20 08:24:08 --> Router Class Initialized
INFO - 2016-02-20 08:24:08 --> Output Class Initialized
INFO - 2016-02-20 08:24:08 --> Security Class Initialized
DEBUG - 2016-02-20 08:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:24:08 --> Input Class Initialized
INFO - 2016-02-20 08:24:08 --> Language Class Initialized
INFO - 2016-02-20 08:24:08 --> Loader Class Initialized
INFO - 2016-02-20 08:24:08 --> Helper loaded: url_helper
INFO - 2016-02-20 08:24:08 --> Helper loaded: file_helper
INFO - 2016-02-20 08:24:08 --> Helper loaded: date_helper
INFO - 2016-02-20 08:24:08 --> Helper loaded: form_helper
INFO - 2016-02-20 08:24:08 --> Database Driver Class Initialized
INFO - 2016-02-20 08:24:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:24:09 --> Controller Class Initialized
INFO - 2016-02-20 08:24:09 --> Model Class Initialized
INFO - 2016-02-20 08:24:09 --> Model Class Initialized
INFO - 2016-02-20 08:24:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:24:09 --> Pagination Class Initialized
INFO - 2016-02-20 08:24:09 --> Helper loaded: text_helper
INFO - 2016-02-20 08:24:09 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 11:24:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:24:09 --> Final output sent to browser
DEBUG - 2016-02-20 11:24:09 --> Total execution time: 1.1673
INFO - 2016-02-20 08:24:11 --> Config Class Initialized
INFO - 2016-02-20 08:24:11 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:24:11 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:24:11 --> Utf8 Class Initialized
INFO - 2016-02-20 08:24:11 --> URI Class Initialized
INFO - 2016-02-20 08:24:11 --> Router Class Initialized
INFO - 2016-02-20 08:24:11 --> Output Class Initialized
INFO - 2016-02-20 08:24:11 --> Security Class Initialized
DEBUG - 2016-02-20 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:24:11 --> Input Class Initialized
INFO - 2016-02-20 08:24:11 --> Language Class Initialized
INFO - 2016-02-20 08:24:11 --> Loader Class Initialized
INFO - 2016-02-20 08:24:11 --> Helper loaded: url_helper
INFO - 2016-02-20 08:24:11 --> Helper loaded: file_helper
INFO - 2016-02-20 08:24:11 --> Helper loaded: date_helper
INFO - 2016-02-20 08:24:11 --> Helper loaded: form_helper
INFO - 2016-02-20 08:24:11 --> Database Driver Class Initialized
INFO - 2016-02-20 08:24:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:24:12 --> Controller Class Initialized
INFO - 2016-02-20 08:24:12 --> Model Class Initialized
INFO - 2016-02-20 08:24:12 --> Model Class Initialized
INFO - 2016-02-20 08:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:24:12 --> Pagination Class Initialized
INFO - 2016-02-20 08:24:12 --> Helper loaded: text_helper
INFO - 2016-02-20 08:24:12 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 11:24:12 --> Query error: Table 'jdboard.comment' doesn't exist - Invalid query: SELECT *
FROM `comment`
WHERE `board_id` = '51'
INFO - 2016-02-20 11:24:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 11:24:12 --> Query error: Unknown column 'board_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455985452
WHERE `board_id` = '51'
AND `id` = 'aa5337ae55f2f6fa917546fec4b86ae69943ebda'
INFO - 2016-02-20 08:30:31 --> Config Class Initialized
INFO - 2016-02-20 08:30:31 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:30:31 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:30:31 --> Utf8 Class Initialized
INFO - 2016-02-20 08:30:31 --> URI Class Initialized
INFO - 2016-02-20 08:30:31 --> Router Class Initialized
INFO - 2016-02-20 08:30:31 --> Output Class Initialized
INFO - 2016-02-20 08:30:31 --> Security Class Initialized
DEBUG - 2016-02-20 08:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:30:31 --> Input Class Initialized
INFO - 2016-02-20 08:30:31 --> Language Class Initialized
INFO - 2016-02-20 08:30:31 --> Loader Class Initialized
INFO - 2016-02-20 08:30:31 --> Helper loaded: url_helper
INFO - 2016-02-20 08:30:31 --> Helper loaded: file_helper
INFO - 2016-02-20 08:30:31 --> Helper loaded: date_helper
INFO - 2016-02-20 08:30:31 --> Helper loaded: form_helper
INFO - 2016-02-20 08:30:31 --> Database Driver Class Initialized
INFO - 2016-02-20 08:30:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:30:32 --> Controller Class Initialized
INFO - 2016-02-20 08:30:32 --> Model Class Initialized
INFO - 2016-02-20 08:30:32 --> Model Class Initialized
INFO - 2016-02-20 08:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:30:32 --> Pagination Class Initialized
INFO - 2016-02-20 08:30:32 --> Helper loaded: text_helper
INFO - 2016-02-20 08:30:32 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 11:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:30:32 --> Final output sent to browser
DEBUG - 2016-02-20 11:30:32 --> Total execution time: 1.1644
INFO - 2016-02-20 08:30:34 --> Config Class Initialized
INFO - 2016-02-20 08:30:34 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:30:34 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:30:34 --> Utf8 Class Initialized
INFO - 2016-02-20 08:30:34 --> URI Class Initialized
INFO - 2016-02-20 08:30:34 --> Router Class Initialized
INFO - 2016-02-20 08:30:34 --> Output Class Initialized
INFO - 2016-02-20 08:30:34 --> Security Class Initialized
DEBUG - 2016-02-20 08:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:30:34 --> Input Class Initialized
INFO - 2016-02-20 08:30:34 --> Language Class Initialized
INFO - 2016-02-20 08:30:34 --> Loader Class Initialized
INFO - 2016-02-20 08:30:34 --> Helper loaded: url_helper
INFO - 2016-02-20 08:30:34 --> Helper loaded: file_helper
INFO - 2016-02-20 08:30:34 --> Helper loaded: date_helper
INFO - 2016-02-20 08:30:34 --> Helper loaded: form_helper
INFO - 2016-02-20 08:30:34 --> Database Driver Class Initialized
INFO - 2016-02-20 08:30:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:30:35 --> Controller Class Initialized
INFO - 2016-02-20 08:30:35 --> Model Class Initialized
INFO - 2016-02-20 08:30:35 --> Model Class Initialized
INFO - 2016-02-20 08:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:30:35 --> Pagination Class Initialized
INFO - 2016-02-20 08:30:35 --> Helper loaded: text_helper
INFO - 2016-02-20 08:30:35 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 11:30:35 --> Query error: Table 'jdboard.comment' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `comment`
WHERE `board_id` LIKE '%51%' ESCAPE '!'
INFO - 2016-02-20 11:30:35 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 11:30:35 --> Query error: Unknown column 'board_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455985835
WHERE `board_id` LIKE '%51%' ESCAPE '!'
AND `id` = '05b6b77a59f42e1cffa579d1cd8c643170e5a16a'
INFO - 2016-02-20 08:32:17 --> Config Class Initialized
INFO - 2016-02-20 08:32:17 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:32:17 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:32:17 --> Utf8 Class Initialized
INFO - 2016-02-20 08:32:17 --> URI Class Initialized
INFO - 2016-02-20 08:32:17 --> Router Class Initialized
INFO - 2016-02-20 08:32:17 --> Output Class Initialized
INFO - 2016-02-20 08:32:17 --> Security Class Initialized
DEBUG - 2016-02-20 08:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:32:17 --> Input Class Initialized
INFO - 2016-02-20 08:32:17 --> Language Class Initialized
INFO - 2016-02-20 08:32:17 --> Loader Class Initialized
INFO - 2016-02-20 08:32:17 --> Helper loaded: url_helper
INFO - 2016-02-20 08:32:17 --> Helper loaded: file_helper
INFO - 2016-02-20 08:32:17 --> Helper loaded: date_helper
INFO - 2016-02-20 08:32:17 --> Helper loaded: form_helper
INFO - 2016-02-20 08:32:17 --> Database Driver Class Initialized
INFO - 2016-02-20 08:32:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:32:19 --> Controller Class Initialized
INFO - 2016-02-20 08:32:19 --> Model Class Initialized
INFO - 2016-02-20 08:32:19 --> Model Class Initialized
INFO - 2016-02-20 08:32:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:32:19 --> Pagination Class Initialized
INFO - 2016-02-20 08:32:19 --> Helper loaded: text_helper
INFO - 2016-02-20 08:32:19 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:32:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:32:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:32:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 11:32:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:32:19 --> Final output sent to browser
DEBUG - 2016-02-20 11:32:19 --> Total execution time: 1.1566
INFO - 2016-02-20 08:32:22 --> Config Class Initialized
INFO - 2016-02-20 08:32:22 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:32:22 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:32:22 --> Utf8 Class Initialized
INFO - 2016-02-20 08:32:22 --> URI Class Initialized
INFO - 2016-02-20 08:32:22 --> Router Class Initialized
INFO - 2016-02-20 08:32:22 --> Output Class Initialized
INFO - 2016-02-20 08:32:22 --> Security Class Initialized
DEBUG - 2016-02-20 08:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:32:22 --> Input Class Initialized
INFO - 2016-02-20 08:32:22 --> Language Class Initialized
INFO - 2016-02-20 08:32:22 --> Loader Class Initialized
INFO - 2016-02-20 08:32:22 --> Helper loaded: url_helper
INFO - 2016-02-20 08:32:22 --> Helper loaded: file_helper
INFO - 2016-02-20 08:32:22 --> Helper loaded: date_helper
INFO - 2016-02-20 08:32:22 --> Helper loaded: form_helper
INFO - 2016-02-20 08:32:22 --> Database Driver Class Initialized
INFO - 2016-02-20 08:32:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:32:24 --> Controller Class Initialized
INFO - 2016-02-20 08:32:24 --> Model Class Initialized
INFO - 2016-02-20 08:32:24 --> Model Class Initialized
INFO - 2016-02-20 08:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:32:24 --> Pagination Class Initialized
INFO - 2016-02-20 08:32:24 --> Helper loaded: text_helper
INFO - 2016-02-20 08:32:24 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 11:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:32:24 --> Final output sent to browser
DEBUG - 2016-02-20 11:32:24 --> Total execution time: 1.1542
INFO - 2016-02-20 08:32:25 --> Config Class Initialized
INFO - 2016-02-20 08:32:25 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:32:25 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:32:25 --> Utf8 Class Initialized
INFO - 2016-02-20 08:32:25 --> URI Class Initialized
INFO - 2016-02-20 08:32:25 --> Router Class Initialized
INFO - 2016-02-20 08:32:25 --> Output Class Initialized
INFO - 2016-02-20 08:32:25 --> Security Class Initialized
DEBUG - 2016-02-20 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:32:25 --> Input Class Initialized
INFO - 2016-02-20 08:32:25 --> Language Class Initialized
INFO - 2016-02-20 08:32:25 --> Loader Class Initialized
INFO - 2016-02-20 08:32:25 --> Helper loaded: url_helper
INFO - 2016-02-20 08:32:25 --> Helper loaded: file_helper
INFO - 2016-02-20 08:32:25 --> Helper loaded: date_helper
INFO - 2016-02-20 08:32:25 --> Helper loaded: form_helper
INFO - 2016-02-20 08:32:25 --> Database Driver Class Initialized
INFO - 2016-02-20 08:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:32:26 --> Controller Class Initialized
INFO - 2016-02-20 08:32:26 --> Model Class Initialized
INFO - 2016-02-20 08:32:26 --> Model Class Initialized
INFO - 2016-02-20 08:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:32:26 --> Pagination Class Initialized
INFO - 2016-02-20 08:32:26 --> Helper loaded: text_helper
INFO - 2016-02-20 08:32:26 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 11:32:26 --> Query error: Table 'jdboard.comment' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `comment`
WHERE `board_id` LIKE '%51%' ESCAPE '!'
INFO - 2016-02-20 11:32:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 11:32:26 --> Query error: Unknown column 'board_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455985946
WHERE `board_id` LIKE '%51%' ESCAPE '!'
AND `id` = '05b6b77a59f42e1cffa579d1cd8c643170e5a16a'
INFO - 2016-02-20 08:33:24 --> Config Class Initialized
INFO - 2016-02-20 08:33:24 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:33:24 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:33:24 --> Utf8 Class Initialized
INFO - 2016-02-20 08:33:24 --> URI Class Initialized
INFO - 2016-02-20 08:33:24 --> Router Class Initialized
INFO - 2016-02-20 08:33:24 --> Output Class Initialized
INFO - 2016-02-20 08:33:24 --> Security Class Initialized
DEBUG - 2016-02-20 08:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:33:24 --> Input Class Initialized
INFO - 2016-02-20 08:33:24 --> Language Class Initialized
INFO - 2016-02-20 08:33:24 --> Loader Class Initialized
INFO - 2016-02-20 08:33:24 --> Helper loaded: url_helper
INFO - 2016-02-20 08:33:24 --> Helper loaded: file_helper
INFO - 2016-02-20 08:33:24 --> Helper loaded: date_helper
INFO - 2016-02-20 08:33:24 --> Helper loaded: form_helper
INFO - 2016-02-20 08:33:24 --> Database Driver Class Initialized
INFO - 2016-02-20 08:33:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:33:25 --> Controller Class Initialized
INFO - 2016-02-20 08:33:25 --> Model Class Initialized
INFO - 2016-02-20 08:33:25 --> Model Class Initialized
INFO - 2016-02-20 08:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:33:25 --> Pagination Class Initialized
INFO - 2016-02-20 08:33:25 --> Helper loaded: text_helper
INFO - 2016-02-20 08:33:25 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:33:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 11:33:25 --> Severity: Warning --> Missing argument 2 for Jboard_model::total_comments(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 135 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 64
ERROR - 2016-02-20 11:33:25 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 66
ERROR - 2016-02-20 11:33:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '51
WHERE `board_id` LIKE '%%' ESCAPE '!'' at line 2 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM 51
WHERE `board_id` LIKE '%%' ESCAPE '!'
INFO - 2016-02-20 11:33:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 11:33:25 --> Query error: Unknown column 'board_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455986005
WHERE `board_id` LIKE '%%' ESCAPE '!'
AND `id` = '05b6b77a59f42e1cffa579d1cd8c643170e5a16a'
INFO - 2016-02-20 08:33:45 --> Config Class Initialized
INFO - 2016-02-20 08:33:45 --> Hooks Class Initialized
DEBUG - 2016-02-20 08:33:45 --> UTF-8 Support Enabled
INFO - 2016-02-20 08:33:45 --> Utf8 Class Initialized
INFO - 2016-02-20 08:33:45 --> URI Class Initialized
INFO - 2016-02-20 08:33:45 --> Router Class Initialized
INFO - 2016-02-20 08:33:45 --> Output Class Initialized
INFO - 2016-02-20 08:33:45 --> Security Class Initialized
DEBUG - 2016-02-20 08:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 08:33:45 --> Input Class Initialized
INFO - 2016-02-20 08:33:45 --> Language Class Initialized
INFO - 2016-02-20 08:33:45 --> Loader Class Initialized
INFO - 2016-02-20 08:33:45 --> Helper loaded: url_helper
INFO - 2016-02-20 08:33:45 --> Helper loaded: file_helper
INFO - 2016-02-20 08:33:45 --> Helper loaded: date_helper
INFO - 2016-02-20 08:33:45 --> Helper loaded: form_helper
INFO - 2016-02-20 08:33:45 --> Database Driver Class Initialized
INFO - 2016-02-20 08:33:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 08:33:46 --> Controller Class Initialized
INFO - 2016-02-20 08:33:46 --> Model Class Initialized
INFO - 2016-02-20 08:33:46 --> Model Class Initialized
INFO - 2016-02-20 08:33:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 08:33:46 --> Pagination Class Initialized
INFO - 2016-02-20 08:33:46 --> Helper loaded: text_helper
INFO - 2016-02-20 08:33:46 --> Helper loaded: cookie_helper
INFO - 2016-02-20 11:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 11:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 11:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 11:33:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 11:33:46 --> Final output sent to browser
DEBUG - 2016-02-20 11:33:47 --> Total execution time: 1.2271
INFO - 2016-02-20 09:55:36 --> Config Class Initialized
INFO - 2016-02-20 09:55:36 --> Hooks Class Initialized
DEBUG - 2016-02-20 09:55:36 --> UTF-8 Support Enabled
INFO - 2016-02-20 09:55:36 --> Utf8 Class Initialized
INFO - 2016-02-20 09:55:36 --> URI Class Initialized
INFO - 2016-02-20 09:55:36 --> Router Class Initialized
INFO - 2016-02-20 09:55:36 --> Output Class Initialized
INFO - 2016-02-20 09:55:36 --> Security Class Initialized
DEBUG - 2016-02-20 09:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 09:55:36 --> Input Class Initialized
INFO - 2016-02-20 09:55:36 --> Language Class Initialized
INFO - 2016-02-20 09:55:36 --> Loader Class Initialized
INFO - 2016-02-20 09:55:36 --> Helper loaded: url_helper
INFO - 2016-02-20 09:55:36 --> Helper loaded: file_helper
INFO - 2016-02-20 09:55:36 --> Helper loaded: date_helper
INFO - 2016-02-20 09:55:36 --> Helper loaded: form_helper
INFO - 2016-02-20 09:55:36 --> Database Driver Class Initialized
INFO - 2016-02-20 09:55:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 09:55:37 --> Controller Class Initialized
INFO - 2016-02-20 09:55:37 --> Model Class Initialized
INFO - 2016-02-20 09:55:37 --> Model Class Initialized
INFO - 2016-02-20 09:55:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 09:55:37 --> Pagination Class Initialized
INFO - 2016-02-20 09:55:37 --> Helper loaded: text_helper
INFO - 2016-02-20 09:55:37 --> Helper loaded: cookie_helper
INFO - 2016-02-20 12:55:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 12:55:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 12:55:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 12:55:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 12:55:37 --> Final output sent to browser
DEBUG - 2016-02-20 12:55:37 --> Total execution time: 1.1388
INFO - 2016-02-20 09:55:40 --> Config Class Initialized
INFO - 2016-02-20 09:55:40 --> Hooks Class Initialized
DEBUG - 2016-02-20 09:55:40 --> UTF-8 Support Enabled
INFO - 2016-02-20 09:55:40 --> Utf8 Class Initialized
INFO - 2016-02-20 09:55:40 --> URI Class Initialized
INFO - 2016-02-20 09:55:40 --> Router Class Initialized
INFO - 2016-02-20 09:55:40 --> Output Class Initialized
INFO - 2016-02-20 09:55:40 --> Security Class Initialized
DEBUG - 2016-02-20 09:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 09:55:40 --> Input Class Initialized
INFO - 2016-02-20 09:55:40 --> Language Class Initialized
INFO - 2016-02-20 09:55:40 --> Loader Class Initialized
INFO - 2016-02-20 09:55:40 --> Helper loaded: url_helper
INFO - 2016-02-20 09:55:40 --> Helper loaded: file_helper
INFO - 2016-02-20 09:55:40 --> Helper loaded: date_helper
INFO - 2016-02-20 09:55:40 --> Helper loaded: form_helper
INFO - 2016-02-20 09:55:40 --> Database Driver Class Initialized
INFO - 2016-02-20 09:55:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 09:55:41 --> Controller Class Initialized
INFO - 2016-02-20 09:55:41 --> Model Class Initialized
INFO - 2016-02-20 09:55:41 --> Model Class Initialized
INFO - 2016-02-20 09:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 09:55:41 --> Pagination Class Initialized
INFO - 2016-02-20 09:55:41 --> Helper loaded: text_helper
INFO - 2016-02-20 09:55:41 --> Helper loaded: cookie_helper
INFO - 2016-02-20 12:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 12:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 12:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 12:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 12:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 12:55:41 --> Final output sent to browser
DEBUG - 2016-02-20 12:55:41 --> Total execution time: 1.1967
INFO - 2016-02-20 09:55:47 --> Config Class Initialized
INFO - 2016-02-20 09:55:47 --> Hooks Class Initialized
DEBUG - 2016-02-20 09:55:47 --> UTF-8 Support Enabled
INFO - 2016-02-20 09:55:47 --> Utf8 Class Initialized
INFO - 2016-02-20 09:55:47 --> URI Class Initialized
INFO - 2016-02-20 09:55:47 --> Router Class Initialized
INFO - 2016-02-20 09:55:47 --> Output Class Initialized
INFO - 2016-02-20 09:55:47 --> Security Class Initialized
DEBUG - 2016-02-20 09:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 09:55:47 --> Input Class Initialized
INFO - 2016-02-20 09:55:47 --> Language Class Initialized
INFO - 2016-02-20 09:55:47 --> Loader Class Initialized
INFO - 2016-02-20 09:55:47 --> Helper loaded: url_helper
INFO - 2016-02-20 09:55:47 --> Helper loaded: file_helper
INFO - 2016-02-20 09:55:47 --> Helper loaded: date_helper
INFO - 2016-02-20 09:55:47 --> Helper loaded: form_helper
INFO - 2016-02-20 09:55:47 --> Database Driver Class Initialized
INFO - 2016-02-20 09:55:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 09:55:48 --> Controller Class Initialized
INFO - 2016-02-20 09:55:48 --> Model Class Initialized
INFO - 2016-02-20 09:55:48 --> Model Class Initialized
INFO - 2016-02-20 09:55:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 09:55:48 --> Pagination Class Initialized
INFO - 2016-02-20 09:55:48 --> Helper loaded: text_helper
INFO - 2016-02-20 09:55:48 --> Helper loaded: cookie_helper
INFO - 2016-02-20 12:55:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 12:55:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 12:55:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 12:55:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 12:55:48 --> Final output sent to browser
DEBUG - 2016-02-20 12:55:48 --> Total execution time: 1.1426
INFO - 2016-02-20 09:55:50 --> Config Class Initialized
INFO - 2016-02-20 09:55:50 --> Hooks Class Initialized
DEBUG - 2016-02-20 09:55:50 --> UTF-8 Support Enabled
INFO - 2016-02-20 09:55:50 --> Utf8 Class Initialized
INFO - 2016-02-20 09:55:50 --> URI Class Initialized
INFO - 2016-02-20 09:55:50 --> Router Class Initialized
INFO - 2016-02-20 09:55:50 --> Output Class Initialized
INFO - 2016-02-20 09:55:50 --> Security Class Initialized
DEBUG - 2016-02-20 09:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 09:55:50 --> Input Class Initialized
INFO - 2016-02-20 09:55:50 --> Language Class Initialized
INFO - 2016-02-20 09:55:50 --> Loader Class Initialized
INFO - 2016-02-20 09:55:50 --> Helper loaded: url_helper
INFO - 2016-02-20 09:55:50 --> Helper loaded: file_helper
INFO - 2016-02-20 09:55:50 --> Helper loaded: date_helper
INFO - 2016-02-20 09:55:50 --> Helper loaded: form_helper
INFO - 2016-02-20 09:55:50 --> Database Driver Class Initialized
INFO - 2016-02-20 09:55:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 09:55:51 --> Controller Class Initialized
INFO - 2016-02-20 09:55:51 --> Model Class Initialized
INFO - 2016-02-20 09:55:51 --> Model Class Initialized
INFO - 2016-02-20 09:55:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 09:55:51 --> Pagination Class Initialized
INFO - 2016-02-20 09:55:51 --> Helper loaded: text_helper
INFO - 2016-02-20 09:55:51 --> Helper loaded: cookie_helper
INFO - 2016-02-20 12:55:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 12:55:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 12:55:51 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 137 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-20 12:55:51 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-20 12:55:51 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-20 12:55:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 09:56:15 --> Config Class Initialized
INFO - 2016-02-20 09:56:15 --> Hooks Class Initialized
DEBUG - 2016-02-20 09:56:15 --> UTF-8 Support Enabled
INFO - 2016-02-20 09:56:15 --> Utf8 Class Initialized
INFO - 2016-02-20 09:56:15 --> URI Class Initialized
INFO - 2016-02-20 09:56:15 --> Router Class Initialized
INFO - 2016-02-20 09:56:15 --> Output Class Initialized
INFO - 2016-02-20 09:56:15 --> Security Class Initialized
DEBUG - 2016-02-20 09:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 09:56:15 --> Input Class Initialized
INFO - 2016-02-20 09:56:15 --> Language Class Initialized
INFO - 2016-02-20 09:56:15 --> Loader Class Initialized
INFO - 2016-02-20 09:56:15 --> Helper loaded: url_helper
INFO - 2016-02-20 09:56:15 --> Helper loaded: file_helper
INFO - 2016-02-20 09:56:15 --> Helper loaded: date_helper
INFO - 2016-02-20 09:56:15 --> Helper loaded: form_helper
INFO - 2016-02-20 09:56:15 --> Database Driver Class Initialized
INFO - 2016-02-20 09:56:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 09:56:16 --> Controller Class Initialized
INFO - 2016-02-20 09:56:16 --> Model Class Initialized
INFO - 2016-02-20 09:56:16 --> Model Class Initialized
INFO - 2016-02-20 09:56:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 09:56:16 --> Pagination Class Initialized
INFO - 2016-02-20 09:56:16 --> Helper loaded: text_helper
INFO - 2016-02-20 09:56:16 --> Helper loaded: cookie_helper
INFO - 2016-02-20 12:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 12:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 12:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 12:56:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 12:56:16 --> Final output sent to browser
DEBUG - 2016-02-20 12:56:16 --> Total execution time: 1.1501
INFO - 2016-02-20 09:56:17 --> Config Class Initialized
INFO - 2016-02-20 09:56:17 --> Hooks Class Initialized
DEBUG - 2016-02-20 09:56:17 --> UTF-8 Support Enabled
INFO - 2016-02-20 09:56:17 --> Utf8 Class Initialized
INFO - 2016-02-20 09:56:17 --> URI Class Initialized
INFO - 2016-02-20 09:56:17 --> Router Class Initialized
INFO - 2016-02-20 09:56:17 --> Output Class Initialized
INFO - 2016-02-20 09:56:17 --> Security Class Initialized
DEBUG - 2016-02-20 09:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 09:56:17 --> Input Class Initialized
INFO - 2016-02-20 09:56:17 --> Language Class Initialized
INFO - 2016-02-20 09:56:17 --> Loader Class Initialized
INFO - 2016-02-20 09:56:17 --> Helper loaded: url_helper
INFO - 2016-02-20 09:56:17 --> Helper loaded: file_helper
INFO - 2016-02-20 09:56:17 --> Helper loaded: date_helper
INFO - 2016-02-20 09:56:17 --> Helper loaded: form_helper
INFO - 2016-02-20 09:56:17 --> Database Driver Class Initialized
INFO - 2016-02-20 09:56:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 09:56:18 --> Controller Class Initialized
INFO - 2016-02-20 09:56:18 --> Model Class Initialized
INFO - 2016-02-20 09:56:18 --> Model Class Initialized
INFO - 2016-02-20 09:56:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 09:56:18 --> Pagination Class Initialized
INFO - 2016-02-20 09:56:18 --> Helper loaded: text_helper
INFO - 2016-02-20 09:56:18 --> Helper loaded: cookie_helper
INFO - 2016-02-20 12:56:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 12:56:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 12:56:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 12:56:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 12:56:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 12:56:18 --> Final output sent to browser
DEBUG - 2016-02-20 12:56:18 --> Total execution time: 1.1987
INFO - 2016-02-20 09:57:38 --> Config Class Initialized
INFO - 2016-02-20 09:57:38 --> Hooks Class Initialized
DEBUG - 2016-02-20 09:57:38 --> UTF-8 Support Enabled
INFO - 2016-02-20 09:57:38 --> Utf8 Class Initialized
INFO - 2016-02-20 09:57:38 --> URI Class Initialized
INFO - 2016-02-20 09:57:38 --> Router Class Initialized
INFO - 2016-02-20 09:57:38 --> Output Class Initialized
INFO - 2016-02-20 09:57:38 --> Security Class Initialized
DEBUG - 2016-02-20 09:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 09:57:38 --> Input Class Initialized
INFO - 2016-02-20 09:57:38 --> Language Class Initialized
INFO - 2016-02-20 09:57:38 --> Loader Class Initialized
INFO - 2016-02-20 09:57:38 --> Helper loaded: url_helper
INFO - 2016-02-20 09:57:38 --> Helper loaded: file_helper
INFO - 2016-02-20 09:57:38 --> Helper loaded: date_helper
INFO - 2016-02-20 09:57:38 --> Helper loaded: form_helper
INFO - 2016-02-20 09:57:38 --> Database Driver Class Initialized
INFO - 2016-02-20 09:57:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 09:57:39 --> Controller Class Initialized
INFO - 2016-02-20 09:57:39 --> Model Class Initialized
INFO - 2016-02-20 09:57:39 --> Model Class Initialized
INFO - 2016-02-20 09:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 09:57:39 --> Pagination Class Initialized
INFO - 2016-02-20 09:57:39 --> Helper loaded: text_helper
INFO - 2016-02-20 09:57:39 --> Helper loaded: cookie_helper
INFO - 2016-02-20 12:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 12:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 12:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 12:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 12:57:39 --> Final output sent to browser
DEBUG - 2016-02-20 12:57:39 --> Total execution time: 1.1238
INFO - 2016-02-20 09:57:41 --> Config Class Initialized
INFO - 2016-02-20 09:57:41 --> Hooks Class Initialized
DEBUG - 2016-02-20 09:57:41 --> UTF-8 Support Enabled
INFO - 2016-02-20 09:57:41 --> Utf8 Class Initialized
INFO - 2016-02-20 09:57:41 --> URI Class Initialized
INFO - 2016-02-20 09:57:41 --> Router Class Initialized
INFO - 2016-02-20 09:57:41 --> Output Class Initialized
INFO - 2016-02-20 09:57:41 --> Security Class Initialized
DEBUG - 2016-02-20 09:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 09:57:41 --> Input Class Initialized
INFO - 2016-02-20 09:57:41 --> Language Class Initialized
INFO - 2016-02-20 09:57:41 --> Loader Class Initialized
INFO - 2016-02-20 09:57:41 --> Helper loaded: url_helper
INFO - 2016-02-20 09:57:41 --> Helper loaded: file_helper
INFO - 2016-02-20 09:57:41 --> Helper loaded: date_helper
INFO - 2016-02-20 09:57:41 --> Helper loaded: form_helper
INFO - 2016-02-20 09:57:41 --> Database Driver Class Initialized
INFO - 2016-02-20 09:57:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 09:57:42 --> Controller Class Initialized
INFO - 2016-02-20 09:57:42 --> Model Class Initialized
INFO - 2016-02-20 09:57:42 --> Model Class Initialized
INFO - 2016-02-20 09:57:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 09:57:42 --> Pagination Class Initialized
INFO - 2016-02-20 09:57:42 --> Helper loaded: text_helper
INFO - 2016-02-20 09:57:42 --> Helper loaded: cookie_helper
INFO - 2016-02-20 12:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 12:57:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 12:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 12:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 12:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 12:57:43 --> Final output sent to browser
DEBUG - 2016-02-20 12:57:43 --> Total execution time: 1.1896
INFO - 2016-02-20 10:00:09 --> Config Class Initialized
INFO - 2016-02-20 10:00:09 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:00:09 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:00:09 --> Utf8 Class Initialized
INFO - 2016-02-20 10:00:09 --> URI Class Initialized
INFO - 2016-02-20 10:00:09 --> Router Class Initialized
INFO - 2016-02-20 10:00:09 --> Output Class Initialized
INFO - 2016-02-20 10:00:09 --> Security Class Initialized
DEBUG - 2016-02-20 10:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:00:09 --> Input Class Initialized
INFO - 2016-02-20 10:00:09 --> Language Class Initialized
INFO - 2016-02-20 10:00:09 --> Loader Class Initialized
INFO - 2016-02-20 10:00:09 --> Helper loaded: url_helper
INFO - 2016-02-20 10:00:09 --> Helper loaded: file_helper
INFO - 2016-02-20 10:00:09 --> Helper loaded: date_helper
INFO - 2016-02-20 10:00:09 --> Helper loaded: form_helper
INFO - 2016-02-20 10:00:09 --> Database Driver Class Initialized
INFO - 2016-02-20 10:00:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:00:10 --> Controller Class Initialized
INFO - 2016-02-20 10:00:10 --> Model Class Initialized
INFO - 2016-02-20 10:00:10 --> Model Class Initialized
INFO - 2016-02-20 10:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:00:10 --> Pagination Class Initialized
INFO - 2016-02-20 10:00:10 --> Helper loaded: text_helper
INFO - 2016-02-20 10:00:10 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:00:10 --> Final output sent to browser
DEBUG - 2016-02-20 13:00:10 --> Total execution time: 1.0950
INFO - 2016-02-20 10:00:12 --> Config Class Initialized
INFO - 2016-02-20 10:00:12 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:00:12 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:00:12 --> Utf8 Class Initialized
INFO - 2016-02-20 10:00:12 --> URI Class Initialized
INFO - 2016-02-20 10:00:12 --> Router Class Initialized
INFO - 2016-02-20 10:00:12 --> Output Class Initialized
INFO - 2016-02-20 10:00:12 --> Security Class Initialized
DEBUG - 2016-02-20 10:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:00:12 --> Input Class Initialized
INFO - 2016-02-20 10:00:12 --> Language Class Initialized
INFO - 2016-02-20 10:00:12 --> Loader Class Initialized
INFO - 2016-02-20 10:00:12 --> Helper loaded: url_helper
INFO - 2016-02-20 10:00:12 --> Helper loaded: file_helper
INFO - 2016-02-20 10:00:12 --> Helper loaded: date_helper
INFO - 2016-02-20 10:00:12 --> Helper loaded: form_helper
INFO - 2016-02-20 10:00:12 --> Database Driver Class Initialized
INFO - 2016-02-20 10:00:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:00:13 --> Controller Class Initialized
INFO - 2016-02-20 10:00:13 --> Model Class Initialized
INFO - 2016-02-20 10:00:14 --> Model Class Initialized
INFO - 2016-02-20 10:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:00:14 --> Pagination Class Initialized
INFO - 2016-02-20 10:00:14 --> Helper loaded: text_helper
INFO - 2016-02-20 10:00:14 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 13:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 13:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:00:14 --> Final output sent to browser
DEBUG - 2016-02-20 13:00:14 --> Total execution time: 1.1321
INFO - 2016-02-20 10:00:24 --> Config Class Initialized
INFO - 2016-02-20 10:00:24 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:00:24 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:00:24 --> Utf8 Class Initialized
INFO - 2016-02-20 10:00:25 --> URI Class Initialized
INFO - 2016-02-20 10:00:25 --> Router Class Initialized
INFO - 2016-02-20 10:00:25 --> Output Class Initialized
INFO - 2016-02-20 10:00:25 --> Security Class Initialized
DEBUG - 2016-02-20 10:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:00:25 --> Input Class Initialized
INFO - 2016-02-20 10:00:25 --> Language Class Initialized
INFO - 2016-02-20 10:00:25 --> Loader Class Initialized
INFO - 2016-02-20 10:00:25 --> Helper loaded: url_helper
INFO - 2016-02-20 10:00:25 --> Helper loaded: file_helper
INFO - 2016-02-20 10:00:25 --> Helper loaded: date_helper
INFO - 2016-02-20 10:00:25 --> Helper loaded: form_helper
INFO - 2016-02-20 10:00:25 --> Database Driver Class Initialized
INFO - 2016-02-20 10:00:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:00:26 --> Controller Class Initialized
INFO - 2016-02-20 10:00:26 --> Model Class Initialized
INFO - 2016-02-20 10:00:26 --> Model Class Initialized
INFO - 2016-02-20 10:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:00:26 --> Pagination Class Initialized
INFO - 2016-02-20 10:00:26 --> Helper loaded: text_helper
INFO - 2016-02-20 10:00:26 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:00:26 --> Final output sent to browser
DEBUG - 2016-02-20 13:00:26 --> Total execution time: 1.1374
INFO - 2016-02-20 10:00:27 --> Config Class Initialized
INFO - 2016-02-20 10:00:27 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:00:27 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:00:27 --> Utf8 Class Initialized
INFO - 2016-02-20 10:00:27 --> URI Class Initialized
INFO - 2016-02-20 10:00:27 --> Router Class Initialized
INFO - 2016-02-20 10:00:27 --> Output Class Initialized
INFO - 2016-02-20 10:00:27 --> Security Class Initialized
DEBUG - 2016-02-20 10:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:00:27 --> Input Class Initialized
INFO - 2016-02-20 10:00:27 --> Language Class Initialized
INFO - 2016-02-20 10:00:27 --> Loader Class Initialized
INFO - 2016-02-20 10:00:27 --> Helper loaded: url_helper
INFO - 2016-02-20 10:00:27 --> Helper loaded: file_helper
INFO - 2016-02-20 10:00:27 --> Helper loaded: date_helper
INFO - 2016-02-20 10:00:27 --> Helper loaded: form_helper
INFO - 2016-02-20 10:00:27 --> Database Driver Class Initialized
INFO - 2016-02-20 10:00:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:00:28 --> Controller Class Initialized
INFO - 2016-02-20 10:00:28 --> Model Class Initialized
INFO - 2016-02-20 10:00:28 --> Model Class Initialized
INFO - 2016-02-20 10:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:00:28 --> Pagination Class Initialized
INFO - 2016-02-20 10:00:28 --> Helper loaded: text_helper
INFO - 2016-02-20 10:00:28 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:00:28 --> Final output sent to browser
DEBUG - 2016-02-20 13:00:28 --> Total execution time: 1.1735
INFO - 2016-02-20 10:01:19 --> Config Class Initialized
INFO - 2016-02-20 10:01:19 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:01:19 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:01:19 --> Utf8 Class Initialized
INFO - 2016-02-20 10:01:19 --> URI Class Initialized
DEBUG - 2016-02-20 10:01:19 --> No URI present. Default controller set.
INFO - 2016-02-20 10:01:19 --> Router Class Initialized
INFO - 2016-02-20 10:01:19 --> Output Class Initialized
INFO - 2016-02-20 10:01:19 --> Security Class Initialized
DEBUG - 2016-02-20 10:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:01:19 --> Input Class Initialized
INFO - 2016-02-20 10:01:19 --> Language Class Initialized
INFO - 2016-02-20 10:01:19 --> Loader Class Initialized
INFO - 2016-02-20 10:01:19 --> Helper loaded: url_helper
INFO - 2016-02-20 10:01:19 --> Helper loaded: file_helper
INFO - 2016-02-20 10:01:19 --> Helper loaded: date_helper
INFO - 2016-02-20 10:01:19 --> Helper loaded: form_helper
INFO - 2016-02-20 10:01:19 --> Database Driver Class Initialized
INFO - 2016-02-20 10:01:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:01:20 --> Controller Class Initialized
INFO - 2016-02-20 10:01:20 --> Model Class Initialized
INFO - 2016-02-20 10:01:20 --> Model Class Initialized
INFO - 2016-02-20 10:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:01:20 --> Pagination Class Initialized
INFO - 2016-02-20 10:01:20 --> Helper loaded: text_helper
INFO - 2016-02-20 10:01:20 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:01:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:01:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 13:01:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-20 13:01:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 10:01:26 --> Config Class Initialized
INFO - 2016-02-20 10:01:26 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:01:26 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:01:26 --> Utf8 Class Initialized
INFO - 2016-02-20 10:01:26 --> URI Class Initialized
INFO - 2016-02-20 10:01:26 --> Router Class Initialized
INFO - 2016-02-20 10:01:26 --> Output Class Initialized
INFO - 2016-02-20 10:01:26 --> Security Class Initialized
DEBUG - 2016-02-20 10:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:01:26 --> Input Class Initialized
INFO - 2016-02-20 10:01:26 --> Language Class Initialized
INFO - 2016-02-20 10:01:26 --> Loader Class Initialized
INFO - 2016-02-20 10:01:26 --> Helper loaded: url_helper
INFO - 2016-02-20 10:01:26 --> Helper loaded: file_helper
INFO - 2016-02-20 10:01:26 --> Helper loaded: date_helper
INFO - 2016-02-20 10:01:26 --> Helper loaded: form_helper
INFO - 2016-02-20 10:01:26 --> Database Driver Class Initialized
INFO - 2016-02-20 10:01:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:01:27 --> Controller Class Initialized
INFO - 2016-02-20 10:01:27 --> Model Class Initialized
INFO - 2016-02-20 10:01:27 --> Model Class Initialized
INFO - 2016-02-20 10:01:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:01:27 --> Pagination Class Initialized
INFO - 2016-02-20 10:01:27 --> Helper loaded: text_helper
INFO - 2016-02-20 10:01:27 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:01:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:01:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:01:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 13:01:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 13:01:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:01:27 --> Final output sent to browser
DEBUG - 2016-02-20 13:01:27 --> Total execution time: 1.1796
INFO - 2016-02-20 10:01:30 --> Config Class Initialized
INFO - 2016-02-20 10:01:30 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:01:30 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:01:30 --> Utf8 Class Initialized
INFO - 2016-02-20 10:01:30 --> URI Class Initialized
INFO - 2016-02-20 10:01:30 --> Router Class Initialized
INFO - 2016-02-20 10:01:30 --> Output Class Initialized
INFO - 2016-02-20 10:01:30 --> Security Class Initialized
DEBUG - 2016-02-20 10:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:01:30 --> Input Class Initialized
INFO - 2016-02-20 10:01:30 --> Language Class Initialized
INFO - 2016-02-20 10:01:30 --> Loader Class Initialized
INFO - 2016-02-20 10:01:30 --> Helper loaded: url_helper
INFO - 2016-02-20 10:01:30 --> Helper loaded: file_helper
INFO - 2016-02-20 10:01:30 --> Helper loaded: date_helper
INFO - 2016-02-20 10:01:30 --> Helper loaded: form_helper
INFO - 2016-02-20 10:01:30 --> Database Driver Class Initialized
INFO - 2016-02-20 10:01:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:01:31 --> Controller Class Initialized
INFO - 2016-02-20 10:01:31 --> Model Class Initialized
INFO - 2016-02-20 10:01:31 --> Model Class Initialized
INFO - 2016-02-20 10:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:01:31 --> Pagination Class Initialized
INFO - 2016-02-20 10:01:31 --> Helper loaded: text_helper
INFO - 2016-02-20 10:01:31 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:01:31 --> Final output sent to browser
DEBUG - 2016-02-20 13:01:31 --> Total execution time: 1.1710
INFO - 2016-02-20 10:05:17 --> Config Class Initialized
INFO - 2016-02-20 10:05:17 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:05:17 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:05:17 --> Utf8 Class Initialized
INFO - 2016-02-20 10:05:17 --> URI Class Initialized
INFO - 2016-02-20 10:05:17 --> Router Class Initialized
INFO - 2016-02-20 10:05:17 --> Output Class Initialized
INFO - 2016-02-20 10:05:17 --> Security Class Initialized
DEBUG - 2016-02-20 10:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:05:17 --> Input Class Initialized
INFO - 2016-02-20 10:05:17 --> Language Class Initialized
INFO - 2016-02-20 10:05:17 --> Loader Class Initialized
INFO - 2016-02-20 10:05:17 --> Helper loaded: url_helper
INFO - 2016-02-20 10:05:17 --> Helper loaded: file_helper
INFO - 2016-02-20 10:05:17 --> Helper loaded: date_helper
INFO - 2016-02-20 10:05:17 --> Helper loaded: form_helper
INFO - 2016-02-20 10:05:17 --> Database Driver Class Initialized
INFO - 2016-02-20 10:05:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:05:18 --> Controller Class Initialized
INFO - 2016-02-20 10:05:18 --> Model Class Initialized
INFO - 2016-02-20 10:05:18 --> Model Class Initialized
INFO - 2016-02-20 10:05:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:05:18 --> Pagination Class Initialized
INFO - 2016-02-20 10:05:18 --> Helper loaded: text_helper
INFO - 2016-02-20 10:05:18 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:05:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:05:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:05:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:05:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:05:18 --> Final output sent to browser
DEBUG - 2016-02-20 13:05:18 --> Total execution time: 1.1327
INFO - 2016-02-20 10:05:19 --> Config Class Initialized
INFO - 2016-02-20 10:05:19 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:05:19 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:05:19 --> Utf8 Class Initialized
INFO - 2016-02-20 10:05:19 --> URI Class Initialized
INFO - 2016-02-20 10:05:19 --> Router Class Initialized
INFO - 2016-02-20 10:05:19 --> Output Class Initialized
INFO - 2016-02-20 10:05:19 --> Security Class Initialized
DEBUG - 2016-02-20 10:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:05:19 --> Input Class Initialized
INFO - 2016-02-20 10:05:19 --> Language Class Initialized
INFO - 2016-02-20 10:05:19 --> Loader Class Initialized
INFO - 2016-02-20 10:05:19 --> Helper loaded: url_helper
INFO - 2016-02-20 10:05:19 --> Helper loaded: file_helper
INFO - 2016-02-20 10:05:19 --> Helper loaded: date_helper
INFO - 2016-02-20 10:05:19 --> Helper loaded: form_helper
INFO - 2016-02-20 10:05:19 --> Database Driver Class Initialized
INFO - 2016-02-20 10:05:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:05:20 --> Controller Class Initialized
INFO - 2016-02-20 10:05:20 --> Model Class Initialized
INFO - 2016-02-20 10:05:20 --> Model Class Initialized
INFO - 2016-02-20 10:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:05:20 --> Pagination Class Initialized
INFO - 2016-02-20 10:05:20 --> Helper loaded: text_helper
INFO - 2016-02-20 10:05:20 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:05:20 --> Final output sent to browser
DEBUG - 2016-02-20 13:05:20 --> Total execution time: 1.1261
INFO - 2016-02-20 10:05:58 --> Config Class Initialized
INFO - 2016-02-20 10:05:58 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:05:58 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:05:58 --> Utf8 Class Initialized
INFO - 2016-02-20 10:05:58 --> URI Class Initialized
INFO - 2016-02-20 10:05:58 --> Router Class Initialized
INFO - 2016-02-20 10:05:58 --> Output Class Initialized
INFO - 2016-02-20 10:05:58 --> Security Class Initialized
DEBUG - 2016-02-20 10:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:05:58 --> Input Class Initialized
INFO - 2016-02-20 10:05:58 --> Language Class Initialized
INFO - 2016-02-20 10:05:58 --> Loader Class Initialized
INFO - 2016-02-20 10:05:58 --> Helper loaded: url_helper
INFO - 2016-02-20 10:05:58 --> Helper loaded: file_helper
INFO - 2016-02-20 10:05:58 --> Helper loaded: date_helper
INFO - 2016-02-20 10:05:58 --> Helper loaded: form_helper
INFO - 2016-02-20 10:05:58 --> Database Driver Class Initialized
INFO - 2016-02-20 10:05:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:05:59 --> Controller Class Initialized
INFO - 2016-02-20 10:05:59 --> Model Class Initialized
INFO - 2016-02-20 10:05:59 --> Model Class Initialized
INFO - 2016-02-20 10:05:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:05:59 --> Pagination Class Initialized
INFO - 2016-02-20 10:05:59 --> Helper loaded: text_helper
INFO - 2016-02-20 10:05:59 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:05:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:05:59 --> Final output sent to browser
DEBUG - 2016-02-20 13:05:59 --> Total execution time: 1.1584
INFO - 2016-02-20 10:06:03 --> Config Class Initialized
INFO - 2016-02-20 10:06:03 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:06:03 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:06:03 --> Utf8 Class Initialized
INFO - 2016-02-20 10:06:03 --> URI Class Initialized
INFO - 2016-02-20 10:06:03 --> Router Class Initialized
INFO - 2016-02-20 10:06:03 --> Output Class Initialized
INFO - 2016-02-20 10:06:03 --> Security Class Initialized
DEBUG - 2016-02-20 10:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:06:03 --> Input Class Initialized
INFO - 2016-02-20 10:06:03 --> Language Class Initialized
INFO - 2016-02-20 10:06:03 --> Loader Class Initialized
INFO - 2016-02-20 10:06:03 --> Helper loaded: url_helper
INFO - 2016-02-20 10:06:03 --> Helper loaded: file_helper
INFO - 2016-02-20 10:06:03 --> Helper loaded: date_helper
INFO - 2016-02-20 10:06:03 --> Helper loaded: form_helper
INFO - 2016-02-20 10:06:03 --> Database Driver Class Initialized
INFO - 2016-02-20 10:06:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:06:04 --> Controller Class Initialized
INFO - 2016-02-20 10:06:04 --> Model Class Initialized
INFO - 2016-02-20 10:06:04 --> Model Class Initialized
INFO - 2016-02-20 10:06:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:06:04 --> Pagination Class Initialized
INFO - 2016-02-20 10:06:04 --> Helper loaded: text_helper
INFO - 2016-02-20 10:06:04 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:06:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:06:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:06:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:06:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:06:04 --> Final output sent to browser
DEBUG - 2016-02-20 13:06:04 --> Total execution time: 1.1261
INFO - 2016-02-20 10:06:11 --> Config Class Initialized
INFO - 2016-02-20 10:06:11 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:06:11 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:06:11 --> Utf8 Class Initialized
INFO - 2016-02-20 10:06:11 --> URI Class Initialized
INFO - 2016-02-20 10:06:11 --> Router Class Initialized
INFO - 2016-02-20 10:06:11 --> Output Class Initialized
INFO - 2016-02-20 10:06:11 --> Security Class Initialized
DEBUG - 2016-02-20 10:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:06:11 --> Input Class Initialized
INFO - 2016-02-20 10:06:11 --> Language Class Initialized
INFO - 2016-02-20 10:06:11 --> Loader Class Initialized
INFO - 2016-02-20 10:06:11 --> Helper loaded: url_helper
INFO - 2016-02-20 10:06:11 --> Helper loaded: file_helper
INFO - 2016-02-20 10:06:11 --> Helper loaded: date_helper
INFO - 2016-02-20 10:06:11 --> Helper loaded: form_helper
INFO - 2016-02-20 10:06:11 --> Database Driver Class Initialized
INFO - 2016-02-20 10:06:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:06:12 --> Controller Class Initialized
INFO - 2016-02-20 10:06:12 --> Model Class Initialized
INFO - 2016-02-20 10:06:12 --> Model Class Initialized
INFO - 2016-02-20 10:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:06:12 --> Pagination Class Initialized
INFO - 2016-02-20 10:06:12 --> Helper loaded: text_helper
INFO - 2016-02-20 10:06:12 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:06:12 --> Final output sent to browser
DEBUG - 2016-02-20 13:06:12 --> Total execution time: 1.1155
INFO - 2016-02-20 10:06:14 --> Config Class Initialized
INFO - 2016-02-20 10:06:14 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:06:14 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:06:14 --> Utf8 Class Initialized
INFO - 2016-02-20 10:06:14 --> URI Class Initialized
INFO - 2016-02-20 10:06:14 --> Router Class Initialized
INFO - 2016-02-20 10:06:14 --> Output Class Initialized
INFO - 2016-02-20 10:06:14 --> Security Class Initialized
DEBUG - 2016-02-20 10:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:06:14 --> Input Class Initialized
INFO - 2016-02-20 10:06:14 --> Language Class Initialized
INFO - 2016-02-20 10:06:14 --> Loader Class Initialized
INFO - 2016-02-20 10:06:14 --> Helper loaded: url_helper
INFO - 2016-02-20 10:06:14 --> Helper loaded: file_helper
INFO - 2016-02-20 10:06:14 --> Helper loaded: date_helper
INFO - 2016-02-20 10:06:14 --> Helper loaded: form_helper
INFO - 2016-02-20 10:06:14 --> Database Driver Class Initialized
INFO - 2016-02-20 10:06:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:06:16 --> Controller Class Initialized
INFO - 2016-02-20 10:06:16 --> Model Class Initialized
INFO - 2016-02-20 10:06:16 --> Model Class Initialized
INFO - 2016-02-20 10:06:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:06:16 --> Pagination Class Initialized
INFO - 2016-02-20 10:06:16 --> Helper loaded: text_helper
INFO - 2016-02-20 10:06:16 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 13:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 13:06:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:06:16 --> Final output sent to browser
DEBUG - 2016-02-20 13:06:16 --> Total execution time: 1.2040
INFO - 2016-02-20 10:20:35 --> Config Class Initialized
INFO - 2016-02-20 10:20:35 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:20:35 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:20:35 --> Utf8 Class Initialized
INFO - 2016-02-20 10:20:35 --> URI Class Initialized
DEBUG - 2016-02-20 10:20:35 --> No URI present. Default controller set.
INFO - 2016-02-20 10:20:35 --> Router Class Initialized
INFO - 2016-02-20 10:20:35 --> Output Class Initialized
INFO - 2016-02-20 10:20:35 --> Security Class Initialized
DEBUG - 2016-02-20 10:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:20:35 --> Input Class Initialized
INFO - 2016-02-20 10:20:35 --> Language Class Initialized
INFO - 2016-02-20 10:20:35 --> Loader Class Initialized
INFO - 2016-02-20 10:20:35 --> Helper loaded: url_helper
INFO - 2016-02-20 10:20:35 --> Helper loaded: file_helper
INFO - 2016-02-20 10:20:35 --> Helper loaded: date_helper
INFO - 2016-02-20 10:20:35 --> Helper loaded: form_helper
INFO - 2016-02-20 10:20:35 --> Database Driver Class Initialized
INFO - 2016-02-20 10:20:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:20:36 --> Controller Class Initialized
INFO - 2016-02-20 10:20:36 --> Model Class Initialized
INFO - 2016-02-20 10:20:36 --> Model Class Initialized
INFO - 2016-02-20 10:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:20:36 --> Pagination Class Initialized
INFO - 2016-02-20 10:20:36 --> Helper loaded: text_helper
INFO - 2016-02-20 10:20:36 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 13:20:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-20 13:20:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 10:20:42 --> Config Class Initialized
INFO - 2016-02-20 10:20:42 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:20:42 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:20:42 --> Utf8 Class Initialized
INFO - 2016-02-20 10:20:42 --> URI Class Initialized
INFO - 2016-02-20 10:20:42 --> Router Class Initialized
INFO - 2016-02-20 10:20:42 --> Output Class Initialized
INFO - 2016-02-20 10:20:42 --> Security Class Initialized
DEBUG - 2016-02-20 10:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:20:42 --> Input Class Initialized
INFO - 2016-02-20 10:20:42 --> Language Class Initialized
INFO - 2016-02-20 10:20:42 --> Loader Class Initialized
INFO - 2016-02-20 10:20:42 --> Helper loaded: url_helper
INFO - 2016-02-20 10:20:42 --> Helper loaded: file_helper
INFO - 2016-02-20 10:20:42 --> Helper loaded: date_helper
INFO - 2016-02-20 10:20:42 --> Helper loaded: form_helper
INFO - 2016-02-20 10:20:42 --> Database Driver Class Initialized
INFO - 2016-02-20 10:20:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:20:43 --> Controller Class Initialized
INFO - 2016-02-20 10:20:43 --> Model Class Initialized
INFO - 2016-02-20 10:20:43 --> Model Class Initialized
INFO - 2016-02-20 10:20:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:20:43 --> Pagination Class Initialized
INFO - 2016-02-20 10:20:43 --> Helper loaded: text_helper
INFO - 2016-02-20 10:20:43 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:20:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:20:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:20:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:20:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:20:43 --> Final output sent to browser
DEBUG - 2016-02-20 13:20:43 --> Total execution time: 1.1625
INFO - 2016-02-20 10:24:20 --> Config Class Initialized
INFO - 2016-02-20 10:24:20 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:24:20 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:24:20 --> Utf8 Class Initialized
INFO - 2016-02-20 10:24:20 --> URI Class Initialized
INFO - 2016-02-20 10:24:20 --> Router Class Initialized
INFO - 2016-02-20 10:24:20 --> Output Class Initialized
INFO - 2016-02-20 10:24:20 --> Security Class Initialized
DEBUG - 2016-02-20 10:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:24:20 --> Input Class Initialized
INFO - 2016-02-20 10:24:20 --> Language Class Initialized
INFO - 2016-02-20 10:24:20 --> Loader Class Initialized
INFO - 2016-02-20 10:24:20 --> Helper loaded: url_helper
INFO - 2016-02-20 10:24:20 --> Helper loaded: file_helper
INFO - 2016-02-20 10:24:20 --> Helper loaded: date_helper
INFO - 2016-02-20 10:24:20 --> Helper loaded: form_helper
INFO - 2016-02-20 10:24:20 --> Database Driver Class Initialized
INFO - 2016-02-20 10:24:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:24:21 --> Controller Class Initialized
INFO - 2016-02-20 10:24:21 --> Model Class Initialized
INFO - 2016-02-20 10:24:21 --> Model Class Initialized
INFO - 2016-02-20 10:24:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:24:21 --> Pagination Class Initialized
INFO - 2016-02-20 10:24:21 --> Helper loaded: text_helper
INFO - 2016-02-20 10:24:21 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:24:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:24:21 --> Final output sent to browser
DEBUG - 2016-02-20 13:24:21 --> Total execution time: 1.1584
INFO - 2016-02-20 10:24:32 --> Config Class Initialized
INFO - 2016-02-20 10:24:32 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:24:32 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:24:33 --> Utf8 Class Initialized
INFO - 2016-02-20 10:24:33 --> URI Class Initialized
INFO - 2016-02-20 10:24:33 --> Router Class Initialized
INFO - 2016-02-20 10:24:33 --> Output Class Initialized
INFO - 2016-02-20 10:24:33 --> Security Class Initialized
DEBUG - 2016-02-20 10:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:24:33 --> Input Class Initialized
INFO - 2016-02-20 10:24:33 --> Language Class Initialized
INFO - 2016-02-20 10:24:33 --> Loader Class Initialized
INFO - 2016-02-20 10:24:33 --> Helper loaded: url_helper
INFO - 2016-02-20 10:24:33 --> Helper loaded: file_helper
INFO - 2016-02-20 10:24:33 --> Helper loaded: date_helper
INFO - 2016-02-20 10:24:33 --> Helper loaded: form_helper
INFO - 2016-02-20 10:24:33 --> Database Driver Class Initialized
INFO - 2016-02-20 10:24:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:24:34 --> Controller Class Initialized
INFO - 2016-02-20 10:24:34 --> Model Class Initialized
INFO - 2016-02-20 10:24:34 --> Model Class Initialized
INFO - 2016-02-20 10:24:34 --> Form Validation Class Initialized
INFO - 2016-02-20 10:24:34 --> Helper loaded: text_helper
INFO - 2016-02-20 10:24:34 --> Config Class Initialized
INFO - 2016-02-20 10:24:34 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:24:34 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:24:34 --> Utf8 Class Initialized
INFO - 2016-02-20 10:24:34 --> URI Class Initialized
INFO - 2016-02-20 10:24:34 --> Router Class Initialized
INFO - 2016-02-20 10:24:34 --> Output Class Initialized
INFO - 2016-02-20 10:24:34 --> Security Class Initialized
DEBUG - 2016-02-20 10:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:24:34 --> Input Class Initialized
INFO - 2016-02-20 10:24:34 --> Language Class Initialized
INFO - 2016-02-20 10:24:34 --> Loader Class Initialized
INFO - 2016-02-20 10:24:34 --> Helper loaded: url_helper
INFO - 2016-02-20 10:24:34 --> Helper loaded: file_helper
INFO - 2016-02-20 10:24:34 --> Helper loaded: date_helper
INFO - 2016-02-20 10:24:34 --> Helper loaded: form_helper
INFO - 2016-02-20 10:24:34 --> Database Driver Class Initialized
INFO - 2016-02-20 10:24:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:24:35 --> Controller Class Initialized
INFO - 2016-02-20 10:24:35 --> Model Class Initialized
INFO - 2016-02-20 10:24:35 --> Model Class Initialized
INFO - 2016-02-20 10:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:24:35 --> Pagination Class Initialized
INFO - 2016-02-20 10:24:35 --> Helper loaded: text_helper
INFO - 2016-02-20 10:24:35 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:24:35 --> Final output sent to browser
DEBUG - 2016-02-20 13:24:35 --> Total execution time: 1.1767
INFO - 2016-02-20 10:24:38 --> Config Class Initialized
INFO - 2016-02-20 10:24:38 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:24:38 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:24:38 --> Utf8 Class Initialized
INFO - 2016-02-20 10:24:38 --> URI Class Initialized
INFO - 2016-02-20 10:24:38 --> Router Class Initialized
INFO - 2016-02-20 10:24:38 --> Output Class Initialized
INFO - 2016-02-20 10:24:38 --> Security Class Initialized
DEBUG - 2016-02-20 10:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:24:38 --> Input Class Initialized
INFO - 2016-02-20 10:24:38 --> Language Class Initialized
INFO - 2016-02-20 10:24:38 --> Loader Class Initialized
INFO - 2016-02-20 10:24:38 --> Helper loaded: url_helper
INFO - 2016-02-20 10:24:38 --> Helper loaded: file_helper
INFO - 2016-02-20 10:24:38 --> Helper loaded: date_helper
INFO - 2016-02-20 10:24:38 --> Helper loaded: form_helper
INFO - 2016-02-20 10:24:38 --> Database Driver Class Initialized
INFO - 2016-02-20 10:24:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:24:39 --> Controller Class Initialized
INFO - 2016-02-20 10:24:39 --> Model Class Initialized
INFO - 2016-02-20 10:24:39 --> Model Class Initialized
INFO - 2016-02-20 10:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:24:39 --> Pagination Class Initialized
INFO - 2016-02-20 10:24:39 --> Helper loaded: text_helper
INFO - 2016-02-20 10:24:39 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 13:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 13:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:24:39 --> Final output sent to browser
DEBUG - 2016-02-20 13:24:39 --> Total execution time: 1.1940
INFO - 2016-02-20 10:24:47 --> Config Class Initialized
INFO - 2016-02-20 10:24:47 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:24:47 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:24:47 --> Utf8 Class Initialized
INFO - 2016-02-20 10:24:47 --> URI Class Initialized
INFO - 2016-02-20 10:24:47 --> Router Class Initialized
INFO - 2016-02-20 10:24:47 --> Output Class Initialized
INFO - 2016-02-20 10:24:47 --> Security Class Initialized
DEBUG - 2016-02-20 10:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:24:47 --> Input Class Initialized
INFO - 2016-02-20 10:24:47 --> Language Class Initialized
INFO - 2016-02-20 10:24:47 --> Loader Class Initialized
INFO - 2016-02-20 10:24:47 --> Helper loaded: url_helper
INFO - 2016-02-20 10:24:47 --> Helper loaded: file_helper
INFO - 2016-02-20 10:24:47 --> Helper loaded: date_helper
INFO - 2016-02-20 10:24:47 --> Helper loaded: form_helper
INFO - 2016-02-20 10:24:47 --> Database Driver Class Initialized
INFO - 2016-02-20 10:24:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:24:48 --> Controller Class Initialized
INFO - 2016-02-20 10:24:48 --> Model Class Initialized
INFO - 2016-02-20 10:24:48 --> Model Class Initialized
INFO - 2016-02-20 10:24:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:24:48 --> Pagination Class Initialized
INFO - 2016-02-20 10:24:48 --> Helper loaded: text_helper
INFO - 2016-02-20 10:24:48 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:24:48 --> Form Validation Class Initialized
INFO - 2016-02-20 13:24:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-20 13:24:48 --> Model Class Initialized
ERROR - 2016-02-20 13:24:48 --> Severity: Warning --> Missing argument 2 for Jboard_model::add_comment(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 222 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 100
ERROR - 2016-02-20 13:24:48 --> Severity: Notice --> Undefined variable: comment_array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 103
ERROR - 2016-02-20 13:24:48 --> Severity: Notice --> Undefined variable: comment_array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 104
ERROR - 2016-02-20 13:24:48 --> Severity: Notice --> Undefined variable: comment_array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 105
ERROR - 2016-02-20 13:24:48 --> Severity: Notice --> Undefined variable: comment_array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 106
ERROR - 2016-02-20 13:24:48 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-20 13:24:48 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `board_id`, `user_id`, `user_name`, `article`) VALUES (NOW(), NULL, NULL, NULL, '')
INFO - 2016-02-20 13:24:48 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 13:24:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-20 10:27:22 --> Config Class Initialized
INFO - 2016-02-20 10:27:22 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:27:22 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:27:22 --> Utf8 Class Initialized
INFO - 2016-02-20 10:27:22 --> URI Class Initialized
INFO - 2016-02-20 10:27:22 --> Router Class Initialized
INFO - 2016-02-20 10:27:22 --> Output Class Initialized
INFO - 2016-02-20 10:27:22 --> Security Class Initialized
DEBUG - 2016-02-20 10:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:27:22 --> Input Class Initialized
INFO - 2016-02-20 10:27:22 --> Language Class Initialized
INFO - 2016-02-20 10:27:22 --> Loader Class Initialized
INFO - 2016-02-20 10:27:22 --> Helper loaded: url_helper
INFO - 2016-02-20 10:27:22 --> Helper loaded: file_helper
INFO - 2016-02-20 10:27:22 --> Helper loaded: date_helper
INFO - 2016-02-20 10:27:22 --> Helper loaded: form_helper
INFO - 2016-02-20 10:27:22 --> Database Driver Class Initialized
INFO - 2016-02-20 10:27:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:27:23 --> Controller Class Initialized
INFO - 2016-02-20 10:27:23 --> Model Class Initialized
INFO - 2016-02-20 10:27:23 --> Model Class Initialized
INFO - 2016-02-20 10:27:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:27:23 --> Pagination Class Initialized
INFO - 2016-02-20 10:27:23 --> Helper loaded: text_helper
INFO - 2016-02-20 10:27:23 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:27:23 --> Form Validation Class Initialized
INFO - 2016-02-20 13:27:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-20 13:27:23 --> Model Class Initialized
ERROR - 2016-02-20 13:27:23 --> Severity: Warning --> Missing argument 2 for Jboard_model::add_comment(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 222 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 100
ERROR - 2016-02-20 13:27:23 --> Severity: Notice --> Undefined variable: comment_array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 103
ERROR - 2016-02-20 13:27:23 --> Severity: Notice --> Undefined variable: comment_array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 104
ERROR - 2016-02-20 13:27:23 --> Severity: Notice --> Undefined variable: comment_array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 105
ERROR - 2016-02-20 13:27:23 --> Severity: Notice --> Undefined variable: comment_array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 106
ERROR - 2016-02-20 13:27:23 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_driver.php 1465
ERROR - 2016-02-20 13:27:23 --> Query error: Table 'jdboard.array' doesn't exist - Invalid query: INSERT INTO Array (created, `board_id`, `user_id`, `user_name`, `article`) VALUES (NOW(), NULL, NULL, NULL, '')
INFO - 2016-02-20 13:27:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 13:27:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-20 10:28:11 --> Config Class Initialized
INFO - 2016-02-20 10:28:11 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:28:11 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:28:11 --> Utf8 Class Initialized
INFO - 2016-02-20 10:28:11 --> URI Class Initialized
INFO - 2016-02-20 10:28:11 --> Router Class Initialized
INFO - 2016-02-20 10:28:11 --> Output Class Initialized
INFO - 2016-02-20 10:28:11 --> Security Class Initialized
DEBUG - 2016-02-20 10:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:28:11 --> Input Class Initialized
INFO - 2016-02-20 10:28:11 --> Language Class Initialized
INFO - 2016-02-20 10:28:11 --> Loader Class Initialized
INFO - 2016-02-20 10:28:11 --> Helper loaded: url_helper
INFO - 2016-02-20 10:28:11 --> Helper loaded: file_helper
INFO - 2016-02-20 10:28:11 --> Helper loaded: date_helper
INFO - 2016-02-20 10:28:11 --> Helper loaded: form_helper
INFO - 2016-02-20 10:28:11 --> Database Driver Class Initialized
INFO - 2016-02-20 10:28:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:28:12 --> Controller Class Initialized
INFO - 2016-02-20 10:28:12 --> Model Class Initialized
INFO - 2016-02-20 10:28:12 --> Model Class Initialized
INFO - 2016-02-20 10:28:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:28:12 --> Pagination Class Initialized
INFO - 2016-02-20 10:28:12 --> Helper loaded: text_helper
INFO - 2016-02-20 10:28:12 --> Helper loaded: cookie_helper
ERROR - 2016-02-20 13:28:12 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 42
INFO - 2016-02-20 10:28:49 --> Config Class Initialized
INFO - 2016-02-20 10:28:49 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:28:49 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:28:49 --> Utf8 Class Initialized
INFO - 2016-02-20 10:28:49 --> URI Class Initialized
INFO - 2016-02-20 10:28:49 --> Router Class Initialized
INFO - 2016-02-20 10:28:49 --> Output Class Initialized
INFO - 2016-02-20 10:28:49 --> Security Class Initialized
DEBUG - 2016-02-20 10:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:28:49 --> Input Class Initialized
INFO - 2016-02-20 10:28:49 --> Language Class Initialized
INFO - 2016-02-20 10:28:49 --> Loader Class Initialized
INFO - 2016-02-20 10:28:49 --> Helper loaded: url_helper
INFO - 2016-02-20 10:28:49 --> Helper loaded: file_helper
INFO - 2016-02-20 10:28:49 --> Helper loaded: date_helper
INFO - 2016-02-20 10:28:49 --> Helper loaded: form_helper
INFO - 2016-02-20 10:28:49 --> Database Driver Class Initialized
INFO - 2016-02-20 10:28:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:28:50 --> Controller Class Initialized
INFO - 2016-02-20 10:28:50 --> Model Class Initialized
INFO - 2016-02-20 10:28:50 --> Model Class Initialized
INFO - 2016-02-20 10:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:28:50 --> Pagination Class Initialized
INFO - 2016-02-20 10:28:50 --> Helper loaded: text_helper
INFO - 2016-02-20 10:28:50 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:28:50 --> Final output sent to browser
DEBUG - 2016-02-20 13:28:50 --> Total execution time: 1.1574
INFO - 2016-02-20 10:28:52 --> Config Class Initialized
INFO - 2016-02-20 10:28:52 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:28:52 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:28:52 --> Utf8 Class Initialized
INFO - 2016-02-20 10:28:52 --> URI Class Initialized
INFO - 2016-02-20 10:28:52 --> Router Class Initialized
INFO - 2016-02-20 10:28:52 --> Output Class Initialized
INFO - 2016-02-20 10:28:52 --> Security Class Initialized
DEBUG - 2016-02-20 10:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:28:52 --> Input Class Initialized
INFO - 2016-02-20 10:28:52 --> Language Class Initialized
INFO - 2016-02-20 10:28:52 --> Loader Class Initialized
INFO - 2016-02-20 10:28:52 --> Helper loaded: url_helper
INFO - 2016-02-20 10:28:52 --> Helper loaded: file_helper
INFO - 2016-02-20 10:28:52 --> Helper loaded: date_helper
INFO - 2016-02-20 10:28:52 --> Helper loaded: form_helper
INFO - 2016-02-20 10:28:52 --> Database Driver Class Initialized
INFO - 2016-02-20 10:28:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:28:54 --> Controller Class Initialized
INFO - 2016-02-20 10:28:54 --> Model Class Initialized
INFO - 2016-02-20 10:28:54 --> Model Class Initialized
INFO - 2016-02-20 10:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:28:54 --> Pagination Class Initialized
INFO - 2016-02-20 10:28:54 --> Helper loaded: text_helper
INFO - 2016-02-20 10:28:54 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 13:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 13:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:28:54 --> Final output sent to browser
DEBUG - 2016-02-20 13:28:54 --> Total execution time: 1.2384
INFO - 2016-02-20 10:28:58 --> Config Class Initialized
INFO - 2016-02-20 10:28:58 --> Hooks Class Initialized
DEBUG - 2016-02-20 10:28:58 --> UTF-8 Support Enabled
INFO - 2016-02-20 10:28:58 --> Utf8 Class Initialized
INFO - 2016-02-20 10:28:58 --> URI Class Initialized
INFO - 2016-02-20 10:28:58 --> Router Class Initialized
INFO - 2016-02-20 10:28:58 --> Output Class Initialized
INFO - 2016-02-20 10:28:58 --> Security Class Initialized
DEBUG - 2016-02-20 10:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 10:28:58 --> Input Class Initialized
INFO - 2016-02-20 10:28:58 --> Language Class Initialized
INFO - 2016-02-20 10:28:58 --> Loader Class Initialized
INFO - 2016-02-20 10:28:58 --> Helper loaded: url_helper
INFO - 2016-02-20 10:28:58 --> Helper loaded: file_helper
INFO - 2016-02-20 10:28:58 --> Helper loaded: date_helper
INFO - 2016-02-20 10:28:58 --> Helper loaded: form_helper
INFO - 2016-02-20 10:28:58 --> Database Driver Class Initialized
INFO - 2016-02-20 10:28:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 10:28:59 --> Controller Class Initialized
INFO - 2016-02-20 10:28:59 --> Model Class Initialized
INFO - 2016-02-20 10:28:59 --> Model Class Initialized
INFO - 2016-02-20 10:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 10:28:59 --> Pagination Class Initialized
INFO - 2016-02-20 10:28:59 --> Helper loaded: text_helper
INFO - 2016-02-20 10:28:59 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:28:59 --> Form Validation Class Initialized
INFO - 2016-02-20 13:28:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-20 13:28:59 --> Model Class Initialized
INFO - 2016-02-20 13:28:59 --> Final output sent to browser
DEBUG - 2016-02-20 13:28:59 --> Total execution time: 1.3399
INFO - 2016-02-20 11:19:16 --> Config Class Initialized
INFO - 2016-02-20 11:19:16 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:19:16 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:19:16 --> Utf8 Class Initialized
INFO - 2016-02-20 11:19:16 --> URI Class Initialized
INFO - 2016-02-20 11:19:16 --> Router Class Initialized
INFO - 2016-02-20 11:19:16 --> Output Class Initialized
INFO - 2016-02-20 11:19:16 --> Security Class Initialized
DEBUG - 2016-02-20 11:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:19:16 --> Input Class Initialized
INFO - 2016-02-20 11:19:16 --> Language Class Initialized
INFO - 2016-02-20 11:19:16 --> Loader Class Initialized
INFO - 2016-02-20 11:19:16 --> Helper loaded: url_helper
INFO - 2016-02-20 11:19:16 --> Helper loaded: file_helper
INFO - 2016-02-20 11:19:16 --> Helper loaded: date_helper
INFO - 2016-02-20 11:19:17 --> Helper loaded: form_helper
INFO - 2016-02-20 11:19:17 --> Database Driver Class Initialized
INFO - 2016-02-20 11:19:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:19:18 --> Controller Class Initialized
INFO - 2016-02-20 11:19:18 --> Model Class Initialized
INFO - 2016-02-20 11:19:18 --> Model Class Initialized
INFO - 2016-02-20 11:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:19:18 --> Pagination Class Initialized
INFO - 2016-02-20 11:19:18 --> Helper loaded: text_helper
INFO - 2016-02-20 11:19:18 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:19:18 --> Final output sent to browser
DEBUG - 2016-02-20 14:19:18 --> Total execution time: 1.1631
INFO - 2016-02-20 11:20:34 --> Config Class Initialized
INFO - 2016-02-20 11:20:34 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:20:34 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:20:34 --> Utf8 Class Initialized
INFO - 2016-02-20 11:20:34 --> URI Class Initialized
INFO - 2016-02-20 11:20:34 --> Router Class Initialized
INFO - 2016-02-20 11:20:34 --> Output Class Initialized
INFO - 2016-02-20 11:20:34 --> Security Class Initialized
DEBUG - 2016-02-20 11:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:20:34 --> Input Class Initialized
INFO - 2016-02-20 11:20:34 --> Language Class Initialized
INFO - 2016-02-20 11:20:34 --> Loader Class Initialized
INFO - 2016-02-20 11:20:34 --> Helper loaded: url_helper
INFO - 2016-02-20 11:20:34 --> Helper loaded: file_helper
INFO - 2016-02-20 11:20:34 --> Helper loaded: date_helper
INFO - 2016-02-20 11:20:34 --> Helper loaded: form_helper
INFO - 2016-02-20 11:20:34 --> Database Driver Class Initialized
INFO - 2016-02-20 11:20:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:20:35 --> Controller Class Initialized
INFO - 2016-02-20 11:20:35 --> Model Class Initialized
INFO - 2016-02-20 11:20:35 --> Model Class Initialized
INFO - 2016-02-20 11:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:20:35 --> Pagination Class Initialized
INFO - 2016-02-20 11:20:35 --> Helper loaded: text_helper
INFO - 2016-02-20 11:20:35 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:20:35 --> Query error: Table 'jdboard.jboard' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `jboard`
INFO - 2016-02-20 14:20:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 11:20:38 --> Config Class Initialized
INFO - 2016-02-20 11:20:38 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:20:38 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:20:38 --> Utf8 Class Initialized
INFO - 2016-02-20 11:20:38 --> URI Class Initialized
INFO - 2016-02-20 11:20:38 --> Router Class Initialized
INFO - 2016-02-20 11:20:38 --> Output Class Initialized
INFO - 2016-02-20 11:20:38 --> Security Class Initialized
DEBUG - 2016-02-20 11:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:20:38 --> Input Class Initialized
INFO - 2016-02-20 11:20:38 --> Language Class Initialized
INFO - 2016-02-20 11:20:38 --> Loader Class Initialized
INFO - 2016-02-20 11:20:38 --> Helper loaded: url_helper
INFO - 2016-02-20 11:20:38 --> Helper loaded: file_helper
INFO - 2016-02-20 11:20:38 --> Helper loaded: date_helper
INFO - 2016-02-20 11:20:38 --> Helper loaded: form_helper
INFO - 2016-02-20 11:20:38 --> Database Driver Class Initialized
INFO - 2016-02-20 11:20:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:20:39 --> Controller Class Initialized
INFO - 2016-02-20 11:20:39 --> Model Class Initialized
INFO - 2016-02-20 11:20:39 --> Model Class Initialized
INFO - 2016-02-20 11:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:20:39 --> Pagination Class Initialized
INFO - 2016-02-20 11:20:39 --> Helper loaded: text_helper
INFO - 2016-02-20 11:20:39 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:20:39 --> Final output sent to browser
DEBUG - 2016-02-20 14:20:39 --> Total execution time: 1.1358
INFO - 2016-02-20 11:21:10 --> Config Class Initialized
INFO - 2016-02-20 11:21:10 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:21:10 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:21:10 --> Utf8 Class Initialized
INFO - 2016-02-20 11:21:10 --> URI Class Initialized
INFO - 2016-02-20 11:21:10 --> Router Class Initialized
INFO - 2016-02-20 11:21:10 --> Output Class Initialized
INFO - 2016-02-20 11:21:10 --> Security Class Initialized
DEBUG - 2016-02-20 11:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:21:10 --> Input Class Initialized
INFO - 2016-02-20 11:21:10 --> Language Class Initialized
INFO - 2016-02-20 11:21:10 --> Loader Class Initialized
INFO - 2016-02-20 11:21:10 --> Helper loaded: url_helper
INFO - 2016-02-20 11:21:10 --> Helper loaded: file_helper
INFO - 2016-02-20 11:21:10 --> Helper loaded: date_helper
INFO - 2016-02-20 11:21:10 --> Helper loaded: form_helper
INFO - 2016-02-20 11:21:10 --> Database Driver Class Initialized
INFO - 2016-02-20 11:21:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:21:11 --> Controller Class Initialized
INFO - 2016-02-20 11:21:11 --> Model Class Initialized
INFO - 2016-02-20 11:21:11 --> Model Class Initialized
INFO - 2016-02-20 11:21:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:21:11 --> Pagination Class Initialized
INFO - 2016-02-20 11:21:11 --> Helper loaded: text_helper
INFO - 2016-02-20 11:21:11 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:21:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:21:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:21:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:21:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:21:11 --> Final output sent to browser
DEBUG - 2016-02-20 14:21:11 --> Total execution time: 1.1757
INFO - 2016-02-20 11:21:14 --> Config Class Initialized
INFO - 2016-02-20 11:21:14 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:21:14 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:21:14 --> Utf8 Class Initialized
INFO - 2016-02-20 11:21:14 --> URI Class Initialized
INFO - 2016-02-20 11:21:14 --> Router Class Initialized
INFO - 2016-02-20 11:21:14 --> Output Class Initialized
INFO - 2016-02-20 11:21:14 --> Security Class Initialized
DEBUG - 2016-02-20 11:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:21:14 --> Input Class Initialized
INFO - 2016-02-20 11:21:14 --> Language Class Initialized
INFO - 2016-02-20 11:21:14 --> Loader Class Initialized
INFO - 2016-02-20 11:21:14 --> Helper loaded: url_helper
INFO - 2016-02-20 11:21:14 --> Helper loaded: file_helper
INFO - 2016-02-20 11:21:14 --> Helper loaded: date_helper
INFO - 2016-02-20 11:21:14 --> Helper loaded: form_helper
INFO - 2016-02-20 11:21:14 --> Database Driver Class Initialized
INFO - 2016-02-20 11:21:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:21:15 --> Controller Class Initialized
INFO - 2016-02-20 11:21:15 --> Model Class Initialized
INFO - 2016-02-20 11:21:15 --> Model Class Initialized
INFO - 2016-02-20 11:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:21:15 --> Pagination Class Initialized
INFO - 2016-02-20 11:21:15 --> Helper loaded: text_helper
INFO - 2016-02-20 11:21:15 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:21:15 --> Final output sent to browser
DEBUG - 2016-02-20 14:21:15 --> Total execution time: 1.1457
INFO - 2016-02-20 11:21:19 --> Config Class Initialized
INFO - 2016-02-20 11:21:19 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:21:19 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:21:19 --> Utf8 Class Initialized
INFO - 2016-02-20 11:21:19 --> URI Class Initialized
INFO - 2016-02-20 11:21:19 --> Router Class Initialized
INFO - 2016-02-20 11:21:19 --> Output Class Initialized
INFO - 2016-02-20 11:21:19 --> Security Class Initialized
DEBUG - 2016-02-20 11:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:21:19 --> Input Class Initialized
INFO - 2016-02-20 11:21:19 --> Language Class Initialized
INFO - 2016-02-20 11:21:19 --> Loader Class Initialized
INFO - 2016-02-20 11:21:19 --> Helper loaded: url_helper
INFO - 2016-02-20 11:21:19 --> Helper loaded: file_helper
INFO - 2016-02-20 11:21:19 --> Helper loaded: date_helper
INFO - 2016-02-20 11:21:19 --> Helper loaded: form_helper
INFO - 2016-02-20 11:21:19 --> Database Driver Class Initialized
INFO - 2016-02-20 11:21:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:21:20 --> Controller Class Initialized
INFO - 2016-02-20 11:21:20 --> Model Class Initialized
INFO - 2016-02-20 11:21:20 --> Model Class Initialized
INFO - 2016-02-20 11:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:21:20 --> Pagination Class Initialized
INFO - 2016-02-20 11:21:20 --> Helper loaded: text_helper
INFO - 2016-02-20 11:21:20 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:21:20 --> Final output sent to browser
DEBUG - 2016-02-20 14:21:20 --> Total execution time: 1.1403
INFO - 2016-02-20 11:21:23 --> Config Class Initialized
INFO - 2016-02-20 11:21:23 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:21:23 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:21:23 --> Utf8 Class Initialized
INFO - 2016-02-20 11:21:23 --> URI Class Initialized
INFO - 2016-02-20 11:21:23 --> Router Class Initialized
INFO - 2016-02-20 11:21:23 --> Output Class Initialized
INFO - 2016-02-20 11:21:23 --> Security Class Initialized
DEBUG - 2016-02-20 11:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:21:23 --> Input Class Initialized
INFO - 2016-02-20 11:21:23 --> Language Class Initialized
INFO - 2016-02-20 11:21:23 --> Loader Class Initialized
INFO - 2016-02-20 11:21:23 --> Helper loaded: url_helper
INFO - 2016-02-20 11:21:23 --> Helper loaded: file_helper
INFO - 2016-02-20 11:21:23 --> Helper loaded: date_helper
INFO - 2016-02-20 11:21:23 --> Helper loaded: form_helper
INFO - 2016-02-20 11:21:23 --> Database Driver Class Initialized
INFO - 2016-02-20 11:21:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:21:24 --> Controller Class Initialized
INFO - 2016-02-20 11:21:24 --> Model Class Initialized
INFO - 2016-02-20 11:21:24 --> Model Class Initialized
INFO - 2016-02-20 11:21:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:21:24 --> Pagination Class Initialized
INFO - 2016-02-20 11:21:24 --> Helper loaded: text_helper
INFO - 2016-02-20 11:21:24 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:21:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:21:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:21:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:21:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:21:25 --> Final output sent to browser
DEBUG - 2016-02-20 14:21:25 --> Total execution time: 1.1997
INFO - 2016-02-20 11:22:04 --> Config Class Initialized
INFO - 2016-02-20 11:22:04 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:22:04 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:22:04 --> Utf8 Class Initialized
INFO - 2016-02-20 11:22:04 --> URI Class Initialized
INFO - 2016-02-20 11:22:04 --> Router Class Initialized
INFO - 2016-02-20 11:22:04 --> Output Class Initialized
INFO - 2016-02-20 11:22:04 --> Security Class Initialized
DEBUG - 2016-02-20 11:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:22:04 --> Input Class Initialized
INFO - 2016-02-20 11:22:04 --> Language Class Initialized
INFO - 2016-02-20 11:22:04 --> Loader Class Initialized
INFO - 2016-02-20 11:22:04 --> Helper loaded: url_helper
INFO - 2016-02-20 11:22:04 --> Helper loaded: file_helper
INFO - 2016-02-20 11:22:04 --> Helper loaded: date_helper
INFO - 2016-02-20 11:22:04 --> Helper loaded: form_helper
INFO - 2016-02-20 11:22:04 --> Database Driver Class Initialized
INFO - 2016-02-20 11:22:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:22:05 --> Controller Class Initialized
INFO - 2016-02-20 11:22:05 --> Model Class Initialized
INFO - 2016-02-20 11:22:05 --> Model Class Initialized
INFO - 2016-02-20 11:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:22:05 --> Pagination Class Initialized
INFO - 2016-02-20 11:22:05 --> Helper loaded: text_helper
INFO - 2016-02-20 11:22:05 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:22:05 --> Final output sent to browser
DEBUG - 2016-02-20 14:22:05 --> Total execution time: 1.1709
INFO - 2016-02-20 11:22:07 --> Config Class Initialized
INFO - 2016-02-20 11:22:07 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:22:07 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:22:07 --> Utf8 Class Initialized
INFO - 2016-02-20 11:22:07 --> URI Class Initialized
INFO - 2016-02-20 11:22:07 --> Router Class Initialized
INFO - 2016-02-20 11:22:07 --> Output Class Initialized
INFO - 2016-02-20 11:22:07 --> Security Class Initialized
DEBUG - 2016-02-20 11:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:22:07 --> Input Class Initialized
INFO - 2016-02-20 11:22:07 --> Language Class Initialized
INFO - 2016-02-20 11:22:07 --> Loader Class Initialized
INFO - 2016-02-20 11:22:07 --> Helper loaded: url_helper
INFO - 2016-02-20 11:22:07 --> Helper loaded: file_helper
INFO - 2016-02-20 11:22:07 --> Helper loaded: date_helper
INFO - 2016-02-20 11:22:07 --> Helper loaded: form_helper
INFO - 2016-02-20 11:22:07 --> Database Driver Class Initialized
INFO - 2016-02-20 11:22:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:22:08 --> Controller Class Initialized
INFO - 2016-02-20 11:22:08 --> Model Class Initialized
INFO - 2016-02-20 11:22:08 --> Model Class Initialized
INFO - 2016-02-20 11:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:22:08 --> Pagination Class Initialized
INFO - 2016-02-20 11:22:08 --> Helper loaded: text_helper
INFO - 2016-02-20 11:22:08 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:22:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:22:08 --> Final output sent to browser
DEBUG - 2016-02-20 14:22:08 --> Total execution time: 1.1992
INFO - 2016-02-20 11:22:17 --> Config Class Initialized
INFO - 2016-02-20 11:22:17 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:22:17 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:22:17 --> Utf8 Class Initialized
INFO - 2016-02-20 11:22:17 --> URI Class Initialized
INFO - 2016-02-20 11:22:17 --> Router Class Initialized
INFO - 2016-02-20 11:22:17 --> Output Class Initialized
INFO - 2016-02-20 11:22:17 --> Security Class Initialized
DEBUG - 2016-02-20 11:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:22:17 --> Input Class Initialized
INFO - 2016-02-20 11:22:17 --> Language Class Initialized
INFO - 2016-02-20 11:22:17 --> Loader Class Initialized
INFO - 2016-02-20 11:22:17 --> Helper loaded: url_helper
INFO - 2016-02-20 11:22:17 --> Helper loaded: file_helper
INFO - 2016-02-20 11:22:17 --> Helper loaded: date_helper
INFO - 2016-02-20 11:22:17 --> Helper loaded: form_helper
INFO - 2016-02-20 11:22:17 --> Database Driver Class Initialized
INFO - 2016-02-20 11:22:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:22:18 --> Controller Class Initialized
INFO - 2016-02-20 11:22:18 --> Model Class Initialized
INFO - 2016-02-20 11:22:18 --> Model Class Initialized
INFO - 2016-02-20 11:22:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:22:18 --> Pagination Class Initialized
INFO - 2016-02-20 11:22:18 --> Helper loaded: text_helper
INFO - 2016-02-20 11:22:18 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:22:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:22:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:22:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:22:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:22:18 --> Final output sent to browser
DEBUG - 2016-02-20 14:22:18 --> Total execution time: 1.1464
INFO - 2016-02-20 11:30:23 --> Config Class Initialized
INFO - 2016-02-20 11:30:23 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:30:23 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:30:23 --> Utf8 Class Initialized
INFO - 2016-02-20 11:30:23 --> URI Class Initialized
INFO - 2016-02-20 11:30:23 --> Router Class Initialized
INFO - 2016-02-20 11:30:23 --> Output Class Initialized
INFO - 2016-02-20 11:30:23 --> Security Class Initialized
DEBUG - 2016-02-20 11:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:30:23 --> Input Class Initialized
INFO - 2016-02-20 11:30:23 --> Language Class Initialized
INFO - 2016-02-20 11:30:23 --> Loader Class Initialized
INFO - 2016-02-20 11:30:23 --> Helper loaded: url_helper
INFO - 2016-02-20 11:30:23 --> Helper loaded: file_helper
INFO - 2016-02-20 11:30:23 --> Helper loaded: date_helper
INFO - 2016-02-20 11:30:23 --> Helper loaded: form_helper
INFO - 2016-02-20 11:30:23 --> Database Driver Class Initialized
INFO - 2016-02-20 11:30:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:30:24 --> Controller Class Initialized
INFO - 2016-02-20 11:30:24 --> Model Class Initialized
INFO - 2016-02-20 11:30:24 --> Model Class Initialized
INFO - 2016-02-20 11:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:30:24 --> Pagination Class Initialized
INFO - 2016-02-20 11:30:24 --> Helper loaded: text_helper
INFO - 2016-02-20 11:30:24 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:30:24 --> Final output sent to browser
DEBUG - 2016-02-20 14:30:24 --> Total execution time: 1.1409
INFO - 2016-02-20 11:30:28 --> Config Class Initialized
INFO - 2016-02-20 11:30:28 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:30:28 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:30:28 --> Utf8 Class Initialized
INFO - 2016-02-20 11:30:28 --> URI Class Initialized
INFO - 2016-02-20 11:30:28 --> Router Class Initialized
INFO - 2016-02-20 11:30:28 --> Output Class Initialized
INFO - 2016-02-20 11:30:28 --> Security Class Initialized
DEBUG - 2016-02-20 11:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:30:28 --> Input Class Initialized
INFO - 2016-02-20 11:30:28 --> Language Class Initialized
INFO - 2016-02-20 11:30:28 --> Loader Class Initialized
INFO - 2016-02-20 11:30:28 --> Helper loaded: url_helper
INFO - 2016-02-20 11:30:28 --> Helper loaded: file_helper
INFO - 2016-02-20 11:30:28 --> Helper loaded: date_helper
INFO - 2016-02-20 11:30:28 --> Helper loaded: form_helper
INFO - 2016-02-20 11:30:28 --> Database Driver Class Initialized
INFO - 2016-02-20 11:30:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:30:29 --> Controller Class Initialized
INFO - 2016-02-20 11:30:29 --> Model Class Initialized
INFO - 2016-02-20 11:30:29 --> Model Class Initialized
INFO - 2016-02-20 11:30:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:30:29 --> Pagination Class Initialized
INFO - 2016-02-20 11:30:29 --> Helper loaded: text_helper
INFO - 2016-02-20 11:30:29 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:30:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:30:29 --> Final output sent to browser
DEBUG - 2016-02-20 14:30:29 --> Total execution time: 1.2138
INFO - 2016-02-20 11:30:35 --> Config Class Initialized
INFO - 2016-02-20 11:30:35 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:30:35 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:30:35 --> Utf8 Class Initialized
INFO - 2016-02-20 11:30:35 --> URI Class Initialized
INFO - 2016-02-20 11:30:35 --> Router Class Initialized
INFO - 2016-02-20 11:30:35 --> Output Class Initialized
INFO - 2016-02-20 11:30:35 --> Security Class Initialized
DEBUG - 2016-02-20 11:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:30:35 --> Input Class Initialized
INFO - 2016-02-20 11:30:35 --> Language Class Initialized
INFO - 2016-02-20 11:30:35 --> Loader Class Initialized
INFO - 2016-02-20 11:30:35 --> Helper loaded: url_helper
INFO - 2016-02-20 11:30:35 --> Helper loaded: file_helper
INFO - 2016-02-20 11:30:35 --> Helper loaded: date_helper
INFO - 2016-02-20 11:30:35 --> Helper loaded: form_helper
INFO - 2016-02-20 11:30:35 --> Database Driver Class Initialized
INFO - 2016-02-20 11:30:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:30:36 --> Controller Class Initialized
INFO - 2016-02-20 11:30:36 --> Model Class Initialized
INFO - 2016-02-20 11:30:36 --> Model Class Initialized
INFO - 2016-02-20 11:30:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:30:36 --> Pagination Class Initialized
INFO - 2016-02-20 11:30:36 --> Helper loaded: text_helper
INFO - 2016-02-20 11:30:36 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:30:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:30:36 --> Final output sent to browser
DEBUG - 2016-02-20 14:30:36 --> Total execution time: 1.1393
INFO - 2016-02-20 11:30:38 --> Config Class Initialized
INFO - 2016-02-20 11:30:38 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:30:38 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:30:38 --> Utf8 Class Initialized
INFO - 2016-02-20 11:30:38 --> URI Class Initialized
INFO - 2016-02-20 11:30:38 --> Router Class Initialized
INFO - 2016-02-20 11:30:38 --> Output Class Initialized
INFO - 2016-02-20 11:30:38 --> Security Class Initialized
DEBUG - 2016-02-20 11:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:30:38 --> Input Class Initialized
INFO - 2016-02-20 11:30:38 --> Language Class Initialized
INFO - 2016-02-20 11:30:38 --> Loader Class Initialized
INFO - 2016-02-20 11:30:38 --> Helper loaded: url_helper
INFO - 2016-02-20 11:30:38 --> Helper loaded: file_helper
INFO - 2016-02-20 11:30:38 --> Helper loaded: date_helper
INFO - 2016-02-20 11:30:38 --> Helper loaded: form_helper
INFO - 2016-02-20 11:30:38 --> Database Driver Class Initialized
INFO - 2016-02-20 11:30:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:30:39 --> Controller Class Initialized
INFO - 2016-02-20 11:30:39 --> Model Class Initialized
INFO - 2016-02-20 11:30:39 --> Model Class Initialized
INFO - 2016-02-20 11:30:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:30:39 --> Pagination Class Initialized
INFO - 2016-02-20 11:30:39 --> Helper loaded: text_helper
INFO - 2016-02-20 11:30:39 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:30:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:30:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:30:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:30:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:30:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:30:40 --> Final output sent to browser
DEBUG - 2016-02-20 14:30:40 --> Total execution time: 1.2678
INFO - 2016-02-20 11:30:43 --> Config Class Initialized
INFO - 2016-02-20 11:30:43 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:30:43 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:30:43 --> Utf8 Class Initialized
INFO - 2016-02-20 11:30:43 --> URI Class Initialized
INFO - 2016-02-20 11:30:43 --> Router Class Initialized
INFO - 2016-02-20 11:30:43 --> Output Class Initialized
INFO - 2016-02-20 11:30:43 --> Security Class Initialized
DEBUG - 2016-02-20 11:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:30:43 --> Input Class Initialized
INFO - 2016-02-20 11:30:43 --> Language Class Initialized
INFO - 2016-02-20 11:30:43 --> Loader Class Initialized
INFO - 2016-02-20 11:30:43 --> Helper loaded: url_helper
INFO - 2016-02-20 11:30:43 --> Helper loaded: file_helper
INFO - 2016-02-20 11:30:43 --> Helper loaded: date_helper
INFO - 2016-02-20 11:30:43 --> Helper loaded: form_helper
INFO - 2016-02-20 11:30:43 --> Database Driver Class Initialized
INFO - 2016-02-20 11:30:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:30:44 --> Controller Class Initialized
INFO - 2016-02-20 11:30:44 --> Model Class Initialized
INFO - 2016-02-20 11:30:44 --> Model Class Initialized
INFO - 2016-02-20 11:30:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:30:44 --> Pagination Class Initialized
INFO - 2016-02-20 11:30:44 --> Helper loaded: text_helper
INFO - 2016-02-20 11:30:44 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:30:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:30:44 --> Final output sent to browser
DEBUG - 2016-02-20 14:30:44 --> Total execution time: 1.1588
INFO - 2016-02-20 11:30:50 --> Config Class Initialized
INFO - 2016-02-20 11:30:50 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:30:50 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:30:50 --> Utf8 Class Initialized
INFO - 2016-02-20 11:30:50 --> URI Class Initialized
INFO - 2016-02-20 11:30:50 --> Router Class Initialized
INFO - 2016-02-20 11:30:50 --> Output Class Initialized
INFO - 2016-02-20 11:30:50 --> Security Class Initialized
DEBUG - 2016-02-20 11:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:30:50 --> Input Class Initialized
INFO - 2016-02-20 11:30:50 --> Language Class Initialized
INFO - 2016-02-20 11:30:50 --> Loader Class Initialized
INFO - 2016-02-20 11:30:50 --> Helper loaded: url_helper
INFO - 2016-02-20 11:30:50 --> Helper loaded: file_helper
INFO - 2016-02-20 11:30:50 --> Helper loaded: date_helper
INFO - 2016-02-20 11:30:50 --> Helper loaded: form_helper
INFO - 2016-02-20 11:30:50 --> Database Driver Class Initialized
INFO - 2016-02-20 11:30:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:30:51 --> Controller Class Initialized
INFO - 2016-02-20 11:30:51 --> Model Class Initialized
INFO - 2016-02-20 11:30:51 --> Model Class Initialized
INFO - 2016-02-20 11:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:30:51 --> Pagination Class Initialized
INFO - 2016-02-20 11:30:51 --> Helper loaded: text_helper
INFO - 2016-02-20 11:30:51 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:30:51 --> Final output sent to browser
DEBUG - 2016-02-20 14:30:51 --> Total execution time: 1.1865
INFO - 2016-02-20 11:30:56 --> Config Class Initialized
INFO - 2016-02-20 11:30:56 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:30:56 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:30:56 --> Utf8 Class Initialized
INFO - 2016-02-20 11:30:56 --> URI Class Initialized
INFO - 2016-02-20 11:30:56 --> Router Class Initialized
INFO - 2016-02-20 11:30:56 --> Output Class Initialized
INFO - 2016-02-20 11:30:56 --> Security Class Initialized
DEBUG - 2016-02-20 11:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:30:56 --> Input Class Initialized
INFO - 2016-02-20 11:30:56 --> Language Class Initialized
INFO - 2016-02-20 11:30:56 --> Loader Class Initialized
INFO - 2016-02-20 11:30:56 --> Helper loaded: url_helper
INFO - 2016-02-20 11:30:56 --> Helper loaded: file_helper
INFO - 2016-02-20 11:30:56 --> Helper loaded: date_helper
INFO - 2016-02-20 11:30:56 --> Helper loaded: form_helper
INFO - 2016-02-20 11:30:56 --> Database Driver Class Initialized
INFO - 2016-02-20 11:30:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:30:57 --> Controller Class Initialized
INFO - 2016-02-20 11:30:57 --> Model Class Initialized
INFO - 2016-02-20 11:30:57 --> Model Class Initialized
INFO - 2016-02-20 11:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:30:57 --> Pagination Class Initialized
INFO - 2016-02-20 11:30:57 --> Helper loaded: text_helper
INFO - 2016-02-20 11:30:57 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:30:57 --> Final output sent to browser
DEBUG - 2016-02-20 14:30:57 --> Total execution time: 1.1299
INFO - 2016-02-20 11:31:02 --> Config Class Initialized
INFO - 2016-02-20 11:31:02 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:31:02 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:31:02 --> Utf8 Class Initialized
INFO - 2016-02-20 11:31:02 --> URI Class Initialized
INFO - 2016-02-20 11:31:02 --> Router Class Initialized
INFO - 2016-02-20 11:31:02 --> Output Class Initialized
INFO - 2016-02-20 11:31:02 --> Security Class Initialized
DEBUG - 2016-02-20 11:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:31:02 --> Input Class Initialized
INFO - 2016-02-20 11:31:02 --> Language Class Initialized
INFO - 2016-02-20 11:31:02 --> Loader Class Initialized
INFO - 2016-02-20 11:31:02 --> Helper loaded: url_helper
INFO - 2016-02-20 11:31:02 --> Helper loaded: file_helper
INFO - 2016-02-20 11:31:02 --> Helper loaded: date_helper
INFO - 2016-02-20 11:31:02 --> Helper loaded: form_helper
INFO - 2016-02-20 11:31:02 --> Database Driver Class Initialized
INFO - 2016-02-20 11:31:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:31:03 --> Controller Class Initialized
INFO - 2016-02-20 11:31:03 --> Model Class Initialized
INFO - 2016-02-20 11:31:03 --> Model Class Initialized
INFO - 2016-02-20 11:31:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:31:03 --> Pagination Class Initialized
INFO - 2016-02-20 11:31:03 --> Helper loaded: text_helper
INFO - 2016-02-20 11:31:03 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:31:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:31:03 --> Final output sent to browser
DEBUG - 2016-02-20 14:31:03 --> Total execution time: 1.2094
INFO - 2016-02-20 11:31:05 --> Config Class Initialized
INFO - 2016-02-20 11:31:05 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:31:05 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:31:05 --> Utf8 Class Initialized
INFO - 2016-02-20 11:31:05 --> URI Class Initialized
INFO - 2016-02-20 11:31:05 --> Router Class Initialized
INFO - 2016-02-20 11:31:05 --> Output Class Initialized
INFO - 2016-02-20 11:31:05 --> Security Class Initialized
DEBUG - 2016-02-20 11:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:31:05 --> Input Class Initialized
INFO - 2016-02-20 11:31:05 --> Language Class Initialized
INFO - 2016-02-20 11:31:05 --> Loader Class Initialized
INFO - 2016-02-20 11:31:05 --> Helper loaded: url_helper
INFO - 2016-02-20 11:31:05 --> Helper loaded: file_helper
INFO - 2016-02-20 11:31:05 --> Helper loaded: date_helper
INFO - 2016-02-20 11:31:05 --> Helper loaded: form_helper
INFO - 2016-02-20 11:31:05 --> Database Driver Class Initialized
INFO - 2016-02-20 11:31:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:31:06 --> Controller Class Initialized
INFO - 2016-02-20 11:31:06 --> Model Class Initialized
INFO - 2016-02-20 11:31:06 --> Model Class Initialized
INFO - 2016-02-20 11:31:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:31:06 --> Pagination Class Initialized
INFO - 2016-02-20 11:31:06 --> Helper loaded: text_helper
INFO - 2016-02-20 11:31:06 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:31:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:31:06 --> Final output sent to browser
DEBUG - 2016-02-20 14:31:06 --> Total execution time: 1.1466
INFO - 2016-02-20 11:31:13 --> Config Class Initialized
INFO - 2016-02-20 11:31:13 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:31:13 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:31:13 --> Utf8 Class Initialized
INFO - 2016-02-20 11:31:13 --> URI Class Initialized
INFO - 2016-02-20 11:31:13 --> Router Class Initialized
INFO - 2016-02-20 11:31:13 --> Output Class Initialized
INFO - 2016-02-20 11:31:13 --> Security Class Initialized
DEBUG - 2016-02-20 11:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:31:13 --> Input Class Initialized
INFO - 2016-02-20 11:31:13 --> Language Class Initialized
INFO - 2016-02-20 11:31:13 --> Loader Class Initialized
INFO - 2016-02-20 11:31:13 --> Helper loaded: url_helper
INFO - 2016-02-20 11:31:13 --> Helper loaded: file_helper
INFO - 2016-02-20 11:31:13 --> Helper loaded: date_helper
INFO - 2016-02-20 11:31:13 --> Helper loaded: form_helper
INFO - 2016-02-20 11:31:13 --> Database Driver Class Initialized
INFO - 2016-02-20 11:31:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:31:14 --> Controller Class Initialized
INFO - 2016-02-20 11:31:14 --> Model Class Initialized
INFO - 2016-02-20 11:31:14 --> Model Class Initialized
INFO - 2016-02-20 11:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:31:14 --> Pagination Class Initialized
INFO - 2016-02-20 11:31:14 --> Helper loaded: text_helper
INFO - 2016-02-20 11:31:14 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:31:14 --> Final output sent to browser
DEBUG - 2016-02-20 14:31:14 --> Total execution time: 1.1283
INFO - 2016-02-20 11:31:16 --> Config Class Initialized
INFO - 2016-02-20 11:31:16 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:31:16 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:31:16 --> Utf8 Class Initialized
INFO - 2016-02-20 11:31:16 --> URI Class Initialized
INFO - 2016-02-20 11:31:16 --> Router Class Initialized
INFO - 2016-02-20 11:31:16 --> Output Class Initialized
INFO - 2016-02-20 11:31:16 --> Security Class Initialized
DEBUG - 2016-02-20 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:31:16 --> Input Class Initialized
INFO - 2016-02-20 11:31:16 --> Language Class Initialized
INFO - 2016-02-20 11:31:16 --> Loader Class Initialized
INFO - 2016-02-20 11:31:16 --> Helper loaded: url_helper
INFO - 2016-02-20 11:31:16 --> Helper loaded: file_helper
INFO - 2016-02-20 11:31:16 --> Helper loaded: date_helper
INFO - 2016-02-20 11:31:16 --> Helper loaded: form_helper
INFO - 2016-02-20 11:31:16 --> Database Driver Class Initialized
INFO - 2016-02-20 11:31:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:31:17 --> Controller Class Initialized
INFO - 2016-02-20 11:31:17 --> Model Class Initialized
INFO - 2016-02-20 11:31:17 --> Model Class Initialized
INFO - 2016-02-20 11:31:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:31:17 --> Pagination Class Initialized
INFO - 2016-02-20 11:31:17 --> Helper loaded: text_helper
INFO - 2016-02-20 11:31:17 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:31:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:31:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:31:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:31:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:31:17 --> Final output sent to browser
DEBUG - 2016-02-20 14:31:17 --> Total execution time: 1.1544
INFO - 2016-02-20 11:31:22 --> Config Class Initialized
INFO - 2016-02-20 11:31:22 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:31:22 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:31:22 --> Utf8 Class Initialized
INFO - 2016-02-20 11:31:22 --> URI Class Initialized
INFO - 2016-02-20 11:31:22 --> Router Class Initialized
INFO - 2016-02-20 11:31:22 --> Output Class Initialized
INFO - 2016-02-20 11:31:22 --> Security Class Initialized
DEBUG - 2016-02-20 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:31:22 --> Input Class Initialized
INFO - 2016-02-20 11:31:22 --> Language Class Initialized
INFO - 2016-02-20 11:31:22 --> Loader Class Initialized
INFO - 2016-02-20 11:31:22 --> Helper loaded: url_helper
INFO - 2016-02-20 11:31:22 --> Helper loaded: file_helper
INFO - 2016-02-20 11:31:22 --> Helper loaded: date_helper
INFO - 2016-02-20 11:31:22 --> Helper loaded: form_helper
INFO - 2016-02-20 11:31:22 --> Database Driver Class Initialized
INFO - 2016-02-20 11:31:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:31:23 --> Controller Class Initialized
INFO - 2016-02-20 11:31:23 --> Model Class Initialized
INFO - 2016-02-20 11:31:23 --> Model Class Initialized
INFO - 2016-02-20 11:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:31:23 --> Pagination Class Initialized
INFO - 2016-02-20 11:31:23 --> Helper loaded: text_helper
INFO - 2016-02-20 11:31:23 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:31:23 --> Final output sent to browser
DEBUG - 2016-02-20 14:31:23 --> Total execution time: 1.2829
INFO - 2016-02-20 11:31:27 --> Config Class Initialized
INFO - 2016-02-20 11:31:27 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:31:27 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:31:27 --> Utf8 Class Initialized
INFO - 2016-02-20 11:31:27 --> URI Class Initialized
INFO - 2016-02-20 11:31:27 --> Router Class Initialized
INFO - 2016-02-20 11:31:27 --> Output Class Initialized
INFO - 2016-02-20 11:31:27 --> Security Class Initialized
DEBUG - 2016-02-20 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:31:27 --> Input Class Initialized
INFO - 2016-02-20 11:31:27 --> Language Class Initialized
INFO - 2016-02-20 11:31:27 --> Loader Class Initialized
INFO - 2016-02-20 11:31:27 --> Helper loaded: url_helper
INFO - 2016-02-20 11:31:27 --> Helper loaded: file_helper
INFO - 2016-02-20 11:31:27 --> Helper loaded: date_helper
INFO - 2016-02-20 11:31:27 --> Helper loaded: form_helper
INFO - 2016-02-20 11:31:27 --> Database Driver Class Initialized
INFO - 2016-02-20 11:31:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:31:28 --> Controller Class Initialized
INFO - 2016-02-20 11:31:28 --> Model Class Initialized
INFO - 2016-02-20 11:31:28 --> Model Class Initialized
INFO - 2016-02-20 11:31:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:31:28 --> Pagination Class Initialized
INFO - 2016-02-20 11:31:28 --> Helper loaded: text_helper
INFO - 2016-02-20 11:31:28 --> Helper loaded: cookie_helper
ERROR - 2016-02-20 14:31:28 --> Severity: Warning --> Missing argument 2 for Jboard_model::singledata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 285 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 34
ERROR - 2016-02-20 14:31:28 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 35
ERROR - 2016-02-20 14:31:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '33
WHERE `id` IS NULL' at line 2 - Invalid query: SELECT *
FROM 33
WHERE `id` IS NULL
INFO - 2016-02-20 14:31:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 11:33:31 --> Config Class Initialized
INFO - 2016-02-20 11:33:31 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:33:31 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:33:31 --> Utf8 Class Initialized
INFO - 2016-02-20 11:33:31 --> URI Class Initialized
INFO - 2016-02-20 11:33:31 --> Router Class Initialized
INFO - 2016-02-20 11:33:31 --> Output Class Initialized
INFO - 2016-02-20 11:33:31 --> Security Class Initialized
DEBUG - 2016-02-20 11:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:33:31 --> Input Class Initialized
INFO - 2016-02-20 11:33:31 --> Language Class Initialized
INFO - 2016-02-20 11:33:31 --> Loader Class Initialized
INFO - 2016-02-20 11:33:31 --> Helper loaded: url_helper
INFO - 2016-02-20 11:33:31 --> Helper loaded: file_helper
INFO - 2016-02-20 11:33:31 --> Helper loaded: date_helper
INFO - 2016-02-20 11:33:31 --> Helper loaded: form_helper
INFO - 2016-02-20 11:33:31 --> Database Driver Class Initialized
INFO - 2016-02-20 11:33:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:33:32 --> Controller Class Initialized
INFO - 2016-02-20 11:33:32 --> Model Class Initialized
INFO - 2016-02-20 11:33:32 --> Model Class Initialized
INFO - 2016-02-20 11:33:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:33:32 --> Pagination Class Initialized
INFO - 2016-02-20 11:33:32 --> Helper loaded: text_helper
INFO - 2016-02-20 11:33:32 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:33:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:33:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:33:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:33:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:33:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:33:32 --> Final output sent to browser
DEBUG - 2016-02-20 14:33:32 --> Total execution time: 1.2022
INFO - 2016-02-20 11:33:35 --> Config Class Initialized
INFO - 2016-02-20 11:33:35 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:33:35 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:33:35 --> Utf8 Class Initialized
INFO - 2016-02-20 11:33:35 --> URI Class Initialized
INFO - 2016-02-20 11:33:35 --> Router Class Initialized
INFO - 2016-02-20 11:33:35 --> Output Class Initialized
INFO - 2016-02-20 11:33:35 --> Security Class Initialized
DEBUG - 2016-02-20 11:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:33:35 --> Input Class Initialized
INFO - 2016-02-20 11:33:35 --> Language Class Initialized
INFO - 2016-02-20 11:33:35 --> Loader Class Initialized
INFO - 2016-02-20 11:33:35 --> Helper loaded: url_helper
INFO - 2016-02-20 11:33:35 --> Helper loaded: file_helper
INFO - 2016-02-20 11:33:35 --> Helper loaded: date_helper
INFO - 2016-02-20 11:33:35 --> Helper loaded: form_helper
INFO - 2016-02-20 11:33:35 --> Database Driver Class Initialized
INFO - 2016-02-20 11:33:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:33:36 --> Controller Class Initialized
INFO - 2016-02-20 11:33:36 --> Model Class Initialized
INFO - 2016-02-20 11:33:36 --> Model Class Initialized
INFO - 2016-02-20 11:33:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:33:36 --> Pagination Class Initialized
INFO - 2016-02-20 11:33:36 --> Helper loaded: text_helper
INFO - 2016-02-20 11:33:36 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:33:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:33:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:33:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
ERROR - 2016-02-20 14:33:36 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 306 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-20 14:33:36 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-20 14:33:36 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-20 14:33:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 11:34:14 --> Config Class Initialized
INFO - 2016-02-20 11:34:14 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:34:14 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:34:14 --> Utf8 Class Initialized
INFO - 2016-02-20 11:34:14 --> URI Class Initialized
INFO - 2016-02-20 11:34:14 --> Router Class Initialized
INFO - 2016-02-20 11:34:14 --> Output Class Initialized
INFO - 2016-02-20 11:34:14 --> Security Class Initialized
DEBUG - 2016-02-20 11:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:34:14 --> Input Class Initialized
INFO - 2016-02-20 11:34:14 --> Language Class Initialized
INFO - 2016-02-20 11:34:14 --> Loader Class Initialized
INFO - 2016-02-20 11:34:14 --> Helper loaded: url_helper
INFO - 2016-02-20 11:34:14 --> Helper loaded: file_helper
INFO - 2016-02-20 11:34:14 --> Helper loaded: date_helper
INFO - 2016-02-20 11:34:14 --> Helper loaded: form_helper
INFO - 2016-02-20 11:34:14 --> Database Driver Class Initialized
INFO - 2016-02-20 11:34:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:34:15 --> Controller Class Initialized
INFO - 2016-02-20 11:34:15 --> Model Class Initialized
INFO - 2016-02-20 11:34:15 --> Model Class Initialized
INFO - 2016-02-20 11:34:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:34:15 --> Pagination Class Initialized
INFO - 2016-02-20 11:34:15 --> Helper loaded: text_helper
INFO - 2016-02-20 11:34:15 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:34:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:34:15 --> Final output sent to browser
DEBUG - 2016-02-20 14:34:15 --> Total execution time: 1.1958
INFO - 2016-02-20 11:34:16 --> Config Class Initialized
INFO - 2016-02-20 11:34:16 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:34:16 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:34:16 --> Utf8 Class Initialized
INFO - 2016-02-20 11:34:16 --> URI Class Initialized
INFO - 2016-02-20 11:34:16 --> Router Class Initialized
INFO - 2016-02-20 11:34:16 --> Output Class Initialized
INFO - 2016-02-20 11:34:16 --> Security Class Initialized
DEBUG - 2016-02-20 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:34:16 --> Input Class Initialized
INFO - 2016-02-20 11:34:16 --> Language Class Initialized
INFO - 2016-02-20 11:34:16 --> Loader Class Initialized
INFO - 2016-02-20 11:34:16 --> Helper loaded: url_helper
INFO - 2016-02-20 11:34:16 --> Helper loaded: file_helper
INFO - 2016-02-20 11:34:16 --> Helper loaded: date_helper
INFO - 2016-02-20 11:34:16 --> Helper loaded: form_helper
INFO - 2016-02-20 11:34:16 --> Database Driver Class Initialized
INFO - 2016-02-20 11:34:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:34:17 --> Controller Class Initialized
INFO - 2016-02-20 11:34:17 --> Model Class Initialized
INFO - 2016-02-20 11:34:17 --> Model Class Initialized
INFO - 2016-02-20 11:34:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:34:17 --> Pagination Class Initialized
INFO - 2016-02-20 11:34:17 --> Helper loaded: text_helper
INFO - 2016-02-20 11:34:17 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:34:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:34:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:34:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
ERROR - 2016-02-20 14:34:17 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-20 14:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-20 14:34:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:34:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:34:17 --> Final output sent to browser
DEBUG - 2016-02-20 14:34:17 --> Total execution time: 1.1870
INFO - 2016-02-20 11:35:05 --> Config Class Initialized
INFO - 2016-02-20 11:35:05 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:35:05 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:35:05 --> Utf8 Class Initialized
INFO - 2016-02-20 11:35:05 --> URI Class Initialized
INFO - 2016-02-20 11:35:05 --> Router Class Initialized
INFO - 2016-02-20 11:35:05 --> Output Class Initialized
INFO - 2016-02-20 11:35:05 --> Security Class Initialized
DEBUG - 2016-02-20 11:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:35:05 --> Input Class Initialized
INFO - 2016-02-20 11:35:05 --> Language Class Initialized
INFO - 2016-02-20 11:35:05 --> Loader Class Initialized
INFO - 2016-02-20 11:35:05 --> Helper loaded: url_helper
INFO - 2016-02-20 11:35:05 --> Helper loaded: file_helper
INFO - 2016-02-20 11:35:05 --> Helper loaded: date_helper
INFO - 2016-02-20 11:35:05 --> Helper loaded: form_helper
INFO - 2016-02-20 11:35:05 --> Database Driver Class Initialized
INFO - 2016-02-20 11:35:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:35:06 --> Controller Class Initialized
INFO - 2016-02-20 11:35:06 --> Model Class Initialized
INFO - 2016-02-20 11:35:06 --> Model Class Initialized
INFO - 2016-02-20 11:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:35:06 --> Pagination Class Initialized
INFO - 2016-02-20 11:35:06 --> Helper loaded: text_helper
INFO - 2016-02-20 11:35:06 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 14:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:35:06 --> Final output sent to browser
DEBUG - 2016-02-20 14:35:06 --> Total execution time: 1.1309
INFO - 2016-02-20 11:35:09 --> Config Class Initialized
INFO - 2016-02-20 11:35:09 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:35:09 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:35:09 --> Utf8 Class Initialized
INFO - 2016-02-20 11:35:09 --> URI Class Initialized
INFO - 2016-02-20 11:35:09 --> Router Class Initialized
INFO - 2016-02-20 11:35:09 --> Output Class Initialized
INFO - 2016-02-20 11:35:09 --> Security Class Initialized
DEBUG - 2016-02-20 11:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:35:09 --> Input Class Initialized
INFO - 2016-02-20 11:35:09 --> Language Class Initialized
INFO - 2016-02-20 11:35:09 --> Loader Class Initialized
INFO - 2016-02-20 11:35:09 --> Helper loaded: url_helper
INFO - 2016-02-20 11:35:09 --> Helper loaded: file_helper
INFO - 2016-02-20 11:35:09 --> Helper loaded: date_helper
INFO - 2016-02-20 11:35:09 --> Helper loaded: form_helper
INFO - 2016-02-20 11:35:09 --> Database Driver Class Initialized
INFO - 2016-02-20 11:35:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:35:10 --> Controller Class Initialized
INFO - 2016-02-20 11:35:10 --> Model Class Initialized
INFO - 2016-02-20 11:35:11 --> Model Class Initialized
INFO - 2016-02-20 11:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:35:11 --> Pagination Class Initialized
INFO - 2016-02-20 11:35:11 --> Helper loaded: text_helper
INFO - 2016-02-20 11:35:11 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:35:11 --> Final output sent to browser
DEBUG - 2016-02-20 14:35:11 --> Total execution time: 1.1659
INFO - 2016-02-20 11:35:13 --> Config Class Initialized
INFO - 2016-02-20 11:35:13 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:35:13 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:35:13 --> Utf8 Class Initialized
INFO - 2016-02-20 11:35:13 --> URI Class Initialized
INFO - 2016-02-20 11:35:13 --> Router Class Initialized
INFO - 2016-02-20 11:35:13 --> Output Class Initialized
INFO - 2016-02-20 11:35:13 --> Security Class Initialized
DEBUG - 2016-02-20 11:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:35:13 --> Input Class Initialized
INFO - 2016-02-20 11:35:13 --> Language Class Initialized
INFO - 2016-02-20 11:35:13 --> Loader Class Initialized
INFO - 2016-02-20 11:35:13 --> Helper loaded: url_helper
INFO - 2016-02-20 11:35:13 --> Helper loaded: file_helper
INFO - 2016-02-20 11:35:13 --> Helper loaded: date_helper
INFO - 2016-02-20 11:35:13 --> Helper loaded: form_helper
INFO - 2016-02-20 11:35:13 --> Database Driver Class Initialized
INFO - 2016-02-20 11:35:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:35:14 --> Controller Class Initialized
INFO - 2016-02-20 11:35:14 --> Model Class Initialized
INFO - 2016-02-20 11:35:14 --> Model Class Initialized
INFO - 2016-02-20 11:35:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:35:14 --> Pagination Class Initialized
INFO - 2016-02-20 11:35:14 --> Helper loaded: text_helper
INFO - 2016-02-20 11:35:14 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:35:14 --> Final output sent to browser
DEBUG - 2016-02-20 14:35:14 --> Total execution time: 1.1544
INFO - 2016-02-20 11:44:44 --> Config Class Initialized
INFO - 2016-02-20 11:44:44 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:44:44 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:44:44 --> Utf8 Class Initialized
INFO - 2016-02-20 11:44:44 --> URI Class Initialized
INFO - 2016-02-20 11:44:44 --> Router Class Initialized
INFO - 2016-02-20 11:44:44 --> Output Class Initialized
INFO - 2016-02-20 11:44:44 --> Security Class Initialized
DEBUG - 2016-02-20 11:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:44:44 --> Input Class Initialized
INFO - 2016-02-20 11:44:44 --> Language Class Initialized
INFO - 2016-02-20 11:44:44 --> Loader Class Initialized
INFO - 2016-02-20 11:44:44 --> Helper loaded: url_helper
INFO - 2016-02-20 11:44:44 --> Helper loaded: file_helper
INFO - 2016-02-20 11:44:44 --> Helper loaded: date_helper
INFO - 2016-02-20 11:44:44 --> Helper loaded: form_helper
INFO - 2016-02-20 11:44:44 --> Database Driver Class Initialized
INFO - 2016-02-20 11:44:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:44:45 --> Controller Class Initialized
INFO - 2016-02-20 11:44:45 --> Model Class Initialized
INFO - 2016-02-20 11:44:45 --> Model Class Initialized
INFO - 2016-02-20 11:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:44:45 --> Pagination Class Initialized
INFO - 2016-02-20 11:44:45 --> Helper loaded: text_helper
INFO - 2016-02-20 11:44:45 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:44:45 --> Upload Class Initialized
INFO - 2016-02-20 14:44:45 --> Final output sent to browser
DEBUG - 2016-02-20 14:44:45 --> Total execution time: 1.1179
INFO - 2016-02-20 11:45:34 --> Config Class Initialized
INFO - 2016-02-20 11:45:34 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:45:34 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:45:34 --> Utf8 Class Initialized
INFO - 2016-02-20 11:45:34 --> URI Class Initialized
INFO - 2016-02-20 11:45:34 --> Router Class Initialized
INFO - 2016-02-20 11:45:34 --> Output Class Initialized
INFO - 2016-02-20 11:45:34 --> Security Class Initialized
DEBUG - 2016-02-20 11:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:45:34 --> Input Class Initialized
INFO - 2016-02-20 11:45:34 --> Language Class Initialized
INFO - 2016-02-20 11:45:34 --> Loader Class Initialized
INFO - 2016-02-20 11:45:34 --> Helper loaded: url_helper
INFO - 2016-02-20 11:45:34 --> Helper loaded: file_helper
INFO - 2016-02-20 11:45:34 --> Helper loaded: date_helper
INFO - 2016-02-20 11:45:34 --> Helper loaded: form_helper
INFO - 2016-02-20 11:45:34 --> Database Driver Class Initialized
INFO - 2016-02-20 11:45:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:45:35 --> Controller Class Initialized
INFO - 2016-02-20 11:45:35 --> Model Class Initialized
INFO - 2016-02-20 11:45:35 --> Model Class Initialized
INFO - 2016-02-20 11:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:45:36 --> Pagination Class Initialized
INFO - 2016-02-20 11:45:36 --> Helper loaded: text_helper
INFO - 2016-02-20 11:45:36 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 11:45:36 --> Config Class Initialized
INFO - 2016-02-20 11:45:36 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:45:36 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:45:36 --> Utf8 Class Initialized
INFO - 2016-02-20 11:45:36 --> URI Class Initialized
INFO - 2016-02-20 11:45:36 --> Router Class Initialized
INFO - 2016-02-20 11:45:36 --> Output Class Initialized
INFO - 2016-02-20 11:45:36 --> Security Class Initialized
DEBUG - 2016-02-20 11:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:45:36 --> Input Class Initialized
INFO - 2016-02-20 11:45:36 --> Language Class Initialized
INFO - 2016-02-20 11:45:36 --> Loader Class Initialized
INFO - 2016-02-20 11:45:36 --> Helper loaded: url_helper
INFO - 2016-02-20 11:45:36 --> Helper loaded: file_helper
INFO - 2016-02-20 11:45:36 --> Helper loaded: date_helper
INFO - 2016-02-20 11:45:36 --> Helper loaded: form_helper
INFO - 2016-02-20 11:45:36 --> Database Driver Class Initialized
INFO - 2016-02-20 11:45:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:45:37 --> Controller Class Initialized
INFO - 2016-02-20 11:45:37 --> Model Class Initialized
INFO - 2016-02-20 11:45:37 --> Model Class Initialized
INFO - 2016-02-20 11:45:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:45:37 --> Pagination Class Initialized
INFO - 2016-02-20 11:45:37 --> Helper loaded: text_helper
INFO - 2016-02-20 11:45:37 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:45:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:45:37 --> Severity: Warning --> Missing argument 2 for Jboard_model::updateview(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 118 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 152
ERROR - 2016-02-20 14:45:37 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 154
ERROR - 2016-02-20 14:45:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '33 SET view = view + 1
WHERE `id` IS NULL' at line 1 - Invalid query: UPDATE 33 SET view = view + 1
WHERE `id` IS NULL
INFO - 2016-02-20 14:45:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 11:47:37 --> Config Class Initialized
INFO - 2016-02-20 11:47:37 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:47:37 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:47:37 --> Utf8 Class Initialized
INFO - 2016-02-20 11:47:37 --> URI Class Initialized
INFO - 2016-02-20 11:47:37 --> Router Class Initialized
INFO - 2016-02-20 11:47:37 --> Output Class Initialized
INFO - 2016-02-20 11:47:37 --> Security Class Initialized
DEBUG - 2016-02-20 11:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:47:37 --> Input Class Initialized
INFO - 2016-02-20 11:47:37 --> Language Class Initialized
INFO - 2016-02-20 11:47:37 --> Loader Class Initialized
INFO - 2016-02-20 11:47:37 --> Helper loaded: url_helper
INFO - 2016-02-20 11:47:37 --> Helper loaded: file_helper
INFO - 2016-02-20 11:47:37 --> Helper loaded: date_helper
INFO - 2016-02-20 11:47:37 --> Helper loaded: form_helper
INFO - 2016-02-20 11:47:37 --> Database Driver Class Initialized
INFO - 2016-02-20 11:47:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:47:39 --> Controller Class Initialized
INFO - 2016-02-20 11:47:39 --> Model Class Initialized
INFO - 2016-02-20 11:47:39 --> Model Class Initialized
INFO - 2016-02-20 11:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:47:39 --> Pagination Class Initialized
INFO - 2016-02-20 11:47:39 --> Helper loaded: text_helper
INFO - 2016-02-20 11:47:39 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:47:39 --> Severity: Warning --> Missing argument 2 for Jboard_model::updateview(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 118 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 152
ERROR - 2016-02-20 14:47:39 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 154
ERROR - 2016-02-20 14:47:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '33 SET view = view + 1
WHERE `id` IS NULL' at line 1 - Invalid query: UPDATE 33 SET view = view + 1
WHERE `id` IS NULL
INFO - 2016-02-20 14:47:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 11:47:40 --> Config Class Initialized
INFO - 2016-02-20 11:47:40 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:47:40 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:47:40 --> Utf8 Class Initialized
INFO - 2016-02-20 11:47:40 --> URI Class Initialized
INFO - 2016-02-20 11:47:40 --> Router Class Initialized
INFO - 2016-02-20 11:47:40 --> Output Class Initialized
INFO - 2016-02-20 11:47:40 --> Security Class Initialized
DEBUG - 2016-02-20 11:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:47:40 --> Input Class Initialized
INFO - 2016-02-20 11:47:40 --> Language Class Initialized
INFO - 2016-02-20 11:47:40 --> Loader Class Initialized
INFO - 2016-02-20 11:47:40 --> Helper loaded: url_helper
INFO - 2016-02-20 11:47:40 --> Helper loaded: file_helper
INFO - 2016-02-20 11:47:40 --> Helper loaded: date_helper
INFO - 2016-02-20 11:47:40 --> Helper loaded: form_helper
INFO - 2016-02-20 11:47:40 --> Database Driver Class Initialized
INFO - 2016-02-20 11:47:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:47:41 --> Controller Class Initialized
INFO - 2016-02-20 11:47:41 --> Model Class Initialized
INFO - 2016-02-20 11:47:41 --> Model Class Initialized
INFO - 2016-02-20 11:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:47:41 --> Pagination Class Initialized
INFO - 2016-02-20 11:47:41 --> Helper loaded: text_helper
INFO - 2016-02-20 11:47:41 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:47:41 --> Final output sent to browser
DEBUG - 2016-02-20 14:47:41 --> Total execution time: 1.1413
INFO - 2016-02-20 11:48:03 --> Config Class Initialized
INFO - 2016-02-20 11:48:03 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:48:03 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:48:03 --> Utf8 Class Initialized
INFO - 2016-02-20 11:48:03 --> URI Class Initialized
INFO - 2016-02-20 11:48:03 --> Router Class Initialized
INFO - 2016-02-20 11:48:03 --> Output Class Initialized
INFO - 2016-02-20 11:48:03 --> Security Class Initialized
DEBUG - 2016-02-20 11:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:48:03 --> Input Class Initialized
INFO - 2016-02-20 11:48:03 --> Language Class Initialized
INFO - 2016-02-20 11:48:03 --> Loader Class Initialized
INFO - 2016-02-20 11:48:03 --> Helper loaded: url_helper
INFO - 2016-02-20 11:48:03 --> Helper loaded: file_helper
INFO - 2016-02-20 11:48:03 --> Helper loaded: date_helper
INFO - 2016-02-20 11:48:03 --> Helper loaded: form_helper
INFO - 2016-02-20 11:48:03 --> Database Driver Class Initialized
INFO - 2016-02-20 11:48:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:48:04 --> Controller Class Initialized
INFO - 2016-02-20 11:48:04 --> Model Class Initialized
INFO - 2016-02-20 11:48:04 --> Model Class Initialized
INFO - 2016-02-20 11:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:48:04 --> Pagination Class Initialized
INFO - 2016-02-20 11:48:04 --> Helper loaded: text_helper
INFO - 2016-02-20 11:48:04 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:48:04 --> Upload Class Initialized
INFO - 2016-02-20 14:48:04 --> Final output sent to browser
DEBUG - 2016-02-20 14:48:04 --> Total execution time: 1.1399
INFO - 2016-02-20 11:48:36 --> Config Class Initialized
INFO - 2016-02-20 11:48:36 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:48:36 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:48:36 --> Utf8 Class Initialized
INFO - 2016-02-20 11:48:36 --> URI Class Initialized
INFO - 2016-02-20 11:48:36 --> Router Class Initialized
INFO - 2016-02-20 11:48:36 --> Output Class Initialized
INFO - 2016-02-20 11:48:36 --> Security Class Initialized
DEBUG - 2016-02-20 11:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:48:36 --> Input Class Initialized
INFO - 2016-02-20 11:48:36 --> Language Class Initialized
INFO - 2016-02-20 11:48:36 --> Loader Class Initialized
INFO - 2016-02-20 11:48:36 --> Helper loaded: url_helper
INFO - 2016-02-20 11:48:36 --> Helper loaded: file_helper
INFO - 2016-02-20 11:48:36 --> Helper loaded: date_helper
INFO - 2016-02-20 11:48:36 --> Helper loaded: form_helper
INFO - 2016-02-20 11:48:36 --> Database Driver Class Initialized
INFO - 2016-02-20 11:48:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:48:37 --> Controller Class Initialized
INFO - 2016-02-20 11:48:37 --> Model Class Initialized
INFO - 2016-02-20 11:48:37 --> Model Class Initialized
INFO - 2016-02-20 11:48:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:48:37 --> Pagination Class Initialized
INFO - 2016-02-20 11:48:37 --> Helper loaded: text_helper
INFO - 2016-02-20 11:48:37 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:48:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:48:37 --> Severity: Warning --> Missing argument 3 for Jboard_model::updatedb(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 314 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 134
ERROR - 2016-02-20 14:48:37 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-20 14:48:37 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 137
INFO - 2016-02-20 14:48:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 14:48:37 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455997717
WHERE `id` = `Array`
AND `id` = 'd01d95a8aaf77329c66f9c912da3806f7db8787f'
INFO - 2016-02-20 11:49:41 --> Config Class Initialized
INFO - 2016-02-20 11:49:41 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:49:41 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:49:41 --> Utf8 Class Initialized
INFO - 2016-02-20 11:49:41 --> URI Class Initialized
INFO - 2016-02-20 11:49:41 --> Router Class Initialized
INFO - 2016-02-20 11:49:41 --> Output Class Initialized
INFO - 2016-02-20 11:49:41 --> Security Class Initialized
DEBUG - 2016-02-20 11:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:49:41 --> Input Class Initialized
INFO - 2016-02-20 11:49:41 --> Language Class Initialized
INFO - 2016-02-20 11:49:41 --> Loader Class Initialized
INFO - 2016-02-20 11:49:41 --> Helper loaded: url_helper
INFO - 2016-02-20 11:49:41 --> Helper loaded: file_helper
INFO - 2016-02-20 11:49:41 --> Helper loaded: date_helper
INFO - 2016-02-20 11:49:41 --> Helper loaded: form_helper
INFO - 2016-02-20 11:49:41 --> Database Driver Class Initialized
INFO - 2016-02-20 11:49:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:49:42 --> Controller Class Initialized
INFO - 2016-02-20 11:49:42 --> Model Class Initialized
INFO - 2016-02-20 11:49:42 --> Model Class Initialized
INFO - 2016-02-20 11:49:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:49:42 --> Pagination Class Initialized
INFO - 2016-02-20 11:49:42 --> Helper loaded: text_helper
INFO - 2016-02-20 11:49:42 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:49:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:49:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:49:42 --> Severity: Warning --> Missing argument 3 for Jboard_model::updatedb(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 314 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 134
ERROR - 2016-02-20 14:49:42 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-20 14:49:42 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 137
INFO - 2016-02-20 14:49:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 14:49:42 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455997782
WHERE `id` = `Array`
AND `id` = 'd01d95a8aaf77329c66f9c912da3806f7db8787f'
INFO - 2016-02-20 11:50:00 --> Config Class Initialized
INFO - 2016-02-20 11:50:00 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:50:00 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:50:00 --> Utf8 Class Initialized
INFO - 2016-02-20 11:50:00 --> URI Class Initialized
INFO - 2016-02-20 11:50:00 --> Router Class Initialized
INFO - 2016-02-20 11:50:00 --> Output Class Initialized
INFO - 2016-02-20 11:50:00 --> Security Class Initialized
DEBUG - 2016-02-20 11:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:50:00 --> Input Class Initialized
INFO - 2016-02-20 11:50:00 --> Language Class Initialized
INFO - 2016-02-20 11:50:00 --> Loader Class Initialized
INFO - 2016-02-20 11:50:00 --> Helper loaded: url_helper
INFO - 2016-02-20 11:50:00 --> Helper loaded: file_helper
INFO - 2016-02-20 11:50:00 --> Helper loaded: date_helper
INFO - 2016-02-20 11:50:00 --> Helper loaded: form_helper
INFO - 2016-02-20 11:50:00 --> Database Driver Class Initialized
INFO - 2016-02-20 11:50:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:50:01 --> Controller Class Initialized
INFO - 2016-02-20 11:50:01 --> Model Class Initialized
INFO - 2016-02-20 11:50:01 --> Model Class Initialized
INFO - 2016-02-20 11:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:50:01 --> Pagination Class Initialized
INFO - 2016-02-20 11:50:01 --> Helper loaded: text_helper
INFO - 2016-02-20 11:50:01 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:50:01 --> Final output sent to browser
DEBUG - 2016-02-20 14:50:01 --> Total execution time: 1.1512
INFO - 2016-02-20 11:50:11 --> Config Class Initialized
INFO - 2016-02-20 11:50:11 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:50:11 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:50:11 --> Utf8 Class Initialized
INFO - 2016-02-20 11:50:11 --> URI Class Initialized
INFO - 2016-02-20 11:50:11 --> Router Class Initialized
INFO - 2016-02-20 11:50:11 --> Output Class Initialized
INFO - 2016-02-20 11:50:11 --> Security Class Initialized
DEBUG - 2016-02-20 11:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:50:11 --> Input Class Initialized
INFO - 2016-02-20 11:50:11 --> Language Class Initialized
INFO - 2016-02-20 11:50:11 --> Loader Class Initialized
INFO - 2016-02-20 11:50:11 --> Helper loaded: url_helper
INFO - 2016-02-20 11:50:11 --> Helper loaded: file_helper
INFO - 2016-02-20 11:50:11 --> Helper loaded: date_helper
INFO - 2016-02-20 11:50:11 --> Helper loaded: form_helper
INFO - 2016-02-20 11:50:11 --> Database Driver Class Initialized
INFO - 2016-02-20 11:50:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:50:13 --> Controller Class Initialized
INFO - 2016-02-20 11:50:13 --> Model Class Initialized
INFO - 2016-02-20 11:50:13 --> Model Class Initialized
INFO - 2016-02-20 11:50:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:50:13 --> Pagination Class Initialized
INFO - 2016-02-20 11:50:13 --> Helper loaded: text_helper
INFO - 2016-02-20 11:50:13 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:50:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:50:13 --> Severity: Warning --> Missing argument 3 for Jboard_model::updatedb(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 314 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 134
ERROR - 2016-02-20 14:50:13 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-20 14:50:13 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 137
INFO - 2016-02-20 14:50:13 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 14:50:13 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455997813
WHERE `id` = `Array`
AND `id` = '44a9992a70eaaedddd9401201875120c8d2c9614'
INFO - 2016-02-20 11:51:17 --> Config Class Initialized
INFO - 2016-02-20 11:51:17 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:51:17 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:51:17 --> Utf8 Class Initialized
INFO - 2016-02-20 11:51:17 --> URI Class Initialized
INFO - 2016-02-20 11:51:17 --> Router Class Initialized
INFO - 2016-02-20 11:51:17 --> Output Class Initialized
INFO - 2016-02-20 11:51:17 --> Security Class Initialized
DEBUG - 2016-02-20 11:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:51:17 --> Input Class Initialized
INFO - 2016-02-20 11:51:17 --> Language Class Initialized
INFO - 2016-02-20 11:51:17 --> Loader Class Initialized
INFO - 2016-02-20 11:51:17 --> Helper loaded: url_helper
INFO - 2016-02-20 11:51:17 --> Helper loaded: file_helper
INFO - 2016-02-20 11:51:17 --> Helper loaded: date_helper
INFO - 2016-02-20 11:51:17 --> Helper loaded: form_helper
INFO - 2016-02-20 11:51:17 --> Database Driver Class Initialized
INFO - 2016-02-20 11:51:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:51:18 --> Controller Class Initialized
INFO - 2016-02-20 11:51:18 --> Model Class Initialized
INFO - 2016-02-20 11:51:18 --> Model Class Initialized
INFO - 2016-02-20 11:51:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:51:18 --> Pagination Class Initialized
INFO - 2016-02-20 11:51:18 --> Helper loaded: text_helper
INFO - 2016-02-20 11:51:18 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:51:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:51:18 --> Final output sent to browser
DEBUG - 2016-02-20 14:51:18 --> Total execution time: 1.1904
INFO - 2016-02-20 11:51:25 --> Config Class Initialized
INFO - 2016-02-20 11:51:25 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:51:25 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:51:25 --> Utf8 Class Initialized
INFO - 2016-02-20 11:51:25 --> URI Class Initialized
INFO - 2016-02-20 11:51:25 --> Router Class Initialized
INFO - 2016-02-20 11:51:25 --> Output Class Initialized
INFO - 2016-02-20 11:51:25 --> Security Class Initialized
DEBUG - 2016-02-20 11:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:51:25 --> Input Class Initialized
INFO - 2016-02-20 11:51:25 --> Language Class Initialized
INFO - 2016-02-20 11:51:25 --> Loader Class Initialized
INFO - 2016-02-20 11:51:25 --> Helper loaded: url_helper
INFO - 2016-02-20 11:51:25 --> Helper loaded: file_helper
INFO - 2016-02-20 11:51:25 --> Helper loaded: date_helper
INFO - 2016-02-20 11:51:25 --> Helper loaded: form_helper
INFO - 2016-02-20 11:51:25 --> Database Driver Class Initialized
INFO - 2016-02-20 11:51:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:51:26 --> Controller Class Initialized
INFO - 2016-02-20 11:51:26 --> Model Class Initialized
INFO - 2016-02-20 11:51:26 --> Model Class Initialized
INFO - 2016-02-20 11:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:51:26 --> Pagination Class Initialized
INFO - 2016-02-20 11:51:26 --> Helper loaded: text_helper
INFO - 2016-02-20 11:51:26 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:51:26 --> Severity: Warning --> Missing argument 3 for Jboard_model::updatedb(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 314 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 134
ERROR - 2016-02-20 14:51:26 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-20 14:51:26 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 137
INFO - 2016-02-20 14:51:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 14:51:26 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455997886
WHERE `id` = `Array`
AND `id` = '44a9992a70eaaedddd9401201875120c8d2c9614'
INFO - 2016-02-20 11:52:05 --> Config Class Initialized
INFO - 2016-02-20 11:52:05 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:52:05 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:52:05 --> Utf8 Class Initialized
INFO - 2016-02-20 11:52:05 --> URI Class Initialized
INFO - 2016-02-20 11:52:05 --> Router Class Initialized
INFO - 2016-02-20 11:52:05 --> Output Class Initialized
INFO - 2016-02-20 11:52:05 --> Security Class Initialized
DEBUG - 2016-02-20 11:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:52:05 --> Input Class Initialized
INFO - 2016-02-20 11:52:05 --> Language Class Initialized
INFO - 2016-02-20 11:52:05 --> Loader Class Initialized
INFO - 2016-02-20 11:52:05 --> Helper loaded: url_helper
INFO - 2016-02-20 11:52:05 --> Helper loaded: file_helper
INFO - 2016-02-20 11:52:05 --> Helper loaded: date_helper
INFO - 2016-02-20 11:52:05 --> Helper loaded: form_helper
INFO - 2016-02-20 11:52:05 --> Database Driver Class Initialized
INFO - 2016-02-20 11:52:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:52:06 --> Controller Class Initialized
INFO - 2016-02-20 11:52:06 --> Model Class Initialized
INFO - 2016-02-20 11:52:06 --> Model Class Initialized
INFO - 2016-02-20 11:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:52:06 --> Pagination Class Initialized
INFO - 2016-02-20 11:52:06 --> Helper loaded: text_helper
INFO - 2016-02-20 11:52:06 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:52:06 --> Final output sent to browser
DEBUG - 2016-02-20 14:52:06 --> Total execution time: 1.1571
INFO - 2016-02-20 11:52:14 --> Config Class Initialized
INFO - 2016-02-20 11:52:14 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:52:14 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:52:14 --> Utf8 Class Initialized
INFO - 2016-02-20 11:52:14 --> URI Class Initialized
INFO - 2016-02-20 11:52:14 --> Router Class Initialized
INFO - 2016-02-20 11:52:14 --> Output Class Initialized
INFO - 2016-02-20 11:52:14 --> Security Class Initialized
DEBUG - 2016-02-20 11:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:52:14 --> Input Class Initialized
INFO - 2016-02-20 11:52:14 --> Language Class Initialized
INFO - 2016-02-20 11:52:14 --> Loader Class Initialized
INFO - 2016-02-20 11:52:14 --> Helper loaded: url_helper
INFO - 2016-02-20 11:52:14 --> Helper loaded: file_helper
INFO - 2016-02-20 11:52:14 --> Helper loaded: date_helper
INFO - 2016-02-20 11:52:14 --> Helper loaded: form_helper
INFO - 2016-02-20 11:52:14 --> Database Driver Class Initialized
INFO - 2016-02-20 11:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:52:15 --> Controller Class Initialized
INFO - 2016-02-20 11:52:15 --> Model Class Initialized
INFO - 2016-02-20 11:52:15 --> Model Class Initialized
INFO - 2016-02-20 11:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:52:15 --> Pagination Class Initialized
INFO - 2016-02-20 11:52:15 --> Helper loaded: text_helper
INFO - 2016-02-20 11:52:15 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:52:15 --> Severity: Warning --> Missing argument 3 for Jboard_model::updatedb(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 314 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 134
ERROR - 2016-02-20 14:52:15 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-20 14:52:15 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 137
INFO - 2016-02-20 14:52:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 14:52:15 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455997935
WHERE `id` = `Array`
AND `id` = '44a9992a70eaaedddd9401201875120c8d2c9614'
INFO - 2016-02-20 11:56:06 --> Config Class Initialized
INFO - 2016-02-20 11:56:06 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:56:06 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:56:06 --> Utf8 Class Initialized
INFO - 2016-02-20 11:56:06 --> URI Class Initialized
INFO - 2016-02-20 11:56:06 --> Router Class Initialized
INFO - 2016-02-20 11:56:06 --> Output Class Initialized
INFO - 2016-02-20 11:56:06 --> Security Class Initialized
DEBUG - 2016-02-20 11:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:56:06 --> Input Class Initialized
INFO - 2016-02-20 11:56:06 --> Language Class Initialized
INFO - 2016-02-20 11:56:06 --> Loader Class Initialized
INFO - 2016-02-20 11:56:06 --> Helper loaded: url_helper
INFO - 2016-02-20 11:56:06 --> Helper loaded: file_helper
INFO - 2016-02-20 11:56:06 --> Helper loaded: date_helper
INFO - 2016-02-20 11:56:06 --> Helper loaded: form_helper
INFO - 2016-02-20 11:56:06 --> Database Driver Class Initialized
INFO - 2016-02-20 11:56:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:56:07 --> Controller Class Initialized
INFO - 2016-02-20 11:56:07 --> Model Class Initialized
INFO - 2016-02-20 11:56:07 --> Model Class Initialized
INFO - 2016-02-20 11:56:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:56:07 --> Pagination Class Initialized
INFO - 2016-02-20 11:56:07 --> Helper loaded: text_helper
INFO - 2016-02-20 11:56:07 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:56:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:56:07 --> Final output sent to browser
DEBUG - 2016-02-20 14:56:07 --> Total execution time: 1.1251
INFO - 2016-02-20 11:56:11 --> Config Class Initialized
INFO - 2016-02-20 11:56:11 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:56:11 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:56:11 --> Utf8 Class Initialized
INFO - 2016-02-20 11:56:11 --> URI Class Initialized
INFO - 2016-02-20 11:56:11 --> Router Class Initialized
INFO - 2016-02-20 11:56:11 --> Output Class Initialized
INFO - 2016-02-20 11:56:11 --> Security Class Initialized
DEBUG - 2016-02-20 11:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:56:11 --> Input Class Initialized
INFO - 2016-02-20 11:56:11 --> Language Class Initialized
INFO - 2016-02-20 11:56:11 --> Loader Class Initialized
INFO - 2016-02-20 11:56:11 --> Helper loaded: url_helper
INFO - 2016-02-20 11:56:11 --> Helper loaded: file_helper
INFO - 2016-02-20 11:56:11 --> Helper loaded: date_helper
INFO - 2016-02-20 11:56:11 --> Helper loaded: form_helper
INFO - 2016-02-20 11:56:11 --> Database Driver Class Initialized
INFO - 2016-02-20 11:56:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:56:12 --> Controller Class Initialized
INFO - 2016-02-20 11:56:12 --> Model Class Initialized
INFO - 2016-02-20 11:56:12 --> Model Class Initialized
INFO - 2016-02-20 11:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:56:12 --> Pagination Class Initialized
INFO - 2016-02-20 11:56:12 --> Helper loaded: text_helper
INFO - 2016-02-20 11:56:12 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 14:56:12 --> Severity: Warning --> Missing argument 3 for Jboard_model::updatedb(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 314 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 134
ERROR - 2016-02-20 14:56:12 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-20 14:56:12 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 137
INFO - 2016-02-20 14:56:12 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-20 14:56:12 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455998172
WHERE `id` = `Array`
AND `id` = 'db08cf824be072a5045ccd805d68cd0df1f1e335'
INFO - 2016-02-20 11:56:20 --> Config Class Initialized
INFO - 2016-02-20 11:56:20 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:56:20 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:56:20 --> Utf8 Class Initialized
INFO - 2016-02-20 11:56:20 --> URI Class Initialized
INFO - 2016-02-20 11:56:20 --> Router Class Initialized
INFO - 2016-02-20 11:56:20 --> Output Class Initialized
INFO - 2016-02-20 11:56:20 --> Security Class Initialized
DEBUG - 2016-02-20 11:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:56:20 --> Input Class Initialized
INFO - 2016-02-20 11:56:20 --> Language Class Initialized
INFO - 2016-02-20 11:56:20 --> Loader Class Initialized
INFO - 2016-02-20 11:56:20 --> Helper loaded: url_helper
INFO - 2016-02-20 11:56:20 --> Helper loaded: file_helper
INFO - 2016-02-20 11:56:20 --> Helper loaded: date_helper
INFO - 2016-02-20 11:56:20 --> Helper loaded: form_helper
INFO - 2016-02-20 11:56:20 --> Database Driver Class Initialized
INFO - 2016-02-20 11:56:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:56:21 --> Controller Class Initialized
INFO - 2016-02-20 11:56:21 --> Model Class Initialized
INFO - 2016-02-20 11:56:21 --> Model Class Initialized
INFO - 2016-02-20 11:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:56:21 --> Pagination Class Initialized
INFO - 2016-02-20 11:56:21 --> Helper loaded: text_helper
INFO - 2016-02-20 11:56:21 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:56:21 --> Final output sent to browser
DEBUG - 2016-02-20 14:56:21 --> Total execution time: 1.1693
INFO - 2016-02-20 11:58:05 --> Config Class Initialized
INFO - 2016-02-20 11:58:05 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:58:05 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:58:05 --> Utf8 Class Initialized
INFO - 2016-02-20 11:58:05 --> URI Class Initialized
INFO - 2016-02-20 11:58:05 --> Router Class Initialized
INFO - 2016-02-20 11:58:05 --> Output Class Initialized
INFO - 2016-02-20 11:58:05 --> Security Class Initialized
DEBUG - 2016-02-20 11:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:58:05 --> Input Class Initialized
INFO - 2016-02-20 11:58:05 --> Language Class Initialized
INFO - 2016-02-20 11:58:05 --> Loader Class Initialized
INFO - 2016-02-20 11:58:05 --> Helper loaded: url_helper
INFO - 2016-02-20 11:58:05 --> Helper loaded: file_helper
INFO - 2016-02-20 11:58:05 --> Helper loaded: date_helper
INFO - 2016-02-20 11:58:05 --> Helper loaded: form_helper
INFO - 2016-02-20 11:58:05 --> Database Driver Class Initialized
INFO - 2016-02-20 11:58:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:58:06 --> Controller Class Initialized
INFO - 2016-02-20 11:58:06 --> Model Class Initialized
INFO - 2016-02-20 11:58:06 --> Model Class Initialized
INFO - 2016-02-20 11:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:58:06 --> Pagination Class Initialized
INFO - 2016-02-20 11:58:06 --> Helper loaded: text_helper
INFO - 2016-02-20 11:58:06 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:58:06 --> Final output sent to browser
DEBUG - 2016-02-20 14:58:06 --> Total execution time: 1.1510
INFO - 2016-02-20 11:58:06 --> Config Class Initialized
INFO - 2016-02-20 11:58:06 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:58:06 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:58:06 --> Utf8 Class Initialized
INFO - 2016-02-20 11:58:06 --> URI Class Initialized
INFO - 2016-02-20 11:58:06 --> Router Class Initialized
INFO - 2016-02-20 11:58:06 --> Output Class Initialized
INFO - 2016-02-20 11:58:06 --> Security Class Initialized
DEBUG - 2016-02-20 11:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:58:06 --> Input Class Initialized
INFO - 2016-02-20 11:58:06 --> Language Class Initialized
ERROR - 2016-02-20 11:58:06 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 11:58:10 --> Config Class Initialized
INFO - 2016-02-20 11:58:10 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:58:10 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:58:10 --> Utf8 Class Initialized
INFO - 2016-02-20 11:58:10 --> URI Class Initialized
INFO - 2016-02-20 11:58:10 --> Router Class Initialized
INFO - 2016-02-20 11:58:10 --> Output Class Initialized
INFO - 2016-02-20 11:58:10 --> Security Class Initialized
DEBUG - 2016-02-20 11:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:58:10 --> Input Class Initialized
INFO - 2016-02-20 11:58:10 --> Language Class Initialized
INFO - 2016-02-20 11:58:10 --> Loader Class Initialized
INFO - 2016-02-20 11:58:10 --> Helper loaded: url_helper
INFO - 2016-02-20 11:58:10 --> Helper loaded: file_helper
INFO - 2016-02-20 11:58:10 --> Helper loaded: date_helper
INFO - 2016-02-20 11:58:10 --> Helper loaded: form_helper
INFO - 2016-02-20 11:58:10 --> Database Driver Class Initialized
INFO - 2016-02-20 11:58:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:58:11 --> Controller Class Initialized
INFO - 2016-02-20 11:58:11 --> Model Class Initialized
INFO - 2016-02-20 11:58:11 --> Model Class Initialized
INFO - 2016-02-20 11:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:58:11 --> Pagination Class Initialized
INFO - 2016-02-20 11:58:11 --> Helper loaded: text_helper
INFO - 2016-02-20 11:58:11 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:58:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:58:11 --> Final output sent to browser
DEBUG - 2016-02-20 14:58:11 --> Total execution time: 1.1947
INFO - 2016-02-20 11:58:13 --> Config Class Initialized
INFO - 2016-02-20 11:58:13 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:58:13 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:58:13 --> Utf8 Class Initialized
INFO - 2016-02-20 11:58:13 --> URI Class Initialized
INFO - 2016-02-20 11:58:13 --> Router Class Initialized
INFO - 2016-02-20 11:58:13 --> Output Class Initialized
INFO - 2016-02-20 11:58:13 --> Security Class Initialized
DEBUG - 2016-02-20 11:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:58:13 --> Input Class Initialized
INFO - 2016-02-20 11:58:13 --> Language Class Initialized
INFO - 2016-02-20 11:58:13 --> Loader Class Initialized
INFO - 2016-02-20 11:58:13 --> Helper loaded: url_helper
INFO - 2016-02-20 11:58:13 --> Helper loaded: file_helper
INFO - 2016-02-20 11:58:13 --> Helper loaded: date_helper
INFO - 2016-02-20 11:58:13 --> Helper loaded: form_helper
INFO - 2016-02-20 11:58:13 --> Database Driver Class Initialized
INFO - 2016-02-20 11:58:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 11:58:14 --> Controller Class Initialized
INFO - 2016-02-20 11:58:14 --> Model Class Initialized
INFO - 2016-02-20 11:58:14 --> Model Class Initialized
INFO - 2016-02-20 11:58:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 11:58:14 --> Pagination Class Initialized
INFO - 2016-02-20 11:58:14 --> Helper loaded: text_helper
INFO - 2016-02-20 11:58:14 --> Helper loaded: cookie_helper
INFO - 2016-02-20 14:58:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 14:58:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 14:58:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 14:58:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 14:58:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 14:58:14 --> Final output sent to browser
DEBUG - 2016-02-20 14:58:14 --> Total execution time: 1.1392
INFO - 2016-02-20 11:58:15 --> Config Class Initialized
INFO - 2016-02-20 11:58:15 --> Hooks Class Initialized
DEBUG - 2016-02-20 11:58:15 --> UTF-8 Support Enabled
INFO - 2016-02-20 11:58:15 --> Utf8 Class Initialized
INFO - 2016-02-20 11:58:15 --> URI Class Initialized
INFO - 2016-02-20 11:58:15 --> Router Class Initialized
INFO - 2016-02-20 11:58:15 --> Output Class Initialized
INFO - 2016-02-20 11:58:15 --> Security Class Initialized
DEBUG - 2016-02-20 11:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 11:58:15 --> Input Class Initialized
INFO - 2016-02-20 11:58:15 --> Language Class Initialized
ERROR - 2016-02-20 11:58:15 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:00:50 --> Config Class Initialized
INFO - 2016-02-20 12:00:50 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:00:50 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:00:50 --> Utf8 Class Initialized
INFO - 2016-02-20 12:00:50 --> URI Class Initialized
INFO - 2016-02-20 12:00:50 --> Router Class Initialized
INFO - 2016-02-20 12:00:50 --> Output Class Initialized
INFO - 2016-02-20 12:00:50 --> Security Class Initialized
DEBUG - 2016-02-20 12:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:00:50 --> Input Class Initialized
INFO - 2016-02-20 12:00:50 --> Language Class Initialized
INFO - 2016-02-20 12:00:50 --> Loader Class Initialized
INFO - 2016-02-20 12:00:50 --> Helper loaded: url_helper
INFO - 2016-02-20 12:00:50 --> Helper loaded: file_helper
INFO - 2016-02-20 12:00:50 --> Helper loaded: date_helper
INFO - 2016-02-20 12:00:50 --> Helper loaded: form_helper
INFO - 2016-02-20 12:00:50 --> Database Driver Class Initialized
INFO - 2016-02-20 12:00:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:00:51 --> Controller Class Initialized
INFO - 2016-02-20 12:00:51 --> Model Class Initialized
INFO - 2016-02-20 12:00:51 --> Model Class Initialized
INFO - 2016-02-20 12:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:00:51 --> Pagination Class Initialized
INFO - 2016-02-20 12:00:52 --> Helper loaded: text_helper
INFO - 2016-02-20 12:00:52 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:00:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:00:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:00:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:00:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:00:52 --> Final output sent to browser
DEBUG - 2016-02-20 15:00:52 --> Total execution time: 1.1635
INFO - 2016-02-20 12:00:54 --> Config Class Initialized
INFO - 2016-02-20 12:00:54 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:00:54 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:00:54 --> Utf8 Class Initialized
INFO - 2016-02-20 12:00:54 --> URI Class Initialized
INFO - 2016-02-20 12:00:54 --> Router Class Initialized
INFO - 2016-02-20 12:00:54 --> Output Class Initialized
INFO - 2016-02-20 12:00:54 --> Security Class Initialized
DEBUG - 2016-02-20 12:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:00:54 --> Input Class Initialized
INFO - 2016-02-20 12:00:54 --> Language Class Initialized
INFO - 2016-02-20 12:00:54 --> Loader Class Initialized
INFO - 2016-02-20 12:00:54 --> Helper loaded: url_helper
INFO - 2016-02-20 12:00:54 --> Helper loaded: file_helper
INFO - 2016-02-20 12:00:54 --> Helper loaded: date_helper
INFO - 2016-02-20 12:00:54 --> Helper loaded: form_helper
INFO - 2016-02-20 12:00:54 --> Database Driver Class Initialized
INFO - 2016-02-20 12:00:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:00:55 --> Controller Class Initialized
INFO - 2016-02-20 12:00:55 --> Model Class Initialized
INFO - 2016-02-20 12:00:55 --> Model Class Initialized
INFO - 2016-02-20 12:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:00:55 --> Pagination Class Initialized
INFO - 2016-02-20 12:00:55 --> Helper loaded: text_helper
INFO - 2016-02-20 12:00:55 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:00:55 --> Final output sent to browser
DEBUG - 2016-02-20 15:00:55 --> Total execution time: 1.1602
INFO - 2016-02-20 12:00:57 --> Config Class Initialized
INFO - 2016-02-20 12:00:57 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:00:57 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:00:57 --> Utf8 Class Initialized
INFO - 2016-02-20 12:00:57 --> URI Class Initialized
INFO - 2016-02-20 12:00:57 --> Router Class Initialized
INFO - 2016-02-20 12:00:57 --> Output Class Initialized
INFO - 2016-02-20 12:00:57 --> Security Class Initialized
DEBUG - 2016-02-20 12:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:00:57 --> Input Class Initialized
INFO - 2016-02-20 12:00:57 --> Language Class Initialized
INFO - 2016-02-20 12:00:57 --> Loader Class Initialized
INFO - 2016-02-20 12:00:57 --> Helper loaded: url_helper
INFO - 2016-02-20 12:00:57 --> Helper loaded: file_helper
INFO - 2016-02-20 12:00:57 --> Helper loaded: date_helper
INFO - 2016-02-20 12:00:57 --> Helper loaded: form_helper
INFO - 2016-02-20 12:00:57 --> Database Driver Class Initialized
INFO - 2016-02-20 12:00:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:00:58 --> Controller Class Initialized
INFO - 2016-02-20 12:00:58 --> Model Class Initialized
INFO - 2016-02-20 12:00:58 --> Model Class Initialized
INFO - 2016-02-20 12:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:00:58 --> Pagination Class Initialized
INFO - 2016-02-20 12:00:58 --> Helper loaded: text_helper
INFO - 2016-02-20 12:00:58 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:00:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:00:58 --> Final output sent to browser
DEBUG - 2016-02-20 15:00:58 --> Total execution time: 1.1353
INFO - 2016-02-20 12:00:58 --> Config Class Initialized
INFO - 2016-02-20 12:00:58 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:00:58 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:00:58 --> Utf8 Class Initialized
INFO - 2016-02-20 12:00:58 --> URI Class Initialized
INFO - 2016-02-20 12:00:58 --> Router Class Initialized
INFO - 2016-02-20 12:00:58 --> Output Class Initialized
INFO - 2016-02-20 12:00:58 --> Security Class Initialized
DEBUG - 2016-02-20 12:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:00:58 --> Input Class Initialized
INFO - 2016-02-20 12:00:58 --> Language Class Initialized
ERROR - 2016-02-20 12:00:58 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:03:18 --> Config Class Initialized
INFO - 2016-02-20 12:03:18 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:03:18 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:03:18 --> Utf8 Class Initialized
INFO - 2016-02-20 12:03:18 --> URI Class Initialized
INFO - 2016-02-20 12:03:18 --> Router Class Initialized
INFO - 2016-02-20 12:03:18 --> Output Class Initialized
INFO - 2016-02-20 12:03:18 --> Security Class Initialized
DEBUG - 2016-02-20 12:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:03:18 --> Input Class Initialized
INFO - 2016-02-20 12:03:18 --> Language Class Initialized
INFO - 2016-02-20 12:03:18 --> Loader Class Initialized
INFO - 2016-02-20 12:03:18 --> Helper loaded: url_helper
INFO - 2016-02-20 12:03:18 --> Helper loaded: file_helper
INFO - 2016-02-20 12:03:18 --> Helper loaded: date_helper
INFO - 2016-02-20 12:03:18 --> Helper loaded: form_helper
INFO - 2016-02-20 12:03:18 --> Database Driver Class Initialized
INFO - 2016-02-20 12:03:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:03:19 --> Controller Class Initialized
INFO - 2016-02-20 12:03:19 --> Model Class Initialized
INFO - 2016-02-20 12:03:19 --> Model Class Initialized
INFO - 2016-02-20 12:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:03:19 --> Pagination Class Initialized
INFO - 2016-02-20 12:03:19 --> Helper loaded: text_helper
INFO - 2016-02-20 12:03:19 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:03:19 --> Final output sent to browser
DEBUG - 2016-02-20 15:03:19 --> Total execution time: 1.1485
INFO - 2016-02-20 12:03:22 --> Config Class Initialized
INFO - 2016-02-20 12:03:22 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:03:22 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:03:22 --> Utf8 Class Initialized
INFO - 2016-02-20 12:03:22 --> URI Class Initialized
INFO - 2016-02-20 12:03:22 --> Router Class Initialized
INFO - 2016-02-20 12:03:22 --> Output Class Initialized
INFO - 2016-02-20 12:03:22 --> Security Class Initialized
DEBUG - 2016-02-20 12:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:03:22 --> Input Class Initialized
INFO - 2016-02-20 12:03:22 --> Language Class Initialized
INFO - 2016-02-20 12:03:22 --> Loader Class Initialized
INFO - 2016-02-20 12:03:22 --> Helper loaded: url_helper
INFO - 2016-02-20 12:03:22 --> Helper loaded: file_helper
INFO - 2016-02-20 12:03:22 --> Helper loaded: date_helper
INFO - 2016-02-20 12:03:22 --> Helper loaded: form_helper
INFO - 2016-02-20 12:03:22 --> Database Driver Class Initialized
INFO - 2016-02-20 12:03:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:03:23 --> Controller Class Initialized
INFO - 2016-02-20 12:03:23 --> Model Class Initialized
INFO - 2016-02-20 12:03:23 --> Model Class Initialized
INFO - 2016-02-20 12:03:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:03:23 --> Pagination Class Initialized
INFO - 2016-02-20 12:03:23 --> Helper loaded: text_helper
INFO - 2016-02-20 12:03:23 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:03:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:03:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:03:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:03:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:03:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:03:23 --> Final output sent to browser
DEBUG - 2016-02-20 15:03:23 --> Total execution time: 1.2090
INFO - 2016-02-20 12:03:24 --> Config Class Initialized
INFO - 2016-02-20 12:03:24 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:03:24 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:03:24 --> Utf8 Class Initialized
INFO - 2016-02-20 12:03:24 --> URI Class Initialized
INFO - 2016-02-20 12:03:24 --> Router Class Initialized
INFO - 2016-02-20 12:03:24 --> Output Class Initialized
INFO - 2016-02-20 12:03:24 --> Security Class Initialized
DEBUG - 2016-02-20 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:03:24 --> Input Class Initialized
INFO - 2016-02-20 12:03:24 --> Language Class Initialized
INFO - 2016-02-20 12:03:24 --> Loader Class Initialized
INFO - 2016-02-20 12:03:24 --> Helper loaded: url_helper
INFO - 2016-02-20 12:03:24 --> Helper loaded: file_helper
INFO - 2016-02-20 12:03:24 --> Helper loaded: date_helper
INFO - 2016-02-20 12:03:24 --> Helper loaded: form_helper
INFO - 2016-02-20 12:03:24 --> Database Driver Class Initialized
INFO - 2016-02-20 12:03:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:03:25 --> Controller Class Initialized
INFO - 2016-02-20 12:03:25 --> Model Class Initialized
INFO - 2016-02-20 12:03:25 --> Model Class Initialized
INFO - 2016-02-20 12:03:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:03:25 --> Pagination Class Initialized
INFO - 2016-02-20 12:03:25 --> Helper loaded: text_helper
INFO - 2016-02-20 12:03:25 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:03:25 --> Final output sent to browser
DEBUG - 2016-02-20 15:03:25 --> Total execution time: 1.1447
INFO - 2016-02-20 12:03:26 --> Config Class Initialized
INFO - 2016-02-20 12:03:26 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:03:26 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:03:26 --> Utf8 Class Initialized
INFO - 2016-02-20 12:03:26 --> URI Class Initialized
INFO - 2016-02-20 12:03:26 --> Router Class Initialized
INFO - 2016-02-20 12:03:26 --> Output Class Initialized
INFO - 2016-02-20 12:03:26 --> Security Class Initialized
DEBUG - 2016-02-20 12:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:03:26 --> Input Class Initialized
INFO - 2016-02-20 12:03:26 --> Language Class Initialized
ERROR - 2016-02-20 12:03:26 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:03:55 --> Config Class Initialized
INFO - 2016-02-20 12:03:55 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:03:55 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:03:55 --> Utf8 Class Initialized
INFO - 2016-02-20 12:03:55 --> URI Class Initialized
INFO - 2016-02-20 12:03:55 --> Router Class Initialized
INFO - 2016-02-20 12:03:55 --> Output Class Initialized
INFO - 2016-02-20 12:03:55 --> Security Class Initialized
DEBUG - 2016-02-20 12:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:03:55 --> Input Class Initialized
INFO - 2016-02-20 12:03:55 --> Language Class Initialized
INFO - 2016-02-20 12:03:55 --> Loader Class Initialized
INFO - 2016-02-20 12:03:55 --> Helper loaded: url_helper
INFO - 2016-02-20 12:03:55 --> Helper loaded: file_helper
INFO - 2016-02-20 12:03:55 --> Helper loaded: date_helper
INFO - 2016-02-20 12:03:55 --> Helper loaded: form_helper
INFO - 2016-02-20 12:03:55 --> Database Driver Class Initialized
INFO - 2016-02-20 12:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:03:56 --> Controller Class Initialized
INFO - 2016-02-20 12:03:56 --> Model Class Initialized
INFO - 2016-02-20 12:03:56 --> Model Class Initialized
INFO - 2016-02-20 12:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:03:56 --> Pagination Class Initialized
INFO - 2016-02-20 12:03:56 --> Helper loaded: text_helper
INFO - 2016-02-20 12:03:56 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:03:56 --> Final output sent to browser
DEBUG - 2016-02-20 15:03:56 --> Total execution time: 1.1410
INFO - 2016-02-20 12:03:58 --> Config Class Initialized
INFO - 2016-02-20 12:03:58 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:03:58 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:03:58 --> Utf8 Class Initialized
INFO - 2016-02-20 12:03:58 --> URI Class Initialized
INFO - 2016-02-20 12:03:58 --> Router Class Initialized
INFO - 2016-02-20 12:03:58 --> Output Class Initialized
INFO - 2016-02-20 12:03:58 --> Security Class Initialized
DEBUG - 2016-02-20 12:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:03:58 --> Input Class Initialized
INFO - 2016-02-20 12:03:58 --> Language Class Initialized
INFO - 2016-02-20 12:03:58 --> Loader Class Initialized
INFO - 2016-02-20 12:03:58 --> Helper loaded: url_helper
INFO - 2016-02-20 12:03:58 --> Helper loaded: file_helper
INFO - 2016-02-20 12:03:58 --> Helper loaded: date_helper
INFO - 2016-02-20 12:03:58 --> Helper loaded: form_helper
INFO - 2016-02-20 12:03:58 --> Database Driver Class Initialized
INFO - 2016-02-20 12:03:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:03:59 --> Controller Class Initialized
INFO - 2016-02-20 12:03:59 --> Model Class Initialized
INFO - 2016-02-20 12:03:59 --> Model Class Initialized
INFO - 2016-02-20 12:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:03:59 --> Pagination Class Initialized
INFO - 2016-02-20 12:03:59 --> Helper loaded: text_helper
INFO - 2016-02-20 12:03:59 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:03:59 --> Final output sent to browser
DEBUG - 2016-02-20 15:03:59 --> Total execution time: 1.1969
INFO - 2016-02-20 12:04:01 --> Config Class Initialized
INFO - 2016-02-20 12:04:01 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:04:01 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:04:01 --> Utf8 Class Initialized
INFO - 2016-02-20 12:04:01 --> URI Class Initialized
INFO - 2016-02-20 12:04:01 --> Router Class Initialized
INFO - 2016-02-20 12:04:01 --> Output Class Initialized
INFO - 2016-02-20 12:04:01 --> Security Class Initialized
DEBUG - 2016-02-20 12:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:04:01 --> Input Class Initialized
INFO - 2016-02-20 12:04:01 --> Language Class Initialized
INFO - 2016-02-20 12:04:01 --> Loader Class Initialized
INFO - 2016-02-20 12:04:01 --> Helper loaded: url_helper
INFO - 2016-02-20 12:04:01 --> Helper loaded: file_helper
INFO - 2016-02-20 12:04:01 --> Helper loaded: date_helper
INFO - 2016-02-20 12:04:01 --> Helper loaded: form_helper
INFO - 2016-02-20 12:04:01 --> Database Driver Class Initialized
INFO - 2016-02-20 12:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:04:02 --> Controller Class Initialized
INFO - 2016-02-20 12:04:02 --> Model Class Initialized
INFO - 2016-02-20 12:04:02 --> Model Class Initialized
INFO - 2016-02-20 12:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:04:02 --> Pagination Class Initialized
INFO - 2016-02-20 12:04:02 --> Helper loaded: text_helper
INFO - 2016-02-20 12:04:02 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:04:02 --> Final output sent to browser
DEBUG - 2016-02-20 15:04:02 --> Total execution time: 1.1418
INFO - 2016-02-20 12:04:02 --> Config Class Initialized
INFO - 2016-02-20 12:04:02 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:04:02 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:04:02 --> Utf8 Class Initialized
INFO - 2016-02-20 12:04:02 --> URI Class Initialized
INFO - 2016-02-20 12:04:02 --> Router Class Initialized
INFO - 2016-02-20 12:04:02 --> Output Class Initialized
INFO - 2016-02-20 12:04:02 --> Security Class Initialized
DEBUG - 2016-02-20 12:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:04:02 --> Input Class Initialized
INFO - 2016-02-20 12:04:02 --> Language Class Initialized
ERROR - 2016-02-20 12:04:02 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:05:16 --> Config Class Initialized
INFO - 2016-02-20 12:05:16 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:05:16 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:05:16 --> Utf8 Class Initialized
INFO - 2016-02-20 12:05:16 --> URI Class Initialized
INFO - 2016-02-20 12:05:16 --> Router Class Initialized
INFO - 2016-02-20 12:05:16 --> Output Class Initialized
INFO - 2016-02-20 12:05:16 --> Security Class Initialized
DEBUG - 2016-02-20 12:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:05:16 --> Input Class Initialized
INFO - 2016-02-20 12:05:16 --> Language Class Initialized
INFO - 2016-02-20 12:05:16 --> Loader Class Initialized
INFO - 2016-02-20 12:05:16 --> Helper loaded: url_helper
INFO - 2016-02-20 12:05:16 --> Helper loaded: file_helper
INFO - 2016-02-20 12:05:16 --> Helper loaded: date_helper
INFO - 2016-02-20 12:05:16 --> Helper loaded: form_helper
INFO - 2016-02-20 12:05:16 --> Database Driver Class Initialized
INFO - 2016-02-20 12:05:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:05:17 --> Controller Class Initialized
INFO - 2016-02-20 12:05:17 --> Model Class Initialized
INFO - 2016-02-20 12:05:17 --> Model Class Initialized
INFO - 2016-02-20 12:05:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:05:17 --> Pagination Class Initialized
INFO - 2016-02-20 12:05:17 --> Helper loaded: text_helper
INFO - 2016-02-20 12:05:17 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:05:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:05:17 --> Final output sent to browser
DEBUG - 2016-02-20 15:05:17 --> Total execution time: 1.1152
INFO - 2016-02-20 12:05:48 --> Config Class Initialized
INFO - 2016-02-20 12:05:48 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:05:48 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:05:48 --> Utf8 Class Initialized
INFO - 2016-02-20 12:05:48 --> URI Class Initialized
INFO - 2016-02-20 12:05:48 --> Router Class Initialized
INFO - 2016-02-20 12:05:48 --> Output Class Initialized
INFO - 2016-02-20 12:05:48 --> Security Class Initialized
DEBUG - 2016-02-20 12:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:05:48 --> Input Class Initialized
INFO - 2016-02-20 12:05:48 --> Language Class Initialized
INFO - 2016-02-20 12:05:48 --> Loader Class Initialized
INFO - 2016-02-20 12:05:48 --> Helper loaded: url_helper
INFO - 2016-02-20 12:05:48 --> Helper loaded: file_helper
INFO - 2016-02-20 12:05:48 --> Helper loaded: date_helper
INFO - 2016-02-20 12:05:48 --> Helper loaded: form_helper
INFO - 2016-02-20 12:05:48 --> Database Driver Class Initialized
INFO - 2016-02-20 12:05:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:05:49 --> Controller Class Initialized
INFO - 2016-02-20 12:05:49 --> Model Class Initialized
INFO - 2016-02-20 12:05:49 --> Model Class Initialized
INFO - 2016-02-20 12:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:05:49 --> Pagination Class Initialized
INFO - 2016-02-20 12:05:49 --> Helper loaded: text_helper
INFO - 2016-02-20 12:05:49 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:05:49 --> Final output sent to browser
DEBUG - 2016-02-20 15:05:49 --> Total execution time: 1.1895
INFO - 2016-02-20 12:05:51 --> Config Class Initialized
INFO - 2016-02-20 12:05:51 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:05:51 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:05:51 --> Utf8 Class Initialized
INFO - 2016-02-20 12:05:51 --> URI Class Initialized
INFO - 2016-02-20 12:05:51 --> Router Class Initialized
INFO - 2016-02-20 12:05:51 --> Output Class Initialized
INFO - 2016-02-20 12:05:51 --> Security Class Initialized
DEBUG - 2016-02-20 12:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:05:51 --> Input Class Initialized
INFO - 2016-02-20 12:05:51 --> Language Class Initialized
INFO - 2016-02-20 12:05:51 --> Loader Class Initialized
INFO - 2016-02-20 12:05:51 --> Helper loaded: url_helper
INFO - 2016-02-20 12:05:51 --> Helper loaded: file_helper
INFO - 2016-02-20 12:05:51 --> Helper loaded: date_helper
INFO - 2016-02-20 12:05:51 --> Helper loaded: form_helper
INFO - 2016-02-20 12:05:51 --> Database Driver Class Initialized
INFO - 2016-02-20 12:05:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:05:52 --> Controller Class Initialized
INFO - 2016-02-20 12:05:52 --> Model Class Initialized
INFO - 2016-02-20 12:05:52 --> Model Class Initialized
INFO - 2016-02-20 12:05:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:05:52 --> Pagination Class Initialized
INFO - 2016-02-20 12:05:52 --> Helper loaded: text_helper
INFO - 2016-02-20 12:05:52 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:05:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:05:52 --> Final output sent to browser
DEBUG - 2016-02-20 15:05:52 --> Total execution time: 1.1613
INFO - 2016-02-20 12:05:53 --> Config Class Initialized
INFO - 2016-02-20 12:05:53 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:05:53 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:05:53 --> Utf8 Class Initialized
INFO - 2016-02-20 12:05:53 --> URI Class Initialized
INFO - 2016-02-20 12:05:53 --> Router Class Initialized
INFO - 2016-02-20 12:05:53 --> Output Class Initialized
INFO - 2016-02-20 12:05:53 --> Security Class Initialized
DEBUG - 2016-02-20 12:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:05:53 --> Input Class Initialized
INFO - 2016-02-20 12:05:53 --> Language Class Initialized
ERROR - 2016-02-20 12:05:53 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:05:57 --> Config Class Initialized
INFO - 2016-02-20 12:05:57 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:05:57 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:05:57 --> Utf8 Class Initialized
INFO - 2016-02-20 12:05:57 --> URI Class Initialized
INFO - 2016-02-20 12:05:57 --> Router Class Initialized
INFO - 2016-02-20 12:05:57 --> Output Class Initialized
INFO - 2016-02-20 12:05:57 --> Security Class Initialized
DEBUG - 2016-02-20 12:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:05:57 --> Input Class Initialized
INFO - 2016-02-20 12:05:57 --> Language Class Initialized
INFO - 2016-02-20 12:05:57 --> Loader Class Initialized
INFO - 2016-02-20 12:05:57 --> Helper loaded: url_helper
INFO - 2016-02-20 12:05:57 --> Helper loaded: file_helper
INFO - 2016-02-20 12:05:57 --> Helper loaded: date_helper
INFO - 2016-02-20 12:05:57 --> Helper loaded: form_helper
INFO - 2016-02-20 12:05:57 --> Database Driver Class Initialized
INFO - 2016-02-20 12:05:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:05:58 --> Controller Class Initialized
INFO - 2016-02-20 12:05:58 --> Model Class Initialized
INFO - 2016-02-20 12:05:58 --> Model Class Initialized
INFO - 2016-02-20 12:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:05:58 --> Pagination Class Initialized
INFO - 2016-02-20 12:05:58 --> Helper loaded: text_helper
INFO - 2016-02-20 12:05:58 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:05:58 --> Final output sent to browser
DEBUG - 2016-02-20 15:05:58 --> Total execution time: 1.2003
INFO - 2016-02-20 12:06:06 --> Config Class Initialized
INFO - 2016-02-20 12:06:06 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:06:06 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:06:06 --> Utf8 Class Initialized
INFO - 2016-02-20 12:06:06 --> URI Class Initialized
INFO - 2016-02-20 12:06:06 --> Router Class Initialized
INFO - 2016-02-20 12:06:06 --> Output Class Initialized
INFO - 2016-02-20 12:06:06 --> Security Class Initialized
DEBUG - 2016-02-20 12:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:06:06 --> Input Class Initialized
INFO - 2016-02-20 12:06:06 --> Language Class Initialized
INFO - 2016-02-20 12:06:06 --> Loader Class Initialized
INFO - 2016-02-20 12:06:06 --> Helper loaded: url_helper
INFO - 2016-02-20 12:06:06 --> Helper loaded: file_helper
INFO - 2016-02-20 12:06:06 --> Helper loaded: date_helper
INFO - 2016-02-20 12:06:06 --> Helper loaded: form_helper
INFO - 2016-02-20 12:06:06 --> Database Driver Class Initialized
INFO - 2016-02-20 12:06:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:06:07 --> Controller Class Initialized
INFO - 2016-02-20 12:06:07 --> Model Class Initialized
INFO - 2016-02-20 12:06:07 --> Model Class Initialized
INFO - 2016-02-20 12:06:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:06:07 --> Pagination Class Initialized
INFO - 2016-02-20 12:06:07 --> Helper loaded: text_helper
INFO - 2016-02-20 12:06:07 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:06:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:06:07 --> Final output sent to browser
DEBUG - 2016-02-20 15:06:07 --> Total execution time: 1.1447
INFO - 2016-02-20 12:06:08 --> Config Class Initialized
INFO - 2016-02-20 12:06:08 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:06:08 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:06:08 --> Utf8 Class Initialized
INFO - 2016-02-20 12:06:08 --> URI Class Initialized
INFO - 2016-02-20 12:06:08 --> Router Class Initialized
INFO - 2016-02-20 12:06:08 --> Output Class Initialized
INFO - 2016-02-20 12:06:08 --> Security Class Initialized
DEBUG - 2016-02-20 12:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:06:08 --> Input Class Initialized
INFO - 2016-02-20 12:06:08 --> Language Class Initialized
ERROR - 2016-02-20 12:06:08 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:06:09 --> Config Class Initialized
INFO - 2016-02-20 12:06:09 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:06:09 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:06:09 --> Utf8 Class Initialized
INFO - 2016-02-20 12:06:09 --> URI Class Initialized
INFO - 2016-02-20 12:06:09 --> Router Class Initialized
INFO - 2016-02-20 12:06:09 --> Output Class Initialized
INFO - 2016-02-20 12:06:09 --> Security Class Initialized
DEBUG - 2016-02-20 12:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:06:09 --> Input Class Initialized
INFO - 2016-02-20 12:06:09 --> Language Class Initialized
INFO - 2016-02-20 12:06:09 --> Loader Class Initialized
INFO - 2016-02-20 12:06:09 --> Helper loaded: url_helper
INFO - 2016-02-20 12:06:09 --> Helper loaded: file_helper
INFO - 2016-02-20 12:06:09 --> Helper loaded: date_helper
INFO - 2016-02-20 12:06:09 --> Helper loaded: form_helper
INFO - 2016-02-20 12:06:09 --> Database Driver Class Initialized
INFO - 2016-02-20 12:06:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:06:10 --> Controller Class Initialized
INFO - 2016-02-20 12:06:10 --> Model Class Initialized
INFO - 2016-02-20 12:06:10 --> Model Class Initialized
INFO - 2016-02-20 12:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:06:10 --> Pagination Class Initialized
INFO - 2016-02-20 12:06:10 --> Helper loaded: text_helper
INFO - 2016-02-20 12:06:10 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:06:10 --> Final output sent to browser
DEBUG - 2016-02-20 15:06:10 --> Total execution time: 1.2109
INFO - 2016-02-20 12:08:21 --> Config Class Initialized
INFO - 2016-02-20 12:08:21 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:08:21 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:08:21 --> Utf8 Class Initialized
INFO - 2016-02-20 12:08:21 --> URI Class Initialized
INFO - 2016-02-20 12:08:21 --> Router Class Initialized
INFO - 2016-02-20 12:08:21 --> Output Class Initialized
INFO - 2016-02-20 12:08:21 --> Security Class Initialized
DEBUG - 2016-02-20 12:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:08:21 --> Input Class Initialized
INFO - 2016-02-20 12:08:21 --> Language Class Initialized
INFO - 2016-02-20 12:08:21 --> Loader Class Initialized
INFO - 2016-02-20 12:08:21 --> Helper loaded: url_helper
INFO - 2016-02-20 12:08:21 --> Helper loaded: file_helper
INFO - 2016-02-20 12:08:21 --> Helper loaded: date_helper
INFO - 2016-02-20 12:08:21 --> Helper loaded: form_helper
INFO - 2016-02-20 12:08:21 --> Database Driver Class Initialized
INFO - 2016-02-20 12:08:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:08:22 --> Controller Class Initialized
INFO - 2016-02-20 12:08:22 --> Model Class Initialized
INFO - 2016-02-20 12:08:22 --> Model Class Initialized
INFO - 2016-02-20 12:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:08:22 --> Pagination Class Initialized
INFO - 2016-02-20 12:08:22 --> Helper loaded: text_helper
INFO - 2016-02-20 12:08:22 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:08:22 --> Final output sent to browser
DEBUG - 2016-02-20 15:08:22 --> Total execution time: 1.1594
INFO - 2016-02-20 12:08:22 --> Config Class Initialized
INFO - 2016-02-20 12:08:22 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:08:22 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:08:22 --> Utf8 Class Initialized
INFO - 2016-02-20 12:08:22 --> URI Class Initialized
INFO - 2016-02-20 12:08:22 --> Router Class Initialized
INFO - 2016-02-20 12:08:22 --> Output Class Initialized
INFO - 2016-02-20 12:08:22 --> Security Class Initialized
DEBUG - 2016-02-20 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:08:22 --> Input Class Initialized
INFO - 2016-02-20 12:08:22 --> Language Class Initialized
ERROR - 2016-02-20 12:08:22 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:11:40 --> Config Class Initialized
INFO - 2016-02-20 12:11:40 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:11:40 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:11:40 --> Utf8 Class Initialized
INFO - 2016-02-20 12:11:40 --> URI Class Initialized
INFO - 2016-02-20 12:11:40 --> Router Class Initialized
INFO - 2016-02-20 12:11:40 --> Output Class Initialized
INFO - 2016-02-20 12:11:40 --> Security Class Initialized
DEBUG - 2016-02-20 12:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:11:40 --> Input Class Initialized
INFO - 2016-02-20 12:11:40 --> Language Class Initialized
INFO - 2016-02-20 12:11:40 --> Loader Class Initialized
INFO - 2016-02-20 12:11:40 --> Helper loaded: url_helper
INFO - 2016-02-20 12:11:40 --> Helper loaded: file_helper
INFO - 2016-02-20 12:11:40 --> Helper loaded: date_helper
INFO - 2016-02-20 12:11:40 --> Helper loaded: form_helper
INFO - 2016-02-20 12:11:40 --> Database Driver Class Initialized
INFO - 2016-02-20 12:11:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:11:41 --> Controller Class Initialized
INFO - 2016-02-20 12:11:41 --> Model Class Initialized
INFO - 2016-02-20 12:11:41 --> Model Class Initialized
INFO - 2016-02-20 12:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:11:41 --> Pagination Class Initialized
INFO - 2016-02-20 12:11:41 --> Helper loaded: text_helper
INFO - 2016-02-20 12:11:41 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:11:41 --> Final output sent to browser
DEBUG - 2016-02-20 15:11:41 --> Total execution time: 1.1442
INFO - 2016-02-20 12:11:44 --> Config Class Initialized
INFO - 2016-02-20 12:11:44 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:11:44 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:11:44 --> Utf8 Class Initialized
INFO - 2016-02-20 12:11:44 --> URI Class Initialized
INFO - 2016-02-20 12:11:44 --> Router Class Initialized
INFO - 2016-02-20 12:11:44 --> Output Class Initialized
INFO - 2016-02-20 12:11:44 --> Security Class Initialized
DEBUG - 2016-02-20 12:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:11:44 --> Input Class Initialized
INFO - 2016-02-20 12:11:44 --> Language Class Initialized
INFO - 2016-02-20 12:11:44 --> Loader Class Initialized
INFO - 2016-02-20 12:11:44 --> Helper loaded: url_helper
INFO - 2016-02-20 12:11:44 --> Helper loaded: file_helper
INFO - 2016-02-20 12:11:44 --> Helper loaded: date_helper
INFO - 2016-02-20 12:11:44 --> Helper loaded: form_helper
INFO - 2016-02-20 12:11:44 --> Database Driver Class Initialized
INFO - 2016-02-20 12:11:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:11:45 --> Controller Class Initialized
INFO - 2016-02-20 12:11:45 --> Model Class Initialized
INFO - 2016-02-20 12:11:45 --> Model Class Initialized
INFO - 2016-02-20 12:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:11:45 --> Pagination Class Initialized
INFO - 2016-02-20 12:11:45 --> Helper loaded: text_helper
INFO - 2016-02-20 12:11:45 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:11:45 --> Final output sent to browser
DEBUG - 2016-02-20 15:11:45 --> Total execution time: 1.1913
INFO - 2016-02-20 12:11:50 --> Config Class Initialized
INFO - 2016-02-20 12:11:50 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:11:50 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:11:50 --> Utf8 Class Initialized
INFO - 2016-02-20 12:11:50 --> URI Class Initialized
INFO - 2016-02-20 12:11:50 --> Router Class Initialized
INFO - 2016-02-20 12:11:50 --> Output Class Initialized
INFO - 2016-02-20 12:11:50 --> Security Class Initialized
DEBUG - 2016-02-20 12:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:11:50 --> Input Class Initialized
INFO - 2016-02-20 12:11:50 --> Language Class Initialized
INFO - 2016-02-20 12:11:50 --> Loader Class Initialized
INFO - 2016-02-20 12:11:50 --> Helper loaded: url_helper
INFO - 2016-02-20 12:11:50 --> Helper loaded: file_helper
INFO - 2016-02-20 12:11:50 --> Helper loaded: date_helper
INFO - 2016-02-20 12:11:50 --> Helper loaded: form_helper
INFO - 2016-02-20 12:11:50 --> Database Driver Class Initialized
INFO - 2016-02-20 12:11:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:11:51 --> Controller Class Initialized
INFO - 2016-02-20 12:11:51 --> Model Class Initialized
INFO - 2016-02-20 12:11:51 --> Model Class Initialized
INFO - 2016-02-20 12:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:11:51 --> Pagination Class Initialized
INFO - 2016-02-20 12:11:51 --> Helper loaded: text_helper
INFO - 2016-02-20 12:11:51 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:11:51 --> Final output sent to browser
DEBUG - 2016-02-20 15:11:51 --> Total execution time: 1.1531
INFO - 2016-02-20 12:11:52 --> Config Class Initialized
INFO - 2016-02-20 12:11:52 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:11:52 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:11:52 --> Utf8 Class Initialized
INFO - 2016-02-20 12:11:52 --> URI Class Initialized
INFO - 2016-02-20 12:11:52 --> Router Class Initialized
INFO - 2016-02-20 12:11:52 --> Output Class Initialized
INFO - 2016-02-20 12:11:52 --> Security Class Initialized
DEBUG - 2016-02-20 12:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:11:52 --> Input Class Initialized
INFO - 2016-02-20 12:11:52 --> Language Class Initialized
ERROR - 2016-02-20 12:11:52 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:14:13 --> Config Class Initialized
INFO - 2016-02-20 12:14:13 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:14:13 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:14:13 --> Utf8 Class Initialized
INFO - 2016-02-20 12:14:13 --> URI Class Initialized
INFO - 2016-02-20 12:14:13 --> Router Class Initialized
INFO - 2016-02-20 12:14:13 --> Output Class Initialized
INFO - 2016-02-20 12:14:13 --> Security Class Initialized
DEBUG - 2016-02-20 12:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:14:13 --> Input Class Initialized
INFO - 2016-02-20 12:14:13 --> Language Class Initialized
INFO - 2016-02-20 12:14:13 --> Loader Class Initialized
INFO - 2016-02-20 12:14:13 --> Helper loaded: url_helper
INFO - 2016-02-20 12:14:13 --> Helper loaded: file_helper
INFO - 2016-02-20 12:14:13 --> Helper loaded: date_helper
INFO - 2016-02-20 12:14:13 --> Helper loaded: form_helper
INFO - 2016-02-20 12:14:13 --> Database Driver Class Initialized
INFO - 2016-02-20 12:14:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:14:14 --> Controller Class Initialized
INFO - 2016-02-20 12:14:14 --> Model Class Initialized
INFO - 2016-02-20 12:14:14 --> Model Class Initialized
INFO - 2016-02-20 12:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:14:14 --> Pagination Class Initialized
INFO - 2016-02-20 12:14:14 --> Helper loaded: text_helper
INFO - 2016-02-20 12:14:14 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:14:14 --> Final output sent to browser
DEBUG - 2016-02-20 15:14:14 --> Total execution time: 1.1581
INFO - 2016-02-20 12:14:16 --> Config Class Initialized
INFO - 2016-02-20 12:14:16 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:14:16 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:14:16 --> Utf8 Class Initialized
INFO - 2016-02-20 12:14:16 --> URI Class Initialized
INFO - 2016-02-20 12:14:16 --> Router Class Initialized
INFO - 2016-02-20 12:14:16 --> Output Class Initialized
INFO - 2016-02-20 12:14:16 --> Security Class Initialized
DEBUG - 2016-02-20 12:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:14:16 --> Input Class Initialized
INFO - 2016-02-20 12:14:16 --> Language Class Initialized
INFO - 2016-02-20 12:14:16 --> Loader Class Initialized
INFO - 2016-02-20 12:14:16 --> Helper loaded: url_helper
INFO - 2016-02-20 12:14:16 --> Helper loaded: file_helper
INFO - 2016-02-20 12:14:16 --> Helper loaded: date_helper
INFO - 2016-02-20 12:14:16 --> Helper loaded: form_helper
INFO - 2016-02-20 12:14:16 --> Database Driver Class Initialized
INFO - 2016-02-20 12:14:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:14:17 --> Controller Class Initialized
INFO - 2016-02-20 12:14:17 --> Model Class Initialized
INFO - 2016-02-20 12:14:17 --> Model Class Initialized
INFO - 2016-02-20 12:14:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:14:17 --> Pagination Class Initialized
INFO - 2016-02-20 12:14:17 --> Helper loaded: text_helper
INFO - 2016-02-20 12:14:17 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:14:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:14:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:14:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:14:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:14:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:14:17 --> Final output sent to browser
DEBUG - 2016-02-20 15:14:17 --> Total execution time: 1.1781
INFO - 2016-02-20 12:14:19 --> Config Class Initialized
INFO - 2016-02-20 12:14:19 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:14:19 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:14:19 --> Utf8 Class Initialized
INFO - 2016-02-20 12:14:19 --> URI Class Initialized
INFO - 2016-02-20 12:14:19 --> Router Class Initialized
INFO - 2016-02-20 12:14:19 --> Output Class Initialized
INFO - 2016-02-20 12:14:19 --> Security Class Initialized
DEBUG - 2016-02-20 12:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:14:19 --> Input Class Initialized
INFO - 2016-02-20 12:14:19 --> Language Class Initialized
INFO - 2016-02-20 12:14:19 --> Loader Class Initialized
INFO - 2016-02-20 12:14:19 --> Helper loaded: url_helper
INFO - 2016-02-20 12:14:19 --> Helper loaded: file_helper
INFO - 2016-02-20 12:14:19 --> Helper loaded: date_helper
INFO - 2016-02-20 12:14:19 --> Helper loaded: form_helper
INFO - 2016-02-20 12:14:19 --> Database Driver Class Initialized
INFO - 2016-02-20 12:14:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:14:20 --> Controller Class Initialized
INFO - 2016-02-20 12:14:20 --> Model Class Initialized
INFO - 2016-02-20 12:14:20 --> Model Class Initialized
INFO - 2016-02-20 12:14:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:14:20 --> Pagination Class Initialized
INFO - 2016-02-20 12:14:20 --> Helper loaded: text_helper
INFO - 2016-02-20 12:14:20 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:14:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:14:20 --> Final output sent to browser
DEBUG - 2016-02-20 15:14:20 --> Total execution time: 1.1413
INFO - 2016-02-20 12:14:20 --> Config Class Initialized
INFO - 2016-02-20 12:14:20 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:14:20 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:14:20 --> Utf8 Class Initialized
INFO - 2016-02-20 12:14:20 --> URI Class Initialized
INFO - 2016-02-20 12:14:20 --> Router Class Initialized
INFO - 2016-02-20 12:14:20 --> Output Class Initialized
INFO - 2016-02-20 12:14:20 --> Security Class Initialized
DEBUG - 2016-02-20 12:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:14:20 --> Input Class Initialized
INFO - 2016-02-20 12:14:20 --> Language Class Initialized
ERROR - 2016-02-20 12:14:20 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:14:25 --> Config Class Initialized
INFO - 2016-02-20 12:14:25 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:14:25 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:14:25 --> Utf8 Class Initialized
INFO - 2016-02-20 12:14:25 --> URI Class Initialized
INFO - 2016-02-20 12:14:25 --> Router Class Initialized
INFO - 2016-02-20 12:14:25 --> Output Class Initialized
INFO - 2016-02-20 12:14:25 --> Security Class Initialized
DEBUG - 2016-02-20 12:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:14:25 --> Input Class Initialized
INFO - 2016-02-20 12:14:25 --> Language Class Initialized
INFO - 2016-02-20 12:14:25 --> Loader Class Initialized
INFO - 2016-02-20 12:14:25 --> Helper loaded: url_helper
INFO - 2016-02-20 12:14:25 --> Helper loaded: file_helper
INFO - 2016-02-20 12:14:25 --> Helper loaded: date_helper
INFO - 2016-02-20 12:14:25 --> Helper loaded: form_helper
INFO - 2016-02-20 12:14:25 --> Database Driver Class Initialized
INFO - 2016-02-20 12:14:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:14:26 --> Controller Class Initialized
INFO - 2016-02-20 12:14:26 --> Model Class Initialized
INFO - 2016-02-20 12:14:26 --> Model Class Initialized
INFO - 2016-02-20 12:14:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:14:27 --> Pagination Class Initialized
INFO - 2016-02-20 12:14:27 --> Helper loaded: text_helper
INFO - 2016-02-20 12:14:27 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:14:27 --> Final output sent to browser
DEBUG - 2016-02-20 15:14:27 --> Total execution time: 1.1104
INFO - 2016-02-20 12:16:19 --> Config Class Initialized
INFO - 2016-02-20 12:16:19 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:16:19 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:16:19 --> Utf8 Class Initialized
INFO - 2016-02-20 12:16:19 --> URI Class Initialized
INFO - 2016-02-20 12:16:19 --> Router Class Initialized
INFO - 2016-02-20 12:16:19 --> Output Class Initialized
INFO - 2016-02-20 12:16:19 --> Security Class Initialized
DEBUG - 2016-02-20 12:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:16:19 --> Input Class Initialized
INFO - 2016-02-20 12:16:19 --> Language Class Initialized
INFO - 2016-02-20 12:16:19 --> Loader Class Initialized
INFO - 2016-02-20 12:16:19 --> Helper loaded: url_helper
INFO - 2016-02-20 12:16:20 --> Helper loaded: file_helper
INFO - 2016-02-20 12:16:20 --> Helper loaded: date_helper
INFO - 2016-02-20 12:16:20 --> Helper loaded: form_helper
INFO - 2016-02-20 12:16:20 --> Database Driver Class Initialized
INFO - 2016-02-20 12:16:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:16:21 --> Controller Class Initialized
INFO - 2016-02-20 12:16:21 --> Model Class Initialized
INFO - 2016-02-20 12:16:21 --> Model Class Initialized
INFO - 2016-02-20 12:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:16:21 --> Pagination Class Initialized
INFO - 2016-02-20 12:16:21 --> Helper loaded: text_helper
INFO - 2016-02-20 12:16:21 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:16:21 --> Final output sent to browser
DEBUG - 2016-02-20 15:16:21 --> Total execution time: 1.1300
INFO - 2016-02-20 12:16:32 --> Config Class Initialized
INFO - 2016-02-20 12:16:32 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:16:32 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:16:32 --> Utf8 Class Initialized
INFO - 2016-02-20 12:16:32 --> URI Class Initialized
INFO - 2016-02-20 12:16:32 --> Router Class Initialized
INFO - 2016-02-20 12:16:32 --> Output Class Initialized
INFO - 2016-02-20 12:16:32 --> Security Class Initialized
DEBUG - 2016-02-20 12:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:16:32 --> Input Class Initialized
INFO - 2016-02-20 12:16:32 --> Language Class Initialized
INFO - 2016-02-20 12:16:32 --> Loader Class Initialized
INFO - 2016-02-20 12:16:32 --> Helper loaded: url_helper
INFO - 2016-02-20 12:16:32 --> Helper loaded: file_helper
INFO - 2016-02-20 12:16:32 --> Helper loaded: date_helper
INFO - 2016-02-20 12:16:32 --> Helper loaded: form_helper
INFO - 2016-02-20 12:16:32 --> Database Driver Class Initialized
INFO - 2016-02-20 12:16:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:16:33 --> Controller Class Initialized
INFO - 2016-02-20 12:16:33 --> Model Class Initialized
INFO - 2016-02-20 12:16:33 --> Model Class Initialized
INFO - 2016-02-20 12:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:16:33 --> Pagination Class Initialized
INFO - 2016-02-20 12:16:33 --> Helper loaded: text_helper
INFO - 2016-02-20 12:16:33 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:16:33 --> Final output sent to browser
DEBUG - 2016-02-20 15:16:33 --> Total execution time: 1.1204
INFO - 2016-02-20 12:16:45 --> Config Class Initialized
INFO - 2016-02-20 12:16:45 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:16:45 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:16:45 --> Utf8 Class Initialized
INFO - 2016-02-20 12:16:45 --> URI Class Initialized
INFO - 2016-02-20 12:16:45 --> Router Class Initialized
INFO - 2016-02-20 12:16:45 --> Output Class Initialized
INFO - 2016-02-20 12:16:45 --> Security Class Initialized
DEBUG - 2016-02-20 12:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:16:45 --> Input Class Initialized
INFO - 2016-02-20 12:16:45 --> Language Class Initialized
INFO - 2016-02-20 12:16:45 --> Loader Class Initialized
INFO - 2016-02-20 12:16:45 --> Helper loaded: url_helper
INFO - 2016-02-20 12:16:45 --> Helper loaded: file_helper
INFO - 2016-02-20 12:16:45 --> Helper loaded: date_helper
INFO - 2016-02-20 12:16:45 --> Helper loaded: form_helper
INFO - 2016-02-20 12:16:45 --> Database Driver Class Initialized
INFO - 2016-02-20 12:16:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:16:47 --> Controller Class Initialized
INFO - 2016-02-20 12:16:47 --> Model Class Initialized
INFO - 2016-02-20 12:16:47 --> Model Class Initialized
INFO - 2016-02-20 12:16:47 --> Form Validation Class Initialized
INFO - 2016-02-20 12:16:47 --> Helper loaded: text_helper
INFO - 2016-02-20 12:16:47 --> Config Class Initialized
INFO - 2016-02-20 12:16:47 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:16:47 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:16:47 --> Utf8 Class Initialized
INFO - 2016-02-20 12:16:47 --> URI Class Initialized
INFO - 2016-02-20 12:16:47 --> Router Class Initialized
INFO - 2016-02-20 12:16:47 --> Output Class Initialized
INFO - 2016-02-20 12:16:47 --> Security Class Initialized
DEBUG - 2016-02-20 12:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:16:47 --> Input Class Initialized
INFO - 2016-02-20 12:16:47 --> Language Class Initialized
INFO - 2016-02-20 12:16:47 --> Loader Class Initialized
INFO - 2016-02-20 12:16:47 --> Helper loaded: url_helper
INFO - 2016-02-20 12:16:47 --> Helper loaded: file_helper
INFO - 2016-02-20 12:16:47 --> Helper loaded: date_helper
INFO - 2016-02-20 12:16:47 --> Helper loaded: form_helper
INFO - 2016-02-20 12:16:47 --> Database Driver Class Initialized
INFO - 2016-02-20 12:16:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:16:48 --> Controller Class Initialized
INFO - 2016-02-20 12:16:48 --> Model Class Initialized
INFO - 2016-02-20 12:16:48 --> Model Class Initialized
INFO - 2016-02-20 12:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:16:48 --> Pagination Class Initialized
INFO - 2016-02-20 12:16:48 --> Helper loaded: text_helper
INFO - 2016-02-20 12:16:48 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:16:48 --> Final output sent to browser
DEBUG - 2016-02-20 15:16:48 --> Total execution time: 1.1271
INFO - 2016-02-20 12:16:53 --> Config Class Initialized
INFO - 2016-02-20 12:16:53 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:16:53 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:16:53 --> Utf8 Class Initialized
INFO - 2016-02-20 12:16:53 --> URI Class Initialized
INFO - 2016-02-20 12:16:53 --> Router Class Initialized
INFO - 2016-02-20 12:16:53 --> Output Class Initialized
INFO - 2016-02-20 12:16:53 --> Security Class Initialized
DEBUG - 2016-02-20 12:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:16:53 --> Input Class Initialized
INFO - 2016-02-20 12:16:53 --> Language Class Initialized
INFO - 2016-02-20 12:16:53 --> Loader Class Initialized
INFO - 2016-02-20 12:16:53 --> Helper loaded: url_helper
INFO - 2016-02-20 12:16:53 --> Helper loaded: file_helper
INFO - 2016-02-20 12:16:53 --> Helper loaded: date_helper
INFO - 2016-02-20 12:16:53 --> Helper loaded: form_helper
INFO - 2016-02-20 12:16:53 --> Database Driver Class Initialized
INFO - 2016-02-20 12:16:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:16:54 --> Controller Class Initialized
INFO - 2016-02-20 12:16:54 --> Model Class Initialized
INFO - 2016-02-20 12:16:54 --> Model Class Initialized
INFO - 2016-02-20 12:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:16:54 --> Pagination Class Initialized
INFO - 2016-02-20 12:16:54 --> Helper loaded: text_helper
INFO - 2016-02-20 12:16:54 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:16:55 --> Final output sent to browser
DEBUG - 2016-02-20 15:16:55 --> Total execution time: 1.2182
INFO - 2016-02-20 12:16:57 --> Config Class Initialized
INFO - 2016-02-20 12:16:57 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:16:57 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:16:57 --> Utf8 Class Initialized
INFO - 2016-02-20 12:16:57 --> URI Class Initialized
INFO - 2016-02-20 12:16:57 --> Router Class Initialized
INFO - 2016-02-20 12:16:57 --> Output Class Initialized
INFO - 2016-02-20 12:16:57 --> Security Class Initialized
DEBUG - 2016-02-20 12:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:16:57 --> Input Class Initialized
INFO - 2016-02-20 12:16:57 --> Language Class Initialized
INFO - 2016-02-20 12:16:57 --> Loader Class Initialized
INFO - 2016-02-20 12:16:57 --> Helper loaded: url_helper
INFO - 2016-02-20 12:16:57 --> Helper loaded: file_helper
INFO - 2016-02-20 12:16:57 --> Helper loaded: date_helper
INFO - 2016-02-20 12:16:57 --> Helper loaded: form_helper
INFO - 2016-02-20 12:16:57 --> Database Driver Class Initialized
INFO - 2016-02-20 12:16:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:16:58 --> Controller Class Initialized
INFO - 2016-02-20 12:16:58 --> Model Class Initialized
INFO - 2016-02-20 12:16:58 --> Model Class Initialized
INFO - 2016-02-20 12:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:16:58 --> Pagination Class Initialized
INFO - 2016-02-20 12:16:58 --> Helper loaded: text_helper
INFO - 2016-02-20 12:16:58 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:16:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:16:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:16:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:16:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:16:58 --> Final output sent to browser
DEBUG - 2016-02-20 15:16:58 --> Total execution time: 1.1077
INFO - 2016-02-20 12:17:01 --> Config Class Initialized
INFO - 2016-02-20 12:17:01 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:17:01 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:17:01 --> Utf8 Class Initialized
INFO - 2016-02-20 12:17:01 --> URI Class Initialized
INFO - 2016-02-20 12:17:01 --> Router Class Initialized
INFO - 2016-02-20 12:17:01 --> Output Class Initialized
INFO - 2016-02-20 12:17:01 --> Security Class Initialized
DEBUG - 2016-02-20 12:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:17:01 --> Input Class Initialized
INFO - 2016-02-20 12:17:01 --> Language Class Initialized
INFO - 2016-02-20 12:17:01 --> Loader Class Initialized
INFO - 2016-02-20 12:17:01 --> Helper loaded: url_helper
INFO - 2016-02-20 12:17:01 --> Helper loaded: file_helper
INFO - 2016-02-20 12:17:01 --> Helper loaded: date_helper
INFO - 2016-02-20 12:17:01 --> Helper loaded: form_helper
INFO - 2016-02-20 12:17:01 --> Database Driver Class Initialized
INFO - 2016-02-20 12:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:17:02 --> Controller Class Initialized
INFO - 2016-02-20 12:17:02 --> Model Class Initialized
INFO - 2016-02-20 12:17:02 --> Model Class Initialized
INFO - 2016-02-20 12:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:17:02 --> Pagination Class Initialized
INFO - 2016-02-20 12:17:02 --> Helper loaded: text_helper
INFO - 2016-02-20 12:17:02 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:17:02 --> Final output sent to browser
DEBUG - 2016-02-20 15:17:02 --> Total execution time: 1.1787
INFO - 2016-02-20 12:17:05 --> Config Class Initialized
INFO - 2016-02-20 12:17:05 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:17:05 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:17:05 --> Utf8 Class Initialized
INFO - 2016-02-20 12:17:05 --> URI Class Initialized
INFO - 2016-02-20 12:17:05 --> Router Class Initialized
INFO - 2016-02-20 12:17:05 --> Output Class Initialized
INFO - 2016-02-20 12:17:05 --> Security Class Initialized
DEBUG - 2016-02-20 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:17:05 --> Input Class Initialized
INFO - 2016-02-20 12:17:05 --> Language Class Initialized
INFO - 2016-02-20 12:17:05 --> Loader Class Initialized
INFO - 2016-02-20 12:17:05 --> Helper loaded: url_helper
INFO - 2016-02-20 12:17:05 --> Helper loaded: file_helper
INFO - 2016-02-20 12:17:05 --> Helper loaded: date_helper
INFO - 2016-02-20 12:17:05 --> Helper loaded: form_helper
INFO - 2016-02-20 12:17:05 --> Database Driver Class Initialized
INFO - 2016-02-20 12:17:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:17:06 --> Controller Class Initialized
INFO - 2016-02-20 12:17:06 --> Model Class Initialized
INFO - 2016-02-20 12:17:06 --> Model Class Initialized
INFO - 2016-02-20 12:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:17:06 --> Pagination Class Initialized
INFO - 2016-02-20 12:17:06 --> Helper loaded: text_helper
INFO - 2016-02-20 12:17:06 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:17:06 --> Final output sent to browser
DEBUG - 2016-02-20 15:17:06 --> Total execution time: 1.1935
INFO - 2016-02-20 12:17:06 --> Config Class Initialized
INFO - 2016-02-20 12:17:06 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:17:06 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:17:06 --> Utf8 Class Initialized
INFO - 2016-02-20 12:17:06 --> URI Class Initialized
INFO - 2016-02-20 12:17:06 --> Router Class Initialized
INFO - 2016-02-20 12:17:06 --> Output Class Initialized
INFO - 2016-02-20 12:17:06 --> Security Class Initialized
DEBUG - 2016-02-20 12:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:17:06 --> Input Class Initialized
INFO - 2016-02-20 12:17:06 --> Language Class Initialized
ERROR - 2016-02-20 12:17:06 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:17:12 --> Config Class Initialized
INFO - 2016-02-20 12:17:12 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:17:12 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:17:12 --> Utf8 Class Initialized
INFO - 2016-02-20 12:17:12 --> URI Class Initialized
INFO - 2016-02-20 12:17:12 --> Router Class Initialized
INFO - 2016-02-20 12:17:12 --> Output Class Initialized
INFO - 2016-02-20 12:17:12 --> Security Class Initialized
DEBUG - 2016-02-20 12:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:17:12 --> Input Class Initialized
INFO - 2016-02-20 12:17:12 --> Language Class Initialized
INFO - 2016-02-20 12:17:12 --> Loader Class Initialized
INFO - 2016-02-20 12:17:12 --> Helper loaded: url_helper
INFO - 2016-02-20 12:17:12 --> Helper loaded: file_helper
INFO - 2016-02-20 12:17:12 --> Helper loaded: date_helper
INFO - 2016-02-20 12:17:12 --> Helper loaded: form_helper
INFO - 2016-02-20 12:17:12 --> Database Driver Class Initialized
INFO - 2016-02-20 12:17:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:17:13 --> Controller Class Initialized
INFO - 2016-02-20 12:17:13 --> Model Class Initialized
INFO - 2016-02-20 12:17:13 --> Model Class Initialized
INFO - 2016-02-20 12:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:17:13 --> Pagination Class Initialized
INFO - 2016-02-20 12:17:13 --> Helper loaded: text_helper
INFO - 2016-02-20 12:17:13 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:17:13 --> Final output sent to browser
DEBUG - 2016-02-20 15:17:13 --> Total execution time: 1.1725
INFO - 2016-02-20 12:17:14 --> Config Class Initialized
INFO - 2016-02-20 12:17:14 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:17:14 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:17:14 --> Utf8 Class Initialized
INFO - 2016-02-20 12:17:14 --> URI Class Initialized
INFO - 2016-02-20 12:17:14 --> Router Class Initialized
INFO - 2016-02-20 12:17:14 --> Output Class Initialized
INFO - 2016-02-20 12:17:14 --> Security Class Initialized
DEBUG - 2016-02-20 12:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:17:14 --> Input Class Initialized
INFO - 2016-02-20 12:17:14 --> Language Class Initialized
ERROR - 2016-02-20 12:17:14 --> 404 Page Not Found: Static/lib
INFO - 2016-02-20 12:22:24 --> Config Class Initialized
INFO - 2016-02-20 12:22:24 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:22:24 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:22:24 --> Utf8 Class Initialized
INFO - 2016-02-20 12:22:24 --> URI Class Initialized
INFO - 2016-02-20 12:22:24 --> Router Class Initialized
INFO - 2016-02-20 12:22:24 --> Output Class Initialized
INFO - 2016-02-20 12:22:24 --> Security Class Initialized
DEBUG - 2016-02-20 12:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:22:24 --> Input Class Initialized
INFO - 2016-02-20 12:22:24 --> Language Class Initialized
INFO - 2016-02-20 12:22:24 --> Loader Class Initialized
INFO - 2016-02-20 12:22:24 --> Helper loaded: url_helper
INFO - 2016-02-20 12:22:24 --> Helper loaded: file_helper
INFO - 2016-02-20 12:22:24 --> Helper loaded: date_helper
INFO - 2016-02-20 12:22:24 --> Helper loaded: form_helper
INFO - 2016-02-20 12:22:24 --> Database Driver Class Initialized
INFO - 2016-02-20 12:22:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:22:25 --> Controller Class Initialized
INFO - 2016-02-20 12:22:25 --> Model Class Initialized
INFO - 2016-02-20 12:22:25 --> Model Class Initialized
INFO - 2016-02-20 12:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:22:25 --> Pagination Class Initialized
INFO - 2016-02-20 12:22:25 --> Helper loaded: text_helper
INFO - 2016-02-20 12:22:25 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:22:25 --> Final output sent to browser
DEBUG - 2016-02-20 15:22:25 --> Total execution time: 1.1180
INFO - 2016-02-20 12:22:28 --> Config Class Initialized
INFO - 2016-02-20 12:22:28 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:22:28 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:22:28 --> Utf8 Class Initialized
INFO - 2016-02-20 12:22:28 --> URI Class Initialized
INFO - 2016-02-20 12:22:28 --> Router Class Initialized
INFO - 2016-02-20 12:22:28 --> Output Class Initialized
INFO - 2016-02-20 12:22:28 --> Security Class Initialized
DEBUG - 2016-02-20 12:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:22:28 --> Input Class Initialized
INFO - 2016-02-20 12:22:28 --> Language Class Initialized
INFO - 2016-02-20 12:22:28 --> Loader Class Initialized
INFO - 2016-02-20 12:22:28 --> Helper loaded: url_helper
INFO - 2016-02-20 12:22:28 --> Helper loaded: file_helper
INFO - 2016-02-20 12:22:28 --> Helper loaded: date_helper
INFO - 2016-02-20 12:22:28 --> Helper loaded: form_helper
INFO - 2016-02-20 12:22:28 --> Database Driver Class Initialized
INFO - 2016-02-20 12:22:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:22:29 --> Controller Class Initialized
INFO - 2016-02-20 12:22:29 --> Model Class Initialized
INFO - 2016-02-20 12:22:30 --> Model Class Initialized
INFO - 2016-02-20 12:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:22:30 --> Pagination Class Initialized
INFO - 2016-02-20 12:22:30 --> Helper loaded: text_helper
INFO - 2016-02-20 12:22:30 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:22:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:22:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:22:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:22:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:22:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:22:30 --> Final output sent to browser
DEBUG - 2016-02-20 15:22:30 --> Total execution time: 1.1807
INFO - 2016-02-20 12:22:31 --> Config Class Initialized
INFO - 2016-02-20 12:22:31 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:22:31 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:22:31 --> Utf8 Class Initialized
INFO - 2016-02-20 12:22:31 --> URI Class Initialized
INFO - 2016-02-20 12:22:31 --> Router Class Initialized
INFO - 2016-02-20 12:22:31 --> Output Class Initialized
INFO - 2016-02-20 12:22:31 --> Security Class Initialized
DEBUG - 2016-02-20 12:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:22:31 --> Input Class Initialized
INFO - 2016-02-20 12:22:31 --> Language Class Initialized
INFO - 2016-02-20 12:22:31 --> Loader Class Initialized
INFO - 2016-02-20 12:22:32 --> Helper loaded: url_helper
INFO - 2016-02-20 12:22:32 --> Helper loaded: file_helper
INFO - 2016-02-20 12:22:32 --> Helper loaded: date_helper
INFO - 2016-02-20 12:22:32 --> Helper loaded: form_helper
INFO - 2016-02-20 12:22:32 --> Database Driver Class Initialized
INFO - 2016-02-20 12:22:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:22:33 --> Controller Class Initialized
INFO - 2016-02-20 12:22:33 --> Model Class Initialized
INFO - 2016-02-20 12:22:33 --> Model Class Initialized
INFO - 2016-02-20 12:22:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:22:33 --> Pagination Class Initialized
INFO - 2016-02-20 12:22:33 --> Helper loaded: text_helper
INFO - 2016-02-20 12:22:33 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:22:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:22:33 --> Final output sent to browser
DEBUG - 2016-02-20 15:22:33 --> Total execution time: 1.1868
INFO - 2016-02-20 12:24:00 --> Config Class Initialized
INFO - 2016-02-20 12:24:00 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:24:00 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:24:00 --> Utf8 Class Initialized
INFO - 2016-02-20 12:24:00 --> URI Class Initialized
INFO - 2016-02-20 12:24:00 --> Router Class Initialized
INFO - 2016-02-20 12:24:00 --> Output Class Initialized
INFO - 2016-02-20 12:24:00 --> Security Class Initialized
DEBUG - 2016-02-20 12:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:24:00 --> Input Class Initialized
INFO - 2016-02-20 12:24:00 --> Language Class Initialized
INFO - 2016-02-20 12:24:00 --> Loader Class Initialized
INFO - 2016-02-20 12:24:00 --> Helper loaded: url_helper
INFO - 2016-02-20 12:24:00 --> Helper loaded: file_helper
INFO - 2016-02-20 12:24:00 --> Helper loaded: date_helper
INFO - 2016-02-20 12:24:00 --> Helper loaded: form_helper
INFO - 2016-02-20 12:24:00 --> Database Driver Class Initialized
INFO - 2016-02-20 12:24:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:24:01 --> Controller Class Initialized
INFO - 2016-02-20 12:24:01 --> Model Class Initialized
INFO - 2016-02-20 12:24:01 --> Model Class Initialized
INFO - 2016-02-20 12:24:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:24:01 --> Pagination Class Initialized
INFO - 2016-02-20 12:24:01 --> Helper loaded: text_helper
INFO - 2016-02-20 12:24:01 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:24:01 --> Final output sent to browser
DEBUG - 2016-02-20 15:24:01 --> Total execution time: 1.1747
INFO - 2016-02-20 12:24:18 --> Config Class Initialized
INFO - 2016-02-20 12:24:18 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:24:18 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:24:18 --> Utf8 Class Initialized
INFO - 2016-02-20 12:24:18 --> URI Class Initialized
INFO - 2016-02-20 12:24:18 --> Router Class Initialized
INFO - 2016-02-20 12:24:18 --> Output Class Initialized
INFO - 2016-02-20 12:24:18 --> Security Class Initialized
DEBUG - 2016-02-20 12:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:24:18 --> Input Class Initialized
INFO - 2016-02-20 12:24:18 --> Language Class Initialized
INFO - 2016-02-20 12:24:18 --> Loader Class Initialized
INFO - 2016-02-20 12:24:18 --> Helper loaded: url_helper
INFO - 2016-02-20 12:24:18 --> Helper loaded: file_helper
INFO - 2016-02-20 12:24:18 --> Helper loaded: date_helper
INFO - 2016-02-20 12:24:18 --> Helper loaded: form_helper
INFO - 2016-02-20 12:24:18 --> Database Driver Class Initialized
INFO - 2016-02-20 12:24:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:24:19 --> Controller Class Initialized
INFO - 2016-02-20 12:24:19 --> Model Class Initialized
INFO - 2016-02-20 12:24:19 --> Model Class Initialized
INFO - 2016-02-20 12:24:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:24:19 --> Pagination Class Initialized
INFO - 2016-02-20 12:24:19 --> Helper loaded: text_helper
INFO - 2016-02-20 12:24:19 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:24:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:24:19 --> Final output sent to browser
DEBUG - 2016-02-20 15:24:19 --> Total execution time: 1.1874
INFO - 2016-02-20 12:24:21 --> Config Class Initialized
INFO - 2016-02-20 12:24:21 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:24:21 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:24:21 --> Utf8 Class Initialized
INFO - 2016-02-20 12:24:21 --> URI Class Initialized
INFO - 2016-02-20 12:24:21 --> Router Class Initialized
INFO - 2016-02-20 12:24:21 --> Output Class Initialized
INFO - 2016-02-20 12:24:21 --> Security Class Initialized
DEBUG - 2016-02-20 12:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:24:21 --> Input Class Initialized
INFO - 2016-02-20 12:24:21 --> Language Class Initialized
INFO - 2016-02-20 12:24:21 --> Loader Class Initialized
INFO - 2016-02-20 12:24:21 --> Helper loaded: url_helper
INFO - 2016-02-20 12:24:21 --> Helper loaded: file_helper
INFO - 2016-02-20 12:24:21 --> Helper loaded: date_helper
INFO - 2016-02-20 12:24:21 --> Helper loaded: form_helper
INFO - 2016-02-20 12:24:21 --> Database Driver Class Initialized
INFO - 2016-02-20 12:24:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:24:22 --> Controller Class Initialized
INFO - 2016-02-20 12:24:22 --> Model Class Initialized
INFO - 2016-02-20 12:24:23 --> Model Class Initialized
INFO - 2016-02-20 12:24:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:24:23 --> Pagination Class Initialized
INFO - 2016-02-20 12:24:23 --> Helper loaded: text_helper
INFO - 2016-02-20 12:24:23 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:24:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:24:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:24:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:24:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:24:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:24:23 --> Final output sent to browser
DEBUG - 2016-02-20 15:24:23 --> Total execution time: 1.1556
INFO - 2016-02-20 12:25:28 --> Config Class Initialized
INFO - 2016-02-20 12:25:28 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:25:28 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:25:28 --> Utf8 Class Initialized
INFO - 2016-02-20 12:25:28 --> URI Class Initialized
INFO - 2016-02-20 12:25:28 --> Router Class Initialized
INFO - 2016-02-20 12:25:28 --> Output Class Initialized
INFO - 2016-02-20 12:25:28 --> Security Class Initialized
DEBUG - 2016-02-20 12:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:25:28 --> Input Class Initialized
INFO - 2016-02-20 12:25:28 --> Language Class Initialized
INFO - 2016-02-20 12:25:28 --> Loader Class Initialized
INFO - 2016-02-20 12:25:28 --> Helper loaded: url_helper
INFO - 2016-02-20 12:25:28 --> Helper loaded: file_helper
INFO - 2016-02-20 12:25:28 --> Helper loaded: date_helper
INFO - 2016-02-20 12:25:28 --> Helper loaded: form_helper
INFO - 2016-02-20 12:25:28 --> Database Driver Class Initialized
INFO - 2016-02-20 12:25:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:25:29 --> Controller Class Initialized
INFO - 2016-02-20 12:25:29 --> Model Class Initialized
INFO - 2016-02-20 12:25:29 --> Model Class Initialized
INFO - 2016-02-20 12:25:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:25:29 --> Pagination Class Initialized
INFO - 2016-02-20 12:25:29 --> Helper loaded: text_helper
INFO - 2016-02-20 12:25:29 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 15:25:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-20 15:25:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-20 15:25:29 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-20 15:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:25:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:25:29 --> Final output sent to browser
DEBUG - 2016-02-20 15:25:29 --> Total execution time: 1.1698
INFO - 2016-02-20 12:26:02 --> Config Class Initialized
INFO - 2016-02-20 12:26:02 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:26:02 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:26:02 --> Utf8 Class Initialized
INFO - 2016-02-20 12:26:02 --> URI Class Initialized
INFO - 2016-02-20 12:26:02 --> Router Class Initialized
INFO - 2016-02-20 12:26:02 --> Output Class Initialized
INFO - 2016-02-20 12:26:02 --> Security Class Initialized
DEBUG - 2016-02-20 12:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:26:02 --> Input Class Initialized
INFO - 2016-02-20 12:26:02 --> Language Class Initialized
INFO - 2016-02-20 12:26:02 --> Loader Class Initialized
INFO - 2016-02-20 12:26:02 --> Helper loaded: url_helper
INFO - 2016-02-20 12:26:02 --> Helper loaded: file_helper
INFO - 2016-02-20 12:26:02 --> Helper loaded: date_helper
INFO - 2016-02-20 12:26:02 --> Helper loaded: form_helper
INFO - 2016-02-20 12:26:02 --> Database Driver Class Initialized
INFO - 2016-02-20 12:26:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:26:03 --> Controller Class Initialized
INFO - 2016-02-20 12:26:03 --> Model Class Initialized
INFO - 2016-02-20 12:26:03 --> Model Class Initialized
INFO - 2016-02-20 12:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:26:03 --> Pagination Class Initialized
INFO - 2016-02-20 12:26:03 --> Helper loaded: text_helper
INFO - 2016-02-20 12:26:03 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 15:26:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-20 15:26:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-20 15:26:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-20 15:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:26:03 --> Final output sent to browser
DEBUG - 2016-02-20 15:26:03 --> Total execution time: 1.1545
INFO - 2016-02-20 12:32:52 --> Config Class Initialized
INFO - 2016-02-20 12:32:52 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:32:52 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:32:52 --> Utf8 Class Initialized
INFO - 2016-02-20 12:32:52 --> URI Class Initialized
INFO - 2016-02-20 12:32:52 --> Router Class Initialized
INFO - 2016-02-20 12:32:52 --> Output Class Initialized
INFO - 2016-02-20 12:32:52 --> Security Class Initialized
DEBUG - 2016-02-20 12:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:32:52 --> Input Class Initialized
INFO - 2016-02-20 12:32:52 --> Language Class Initialized
INFO - 2016-02-20 12:32:52 --> Loader Class Initialized
INFO - 2016-02-20 12:32:52 --> Helper loaded: url_helper
INFO - 2016-02-20 12:32:52 --> Helper loaded: file_helper
INFO - 2016-02-20 12:32:52 --> Helper loaded: date_helper
INFO - 2016-02-20 12:32:52 --> Helper loaded: form_helper
INFO - 2016-02-20 12:32:52 --> Database Driver Class Initialized
INFO - 2016-02-20 12:32:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:32:53 --> Controller Class Initialized
INFO - 2016-02-20 12:32:53 --> Model Class Initialized
INFO - 2016-02-20 12:32:53 --> Model Class Initialized
INFO - 2016-02-20 12:32:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:32:53 --> Pagination Class Initialized
INFO - 2016-02-20 12:32:53 --> Helper loaded: text_helper
INFO - 2016-02-20 12:32:53 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:32:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:32:53 --> Final output sent to browser
DEBUG - 2016-02-20 15:32:53 --> Total execution time: 1.1827
INFO - 2016-02-20 12:32:57 --> Config Class Initialized
INFO - 2016-02-20 12:32:57 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:32:57 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:32:57 --> Utf8 Class Initialized
INFO - 2016-02-20 12:32:57 --> URI Class Initialized
INFO - 2016-02-20 12:32:57 --> Router Class Initialized
INFO - 2016-02-20 12:32:57 --> Output Class Initialized
INFO - 2016-02-20 12:32:57 --> Security Class Initialized
DEBUG - 2016-02-20 12:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:32:57 --> Input Class Initialized
INFO - 2016-02-20 12:32:57 --> Language Class Initialized
INFO - 2016-02-20 12:32:57 --> Loader Class Initialized
INFO - 2016-02-20 12:32:57 --> Helper loaded: url_helper
INFO - 2016-02-20 12:32:57 --> Helper loaded: file_helper
INFO - 2016-02-20 12:32:57 --> Helper loaded: date_helper
INFO - 2016-02-20 12:32:57 --> Helper loaded: form_helper
INFO - 2016-02-20 12:32:57 --> Database Driver Class Initialized
INFO - 2016-02-20 12:32:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:32:58 --> Controller Class Initialized
INFO - 2016-02-20 12:32:58 --> Model Class Initialized
INFO - 2016-02-20 12:32:58 --> Model Class Initialized
INFO - 2016-02-20 12:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:32:59 --> Pagination Class Initialized
INFO - 2016-02-20 12:32:59 --> Helper loaded: text_helper
INFO - 2016-02-20 12:32:59 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:32:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:32:59 --> Final output sent to browser
DEBUG - 2016-02-20 15:32:59 --> Total execution time: 1.2326
INFO - 2016-02-20 12:33:04 --> Config Class Initialized
INFO - 2016-02-20 12:33:04 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:33:04 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:33:04 --> Utf8 Class Initialized
INFO - 2016-02-20 12:33:04 --> URI Class Initialized
INFO - 2016-02-20 12:33:04 --> Router Class Initialized
INFO - 2016-02-20 12:33:04 --> Output Class Initialized
INFO - 2016-02-20 12:33:04 --> Security Class Initialized
DEBUG - 2016-02-20 12:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:33:04 --> Input Class Initialized
INFO - 2016-02-20 12:33:04 --> Language Class Initialized
INFO - 2016-02-20 12:33:04 --> Loader Class Initialized
INFO - 2016-02-20 12:33:04 --> Helper loaded: url_helper
INFO - 2016-02-20 12:33:04 --> Helper loaded: file_helper
INFO - 2016-02-20 12:33:04 --> Helper loaded: date_helper
INFO - 2016-02-20 12:33:04 --> Helper loaded: form_helper
INFO - 2016-02-20 12:33:04 --> Database Driver Class Initialized
INFO - 2016-02-20 12:33:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:33:05 --> Controller Class Initialized
INFO - 2016-02-20 12:33:05 --> Model Class Initialized
INFO - 2016-02-20 12:33:05 --> Model Class Initialized
INFO - 2016-02-20 12:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:33:05 --> Pagination Class Initialized
INFO - 2016-02-20 12:33:05 --> Helper loaded: text_helper
INFO - 2016-02-20 12:33:05 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:33:06 --> Final output sent to browser
DEBUG - 2016-02-20 15:33:06 --> Total execution time: 1.2311
INFO - 2016-02-20 12:33:30 --> Config Class Initialized
INFO - 2016-02-20 12:33:30 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:33:30 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:33:30 --> Utf8 Class Initialized
INFO - 2016-02-20 12:33:30 --> URI Class Initialized
INFO - 2016-02-20 12:33:30 --> Router Class Initialized
INFO - 2016-02-20 12:33:30 --> Output Class Initialized
INFO - 2016-02-20 12:33:30 --> Security Class Initialized
DEBUG - 2016-02-20 12:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:33:30 --> Input Class Initialized
INFO - 2016-02-20 12:33:30 --> Language Class Initialized
INFO - 2016-02-20 12:33:30 --> Loader Class Initialized
INFO - 2016-02-20 12:33:30 --> Helper loaded: url_helper
INFO - 2016-02-20 12:33:30 --> Helper loaded: file_helper
INFO - 2016-02-20 12:33:30 --> Helper loaded: date_helper
INFO - 2016-02-20 12:33:30 --> Helper loaded: form_helper
INFO - 2016-02-20 12:33:30 --> Database Driver Class Initialized
INFO - 2016-02-20 12:33:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:33:31 --> Controller Class Initialized
INFO - 2016-02-20 12:33:31 --> Model Class Initialized
INFO - 2016-02-20 12:33:31 --> Model Class Initialized
INFO - 2016-02-20 12:33:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:33:31 --> Pagination Class Initialized
INFO - 2016-02-20 12:33:31 --> Helper loaded: text_helper
INFO - 2016-02-20 12:33:31 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:33:31 --> Final output sent to browser
DEBUG - 2016-02-20 15:33:31 --> Total execution time: 1.1502
INFO - 2016-02-20 12:49:45 --> Config Class Initialized
INFO - 2016-02-20 12:49:45 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:49:45 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:49:45 --> Utf8 Class Initialized
INFO - 2016-02-20 12:49:45 --> URI Class Initialized
INFO - 2016-02-20 12:49:45 --> Router Class Initialized
INFO - 2016-02-20 12:49:45 --> Output Class Initialized
INFO - 2016-02-20 12:49:45 --> Security Class Initialized
DEBUG - 2016-02-20 12:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:49:45 --> Input Class Initialized
INFO - 2016-02-20 12:49:45 --> Language Class Initialized
INFO - 2016-02-20 12:49:45 --> Loader Class Initialized
INFO - 2016-02-20 12:49:45 --> Helper loaded: url_helper
INFO - 2016-02-20 12:49:45 --> Helper loaded: file_helper
INFO - 2016-02-20 12:49:45 --> Helper loaded: date_helper
INFO - 2016-02-20 12:49:45 --> Helper loaded: form_helper
INFO - 2016-02-20 12:49:45 --> Database Driver Class Initialized
INFO - 2016-02-20 12:49:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:49:46 --> Controller Class Initialized
INFO - 2016-02-20 12:49:46 --> Model Class Initialized
INFO - 2016-02-20 12:49:46 --> Model Class Initialized
INFO - 2016-02-20 12:49:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:49:46 --> Pagination Class Initialized
INFO - 2016-02-20 12:49:46 --> Helper loaded: text_helper
INFO - 2016-02-20 12:49:46 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:49:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:49:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 15:49:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-20 15:49:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-20 15:49:46 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-20 15:49:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:49:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:49:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:49:46 --> Final output sent to browser
DEBUG - 2016-02-20 15:49:46 --> Total execution time: 1.1431
INFO - 2016-02-20 12:51:25 --> Config Class Initialized
INFO - 2016-02-20 12:51:25 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:51:25 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:51:25 --> Utf8 Class Initialized
INFO - 2016-02-20 12:51:25 --> URI Class Initialized
INFO - 2016-02-20 12:51:25 --> Router Class Initialized
INFO - 2016-02-20 12:51:25 --> Output Class Initialized
INFO - 2016-02-20 12:51:25 --> Security Class Initialized
DEBUG - 2016-02-20 12:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:51:25 --> Input Class Initialized
INFO - 2016-02-20 12:51:25 --> Language Class Initialized
INFO - 2016-02-20 12:51:25 --> Loader Class Initialized
INFO - 2016-02-20 12:51:25 --> Helper loaded: url_helper
INFO - 2016-02-20 12:51:25 --> Helper loaded: file_helper
INFO - 2016-02-20 12:51:25 --> Helper loaded: date_helper
INFO - 2016-02-20 12:51:25 --> Helper loaded: form_helper
INFO - 2016-02-20 12:51:25 --> Database Driver Class Initialized
INFO - 2016-02-20 12:51:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:51:26 --> Controller Class Initialized
INFO - 2016-02-20 12:51:26 --> Model Class Initialized
INFO - 2016-02-20 12:51:26 --> Model Class Initialized
INFO - 2016-02-20 12:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:51:26 --> Pagination Class Initialized
INFO - 2016-02-20 12:51:26 --> Helper loaded: text_helper
INFO - 2016-02-20 12:51:26 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:51:26 --> Final output sent to browser
DEBUG - 2016-02-20 15:51:26 --> Total execution time: 1.1372
INFO - 2016-02-20 12:51:29 --> Config Class Initialized
INFO - 2016-02-20 12:51:29 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:51:29 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:51:29 --> Utf8 Class Initialized
INFO - 2016-02-20 12:51:29 --> URI Class Initialized
INFO - 2016-02-20 12:51:29 --> Router Class Initialized
INFO - 2016-02-20 12:51:29 --> Output Class Initialized
INFO - 2016-02-20 12:51:29 --> Security Class Initialized
DEBUG - 2016-02-20 12:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:51:29 --> Input Class Initialized
INFO - 2016-02-20 12:51:29 --> Language Class Initialized
INFO - 2016-02-20 12:51:29 --> Loader Class Initialized
INFO - 2016-02-20 12:51:29 --> Helper loaded: url_helper
INFO - 2016-02-20 12:51:29 --> Helper loaded: file_helper
INFO - 2016-02-20 12:51:29 --> Helper loaded: date_helper
INFO - 2016-02-20 12:51:29 --> Helper loaded: form_helper
INFO - 2016-02-20 12:51:29 --> Database Driver Class Initialized
INFO - 2016-02-20 12:51:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:51:30 --> Controller Class Initialized
INFO - 2016-02-20 12:51:30 --> Model Class Initialized
INFO - 2016-02-20 12:51:30 --> Model Class Initialized
INFO - 2016-02-20 12:51:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:51:30 --> Pagination Class Initialized
INFO - 2016-02-20 12:51:30 --> Helper loaded: text_helper
INFO - 2016-02-20 12:51:30 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:51:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:51:30 --> Final output sent to browser
DEBUG - 2016-02-20 15:51:30 --> Total execution time: 1.1917
INFO - 2016-02-20 12:51:31 --> Config Class Initialized
INFO - 2016-02-20 12:51:31 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:51:31 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:51:31 --> Utf8 Class Initialized
INFO - 2016-02-20 12:51:31 --> URI Class Initialized
INFO - 2016-02-20 12:51:31 --> Router Class Initialized
INFO - 2016-02-20 12:51:31 --> Output Class Initialized
INFO - 2016-02-20 12:51:31 --> Security Class Initialized
DEBUG - 2016-02-20 12:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:51:31 --> Input Class Initialized
INFO - 2016-02-20 12:51:31 --> Language Class Initialized
INFO - 2016-02-20 12:51:31 --> Loader Class Initialized
INFO - 2016-02-20 12:51:31 --> Helper loaded: url_helper
INFO - 2016-02-20 12:51:31 --> Helper loaded: file_helper
INFO - 2016-02-20 12:51:31 --> Helper loaded: date_helper
INFO - 2016-02-20 12:51:31 --> Helper loaded: form_helper
INFO - 2016-02-20 12:51:31 --> Database Driver Class Initialized
INFO - 2016-02-20 12:51:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:51:32 --> Controller Class Initialized
INFO - 2016-02-20 12:51:32 --> Model Class Initialized
INFO - 2016-02-20 12:51:32 --> Model Class Initialized
INFO - 2016-02-20 12:51:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:51:32 --> Pagination Class Initialized
INFO - 2016-02-20 12:51:32 --> Helper loaded: text_helper
INFO - 2016-02-20 12:51:32 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:51:32 --> Final output sent to browser
DEBUG - 2016-02-20 15:51:32 --> Total execution time: 1.1511
INFO - 2016-02-20 12:51:50 --> Config Class Initialized
INFO - 2016-02-20 12:51:50 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:51:50 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:51:50 --> Utf8 Class Initialized
INFO - 2016-02-20 12:51:50 --> URI Class Initialized
INFO - 2016-02-20 12:51:50 --> Router Class Initialized
INFO - 2016-02-20 12:51:50 --> Output Class Initialized
INFO - 2016-02-20 12:51:50 --> Security Class Initialized
DEBUG - 2016-02-20 12:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:51:50 --> Input Class Initialized
INFO - 2016-02-20 12:51:50 --> Language Class Initialized
INFO - 2016-02-20 12:51:50 --> Loader Class Initialized
INFO - 2016-02-20 12:51:50 --> Helper loaded: url_helper
INFO - 2016-02-20 12:51:50 --> Helper loaded: file_helper
INFO - 2016-02-20 12:51:50 --> Helper loaded: date_helper
INFO - 2016-02-20 12:51:50 --> Helper loaded: form_helper
INFO - 2016-02-20 12:51:50 --> Database Driver Class Initialized
INFO - 2016-02-20 12:51:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:51:51 --> Controller Class Initialized
INFO - 2016-02-20 12:51:51 --> Model Class Initialized
INFO - 2016-02-20 12:51:51 --> Model Class Initialized
INFO - 2016-02-20 12:51:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:51:51 --> Pagination Class Initialized
INFO - 2016-02-20 12:51:51 --> Helper loaded: text_helper
INFO - 2016-02-20 12:51:51 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:51:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:51:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 15:51:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-20 15:51:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-20 15:51:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-20 15:51:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:51:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:51:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:51:51 --> Final output sent to browser
DEBUG - 2016-02-20 15:51:51 --> Total execution time: 1.1922
INFO - 2016-02-20 12:52:07 --> Config Class Initialized
INFO - 2016-02-20 12:52:07 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:52:07 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:52:07 --> Utf8 Class Initialized
INFO - 2016-02-20 12:52:07 --> URI Class Initialized
INFO - 2016-02-20 12:52:07 --> Router Class Initialized
INFO - 2016-02-20 12:52:07 --> Output Class Initialized
INFO - 2016-02-20 12:52:07 --> Security Class Initialized
DEBUG - 2016-02-20 12:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:52:07 --> Input Class Initialized
INFO - 2016-02-20 12:52:07 --> Language Class Initialized
INFO - 2016-02-20 12:52:07 --> Loader Class Initialized
INFO - 2016-02-20 12:52:07 --> Helper loaded: url_helper
INFO - 2016-02-20 12:52:07 --> Helper loaded: file_helper
INFO - 2016-02-20 12:52:07 --> Helper loaded: date_helper
INFO - 2016-02-20 12:52:07 --> Helper loaded: form_helper
INFO - 2016-02-20 12:52:07 --> Database Driver Class Initialized
INFO - 2016-02-20 12:52:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:52:08 --> Controller Class Initialized
INFO - 2016-02-20 12:52:08 --> Model Class Initialized
INFO - 2016-02-20 12:52:08 --> Model Class Initialized
INFO - 2016-02-20 12:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:52:08 --> Pagination Class Initialized
INFO - 2016-02-20 12:52:08 --> Helper loaded: text_helper
INFO - 2016-02-20 12:52:08 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:52:08 --> Final output sent to browser
DEBUG - 2016-02-20 15:52:08 --> Total execution time: 1.1649
INFO - 2016-02-20 12:52:10 --> Config Class Initialized
INFO - 2016-02-20 12:52:10 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:52:10 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:52:10 --> Utf8 Class Initialized
INFO - 2016-02-20 12:52:10 --> URI Class Initialized
INFO - 2016-02-20 12:52:10 --> Router Class Initialized
INFO - 2016-02-20 12:52:10 --> Output Class Initialized
INFO - 2016-02-20 12:52:10 --> Security Class Initialized
DEBUG - 2016-02-20 12:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:52:10 --> Input Class Initialized
INFO - 2016-02-20 12:52:11 --> Language Class Initialized
INFO - 2016-02-20 12:52:11 --> Loader Class Initialized
INFO - 2016-02-20 12:52:11 --> Helper loaded: url_helper
INFO - 2016-02-20 12:52:11 --> Helper loaded: file_helper
INFO - 2016-02-20 12:52:11 --> Helper loaded: date_helper
INFO - 2016-02-20 12:52:11 --> Helper loaded: form_helper
INFO - 2016-02-20 12:52:11 --> Database Driver Class Initialized
INFO - 2016-02-20 12:52:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:52:12 --> Controller Class Initialized
INFO - 2016-02-20 12:52:12 --> Model Class Initialized
INFO - 2016-02-20 12:52:12 --> Model Class Initialized
INFO - 2016-02-20 12:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:52:12 --> Pagination Class Initialized
INFO - 2016-02-20 12:52:12 --> Helper loaded: text_helper
INFO - 2016-02-20 12:52:12 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:52:12 --> Final output sent to browser
DEBUG - 2016-02-20 15:52:12 --> Total execution time: 1.1680
INFO - 2016-02-20 12:52:14 --> Config Class Initialized
INFO - 2016-02-20 12:52:14 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:52:14 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:52:14 --> Utf8 Class Initialized
INFO - 2016-02-20 12:52:14 --> URI Class Initialized
INFO - 2016-02-20 12:52:14 --> Router Class Initialized
INFO - 2016-02-20 12:52:14 --> Output Class Initialized
INFO - 2016-02-20 12:52:14 --> Security Class Initialized
DEBUG - 2016-02-20 12:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:52:14 --> Input Class Initialized
INFO - 2016-02-20 12:52:14 --> Language Class Initialized
INFO - 2016-02-20 12:52:14 --> Loader Class Initialized
INFO - 2016-02-20 12:52:14 --> Helper loaded: url_helper
INFO - 2016-02-20 12:52:14 --> Helper loaded: file_helper
INFO - 2016-02-20 12:52:14 --> Helper loaded: date_helper
INFO - 2016-02-20 12:52:14 --> Helper loaded: form_helper
INFO - 2016-02-20 12:52:14 --> Database Driver Class Initialized
INFO - 2016-02-20 12:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:52:15 --> Controller Class Initialized
INFO - 2016-02-20 12:52:15 --> Model Class Initialized
INFO - 2016-02-20 12:52:15 --> Model Class Initialized
INFO - 2016-02-20 12:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:52:15 --> Pagination Class Initialized
INFO - 2016-02-20 12:52:15 --> Helper loaded: text_helper
INFO - 2016-02-20 12:52:15 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:52:15 --> Final output sent to browser
DEBUG - 2016-02-20 15:52:15 --> Total execution time: 1.1538
INFO - 2016-02-20 12:52:36 --> Config Class Initialized
INFO - 2016-02-20 12:52:36 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:52:36 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:52:36 --> Utf8 Class Initialized
INFO - 2016-02-20 12:52:36 --> URI Class Initialized
INFO - 2016-02-20 12:52:36 --> Router Class Initialized
INFO - 2016-02-20 12:52:36 --> Output Class Initialized
INFO - 2016-02-20 12:52:36 --> Security Class Initialized
DEBUG - 2016-02-20 12:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:52:36 --> Input Class Initialized
INFO - 2016-02-20 12:52:36 --> Language Class Initialized
INFO - 2016-02-20 12:52:36 --> Loader Class Initialized
INFO - 2016-02-20 12:52:36 --> Helper loaded: url_helper
INFO - 2016-02-20 12:52:36 --> Helper loaded: file_helper
INFO - 2016-02-20 12:52:36 --> Helper loaded: date_helper
INFO - 2016-02-20 12:52:36 --> Helper loaded: form_helper
INFO - 2016-02-20 12:52:36 --> Database Driver Class Initialized
INFO - 2016-02-20 12:52:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:52:37 --> Controller Class Initialized
INFO - 2016-02-20 12:52:37 --> Model Class Initialized
INFO - 2016-02-20 12:52:37 --> Model Class Initialized
INFO - 2016-02-20 12:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:52:37 --> Pagination Class Initialized
INFO - 2016-02-20 12:52:37 --> Helper loaded: text_helper
INFO - 2016-02-20 12:52:37 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:52:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:52:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 15:52:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-20 15:52:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-20 15:52:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-20 15:52:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:52:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:52:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:52:37 --> Final output sent to browser
DEBUG - 2016-02-20 15:52:37 --> Total execution time: 1.1570
INFO - 2016-02-20 12:54:14 --> Config Class Initialized
INFO - 2016-02-20 12:54:14 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:54:14 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:54:14 --> Utf8 Class Initialized
INFO - 2016-02-20 12:54:14 --> URI Class Initialized
INFO - 2016-02-20 12:54:14 --> Router Class Initialized
INFO - 2016-02-20 12:54:14 --> Output Class Initialized
INFO - 2016-02-20 12:54:14 --> Security Class Initialized
DEBUG - 2016-02-20 12:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:54:14 --> Input Class Initialized
INFO - 2016-02-20 12:54:14 --> Language Class Initialized
INFO - 2016-02-20 12:54:14 --> Loader Class Initialized
INFO - 2016-02-20 12:54:14 --> Helper loaded: url_helper
INFO - 2016-02-20 12:54:14 --> Helper loaded: file_helper
INFO - 2016-02-20 12:54:14 --> Helper loaded: date_helper
INFO - 2016-02-20 12:54:14 --> Helper loaded: form_helper
INFO - 2016-02-20 12:54:14 --> Database Driver Class Initialized
INFO - 2016-02-20 12:54:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:54:15 --> Controller Class Initialized
INFO - 2016-02-20 12:54:15 --> Model Class Initialized
INFO - 2016-02-20 12:54:15 --> Model Class Initialized
INFO - 2016-02-20 12:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:54:15 --> Pagination Class Initialized
INFO - 2016-02-20 12:54:15 --> Helper loaded: text_helper
INFO - 2016-02-20 12:54:15 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 15:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:54:15 --> Final output sent to browser
DEBUG - 2016-02-20 15:54:15 --> Total execution time: 1.1600
INFO - 2016-02-20 12:54:17 --> Config Class Initialized
INFO - 2016-02-20 12:54:17 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:54:17 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:54:17 --> Utf8 Class Initialized
INFO - 2016-02-20 12:54:17 --> URI Class Initialized
INFO - 2016-02-20 12:54:17 --> Router Class Initialized
INFO - 2016-02-20 12:54:17 --> Output Class Initialized
INFO - 2016-02-20 12:54:17 --> Security Class Initialized
DEBUG - 2016-02-20 12:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:54:17 --> Input Class Initialized
INFO - 2016-02-20 12:54:17 --> Language Class Initialized
INFO - 2016-02-20 12:54:17 --> Loader Class Initialized
INFO - 2016-02-20 12:54:17 --> Helper loaded: url_helper
INFO - 2016-02-20 12:54:17 --> Helper loaded: file_helper
INFO - 2016-02-20 12:54:17 --> Helper loaded: date_helper
INFO - 2016-02-20 12:54:17 --> Helper loaded: form_helper
INFO - 2016-02-20 12:54:17 --> Database Driver Class Initialized
INFO - 2016-02-20 12:54:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:54:18 --> Controller Class Initialized
INFO - 2016-02-20 12:54:18 --> Model Class Initialized
INFO - 2016-02-20 12:54:18 --> Model Class Initialized
INFO - 2016-02-20 12:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:54:18 --> Pagination Class Initialized
INFO - 2016-02-20 12:54:18 --> Helper loaded: text_helper
INFO - 2016-02-20 12:54:18 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:54:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:54:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:54:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 15:54:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:54:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:54:18 --> Final output sent to browser
DEBUG - 2016-02-20 15:54:18 --> Total execution time: 1.1956
INFO - 2016-02-20 12:54:24 --> Config Class Initialized
INFO - 2016-02-20 12:54:24 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:54:24 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:54:24 --> Utf8 Class Initialized
INFO - 2016-02-20 12:54:24 --> URI Class Initialized
INFO - 2016-02-20 12:54:24 --> Router Class Initialized
INFO - 2016-02-20 12:54:24 --> Output Class Initialized
INFO - 2016-02-20 12:54:24 --> Security Class Initialized
DEBUG - 2016-02-20 12:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:54:24 --> Input Class Initialized
INFO - 2016-02-20 12:54:24 --> Language Class Initialized
INFO - 2016-02-20 12:54:24 --> Loader Class Initialized
INFO - 2016-02-20 12:54:24 --> Helper loaded: url_helper
INFO - 2016-02-20 12:54:24 --> Helper loaded: file_helper
INFO - 2016-02-20 12:54:24 --> Helper loaded: date_helper
INFO - 2016-02-20 12:54:24 --> Helper loaded: form_helper
INFO - 2016-02-20 12:54:24 --> Database Driver Class Initialized
INFO - 2016-02-20 12:54:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:54:25 --> Controller Class Initialized
INFO - 2016-02-20 12:54:25 --> Model Class Initialized
INFO - 2016-02-20 12:54:25 --> Model Class Initialized
INFO - 2016-02-20 12:54:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:54:25 --> Pagination Class Initialized
INFO - 2016-02-20 12:54:25 --> Helper loaded: text_helper
INFO - 2016-02-20 12:54:25 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:54:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:54:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 15:54:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:54:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:54:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:54:25 --> Final output sent to browser
DEBUG - 2016-02-20 15:54:25 --> Total execution time: 1.2199
INFO - 2016-02-20 12:54:58 --> Config Class Initialized
INFO - 2016-02-20 12:54:58 --> Hooks Class Initialized
DEBUG - 2016-02-20 12:54:58 --> UTF-8 Support Enabled
INFO - 2016-02-20 12:54:58 --> Utf8 Class Initialized
INFO - 2016-02-20 12:54:58 --> URI Class Initialized
INFO - 2016-02-20 12:54:58 --> Router Class Initialized
INFO - 2016-02-20 12:54:58 --> Output Class Initialized
INFO - 2016-02-20 12:54:58 --> Security Class Initialized
DEBUG - 2016-02-20 12:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 12:54:58 --> Input Class Initialized
INFO - 2016-02-20 12:54:58 --> Language Class Initialized
INFO - 2016-02-20 12:54:58 --> Loader Class Initialized
INFO - 2016-02-20 12:54:58 --> Helper loaded: url_helper
INFO - 2016-02-20 12:54:58 --> Helper loaded: file_helper
INFO - 2016-02-20 12:54:58 --> Helper loaded: date_helper
INFO - 2016-02-20 12:54:58 --> Helper loaded: form_helper
INFO - 2016-02-20 12:54:58 --> Database Driver Class Initialized
INFO - 2016-02-20 12:54:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 12:54:59 --> Controller Class Initialized
INFO - 2016-02-20 12:54:59 --> Model Class Initialized
INFO - 2016-02-20 12:54:59 --> Model Class Initialized
INFO - 2016-02-20 12:54:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 12:54:59 --> Pagination Class Initialized
INFO - 2016-02-20 12:54:59 --> Helper loaded: text_helper
INFO - 2016-02-20 12:54:59 --> Helper loaded: cookie_helper
INFO - 2016-02-20 15:54:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 15:54:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 15:54:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-20 15:54:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-20 15:54:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-20 15:54:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 15:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 15:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 15:55:00 --> Final output sent to browser
DEBUG - 2016-02-20 15:55:00 --> Total execution time: 1.1757
INFO - 2016-02-20 13:04:22 --> Config Class Initialized
INFO - 2016-02-20 13:04:22 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:04:22 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:04:22 --> Utf8 Class Initialized
INFO - 2016-02-20 13:04:22 --> URI Class Initialized
INFO - 2016-02-20 13:04:22 --> Router Class Initialized
INFO - 2016-02-20 13:04:22 --> Output Class Initialized
INFO - 2016-02-20 13:04:22 --> Security Class Initialized
DEBUG - 2016-02-20 13:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:04:22 --> Input Class Initialized
INFO - 2016-02-20 13:04:22 --> Language Class Initialized
INFO - 2016-02-20 13:04:22 --> Loader Class Initialized
INFO - 2016-02-20 13:04:22 --> Helper loaded: url_helper
INFO - 2016-02-20 13:04:22 --> Helper loaded: file_helper
INFO - 2016-02-20 13:04:22 --> Helper loaded: date_helper
INFO - 2016-02-20 13:04:22 --> Helper loaded: form_helper
INFO - 2016-02-20 13:04:22 --> Database Driver Class Initialized
INFO - 2016-02-20 13:04:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:04:23 --> Controller Class Initialized
INFO - 2016-02-20 13:04:23 --> Model Class Initialized
INFO - 2016-02-20 13:04:23 --> Model Class Initialized
INFO - 2016-02-20 13:04:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:04:23 --> Pagination Class Initialized
INFO - 2016-02-20 13:04:23 --> Helper loaded: text_helper
INFO - 2016-02-20 13:04:23 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:04:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:04:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:04:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 16:04:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:04:23 --> Final output sent to browser
DEBUG - 2016-02-20 16:04:23 --> Total execution time: 1.1767
INFO - 2016-02-20 13:04:25 --> Config Class Initialized
INFO - 2016-02-20 13:04:25 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:04:25 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:04:25 --> Utf8 Class Initialized
INFO - 2016-02-20 13:04:25 --> URI Class Initialized
INFO - 2016-02-20 13:04:25 --> Router Class Initialized
INFO - 2016-02-20 13:04:25 --> Output Class Initialized
INFO - 2016-02-20 13:04:25 --> Security Class Initialized
DEBUG - 2016-02-20 13:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:04:25 --> Input Class Initialized
INFO - 2016-02-20 13:04:25 --> Language Class Initialized
INFO - 2016-02-20 13:04:25 --> Loader Class Initialized
INFO - 2016-02-20 13:04:25 --> Helper loaded: url_helper
INFO - 2016-02-20 13:04:25 --> Helper loaded: file_helper
INFO - 2016-02-20 13:04:25 --> Helper loaded: date_helper
INFO - 2016-02-20 13:04:25 --> Helper loaded: form_helper
INFO - 2016-02-20 13:04:25 --> Database Driver Class Initialized
INFO - 2016-02-20 13:04:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:04:27 --> Controller Class Initialized
INFO - 2016-02-20 13:04:27 --> Model Class Initialized
INFO - 2016-02-20 13:04:27 --> Model Class Initialized
INFO - 2016-02-20 13:04:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:04:27 --> Pagination Class Initialized
INFO - 2016-02-20 13:04:27 --> Helper loaded: text_helper
INFO - 2016-02-20 13:04:27 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:04:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:04:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 16:04:27 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 538 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-20 16:04:27 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-20 16:04:27 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-20 16:04:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 13:05:09 --> Config Class Initialized
INFO - 2016-02-20 13:05:09 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:05:09 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:05:09 --> Utf8 Class Initialized
INFO - 2016-02-20 13:05:09 --> URI Class Initialized
INFO - 2016-02-20 13:05:09 --> Router Class Initialized
INFO - 2016-02-20 13:05:09 --> Output Class Initialized
INFO - 2016-02-20 13:05:09 --> Security Class Initialized
DEBUG - 2016-02-20 13:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:05:09 --> Input Class Initialized
INFO - 2016-02-20 13:05:09 --> Language Class Initialized
INFO - 2016-02-20 13:05:09 --> Loader Class Initialized
INFO - 2016-02-20 13:05:09 --> Helper loaded: url_helper
INFO - 2016-02-20 13:05:09 --> Helper loaded: file_helper
INFO - 2016-02-20 13:05:09 --> Helper loaded: date_helper
INFO - 2016-02-20 13:05:09 --> Helper loaded: form_helper
INFO - 2016-02-20 13:05:09 --> Database Driver Class Initialized
INFO - 2016-02-20 13:05:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:05:10 --> Controller Class Initialized
INFO - 2016-02-20 13:05:10 --> Model Class Initialized
INFO - 2016-02-20 13:05:10 --> Model Class Initialized
INFO - 2016-02-20 13:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:05:10 --> Pagination Class Initialized
INFO - 2016-02-20 13:05:10 --> Helper loaded: text_helper
INFO - 2016-02-20 13:05:10 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 16:05:10 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 29
INFO - 2016-02-20 13:05:40 --> Config Class Initialized
INFO - 2016-02-20 13:05:40 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:05:40 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:05:40 --> Utf8 Class Initialized
INFO - 2016-02-20 13:05:40 --> URI Class Initialized
INFO - 2016-02-20 13:05:40 --> Router Class Initialized
INFO - 2016-02-20 13:05:40 --> Output Class Initialized
INFO - 2016-02-20 13:05:40 --> Security Class Initialized
DEBUG - 2016-02-20 13:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:05:40 --> Input Class Initialized
INFO - 2016-02-20 13:05:40 --> Language Class Initialized
INFO - 2016-02-20 13:05:40 --> Loader Class Initialized
INFO - 2016-02-20 13:05:40 --> Helper loaded: url_helper
INFO - 2016-02-20 13:05:40 --> Helper loaded: file_helper
INFO - 2016-02-20 13:05:40 --> Helper loaded: date_helper
INFO - 2016-02-20 13:05:40 --> Helper loaded: form_helper
INFO - 2016-02-20 13:05:40 --> Database Driver Class Initialized
INFO - 2016-02-20 13:05:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:05:41 --> Controller Class Initialized
INFO - 2016-02-20 13:05:41 --> Model Class Initialized
INFO - 2016-02-20 13:05:41 --> Model Class Initialized
INFO - 2016-02-20 13:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:05:41 --> Pagination Class Initialized
INFO - 2016-02-20 13:05:41 --> Helper loaded: text_helper
INFO - 2016-02-20 13:05:41 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 16:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:05:41 --> Final output sent to browser
DEBUG - 2016-02-20 16:05:41 --> Total execution time: 1.1645
INFO - 2016-02-20 13:05:43 --> Config Class Initialized
INFO - 2016-02-20 13:05:43 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:05:43 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:05:43 --> Utf8 Class Initialized
INFO - 2016-02-20 13:05:43 --> URI Class Initialized
INFO - 2016-02-20 13:05:43 --> Router Class Initialized
INFO - 2016-02-20 13:05:43 --> Output Class Initialized
INFO - 2016-02-20 13:05:43 --> Security Class Initialized
DEBUG - 2016-02-20 13:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:05:43 --> Input Class Initialized
INFO - 2016-02-20 13:05:43 --> Language Class Initialized
INFO - 2016-02-20 13:05:43 --> Loader Class Initialized
INFO - 2016-02-20 13:05:43 --> Helper loaded: url_helper
INFO - 2016-02-20 13:05:43 --> Helper loaded: file_helper
INFO - 2016-02-20 13:05:43 --> Helper loaded: date_helper
INFO - 2016-02-20 13:05:43 --> Helper loaded: form_helper
INFO - 2016-02-20 13:05:43 --> Database Driver Class Initialized
INFO - 2016-02-20 13:05:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:05:44 --> Controller Class Initialized
INFO - 2016-02-20 13:05:44 --> Model Class Initialized
INFO - 2016-02-20 13:05:44 --> Model Class Initialized
INFO - 2016-02-20 13:05:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:05:44 --> Pagination Class Initialized
INFO - 2016-02-20 13:05:44 --> Helper loaded: text_helper
INFO - 2016-02-20 13:05:44 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 16:05:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:05:44 --> Final output sent to browser
DEBUG - 2016-02-20 16:05:44 --> Total execution time: 1.1447
INFO - 2016-02-20 13:05:46 --> Config Class Initialized
INFO - 2016-02-20 13:05:46 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:05:46 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:05:46 --> Utf8 Class Initialized
INFO - 2016-02-20 13:05:46 --> URI Class Initialized
INFO - 2016-02-20 13:05:46 --> Router Class Initialized
INFO - 2016-02-20 13:05:46 --> Output Class Initialized
INFO - 2016-02-20 13:05:46 --> Security Class Initialized
DEBUG - 2016-02-20 13:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:05:46 --> Input Class Initialized
INFO - 2016-02-20 13:05:46 --> Language Class Initialized
INFO - 2016-02-20 13:05:46 --> Loader Class Initialized
INFO - 2016-02-20 13:05:46 --> Helper loaded: url_helper
INFO - 2016-02-20 13:05:46 --> Helper loaded: file_helper
INFO - 2016-02-20 13:05:46 --> Helper loaded: date_helper
INFO - 2016-02-20 13:05:46 --> Helper loaded: form_helper
INFO - 2016-02-20 13:05:46 --> Database Driver Class Initialized
INFO - 2016-02-20 13:05:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:05:47 --> Controller Class Initialized
INFO - 2016-02-20 13:05:47 --> Model Class Initialized
INFO - 2016-02-20 13:05:47 --> Model Class Initialized
INFO - 2016-02-20 13:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:05:47 --> Pagination Class Initialized
INFO - 2016-02-20 13:05:47 --> Helper loaded: text_helper
INFO - 2016-02-20 13:05:47 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:05:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:05:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-20 16:05:47 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 538 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-20 16:05:47 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-20 16:05:47 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-20 16:05:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-20 13:07:28 --> Config Class Initialized
INFO - 2016-02-20 13:07:28 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:07:28 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:07:28 --> Utf8 Class Initialized
INFO - 2016-02-20 13:07:28 --> URI Class Initialized
INFO - 2016-02-20 13:07:28 --> Router Class Initialized
INFO - 2016-02-20 13:07:28 --> Output Class Initialized
INFO - 2016-02-20 13:07:28 --> Security Class Initialized
DEBUG - 2016-02-20 13:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:07:28 --> Input Class Initialized
INFO - 2016-02-20 13:07:28 --> Language Class Initialized
INFO - 2016-02-20 13:07:28 --> Loader Class Initialized
INFO - 2016-02-20 13:07:28 --> Helper loaded: url_helper
INFO - 2016-02-20 13:07:28 --> Helper loaded: file_helper
INFO - 2016-02-20 13:07:28 --> Helper loaded: date_helper
INFO - 2016-02-20 13:07:28 --> Helper loaded: form_helper
INFO - 2016-02-20 13:07:28 --> Database Driver Class Initialized
INFO - 2016-02-20 13:07:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:07:29 --> Controller Class Initialized
INFO - 2016-02-20 13:07:29 --> Model Class Initialized
INFO - 2016-02-20 13:07:29 --> Model Class Initialized
INFO - 2016-02-20 13:07:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:07:29 --> Pagination Class Initialized
INFO - 2016-02-20 13:07:29 --> Helper loaded: text_helper
INFO - 2016-02-20 13:07:29 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:07:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:07:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:07:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 16:07:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:07:29 --> Final output sent to browser
DEBUG - 2016-02-20 16:07:29 --> Total execution time: 1.1922
INFO - 2016-02-20 13:07:30 --> Config Class Initialized
INFO - 2016-02-20 13:07:30 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:07:30 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:07:30 --> Utf8 Class Initialized
INFO - 2016-02-20 13:07:30 --> URI Class Initialized
INFO - 2016-02-20 13:07:30 --> Router Class Initialized
INFO - 2016-02-20 13:07:30 --> Output Class Initialized
INFO - 2016-02-20 13:07:30 --> Security Class Initialized
DEBUG - 2016-02-20 13:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:07:30 --> Input Class Initialized
INFO - 2016-02-20 13:07:30 --> Language Class Initialized
INFO - 2016-02-20 13:07:31 --> Loader Class Initialized
INFO - 2016-02-20 13:07:31 --> Helper loaded: url_helper
INFO - 2016-02-20 13:07:31 --> Helper loaded: file_helper
INFO - 2016-02-20 13:07:31 --> Helper loaded: date_helper
INFO - 2016-02-20 13:07:31 --> Helper loaded: form_helper
INFO - 2016-02-20 13:07:31 --> Database Driver Class Initialized
INFO - 2016-02-20 13:07:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:07:32 --> Controller Class Initialized
INFO - 2016-02-20 13:07:32 --> Model Class Initialized
INFO - 2016-02-20 13:07:32 --> Model Class Initialized
INFO - 2016-02-20 13:07:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:07:32 --> Pagination Class Initialized
INFO - 2016-02-20 13:07:32 --> Helper loaded: text_helper
INFO - 2016-02-20 13:07:32 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:07:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:07:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:07:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-20 16:07:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:07:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:07:32 --> Final output sent to browser
DEBUG - 2016-02-20 16:07:32 --> Total execution time: 1.1576
INFO - 2016-02-20 13:07:44 --> Config Class Initialized
INFO - 2016-02-20 13:07:44 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:07:44 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:07:44 --> Utf8 Class Initialized
INFO - 2016-02-20 13:07:44 --> URI Class Initialized
INFO - 2016-02-20 13:07:44 --> Router Class Initialized
INFO - 2016-02-20 13:07:44 --> Output Class Initialized
INFO - 2016-02-20 13:07:44 --> Security Class Initialized
DEBUG - 2016-02-20 13:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:07:44 --> Input Class Initialized
INFO - 2016-02-20 13:07:44 --> Language Class Initialized
INFO - 2016-02-20 13:07:44 --> Loader Class Initialized
INFO - 2016-02-20 13:07:44 --> Helper loaded: url_helper
INFO - 2016-02-20 13:07:44 --> Helper loaded: file_helper
INFO - 2016-02-20 13:07:44 --> Helper loaded: date_helper
INFO - 2016-02-20 13:07:44 --> Helper loaded: form_helper
INFO - 2016-02-20 13:07:44 --> Database Driver Class Initialized
INFO - 2016-02-20 13:07:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:07:45 --> Controller Class Initialized
INFO - 2016-02-20 13:07:45 --> Model Class Initialized
INFO - 2016-02-20 13:07:45 --> Model Class Initialized
INFO - 2016-02-20 13:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:07:45 --> Pagination Class Initialized
INFO - 2016-02-20 13:07:45 --> Helper loaded: text_helper
INFO - 2016-02-20 13:07:45 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:07:45 --> Upload Class Initialized
INFO - 2016-02-20 16:07:45 --> Final output sent to browser
DEBUG - 2016-02-20 16:07:45 --> Total execution time: 1.1254
INFO - 2016-02-20 13:08:49 --> Config Class Initialized
INFO - 2016-02-20 13:08:49 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:08:49 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:08:49 --> Utf8 Class Initialized
INFO - 2016-02-20 13:08:49 --> URI Class Initialized
INFO - 2016-02-20 13:08:49 --> Router Class Initialized
INFO - 2016-02-20 13:08:49 --> Output Class Initialized
INFO - 2016-02-20 13:08:49 --> Security Class Initialized
DEBUG - 2016-02-20 13:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:08:49 --> Input Class Initialized
INFO - 2016-02-20 13:08:49 --> Language Class Initialized
INFO - 2016-02-20 13:08:49 --> Loader Class Initialized
INFO - 2016-02-20 13:08:49 --> Helper loaded: url_helper
INFO - 2016-02-20 13:08:49 --> Helper loaded: file_helper
INFO - 2016-02-20 13:08:49 --> Helper loaded: date_helper
INFO - 2016-02-20 13:08:49 --> Helper loaded: form_helper
INFO - 2016-02-20 13:08:49 --> Database Driver Class Initialized
INFO - 2016-02-20 13:08:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:08:50 --> Controller Class Initialized
INFO - 2016-02-20 13:08:50 --> Model Class Initialized
INFO - 2016-02-20 13:08:50 --> Model Class Initialized
INFO - 2016-02-20 13:08:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:08:50 --> Pagination Class Initialized
INFO - 2016-02-20 13:08:50 --> Helper loaded: text_helper
INFO - 2016-02-20 13:08:50 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 16:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:08:50 --> Final output sent to browser
DEBUG - 2016-02-20 16:08:50 --> Total execution time: 1.1707
INFO - 2016-02-20 13:08:52 --> Config Class Initialized
INFO - 2016-02-20 13:08:52 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:08:52 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:08:52 --> Utf8 Class Initialized
INFO - 2016-02-20 13:08:52 --> URI Class Initialized
INFO - 2016-02-20 13:08:52 --> Router Class Initialized
INFO - 2016-02-20 13:08:52 --> Output Class Initialized
INFO - 2016-02-20 13:08:52 --> Security Class Initialized
DEBUG - 2016-02-20 13:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:08:52 --> Input Class Initialized
INFO - 2016-02-20 13:08:52 --> Language Class Initialized
INFO - 2016-02-20 13:08:52 --> Loader Class Initialized
INFO - 2016-02-20 13:08:52 --> Helper loaded: url_helper
INFO - 2016-02-20 13:08:52 --> Helper loaded: file_helper
INFO - 2016-02-20 13:08:52 --> Helper loaded: date_helper
INFO - 2016-02-20 13:08:52 --> Helper loaded: form_helper
INFO - 2016-02-20 13:08:52 --> Database Driver Class Initialized
INFO - 2016-02-20 13:08:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:08:53 --> Controller Class Initialized
INFO - 2016-02-20 13:08:53 --> Model Class Initialized
INFO - 2016-02-20 13:08:53 --> Model Class Initialized
INFO - 2016-02-20 13:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:08:53 --> Pagination Class Initialized
INFO - 2016-02-20 13:08:53 --> Helper loaded: text_helper
INFO - 2016-02-20 13:08:53 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:08:53 --> Final output sent to browser
DEBUG - 2016-02-20 16:08:53 --> Total execution time: 1.1911
INFO - 2016-02-20 13:08:55 --> Config Class Initialized
INFO - 2016-02-20 13:08:55 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:08:55 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:08:55 --> Utf8 Class Initialized
INFO - 2016-02-20 13:08:55 --> URI Class Initialized
INFO - 2016-02-20 13:08:55 --> Router Class Initialized
INFO - 2016-02-20 13:08:55 --> Output Class Initialized
INFO - 2016-02-20 13:08:55 --> Security Class Initialized
DEBUG - 2016-02-20 13:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:08:55 --> Input Class Initialized
INFO - 2016-02-20 13:08:55 --> Language Class Initialized
INFO - 2016-02-20 13:08:55 --> Loader Class Initialized
INFO - 2016-02-20 13:08:55 --> Helper loaded: url_helper
INFO - 2016-02-20 13:08:55 --> Helper loaded: file_helper
INFO - 2016-02-20 13:08:55 --> Helper loaded: date_helper
INFO - 2016-02-20 13:08:55 --> Helper loaded: form_helper
INFO - 2016-02-20 13:08:55 --> Database Driver Class Initialized
INFO - 2016-02-20 13:08:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:08:56 --> Controller Class Initialized
INFO - 2016-02-20 13:08:56 --> Model Class Initialized
INFO - 2016-02-20 13:08:56 --> Model Class Initialized
INFO - 2016-02-20 13:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:08:56 --> Pagination Class Initialized
INFO - 2016-02-20 13:08:56 --> Helper loaded: text_helper
INFO - 2016-02-20 13:08:56 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 16:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:08:56 --> Final output sent to browser
DEBUG - 2016-02-20 16:08:56 --> Total execution time: 1.1528
INFO - 2016-02-20 13:09:09 --> Config Class Initialized
INFO - 2016-02-20 13:09:09 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:09:09 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:09:09 --> Utf8 Class Initialized
INFO - 2016-02-20 13:09:09 --> URI Class Initialized
INFO - 2016-02-20 13:09:09 --> Router Class Initialized
INFO - 2016-02-20 13:09:09 --> Output Class Initialized
INFO - 2016-02-20 13:09:09 --> Security Class Initialized
DEBUG - 2016-02-20 13:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:09:09 --> Input Class Initialized
INFO - 2016-02-20 13:09:09 --> Language Class Initialized
ERROR - 2016-02-20 13:09:09 --> 404 Page Not Found: Upload_receive_from_ck/index
INFO - 2016-02-20 13:11:48 --> Config Class Initialized
INFO - 2016-02-20 13:11:48 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:11:48 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:11:48 --> Utf8 Class Initialized
INFO - 2016-02-20 13:11:48 --> URI Class Initialized
INFO - 2016-02-20 13:11:48 --> Router Class Initialized
INFO - 2016-02-20 13:11:48 --> Output Class Initialized
INFO - 2016-02-20 13:11:48 --> Security Class Initialized
DEBUG - 2016-02-20 13:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:11:48 --> Input Class Initialized
INFO - 2016-02-20 13:11:48 --> Language Class Initialized
INFO - 2016-02-20 13:11:48 --> Loader Class Initialized
INFO - 2016-02-20 13:11:48 --> Helper loaded: url_helper
INFO - 2016-02-20 13:11:48 --> Helper loaded: file_helper
INFO - 2016-02-20 13:11:48 --> Helper loaded: date_helper
INFO - 2016-02-20 13:11:48 --> Helper loaded: form_helper
INFO - 2016-02-20 13:11:48 --> Database Driver Class Initialized
INFO - 2016-02-20 13:11:49 --> Config Class Initialized
INFO - 2016-02-20 13:11:49 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:11:49 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:11:49 --> Utf8 Class Initialized
INFO - 2016-02-20 13:11:49 --> URI Class Initialized
INFO - 2016-02-20 13:11:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:11:49 --> Router Class Initialized
INFO - 2016-02-20 13:11:49 --> Controller Class Initialized
INFO - 2016-02-20 13:11:49 --> Model Class Initialized
INFO - 2016-02-20 13:11:49 --> Output Class Initialized
INFO - 2016-02-20 13:11:49 --> Model Class Initialized
INFO - 2016-02-20 13:11:49 --> Security Class Initialized
INFO - 2016-02-20 13:11:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2016-02-20 13:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:11:49 --> Pagination Class Initialized
INFO - 2016-02-20 13:11:49 --> Input Class Initialized
INFO - 2016-02-20 13:11:49 --> Helper loaded: text_helper
INFO - 2016-02-20 13:11:49 --> Language Class Initialized
INFO - 2016-02-20 13:11:49 --> Helper loaded: cookie_helper
INFO - 2016-02-20 13:11:49 --> Loader Class Initialized
INFO - 2016-02-20 16:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 13:11:49 --> Helper loaded: url_helper
INFO - 2016-02-20 16:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 13:11:49 --> Helper loaded: file_helper
INFO - 2016-02-20 16:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 13:11:49 --> Helper loaded: date_helper
INFO - 2016-02-20 16:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 13:11:49 --> Helper loaded: form_helper
INFO - 2016-02-20 16:11:49 --> Final output sent to browser
DEBUG - 2016-02-20 16:11:49 --> Total execution time: 1.1257
INFO - 2016-02-20 13:11:49 --> Database Driver Class Initialized
INFO - 2016-02-20 13:11:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:11:50 --> Controller Class Initialized
INFO - 2016-02-20 13:11:50 --> Model Class Initialized
INFO - 2016-02-20 13:11:50 --> Model Class Initialized
INFO - 2016-02-20 13:11:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:11:50 --> Pagination Class Initialized
INFO - 2016-02-20 13:11:50 --> Helper loaded: text_helper
INFO - 2016-02-20 13:11:50 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 16:11:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:11:50 --> Final output sent to browser
DEBUG - 2016-02-20 16:11:50 --> Total execution time: 1.1942
INFO - 2016-02-20 13:11:57 --> Config Class Initialized
INFO - 2016-02-20 13:11:57 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:11:57 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:11:57 --> Utf8 Class Initialized
INFO - 2016-02-20 13:11:57 --> URI Class Initialized
INFO - 2016-02-20 13:11:57 --> Router Class Initialized
INFO - 2016-02-20 13:11:57 --> Output Class Initialized
INFO - 2016-02-20 13:11:57 --> Security Class Initialized
DEBUG - 2016-02-20 13:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:11:57 --> Input Class Initialized
INFO - 2016-02-20 13:11:57 --> Language Class Initialized
INFO - 2016-02-20 13:11:57 --> Loader Class Initialized
INFO - 2016-02-20 13:11:57 --> Helper loaded: url_helper
INFO - 2016-02-20 13:11:57 --> Helper loaded: file_helper
INFO - 2016-02-20 13:11:57 --> Helper loaded: date_helper
INFO - 2016-02-20 13:11:57 --> Helper loaded: form_helper
INFO - 2016-02-20 13:11:57 --> Database Driver Class Initialized
INFO - 2016-02-20 13:11:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:11:58 --> Controller Class Initialized
INFO - 2016-02-20 13:11:58 --> Model Class Initialized
INFO - 2016-02-20 13:11:58 --> Model Class Initialized
INFO - 2016-02-20 13:11:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:11:58 --> Pagination Class Initialized
INFO - 2016-02-20 13:11:58 --> Helper loaded: text_helper
INFO - 2016-02-20 13:11:58 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:11:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:11:58 --> Final output sent to browser
DEBUG - 2016-02-20 16:11:58 --> Total execution time: 1.1920
INFO - 2016-02-20 13:12:03 --> Config Class Initialized
INFO - 2016-02-20 13:12:03 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:12:03 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:12:03 --> Utf8 Class Initialized
INFO - 2016-02-20 13:12:03 --> URI Class Initialized
INFO - 2016-02-20 13:12:03 --> Router Class Initialized
INFO - 2016-02-20 13:12:03 --> Output Class Initialized
INFO - 2016-02-20 13:12:03 --> Security Class Initialized
DEBUG - 2016-02-20 13:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:12:03 --> Input Class Initialized
INFO - 2016-02-20 13:12:03 --> Language Class Initialized
INFO - 2016-02-20 13:12:03 --> Loader Class Initialized
INFO - 2016-02-20 13:12:03 --> Helper loaded: url_helper
INFO - 2016-02-20 13:12:03 --> Helper loaded: file_helper
INFO - 2016-02-20 13:12:03 --> Helper loaded: date_helper
INFO - 2016-02-20 13:12:03 --> Helper loaded: form_helper
INFO - 2016-02-20 13:12:03 --> Database Driver Class Initialized
INFO - 2016-02-20 13:12:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:12:04 --> Controller Class Initialized
INFO - 2016-02-20 13:12:04 --> Model Class Initialized
INFO - 2016-02-20 13:12:04 --> Model Class Initialized
INFO - 2016-02-20 13:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:12:04 --> Pagination Class Initialized
INFO - 2016-02-20 13:12:04 --> Helper loaded: text_helper
INFO - 2016-02-20 13:12:04 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 16:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:12:04 --> Final output sent to browser
DEBUG - 2016-02-20 16:12:04 --> Total execution time: 1.1831
INFO - 2016-02-20 13:12:20 --> Config Class Initialized
INFO - 2016-02-20 13:12:20 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:12:20 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:12:20 --> Utf8 Class Initialized
INFO - 2016-02-20 13:12:20 --> URI Class Initialized
INFO - 2016-02-20 13:12:20 --> Router Class Initialized
INFO - 2016-02-20 13:12:20 --> Output Class Initialized
INFO - 2016-02-20 13:12:20 --> Security Class Initialized
DEBUG - 2016-02-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:12:20 --> Input Class Initialized
INFO - 2016-02-20 13:12:20 --> Language Class Initialized
ERROR - 2016-02-20 13:12:20 --> 404 Page Not Found: Upload_receive_from_ck/index
INFO - 2016-02-20 13:14:40 --> Config Class Initialized
INFO - 2016-02-20 13:14:40 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:14:40 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:14:40 --> Utf8 Class Initialized
INFO - 2016-02-20 13:14:40 --> URI Class Initialized
INFO - 2016-02-20 13:14:40 --> Router Class Initialized
INFO - 2016-02-20 13:14:40 --> Output Class Initialized
INFO - 2016-02-20 13:14:40 --> Security Class Initialized
DEBUG - 2016-02-20 13:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:14:40 --> Input Class Initialized
INFO - 2016-02-20 13:14:40 --> Language Class Initialized
INFO - 2016-02-20 13:14:40 --> Loader Class Initialized
INFO - 2016-02-20 13:14:40 --> Helper loaded: url_helper
INFO - 2016-02-20 13:14:40 --> Helper loaded: file_helper
INFO - 2016-02-20 13:14:40 --> Helper loaded: date_helper
INFO - 2016-02-20 13:14:40 --> Helper loaded: form_helper
INFO - 2016-02-20 13:14:40 --> Database Driver Class Initialized
INFO - 2016-02-20 13:14:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:14:41 --> Controller Class Initialized
INFO - 2016-02-20 13:14:41 --> Model Class Initialized
INFO - 2016-02-20 13:14:41 --> Model Class Initialized
INFO - 2016-02-20 13:14:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:14:41 --> Pagination Class Initialized
INFO - 2016-02-20 13:14:41 --> Helper loaded: text_helper
INFO - 2016-02-20 13:14:41 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:14:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:14:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:14:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 16:14:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:14:41 --> Final output sent to browser
DEBUG - 2016-02-20 16:14:41 --> Total execution time: 1.1458
INFO - 2016-02-20 13:14:46 --> Config Class Initialized
INFO - 2016-02-20 13:14:46 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:14:46 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:14:46 --> Utf8 Class Initialized
INFO - 2016-02-20 13:14:46 --> URI Class Initialized
INFO - 2016-02-20 13:14:46 --> Router Class Initialized
INFO - 2016-02-20 13:14:46 --> Output Class Initialized
INFO - 2016-02-20 13:14:46 --> Security Class Initialized
DEBUG - 2016-02-20 13:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:14:46 --> Input Class Initialized
INFO - 2016-02-20 13:14:46 --> Language Class Initialized
INFO - 2016-02-20 13:14:46 --> Loader Class Initialized
INFO - 2016-02-20 13:14:46 --> Helper loaded: url_helper
INFO - 2016-02-20 13:14:46 --> Helper loaded: file_helper
INFO - 2016-02-20 13:14:46 --> Helper loaded: date_helper
INFO - 2016-02-20 13:14:46 --> Helper loaded: form_helper
INFO - 2016-02-20 13:14:46 --> Database Driver Class Initialized
INFO - 2016-02-20 13:14:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:14:47 --> Controller Class Initialized
INFO - 2016-02-20 13:14:47 --> Model Class Initialized
INFO - 2016-02-20 13:14:47 --> Model Class Initialized
INFO - 2016-02-20 13:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:14:47 --> Pagination Class Initialized
INFO - 2016-02-20 13:14:47 --> Helper loaded: text_helper
INFO - 2016-02-20 13:14:47 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:14:47 --> Final output sent to browser
DEBUG - 2016-02-20 16:14:47 --> Total execution time: 1.1828
INFO - 2016-02-20 13:14:49 --> Config Class Initialized
INFO - 2016-02-20 13:14:49 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:14:49 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:14:49 --> Utf8 Class Initialized
INFO - 2016-02-20 13:14:49 --> URI Class Initialized
INFO - 2016-02-20 13:14:49 --> Router Class Initialized
INFO - 2016-02-20 13:14:49 --> Output Class Initialized
INFO - 2016-02-20 13:14:49 --> Security Class Initialized
DEBUG - 2016-02-20 13:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:14:49 --> Input Class Initialized
INFO - 2016-02-20 13:14:49 --> Language Class Initialized
INFO - 2016-02-20 13:14:49 --> Loader Class Initialized
INFO - 2016-02-20 13:14:49 --> Helper loaded: url_helper
INFO - 2016-02-20 13:14:49 --> Helper loaded: file_helper
INFO - 2016-02-20 13:14:49 --> Helper loaded: date_helper
INFO - 2016-02-20 13:14:49 --> Helper loaded: form_helper
INFO - 2016-02-20 13:14:49 --> Database Driver Class Initialized
INFO - 2016-02-20 13:14:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:14:50 --> Controller Class Initialized
INFO - 2016-02-20 13:14:50 --> Model Class Initialized
INFO - 2016-02-20 13:14:50 --> Model Class Initialized
INFO - 2016-02-20 13:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:14:50 --> Pagination Class Initialized
INFO - 2016-02-20 13:14:50 --> Helper loaded: text_helper
INFO - 2016-02-20 13:14:50 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-20 16:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:14:50 --> Final output sent to browser
DEBUG - 2016-02-20 16:14:50 --> Total execution time: 1.1351
INFO - 2016-02-20 13:15:05 --> Config Class Initialized
INFO - 2016-02-20 13:15:05 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:15:05 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:15:05 --> Utf8 Class Initialized
INFO - 2016-02-20 13:15:05 --> URI Class Initialized
INFO - 2016-02-20 13:15:05 --> Router Class Initialized
INFO - 2016-02-20 13:15:05 --> Output Class Initialized
INFO - 2016-02-20 13:15:05 --> Security Class Initialized
DEBUG - 2016-02-20 13:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:15:05 --> Input Class Initialized
INFO - 2016-02-20 13:15:05 --> Language Class Initialized
INFO - 2016-02-20 13:15:05 --> Loader Class Initialized
INFO - 2016-02-20 13:15:05 --> Helper loaded: url_helper
INFO - 2016-02-20 13:15:05 --> Helper loaded: file_helper
INFO - 2016-02-20 13:15:05 --> Helper loaded: date_helper
INFO - 2016-02-20 13:15:05 --> Helper loaded: form_helper
INFO - 2016-02-20 13:15:05 --> Database Driver Class Initialized
INFO - 2016-02-20 13:15:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:15:06 --> Controller Class Initialized
INFO - 2016-02-20 13:15:06 --> Model Class Initialized
INFO - 2016-02-20 13:15:06 --> Model Class Initialized
INFO - 2016-02-20 13:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:15:06 --> Pagination Class Initialized
INFO - 2016-02-20 13:15:06 --> Helper loaded: text_helper
INFO - 2016-02-20 13:15:06 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:15:06 --> Upload Class Initialized
INFO - 2016-02-20 16:15:06 --> Final output sent to browser
DEBUG - 2016-02-20 16:15:06 --> Total execution time: 1.1503
INFO - 2016-02-20 13:15:25 --> Config Class Initialized
INFO - 2016-02-20 13:15:25 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:15:25 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:15:25 --> Utf8 Class Initialized
INFO - 2016-02-20 13:15:25 --> URI Class Initialized
INFO - 2016-02-20 13:15:25 --> Router Class Initialized
INFO - 2016-02-20 13:15:25 --> Output Class Initialized
INFO - 2016-02-20 13:15:25 --> Security Class Initialized
DEBUG - 2016-02-20 13:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:15:25 --> Input Class Initialized
INFO - 2016-02-20 13:15:25 --> Language Class Initialized
INFO - 2016-02-20 13:15:25 --> Loader Class Initialized
INFO - 2016-02-20 13:15:25 --> Helper loaded: url_helper
INFO - 2016-02-20 13:15:25 --> Helper loaded: file_helper
INFO - 2016-02-20 13:15:25 --> Helper loaded: date_helper
INFO - 2016-02-20 13:15:25 --> Helper loaded: form_helper
INFO - 2016-02-20 13:15:25 --> Database Driver Class Initialized
INFO - 2016-02-20 13:15:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:15:26 --> Controller Class Initialized
INFO - 2016-02-20 13:15:26 --> Model Class Initialized
INFO - 2016-02-20 13:15:26 --> Model Class Initialized
INFO - 2016-02-20 13:15:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:15:26 --> Pagination Class Initialized
INFO - 2016-02-20 13:15:26 --> Helper loaded: text_helper
INFO - 2016-02-20 13:15:26 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 16:15:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:15:26 --> Final output sent to browser
DEBUG - 2016-02-20 16:15:26 --> Total execution time: 1.1211
INFO - 2016-02-20 13:15:30 --> Config Class Initialized
INFO - 2016-02-20 13:15:30 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:15:30 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:15:30 --> Utf8 Class Initialized
INFO - 2016-02-20 13:15:30 --> URI Class Initialized
INFO - 2016-02-20 13:15:30 --> Router Class Initialized
INFO - 2016-02-20 13:15:30 --> Output Class Initialized
INFO - 2016-02-20 13:15:30 --> Security Class Initialized
DEBUG - 2016-02-20 13:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:15:30 --> Input Class Initialized
INFO - 2016-02-20 13:15:30 --> Language Class Initialized
INFO - 2016-02-20 13:15:30 --> Loader Class Initialized
INFO - 2016-02-20 13:15:30 --> Helper loaded: url_helper
INFO - 2016-02-20 13:15:30 --> Helper loaded: file_helper
INFO - 2016-02-20 13:15:30 --> Helper loaded: date_helper
INFO - 2016-02-20 13:15:30 --> Helper loaded: form_helper
INFO - 2016-02-20 13:15:30 --> Database Driver Class Initialized
INFO - 2016-02-20 13:15:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:15:31 --> Controller Class Initialized
INFO - 2016-02-20 13:15:31 --> Model Class Initialized
INFO - 2016-02-20 13:15:31 --> Model Class Initialized
INFO - 2016-02-20 13:15:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:15:31 --> Pagination Class Initialized
INFO - 2016-02-20 13:15:31 --> Helper loaded: text_helper
INFO - 2016-02-20 13:15:31 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:15:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:15:31 --> Final output sent to browser
DEBUG - 2016-02-20 16:15:31 --> Total execution time: 1.1845
INFO - 2016-02-20 13:20:12 --> Config Class Initialized
INFO - 2016-02-20 13:20:12 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:20:12 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:20:12 --> Utf8 Class Initialized
INFO - 2016-02-20 13:20:12 --> URI Class Initialized
INFO - 2016-02-20 13:20:12 --> Router Class Initialized
INFO - 2016-02-20 13:20:12 --> Output Class Initialized
INFO - 2016-02-20 13:20:12 --> Security Class Initialized
DEBUG - 2016-02-20 13:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:20:12 --> Input Class Initialized
INFO - 2016-02-20 13:20:12 --> Language Class Initialized
INFO - 2016-02-20 13:20:12 --> Loader Class Initialized
INFO - 2016-02-20 13:20:12 --> Helper loaded: url_helper
INFO - 2016-02-20 13:20:12 --> Helper loaded: file_helper
INFO - 2016-02-20 13:20:12 --> Helper loaded: date_helper
INFO - 2016-02-20 13:20:12 --> Helper loaded: form_helper
INFO - 2016-02-20 13:20:12 --> Database Driver Class Initialized
INFO - 2016-02-20 13:20:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:20:13 --> Controller Class Initialized
INFO - 2016-02-20 13:20:13 --> Model Class Initialized
INFO - 2016-02-20 13:20:13 --> Model Class Initialized
INFO - 2016-02-20 13:20:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:20:13 --> Pagination Class Initialized
INFO - 2016-02-20 13:20:13 --> Helper loaded: text_helper
INFO - 2016-02-20 13:20:13 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:20:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:20:13 --> Final output sent to browser
DEBUG - 2016-02-20 16:20:13 --> Total execution time: 1.1416
INFO - 2016-02-20 13:22:27 --> Config Class Initialized
INFO - 2016-02-20 13:22:27 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:22:27 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:22:27 --> Utf8 Class Initialized
INFO - 2016-02-20 13:22:27 --> URI Class Initialized
INFO - 2016-02-20 13:22:27 --> Router Class Initialized
INFO - 2016-02-20 13:22:27 --> Output Class Initialized
INFO - 2016-02-20 13:22:27 --> Security Class Initialized
DEBUG - 2016-02-20 13:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:22:27 --> Input Class Initialized
INFO - 2016-02-20 13:22:27 --> Language Class Initialized
INFO - 2016-02-20 13:22:27 --> Loader Class Initialized
INFO - 2016-02-20 13:22:27 --> Helper loaded: url_helper
INFO - 2016-02-20 13:22:27 --> Helper loaded: file_helper
INFO - 2016-02-20 13:22:27 --> Helper loaded: date_helper
INFO - 2016-02-20 13:22:27 --> Helper loaded: form_helper
INFO - 2016-02-20 13:22:27 --> Database Driver Class Initialized
INFO - 2016-02-20 13:22:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:22:28 --> Controller Class Initialized
INFO - 2016-02-20 13:22:28 --> Model Class Initialized
INFO - 2016-02-20 13:22:28 --> Model Class Initialized
INFO - 2016-02-20 13:22:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:22:28 --> Pagination Class Initialized
INFO - 2016-02-20 13:22:28 --> Helper loaded: text_helper
INFO - 2016-02-20 13:22:28 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:22:28 --> Final output sent to browser
DEBUG - 2016-02-20 16:22:28 --> Total execution time: 1.1671
INFO - 2016-02-20 13:23:03 --> Config Class Initialized
INFO - 2016-02-20 13:23:04 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:23:04 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:23:04 --> Utf8 Class Initialized
INFO - 2016-02-20 13:23:04 --> URI Class Initialized
INFO - 2016-02-20 13:23:04 --> Router Class Initialized
INFO - 2016-02-20 13:23:04 --> Output Class Initialized
INFO - 2016-02-20 13:23:04 --> Security Class Initialized
DEBUG - 2016-02-20 13:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:23:04 --> Input Class Initialized
INFO - 2016-02-20 13:23:04 --> Language Class Initialized
INFO - 2016-02-20 13:23:04 --> Loader Class Initialized
INFO - 2016-02-20 13:23:04 --> Helper loaded: url_helper
INFO - 2016-02-20 13:23:04 --> Helper loaded: file_helper
INFO - 2016-02-20 13:23:04 --> Helper loaded: date_helper
INFO - 2016-02-20 13:23:04 --> Helper loaded: form_helper
INFO - 2016-02-20 13:23:04 --> Database Driver Class Initialized
INFO - 2016-02-20 13:23:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:23:05 --> Controller Class Initialized
INFO - 2016-02-20 13:23:05 --> Model Class Initialized
INFO - 2016-02-20 13:23:05 --> Model Class Initialized
INFO - 2016-02-20 13:23:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:23:05 --> Pagination Class Initialized
INFO - 2016-02-20 13:23:05 --> Helper loaded: text_helper
INFO - 2016-02-20 13:23:05 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:23:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:23:05 --> Final output sent to browser
DEBUG - 2016-02-20 16:23:05 --> Total execution time: 1.2315
INFO - 2016-02-20 13:23:49 --> Config Class Initialized
INFO - 2016-02-20 13:23:49 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:23:49 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:23:49 --> Utf8 Class Initialized
INFO - 2016-02-20 13:23:49 --> URI Class Initialized
INFO - 2016-02-20 13:23:49 --> Router Class Initialized
INFO - 2016-02-20 13:23:49 --> Output Class Initialized
INFO - 2016-02-20 13:23:49 --> Security Class Initialized
DEBUG - 2016-02-20 13:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:23:49 --> Input Class Initialized
INFO - 2016-02-20 13:23:49 --> Language Class Initialized
INFO - 2016-02-20 13:23:49 --> Loader Class Initialized
INFO - 2016-02-20 13:23:49 --> Helper loaded: url_helper
INFO - 2016-02-20 13:23:49 --> Helper loaded: file_helper
INFO - 2016-02-20 13:23:49 --> Helper loaded: date_helper
INFO - 2016-02-20 13:23:49 --> Helper loaded: form_helper
INFO - 2016-02-20 13:23:49 --> Database Driver Class Initialized
INFO - 2016-02-20 13:23:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:23:50 --> Controller Class Initialized
INFO - 2016-02-20 13:23:50 --> Model Class Initialized
INFO - 2016-02-20 13:23:50 --> Model Class Initialized
INFO - 2016-02-20 13:23:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:23:50 --> Pagination Class Initialized
INFO - 2016-02-20 13:23:50 --> Helper loaded: text_helper
INFO - 2016-02-20 13:23:50 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:23:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:23:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:23:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:23:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:23:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:23:50 --> Final output sent to browser
DEBUG - 2016-02-20 16:23:50 --> Total execution time: 1.1758
INFO - 2016-02-20 13:25:35 --> Config Class Initialized
INFO - 2016-02-20 13:25:35 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:25:35 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:25:35 --> Utf8 Class Initialized
INFO - 2016-02-20 13:25:35 --> URI Class Initialized
INFO - 2016-02-20 13:25:35 --> Router Class Initialized
INFO - 2016-02-20 13:25:35 --> Output Class Initialized
INFO - 2016-02-20 13:25:35 --> Security Class Initialized
DEBUG - 2016-02-20 13:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:25:35 --> Input Class Initialized
INFO - 2016-02-20 13:25:35 --> Language Class Initialized
INFO - 2016-02-20 13:25:35 --> Loader Class Initialized
INFO - 2016-02-20 13:25:35 --> Helper loaded: url_helper
INFO - 2016-02-20 13:25:35 --> Helper loaded: file_helper
INFO - 2016-02-20 13:25:35 --> Helper loaded: date_helper
INFO - 2016-02-20 13:25:35 --> Helper loaded: form_helper
INFO - 2016-02-20 13:25:35 --> Database Driver Class Initialized
INFO - 2016-02-20 13:25:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:25:36 --> Controller Class Initialized
INFO - 2016-02-20 13:25:36 --> Model Class Initialized
INFO - 2016-02-20 13:25:36 --> Model Class Initialized
INFO - 2016-02-20 13:25:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:25:36 --> Pagination Class Initialized
INFO - 2016-02-20 13:25:36 --> Helper loaded: text_helper
INFO - 2016-02-20 13:25:36 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:25:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:25:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:25:37 --> Final output sent to browser
DEBUG - 2016-02-20 16:25:37 --> Total execution time: 1.2206
INFO - 2016-02-20 13:25:58 --> Config Class Initialized
INFO - 2016-02-20 13:25:58 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:25:58 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:25:58 --> Utf8 Class Initialized
INFO - 2016-02-20 13:25:58 --> URI Class Initialized
INFO - 2016-02-20 13:25:58 --> Router Class Initialized
INFO - 2016-02-20 13:25:58 --> Output Class Initialized
INFO - 2016-02-20 13:25:58 --> Security Class Initialized
DEBUG - 2016-02-20 13:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:25:58 --> Input Class Initialized
INFO - 2016-02-20 13:25:58 --> Language Class Initialized
INFO - 2016-02-20 13:25:58 --> Loader Class Initialized
INFO - 2016-02-20 13:25:58 --> Helper loaded: url_helper
INFO - 2016-02-20 13:25:58 --> Helper loaded: file_helper
INFO - 2016-02-20 13:25:58 --> Helper loaded: date_helper
INFO - 2016-02-20 13:25:58 --> Helper loaded: form_helper
INFO - 2016-02-20 13:25:58 --> Database Driver Class Initialized
INFO - 2016-02-20 13:25:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:25:59 --> Controller Class Initialized
INFO - 2016-02-20 13:25:59 --> Model Class Initialized
INFO - 2016-02-20 13:25:59 --> Model Class Initialized
INFO - 2016-02-20 13:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:25:59 --> Pagination Class Initialized
INFO - 2016-02-20 13:25:59 --> Helper loaded: text_helper
INFO - 2016-02-20 13:26:00 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:26:00 --> Final output sent to browser
DEBUG - 2016-02-20 16:26:00 --> Total execution time: 1.1185
INFO - 2016-02-20 13:26:14 --> Config Class Initialized
INFO - 2016-02-20 13:26:14 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:26:14 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:26:14 --> Utf8 Class Initialized
INFO - 2016-02-20 13:26:14 --> URI Class Initialized
INFO - 2016-02-20 13:26:14 --> Router Class Initialized
INFO - 2016-02-20 13:26:14 --> Output Class Initialized
INFO - 2016-02-20 13:26:14 --> Security Class Initialized
DEBUG - 2016-02-20 13:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:26:14 --> Input Class Initialized
INFO - 2016-02-20 13:26:14 --> Language Class Initialized
INFO - 2016-02-20 13:26:14 --> Loader Class Initialized
INFO - 2016-02-20 13:26:14 --> Helper loaded: url_helper
INFO - 2016-02-20 13:26:14 --> Helper loaded: file_helper
INFO - 2016-02-20 13:26:14 --> Helper loaded: date_helper
INFO - 2016-02-20 13:26:14 --> Helper loaded: form_helper
INFO - 2016-02-20 13:26:14 --> Database Driver Class Initialized
INFO - 2016-02-20 13:26:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:26:15 --> Controller Class Initialized
INFO - 2016-02-20 13:26:15 --> Model Class Initialized
INFO - 2016-02-20 13:26:15 --> Model Class Initialized
INFO - 2016-02-20 13:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:26:15 --> Pagination Class Initialized
INFO - 2016-02-20 13:26:15 --> Helper loaded: text_helper
INFO - 2016-02-20 13:26:15 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:26:16 --> Final output sent to browser
DEBUG - 2016-02-20 16:26:16 --> Total execution time: 1.1987
INFO - 2016-02-20 13:26:26 --> Config Class Initialized
INFO - 2016-02-20 13:26:26 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:26:26 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:26:26 --> Utf8 Class Initialized
INFO - 2016-02-20 13:26:26 --> URI Class Initialized
INFO - 2016-02-20 13:26:26 --> Router Class Initialized
INFO - 2016-02-20 13:26:26 --> Output Class Initialized
INFO - 2016-02-20 13:26:26 --> Security Class Initialized
DEBUG - 2016-02-20 13:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:26:26 --> Input Class Initialized
INFO - 2016-02-20 13:26:26 --> Language Class Initialized
INFO - 2016-02-20 13:26:26 --> Loader Class Initialized
INFO - 2016-02-20 13:26:26 --> Helper loaded: url_helper
INFO - 2016-02-20 13:26:26 --> Helper loaded: file_helper
INFO - 2016-02-20 13:26:26 --> Helper loaded: date_helper
INFO - 2016-02-20 13:26:26 --> Helper loaded: form_helper
INFO - 2016-02-20 13:26:26 --> Database Driver Class Initialized
INFO - 2016-02-20 13:26:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:26:27 --> Controller Class Initialized
INFO - 2016-02-20 13:26:27 --> Model Class Initialized
INFO - 2016-02-20 13:26:27 --> Model Class Initialized
INFO - 2016-02-20 13:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:26:27 --> Pagination Class Initialized
INFO - 2016-02-20 13:26:27 --> Helper loaded: text_helper
INFO - 2016-02-20 13:26:27 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:26:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:26:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:26:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:26:28 --> Final output sent to browser
DEBUG - 2016-02-20 16:26:28 --> Total execution time: 1.1903
INFO - 2016-02-20 13:27:13 --> Config Class Initialized
INFO - 2016-02-20 13:27:13 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:27:13 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:27:13 --> Utf8 Class Initialized
INFO - 2016-02-20 13:27:13 --> URI Class Initialized
INFO - 2016-02-20 13:27:13 --> Router Class Initialized
INFO - 2016-02-20 13:27:13 --> Output Class Initialized
INFO - 2016-02-20 13:27:13 --> Security Class Initialized
DEBUG - 2016-02-20 13:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:27:13 --> Input Class Initialized
INFO - 2016-02-20 13:27:13 --> Language Class Initialized
INFO - 2016-02-20 13:27:13 --> Loader Class Initialized
INFO - 2016-02-20 13:27:13 --> Helper loaded: url_helper
INFO - 2016-02-20 13:27:13 --> Helper loaded: file_helper
INFO - 2016-02-20 13:27:13 --> Helper loaded: date_helper
INFO - 2016-02-20 13:27:13 --> Helper loaded: form_helper
INFO - 2016-02-20 13:27:13 --> Database Driver Class Initialized
INFO - 2016-02-20 13:27:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:27:14 --> Controller Class Initialized
INFO - 2016-02-20 13:27:14 --> Model Class Initialized
INFO - 2016-02-20 13:27:14 --> Model Class Initialized
INFO - 2016-02-20 13:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:27:14 --> Pagination Class Initialized
INFO - 2016-02-20 13:27:14 --> Helper loaded: text_helper
INFO - 2016-02-20 13:27:14 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:27:14 --> Final output sent to browser
DEBUG - 2016-02-20 16:27:14 --> Total execution time: 1.2213
INFO - 2016-02-20 13:27:20 --> Config Class Initialized
INFO - 2016-02-20 13:27:20 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:27:20 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:27:20 --> Utf8 Class Initialized
INFO - 2016-02-20 13:27:20 --> URI Class Initialized
INFO - 2016-02-20 13:27:20 --> Router Class Initialized
INFO - 2016-02-20 13:27:20 --> Output Class Initialized
INFO - 2016-02-20 13:27:20 --> Security Class Initialized
DEBUG - 2016-02-20 13:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:27:20 --> Input Class Initialized
INFO - 2016-02-20 13:27:20 --> Language Class Initialized
INFO - 2016-02-20 13:27:20 --> Loader Class Initialized
INFO - 2016-02-20 13:27:20 --> Helper loaded: url_helper
INFO - 2016-02-20 13:27:20 --> Helper loaded: file_helper
INFO - 2016-02-20 13:27:20 --> Helper loaded: date_helper
INFO - 2016-02-20 13:27:20 --> Helper loaded: form_helper
INFO - 2016-02-20 13:27:20 --> Database Driver Class Initialized
INFO - 2016-02-20 13:27:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:27:21 --> Controller Class Initialized
INFO - 2016-02-20 13:27:21 --> Model Class Initialized
INFO - 2016-02-20 13:27:21 --> Model Class Initialized
INFO - 2016-02-20 13:27:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:27:21 --> Pagination Class Initialized
INFO - 2016-02-20 13:27:21 --> Helper loaded: text_helper
INFO - 2016-02-20 13:27:21 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:27:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:27:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:27:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:27:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:27:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:27:21 --> Final output sent to browser
DEBUG - 2016-02-20 16:27:21 --> Total execution time: 1.1613
INFO - 2016-02-20 13:29:23 --> Config Class Initialized
INFO - 2016-02-20 13:29:23 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:29:23 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:29:23 --> Utf8 Class Initialized
INFO - 2016-02-20 13:29:23 --> URI Class Initialized
INFO - 2016-02-20 13:29:23 --> Router Class Initialized
INFO - 2016-02-20 13:29:23 --> Output Class Initialized
INFO - 2016-02-20 13:29:23 --> Security Class Initialized
DEBUG - 2016-02-20 13:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:29:23 --> Input Class Initialized
INFO - 2016-02-20 13:29:23 --> Language Class Initialized
INFO - 2016-02-20 13:29:23 --> Loader Class Initialized
INFO - 2016-02-20 13:29:23 --> Helper loaded: url_helper
INFO - 2016-02-20 13:29:23 --> Helper loaded: file_helper
INFO - 2016-02-20 13:29:23 --> Helper loaded: date_helper
INFO - 2016-02-20 13:29:23 --> Helper loaded: form_helper
INFO - 2016-02-20 13:29:23 --> Database Driver Class Initialized
INFO - 2016-02-20 13:29:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:29:24 --> Controller Class Initialized
INFO - 2016-02-20 13:29:24 --> Model Class Initialized
INFO - 2016-02-20 13:29:24 --> Model Class Initialized
INFO - 2016-02-20 13:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:29:24 --> Pagination Class Initialized
INFO - 2016-02-20 13:29:24 --> Helper loaded: text_helper
INFO - 2016-02-20 13:29:24 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:29:24 --> Final output sent to browser
DEBUG - 2016-02-20 16:29:24 --> Total execution time: 1.1688
INFO - 2016-02-20 13:29:43 --> Config Class Initialized
INFO - 2016-02-20 13:29:43 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:29:43 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:29:43 --> Utf8 Class Initialized
INFO - 2016-02-20 13:29:43 --> URI Class Initialized
INFO - 2016-02-20 13:29:43 --> Router Class Initialized
INFO - 2016-02-20 13:29:43 --> Output Class Initialized
INFO - 2016-02-20 13:29:43 --> Security Class Initialized
DEBUG - 2016-02-20 13:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:29:43 --> Input Class Initialized
INFO - 2016-02-20 13:29:43 --> Language Class Initialized
INFO - 2016-02-20 13:29:43 --> Loader Class Initialized
INFO - 2016-02-20 13:29:43 --> Helper loaded: url_helper
INFO - 2016-02-20 13:29:43 --> Helper loaded: file_helper
INFO - 2016-02-20 13:29:43 --> Helper loaded: date_helper
INFO - 2016-02-20 13:29:43 --> Helper loaded: form_helper
INFO - 2016-02-20 13:29:43 --> Database Driver Class Initialized
INFO - 2016-02-20 13:29:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:29:44 --> Controller Class Initialized
INFO - 2016-02-20 13:29:44 --> Model Class Initialized
INFO - 2016-02-20 13:29:44 --> Model Class Initialized
INFO - 2016-02-20 13:29:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:29:44 --> Pagination Class Initialized
INFO - 2016-02-20 13:29:44 --> Helper loaded: text_helper
INFO - 2016-02-20 13:29:44 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:29:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:29:44 --> Final output sent to browser
DEBUG - 2016-02-20 16:29:44 --> Total execution time: 1.1840
INFO - 2016-02-20 13:30:30 --> Config Class Initialized
INFO - 2016-02-20 13:30:30 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:30:30 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:30:30 --> Utf8 Class Initialized
INFO - 2016-02-20 13:30:30 --> URI Class Initialized
INFO - 2016-02-20 13:30:30 --> Router Class Initialized
INFO - 2016-02-20 13:30:30 --> Output Class Initialized
INFO - 2016-02-20 13:30:30 --> Security Class Initialized
DEBUG - 2016-02-20 13:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:30:30 --> Input Class Initialized
INFO - 2016-02-20 13:30:30 --> Language Class Initialized
INFO - 2016-02-20 13:30:30 --> Loader Class Initialized
INFO - 2016-02-20 13:30:30 --> Helper loaded: url_helper
INFO - 2016-02-20 13:30:30 --> Helper loaded: file_helper
INFO - 2016-02-20 13:30:30 --> Helper loaded: date_helper
INFO - 2016-02-20 13:30:30 --> Helper loaded: form_helper
INFO - 2016-02-20 13:30:30 --> Database Driver Class Initialized
INFO - 2016-02-20 13:30:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:30:31 --> Controller Class Initialized
INFO - 2016-02-20 13:30:31 --> Model Class Initialized
INFO - 2016-02-20 13:30:31 --> Model Class Initialized
INFO - 2016-02-20 13:30:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:30:31 --> Pagination Class Initialized
INFO - 2016-02-20 13:30:31 --> Helper loaded: text_helper
INFO - 2016-02-20 13:30:31 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:30:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:30:31 --> Final output sent to browser
DEBUG - 2016-02-20 16:30:31 --> Total execution time: 1.1300
INFO - 2016-02-20 13:31:12 --> Config Class Initialized
INFO - 2016-02-20 13:31:12 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:31:12 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:31:12 --> Utf8 Class Initialized
INFO - 2016-02-20 13:31:12 --> URI Class Initialized
INFO - 2016-02-20 13:31:12 --> Router Class Initialized
INFO - 2016-02-20 13:31:12 --> Output Class Initialized
INFO - 2016-02-20 13:31:12 --> Security Class Initialized
DEBUG - 2016-02-20 13:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:31:12 --> Input Class Initialized
INFO - 2016-02-20 13:31:12 --> Language Class Initialized
INFO - 2016-02-20 13:31:12 --> Loader Class Initialized
INFO - 2016-02-20 13:31:12 --> Helper loaded: url_helper
INFO - 2016-02-20 13:31:12 --> Helper loaded: file_helper
INFO - 2016-02-20 13:31:12 --> Helper loaded: date_helper
INFO - 2016-02-20 13:31:12 --> Helper loaded: form_helper
INFO - 2016-02-20 13:31:12 --> Database Driver Class Initialized
INFO - 2016-02-20 13:31:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:31:13 --> Controller Class Initialized
INFO - 2016-02-20 13:31:13 --> Model Class Initialized
INFO - 2016-02-20 13:31:13 --> Model Class Initialized
INFO - 2016-02-20 13:31:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:31:13 --> Pagination Class Initialized
INFO - 2016-02-20 13:31:13 --> Helper loaded: text_helper
INFO - 2016-02-20 13:31:13 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:31:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:31:13 --> Final output sent to browser
DEBUG - 2016-02-20 16:31:13 --> Total execution time: 1.1883
INFO - 2016-02-20 13:34:25 --> Config Class Initialized
INFO - 2016-02-20 13:34:25 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:34:25 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:34:25 --> Utf8 Class Initialized
INFO - 2016-02-20 13:34:25 --> URI Class Initialized
INFO - 2016-02-20 13:34:25 --> Router Class Initialized
INFO - 2016-02-20 13:34:25 --> Output Class Initialized
INFO - 2016-02-20 13:34:25 --> Security Class Initialized
DEBUG - 2016-02-20 13:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:34:25 --> Input Class Initialized
INFO - 2016-02-20 13:34:25 --> Language Class Initialized
INFO - 2016-02-20 13:34:25 --> Loader Class Initialized
INFO - 2016-02-20 13:34:25 --> Helper loaded: url_helper
INFO - 2016-02-20 13:34:25 --> Helper loaded: file_helper
INFO - 2016-02-20 13:34:25 --> Helper loaded: date_helper
INFO - 2016-02-20 13:34:25 --> Helper loaded: form_helper
INFO - 2016-02-20 13:34:25 --> Database Driver Class Initialized
INFO - 2016-02-20 13:34:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:34:26 --> Controller Class Initialized
INFO - 2016-02-20 13:34:26 --> Model Class Initialized
INFO - 2016-02-20 13:34:26 --> Model Class Initialized
INFO - 2016-02-20 13:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:34:26 --> Pagination Class Initialized
INFO - 2016-02-20 13:34:26 --> Helper loaded: text_helper
INFO - 2016-02-20 13:34:26 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:34:26 --> Final output sent to browser
DEBUG - 2016-02-20 16:34:26 --> Total execution time: 1.1874
INFO - 2016-02-20 13:38:01 --> Config Class Initialized
INFO - 2016-02-20 13:38:01 --> Hooks Class Initialized
DEBUG - 2016-02-20 13:38:01 --> UTF-8 Support Enabled
INFO - 2016-02-20 13:38:01 --> Utf8 Class Initialized
INFO - 2016-02-20 13:38:01 --> URI Class Initialized
INFO - 2016-02-20 13:38:01 --> Router Class Initialized
INFO - 2016-02-20 13:38:01 --> Output Class Initialized
INFO - 2016-02-20 13:38:01 --> Security Class Initialized
DEBUG - 2016-02-20 13:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 13:38:01 --> Input Class Initialized
INFO - 2016-02-20 13:38:01 --> Language Class Initialized
INFO - 2016-02-20 13:38:01 --> Loader Class Initialized
INFO - 2016-02-20 13:38:01 --> Helper loaded: url_helper
INFO - 2016-02-20 13:38:01 --> Helper loaded: file_helper
INFO - 2016-02-20 13:38:01 --> Helper loaded: date_helper
INFO - 2016-02-20 13:38:01 --> Helper loaded: form_helper
INFO - 2016-02-20 13:38:01 --> Database Driver Class Initialized
INFO - 2016-02-20 13:38:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 13:38:02 --> Controller Class Initialized
INFO - 2016-02-20 13:38:02 --> Model Class Initialized
INFO - 2016-02-20 13:38:02 --> Model Class Initialized
INFO - 2016-02-20 13:38:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 13:38:02 --> Pagination Class Initialized
INFO - 2016-02-20 13:38:02 --> Helper loaded: text_helper
INFO - 2016-02-20 13:38:02 --> Helper loaded: cookie_helper
INFO - 2016-02-20 16:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 16:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 16:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 16:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 16:38:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 16:38:02 --> Final output sent to browser
DEBUG - 2016-02-20 16:38:02 --> Total execution time: 1.2320
INFO - 2016-02-20 14:25:34 --> Config Class Initialized
INFO - 2016-02-20 14:25:34 --> Hooks Class Initialized
DEBUG - 2016-02-20 14:25:34 --> UTF-8 Support Enabled
INFO - 2016-02-20 14:25:34 --> Utf8 Class Initialized
INFO - 2016-02-20 14:25:34 --> URI Class Initialized
INFO - 2016-02-20 14:25:34 --> Router Class Initialized
INFO - 2016-02-20 14:25:34 --> Output Class Initialized
INFO - 2016-02-20 14:25:34 --> Security Class Initialized
DEBUG - 2016-02-20 14:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 14:25:34 --> Input Class Initialized
INFO - 2016-02-20 14:25:34 --> Language Class Initialized
INFO - 2016-02-20 14:25:34 --> Loader Class Initialized
INFO - 2016-02-20 14:25:34 --> Helper loaded: url_helper
INFO - 2016-02-20 14:25:34 --> Helper loaded: file_helper
INFO - 2016-02-20 14:25:34 --> Helper loaded: date_helper
INFO - 2016-02-20 14:25:34 --> Helper loaded: form_helper
INFO - 2016-02-20 14:25:34 --> Database Driver Class Initialized
INFO - 2016-02-20 14:25:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 14:25:35 --> Controller Class Initialized
INFO - 2016-02-20 14:25:35 --> Model Class Initialized
INFO - 2016-02-20 14:25:35 --> Model Class Initialized
INFO - 2016-02-20 14:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 14:25:35 --> Pagination Class Initialized
INFO - 2016-02-20 14:25:35 --> Helper loaded: text_helper
INFO - 2016-02-20 14:25:35 --> Helper loaded: cookie_helper
INFO - 2016-02-20 17:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 17:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 17:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 17:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 17:25:35 --> Final output sent to browser
DEBUG - 2016-02-20 17:25:35 --> Total execution time: 1.1465
INFO - 2016-02-20 14:25:38 --> Config Class Initialized
INFO - 2016-02-20 14:25:38 --> Hooks Class Initialized
DEBUG - 2016-02-20 14:25:38 --> UTF-8 Support Enabled
INFO - 2016-02-20 14:25:38 --> Utf8 Class Initialized
INFO - 2016-02-20 14:25:38 --> URI Class Initialized
INFO - 2016-02-20 14:25:38 --> Router Class Initialized
INFO - 2016-02-20 14:25:38 --> Output Class Initialized
INFO - 2016-02-20 14:25:38 --> Security Class Initialized
DEBUG - 2016-02-20 14:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 14:25:38 --> Input Class Initialized
INFO - 2016-02-20 14:25:38 --> Language Class Initialized
INFO - 2016-02-20 14:25:38 --> Loader Class Initialized
INFO - 2016-02-20 14:25:38 --> Helper loaded: url_helper
INFO - 2016-02-20 14:25:38 --> Helper loaded: file_helper
INFO - 2016-02-20 14:25:38 --> Helper loaded: date_helper
INFO - 2016-02-20 14:25:38 --> Helper loaded: form_helper
INFO - 2016-02-20 14:25:38 --> Database Driver Class Initialized
INFO - 2016-02-20 14:25:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 14:25:39 --> Controller Class Initialized
INFO - 2016-02-20 14:25:39 --> Model Class Initialized
INFO - 2016-02-20 14:25:39 --> Model Class Initialized
INFO - 2016-02-20 14:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 14:25:39 --> Pagination Class Initialized
INFO - 2016-02-20 14:25:39 --> Helper loaded: text_helper
INFO - 2016-02-20 14:25:39 --> Helper loaded: cookie_helper
INFO - 2016-02-20 17:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 17:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 17:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 17:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 17:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 17:25:39 --> Final output sent to browser
DEBUG - 2016-02-20 17:25:39 --> Total execution time: 1.1773
INFO - 2016-02-20 14:25:43 --> Config Class Initialized
INFO - 2016-02-20 14:25:43 --> Hooks Class Initialized
DEBUG - 2016-02-20 14:25:43 --> UTF-8 Support Enabled
INFO - 2016-02-20 14:25:43 --> Utf8 Class Initialized
INFO - 2016-02-20 14:25:43 --> URI Class Initialized
INFO - 2016-02-20 14:25:43 --> Router Class Initialized
INFO - 2016-02-20 14:25:43 --> Output Class Initialized
INFO - 2016-02-20 14:25:43 --> Security Class Initialized
DEBUG - 2016-02-20 14:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 14:25:43 --> Input Class Initialized
INFO - 2016-02-20 14:25:43 --> Language Class Initialized
INFO - 2016-02-20 14:25:43 --> Loader Class Initialized
INFO - 2016-02-20 14:25:43 --> Helper loaded: url_helper
INFO - 2016-02-20 14:25:43 --> Helper loaded: file_helper
INFO - 2016-02-20 14:25:43 --> Helper loaded: date_helper
INFO - 2016-02-20 14:25:43 --> Helper loaded: form_helper
INFO - 2016-02-20 14:25:43 --> Database Driver Class Initialized
INFO - 2016-02-20 14:25:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 14:25:44 --> Controller Class Initialized
INFO - 2016-02-20 14:25:44 --> Model Class Initialized
INFO - 2016-02-20 14:25:44 --> Model Class Initialized
INFO - 2016-02-20 14:25:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 14:25:44 --> Pagination Class Initialized
INFO - 2016-02-20 14:25:44 --> Helper loaded: text_helper
INFO - 2016-02-20 14:25:44 --> Helper loaded: cookie_helper
INFO - 2016-02-20 17:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 17:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 17:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-20 17:25:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 17:25:44 --> Final output sent to browser
DEBUG - 2016-02-20 17:25:44 --> Total execution time: 1.1313
INFO - 2016-02-20 14:25:47 --> Config Class Initialized
INFO - 2016-02-20 14:25:47 --> Hooks Class Initialized
DEBUG - 2016-02-20 14:25:47 --> UTF-8 Support Enabled
INFO - 2016-02-20 14:25:47 --> Utf8 Class Initialized
INFO - 2016-02-20 14:25:47 --> URI Class Initialized
INFO - 2016-02-20 14:25:47 --> Router Class Initialized
INFO - 2016-02-20 14:25:47 --> Output Class Initialized
INFO - 2016-02-20 14:25:47 --> Security Class Initialized
DEBUG - 2016-02-20 14:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-20 14:25:47 --> Input Class Initialized
INFO - 2016-02-20 14:25:47 --> Language Class Initialized
INFO - 2016-02-20 14:25:47 --> Loader Class Initialized
INFO - 2016-02-20 14:25:47 --> Helper loaded: url_helper
INFO - 2016-02-20 14:25:47 --> Helper loaded: file_helper
INFO - 2016-02-20 14:25:47 --> Helper loaded: date_helper
INFO - 2016-02-20 14:25:47 --> Helper loaded: form_helper
INFO - 2016-02-20 14:25:47 --> Database Driver Class Initialized
INFO - 2016-02-20 14:25:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-20 14:25:48 --> Controller Class Initialized
INFO - 2016-02-20 14:25:48 --> Model Class Initialized
INFO - 2016-02-20 14:25:48 --> Model Class Initialized
INFO - 2016-02-20 14:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-20 14:25:48 --> Pagination Class Initialized
INFO - 2016-02-20 14:25:48 --> Helper loaded: text_helper
INFO - 2016-02-20 14:25:48 --> Helper loaded: cookie_helper
INFO - 2016-02-20 17:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-20 17:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-20 17:25:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-20 17:25:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-20 17:25:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-20 17:25:49 --> Final output sent to browser
DEBUG - 2016-02-20 17:25:49 --> Total execution time: 1.3719
