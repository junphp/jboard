<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-06 05:28:58 --> Config Class Initialized
INFO - 2016-03-06 05:28:58 --> Hooks Class Initialized
DEBUG - 2016-03-06 05:28:58 --> UTF-8 Support Enabled
INFO - 2016-03-06 05:28:58 --> Utf8 Class Initialized
INFO - 2016-03-06 05:28:58 --> URI Class Initialized
INFO - 2016-03-06 05:28:58 --> Router Class Initialized
INFO - 2016-03-06 05:28:58 --> Output Class Initialized
INFO - 2016-03-06 05:28:58 --> Security Class Initialized
DEBUG - 2016-03-06 05:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 05:28:58 --> Input Class Initialized
INFO - 2016-03-06 05:28:58 --> Language Class Initialized
INFO - 2016-03-06 05:28:58 --> Loader Class Initialized
INFO - 2016-03-06 05:28:58 --> Helper loaded: url_helper
INFO - 2016-03-06 05:28:58 --> Helper loaded: file_helper
INFO - 2016-03-06 05:28:58 --> Helper loaded: date_helper
INFO - 2016-03-06 05:28:58 --> Helper loaded: form_helper
INFO - 2016-03-06 05:28:58 --> Database Driver Class Initialized
INFO - 2016-03-06 05:28:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 05:28:59 --> Controller Class Initialized
INFO - 2016-03-06 05:28:59 --> Model Class Initialized
INFO - 2016-03-06 05:28:59 --> Model Class Initialized
INFO - 2016-03-06 05:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 05:28:59 --> Pagination Class Initialized
INFO - 2016-03-06 05:28:59 --> Helper loaded: text_helper
INFO - 2016-03-06 05:28:59 --> Helper loaded: cookie_helper
INFO - 2016-03-06 08:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 08:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 08:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 08:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 08:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 08:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 08:28:59 --> Final output sent to browser
DEBUG - 2016-03-06 08:28:59 --> Total execution time: 1.1789
INFO - 2016-03-06 05:29:10 --> Config Class Initialized
INFO - 2016-03-06 05:29:10 --> Hooks Class Initialized
DEBUG - 2016-03-06 05:29:10 --> UTF-8 Support Enabled
INFO - 2016-03-06 05:29:10 --> Utf8 Class Initialized
INFO - 2016-03-06 05:29:10 --> URI Class Initialized
INFO - 2016-03-06 05:29:10 --> Router Class Initialized
INFO - 2016-03-06 05:29:10 --> Output Class Initialized
INFO - 2016-03-06 05:29:10 --> Security Class Initialized
DEBUG - 2016-03-06 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 05:29:10 --> Input Class Initialized
INFO - 2016-03-06 05:29:10 --> Language Class Initialized
INFO - 2016-03-06 05:29:10 --> Loader Class Initialized
INFO - 2016-03-06 05:29:10 --> Helper loaded: url_helper
INFO - 2016-03-06 05:29:10 --> Helper loaded: file_helper
INFO - 2016-03-06 05:29:10 --> Helper loaded: date_helper
INFO - 2016-03-06 05:29:10 --> Helper loaded: form_helper
INFO - 2016-03-06 05:29:10 --> Database Driver Class Initialized
INFO - 2016-03-06 05:29:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 05:29:11 --> Controller Class Initialized
INFO - 2016-03-06 05:29:11 --> Model Class Initialized
INFO - 2016-03-06 05:29:11 --> Model Class Initialized
INFO - 2016-03-06 05:29:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 05:29:11 --> Pagination Class Initialized
INFO - 2016-03-06 05:29:11 --> Helper loaded: text_helper
INFO - 2016-03-06 05:29:11 --> Helper loaded: cookie_helper
INFO - 2016-03-06 08:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 08:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 08:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 08:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 08:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 08:29:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 08:29:11 --> Final output sent to browser
DEBUG - 2016-03-06 08:29:11 --> Total execution time: 1.2179
INFO - 2016-03-06 05:29:19 --> Config Class Initialized
INFO - 2016-03-06 05:29:19 --> Hooks Class Initialized
DEBUG - 2016-03-06 05:29:19 --> UTF-8 Support Enabled
INFO - 2016-03-06 05:29:19 --> Utf8 Class Initialized
INFO - 2016-03-06 05:29:19 --> URI Class Initialized
INFO - 2016-03-06 05:29:19 --> Router Class Initialized
INFO - 2016-03-06 05:29:19 --> Output Class Initialized
INFO - 2016-03-06 05:29:19 --> Security Class Initialized
DEBUG - 2016-03-06 05:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 05:29:19 --> Input Class Initialized
INFO - 2016-03-06 05:29:19 --> Language Class Initialized
INFO - 2016-03-06 05:29:19 --> Loader Class Initialized
INFO - 2016-03-06 05:29:19 --> Helper loaded: url_helper
INFO - 2016-03-06 05:29:19 --> Helper loaded: file_helper
INFO - 2016-03-06 05:29:19 --> Helper loaded: date_helper
INFO - 2016-03-06 05:29:19 --> Helper loaded: form_helper
INFO - 2016-03-06 05:29:19 --> Database Driver Class Initialized
INFO - 2016-03-06 05:29:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 05:29:20 --> Controller Class Initialized
INFO - 2016-03-06 05:29:20 --> Model Class Initialized
INFO - 2016-03-06 05:29:20 --> Model Class Initialized
INFO - 2016-03-06 05:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 05:29:20 --> Pagination Class Initialized
INFO - 2016-03-06 05:29:20 --> Helper loaded: text_helper
INFO - 2016-03-06 05:29:20 --> Helper loaded: cookie_helper
INFO - 2016-03-06 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 08:29:20 --> Final output sent to browser
DEBUG - 2016-03-06 08:29:20 --> Total execution time: 1.1705
INFO - 2016-03-06 05:37:32 --> Config Class Initialized
INFO - 2016-03-06 05:37:32 --> Hooks Class Initialized
DEBUG - 2016-03-06 05:37:32 --> UTF-8 Support Enabled
INFO - 2016-03-06 05:37:32 --> Utf8 Class Initialized
INFO - 2016-03-06 05:37:32 --> URI Class Initialized
INFO - 2016-03-06 05:37:32 --> Router Class Initialized
INFO - 2016-03-06 05:37:32 --> Output Class Initialized
INFO - 2016-03-06 05:37:32 --> Security Class Initialized
DEBUG - 2016-03-06 05:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 05:37:32 --> Input Class Initialized
INFO - 2016-03-06 05:37:32 --> Language Class Initialized
INFO - 2016-03-06 05:37:32 --> Loader Class Initialized
INFO - 2016-03-06 05:37:32 --> Helper loaded: url_helper
INFO - 2016-03-06 05:37:32 --> Helper loaded: file_helper
INFO - 2016-03-06 05:37:32 --> Helper loaded: date_helper
INFO - 2016-03-06 05:37:32 --> Helper loaded: form_helper
INFO - 2016-03-06 05:37:32 --> Database Driver Class Initialized
INFO - 2016-03-06 05:37:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 05:37:33 --> Controller Class Initialized
INFO - 2016-03-06 05:37:33 --> Model Class Initialized
INFO - 2016-03-06 05:37:33 --> Model Class Initialized
INFO - 2016-03-06 05:37:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 05:37:33 --> Pagination Class Initialized
INFO - 2016-03-06 05:37:33 --> Helper loaded: text_helper
INFO - 2016-03-06 05:37:33 --> Helper loaded: cookie_helper
INFO - 2016-03-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 08:37:33 --> Final output sent to browser
DEBUG - 2016-03-06 08:37:33 --> Total execution time: 1.2260
INFO - 2016-03-06 05:38:16 --> Config Class Initialized
INFO - 2016-03-06 05:38:16 --> Hooks Class Initialized
DEBUG - 2016-03-06 05:38:16 --> UTF-8 Support Enabled
INFO - 2016-03-06 05:38:16 --> Utf8 Class Initialized
INFO - 2016-03-06 05:38:16 --> URI Class Initialized
INFO - 2016-03-06 05:38:16 --> Router Class Initialized
INFO - 2016-03-06 05:38:16 --> Output Class Initialized
INFO - 2016-03-06 05:38:16 --> Security Class Initialized
DEBUG - 2016-03-06 05:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 05:38:16 --> Input Class Initialized
INFO - 2016-03-06 05:38:16 --> Language Class Initialized
INFO - 2016-03-06 05:38:16 --> Loader Class Initialized
INFO - 2016-03-06 05:38:16 --> Helper loaded: url_helper
INFO - 2016-03-06 05:38:16 --> Helper loaded: file_helper
INFO - 2016-03-06 05:38:16 --> Helper loaded: date_helper
INFO - 2016-03-06 05:38:16 --> Helper loaded: form_helper
INFO - 2016-03-06 05:38:16 --> Database Driver Class Initialized
INFO - 2016-03-06 05:38:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 05:38:17 --> Controller Class Initialized
INFO - 2016-03-06 05:38:17 --> Model Class Initialized
INFO - 2016-03-06 05:38:17 --> Model Class Initialized
INFO - 2016-03-06 05:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 05:38:17 --> Pagination Class Initialized
INFO - 2016-03-06 05:38:17 --> Helper loaded: text_helper
INFO - 2016-03-06 05:38:17 --> Helper loaded: cookie_helper
INFO - 2016-03-06 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 08:38:17 --> Final output sent to browser
DEBUG - 2016-03-06 08:38:17 --> Total execution time: 1.1941
INFO - 2016-03-06 06:13:05 --> Config Class Initialized
INFO - 2016-03-06 06:13:05 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:13:05 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:13:05 --> Utf8 Class Initialized
INFO - 2016-03-06 06:13:05 --> URI Class Initialized
INFO - 2016-03-06 06:13:05 --> Router Class Initialized
INFO - 2016-03-06 06:13:05 --> Output Class Initialized
INFO - 2016-03-06 06:13:05 --> Security Class Initialized
DEBUG - 2016-03-06 06:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:13:05 --> Input Class Initialized
INFO - 2016-03-06 06:13:05 --> Language Class Initialized
INFO - 2016-03-06 06:13:05 --> Loader Class Initialized
INFO - 2016-03-06 06:13:05 --> Helper loaded: url_helper
INFO - 2016-03-06 06:13:06 --> Helper loaded: file_helper
INFO - 2016-03-06 06:13:06 --> Helper loaded: date_helper
INFO - 2016-03-06 06:13:06 --> Helper loaded: form_helper
INFO - 2016-03-06 06:13:06 --> Database Driver Class Initialized
INFO - 2016-03-06 06:13:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:13:07 --> Controller Class Initialized
INFO - 2016-03-06 06:13:07 --> Model Class Initialized
INFO - 2016-03-06 06:13:07 --> Model Class Initialized
INFO - 2016-03-06 06:13:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:13:07 --> Pagination Class Initialized
INFO - 2016-03-06 06:13:07 --> Helper loaded: text_helper
INFO - 2016-03-06 06:13:07 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:13:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:13:07 --> Final output sent to browser
DEBUG - 2016-03-06 09:13:07 --> Total execution time: 1.1476
INFO - 2016-03-06 06:13:20 --> Config Class Initialized
INFO - 2016-03-06 06:13:20 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:13:20 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:13:20 --> Utf8 Class Initialized
INFO - 2016-03-06 06:13:20 --> URI Class Initialized
INFO - 2016-03-06 06:13:20 --> Router Class Initialized
INFO - 2016-03-06 06:13:20 --> Output Class Initialized
INFO - 2016-03-06 06:13:20 --> Security Class Initialized
DEBUG - 2016-03-06 06:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:13:20 --> Input Class Initialized
INFO - 2016-03-06 06:13:20 --> Language Class Initialized
INFO - 2016-03-06 06:13:20 --> Loader Class Initialized
INFO - 2016-03-06 06:13:20 --> Helper loaded: url_helper
INFO - 2016-03-06 06:13:20 --> Helper loaded: file_helper
INFO - 2016-03-06 06:13:20 --> Helper loaded: date_helper
INFO - 2016-03-06 06:13:20 --> Helper loaded: form_helper
INFO - 2016-03-06 06:13:20 --> Database Driver Class Initialized
INFO - 2016-03-06 06:13:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:13:21 --> Controller Class Initialized
INFO - 2016-03-06 06:13:21 --> Model Class Initialized
INFO - 2016-03-06 06:13:21 --> Model Class Initialized
INFO - 2016-03-06 06:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:13:21 --> Pagination Class Initialized
INFO - 2016-03-06 06:13:21 --> Helper loaded: text_helper
INFO - 2016-03-06 06:13:21 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:13:21 --> Final output sent to browser
DEBUG - 2016-03-06 09:13:21 --> Total execution time: 1.1835
INFO - 2016-03-06 06:17:05 --> Config Class Initialized
INFO - 2016-03-06 06:17:05 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:17:05 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:17:05 --> Utf8 Class Initialized
INFO - 2016-03-06 06:17:05 --> URI Class Initialized
INFO - 2016-03-06 06:17:05 --> Router Class Initialized
INFO - 2016-03-06 06:17:05 --> Output Class Initialized
INFO - 2016-03-06 06:17:05 --> Security Class Initialized
DEBUG - 2016-03-06 06:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:17:05 --> Input Class Initialized
INFO - 2016-03-06 06:17:05 --> Language Class Initialized
INFO - 2016-03-06 06:17:05 --> Loader Class Initialized
INFO - 2016-03-06 06:17:05 --> Helper loaded: url_helper
INFO - 2016-03-06 06:17:05 --> Helper loaded: file_helper
INFO - 2016-03-06 06:17:05 --> Helper loaded: date_helper
INFO - 2016-03-06 06:17:05 --> Helper loaded: form_helper
INFO - 2016-03-06 06:17:05 --> Database Driver Class Initialized
INFO - 2016-03-06 06:17:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:17:06 --> Controller Class Initialized
INFO - 2016-03-06 06:17:06 --> Model Class Initialized
INFO - 2016-03-06 06:17:06 --> Model Class Initialized
INFO - 2016-03-06 06:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:17:06 --> Pagination Class Initialized
INFO - 2016-03-06 06:17:06 --> Helper loaded: text_helper
INFO - 2016-03-06 06:17:06 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:17:06 --> Final output sent to browser
DEBUG - 2016-03-06 09:17:06 --> Total execution time: 1.1523
INFO - 2016-03-06 06:19:09 --> Config Class Initialized
INFO - 2016-03-06 06:19:09 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:19:09 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:19:09 --> Utf8 Class Initialized
INFO - 2016-03-06 06:19:09 --> URI Class Initialized
INFO - 2016-03-06 06:19:09 --> Router Class Initialized
INFO - 2016-03-06 06:19:09 --> Output Class Initialized
INFO - 2016-03-06 06:19:09 --> Security Class Initialized
DEBUG - 2016-03-06 06:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:19:09 --> Input Class Initialized
INFO - 2016-03-06 06:19:09 --> Language Class Initialized
INFO - 2016-03-06 06:19:09 --> Loader Class Initialized
INFO - 2016-03-06 06:19:09 --> Helper loaded: url_helper
INFO - 2016-03-06 06:19:09 --> Helper loaded: file_helper
INFO - 2016-03-06 06:19:09 --> Helper loaded: date_helper
INFO - 2016-03-06 06:19:09 --> Helper loaded: form_helper
INFO - 2016-03-06 06:19:09 --> Database Driver Class Initialized
INFO - 2016-03-06 06:19:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:19:10 --> Controller Class Initialized
INFO - 2016-03-06 06:19:10 --> Model Class Initialized
INFO - 2016-03-06 06:19:10 --> Model Class Initialized
INFO - 2016-03-06 06:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:19:10 --> Pagination Class Initialized
INFO - 2016-03-06 06:19:10 --> Helper loaded: text_helper
INFO - 2016-03-06 06:19:10 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:19:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:19:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:19:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:19:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:19:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:19:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:19:10 --> Final output sent to browser
DEBUG - 2016-03-06 09:19:10 --> Total execution time: 1.2157
INFO - 2016-03-06 06:19:34 --> Config Class Initialized
INFO - 2016-03-06 06:19:34 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:19:34 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:19:34 --> Utf8 Class Initialized
INFO - 2016-03-06 06:19:34 --> URI Class Initialized
INFO - 2016-03-06 06:19:34 --> Router Class Initialized
INFO - 2016-03-06 06:19:34 --> Output Class Initialized
INFO - 2016-03-06 06:19:34 --> Security Class Initialized
DEBUG - 2016-03-06 06:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:19:34 --> Input Class Initialized
INFO - 2016-03-06 06:19:34 --> Language Class Initialized
INFO - 2016-03-06 06:19:34 --> Loader Class Initialized
INFO - 2016-03-06 06:19:34 --> Helper loaded: url_helper
INFO - 2016-03-06 06:19:34 --> Helper loaded: file_helper
INFO - 2016-03-06 06:19:34 --> Helper loaded: date_helper
INFO - 2016-03-06 06:19:34 --> Helper loaded: form_helper
INFO - 2016-03-06 06:19:34 --> Database Driver Class Initialized
INFO - 2016-03-06 06:19:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:19:35 --> Controller Class Initialized
INFO - 2016-03-06 06:19:35 --> Model Class Initialized
INFO - 2016-03-06 06:19:35 --> Model Class Initialized
INFO - 2016-03-06 06:19:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:19:35 --> Pagination Class Initialized
INFO - 2016-03-06 06:19:35 --> Helper loaded: text_helper
INFO - 2016-03-06 06:19:35 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:19:35 --> Final output sent to browser
DEBUG - 2016-03-06 09:19:35 --> Total execution time: 1.2596
INFO - 2016-03-06 06:20:13 --> Config Class Initialized
INFO - 2016-03-06 06:20:13 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:20:13 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:20:13 --> Utf8 Class Initialized
INFO - 2016-03-06 06:20:13 --> URI Class Initialized
INFO - 2016-03-06 06:20:13 --> Router Class Initialized
INFO - 2016-03-06 06:20:13 --> Output Class Initialized
INFO - 2016-03-06 06:20:13 --> Security Class Initialized
DEBUG - 2016-03-06 06:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:20:13 --> Input Class Initialized
INFO - 2016-03-06 06:20:13 --> Language Class Initialized
INFO - 2016-03-06 06:20:13 --> Loader Class Initialized
INFO - 2016-03-06 06:20:13 --> Helper loaded: url_helper
INFO - 2016-03-06 06:20:13 --> Helper loaded: file_helper
INFO - 2016-03-06 06:20:13 --> Helper loaded: date_helper
INFO - 2016-03-06 06:20:13 --> Helper loaded: form_helper
INFO - 2016-03-06 06:20:13 --> Database Driver Class Initialized
INFO - 2016-03-06 06:20:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:20:14 --> Controller Class Initialized
INFO - 2016-03-06 06:20:14 --> Model Class Initialized
INFO - 2016-03-06 06:20:14 --> Model Class Initialized
INFO - 2016-03-06 06:20:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:20:14 --> Pagination Class Initialized
INFO - 2016-03-06 06:20:14 --> Helper loaded: text_helper
INFO - 2016-03-06 06:20:14 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:20:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:20:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:20:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:20:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:20:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:20:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:20:14 --> Final output sent to browser
DEBUG - 2016-03-06 09:20:14 --> Total execution time: 1.1660
INFO - 2016-03-06 06:20:27 --> Config Class Initialized
INFO - 2016-03-06 06:20:27 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:20:27 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:20:27 --> Utf8 Class Initialized
INFO - 2016-03-06 06:20:27 --> URI Class Initialized
INFO - 2016-03-06 06:20:27 --> Router Class Initialized
INFO - 2016-03-06 06:20:27 --> Output Class Initialized
INFO - 2016-03-06 06:20:27 --> Security Class Initialized
DEBUG - 2016-03-06 06:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:20:27 --> Input Class Initialized
INFO - 2016-03-06 06:20:27 --> Language Class Initialized
INFO - 2016-03-06 06:20:27 --> Loader Class Initialized
INFO - 2016-03-06 06:20:27 --> Helper loaded: url_helper
INFO - 2016-03-06 06:20:27 --> Helper loaded: file_helper
INFO - 2016-03-06 06:20:27 --> Helper loaded: date_helper
INFO - 2016-03-06 06:20:27 --> Helper loaded: form_helper
INFO - 2016-03-06 06:20:27 --> Database Driver Class Initialized
INFO - 2016-03-06 06:20:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:20:28 --> Controller Class Initialized
INFO - 2016-03-06 06:20:28 --> Model Class Initialized
INFO - 2016-03-06 06:20:28 --> Model Class Initialized
INFO - 2016-03-06 06:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:20:28 --> Pagination Class Initialized
INFO - 2016-03-06 06:20:28 --> Helper loaded: text_helper
INFO - 2016-03-06 06:20:28 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:20:28 --> Final output sent to browser
DEBUG - 2016-03-06 09:20:28 --> Total execution time: 1.1509
INFO - 2016-03-06 06:20:39 --> Config Class Initialized
INFO - 2016-03-06 06:20:39 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:20:39 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:20:39 --> Utf8 Class Initialized
INFO - 2016-03-06 06:20:39 --> URI Class Initialized
INFO - 2016-03-06 06:20:39 --> Router Class Initialized
INFO - 2016-03-06 06:20:39 --> Output Class Initialized
INFO - 2016-03-06 06:20:39 --> Security Class Initialized
DEBUG - 2016-03-06 06:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:20:39 --> Input Class Initialized
INFO - 2016-03-06 06:20:39 --> Language Class Initialized
INFO - 2016-03-06 06:20:39 --> Loader Class Initialized
INFO - 2016-03-06 06:20:39 --> Helper loaded: url_helper
INFO - 2016-03-06 06:20:39 --> Helper loaded: file_helper
INFO - 2016-03-06 06:20:39 --> Helper loaded: date_helper
INFO - 2016-03-06 06:20:39 --> Helper loaded: form_helper
INFO - 2016-03-06 06:20:39 --> Database Driver Class Initialized
INFO - 2016-03-06 06:20:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:20:40 --> Controller Class Initialized
INFO - 2016-03-06 06:20:40 --> Model Class Initialized
INFO - 2016-03-06 06:20:40 --> Model Class Initialized
INFO - 2016-03-06 06:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:20:40 --> Pagination Class Initialized
INFO - 2016-03-06 06:20:40 --> Helper loaded: text_helper
INFO - 2016-03-06 06:20:40 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 09:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 09:20:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:20:40 --> Final output sent to browser
DEBUG - 2016-03-06 09:20:40 --> Total execution time: 1.1197
INFO - 2016-03-06 06:21:03 --> Config Class Initialized
INFO - 2016-03-06 06:21:03 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:21:03 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:21:03 --> Utf8 Class Initialized
INFO - 2016-03-06 06:21:03 --> URI Class Initialized
INFO - 2016-03-06 06:21:03 --> Router Class Initialized
INFO - 2016-03-06 06:21:03 --> Output Class Initialized
INFO - 2016-03-06 06:21:03 --> Security Class Initialized
DEBUG - 2016-03-06 06:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:21:03 --> Input Class Initialized
INFO - 2016-03-06 06:21:03 --> Language Class Initialized
INFO - 2016-03-06 06:21:03 --> Loader Class Initialized
INFO - 2016-03-06 06:21:03 --> Helper loaded: url_helper
INFO - 2016-03-06 06:21:03 --> Helper loaded: file_helper
INFO - 2016-03-06 06:21:03 --> Helper loaded: date_helper
INFO - 2016-03-06 06:21:03 --> Helper loaded: form_helper
INFO - 2016-03-06 06:21:03 --> Database Driver Class Initialized
INFO - 2016-03-06 06:21:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:21:04 --> Controller Class Initialized
INFO - 2016-03-06 06:21:04 --> Model Class Initialized
INFO - 2016-03-06 06:21:04 --> Model Class Initialized
INFO - 2016-03-06 06:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:21:04 --> Pagination Class Initialized
INFO - 2016-03-06 06:21:04 --> Helper loaded: text_helper
INFO - 2016-03-06 06:21:04 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 09:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 09:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:21:04 --> Final output sent to browser
DEBUG - 2016-03-06 09:21:04 --> Total execution time: 1.1405
INFO - 2016-03-06 06:21:11 --> Config Class Initialized
INFO - 2016-03-06 06:21:11 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:21:11 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:21:11 --> Utf8 Class Initialized
INFO - 2016-03-06 06:21:11 --> URI Class Initialized
INFO - 2016-03-06 06:21:11 --> Router Class Initialized
INFO - 2016-03-06 06:21:11 --> Output Class Initialized
INFO - 2016-03-06 06:21:11 --> Security Class Initialized
DEBUG - 2016-03-06 06:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:21:11 --> Input Class Initialized
INFO - 2016-03-06 06:21:11 --> Language Class Initialized
INFO - 2016-03-06 06:21:12 --> Loader Class Initialized
INFO - 2016-03-06 06:21:12 --> Helper loaded: url_helper
INFO - 2016-03-06 06:21:12 --> Helper loaded: file_helper
INFO - 2016-03-06 06:21:12 --> Helper loaded: date_helper
INFO - 2016-03-06 06:21:12 --> Helper loaded: form_helper
INFO - 2016-03-06 06:21:12 --> Database Driver Class Initialized
INFO - 2016-03-06 06:21:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:21:13 --> Controller Class Initialized
INFO - 2016-03-06 06:21:13 --> Model Class Initialized
INFO - 2016-03-06 06:21:13 --> Model Class Initialized
INFO - 2016-03-06 06:21:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:21:13 --> Pagination Class Initialized
INFO - 2016-03-06 06:21:13 --> Helper loaded: text_helper
INFO - 2016-03-06 06:21:13 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:21:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:21:13 --> Final output sent to browser
DEBUG - 2016-03-06 09:21:13 --> Total execution time: 1.1560
INFO - 2016-03-06 06:21:48 --> Config Class Initialized
INFO - 2016-03-06 06:21:48 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:21:48 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:21:48 --> Utf8 Class Initialized
INFO - 2016-03-06 06:21:48 --> URI Class Initialized
INFO - 2016-03-06 06:21:48 --> Router Class Initialized
INFO - 2016-03-06 06:21:48 --> Output Class Initialized
INFO - 2016-03-06 06:21:48 --> Security Class Initialized
DEBUG - 2016-03-06 06:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:21:48 --> Input Class Initialized
INFO - 2016-03-06 06:21:48 --> Language Class Initialized
INFO - 2016-03-06 06:21:48 --> Loader Class Initialized
INFO - 2016-03-06 06:21:48 --> Helper loaded: url_helper
INFO - 2016-03-06 06:21:48 --> Helper loaded: file_helper
INFO - 2016-03-06 06:21:48 --> Helper loaded: date_helper
INFO - 2016-03-06 06:21:48 --> Helper loaded: form_helper
INFO - 2016-03-06 06:21:48 --> Database Driver Class Initialized
INFO - 2016-03-06 06:21:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:21:49 --> Controller Class Initialized
INFO - 2016-03-06 06:21:49 --> Model Class Initialized
INFO - 2016-03-06 06:21:49 --> Model Class Initialized
INFO - 2016-03-06 06:21:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:21:49 --> Pagination Class Initialized
INFO - 2016-03-06 06:21:49 --> Helper loaded: text_helper
INFO - 2016-03-06 06:21:49 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:21:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:21:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:21:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:21:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:21:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:21:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:21:49 --> Final output sent to browser
DEBUG - 2016-03-06 09:21:49 --> Total execution time: 1.2053
INFO - 2016-03-06 06:24:01 --> Config Class Initialized
INFO - 2016-03-06 06:24:01 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:24:01 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:24:01 --> Utf8 Class Initialized
INFO - 2016-03-06 06:24:01 --> URI Class Initialized
INFO - 2016-03-06 06:24:01 --> Router Class Initialized
INFO - 2016-03-06 06:24:01 --> Output Class Initialized
INFO - 2016-03-06 06:24:01 --> Security Class Initialized
DEBUG - 2016-03-06 06:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:24:01 --> Input Class Initialized
INFO - 2016-03-06 06:24:01 --> Language Class Initialized
INFO - 2016-03-06 06:24:01 --> Loader Class Initialized
INFO - 2016-03-06 06:24:01 --> Helper loaded: url_helper
INFO - 2016-03-06 06:24:01 --> Helper loaded: file_helper
INFO - 2016-03-06 06:24:01 --> Helper loaded: date_helper
INFO - 2016-03-06 06:24:01 --> Helper loaded: form_helper
INFO - 2016-03-06 06:24:01 --> Database Driver Class Initialized
INFO - 2016-03-06 06:24:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:24:02 --> Controller Class Initialized
INFO - 2016-03-06 06:24:02 --> Model Class Initialized
INFO - 2016-03-06 06:24:02 --> Model Class Initialized
INFO - 2016-03-06 06:24:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:24:02 --> Pagination Class Initialized
INFO - 2016-03-06 06:24:02 --> Helper loaded: text_helper
INFO - 2016-03-06 06:24:02 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:24:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:24:02 --> Final output sent to browser
DEBUG - 2016-03-06 09:24:02 --> Total execution time: 1.2337
INFO - 2016-03-06 06:26:11 --> Config Class Initialized
INFO - 2016-03-06 06:26:11 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:26:11 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:26:11 --> Utf8 Class Initialized
INFO - 2016-03-06 06:26:11 --> URI Class Initialized
INFO - 2016-03-06 06:26:11 --> Router Class Initialized
INFO - 2016-03-06 06:26:11 --> Output Class Initialized
INFO - 2016-03-06 06:26:11 --> Security Class Initialized
DEBUG - 2016-03-06 06:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:26:11 --> Input Class Initialized
INFO - 2016-03-06 06:26:11 --> Language Class Initialized
INFO - 2016-03-06 06:26:11 --> Loader Class Initialized
INFO - 2016-03-06 06:26:11 --> Helper loaded: url_helper
INFO - 2016-03-06 06:26:11 --> Helper loaded: file_helper
INFO - 2016-03-06 06:26:11 --> Helper loaded: date_helper
INFO - 2016-03-06 06:26:11 --> Helper loaded: form_helper
INFO - 2016-03-06 06:26:11 --> Database Driver Class Initialized
INFO - 2016-03-06 06:26:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:26:12 --> Controller Class Initialized
INFO - 2016-03-06 06:26:12 --> Model Class Initialized
INFO - 2016-03-06 06:26:12 --> Model Class Initialized
INFO - 2016-03-06 06:26:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:26:12 --> Pagination Class Initialized
INFO - 2016-03-06 06:26:12 --> Helper loaded: text_helper
INFO - 2016-03-06 06:26:12 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:26:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:26:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:26:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:26:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:26:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:26:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:26:12 --> Final output sent to browser
DEBUG - 2016-03-06 09:26:12 --> Total execution time: 1.2228
INFO - 2016-03-06 06:26:59 --> Config Class Initialized
INFO - 2016-03-06 06:26:59 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:26:59 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:26:59 --> Utf8 Class Initialized
INFO - 2016-03-06 06:26:59 --> URI Class Initialized
INFO - 2016-03-06 06:26:59 --> Router Class Initialized
INFO - 2016-03-06 06:26:59 --> Output Class Initialized
INFO - 2016-03-06 06:26:59 --> Security Class Initialized
DEBUG - 2016-03-06 06:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:26:59 --> Input Class Initialized
INFO - 2016-03-06 06:26:59 --> Language Class Initialized
INFO - 2016-03-06 06:26:59 --> Loader Class Initialized
INFO - 2016-03-06 06:26:59 --> Helper loaded: url_helper
INFO - 2016-03-06 06:26:59 --> Helper loaded: file_helper
INFO - 2016-03-06 06:26:59 --> Helper loaded: date_helper
INFO - 2016-03-06 06:26:59 --> Helper loaded: form_helper
INFO - 2016-03-06 06:26:59 --> Database Driver Class Initialized
INFO - 2016-03-06 06:27:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:27:00 --> Controller Class Initialized
INFO - 2016-03-06 06:27:00 --> Model Class Initialized
INFO - 2016-03-06 06:27:00 --> Model Class Initialized
INFO - 2016-03-06 06:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:27:00 --> Pagination Class Initialized
INFO - 2016-03-06 06:27:00 --> Helper loaded: text_helper
INFO - 2016-03-06 06:27:00 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:27:00 --> Final output sent to browser
DEBUG - 2016-03-06 09:27:00 --> Total execution time: 1.2398
INFO - 2016-03-06 06:30:27 --> Config Class Initialized
INFO - 2016-03-06 06:30:27 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:30:27 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:30:27 --> Utf8 Class Initialized
INFO - 2016-03-06 06:30:27 --> URI Class Initialized
INFO - 2016-03-06 06:30:27 --> Router Class Initialized
INFO - 2016-03-06 06:30:27 --> Output Class Initialized
INFO - 2016-03-06 06:30:27 --> Security Class Initialized
DEBUG - 2016-03-06 06:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:30:27 --> Input Class Initialized
INFO - 2016-03-06 06:30:27 --> Language Class Initialized
INFO - 2016-03-06 06:30:27 --> Loader Class Initialized
INFO - 2016-03-06 06:30:27 --> Helper loaded: url_helper
INFO - 2016-03-06 06:30:27 --> Helper loaded: file_helper
INFO - 2016-03-06 06:30:27 --> Helper loaded: date_helper
INFO - 2016-03-06 06:30:27 --> Helper loaded: form_helper
INFO - 2016-03-06 06:30:27 --> Database Driver Class Initialized
INFO - 2016-03-06 06:30:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:30:28 --> Controller Class Initialized
INFO - 2016-03-06 06:30:28 --> Model Class Initialized
INFO - 2016-03-06 06:30:28 --> Model Class Initialized
INFO - 2016-03-06 06:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:30:28 --> Pagination Class Initialized
INFO - 2016-03-06 06:30:28 --> Helper loaded: text_helper
INFO - 2016-03-06 06:30:28 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:30:28 --> Final output sent to browser
DEBUG - 2016-03-06 09:30:28 --> Total execution time: 1.1970
INFO - 2016-03-06 06:30:45 --> Config Class Initialized
INFO - 2016-03-06 06:30:45 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:30:45 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:30:45 --> Utf8 Class Initialized
INFO - 2016-03-06 06:30:45 --> URI Class Initialized
INFO - 2016-03-06 06:30:45 --> Router Class Initialized
INFO - 2016-03-06 06:30:45 --> Output Class Initialized
INFO - 2016-03-06 06:30:45 --> Security Class Initialized
DEBUG - 2016-03-06 06:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:30:45 --> Input Class Initialized
INFO - 2016-03-06 06:30:45 --> Language Class Initialized
INFO - 2016-03-06 06:30:45 --> Loader Class Initialized
INFO - 2016-03-06 06:30:45 --> Helper loaded: url_helper
INFO - 2016-03-06 06:30:45 --> Helper loaded: file_helper
INFO - 2016-03-06 06:30:45 --> Helper loaded: date_helper
INFO - 2016-03-06 06:30:45 --> Helper loaded: form_helper
INFO - 2016-03-06 06:30:45 --> Database Driver Class Initialized
INFO - 2016-03-06 06:30:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:30:46 --> Controller Class Initialized
INFO - 2016-03-06 06:30:46 --> Model Class Initialized
INFO - 2016-03-06 06:30:46 --> Model Class Initialized
INFO - 2016-03-06 06:30:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:30:46 --> Pagination Class Initialized
INFO - 2016-03-06 06:30:46 --> Helper loaded: text_helper
INFO - 2016-03-06 06:30:46 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:30:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:30:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:30:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 09:30:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 09:30:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:30:46 --> Final output sent to browser
DEBUG - 2016-03-06 09:30:46 --> Total execution time: 1.1178
INFO - 2016-03-06 06:31:04 --> Config Class Initialized
INFO - 2016-03-06 06:31:04 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:31:04 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:31:04 --> Utf8 Class Initialized
INFO - 2016-03-06 06:31:04 --> URI Class Initialized
INFO - 2016-03-06 06:31:04 --> Router Class Initialized
INFO - 2016-03-06 06:31:04 --> Output Class Initialized
INFO - 2016-03-06 06:31:04 --> Security Class Initialized
DEBUG - 2016-03-06 06:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:31:04 --> Input Class Initialized
INFO - 2016-03-06 06:31:04 --> Language Class Initialized
INFO - 2016-03-06 06:31:04 --> Loader Class Initialized
INFO - 2016-03-06 06:31:04 --> Helper loaded: url_helper
INFO - 2016-03-06 06:31:04 --> Helper loaded: file_helper
INFO - 2016-03-06 06:31:04 --> Helper loaded: date_helper
INFO - 2016-03-06 06:31:04 --> Helper loaded: form_helper
INFO - 2016-03-06 06:31:04 --> Database Driver Class Initialized
INFO - 2016-03-06 06:31:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:31:05 --> Controller Class Initialized
INFO - 2016-03-06 06:31:05 --> Model Class Initialized
INFO - 2016-03-06 06:31:05 --> Model Class Initialized
INFO - 2016-03-06 06:31:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:31:05 --> Pagination Class Initialized
INFO - 2016-03-06 06:31:05 --> Helper loaded: text_helper
INFO - 2016-03-06 06:31:05 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:31:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:31:05 --> Final output sent to browser
DEBUG - 2016-03-06 09:31:05 --> Total execution time: 1.1759
INFO - 2016-03-06 06:31:08 --> Config Class Initialized
INFO - 2016-03-06 06:31:08 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:31:08 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:31:08 --> Utf8 Class Initialized
INFO - 2016-03-06 06:31:08 --> URI Class Initialized
DEBUG - 2016-03-06 06:31:08 --> No URI present. Default controller set.
INFO - 2016-03-06 06:31:08 --> Router Class Initialized
INFO - 2016-03-06 06:31:08 --> Output Class Initialized
INFO - 2016-03-06 06:31:08 --> Security Class Initialized
DEBUG - 2016-03-06 06:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:31:08 --> Input Class Initialized
INFO - 2016-03-06 06:31:08 --> Language Class Initialized
INFO - 2016-03-06 06:31:08 --> Loader Class Initialized
INFO - 2016-03-06 06:31:08 --> Helper loaded: url_helper
INFO - 2016-03-06 06:31:08 --> Helper loaded: file_helper
INFO - 2016-03-06 06:31:08 --> Helper loaded: date_helper
INFO - 2016-03-06 06:31:08 --> Helper loaded: form_helper
INFO - 2016-03-06 06:31:08 --> Database Driver Class Initialized
INFO - 2016-03-06 06:31:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:31:09 --> Controller Class Initialized
INFO - 2016-03-06 06:31:09 --> Model Class Initialized
INFO - 2016-03-06 06:31:09 --> Model Class Initialized
INFO - 2016-03-06 06:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:31:09 --> Pagination Class Initialized
INFO - 2016-03-06 06:31:09 --> Helper loaded: text_helper
INFO - 2016-03-06 06:31:09 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 09:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:31:09 --> Final output sent to browser
DEBUG - 2016-03-06 09:31:09 --> Total execution time: 1.1032
INFO - 2016-03-06 06:31:13 --> Config Class Initialized
INFO - 2016-03-06 06:31:13 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:31:13 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:31:13 --> Utf8 Class Initialized
INFO - 2016-03-06 06:31:13 --> URI Class Initialized
INFO - 2016-03-06 06:31:13 --> Router Class Initialized
INFO - 2016-03-06 06:31:13 --> Output Class Initialized
INFO - 2016-03-06 06:31:13 --> Security Class Initialized
DEBUG - 2016-03-06 06:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:31:13 --> Input Class Initialized
INFO - 2016-03-06 06:31:13 --> Language Class Initialized
INFO - 2016-03-06 06:31:13 --> Loader Class Initialized
INFO - 2016-03-06 06:31:13 --> Helper loaded: url_helper
INFO - 2016-03-06 06:31:13 --> Helper loaded: file_helper
INFO - 2016-03-06 06:31:13 --> Helper loaded: date_helper
INFO - 2016-03-06 06:31:13 --> Helper loaded: form_helper
INFO - 2016-03-06 06:31:13 --> Database Driver Class Initialized
INFO - 2016-03-06 06:31:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:31:14 --> Controller Class Initialized
INFO - 2016-03-06 06:31:14 --> Model Class Initialized
INFO - 2016-03-06 06:31:14 --> Model Class Initialized
INFO - 2016-03-06 06:31:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:31:14 --> Pagination Class Initialized
INFO - 2016-03-06 06:31:14 --> Helper loaded: text_helper
INFO - 2016-03-06 06:31:14 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 09:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 09:31:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:31:14 --> Final output sent to browser
DEBUG - 2016-03-06 09:31:14 --> Total execution time: 1.1127
INFO - 2016-03-06 06:32:19 --> Config Class Initialized
INFO - 2016-03-06 06:32:19 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:32:19 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:32:19 --> Utf8 Class Initialized
INFO - 2016-03-06 06:32:19 --> URI Class Initialized
INFO - 2016-03-06 06:32:19 --> Router Class Initialized
INFO - 2016-03-06 06:32:19 --> Output Class Initialized
INFO - 2016-03-06 06:32:19 --> Security Class Initialized
DEBUG - 2016-03-06 06:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:32:19 --> Input Class Initialized
INFO - 2016-03-06 06:32:19 --> Language Class Initialized
INFO - 2016-03-06 06:32:19 --> Loader Class Initialized
INFO - 2016-03-06 06:32:19 --> Helper loaded: url_helper
INFO - 2016-03-06 06:32:19 --> Helper loaded: file_helper
INFO - 2016-03-06 06:32:19 --> Helper loaded: date_helper
INFO - 2016-03-06 06:32:19 --> Helper loaded: form_helper
INFO - 2016-03-06 06:32:19 --> Database Driver Class Initialized
INFO - 2016-03-06 06:32:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:32:20 --> Controller Class Initialized
INFO - 2016-03-06 06:32:20 --> Model Class Initialized
INFO - 2016-03-06 06:32:20 --> Model Class Initialized
INFO - 2016-03-06 06:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:32:20 --> Pagination Class Initialized
INFO - 2016-03-06 06:32:20 --> Helper loaded: text_helper
INFO - 2016-03-06 06:32:20 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 09:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 09:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:32:20 --> Final output sent to browser
DEBUG - 2016-03-06 09:32:20 --> Total execution time: 1.1922
INFO - 2016-03-06 06:33:00 --> Config Class Initialized
INFO - 2016-03-06 06:33:00 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:33:00 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:33:00 --> Utf8 Class Initialized
INFO - 2016-03-06 06:33:00 --> URI Class Initialized
INFO - 2016-03-06 06:33:00 --> Router Class Initialized
INFO - 2016-03-06 06:33:00 --> Output Class Initialized
INFO - 2016-03-06 06:33:00 --> Security Class Initialized
DEBUG - 2016-03-06 06:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:33:00 --> Input Class Initialized
INFO - 2016-03-06 06:33:00 --> Language Class Initialized
INFO - 2016-03-06 06:33:00 --> Loader Class Initialized
INFO - 2016-03-06 06:33:00 --> Helper loaded: url_helper
INFO - 2016-03-06 06:33:00 --> Helper loaded: file_helper
INFO - 2016-03-06 06:33:00 --> Helper loaded: date_helper
INFO - 2016-03-06 06:33:00 --> Helper loaded: form_helper
INFO - 2016-03-06 06:33:00 --> Database Driver Class Initialized
INFO - 2016-03-06 06:33:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:33:01 --> Controller Class Initialized
INFO - 2016-03-06 06:33:01 --> Model Class Initialized
INFO - 2016-03-06 06:33:01 --> Model Class Initialized
INFO - 2016-03-06 06:33:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:33:01 --> Pagination Class Initialized
INFO - 2016-03-06 06:33:01 --> Helper loaded: text_helper
INFO - 2016-03-06 06:33:01 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:33:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:33:01 --> Final output sent to browser
DEBUG - 2016-03-06 09:33:01 --> Total execution time: 1.1779
INFO - 2016-03-06 06:34:08 --> Config Class Initialized
INFO - 2016-03-06 06:34:08 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:34:08 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:34:08 --> Utf8 Class Initialized
INFO - 2016-03-06 06:34:08 --> URI Class Initialized
INFO - 2016-03-06 06:34:08 --> Router Class Initialized
INFO - 2016-03-06 06:34:08 --> Output Class Initialized
INFO - 2016-03-06 06:34:08 --> Security Class Initialized
DEBUG - 2016-03-06 06:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:34:08 --> Input Class Initialized
INFO - 2016-03-06 06:34:08 --> Language Class Initialized
INFO - 2016-03-06 06:34:08 --> Loader Class Initialized
INFO - 2016-03-06 06:34:08 --> Helper loaded: url_helper
INFO - 2016-03-06 06:34:08 --> Helper loaded: file_helper
INFO - 2016-03-06 06:34:08 --> Helper loaded: date_helper
INFO - 2016-03-06 06:34:08 --> Helper loaded: form_helper
INFO - 2016-03-06 06:34:08 --> Database Driver Class Initialized
INFO - 2016-03-06 06:34:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:34:09 --> Controller Class Initialized
INFO - 2016-03-06 06:34:09 --> Model Class Initialized
INFO - 2016-03-06 06:34:09 --> Model Class Initialized
INFO - 2016-03-06 06:34:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:34:09 --> Pagination Class Initialized
INFO - 2016-03-06 06:34:09 --> Helper loaded: text_helper
INFO - 2016-03-06 06:34:09 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:34:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:34:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:34:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 09:34:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 09:34:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:34:09 --> Final output sent to browser
DEBUG - 2016-03-06 09:34:09 --> Total execution time: 1.1535
INFO - 2016-03-06 06:35:38 --> Config Class Initialized
INFO - 2016-03-06 06:35:38 --> Hooks Class Initialized
DEBUG - 2016-03-06 06:35:38 --> UTF-8 Support Enabled
INFO - 2016-03-06 06:35:38 --> Utf8 Class Initialized
INFO - 2016-03-06 06:35:38 --> URI Class Initialized
INFO - 2016-03-06 06:35:38 --> Router Class Initialized
INFO - 2016-03-06 06:35:38 --> Output Class Initialized
INFO - 2016-03-06 06:35:38 --> Security Class Initialized
DEBUG - 2016-03-06 06:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 06:35:38 --> Input Class Initialized
INFO - 2016-03-06 06:35:38 --> Language Class Initialized
INFO - 2016-03-06 06:35:38 --> Loader Class Initialized
INFO - 2016-03-06 06:35:38 --> Helper loaded: url_helper
INFO - 2016-03-06 06:35:38 --> Helper loaded: file_helper
INFO - 2016-03-06 06:35:38 --> Helper loaded: date_helper
INFO - 2016-03-06 06:35:38 --> Helper loaded: form_helper
INFO - 2016-03-06 06:35:38 --> Database Driver Class Initialized
INFO - 2016-03-06 06:35:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 06:35:39 --> Controller Class Initialized
INFO - 2016-03-06 06:35:39 --> Model Class Initialized
INFO - 2016-03-06 06:35:39 --> Model Class Initialized
INFO - 2016-03-06 06:35:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 06:35:39 --> Pagination Class Initialized
INFO - 2016-03-06 06:35:39 --> Helper loaded: text_helper
INFO - 2016-03-06 06:35:39 --> Helper loaded: cookie_helper
INFO - 2016-03-06 09:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 09:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 09:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 09:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 09:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 09:35:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 09:35:39 --> Final output sent to browser
DEBUG - 2016-03-06 09:35:39 --> Total execution time: 1.1881
INFO - 2016-03-06 08:41:28 --> Config Class Initialized
INFO - 2016-03-06 08:41:28 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:41:28 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:41:29 --> Utf8 Class Initialized
INFO - 2016-03-06 08:41:29 --> URI Class Initialized
INFO - 2016-03-06 08:41:29 --> Router Class Initialized
INFO - 2016-03-06 08:41:29 --> Output Class Initialized
INFO - 2016-03-06 08:41:29 --> Security Class Initialized
DEBUG - 2016-03-06 08:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:41:29 --> Input Class Initialized
INFO - 2016-03-06 08:41:29 --> Language Class Initialized
INFO - 2016-03-06 08:41:29 --> Loader Class Initialized
INFO - 2016-03-06 08:41:29 --> Helper loaded: url_helper
INFO - 2016-03-06 08:41:29 --> Helper loaded: file_helper
INFO - 2016-03-06 08:41:29 --> Helper loaded: date_helper
INFO - 2016-03-06 08:41:29 --> Helper loaded: form_helper
INFO - 2016-03-06 08:41:29 --> Database Driver Class Initialized
INFO - 2016-03-06 08:41:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:41:30 --> Controller Class Initialized
INFO - 2016-03-06 08:41:30 --> Model Class Initialized
INFO - 2016-03-06 08:41:30 --> Model Class Initialized
INFO - 2016-03-06 08:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:41:30 --> Pagination Class Initialized
INFO - 2016-03-06 08:41:30 --> Helper loaded: text_helper
INFO - 2016-03-06 08:41:30 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:41:30 --> Final output sent to browser
DEBUG - 2016-03-06 11:41:30 --> Total execution time: 1.3916
INFO - 2016-03-06 08:42:35 --> Config Class Initialized
INFO - 2016-03-06 08:42:35 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:42:35 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:42:35 --> Utf8 Class Initialized
INFO - 2016-03-06 08:42:35 --> URI Class Initialized
INFO - 2016-03-06 08:42:35 --> Router Class Initialized
INFO - 2016-03-06 08:42:35 --> Output Class Initialized
INFO - 2016-03-06 08:42:35 --> Security Class Initialized
DEBUG - 2016-03-06 08:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:42:35 --> Input Class Initialized
INFO - 2016-03-06 08:42:35 --> Language Class Initialized
INFO - 2016-03-06 08:42:35 --> Loader Class Initialized
INFO - 2016-03-06 08:42:35 --> Helper loaded: url_helper
INFO - 2016-03-06 08:42:35 --> Helper loaded: file_helper
INFO - 2016-03-06 08:42:35 --> Helper loaded: date_helper
INFO - 2016-03-06 08:42:35 --> Helper loaded: form_helper
INFO - 2016-03-06 08:42:35 --> Database Driver Class Initialized
INFO - 2016-03-06 08:42:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:42:36 --> Controller Class Initialized
INFO - 2016-03-06 08:42:36 --> Model Class Initialized
INFO - 2016-03-06 08:42:36 --> Model Class Initialized
INFO - 2016-03-06 08:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:42:36 --> Pagination Class Initialized
INFO - 2016-03-06 08:42:36 --> Helper loaded: text_helper
INFO - 2016-03-06 08:42:36 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 11:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 11:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 11:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:42:36 --> Final output sent to browser
DEBUG - 2016-03-06 11:42:36 --> Total execution time: 1.1829
INFO - 2016-03-06 08:43:43 --> Config Class Initialized
INFO - 2016-03-06 08:43:43 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:43:43 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:43:43 --> Utf8 Class Initialized
INFO - 2016-03-06 08:43:43 --> URI Class Initialized
INFO - 2016-03-06 08:43:43 --> Router Class Initialized
INFO - 2016-03-06 08:43:43 --> Output Class Initialized
INFO - 2016-03-06 08:43:43 --> Security Class Initialized
DEBUG - 2016-03-06 08:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:43:43 --> Input Class Initialized
INFO - 2016-03-06 08:43:43 --> Language Class Initialized
INFO - 2016-03-06 08:43:43 --> Loader Class Initialized
INFO - 2016-03-06 08:43:43 --> Helper loaded: url_helper
INFO - 2016-03-06 08:43:43 --> Helper loaded: file_helper
INFO - 2016-03-06 08:43:43 --> Helper loaded: date_helper
INFO - 2016-03-06 08:43:43 --> Helper loaded: form_helper
INFO - 2016-03-06 08:43:43 --> Database Driver Class Initialized
INFO - 2016-03-06 08:43:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:43:44 --> Controller Class Initialized
INFO - 2016-03-06 08:43:44 --> Model Class Initialized
INFO - 2016-03-06 08:43:44 --> Model Class Initialized
INFO - 2016-03-06 08:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:43:44 --> Pagination Class Initialized
INFO - 2016-03-06 08:43:44 --> Helper loaded: text_helper
INFO - 2016-03-06 08:43:44 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 11:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 11:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 11:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:43:45 --> Final output sent to browser
DEBUG - 2016-03-06 11:43:45 --> Total execution time: 1.1984
INFO - 2016-03-06 08:46:30 --> Config Class Initialized
INFO - 2016-03-06 08:46:30 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:46:30 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:46:30 --> Utf8 Class Initialized
INFO - 2016-03-06 08:46:30 --> URI Class Initialized
INFO - 2016-03-06 08:46:30 --> Router Class Initialized
INFO - 2016-03-06 08:46:30 --> Output Class Initialized
INFO - 2016-03-06 08:46:30 --> Security Class Initialized
DEBUG - 2016-03-06 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:46:30 --> Input Class Initialized
INFO - 2016-03-06 08:46:30 --> Language Class Initialized
INFO - 2016-03-06 08:46:30 --> Loader Class Initialized
INFO - 2016-03-06 08:46:30 --> Helper loaded: url_helper
INFO - 2016-03-06 08:46:30 --> Helper loaded: file_helper
INFO - 2016-03-06 08:46:30 --> Helper loaded: date_helper
INFO - 2016-03-06 08:46:30 --> Helper loaded: form_helper
INFO - 2016-03-06 08:46:30 --> Database Driver Class Initialized
INFO - 2016-03-06 08:46:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:46:31 --> Controller Class Initialized
INFO - 2016-03-06 08:46:31 --> Model Class Initialized
INFO - 2016-03-06 08:46:31 --> Model Class Initialized
INFO - 2016-03-06 08:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:46:31 --> Pagination Class Initialized
INFO - 2016-03-06 08:46:31 --> Helper loaded: text_helper
INFO - 2016-03-06 08:46:31 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 11:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 11:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:46:31 --> Final output sent to browser
DEBUG - 2016-03-06 11:46:31 --> Total execution time: 1.1800
INFO - 2016-03-06 08:46:53 --> Config Class Initialized
INFO - 2016-03-06 08:46:53 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:46:53 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:46:53 --> Utf8 Class Initialized
INFO - 2016-03-06 08:46:53 --> URI Class Initialized
INFO - 2016-03-06 08:46:53 --> Router Class Initialized
INFO - 2016-03-06 08:46:53 --> Output Class Initialized
INFO - 2016-03-06 08:46:53 --> Security Class Initialized
DEBUG - 2016-03-06 08:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:46:53 --> Input Class Initialized
INFO - 2016-03-06 08:46:53 --> Language Class Initialized
INFO - 2016-03-06 08:46:53 --> Loader Class Initialized
INFO - 2016-03-06 08:46:53 --> Helper loaded: url_helper
INFO - 2016-03-06 08:46:53 --> Helper loaded: file_helper
INFO - 2016-03-06 08:46:53 --> Helper loaded: date_helper
INFO - 2016-03-06 08:46:53 --> Helper loaded: form_helper
INFO - 2016-03-06 08:46:53 --> Database Driver Class Initialized
INFO - 2016-03-06 08:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:46:54 --> Controller Class Initialized
INFO - 2016-03-06 08:46:54 --> Model Class Initialized
INFO - 2016-03-06 08:46:54 --> Model Class Initialized
INFO - 2016-03-06 08:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:46:54 --> Pagination Class Initialized
INFO - 2016-03-06 08:46:54 --> Helper loaded: text_helper
INFO - 2016-03-06 08:46:54 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:46:54 --> Final output sent to browser
DEBUG - 2016-03-06 11:46:54 --> Total execution time: 1.2162
INFO - 2016-03-06 08:46:56 --> Config Class Initialized
INFO - 2016-03-06 08:46:56 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:46:56 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:46:56 --> Utf8 Class Initialized
INFO - 2016-03-06 08:46:56 --> URI Class Initialized
INFO - 2016-03-06 08:46:56 --> Router Class Initialized
INFO - 2016-03-06 08:46:56 --> Output Class Initialized
INFO - 2016-03-06 08:46:56 --> Security Class Initialized
DEBUG - 2016-03-06 08:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:46:56 --> Input Class Initialized
INFO - 2016-03-06 08:46:56 --> Language Class Initialized
INFO - 2016-03-06 08:46:56 --> Loader Class Initialized
INFO - 2016-03-06 08:46:56 --> Helper loaded: url_helper
INFO - 2016-03-06 08:46:56 --> Helper loaded: file_helper
INFO - 2016-03-06 08:46:56 --> Helper loaded: date_helper
INFO - 2016-03-06 08:46:56 --> Helper loaded: form_helper
INFO - 2016-03-06 08:46:56 --> Database Driver Class Initialized
INFO - 2016-03-06 08:46:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:46:57 --> Controller Class Initialized
INFO - 2016-03-06 08:46:57 --> Model Class Initialized
INFO - 2016-03-06 08:46:57 --> Model Class Initialized
INFO - 2016-03-06 08:46:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:46:57 --> Pagination Class Initialized
INFO - 2016-03-06 08:46:57 --> Helper loaded: text_helper
INFO - 2016-03-06 08:46:57 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 11:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 11:46:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:46:57 --> Final output sent to browser
DEBUG - 2016-03-06 11:46:57 --> Total execution time: 1.1341
INFO - 2016-03-06 08:47:01 --> Config Class Initialized
INFO - 2016-03-06 08:47:01 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:47:02 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:47:02 --> Utf8 Class Initialized
INFO - 2016-03-06 08:47:02 --> URI Class Initialized
INFO - 2016-03-06 08:47:02 --> Router Class Initialized
INFO - 2016-03-06 08:47:02 --> Output Class Initialized
INFO - 2016-03-06 08:47:02 --> Security Class Initialized
DEBUG - 2016-03-06 08:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:47:02 --> Input Class Initialized
INFO - 2016-03-06 08:47:02 --> Language Class Initialized
INFO - 2016-03-06 08:47:02 --> Loader Class Initialized
INFO - 2016-03-06 08:47:02 --> Helper loaded: url_helper
INFO - 2016-03-06 08:47:02 --> Helper loaded: file_helper
INFO - 2016-03-06 08:47:02 --> Helper loaded: date_helper
INFO - 2016-03-06 08:47:02 --> Helper loaded: form_helper
INFO - 2016-03-06 08:47:02 --> Database Driver Class Initialized
INFO - 2016-03-06 08:47:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:47:03 --> Controller Class Initialized
INFO - 2016-03-06 08:47:03 --> Model Class Initialized
INFO - 2016-03-06 08:47:03 --> Model Class Initialized
INFO - 2016-03-06 08:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:47:03 --> Pagination Class Initialized
INFO - 2016-03-06 08:47:03 --> Helper loaded: text_helper
INFO - 2016-03-06 08:47:03 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 11:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 11:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:47:03 --> Final output sent to browser
DEBUG - 2016-03-06 11:47:03 --> Total execution time: 1.1810
INFO - 2016-03-06 08:47:05 --> Config Class Initialized
INFO - 2016-03-06 08:47:05 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:47:05 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:47:05 --> Utf8 Class Initialized
INFO - 2016-03-06 08:47:05 --> URI Class Initialized
INFO - 2016-03-06 08:47:05 --> Router Class Initialized
INFO - 2016-03-06 08:47:05 --> Output Class Initialized
INFO - 2016-03-06 08:47:05 --> Security Class Initialized
DEBUG - 2016-03-06 08:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:47:05 --> Input Class Initialized
INFO - 2016-03-06 08:47:05 --> Language Class Initialized
INFO - 2016-03-06 08:47:05 --> Loader Class Initialized
INFO - 2016-03-06 08:47:05 --> Helper loaded: url_helper
INFO - 2016-03-06 08:47:05 --> Helper loaded: file_helper
INFO - 2016-03-06 08:47:05 --> Helper loaded: date_helper
INFO - 2016-03-06 08:47:05 --> Helper loaded: form_helper
INFO - 2016-03-06 08:47:05 --> Database Driver Class Initialized
INFO - 2016-03-06 08:47:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:47:06 --> Controller Class Initialized
INFO - 2016-03-06 08:47:06 --> Model Class Initialized
INFO - 2016-03-06 08:47:06 --> Model Class Initialized
INFO - 2016-03-06 08:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:47:06 --> Pagination Class Initialized
INFO - 2016-03-06 08:47:06 --> Helper loaded: text_helper
INFO - 2016-03-06 08:47:06 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 11:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 11:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:47:06 --> Final output sent to browser
DEBUG - 2016-03-06 11:47:06 --> Total execution time: 1.1214
INFO - 2016-03-06 08:47:09 --> Config Class Initialized
INFO - 2016-03-06 08:47:09 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:47:09 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:47:09 --> Utf8 Class Initialized
INFO - 2016-03-06 08:47:09 --> URI Class Initialized
INFO - 2016-03-06 08:47:09 --> Router Class Initialized
INFO - 2016-03-06 08:47:09 --> Output Class Initialized
INFO - 2016-03-06 08:47:09 --> Security Class Initialized
DEBUG - 2016-03-06 08:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:47:09 --> Input Class Initialized
INFO - 2016-03-06 08:47:09 --> Language Class Initialized
INFO - 2016-03-06 08:47:09 --> Loader Class Initialized
INFO - 2016-03-06 08:47:09 --> Helper loaded: url_helper
INFO - 2016-03-06 08:47:09 --> Helper loaded: file_helper
INFO - 2016-03-06 08:47:09 --> Helper loaded: date_helper
INFO - 2016-03-06 08:47:09 --> Helper loaded: form_helper
INFO - 2016-03-06 08:47:09 --> Database Driver Class Initialized
INFO - 2016-03-06 08:47:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:47:10 --> Controller Class Initialized
INFO - 2016-03-06 08:47:10 --> Model Class Initialized
INFO - 2016-03-06 08:47:10 --> Model Class Initialized
INFO - 2016-03-06 08:47:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:47:10 --> Pagination Class Initialized
INFO - 2016-03-06 08:47:10 --> Helper loaded: text_helper
INFO - 2016-03-06 08:47:10 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 11:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 11:47:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:47:10 --> Final output sent to browser
DEBUG - 2016-03-06 11:47:10 --> Total execution time: 1.0994
ERROR - 2016-03-06 08:57:53 --> Severity: Error --> Call to undefined function site_url() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\config\config.php 523
ERROR - 2016-03-06 08:58:48 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\config\config.php 524
ERROR - 2016-03-06 08:58:48 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\config\config.php 525
INFO - 2016-03-06 08:58:48 --> Config Class Initialized
INFO - 2016-03-06 08:58:48 --> Hooks Class Initialized
DEBUG - 2016-03-06 08:58:48 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:58:48 --> Utf8 Class Initialized
INFO - 2016-03-06 08:58:48 --> URI Class Initialized
INFO - 2016-03-06 08:58:48 --> Router Class Initialized
INFO - 2016-03-06 08:58:48 --> Output Class Initialized
INFO - 2016-03-06 08:58:48 --> Security Class Initialized
DEBUG - 2016-03-06 08:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:58:48 --> Input Class Initialized
INFO - 2016-03-06 08:58:48 --> Language Class Initialized
INFO - 2016-03-06 08:58:48 --> Loader Class Initialized
INFO - 2016-03-06 08:58:48 --> Helper loaded: url_helper
INFO - 2016-03-06 08:58:48 --> Helper loaded: file_helper
INFO - 2016-03-06 08:58:48 --> Helper loaded: date_helper
INFO - 2016-03-06 08:58:48 --> Helper loaded: form_helper
INFO - 2016-03-06 08:58:48 --> Database Driver Class Initialized
INFO - 2016-03-06 08:58:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:58:49 --> Controller Class Initialized
INFO - 2016-03-06 08:58:49 --> Model Class Initialized
INFO - 2016-03-06 08:58:49 --> Model Class Initialized
INFO - 2016-03-06 08:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:58:49 --> Pagination Class Initialized
INFO - 2016-03-06 08:58:49 --> Helper loaded: text_helper
INFO - 2016-03-06 08:58:49 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 11:58:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:58:49 --> Final output sent to browser
DEBUG - 2016-03-06 11:58:49 --> Total execution time: 1.1629
ERROR - 2016-03-06 08:58:49 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\config\config.php 524
ERROR - 2016-03-06 08:58:49 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\config\config.php 525
ERROR - 2016-03-06 08:58:49 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\config\config.php 524
INFO - 2016-03-06 08:58:49 --> Config Class Initialized
ERROR - 2016-03-06 08:58:49 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\config\config.php 525
INFO - 2016-03-06 08:58:49 --> Hooks Class Initialized
INFO - 2016-03-06 08:58:49 --> Config Class Initialized
DEBUG - 2016-03-06 08:58:49 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:58:49 --> Hooks Class Initialized
INFO - 2016-03-06 08:58:49 --> Utf8 Class Initialized
DEBUG - 2016-03-06 08:58:49 --> UTF-8 Support Enabled
INFO - 2016-03-06 08:58:49 --> Utf8 Class Initialized
INFO - 2016-03-06 08:58:49 --> URI Class Initialized
INFO - 2016-03-06 08:58:49 --> URI Class Initialized
INFO - 2016-03-06 08:58:49 --> Router Class Initialized
INFO - 2016-03-06 08:58:49 --> Router Class Initialized
INFO - 2016-03-06 08:58:49 --> Output Class Initialized
INFO - 2016-03-06 08:58:49 --> Output Class Initialized
INFO - 2016-03-06 08:58:49 --> Security Class Initialized
INFO - 2016-03-06 08:58:49 --> Security Class Initialized
DEBUG - 2016-03-06 08:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-03-06 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 08:58:49 --> Input Class Initialized
INFO - 2016-03-06 08:58:49 --> Input Class Initialized
INFO - 2016-03-06 08:58:49 --> Language Class Initialized
INFO - 2016-03-06 08:58:49 --> Language Class Initialized
INFO - 2016-03-06 08:58:49 --> Loader Class Initialized
INFO - 2016-03-06 08:58:49 --> Loader Class Initialized
INFO - 2016-03-06 08:58:49 --> Helper loaded: url_helper
INFO - 2016-03-06 08:58:49 --> Helper loaded: url_helper
INFO - 2016-03-06 08:58:49 --> Helper loaded: file_helper
INFO - 2016-03-06 08:58:49 --> Helper loaded: file_helper
INFO - 2016-03-06 08:58:49 --> Helper loaded: date_helper
INFO - 2016-03-06 08:58:49 --> Helper loaded: date_helper
INFO - 2016-03-06 08:58:49 --> Helper loaded: form_helper
INFO - 2016-03-06 08:58:49 --> Helper loaded: form_helper
INFO - 2016-03-06 08:58:49 --> Database Driver Class Initialized
INFO - 2016-03-06 08:58:49 --> Database Driver Class Initialized
INFO - 2016-03-06 08:58:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:58:50 --> Controller Class Initialized
INFO - 2016-03-06 08:58:50 --> Model Class Initialized
INFO - 2016-03-06 08:58:50 --> Model Class Initialized
INFO - 2016-03-06 08:58:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:58:50 --> Pagination Class Initialized
INFO - 2016-03-06 08:58:51 --> Helper loaded: text_helper
INFO - 2016-03-06 08:58:51 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 143
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:58:51 --> Final output sent to browser
DEBUG - 2016-03-06 11:58:51 --> Total execution time: 1.2772
INFO - 2016-03-06 08:58:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 08:58:51 --> Controller Class Initialized
INFO - 2016-03-06 08:58:51 --> Model Class Initialized
INFO - 2016-03-06 08:58:51 --> Model Class Initialized
INFO - 2016-03-06 08:58:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 08:58:51 --> Pagination Class Initialized
INFO - 2016-03-06 08:58:51 --> Helper loaded: text_helper
INFO - 2016-03-06 08:58:51 --> Helper loaded: cookie_helper
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-06 11:58:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 143
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 11:58:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 11:58:51 --> Final output sent to browser
DEBUG - 2016-03-06 11:58:51 --> Total execution time: 1.4303
INFO - 2016-03-06 09:00:51 --> Config Class Initialized
INFO - 2016-03-06 09:00:51 --> Hooks Class Initialized
DEBUG - 2016-03-06 09:00:51 --> UTF-8 Support Enabled
INFO - 2016-03-06 09:00:51 --> Utf8 Class Initialized
INFO - 2016-03-06 09:00:51 --> URI Class Initialized
INFO - 2016-03-06 09:00:51 --> Router Class Initialized
INFO - 2016-03-06 09:00:51 --> Output Class Initialized
INFO - 2016-03-06 09:00:51 --> Security Class Initialized
DEBUG - 2016-03-06 09:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 09:00:51 --> Input Class Initialized
INFO - 2016-03-06 09:00:51 --> Language Class Initialized
INFO - 2016-03-06 09:00:51 --> Loader Class Initialized
INFO - 2016-03-06 09:00:51 --> Helper loaded: url_helper
INFO - 2016-03-06 09:00:51 --> Helper loaded: file_helper
INFO - 2016-03-06 09:00:51 --> Helper loaded: date_helper
INFO - 2016-03-06 09:00:51 --> Helper loaded: form_helper
INFO - 2016-03-06 09:00:51 --> Database Driver Class Initialized
INFO - 2016-03-06 09:00:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 09:00:52 --> Controller Class Initialized
INFO - 2016-03-06 09:00:52 --> Model Class Initialized
INFO - 2016-03-06 09:00:52 --> Model Class Initialized
INFO - 2016-03-06 09:00:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 09:00:52 --> Pagination Class Initialized
INFO - 2016-03-06 09:00:52 --> Helper loaded: text_helper
INFO - 2016-03-06 09:00:52 --> Helper loaded: cookie_helper
INFO - 2016-03-06 12:00:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 12:00:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-06 12:00:52 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 122
ERROR - 2016-03-06 12:00:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-03-06 12:00:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-06 09:01:43 --> Config Class Initialized
INFO - 2016-03-06 09:01:43 --> Hooks Class Initialized
DEBUG - 2016-03-06 09:01:43 --> UTF-8 Support Enabled
INFO - 2016-03-06 09:01:43 --> Utf8 Class Initialized
INFO - 2016-03-06 09:01:43 --> URI Class Initialized
INFO - 2016-03-06 09:01:43 --> Router Class Initialized
INFO - 2016-03-06 09:01:43 --> Output Class Initialized
INFO - 2016-03-06 09:01:43 --> Security Class Initialized
DEBUG - 2016-03-06 09:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 09:01:43 --> Input Class Initialized
INFO - 2016-03-06 09:01:43 --> Language Class Initialized
INFO - 2016-03-06 09:01:43 --> Loader Class Initialized
INFO - 2016-03-06 09:01:43 --> Helper loaded: url_helper
INFO - 2016-03-06 09:01:43 --> Helper loaded: file_helper
INFO - 2016-03-06 09:01:43 --> Helper loaded: date_helper
INFO - 2016-03-06 09:01:43 --> Helper loaded: form_helper
INFO - 2016-03-06 09:01:43 --> Database Driver Class Initialized
INFO - 2016-03-06 09:01:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 09:01:44 --> Controller Class Initialized
INFO - 2016-03-06 09:01:44 --> Model Class Initialized
INFO - 2016-03-06 09:01:44 --> Model Class Initialized
INFO - 2016-03-06 09:01:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 09:01:44 --> Pagination Class Initialized
INFO - 2016-03-06 09:01:44 --> Helper loaded: text_helper
INFO - 2016-03-06 09:01:44 --> Helper loaded: cookie_helper
INFO - 2016-03-06 12:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 12:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 12:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 12:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 12:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 12:01:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 12:01:44 --> Final output sent to browser
DEBUG - 2016-03-06 12:01:44 --> Total execution time: 1.3310
INFO - 2016-03-06 10:08:27 --> Config Class Initialized
INFO - 2016-03-06 10:08:27 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:08:27 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:08:27 --> Utf8 Class Initialized
INFO - 2016-03-06 10:08:27 --> URI Class Initialized
INFO - 2016-03-06 10:08:27 --> Router Class Initialized
INFO - 2016-03-06 10:08:27 --> Output Class Initialized
INFO - 2016-03-06 10:08:27 --> Security Class Initialized
DEBUG - 2016-03-06 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:08:27 --> Input Class Initialized
INFO - 2016-03-06 10:08:27 --> Language Class Initialized
INFO - 2016-03-06 10:08:27 --> Loader Class Initialized
INFO - 2016-03-06 10:08:27 --> Helper loaded: url_helper
INFO - 2016-03-06 10:08:27 --> Helper loaded: file_helper
INFO - 2016-03-06 10:08:27 --> Helper loaded: date_helper
INFO - 2016-03-06 10:08:27 --> Helper loaded: form_helper
INFO - 2016-03-06 10:08:27 --> Database Driver Class Initialized
INFO - 2016-03-06 10:08:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:08:28 --> Controller Class Initialized
INFO - 2016-03-06 10:08:28 --> Model Class Initialized
INFO - 2016-03-06 10:08:28 --> Model Class Initialized
INFO - 2016-03-06 10:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:08:28 --> Pagination Class Initialized
INFO - 2016-03-06 10:08:28 --> Helper loaded: text_helper
INFO - 2016-03-06 10:08:28 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:08:28 --> Final output sent to browser
DEBUG - 2016-03-06 13:08:28 --> Total execution time: 1.1770
INFO - 2016-03-06 10:08:32 --> Config Class Initialized
INFO - 2016-03-06 10:08:32 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:08:32 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:08:32 --> Utf8 Class Initialized
INFO - 2016-03-06 10:08:32 --> URI Class Initialized
INFO - 2016-03-06 10:08:32 --> Router Class Initialized
INFO - 2016-03-06 10:08:32 --> Output Class Initialized
INFO - 2016-03-06 10:08:32 --> Security Class Initialized
DEBUG - 2016-03-06 10:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:08:32 --> Input Class Initialized
INFO - 2016-03-06 10:08:32 --> Language Class Initialized
INFO - 2016-03-06 10:08:32 --> Loader Class Initialized
INFO - 2016-03-06 10:08:32 --> Helper loaded: url_helper
INFO - 2016-03-06 10:08:32 --> Helper loaded: file_helper
INFO - 2016-03-06 10:08:32 --> Helper loaded: date_helper
INFO - 2016-03-06 10:08:32 --> Helper loaded: form_helper
INFO - 2016-03-06 10:08:32 --> Database Driver Class Initialized
INFO - 2016-03-06 10:08:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:08:33 --> Controller Class Initialized
INFO - 2016-03-06 10:08:33 --> Model Class Initialized
INFO - 2016-03-06 10:08:33 --> Model Class Initialized
INFO - 2016-03-06 10:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:08:33 --> Pagination Class Initialized
INFO - 2016-03-06 10:08:33 --> Helper loaded: text_helper
INFO - 2016-03-06 10:08:33 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:08:33 --> Final output sent to browser
DEBUG - 2016-03-06 13:08:33 --> Total execution time: 1.1200
INFO - 2016-03-06 10:09:41 --> Config Class Initialized
INFO - 2016-03-06 10:09:41 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:09:41 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:09:41 --> Utf8 Class Initialized
INFO - 2016-03-06 10:09:41 --> URI Class Initialized
INFO - 2016-03-06 10:09:41 --> Router Class Initialized
INFO - 2016-03-06 10:09:41 --> Output Class Initialized
INFO - 2016-03-06 10:09:41 --> Security Class Initialized
DEBUG - 2016-03-06 10:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:09:41 --> Input Class Initialized
INFO - 2016-03-06 10:09:41 --> Language Class Initialized
INFO - 2016-03-06 10:09:41 --> Loader Class Initialized
INFO - 2016-03-06 10:09:41 --> Helper loaded: url_helper
INFO - 2016-03-06 10:09:41 --> Helper loaded: file_helper
INFO - 2016-03-06 10:09:41 --> Helper loaded: date_helper
INFO - 2016-03-06 10:09:41 --> Helper loaded: form_helper
INFO - 2016-03-06 10:09:41 --> Database Driver Class Initialized
INFO - 2016-03-06 10:09:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:09:42 --> Controller Class Initialized
INFO - 2016-03-06 10:09:42 --> Model Class Initialized
INFO - 2016-03-06 10:09:42 --> Model Class Initialized
INFO - 2016-03-06 10:09:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:09:42 --> Pagination Class Initialized
INFO - 2016-03-06 10:09:42 --> Helper loaded: text_helper
INFO - 2016-03-06 10:09:42 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:09:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:09:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:09:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:09:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:09:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:09:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:09:42 --> Final output sent to browser
DEBUG - 2016-03-06 13:09:42 --> Total execution time: 1.1463
INFO - 2016-03-06 10:09:51 --> Config Class Initialized
INFO - 2016-03-06 10:09:51 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:09:51 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:09:51 --> Utf8 Class Initialized
INFO - 2016-03-06 10:09:51 --> URI Class Initialized
INFO - 2016-03-06 10:09:51 --> Router Class Initialized
INFO - 2016-03-06 10:09:51 --> Output Class Initialized
INFO - 2016-03-06 10:09:51 --> Security Class Initialized
DEBUG - 2016-03-06 10:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:09:51 --> Input Class Initialized
INFO - 2016-03-06 10:09:51 --> Language Class Initialized
INFO - 2016-03-06 10:09:51 --> Loader Class Initialized
INFO - 2016-03-06 10:09:51 --> Helper loaded: url_helper
INFO - 2016-03-06 10:09:51 --> Helper loaded: file_helper
INFO - 2016-03-06 10:09:51 --> Helper loaded: date_helper
INFO - 2016-03-06 10:09:51 --> Helper loaded: form_helper
INFO - 2016-03-06 10:09:51 --> Database Driver Class Initialized
INFO - 2016-03-06 10:09:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:09:52 --> Controller Class Initialized
INFO - 2016-03-06 10:09:52 --> Model Class Initialized
INFO - 2016-03-06 10:09:52 --> Model Class Initialized
INFO - 2016-03-06 10:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:09:52 --> Pagination Class Initialized
INFO - 2016-03-06 10:09:52 --> Helper loaded: text_helper
INFO - 2016-03-06 10:09:52 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:09:52 --> Final output sent to browser
DEBUG - 2016-03-06 13:09:52 --> Total execution time: 1.1502
INFO - 2016-03-06 10:09:57 --> Config Class Initialized
INFO - 2016-03-06 10:09:57 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:09:57 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:09:57 --> Utf8 Class Initialized
INFO - 2016-03-06 10:09:57 --> URI Class Initialized
INFO - 2016-03-06 10:09:57 --> Router Class Initialized
INFO - 2016-03-06 10:09:57 --> Output Class Initialized
INFO - 2016-03-06 10:09:57 --> Security Class Initialized
DEBUG - 2016-03-06 10:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:09:57 --> Input Class Initialized
INFO - 2016-03-06 10:09:57 --> Language Class Initialized
INFO - 2016-03-06 10:09:57 --> Loader Class Initialized
INFO - 2016-03-06 10:09:57 --> Helper loaded: url_helper
INFO - 2016-03-06 10:09:57 --> Helper loaded: file_helper
INFO - 2016-03-06 10:09:57 --> Helper loaded: date_helper
INFO - 2016-03-06 10:09:57 --> Helper loaded: form_helper
INFO - 2016-03-06 10:09:57 --> Database Driver Class Initialized
INFO - 2016-03-06 10:09:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:09:58 --> Controller Class Initialized
INFO - 2016-03-06 10:09:58 --> Model Class Initialized
INFO - 2016-03-06 10:09:58 --> Model Class Initialized
INFO - 2016-03-06 10:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:09:58 --> Pagination Class Initialized
INFO - 2016-03-06 10:09:58 --> Helper loaded: text_helper
INFO - 2016-03-06 10:09:58 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:09:58 --> Final output sent to browser
DEBUG - 2016-03-06 13:09:58 --> Total execution time: 1.1666
INFO - 2016-03-06 10:10:46 --> Config Class Initialized
INFO - 2016-03-06 10:10:46 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:10:46 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:10:46 --> Utf8 Class Initialized
INFO - 2016-03-06 10:10:46 --> URI Class Initialized
INFO - 2016-03-06 10:10:46 --> Router Class Initialized
INFO - 2016-03-06 10:10:46 --> Output Class Initialized
INFO - 2016-03-06 10:10:46 --> Security Class Initialized
DEBUG - 2016-03-06 10:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:10:46 --> Input Class Initialized
INFO - 2016-03-06 10:10:46 --> Language Class Initialized
INFO - 2016-03-06 10:10:46 --> Loader Class Initialized
INFO - 2016-03-06 10:10:46 --> Helper loaded: url_helper
INFO - 2016-03-06 10:10:46 --> Helper loaded: file_helper
INFO - 2016-03-06 10:10:46 --> Helper loaded: date_helper
INFO - 2016-03-06 10:10:46 --> Helper loaded: form_helper
INFO - 2016-03-06 10:10:46 --> Database Driver Class Initialized
INFO - 2016-03-06 10:10:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:10:47 --> Controller Class Initialized
INFO - 2016-03-06 10:10:47 --> Model Class Initialized
INFO - 2016-03-06 10:10:47 --> Model Class Initialized
INFO - 2016-03-06 10:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:10:47 --> Pagination Class Initialized
INFO - 2016-03-06 10:10:47 --> Helper loaded: text_helper
INFO - 2016-03-06 10:10:47 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:10:47 --> Final output sent to browser
DEBUG - 2016-03-06 13:10:47 --> Total execution time: 1.1847
INFO - 2016-03-06 10:10:50 --> Config Class Initialized
INFO - 2016-03-06 10:10:50 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:10:50 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:10:50 --> Utf8 Class Initialized
INFO - 2016-03-06 10:10:50 --> URI Class Initialized
INFO - 2016-03-06 10:10:50 --> Router Class Initialized
INFO - 2016-03-06 10:10:50 --> Output Class Initialized
INFO - 2016-03-06 10:10:50 --> Security Class Initialized
DEBUG - 2016-03-06 10:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:10:50 --> Input Class Initialized
INFO - 2016-03-06 10:10:50 --> Language Class Initialized
INFO - 2016-03-06 10:10:50 --> Loader Class Initialized
INFO - 2016-03-06 10:10:50 --> Helper loaded: url_helper
INFO - 2016-03-06 10:10:50 --> Helper loaded: file_helper
INFO - 2016-03-06 10:10:50 --> Helper loaded: date_helper
INFO - 2016-03-06 10:10:50 --> Helper loaded: form_helper
INFO - 2016-03-06 10:10:50 --> Database Driver Class Initialized
INFO - 2016-03-06 10:10:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:10:51 --> Controller Class Initialized
INFO - 2016-03-06 10:10:51 --> Model Class Initialized
INFO - 2016-03-06 10:10:51 --> Model Class Initialized
INFO - 2016-03-06 10:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:10:51 --> Pagination Class Initialized
INFO - 2016-03-06 10:10:51 --> Helper loaded: text_helper
INFO - 2016-03-06 10:10:51 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:10:51 --> Final output sent to browser
DEBUG - 2016-03-06 13:10:51 --> Total execution time: 1.1559
INFO - 2016-03-06 10:10:57 --> Config Class Initialized
INFO - 2016-03-06 10:10:57 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:10:57 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:10:57 --> Utf8 Class Initialized
INFO - 2016-03-06 10:10:57 --> URI Class Initialized
INFO - 2016-03-06 10:10:57 --> Router Class Initialized
INFO - 2016-03-06 10:10:57 --> Output Class Initialized
INFO - 2016-03-06 10:10:57 --> Security Class Initialized
DEBUG - 2016-03-06 10:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:10:57 --> Input Class Initialized
INFO - 2016-03-06 10:10:57 --> Language Class Initialized
INFO - 2016-03-06 10:10:57 --> Loader Class Initialized
INFO - 2016-03-06 10:10:57 --> Helper loaded: url_helper
INFO - 2016-03-06 10:10:57 --> Helper loaded: file_helper
INFO - 2016-03-06 10:10:57 --> Helper loaded: date_helper
INFO - 2016-03-06 10:10:57 --> Helper loaded: form_helper
INFO - 2016-03-06 10:10:57 --> Database Driver Class Initialized
INFO - 2016-03-06 10:10:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:10:58 --> Controller Class Initialized
INFO - 2016-03-06 10:10:58 --> Model Class Initialized
INFO - 2016-03-06 10:10:58 --> Model Class Initialized
INFO - 2016-03-06 10:10:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:10:58 --> Pagination Class Initialized
INFO - 2016-03-06 10:10:58 --> Helper loaded: text_helper
INFO - 2016-03-06 10:10:58 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:10:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:10:58 --> Final output sent to browser
DEBUG - 2016-03-06 13:10:58 --> Total execution time: 1.1749
INFO - 2016-03-06 10:11:00 --> Config Class Initialized
INFO - 2016-03-06 10:11:00 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:11:00 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:11:00 --> Utf8 Class Initialized
INFO - 2016-03-06 10:11:00 --> URI Class Initialized
INFO - 2016-03-06 10:11:00 --> Router Class Initialized
INFO - 2016-03-06 10:11:00 --> Output Class Initialized
INFO - 2016-03-06 10:11:00 --> Security Class Initialized
DEBUG - 2016-03-06 10:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:11:00 --> Input Class Initialized
INFO - 2016-03-06 10:11:00 --> Language Class Initialized
INFO - 2016-03-06 10:11:00 --> Loader Class Initialized
INFO - 2016-03-06 10:11:00 --> Helper loaded: url_helper
INFO - 2016-03-06 10:11:00 --> Helper loaded: file_helper
INFO - 2016-03-06 10:11:00 --> Helper loaded: date_helper
INFO - 2016-03-06 10:11:00 --> Helper loaded: form_helper
INFO - 2016-03-06 10:11:00 --> Database Driver Class Initialized
INFO - 2016-03-06 10:11:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:11:01 --> Controller Class Initialized
INFO - 2016-03-06 10:11:01 --> Model Class Initialized
INFO - 2016-03-06 10:11:01 --> Model Class Initialized
INFO - 2016-03-06 10:11:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:11:01 --> Pagination Class Initialized
INFO - 2016-03-06 10:11:01 --> Helper loaded: text_helper
INFO - 2016-03-06 10:11:01 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:11:01 --> Final output sent to browser
DEBUG - 2016-03-06 13:11:01 --> Total execution time: 1.1301
INFO - 2016-03-06 10:36:03 --> Config Class Initialized
INFO - 2016-03-06 10:36:03 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:36:03 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:36:03 --> Utf8 Class Initialized
INFO - 2016-03-06 10:36:03 --> URI Class Initialized
INFO - 2016-03-06 10:36:03 --> Router Class Initialized
INFO - 2016-03-06 10:36:03 --> Output Class Initialized
INFO - 2016-03-06 10:36:03 --> Security Class Initialized
DEBUG - 2016-03-06 10:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:36:03 --> Input Class Initialized
INFO - 2016-03-06 10:36:03 --> Language Class Initialized
INFO - 2016-03-06 10:36:03 --> Loader Class Initialized
INFO - 2016-03-06 10:36:03 --> Helper loaded: url_helper
INFO - 2016-03-06 10:36:03 --> Helper loaded: file_helper
INFO - 2016-03-06 10:36:03 --> Helper loaded: date_helper
INFO - 2016-03-06 10:36:03 --> Helper loaded: form_helper
INFO - 2016-03-06 10:36:03 --> Database Driver Class Initialized
INFO - 2016-03-06 10:36:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:36:04 --> Controller Class Initialized
INFO - 2016-03-06 10:36:04 --> Model Class Initialized
INFO - 2016-03-06 10:36:04 --> Model Class Initialized
INFO - 2016-03-06 10:36:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:36:04 --> Pagination Class Initialized
INFO - 2016-03-06 10:36:04 --> Helper loaded: text_helper
INFO - 2016-03-06 10:36:04 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:36:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
INFO - 2016-03-06 13:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:36:04 --> Final output sent to browser
DEBUG - 2016-03-06 13:36:04 --> Total execution time: 1.1698
INFO - 2016-03-06 10:37:03 --> Config Class Initialized
INFO - 2016-03-06 10:37:03 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:37:03 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:37:03 --> Utf8 Class Initialized
INFO - 2016-03-06 10:37:03 --> URI Class Initialized
INFO - 2016-03-06 10:37:03 --> Router Class Initialized
INFO - 2016-03-06 10:37:03 --> Output Class Initialized
INFO - 2016-03-06 10:37:03 --> Security Class Initialized
DEBUG - 2016-03-06 10:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:37:03 --> Input Class Initialized
INFO - 2016-03-06 10:37:03 --> Language Class Initialized
INFO - 2016-03-06 10:37:03 --> Loader Class Initialized
INFO - 2016-03-06 10:37:03 --> Helper loaded: url_helper
INFO - 2016-03-06 10:37:03 --> Helper loaded: file_helper
INFO - 2016-03-06 10:37:03 --> Helper loaded: date_helper
INFO - 2016-03-06 10:37:03 --> Helper loaded: form_helper
INFO - 2016-03-06 10:37:03 --> Database Driver Class Initialized
INFO - 2016-03-06 10:37:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:37:04 --> Controller Class Initialized
INFO - 2016-03-06 10:37:04 --> Model Class Initialized
INFO - 2016-03-06 10:37:04 --> Model Class Initialized
INFO - 2016-03-06 10:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:37:04 --> Pagination Class Initialized
INFO - 2016-03-06 10:37:04 --> Helper loaded: text_helper
INFO - 2016-03-06 10:37:04 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:37:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
INFO - 2016-03-06 13:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:37:04 --> Final output sent to browser
DEBUG - 2016-03-06 13:37:04 --> Total execution time: 1.2151
INFO - 2016-03-06 10:37:36 --> Config Class Initialized
INFO - 2016-03-06 10:37:36 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:37:36 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:37:36 --> Utf8 Class Initialized
INFO - 2016-03-06 10:37:36 --> URI Class Initialized
INFO - 2016-03-06 10:37:36 --> Router Class Initialized
INFO - 2016-03-06 10:37:36 --> Output Class Initialized
INFO - 2016-03-06 10:37:36 --> Security Class Initialized
DEBUG - 2016-03-06 10:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:37:36 --> Input Class Initialized
INFO - 2016-03-06 10:37:36 --> Language Class Initialized
INFO - 2016-03-06 10:37:36 --> Loader Class Initialized
INFO - 2016-03-06 10:37:36 --> Helper loaded: url_helper
INFO - 2016-03-06 10:37:36 --> Helper loaded: file_helper
INFO - 2016-03-06 10:37:36 --> Helper loaded: date_helper
INFO - 2016-03-06 10:37:36 --> Helper loaded: form_helper
INFO - 2016-03-06 10:37:36 --> Database Driver Class Initialized
INFO - 2016-03-06 10:37:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:37:37 --> Controller Class Initialized
INFO - 2016-03-06 10:37:37 --> Model Class Initialized
INFO - 2016-03-06 10:37:37 --> Model Class Initialized
INFO - 2016-03-06 10:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:37:37 --> Pagination Class Initialized
INFO - 2016-03-06 10:37:37 --> Helper loaded: text_helper
INFO - 2016-03-06 10:37:37 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:37:37 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
INFO - 2016-03-06 10:38:08 --> Config Class Initialized
INFO - 2016-03-06 10:38:08 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:38:08 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:38:08 --> Utf8 Class Initialized
INFO - 2016-03-06 10:38:08 --> URI Class Initialized
INFO - 2016-03-06 10:38:08 --> Router Class Initialized
INFO - 2016-03-06 10:38:08 --> Output Class Initialized
INFO - 2016-03-06 10:38:08 --> Security Class Initialized
DEBUG - 2016-03-06 10:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:38:08 --> Input Class Initialized
INFO - 2016-03-06 10:38:08 --> Language Class Initialized
INFO - 2016-03-06 10:38:08 --> Loader Class Initialized
INFO - 2016-03-06 10:38:08 --> Helper loaded: url_helper
INFO - 2016-03-06 10:38:08 --> Helper loaded: file_helper
INFO - 2016-03-06 10:38:08 --> Helper loaded: date_helper
INFO - 2016-03-06 10:38:08 --> Helper loaded: form_helper
INFO - 2016-03-06 10:38:08 --> Database Driver Class Initialized
INFO - 2016-03-06 10:38:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:38:09 --> Controller Class Initialized
INFO - 2016-03-06 10:38:09 --> Model Class Initialized
INFO - 2016-03-06 10:38:09 --> Model Class Initialized
INFO - 2016-03-06 10:38:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:38:09 --> Pagination Class Initialized
INFO - 2016-03-06 10:38:09 --> Helper loaded: text_helper
INFO - 2016-03-06 10:38:09 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:38:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
INFO - 2016-03-06 13:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:38:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:38:09 --> Final output sent to browser
DEBUG - 2016-03-06 13:38:09 --> Total execution time: 1.1485
INFO - 2016-03-06 10:41:28 --> Config Class Initialized
INFO - 2016-03-06 10:41:28 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:41:28 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:41:28 --> Utf8 Class Initialized
INFO - 2016-03-06 10:41:28 --> URI Class Initialized
INFO - 2016-03-06 10:41:28 --> Router Class Initialized
INFO - 2016-03-06 10:41:28 --> Output Class Initialized
INFO - 2016-03-06 10:41:28 --> Security Class Initialized
DEBUG - 2016-03-06 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:41:28 --> Input Class Initialized
INFO - 2016-03-06 10:41:28 --> Language Class Initialized
INFO - 2016-03-06 10:41:28 --> Loader Class Initialized
INFO - 2016-03-06 10:41:28 --> Helper loaded: url_helper
INFO - 2016-03-06 10:41:28 --> Helper loaded: file_helper
INFO - 2016-03-06 10:41:28 --> Helper loaded: date_helper
INFO - 2016-03-06 10:41:28 --> Helper loaded: form_helper
INFO - 2016-03-06 10:41:28 --> Database Driver Class Initialized
INFO - 2016-03-06 10:41:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:41:29 --> Controller Class Initialized
INFO - 2016-03-06 10:41:29 --> Model Class Initialized
INFO - 2016-03-06 10:41:29 --> Model Class Initialized
INFO - 2016-03-06 10:41:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:41:29 --> Pagination Class Initialized
INFO - 2016-03-06 10:41:29 --> Helper loaded: text_helper
INFO - 2016-03-06 10:41:29 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:41:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:41:29 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 49
INFO - 2016-03-06 10:44:20 --> Config Class Initialized
INFO - 2016-03-06 10:44:20 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:44:20 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:44:20 --> Utf8 Class Initialized
INFO - 2016-03-06 10:44:20 --> URI Class Initialized
INFO - 2016-03-06 10:44:20 --> Router Class Initialized
INFO - 2016-03-06 10:44:20 --> Output Class Initialized
INFO - 2016-03-06 10:44:20 --> Security Class Initialized
DEBUG - 2016-03-06 10:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:44:20 --> Input Class Initialized
INFO - 2016-03-06 10:44:20 --> Language Class Initialized
INFO - 2016-03-06 10:44:20 --> Loader Class Initialized
INFO - 2016-03-06 10:44:20 --> Helper loaded: url_helper
INFO - 2016-03-06 10:44:20 --> Helper loaded: file_helper
INFO - 2016-03-06 10:44:20 --> Helper loaded: date_helper
INFO - 2016-03-06 10:44:20 --> Helper loaded: form_helper
INFO - 2016-03-06 10:44:20 --> Database Driver Class Initialized
INFO - 2016-03-06 10:44:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:44:21 --> Controller Class Initialized
INFO - 2016-03-06 10:44:21 --> Model Class Initialized
INFO - 2016-03-06 10:44:21 --> Model Class Initialized
INFO - 2016-03-06 10:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:44:21 --> Pagination Class Initialized
INFO - 2016-03-06 10:44:21 --> Helper loaded: text_helper
INFO - 2016-03-06 10:44:21 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:44:21 --> Severity: Notice --> Undefined variable: list_bottom C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
ERROR - 2016-03-06 13:44:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
INFO - 2016-03-06 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:44:21 --> Final output sent to browser
DEBUG - 2016-03-06 13:44:21 --> Total execution time: 1.1605
INFO - 2016-03-06 10:44:36 --> Config Class Initialized
INFO - 2016-03-06 10:44:36 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:44:36 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:44:36 --> Utf8 Class Initialized
INFO - 2016-03-06 10:44:36 --> URI Class Initialized
INFO - 2016-03-06 10:44:36 --> Router Class Initialized
INFO - 2016-03-06 10:44:36 --> Output Class Initialized
INFO - 2016-03-06 10:44:36 --> Security Class Initialized
DEBUG - 2016-03-06 10:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:44:36 --> Input Class Initialized
INFO - 2016-03-06 10:44:36 --> Language Class Initialized
INFO - 2016-03-06 10:44:36 --> Loader Class Initialized
INFO - 2016-03-06 10:44:36 --> Helper loaded: url_helper
INFO - 2016-03-06 10:44:36 --> Helper loaded: file_helper
INFO - 2016-03-06 10:44:36 --> Helper loaded: date_helper
INFO - 2016-03-06 10:44:36 --> Helper loaded: form_helper
INFO - 2016-03-06 10:44:37 --> Database Driver Class Initialized
INFO - 2016-03-06 10:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:44:38 --> Controller Class Initialized
INFO - 2016-03-06 10:44:38 --> Model Class Initialized
INFO - 2016-03-06 10:44:38 --> Model Class Initialized
INFO - 2016-03-06 10:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:44:38 --> Pagination Class Initialized
INFO - 2016-03-06 10:44:38 --> Helper loaded: text_helper
INFO - 2016-03-06 10:44:38 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:44:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
INFO - 2016-03-06 13:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:44:38 --> Final output sent to browser
DEBUG - 2016-03-06 13:44:38 --> Total execution time: 1.1516
INFO - 2016-03-06 10:46:00 --> Config Class Initialized
INFO - 2016-03-06 10:46:00 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:46:00 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:46:00 --> Utf8 Class Initialized
INFO - 2016-03-06 10:46:00 --> URI Class Initialized
INFO - 2016-03-06 10:46:00 --> Router Class Initialized
INFO - 2016-03-06 10:46:00 --> Output Class Initialized
INFO - 2016-03-06 10:46:00 --> Security Class Initialized
DEBUG - 2016-03-06 10:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:46:00 --> Input Class Initialized
INFO - 2016-03-06 10:46:00 --> Language Class Initialized
INFO - 2016-03-06 10:46:00 --> Loader Class Initialized
INFO - 2016-03-06 10:46:00 --> Helper loaded: url_helper
INFO - 2016-03-06 10:46:00 --> Helper loaded: file_helper
INFO - 2016-03-06 10:46:00 --> Helper loaded: date_helper
INFO - 2016-03-06 10:46:00 --> Helper loaded: form_helper
INFO - 2016-03-06 10:46:00 --> Database Driver Class Initialized
INFO - 2016-03-06 10:46:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:46:01 --> Controller Class Initialized
INFO - 2016-03-06 10:46:01 --> Model Class Initialized
INFO - 2016-03-06 10:46:01 --> Model Class Initialized
INFO - 2016-03-06 10:46:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:46:01 --> Pagination Class Initialized
INFO - 2016-03-06 10:46:01 --> Helper loaded: text_helper
INFO - 2016-03-06 10:46:01 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:46:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:46:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:46:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:46:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:46:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:46:01 --> Final output sent to browser
DEBUG - 2016-03-06 13:46:01 --> Total execution time: 1.1360
INFO - 2016-03-06 10:46:09 --> Config Class Initialized
INFO - 2016-03-06 10:46:09 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:46:09 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:46:09 --> Utf8 Class Initialized
INFO - 2016-03-06 10:46:09 --> URI Class Initialized
INFO - 2016-03-06 10:46:09 --> Router Class Initialized
INFO - 2016-03-06 10:46:09 --> Output Class Initialized
INFO - 2016-03-06 10:46:09 --> Security Class Initialized
DEBUG - 2016-03-06 10:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:46:09 --> Input Class Initialized
INFO - 2016-03-06 10:46:09 --> Language Class Initialized
INFO - 2016-03-06 10:46:09 --> Loader Class Initialized
INFO - 2016-03-06 10:46:09 --> Helper loaded: url_helper
INFO - 2016-03-06 10:46:09 --> Helper loaded: file_helper
INFO - 2016-03-06 10:46:09 --> Helper loaded: date_helper
INFO - 2016-03-06 10:46:09 --> Helper loaded: form_helper
INFO - 2016-03-06 10:46:09 --> Database Driver Class Initialized
INFO - 2016-03-06 10:46:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:46:10 --> Controller Class Initialized
INFO - 2016-03-06 10:46:10 --> Model Class Initialized
INFO - 2016-03-06 10:46:10 --> Model Class Initialized
INFO - 2016-03-06 10:46:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:46:10 --> Pagination Class Initialized
INFO - 2016-03-06 10:46:10 --> Helper loaded: text_helper
INFO - 2016-03-06 10:46:10 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:46:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
INFO - 2016-03-06 13:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:46:10 --> Final output sent to browser
DEBUG - 2016-03-06 13:46:10 --> Total execution time: 1.2045
INFO - 2016-03-06 10:47:57 --> Config Class Initialized
INFO - 2016-03-06 10:47:57 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:47:57 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:47:57 --> Utf8 Class Initialized
INFO - 2016-03-06 10:47:57 --> URI Class Initialized
INFO - 2016-03-06 10:47:57 --> Router Class Initialized
INFO - 2016-03-06 10:47:57 --> Output Class Initialized
INFO - 2016-03-06 10:47:57 --> Security Class Initialized
DEBUG - 2016-03-06 10:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:47:57 --> Input Class Initialized
INFO - 2016-03-06 10:47:57 --> Language Class Initialized
INFO - 2016-03-06 10:47:57 --> Loader Class Initialized
INFO - 2016-03-06 10:47:57 --> Helper loaded: url_helper
INFO - 2016-03-06 10:47:57 --> Helper loaded: file_helper
INFO - 2016-03-06 10:47:57 --> Helper loaded: date_helper
INFO - 2016-03-06 10:47:57 --> Helper loaded: form_helper
INFO - 2016-03-06 10:47:57 --> Database Driver Class Initialized
INFO - 2016-03-06 10:47:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:47:58 --> Controller Class Initialized
INFO - 2016-03-06 10:47:58 --> Model Class Initialized
INFO - 2016-03-06 10:47:58 --> Model Class Initialized
INFO - 2016-03-06 10:47:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:47:58 --> Pagination Class Initialized
INFO - 2016-03-06 10:47:58 --> Helper loaded: text_helper
INFO - 2016-03-06 10:47:58 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:47:58 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 38
INFO - 2016-03-06 10:48:22 --> Config Class Initialized
INFO - 2016-03-06 10:48:22 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:48:22 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:48:22 --> Utf8 Class Initialized
INFO - 2016-03-06 10:48:22 --> URI Class Initialized
INFO - 2016-03-06 10:48:22 --> Router Class Initialized
INFO - 2016-03-06 10:48:22 --> Output Class Initialized
INFO - 2016-03-06 10:48:22 --> Security Class Initialized
DEBUG - 2016-03-06 10:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:48:22 --> Input Class Initialized
INFO - 2016-03-06 10:48:22 --> Language Class Initialized
INFO - 2016-03-06 10:48:22 --> Loader Class Initialized
INFO - 2016-03-06 10:48:22 --> Helper loaded: url_helper
INFO - 2016-03-06 10:48:22 --> Helper loaded: file_helper
INFO - 2016-03-06 10:48:22 --> Helper loaded: date_helper
INFO - 2016-03-06 10:48:22 --> Helper loaded: form_helper
INFO - 2016-03-06 10:48:22 --> Database Driver Class Initialized
INFO - 2016-03-06 10:48:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:48:23 --> Controller Class Initialized
INFO - 2016-03-06 10:48:23 --> Model Class Initialized
INFO - 2016-03-06 10:48:23 --> Model Class Initialized
INFO - 2016-03-06 10:48:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:48:23 --> Pagination Class Initialized
INFO - 2016-03-06 10:48:23 --> Helper loaded: text_helper
INFO - 2016-03-06 10:48:23 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:48:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:48:23 --> Final output sent to browser
DEBUG - 2016-03-06 13:48:23 --> Total execution time: 1.1796
INFO - 2016-03-06 10:49:17 --> Config Class Initialized
INFO - 2016-03-06 10:49:17 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:49:17 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:49:17 --> Utf8 Class Initialized
INFO - 2016-03-06 10:49:17 --> URI Class Initialized
INFO - 2016-03-06 10:49:17 --> Router Class Initialized
INFO - 2016-03-06 10:49:17 --> Output Class Initialized
INFO - 2016-03-06 10:49:17 --> Security Class Initialized
DEBUG - 2016-03-06 10:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:49:17 --> Input Class Initialized
INFO - 2016-03-06 10:49:17 --> Language Class Initialized
INFO - 2016-03-06 10:49:17 --> Loader Class Initialized
INFO - 2016-03-06 10:49:17 --> Helper loaded: url_helper
INFO - 2016-03-06 10:49:17 --> Helper loaded: file_helper
INFO - 2016-03-06 10:49:17 --> Helper loaded: date_helper
INFO - 2016-03-06 10:49:17 --> Helper loaded: form_helper
INFO - 2016-03-06 10:49:17 --> Database Driver Class Initialized
INFO - 2016-03-06 10:49:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:49:18 --> Controller Class Initialized
INFO - 2016-03-06 10:49:18 --> Model Class Initialized
INFO - 2016-03-06 10:49:18 --> Model Class Initialized
INFO - 2016-03-06 10:49:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:49:18 --> Pagination Class Initialized
INFO - 2016-03-06 10:49:18 --> Helper loaded: text_helper
INFO - 2016-03-06 10:49:18 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:49:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:49:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:49:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:49:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 13:49:18 --> Severity: Notice --> Undefined variable: list_bottom C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
ERROR - 2016-03-06 13:49:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
INFO - 2016-03-06 13:49:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:49:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:49:19 --> Final output sent to browser
DEBUG - 2016-03-06 13:49:19 --> Total execution time: 1.1760
INFO - 2016-03-06 10:50:50 --> Config Class Initialized
INFO - 2016-03-06 10:50:50 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:50:50 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:50:50 --> Utf8 Class Initialized
INFO - 2016-03-06 10:50:50 --> URI Class Initialized
INFO - 2016-03-06 10:50:50 --> Router Class Initialized
INFO - 2016-03-06 10:50:50 --> Output Class Initialized
INFO - 2016-03-06 10:50:50 --> Security Class Initialized
DEBUG - 2016-03-06 10:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:50:50 --> Input Class Initialized
INFO - 2016-03-06 10:50:50 --> Language Class Initialized
INFO - 2016-03-06 10:50:50 --> Loader Class Initialized
INFO - 2016-03-06 10:50:50 --> Helper loaded: url_helper
INFO - 2016-03-06 10:50:50 --> Helper loaded: file_helper
INFO - 2016-03-06 10:50:50 --> Helper loaded: date_helper
INFO - 2016-03-06 10:50:50 --> Helper loaded: form_helper
INFO - 2016-03-06 10:50:50 --> Database Driver Class Initialized
INFO - 2016-03-06 10:50:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:50:51 --> Controller Class Initialized
INFO - 2016-03-06 10:50:51 --> Model Class Initialized
INFO - 2016-03-06 10:50:51 --> Model Class Initialized
INFO - 2016-03-06 10:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:50:51 --> Pagination Class Initialized
INFO - 2016-03-06 10:50:51 --> Helper loaded: text_helper
INFO - 2016-03-06 10:50:51 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:50:51 --> Final output sent to browser
DEBUG - 2016-03-06 13:50:51 --> Total execution time: 1.1684
INFO - 2016-03-06 10:50:55 --> Config Class Initialized
INFO - 2016-03-06 10:50:55 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:50:55 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:50:55 --> Utf8 Class Initialized
INFO - 2016-03-06 10:50:55 --> URI Class Initialized
INFO - 2016-03-06 10:50:55 --> Router Class Initialized
INFO - 2016-03-06 10:50:55 --> Output Class Initialized
INFO - 2016-03-06 10:50:55 --> Security Class Initialized
DEBUG - 2016-03-06 10:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:50:55 --> Input Class Initialized
INFO - 2016-03-06 10:50:55 --> Language Class Initialized
INFO - 2016-03-06 10:50:55 --> Loader Class Initialized
INFO - 2016-03-06 10:50:55 --> Helper loaded: url_helper
INFO - 2016-03-06 10:50:55 --> Helper loaded: file_helper
INFO - 2016-03-06 10:50:55 --> Helper loaded: date_helper
INFO - 2016-03-06 10:50:55 --> Helper loaded: form_helper
INFO - 2016-03-06 10:50:55 --> Database Driver Class Initialized
INFO - 2016-03-06 10:50:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:50:56 --> Controller Class Initialized
INFO - 2016-03-06 10:50:56 --> Model Class Initialized
INFO - 2016-03-06 10:50:56 --> Model Class Initialized
INFO - 2016-03-06 10:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:50:56 --> Pagination Class Initialized
INFO - 2016-03-06 10:50:56 --> Helper loaded: text_helper
INFO - 2016-03-06 10:50:56 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:50:56 --> Final output sent to browser
DEBUG - 2016-03-06 13:50:56 --> Total execution time: 1.1013
INFO - 2016-03-06 10:50:58 --> Config Class Initialized
INFO - 2016-03-06 10:50:58 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:50:58 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:50:58 --> Utf8 Class Initialized
INFO - 2016-03-06 10:50:58 --> URI Class Initialized
INFO - 2016-03-06 10:50:58 --> Router Class Initialized
INFO - 2016-03-06 10:50:58 --> Output Class Initialized
INFO - 2016-03-06 10:50:58 --> Security Class Initialized
DEBUG - 2016-03-06 10:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:50:58 --> Input Class Initialized
INFO - 2016-03-06 10:50:58 --> Language Class Initialized
INFO - 2016-03-06 10:50:58 --> Loader Class Initialized
INFO - 2016-03-06 10:50:58 --> Helper loaded: url_helper
INFO - 2016-03-06 10:50:58 --> Helper loaded: file_helper
INFO - 2016-03-06 10:50:58 --> Helper loaded: date_helper
INFO - 2016-03-06 10:50:58 --> Helper loaded: form_helper
INFO - 2016-03-06 10:50:58 --> Database Driver Class Initialized
INFO - 2016-03-06 10:50:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:50:59 --> Controller Class Initialized
INFO - 2016-03-06 10:50:59 --> Model Class Initialized
INFO - 2016-03-06 10:50:59 --> Model Class Initialized
INFO - 2016-03-06 10:50:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:50:59 --> Pagination Class Initialized
INFO - 2016-03-06 10:50:59 --> Helper loaded: text_helper
INFO - 2016-03-06 10:50:59 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:50:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:50:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:50:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:50:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:50:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:50:59 --> Final output sent to browser
DEBUG - 2016-03-06 13:50:59 --> Total execution time: 1.1124
INFO - 2016-03-06 10:51:02 --> Config Class Initialized
INFO - 2016-03-06 10:51:02 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:51:02 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:51:02 --> Utf8 Class Initialized
INFO - 2016-03-06 10:51:02 --> URI Class Initialized
INFO - 2016-03-06 10:51:02 --> Router Class Initialized
INFO - 2016-03-06 10:51:02 --> Output Class Initialized
INFO - 2016-03-06 10:51:02 --> Security Class Initialized
DEBUG - 2016-03-06 10:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:51:02 --> Input Class Initialized
INFO - 2016-03-06 10:51:02 --> Language Class Initialized
INFO - 2016-03-06 10:51:02 --> Loader Class Initialized
INFO - 2016-03-06 10:51:02 --> Helper loaded: url_helper
INFO - 2016-03-06 10:51:02 --> Helper loaded: file_helper
INFO - 2016-03-06 10:51:02 --> Helper loaded: date_helper
INFO - 2016-03-06 10:51:02 --> Helper loaded: form_helper
INFO - 2016-03-06 10:51:02 --> Database Driver Class Initialized
INFO - 2016-03-06 10:51:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:51:03 --> Controller Class Initialized
INFO - 2016-03-06 10:51:03 --> Model Class Initialized
INFO - 2016-03-06 10:51:03 --> Model Class Initialized
INFO - 2016-03-06 10:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:51:03 --> Pagination Class Initialized
INFO - 2016-03-06 10:51:03 --> Helper loaded: text_helper
INFO - 2016-03-06 10:51:03 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:51:03 --> Final output sent to browser
DEBUG - 2016-03-06 13:51:03 --> Total execution time: 1.1334
INFO - 2016-03-06 10:55:12 --> Config Class Initialized
INFO - 2016-03-06 10:55:12 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:55:12 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:55:12 --> Utf8 Class Initialized
INFO - 2016-03-06 10:55:12 --> URI Class Initialized
INFO - 2016-03-06 10:55:12 --> Router Class Initialized
INFO - 2016-03-06 10:55:12 --> Output Class Initialized
INFO - 2016-03-06 10:55:12 --> Security Class Initialized
DEBUG - 2016-03-06 10:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:55:12 --> Input Class Initialized
INFO - 2016-03-06 10:55:12 --> Language Class Initialized
INFO - 2016-03-06 10:55:12 --> Loader Class Initialized
INFO - 2016-03-06 10:55:12 --> Helper loaded: url_helper
INFO - 2016-03-06 10:55:12 --> Helper loaded: file_helper
INFO - 2016-03-06 10:55:12 --> Helper loaded: date_helper
INFO - 2016-03-06 10:55:12 --> Helper loaded: form_helper
INFO - 2016-03-06 10:55:12 --> Database Driver Class Initialized
INFO - 2016-03-06 10:55:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:55:14 --> Controller Class Initialized
INFO - 2016-03-06 10:55:14 --> Model Class Initialized
INFO - 2016-03-06 10:55:14 --> Model Class Initialized
INFO - 2016-03-06 10:55:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:55:14 --> Pagination Class Initialized
INFO - 2016-03-06 10:55:14 --> Helper loaded: text_helper
INFO - 2016-03-06 10:55:14 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:55:14 --> Final output sent to browser
DEBUG - 2016-03-06 13:55:14 --> Total execution time: 1.2231
INFO - 2016-03-06 10:56:12 --> Config Class Initialized
INFO - 2016-03-06 10:56:12 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:56:12 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:56:12 --> Utf8 Class Initialized
INFO - 2016-03-06 10:56:12 --> URI Class Initialized
INFO - 2016-03-06 10:56:12 --> Router Class Initialized
INFO - 2016-03-06 10:56:12 --> Output Class Initialized
INFO - 2016-03-06 10:56:12 --> Security Class Initialized
DEBUG - 2016-03-06 10:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:56:12 --> Input Class Initialized
INFO - 2016-03-06 10:56:12 --> Language Class Initialized
INFO - 2016-03-06 10:56:12 --> Loader Class Initialized
INFO - 2016-03-06 10:56:12 --> Helper loaded: url_helper
INFO - 2016-03-06 10:56:12 --> Helper loaded: file_helper
INFO - 2016-03-06 10:56:12 --> Helper loaded: date_helper
INFO - 2016-03-06 10:56:12 --> Helper loaded: form_helper
INFO - 2016-03-06 10:56:12 --> Database Driver Class Initialized
INFO - 2016-03-06 10:56:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:56:13 --> Controller Class Initialized
INFO - 2016-03-06 10:56:13 --> Model Class Initialized
INFO - 2016-03-06 10:56:13 --> Model Class Initialized
INFO - 2016-03-06 10:56:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:56:13 --> Pagination Class Initialized
INFO - 2016-03-06 10:56:13 --> Helper loaded: text_helper
INFO - 2016-03-06 10:56:13 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:56:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:56:13 --> Final output sent to browser
DEBUG - 2016-03-06 13:56:13 --> Total execution time: 1.1648
INFO - 2016-03-06 10:57:49 --> Config Class Initialized
INFO - 2016-03-06 10:57:49 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:57:49 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:57:49 --> Utf8 Class Initialized
INFO - 2016-03-06 10:57:49 --> URI Class Initialized
INFO - 2016-03-06 10:57:49 --> Router Class Initialized
INFO - 2016-03-06 10:57:49 --> Output Class Initialized
INFO - 2016-03-06 10:57:49 --> Security Class Initialized
DEBUG - 2016-03-06 10:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:57:49 --> Input Class Initialized
INFO - 2016-03-06 10:57:49 --> Language Class Initialized
INFO - 2016-03-06 10:57:49 --> Loader Class Initialized
INFO - 2016-03-06 10:57:49 --> Helper loaded: url_helper
INFO - 2016-03-06 10:57:49 --> Helper loaded: file_helper
INFO - 2016-03-06 10:57:49 --> Helper loaded: date_helper
INFO - 2016-03-06 10:57:49 --> Helper loaded: form_helper
INFO - 2016-03-06 10:57:49 --> Database Driver Class Initialized
INFO - 2016-03-06 10:57:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:57:50 --> Controller Class Initialized
INFO - 2016-03-06 10:57:50 --> Model Class Initialized
INFO - 2016-03-06 10:57:51 --> Model Class Initialized
INFO - 2016-03-06 10:57:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:57:51 --> Pagination Class Initialized
INFO - 2016-03-06 10:57:51 --> Helper loaded: text_helper
INFO - 2016-03-06 10:57:51 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 13:57:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:57:51 --> Final output sent to browser
DEBUG - 2016-03-06 13:57:51 --> Total execution time: 1.1833
INFO - 2016-03-06 10:58:19 --> Config Class Initialized
INFO - 2016-03-06 10:58:19 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:58:19 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:58:19 --> Utf8 Class Initialized
INFO - 2016-03-06 10:58:19 --> URI Class Initialized
INFO - 2016-03-06 10:58:19 --> Router Class Initialized
INFO - 2016-03-06 10:58:19 --> Output Class Initialized
INFO - 2016-03-06 10:58:19 --> Security Class Initialized
DEBUG - 2016-03-06 10:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:58:19 --> Input Class Initialized
INFO - 2016-03-06 10:58:19 --> Language Class Initialized
INFO - 2016-03-06 10:58:19 --> Loader Class Initialized
INFO - 2016-03-06 10:58:19 --> Helper loaded: url_helper
INFO - 2016-03-06 10:58:19 --> Helper loaded: file_helper
INFO - 2016-03-06 10:58:19 --> Helper loaded: date_helper
INFO - 2016-03-06 10:58:19 --> Helper loaded: form_helper
INFO - 2016-03-06 10:58:19 --> Database Driver Class Initialized
INFO - 2016-03-06 10:58:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:58:20 --> Controller Class Initialized
INFO - 2016-03-06 10:58:20 --> Model Class Initialized
INFO - 2016-03-06 10:58:20 --> Model Class Initialized
INFO - 2016-03-06 10:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:58:20 --> Pagination Class Initialized
INFO - 2016-03-06 10:58:20 --> Helper loaded: text_helper
INFO - 2016-03-06 10:58:20 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:58:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:58:20 --> Final output sent to browser
DEBUG - 2016-03-06 13:58:20 --> Total execution time: 1.1114
INFO - 2016-03-06 10:58:25 --> Config Class Initialized
INFO - 2016-03-06 10:58:25 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:58:25 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:58:25 --> Utf8 Class Initialized
INFO - 2016-03-06 10:58:26 --> URI Class Initialized
INFO - 2016-03-06 10:58:26 --> Router Class Initialized
INFO - 2016-03-06 10:58:26 --> Output Class Initialized
INFO - 2016-03-06 10:58:26 --> Security Class Initialized
DEBUG - 2016-03-06 10:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:58:26 --> Input Class Initialized
INFO - 2016-03-06 10:58:26 --> Language Class Initialized
INFO - 2016-03-06 10:58:26 --> Loader Class Initialized
INFO - 2016-03-06 10:58:26 --> Helper loaded: url_helper
INFO - 2016-03-06 10:58:26 --> Helper loaded: file_helper
INFO - 2016-03-06 10:58:26 --> Helper loaded: date_helper
INFO - 2016-03-06 10:58:26 --> Helper loaded: form_helper
INFO - 2016-03-06 10:58:26 --> Database Driver Class Initialized
INFO - 2016-03-06 10:58:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:58:27 --> Controller Class Initialized
INFO - 2016-03-06 10:58:27 --> Model Class Initialized
INFO - 2016-03-06 10:58:27 --> Model Class Initialized
INFO - 2016-03-06 10:58:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:58:27 --> Pagination Class Initialized
INFO - 2016-03-06 10:58:27 --> Helper loaded: text_helper
INFO - 2016-03-06 10:58:27 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:58:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:58:27 --> Final output sent to browser
DEBUG - 2016-03-06 13:58:27 --> Total execution time: 1.1217
INFO - 2016-03-06 10:59:11 --> Config Class Initialized
INFO - 2016-03-06 10:59:11 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:59:11 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:59:11 --> Utf8 Class Initialized
INFO - 2016-03-06 10:59:11 --> URI Class Initialized
INFO - 2016-03-06 10:59:11 --> Router Class Initialized
INFO - 2016-03-06 10:59:11 --> Output Class Initialized
INFO - 2016-03-06 10:59:11 --> Security Class Initialized
DEBUG - 2016-03-06 10:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:59:11 --> Input Class Initialized
INFO - 2016-03-06 10:59:11 --> Language Class Initialized
INFO - 2016-03-06 10:59:11 --> Loader Class Initialized
INFO - 2016-03-06 10:59:11 --> Helper loaded: url_helper
INFO - 2016-03-06 10:59:11 --> Helper loaded: file_helper
INFO - 2016-03-06 10:59:11 --> Helper loaded: date_helper
INFO - 2016-03-06 10:59:11 --> Helper loaded: form_helper
INFO - 2016-03-06 10:59:11 --> Database Driver Class Initialized
INFO - 2016-03-06 10:59:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:59:12 --> Controller Class Initialized
INFO - 2016-03-06 10:59:12 --> Model Class Initialized
INFO - 2016-03-06 10:59:12 --> Model Class Initialized
INFO - 2016-03-06 10:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:59:12 --> Pagination Class Initialized
INFO - 2016-03-06 10:59:12 --> Helper loaded: text_helper
INFO - 2016-03-06 10:59:12 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:59:12 --> Final output sent to browser
DEBUG - 2016-03-06 13:59:12 --> Total execution time: 1.1376
INFO - 2016-03-06 10:59:35 --> Config Class Initialized
INFO - 2016-03-06 10:59:35 --> Hooks Class Initialized
DEBUG - 2016-03-06 10:59:35 --> UTF-8 Support Enabled
INFO - 2016-03-06 10:59:35 --> Utf8 Class Initialized
INFO - 2016-03-06 10:59:35 --> URI Class Initialized
INFO - 2016-03-06 10:59:35 --> Router Class Initialized
INFO - 2016-03-06 10:59:35 --> Output Class Initialized
INFO - 2016-03-06 10:59:35 --> Security Class Initialized
DEBUG - 2016-03-06 10:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 10:59:35 --> Input Class Initialized
INFO - 2016-03-06 10:59:35 --> Language Class Initialized
INFO - 2016-03-06 10:59:35 --> Loader Class Initialized
INFO - 2016-03-06 10:59:35 --> Helper loaded: url_helper
INFO - 2016-03-06 10:59:35 --> Helper loaded: file_helper
INFO - 2016-03-06 10:59:35 --> Helper loaded: date_helper
INFO - 2016-03-06 10:59:35 --> Helper loaded: form_helper
INFO - 2016-03-06 10:59:35 --> Database Driver Class Initialized
INFO - 2016-03-06 10:59:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 10:59:36 --> Controller Class Initialized
INFO - 2016-03-06 10:59:36 --> Model Class Initialized
INFO - 2016-03-06 10:59:36 --> Model Class Initialized
INFO - 2016-03-06 10:59:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 10:59:36 --> Pagination Class Initialized
INFO - 2016-03-06 10:59:36 --> Helper loaded: text_helper
INFO - 2016-03-06 10:59:36 --> Helper loaded: cookie_helper
INFO - 2016-03-06 13:59:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 13:59:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 13:59:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 13:59:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 13:59:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 13:59:36 --> Final output sent to browser
DEBUG - 2016-03-06 13:59:36 --> Total execution time: 1.1037
INFO - 2016-03-06 11:00:14 --> Config Class Initialized
INFO - 2016-03-06 11:00:14 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:00:14 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:00:14 --> Utf8 Class Initialized
INFO - 2016-03-06 11:00:14 --> URI Class Initialized
INFO - 2016-03-06 11:00:14 --> Router Class Initialized
INFO - 2016-03-06 11:00:14 --> Output Class Initialized
INFO - 2016-03-06 11:00:14 --> Security Class Initialized
DEBUG - 2016-03-06 11:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:00:14 --> Input Class Initialized
INFO - 2016-03-06 11:00:14 --> Language Class Initialized
INFO - 2016-03-06 11:00:14 --> Loader Class Initialized
INFO - 2016-03-06 11:00:14 --> Helper loaded: url_helper
INFO - 2016-03-06 11:00:14 --> Helper loaded: file_helper
INFO - 2016-03-06 11:00:14 --> Helper loaded: date_helper
INFO - 2016-03-06 11:00:14 --> Helper loaded: form_helper
INFO - 2016-03-06 11:00:14 --> Database Driver Class Initialized
INFO - 2016-03-06 11:00:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:00:15 --> Controller Class Initialized
INFO - 2016-03-06 11:00:15 --> Model Class Initialized
INFO - 2016-03-06 11:00:15 --> Model Class Initialized
INFO - 2016-03-06 11:00:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:00:15 --> Pagination Class Initialized
INFO - 2016-03-06 11:00:15 --> Helper loaded: text_helper
INFO - 2016-03-06 11:00:15 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:00:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:00:15 --> Final output sent to browser
DEBUG - 2016-03-06 14:00:15 --> Total execution time: 1.1527
INFO - 2016-03-06 11:00:18 --> Config Class Initialized
INFO - 2016-03-06 11:00:18 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:00:18 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:00:18 --> Utf8 Class Initialized
INFO - 2016-03-06 11:00:18 --> URI Class Initialized
INFO - 2016-03-06 11:00:18 --> Router Class Initialized
INFO - 2016-03-06 11:00:18 --> Output Class Initialized
INFO - 2016-03-06 11:00:18 --> Security Class Initialized
DEBUG - 2016-03-06 11:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:00:18 --> Input Class Initialized
INFO - 2016-03-06 11:00:18 --> Language Class Initialized
INFO - 2016-03-06 11:00:18 --> Loader Class Initialized
INFO - 2016-03-06 11:00:18 --> Helper loaded: url_helper
INFO - 2016-03-06 11:00:18 --> Helper loaded: file_helper
INFO - 2016-03-06 11:00:18 --> Helper loaded: date_helper
INFO - 2016-03-06 11:00:18 --> Helper loaded: form_helper
INFO - 2016-03-06 11:00:18 --> Database Driver Class Initialized
INFO - 2016-03-06 11:00:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:00:19 --> Controller Class Initialized
INFO - 2016-03-06 11:00:19 --> Model Class Initialized
INFO - 2016-03-06 11:00:19 --> Model Class Initialized
INFO - 2016-03-06 11:00:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:00:19 --> Pagination Class Initialized
INFO - 2016-03-06 11:00:19 --> Helper loaded: text_helper
INFO - 2016-03-06 11:00:19 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:00:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:00:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:00:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:00:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:00:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:00:19 --> Final output sent to browser
DEBUG - 2016-03-06 14:00:19 --> Total execution time: 1.1193
INFO - 2016-03-06 11:00:41 --> Config Class Initialized
INFO - 2016-03-06 11:00:41 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:00:41 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:00:41 --> Utf8 Class Initialized
INFO - 2016-03-06 11:00:41 --> URI Class Initialized
INFO - 2016-03-06 11:00:41 --> Router Class Initialized
INFO - 2016-03-06 11:00:41 --> Output Class Initialized
INFO - 2016-03-06 11:00:41 --> Security Class Initialized
DEBUG - 2016-03-06 11:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:00:41 --> Input Class Initialized
INFO - 2016-03-06 11:00:41 --> Language Class Initialized
INFO - 2016-03-06 11:00:41 --> Loader Class Initialized
INFO - 2016-03-06 11:00:41 --> Helper loaded: url_helper
INFO - 2016-03-06 11:00:41 --> Helper loaded: file_helper
INFO - 2016-03-06 11:00:41 --> Helper loaded: date_helper
INFO - 2016-03-06 11:00:41 --> Helper loaded: form_helper
INFO - 2016-03-06 11:00:41 --> Database Driver Class Initialized
INFO - 2016-03-06 11:00:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:00:42 --> Controller Class Initialized
INFO - 2016-03-06 11:00:42 --> Model Class Initialized
INFO - 2016-03-06 11:00:42 --> Model Class Initialized
INFO - 2016-03-06 11:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:00:42 --> Pagination Class Initialized
INFO - 2016-03-06 11:00:42 --> Helper loaded: text_helper
INFO - 2016-03-06 11:00:42 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 14:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:00:42 --> Final output sent to browser
DEBUG - 2016-03-06 14:00:42 --> Total execution time: 1.1878
INFO - 2016-03-06 11:21:19 --> Config Class Initialized
INFO - 2016-03-06 11:21:19 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:21:19 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:21:19 --> Utf8 Class Initialized
INFO - 2016-03-06 11:21:19 --> URI Class Initialized
DEBUG - 2016-03-06 11:21:19 --> No URI present. Default controller set.
INFO - 2016-03-06 11:21:19 --> Router Class Initialized
INFO - 2016-03-06 11:21:19 --> Output Class Initialized
INFO - 2016-03-06 11:21:19 --> Security Class Initialized
DEBUG - 2016-03-06 11:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:21:19 --> Input Class Initialized
INFO - 2016-03-06 11:21:19 --> Language Class Initialized
INFO - 2016-03-06 11:21:19 --> Loader Class Initialized
INFO - 2016-03-06 11:21:19 --> Helper loaded: url_helper
INFO - 2016-03-06 11:21:19 --> Helper loaded: file_helper
INFO - 2016-03-06 11:21:19 --> Helper loaded: date_helper
INFO - 2016-03-06 11:21:19 --> Helper loaded: form_helper
INFO - 2016-03-06 11:21:19 --> Database Driver Class Initialized
INFO - 2016-03-06 11:21:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:21:20 --> Controller Class Initialized
INFO - 2016-03-06 11:21:20 --> Model Class Initialized
INFO - 2016-03-06 11:21:20 --> Model Class Initialized
INFO - 2016-03-06 11:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:21:20 --> Pagination Class Initialized
INFO - 2016-03-06 11:21:20 --> Helper loaded: text_helper
INFO - 2016-03-06 11:21:20 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 14:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:21:20 --> Final output sent to browser
DEBUG - 2016-03-06 14:21:20 --> Total execution time: 1.1201
INFO - 2016-03-06 11:21:22 --> Config Class Initialized
INFO - 2016-03-06 11:21:22 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:21:22 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:21:22 --> Utf8 Class Initialized
INFO - 2016-03-06 11:21:22 --> URI Class Initialized
INFO - 2016-03-06 11:21:22 --> Router Class Initialized
INFO - 2016-03-06 11:21:22 --> Output Class Initialized
INFO - 2016-03-06 11:21:22 --> Security Class Initialized
DEBUG - 2016-03-06 11:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:21:22 --> Input Class Initialized
INFO - 2016-03-06 11:21:22 --> Language Class Initialized
INFO - 2016-03-06 11:21:22 --> Loader Class Initialized
INFO - 2016-03-06 11:21:22 --> Helper loaded: url_helper
INFO - 2016-03-06 11:21:22 --> Helper loaded: file_helper
INFO - 2016-03-06 11:21:22 --> Helper loaded: date_helper
INFO - 2016-03-06 11:21:22 --> Helper loaded: form_helper
INFO - 2016-03-06 11:21:22 --> Database Driver Class Initialized
INFO - 2016-03-06 11:21:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:21:23 --> Controller Class Initialized
INFO - 2016-03-06 11:21:23 --> Model Class Initialized
INFO - 2016-03-06 11:21:23 --> Model Class Initialized
INFO - 2016-03-06 11:21:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:21:23 --> Pagination Class Initialized
INFO - 2016-03-06 11:21:23 --> Helper loaded: text_helper
INFO - 2016-03-06 11:21:23 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:21:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:21:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:21:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:21:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:21:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:21:23 --> Final output sent to browser
DEBUG - 2016-03-06 14:21:23 --> Total execution time: 1.1406
INFO - 2016-03-06 11:21:47 --> Config Class Initialized
INFO - 2016-03-06 11:21:47 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:21:47 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:21:47 --> Utf8 Class Initialized
INFO - 2016-03-06 11:21:47 --> URI Class Initialized
INFO - 2016-03-06 11:21:47 --> Router Class Initialized
INFO - 2016-03-06 11:21:47 --> Output Class Initialized
INFO - 2016-03-06 11:21:47 --> Security Class Initialized
DEBUG - 2016-03-06 11:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:21:47 --> Input Class Initialized
INFO - 2016-03-06 11:21:47 --> Language Class Initialized
INFO - 2016-03-06 11:21:47 --> Loader Class Initialized
INFO - 2016-03-06 11:21:47 --> Helper loaded: url_helper
INFO - 2016-03-06 11:21:47 --> Helper loaded: file_helper
INFO - 2016-03-06 11:21:47 --> Helper loaded: date_helper
INFO - 2016-03-06 11:21:47 --> Helper loaded: form_helper
INFO - 2016-03-06 11:21:47 --> Database Driver Class Initialized
INFO - 2016-03-06 11:21:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:21:48 --> Controller Class Initialized
INFO - 2016-03-06 11:21:48 --> Model Class Initialized
INFO - 2016-03-06 11:21:48 --> Model Class Initialized
INFO - 2016-03-06 11:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:21:48 --> Pagination Class Initialized
INFO - 2016-03-06 11:21:48 --> Helper loaded: text_helper
INFO - 2016-03-06 11:21:48 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 14:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:21:48 --> Final output sent to browser
DEBUG - 2016-03-06 14:21:48 --> Total execution time: 1.1716
INFO - 2016-03-06 11:21:49 --> Config Class Initialized
INFO - 2016-03-06 11:21:49 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:21:49 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:21:49 --> Utf8 Class Initialized
INFO - 2016-03-06 11:21:49 --> URI Class Initialized
INFO - 2016-03-06 11:21:49 --> Router Class Initialized
INFO - 2016-03-06 11:21:49 --> Output Class Initialized
INFO - 2016-03-06 11:21:49 --> Security Class Initialized
DEBUG - 2016-03-06 11:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:21:49 --> Input Class Initialized
INFO - 2016-03-06 11:21:49 --> Language Class Initialized
INFO - 2016-03-06 11:21:49 --> Loader Class Initialized
INFO - 2016-03-06 11:21:49 --> Helper loaded: url_helper
INFO - 2016-03-06 11:21:49 --> Helper loaded: file_helper
INFO - 2016-03-06 11:21:49 --> Helper loaded: date_helper
INFO - 2016-03-06 11:21:49 --> Helper loaded: form_helper
INFO - 2016-03-06 11:21:49 --> Database Driver Class Initialized
INFO - 2016-03-06 11:21:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:21:50 --> Controller Class Initialized
INFO - 2016-03-06 11:21:50 --> Model Class Initialized
INFO - 2016-03-06 11:21:50 --> Model Class Initialized
INFO - 2016-03-06 11:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:21:50 --> Pagination Class Initialized
INFO - 2016-03-06 11:21:50 --> Helper loaded: text_helper
INFO - 2016-03-06 11:21:50 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:21:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:21:50 --> Final output sent to browser
DEBUG - 2016-03-06 14:21:50 --> Total execution time: 1.1324
INFO - 2016-03-06 11:21:54 --> Config Class Initialized
INFO - 2016-03-06 11:21:54 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:21:54 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:21:54 --> Utf8 Class Initialized
INFO - 2016-03-06 11:21:54 --> URI Class Initialized
INFO - 2016-03-06 11:21:54 --> Router Class Initialized
INFO - 2016-03-06 11:21:54 --> Output Class Initialized
INFO - 2016-03-06 11:21:54 --> Security Class Initialized
DEBUG - 2016-03-06 11:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:21:54 --> Input Class Initialized
INFO - 2016-03-06 11:21:54 --> Language Class Initialized
INFO - 2016-03-06 11:21:54 --> Loader Class Initialized
INFO - 2016-03-06 11:21:54 --> Helper loaded: url_helper
INFO - 2016-03-06 11:21:54 --> Helper loaded: file_helper
INFO - 2016-03-06 11:21:54 --> Helper loaded: date_helper
INFO - 2016-03-06 11:21:54 --> Helper loaded: form_helper
INFO - 2016-03-06 11:21:54 --> Database Driver Class Initialized
INFO - 2016-03-06 11:21:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:21:55 --> Controller Class Initialized
INFO - 2016-03-06 11:21:55 --> Model Class Initialized
INFO - 2016-03-06 11:21:55 --> Model Class Initialized
INFO - 2016-03-06 11:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:21:55 --> Pagination Class Initialized
INFO - 2016-03-06 11:21:55 --> Helper loaded: text_helper
INFO - 2016-03-06 11:21:55 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:21:55 --> Final output sent to browser
DEBUG - 2016-03-06 14:21:55 --> Total execution time: 1.1315
INFO - 2016-03-06 11:28:22 --> Config Class Initialized
INFO - 2016-03-06 11:28:22 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:28:22 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:28:22 --> Utf8 Class Initialized
INFO - 2016-03-06 11:28:22 --> URI Class Initialized
INFO - 2016-03-06 11:28:22 --> Router Class Initialized
INFO - 2016-03-06 11:28:23 --> Output Class Initialized
INFO - 2016-03-06 11:28:23 --> Security Class Initialized
DEBUG - 2016-03-06 11:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:28:23 --> Input Class Initialized
INFO - 2016-03-06 11:28:23 --> Language Class Initialized
INFO - 2016-03-06 11:28:23 --> Loader Class Initialized
INFO - 2016-03-06 11:28:23 --> Helper loaded: url_helper
INFO - 2016-03-06 11:28:23 --> Helper loaded: file_helper
INFO - 2016-03-06 11:28:23 --> Helper loaded: date_helper
INFO - 2016-03-06 11:28:23 --> Helper loaded: form_helper
INFO - 2016-03-06 11:28:23 --> Database Driver Class Initialized
INFO - 2016-03-06 11:28:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:28:24 --> Controller Class Initialized
INFO - 2016-03-06 11:28:24 --> Model Class Initialized
INFO - 2016-03-06 11:28:24 --> Model Class Initialized
INFO - 2016-03-06 11:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:28:24 --> Pagination Class Initialized
INFO - 2016-03-06 11:28:24 --> Helper loaded: text_helper
INFO - 2016-03-06 11:28:24 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:28:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:28:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:28:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:28:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:28:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:28:24 --> Final output sent to browser
DEBUG - 2016-03-06 14:28:24 --> Total execution time: 1.1181
INFO - 2016-03-06 11:28:25 --> Config Class Initialized
INFO - 2016-03-06 11:28:25 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:28:25 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:28:26 --> Utf8 Class Initialized
INFO - 2016-03-06 11:28:26 --> URI Class Initialized
INFO - 2016-03-06 11:28:26 --> Router Class Initialized
INFO - 2016-03-06 11:28:26 --> Output Class Initialized
INFO - 2016-03-06 11:28:26 --> Security Class Initialized
DEBUG - 2016-03-06 11:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:28:26 --> Input Class Initialized
INFO - 2016-03-06 11:28:26 --> Language Class Initialized
INFO - 2016-03-06 11:28:26 --> Loader Class Initialized
INFO - 2016-03-06 11:28:26 --> Helper loaded: url_helper
INFO - 2016-03-06 11:28:26 --> Helper loaded: file_helper
INFO - 2016-03-06 11:28:26 --> Helper loaded: date_helper
INFO - 2016-03-06 11:28:26 --> Helper loaded: form_helper
INFO - 2016-03-06 11:28:26 --> Database Driver Class Initialized
INFO - 2016-03-06 11:28:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:28:27 --> Controller Class Initialized
INFO - 2016-03-06 11:28:27 --> Model Class Initialized
INFO - 2016-03-06 11:28:27 --> Model Class Initialized
INFO - 2016-03-06 11:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:28:27 --> Pagination Class Initialized
INFO - 2016-03-06 11:28:27 --> Helper loaded: text_helper
INFO - 2016-03-06 11:28:27 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:28:27 --> Final output sent to browser
DEBUG - 2016-03-06 14:28:27 --> Total execution time: 1.1308
INFO - 2016-03-06 11:29:22 --> Config Class Initialized
INFO - 2016-03-06 11:29:22 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:29:22 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:29:22 --> Utf8 Class Initialized
INFO - 2016-03-06 11:29:22 --> URI Class Initialized
INFO - 2016-03-06 11:29:22 --> Router Class Initialized
INFO - 2016-03-06 11:29:22 --> Output Class Initialized
INFO - 2016-03-06 11:29:22 --> Security Class Initialized
DEBUG - 2016-03-06 11:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:29:22 --> Input Class Initialized
INFO - 2016-03-06 11:29:22 --> Language Class Initialized
INFO - 2016-03-06 11:29:22 --> Loader Class Initialized
INFO - 2016-03-06 11:29:22 --> Helper loaded: url_helper
INFO - 2016-03-06 11:29:22 --> Helper loaded: file_helper
INFO - 2016-03-06 11:29:22 --> Helper loaded: date_helper
INFO - 2016-03-06 11:29:22 --> Helper loaded: form_helper
INFO - 2016-03-06 11:29:22 --> Database Driver Class Initialized
INFO - 2016-03-06 11:29:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:29:23 --> Controller Class Initialized
INFO - 2016-03-06 11:29:23 --> Model Class Initialized
INFO - 2016-03-06 11:29:23 --> Model Class Initialized
INFO - 2016-03-06 11:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:29:23 --> Pagination Class Initialized
INFO - 2016-03-06 11:29:23 --> Helper loaded: text_helper
INFO - 2016-03-06 11:29:23 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:29:23 --> Final output sent to browser
DEBUG - 2016-03-06 14:29:23 --> Total execution time: 1.1163
INFO - 2016-03-06 11:29:26 --> Config Class Initialized
INFO - 2016-03-06 11:29:26 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:29:26 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:29:26 --> Utf8 Class Initialized
INFO - 2016-03-06 11:29:26 --> URI Class Initialized
INFO - 2016-03-06 11:29:26 --> Router Class Initialized
INFO - 2016-03-06 11:29:26 --> Output Class Initialized
INFO - 2016-03-06 11:29:26 --> Security Class Initialized
DEBUG - 2016-03-06 11:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:29:26 --> Input Class Initialized
INFO - 2016-03-06 11:29:26 --> Language Class Initialized
INFO - 2016-03-06 11:29:26 --> Loader Class Initialized
INFO - 2016-03-06 11:29:26 --> Helper loaded: url_helper
INFO - 2016-03-06 11:29:26 --> Helper loaded: file_helper
INFO - 2016-03-06 11:29:26 --> Helper loaded: date_helper
INFO - 2016-03-06 11:29:26 --> Helper loaded: form_helper
INFO - 2016-03-06 11:29:26 --> Database Driver Class Initialized
INFO - 2016-03-06 11:29:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:29:27 --> Controller Class Initialized
INFO - 2016-03-06 11:29:27 --> Model Class Initialized
INFO - 2016-03-06 11:29:27 --> Model Class Initialized
INFO - 2016-03-06 11:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:29:27 --> Pagination Class Initialized
INFO - 2016-03-06 11:29:27 --> Helper loaded: text_helper
INFO - 2016-03-06 11:29:27 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 14:29:27 --> Severity: Notice --> Undefined variable: list_bottom C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
ERROR - 2016-03-06 14:29:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 16
INFO - 2016-03-06 14:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:29:27 --> Final output sent to browser
DEBUG - 2016-03-06 14:29:27 --> Total execution time: 1.1875
INFO - 2016-03-06 11:30:26 --> Config Class Initialized
INFO - 2016-03-06 11:30:26 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:30:26 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:30:26 --> Utf8 Class Initialized
INFO - 2016-03-06 11:30:26 --> URI Class Initialized
INFO - 2016-03-06 11:30:27 --> Router Class Initialized
INFO - 2016-03-06 11:30:27 --> Output Class Initialized
INFO - 2016-03-06 11:30:27 --> Security Class Initialized
DEBUG - 2016-03-06 11:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:30:27 --> Input Class Initialized
INFO - 2016-03-06 11:30:27 --> Language Class Initialized
INFO - 2016-03-06 11:30:27 --> Loader Class Initialized
INFO - 2016-03-06 11:30:27 --> Helper loaded: url_helper
INFO - 2016-03-06 11:30:27 --> Helper loaded: file_helper
INFO - 2016-03-06 11:30:27 --> Helper loaded: date_helper
INFO - 2016-03-06 11:30:27 --> Helper loaded: form_helper
INFO - 2016-03-06 11:30:27 --> Database Driver Class Initialized
INFO - 2016-03-06 11:30:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:30:28 --> Controller Class Initialized
INFO - 2016-03-06 11:30:28 --> Model Class Initialized
INFO - 2016-03-06 11:30:28 --> Model Class Initialized
INFO - 2016-03-06 11:30:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:30:28 --> Pagination Class Initialized
INFO - 2016-03-06 11:30:28 --> Helper loaded: text_helper
INFO - 2016-03-06 11:30:28 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 14:30:28 --> Severity: Notice --> Undefined variable: list_bottom C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
ERROR - 2016-03-06 14:30:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-06 14:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:30:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:30:28 --> Final output sent to browser
DEBUG - 2016-03-06 14:30:28 --> Total execution time: 1.2011
INFO - 2016-03-06 11:30:54 --> Config Class Initialized
INFO - 2016-03-06 11:30:54 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:30:54 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:30:54 --> Utf8 Class Initialized
INFO - 2016-03-06 11:30:54 --> URI Class Initialized
INFO - 2016-03-06 11:30:54 --> Router Class Initialized
INFO - 2016-03-06 11:30:54 --> Output Class Initialized
INFO - 2016-03-06 11:30:54 --> Security Class Initialized
DEBUG - 2016-03-06 11:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:30:54 --> Input Class Initialized
INFO - 2016-03-06 11:30:54 --> Language Class Initialized
INFO - 2016-03-06 11:30:54 --> Loader Class Initialized
INFO - 2016-03-06 11:30:54 --> Helper loaded: url_helper
INFO - 2016-03-06 11:30:54 --> Helper loaded: file_helper
INFO - 2016-03-06 11:30:54 --> Helper loaded: date_helper
INFO - 2016-03-06 11:30:54 --> Helper loaded: form_helper
INFO - 2016-03-06 11:30:54 --> Database Driver Class Initialized
INFO - 2016-03-06 11:30:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:30:55 --> Controller Class Initialized
INFO - 2016-03-06 11:30:55 --> Model Class Initialized
INFO - 2016-03-06 11:30:55 --> Model Class Initialized
INFO - 2016-03-06 11:30:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:30:55 --> Pagination Class Initialized
INFO - 2016-03-06 11:30:55 --> Helper loaded: text_helper
INFO - 2016-03-06 11:30:55 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:30:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:30:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:30:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:30:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:30:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:30:55 --> Final output sent to browser
DEBUG - 2016-03-06 14:30:55 --> Total execution time: 1.1112
INFO - 2016-03-06 11:30:57 --> Config Class Initialized
INFO - 2016-03-06 11:30:57 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:30:57 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:30:57 --> Utf8 Class Initialized
INFO - 2016-03-06 11:30:57 --> URI Class Initialized
INFO - 2016-03-06 11:30:57 --> Router Class Initialized
INFO - 2016-03-06 11:30:57 --> Output Class Initialized
INFO - 2016-03-06 11:30:57 --> Security Class Initialized
DEBUG - 2016-03-06 11:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:30:57 --> Input Class Initialized
INFO - 2016-03-06 11:30:57 --> Language Class Initialized
INFO - 2016-03-06 11:30:57 --> Loader Class Initialized
INFO - 2016-03-06 11:30:57 --> Helper loaded: url_helper
INFO - 2016-03-06 11:30:57 --> Helper loaded: file_helper
INFO - 2016-03-06 11:30:57 --> Helper loaded: date_helper
INFO - 2016-03-06 11:30:57 --> Helper loaded: form_helper
INFO - 2016-03-06 11:30:57 --> Database Driver Class Initialized
INFO - 2016-03-06 11:30:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:30:58 --> Controller Class Initialized
INFO - 2016-03-06 11:30:58 --> Model Class Initialized
INFO - 2016-03-06 11:30:58 --> Model Class Initialized
INFO - 2016-03-06 11:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:30:58 --> Pagination Class Initialized
INFO - 2016-03-06 11:30:58 --> Helper loaded: text_helper
INFO - 2016-03-06 11:30:58 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 14:30:58 --> Severity: Notice --> Undefined variable: list_bottom C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
ERROR - 2016-03-06 14:30:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-06 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:30:58 --> Final output sent to browser
DEBUG - 2016-03-06 14:30:58 --> Total execution time: 1.1965
INFO - 2016-03-06 11:33:12 --> Config Class Initialized
INFO - 2016-03-06 11:33:12 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:33:12 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:33:12 --> Utf8 Class Initialized
INFO - 2016-03-06 11:33:12 --> URI Class Initialized
INFO - 2016-03-06 11:33:12 --> Router Class Initialized
INFO - 2016-03-06 11:33:12 --> Output Class Initialized
INFO - 2016-03-06 11:33:13 --> Security Class Initialized
DEBUG - 2016-03-06 11:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:33:13 --> Input Class Initialized
INFO - 2016-03-06 11:33:13 --> Language Class Initialized
INFO - 2016-03-06 11:33:13 --> Loader Class Initialized
INFO - 2016-03-06 11:33:13 --> Helper loaded: url_helper
INFO - 2016-03-06 11:33:13 --> Helper loaded: file_helper
INFO - 2016-03-06 11:33:13 --> Helper loaded: date_helper
INFO - 2016-03-06 11:33:13 --> Helper loaded: form_helper
INFO - 2016-03-06 11:33:13 --> Database Driver Class Initialized
INFO - 2016-03-06 11:33:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:33:14 --> Controller Class Initialized
INFO - 2016-03-06 11:33:14 --> Model Class Initialized
INFO - 2016-03-06 11:33:14 --> Model Class Initialized
INFO - 2016-03-06 11:33:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:33:14 --> Pagination Class Initialized
INFO - 2016-03-06 11:33:14 --> Helper loaded: text_helper
INFO - 2016-03-06 11:33:14 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:33:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:33:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:33:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:33:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:33:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:33:14 --> Final output sent to browser
DEBUG - 2016-03-06 14:33:14 --> Total execution time: 1.1208
INFO - 2016-03-06 11:33:19 --> Config Class Initialized
INFO - 2016-03-06 11:33:19 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:33:19 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:33:19 --> Utf8 Class Initialized
INFO - 2016-03-06 11:33:19 --> URI Class Initialized
INFO - 2016-03-06 11:33:19 --> Router Class Initialized
INFO - 2016-03-06 11:33:19 --> Output Class Initialized
INFO - 2016-03-06 11:33:19 --> Security Class Initialized
DEBUG - 2016-03-06 11:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:33:19 --> Input Class Initialized
INFO - 2016-03-06 11:33:19 --> Language Class Initialized
INFO - 2016-03-06 11:33:19 --> Loader Class Initialized
INFO - 2016-03-06 11:33:19 --> Helper loaded: url_helper
INFO - 2016-03-06 11:33:19 --> Helper loaded: file_helper
INFO - 2016-03-06 11:33:19 --> Helper loaded: date_helper
INFO - 2016-03-06 11:33:19 --> Helper loaded: form_helper
INFO - 2016-03-06 11:33:19 --> Database Driver Class Initialized
INFO - 2016-03-06 11:33:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:33:21 --> Controller Class Initialized
INFO - 2016-03-06 11:33:21 --> Model Class Initialized
INFO - 2016-03-06 11:33:21 --> Model Class Initialized
INFO - 2016-03-06 11:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:33:21 --> Pagination Class Initialized
INFO - 2016-03-06 11:33:21 --> Helper loaded: text_helper
INFO - 2016-03-06 11:33:21 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:33:21 --> Final output sent to browser
DEBUG - 2016-03-06 14:33:21 --> Total execution time: 1.1411
INFO - 2016-03-06 11:33:30 --> Config Class Initialized
INFO - 2016-03-06 11:33:30 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:33:30 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:33:30 --> Utf8 Class Initialized
INFO - 2016-03-06 11:33:30 --> URI Class Initialized
INFO - 2016-03-06 11:33:30 --> Router Class Initialized
INFO - 2016-03-06 11:33:30 --> Output Class Initialized
INFO - 2016-03-06 11:33:30 --> Security Class Initialized
DEBUG - 2016-03-06 11:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:33:30 --> Input Class Initialized
INFO - 2016-03-06 11:33:30 --> Language Class Initialized
INFO - 2016-03-06 11:33:30 --> Loader Class Initialized
INFO - 2016-03-06 11:33:30 --> Helper loaded: url_helper
INFO - 2016-03-06 11:33:30 --> Helper loaded: file_helper
INFO - 2016-03-06 11:33:30 --> Helper loaded: date_helper
INFO - 2016-03-06 11:33:30 --> Helper loaded: form_helper
INFO - 2016-03-06 11:33:30 --> Database Driver Class Initialized
INFO - 2016-03-06 11:33:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:33:31 --> Controller Class Initialized
INFO - 2016-03-06 11:33:31 --> Model Class Initialized
INFO - 2016-03-06 11:33:31 --> Model Class Initialized
INFO - 2016-03-06 11:33:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:33:31 --> Pagination Class Initialized
INFO - 2016-03-06 11:33:31 --> Helper loaded: text_helper
INFO - 2016-03-06 11:33:31 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 14:33:31 --> Severity: Notice --> Undefined variable: list_bottom C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
ERROR - 2016-03-06 14:33:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-06 14:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:33:31 --> Final output sent to browser
DEBUG - 2016-03-06 14:33:31 --> Total execution time: 1.1627
INFO - 2016-03-06 11:40:49 --> Config Class Initialized
INFO - 2016-03-06 11:40:49 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:40:49 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:40:49 --> Utf8 Class Initialized
INFO - 2016-03-06 11:40:49 --> URI Class Initialized
INFO - 2016-03-06 11:40:49 --> Router Class Initialized
INFO - 2016-03-06 11:40:49 --> Output Class Initialized
INFO - 2016-03-06 11:40:49 --> Security Class Initialized
DEBUG - 2016-03-06 11:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:40:49 --> Input Class Initialized
INFO - 2016-03-06 11:40:49 --> Language Class Initialized
ERROR - 2016-03-06 11:40:49 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 186
INFO - 2016-03-06 11:41:07 --> Config Class Initialized
INFO - 2016-03-06 11:41:07 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:41:07 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:41:07 --> Utf8 Class Initialized
INFO - 2016-03-06 11:41:07 --> URI Class Initialized
INFO - 2016-03-06 11:41:07 --> Router Class Initialized
INFO - 2016-03-06 11:41:07 --> Output Class Initialized
INFO - 2016-03-06 11:41:07 --> Security Class Initialized
DEBUG - 2016-03-06 11:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:41:07 --> Input Class Initialized
INFO - 2016-03-06 11:41:07 --> Language Class Initialized
INFO - 2016-03-06 11:41:07 --> Loader Class Initialized
INFO - 2016-03-06 11:41:07 --> Helper loaded: url_helper
INFO - 2016-03-06 11:41:07 --> Helper loaded: file_helper
INFO - 2016-03-06 11:41:07 --> Helper loaded: date_helper
INFO - 2016-03-06 11:41:07 --> Helper loaded: form_helper
INFO - 2016-03-06 11:41:07 --> Database Driver Class Initialized
INFO - 2016-03-06 11:41:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:41:08 --> Controller Class Initialized
INFO - 2016-03-06 11:41:08 --> Model Class Initialized
INFO - 2016-03-06 11:41:08 --> Model Class Initialized
INFO - 2016-03-06 11:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:41:08 --> Pagination Class Initialized
INFO - 2016-03-06 11:41:08 --> Helper loaded: text_helper
INFO - 2016-03-06 11:41:08 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:41:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:41:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:41:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:41:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 14:41:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:41:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:41:08 --> Final output sent to browser
DEBUG - 2016-03-06 14:41:08 --> Total execution time: 1.1633
INFO - 2016-03-06 11:41:40 --> Config Class Initialized
INFO - 2016-03-06 11:41:40 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:41:40 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:41:40 --> Utf8 Class Initialized
INFO - 2016-03-06 11:41:40 --> URI Class Initialized
INFO - 2016-03-06 11:41:40 --> Router Class Initialized
INFO - 2016-03-06 11:41:40 --> Output Class Initialized
INFO - 2016-03-06 11:41:40 --> Security Class Initialized
DEBUG - 2016-03-06 11:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:41:40 --> Input Class Initialized
INFO - 2016-03-06 11:41:41 --> Language Class Initialized
INFO - 2016-03-06 11:41:41 --> Loader Class Initialized
INFO - 2016-03-06 11:41:41 --> Helper loaded: url_helper
INFO - 2016-03-06 11:41:41 --> Helper loaded: file_helper
INFO - 2016-03-06 11:41:41 --> Helper loaded: date_helper
INFO - 2016-03-06 11:41:41 --> Helper loaded: form_helper
INFO - 2016-03-06 11:41:41 --> Database Driver Class Initialized
INFO - 2016-03-06 11:41:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:41:42 --> Controller Class Initialized
INFO - 2016-03-06 11:41:42 --> Model Class Initialized
INFO - 2016-03-06 11:41:42 --> Model Class Initialized
INFO - 2016-03-06 11:41:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:41:42 --> Pagination Class Initialized
INFO - 2016-03-06 11:41:42 --> Helper loaded: text_helper
INFO - 2016-03-06 11:41:42 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 14:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 14:41:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:41:42 --> Final output sent to browser
DEBUG - 2016-03-06 14:41:42 --> Total execution time: 1.1850
INFO - 2016-03-06 11:41:47 --> Config Class Initialized
INFO - 2016-03-06 11:41:47 --> Hooks Class Initialized
DEBUG - 2016-03-06 11:41:47 --> UTF-8 Support Enabled
INFO - 2016-03-06 11:41:47 --> Utf8 Class Initialized
INFO - 2016-03-06 11:41:47 --> URI Class Initialized
INFO - 2016-03-06 11:41:47 --> Router Class Initialized
INFO - 2016-03-06 11:41:47 --> Output Class Initialized
INFO - 2016-03-06 11:41:47 --> Security Class Initialized
DEBUG - 2016-03-06 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 11:41:47 --> Input Class Initialized
INFO - 2016-03-06 11:41:47 --> Language Class Initialized
INFO - 2016-03-06 11:41:47 --> Loader Class Initialized
INFO - 2016-03-06 11:41:47 --> Helper loaded: url_helper
INFO - 2016-03-06 11:41:47 --> Helper loaded: file_helper
INFO - 2016-03-06 11:41:47 --> Helper loaded: date_helper
INFO - 2016-03-06 11:41:47 --> Helper loaded: form_helper
INFO - 2016-03-06 11:41:47 --> Database Driver Class Initialized
INFO - 2016-03-06 11:41:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 11:41:48 --> Controller Class Initialized
INFO - 2016-03-06 11:41:48 --> Model Class Initialized
INFO - 2016-03-06 11:41:48 --> Model Class Initialized
INFO - 2016-03-06 11:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 11:41:48 --> Pagination Class Initialized
INFO - 2016-03-06 11:41:48 --> Helper loaded: text_helper
INFO - 2016-03-06 11:41:48 --> Helper loaded: cookie_helper
INFO - 2016-03-06 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 14:41:48 --> Final output sent to browser
DEBUG - 2016-03-06 14:41:48 --> Total execution time: 1.1469
INFO - 2016-03-06 12:05:12 --> Config Class Initialized
INFO - 2016-03-06 12:05:12 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:05:12 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:05:12 --> Utf8 Class Initialized
INFO - 2016-03-06 12:05:12 --> URI Class Initialized
INFO - 2016-03-06 12:05:12 --> Router Class Initialized
INFO - 2016-03-06 12:05:12 --> Output Class Initialized
INFO - 2016-03-06 12:05:12 --> Security Class Initialized
DEBUG - 2016-03-06 12:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:05:12 --> Input Class Initialized
INFO - 2016-03-06 12:05:12 --> Language Class Initialized
INFO - 2016-03-06 12:05:12 --> Loader Class Initialized
INFO - 2016-03-06 12:05:12 --> Helper loaded: url_helper
INFO - 2016-03-06 12:05:12 --> Helper loaded: file_helper
INFO - 2016-03-06 12:05:12 --> Helper loaded: date_helper
INFO - 2016-03-06 12:05:12 --> Helper loaded: form_helper
INFO - 2016-03-06 12:05:12 --> Database Driver Class Initialized
INFO - 2016-03-06 12:05:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:05:13 --> Controller Class Initialized
INFO - 2016-03-06 12:05:13 --> Model Class Initialized
INFO - 2016-03-06 12:05:13 --> Model Class Initialized
INFO - 2016-03-06 12:05:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:05:13 --> Pagination Class Initialized
INFO - 2016-03-06 12:05:13 --> Helper loaded: text_helper
INFO - 2016-03-06 12:05:13 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:05:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:05:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:05:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:05:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:05:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:05:13 --> Final output sent to browser
DEBUG - 2016-03-06 15:05:13 --> Total execution time: 1.1381
INFO - 2016-03-06 12:05:36 --> Config Class Initialized
INFO - 2016-03-06 12:05:36 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:05:36 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:05:36 --> Utf8 Class Initialized
INFO - 2016-03-06 12:05:36 --> URI Class Initialized
INFO - 2016-03-06 12:05:36 --> Router Class Initialized
INFO - 2016-03-06 12:05:36 --> Output Class Initialized
INFO - 2016-03-06 12:05:36 --> Security Class Initialized
DEBUG - 2016-03-06 12:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:05:36 --> Input Class Initialized
INFO - 2016-03-06 12:05:36 --> Language Class Initialized
INFO - 2016-03-06 12:05:36 --> Loader Class Initialized
INFO - 2016-03-06 12:05:36 --> Helper loaded: url_helper
INFO - 2016-03-06 12:05:36 --> Helper loaded: file_helper
INFO - 2016-03-06 12:05:36 --> Helper loaded: date_helper
INFO - 2016-03-06 12:05:36 --> Helper loaded: form_helper
INFO - 2016-03-06 12:05:36 --> Database Driver Class Initialized
INFO - 2016-03-06 12:05:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:05:37 --> Controller Class Initialized
INFO - 2016-03-06 12:05:37 --> Model Class Initialized
INFO - 2016-03-06 12:05:37 --> Model Class Initialized
INFO - 2016-03-06 12:05:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:05:37 --> Pagination Class Initialized
INFO - 2016-03-06 12:05:37 --> Helper loaded: text_helper
INFO - 2016-03-06 12:05:37 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:05:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:05:37 --> Final output sent to browser
DEBUG - 2016-03-06 15:05:37 --> Total execution time: 1.1113
INFO - 2016-03-06 12:05:40 --> Config Class Initialized
INFO - 2016-03-06 12:05:40 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:05:40 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:05:40 --> Utf8 Class Initialized
INFO - 2016-03-06 12:05:40 --> URI Class Initialized
INFO - 2016-03-06 12:05:40 --> Router Class Initialized
INFO - 2016-03-06 12:05:40 --> Output Class Initialized
INFO - 2016-03-06 12:05:40 --> Security Class Initialized
DEBUG - 2016-03-06 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:05:40 --> Input Class Initialized
INFO - 2016-03-06 12:05:40 --> Language Class Initialized
INFO - 2016-03-06 12:05:40 --> Loader Class Initialized
INFO - 2016-03-06 12:05:40 --> Helper loaded: url_helper
INFO - 2016-03-06 12:05:40 --> Helper loaded: file_helper
INFO - 2016-03-06 12:05:40 --> Helper loaded: date_helper
INFO - 2016-03-06 12:05:40 --> Helper loaded: form_helper
INFO - 2016-03-06 12:05:40 --> Database Driver Class Initialized
INFO - 2016-03-06 12:05:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:05:41 --> Controller Class Initialized
INFO - 2016-03-06 12:05:41 --> Model Class Initialized
INFO - 2016-03-06 12:05:41 --> Model Class Initialized
INFO - 2016-03-06 12:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:05:41 --> Pagination Class Initialized
INFO - 2016-03-06 12:05:41 --> Helper loaded: text_helper
INFO - 2016-03-06 12:05:41 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:05:41 --> Final output sent to browser
DEBUG - 2016-03-06 15:05:41 --> Total execution time: 1.1548
INFO - 2016-03-06 12:05:48 --> Config Class Initialized
INFO - 2016-03-06 12:05:48 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:05:48 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:05:48 --> Utf8 Class Initialized
INFO - 2016-03-06 12:05:48 --> URI Class Initialized
INFO - 2016-03-06 12:05:48 --> Router Class Initialized
INFO - 2016-03-06 12:05:48 --> Output Class Initialized
INFO - 2016-03-06 12:05:48 --> Security Class Initialized
DEBUG - 2016-03-06 12:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:05:48 --> Input Class Initialized
INFO - 2016-03-06 12:05:48 --> Language Class Initialized
INFO - 2016-03-06 12:05:48 --> Loader Class Initialized
INFO - 2016-03-06 12:05:48 --> Helper loaded: url_helper
INFO - 2016-03-06 12:05:48 --> Helper loaded: file_helper
INFO - 2016-03-06 12:05:48 --> Helper loaded: date_helper
INFO - 2016-03-06 12:05:48 --> Helper loaded: form_helper
INFO - 2016-03-06 12:05:48 --> Database Driver Class Initialized
INFO - 2016-03-06 12:05:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:05:49 --> Controller Class Initialized
INFO - 2016-03-06 12:05:49 --> Model Class Initialized
INFO - 2016-03-06 12:05:49 --> Model Class Initialized
INFO - 2016-03-06 12:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:05:49 --> Pagination Class Initialized
INFO - 2016-03-06 12:05:49 --> Helper loaded: text_helper
INFO - 2016-03-06 12:05:49 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:05:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:05:49 --> Final output sent to browser
DEBUG - 2016-03-06 15:05:49 --> Total execution time: 1.1204
INFO - 2016-03-06 12:10:23 --> Config Class Initialized
INFO - 2016-03-06 12:10:23 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:10:23 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:10:23 --> Utf8 Class Initialized
INFO - 2016-03-06 12:10:23 --> URI Class Initialized
INFO - 2016-03-06 12:10:23 --> Router Class Initialized
INFO - 2016-03-06 12:10:23 --> Output Class Initialized
INFO - 2016-03-06 12:10:23 --> Security Class Initialized
DEBUG - 2016-03-06 12:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:10:23 --> Input Class Initialized
INFO - 2016-03-06 12:10:23 --> Language Class Initialized
INFO - 2016-03-06 12:10:23 --> Loader Class Initialized
INFO - 2016-03-06 12:10:23 --> Helper loaded: url_helper
INFO - 2016-03-06 12:10:23 --> Helper loaded: file_helper
INFO - 2016-03-06 12:10:23 --> Helper loaded: date_helper
INFO - 2016-03-06 12:10:23 --> Helper loaded: form_helper
INFO - 2016-03-06 12:10:23 --> Database Driver Class Initialized
INFO - 2016-03-06 12:10:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:10:24 --> Controller Class Initialized
INFO - 2016-03-06 12:10:24 --> Model Class Initialized
INFO - 2016-03-06 12:10:24 --> Model Class Initialized
INFO - 2016-03-06 12:10:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:10:24 --> Pagination Class Initialized
INFO - 2016-03-06 12:10:24 --> Helper loaded: text_helper
INFO - 2016-03-06 12:10:24 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:10:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:10:24 --> Final output sent to browser
DEBUG - 2016-03-06 15:10:24 --> Total execution time: 1.1132
INFO - 2016-03-06 12:10:28 --> Config Class Initialized
INFO - 2016-03-06 12:10:28 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:10:28 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:10:28 --> Utf8 Class Initialized
INFO - 2016-03-06 12:10:28 --> URI Class Initialized
INFO - 2016-03-06 12:10:28 --> Router Class Initialized
INFO - 2016-03-06 12:10:28 --> Output Class Initialized
INFO - 2016-03-06 12:10:28 --> Security Class Initialized
DEBUG - 2016-03-06 12:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:10:28 --> Input Class Initialized
INFO - 2016-03-06 12:10:28 --> Language Class Initialized
INFO - 2016-03-06 12:10:28 --> Loader Class Initialized
INFO - 2016-03-06 12:10:28 --> Helper loaded: url_helper
INFO - 2016-03-06 12:10:28 --> Helper loaded: file_helper
INFO - 2016-03-06 12:10:28 --> Helper loaded: date_helper
INFO - 2016-03-06 12:10:28 --> Helper loaded: form_helper
INFO - 2016-03-06 12:10:28 --> Database Driver Class Initialized
INFO - 2016-03-06 12:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:10:29 --> Controller Class Initialized
INFO - 2016-03-06 12:10:29 --> Model Class Initialized
INFO - 2016-03-06 12:10:29 --> Model Class Initialized
INFO - 2016-03-06 12:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:10:29 --> Pagination Class Initialized
INFO - 2016-03-06 12:10:29 --> Helper loaded: text_helper
INFO - 2016-03-06 12:10:29 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:10:29 --> Final output sent to browser
DEBUG - 2016-03-06 15:10:29 --> Total execution time: 1.1278
INFO - 2016-03-06 12:10:32 --> Config Class Initialized
INFO - 2016-03-06 12:10:32 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:10:32 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:10:32 --> Utf8 Class Initialized
INFO - 2016-03-06 12:10:32 --> URI Class Initialized
INFO - 2016-03-06 12:10:32 --> Router Class Initialized
INFO - 2016-03-06 12:10:32 --> Output Class Initialized
INFO - 2016-03-06 12:10:32 --> Security Class Initialized
DEBUG - 2016-03-06 12:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:10:32 --> Input Class Initialized
INFO - 2016-03-06 12:10:32 --> Language Class Initialized
INFO - 2016-03-06 12:10:32 --> Loader Class Initialized
INFO - 2016-03-06 12:10:32 --> Helper loaded: url_helper
INFO - 2016-03-06 12:10:32 --> Helper loaded: file_helper
INFO - 2016-03-06 12:10:32 --> Helper loaded: date_helper
INFO - 2016-03-06 12:10:32 --> Helper loaded: form_helper
INFO - 2016-03-06 12:10:32 --> Database Driver Class Initialized
INFO - 2016-03-06 12:10:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:10:33 --> Controller Class Initialized
INFO - 2016-03-06 12:10:33 --> Model Class Initialized
INFO - 2016-03-06 12:10:33 --> Model Class Initialized
INFO - 2016-03-06 12:10:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:10:33 --> Pagination Class Initialized
INFO - 2016-03-06 12:10:33 --> Helper loaded: text_helper
INFO - 2016-03-06 12:10:33 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:10:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:10:33 --> Final output sent to browser
DEBUG - 2016-03-06 15:10:33 --> Total execution time: 1.1661
INFO - 2016-03-06 12:13:09 --> Config Class Initialized
INFO - 2016-03-06 12:13:09 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:13:09 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:13:09 --> Utf8 Class Initialized
INFO - 2016-03-06 12:13:09 --> URI Class Initialized
INFO - 2016-03-06 12:13:09 --> Router Class Initialized
INFO - 2016-03-06 12:13:09 --> Output Class Initialized
INFO - 2016-03-06 12:13:09 --> Security Class Initialized
DEBUG - 2016-03-06 12:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:13:09 --> Input Class Initialized
INFO - 2016-03-06 12:13:09 --> Language Class Initialized
INFO - 2016-03-06 12:13:09 --> Loader Class Initialized
INFO - 2016-03-06 12:13:09 --> Helper loaded: url_helper
INFO - 2016-03-06 12:13:09 --> Helper loaded: file_helper
INFO - 2016-03-06 12:13:09 --> Helper loaded: date_helper
INFO - 2016-03-06 12:13:09 --> Helper loaded: form_helper
INFO - 2016-03-06 12:13:09 --> Database Driver Class Initialized
INFO - 2016-03-06 12:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:13:10 --> Controller Class Initialized
INFO - 2016-03-06 12:13:10 --> Model Class Initialized
INFO - 2016-03-06 12:13:10 --> Model Class Initialized
INFO - 2016-03-06 12:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:13:10 --> Pagination Class Initialized
INFO - 2016-03-06 12:13:10 --> Helper loaded: text_helper
INFO - 2016-03-06 12:13:10 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:13:10 --> Final output sent to browser
DEBUG - 2016-03-06 15:13:10 --> Total execution time: 1.1708
INFO - 2016-03-06 12:14:36 --> Config Class Initialized
INFO - 2016-03-06 12:14:36 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:14:36 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:14:36 --> Utf8 Class Initialized
INFO - 2016-03-06 12:14:36 --> URI Class Initialized
INFO - 2016-03-06 12:14:36 --> Router Class Initialized
INFO - 2016-03-06 12:14:36 --> Output Class Initialized
INFO - 2016-03-06 12:14:36 --> Security Class Initialized
DEBUG - 2016-03-06 12:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:14:36 --> Input Class Initialized
INFO - 2016-03-06 12:14:36 --> Language Class Initialized
INFO - 2016-03-06 12:14:36 --> Loader Class Initialized
INFO - 2016-03-06 12:14:36 --> Helper loaded: url_helper
INFO - 2016-03-06 12:14:36 --> Helper loaded: file_helper
INFO - 2016-03-06 12:14:36 --> Helper loaded: date_helper
INFO - 2016-03-06 12:14:36 --> Helper loaded: form_helper
INFO - 2016-03-06 12:14:36 --> Database Driver Class Initialized
INFO - 2016-03-06 12:14:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:14:37 --> Controller Class Initialized
INFO - 2016-03-06 12:14:37 --> Model Class Initialized
INFO - 2016-03-06 12:14:37 --> Model Class Initialized
INFO - 2016-03-06 12:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:14:37 --> Pagination Class Initialized
INFO - 2016-03-06 12:14:37 --> Helper loaded: text_helper
INFO - 2016-03-06 12:14:37 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:14:37 --> Final output sent to browser
DEBUG - 2016-03-06 15:14:37 --> Total execution time: 1.1643
INFO - 2016-03-06 12:16:32 --> Config Class Initialized
INFO - 2016-03-06 12:16:32 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:16:32 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:16:32 --> Utf8 Class Initialized
INFO - 2016-03-06 12:16:32 --> URI Class Initialized
INFO - 2016-03-06 12:16:32 --> Router Class Initialized
INFO - 2016-03-06 12:16:32 --> Output Class Initialized
INFO - 2016-03-06 12:16:32 --> Security Class Initialized
DEBUG - 2016-03-06 12:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:16:32 --> Input Class Initialized
INFO - 2016-03-06 12:16:32 --> Language Class Initialized
INFO - 2016-03-06 12:16:32 --> Loader Class Initialized
INFO - 2016-03-06 12:16:32 --> Helper loaded: url_helper
INFO - 2016-03-06 12:16:32 --> Helper loaded: file_helper
INFO - 2016-03-06 12:16:32 --> Helper loaded: date_helper
INFO - 2016-03-06 12:16:32 --> Helper loaded: form_helper
INFO - 2016-03-06 12:16:32 --> Database Driver Class Initialized
INFO - 2016-03-06 12:16:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:16:33 --> Controller Class Initialized
INFO - 2016-03-06 12:16:33 --> Model Class Initialized
INFO - 2016-03-06 12:16:33 --> Model Class Initialized
INFO - 2016-03-06 12:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:16:33 --> Pagination Class Initialized
INFO - 2016-03-06 12:16:33 --> Helper loaded: text_helper
INFO - 2016-03-06 12:16:33 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:16:34 --> Final output sent to browser
DEBUG - 2016-03-06 15:16:34 --> Total execution time: 1.1997
INFO - 2016-03-06 12:16:41 --> Config Class Initialized
INFO - 2016-03-06 12:16:41 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:16:41 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:16:41 --> Utf8 Class Initialized
INFO - 2016-03-06 12:16:41 --> URI Class Initialized
DEBUG - 2016-03-06 12:16:41 --> No URI present. Default controller set.
INFO - 2016-03-06 12:16:41 --> Router Class Initialized
INFO - 2016-03-06 12:16:41 --> Output Class Initialized
INFO - 2016-03-06 12:16:41 --> Security Class Initialized
DEBUG - 2016-03-06 12:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:16:41 --> Input Class Initialized
INFO - 2016-03-06 12:16:41 --> Language Class Initialized
INFO - 2016-03-06 12:16:41 --> Loader Class Initialized
INFO - 2016-03-06 12:16:41 --> Helper loaded: url_helper
INFO - 2016-03-06 12:16:41 --> Helper loaded: file_helper
INFO - 2016-03-06 12:16:41 --> Helper loaded: date_helper
INFO - 2016-03-06 12:16:41 --> Helper loaded: form_helper
INFO - 2016-03-06 12:16:41 --> Database Driver Class Initialized
INFO - 2016-03-06 12:16:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:16:42 --> Controller Class Initialized
INFO - 2016-03-06 12:16:42 --> Model Class Initialized
INFO - 2016-03-06 12:16:42 --> Model Class Initialized
INFO - 2016-03-06 12:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:16:42 --> Pagination Class Initialized
INFO - 2016-03-06 12:16:42 --> Helper loaded: text_helper
INFO - 2016-03-06 12:16:42 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 15:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:16:42 --> Final output sent to browser
DEBUG - 2016-03-06 15:16:42 --> Total execution time: 1.1318
INFO - 2016-03-06 12:16:44 --> Config Class Initialized
INFO - 2016-03-06 12:16:44 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:16:44 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:16:44 --> Utf8 Class Initialized
INFO - 2016-03-06 12:16:44 --> URI Class Initialized
INFO - 2016-03-06 12:16:44 --> Router Class Initialized
INFO - 2016-03-06 12:16:44 --> Output Class Initialized
INFO - 2016-03-06 12:16:44 --> Security Class Initialized
DEBUG - 2016-03-06 12:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:16:44 --> Input Class Initialized
INFO - 2016-03-06 12:16:44 --> Language Class Initialized
INFO - 2016-03-06 12:16:44 --> Loader Class Initialized
INFO - 2016-03-06 12:16:44 --> Helper loaded: url_helper
INFO - 2016-03-06 12:16:44 --> Helper loaded: file_helper
INFO - 2016-03-06 12:16:44 --> Helper loaded: date_helper
INFO - 2016-03-06 12:16:44 --> Helper loaded: form_helper
INFO - 2016-03-06 12:16:44 --> Database Driver Class Initialized
INFO - 2016-03-06 12:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:16:45 --> Controller Class Initialized
INFO - 2016-03-06 12:16:45 --> Model Class Initialized
INFO - 2016-03-06 12:16:45 --> Model Class Initialized
INFO - 2016-03-06 12:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:16:45 --> Pagination Class Initialized
INFO - 2016-03-06 12:16:45 --> Helper loaded: text_helper
INFO - 2016-03-06 12:16:45 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:16:45 --> Final output sent to browser
DEBUG - 2016-03-06 15:16:45 --> Total execution time: 1.1199
INFO - 2016-03-06 12:16:47 --> Config Class Initialized
INFO - 2016-03-06 12:16:47 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:16:47 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:16:47 --> Utf8 Class Initialized
INFO - 2016-03-06 12:16:47 --> URI Class Initialized
INFO - 2016-03-06 12:16:47 --> Router Class Initialized
INFO - 2016-03-06 12:16:47 --> Output Class Initialized
INFO - 2016-03-06 12:16:47 --> Security Class Initialized
DEBUG - 2016-03-06 12:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:16:47 --> Input Class Initialized
INFO - 2016-03-06 12:16:47 --> Language Class Initialized
INFO - 2016-03-06 12:16:47 --> Loader Class Initialized
INFO - 2016-03-06 12:16:47 --> Helper loaded: url_helper
INFO - 2016-03-06 12:16:47 --> Helper loaded: file_helper
INFO - 2016-03-06 12:16:47 --> Helper loaded: date_helper
INFO - 2016-03-06 12:16:47 --> Helper loaded: form_helper
INFO - 2016-03-06 12:16:47 --> Database Driver Class Initialized
INFO - 2016-03-06 12:16:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:16:48 --> Controller Class Initialized
INFO - 2016-03-06 12:16:48 --> Model Class Initialized
INFO - 2016-03-06 12:16:48 --> Model Class Initialized
INFO - 2016-03-06 12:16:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:16:48 --> Pagination Class Initialized
INFO - 2016-03-06 12:16:48 --> Helper loaded: text_helper
INFO - 2016-03-06 12:16:48 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:16:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:16:48 --> Final output sent to browser
DEBUG - 2016-03-06 15:16:48 --> Total execution time: 1.1786
INFO - 2016-03-06 12:16:58 --> Config Class Initialized
INFO - 2016-03-06 12:16:58 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:16:58 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:16:58 --> Utf8 Class Initialized
INFO - 2016-03-06 12:16:58 --> URI Class Initialized
INFO - 2016-03-06 12:16:58 --> Router Class Initialized
INFO - 2016-03-06 12:16:58 --> Output Class Initialized
INFO - 2016-03-06 12:16:58 --> Security Class Initialized
DEBUG - 2016-03-06 12:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:16:58 --> Input Class Initialized
INFO - 2016-03-06 12:16:58 --> Language Class Initialized
INFO - 2016-03-06 12:16:58 --> Loader Class Initialized
INFO - 2016-03-06 12:16:58 --> Helper loaded: url_helper
INFO - 2016-03-06 12:16:58 --> Helper loaded: file_helper
INFO - 2016-03-06 12:16:58 --> Helper loaded: date_helper
INFO - 2016-03-06 12:16:58 --> Helper loaded: form_helper
INFO - 2016-03-06 12:16:58 --> Database Driver Class Initialized
INFO - 2016-03-06 12:16:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:16:59 --> Controller Class Initialized
INFO - 2016-03-06 12:16:59 --> Model Class Initialized
INFO - 2016-03-06 12:16:59 --> Model Class Initialized
INFO - 2016-03-06 12:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:16:59 --> Pagination Class Initialized
INFO - 2016-03-06 12:16:59 --> Helper loaded: text_helper
INFO - 2016-03-06 12:16:59 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:16:59 --> Final output sent to browser
DEBUG - 2016-03-06 15:16:59 --> Total execution time: 1.1229
INFO - 2016-03-06 12:17:01 --> Config Class Initialized
INFO - 2016-03-06 12:17:01 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:17:01 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:17:01 --> Utf8 Class Initialized
INFO - 2016-03-06 12:17:01 --> URI Class Initialized
INFO - 2016-03-06 12:17:01 --> Router Class Initialized
INFO - 2016-03-06 12:17:01 --> Output Class Initialized
INFO - 2016-03-06 12:17:01 --> Security Class Initialized
DEBUG - 2016-03-06 12:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:17:01 --> Input Class Initialized
INFO - 2016-03-06 12:17:01 --> Language Class Initialized
INFO - 2016-03-06 12:17:01 --> Loader Class Initialized
INFO - 2016-03-06 12:17:01 --> Helper loaded: url_helper
INFO - 2016-03-06 12:17:01 --> Helper loaded: file_helper
INFO - 2016-03-06 12:17:01 --> Helper loaded: date_helper
INFO - 2016-03-06 12:17:01 --> Helper loaded: form_helper
INFO - 2016-03-06 12:17:01 --> Database Driver Class Initialized
INFO - 2016-03-06 12:17:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:17:02 --> Controller Class Initialized
INFO - 2016-03-06 12:17:02 --> Model Class Initialized
INFO - 2016-03-06 12:17:02 --> Model Class Initialized
INFO - 2016-03-06 12:17:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:17:02 --> Pagination Class Initialized
INFO - 2016-03-06 12:17:02 --> Helper loaded: text_helper
INFO - 2016-03-06 12:17:02 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:17:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:17:02 --> Final output sent to browser
DEBUG - 2016-03-06 15:17:02 --> Total execution time: 1.1217
INFO - 2016-03-06 12:17:05 --> Config Class Initialized
INFO - 2016-03-06 12:17:05 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:17:05 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:17:05 --> Utf8 Class Initialized
INFO - 2016-03-06 12:17:05 --> URI Class Initialized
INFO - 2016-03-06 12:17:05 --> Router Class Initialized
INFO - 2016-03-06 12:17:05 --> Output Class Initialized
INFO - 2016-03-06 12:17:05 --> Security Class Initialized
DEBUG - 2016-03-06 12:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:17:05 --> Input Class Initialized
INFO - 2016-03-06 12:17:05 --> Language Class Initialized
INFO - 2016-03-06 12:17:05 --> Loader Class Initialized
INFO - 2016-03-06 12:17:05 --> Helper loaded: url_helper
INFO - 2016-03-06 12:17:05 --> Helper loaded: file_helper
INFO - 2016-03-06 12:17:05 --> Helper loaded: date_helper
INFO - 2016-03-06 12:17:05 --> Helper loaded: form_helper
INFO - 2016-03-06 12:17:05 --> Database Driver Class Initialized
INFO - 2016-03-06 12:17:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:17:06 --> Controller Class Initialized
INFO - 2016-03-06 12:17:06 --> Model Class Initialized
INFO - 2016-03-06 12:17:06 --> Model Class Initialized
INFO - 2016-03-06 12:17:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:17:06 --> Pagination Class Initialized
INFO - 2016-03-06 12:17:06 --> Helper loaded: text_helper
INFO - 2016-03-06 12:17:06 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:17:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:17:06 --> Final output sent to browser
DEBUG - 2016-03-06 15:17:06 --> Total execution time: 1.1454
INFO - 2016-03-06 12:20:40 --> Config Class Initialized
INFO - 2016-03-06 12:20:40 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:20:40 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:20:40 --> Utf8 Class Initialized
INFO - 2016-03-06 12:20:40 --> URI Class Initialized
INFO - 2016-03-06 12:20:40 --> Router Class Initialized
INFO - 2016-03-06 12:20:40 --> Output Class Initialized
INFO - 2016-03-06 12:20:40 --> Security Class Initialized
DEBUG - 2016-03-06 12:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:20:40 --> Input Class Initialized
INFO - 2016-03-06 12:20:40 --> Language Class Initialized
ERROR - 2016-03-06 12:20:40 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 185
INFO - 2016-03-06 12:20:58 --> Config Class Initialized
INFO - 2016-03-06 12:20:58 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:20:58 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:20:58 --> Utf8 Class Initialized
INFO - 2016-03-06 12:20:58 --> URI Class Initialized
INFO - 2016-03-06 12:20:58 --> Router Class Initialized
INFO - 2016-03-06 12:20:58 --> Output Class Initialized
INFO - 2016-03-06 12:20:58 --> Security Class Initialized
DEBUG - 2016-03-06 12:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:20:58 --> Input Class Initialized
INFO - 2016-03-06 12:20:58 --> Language Class Initialized
INFO - 2016-03-06 12:20:58 --> Loader Class Initialized
INFO - 2016-03-06 12:20:58 --> Helper loaded: url_helper
INFO - 2016-03-06 12:20:58 --> Helper loaded: file_helper
INFO - 2016-03-06 12:20:58 --> Helper loaded: date_helper
INFO - 2016-03-06 12:20:58 --> Helper loaded: form_helper
INFO - 2016-03-06 12:20:58 --> Database Driver Class Initialized
INFO - 2016-03-06 12:20:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:20:59 --> Controller Class Initialized
INFO - 2016-03-06 12:20:59 --> Model Class Initialized
INFO - 2016-03-06 12:20:59 --> Model Class Initialized
INFO - 2016-03-06 12:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:20:59 --> Pagination Class Initialized
INFO - 2016-03-06 12:20:59 --> Helper loaded: text_helper
INFO - 2016-03-06 12:20:59 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:20:59 --> Final output sent to browser
DEBUG - 2016-03-06 15:20:59 --> Total execution time: 1.1753
INFO - 2016-03-06 12:21:11 --> Config Class Initialized
INFO - 2016-03-06 12:21:11 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:21:11 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:21:11 --> Utf8 Class Initialized
INFO - 2016-03-06 12:21:11 --> URI Class Initialized
INFO - 2016-03-06 12:21:11 --> Router Class Initialized
INFO - 2016-03-06 12:21:11 --> Output Class Initialized
INFO - 2016-03-06 12:21:11 --> Security Class Initialized
DEBUG - 2016-03-06 12:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:21:11 --> Input Class Initialized
INFO - 2016-03-06 12:21:11 --> Language Class Initialized
INFO - 2016-03-06 12:21:11 --> Loader Class Initialized
INFO - 2016-03-06 12:21:11 --> Helper loaded: url_helper
INFO - 2016-03-06 12:21:11 --> Helper loaded: file_helper
INFO - 2016-03-06 12:21:11 --> Helper loaded: date_helper
INFO - 2016-03-06 12:21:11 --> Helper loaded: form_helper
INFO - 2016-03-06 12:21:11 --> Database Driver Class Initialized
INFO - 2016-03-06 12:21:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:21:12 --> Controller Class Initialized
INFO - 2016-03-06 12:21:12 --> Model Class Initialized
INFO - 2016-03-06 12:21:12 --> Model Class Initialized
INFO - 2016-03-06 12:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:21:12 --> Pagination Class Initialized
INFO - 2016-03-06 12:21:12 --> Helper loaded: text_helper
INFO - 2016-03-06 12:21:12 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:21:12 --> Final output sent to browser
DEBUG - 2016-03-06 15:21:12 --> Total execution time: 1.1169
INFO - 2016-03-06 12:21:16 --> Config Class Initialized
INFO - 2016-03-06 12:21:16 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:21:16 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:21:16 --> Utf8 Class Initialized
INFO - 2016-03-06 12:21:16 --> URI Class Initialized
INFO - 2016-03-06 12:21:16 --> Router Class Initialized
INFO - 2016-03-06 12:21:16 --> Output Class Initialized
INFO - 2016-03-06 12:21:16 --> Security Class Initialized
DEBUG - 2016-03-06 12:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:21:16 --> Input Class Initialized
INFO - 2016-03-06 12:21:16 --> Language Class Initialized
INFO - 2016-03-06 12:21:16 --> Loader Class Initialized
INFO - 2016-03-06 12:21:16 --> Helper loaded: url_helper
INFO - 2016-03-06 12:21:16 --> Helper loaded: file_helper
INFO - 2016-03-06 12:21:16 --> Helper loaded: date_helper
INFO - 2016-03-06 12:21:16 --> Helper loaded: form_helper
INFO - 2016-03-06 12:21:16 --> Database Driver Class Initialized
INFO - 2016-03-06 12:21:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:21:17 --> Controller Class Initialized
INFO - 2016-03-06 12:21:17 --> Model Class Initialized
INFO - 2016-03-06 12:21:17 --> Model Class Initialized
INFO - 2016-03-06 12:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:21:17 --> Pagination Class Initialized
INFO - 2016-03-06 12:21:17 --> Helper loaded: text_helper
INFO - 2016-03-06 12:21:17 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:21:17 --> Final output sent to browser
DEBUG - 2016-03-06 15:21:17 --> Total execution time: 1.1103
INFO - 2016-03-06 12:21:20 --> Config Class Initialized
INFO - 2016-03-06 12:21:20 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:21:20 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:21:20 --> Utf8 Class Initialized
INFO - 2016-03-06 12:21:20 --> URI Class Initialized
INFO - 2016-03-06 12:21:20 --> Router Class Initialized
INFO - 2016-03-06 12:21:20 --> Output Class Initialized
INFO - 2016-03-06 12:21:20 --> Security Class Initialized
DEBUG - 2016-03-06 12:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:21:20 --> Input Class Initialized
INFO - 2016-03-06 12:21:20 --> Language Class Initialized
INFO - 2016-03-06 12:21:20 --> Loader Class Initialized
INFO - 2016-03-06 12:21:20 --> Helper loaded: url_helper
INFO - 2016-03-06 12:21:20 --> Helper loaded: file_helper
INFO - 2016-03-06 12:21:20 --> Helper loaded: date_helper
INFO - 2016-03-06 12:21:20 --> Helper loaded: form_helper
INFO - 2016-03-06 12:21:20 --> Database Driver Class Initialized
INFO - 2016-03-06 12:21:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:21:21 --> Controller Class Initialized
INFO - 2016-03-06 12:21:21 --> Model Class Initialized
INFO - 2016-03-06 12:21:21 --> Model Class Initialized
INFO - 2016-03-06 12:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:21:21 --> Pagination Class Initialized
INFO - 2016-03-06 12:21:21 --> Helper loaded: text_helper
INFO - 2016-03-06 12:21:21 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:21:21 --> Final output sent to browser
DEBUG - 2016-03-06 15:21:21 --> Total execution time: 1.1839
INFO - 2016-03-06 12:23:45 --> Config Class Initialized
INFO - 2016-03-06 12:23:45 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:23:45 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:23:45 --> Utf8 Class Initialized
INFO - 2016-03-06 12:23:45 --> URI Class Initialized
INFO - 2016-03-06 12:23:45 --> Router Class Initialized
INFO - 2016-03-06 12:23:45 --> Output Class Initialized
INFO - 2016-03-06 12:23:45 --> Security Class Initialized
DEBUG - 2016-03-06 12:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:23:45 --> Input Class Initialized
INFO - 2016-03-06 12:23:45 --> Language Class Initialized
INFO - 2016-03-06 12:23:45 --> Loader Class Initialized
INFO - 2016-03-06 12:23:45 --> Helper loaded: url_helper
INFO - 2016-03-06 12:23:45 --> Helper loaded: file_helper
INFO - 2016-03-06 12:23:45 --> Helper loaded: date_helper
INFO - 2016-03-06 12:23:45 --> Helper loaded: form_helper
INFO - 2016-03-06 12:23:45 --> Database Driver Class Initialized
INFO - 2016-03-06 12:23:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:23:46 --> Controller Class Initialized
INFO - 2016-03-06 12:23:46 --> Model Class Initialized
ERROR - 2016-03-06 12:23:46 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 312
INFO - 2016-03-06 12:23:59 --> Config Class Initialized
INFO - 2016-03-06 12:23:59 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:23:59 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:23:59 --> Utf8 Class Initialized
INFO - 2016-03-06 12:23:59 --> URI Class Initialized
INFO - 2016-03-06 12:23:59 --> Router Class Initialized
INFO - 2016-03-06 12:23:59 --> Output Class Initialized
INFO - 2016-03-06 12:23:59 --> Security Class Initialized
DEBUG - 2016-03-06 12:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:23:59 --> Input Class Initialized
INFO - 2016-03-06 12:23:59 --> Language Class Initialized
INFO - 2016-03-06 12:23:59 --> Loader Class Initialized
INFO - 2016-03-06 12:23:59 --> Helper loaded: url_helper
INFO - 2016-03-06 12:23:59 --> Helper loaded: file_helper
INFO - 2016-03-06 12:23:59 --> Helper loaded: date_helper
INFO - 2016-03-06 12:23:59 --> Helper loaded: form_helper
INFO - 2016-03-06 12:23:59 --> Database Driver Class Initialized
INFO - 2016-03-06 12:24:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:24:00 --> Controller Class Initialized
INFO - 2016-03-06 12:24:00 --> Model Class Initialized
INFO - 2016-03-06 12:24:00 --> Model Class Initialized
INFO - 2016-03-06 12:24:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:24:00 --> Pagination Class Initialized
INFO - 2016-03-06 12:24:00 --> Helper loaded: text_helper
INFO - 2016-03-06 12:24:00 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:24:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:24:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:24:01 --> Final output sent to browser
DEBUG - 2016-03-06 15:24:01 --> Total execution time: 1.2609
INFO - 2016-03-06 12:24:09 --> Config Class Initialized
INFO - 2016-03-06 12:24:09 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:24:09 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:24:09 --> Utf8 Class Initialized
INFO - 2016-03-06 12:24:09 --> URI Class Initialized
DEBUG - 2016-03-06 12:24:09 --> No URI present. Default controller set.
INFO - 2016-03-06 12:24:09 --> Router Class Initialized
INFO - 2016-03-06 12:24:09 --> Output Class Initialized
INFO - 2016-03-06 12:24:09 --> Security Class Initialized
DEBUG - 2016-03-06 12:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:24:09 --> Input Class Initialized
INFO - 2016-03-06 12:24:09 --> Language Class Initialized
INFO - 2016-03-06 12:24:09 --> Loader Class Initialized
INFO - 2016-03-06 12:24:09 --> Helper loaded: url_helper
INFO - 2016-03-06 12:24:09 --> Helper loaded: file_helper
INFO - 2016-03-06 12:24:09 --> Helper loaded: date_helper
INFO - 2016-03-06 12:24:09 --> Helper loaded: form_helper
INFO - 2016-03-06 12:24:09 --> Database Driver Class Initialized
INFO - 2016-03-06 12:24:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:24:10 --> Controller Class Initialized
INFO - 2016-03-06 12:24:10 --> Model Class Initialized
INFO - 2016-03-06 12:24:10 --> Model Class Initialized
INFO - 2016-03-06 12:24:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:24:10 --> Pagination Class Initialized
INFO - 2016-03-06 12:24:10 --> Helper loaded: text_helper
INFO - 2016-03-06 12:24:10 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 15:24:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:24:10 --> Final output sent to browser
DEBUG - 2016-03-06 15:24:10 --> Total execution time: 1.1110
INFO - 2016-03-06 12:24:14 --> Config Class Initialized
INFO - 2016-03-06 12:24:14 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:24:14 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:24:14 --> Utf8 Class Initialized
INFO - 2016-03-06 12:24:14 --> URI Class Initialized
INFO - 2016-03-06 12:24:14 --> Router Class Initialized
INFO - 2016-03-06 12:24:14 --> Output Class Initialized
INFO - 2016-03-06 12:24:14 --> Security Class Initialized
DEBUG - 2016-03-06 12:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:24:14 --> Input Class Initialized
INFO - 2016-03-06 12:24:14 --> Language Class Initialized
INFO - 2016-03-06 12:24:14 --> Loader Class Initialized
INFO - 2016-03-06 12:24:14 --> Helper loaded: url_helper
INFO - 2016-03-06 12:24:14 --> Helper loaded: file_helper
INFO - 2016-03-06 12:24:14 --> Helper loaded: date_helper
INFO - 2016-03-06 12:24:14 --> Helper loaded: form_helper
INFO - 2016-03-06 12:24:14 --> Database Driver Class Initialized
INFO - 2016-03-06 12:24:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:24:15 --> Controller Class Initialized
INFO - 2016-03-06 12:24:15 --> Model Class Initialized
INFO - 2016-03-06 12:24:15 --> Model Class Initialized
INFO - 2016-03-06 12:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:24:15 --> Pagination Class Initialized
INFO - 2016-03-06 12:24:15 --> Helper loaded: text_helper
INFO - 2016-03-06 12:24:15 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:24:15 --> Final output sent to browser
DEBUG - 2016-03-06 15:24:15 --> Total execution time: 1.1291
INFO - 2016-03-06 12:24:18 --> Config Class Initialized
INFO - 2016-03-06 12:24:18 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:24:18 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:24:18 --> Utf8 Class Initialized
INFO - 2016-03-06 12:24:18 --> URI Class Initialized
INFO - 2016-03-06 12:24:18 --> Router Class Initialized
INFO - 2016-03-06 12:24:18 --> Output Class Initialized
INFO - 2016-03-06 12:24:18 --> Security Class Initialized
DEBUG - 2016-03-06 12:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:24:18 --> Input Class Initialized
INFO - 2016-03-06 12:24:18 --> Language Class Initialized
INFO - 2016-03-06 12:24:18 --> Loader Class Initialized
INFO - 2016-03-06 12:24:18 --> Helper loaded: url_helper
INFO - 2016-03-06 12:24:18 --> Helper loaded: file_helper
INFO - 2016-03-06 12:24:18 --> Helper loaded: date_helper
INFO - 2016-03-06 12:24:18 --> Helper loaded: form_helper
INFO - 2016-03-06 12:24:18 --> Database Driver Class Initialized
INFO - 2016-03-06 12:24:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:24:20 --> Controller Class Initialized
INFO - 2016-03-06 12:24:20 --> Model Class Initialized
INFO - 2016-03-06 12:24:20 --> Model Class Initialized
INFO - 2016-03-06 12:24:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:24:20 --> Pagination Class Initialized
INFO - 2016-03-06 12:24:20 --> Helper loaded: text_helper
INFO - 2016-03-06 12:24:20 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:24:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:24:20 --> Final output sent to browser
DEBUG - 2016-03-06 15:24:20 --> Total execution time: 1.1698
INFO - 2016-03-06 12:25:31 --> Config Class Initialized
INFO - 2016-03-06 12:25:31 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:25:31 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:25:31 --> Utf8 Class Initialized
INFO - 2016-03-06 12:25:31 --> URI Class Initialized
INFO - 2016-03-06 12:25:31 --> Router Class Initialized
INFO - 2016-03-06 12:25:31 --> Output Class Initialized
INFO - 2016-03-06 12:25:31 --> Security Class Initialized
DEBUG - 2016-03-06 12:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:25:31 --> Input Class Initialized
INFO - 2016-03-06 12:25:31 --> Language Class Initialized
INFO - 2016-03-06 12:25:31 --> Loader Class Initialized
INFO - 2016-03-06 12:25:31 --> Helper loaded: url_helper
INFO - 2016-03-06 12:25:31 --> Helper loaded: file_helper
INFO - 2016-03-06 12:25:31 --> Helper loaded: date_helper
INFO - 2016-03-06 12:25:31 --> Helper loaded: form_helper
INFO - 2016-03-06 12:25:31 --> Database Driver Class Initialized
INFO - 2016-03-06 12:25:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:25:32 --> Controller Class Initialized
INFO - 2016-03-06 12:25:32 --> Model Class Initialized
INFO - 2016-03-06 12:25:32 --> Model Class Initialized
INFO - 2016-03-06 12:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:25:32 --> Pagination Class Initialized
INFO - 2016-03-06 12:25:32 --> Helper loaded: text_helper
INFO - 2016-03-06 12:25:32 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-06 15:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-06 15:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:25:33 --> Final output sent to browser
DEBUG - 2016-03-06 15:25:33 --> Total execution time: 1.1175
INFO - 2016-03-06 12:25:49 --> Config Class Initialized
INFO - 2016-03-06 12:25:49 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:25:49 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:25:49 --> Utf8 Class Initialized
INFO - 2016-03-06 12:25:49 --> URI Class Initialized
INFO - 2016-03-06 12:25:49 --> Router Class Initialized
INFO - 2016-03-06 12:25:49 --> Output Class Initialized
INFO - 2016-03-06 12:25:49 --> Security Class Initialized
DEBUG - 2016-03-06 12:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:25:49 --> Input Class Initialized
INFO - 2016-03-06 12:25:49 --> Language Class Initialized
INFO - 2016-03-06 12:25:49 --> Loader Class Initialized
INFO - 2016-03-06 12:25:49 --> Helper loaded: url_helper
INFO - 2016-03-06 12:25:49 --> Helper loaded: file_helper
INFO - 2016-03-06 12:25:49 --> Helper loaded: date_helper
INFO - 2016-03-06 12:25:49 --> Helper loaded: form_helper
INFO - 2016-03-06 12:25:49 --> Database Driver Class Initialized
INFO - 2016-03-06 12:25:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:25:50 --> Controller Class Initialized
INFO - 2016-03-06 12:25:50 --> Model Class Initialized
INFO - 2016-03-06 12:25:50 --> Model Class Initialized
INFO - 2016-03-06 12:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:25:50 --> Pagination Class Initialized
INFO - 2016-03-06 12:25:50 --> Helper loaded: text_helper
INFO - 2016-03-06 12:25:50 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-06 15:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-06 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:25:50 --> Final output sent to browser
DEBUG - 2016-03-06 15:25:50 --> Total execution time: 1.1142
INFO - 2016-03-06 12:25:54 --> Config Class Initialized
INFO - 2016-03-06 12:25:54 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:25:54 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:25:54 --> Utf8 Class Initialized
INFO - 2016-03-06 12:25:54 --> URI Class Initialized
INFO - 2016-03-06 12:25:54 --> Router Class Initialized
INFO - 2016-03-06 12:25:54 --> Output Class Initialized
INFO - 2016-03-06 12:25:54 --> Security Class Initialized
DEBUG - 2016-03-06 12:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:25:54 --> Input Class Initialized
INFO - 2016-03-06 12:25:54 --> Language Class Initialized
INFO - 2016-03-06 12:25:54 --> Loader Class Initialized
INFO - 2016-03-06 12:25:54 --> Helper loaded: url_helper
INFO - 2016-03-06 12:25:54 --> Helper loaded: file_helper
INFO - 2016-03-06 12:25:54 --> Helper loaded: date_helper
INFO - 2016-03-06 12:25:54 --> Helper loaded: form_helper
INFO - 2016-03-06 12:25:54 --> Database Driver Class Initialized
INFO - 2016-03-06 12:25:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:25:55 --> Controller Class Initialized
INFO - 2016-03-06 12:25:55 --> Model Class Initialized
INFO - 2016-03-06 12:25:55 --> Model Class Initialized
INFO - 2016-03-06 12:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:25:55 --> Pagination Class Initialized
INFO - 2016-03-06 12:25:55 --> Helper loaded: text_helper
INFO - 2016-03-06 12:25:55 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:25:55 --> Final output sent to browser
DEBUG - 2016-03-06 15:25:55 --> Total execution time: 1.1134
INFO - 2016-03-06 12:26:00 --> Config Class Initialized
INFO - 2016-03-06 12:26:00 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:26:00 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:26:00 --> Utf8 Class Initialized
INFO - 2016-03-06 12:26:00 --> URI Class Initialized
INFO - 2016-03-06 12:26:00 --> Router Class Initialized
INFO - 2016-03-06 12:26:00 --> Output Class Initialized
INFO - 2016-03-06 12:26:00 --> Security Class Initialized
DEBUG - 2016-03-06 12:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:26:00 --> Input Class Initialized
INFO - 2016-03-06 12:26:00 --> Language Class Initialized
INFO - 2016-03-06 12:26:00 --> Loader Class Initialized
INFO - 2016-03-06 12:26:00 --> Helper loaded: url_helper
INFO - 2016-03-06 12:26:00 --> Helper loaded: file_helper
INFO - 2016-03-06 12:26:00 --> Helper loaded: date_helper
INFO - 2016-03-06 12:26:00 --> Helper loaded: form_helper
INFO - 2016-03-06 12:26:00 --> Database Driver Class Initialized
INFO - 2016-03-06 12:26:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:26:01 --> Controller Class Initialized
INFO - 2016-03-06 12:26:01 --> Model Class Initialized
INFO - 2016-03-06 12:26:01 --> Model Class Initialized
INFO - 2016-03-06 12:26:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:26:01 --> Pagination Class Initialized
INFO - 2016-03-06 12:26:01 --> Helper loaded: text_helper
INFO - 2016-03-06 12:26:01 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:26:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:26:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:26:02 --> Final output sent to browser
DEBUG - 2016-03-06 15:26:02 --> Total execution time: 1.1680
INFO - 2016-03-06 12:26:22 --> Config Class Initialized
INFO - 2016-03-06 12:26:22 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:26:22 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:26:22 --> Utf8 Class Initialized
INFO - 2016-03-06 12:26:22 --> URI Class Initialized
INFO - 2016-03-06 12:26:22 --> Router Class Initialized
INFO - 2016-03-06 12:26:22 --> Output Class Initialized
INFO - 2016-03-06 12:26:22 --> Security Class Initialized
DEBUG - 2016-03-06 12:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:26:22 --> Input Class Initialized
INFO - 2016-03-06 12:26:22 --> Language Class Initialized
INFO - 2016-03-06 12:26:22 --> Loader Class Initialized
INFO - 2016-03-06 12:26:22 --> Helper loaded: url_helper
INFO - 2016-03-06 12:26:22 --> Helper loaded: file_helper
INFO - 2016-03-06 12:26:22 --> Helper loaded: date_helper
INFO - 2016-03-06 12:26:22 --> Helper loaded: form_helper
INFO - 2016-03-06 12:26:22 --> Database Driver Class Initialized
INFO - 2016-03-06 12:26:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:26:23 --> Controller Class Initialized
INFO - 2016-03-06 12:26:23 --> Model Class Initialized
INFO - 2016-03-06 12:26:23 --> Model Class Initialized
INFO - 2016-03-06 12:26:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:26:23 --> Pagination Class Initialized
INFO - 2016-03-06 12:26:23 --> Helper loaded: text_helper
INFO - 2016-03-06 12:26:23 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:26:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:26:23 --> Final output sent to browser
DEBUG - 2016-03-06 15:26:23 --> Total execution time: 1.1337
INFO - 2016-03-06 12:26:38 --> Config Class Initialized
INFO - 2016-03-06 12:26:38 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:26:38 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:26:38 --> Utf8 Class Initialized
INFO - 2016-03-06 12:26:38 --> URI Class Initialized
INFO - 2016-03-06 12:26:38 --> Router Class Initialized
INFO - 2016-03-06 12:26:38 --> Output Class Initialized
INFO - 2016-03-06 12:26:38 --> Security Class Initialized
DEBUG - 2016-03-06 12:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:26:38 --> Input Class Initialized
INFO - 2016-03-06 12:26:38 --> Language Class Initialized
INFO - 2016-03-06 12:26:38 --> Loader Class Initialized
INFO - 2016-03-06 12:26:38 --> Helper loaded: url_helper
INFO - 2016-03-06 12:26:38 --> Helper loaded: file_helper
INFO - 2016-03-06 12:26:38 --> Helper loaded: date_helper
INFO - 2016-03-06 12:26:38 --> Helper loaded: form_helper
INFO - 2016-03-06 12:26:38 --> Database Driver Class Initialized
INFO - 2016-03-06 12:26:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:26:39 --> Controller Class Initialized
INFO - 2016-03-06 12:26:39 --> Model Class Initialized
INFO - 2016-03-06 12:26:39 --> Model Class Initialized
INFO - 2016-03-06 12:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:26:39 --> Pagination Class Initialized
INFO - 2016-03-06 12:26:39 --> Helper loaded: text_helper
INFO - 2016-03-06 12:26:39 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:26:39 --> Final output sent to browser
DEBUG - 2016-03-06 15:26:39 --> Total execution time: 1.1724
INFO - 2016-03-06 12:26:58 --> Config Class Initialized
INFO - 2016-03-06 12:26:58 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:26:58 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:26:58 --> Utf8 Class Initialized
INFO - 2016-03-06 12:26:58 --> URI Class Initialized
INFO - 2016-03-06 12:26:58 --> Router Class Initialized
INFO - 2016-03-06 12:26:58 --> Output Class Initialized
INFO - 2016-03-06 12:26:58 --> Security Class Initialized
DEBUG - 2016-03-06 12:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:26:58 --> Input Class Initialized
INFO - 2016-03-06 12:26:58 --> Language Class Initialized
INFO - 2016-03-06 12:26:58 --> Loader Class Initialized
INFO - 2016-03-06 12:26:58 --> Helper loaded: url_helper
INFO - 2016-03-06 12:26:58 --> Helper loaded: file_helper
INFO - 2016-03-06 12:26:58 --> Helper loaded: date_helper
INFO - 2016-03-06 12:26:58 --> Helper loaded: form_helper
INFO - 2016-03-06 12:26:58 --> Database Driver Class Initialized
INFO - 2016-03-06 12:26:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:26:59 --> Controller Class Initialized
INFO - 2016-03-06 12:26:59 --> Model Class Initialized
INFO - 2016-03-06 12:26:59 --> Model Class Initialized
INFO - 2016-03-06 12:26:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:26:59 --> Pagination Class Initialized
INFO - 2016-03-06 12:26:59 --> Helper loaded: text_helper
INFO - 2016-03-06 12:26:59 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:26:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:26:59 --> Final output sent to browser
DEBUG - 2016-03-06 15:26:59 --> Total execution time: 1.1659
INFO - 2016-03-06 12:27:23 --> Config Class Initialized
INFO - 2016-03-06 12:27:23 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:27:23 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:27:23 --> Utf8 Class Initialized
INFO - 2016-03-06 12:27:23 --> URI Class Initialized
INFO - 2016-03-06 12:27:23 --> Router Class Initialized
INFO - 2016-03-06 12:27:23 --> Output Class Initialized
INFO - 2016-03-06 12:27:23 --> Security Class Initialized
DEBUG - 2016-03-06 12:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:27:23 --> Input Class Initialized
INFO - 2016-03-06 12:27:23 --> Language Class Initialized
INFO - 2016-03-06 12:27:23 --> Loader Class Initialized
INFO - 2016-03-06 12:27:23 --> Helper loaded: url_helper
INFO - 2016-03-06 12:27:23 --> Helper loaded: file_helper
INFO - 2016-03-06 12:27:23 --> Helper loaded: date_helper
INFO - 2016-03-06 12:27:23 --> Helper loaded: form_helper
INFO - 2016-03-06 12:27:23 --> Database Driver Class Initialized
INFO - 2016-03-06 12:27:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:27:24 --> Controller Class Initialized
INFO - 2016-03-06 12:27:24 --> Model Class Initialized
INFO - 2016-03-06 12:27:24 --> Model Class Initialized
INFO - 2016-03-06 12:27:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:27:24 --> Pagination Class Initialized
INFO - 2016-03-06 12:27:24 --> Helper loaded: text_helper
INFO - 2016-03-06 12:27:24 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:27:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:27:24 --> Final output sent to browser
DEBUG - 2016-03-06 15:27:24 --> Total execution time: 1.1547
INFO - 2016-03-06 12:27:27 --> Config Class Initialized
INFO - 2016-03-06 12:27:27 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:27:27 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:27:27 --> Utf8 Class Initialized
INFO - 2016-03-06 12:27:27 --> URI Class Initialized
INFO - 2016-03-06 12:27:27 --> Router Class Initialized
INFO - 2016-03-06 12:27:27 --> Output Class Initialized
INFO - 2016-03-06 12:27:27 --> Security Class Initialized
DEBUG - 2016-03-06 12:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:27:27 --> Input Class Initialized
INFO - 2016-03-06 12:27:27 --> Language Class Initialized
INFO - 2016-03-06 12:27:27 --> Loader Class Initialized
INFO - 2016-03-06 12:27:27 --> Helper loaded: url_helper
INFO - 2016-03-06 12:27:27 --> Helper loaded: file_helper
INFO - 2016-03-06 12:27:27 --> Helper loaded: date_helper
INFO - 2016-03-06 12:27:27 --> Helper loaded: form_helper
INFO - 2016-03-06 12:27:27 --> Database Driver Class Initialized
INFO - 2016-03-06 12:27:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:27:28 --> Controller Class Initialized
INFO - 2016-03-06 12:27:28 --> Model Class Initialized
INFO - 2016-03-06 12:27:28 --> Model Class Initialized
INFO - 2016-03-06 12:27:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:27:28 --> Pagination Class Initialized
INFO - 2016-03-06 12:27:28 --> Helper loaded: text_helper
INFO - 2016-03-06 12:27:28 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:27:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:27:28 --> Final output sent to browser
DEBUG - 2016-03-06 15:27:28 --> Total execution time: 1.1455
INFO - 2016-03-06 12:27:29 --> Config Class Initialized
INFO - 2016-03-06 12:27:29 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:27:29 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:27:29 --> Utf8 Class Initialized
INFO - 2016-03-06 12:27:29 --> URI Class Initialized
INFO - 2016-03-06 12:27:29 --> Router Class Initialized
INFO - 2016-03-06 12:27:29 --> Output Class Initialized
INFO - 2016-03-06 12:27:29 --> Security Class Initialized
DEBUG - 2016-03-06 12:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:27:29 --> Input Class Initialized
INFO - 2016-03-06 12:27:29 --> Language Class Initialized
INFO - 2016-03-06 12:27:29 --> Loader Class Initialized
INFO - 2016-03-06 12:27:29 --> Helper loaded: url_helper
INFO - 2016-03-06 12:27:29 --> Helper loaded: file_helper
INFO - 2016-03-06 12:27:29 --> Helper loaded: date_helper
INFO - 2016-03-06 12:27:29 --> Helper loaded: form_helper
INFO - 2016-03-06 12:27:30 --> Database Driver Class Initialized
INFO - 2016-03-06 12:27:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:27:31 --> Controller Class Initialized
INFO - 2016-03-06 12:27:31 --> Model Class Initialized
INFO - 2016-03-06 12:27:31 --> Model Class Initialized
INFO - 2016-03-06 12:27:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:27:31 --> Pagination Class Initialized
INFO - 2016-03-06 12:27:31 --> Helper loaded: text_helper
INFO - 2016-03-06 12:27:31 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:27:31 --> Final output sent to browser
DEBUG - 2016-03-06 15:27:31 --> Total execution time: 1.3038
INFO - 2016-03-06 12:28:08 --> Config Class Initialized
INFO - 2016-03-06 12:28:08 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:28:08 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:28:08 --> Utf8 Class Initialized
INFO - 2016-03-06 12:28:08 --> URI Class Initialized
INFO - 2016-03-06 12:28:08 --> Router Class Initialized
INFO - 2016-03-06 12:28:08 --> Output Class Initialized
INFO - 2016-03-06 12:28:08 --> Security Class Initialized
DEBUG - 2016-03-06 12:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:28:08 --> Input Class Initialized
INFO - 2016-03-06 12:28:08 --> Language Class Initialized
INFO - 2016-03-06 12:28:08 --> Loader Class Initialized
INFO - 2016-03-06 12:28:08 --> Helper loaded: url_helper
INFO - 2016-03-06 12:28:08 --> Helper loaded: file_helper
INFO - 2016-03-06 12:28:08 --> Helper loaded: date_helper
INFO - 2016-03-06 12:28:08 --> Helper loaded: form_helper
INFO - 2016-03-06 12:28:08 --> Database Driver Class Initialized
INFO - 2016-03-06 12:28:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:28:09 --> Controller Class Initialized
INFO - 2016-03-06 12:28:09 --> Model Class Initialized
INFO - 2016-03-06 12:28:09 --> Model Class Initialized
INFO - 2016-03-06 12:28:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:28:09 --> Pagination Class Initialized
INFO - 2016-03-06 12:28:09 --> Helper loaded: text_helper
INFO - 2016-03-06 12:28:09 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:28:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:28:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:28:10 --> Final output sent to browser
DEBUG - 2016-03-06 15:28:10 --> Total execution time: 1.2853
INFO - 2016-03-06 12:28:48 --> Config Class Initialized
INFO - 2016-03-06 12:28:48 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:28:48 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:28:48 --> Utf8 Class Initialized
INFO - 2016-03-06 12:28:48 --> URI Class Initialized
INFO - 2016-03-06 12:28:48 --> Router Class Initialized
INFO - 2016-03-06 12:28:48 --> Output Class Initialized
INFO - 2016-03-06 12:28:48 --> Security Class Initialized
DEBUG - 2016-03-06 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:28:48 --> Input Class Initialized
INFO - 2016-03-06 12:28:48 --> Language Class Initialized
INFO - 2016-03-06 12:28:48 --> Loader Class Initialized
INFO - 2016-03-06 12:28:48 --> Helper loaded: url_helper
INFO - 2016-03-06 12:28:48 --> Helper loaded: file_helper
INFO - 2016-03-06 12:28:48 --> Helper loaded: date_helper
INFO - 2016-03-06 12:28:48 --> Helper loaded: form_helper
INFO - 2016-03-06 12:28:48 --> Database Driver Class Initialized
INFO - 2016-03-06 12:28:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:28:49 --> Controller Class Initialized
INFO - 2016-03-06 12:28:50 --> Model Class Initialized
INFO - 2016-03-06 12:28:50 --> Model Class Initialized
INFO - 2016-03-06 12:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:28:50 --> Pagination Class Initialized
INFO - 2016-03-06 12:28:50 --> Helper loaded: text_helper
INFO - 2016-03-06 12:28:50 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:28:50 --> Final output sent to browser
DEBUG - 2016-03-06 15:28:50 --> Total execution time: 1.2004
INFO - 2016-03-06 12:28:53 --> Config Class Initialized
INFO - 2016-03-06 12:28:53 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:28:53 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:28:53 --> Utf8 Class Initialized
INFO - 2016-03-06 12:28:53 --> URI Class Initialized
DEBUG - 2016-03-06 12:28:53 --> No URI present. Default controller set.
INFO - 2016-03-06 12:28:53 --> Router Class Initialized
INFO - 2016-03-06 12:28:53 --> Output Class Initialized
INFO - 2016-03-06 12:28:53 --> Security Class Initialized
DEBUG - 2016-03-06 12:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:28:53 --> Input Class Initialized
INFO - 2016-03-06 12:28:53 --> Language Class Initialized
INFO - 2016-03-06 12:28:53 --> Loader Class Initialized
INFO - 2016-03-06 12:28:53 --> Helper loaded: url_helper
INFO - 2016-03-06 12:28:53 --> Helper loaded: file_helper
INFO - 2016-03-06 12:28:53 --> Helper loaded: date_helper
INFO - 2016-03-06 12:28:53 --> Helper loaded: form_helper
INFO - 2016-03-06 12:28:53 --> Database Driver Class Initialized
INFO - 2016-03-06 12:28:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:28:54 --> Controller Class Initialized
INFO - 2016-03-06 12:28:54 --> Model Class Initialized
INFO - 2016-03-06 12:28:54 --> Model Class Initialized
INFO - 2016-03-06 12:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:28:54 --> Pagination Class Initialized
INFO - 2016-03-06 12:28:54 --> Helper loaded: text_helper
INFO - 2016-03-06 12:28:54 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 15:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:28:54 --> Final output sent to browser
DEBUG - 2016-03-06 15:28:54 --> Total execution time: 1.1249
INFO - 2016-03-06 12:28:56 --> Config Class Initialized
INFO - 2016-03-06 12:28:56 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:28:56 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:28:56 --> Utf8 Class Initialized
INFO - 2016-03-06 12:28:56 --> URI Class Initialized
INFO - 2016-03-06 12:28:56 --> Router Class Initialized
INFO - 2016-03-06 12:28:56 --> Output Class Initialized
INFO - 2016-03-06 12:28:56 --> Security Class Initialized
DEBUG - 2016-03-06 12:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:28:56 --> Input Class Initialized
INFO - 2016-03-06 12:28:56 --> Language Class Initialized
INFO - 2016-03-06 12:28:56 --> Loader Class Initialized
INFO - 2016-03-06 12:28:56 --> Helper loaded: url_helper
INFO - 2016-03-06 12:28:56 --> Helper loaded: file_helper
INFO - 2016-03-06 12:28:56 --> Helper loaded: date_helper
INFO - 2016-03-06 12:28:56 --> Helper loaded: form_helper
INFO - 2016-03-06 12:28:56 --> Database Driver Class Initialized
INFO - 2016-03-06 12:28:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:28:57 --> Controller Class Initialized
INFO - 2016-03-06 12:28:57 --> Model Class Initialized
INFO - 2016-03-06 12:28:57 --> Model Class Initialized
INFO - 2016-03-06 12:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:28:57 --> Pagination Class Initialized
INFO - 2016-03-06 12:28:57 --> Helper loaded: text_helper
INFO - 2016-03-06 12:28:57 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-06 15:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-06 15:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:28:57 --> Final output sent to browser
DEBUG - 2016-03-06 15:28:57 --> Total execution time: 1.1190
INFO - 2016-03-06 12:29:00 --> Config Class Initialized
INFO - 2016-03-06 12:29:00 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:29:00 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:29:00 --> Utf8 Class Initialized
INFO - 2016-03-06 12:29:00 --> URI Class Initialized
INFO - 2016-03-06 12:29:00 --> Router Class Initialized
INFO - 2016-03-06 12:29:00 --> Output Class Initialized
INFO - 2016-03-06 12:29:00 --> Security Class Initialized
DEBUG - 2016-03-06 12:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:29:00 --> Input Class Initialized
INFO - 2016-03-06 12:29:00 --> Language Class Initialized
INFO - 2016-03-06 12:29:00 --> Loader Class Initialized
INFO - 2016-03-06 12:29:00 --> Helper loaded: url_helper
INFO - 2016-03-06 12:29:00 --> Helper loaded: file_helper
INFO - 2016-03-06 12:29:00 --> Helper loaded: date_helper
INFO - 2016-03-06 12:29:00 --> Helper loaded: form_helper
INFO - 2016-03-06 12:29:00 --> Database Driver Class Initialized
INFO - 2016-03-06 12:29:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:29:01 --> Controller Class Initialized
INFO - 2016-03-06 12:29:01 --> Model Class Initialized
INFO - 2016-03-06 12:29:01 --> Model Class Initialized
INFO - 2016-03-06 12:29:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:29:01 --> Pagination Class Initialized
INFO - 2016-03-06 12:29:01 --> Helper loaded: text_helper
INFO - 2016-03-06 12:29:01 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:29:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:29:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:29:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:29:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:29:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-06 15:29:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:29:01 --> Final output sent to browser
DEBUG - 2016-03-06 15:29:01 --> Total execution time: 1.1641
INFO - 2016-03-06 12:30:08 --> Config Class Initialized
INFO - 2016-03-06 12:30:08 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:30:08 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:30:08 --> Utf8 Class Initialized
INFO - 2016-03-06 12:30:08 --> URI Class Initialized
INFO - 2016-03-06 12:30:08 --> Router Class Initialized
INFO - 2016-03-06 12:30:08 --> Output Class Initialized
INFO - 2016-03-06 12:30:08 --> Security Class Initialized
DEBUG - 2016-03-06 12:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:30:08 --> Input Class Initialized
INFO - 2016-03-06 12:30:08 --> Language Class Initialized
INFO - 2016-03-06 12:30:08 --> Loader Class Initialized
INFO - 2016-03-06 12:30:08 --> Helper loaded: url_helper
INFO - 2016-03-06 12:30:08 --> Helper loaded: file_helper
INFO - 2016-03-06 12:30:08 --> Helper loaded: date_helper
INFO - 2016-03-06 12:30:08 --> Helper loaded: form_helper
INFO - 2016-03-06 12:30:08 --> Database Driver Class Initialized
INFO - 2016-03-06 12:30:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:30:09 --> Controller Class Initialized
INFO - 2016-03-06 12:30:09 --> Model Class Initialized
INFO - 2016-03-06 12:30:09 --> Model Class Initialized
INFO - 2016-03-06 12:30:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:30:09 --> Pagination Class Initialized
INFO - 2016-03-06 12:30:09 --> Helper loaded: text_helper
INFO - 2016-03-06 12:30:09 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:30:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-06 15:30:09 --> Severity: Warning --> Missing argument 1 for Jboard_model::list_bottom(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 169 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 300
ERROR - 2016-03-06 15:30:09 --> Severity: Warning --> Missing argument 2 for Jboard_model::list_bottom(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 169 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 300
ERROR - 2016-03-06 15:30:09 --> Severity: Warning --> Missing argument 3 for Jboard_model::list_bottom(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 169 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 300
ERROR - 2016-03-06 15:30:09 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 302
ERROR - 2016-03-06 15:30:09 --> Severity: Notice --> Undefined variable: limit C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 302
ERROR - 2016-03-06 15:30:09 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 302
ERROR - 2016-03-06 15:30:09 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
INFO - 2016-03-06 15:30:09 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-03-06 15:30:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-03-06 12:30:48 --> Config Class Initialized
INFO - 2016-03-06 12:30:48 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:30:48 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:30:48 --> Utf8 Class Initialized
INFO - 2016-03-06 12:30:48 --> URI Class Initialized
INFO - 2016-03-06 12:30:48 --> Router Class Initialized
INFO - 2016-03-06 12:30:48 --> Output Class Initialized
INFO - 2016-03-06 12:30:48 --> Security Class Initialized
DEBUG - 2016-03-06 12:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:30:48 --> Input Class Initialized
INFO - 2016-03-06 12:30:48 --> Language Class Initialized
INFO - 2016-03-06 12:30:48 --> Loader Class Initialized
INFO - 2016-03-06 12:30:48 --> Helper loaded: url_helper
INFO - 2016-03-06 12:30:48 --> Helper loaded: file_helper
INFO - 2016-03-06 12:30:48 --> Helper loaded: date_helper
INFO - 2016-03-06 12:30:48 --> Helper loaded: form_helper
INFO - 2016-03-06 12:30:48 --> Database Driver Class Initialized
INFO - 2016-03-06 12:30:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:30:49 --> Controller Class Initialized
INFO - 2016-03-06 12:30:49 --> Model Class Initialized
INFO - 2016-03-06 12:30:49 --> Model Class Initialized
INFO - 2016-03-06 12:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:30:49 --> Pagination Class Initialized
INFO - 2016-03-06 12:30:50 --> Helper loaded: text_helper
INFO - 2016-03-06 12:30:50 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 15:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:30:50 --> Final output sent to browser
DEBUG - 2016-03-06 15:30:50 --> Total execution time: 1.1750
INFO - 2016-03-06 12:31:00 --> Config Class Initialized
INFO - 2016-03-06 12:31:00 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:31:00 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:31:00 --> Utf8 Class Initialized
INFO - 2016-03-06 12:31:00 --> URI Class Initialized
DEBUG - 2016-03-06 12:31:00 --> No URI present. Default controller set.
INFO - 2016-03-06 12:31:00 --> Router Class Initialized
INFO - 2016-03-06 12:31:00 --> Output Class Initialized
INFO - 2016-03-06 12:31:00 --> Security Class Initialized
DEBUG - 2016-03-06 12:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:31:00 --> Input Class Initialized
INFO - 2016-03-06 12:31:00 --> Language Class Initialized
INFO - 2016-03-06 12:31:00 --> Loader Class Initialized
INFO - 2016-03-06 12:31:00 --> Helper loaded: url_helper
INFO - 2016-03-06 12:31:00 --> Helper loaded: file_helper
INFO - 2016-03-06 12:31:00 --> Helper loaded: date_helper
INFO - 2016-03-06 12:31:00 --> Helper loaded: form_helper
INFO - 2016-03-06 12:31:00 --> Database Driver Class Initialized
INFO - 2016-03-06 12:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:31:01 --> Controller Class Initialized
INFO - 2016-03-06 12:31:01 --> Model Class Initialized
INFO - 2016-03-06 12:31:01 --> Model Class Initialized
INFO - 2016-03-06 12:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:31:01 --> Pagination Class Initialized
INFO - 2016-03-06 12:31:01 --> Helper loaded: text_helper
INFO - 2016-03-06 12:31:01 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 15:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:31:01 --> Final output sent to browser
DEBUG - 2016-03-06 15:31:01 --> Total execution time: 1.1166
INFO - 2016-03-06 12:31:08 --> Config Class Initialized
INFO - 2016-03-06 12:31:08 --> Hooks Class Initialized
DEBUG - 2016-03-06 12:31:08 --> UTF-8 Support Enabled
INFO - 2016-03-06 12:31:08 --> Utf8 Class Initialized
INFO - 2016-03-06 12:31:08 --> URI Class Initialized
DEBUG - 2016-03-06 12:31:08 --> No URI present. Default controller set.
INFO - 2016-03-06 12:31:08 --> Router Class Initialized
INFO - 2016-03-06 12:31:08 --> Output Class Initialized
INFO - 2016-03-06 12:31:08 --> Security Class Initialized
DEBUG - 2016-03-06 12:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 12:31:08 --> Input Class Initialized
INFO - 2016-03-06 12:31:08 --> Language Class Initialized
INFO - 2016-03-06 12:31:08 --> Loader Class Initialized
INFO - 2016-03-06 12:31:08 --> Helper loaded: url_helper
INFO - 2016-03-06 12:31:08 --> Helper loaded: file_helper
INFO - 2016-03-06 12:31:08 --> Helper loaded: date_helper
INFO - 2016-03-06 12:31:08 --> Helper loaded: form_helper
INFO - 2016-03-06 12:31:08 --> Database Driver Class Initialized
INFO - 2016-03-06 12:31:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 12:31:09 --> Controller Class Initialized
INFO - 2016-03-06 12:31:09 --> Model Class Initialized
INFO - 2016-03-06 12:31:09 --> Model Class Initialized
INFO - 2016-03-06 12:31:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 12:31:09 --> Pagination Class Initialized
INFO - 2016-03-06 12:31:09 --> Helper loaded: text_helper
INFO - 2016-03-06 12:31:09 --> Helper loaded: cookie_helper
INFO - 2016-03-06 15:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 15:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 15:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 15:31:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 15:31:09 --> Final output sent to browser
DEBUG - 2016-03-06 15:31:09 --> Total execution time: 1.1337
INFO - 2016-03-06 13:19:38 --> Config Class Initialized
INFO - 2016-03-06 13:19:38 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:19:38 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:19:38 --> Utf8 Class Initialized
INFO - 2016-03-06 13:19:38 --> URI Class Initialized
DEBUG - 2016-03-06 13:19:38 --> No URI present. Default controller set.
INFO - 2016-03-06 13:19:38 --> Router Class Initialized
INFO - 2016-03-06 13:19:38 --> Output Class Initialized
INFO - 2016-03-06 13:19:38 --> Security Class Initialized
DEBUG - 2016-03-06 13:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:19:38 --> Input Class Initialized
INFO - 2016-03-06 13:19:38 --> Language Class Initialized
INFO - 2016-03-06 13:19:38 --> Loader Class Initialized
INFO - 2016-03-06 13:19:38 --> Helper loaded: url_helper
INFO - 2016-03-06 13:19:38 --> Helper loaded: file_helper
INFO - 2016-03-06 13:19:38 --> Helper loaded: date_helper
INFO - 2016-03-06 13:19:38 --> Helper loaded: form_helper
INFO - 2016-03-06 13:19:38 --> Database Driver Class Initialized
INFO - 2016-03-06 13:19:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:19:39 --> Controller Class Initialized
INFO - 2016-03-06 13:19:39 --> Model Class Initialized
INFO - 2016-03-06 13:19:39 --> Model Class Initialized
INFO - 2016-03-06 13:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:19:39 --> Pagination Class Initialized
INFO - 2016-03-06 13:19:39 --> Helper loaded: text_helper
INFO - 2016-03-06 13:19:39 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 16:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 16:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 16:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 16:19:39 --> Final output sent to browser
DEBUG - 2016-03-06 16:19:39 --> Total execution time: 1.1472
INFO - 2016-03-06 13:21:20 --> Config Class Initialized
INFO - 2016-03-06 13:21:20 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:21:20 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:21:20 --> Utf8 Class Initialized
INFO - 2016-03-06 13:21:20 --> URI Class Initialized
INFO - 2016-03-06 13:21:20 --> Router Class Initialized
INFO - 2016-03-06 13:21:20 --> Output Class Initialized
INFO - 2016-03-06 13:21:20 --> Security Class Initialized
DEBUG - 2016-03-06 13:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:21:20 --> Input Class Initialized
INFO - 2016-03-06 13:21:20 --> Language Class Initialized
INFO - 2016-03-06 13:21:20 --> Loader Class Initialized
INFO - 2016-03-06 13:21:20 --> Helper loaded: url_helper
INFO - 2016-03-06 13:21:20 --> Helper loaded: file_helper
INFO - 2016-03-06 13:21:20 --> Helper loaded: date_helper
INFO - 2016-03-06 13:21:20 --> Helper loaded: form_helper
INFO - 2016-03-06 13:21:20 --> Database Driver Class Initialized
INFO - 2016-03-06 13:21:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:21:21 --> Controller Class Initialized
INFO - 2016-03-06 13:21:21 --> Model Class Initialized
INFO - 2016-03-06 13:21:21 --> Model Class Initialized
INFO - 2016-03-06 13:21:21 --> Form Validation Class Initialized
INFO - 2016-03-06 13:21:21 --> Helper loaded: text_helper
INFO - 2016-03-06 13:21:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-06 13:21:22 --> Query error: Duplicate entry 'gom3572@hotmail.com' for key 'email_idx' - Invalid query: INSERT INTO `user` (`nickname`, `email`, `password`, created) VALUES ('babana kick', 'gom3572@hotmail.com', '$2y$10$Zy5VJALiaEdeoDRqt36mgO.hjUhGR3NEyLHJJihVrs/aSVl.Xk33i', NOW())
INFO - 2016-03-06 13:21:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-06 13:23:06 --> Config Class Initialized
INFO - 2016-03-06 13:23:06 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:23:06 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:23:06 --> Utf8 Class Initialized
INFO - 2016-03-06 13:23:06 --> URI Class Initialized
DEBUG - 2016-03-06 13:23:06 --> No URI present. Default controller set.
INFO - 2016-03-06 13:23:06 --> Router Class Initialized
INFO - 2016-03-06 13:23:06 --> Output Class Initialized
INFO - 2016-03-06 13:23:06 --> Security Class Initialized
DEBUG - 2016-03-06 13:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:23:06 --> Input Class Initialized
INFO - 2016-03-06 13:23:06 --> Language Class Initialized
INFO - 2016-03-06 13:23:06 --> Loader Class Initialized
INFO - 2016-03-06 13:23:06 --> Helper loaded: url_helper
INFO - 2016-03-06 13:23:06 --> Helper loaded: file_helper
INFO - 2016-03-06 13:23:06 --> Helper loaded: date_helper
INFO - 2016-03-06 13:23:06 --> Helper loaded: form_helper
INFO - 2016-03-06 13:23:06 --> Database Driver Class Initialized
INFO - 2016-03-06 13:23:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:23:07 --> Controller Class Initialized
INFO - 2016-03-06 13:23:07 --> Model Class Initialized
INFO - 2016-03-06 13:23:07 --> Model Class Initialized
INFO - 2016-03-06 13:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:23:07 --> Pagination Class Initialized
INFO - 2016-03-06 13:23:07 --> Helper loaded: text_helper
INFO - 2016-03-06 13:23:07 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 16:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 16:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 16:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 16:23:07 --> Final output sent to browser
DEBUG - 2016-03-06 16:23:07 --> Total execution time: 1.1627
INFO - 2016-03-06 13:23:36 --> Config Class Initialized
INFO - 2016-03-06 13:23:36 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:23:36 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:23:36 --> Utf8 Class Initialized
INFO - 2016-03-06 13:23:36 --> URI Class Initialized
INFO - 2016-03-06 13:23:36 --> Router Class Initialized
INFO - 2016-03-06 13:23:36 --> Output Class Initialized
INFO - 2016-03-06 13:23:36 --> Security Class Initialized
DEBUG - 2016-03-06 13:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:23:36 --> Input Class Initialized
INFO - 2016-03-06 13:23:36 --> Language Class Initialized
INFO - 2016-03-06 13:23:36 --> Loader Class Initialized
INFO - 2016-03-06 13:23:36 --> Helper loaded: url_helper
INFO - 2016-03-06 13:23:36 --> Helper loaded: file_helper
INFO - 2016-03-06 13:23:36 --> Helper loaded: date_helper
INFO - 2016-03-06 13:23:36 --> Helper loaded: form_helper
INFO - 2016-03-06 13:23:36 --> Database Driver Class Initialized
INFO - 2016-03-06 13:23:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:23:37 --> Controller Class Initialized
INFO - 2016-03-06 13:23:37 --> Model Class Initialized
INFO - 2016-03-06 13:23:37 --> Model Class Initialized
INFO - 2016-03-06 13:23:37 --> Form Validation Class Initialized
INFO - 2016-03-06 13:23:37 --> Helper loaded: text_helper
INFO - 2016-03-06 13:23:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-06 13:23:37 --> Query error: Duplicate entry 'gom3572@hotmail.com' for key 'email_idx' - Invalid query: INSERT INTO `user` (`nickname`, `email`, `password`, created) VALUES ('babana kick', 'gom3572@hotmail.com', '$2y$10$GBEVBfxSL7vGOLYjF1BOreFiq2EbM9Uza7Qi3qxFkBfOv7YG10y5m', NOW())
INFO - 2016-03-06 13:23:37 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-06 13:27:56 --> Config Class Initialized
INFO - 2016-03-06 13:27:56 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:27:56 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:27:56 --> Utf8 Class Initialized
INFO - 2016-03-06 13:27:56 --> URI Class Initialized
DEBUG - 2016-03-06 13:27:56 --> No URI present. Default controller set.
INFO - 2016-03-06 13:27:56 --> Router Class Initialized
INFO - 2016-03-06 13:27:56 --> Output Class Initialized
INFO - 2016-03-06 13:27:56 --> Security Class Initialized
DEBUG - 2016-03-06 13:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:27:56 --> Input Class Initialized
INFO - 2016-03-06 13:27:56 --> Language Class Initialized
INFO - 2016-03-06 13:27:56 --> Loader Class Initialized
INFO - 2016-03-06 13:27:56 --> Helper loaded: url_helper
INFO - 2016-03-06 13:27:56 --> Helper loaded: file_helper
INFO - 2016-03-06 13:27:56 --> Helper loaded: date_helper
INFO - 2016-03-06 13:27:56 --> Helper loaded: form_helper
INFO - 2016-03-06 13:27:56 --> Database Driver Class Initialized
INFO - 2016-03-06 13:27:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:27:57 --> Controller Class Initialized
INFO - 2016-03-06 13:27:57 --> Model Class Initialized
INFO - 2016-03-06 13:27:57 --> Model Class Initialized
INFO - 2016-03-06 13:27:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:27:57 --> Pagination Class Initialized
INFO - 2016-03-06 13:27:57 --> Helper loaded: text_helper
INFO - 2016-03-06 13:27:57 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:27:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 16:27:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 16:27:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 16:27:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 16:27:57 --> Final output sent to browser
DEBUG - 2016-03-06 16:27:57 --> Total execution time: 1.1286
INFO - 2016-03-06 13:28:39 --> Config Class Initialized
INFO - 2016-03-06 13:28:39 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:28:39 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:28:39 --> Utf8 Class Initialized
INFO - 2016-03-06 13:28:39 --> URI Class Initialized
INFO - 2016-03-06 13:28:39 --> Router Class Initialized
INFO - 2016-03-06 13:28:39 --> Output Class Initialized
INFO - 2016-03-06 13:28:39 --> Security Class Initialized
DEBUG - 2016-03-06 13:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:28:39 --> Input Class Initialized
INFO - 2016-03-06 13:28:39 --> Language Class Initialized
INFO - 2016-03-06 13:28:39 --> Loader Class Initialized
INFO - 2016-03-06 13:28:39 --> Helper loaded: url_helper
INFO - 2016-03-06 13:28:39 --> Helper loaded: file_helper
INFO - 2016-03-06 13:28:39 --> Helper loaded: date_helper
INFO - 2016-03-06 13:28:39 --> Helper loaded: form_helper
INFO - 2016-03-06 13:28:39 --> Database Driver Class Initialized
INFO - 2016-03-06 13:28:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:28:40 --> Controller Class Initialized
INFO - 2016-03-06 13:28:40 --> Model Class Initialized
INFO - 2016-03-06 13:28:40 --> Model Class Initialized
INFO - 2016-03-06 13:28:40 --> Form Validation Class Initialized
INFO - 2016-03-06 13:28:40 --> Helper loaded: text_helper
INFO - 2016-03-06 13:28:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-06 13:28:40 --> Query error: Duplicate entry 'gom3572@hotmail.com' for key 'email_idx' - Invalid query: INSERT INTO `user` (`nickname`, `email`, `password`, created) VALUES ('banana kick', 'gom3572@hotmail.com', '$2y$10$DsgP52toViJuhzP6gL2BNeDCiKdSc6BMFNI5gPCQEHNO3FXgK4hRO', NOW())
INFO - 2016-03-06 13:28:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-06 13:31:58 --> Config Class Initialized
INFO - 2016-03-06 13:31:58 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:31:58 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:31:58 --> Utf8 Class Initialized
INFO - 2016-03-06 13:31:58 --> URI Class Initialized
DEBUG - 2016-03-06 13:31:58 --> No URI present. Default controller set.
INFO - 2016-03-06 13:31:58 --> Router Class Initialized
INFO - 2016-03-06 13:31:58 --> Output Class Initialized
INFO - 2016-03-06 13:31:58 --> Security Class Initialized
DEBUG - 2016-03-06 13:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:31:58 --> Input Class Initialized
INFO - 2016-03-06 13:31:58 --> Language Class Initialized
INFO - 2016-03-06 13:31:58 --> Loader Class Initialized
INFO - 2016-03-06 13:31:58 --> Helper loaded: url_helper
INFO - 2016-03-06 13:31:58 --> Helper loaded: file_helper
INFO - 2016-03-06 13:31:58 --> Helper loaded: date_helper
INFO - 2016-03-06 13:31:58 --> Helper loaded: form_helper
INFO - 2016-03-06 13:31:58 --> Database Driver Class Initialized
INFO - 2016-03-06 13:31:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:31:59 --> Controller Class Initialized
INFO - 2016-03-06 13:31:59 --> Model Class Initialized
INFO - 2016-03-06 13:31:59 --> Model Class Initialized
INFO - 2016-03-06 13:31:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:31:59 --> Pagination Class Initialized
INFO - 2016-03-06 13:31:59 --> Helper loaded: text_helper
INFO - 2016-03-06 13:31:59 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 16:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 16:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 16:31:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 16:31:59 --> Final output sent to browser
DEBUG - 2016-03-06 16:31:59 --> Total execution time: 1.1562
INFO - 2016-03-06 13:32:53 --> Config Class Initialized
INFO - 2016-03-06 13:32:53 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:32:53 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:32:53 --> Utf8 Class Initialized
INFO - 2016-03-06 13:32:53 --> URI Class Initialized
INFO - 2016-03-06 13:32:53 --> Router Class Initialized
INFO - 2016-03-06 13:32:53 --> Output Class Initialized
INFO - 2016-03-06 13:32:53 --> Security Class Initialized
DEBUG - 2016-03-06 13:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:32:53 --> Input Class Initialized
INFO - 2016-03-06 13:32:53 --> Language Class Initialized
INFO - 2016-03-06 13:32:53 --> Loader Class Initialized
INFO - 2016-03-06 13:32:53 --> Helper loaded: url_helper
INFO - 2016-03-06 13:32:53 --> Helper loaded: file_helper
INFO - 2016-03-06 13:32:53 --> Helper loaded: date_helper
INFO - 2016-03-06 13:32:53 --> Helper loaded: form_helper
INFO - 2016-03-06 13:32:53 --> Database Driver Class Initialized
INFO - 2016-03-06 13:32:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:32:54 --> Controller Class Initialized
INFO - 2016-03-06 13:32:54 --> Model Class Initialized
INFO - 2016-03-06 13:32:54 --> Model Class Initialized
INFO - 2016-03-06 13:32:54 --> Form Validation Class Initialized
INFO - 2016-03-06 13:32:54 --> Helper loaded: text_helper
INFO - 2016-03-06 13:32:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-06 13:32:55 --> Final output sent to browser
DEBUG - 2016-03-06 13:32:55 --> Total execution time: 1.2684
INFO - 2016-03-06 13:32:57 --> Config Class Initialized
INFO - 2016-03-06 13:32:57 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:32:57 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:32:57 --> Utf8 Class Initialized
INFO - 2016-03-06 13:32:57 --> URI Class Initialized
DEBUG - 2016-03-06 13:32:57 --> No URI present. Default controller set.
INFO - 2016-03-06 13:32:57 --> Router Class Initialized
INFO - 2016-03-06 13:32:57 --> Output Class Initialized
INFO - 2016-03-06 13:32:57 --> Security Class Initialized
DEBUG - 2016-03-06 13:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:32:57 --> Input Class Initialized
INFO - 2016-03-06 13:32:57 --> Language Class Initialized
INFO - 2016-03-06 13:32:57 --> Loader Class Initialized
INFO - 2016-03-06 13:32:57 --> Helper loaded: url_helper
INFO - 2016-03-06 13:32:57 --> Helper loaded: file_helper
INFO - 2016-03-06 13:32:57 --> Helper loaded: date_helper
INFO - 2016-03-06 13:32:57 --> Helper loaded: form_helper
INFO - 2016-03-06 13:32:57 --> Database Driver Class Initialized
INFO - 2016-03-06 13:32:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:32:58 --> Controller Class Initialized
INFO - 2016-03-06 13:32:58 --> Model Class Initialized
INFO - 2016-03-06 13:32:58 --> Model Class Initialized
INFO - 2016-03-06 13:32:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:32:58 --> Pagination Class Initialized
INFO - 2016-03-06 13:32:58 --> Helper loaded: text_helper
INFO - 2016-03-06 13:32:58 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:32:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 16:32:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 16:32:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-06 16:32:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 16:32:58 --> Final output sent to browser
DEBUG - 2016-03-06 16:32:58 --> Total execution time: 1.2168
INFO - 2016-03-06 13:33:05 --> Config Class Initialized
INFO - 2016-03-06 13:33:05 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:33:05 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:33:05 --> Utf8 Class Initialized
INFO - 2016-03-06 13:33:05 --> URI Class Initialized
INFO - 2016-03-06 13:33:05 --> Router Class Initialized
INFO - 2016-03-06 13:33:05 --> Output Class Initialized
INFO - 2016-03-06 13:33:05 --> Security Class Initialized
DEBUG - 2016-03-06 13:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:33:05 --> Input Class Initialized
INFO - 2016-03-06 13:33:05 --> Language Class Initialized
INFO - 2016-03-06 13:33:05 --> Loader Class Initialized
INFO - 2016-03-06 13:33:05 --> Helper loaded: url_helper
INFO - 2016-03-06 13:33:05 --> Helper loaded: file_helper
INFO - 2016-03-06 13:33:05 --> Helper loaded: date_helper
INFO - 2016-03-06 13:33:05 --> Helper loaded: form_helper
INFO - 2016-03-06 13:33:05 --> Database Driver Class Initialized
INFO - 2016-03-06 13:33:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:33:06 --> Controller Class Initialized
INFO - 2016-03-06 13:33:06 --> Model Class Initialized
INFO - 2016-03-06 13:33:06 --> Model Class Initialized
INFO - 2016-03-06 13:33:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:33:06 --> Pagination Class Initialized
INFO - 2016-03-06 13:33:06 --> Helper loaded: text_helper
INFO - 2016-03-06 13:33:06 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 16:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 16:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 16:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 16:33:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 16:33:06 --> Final output sent to browser
DEBUG - 2016-03-06 16:33:06 --> Total execution time: 1.2272
INFO - 2016-03-06 13:33:24 --> Config Class Initialized
INFO - 2016-03-06 13:33:24 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:33:24 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:33:24 --> Utf8 Class Initialized
INFO - 2016-03-06 13:33:24 --> URI Class Initialized
INFO - 2016-03-06 13:33:24 --> Router Class Initialized
INFO - 2016-03-06 13:33:24 --> Output Class Initialized
INFO - 2016-03-06 13:33:24 --> Security Class Initialized
DEBUG - 2016-03-06 13:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:33:24 --> Input Class Initialized
INFO - 2016-03-06 13:33:24 --> Language Class Initialized
INFO - 2016-03-06 13:33:24 --> Loader Class Initialized
INFO - 2016-03-06 13:33:24 --> Helper loaded: url_helper
INFO - 2016-03-06 13:33:24 --> Helper loaded: file_helper
INFO - 2016-03-06 13:33:24 --> Helper loaded: date_helper
INFO - 2016-03-06 13:33:24 --> Helper loaded: form_helper
INFO - 2016-03-06 13:33:24 --> Database Driver Class Initialized
INFO - 2016-03-06 13:33:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:33:25 --> Controller Class Initialized
INFO - 2016-03-06 13:33:25 --> Model Class Initialized
INFO - 2016-03-06 13:33:25 --> Model Class Initialized
INFO - 2016-03-06 13:33:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:33:25 --> Pagination Class Initialized
INFO - 2016-03-06 13:33:25 --> Helper loaded: text_helper
INFO - 2016-03-06 13:33:25 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:33:25 --> Final output sent to browser
DEBUG - 2016-03-06 16:33:25 --> Total execution time: 1.1284
INFO - 2016-03-06 13:33:55 --> Config Class Initialized
INFO - 2016-03-06 13:33:55 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:33:55 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:33:55 --> Utf8 Class Initialized
INFO - 2016-03-06 13:33:55 --> URI Class Initialized
INFO - 2016-03-06 13:33:55 --> Router Class Initialized
INFO - 2016-03-06 13:33:55 --> Output Class Initialized
INFO - 2016-03-06 13:33:55 --> Security Class Initialized
DEBUG - 2016-03-06 13:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:33:55 --> Input Class Initialized
INFO - 2016-03-06 13:33:55 --> Language Class Initialized
INFO - 2016-03-06 13:33:55 --> Loader Class Initialized
INFO - 2016-03-06 13:33:55 --> Helper loaded: url_helper
INFO - 2016-03-06 13:33:55 --> Helper loaded: file_helper
INFO - 2016-03-06 13:33:55 --> Helper loaded: date_helper
INFO - 2016-03-06 13:33:55 --> Helper loaded: form_helper
INFO - 2016-03-06 13:33:55 --> Database Driver Class Initialized
INFO - 2016-03-06 13:33:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:33:56 --> Controller Class Initialized
INFO - 2016-03-06 13:33:56 --> Model Class Initialized
INFO - 2016-03-06 13:33:56 --> Model Class Initialized
INFO - 2016-03-06 13:33:56 --> Form Validation Class Initialized
INFO - 2016-03-06 13:33:56 --> Helper loaded: text_helper
INFO - 2016-03-06 13:33:56 --> Final output sent to browser
DEBUG - 2016-03-06 13:33:56 --> Total execution time: 1.2035
INFO - 2016-03-06 13:33:56 --> Config Class Initialized
INFO - 2016-03-06 13:33:56 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:33:56 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:33:56 --> Utf8 Class Initialized
INFO - 2016-03-06 13:33:56 --> URI Class Initialized
INFO - 2016-03-06 13:33:56 --> Router Class Initialized
INFO - 2016-03-06 13:33:56 --> Output Class Initialized
INFO - 2016-03-06 13:33:56 --> Security Class Initialized
DEBUG - 2016-03-06 13:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:33:56 --> Input Class Initialized
INFO - 2016-03-06 13:33:56 --> Language Class Initialized
INFO - 2016-03-06 13:33:56 --> Loader Class Initialized
INFO - 2016-03-06 13:33:56 --> Helper loaded: url_helper
INFO - 2016-03-06 13:33:56 --> Helper loaded: file_helper
INFO - 2016-03-06 13:33:56 --> Helper loaded: date_helper
INFO - 2016-03-06 13:33:56 --> Helper loaded: form_helper
INFO - 2016-03-06 13:33:57 --> Database Driver Class Initialized
INFO - 2016-03-06 13:33:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:33:58 --> Controller Class Initialized
INFO - 2016-03-06 13:33:58 --> Model Class Initialized
INFO - 2016-03-06 13:33:58 --> Model Class Initialized
INFO - 2016-03-06 13:33:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:33:58 --> Pagination Class Initialized
INFO - 2016-03-06 13:33:58 --> Helper loaded: text_helper
INFO - 2016-03-06 13:33:58 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 16:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 16:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-06 16:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 16:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 16:33:58 --> Final output sent to browser
DEBUG - 2016-03-06 16:33:58 --> Total execution time: 1.2192
INFO - 2016-03-06 13:34:04 --> Config Class Initialized
INFO - 2016-03-06 13:34:04 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:34:04 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:34:04 --> Utf8 Class Initialized
INFO - 2016-03-06 13:34:04 --> URI Class Initialized
INFO - 2016-03-06 13:34:04 --> Router Class Initialized
INFO - 2016-03-06 13:34:04 --> Output Class Initialized
INFO - 2016-03-06 13:34:04 --> Security Class Initialized
DEBUG - 2016-03-06 13:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:34:04 --> Input Class Initialized
INFO - 2016-03-06 13:34:04 --> Language Class Initialized
INFO - 2016-03-06 13:34:04 --> Loader Class Initialized
INFO - 2016-03-06 13:34:04 --> Helper loaded: url_helper
INFO - 2016-03-06 13:34:04 --> Helper loaded: file_helper
INFO - 2016-03-06 13:34:04 --> Helper loaded: date_helper
INFO - 2016-03-06 13:34:04 --> Helper loaded: form_helper
INFO - 2016-03-06 13:34:04 --> Database Driver Class Initialized
INFO - 2016-03-06 13:34:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:34:05 --> Controller Class Initialized
INFO - 2016-03-06 13:34:05 --> Model Class Initialized
INFO - 2016-03-06 13:34:05 --> Model Class Initialized
INFO - 2016-03-06 13:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:34:05 --> Pagination Class Initialized
INFO - 2016-03-06 13:34:05 --> Helper loaded: text_helper
INFO - 2016-03-06 13:34:05 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:34:05 --> Final output sent to browser
DEBUG - 2016-03-06 16:34:05 --> Total execution time: 1.1524
INFO - 2016-03-06 13:37:07 --> Config Class Initialized
INFO - 2016-03-06 13:37:07 --> Hooks Class Initialized
DEBUG - 2016-03-06 13:37:07 --> UTF-8 Support Enabled
INFO - 2016-03-06 13:37:07 --> Utf8 Class Initialized
INFO - 2016-03-06 13:37:07 --> URI Class Initialized
INFO - 2016-03-06 13:37:07 --> Router Class Initialized
INFO - 2016-03-06 13:37:07 --> Output Class Initialized
INFO - 2016-03-06 13:37:07 --> Security Class Initialized
DEBUG - 2016-03-06 13:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-06 13:37:07 --> Input Class Initialized
INFO - 2016-03-06 13:37:07 --> Language Class Initialized
INFO - 2016-03-06 13:37:07 --> Loader Class Initialized
INFO - 2016-03-06 13:37:07 --> Helper loaded: url_helper
INFO - 2016-03-06 13:37:07 --> Helper loaded: file_helper
INFO - 2016-03-06 13:37:07 --> Helper loaded: date_helper
INFO - 2016-03-06 13:37:07 --> Helper loaded: form_helper
INFO - 2016-03-06 13:37:07 --> Database Driver Class Initialized
INFO - 2016-03-06 13:37:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-06 13:37:08 --> Controller Class Initialized
INFO - 2016-03-06 13:37:08 --> Model Class Initialized
INFO - 2016-03-06 13:37:08 --> Model Class Initialized
INFO - 2016-03-06 13:37:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-06 13:37:08 --> Pagination Class Initialized
INFO - 2016-03-06 13:37:08 --> Helper loaded: text_helper
INFO - 2016-03-06 13:37:08 --> Helper loaded: cookie_helper
INFO - 2016-03-06 16:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-06 16:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-06 16:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-06 16:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-06 16:37:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-06 16:37:08 --> Final output sent to browser
DEBUG - 2016-03-06 16:37:08 --> Total execution time: 1.1864
