<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-01-26 10:39:31 --> Config Class Initialized
INFO - 2016-01-26 10:39:31 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:39:31 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:39:31 --> Utf8 Class Initialized
INFO - 2016-01-26 10:39:31 --> URI Class Initialized
DEBUG - 2016-01-26 10:39:31 --> No URI present. Default controller set.
INFO - 2016-01-26 10:39:31 --> Router Class Initialized
INFO - 2016-01-26 10:39:31 --> Output Class Initialized
INFO - 2016-01-26 10:39:31 --> Security Class Initialized
DEBUG - 2016-01-26 10:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:39:31 --> Input Class Initialized
INFO - 2016-01-26 10:39:31 --> Language Class Initialized
INFO - 2016-01-26 10:39:31 --> Loader Class Initialized
INFO - 2016-01-26 10:39:31 --> Helper loaded: url_helper
INFO - 2016-01-26 10:39:31 --> Helper loaded: file_helper
INFO - 2016-01-26 10:39:31 --> Helper loaded: date_helper
INFO - 2016-01-26 10:39:31 --> Database Driver Class Initialized
INFO - 2016-01-26 10:39:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:39:32 --> Controller Class Initialized
INFO - 2016-01-26 10:39:32 --> Model Class Initialized
INFO - 2016-01-26 10:39:32 --> Model Class Initialized
INFO - 2016-01-26 10:39:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:39:32 --> Pagination Class Initialized
INFO - 2016-01-26 10:39:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:39:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 10:39:32 --> Final output sent to browser
DEBUG - 2016-01-26 10:39:32 --> Total execution time: 1.4945
INFO - 2016-01-26 10:39:35 --> Config Class Initialized
INFO - 2016-01-26 10:39:35 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:39:35 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:39:35 --> Utf8 Class Initialized
INFO - 2016-01-26 10:39:35 --> URI Class Initialized
INFO - 2016-01-26 10:39:35 --> Router Class Initialized
INFO - 2016-01-26 10:39:35 --> Output Class Initialized
INFO - 2016-01-26 10:39:35 --> Security Class Initialized
DEBUG - 2016-01-26 10:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:39:35 --> Input Class Initialized
INFO - 2016-01-26 10:39:35 --> Language Class Initialized
INFO - 2016-01-26 10:39:35 --> Loader Class Initialized
INFO - 2016-01-26 10:39:35 --> Helper loaded: url_helper
INFO - 2016-01-26 10:39:35 --> Helper loaded: file_helper
INFO - 2016-01-26 10:39:35 --> Helper loaded: date_helper
INFO - 2016-01-26 10:39:35 --> Database Driver Class Initialized
INFO - 2016-01-26 10:39:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:39:36 --> Controller Class Initialized
INFO - 2016-01-26 10:39:36 --> Model Class Initialized
INFO - 2016-01-26 10:39:36 --> Model Class Initialized
INFO - 2016-01-26 10:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:39:36 --> Pagination Class Initialized
INFO - 2016-01-26 10:39:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:39:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 10:39:36 --> Final output sent to browser
DEBUG - 2016-01-26 10:39:36 --> Total execution time: 1.0818
INFO - 2016-01-26 10:39:38 --> Config Class Initialized
INFO - 2016-01-26 10:39:38 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:39:38 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:39:38 --> Utf8 Class Initialized
INFO - 2016-01-26 10:39:38 --> URI Class Initialized
INFO - 2016-01-26 10:39:38 --> Router Class Initialized
INFO - 2016-01-26 10:39:38 --> Output Class Initialized
INFO - 2016-01-26 10:39:38 --> Security Class Initialized
DEBUG - 2016-01-26 10:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:39:38 --> Input Class Initialized
INFO - 2016-01-26 10:39:38 --> Language Class Initialized
INFO - 2016-01-26 10:39:38 --> Loader Class Initialized
INFO - 2016-01-26 10:39:38 --> Helper loaded: url_helper
INFO - 2016-01-26 10:39:38 --> Helper loaded: file_helper
INFO - 2016-01-26 10:39:38 --> Helper loaded: date_helper
INFO - 2016-01-26 10:39:38 --> Database Driver Class Initialized
INFO - 2016-01-26 10:39:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:39:39 --> Controller Class Initialized
INFO - 2016-01-26 10:39:39 --> Model Class Initialized
INFO - 2016-01-26 10:39:39 --> Model Class Initialized
INFO - 2016-01-26 10:39:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:39:39 --> Pagination Class Initialized
INFO - 2016-01-26 10:39:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:39:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 10:39:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 10:39:39 --> Final output sent to browser
DEBUG - 2016-01-26 10:39:39 --> Total execution time: 1.3048
INFO - 2016-01-26 10:39:43 --> Config Class Initialized
INFO - 2016-01-26 10:39:43 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:39:43 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:39:43 --> Utf8 Class Initialized
INFO - 2016-01-26 10:39:43 --> URI Class Initialized
INFO - 2016-01-26 10:39:43 --> Router Class Initialized
INFO - 2016-01-26 10:39:43 --> Output Class Initialized
INFO - 2016-01-26 10:39:43 --> Security Class Initialized
DEBUG - 2016-01-26 10:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:39:43 --> Input Class Initialized
INFO - 2016-01-26 10:39:43 --> Language Class Initialized
INFO - 2016-01-26 10:39:43 --> Loader Class Initialized
INFO - 2016-01-26 10:39:43 --> Helper loaded: url_helper
INFO - 2016-01-26 10:39:43 --> Helper loaded: file_helper
INFO - 2016-01-26 10:39:43 --> Helper loaded: date_helper
INFO - 2016-01-26 10:39:43 --> Database Driver Class Initialized
INFO - 2016-01-26 10:39:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:39:44 --> Controller Class Initialized
INFO - 2016-01-26 10:39:44 --> Model Class Initialized
INFO - 2016-01-26 10:39:44 --> Model Class Initialized
INFO - 2016-01-26 10:39:44 --> Helper loaded: form_helper
INFO - 2016-01-26 10:39:44 --> Form Validation Class Initialized
INFO - 2016-01-26 10:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:39:44 --> Final output sent to browser
DEBUG - 2016-01-26 10:39:44 --> Total execution time: 1.1681
INFO - 2016-01-26 10:39:49 --> Config Class Initialized
INFO - 2016-01-26 10:39:49 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:39:49 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:39:49 --> Utf8 Class Initialized
INFO - 2016-01-26 10:39:49 --> URI Class Initialized
INFO - 2016-01-26 10:39:49 --> Router Class Initialized
INFO - 2016-01-26 10:39:49 --> Output Class Initialized
INFO - 2016-01-26 10:39:49 --> Security Class Initialized
DEBUG - 2016-01-26 10:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:39:49 --> Input Class Initialized
INFO - 2016-01-26 10:39:49 --> Language Class Initialized
INFO - 2016-01-26 10:39:49 --> Loader Class Initialized
INFO - 2016-01-26 10:39:49 --> Helper loaded: url_helper
INFO - 2016-01-26 10:39:49 --> Helper loaded: file_helper
INFO - 2016-01-26 10:39:49 --> Helper loaded: date_helper
INFO - 2016-01-26 10:39:49 --> Database Driver Class Initialized
INFO - 2016-01-26 10:39:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:39:50 --> Controller Class Initialized
INFO - 2016-01-26 10:39:50 --> Model Class Initialized
INFO - 2016-01-26 10:39:50 --> Model Class Initialized
INFO - 2016-01-26 10:39:50 --> Helper loaded: form_helper
INFO - 2016-01-26 10:39:50 --> Form Validation Class Initialized
INFO - 2016-01-26 10:39:50 --> Config Class Initialized
INFO - 2016-01-26 10:39:50 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:39:50 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:39:50 --> Utf8 Class Initialized
INFO - 2016-01-26 10:39:50 --> URI Class Initialized
INFO - 2016-01-26 10:39:50 --> Router Class Initialized
INFO - 2016-01-26 10:39:50 --> Output Class Initialized
INFO - 2016-01-26 10:39:50 --> Security Class Initialized
DEBUG - 2016-01-26 10:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:39:50 --> Input Class Initialized
INFO - 2016-01-26 10:39:50 --> Language Class Initialized
INFO - 2016-01-26 10:39:50 --> Loader Class Initialized
INFO - 2016-01-26 10:39:50 --> Helper loaded: url_helper
INFO - 2016-01-26 10:39:50 --> Helper loaded: file_helper
INFO - 2016-01-26 10:39:50 --> Helper loaded: date_helper
INFO - 2016-01-26 10:39:50 --> Database Driver Class Initialized
INFO - 2016-01-26 10:39:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:39:51 --> Controller Class Initialized
INFO - 2016-01-26 10:39:51 --> Model Class Initialized
INFO - 2016-01-26 10:39:51 --> Model Class Initialized
INFO - 2016-01-26 10:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:39:51 --> Pagination Class Initialized
INFO - 2016-01-26 10:39:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:39:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 10:39:51 --> Final output sent to browser
DEBUG - 2016-01-26 10:39:51 --> Total execution time: 1.0991
INFO - 2016-01-26 10:39:56 --> Config Class Initialized
INFO - 2016-01-26 10:39:56 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:39:56 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:39:56 --> Utf8 Class Initialized
INFO - 2016-01-26 10:39:56 --> URI Class Initialized
INFO - 2016-01-26 10:39:56 --> Router Class Initialized
INFO - 2016-01-26 10:39:56 --> Output Class Initialized
INFO - 2016-01-26 10:39:56 --> Security Class Initialized
DEBUG - 2016-01-26 10:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:39:56 --> Input Class Initialized
INFO - 2016-01-26 10:39:56 --> Language Class Initialized
INFO - 2016-01-26 10:39:56 --> Loader Class Initialized
INFO - 2016-01-26 10:39:56 --> Helper loaded: url_helper
INFO - 2016-01-26 10:39:56 --> Helper loaded: file_helper
INFO - 2016-01-26 10:39:56 --> Helper loaded: date_helper
INFO - 2016-01-26 10:39:56 --> Database Driver Class Initialized
INFO - 2016-01-26 10:39:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:39:57 --> Controller Class Initialized
INFO - 2016-01-26 10:39:57 --> Model Class Initialized
INFO - 2016-01-26 10:39:57 --> Model Class Initialized
INFO - 2016-01-26 10:39:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:39:57 --> Pagination Class Initialized
INFO - 2016-01-26 10:39:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:39:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 10:39:57 --> Final output sent to browser
DEBUG - 2016-01-26 10:39:57 --> Total execution time: 1.0788
INFO - 2016-01-26 10:39:59 --> Config Class Initialized
INFO - 2016-01-26 10:39:59 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:39:59 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:39:59 --> Utf8 Class Initialized
INFO - 2016-01-26 10:39:59 --> URI Class Initialized
INFO - 2016-01-26 10:39:59 --> Router Class Initialized
INFO - 2016-01-26 10:39:59 --> Output Class Initialized
INFO - 2016-01-26 10:39:59 --> Security Class Initialized
DEBUG - 2016-01-26 10:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:39:59 --> Input Class Initialized
INFO - 2016-01-26 10:39:59 --> Language Class Initialized
INFO - 2016-01-26 10:39:59 --> Loader Class Initialized
INFO - 2016-01-26 10:39:59 --> Helper loaded: url_helper
INFO - 2016-01-26 10:39:59 --> Helper loaded: file_helper
INFO - 2016-01-26 10:39:59 --> Helper loaded: date_helper
INFO - 2016-01-26 10:39:59 --> Database Driver Class Initialized
INFO - 2016-01-26 10:40:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:40:00 --> Controller Class Initialized
INFO - 2016-01-26 10:40:00 --> Model Class Initialized
INFO - 2016-01-26 10:40:00 --> Model Class Initialized
INFO - 2016-01-26 10:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:40:00 --> Pagination Class Initialized
INFO - 2016-01-26 10:40:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:40:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 10:40:00 --> Final output sent to browser
DEBUG - 2016-01-26 10:40:00 --> Total execution time: 1.1015
INFO - 2016-01-26 10:40:02 --> Config Class Initialized
INFO - 2016-01-26 10:40:02 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:40:02 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:40:02 --> Utf8 Class Initialized
INFO - 2016-01-26 10:40:02 --> URI Class Initialized
INFO - 2016-01-26 10:40:02 --> Router Class Initialized
INFO - 2016-01-26 10:40:02 --> Output Class Initialized
INFO - 2016-01-26 10:40:02 --> Security Class Initialized
DEBUG - 2016-01-26 10:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:40:02 --> Input Class Initialized
INFO - 2016-01-26 10:40:02 --> Language Class Initialized
INFO - 2016-01-26 10:40:02 --> Loader Class Initialized
INFO - 2016-01-26 10:40:02 --> Helper loaded: url_helper
INFO - 2016-01-26 10:40:02 --> Helper loaded: file_helper
INFO - 2016-01-26 10:40:02 --> Helper loaded: date_helper
INFO - 2016-01-26 10:40:02 --> Database Driver Class Initialized
INFO - 2016-01-26 10:40:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:40:03 --> Controller Class Initialized
INFO - 2016-01-26 10:40:03 --> Model Class Initialized
INFO - 2016-01-26 10:40:03 --> Model Class Initialized
INFO - 2016-01-26 10:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:40:03 --> Pagination Class Initialized
INFO - 2016-01-26 10:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 10:40:03 --> Final output sent to browser
DEBUG - 2016-01-26 10:40:03 --> Total execution time: 1.1002
INFO - 2016-01-26 10:41:12 --> Config Class Initialized
INFO - 2016-01-26 10:41:12 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:41:12 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:41:12 --> Utf8 Class Initialized
INFO - 2016-01-26 10:41:12 --> URI Class Initialized
INFO - 2016-01-26 10:41:12 --> Router Class Initialized
INFO - 2016-01-26 10:41:12 --> Output Class Initialized
INFO - 2016-01-26 10:41:12 --> Security Class Initialized
DEBUG - 2016-01-26 10:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:41:12 --> Input Class Initialized
INFO - 2016-01-26 10:41:12 --> Language Class Initialized
INFO - 2016-01-26 10:41:12 --> Loader Class Initialized
INFO - 2016-01-26 10:41:12 --> Helper loaded: url_helper
INFO - 2016-01-26 10:41:12 --> Helper loaded: file_helper
INFO - 2016-01-26 10:41:12 --> Helper loaded: date_helper
INFO - 2016-01-26 10:41:12 --> Database Driver Class Initialized
INFO - 2016-01-26 10:41:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:41:13 --> Controller Class Initialized
INFO - 2016-01-26 10:41:13 --> Model Class Initialized
INFO - 2016-01-26 10:41:13 --> Model Class Initialized
INFO - 2016-01-26 10:41:13 --> Helper loaded: form_helper
INFO - 2016-01-26 10:41:13 --> Form Validation Class Initialized
INFO - 2016-01-26 10:41:13 --> Config Class Initialized
INFO - 2016-01-26 10:41:13 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:41:13 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:41:13 --> Utf8 Class Initialized
INFO - 2016-01-26 10:41:13 --> URI Class Initialized
INFO - 2016-01-26 10:41:13 --> Router Class Initialized
INFO - 2016-01-26 10:41:13 --> Output Class Initialized
INFO - 2016-01-26 10:41:13 --> Security Class Initialized
DEBUG - 2016-01-26 10:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:41:13 --> Input Class Initialized
INFO - 2016-01-26 10:41:13 --> Language Class Initialized
INFO - 2016-01-26 10:41:13 --> Loader Class Initialized
INFO - 2016-01-26 10:41:13 --> Helper loaded: url_helper
INFO - 2016-01-26 10:41:13 --> Helper loaded: file_helper
INFO - 2016-01-26 10:41:13 --> Helper loaded: date_helper
INFO - 2016-01-26 10:41:13 --> Database Driver Class Initialized
INFO - 2016-01-26 10:41:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:41:14 --> Controller Class Initialized
INFO - 2016-01-26 10:41:14 --> Model Class Initialized
INFO - 2016-01-26 10:41:14 --> Model Class Initialized
INFO - 2016-01-26 10:41:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:41:14 --> Pagination Class Initialized
INFO - 2016-01-26 10:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:41:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 10:41:14 --> Final output sent to browser
DEBUG - 2016-01-26 10:41:14 --> Total execution time: 1.0928
INFO - 2016-01-26 10:41:18 --> Config Class Initialized
INFO - 2016-01-26 10:41:18 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:41:18 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:41:18 --> Utf8 Class Initialized
INFO - 2016-01-26 10:41:18 --> URI Class Initialized
INFO - 2016-01-26 10:41:18 --> Router Class Initialized
INFO - 2016-01-26 10:41:18 --> Output Class Initialized
INFO - 2016-01-26 10:41:18 --> Security Class Initialized
DEBUG - 2016-01-26 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:41:18 --> Input Class Initialized
INFO - 2016-01-26 10:41:18 --> Language Class Initialized
INFO - 2016-01-26 10:41:18 --> Loader Class Initialized
INFO - 2016-01-26 10:41:18 --> Helper loaded: url_helper
INFO - 2016-01-26 10:41:18 --> Helper loaded: file_helper
INFO - 2016-01-26 10:41:18 --> Helper loaded: date_helper
INFO - 2016-01-26 10:41:18 --> Database Driver Class Initialized
INFO - 2016-01-26 10:41:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:41:19 --> Controller Class Initialized
INFO - 2016-01-26 10:41:19 --> Model Class Initialized
INFO - 2016-01-26 10:41:19 --> Model Class Initialized
INFO - 2016-01-26 10:41:19 --> Helper loaded: form_helper
INFO - 2016-01-26 10:41:19 --> Form Validation Class Initialized
INFO - 2016-01-26 10:41:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:41:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:41:19 --> Final output sent to browser
DEBUG - 2016-01-26 10:41:19 --> Total execution time: 1.0848
INFO - 2016-01-26 10:41:26 --> Config Class Initialized
INFO - 2016-01-26 10:41:26 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:41:26 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:41:26 --> Utf8 Class Initialized
INFO - 2016-01-26 10:41:26 --> URI Class Initialized
INFO - 2016-01-26 10:41:26 --> Router Class Initialized
INFO - 2016-01-26 10:41:26 --> Output Class Initialized
INFO - 2016-01-26 10:41:26 --> Security Class Initialized
DEBUG - 2016-01-26 10:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:41:26 --> Input Class Initialized
INFO - 2016-01-26 10:41:26 --> Language Class Initialized
INFO - 2016-01-26 10:41:26 --> Loader Class Initialized
INFO - 2016-01-26 10:41:26 --> Helper loaded: url_helper
INFO - 2016-01-26 10:41:26 --> Helper loaded: file_helper
INFO - 2016-01-26 10:41:26 --> Helper loaded: date_helper
INFO - 2016-01-26 10:41:26 --> Database Driver Class Initialized
INFO - 2016-01-26 10:41:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:41:27 --> Controller Class Initialized
INFO - 2016-01-26 10:41:27 --> Model Class Initialized
INFO - 2016-01-26 10:41:27 --> Model Class Initialized
INFO - 2016-01-26 10:41:27 --> Helper loaded: form_helper
INFO - 2016-01-26 10:41:27 --> Form Validation Class Initialized
INFO - 2016-01-26 10:41:27 --> Config Class Initialized
INFO - 2016-01-26 10:41:27 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:41:27 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:41:27 --> Utf8 Class Initialized
INFO - 2016-01-26 10:41:27 --> URI Class Initialized
INFO - 2016-01-26 10:41:27 --> Router Class Initialized
INFO - 2016-01-26 10:41:27 --> Output Class Initialized
INFO - 2016-01-26 10:41:27 --> Security Class Initialized
DEBUG - 2016-01-26 10:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:41:27 --> Input Class Initialized
INFO - 2016-01-26 10:41:27 --> Language Class Initialized
ERROR - 2016-01-26 10:41:27 --> 404 Page Not Found: Signin-test-f/index
INFO - 2016-01-26 10:41:52 --> Config Class Initialized
INFO - 2016-01-26 10:41:52 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:41:52 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:41:52 --> Utf8 Class Initialized
INFO - 2016-01-26 10:41:52 --> URI Class Initialized
INFO - 2016-01-26 10:41:52 --> Router Class Initialized
INFO - 2016-01-26 10:41:52 --> Output Class Initialized
INFO - 2016-01-26 10:41:52 --> Security Class Initialized
DEBUG - 2016-01-26 10:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:41:52 --> Input Class Initialized
INFO - 2016-01-26 10:41:52 --> Language Class Initialized
INFO - 2016-01-26 10:41:52 --> Loader Class Initialized
INFO - 2016-01-26 10:41:52 --> Helper loaded: url_helper
INFO - 2016-01-26 10:41:52 --> Helper loaded: file_helper
INFO - 2016-01-26 10:41:52 --> Helper loaded: date_helper
INFO - 2016-01-26 10:41:52 --> Database Driver Class Initialized
INFO - 2016-01-26 10:41:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:41:53 --> Controller Class Initialized
INFO - 2016-01-26 10:41:53 --> Model Class Initialized
INFO - 2016-01-26 10:41:53 --> Model Class Initialized
INFO - 2016-01-26 10:41:53 --> Helper loaded: form_helper
INFO - 2016-01-26 10:41:53 --> Form Validation Class Initialized
INFO - 2016-01-26 10:41:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:41:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:41:53 --> Final output sent to browser
DEBUG - 2016-01-26 10:41:53 --> Total execution time: 1.1084
INFO - 2016-01-26 10:41:57 --> Config Class Initialized
INFO - 2016-01-26 10:41:57 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:41:57 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:41:57 --> Utf8 Class Initialized
INFO - 2016-01-26 10:41:57 --> URI Class Initialized
INFO - 2016-01-26 10:41:57 --> Router Class Initialized
INFO - 2016-01-26 10:41:57 --> Output Class Initialized
INFO - 2016-01-26 10:41:57 --> Security Class Initialized
DEBUG - 2016-01-26 10:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:41:57 --> Input Class Initialized
INFO - 2016-01-26 10:41:57 --> Language Class Initialized
INFO - 2016-01-26 10:41:57 --> Loader Class Initialized
INFO - 2016-01-26 10:41:57 --> Helper loaded: url_helper
INFO - 2016-01-26 10:41:57 --> Helper loaded: file_helper
INFO - 2016-01-26 10:41:57 --> Helper loaded: date_helper
INFO - 2016-01-26 10:41:57 --> Database Driver Class Initialized
INFO - 2016-01-26 10:41:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:41:58 --> Controller Class Initialized
INFO - 2016-01-26 10:41:58 --> Model Class Initialized
INFO - 2016-01-26 10:41:58 --> Model Class Initialized
INFO - 2016-01-26 10:41:59 --> Helper loaded: form_helper
INFO - 2016-01-26 10:41:59 --> Form Validation Class Initialized
INFO - 2016-01-26 10:41:59 --> Config Class Initialized
INFO - 2016-01-26 10:41:59 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:41:59 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:41:59 --> Utf8 Class Initialized
INFO - 2016-01-26 10:41:59 --> URI Class Initialized
INFO - 2016-01-26 10:41:59 --> Router Class Initialized
INFO - 2016-01-26 10:41:59 --> Output Class Initialized
INFO - 2016-01-26 10:41:59 --> Security Class Initialized
DEBUG - 2016-01-26 10:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:41:59 --> Input Class Initialized
INFO - 2016-01-26 10:41:59 --> Language Class Initialized
ERROR - 2016-01-26 10:41:59 --> 404 Page Not Found: Signin/index
INFO - 2016-01-26 10:42:11 --> Config Class Initialized
INFO - 2016-01-26 10:42:11 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:42:11 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:42:11 --> Utf8 Class Initialized
INFO - 2016-01-26 10:42:11 --> URI Class Initialized
INFO - 2016-01-26 10:42:11 --> Router Class Initialized
INFO - 2016-01-26 10:42:11 --> Output Class Initialized
INFO - 2016-01-26 10:42:11 --> Security Class Initialized
DEBUG - 2016-01-26 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:42:11 --> Input Class Initialized
INFO - 2016-01-26 10:42:11 --> Language Class Initialized
INFO - 2016-01-26 10:42:11 --> Loader Class Initialized
INFO - 2016-01-26 10:42:11 --> Helper loaded: url_helper
INFO - 2016-01-26 10:42:11 --> Helper loaded: file_helper
INFO - 2016-01-26 10:42:11 --> Helper loaded: date_helper
INFO - 2016-01-26 10:42:11 --> Database Driver Class Initialized
INFO - 2016-01-26 10:42:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:42:12 --> Controller Class Initialized
INFO - 2016-01-26 10:42:12 --> Model Class Initialized
INFO - 2016-01-26 10:42:12 --> Model Class Initialized
INFO - 2016-01-26 10:42:12 --> Helper loaded: form_helper
INFO - 2016-01-26 10:42:12 --> Form Validation Class Initialized
INFO - 2016-01-26 10:42:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:42:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:42:12 --> Final output sent to browser
DEBUG - 2016-01-26 10:42:12 --> Total execution time: 1.0974
INFO - 2016-01-26 10:42:17 --> Config Class Initialized
INFO - 2016-01-26 10:42:17 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:42:17 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:42:17 --> Utf8 Class Initialized
INFO - 2016-01-26 10:42:17 --> URI Class Initialized
INFO - 2016-01-26 10:42:17 --> Router Class Initialized
INFO - 2016-01-26 10:42:17 --> Output Class Initialized
INFO - 2016-01-26 10:42:17 --> Security Class Initialized
DEBUG - 2016-01-26 10:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:42:17 --> Input Class Initialized
INFO - 2016-01-26 10:42:17 --> Language Class Initialized
INFO - 2016-01-26 10:42:17 --> Loader Class Initialized
INFO - 2016-01-26 10:42:17 --> Helper loaded: url_helper
INFO - 2016-01-26 10:42:17 --> Helper loaded: file_helper
INFO - 2016-01-26 10:42:17 --> Helper loaded: date_helper
INFO - 2016-01-26 10:42:17 --> Database Driver Class Initialized
INFO - 2016-01-26 10:42:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:42:18 --> Controller Class Initialized
INFO - 2016-01-26 10:42:18 --> Model Class Initialized
INFO - 2016-01-26 10:42:18 --> Model Class Initialized
INFO - 2016-01-26 10:42:18 --> Helper loaded: form_helper
INFO - 2016-01-26 10:42:18 --> Form Validation Class Initialized
INFO - 2016-01-26 10:42:18 --> Config Class Initialized
INFO - 2016-01-26 10:42:18 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:42:18 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:42:18 --> Utf8 Class Initialized
INFO - 2016-01-26 10:42:18 --> URI Class Initialized
INFO - 2016-01-26 10:42:18 --> Router Class Initialized
INFO - 2016-01-26 10:42:18 --> Output Class Initialized
INFO - 2016-01-26 10:42:18 --> Security Class Initialized
DEBUG - 2016-01-26 10:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:42:18 --> Input Class Initialized
INFO - 2016-01-26 10:42:18 --> Language Class Initialized
ERROR - 2016-01-26 10:42:18 --> 404 Page Not Found: Auth/signin
INFO - 2016-01-26 10:46:27 --> Config Class Initialized
INFO - 2016-01-26 10:46:27 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:46:27 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:46:27 --> Utf8 Class Initialized
INFO - 2016-01-26 10:46:27 --> URI Class Initialized
INFO - 2016-01-26 10:46:27 --> Router Class Initialized
INFO - 2016-01-26 10:46:27 --> Output Class Initialized
INFO - 2016-01-26 10:46:27 --> Security Class Initialized
DEBUG - 2016-01-26 10:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:46:27 --> Input Class Initialized
INFO - 2016-01-26 10:46:27 --> Language Class Initialized
INFO - 2016-01-26 10:46:27 --> Loader Class Initialized
INFO - 2016-01-26 10:46:27 --> Helper loaded: url_helper
INFO - 2016-01-26 10:46:27 --> Helper loaded: file_helper
INFO - 2016-01-26 10:46:27 --> Helper loaded: date_helper
INFO - 2016-01-26 10:46:27 --> Database Driver Class Initialized
INFO - 2016-01-26 10:46:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:46:29 --> Controller Class Initialized
INFO - 2016-01-26 10:46:29 --> Model Class Initialized
INFO - 2016-01-26 10:46:29 --> Model Class Initialized
INFO - 2016-01-26 10:46:29 --> Helper loaded: form_helper
INFO - 2016-01-26 10:46:29 --> Form Validation Class Initialized
INFO - 2016-01-26 10:46:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:46:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:46:29 --> Final output sent to browser
DEBUG - 2016-01-26 10:46:29 --> Total execution time: 2.3945
INFO - 2016-01-26 10:46:37 --> Config Class Initialized
INFO - 2016-01-26 10:46:37 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:46:37 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:46:37 --> Utf8 Class Initialized
INFO - 2016-01-26 10:46:37 --> URI Class Initialized
INFO - 2016-01-26 10:46:37 --> Router Class Initialized
INFO - 2016-01-26 10:46:37 --> Output Class Initialized
INFO - 2016-01-26 10:46:37 --> Security Class Initialized
DEBUG - 2016-01-26 10:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:46:37 --> Input Class Initialized
INFO - 2016-01-26 10:46:37 --> Language Class Initialized
INFO - 2016-01-26 10:46:37 --> Loader Class Initialized
INFO - 2016-01-26 10:46:37 --> Helper loaded: url_helper
INFO - 2016-01-26 10:46:37 --> Helper loaded: file_helper
INFO - 2016-01-26 10:46:37 --> Helper loaded: date_helper
INFO - 2016-01-26 10:46:37 --> Database Driver Class Initialized
INFO - 2016-01-26 10:46:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:46:38 --> Controller Class Initialized
INFO - 2016-01-26 10:46:38 --> Model Class Initialized
INFO - 2016-01-26 10:46:38 --> Model Class Initialized
INFO - 2016-01-26 10:46:38 --> Helper loaded: form_helper
INFO - 2016-01-26 10:46:38 --> Form Validation Class Initialized
INFO - 2016-01-26 10:46:39 --> Config Class Initialized
INFO - 2016-01-26 10:46:39 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:46:39 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:46:39 --> Utf8 Class Initialized
INFO - 2016-01-26 10:46:39 --> URI Class Initialized
INFO - 2016-01-26 10:46:39 --> Router Class Initialized
INFO - 2016-01-26 10:46:39 --> Output Class Initialized
INFO - 2016-01-26 10:46:39 --> Security Class Initialized
DEBUG - 2016-01-26 10:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:46:39 --> Input Class Initialized
INFO - 2016-01-26 10:46:39 --> Language Class Initialized
INFO - 2016-01-26 10:46:39 --> Loader Class Initialized
INFO - 2016-01-26 10:46:39 --> Helper loaded: url_helper
INFO - 2016-01-26 10:46:39 --> Helper loaded: file_helper
INFO - 2016-01-26 10:46:39 --> Helper loaded: date_helper
INFO - 2016-01-26 10:46:39 --> Database Driver Class Initialized
INFO - 2016-01-26 10:46:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:46:40 --> Controller Class Initialized
INFO - 2016-01-26 10:46:40 --> Model Class Initialized
INFO - 2016-01-26 10:46:40 --> Model Class Initialized
INFO - 2016-01-26 10:46:40 --> Helper loaded: form_helper
INFO - 2016-01-26 10:46:40 --> Form Validation Class Initialized
INFO - 2016-01-26 10:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:46:40 --> Final output sent to browser
DEBUG - 2016-01-26 10:46:40 --> Total execution time: 1.2446
INFO - 2016-01-26 10:49:02 --> Config Class Initialized
INFO - 2016-01-26 10:49:02 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:49:02 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:49:02 --> Utf8 Class Initialized
INFO - 2016-01-26 10:49:02 --> URI Class Initialized
INFO - 2016-01-26 10:49:02 --> Router Class Initialized
INFO - 2016-01-26 10:49:02 --> Output Class Initialized
INFO - 2016-01-26 10:49:02 --> Security Class Initialized
DEBUG - 2016-01-26 10:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:49:02 --> Input Class Initialized
INFO - 2016-01-26 10:49:02 --> Language Class Initialized
INFO - 2016-01-26 10:49:02 --> Loader Class Initialized
INFO - 2016-01-26 10:49:02 --> Helper loaded: url_helper
INFO - 2016-01-26 10:49:02 --> Helper loaded: file_helper
INFO - 2016-01-26 10:49:02 --> Helper loaded: date_helper
INFO - 2016-01-26 10:49:02 --> Database Driver Class Initialized
INFO - 2016-01-26 10:49:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:49:03 --> Controller Class Initialized
INFO - 2016-01-26 10:49:03 --> Model Class Initialized
INFO - 2016-01-26 10:49:03 --> Model Class Initialized
INFO - 2016-01-26 10:49:03 --> Helper loaded: form_helper
INFO - 2016-01-26 10:49:03 --> Form Validation Class Initialized
INFO - 2016-01-26 10:49:03 --> Config Class Initialized
INFO - 2016-01-26 10:49:03 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:49:03 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:49:03 --> Utf8 Class Initialized
INFO - 2016-01-26 10:49:03 --> URI Class Initialized
INFO - 2016-01-26 10:49:03 --> Router Class Initialized
INFO - 2016-01-26 10:49:03 --> Output Class Initialized
INFO - 2016-01-26 10:49:03 --> Security Class Initialized
DEBUG - 2016-01-26 10:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:49:03 --> Input Class Initialized
INFO - 2016-01-26 10:49:03 --> Language Class Initialized
INFO - 2016-01-26 10:49:03 --> Loader Class Initialized
INFO - 2016-01-26 10:49:03 --> Helper loaded: url_helper
INFO - 2016-01-26 10:49:03 --> Helper loaded: file_helper
INFO - 2016-01-26 10:49:03 --> Helper loaded: date_helper
INFO - 2016-01-26 10:49:03 --> Database Driver Class Initialized
INFO - 2016-01-26 10:49:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:49:04 --> Controller Class Initialized
INFO - 2016-01-26 10:49:04 --> Model Class Initialized
INFO - 2016-01-26 10:49:04 --> Model Class Initialized
INFO - 2016-01-26 10:49:04 --> Helper loaded: form_helper
INFO - 2016-01-26 10:49:04 --> Form Validation Class Initialized
INFO - 2016-01-26 10:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:49:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:49:04 --> Final output sent to browser
DEBUG - 2016-01-26 10:49:04 --> Total execution time: 1.1786
INFO - 2016-01-26 10:49:12 --> Config Class Initialized
INFO - 2016-01-26 10:49:12 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:49:12 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:49:12 --> Utf8 Class Initialized
INFO - 2016-01-26 10:49:12 --> URI Class Initialized
INFO - 2016-01-26 10:49:12 --> Router Class Initialized
INFO - 2016-01-26 10:49:12 --> Output Class Initialized
INFO - 2016-01-26 10:49:12 --> Security Class Initialized
DEBUG - 2016-01-26 10:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:49:12 --> Input Class Initialized
INFO - 2016-01-26 10:49:12 --> Language Class Initialized
INFO - 2016-01-26 10:49:12 --> Loader Class Initialized
INFO - 2016-01-26 10:49:12 --> Helper loaded: url_helper
INFO - 2016-01-26 10:49:12 --> Helper loaded: file_helper
INFO - 2016-01-26 10:49:12 --> Helper loaded: date_helper
INFO - 2016-01-26 10:49:12 --> Database Driver Class Initialized
INFO - 2016-01-26 10:49:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:49:13 --> Controller Class Initialized
INFO - 2016-01-26 10:49:13 --> Model Class Initialized
INFO - 2016-01-26 10:49:13 --> Model Class Initialized
INFO - 2016-01-26 10:49:13 --> Helper loaded: form_helper
INFO - 2016-01-26 10:49:13 --> Form Validation Class Initialized
INFO - 2016-01-26 10:49:14 --> Config Class Initialized
INFO - 2016-01-26 10:49:14 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:49:14 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:49:14 --> Utf8 Class Initialized
INFO - 2016-01-26 10:49:14 --> URI Class Initialized
INFO - 2016-01-26 10:49:14 --> Router Class Initialized
INFO - 2016-01-26 10:49:14 --> Output Class Initialized
INFO - 2016-01-26 10:49:14 --> Security Class Initialized
DEBUG - 2016-01-26 10:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:49:14 --> Input Class Initialized
INFO - 2016-01-26 10:49:14 --> Language Class Initialized
INFO - 2016-01-26 10:49:14 --> Loader Class Initialized
INFO - 2016-01-26 10:49:14 --> Helper loaded: url_helper
INFO - 2016-01-26 10:49:14 --> Helper loaded: file_helper
INFO - 2016-01-26 10:49:14 --> Helper loaded: date_helper
INFO - 2016-01-26 10:49:14 --> Database Driver Class Initialized
INFO - 2016-01-26 10:49:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:49:15 --> Controller Class Initialized
INFO - 2016-01-26 10:49:15 --> Model Class Initialized
INFO - 2016-01-26 10:49:15 --> Model Class Initialized
INFO - 2016-01-26 10:49:15 --> Helper loaded: form_helper
INFO - 2016-01-26 10:49:15 --> Form Validation Class Initialized
INFO - 2016-01-26 10:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:49:15 --> Final output sent to browser
DEBUG - 2016-01-26 10:49:15 --> Total execution time: 1.0933
INFO - 2016-01-26 10:59:53 --> Config Class Initialized
INFO - 2016-01-26 10:59:53 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:59:53 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:59:53 --> Utf8 Class Initialized
INFO - 2016-01-26 10:59:53 --> URI Class Initialized
DEBUG - 2016-01-26 10:59:53 --> No URI present. Default controller set.
INFO - 2016-01-26 10:59:53 --> Router Class Initialized
INFO - 2016-01-26 10:59:53 --> Output Class Initialized
INFO - 2016-01-26 10:59:53 --> Security Class Initialized
DEBUG - 2016-01-26 10:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:59:53 --> Input Class Initialized
INFO - 2016-01-26 10:59:53 --> Language Class Initialized
INFO - 2016-01-26 10:59:53 --> Loader Class Initialized
INFO - 2016-01-26 10:59:53 --> Helper loaded: url_helper
INFO - 2016-01-26 10:59:53 --> Helper loaded: file_helper
INFO - 2016-01-26 10:59:53 --> Helper loaded: date_helper
INFO - 2016-01-26 10:59:53 --> Database Driver Class Initialized
INFO - 2016-01-26 10:59:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:59:54 --> Controller Class Initialized
INFO - 2016-01-26 10:59:54 --> Model Class Initialized
INFO - 2016-01-26 10:59:54 --> Model Class Initialized
INFO - 2016-01-26 10:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 10:59:54 --> Pagination Class Initialized
INFO - 2016-01-26 10:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 10:59:54 --> Final output sent to browser
DEBUG - 2016-01-26 10:59:54 --> Total execution time: 1.8163
INFO - 2016-01-26 10:59:57 --> Config Class Initialized
INFO - 2016-01-26 10:59:57 --> Hooks Class Initialized
DEBUG - 2016-01-26 10:59:57 --> UTF-8 Support Enabled
INFO - 2016-01-26 10:59:57 --> Utf8 Class Initialized
INFO - 2016-01-26 10:59:57 --> URI Class Initialized
INFO - 2016-01-26 10:59:57 --> Router Class Initialized
INFO - 2016-01-26 10:59:57 --> Output Class Initialized
INFO - 2016-01-26 10:59:57 --> Security Class Initialized
DEBUG - 2016-01-26 10:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 10:59:57 --> Input Class Initialized
INFO - 2016-01-26 10:59:57 --> Language Class Initialized
INFO - 2016-01-26 10:59:57 --> Loader Class Initialized
INFO - 2016-01-26 10:59:57 --> Helper loaded: url_helper
INFO - 2016-01-26 10:59:57 --> Helper loaded: file_helper
INFO - 2016-01-26 10:59:57 --> Helper loaded: date_helper
INFO - 2016-01-26 10:59:57 --> Database Driver Class Initialized
INFO - 2016-01-26 10:59:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 10:59:58 --> Controller Class Initialized
INFO - 2016-01-26 10:59:58 --> Model Class Initialized
INFO - 2016-01-26 10:59:58 --> Model Class Initialized
INFO - 2016-01-26 10:59:58 --> Helper loaded: form_helper
INFO - 2016-01-26 10:59:58 --> Form Validation Class Initialized
INFO - 2016-01-26 10:59:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 10:59:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 10:59:58 --> Final output sent to browser
DEBUG - 2016-01-26 10:59:58 --> Total execution time: 1.1803
INFO - 2016-01-26 11:00:04 --> Config Class Initialized
INFO - 2016-01-26 11:00:04 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:00:04 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:00:04 --> Utf8 Class Initialized
INFO - 2016-01-26 11:00:04 --> URI Class Initialized
INFO - 2016-01-26 11:00:04 --> Router Class Initialized
INFO - 2016-01-26 11:00:04 --> Output Class Initialized
INFO - 2016-01-26 11:00:04 --> Security Class Initialized
DEBUG - 2016-01-26 11:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:00:04 --> Input Class Initialized
INFO - 2016-01-26 11:00:04 --> Language Class Initialized
INFO - 2016-01-26 11:00:04 --> Loader Class Initialized
INFO - 2016-01-26 11:00:04 --> Helper loaded: url_helper
INFO - 2016-01-26 11:00:04 --> Helper loaded: file_helper
INFO - 2016-01-26 11:00:04 --> Helper loaded: date_helper
INFO - 2016-01-26 11:00:04 --> Database Driver Class Initialized
INFO - 2016-01-26 11:00:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:00:05 --> Controller Class Initialized
INFO - 2016-01-26 11:00:05 --> Model Class Initialized
INFO - 2016-01-26 11:00:05 --> Model Class Initialized
INFO - 2016-01-26 11:00:05 --> Helper loaded: form_helper
INFO - 2016-01-26 11:00:05 --> Form Validation Class Initialized
INFO - 2016-01-26 11:00:05 --> Config Class Initialized
INFO - 2016-01-26 11:00:05 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:00:05 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:00:05 --> Utf8 Class Initialized
INFO - 2016-01-26 11:00:05 --> URI Class Initialized
INFO - 2016-01-26 11:00:05 --> Router Class Initialized
INFO - 2016-01-26 11:00:05 --> Output Class Initialized
INFO - 2016-01-26 11:00:05 --> Security Class Initialized
DEBUG - 2016-01-26 11:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:00:05 --> Input Class Initialized
INFO - 2016-01-26 11:00:05 --> Language Class Initialized
INFO - 2016-01-26 11:00:05 --> Loader Class Initialized
INFO - 2016-01-26 11:00:05 --> Helper loaded: url_helper
INFO - 2016-01-26 11:00:05 --> Helper loaded: file_helper
INFO - 2016-01-26 11:00:05 --> Helper loaded: date_helper
INFO - 2016-01-26 11:00:05 --> Database Driver Class Initialized
INFO - 2016-01-26 11:00:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:00:06 --> Controller Class Initialized
INFO - 2016-01-26 11:00:06 --> Model Class Initialized
INFO - 2016-01-26 11:00:06 --> Model Class Initialized
INFO - 2016-01-26 11:00:06 --> Helper loaded: form_helper
INFO - 2016-01-26 11:00:06 --> Form Validation Class Initialized
INFO - 2016-01-26 11:00:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:00:35 --> Config Class Initialized
INFO - 2016-01-26 11:00:35 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:00:35 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:00:35 --> Utf8 Class Initialized
INFO - 2016-01-26 11:00:35 --> URI Class Initialized
INFO - 2016-01-26 11:00:35 --> Router Class Initialized
INFO - 2016-01-26 11:00:35 --> Output Class Initialized
INFO - 2016-01-26 11:00:35 --> Security Class Initialized
DEBUG - 2016-01-26 11:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:00:35 --> Input Class Initialized
INFO - 2016-01-26 11:00:35 --> Language Class Initialized
INFO - 2016-01-26 11:00:35 --> Loader Class Initialized
INFO - 2016-01-26 11:00:35 --> Helper loaded: url_helper
INFO - 2016-01-26 11:00:35 --> Helper loaded: file_helper
INFO - 2016-01-26 11:00:35 --> Helper loaded: date_helper
INFO - 2016-01-26 11:00:35 --> Database Driver Class Initialized
INFO - 2016-01-26 11:00:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:00:36 --> Controller Class Initialized
INFO - 2016-01-26 11:00:36 --> Model Class Initialized
INFO - 2016-01-26 11:00:36 --> Model Class Initialized
INFO - 2016-01-26 11:00:36 --> Helper loaded: form_helper
INFO - 2016-01-26 11:00:36 --> Form Validation Class Initialized
INFO - 2016-01-26 11:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 11:00:36 --> Final output sent to browser
DEBUG - 2016-01-26 11:00:36 --> Total execution time: 1.1067
INFO - 2016-01-26 11:00:42 --> Config Class Initialized
INFO - 2016-01-26 11:00:42 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:00:42 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:00:42 --> Utf8 Class Initialized
INFO - 2016-01-26 11:00:42 --> URI Class Initialized
INFO - 2016-01-26 11:00:42 --> Router Class Initialized
INFO - 2016-01-26 11:00:42 --> Output Class Initialized
INFO - 2016-01-26 11:00:42 --> Security Class Initialized
DEBUG - 2016-01-26 11:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:00:42 --> Input Class Initialized
INFO - 2016-01-26 11:00:42 --> Language Class Initialized
INFO - 2016-01-26 11:00:42 --> Loader Class Initialized
INFO - 2016-01-26 11:00:42 --> Helper loaded: url_helper
INFO - 2016-01-26 11:00:42 --> Helper loaded: file_helper
INFO - 2016-01-26 11:00:42 --> Helper loaded: date_helper
INFO - 2016-01-26 11:00:42 --> Database Driver Class Initialized
INFO - 2016-01-26 11:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:00:43 --> Controller Class Initialized
INFO - 2016-01-26 11:00:43 --> Model Class Initialized
INFO - 2016-01-26 11:00:43 --> Model Class Initialized
INFO - 2016-01-26 11:00:43 --> Helper loaded: form_helper
INFO - 2016-01-26 11:00:43 --> Form Validation Class Initialized
INFO - 2016-01-26 11:00:43 --> Config Class Initialized
INFO - 2016-01-26 11:00:43 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:00:43 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:00:43 --> Utf8 Class Initialized
INFO - 2016-01-26 11:00:43 --> URI Class Initialized
INFO - 2016-01-26 11:00:43 --> Router Class Initialized
INFO - 2016-01-26 11:00:43 --> Output Class Initialized
INFO - 2016-01-26 11:00:43 --> Security Class Initialized
DEBUG - 2016-01-26 11:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:00:43 --> Input Class Initialized
INFO - 2016-01-26 11:00:43 --> Language Class Initialized
INFO - 2016-01-26 11:00:43 --> Loader Class Initialized
INFO - 2016-01-26 11:00:43 --> Helper loaded: url_helper
INFO - 2016-01-26 11:00:43 --> Helper loaded: file_helper
INFO - 2016-01-26 11:00:43 --> Helper loaded: date_helper
INFO - 2016-01-26 11:00:43 --> Database Driver Class Initialized
INFO - 2016-01-26 11:00:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:00:44 --> Controller Class Initialized
INFO - 2016-01-26 11:00:44 --> Model Class Initialized
INFO - 2016-01-26 11:00:44 --> Model Class Initialized
INFO - 2016-01-26 11:00:44 --> Helper loaded: form_helper
INFO - 2016-01-26 11:00:44 --> Form Validation Class Initialized
INFO - 2016-01-26 11:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:00:44 --> Final output sent to browser
DEBUG - 2016-01-26 11:00:44 --> Total execution time: 1.0852
INFO - 2016-01-26 11:05:54 --> Config Class Initialized
INFO - 2016-01-26 11:05:54 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:05:54 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:05:54 --> Utf8 Class Initialized
INFO - 2016-01-26 11:05:54 --> URI Class Initialized
INFO - 2016-01-26 11:05:54 --> Router Class Initialized
INFO - 2016-01-26 11:05:54 --> Output Class Initialized
INFO - 2016-01-26 11:05:54 --> Security Class Initialized
DEBUG - 2016-01-26 11:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:05:54 --> Input Class Initialized
INFO - 2016-01-26 11:05:54 --> Language Class Initialized
INFO - 2016-01-26 11:05:54 --> Loader Class Initialized
INFO - 2016-01-26 11:05:54 --> Helper loaded: url_helper
INFO - 2016-01-26 11:05:54 --> Helper loaded: file_helper
INFO - 2016-01-26 11:05:54 --> Helper loaded: date_helper
INFO - 2016-01-26 11:05:54 --> Database Driver Class Initialized
INFO - 2016-01-26 11:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:05:55 --> Controller Class Initialized
INFO - 2016-01-26 11:05:55 --> Model Class Initialized
INFO - 2016-01-26 11:05:55 --> Model Class Initialized
INFO - 2016-01-26 11:05:55 --> Helper loaded: form_helper
INFO - 2016-01-26 11:05:55 --> Form Validation Class Initialized
INFO - 2016-01-26 11:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\side_login_banner.php
INFO - 2016-01-26 11:05:55 --> Final output sent to browser
DEBUG - 2016-01-26 11:05:55 --> Total execution time: 1.0858
INFO - 2016-01-26 11:06:20 --> Config Class Initialized
INFO - 2016-01-26 11:06:20 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:06:20 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:06:20 --> Utf8 Class Initialized
INFO - 2016-01-26 11:06:20 --> URI Class Initialized
INFO - 2016-01-26 11:06:20 --> Router Class Initialized
INFO - 2016-01-26 11:06:20 --> Output Class Initialized
INFO - 2016-01-26 11:06:20 --> Security Class Initialized
DEBUG - 2016-01-26 11:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:06:20 --> Input Class Initialized
INFO - 2016-01-26 11:06:20 --> Language Class Initialized
INFO - 2016-01-26 11:06:20 --> Loader Class Initialized
INFO - 2016-01-26 11:06:20 --> Helper loaded: url_helper
INFO - 2016-01-26 11:06:20 --> Helper loaded: file_helper
INFO - 2016-01-26 11:06:20 --> Helper loaded: date_helper
INFO - 2016-01-26 11:06:20 --> Database Driver Class Initialized
INFO - 2016-01-26 11:06:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:06:21 --> Controller Class Initialized
INFO - 2016-01-26 11:06:21 --> Model Class Initialized
INFO - 2016-01-26 11:06:21 --> Model Class Initialized
INFO - 2016-01-26 11:06:21 --> Helper loaded: form_helper
INFO - 2016-01-26 11:06:21 --> Form Validation Class Initialized
INFO - 2016-01-26 11:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\side_login_banner.php
INFO - 2016-01-26 11:06:21 --> Final output sent to browser
DEBUG - 2016-01-26 11:06:21 --> Total execution time: 1.1682
INFO - 2016-01-26 11:07:11 --> Config Class Initialized
INFO - 2016-01-26 11:07:11 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:07:11 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:07:11 --> Utf8 Class Initialized
INFO - 2016-01-26 11:07:11 --> URI Class Initialized
DEBUG - 2016-01-26 11:07:11 --> No URI present. Default controller set.
INFO - 2016-01-26 11:07:11 --> Router Class Initialized
INFO - 2016-01-26 11:07:11 --> Output Class Initialized
INFO - 2016-01-26 11:07:11 --> Security Class Initialized
DEBUG - 2016-01-26 11:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:07:11 --> Input Class Initialized
INFO - 2016-01-26 11:07:11 --> Language Class Initialized
INFO - 2016-01-26 11:07:11 --> Loader Class Initialized
INFO - 2016-01-26 11:07:11 --> Helper loaded: url_helper
INFO - 2016-01-26 11:07:11 --> Helper loaded: file_helper
INFO - 2016-01-26 11:07:11 --> Helper loaded: date_helper
INFO - 2016-01-26 11:07:11 --> Database Driver Class Initialized
INFO - 2016-01-26 11:07:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:07:12 --> Controller Class Initialized
INFO - 2016-01-26 11:07:12 --> Model Class Initialized
INFO - 2016-01-26 11:07:12 --> Model Class Initialized
INFO - 2016-01-26 11:07:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 11:07:12 --> Pagination Class Initialized
INFO - 2016-01-26 11:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:07:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 11:07:12 --> Final output sent to browser
DEBUG - 2016-01-26 11:07:12 --> Total execution time: 1.0978
INFO - 2016-01-26 11:07:14 --> Config Class Initialized
INFO - 2016-01-26 11:07:14 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:07:14 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:07:14 --> Utf8 Class Initialized
INFO - 2016-01-26 11:07:14 --> URI Class Initialized
INFO - 2016-01-26 11:07:14 --> Router Class Initialized
INFO - 2016-01-26 11:07:14 --> Output Class Initialized
INFO - 2016-01-26 11:07:14 --> Security Class Initialized
DEBUG - 2016-01-26 11:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:07:14 --> Input Class Initialized
INFO - 2016-01-26 11:07:14 --> Language Class Initialized
INFO - 2016-01-26 11:07:14 --> Loader Class Initialized
INFO - 2016-01-26 11:07:14 --> Helper loaded: url_helper
INFO - 2016-01-26 11:07:14 --> Helper loaded: file_helper
INFO - 2016-01-26 11:07:14 --> Helper loaded: date_helper
INFO - 2016-01-26 11:07:14 --> Database Driver Class Initialized
INFO - 2016-01-26 11:07:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:07:15 --> Controller Class Initialized
INFO - 2016-01-26 11:07:15 --> Model Class Initialized
INFO - 2016-01-26 11:07:15 --> Model Class Initialized
INFO - 2016-01-26 11:07:15 --> Helper loaded: form_helper
INFO - 2016-01-26 11:07:15 --> Form Validation Class Initialized
INFO - 2016-01-26 11:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\side_login_banner.php
INFO - 2016-01-26 11:07:15 --> Final output sent to browser
DEBUG - 2016-01-26 11:07:15 --> Total execution time: 1.1162
INFO - 2016-01-26 11:07:16 --> Config Class Initialized
INFO - 2016-01-26 11:07:16 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:07:16 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:07:16 --> Utf8 Class Initialized
INFO - 2016-01-26 11:07:16 --> URI Class Initialized
INFO - 2016-01-26 11:07:16 --> Router Class Initialized
INFO - 2016-01-26 11:07:16 --> Output Class Initialized
INFO - 2016-01-26 11:07:16 --> Security Class Initialized
DEBUG - 2016-01-26 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:07:16 --> Input Class Initialized
INFO - 2016-01-26 11:07:16 --> Language Class Initialized
INFO - 2016-01-26 11:07:16 --> Loader Class Initialized
INFO - 2016-01-26 11:07:16 --> Helper loaded: url_helper
INFO - 2016-01-26 11:07:16 --> Helper loaded: file_helper
INFO - 2016-01-26 11:07:16 --> Helper loaded: date_helper
INFO - 2016-01-26 11:07:16 --> Database Driver Class Initialized
INFO - 2016-01-26 11:07:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:07:17 --> Controller Class Initialized
INFO - 2016-01-26 11:07:17 --> Model Class Initialized
INFO - 2016-01-26 11:07:17 --> Model Class Initialized
INFO - 2016-01-26 11:07:17 --> Helper loaded: form_helper
INFO - 2016-01-26 11:07:17 --> Form Validation Class Initialized
INFO - 2016-01-26 11:07:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:07:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 11:07:17 --> Final output sent to browser
DEBUG - 2016-01-26 11:07:17 --> Total execution time: 1.0832
INFO - 2016-01-26 11:08:00 --> Config Class Initialized
INFO - 2016-01-26 11:08:00 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:08:00 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:08:00 --> Utf8 Class Initialized
INFO - 2016-01-26 11:08:00 --> URI Class Initialized
INFO - 2016-01-26 11:08:00 --> Router Class Initialized
INFO - 2016-01-26 11:08:00 --> Output Class Initialized
INFO - 2016-01-26 11:08:00 --> Security Class Initialized
DEBUG - 2016-01-26 11:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:08:00 --> Input Class Initialized
INFO - 2016-01-26 11:08:00 --> Language Class Initialized
INFO - 2016-01-26 11:08:00 --> Loader Class Initialized
INFO - 2016-01-26 11:08:00 --> Helper loaded: url_helper
INFO - 2016-01-26 11:08:00 --> Helper loaded: file_helper
INFO - 2016-01-26 11:08:00 --> Helper loaded: date_helper
INFO - 2016-01-26 11:08:00 --> Database Driver Class Initialized
INFO - 2016-01-26 11:08:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:08:01 --> Controller Class Initialized
INFO - 2016-01-26 11:08:01 --> Model Class Initialized
INFO - 2016-01-26 11:08:01 --> Model Class Initialized
INFO - 2016-01-26 11:08:01 --> Helper loaded: form_helper
INFO - 2016-01-26 11:08:01 --> Form Validation Class Initialized
INFO - 2016-01-26 11:08:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:08:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:08:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\side_login_banner.php
INFO - 2016-01-26 11:08:01 --> Final output sent to browser
DEBUG - 2016-01-26 11:08:01 --> Total execution time: 1.1103
INFO - 2016-01-26 11:16:32 --> Config Class Initialized
INFO - 2016-01-26 11:16:32 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:16:32 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:16:32 --> Utf8 Class Initialized
INFO - 2016-01-26 11:16:32 --> URI Class Initialized
INFO - 2016-01-26 11:16:32 --> Router Class Initialized
INFO - 2016-01-26 11:16:32 --> Output Class Initialized
INFO - 2016-01-26 11:16:32 --> Security Class Initialized
DEBUG - 2016-01-26 11:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:16:32 --> Input Class Initialized
INFO - 2016-01-26 11:16:32 --> Language Class Initialized
INFO - 2016-01-26 11:16:32 --> Loader Class Initialized
INFO - 2016-01-26 11:16:32 --> Helper loaded: url_helper
INFO - 2016-01-26 11:16:32 --> Helper loaded: file_helper
INFO - 2016-01-26 11:16:32 --> Helper loaded: date_helper
INFO - 2016-01-26 11:16:32 --> Database Driver Class Initialized
INFO - 2016-01-26 11:16:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:16:33 --> Controller Class Initialized
INFO - 2016-01-26 11:16:33 --> Model Class Initialized
INFO - 2016-01-26 11:16:33 --> Model Class Initialized
INFO - 2016-01-26 11:16:33 --> Helper loaded: form_helper
INFO - 2016-01-26 11:16:33 --> Form Validation Class Initialized
INFO - 2016-01-26 11:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:16:33 --> Final output sent to browser
DEBUG - 2016-01-26 11:16:33 --> Total execution time: 1.1083
INFO - 2016-01-26 11:16:34 --> Config Class Initialized
INFO - 2016-01-26 11:16:34 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:16:34 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:16:34 --> Utf8 Class Initialized
INFO - 2016-01-26 11:16:34 --> URI Class Initialized
INFO - 2016-01-26 11:16:34 --> Router Class Initialized
INFO - 2016-01-26 11:16:34 --> Output Class Initialized
INFO - 2016-01-26 11:16:34 --> Security Class Initialized
DEBUG - 2016-01-26 11:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:16:34 --> Input Class Initialized
INFO - 2016-01-26 11:16:34 --> Language Class Initialized
ERROR - 2016-01-26 11:16:34 --> 404 Page Not Found: Auth/jumbotron-narrow.css
INFO - 2016-01-26 11:19:03 --> Config Class Initialized
INFO - 2016-01-26 11:19:03 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:19:03 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:19:03 --> Utf8 Class Initialized
INFO - 2016-01-26 11:19:03 --> URI Class Initialized
INFO - 2016-01-26 11:19:03 --> Router Class Initialized
INFO - 2016-01-26 11:19:03 --> Output Class Initialized
INFO - 2016-01-26 11:19:03 --> Security Class Initialized
DEBUG - 2016-01-26 11:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:19:03 --> Input Class Initialized
INFO - 2016-01-26 11:19:03 --> Language Class Initialized
INFO - 2016-01-26 11:19:03 --> Loader Class Initialized
INFO - 2016-01-26 11:19:03 --> Helper loaded: url_helper
INFO - 2016-01-26 11:19:03 --> Helper loaded: file_helper
INFO - 2016-01-26 11:19:03 --> Helper loaded: date_helper
INFO - 2016-01-26 11:19:03 --> Database Driver Class Initialized
INFO - 2016-01-26 11:19:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:19:04 --> Controller Class Initialized
INFO - 2016-01-26 11:19:04 --> Model Class Initialized
INFO - 2016-01-26 11:19:04 --> Model Class Initialized
INFO - 2016-01-26 11:19:04 --> Helper loaded: form_helper
INFO - 2016-01-26 11:19:04 --> Form Validation Class Initialized
INFO - 2016-01-26 11:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:19:04 --> Final output sent to browser
DEBUG - 2016-01-26 11:19:04 --> Total execution time: 1.1167
INFO - 2016-01-26 11:19:05 --> Config Class Initialized
INFO - 2016-01-26 11:19:05 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:19:05 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:19:05 --> Utf8 Class Initialized
INFO - 2016-01-26 11:19:05 --> URI Class Initialized
INFO - 2016-01-26 11:19:05 --> Router Class Initialized
INFO - 2016-01-26 11:19:05 --> Output Class Initialized
INFO - 2016-01-26 11:19:05 --> Security Class Initialized
DEBUG - 2016-01-26 11:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:19:05 --> Input Class Initialized
INFO - 2016-01-26 11:19:05 --> Language Class Initialized
ERROR - 2016-01-26 11:19:05 --> 404 Page Not Found: Auth/jumbotron-narrow.css
INFO - 2016-01-26 11:19:07 --> Config Class Initialized
INFO - 2016-01-26 11:19:07 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:19:07 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:19:07 --> Utf8 Class Initialized
INFO - 2016-01-26 11:19:07 --> URI Class Initialized
INFO - 2016-01-26 11:19:07 --> Router Class Initialized
INFO - 2016-01-26 11:19:07 --> Output Class Initialized
INFO - 2016-01-26 11:19:07 --> Security Class Initialized
DEBUG - 2016-01-26 11:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:19:07 --> Input Class Initialized
INFO - 2016-01-26 11:19:07 --> Language Class Initialized
ERROR - 2016-01-26 11:19:07 --> 404 Page Not Found: Auth/jumbotron-narrow.css
INFO - 2016-01-26 11:19:13 --> Config Class Initialized
INFO - 2016-01-26 11:19:13 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:19:13 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:19:13 --> Utf8 Class Initialized
INFO - 2016-01-26 11:19:13 --> URI Class Initialized
INFO - 2016-01-26 11:19:13 --> Router Class Initialized
INFO - 2016-01-26 11:19:13 --> Output Class Initialized
INFO - 2016-01-26 11:19:13 --> Security Class Initialized
DEBUG - 2016-01-26 11:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:19:13 --> Input Class Initialized
INFO - 2016-01-26 11:19:13 --> Language Class Initialized
INFO - 2016-01-26 11:19:13 --> Loader Class Initialized
INFO - 2016-01-26 11:19:13 --> Helper loaded: url_helper
INFO - 2016-01-26 11:19:13 --> Helper loaded: file_helper
INFO - 2016-01-26 11:19:13 --> Helper loaded: date_helper
INFO - 2016-01-26 11:19:13 --> Database Driver Class Initialized
INFO - 2016-01-26 11:19:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:19:14 --> Controller Class Initialized
INFO - 2016-01-26 11:19:14 --> Model Class Initialized
INFO - 2016-01-26 11:19:14 --> Model Class Initialized
INFO - 2016-01-26 11:19:14 --> Helper loaded: form_helper
INFO - 2016-01-26 11:19:14 --> Form Validation Class Initialized
INFO - 2016-01-26 11:19:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:19:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:19:14 --> Final output sent to browser
DEBUG - 2016-01-26 11:19:14 --> Total execution time: 1.1294
INFO - 2016-01-26 11:19:15 --> Config Class Initialized
INFO - 2016-01-26 11:19:15 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:19:15 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:19:15 --> Utf8 Class Initialized
INFO - 2016-01-26 11:19:15 --> URI Class Initialized
INFO - 2016-01-26 11:19:15 --> Router Class Initialized
INFO - 2016-01-26 11:19:15 --> Output Class Initialized
INFO - 2016-01-26 11:19:15 --> Security Class Initialized
DEBUG - 2016-01-26 11:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:19:15 --> Input Class Initialized
INFO - 2016-01-26 11:19:15 --> Language Class Initialized
ERROR - 2016-01-26 11:19:15 --> 404 Page Not Found: Auth/jumbotron-narrow.css
INFO - 2016-01-26 11:21:15 --> Config Class Initialized
INFO - 2016-01-26 11:21:15 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:21:15 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:21:15 --> Utf8 Class Initialized
INFO - 2016-01-26 11:21:15 --> URI Class Initialized
INFO - 2016-01-26 11:21:15 --> Router Class Initialized
INFO - 2016-01-26 11:21:15 --> Output Class Initialized
INFO - 2016-01-26 11:21:15 --> Security Class Initialized
DEBUG - 2016-01-26 11:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:21:15 --> Input Class Initialized
INFO - 2016-01-26 11:21:15 --> Language Class Initialized
INFO - 2016-01-26 11:21:15 --> Loader Class Initialized
INFO - 2016-01-26 11:21:15 --> Helper loaded: url_helper
INFO - 2016-01-26 11:21:15 --> Helper loaded: file_helper
INFO - 2016-01-26 11:21:15 --> Helper loaded: date_helper
INFO - 2016-01-26 11:21:15 --> Database Driver Class Initialized
INFO - 2016-01-26 11:21:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:21:16 --> Controller Class Initialized
INFO - 2016-01-26 11:21:16 --> Model Class Initialized
INFO - 2016-01-26 11:21:16 --> Model Class Initialized
INFO - 2016-01-26 11:21:16 --> Helper loaded: form_helper
INFO - 2016-01-26 11:21:16 --> Form Validation Class Initialized
INFO - 2016-01-26 11:21:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:21:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:21:16 --> Final output sent to browser
DEBUG - 2016-01-26 11:21:16 --> Total execution time: 1.1287
INFO - 2016-01-26 11:21:17 --> Config Class Initialized
INFO - 2016-01-26 11:21:17 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:21:17 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:21:17 --> Utf8 Class Initialized
INFO - 2016-01-26 11:21:17 --> URI Class Initialized
INFO - 2016-01-26 11:21:17 --> Router Class Initialized
INFO - 2016-01-26 11:21:17 --> Output Class Initialized
INFO - 2016-01-26 11:21:17 --> Security Class Initialized
DEBUG - 2016-01-26 11:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:21:17 --> Input Class Initialized
INFO - 2016-01-26 11:21:17 --> Language Class Initialized
ERROR - 2016-01-26 11:21:17 --> 404 Page Not Found: Auth/jumbotron-narrow.css
INFO - 2016-01-26 11:22:23 --> Config Class Initialized
INFO - 2016-01-26 11:22:23 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:22:23 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:22:23 --> Utf8 Class Initialized
INFO - 2016-01-26 11:22:23 --> URI Class Initialized
INFO - 2016-01-26 11:22:23 --> Router Class Initialized
INFO - 2016-01-26 11:22:23 --> Output Class Initialized
INFO - 2016-01-26 11:22:23 --> Security Class Initialized
DEBUG - 2016-01-26 11:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:22:23 --> Input Class Initialized
INFO - 2016-01-26 11:22:23 --> Language Class Initialized
INFO - 2016-01-26 11:22:23 --> Loader Class Initialized
INFO - 2016-01-26 11:22:23 --> Helper loaded: url_helper
INFO - 2016-01-26 11:22:23 --> Helper loaded: file_helper
INFO - 2016-01-26 11:22:23 --> Helper loaded: date_helper
INFO - 2016-01-26 11:22:23 --> Database Driver Class Initialized
INFO - 2016-01-26 11:22:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:22:24 --> Controller Class Initialized
INFO - 2016-01-26 11:22:24 --> Model Class Initialized
INFO - 2016-01-26 11:22:24 --> Model Class Initialized
INFO - 2016-01-26 11:22:24 --> Helper loaded: form_helper
INFO - 2016-01-26 11:22:24 --> Form Validation Class Initialized
INFO - 2016-01-26 11:22:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:22:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:22:24 --> Final output sent to browser
DEBUG - 2016-01-26 11:22:24 --> Total execution time: 1.1226
INFO - 2016-01-26 11:22:24 --> Config Class Initialized
INFO - 2016-01-26 11:22:24 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:22:24 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:22:24 --> Utf8 Class Initialized
INFO - 2016-01-26 11:22:24 --> URI Class Initialized
INFO - 2016-01-26 11:22:24 --> Router Class Initialized
INFO - 2016-01-26 11:22:24 --> Output Class Initialized
INFO - 2016-01-26 11:22:24 --> Security Class Initialized
DEBUG - 2016-01-26 11:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:22:24 --> Input Class Initialized
INFO - 2016-01-26 11:22:24 --> Language Class Initialized
ERROR - 2016-01-26 11:22:24 --> 404 Page Not Found: Auth/jumbotron-narrow.css
INFO - 2016-01-26 11:23:28 --> Config Class Initialized
INFO - 2016-01-26 11:23:28 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:23:28 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:23:28 --> Utf8 Class Initialized
INFO - 2016-01-26 11:23:28 --> URI Class Initialized
INFO - 2016-01-26 11:23:28 --> Router Class Initialized
INFO - 2016-01-26 11:23:28 --> Output Class Initialized
INFO - 2016-01-26 11:23:28 --> Security Class Initialized
DEBUG - 2016-01-26 11:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:23:28 --> Input Class Initialized
INFO - 2016-01-26 11:23:28 --> Language Class Initialized
INFO - 2016-01-26 11:23:28 --> Loader Class Initialized
INFO - 2016-01-26 11:23:28 --> Helper loaded: url_helper
INFO - 2016-01-26 11:23:28 --> Helper loaded: file_helper
INFO - 2016-01-26 11:23:28 --> Helper loaded: date_helper
INFO - 2016-01-26 11:23:28 --> Database Driver Class Initialized
INFO - 2016-01-26 11:23:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:23:29 --> Controller Class Initialized
INFO - 2016-01-26 11:23:29 --> Model Class Initialized
INFO - 2016-01-26 11:23:29 --> Model Class Initialized
INFO - 2016-01-26 11:23:29 --> Helper loaded: form_helper
INFO - 2016-01-26 11:23:29 --> Form Validation Class Initialized
INFO - 2016-01-26 11:23:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:23:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:23:29 --> Final output sent to browser
DEBUG - 2016-01-26 11:23:29 --> Total execution time: 1.1281
INFO - 2016-01-26 11:24:04 --> Config Class Initialized
INFO - 2016-01-26 11:24:04 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:24:04 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:24:04 --> Utf8 Class Initialized
INFO - 2016-01-26 11:24:04 --> URI Class Initialized
INFO - 2016-01-26 11:24:04 --> Router Class Initialized
INFO - 2016-01-26 11:24:04 --> Output Class Initialized
INFO - 2016-01-26 11:24:04 --> Security Class Initialized
DEBUG - 2016-01-26 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:24:04 --> Input Class Initialized
INFO - 2016-01-26 11:24:04 --> Language Class Initialized
INFO - 2016-01-26 11:24:04 --> Loader Class Initialized
INFO - 2016-01-26 11:24:04 --> Helper loaded: url_helper
INFO - 2016-01-26 11:24:04 --> Helper loaded: file_helper
INFO - 2016-01-26 11:24:04 --> Helper loaded: date_helper
INFO - 2016-01-26 11:24:04 --> Database Driver Class Initialized
INFO - 2016-01-26 11:24:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:24:05 --> Controller Class Initialized
INFO - 2016-01-26 11:24:05 --> Model Class Initialized
INFO - 2016-01-26 11:24:05 --> Model Class Initialized
INFO - 2016-01-26 11:24:05 --> Helper loaded: form_helper
INFO - 2016-01-26 11:24:05 --> Form Validation Class Initialized
INFO - 2016-01-26 11:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:24:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:24:05 --> Final output sent to browser
DEBUG - 2016-01-26 11:24:05 --> Total execution time: 1.1293
INFO - 2016-01-26 11:24:15 --> Config Class Initialized
INFO - 2016-01-26 11:24:15 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:24:15 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:24:15 --> Utf8 Class Initialized
INFO - 2016-01-26 11:24:15 --> URI Class Initialized
INFO - 2016-01-26 11:24:15 --> Router Class Initialized
INFO - 2016-01-26 11:24:15 --> Output Class Initialized
INFO - 2016-01-26 11:24:15 --> Security Class Initialized
DEBUG - 2016-01-26 11:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:24:15 --> Input Class Initialized
INFO - 2016-01-26 11:24:15 --> Language Class Initialized
INFO - 2016-01-26 11:24:15 --> Loader Class Initialized
INFO - 2016-01-26 11:24:15 --> Helper loaded: url_helper
INFO - 2016-01-26 11:24:15 --> Helper loaded: file_helper
INFO - 2016-01-26 11:24:15 --> Helper loaded: date_helper
INFO - 2016-01-26 11:24:15 --> Database Driver Class Initialized
INFO - 2016-01-26 11:24:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:24:16 --> Controller Class Initialized
INFO - 2016-01-26 11:24:16 --> Model Class Initialized
INFO - 2016-01-26 11:24:16 --> Model Class Initialized
INFO - 2016-01-26 11:24:16 --> Helper loaded: form_helper
INFO - 2016-01-26 11:24:16 --> Form Validation Class Initialized
INFO - 2016-01-26 11:24:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:24:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:24:16 --> Final output sent to browser
DEBUG - 2016-01-26 11:24:16 --> Total execution time: 1.1847
INFO - 2016-01-26 11:27:20 --> Config Class Initialized
INFO - 2016-01-26 11:27:20 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:27:20 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:27:20 --> Utf8 Class Initialized
INFO - 2016-01-26 11:27:20 --> URI Class Initialized
INFO - 2016-01-26 11:27:20 --> Router Class Initialized
INFO - 2016-01-26 11:27:20 --> Output Class Initialized
INFO - 2016-01-26 11:27:20 --> Security Class Initialized
DEBUG - 2016-01-26 11:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:27:20 --> Input Class Initialized
INFO - 2016-01-26 11:27:20 --> Language Class Initialized
INFO - 2016-01-26 11:27:20 --> Loader Class Initialized
INFO - 2016-01-26 11:27:20 --> Helper loaded: url_helper
INFO - 2016-01-26 11:27:20 --> Helper loaded: file_helper
INFO - 2016-01-26 11:27:20 --> Helper loaded: date_helper
INFO - 2016-01-26 11:27:20 --> Database Driver Class Initialized
INFO - 2016-01-26 11:27:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:27:21 --> Controller Class Initialized
INFO - 2016-01-26 11:27:21 --> Model Class Initialized
INFO - 2016-01-26 11:27:21 --> Model Class Initialized
INFO - 2016-01-26 11:27:21 --> Helper loaded: form_helper
INFO - 2016-01-26 11:27:21 --> Form Validation Class Initialized
INFO - 2016-01-26 11:27:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:27:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:27:21 --> Final output sent to browser
DEBUG - 2016-01-26 11:27:21 --> Total execution time: 1.0967
INFO - 2016-01-26 11:28:00 --> Config Class Initialized
INFO - 2016-01-26 11:28:00 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:28:00 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:28:00 --> Utf8 Class Initialized
INFO - 2016-01-26 11:28:00 --> URI Class Initialized
INFO - 2016-01-26 11:28:00 --> Router Class Initialized
INFO - 2016-01-26 11:28:00 --> Output Class Initialized
INFO - 2016-01-26 11:28:00 --> Security Class Initialized
DEBUG - 2016-01-26 11:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:28:00 --> Input Class Initialized
INFO - 2016-01-26 11:28:00 --> Language Class Initialized
INFO - 2016-01-26 11:28:00 --> Loader Class Initialized
INFO - 2016-01-26 11:28:00 --> Helper loaded: url_helper
INFO - 2016-01-26 11:28:00 --> Helper loaded: file_helper
INFO - 2016-01-26 11:28:00 --> Helper loaded: date_helper
INFO - 2016-01-26 11:28:00 --> Database Driver Class Initialized
INFO - 2016-01-26 11:28:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:28:01 --> Controller Class Initialized
INFO - 2016-01-26 11:28:01 --> Model Class Initialized
INFO - 2016-01-26 11:28:01 --> Model Class Initialized
INFO - 2016-01-26 11:28:01 --> Helper loaded: form_helper
INFO - 2016-01-26 11:28:01 --> Form Validation Class Initialized
INFO - 2016-01-26 11:28:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:28:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:28:01 --> Final output sent to browser
DEBUG - 2016-01-26 11:28:01 --> Total execution time: 1.1165
INFO - 2016-01-26 11:28:32 --> Config Class Initialized
INFO - 2016-01-26 11:28:32 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:28:32 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:28:32 --> Utf8 Class Initialized
INFO - 2016-01-26 11:28:32 --> URI Class Initialized
INFO - 2016-01-26 11:28:32 --> Router Class Initialized
INFO - 2016-01-26 11:28:32 --> Output Class Initialized
INFO - 2016-01-26 11:28:32 --> Security Class Initialized
DEBUG - 2016-01-26 11:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:28:32 --> Input Class Initialized
INFO - 2016-01-26 11:28:32 --> Language Class Initialized
INFO - 2016-01-26 11:28:32 --> Loader Class Initialized
INFO - 2016-01-26 11:28:32 --> Helper loaded: url_helper
INFO - 2016-01-26 11:28:32 --> Helper loaded: file_helper
INFO - 2016-01-26 11:28:32 --> Helper loaded: date_helper
INFO - 2016-01-26 11:28:32 --> Database Driver Class Initialized
INFO - 2016-01-26 11:28:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:28:33 --> Controller Class Initialized
INFO - 2016-01-26 11:28:33 --> Model Class Initialized
INFO - 2016-01-26 11:28:33 --> Model Class Initialized
INFO - 2016-01-26 11:28:33 --> Helper loaded: form_helper
INFO - 2016-01-26 11:28:33 --> Form Validation Class Initialized
INFO - 2016-01-26 11:28:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:28:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:28:33 --> Final output sent to browser
DEBUG - 2016-01-26 11:28:33 --> Total execution time: 1.0773
INFO - 2016-01-26 11:29:17 --> Config Class Initialized
INFO - 2016-01-26 11:29:17 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:29:17 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:29:17 --> Utf8 Class Initialized
INFO - 2016-01-26 11:29:17 --> URI Class Initialized
INFO - 2016-01-26 11:29:17 --> Router Class Initialized
INFO - 2016-01-26 11:29:17 --> Output Class Initialized
INFO - 2016-01-26 11:29:17 --> Security Class Initialized
DEBUG - 2016-01-26 11:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:29:17 --> Input Class Initialized
INFO - 2016-01-26 11:29:17 --> Language Class Initialized
INFO - 2016-01-26 11:29:17 --> Loader Class Initialized
INFO - 2016-01-26 11:29:17 --> Helper loaded: url_helper
INFO - 2016-01-26 11:29:17 --> Helper loaded: file_helper
INFO - 2016-01-26 11:29:17 --> Helper loaded: date_helper
INFO - 2016-01-26 11:29:17 --> Database Driver Class Initialized
INFO - 2016-01-26 11:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:29:18 --> Controller Class Initialized
INFO - 2016-01-26 11:29:18 --> Model Class Initialized
INFO - 2016-01-26 11:29:18 --> Model Class Initialized
INFO - 2016-01-26 11:29:18 --> Helper loaded: form_helper
INFO - 2016-01-26 11:29:18 --> Form Validation Class Initialized
INFO - 2016-01-26 11:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:29:18 --> Final output sent to browser
DEBUG - 2016-01-26 11:29:18 --> Total execution time: 1.1086
INFO - 2016-01-26 11:30:22 --> Config Class Initialized
INFO - 2016-01-26 11:30:22 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:30:22 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:30:22 --> Utf8 Class Initialized
INFO - 2016-01-26 11:30:22 --> URI Class Initialized
INFO - 2016-01-26 11:30:22 --> Router Class Initialized
INFO - 2016-01-26 11:30:22 --> Output Class Initialized
INFO - 2016-01-26 11:30:22 --> Security Class Initialized
DEBUG - 2016-01-26 11:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:30:22 --> Input Class Initialized
INFO - 2016-01-26 11:30:22 --> Language Class Initialized
INFO - 2016-01-26 11:30:22 --> Loader Class Initialized
INFO - 2016-01-26 11:30:22 --> Helper loaded: url_helper
INFO - 2016-01-26 11:30:22 --> Helper loaded: file_helper
INFO - 2016-01-26 11:30:22 --> Helper loaded: date_helper
INFO - 2016-01-26 11:30:22 --> Database Driver Class Initialized
INFO - 2016-01-26 11:30:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:30:23 --> Controller Class Initialized
INFO - 2016-01-26 11:30:23 --> Model Class Initialized
INFO - 2016-01-26 11:30:23 --> Model Class Initialized
INFO - 2016-01-26 11:30:23 --> Helper loaded: form_helper
INFO - 2016-01-26 11:30:23 --> Form Validation Class Initialized
INFO - 2016-01-26 11:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:30:23 --> Final output sent to browser
DEBUG - 2016-01-26 11:30:23 --> Total execution time: 1.0990
INFO - 2016-01-26 11:33:42 --> Config Class Initialized
INFO - 2016-01-26 11:33:42 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:33:42 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:33:42 --> Utf8 Class Initialized
INFO - 2016-01-26 11:33:42 --> URI Class Initialized
INFO - 2016-01-26 11:33:42 --> Router Class Initialized
INFO - 2016-01-26 11:33:42 --> Output Class Initialized
INFO - 2016-01-26 11:33:42 --> Security Class Initialized
DEBUG - 2016-01-26 11:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:33:42 --> Input Class Initialized
INFO - 2016-01-26 11:33:42 --> Language Class Initialized
INFO - 2016-01-26 11:33:42 --> Loader Class Initialized
INFO - 2016-01-26 11:33:42 --> Helper loaded: url_helper
INFO - 2016-01-26 11:33:42 --> Helper loaded: file_helper
INFO - 2016-01-26 11:33:42 --> Helper loaded: date_helper
INFO - 2016-01-26 11:33:42 --> Database Driver Class Initialized
INFO - 2016-01-26 11:33:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:33:43 --> Controller Class Initialized
INFO - 2016-01-26 11:33:43 --> Model Class Initialized
INFO - 2016-01-26 11:33:43 --> Model Class Initialized
INFO - 2016-01-26 11:33:43 --> Helper loaded: form_helper
INFO - 2016-01-26 11:33:43 --> Form Validation Class Initialized
INFO - 2016-01-26 11:33:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:33:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:33:43 --> Final output sent to browser
DEBUG - 2016-01-26 11:33:43 --> Total execution time: 1.0969
INFO - 2016-01-26 11:34:15 --> Config Class Initialized
INFO - 2016-01-26 11:34:15 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:34:15 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:34:15 --> Utf8 Class Initialized
INFO - 2016-01-26 11:34:15 --> URI Class Initialized
INFO - 2016-01-26 11:34:15 --> Router Class Initialized
INFO - 2016-01-26 11:34:15 --> Output Class Initialized
INFO - 2016-01-26 11:34:15 --> Security Class Initialized
DEBUG - 2016-01-26 11:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:34:15 --> Input Class Initialized
INFO - 2016-01-26 11:34:15 --> Language Class Initialized
INFO - 2016-01-26 11:34:15 --> Loader Class Initialized
INFO - 2016-01-26 11:34:15 --> Helper loaded: url_helper
INFO - 2016-01-26 11:34:15 --> Helper loaded: file_helper
INFO - 2016-01-26 11:34:15 --> Helper loaded: date_helper
INFO - 2016-01-26 11:34:15 --> Database Driver Class Initialized
INFO - 2016-01-26 11:34:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:34:16 --> Controller Class Initialized
INFO - 2016-01-26 11:34:16 --> Model Class Initialized
INFO - 2016-01-26 11:34:16 --> Model Class Initialized
INFO - 2016-01-26 11:34:16 --> Helper loaded: form_helper
INFO - 2016-01-26 11:34:16 --> Form Validation Class Initialized
INFO - 2016-01-26 11:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:34:16 --> Final output sent to browser
DEBUG - 2016-01-26 11:34:16 --> Total execution time: 1.1076
INFO - 2016-01-26 11:34:35 --> Config Class Initialized
INFO - 2016-01-26 11:34:35 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:34:35 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:34:35 --> Utf8 Class Initialized
INFO - 2016-01-26 11:34:35 --> URI Class Initialized
INFO - 2016-01-26 11:34:35 --> Router Class Initialized
INFO - 2016-01-26 11:34:35 --> Output Class Initialized
INFO - 2016-01-26 11:34:35 --> Security Class Initialized
DEBUG - 2016-01-26 11:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:34:35 --> Input Class Initialized
INFO - 2016-01-26 11:34:35 --> Language Class Initialized
INFO - 2016-01-26 11:34:35 --> Loader Class Initialized
INFO - 2016-01-26 11:34:35 --> Helper loaded: url_helper
INFO - 2016-01-26 11:34:35 --> Helper loaded: file_helper
INFO - 2016-01-26 11:34:35 --> Helper loaded: date_helper
INFO - 2016-01-26 11:34:35 --> Database Driver Class Initialized
INFO - 2016-01-26 11:34:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:34:36 --> Controller Class Initialized
INFO - 2016-01-26 11:34:36 --> Model Class Initialized
INFO - 2016-01-26 11:34:36 --> Model Class Initialized
INFO - 2016-01-26 11:34:36 --> Helper loaded: form_helper
INFO - 2016-01-26 11:34:36 --> Form Validation Class Initialized
INFO - 2016-01-26 11:34:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:34:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:34:36 --> Final output sent to browser
DEBUG - 2016-01-26 11:34:36 --> Total execution time: 1.1139
INFO - 2016-01-26 11:36:24 --> Config Class Initialized
INFO - 2016-01-26 11:36:24 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:36:24 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:36:24 --> Utf8 Class Initialized
INFO - 2016-01-26 11:36:24 --> URI Class Initialized
DEBUG - 2016-01-26 11:36:24 --> No URI present. Default controller set.
INFO - 2016-01-26 11:36:24 --> Router Class Initialized
INFO - 2016-01-26 11:36:24 --> Output Class Initialized
INFO - 2016-01-26 11:36:24 --> Security Class Initialized
DEBUG - 2016-01-26 11:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:36:24 --> Input Class Initialized
INFO - 2016-01-26 11:36:24 --> Language Class Initialized
INFO - 2016-01-26 11:36:24 --> Loader Class Initialized
INFO - 2016-01-26 11:36:24 --> Helper loaded: url_helper
INFO - 2016-01-26 11:36:24 --> Helper loaded: file_helper
INFO - 2016-01-26 11:36:24 --> Helper loaded: date_helper
INFO - 2016-01-26 11:36:24 --> Database Driver Class Initialized
INFO - 2016-01-26 11:36:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:36:25 --> Controller Class Initialized
INFO - 2016-01-26 11:36:25 --> Model Class Initialized
INFO - 2016-01-26 11:36:25 --> Model Class Initialized
INFO - 2016-01-26 11:36:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 11:36:25 --> Pagination Class Initialized
INFO - 2016-01-26 11:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:36:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 11:36:25 --> Final output sent to browser
DEBUG - 2016-01-26 11:36:25 --> Total execution time: 1.1133
INFO - 2016-01-26 11:38:21 --> Config Class Initialized
INFO - 2016-01-26 11:38:21 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:38:21 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:38:21 --> Utf8 Class Initialized
INFO - 2016-01-26 11:38:21 --> URI Class Initialized
INFO - 2016-01-26 11:38:21 --> Router Class Initialized
INFO - 2016-01-26 11:38:21 --> Output Class Initialized
INFO - 2016-01-26 11:38:21 --> Security Class Initialized
DEBUG - 2016-01-26 11:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:38:21 --> Input Class Initialized
INFO - 2016-01-26 11:38:21 --> Language Class Initialized
INFO - 2016-01-26 11:38:21 --> Loader Class Initialized
INFO - 2016-01-26 11:38:21 --> Helper loaded: url_helper
INFO - 2016-01-26 11:38:21 --> Helper loaded: file_helper
INFO - 2016-01-26 11:38:21 --> Helper loaded: date_helper
INFO - 2016-01-26 11:38:21 --> Database Driver Class Initialized
INFO - 2016-01-26 11:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:38:22 --> Controller Class Initialized
INFO - 2016-01-26 11:38:22 --> Model Class Initialized
INFO - 2016-01-26 11:38:22 --> Model Class Initialized
INFO - 2016-01-26 11:38:22 --> Helper loaded: form_helper
INFO - 2016-01-26 11:38:22 --> Form Validation Class Initialized
INFO - 2016-01-26 11:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:38:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 11:38:22 --> Final output sent to browser
DEBUG - 2016-01-26 11:38:22 --> Total execution time: 1.0973
INFO - 2016-01-26 11:38:26 --> Config Class Initialized
INFO - 2016-01-26 11:38:26 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:38:26 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:38:26 --> Utf8 Class Initialized
INFO - 2016-01-26 11:38:26 --> URI Class Initialized
INFO - 2016-01-26 11:38:26 --> Router Class Initialized
INFO - 2016-01-26 11:38:26 --> Output Class Initialized
INFO - 2016-01-26 11:38:26 --> Security Class Initialized
DEBUG - 2016-01-26 11:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:38:26 --> Input Class Initialized
INFO - 2016-01-26 11:38:26 --> Language Class Initialized
INFO - 2016-01-26 11:38:26 --> Loader Class Initialized
INFO - 2016-01-26 11:38:26 --> Helper loaded: url_helper
INFO - 2016-01-26 11:38:26 --> Helper loaded: file_helper
INFO - 2016-01-26 11:38:26 --> Helper loaded: date_helper
INFO - 2016-01-26 11:38:26 --> Database Driver Class Initialized
INFO - 2016-01-26 11:38:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:38:27 --> Controller Class Initialized
INFO - 2016-01-26 11:38:27 --> Model Class Initialized
INFO - 2016-01-26 11:38:27 --> Model Class Initialized
INFO - 2016-01-26 11:38:27 --> Helper loaded: form_helper
INFO - 2016-01-26 11:38:27 --> Form Validation Class Initialized
INFO - 2016-01-26 11:38:27 --> Config Class Initialized
INFO - 2016-01-26 11:38:27 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:38:27 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:38:27 --> Utf8 Class Initialized
INFO - 2016-01-26 11:38:27 --> URI Class Initialized
INFO - 2016-01-26 11:38:27 --> Router Class Initialized
INFO - 2016-01-26 11:38:27 --> Output Class Initialized
INFO - 2016-01-26 11:38:27 --> Security Class Initialized
DEBUG - 2016-01-26 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:38:27 --> Input Class Initialized
INFO - 2016-01-26 11:38:27 --> Language Class Initialized
INFO - 2016-01-26 11:38:27 --> Loader Class Initialized
INFO - 2016-01-26 11:38:27 --> Helper loaded: url_helper
INFO - 2016-01-26 11:38:27 --> Helper loaded: file_helper
INFO - 2016-01-26 11:38:27 --> Helper loaded: date_helper
INFO - 2016-01-26 11:38:27 --> Database Driver Class Initialized
INFO - 2016-01-26 11:38:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:38:28 --> Controller Class Initialized
INFO - 2016-01-26 11:38:28 --> Model Class Initialized
INFO - 2016-01-26 11:38:28 --> Model Class Initialized
INFO - 2016-01-26 11:38:28 --> Helper loaded: form_helper
INFO - 2016-01-26 11:38:28 --> Form Validation Class Initialized
INFO - 2016-01-26 11:38:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 11:38:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:38:28 --> Final output sent to browser
DEBUG - 2016-01-26 11:38:28 --> Total execution time: 1.0952
INFO - 2016-01-26 11:38:55 --> Config Class Initialized
INFO - 2016-01-26 11:38:55 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:38:55 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:38:55 --> Utf8 Class Initialized
INFO - 2016-01-26 11:38:55 --> URI Class Initialized
INFO - 2016-01-26 11:38:55 --> Router Class Initialized
INFO - 2016-01-26 11:38:55 --> Output Class Initialized
INFO - 2016-01-26 11:38:55 --> Security Class Initialized
DEBUG - 2016-01-26 11:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:38:55 --> Input Class Initialized
INFO - 2016-01-26 11:38:55 --> Language Class Initialized
INFO - 2016-01-26 11:38:55 --> Loader Class Initialized
INFO - 2016-01-26 11:38:55 --> Helper loaded: url_helper
INFO - 2016-01-26 11:38:55 --> Helper loaded: file_helper
INFO - 2016-01-26 11:38:55 --> Helper loaded: date_helper
INFO - 2016-01-26 11:38:55 --> Database Driver Class Initialized
INFO - 2016-01-26 11:38:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:38:56 --> Controller Class Initialized
INFO - 2016-01-26 11:38:56 --> Model Class Initialized
INFO - 2016-01-26 11:38:56 --> Model Class Initialized
INFO - 2016-01-26 11:38:56 --> Helper loaded: form_helper
INFO - 2016-01-26 11:38:56 --> Form Validation Class Initialized
INFO - 2016-01-26 11:38:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:38:56 --> Final output sent to browser
DEBUG - 2016-01-26 11:38:56 --> Total execution time: 1.1112
INFO - 2016-01-26 11:40:01 --> Config Class Initialized
INFO - 2016-01-26 11:40:01 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:40:01 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:40:01 --> Utf8 Class Initialized
INFO - 2016-01-26 11:40:01 --> URI Class Initialized
INFO - 2016-01-26 11:40:01 --> Router Class Initialized
INFO - 2016-01-26 11:40:01 --> Output Class Initialized
INFO - 2016-01-26 11:40:01 --> Security Class Initialized
DEBUG - 2016-01-26 11:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:40:01 --> Input Class Initialized
INFO - 2016-01-26 11:40:01 --> Language Class Initialized
INFO - 2016-01-26 11:40:01 --> Loader Class Initialized
INFO - 2016-01-26 11:40:01 --> Helper loaded: url_helper
INFO - 2016-01-26 11:40:01 --> Helper loaded: file_helper
INFO - 2016-01-26 11:40:01 --> Helper loaded: date_helper
INFO - 2016-01-26 11:40:01 --> Database Driver Class Initialized
INFO - 2016-01-26 11:40:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:40:02 --> Controller Class Initialized
INFO - 2016-01-26 11:40:02 --> Model Class Initialized
INFO - 2016-01-26 11:40:02 --> Model Class Initialized
INFO - 2016-01-26 11:40:02 --> Helper loaded: form_helper
INFO - 2016-01-26 11:40:02 --> Form Validation Class Initialized
INFO - 2016-01-26 11:40:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:40:02 --> Final output sent to browser
DEBUG - 2016-01-26 11:40:02 --> Total execution time: 1.1035
INFO - 2016-01-26 11:41:38 --> Config Class Initialized
INFO - 2016-01-26 11:41:38 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:41:38 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:41:38 --> Utf8 Class Initialized
INFO - 2016-01-26 11:41:38 --> URI Class Initialized
INFO - 2016-01-26 11:41:38 --> Router Class Initialized
INFO - 2016-01-26 11:41:38 --> Output Class Initialized
INFO - 2016-01-26 11:41:38 --> Security Class Initialized
DEBUG - 2016-01-26 11:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:41:38 --> Input Class Initialized
INFO - 2016-01-26 11:41:38 --> Language Class Initialized
INFO - 2016-01-26 11:41:38 --> Loader Class Initialized
INFO - 2016-01-26 11:41:38 --> Helper loaded: url_helper
INFO - 2016-01-26 11:41:38 --> Helper loaded: file_helper
INFO - 2016-01-26 11:41:38 --> Helper loaded: date_helper
INFO - 2016-01-26 11:41:38 --> Database Driver Class Initialized
INFO - 2016-01-26 11:41:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:41:39 --> Controller Class Initialized
INFO - 2016-01-26 11:41:39 --> Model Class Initialized
INFO - 2016-01-26 11:41:39 --> Model Class Initialized
INFO - 2016-01-26 11:41:39 --> Helper loaded: form_helper
INFO - 2016-01-26 11:41:39 --> Form Validation Class Initialized
INFO - 2016-01-26 11:41:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:41:39 --> Final output sent to browser
DEBUG - 2016-01-26 11:41:39 --> Total execution time: 1.1038
INFO - 2016-01-26 11:41:54 --> Config Class Initialized
INFO - 2016-01-26 11:41:54 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:41:54 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:41:54 --> Utf8 Class Initialized
INFO - 2016-01-26 11:41:54 --> URI Class Initialized
INFO - 2016-01-26 11:41:54 --> Router Class Initialized
INFO - 2016-01-26 11:41:54 --> Output Class Initialized
INFO - 2016-01-26 11:41:54 --> Security Class Initialized
DEBUG - 2016-01-26 11:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:41:54 --> Input Class Initialized
INFO - 2016-01-26 11:41:54 --> Language Class Initialized
INFO - 2016-01-26 11:41:54 --> Loader Class Initialized
INFO - 2016-01-26 11:41:54 --> Helper loaded: url_helper
INFO - 2016-01-26 11:41:54 --> Helper loaded: file_helper
INFO - 2016-01-26 11:41:54 --> Helper loaded: date_helper
INFO - 2016-01-26 11:41:54 --> Database Driver Class Initialized
INFO - 2016-01-26 11:41:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:41:55 --> Controller Class Initialized
INFO - 2016-01-26 11:41:55 --> Model Class Initialized
INFO - 2016-01-26 11:41:55 --> Model Class Initialized
INFO - 2016-01-26 11:41:55 --> Helper loaded: form_helper
INFO - 2016-01-26 11:41:55 --> Form Validation Class Initialized
INFO - 2016-01-26 11:41:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:41:55 --> Final output sent to browser
DEBUG - 2016-01-26 11:41:55 --> Total execution time: 1.0988
INFO - 2016-01-26 11:42:58 --> Config Class Initialized
INFO - 2016-01-26 11:42:58 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:42:58 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:42:58 --> Utf8 Class Initialized
INFO - 2016-01-26 11:42:58 --> URI Class Initialized
INFO - 2016-01-26 11:42:58 --> Router Class Initialized
INFO - 2016-01-26 11:42:58 --> Output Class Initialized
INFO - 2016-01-26 11:42:58 --> Security Class Initialized
DEBUG - 2016-01-26 11:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:42:58 --> Input Class Initialized
INFO - 2016-01-26 11:42:58 --> Language Class Initialized
INFO - 2016-01-26 11:42:58 --> Loader Class Initialized
INFO - 2016-01-26 11:42:58 --> Helper loaded: url_helper
INFO - 2016-01-26 11:42:58 --> Helper loaded: file_helper
INFO - 2016-01-26 11:42:58 --> Helper loaded: date_helper
INFO - 2016-01-26 11:42:58 --> Database Driver Class Initialized
INFO - 2016-01-26 11:42:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:42:59 --> Controller Class Initialized
INFO - 2016-01-26 11:42:59 --> Model Class Initialized
INFO - 2016-01-26 11:42:59 --> Model Class Initialized
INFO - 2016-01-26 11:42:59 --> Helper loaded: form_helper
INFO - 2016-01-26 11:42:59 --> Form Validation Class Initialized
INFO - 2016-01-26 11:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:42:59 --> Final output sent to browser
DEBUG - 2016-01-26 11:42:59 --> Total execution time: 1.1092
INFO - 2016-01-26 11:44:31 --> Config Class Initialized
INFO - 2016-01-26 11:44:31 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:44:31 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:44:31 --> Utf8 Class Initialized
INFO - 2016-01-26 11:44:31 --> URI Class Initialized
INFO - 2016-01-26 11:44:31 --> Router Class Initialized
INFO - 2016-01-26 11:44:31 --> Output Class Initialized
INFO - 2016-01-26 11:44:31 --> Security Class Initialized
DEBUG - 2016-01-26 11:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:44:31 --> Input Class Initialized
INFO - 2016-01-26 11:44:31 --> Language Class Initialized
INFO - 2016-01-26 11:44:31 --> Loader Class Initialized
INFO - 2016-01-26 11:44:31 --> Helper loaded: url_helper
INFO - 2016-01-26 11:44:31 --> Helper loaded: file_helper
INFO - 2016-01-26 11:44:31 --> Helper loaded: date_helper
INFO - 2016-01-26 11:44:31 --> Database Driver Class Initialized
INFO - 2016-01-26 11:44:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:44:32 --> Controller Class Initialized
INFO - 2016-01-26 11:44:32 --> Model Class Initialized
INFO - 2016-01-26 11:44:32 --> Model Class Initialized
INFO - 2016-01-26 11:44:32 --> Helper loaded: form_helper
INFO - 2016-01-26 11:44:32 --> Form Validation Class Initialized
INFO - 2016-01-26 11:44:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:44:32 --> Final output sent to browser
DEBUG - 2016-01-26 11:44:32 --> Total execution time: 1.1038
INFO - 2016-01-26 11:45:35 --> Config Class Initialized
INFO - 2016-01-26 11:45:35 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:45:35 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:45:35 --> Utf8 Class Initialized
INFO - 2016-01-26 11:45:35 --> URI Class Initialized
INFO - 2016-01-26 11:45:35 --> Router Class Initialized
INFO - 2016-01-26 11:45:35 --> Output Class Initialized
INFO - 2016-01-26 11:45:35 --> Security Class Initialized
DEBUG - 2016-01-26 11:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:45:35 --> Input Class Initialized
INFO - 2016-01-26 11:45:35 --> Language Class Initialized
INFO - 2016-01-26 11:45:35 --> Loader Class Initialized
INFO - 2016-01-26 11:45:35 --> Helper loaded: url_helper
INFO - 2016-01-26 11:45:35 --> Helper loaded: file_helper
INFO - 2016-01-26 11:45:35 --> Helper loaded: date_helper
INFO - 2016-01-26 11:45:35 --> Database Driver Class Initialized
INFO - 2016-01-26 11:45:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:45:36 --> Controller Class Initialized
INFO - 2016-01-26 11:45:36 --> Model Class Initialized
INFO - 2016-01-26 11:45:36 --> Model Class Initialized
INFO - 2016-01-26 11:45:36 --> Helper loaded: form_helper
INFO - 2016-01-26 11:45:36 --> Form Validation Class Initialized
INFO - 2016-01-26 11:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:45:36 --> Final output sent to browser
DEBUG - 2016-01-26 11:45:36 --> Total execution time: 1.1091
INFO - 2016-01-26 11:46:36 --> Config Class Initialized
INFO - 2016-01-26 11:46:36 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:46:36 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:46:36 --> Utf8 Class Initialized
INFO - 2016-01-26 11:46:36 --> URI Class Initialized
INFO - 2016-01-26 11:46:36 --> Router Class Initialized
INFO - 2016-01-26 11:46:36 --> Output Class Initialized
INFO - 2016-01-26 11:46:36 --> Security Class Initialized
DEBUG - 2016-01-26 11:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:46:36 --> Input Class Initialized
INFO - 2016-01-26 11:46:36 --> Language Class Initialized
INFO - 2016-01-26 11:46:36 --> Loader Class Initialized
INFO - 2016-01-26 11:46:36 --> Helper loaded: url_helper
INFO - 2016-01-26 11:46:36 --> Helper loaded: file_helper
INFO - 2016-01-26 11:46:36 --> Helper loaded: date_helper
INFO - 2016-01-26 11:46:36 --> Database Driver Class Initialized
INFO - 2016-01-26 11:46:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:46:37 --> Controller Class Initialized
INFO - 2016-01-26 11:46:37 --> Model Class Initialized
INFO - 2016-01-26 11:46:37 --> Model Class Initialized
INFO - 2016-01-26 11:46:37 --> Helper loaded: form_helper
INFO - 2016-01-26 11:46:37 --> Form Validation Class Initialized
INFO - 2016-01-26 11:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:46:37 --> Final output sent to browser
DEBUG - 2016-01-26 11:46:37 --> Total execution time: 1.1060
INFO - 2016-01-26 11:46:47 --> Config Class Initialized
INFO - 2016-01-26 11:46:47 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:46:47 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:46:47 --> Utf8 Class Initialized
INFO - 2016-01-26 11:46:47 --> URI Class Initialized
INFO - 2016-01-26 11:46:47 --> Router Class Initialized
INFO - 2016-01-26 11:46:47 --> Output Class Initialized
INFO - 2016-01-26 11:46:47 --> Security Class Initialized
DEBUG - 2016-01-26 11:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:46:47 --> Input Class Initialized
INFO - 2016-01-26 11:46:47 --> Language Class Initialized
INFO - 2016-01-26 11:46:47 --> Loader Class Initialized
INFO - 2016-01-26 11:46:47 --> Helper loaded: url_helper
INFO - 2016-01-26 11:46:47 --> Helper loaded: file_helper
INFO - 2016-01-26 11:46:47 --> Helper loaded: date_helper
INFO - 2016-01-26 11:46:47 --> Database Driver Class Initialized
INFO - 2016-01-26 11:46:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:46:49 --> Controller Class Initialized
INFO - 2016-01-26 11:46:49 --> Model Class Initialized
INFO - 2016-01-26 11:46:49 --> Model Class Initialized
INFO - 2016-01-26 11:46:49 --> Helper loaded: form_helper
INFO - 2016-01-26 11:46:49 --> Form Validation Class Initialized
INFO - 2016-01-26 11:46:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:46:49 --> Final output sent to browser
DEBUG - 2016-01-26 11:46:49 --> Total execution time: 1.1240
INFO - 2016-01-26 11:47:28 --> Config Class Initialized
INFO - 2016-01-26 11:47:28 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:47:28 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:47:28 --> Utf8 Class Initialized
INFO - 2016-01-26 11:47:28 --> URI Class Initialized
INFO - 2016-01-26 11:47:28 --> Router Class Initialized
INFO - 2016-01-26 11:47:28 --> Output Class Initialized
INFO - 2016-01-26 11:47:28 --> Security Class Initialized
DEBUG - 2016-01-26 11:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:47:28 --> Input Class Initialized
INFO - 2016-01-26 11:47:28 --> Language Class Initialized
INFO - 2016-01-26 11:47:28 --> Loader Class Initialized
INFO - 2016-01-26 11:47:28 --> Helper loaded: url_helper
INFO - 2016-01-26 11:47:28 --> Helper loaded: file_helper
INFO - 2016-01-26 11:47:28 --> Helper loaded: date_helper
INFO - 2016-01-26 11:47:28 --> Database Driver Class Initialized
INFO - 2016-01-26 11:47:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:47:29 --> Controller Class Initialized
INFO - 2016-01-26 11:47:29 --> Model Class Initialized
INFO - 2016-01-26 11:47:29 --> Model Class Initialized
INFO - 2016-01-26 11:47:29 --> Helper loaded: form_helper
INFO - 2016-01-26 11:47:29 --> Form Validation Class Initialized
INFO - 2016-01-26 11:47:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:47:29 --> Final output sent to browser
DEBUG - 2016-01-26 11:47:29 --> Total execution time: 1.1028
INFO - 2016-01-26 11:48:23 --> Config Class Initialized
INFO - 2016-01-26 11:48:23 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:48:23 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:48:23 --> Utf8 Class Initialized
INFO - 2016-01-26 11:48:23 --> URI Class Initialized
INFO - 2016-01-26 11:48:23 --> Router Class Initialized
INFO - 2016-01-26 11:48:23 --> Output Class Initialized
INFO - 2016-01-26 11:48:23 --> Security Class Initialized
DEBUG - 2016-01-26 11:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:48:23 --> Input Class Initialized
INFO - 2016-01-26 11:48:23 --> Language Class Initialized
INFO - 2016-01-26 11:48:23 --> Loader Class Initialized
INFO - 2016-01-26 11:48:23 --> Helper loaded: url_helper
INFO - 2016-01-26 11:48:23 --> Helper loaded: file_helper
INFO - 2016-01-26 11:48:23 --> Helper loaded: date_helper
INFO - 2016-01-26 11:48:23 --> Database Driver Class Initialized
INFO - 2016-01-26 11:48:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:48:24 --> Controller Class Initialized
INFO - 2016-01-26 11:48:24 --> Model Class Initialized
INFO - 2016-01-26 11:48:24 --> Model Class Initialized
INFO - 2016-01-26 11:48:24 --> Helper loaded: form_helper
INFO - 2016-01-26 11:48:24 --> Form Validation Class Initialized
INFO - 2016-01-26 11:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:48:24 --> Final output sent to browser
DEBUG - 2016-01-26 11:48:24 --> Total execution time: 1.0805
INFO - 2016-01-26 11:49:54 --> Config Class Initialized
INFO - 2016-01-26 11:49:54 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:49:54 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:49:54 --> Utf8 Class Initialized
INFO - 2016-01-26 11:49:54 --> URI Class Initialized
INFO - 2016-01-26 11:49:54 --> Router Class Initialized
INFO - 2016-01-26 11:49:54 --> Output Class Initialized
INFO - 2016-01-26 11:49:54 --> Security Class Initialized
DEBUG - 2016-01-26 11:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:49:54 --> Input Class Initialized
INFO - 2016-01-26 11:49:54 --> Language Class Initialized
INFO - 2016-01-26 11:49:54 --> Loader Class Initialized
INFO - 2016-01-26 11:49:54 --> Helper loaded: url_helper
INFO - 2016-01-26 11:49:54 --> Helper loaded: file_helper
INFO - 2016-01-26 11:49:54 --> Helper loaded: date_helper
INFO - 2016-01-26 11:49:54 --> Database Driver Class Initialized
INFO - 2016-01-26 11:49:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:49:55 --> Controller Class Initialized
INFO - 2016-01-26 11:49:55 --> Model Class Initialized
INFO - 2016-01-26 11:49:55 --> Model Class Initialized
INFO - 2016-01-26 11:49:55 --> Helper loaded: form_helper
INFO - 2016-01-26 11:49:55 --> Form Validation Class Initialized
INFO - 2016-01-26 11:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:49:55 --> Final output sent to browser
DEBUG - 2016-01-26 11:49:55 --> Total execution time: 1.0794
INFO - 2016-01-26 11:50:50 --> Config Class Initialized
INFO - 2016-01-26 11:50:50 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:50:50 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:50:50 --> Utf8 Class Initialized
INFO - 2016-01-26 11:50:50 --> URI Class Initialized
INFO - 2016-01-26 11:50:50 --> Router Class Initialized
INFO - 2016-01-26 11:50:50 --> Output Class Initialized
INFO - 2016-01-26 11:50:50 --> Security Class Initialized
DEBUG - 2016-01-26 11:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:50:50 --> Input Class Initialized
INFO - 2016-01-26 11:50:50 --> Language Class Initialized
INFO - 2016-01-26 11:50:50 --> Loader Class Initialized
INFO - 2016-01-26 11:50:50 --> Helper loaded: url_helper
INFO - 2016-01-26 11:50:50 --> Helper loaded: file_helper
INFO - 2016-01-26 11:50:50 --> Helper loaded: date_helper
INFO - 2016-01-26 11:50:50 --> Database Driver Class Initialized
INFO - 2016-01-26 11:50:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:50:51 --> Controller Class Initialized
INFO - 2016-01-26 11:50:51 --> Model Class Initialized
INFO - 2016-01-26 11:50:51 --> Model Class Initialized
INFO - 2016-01-26 11:50:51 --> Helper loaded: form_helper
INFO - 2016-01-26 11:50:51 --> Form Validation Class Initialized
INFO - 2016-01-26 11:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:50:51 --> Final output sent to browser
DEBUG - 2016-01-26 11:50:51 --> Total execution time: 1.0822
INFO - 2016-01-26 11:51:02 --> Config Class Initialized
INFO - 2016-01-26 11:51:02 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:51:02 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:51:02 --> Utf8 Class Initialized
INFO - 2016-01-26 11:51:02 --> URI Class Initialized
INFO - 2016-01-26 11:51:02 --> Router Class Initialized
INFO - 2016-01-26 11:51:02 --> Output Class Initialized
INFO - 2016-01-26 11:51:02 --> Security Class Initialized
DEBUG - 2016-01-26 11:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:51:02 --> Input Class Initialized
INFO - 2016-01-26 11:51:02 --> Language Class Initialized
INFO - 2016-01-26 11:51:02 --> Loader Class Initialized
INFO - 2016-01-26 11:51:02 --> Helper loaded: url_helper
INFO - 2016-01-26 11:51:02 --> Helper loaded: file_helper
INFO - 2016-01-26 11:51:02 --> Helper loaded: date_helper
INFO - 2016-01-26 11:51:02 --> Database Driver Class Initialized
INFO - 2016-01-26 11:51:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:51:03 --> Controller Class Initialized
INFO - 2016-01-26 11:51:03 --> Model Class Initialized
INFO - 2016-01-26 11:51:03 --> Model Class Initialized
INFO - 2016-01-26 11:51:03 --> Helper loaded: form_helper
INFO - 2016-01-26 11:51:03 --> Form Validation Class Initialized
INFO - 2016-01-26 11:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:51:03 --> Final output sent to browser
DEBUG - 2016-01-26 11:51:03 --> Total execution time: 1.0879
INFO - 2016-01-26 11:51:58 --> Config Class Initialized
INFO - 2016-01-26 11:51:58 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:51:58 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:51:58 --> Utf8 Class Initialized
INFO - 2016-01-26 11:51:58 --> URI Class Initialized
INFO - 2016-01-26 11:51:58 --> Router Class Initialized
INFO - 2016-01-26 11:51:58 --> Output Class Initialized
INFO - 2016-01-26 11:51:58 --> Security Class Initialized
DEBUG - 2016-01-26 11:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:51:58 --> Input Class Initialized
INFO - 2016-01-26 11:51:58 --> Language Class Initialized
INFO - 2016-01-26 11:51:58 --> Loader Class Initialized
INFO - 2016-01-26 11:51:58 --> Helper loaded: url_helper
INFO - 2016-01-26 11:51:58 --> Helper loaded: file_helper
INFO - 2016-01-26 11:51:58 --> Helper loaded: date_helper
INFO - 2016-01-26 11:51:58 --> Database Driver Class Initialized
INFO - 2016-01-26 11:51:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:51:59 --> Controller Class Initialized
INFO - 2016-01-26 11:51:59 --> Model Class Initialized
INFO - 2016-01-26 11:51:59 --> Model Class Initialized
INFO - 2016-01-26 11:51:59 --> Helper loaded: form_helper
INFO - 2016-01-26 11:51:59 --> Form Validation Class Initialized
INFO - 2016-01-26 11:51:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:51:59 --> Final output sent to browser
DEBUG - 2016-01-26 11:51:59 --> Total execution time: 1.0955
INFO - 2016-01-26 11:53:14 --> Config Class Initialized
INFO - 2016-01-26 11:53:14 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:53:14 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:53:14 --> Utf8 Class Initialized
INFO - 2016-01-26 11:53:14 --> URI Class Initialized
INFO - 2016-01-26 11:53:14 --> Router Class Initialized
INFO - 2016-01-26 11:53:14 --> Output Class Initialized
INFO - 2016-01-26 11:53:14 --> Security Class Initialized
DEBUG - 2016-01-26 11:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:53:14 --> Input Class Initialized
INFO - 2016-01-26 11:53:14 --> Language Class Initialized
INFO - 2016-01-26 11:53:14 --> Loader Class Initialized
INFO - 2016-01-26 11:53:14 --> Helper loaded: url_helper
INFO - 2016-01-26 11:53:14 --> Helper loaded: file_helper
INFO - 2016-01-26 11:53:14 --> Helper loaded: date_helper
INFO - 2016-01-26 11:53:14 --> Database Driver Class Initialized
INFO - 2016-01-26 11:53:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:53:15 --> Controller Class Initialized
INFO - 2016-01-26 11:53:15 --> Model Class Initialized
INFO - 2016-01-26 11:53:15 --> Model Class Initialized
INFO - 2016-01-26 11:53:15 --> Helper loaded: form_helper
INFO - 2016-01-26 11:53:15 --> Form Validation Class Initialized
INFO - 2016-01-26 11:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:53:15 --> Final output sent to browser
DEBUG - 2016-01-26 11:53:15 --> Total execution time: 1.0855
INFO - 2016-01-26 11:53:34 --> Config Class Initialized
INFO - 2016-01-26 11:53:34 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:53:34 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:53:34 --> Utf8 Class Initialized
INFO - 2016-01-26 11:53:34 --> URI Class Initialized
INFO - 2016-01-26 11:53:34 --> Router Class Initialized
INFO - 2016-01-26 11:53:34 --> Output Class Initialized
INFO - 2016-01-26 11:53:34 --> Security Class Initialized
DEBUG - 2016-01-26 11:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:53:34 --> Input Class Initialized
INFO - 2016-01-26 11:53:34 --> Language Class Initialized
INFO - 2016-01-26 11:53:34 --> Loader Class Initialized
INFO - 2016-01-26 11:53:34 --> Helper loaded: url_helper
INFO - 2016-01-26 11:53:34 --> Helper loaded: file_helper
INFO - 2016-01-26 11:53:34 --> Helper loaded: date_helper
INFO - 2016-01-26 11:53:34 --> Database Driver Class Initialized
INFO - 2016-01-26 11:53:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:53:35 --> Controller Class Initialized
INFO - 2016-01-26 11:53:35 --> Model Class Initialized
INFO - 2016-01-26 11:53:35 --> Model Class Initialized
INFO - 2016-01-26 11:53:35 --> Helper loaded: form_helper
INFO - 2016-01-26 11:53:35 --> Form Validation Class Initialized
INFO - 2016-01-26 11:53:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:53:35 --> Final output sent to browser
DEBUG - 2016-01-26 11:53:35 --> Total execution time: 1.0949
INFO - 2016-01-26 11:53:55 --> Config Class Initialized
INFO - 2016-01-26 11:53:55 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:53:55 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:53:55 --> Utf8 Class Initialized
INFO - 2016-01-26 11:53:55 --> URI Class Initialized
INFO - 2016-01-26 11:53:55 --> Router Class Initialized
INFO - 2016-01-26 11:53:55 --> Output Class Initialized
INFO - 2016-01-26 11:53:55 --> Security Class Initialized
DEBUG - 2016-01-26 11:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:53:55 --> Input Class Initialized
INFO - 2016-01-26 11:53:55 --> Language Class Initialized
INFO - 2016-01-26 11:53:55 --> Loader Class Initialized
INFO - 2016-01-26 11:53:55 --> Helper loaded: url_helper
INFO - 2016-01-26 11:53:55 --> Helper loaded: file_helper
INFO - 2016-01-26 11:53:55 --> Helper loaded: date_helper
INFO - 2016-01-26 11:53:55 --> Database Driver Class Initialized
INFO - 2016-01-26 11:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:53:56 --> Controller Class Initialized
INFO - 2016-01-26 11:53:56 --> Model Class Initialized
INFO - 2016-01-26 11:53:56 --> Model Class Initialized
INFO - 2016-01-26 11:53:56 --> Helper loaded: form_helper
INFO - 2016-01-26 11:53:56 --> Form Validation Class Initialized
INFO - 2016-01-26 11:53:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:53:56 --> Final output sent to browser
DEBUG - 2016-01-26 11:53:56 --> Total execution time: 1.0959
INFO - 2016-01-26 11:54:31 --> Config Class Initialized
INFO - 2016-01-26 11:54:31 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:54:31 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:54:31 --> Utf8 Class Initialized
INFO - 2016-01-26 11:54:31 --> URI Class Initialized
INFO - 2016-01-26 11:54:31 --> Router Class Initialized
INFO - 2016-01-26 11:54:31 --> Output Class Initialized
INFO - 2016-01-26 11:54:31 --> Security Class Initialized
DEBUG - 2016-01-26 11:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:54:31 --> Input Class Initialized
INFO - 2016-01-26 11:54:31 --> Language Class Initialized
INFO - 2016-01-26 11:54:31 --> Loader Class Initialized
INFO - 2016-01-26 11:54:31 --> Helper loaded: url_helper
INFO - 2016-01-26 11:54:31 --> Helper loaded: file_helper
INFO - 2016-01-26 11:54:31 --> Helper loaded: date_helper
INFO - 2016-01-26 11:54:31 --> Database Driver Class Initialized
INFO - 2016-01-26 11:54:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:54:32 --> Controller Class Initialized
INFO - 2016-01-26 11:54:32 --> Model Class Initialized
INFO - 2016-01-26 11:54:32 --> Model Class Initialized
INFO - 2016-01-26 11:54:32 --> Helper loaded: form_helper
INFO - 2016-01-26 11:54:32 --> Form Validation Class Initialized
INFO - 2016-01-26 11:54:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:54:32 --> Final output sent to browser
DEBUG - 2016-01-26 11:54:32 --> Total execution time: 1.0747
INFO - 2016-01-26 11:54:50 --> Config Class Initialized
INFO - 2016-01-26 11:54:50 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:54:50 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:54:50 --> Utf8 Class Initialized
INFO - 2016-01-26 11:54:50 --> URI Class Initialized
INFO - 2016-01-26 11:54:50 --> Router Class Initialized
INFO - 2016-01-26 11:54:50 --> Output Class Initialized
INFO - 2016-01-26 11:54:50 --> Security Class Initialized
DEBUG - 2016-01-26 11:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:54:50 --> Input Class Initialized
INFO - 2016-01-26 11:54:50 --> Language Class Initialized
INFO - 2016-01-26 11:54:50 --> Loader Class Initialized
INFO - 2016-01-26 11:54:50 --> Helper loaded: url_helper
INFO - 2016-01-26 11:54:50 --> Helper loaded: file_helper
INFO - 2016-01-26 11:54:50 --> Helper loaded: date_helper
INFO - 2016-01-26 11:54:50 --> Database Driver Class Initialized
INFO - 2016-01-26 11:54:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:54:51 --> Controller Class Initialized
INFO - 2016-01-26 11:54:51 --> Model Class Initialized
INFO - 2016-01-26 11:54:51 --> Model Class Initialized
INFO - 2016-01-26 11:54:51 --> Helper loaded: form_helper
INFO - 2016-01-26 11:54:51 --> Form Validation Class Initialized
INFO - 2016-01-26 11:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:54:51 --> Final output sent to browser
DEBUG - 2016-01-26 11:54:51 --> Total execution time: 1.1090
INFO - 2016-01-26 11:55:12 --> Config Class Initialized
INFO - 2016-01-26 11:55:12 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:55:12 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:55:12 --> Utf8 Class Initialized
INFO - 2016-01-26 11:55:12 --> URI Class Initialized
INFO - 2016-01-26 11:55:12 --> Router Class Initialized
INFO - 2016-01-26 11:55:12 --> Output Class Initialized
INFO - 2016-01-26 11:55:12 --> Security Class Initialized
DEBUG - 2016-01-26 11:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:55:12 --> Input Class Initialized
INFO - 2016-01-26 11:55:12 --> Language Class Initialized
INFO - 2016-01-26 11:55:12 --> Loader Class Initialized
INFO - 2016-01-26 11:55:12 --> Helper loaded: url_helper
INFO - 2016-01-26 11:55:12 --> Helper loaded: file_helper
INFO - 2016-01-26 11:55:12 --> Helper loaded: date_helper
INFO - 2016-01-26 11:55:12 --> Database Driver Class Initialized
INFO - 2016-01-26 11:55:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:55:13 --> Controller Class Initialized
INFO - 2016-01-26 11:55:13 --> Model Class Initialized
INFO - 2016-01-26 11:55:13 --> Model Class Initialized
INFO - 2016-01-26 11:55:13 --> Helper loaded: form_helper
INFO - 2016-01-26 11:55:13 --> Form Validation Class Initialized
INFO - 2016-01-26 11:55:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:55:14 --> Final output sent to browser
DEBUG - 2016-01-26 11:55:14 --> Total execution time: 1.0812
INFO - 2016-01-26 11:55:21 --> Config Class Initialized
INFO - 2016-01-26 11:55:21 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:55:21 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:55:21 --> Utf8 Class Initialized
INFO - 2016-01-26 11:55:21 --> URI Class Initialized
INFO - 2016-01-26 11:55:21 --> Router Class Initialized
INFO - 2016-01-26 11:55:21 --> Output Class Initialized
INFO - 2016-01-26 11:55:21 --> Security Class Initialized
DEBUG - 2016-01-26 11:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:55:21 --> Input Class Initialized
INFO - 2016-01-26 11:55:21 --> Language Class Initialized
INFO - 2016-01-26 11:55:21 --> Loader Class Initialized
INFO - 2016-01-26 11:55:21 --> Helper loaded: url_helper
INFO - 2016-01-26 11:55:21 --> Helper loaded: file_helper
INFO - 2016-01-26 11:55:21 --> Helper loaded: date_helper
INFO - 2016-01-26 11:55:21 --> Database Driver Class Initialized
INFO - 2016-01-26 11:55:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:55:22 --> Controller Class Initialized
INFO - 2016-01-26 11:55:22 --> Model Class Initialized
INFO - 2016-01-26 11:55:22 --> Model Class Initialized
INFO - 2016-01-26 11:55:22 --> Helper loaded: form_helper
INFO - 2016-01-26 11:55:22 --> Form Validation Class Initialized
INFO - 2016-01-26 11:55:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:55:22 --> Final output sent to browser
DEBUG - 2016-01-26 11:55:22 --> Total execution time: 1.1143
INFO - 2016-01-26 11:55:34 --> Config Class Initialized
INFO - 2016-01-26 11:55:34 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:55:34 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:55:34 --> Utf8 Class Initialized
INFO - 2016-01-26 11:55:34 --> URI Class Initialized
INFO - 2016-01-26 11:55:34 --> Router Class Initialized
INFO - 2016-01-26 11:55:34 --> Output Class Initialized
INFO - 2016-01-26 11:55:34 --> Security Class Initialized
DEBUG - 2016-01-26 11:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:55:34 --> Input Class Initialized
INFO - 2016-01-26 11:55:34 --> Language Class Initialized
INFO - 2016-01-26 11:55:34 --> Loader Class Initialized
INFO - 2016-01-26 11:55:34 --> Helper loaded: url_helper
INFO - 2016-01-26 11:55:34 --> Helper loaded: file_helper
INFO - 2016-01-26 11:55:34 --> Helper loaded: date_helper
INFO - 2016-01-26 11:55:34 --> Database Driver Class Initialized
INFO - 2016-01-26 11:55:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:55:35 --> Controller Class Initialized
INFO - 2016-01-26 11:55:35 --> Model Class Initialized
INFO - 2016-01-26 11:55:35 --> Model Class Initialized
INFO - 2016-01-26 11:55:35 --> Helper loaded: form_helper
INFO - 2016-01-26 11:55:35 --> Form Validation Class Initialized
INFO - 2016-01-26 11:55:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:55:35 --> Final output sent to browser
DEBUG - 2016-01-26 11:55:35 --> Total execution time: 1.1055
INFO - 2016-01-26 11:56:49 --> Config Class Initialized
INFO - 2016-01-26 11:56:49 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:56:49 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:56:49 --> Utf8 Class Initialized
INFO - 2016-01-26 11:56:49 --> URI Class Initialized
INFO - 2016-01-26 11:56:49 --> Router Class Initialized
INFO - 2016-01-26 11:56:49 --> Output Class Initialized
INFO - 2016-01-26 11:56:49 --> Security Class Initialized
DEBUG - 2016-01-26 11:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:56:49 --> Input Class Initialized
INFO - 2016-01-26 11:56:49 --> Language Class Initialized
INFO - 2016-01-26 11:56:49 --> Loader Class Initialized
INFO - 2016-01-26 11:56:49 --> Helper loaded: url_helper
INFO - 2016-01-26 11:56:49 --> Helper loaded: file_helper
INFO - 2016-01-26 11:56:49 --> Helper loaded: date_helper
INFO - 2016-01-26 11:56:49 --> Database Driver Class Initialized
INFO - 2016-01-26 11:56:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:56:50 --> Controller Class Initialized
INFO - 2016-01-26 11:56:50 --> Model Class Initialized
INFO - 2016-01-26 11:56:50 --> Model Class Initialized
INFO - 2016-01-26 11:56:50 --> Helper loaded: form_helper
INFO - 2016-01-26 11:56:50 --> Form Validation Class Initialized
INFO - 2016-01-26 11:56:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:56:50 --> Final output sent to browser
DEBUG - 2016-01-26 11:56:50 --> Total execution time: 1.0917
INFO - 2016-01-26 11:57:11 --> Config Class Initialized
INFO - 2016-01-26 11:57:11 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:57:11 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:57:11 --> Utf8 Class Initialized
INFO - 2016-01-26 11:57:11 --> URI Class Initialized
INFO - 2016-01-26 11:57:11 --> Router Class Initialized
INFO - 2016-01-26 11:57:11 --> Output Class Initialized
INFO - 2016-01-26 11:57:11 --> Security Class Initialized
DEBUG - 2016-01-26 11:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:57:11 --> Input Class Initialized
INFO - 2016-01-26 11:57:11 --> Language Class Initialized
INFO - 2016-01-26 11:57:11 --> Loader Class Initialized
INFO - 2016-01-26 11:57:11 --> Helper loaded: url_helper
INFO - 2016-01-26 11:57:11 --> Helper loaded: file_helper
INFO - 2016-01-26 11:57:11 --> Helper loaded: date_helper
INFO - 2016-01-26 11:57:11 --> Database Driver Class Initialized
INFO - 2016-01-26 11:57:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:57:12 --> Controller Class Initialized
INFO - 2016-01-26 11:57:12 --> Model Class Initialized
INFO - 2016-01-26 11:57:12 --> Model Class Initialized
INFO - 2016-01-26 11:57:12 --> Helper loaded: form_helper
INFO - 2016-01-26 11:57:12 --> Form Validation Class Initialized
INFO - 2016-01-26 11:57:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:57:12 --> Final output sent to browser
DEBUG - 2016-01-26 11:57:12 --> Total execution time: 1.0954
INFO - 2016-01-26 11:58:43 --> Config Class Initialized
INFO - 2016-01-26 11:58:43 --> Hooks Class Initialized
DEBUG - 2016-01-26 11:58:43 --> UTF-8 Support Enabled
INFO - 2016-01-26 11:58:43 --> Utf8 Class Initialized
INFO - 2016-01-26 11:58:43 --> URI Class Initialized
INFO - 2016-01-26 11:58:43 --> Router Class Initialized
INFO - 2016-01-26 11:58:43 --> Output Class Initialized
INFO - 2016-01-26 11:58:43 --> Security Class Initialized
DEBUG - 2016-01-26 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 11:58:43 --> Input Class Initialized
INFO - 2016-01-26 11:58:43 --> Language Class Initialized
INFO - 2016-01-26 11:58:43 --> Loader Class Initialized
INFO - 2016-01-26 11:58:43 --> Helper loaded: url_helper
INFO - 2016-01-26 11:58:43 --> Helper loaded: file_helper
INFO - 2016-01-26 11:58:43 --> Helper loaded: date_helper
INFO - 2016-01-26 11:58:43 --> Database Driver Class Initialized
INFO - 2016-01-26 11:58:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 11:58:45 --> Controller Class Initialized
INFO - 2016-01-26 11:58:45 --> Model Class Initialized
INFO - 2016-01-26 11:58:45 --> Model Class Initialized
INFO - 2016-01-26 11:58:45 --> Helper loaded: form_helper
INFO - 2016-01-26 11:58:45 --> Form Validation Class Initialized
INFO - 2016-01-26 11:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 11:58:45 --> Final output sent to browser
DEBUG - 2016-01-26 11:58:45 --> Total execution time: 1.1170
INFO - 2016-01-26 12:00:04 --> Config Class Initialized
INFO - 2016-01-26 12:00:04 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:00:04 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:00:04 --> Utf8 Class Initialized
INFO - 2016-01-26 12:00:04 --> URI Class Initialized
INFO - 2016-01-26 12:00:04 --> Router Class Initialized
INFO - 2016-01-26 12:00:04 --> Output Class Initialized
INFO - 2016-01-26 12:00:04 --> Security Class Initialized
DEBUG - 2016-01-26 12:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:00:04 --> Input Class Initialized
INFO - 2016-01-26 12:00:04 --> Language Class Initialized
INFO - 2016-01-26 12:00:04 --> Loader Class Initialized
INFO - 2016-01-26 12:00:04 --> Helper loaded: url_helper
INFO - 2016-01-26 12:00:04 --> Helper loaded: file_helper
INFO - 2016-01-26 12:00:04 --> Helper loaded: date_helper
INFO - 2016-01-26 12:00:04 --> Database Driver Class Initialized
INFO - 2016-01-26 12:00:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:00:05 --> Controller Class Initialized
INFO - 2016-01-26 12:00:05 --> Model Class Initialized
INFO - 2016-01-26 12:00:05 --> Model Class Initialized
INFO - 2016-01-26 12:00:05 --> Helper loaded: form_helper
INFO - 2016-01-26 12:00:05 --> Form Validation Class Initialized
INFO - 2016-01-26 12:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:00:05 --> Final output sent to browser
DEBUG - 2016-01-26 12:00:05 --> Total execution time: 1.1021
INFO - 2016-01-26 12:00:48 --> Config Class Initialized
INFO - 2016-01-26 12:00:48 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:00:48 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:00:48 --> Utf8 Class Initialized
INFO - 2016-01-26 12:00:48 --> URI Class Initialized
INFO - 2016-01-26 12:00:48 --> Router Class Initialized
INFO - 2016-01-26 12:00:48 --> Output Class Initialized
INFO - 2016-01-26 12:00:48 --> Security Class Initialized
DEBUG - 2016-01-26 12:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:00:48 --> Input Class Initialized
INFO - 2016-01-26 12:00:48 --> Language Class Initialized
INFO - 2016-01-26 12:00:48 --> Loader Class Initialized
INFO - 2016-01-26 12:00:48 --> Helper loaded: url_helper
INFO - 2016-01-26 12:00:48 --> Helper loaded: file_helper
INFO - 2016-01-26 12:00:48 --> Helper loaded: date_helper
INFO - 2016-01-26 12:00:48 --> Database Driver Class Initialized
INFO - 2016-01-26 12:00:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:00:49 --> Controller Class Initialized
INFO - 2016-01-26 12:00:49 --> Model Class Initialized
INFO - 2016-01-26 12:00:49 --> Model Class Initialized
INFO - 2016-01-26 12:00:49 --> Helper loaded: form_helper
INFO - 2016-01-26 12:00:49 --> Form Validation Class Initialized
INFO - 2016-01-26 12:00:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:00:49 --> Final output sent to browser
DEBUG - 2016-01-26 12:00:49 --> Total execution time: 1.0968
INFO - 2016-01-26 12:02:15 --> Config Class Initialized
INFO - 2016-01-26 12:02:15 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:02:15 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:02:15 --> Utf8 Class Initialized
INFO - 2016-01-26 12:02:15 --> URI Class Initialized
INFO - 2016-01-26 12:02:15 --> Router Class Initialized
INFO - 2016-01-26 12:02:15 --> Output Class Initialized
INFO - 2016-01-26 12:02:15 --> Security Class Initialized
DEBUG - 2016-01-26 12:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:02:15 --> Input Class Initialized
INFO - 2016-01-26 12:02:15 --> Language Class Initialized
INFO - 2016-01-26 12:02:15 --> Loader Class Initialized
INFO - 2016-01-26 12:02:15 --> Helper loaded: url_helper
INFO - 2016-01-26 12:02:15 --> Helper loaded: file_helper
INFO - 2016-01-26 12:02:15 --> Helper loaded: date_helper
INFO - 2016-01-26 12:02:15 --> Database Driver Class Initialized
INFO - 2016-01-26 12:02:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:02:16 --> Controller Class Initialized
INFO - 2016-01-26 12:02:16 --> Model Class Initialized
INFO - 2016-01-26 12:02:16 --> Model Class Initialized
INFO - 2016-01-26 12:02:16 --> Helper loaded: form_helper
INFO - 2016-01-26 12:02:16 --> Form Validation Class Initialized
INFO - 2016-01-26 12:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:02:16 --> Final output sent to browser
DEBUG - 2016-01-26 12:02:16 --> Total execution time: 1.1062
INFO - 2016-01-26 12:02:41 --> Config Class Initialized
INFO - 2016-01-26 12:02:41 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:02:41 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:02:41 --> Utf8 Class Initialized
INFO - 2016-01-26 12:02:41 --> URI Class Initialized
INFO - 2016-01-26 12:02:41 --> Router Class Initialized
INFO - 2016-01-26 12:02:41 --> Output Class Initialized
INFO - 2016-01-26 12:02:41 --> Security Class Initialized
DEBUG - 2016-01-26 12:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:02:41 --> Input Class Initialized
INFO - 2016-01-26 12:02:41 --> Language Class Initialized
INFO - 2016-01-26 12:02:41 --> Loader Class Initialized
INFO - 2016-01-26 12:02:41 --> Helper loaded: url_helper
INFO - 2016-01-26 12:02:41 --> Helper loaded: file_helper
INFO - 2016-01-26 12:02:41 --> Helper loaded: date_helper
INFO - 2016-01-26 12:02:41 --> Database Driver Class Initialized
INFO - 2016-01-26 12:02:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:02:42 --> Controller Class Initialized
INFO - 2016-01-26 12:02:42 --> Model Class Initialized
INFO - 2016-01-26 12:02:42 --> Model Class Initialized
INFO - 2016-01-26 12:02:42 --> Helper loaded: form_helper
INFO - 2016-01-26 12:02:42 --> Form Validation Class Initialized
INFO - 2016-01-26 12:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:02:42 --> Final output sent to browser
DEBUG - 2016-01-26 12:02:42 --> Total execution time: 1.0962
INFO - 2016-01-26 12:02:53 --> Config Class Initialized
INFO - 2016-01-26 12:02:53 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:02:53 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:02:53 --> Utf8 Class Initialized
INFO - 2016-01-26 12:02:53 --> URI Class Initialized
INFO - 2016-01-26 12:02:53 --> Router Class Initialized
INFO - 2016-01-26 12:02:53 --> Output Class Initialized
INFO - 2016-01-26 12:02:53 --> Security Class Initialized
DEBUG - 2016-01-26 12:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:02:53 --> Input Class Initialized
INFO - 2016-01-26 12:02:53 --> Language Class Initialized
INFO - 2016-01-26 12:02:53 --> Loader Class Initialized
INFO - 2016-01-26 12:02:53 --> Helper loaded: url_helper
INFO - 2016-01-26 12:02:53 --> Helper loaded: file_helper
INFO - 2016-01-26 12:02:53 --> Helper loaded: date_helper
INFO - 2016-01-26 12:02:53 --> Database Driver Class Initialized
INFO - 2016-01-26 12:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:02:54 --> Controller Class Initialized
INFO - 2016-01-26 12:02:54 --> Model Class Initialized
INFO - 2016-01-26 12:02:54 --> Model Class Initialized
INFO - 2016-01-26 12:02:54 --> Helper loaded: form_helper
INFO - 2016-01-26 12:02:54 --> Form Validation Class Initialized
INFO - 2016-01-26 12:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:02:54 --> Final output sent to browser
DEBUG - 2016-01-26 12:02:54 --> Total execution time: 1.0760
INFO - 2016-01-26 12:03:07 --> Config Class Initialized
INFO - 2016-01-26 12:03:07 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:03:07 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:03:07 --> Utf8 Class Initialized
INFO - 2016-01-26 12:03:07 --> URI Class Initialized
INFO - 2016-01-26 12:03:07 --> Router Class Initialized
INFO - 2016-01-26 12:03:07 --> Output Class Initialized
INFO - 2016-01-26 12:03:07 --> Security Class Initialized
DEBUG - 2016-01-26 12:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:03:07 --> Input Class Initialized
INFO - 2016-01-26 12:03:07 --> Language Class Initialized
INFO - 2016-01-26 12:03:07 --> Loader Class Initialized
INFO - 2016-01-26 12:03:07 --> Helper loaded: url_helper
INFO - 2016-01-26 12:03:07 --> Helper loaded: file_helper
INFO - 2016-01-26 12:03:07 --> Helper loaded: date_helper
INFO - 2016-01-26 12:03:07 --> Database Driver Class Initialized
INFO - 2016-01-26 12:03:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:03:08 --> Controller Class Initialized
INFO - 2016-01-26 12:03:08 --> Model Class Initialized
INFO - 2016-01-26 12:03:08 --> Model Class Initialized
INFO - 2016-01-26 12:03:08 --> Helper loaded: form_helper
INFO - 2016-01-26 12:03:08 --> Form Validation Class Initialized
INFO - 2016-01-26 12:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:03:08 --> Final output sent to browser
DEBUG - 2016-01-26 12:03:08 --> Total execution time: 1.1000
INFO - 2016-01-26 12:03:24 --> Config Class Initialized
INFO - 2016-01-26 12:03:24 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:03:24 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:03:24 --> Utf8 Class Initialized
INFO - 2016-01-26 12:03:24 --> URI Class Initialized
INFO - 2016-01-26 12:03:24 --> Router Class Initialized
INFO - 2016-01-26 12:03:24 --> Output Class Initialized
INFO - 2016-01-26 12:03:24 --> Security Class Initialized
DEBUG - 2016-01-26 12:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:03:24 --> Input Class Initialized
INFO - 2016-01-26 12:03:24 --> Language Class Initialized
INFO - 2016-01-26 12:03:24 --> Loader Class Initialized
INFO - 2016-01-26 12:03:24 --> Helper loaded: url_helper
INFO - 2016-01-26 12:03:24 --> Helper loaded: file_helper
INFO - 2016-01-26 12:03:24 --> Helper loaded: date_helper
INFO - 2016-01-26 12:03:24 --> Database Driver Class Initialized
INFO - 2016-01-26 12:03:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:03:25 --> Controller Class Initialized
INFO - 2016-01-26 12:03:25 --> Model Class Initialized
INFO - 2016-01-26 12:03:25 --> Model Class Initialized
INFO - 2016-01-26 12:03:25 --> Helper loaded: form_helper
INFO - 2016-01-26 12:03:25 --> Form Validation Class Initialized
INFO - 2016-01-26 12:03:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:03:25 --> Final output sent to browser
DEBUG - 2016-01-26 12:03:25 --> Total execution time: 1.0721
INFO - 2016-01-26 12:04:12 --> Config Class Initialized
INFO - 2016-01-26 12:04:12 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:04:12 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:04:12 --> Utf8 Class Initialized
INFO - 2016-01-26 12:04:12 --> URI Class Initialized
INFO - 2016-01-26 12:04:12 --> Router Class Initialized
INFO - 2016-01-26 12:04:12 --> Output Class Initialized
INFO - 2016-01-26 12:04:12 --> Security Class Initialized
DEBUG - 2016-01-26 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:04:12 --> Input Class Initialized
INFO - 2016-01-26 12:04:12 --> Language Class Initialized
INFO - 2016-01-26 12:04:12 --> Loader Class Initialized
INFO - 2016-01-26 12:04:12 --> Helper loaded: url_helper
INFO - 2016-01-26 12:04:12 --> Helper loaded: file_helper
INFO - 2016-01-26 12:04:12 --> Helper loaded: date_helper
INFO - 2016-01-26 12:04:12 --> Database Driver Class Initialized
INFO - 2016-01-26 12:04:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:04:13 --> Controller Class Initialized
INFO - 2016-01-26 12:04:13 --> Model Class Initialized
INFO - 2016-01-26 12:04:13 --> Model Class Initialized
INFO - 2016-01-26 12:04:13 --> Helper loaded: form_helper
INFO - 2016-01-26 12:04:13 --> Form Validation Class Initialized
INFO - 2016-01-26 12:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:04:13 --> Final output sent to browser
DEBUG - 2016-01-26 12:04:13 --> Total execution time: 1.0979
INFO - 2016-01-26 12:05:23 --> Config Class Initialized
INFO - 2016-01-26 12:05:23 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:05:23 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:05:23 --> Utf8 Class Initialized
INFO - 2016-01-26 12:05:23 --> URI Class Initialized
INFO - 2016-01-26 12:05:23 --> Router Class Initialized
INFO - 2016-01-26 12:05:23 --> Output Class Initialized
INFO - 2016-01-26 12:05:23 --> Security Class Initialized
DEBUG - 2016-01-26 12:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:05:23 --> Input Class Initialized
INFO - 2016-01-26 12:05:23 --> Language Class Initialized
INFO - 2016-01-26 12:05:23 --> Loader Class Initialized
INFO - 2016-01-26 12:05:23 --> Helper loaded: url_helper
INFO - 2016-01-26 12:05:23 --> Helper loaded: file_helper
INFO - 2016-01-26 12:05:23 --> Helper loaded: date_helper
INFO - 2016-01-26 12:05:23 --> Database Driver Class Initialized
INFO - 2016-01-26 12:05:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:05:24 --> Controller Class Initialized
INFO - 2016-01-26 12:05:24 --> Model Class Initialized
INFO - 2016-01-26 12:05:24 --> Model Class Initialized
INFO - 2016-01-26 12:05:24 --> Helper loaded: form_helper
INFO - 2016-01-26 12:05:24 --> Form Validation Class Initialized
INFO - 2016-01-26 12:05:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:05:24 --> Final output sent to browser
DEBUG - 2016-01-26 12:05:24 --> Total execution time: 1.0882
INFO - 2016-01-26 12:06:17 --> Config Class Initialized
INFO - 2016-01-26 12:06:17 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:06:17 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:06:17 --> Utf8 Class Initialized
INFO - 2016-01-26 12:06:17 --> URI Class Initialized
INFO - 2016-01-26 12:06:17 --> Router Class Initialized
INFO - 2016-01-26 12:06:17 --> Output Class Initialized
INFO - 2016-01-26 12:06:17 --> Security Class Initialized
DEBUG - 2016-01-26 12:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:06:17 --> Input Class Initialized
INFO - 2016-01-26 12:06:17 --> Language Class Initialized
INFO - 2016-01-26 12:06:17 --> Loader Class Initialized
INFO - 2016-01-26 12:06:17 --> Helper loaded: url_helper
INFO - 2016-01-26 12:06:17 --> Helper loaded: file_helper
INFO - 2016-01-26 12:06:17 --> Helper loaded: date_helper
INFO - 2016-01-26 12:06:17 --> Database Driver Class Initialized
INFO - 2016-01-26 12:06:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:06:18 --> Controller Class Initialized
INFO - 2016-01-26 12:06:18 --> Model Class Initialized
INFO - 2016-01-26 12:06:18 --> Model Class Initialized
INFO - 2016-01-26 12:06:18 --> Helper loaded: form_helper
INFO - 2016-01-26 12:06:18 --> Form Validation Class Initialized
INFO - 2016-01-26 12:06:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:06:18 --> Final output sent to browser
DEBUG - 2016-01-26 12:06:18 --> Total execution time: 1.1199
INFO - 2016-01-26 12:09:16 --> Config Class Initialized
INFO - 2016-01-26 12:09:16 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:09:16 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:09:16 --> Utf8 Class Initialized
INFO - 2016-01-26 12:09:16 --> URI Class Initialized
INFO - 2016-01-26 12:09:16 --> Router Class Initialized
INFO - 2016-01-26 12:09:16 --> Output Class Initialized
INFO - 2016-01-26 12:09:16 --> Security Class Initialized
DEBUG - 2016-01-26 12:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:09:16 --> Input Class Initialized
INFO - 2016-01-26 12:09:16 --> Language Class Initialized
INFO - 2016-01-26 12:09:16 --> Loader Class Initialized
INFO - 2016-01-26 12:09:16 --> Helper loaded: url_helper
INFO - 2016-01-26 12:09:16 --> Helper loaded: file_helper
INFO - 2016-01-26 12:09:16 --> Helper loaded: date_helper
INFO - 2016-01-26 12:09:16 --> Database Driver Class Initialized
INFO - 2016-01-26 12:09:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:09:17 --> Controller Class Initialized
INFO - 2016-01-26 12:09:17 --> Model Class Initialized
INFO - 2016-01-26 12:09:17 --> Model Class Initialized
INFO - 2016-01-26 12:09:17 --> Helper loaded: form_helper
INFO - 2016-01-26 12:09:17 --> Form Validation Class Initialized
INFO - 2016-01-26 12:09:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:09:17 --> Final output sent to browser
DEBUG - 2016-01-26 12:09:17 --> Total execution time: 1.1032
INFO - 2016-01-26 12:12:44 --> Config Class Initialized
INFO - 2016-01-26 12:12:44 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:12:44 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:12:44 --> Utf8 Class Initialized
INFO - 2016-01-26 12:12:44 --> URI Class Initialized
INFO - 2016-01-26 12:12:44 --> Router Class Initialized
INFO - 2016-01-26 12:12:44 --> Output Class Initialized
INFO - 2016-01-26 12:12:44 --> Security Class Initialized
DEBUG - 2016-01-26 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:12:44 --> Input Class Initialized
INFO - 2016-01-26 12:12:44 --> Language Class Initialized
INFO - 2016-01-26 12:12:44 --> Loader Class Initialized
INFO - 2016-01-26 12:12:44 --> Helper loaded: url_helper
INFO - 2016-01-26 12:12:44 --> Helper loaded: file_helper
INFO - 2016-01-26 12:12:44 --> Helper loaded: date_helper
INFO - 2016-01-26 12:12:44 --> Database Driver Class Initialized
INFO - 2016-01-26 12:12:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:12:45 --> Controller Class Initialized
INFO - 2016-01-26 12:12:45 --> Model Class Initialized
INFO - 2016-01-26 12:12:45 --> Model Class Initialized
INFO - 2016-01-26 12:12:45 --> Helper loaded: form_helper
INFO - 2016-01-26 12:12:45 --> Form Validation Class Initialized
INFO - 2016-01-26 12:12:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 12:12:45 --> Final output sent to browser
DEBUG - 2016-01-26 12:12:45 --> Total execution time: 1.0995
INFO - 2016-01-26 12:12:50 --> Config Class Initialized
INFO - 2016-01-26 12:12:50 --> Hooks Class Initialized
DEBUG - 2016-01-26 12:12:50 --> UTF-8 Support Enabled
INFO - 2016-01-26 12:12:50 --> Utf8 Class Initialized
INFO - 2016-01-26 12:12:50 --> URI Class Initialized
DEBUG - 2016-01-26 12:12:50 --> No URI present. Default controller set.
INFO - 2016-01-26 12:12:50 --> Router Class Initialized
INFO - 2016-01-26 12:12:50 --> Output Class Initialized
INFO - 2016-01-26 12:12:50 --> Security Class Initialized
DEBUG - 2016-01-26 12:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 12:12:50 --> Input Class Initialized
INFO - 2016-01-26 12:12:50 --> Language Class Initialized
INFO - 2016-01-26 12:12:50 --> Loader Class Initialized
INFO - 2016-01-26 12:12:50 --> Helper loaded: url_helper
INFO - 2016-01-26 12:12:50 --> Helper loaded: file_helper
INFO - 2016-01-26 12:12:50 --> Helper loaded: date_helper
INFO - 2016-01-26 12:12:50 --> Database Driver Class Initialized
INFO - 2016-01-26 12:12:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 12:12:51 --> Controller Class Initialized
INFO - 2016-01-26 12:12:51 --> Model Class Initialized
INFO - 2016-01-26 12:12:51 --> Model Class Initialized
INFO - 2016-01-26 12:12:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 12:12:51 --> Pagination Class Initialized
INFO - 2016-01-26 12:12:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 12:12:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 12:12:51 --> Final output sent to browser
DEBUG - 2016-01-26 12:12:51 --> Total execution time: 1.1027
INFO - 2016-01-26 13:59:12 --> Config Class Initialized
INFO - 2016-01-26 13:59:12 --> Hooks Class Initialized
DEBUG - 2016-01-26 13:59:12 --> UTF-8 Support Enabled
INFO - 2016-01-26 13:59:12 --> Utf8 Class Initialized
INFO - 2016-01-26 13:59:12 --> URI Class Initialized
INFO - 2016-01-26 13:59:12 --> Router Class Initialized
INFO - 2016-01-26 13:59:12 --> Output Class Initialized
INFO - 2016-01-26 13:59:12 --> Security Class Initialized
DEBUG - 2016-01-26 13:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 13:59:12 --> Input Class Initialized
INFO - 2016-01-26 13:59:12 --> Language Class Initialized
INFO - 2016-01-26 13:59:12 --> Loader Class Initialized
INFO - 2016-01-26 13:59:12 --> Helper loaded: url_helper
INFO - 2016-01-26 13:59:12 --> Helper loaded: file_helper
INFO - 2016-01-26 13:59:12 --> Helper loaded: date_helper
INFO - 2016-01-26 13:59:12 --> Database Driver Class Initialized
INFO - 2016-01-26 13:59:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 13:59:13 --> Controller Class Initialized
INFO - 2016-01-26 13:59:13 --> Model Class Initialized
INFO - 2016-01-26 13:59:13 --> Model Class Initialized
INFO - 2016-01-26 13:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 13:59:13 --> Pagination Class Initialized
INFO - 2016-01-26 13:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 13:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 13:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 13:59:13 --> Final output sent to browser
DEBUG - 2016-01-26 13:59:13 --> Total execution time: 1.2110
INFO - 2016-01-26 14:01:35 --> Config Class Initialized
INFO - 2016-01-26 14:01:35 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:01:35 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:01:35 --> Utf8 Class Initialized
INFO - 2016-01-26 14:01:35 --> URI Class Initialized
DEBUG - 2016-01-26 14:01:35 --> No URI present. Default controller set.
INFO - 2016-01-26 14:01:35 --> Router Class Initialized
INFO - 2016-01-26 14:01:35 --> Output Class Initialized
INFO - 2016-01-26 14:01:35 --> Security Class Initialized
DEBUG - 2016-01-26 14:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:01:35 --> Input Class Initialized
INFO - 2016-01-26 14:01:35 --> Language Class Initialized
INFO - 2016-01-26 14:01:35 --> Loader Class Initialized
INFO - 2016-01-26 14:01:35 --> Helper loaded: url_helper
INFO - 2016-01-26 14:01:35 --> Helper loaded: file_helper
INFO - 2016-01-26 14:01:35 --> Helper loaded: date_helper
INFO - 2016-01-26 14:01:35 --> Database Driver Class Initialized
INFO - 2016-01-26 14:01:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:01:36 --> Controller Class Initialized
INFO - 2016-01-26 14:01:36 --> Model Class Initialized
INFO - 2016-01-26 14:01:36 --> Model Class Initialized
INFO - 2016-01-26 14:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 14:01:36 --> Pagination Class Initialized
INFO - 2016-01-26 14:01:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 14:01:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 14:01:36 --> Final output sent to browser
DEBUG - 2016-01-26 14:01:36 --> Total execution time: 1.0997
INFO - 2016-01-26 14:01:37 --> Config Class Initialized
INFO - 2016-01-26 14:01:37 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:01:37 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:01:37 --> Utf8 Class Initialized
INFO - 2016-01-26 14:01:37 --> URI Class Initialized
INFO - 2016-01-26 14:01:37 --> Router Class Initialized
INFO - 2016-01-26 14:01:37 --> Output Class Initialized
INFO - 2016-01-26 14:01:37 --> Security Class Initialized
DEBUG - 2016-01-26 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:01:37 --> Input Class Initialized
INFO - 2016-01-26 14:01:37 --> Language Class Initialized
INFO - 2016-01-26 14:01:37 --> Loader Class Initialized
INFO - 2016-01-26 14:01:37 --> Helper loaded: url_helper
INFO - 2016-01-26 14:01:37 --> Helper loaded: file_helper
INFO - 2016-01-26 14:01:37 --> Helper loaded: date_helper
INFO - 2016-01-26 14:01:37 --> Database Driver Class Initialized
INFO - 2016-01-26 14:01:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:01:38 --> Controller Class Initialized
INFO - 2016-01-26 14:01:38 --> Model Class Initialized
INFO - 2016-01-26 14:01:38 --> Model Class Initialized
INFO - 2016-01-26 14:01:38 --> Helper loaded: form_helper
INFO - 2016-01-26 14:01:38 --> Form Validation Class Initialized
INFO - 2016-01-26 14:01:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 14:01:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-01-26 14:01:38 --> Final output sent to browser
DEBUG - 2016-01-26 14:01:38 --> Total execution time: 1.0945
INFO - 2016-01-26 14:01:42 --> Config Class Initialized
INFO - 2016-01-26 14:01:42 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:01:42 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:01:42 --> Utf8 Class Initialized
INFO - 2016-01-26 14:01:42 --> URI Class Initialized
INFO - 2016-01-26 14:01:42 --> Router Class Initialized
INFO - 2016-01-26 14:01:42 --> Output Class Initialized
INFO - 2016-01-26 14:01:42 --> Security Class Initialized
DEBUG - 2016-01-26 14:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:01:42 --> Input Class Initialized
INFO - 2016-01-26 14:01:43 --> Language Class Initialized
INFO - 2016-01-26 14:01:43 --> Loader Class Initialized
INFO - 2016-01-26 14:01:43 --> Helper loaded: url_helper
INFO - 2016-01-26 14:01:43 --> Helper loaded: file_helper
INFO - 2016-01-26 14:01:43 --> Helper loaded: date_helper
INFO - 2016-01-26 14:01:43 --> Database Driver Class Initialized
INFO - 2016-01-26 14:01:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:01:44 --> Controller Class Initialized
INFO - 2016-01-26 14:01:44 --> Model Class Initialized
INFO - 2016-01-26 14:01:44 --> Model Class Initialized
INFO - 2016-01-26 14:01:44 --> Helper loaded: form_helper
INFO - 2016-01-26 14:01:44 --> Form Validation Class Initialized
INFO - 2016-01-26 14:01:44 --> Config Class Initialized
INFO - 2016-01-26 14:01:44 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:01:44 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:01:44 --> Utf8 Class Initialized
INFO - 2016-01-26 14:01:44 --> URI Class Initialized
INFO - 2016-01-26 14:01:44 --> Router Class Initialized
INFO - 2016-01-26 14:01:44 --> Output Class Initialized
INFO - 2016-01-26 14:01:44 --> Security Class Initialized
DEBUG - 2016-01-26 14:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:01:44 --> Input Class Initialized
INFO - 2016-01-26 14:01:44 --> Language Class Initialized
INFO - 2016-01-26 14:01:44 --> Loader Class Initialized
INFO - 2016-01-26 14:01:44 --> Helper loaded: url_helper
INFO - 2016-01-26 14:01:44 --> Helper loaded: file_helper
INFO - 2016-01-26 14:01:44 --> Helper loaded: date_helper
INFO - 2016-01-26 14:01:44 --> Database Driver Class Initialized
INFO - 2016-01-26 14:01:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:01:45 --> Controller Class Initialized
INFO - 2016-01-26 14:01:45 --> Model Class Initialized
INFO - 2016-01-26 14:01:45 --> Model Class Initialized
INFO - 2016-01-26 14:01:45 --> Helper loaded: form_helper
INFO - 2016-01-26 14:01:45 --> Form Validation Class Initialized
INFO - 2016-01-26 14:01:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-01-26 14:01:45 --> Final output sent to browser
DEBUG - 2016-01-26 14:01:45 --> Total execution time: 1.0900
INFO - 2016-01-26 14:01:55 --> Config Class Initialized
INFO - 2016-01-26 14:01:55 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:01:55 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:01:55 --> Utf8 Class Initialized
INFO - 2016-01-26 14:01:55 --> URI Class Initialized
DEBUG - 2016-01-26 14:01:55 --> No URI present. Default controller set.
INFO - 2016-01-26 14:01:55 --> Router Class Initialized
INFO - 2016-01-26 14:01:55 --> Output Class Initialized
INFO - 2016-01-26 14:01:55 --> Security Class Initialized
DEBUG - 2016-01-26 14:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:01:55 --> Input Class Initialized
INFO - 2016-01-26 14:01:55 --> Language Class Initialized
INFO - 2016-01-26 14:01:55 --> Loader Class Initialized
INFO - 2016-01-26 14:01:55 --> Helper loaded: url_helper
INFO - 2016-01-26 14:01:55 --> Helper loaded: file_helper
INFO - 2016-01-26 14:01:55 --> Helper loaded: date_helper
INFO - 2016-01-26 14:01:55 --> Database Driver Class Initialized
INFO - 2016-01-26 14:01:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:01:56 --> Controller Class Initialized
INFO - 2016-01-26 14:01:56 --> Model Class Initialized
INFO - 2016-01-26 14:01:56 --> Model Class Initialized
INFO - 2016-01-26 14:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 14:01:56 --> Pagination Class Initialized
INFO - 2016-01-26 14:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 14:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 14:01:56 --> Final output sent to browser
DEBUG - 2016-01-26 14:01:56 --> Total execution time: 1.0948
INFO - 2016-01-26 14:02:03 --> Config Class Initialized
INFO - 2016-01-26 14:02:03 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:02:03 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:02:03 --> Utf8 Class Initialized
INFO - 2016-01-26 14:02:03 --> URI Class Initialized
INFO - 2016-01-26 14:02:03 --> Router Class Initialized
INFO - 2016-01-26 14:02:03 --> Output Class Initialized
INFO - 2016-01-26 14:02:03 --> Security Class Initialized
DEBUG - 2016-01-26 14:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:02:03 --> Input Class Initialized
INFO - 2016-01-26 14:02:03 --> Language Class Initialized
INFO - 2016-01-26 14:02:03 --> Loader Class Initialized
INFO - 2016-01-26 14:02:03 --> Helper loaded: url_helper
INFO - 2016-01-26 14:02:03 --> Helper loaded: file_helper
INFO - 2016-01-26 14:02:03 --> Helper loaded: date_helper
INFO - 2016-01-26 14:02:03 --> Database Driver Class Initialized
INFO - 2016-01-26 14:02:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:02:04 --> Controller Class Initialized
INFO - 2016-01-26 14:02:04 --> Model Class Initialized
INFO - 2016-01-26 14:02:04 --> Model Class Initialized
INFO - 2016-01-26 14:02:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 14:02:04 --> Pagination Class Initialized
INFO - 2016-01-26 14:02:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 14:02:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 14:02:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 14:02:04 --> Final output sent to browser
DEBUG - 2016-01-26 14:02:04 --> Total execution time: 1.1414
INFO - 2016-01-26 14:47:11 --> Config Class Initialized
INFO - 2016-01-26 14:47:11 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:47:11 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:47:11 --> Utf8 Class Initialized
INFO - 2016-01-26 14:47:11 --> URI Class Initialized
DEBUG - 2016-01-26 14:47:11 --> No URI present. Default controller set.
INFO - 2016-01-26 14:47:11 --> Router Class Initialized
INFO - 2016-01-26 14:47:11 --> Output Class Initialized
INFO - 2016-01-26 14:47:11 --> Security Class Initialized
DEBUG - 2016-01-26 14:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:47:11 --> Input Class Initialized
INFO - 2016-01-26 14:47:11 --> Language Class Initialized
INFO - 2016-01-26 14:47:11 --> Loader Class Initialized
INFO - 2016-01-26 14:47:11 --> Helper loaded: url_helper
INFO - 2016-01-26 14:47:11 --> Helper loaded: file_helper
INFO - 2016-01-26 14:47:11 --> Helper loaded: date_helper
INFO - 2016-01-26 14:47:11 --> Database Driver Class Initialized
INFO - 2016-01-26 14:47:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:47:12 --> Controller Class Initialized
INFO - 2016-01-26 14:47:12 --> Model Class Initialized
INFO - 2016-01-26 14:47:12 --> Model Class Initialized
INFO - 2016-01-26 14:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 14:47:12 --> Pagination Class Initialized
INFO - 2016-01-26 14:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 14:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 14:47:12 --> Final output sent to browser
DEBUG - 2016-01-26 14:47:12 --> Total execution time: 1.1302
INFO - 2016-01-26 14:47:14 --> Config Class Initialized
INFO - 2016-01-26 14:47:14 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:47:14 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:47:14 --> Utf8 Class Initialized
INFO - 2016-01-26 14:47:14 --> URI Class Initialized
INFO - 2016-01-26 14:47:14 --> Router Class Initialized
INFO - 2016-01-26 14:47:14 --> Output Class Initialized
INFO - 2016-01-26 14:47:14 --> Security Class Initialized
DEBUG - 2016-01-26 14:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:47:14 --> Input Class Initialized
INFO - 2016-01-26 14:47:14 --> Language Class Initialized
INFO - 2016-01-26 14:47:14 --> Loader Class Initialized
INFO - 2016-01-26 14:47:14 --> Helper loaded: url_helper
INFO - 2016-01-26 14:47:14 --> Helper loaded: file_helper
INFO - 2016-01-26 14:47:14 --> Helper loaded: date_helper
INFO - 2016-01-26 14:47:14 --> Database Driver Class Initialized
INFO - 2016-01-26 14:47:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:47:15 --> Controller Class Initialized
INFO - 2016-01-26 14:47:15 --> Model Class Initialized
INFO - 2016-01-26 14:47:15 --> Model Class Initialized
INFO - 2016-01-26 14:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 14:47:15 --> Pagination Class Initialized
INFO - 2016-01-26 14:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 14:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 14:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 14:47:15 --> Final output sent to browser
DEBUG - 2016-01-26 14:47:15 --> Total execution time: 1.1453
INFO - 2016-01-26 14:49:47 --> Config Class Initialized
INFO - 2016-01-26 14:49:47 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:49:47 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:49:47 --> Utf8 Class Initialized
INFO - 2016-01-26 14:49:47 --> URI Class Initialized
INFO - 2016-01-26 14:49:47 --> Router Class Initialized
INFO - 2016-01-26 14:49:47 --> Output Class Initialized
INFO - 2016-01-26 14:49:47 --> Security Class Initialized
DEBUG - 2016-01-26 14:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:49:47 --> Input Class Initialized
INFO - 2016-01-26 14:49:47 --> Language Class Initialized
INFO - 2016-01-26 14:49:47 --> Loader Class Initialized
INFO - 2016-01-26 14:49:47 --> Helper loaded: url_helper
INFO - 2016-01-26 14:49:47 --> Helper loaded: file_helper
INFO - 2016-01-26 14:49:47 --> Helper loaded: date_helper
INFO - 2016-01-26 14:49:47 --> Database Driver Class Initialized
INFO - 2016-01-26 14:49:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:49:48 --> Controller Class Initialized
INFO - 2016-01-26 14:49:48 --> Model Class Initialized
INFO - 2016-01-26 14:49:48 --> Model Class Initialized
INFO - 2016-01-26 14:49:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 14:49:48 --> Pagination Class Initialized
INFO - 2016-01-26 14:49:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 14:49:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 14:49:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 14:49:48 --> Final output sent to browser
DEBUG - 2016-01-26 14:49:48 --> Total execution time: 1.1382
INFO - 2016-01-26 14:59:45 --> Config Class Initialized
INFO - 2016-01-26 14:59:45 --> Hooks Class Initialized
DEBUG - 2016-01-26 14:59:45 --> UTF-8 Support Enabled
INFO - 2016-01-26 14:59:45 --> Utf8 Class Initialized
INFO - 2016-01-26 14:59:45 --> URI Class Initialized
DEBUG - 2016-01-26 14:59:45 --> No URI present. Default controller set.
INFO - 2016-01-26 14:59:45 --> Router Class Initialized
INFO - 2016-01-26 14:59:45 --> Output Class Initialized
INFO - 2016-01-26 14:59:45 --> Security Class Initialized
DEBUG - 2016-01-26 14:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 14:59:45 --> Input Class Initialized
INFO - 2016-01-26 14:59:45 --> Language Class Initialized
INFO - 2016-01-26 14:59:45 --> Loader Class Initialized
INFO - 2016-01-26 14:59:45 --> Helper loaded: url_helper
INFO - 2016-01-26 14:59:45 --> Helper loaded: file_helper
INFO - 2016-01-26 14:59:45 --> Helper loaded: date_helper
INFO - 2016-01-26 14:59:45 --> Database Driver Class Initialized
INFO - 2016-01-26 14:59:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 14:59:46 --> Controller Class Initialized
INFO - 2016-01-26 14:59:46 --> Model Class Initialized
INFO - 2016-01-26 14:59:46 --> Model Class Initialized
INFO - 2016-01-26 14:59:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 14:59:46 --> Pagination Class Initialized
INFO - 2016-01-26 14:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 14:59:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 14:59:46 --> Final output sent to browser
DEBUG - 2016-01-26 14:59:46 --> Total execution time: 1.1170
INFO - 2016-01-26 20:00:33 --> Config Class Initialized
INFO - 2016-01-26 20:00:33 --> Hooks Class Initialized
DEBUG - 2016-01-26 20:00:33 --> UTF-8 Support Enabled
INFO - 2016-01-26 20:00:33 --> Utf8 Class Initialized
INFO - 2016-01-26 20:00:33 --> URI Class Initialized
DEBUG - 2016-01-26 20:00:33 --> No URI present. Default controller set.
INFO - 2016-01-26 20:00:33 --> Router Class Initialized
INFO - 2016-01-26 20:00:33 --> Output Class Initialized
INFO - 2016-01-26 20:00:33 --> Security Class Initialized
DEBUG - 2016-01-26 20:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 20:00:33 --> Input Class Initialized
INFO - 2016-01-26 20:00:33 --> Language Class Initialized
INFO - 2016-01-26 20:00:33 --> Loader Class Initialized
INFO - 2016-01-26 20:00:33 --> Helper loaded: url_helper
INFO - 2016-01-26 20:00:33 --> Helper loaded: file_helper
INFO - 2016-01-26 20:00:33 --> Helper loaded: date_helper
INFO - 2016-01-26 20:00:33 --> Database Driver Class Initialized
INFO - 2016-01-26 20:00:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 20:00:34 --> Controller Class Initialized
INFO - 2016-01-26 20:00:34 --> Model Class Initialized
INFO - 2016-01-26 20:00:34 --> Model Class Initialized
INFO - 2016-01-26 20:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 20:00:34 --> Pagination Class Initialized
INFO - 2016-01-26 20:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 20:00:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 20:00:34 --> Final output sent to browser
DEBUG - 2016-01-26 20:00:34 --> Total execution time: 1.0921
INFO - 2016-01-26 20:00:41 --> Config Class Initialized
INFO - 2016-01-26 20:00:41 --> Hooks Class Initialized
DEBUG - 2016-01-26 20:00:41 --> UTF-8 Support Enabled
INFO - 2016-01-26 20:00:41 --> Utf8 Class Initialized
INFO - 2016-01-26 20:00:41 --> URI Class Initialized
INFO - 2016-01-26 20:00:41 --> Router Class Initialized
INFO - 2016-01-26 20:00:41 --> Output Class Initialized
INFO - 2016-01-26 20:00:41 --> Security Class Initialized
DEBUG - 2016-01-26 20:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 20:00:41 --> Input Class Initialized
INFO - 2016-01-26 20:00:41 --> Language Class Initialized
INFO - 2016-01-26 20:00:41 --> Loader Class Initialized
INFO - 2016-01-26 20:00:41 --> Helper loaded: url_helper
INFO - 2016-01-26 20:00:41 --> Helper loaded: file_helper
INFO - 2016-01-26 20:00:41 --> Helper loaded: date_helper
INFO - 2016-01-26 20:00:41 --> Database Driver Class Initialized
INFO - 2016-01-26 20:00:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 20:00:42 --> Controller Class Initialized
INFO - 2016-01-26 20:00:42 --> Model Class Initialized
INFO - 2016-01-26 20:00:42 --> Model Class Initialized
INFO - 2016-01-26 20:00:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 20:00:42 --> Pagination Class Initialized
INFO - 2016-01-26 20:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 20:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 20:00:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 20:00:42 --> Final output sent to browser
DEBUG - 2016-01-26 20:00:42 --> Total execution time: 1.1107
INFO - 2016-01-26 20:22:27 --> Config Class Initialized
INFO - 2016-01-26 20:22:27 --> Hooks Class Initialized
DEBUG - 2016-01-26 20:22:27 --> UTF-8 Support Enabled
INFO - 2016-01-26 20:22:27 --> Utf8 Class Initialized
INFO - 2016-01-26 20:22:27 --> URI Class Initialized
DEBUG - 2016-01-26 20:22:27 --> No URI present. Default controller set.
INFO - 2016-01-26 20:22:27 --> Router Class Initialized
INFO - 2016-01-26 20:22:27 --> Output Class Initialized
INFO - 2016-01-26 20:22:27 --> Security Class Initialized
DEBUG - 2016-01-26 20:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 20:22:27 --> Input Class Initialized
INFO - 2016-01-26 20:22:27 --> Language Class Initialized
INFO - 2016-01-26 20:22:27 --> Loader Class Initialized
INFO - 2016-01-26 20:22:27 --> Helper loaded: url_helper
INFO - 2016-01-26 20:22:27 --> Helper loaded: file_helper
INFO - 2016-01-26 20:22:27 --> Helper loaded: date_helper
INFO - 2016-01-26 20:22:27 --> Database Driver Class Initialized
INFO - 2016-01-26 20:22:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 20:22:28 --> Controller Class Initialized
INFO - 2016-01-26 20:22:28 --> Model Class Initialized
ERROR - 2016-01-26 20:22:28 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 52
INFO - 2016-01-26 20:22:44 --> Config Class Initialized
INFO - 2016-01-26 20:22:44 --> Hooks Class Initialized
DEBUG - 2016-01-26 20:22:44 --> UTF-8 Support Enabled
INFO - 2016-01-26 20:22:44 --> Utf8 Class Initialized
INFO - 2016-01-26 20:22:44 --> URI Class Initialized
INFO - 2016-01-26 20:22:44 --> Router Class Initialized
INFO - 2016-01-26 20:22:44 --> Output Class Initialized
INFO - 2016-01-26 20:22:44 --> Security Class Initialized
DEBUG - 2016-01-26 20:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 20:22:44 --> Input Class Initialized
INFO - 2016-01-26 20:22:44 --> Language Class Initialized
INFO - 2016-01-26 20:22:44 --> Loader Class Initialized
INFO - 2016-01-26 20:22:44 --> Helper loaded: url_helper
INFO - 2016-01-26 20:22:44 --> Helper loaded: file_helper
INFO - 2016-01-26 20:22:44 --> Helper loaded: date_helper
INFO - 2016-01-26 20:22:44 --> Database Driver Class Initialized
INFO - 2016-01-26 20:22:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 20:22:45 --> Controller Class Initialized
INFO - 2016-01-26 20:22:45 --> Model Class Initialized
INFO - 2016-01-26 20:22:45 --> Model Class Initialized
INFO - 2016-01-26 20:22:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 20:22:45 --> Pagination Class Initialized
INFO - 2016-01-26 20:22:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-26 20:22:46 --> Severity: Warning --> Illegal string offset 'board_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 52
ERROR - 2016-01-26 20:22:46 --> Severity: Warning --> Illegal string offset 'user_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
ERROR - 2016-01-26 20:22:46 --> Severity: Warning --> Illegal string offset 'user_name' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 54
ERROR - 2016-01-26 20:22:46 --> Severity: Warning --> Illegal string offset 'article' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 55
INFO - 2016-01-26 20:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 20:22:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 20:22:46 --> Final output sent to browser
DEBUG - 2016-01-26 20:22:46 --> Total execution time: 1.1519
INFO - 2016-01-26 20:23:18 --> Config Class Initialized
INFO - 2016-01-26 20:23:18 --> Hooks Class Initialized
DEBUG - 2016-01-26 20:23:18 --> UTF-8 Support Enabled
INFO - 2016-01-26 20:23:18 --> Utf8 Class Initialized
INFO - 2016-01-26 20:23:18 --> URI Class Initialized
DEBUG - 2016-01-26 20:23:18 --> No URI present. Default controller set.
INFO - 2016-01-26 20:23:18 --> Router Class Initialized
INFO - 2016-01-26 20:23:18 --> Output Class Initialized
INFO - 2016-01-26 20:23:18 --> Security Class Initialized
DEBUG - 2016-01-26 20:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 20:23:18 --> Input Class Initialized
INFO - 2016-01-26 20:23:18 --> Language Class Initialized
INFO - 2016-01-26 20:23:18 --> Loader Class Initialized
INFO - 2016-01-26 20:23:18 --> Helper loaded: url_helper
INFO - 2016-01-26 20:23:18 --> Helper loaded: file_helper
INFO - 2016-01-26 20:23:18 --> Helper loaded: date_helper
INFO - 2016-01-26 20:23:18 --> Database Driver Class Initialized
INFO - 2016-01-26 20:23:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 20:23:19 --> Controller Class Initialized
INFO - 2016-01-26 20:23:19 --> Model Class Initialized
INFO - 2016-01-26 20:23:19 --> Model Class Initialized
INFO - 2016-01-26 20:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 20:23:19 --> Pagination Class Initialized
INFO - 2016-01-26 20:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 20:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 20:23:19 --> Final output sent to browser
DEBUG - 2016-01-26 20:23:19 --> Total execution time: 1.1137
INFO - 2016-01-26 20:23:21 --> Config Class Initialized
INFO - 2016-01-26 20:23:21 --> Hooks Class Initialized
DEBUG - 2016-01-26 20:23:21 --> UTF-8 Support Enabled
INFO - 2016-01-26 20:23:21 --> Utf8 Class Initialized
INFO - 2016-01-26 20:23:21 --> URI Class Initialized
INFO - 2016-01-26 20:23:21 --> Router Class Initialized
INFO - 2016-01-26 20:23:21 --> Output Class Initialized
INFO - 2016-01-26 20:23:21 --> Security Class Initialized
DEBUG - 2016-01-26 20:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 20:23:21 --> Input Class Initialized
INFO - 2016-01-26 20:23:21 --> Language Class Initialized
INFO - 2016-01-26 20:23:21 --> Loader Class Initialized
INFO - 2016-01-26 20:23:21 --> Helper loaded: url_helper
INFO - 2016-01-26 20:23:21 --> Helper loaded: file_helper
INFO - 2016-01-26 20:23:21 --> Helper loaded: date_helper
INFO - 2016-01-26 20:23:21 --> Database Driver Class Initialized
INFO - 2016-01-26 20:23:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 20:23:22 --> Controller Class Initialized
INFO - 2016-01-26 20:23:22 --> Model Class Initialized
INFO - 2016-01-26 20:23:22 --> Model Class Initialized
INFO - 2016-01-26 20:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 20:23:22 --> Pagination Class Initialized
INFO - 2016-01-26 20:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-26 20:23:22 --> Severity: Warning --> Illegal string offset 'board_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 52
ERROR - 2016-01-26 20:23:22 --> Severity: Warning --> Illegal string offset 'user_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
ERROR - 2016-01-26 20:23:22 --> Severity: Warning --> Illegal string offset 'user_name' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 54
ERROR - 2016-01-26 20:23:22 --> Severity: Warning --> Illegal string offset 'article' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 55
INFO - 2016-01-26 20:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 20:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 20:23:22 --> Final output sent to browser
DEBUG - 2016-01-26 20:23:22 --> Total execution time: 1.1995
INFO - 2016-01-26 22:18:55 --> Config Class Initialized
INFO - 2016-01-26 22:18:55 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:18:55 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:18:55 --> Utf8 Class Initialized
INFO - 2016-01-26 22:18:55 --> URI Class Initialized
DEBUG - 2016-01-26 22:18:55 --> No URI present. Default controller set.
INFO - 2016-01-26 22:18:55 --> Router Class Initialized
INFO - 2016-01-26 22:18:55 --> Output Class Initialized
INFO - 2016-01-26 22:18:55 --> Security Class Initialized
DEBUG - 2016-01-26 22:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:18:55 --> Input Class Initialized
INFO - 2016-01-26 22:18:55 --> Language Class Initialized
INFO - 2016-01-26 22:18:55 --> Loader Class Initialized
INFO - 2016-01-26 22:18:55 --> Helper loaded: url_helper
INFO - 2016-01-26 22:18:55 --> Helper loaded: file_helper
INFO - 2016-01-26 22:18:55 --> Helper loaded: date_helper
INFO - 2016-01-26 22:18:55 --> Database Driver Class Initialized
INFO - 2016-01-26 22:18:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:18:56 --> Controller Class Initialized
INFO - 2016-01-26 22:18:56 --> Model Class Initialized
INFO - 2016-01-26 22:18:56 --> Model Class Initialized
INFO - 2016-01-26 22:18:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:18:56 --> Pagination Class Initialized
INFO - 2016-01-26 22:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:18:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 22:18:56 --> Final output sent to browser
DEBUG - 2016-01-26 22:18:56 --> Total execution time: 1.1169
INFO - 2016-01-26 22:18:58 --> Config Class Initialized
INFO - 2016-01-26 22:18:58 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:18:58 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:18:58 --> Utf8 Class Initialized
INFO - 2016-01-26 22:18:58 --> URI Class Initialized
INFO - 2016-01-26 22:18:58 --> Router Class Initialized
INFO - 2016-01-26 22:18:58 --> Output Class Initialized
INFO - 2016-01-26 22:18:58 --> Security Class Initialized
DEBUG - 2016-01-26 22:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:18:58 --> Input Class Initialized
INFO - 2016-01-26 22:18:58 --> Language Class Initialized
INFO - 2016-01-26 22:18:58 --> Loader Class Initialized
INFO - 2016-01-26 22:18:58 --> Helper loaded: url_helper
INFO - 2016-01-26 22:18:58 --> Helper loaded: file_helper
INFO - 2016-01-26 22:18:58 --> Helper loaded: date_helper
INFO - 2016-01-26 22:18:58 --> Database Driver Class Initialized
INFO - 2016-01-26 22:18:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:18:59 --> Controller Class Initialized
INFO - 2016-01-26 22:18:59 --> Model Class Initialized
INFO - 2016-01-26 22:18:59 --> Model Class Initialized
INFO - 2016-01-26 22:18:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:18:59 --> Pagination Class Initialized
INFO - 2016-01-26 22:18:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-26 22:18:59 --> Severity: Warning --> Illegal string offset 'board_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 52
ERROR - 2016-01-26 22:18:59 --> Severity: Warning --> Illegal string offset 'user_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
ERROR - 2016-01-26 22:18:59 --> Severity: Warning --> Illegal string offset 'user_name' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 54
ERROR - 2016-01-26 22:18:59 --> Severity: Warning --> Illegal string offset 'article' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 55
INFO - 2016-01-26 22:18:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:18:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:18:59 --> Final output sent to browser
DEBUG - 2016-01-26 22:18:59 --> Total execution time: 1.2159
INFO - 2016-01-26 22:19:16 --> Config Class Initialized
INFO - 2016-01-26 22:19:16 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:19:16 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:19:16 --> Utf8 Class Initialized
INFO - 2016-01-26 22:19:16 --> URI Class Initialized
DEBUG - 2016-01-26 22:19:16 --> No URI present. Default controller set.
INFO - 2016-01-26 22:19:16 --> Router Class Initialized
INFO - 2016-01-26 22:19:16 --> Output Class Initialized
INFO - 2016-01-26 22:19:16 --> Security Class Initialized
DEBUG - 2016-01-26 22:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:19:16 --> Input Class Initialized
INFO - 2016-01-26 22:19:16 --> Language Class Initialized
INFO - 2016-01-26 22:19:16 --> Loader Class Initialized
INFO - 2016-01-26 22:19:16 --> Helper loaded: url_helper
INFO - 2016-01-26 22:19:16 --> Helper loaded: file_helper
INFO - 2016-01-26 22:19:16 --> Helper loaded: date_helper
INFO - 2016-01-26 22:19:16 --> Database Driver Class Initialized
INFO - 2016-01-26 22:19:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:19:17 --> Controller Class Initialized
INFO - 2016-01-26 22:19:17 --> Model Class Initialized
INFO - 2016-01-26 22:19:17 --> Model Class Initialized
INFO - 2016-01-26 22:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:19:17 --> Pagination Class Initialized
INFO - 2016-01-26 22:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 22:19:17 --> Final output sent to browser
DEBUG - 2016-01-26 22:19:17 --> Total execution time: 1.1176
INFO - 2016-01-26 22:19:19 --> Config Class Initialized
INFO - 2016-01-26 22:19:19 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:19:19 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:19:19 --> Utf8 Class Initialized
INFO - 2016-01-26 22:19:19 --> URI Class Initialized
INFO - 2016-01-26 22:19:19 --> Router Class Initialized
INFO - 2016-01-26 22:19:19 --> Output Class Initialized
INFO - 2016-01-26 22:19:19 --> Security Class Initialized
DEBUG - 2016-01-26 22:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:19:19 --> Input Class Initialized
INFO - 2016-01-26 22:19:19 --> Language Class Initialized
INFO - 2016-01-26 22:19:19 --> Loader Class Initialized
INFO - 2016-01-26 22:19:19 --> Helper loaded: url_helper
INFO - 2016-01-26 22:19:19 --> Helper loaded: file_helper
INFO - 2016-01-26 22:19:19 --> Helper loaded: date_helper
INFO - 2016-01-26 22:19:19 --> Database Driver Class Initialized
INFO - 2016-01-26 22:19:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:19:20 --> Controller Class Initialized
INFO - 2016-01-26 22:19:20 --> Model Class Initialized
INFO - 2016-01-26 22:19:20 --> Model Class Initialized
INFO - 2016-01-26 22:19:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:19:20 --> Pagination Class Initialized
INFO - 2016-01-26 22:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-26 22:19:20 --> Severity: Warning --> Illegal string offset 'user_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
ERROR - 2016-01-26 22:19:20 --> Severity: Warning --> Illegal string offset 'user_name' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 54
ERROR - 2016-01-26 22:19:20 --> Severity: Warning --> Illegal string offset 'article' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 55
INFO - 2016-01-26 22:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:19:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:19:20 --> Final output sent to browser
DEBUG - 2016-01-26 22:19:20 --> Total execution time: 1.1572
INFO - 2016-01-26 22:19:52 --> Config Class Initialized
INFO - 2016-01-26 22:19:52 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:19:52 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:19:52 --> Utf8 Class Initialized
INFO - 2016-01-26 22:19:52 --> URI Class Initialized
DEBUG - 2016-01-26 22:19:52 --> No URI present. Default controller set.
INFO - 2016-01-26 22:19:52 --> Router Class Initialized
INFO - 2016-01-26 22:19:52 --> Output Class Initialized
INFO - 2016-01-26 22:19:52 --> Security Class Initialized
DEBUG - 2016-01-26 22:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:19:52 --> Input Class Initialized
INFO - 2016-01-26 22:19:52 --> Language Class Initialized
INFO - 2016-01-26 22:19:52 --> Loader Class Initialized
INFO - 2016-01-26 22:19:52 --> Helper loaded: url_helper
INFO - 2016-01-26 22:19:52 --> Helper loaded: file_helper
INFO - 2016-01-26 22:19:52 --> Helper loaded: date_helper
INFO - 2016-01-26 22:19:53 --> Database Driver Class Initialized
INFO - 2016-01-26 22:19:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:19:54 --> Controller Class Initialized
INFO - 2016-01-26 22:19:54 --> Model Class Initialized
INFO - 2016-01-26 22:19:54 --> Model Class Initialized
INFO - 2016-01-26 22:19:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:19:54 --> Pagination Class Initialized
INFO - 2016-01-26 22:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:19:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 22:19:54 --> Final output sent to browser
DEBUG - 2016-01-26 22:19:54 --> Total execution time: 1.1062
INFO - 2016-01-26 22:19:55 --> Config Class Initialized
INFO - 2016-01-26 22:19:55 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:19:55 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:19:55 --> Utf8 Class Initialized
INFO - 2016-01-26 22:19:55 --> URI Class Initialized
INFO - 2016-01-26 22:19:55 --> Router Class Initialized
INFO - 2016-01-26 22:19:55 --> Output Class Initialized
INFO - 2016-01-26 22:19:55 --> Security Class Initialized
DEBUG - 2016-01-26 22:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:19:55 --> Input Class Initialized
INFO - 2016-01-26 22:19:55 --> Language Class Initialized
INFO - 2016-01-26 22:19:55 --> Loader Class Initialized
INFO - 2016-01-26 22:19:55 --> Helper loaded: url_helper
INFO - 2016-01-26 22:19:55 --> Helper loaded: file_helper
INFO - 2016-01-26 22:19:55 --> Helper loaded: date_helper
INFO - 2016-01-26 22:19:55 --> Database Driver Class Initialized
INFO - 2016-01-26 22:19:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:19:56 --> Controller Class Initialized
INFO - 2016-01-26 22:19:56 --> Model Class Initialized
INFO - 2016-01-26 22:19:56 --> Model Class Initialized
INFO - 2016-01-26 22:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:19:56 --> Pagination Class Initialized
INFO - 2016-01-26 22:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-26 22:19:56 --> Severity: Warning --> Illegal string offset 'user_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
ERROR - 2016-01-26 22:19:56 --> Severity: Warning --> Illegal string offset 'user_name' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 54
ERROR - 2016-01-26 22:19:56 --> Severity: Warning --> Illegal string offset 'article' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 55
INFO - 2016-01-26 22:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:19:56 --> Final output sent to browser
DEBUG - 2016-01-26 22:19:56 --> Total execution time: 1.1645
INFO - 2016-01-26 22:21:19 --> Config Class Initialized
INFO - 2016-01-26 22:21:19 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:21:19 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:21:19 --> Utf8 Class Initialized
INFO - 2016-01-26 22:21:19 --> URI Class Initialized
DEBUG - 2016-01-26 22:21:19 --> No URI present. Default controller set.
INFO - 2016-01-26 22:21:19 --> Router Class Initialized
INFO - 2016-01-26 22:21:19 --> Output Class Initialized
INFO - 2016-01-26 22:21:19 --> Security Class Initialized
DEBUG - 2016-01-26 22:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:21:19 --> Input Class Initialized
INFO - 2016-01-26 22:21:19 --> Language Class Initialized
INFO - 2016-01-26 22:21:19 --> Loader Class Initialized
INFO - 2016-01-26 22:21:19 --> Helper loaded: url_helper
INFO - 2016-01-26 22:21:19 --> Helper loaded: file_helper
INFO - 2016-01-26 22:21:19 --> Helper loaded: date_helper
INFO - 2016-01-26 22:21:19 --> Database Driver Class Initialized
INFO - 2016-01-26 22:21:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:21:20 --> Controller Class Initialized
INFO - 2016-01-26 22:21:20 --> Model Class Initialized
INFO - 2016-01-26 22:21:20 --> Model Class Initialized
INFO - 2016-01-26 22:21:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:21:20 --> Pagination Class Initialized
INFO - 2016-01-26 22:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:21:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 22:21:20 --> Final output sent to browser
DEBUG - 2016-01-26 22:21:20 --> Total execution time: 1.1259
INFO - 2016-01-26 22:21:21 --> Config Class Initialized
INFO - 2016-01-26 22:21:21 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:21:21 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:21:21 --> Utf8 Class Initialized
INFO - 2016-01-26 22:21:21 --> URI Class Initialized
INFO - 2016-01-26 22:21:21 --> Router Class Initialized
INFO - 2016-01-26 22:21:21 --> Output Class Initialized
INFO - 2016-01-26 22:21:21 --> Security Class Initialized
DEBUG - 2016-01-26 22:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:21:21 --> Input Class Initialized
INFO - 2016-01-26 22:21:21 --> Language Class Initialized
INFO - 2016-01-26 22:21:21 --> Loader Class Initialized
INFO - 2016-01-26 22:21:21 --> Helper loaded: url_helper
INFO - 2016-01-26 22:21:21 --> Helper loaded: file_helper
INFO - 2016-01-26 22:21:21 --> Helper loaded: date_helper
INFO - 2016-01-26 22:21:21 --> Database Driver Class Initialized
INFO - 2016-01-26 22:21:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:21:22 --> Controller Class Initialized
INFO - 2016-01-26 22:21:22 --> Model Class Initialized
INFO - 2016-01-26 22:21:22 --> Model Class Initialized
INFO - 2016-01-26 22:21:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:21:22 --> Pagination Class Initialized
INFO - 2016-01-26 22:21:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-01-26 22:21:23 --> Severity: Warning --> Illegal string offset 'user_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
ERROR - 2016-01-26 22:21:23 --> Severity: Warning --> Illegal string offset 'user_name' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 54
ERROR - 2016-01-26 22:21:23 --> Severity: Warning --> Illegal string offset 'article' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 55
INFO - 2016-01-26 22:21:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:21:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:21:23 --> Final output sent to browser
DEBUG - 2016-01-26 22:21:23 --> Total execution time: 1.1729
INFO - 2016-01-26 22:21:59 --> Config Class Initialized
INFO - 2016-01-26 22:21:59 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:21:59 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:21:59 --> Utf8 Class Initialized
INFO - 2016-01-26 22:21:59 --> URI Class Initialized
DEBUG - 2016-01-26 22:21:59 --> No URI present. Default controller set.
INFO - 2016-01-26 22:21:59 --> Router Class Initialized
INFO - 2016-01-26 22:21:59 --> Output Class Initialized
INFO - 2016-01-26 22:21:59 --> Security Class Initialized
DEBUG - 2016-01-26 22:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:21:59 --> Input Class Initialized
INFO - 2016-01-26 22:21:59 --> Language Class Initialized
INFO - 2016-01-26 22:21:59 --> Loader Class Initialized
INFO - 2016-01-26 22:21:59 --> Helper loaded: url_helper
INFO - 2016-01-26 22:21:59 --> Helper loaded: file_helper
INFO - 2016-01-26 22:21:59 --> Helper loaded: date_helper
INFO - 2016-01-26 22:21:59 --> Database Driver Class Initialized
INFO - 2016-01-26 22:22:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:22:00 --> Controller Class Initialized
INFO - 2016-01-26 22:22:00 --> Model Class Initialized
INFO - 2016-01-26 22:22:00 --> Model Class Initialized
INFO - 2016-01-26 22:22:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:22:00 --> Pagination Class Initialized
INFO - 2016-01-26 22:22:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:22:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 22:22:00 --> Final output sent to browser
DEBUG - 2016-01-26 22:22:00 --> Total execution time: 1.1082
INFO - 2016-01-26 22:22:01 --> Config Class Initialized
INFO - 2016-01-26 22:22:01 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:22:01 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:22:01 --> Utf8 Class Initialized
INFO - 2016-01-26 22:22:01 --> URI Class Initialized
INFO - 2016-01-26 22:22:01 --> Router Class Initialized
INFO - 2016-01-26 22:22:01 --> Output Class Initialized
INFO - 2016-01-26 22:22:01 --> Security Class Initialized
DEBUG - 2016-01-26 22:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:22:01 --> Input Class Initialized
INFO - 2016-01-26 22:22:01 --> Language Class Initialized
INFO - 2016-01-26 22:22:01 --> Loader Class Initialized
INFO - 2016-01-26 22:22:01 --> Helper loaded: url_helper
INFO - 2016-01-26 22:22:01 --> Helper loaded: file_helper
INFO - 2016-01-26 22:22:01 --> Helper loaded: date_helper
INFO - 2016-01-26 22:22:01 --> Database Driver Class Initialized
INFO - 2016-01-26 22:22:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:22:02 --> Controller Class Initialized
INFO - 2016-01-26 22:22:02 --> Model Class Initialized
INFO - 2016-01-26 22:22:02 --> Model Class Initialized
INFO - 2016-01-26 22:22:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:22:02 --> Pagination Class Initialized
INFO - 2016-01-26 22:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:22:02 --> Final output sent to browser
DEBUG - 2016-01-26 22:22:02 --> Total execution time: 1.1413
INFO - 2016-01-26 22:29:11 --> Config Class Initialized
INFO - 2016-01-26 22:29:11 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:29:11 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:29:11 --> Utf8 Class Initialized
INFO - 2016-01-26 22:29:11 --> URI Class Initialized
INFO - 2016-01-26 22:29:11 --> Router Class Initialized
INFO - 2016-01-26 22:29:11 --> Output Class Initialized
INFO - 2016-01-26 22:29:11 --> Security Class Initialized
DEBUG - 2016-01-26 22:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:29:11 --> Input Class Initialized
INFO - 2016-01-26 22:29:11 --> Language Class Initialized
INFO - 2016-01-26 22:29:11 --> Loader Class Initialized
INFO - 2016-01-26 22:29:11 --> Helper loaded: url_helper
INFO - 2016-01-26 22:29:11 --> Helper loaded: file_helper
INFO - 2016-01-26 22:29:11 --> Helper loaded: date_helper
INFO - 2016-01-26 22:29:11 --> Database Driver Class Initialized
INFO - 2016-01-26 22:29:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:29:12 --> Controller Class Initialized
INFO - 2016-01-26 22:29:12 --> Model Class Initialized
INFO - 2016-01-26 22:29:12 --> Model Class Initialized
INFO - 2016-01-26 22:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:29:12 --> Pagination Class Initialized
INFO - 2016-01-26 22:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:29:18 --> Config Class Initialized
INFO - 2016-01-26 22:29:18 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:29:18 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:29:18 --> Utf8 Class Initialized
INFO - 2016-01-26 22:29:18 --> URI Class Initialized
DEBUG - 2016-01-26 22:29:18 --> No URI present. Default controller set.
INFO - 2016-01-26 22:29:18 --> Router Class Initialized
INFO - 2016-01-26 22:29:18 --> Output Class Initialized
INFO - 2016-01-26 22:29:18 --> Security Class Initialized
DEBUG - 2016-01-26 22:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:29:18 --> Input Class Initialized
INFO - 2016-01-26 22:29:18 --> Language Class Initialized
INFO - 2016-01-26 22:29:18 --> Loader Class Initialized
INFO - 2016-01-26 22:29:18 --> Helper loaded: url_helper
INFO - 2016-01-26 22:29:18 --> Helper loaded: file_helper
INFO - 2016-01-26 22:29:18 --> Helper loaded: date_helper
INFO - 2016-01-26 22:29:18 --> Database Driver Class Initialized
INFO - 2016-01-26 22:29:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:29:19 --> Controller Class Initialized
INFO - 2016-01-26 22:29:19 --> Model Class Initialized
INFO - 2016-01-26 22:29:19 --> Model Class Initialized
INFO - 2016-01-26 22:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:29:19 --> Pagination Class Initialized
INFO - 2016-01-26 22:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-01-26 22:29:19 --> Final output sent to browser
DEBUG - 2016-01-26 22:29:19 --> Total execution time: 1.1186
INFO - 2016-01-26 22:29:21 --> Config Class Initialized
INFO - 2016-01-26 22:29:21 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:29:21 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:29:21 --> Utf8 Class Initialized
INFO - 2016-01-26 22:29:21 --> URI Class Initialized
INFO - 2016-01-26 22:29:21 --> Router Class Initialized
INFO - 2016-01-26 22:29:21 --> Output Class Initialized
INFO - 2016-01-26 22:29:21 --> Security Class Initialized
DEBUG - 2016-01-26 22:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:29:21 --> Input Class Initialized
INFO - 2016-01-26 22:29:21 --> Language Class Initialized
INFO - 2016-01-26 22:29:21 --> Loader Class Initialized
INFO - 2016-01-26 22:29:21 --> Helper loaded: url_helper
INFO - 2016-01-26 22:29:21 --> Helper loaded: file_helper
INFO - 2016-01-26 22:29:21 --> Helper loaded: date_helper
INFO - 2016-01-26 22:29:21 --> Database Driver Class Initialized
INFO - 2016-01-26 22:29:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:29:22 --> Controller Class Initialized
INFO - 2016-01-26 22:29:22 --> Model Class Initialized
INFO - 2016-01-26 22:29:22 --> Model Class Initialized
INFO - 2016-01-26 22:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:29:22 --> Pagination Class Initialized
INFO - 2016-01-26 22:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:29:44 --> Config Class Initialized
INFO - 2016-01-26 22:29:44 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:29:44 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:29:44 --> Utf8 Class Initialized
INFO - 2016-01-26 22:29:44 --> URI Class Initialized
INFO - 2016-01-26 22:29:44 --> Router Class Initialized
INFO - 2016-01-26 22:29:44 --> Output Class Initialized
INFO - 2016-01-26 22:29:44 --> Security Class Initialized
DEBUG - 2016-01-26 22:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:29:44 --> Input Class Initialized
INFO - 2016-01-26 22:29:44 --> Language Class Initialized
INFO - 2016-01-26 22:29:44 --> Loader Class Initialized
INFO - 2016-01-26 22:29:44 --> Helper loaded: url_helper
INFO - 2016-01-26 22:29:44 --> Helper loaded: file_helper
INFO - 2016-01-26 22:29:44 --> Helper loaded: date_helper
INFO - 2016-01-26 22:29:44 --> Database Driver Class Initialized
INFO - 2016-01-26 22:29:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:29:45 --> Controller Class Initialized
INFO - 2016-01-26 22:29:45 --> Model Class Initialized
INFO - 2016-01-26 22:29:45 --> Model Class Initialized
INFO - 2016-01-26 22:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:29:45 --> Pagination Class Initialized
INFO - 2016-01-26 22:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-01-26 22:29:45 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\comment_list.php 11
INFO - 2016-01-26 22:30:01 --> Config Class Initialized
INFO - 2016-01-26 22:30:01 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:30:01 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:30:01 --> Utf8 Class Initialized
INFO - 2016-01-26 22:30:01 --> URI Class Initialized
INFO - 2016-01-26 22:30:01 --> Router Class Initialized
INFO - 2016-01-26 22:30:01 --> Output Class Initialized
INFO - 2016-01-26 22:30:01 --> Security Class Initialized
DEBUG - 2016-01-26 22:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:30:01 --> Input Class Initialized
INFO - 2016-01-26 22:30:01 --> Language Class Initialized
INFO - 2016-01-26 22:30:01 --> Loader Class Initialized
INFO - 2016-01-26 22:30:01 --> Helper loaded: url_helper
INFO - 2016-01-26 22:30:01 --> Helper loaded: file_helper
INFO - 2016-01-26 22:30:01 --> Helper loaded: date_helper
INFO - 2016-01-26 22:30:01 --> Database Driver Class Initialized
INFO - 2016-01-26 22:30:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:30:02 --> Controller Class Initialized
INFO - 2016-01-26 22:30:02 --> Model Class Initialized
INFO - 2016-01-26 22:30:02 --> Model Class Initialized
INFO - 2016-01-26 22:30:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:30:02 --> Pagination Class Initialized
INFO - 2016-01-26 22:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\comment_list.php
INFO - 2016-01-26 22:30:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:30:02 --> Final output sent to browser
DEBUG - 2016-01-26 22:30:02 --> Total execution time: 1.1470
INFO - 2016-01-26 22:30:32 --> Config Class Initialized
INFO - 2016-01-26 22:30:32 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:30:32 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:30:32 --> Utf8 Class Initialized
INFO - 2016-01-26 22:30:32 --> URI Class Initialized
INFO - 2016-01-26 22:30:32 --> Router Class Initialized
INFO - 2016-01-26 22:30:32 --> Output Class Initialized
INFO - 2016-01-26 22:30:32 --> Security Class Initialized
DEBUG - 2016-01-26 22:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:30:32 --> Input Class Initialized
INFO - 2016-01-26 22:30:32 --> Language Class Initialized
INFO - 2016-01-26 22:30:33 --> Loader Class Initialized
INFO - 2016-01-26 22:30:33 --> Helper loaded: url_helper
INFO - 2016-01-26 22:30:33 --> Helper loaded: file_helper
INFO - 2016-01-26 22:30:33 --> Helper loaded: date_helper
INFO - 2016-01-26 22:30:33 --> Database Driver Class Initialized
INFO - 2016-01-26 22:30:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:30:34 --> Controller Class Initialized
INFO - 2016-01-26 22:30:34 --> Model Class Initialized
INFO - 2016-01-26 22:30:34 --> Model Class Initialized
INFO - 2016-01-26 22:30:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:30:34 --> Pagination Class Initialized
INFO - 2016-01-26 22:30:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:30:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:30:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:30:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\comment_list.php
INFO - 2016-01-26 22:30:34 --> Final output sent to browser
DEBUG - 2016-01-26 22:30:34 --> Total execution time: 1.2478
INFO - 2016-01-26 22:45:03 --> Config Class Initialized
INFO - 2016-01-26 22:45:03 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:45:03 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:45:03 --> Utf8 Class Initialized
INFO - 2016-01-26 22:45:03 --> URI Class Initialized
INFO - 2016-01-26 22:45:03 --> Router Class Initialized
INFO - 2016-01-26 22:45:03 --> Output Class Initialized
INFO - 2016-01-26 22:45:03 --> Security Class Initialized
DEBUG - 2016-01-26 22:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:45:03 --> Input Class Initialized
INFO - 2016-01-26 22:45:03 --> Language Class Initialized
INFO - 2016-01-26 22:45:03 --> Loader Class Initialized
INFO - 2016-01-26 22:45:03 --> Helper loaded: url_helper
INFO - 2016-01-26 22:45:03 --> Helper loaded: file_helper
INFO - 2016-01-26 22:45:03 --> Helper loaded: date_helper
INFO - 2016-01-26 22:45:03 --> Database Driver Class Initialized
INFO - 2016-01-26 22:45:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:45:04 --> Controller Class Initialized
INFO - 2016-01-26 22:45:04 --> Model Class Initialized
INFO - 2016-01-26 22:45:04 --> Model Class Initialized
INFO - 2016-01-26 22:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:45:04 --> Pagination Class Initialized
INFO - 2016-01-26 22:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\comment_list.php
INFO - 2016-01-26 22:45:04 --> Final output sent to browser
DEBUG - 2016-01-26 22:45:04 --> Total execution time: 1.1873
INFO - 2016-01-26 22:46:54 --> Config Class Initialized
INFO - 2016-01-26 22:46:54 --> Hooks Class Initialized
DEBUG - 2016-01-26 22:46:54 --> UTF-8 Support Enabled
INFO - 2016-01-26 22:46:54 --> Utf8 Class Initialized
INFO - 2016-01-26 22:46:54 --> URI Class Initialized
INFO - 2016-01-26 22:46:54 --> Router Class Initialized
INFO - 2016-01-26 22:46:54 --> Output Class Initialized
INFO - 2016-01-26 22:46:54 --> Security Class Initialized
DEBUG - 2016-01-26 22:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-01-26 22:46:54 --> Input Class Initialized
INFO - 2016-01-26 22:46:54 --> Language Class Initialized
INFO - 2016-01-26 22:46:54 --> Loader Class Initialized
INFO - 2016-01-26 22:46:54 --> Helper loaded: url_helper
INFO - 2016-01-26 22:46:54 --> Helper loaded: file_helper
INFO - 2016-01-26 22:46:54 --> Helper loaded: date_helper
INFO - 2016-01-26 22:46:54 --> Database Driver Class Initialized
INFO - 2016-01-26 22:46:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-01-26 22:46:55 --> Controller Class Initialized
INFO - 2016-01-26 22:46:55 --> Model Class Initialized
INFO - 2016-01-26 22:46:55 --> Model Class Initialized
INFO - 2016-01-26 22:46:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-01-26 22:46:55 --> Pagination Class Initialized
INFO - 2016-01-26 22:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-01-26 22:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-01-26 22:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-01-26 22:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\comment_list.php
INFO - 2016-01-26 22:46:55 --> Final output sent to browser
DEBUG - 2016-01-26 22:46:55 --> Total execution time: 1.2459
