<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-05 06:16:04 --> Config Class Initialized
INFO - 2016-02-05 06:16:04 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:16:04 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:16:04 --> Utf8 Class Initialized
INFO - 2016-02-05 06:16:04 --> URI Class Initialized
INFO - 2016-02-05 06:16:04 --> Router Class Initialized
INFO - 2016-02-05 06:16:04 --> Output Class Initialized
INFO - 2016-02-05 06:16:04 --> Security Class Initialized
DEBUG - 2016-02-05 06:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:16:04 --> Input Class Initialized
INFO - 2016-02-05 06:16:04 --> Language Class Initialized
ERROR - 2016-02-05 06:16:04 --> 404 Page Not Found: Ajax/index
INFO - 2016-02-05 06:16:13 --> Config Class Initialized
INFO - 2016-02-05 06:16:13 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:16:13 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:16:13 --> Utf8 Class Initialized
INFO - 2016-02-05 06:16:13 --> URI Class Initialized
INFO - 2016-02-05 06:16:13 --> Router Class Initialized
INFO - 2016-02-05 06:16:13 --> Output Class Initialized
INFO - 2016-02-05 06:16:13 --> Security Class Initialized
DEBUG - 2016-02-05 06:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:16:13 --> Input Class Initialized
INFO - 2016-02-05 06:16:13 --> Language Class Initialized
ERROR - 2016-02-05 06:16:13 --> 404 Page Not Found: Ajax/index
INFO - 2016-02-05 06:16:36 --> Config Class Initialized
INFO - 2016-02-05 06:16:36 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:16:36 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:16:36 --> Utf8 Class Initialized
INFO - 2016-02-05 06:16:36 --> URI Class Initialized
INFO - 2016-02-05 06:16:36 --> Router Class Initialized
INFO - 2016-02-05 06:16:36 --> Output Class Initialized
INFO - 2016-02-05 06:16:36 --> Security Class Initialized
DEBUG - 2016-02-05 06:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:16:36 --> Input Class Initialized
INFO - 2016-02-05 06:16:36 --> Language Class Initialized
ERROR - 2016-02-05 06:16:36 --> 404 Page Not Found: Ajax/index
INFO - 2016-02-05 06:17:02 --> Config Class Initialized
INFO - 2016-02-05 06:17:02 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:17:02 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:17:02 --> Utf8 Class Initialized
INFO - 2016-02-05 06:17:02 --> URI Class Initialized
INFO - 2016-02-05 06:17:02 --> Router Class Initialized
INFO - 2016-02-05 06:17:02 --> Output Class Initialized
INFO - 2016-02-05 06:17:02 --> Security Class Initialized
DEBUG - 2016-02-05 06:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:17:02 --> Input Class Initialized
INFO - 2016-02-05 06:17:02 --> Language Class Initialized
ERROR - 2016-02-05 06:17:02 --> 404 Page Not Found: Ajax/index
INFO - 2016-02-05 06:18:02 --> Config Class Initialized
INFO - 2016-02-05 06:18:02 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:18:02 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:18:02 --> Utf8 Class Initialized
INFO - 2016-02-05 06:18:02 --> URI Class Initialized
INFO - 2016-02-05 06:18:02 --> Router Class Initialized
INFO - 2016-02-05 06:18:02 --> Output Class Initialized
INFO - 2016-02-05 06:18:02 --> Security Class Initialized
DEBUG - 2016-02-05 06:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:18:02 --> Input Class Initialized
INFO - 2016-02-05 06:18:02 --> Language Class Initialized
ERROR - 2016-02-05 06:18:02 --> 404 Page Not Found: Ajax/index
INFO - 2016-02-05 06:19:55 --> Config Class Initialized
INFO - 2016-02-05 06:19:55 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:19:55 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:19:55 --> Utf8 Class Initialized
INFO - 2016-02-05 06:19:55 --> URI Class Initialized
INFO - 2016-02-05 06:19:55 --> Router Class Initialized
INFO - 2016-02-05 06:19:55 --> Output Class Initialized
INFO - 2016-02-05 06:19:55 --> Security Class Initialized
DEBUG - 2016-02-05 06:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:19:55 --> Input Class Initialized
INFO - 2016-02-05 06:19:55 --> Language Class Initialized
ERROR - 2016-02-05 06:19:55 --> 404 Page Not Found: Ajax/index
INFO - 2016-02-05 06:19:56 --> Config Class Initialized
INFO - 2016-02-05 06:19:56 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:19:56 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:19:56 --> Utf8 Class Initialized
INFO - 2016-02-05 06:19:56 --> URI Class Initialized
INFO - 2016-02-05 06:19:56 --> Router Class Initialized
INFO - 2016-02-05 06:19:56 --> Output Class Initialized
INFO - 2016-02-05 06:19:56 --> Security Class Initialized
DEBUG - 2016-02-05 06:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:19:56 --> Input Class Initialized
INFO - 2016-02-05 06:19:56 --> Language Class Initialized
ERROR - 2016-02-05 06:19:56 --> 404 Page Not Found: Ajax/index
INFO - 2016-02-05 06:20:00 --> Config Class Initialized
INFO - 2016-02-05 06:20:00 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:20:00 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:20:00 --> Utf8 Class Initialized
INFO - 2016-02-05 06:20:00 --> URI Class Initialized
INFO - 2016-02-05 06:20:00 --> Router Class Initialized
INFO - 2016-02-05 06:20:00 --> Output Class Initialized
INFO - 2016-02-05 06:20:00 --> Security Class Initialized
DEBUG - 2016-02-05 06:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:20:00 --> Input Class Initialized
INFO - 2016-02-05 06:20:00 --> Language Class Initialized
ERROR - 2016-02-05 06:20:00 --> 404 Page Not Found: Ajax/index
INFO - 2016-02-05 06:21:02 --> Config Class Initialized
INFO - 2016-02-05 06:21:02 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:21:02 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:21:02 --> Utf8 Class Initialized
INFO - 2016-02-05 06:21:02 --> URI Class Initialized
INFO - 2016-02-05 06:21:02 --> Router Class Initialized
INFO - 2016-02-05 06:21:02 --> Output Class Initialized
INFO - 2016-02-05 06:21:02 --> Security Class Initialized
DEBUG - 2016-02-05 06:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:21:02 --> Input Class Initialized
INFO - 2016-02-05 06:21:02 --> Language Class Initialized
INFO - 2016-02-05 06:21:02 --> Loader Class Initialized
INFO - 2016-02-05 06:21:02 --> Helper loaded: url_helper
INFO - 2016-02-05 06:21:02 --> Helper loaded: file_helper
INFO - 2016-02-05 06:21:02 --> Helper loaded: date_helper
INFO - 2016-02-05 06:21:02 --> Helper loaded: form_helper
INFO - 2016-02-05 06:21:02 --> Database Driver Class Initialized
INFO - 2016-02-05 06:21:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 06:21:03 --> Controller Class Initialized
INFO - 2016-02-05 06:21:03 --> Model Class Initialized
INFO - 2016-02-05 06:21:03 --> Model Class Initialized
INFO - 2016-02-05 06:21:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 06:21:03 --> Pagination Class Initialized
INFO - 2016-02-05 06:21:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\ajax_post_view.php
INFO - 2016-02-05 06:21:03 --> Final output sent to browser
DEBUG - 2016-02-05 06:21:03 --> Total execution time: 1.1762
INFO - 2016-02-05 06:21:03 --> Config Class Initialized
INFO - 2016-02-05 06:21:03 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:21:03 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:21:03 --> Utf8 Class Initialized
INFO - 2016-02-05 06:21:03 --> URI Class Initialized
INFO - 2016-02-05 06:21:03 --> Router Class Initialized
INFO - 2016-02-05 06:21:03 --> Output Class Initialized
INFO - 2016-02-05 06:21:03 --> Security Class Initialized
DEBUG - 2016-02-05 06:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:21:03 --> Input Class Initialized
INFO - 2016-02-05 06:21:03 --> Language Class Initialized
ERROR - 2016-02-05 06:21:03 --> 404 Page Not Found: Css/style.css
INFO - 2016-02-05 06:21:19 --> Config Class Initialized
INFO - 2016-02-05 06:21:19 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:21:19 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:21:19 --> Utf8 Class Initialized
INFO - 2016-02-05 06:21:19 --> URI Class Initialized
INFO - 2016-02-05 06:21:19 --> Router Class Initialized
INFO - 2016-02-05 06:21:19 --> Output Class Initialized
INFO - 2016-02-05 06:21:19 --> Security Class Initialized
DEBUG - 2016-02-05 06:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:21:19 --> Input Class Initialized
INFO - 2016-02-05 06:21:19 --> Language Class Initialized
ERROR - 2016-02-05 06:21:19 --> 404 Page Not Found: Ajax_post_controller/user_data_submit
INFO - 2016-02-05 06:22:15 --> Config Class Initialized
INFO - 2016-02-05 06:22:15 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:22:15 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:22:15 --> Utf8 Class Initialized
INFO - 2016-02-05 06:22:15 --> URI Class Initialized
INFO - 2016-02-05 06:22:15 --> Router Class Initialized
INFO - 2016-02-05 06:22:15 --> Output Class Initialized
INFO - 2016-02-05 06:22:15 --> Security Class Initialized
DEBUG - 2016-02-05 06:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:22:15 --> Input Class Initialized
INFO - 2016-02-05 06:22:15 --> Language Class Initialized
INFO - 2016-02-05 06:22:15 --> Loader Class Initialized
INFO - 2016-02-05 06:22:15 --> Helper loaded: url_helper
INFO - 2016-02-05 06:22:15 --> Helper loaded: file_helper
INFO - 2016-02-05 06:22:15 --> Helper loaded: date_helper
INFO - 2016-02-05 06:22:15 --> Helper loaded: form_helper
INFO - 2016-02-05 06:22:15 --> Database Driver Class Initialized
INFO - 2016-02-05 06:22:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 06:22:16 --> Controller Class Initialized
INFO - 2016-02-05 06:22:16 --> Model Class Initialized
INFO - 2016-02-05 06:22:16 --> Model Class Initialized
INFO - 2016-02-05 06:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 06:22:16 --> Pagination Class Initialized
INFO - 2016-02-05 06:22:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\ajax_post_view.php
INFO - 2016-02-05 06:22:16 --> Final output sent to browser
DEBUG - 2016-02-05 06:22:16 --> Total execution time: 1.1473
INFO - 2016-02-05 06:22:16 --> Config Class Initialized
INFO - 2016-02-05 06:22:16 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:22:16 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:22:16 --> Utf8 Class Initialized
INFO - 2016-02-05 06:22:16 --> URI Class Initialized
INFO - 2016-02-05 06:22:16 --> Router Class Initialized
INFO - 2016-02-05 06:22:16 --> Output Class Initialized
INFO - 2016-02-05 06:22:16 --> Security Class Initialized
DEBUG - 2016-02-05 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:22:16 --> Input Class Initialized
INFO - 2016-02-05 06:22:16 --> Language Class Initialized
ERROR - 2016-02-05 06:22:16 --> 404 Page Not Found: Css/style.css
INFO - 2016-02-05 06:22:23 --> Config Class Initialized
INFO - 2016-02-05 06:22:23 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:22:23 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:22:23 --> Utf8 Class Initialized
INFO - 2016-02-05 06:22:23 --> URI Class Initialized
INFO - 2016-02-05 06:22:23 --> Router Class Initialized
INFO - 2016-02-05 06:22:23 --> Output Class Initialized
INFO - 2016-02-05 06:22:23 --> Security Class Initialized
DEBUG - 2016-02-05 06:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:22:23 --> Input Class Initialized
INFO - 2016-02-05 06:22:23 --> Language Class Initialized
INFO - 2016-02-05 06:22:23 --> Loader Class Initialized
INFO - 2016-02-05 06:22:23 --> Helper loaded: url_helper
INFO - 2016-02-05 06:22:23 --> Helper loaded: file_helper
INFO - 2016-02-05 06:22:23 --> Helper loaded: date_helper
INFO - 2016-02-05 06:22:23 --> Helper loaded: form_helper
INFO - 2016-02-05 06:22:23 --> Database Driver Class Initialized
INFO - 2016-02-05 06:22:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 06:22:24 --> Controller Class Initialized
INFO - 2016-02-05 06:22:24 --> Model Class Initialized
INFO - 2016-02-05 06:22:24 --> Model Class Initialized
INFO - 2016-02-05 06:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 06:22:24 --> Pagination Class Initialized
INFO - 2016-02-05 06:22:24 --> Final output sent to browser
DEBUG - 2016-02-05 06:22:24 --> Total execution time: 1.1067
INFO - 2016-02-05 06:40:16 --> Config Class Initialized
INFO - 2016-02-05 06:40:16 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:40:16 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:40:16 --> Utf8 Class Initialized
INFO - 2016-02-05 06:40:16 --> URI Class Initialized
DEBUG - 2016-02-05 06:40:16 --> No URI present. Default controller set.
INFO - 2016-02-05 06:40:16 --> Router Class Initialized
INFO - 2016-02-05 06:40:16 --> Output Class Initialized
INFO - 2016-02-05 06:40:16 --> Security Class Initialized
DEBUG - 2016-02-05 06:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:40:16 --> Input Class Initialized
INFO - 2016-02-05 06:40:16 --> Language Class Initialized
INFO - 2016-02-05 06:40:16 --> Loader Class Initialized
INFO - 2016-02-05 06:40:16 --> Helper loaded: url_helper
INFO - 2016-02-05 06:40:16 --> Helper loaded: file_helper
INFO - 2016-02-05 06:40:16 --> Helper loaded: date_helper
INFO - 2016-02-05 06:40:16 --> Helper loaded: form_helper
INFO - 2016-02-05 06:40:16 --> Database Driver Class Initialized
INFO - 2016-02-05 06:40:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 06:40:17 --> Controller Class Initialized
INFO - 2016-02-05 06:40:17 --> Model Class Initialized
INFO - 2016-02-05 06:40:17 --> Model Class Initialized
INFO - 2016-02-05 06:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 06:40:17 --> Pagination Class Initialized
INFO - 2016-02-05 06:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 06:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 06:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 06:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 06:40:17 --> Final output sent to browser
DEBUG - 2016-02-05 06:40:17 --> Total execution time: 1.1243
INFO - 2016-02-05 06:40:19 --> Config Class Initialized
INFO - 2016-02-05 06:40:19 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:40:19 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:40:19 --> Utf8 Class Initialized
INFO - 2016-02-05 06:40:19 --> URI Class Initialized
INFO - 2016-02-05 06:40:19 --> Router Class Initialized
INFO - 2016-02-05 06:40:19 --> Output Class Initialized
INFO - 2016-02-05 06:40:19 --> Security Class Initialized
DEBUG - 2016-02-05 06:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:40:19 --> Input Class Initialized
INFO - 2016-02-05 06:40:19 --> Language Class Initialized
INFO - 2016-02-05 06:40:19 --> Loader Class Initialized
INFO - 2016-02-05 06:40:19 --> Helper loaded: url_helper
INFO - 2016-02-05 06:40:19 --> Helper loaded: file_helper
INFO - 2016-02-05 06:40:19 --> Helper loaded: date_helper
INFO - 2016-02-05 06:40:19 --> Helper loaded: form_helper
INFO - 2016-02-05 06:40:19 --> Database Driver Class Initialized
INFO - 2016-02-05 06:40:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 06:40:20 --> Controller Class Initialized
INFO - 2016-02-05 06:40:20 --> Model Class Initialized
INFO - 2016-02-05 06:40:20 --> Model Class Initialized
INFO - 2016-02-05 06:40:20 --> Form Validation Class Initialized
INFO - 2016-02-05 06:40:20 --> Helper loaded: text_helper
INFO - 2016-02-05 06:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 06:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 06:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 06:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 06:40:20 --> Final output sent to browser
DEBUG - 2016-02-05 06:40:20 --> Total execution time: 1.1202
INFO - 2016-02-05 06:43:13 --> Config Class Initialized
INFO - 2016-02-05 06:43:13 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:43:13 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:43:13 --> Utf8 Class Initialized
INFO - 2016-02-05 06:43:13 --> URI Class Initialized
INFO - 2016-02-05 06:43:13 --> Router Class Initialized
INFO - 2016-02-05 06:43:13 --> Output Class Initialized
INFO - 2016-02-05 06:43:13 --> Security Class Initialized
DEBUG - 2016-02-05 06:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:43:13 --> Input Class Initialized
INFO - 2016-02-05 06:43:13 --> Language Class Initialized
INFO - 2016-02-05 06:43:13 --> Loader Class Initialized
INFO - 2016-02-05 06:43:13 --> Helper loaded: url_helper
INFO - 2016-02-05 06:43:13 --> Helper loaded: file_helper
INFO - 2016-02-05 06:43:13 --> Helper loaded: date_helper
INFO - 2016-02-05 06:43:13 --> Helper loaded: form_helper
INFO - 2016-02-05 06:43:13 --> Database Driver Class Initialized
INFO - 2016-02-05 06:43:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 06:43:14 --> Controller Class Initialized
INFO - 2016-02-05 06:43:14 --> Model Class Initialized
INFO - 2016-02-05 06:43:14 --> Model Class Initialized
INFO - 2016-02-05 06:43:14 --> Form Validation Class Initialized
INFO - 2016-02-05 06:43:14 --> Helper loaded: text_helper
INFO - 2016-02-05 06:43:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 06:43:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 06:43:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 06:43:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 06:43:14 --> Final output sent to browser
DEBUG - 2016-02-05 06:43:14 --> Total execution time: 1.1427
INFO - 2016-02-05 06:43:22 --> Config Class Initialized
INFO - 2016-02-05 06:43:22 --> Hooks Class Initialized
DEBUG - 2016-02-05 06:43:22 --> UTF-8 Support Enabled
INFO - 2016-02-05 06:43:22 --> Utf8 Class Initialized
INFO - 2016-02-05 06:43:22 --> URI Class Initialized
INFO - 2016-02-05 06:43:22 --> Router Class Initialized
INFO - 2016-02-05 06:43:22 --> Output Class Initialized
INFO - 2016-02-05 06:43:22 --> Security Class Initialized
DEBUG - 2016-02-05 06:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 06:43:22 --> Input Class Initialized
INFO - 2016-02-05 06:43:22 --> Language Class Initialized
INFO - 2016-02-05 06:43:22 --> Loader Class Initialized
INFO - 2016-02-05 06:43:22 --> Helper loaded: url_helper
INFO - 2016-02-05 06:43:22 --> Helper loaded: file_helper
INFO - 2016-02-05 06:43:22 --> Helper loaded: date_helper
INFO - 2016-02-05 06:43:22 --> Helper loaded: form_helper
INFO - 2016-02-05 06:43:22 --> Database Driver Class Initialized
INFO - 2016-02-05 06:43:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 06:43:23 --> Controller Class Initialized
INFO - 2016-02-05 06:43:23 --> Model Class Initialized
INFO - 2016-02-05 06:43:23 --> Model Class Initialized
INFO - 2016-02-05 06:43:23 --> Form Validation Class Initialized
INFO - 2016-02-05 06:43:23 --> Helper loaded: text_helper
INFO - 2016-02-05 06:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 06:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 06:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 06:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 06:43:23 --> Final output sent to browser
DEBUG - 2016-02-05 06:43:23 --> Total execution time: 1.1398
INFO - 2016-02-05 07:00:53 --> Config Class Initialized
INFO - 2016-02-05 07:00:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:00:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:00:53 --> Utf8 Class Initialized
INFO - 2016-02-05 07:00:53 --> URI Class Initialized
INFO - 2016-02-05 07:00:53 --> Router Class Initialized
INFO - 2016-02-05 07:00:53 --> Output Class Initialized
INFO - 2016-02-05 07:00:53 --> Security Class Initialized
DEBUG - 2016-02-05 07:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:00:53 --> Input Class Initialized
INFO - 2016-02-05 07:00:53 --> Language Class Initialized
INFO - 2016-02-05 07:00:53 --> Loader Class Initialized
INFO - 2016-02-05 07:00:53 --> Helper loaded: url_helper
INFO - 2016-02-05 07:00:53 --> Helper loaded: file_helper
INFO - 2016-02-05 07:00:53 --> Helper loaded: date_helper
INFO - 2016-02-05 07:00:53 --> Helper loaded: form_helper
INFO - 2016-02-05 07:00:53 --> Database Driver Class Initialized
INFO - 2016-02-05 07:00:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:00:54 --> Controller Class Initialized
INFO - 2016-02-05 07:00:54 --> Model Class Initialized
INFO - 2016-02-05 07:00:54 --> Model Class Initialized
INFO - 2016-02-05 07:00:54 --> Form Validation Class Initialized
INFO - 2016-02-05 07:00:54 --> Helper loaded: text_helper
INFO - 2016-02-05 07:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:00:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:00:54 --> Final output sent to browser
DEBUG - 2016-02-05 07:00:54 --> Total execution time: 1.1491
INFO - 2016-02-05 07:01:01 --> Config Class Initialized
INFO - 2016-02-05 07:01:01 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:01:01 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:01:01 --> Utf8 Class Initialized
INFO - 2016-02-05 07:01:01 --> URI Class Initialized
INFO - 2016-02-05 07:01:01 --> Router Class Initialized
INFO - 2016-02-05 07:01:01 --> Output Class Initialized
INFO - 2016-02-05 07:01:01 --> Security Class Initialized
DEBUG - 2016-02-05 07:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:01:01 --> Input Class Initialized
INFO - 2016-02-05 07:01:01 --> Language Class Initialized
INFO - 2016-02-05 07:01:01 --> Loader Class Initialized
INFO - 2016-02-05 07:01:01 --> Helper loaded: url_helper
INFO - 2016-02-05 07:01:01 --> Helper loaded: file_helper
INFO - 2016-02-05 07:01:01 --> Helper loaded: date_helper
INFO - 2016-02-05 07:01:01 --> Helper loaded: form_helper
INFO - 2016-02-05 07:01:01 --> Database Driver Class Initialized
INFO - 2016-02-05 07:01:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:01:02 --> Controller Class Initialized
INFO - 2016-02-05 07:01:02 --> Model Class Initialized
INFO - 2016-02-05 07:01:02 --> Model Class Initialized
INFO - 2016-02-05 07:01:02 --> Form Validation Class Initialized
INFO - 2016-02-05 07:01:02 --> Helper loaded: text_helper
INFO - 2016-02-05 07:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:01:02 --> Final output sent to browser
DEBUG - 2016-02-05 07:01:02 --> Total execution time: 1.1191
INFO - 2016-02-05 07:01:06 --> Config Class Initialized
INFO - 2016-02-05 07:01:06 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:01:06 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:01:06 --> Utf8 Class Initialized
INFO - 2016-02-05 07:01:06 --> URI Class Initialized
INFO - 2016-02-05 07:01:06 --> Router Class Initialized
INFO - 2016-02-05 07:01:06 --> Output Class Initialized
INFO - 2016-02-05 07:01:06 --> Security Class Initialized
DEBUG - 2016-02-05 07:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:01:06 --> Input Class Initialized
INFO - 2016-02-05 07:01:06 --> Language Class Initialized
INFO - 2016-02-05 07:01:06 --> Loader Class Initialized
INFO - 2016-02-05 07:01:06 --> Helper loaded: url_helper
INFO - 2016-02-05 07:01:06 --> Helper loaded: file_helper
INFO - 2016-02-05 07:01:06 --> Helper loaded: date_helper
INFO - 2016-02-05 07:01:06 --> Helper loaded: form_helper
INFO - 2016-02-05 07:01:06 --> Database Driver Class Initialized
INFO - 2016-02-05 07:01:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:01:07 --> Controller Class Initialized
INFO - 2016-02-05 07:01:07 --> Model Class Initialized
INFO - 2016-02-05 07:01:07 --> Model Class Initialized
INFO - 2016-02-05 07:01:07 --> Form Validation Class Initialized
INFO - 2016-02-05 07:01:07 --> Helper loaded: text_helper
INFO - 2016-02-05 07:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:01:07 --> Final output sent to browser
DEBUG - 2016-02-05 07:01:07 --> Total execution time: 1.1285
INFO - 2016-02-05 07:01:14 --> Config Class Initialized
INFO - 2016-02-05 07:01:14 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:01:14 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:01:14 --> Utf8 Class Initialized
INFO - 2016-02-05 07:01:14 --> URI Class Initialized
INFO - 2016-02-05 07:01:14 --> Router Class Initialized
INFO - 2016-02-05 07:01:14 --> Output Class Initialized
INFO - 2016-02-05 07:01:14 --> Security Class Initialized
DEBUG - 2016-02-05 07:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:01:14 --> Input Class Initialized
INFO - 2016-02-05 07:01:14 --> Language Class Initialized
INFO - 2016-02-05 07:01:14 --> Loader Class Initialized
INFO - 2016-02-05 07:01:14 --> Helper loaded: url_helper
INFO - 2016-02-05 07:01:14 --> Helper loaded: file_helper
INFO - 2016-02-05 07:01:14 --> Helper loaded: date_helper
INFO - 2016-02-05 07:01:14 --> Helper loaded: form_helper
INFO - 2016-02-05 07:01:14 --> Database Driver Class Initialized
INFO - 2016-02-05 07:01:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:01:15 --> Controller Class Initialized
INFO - 2016-02-05 07:01:15 --> Model Class Initialized
INFO - 2016-02-05 07:01:15 --> Model Class Initialized
INFO - 2016-02-05 07:01:15 --> Form Validation Class Initialized
INFO - 2016-02-05 07:01:15 --> Helper loaded: text_helper
INFO - 2016-02-05 07:01:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:01:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:01:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:01:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:01:15 --> Final output sent to browser
DEBUG - 2016-02-05 07:01:15 --> Total execution time: 1.1386
INFO - 2016-02-05 07:08:03 --> Config Class Initialized
INFO - 2016-02-05 07:08:03 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:08:03 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:08:03 --> Utf8 Class Initialized
INFO - 2016-02-05 07:08:03 --> URI Class Initialized
INFO - 2016-02-05 07:08:03 --> Router Class Initialized
INFO - 2016-02-05 07:08:03 --> Output Class Initialized
INFO - 2016-02-05 07:08:03 --> Security Class Initialized
DEBUG - 2016-02-05 07:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:08:03 --> Input Class Initialized
INFO - 2016-02-05 07:08:03 --> Language Class Initialized
INFO - 2016-02-05 07:08:03 --> Loader Class Initialized
INFO - 2016-02-05 07:08:03 --> Helper loaded: url_helper
INFO - 2016-02-05 07:08:03 --> Helper loaded: file_helper
INFO - 2016-02-05 07:08:03 --> Helper loaded: date_helper
INFO - 2016-02-05 07:08:03 --> Helper loaded: form_helper
INFO - 2016-02-05 07:08:03 --> Database Driver Class Initialized
INFO - 2016-02-05 07:08:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:08:04 --> Controller Class Initialized
INFO - 2016-02-05 07:08:04 --> Model Class Initialized
INFO - 2016-02-05 07:08:04 --> Model Class Initialized
INFO - 2016-02-05 07:08:04 --> Form Validation Class Initialized
INFO - 2016-02-05 07:08:04 --> Helper loaded: text_helper
INFO - 2016-02-05 07:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:08:04 --> Final output sent to browser
DEBUG - 2016-02-05 07:08:04 --> Total execution time: 1.1371
INFO - 2016-02-05 07:08:08 --> Config Class Initialized
INFO - 2016-02-05 07:08:08 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:08:08 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:08:08 --> Utf8 Class Initialized
INFO - 2016-02-05 07:08:08 --> URI Class Initialized
INFO - 2016-02-05 07:08:08 --> Router Class Initialized
INFO - 2016-02-05 07:08:08 --> Output Class Initialized
INFO - 2016-02-05 07:08:08 --> Security Class Initialized
DEBUG - 2016-02-05 07:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:08:08 --> Input Class Initialized
INFO - 2016-02-05 07:08:08 --> Language Class Initialized
INFO - 2016-02-05 07:08:08 --> Loader Class Initialized
INFO - 2016-02-05 07:08:08 --> Helper loaded: url_helper
INFO - 2016-02-05 07:08:08 --> Helper loaded: file_helper
INFO - 2016-02-05 07:08:08 --> Helper loaded: date_helper
INFO - 2016-02-05 07:08:08 --> Helper loaded: form_helper
INFO - 2016-02-05 07:08:08 --> Database Driver Class Initialized
INFO - 2016-02-05 07:08:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:08:09 --> Controller Class Initialized
INFO - 2016-02-05 07:08:09 --> Model Class Initialized
INFO - 2016-02-05 07:08:09 --> Model Class Initialized
INFO - 2016-02-05 07:08:09 --> Form Validation Class Initialized
INFO - 2016-02-05 07:08:09 --> Helper loaded: text_helper
INFO - 2016-02-05 07:08:09 --> Config Class Initialized
INFO - 2016-02-05 07:08:09 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:08:09 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:08:09 --> Utf8 Class Initialized
INFO - 2016-02-05 07:08:09 --> URI Class Initialized
INFO - 2016-02-05 07:08:09 --> Router Class Initialized
INFO - 2016-02-05 07:08:09 --> Output Class Initialized
INFO - 2016-02-05 07:08:09 --> Security Class Initialized
DEBUG - 2016-02-05 07:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:08:09 --> Input Class Initialized
INFO - 2016-02-05 07:08:09 --> Language Class Initialized
INFO - 2016-02-05 07:08:09 --> Loader Class Initialized
INFO - 2016-02-05 07:08:09 --> Helper loaded: url_helper
INFO - 2016-02-05 07:08:09 --> Helper loaded: file_helper
INFO - 2016-02-05 07:08:09 --> Helper loaded: date_helper
INFO - 2016-02-05 07:08:09 --> Helper loaded: form_helper
INFO - 2016-02-05 07:08:09 --> Database Driver Class Initialized
INFO - 2016-02-05 07:08:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:08:10 --> Controller Class Initialized
INFO - 2016-02-05 07:08:10 --> Model Class Initialized
INFO - 2016-02-05 07:08:11 --> Model Class Initialized
INFO - 2016-02-05 07:08:11 --> Form Validation Class Initialized
INFO - 2016-02-05 07:08:11 --> Helper loaded: text_helper
INFO - 2016-02-05 07:08:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-05 07:08:11 --> Final output sent to browser
DEBUG - 2016-02-05 07:08:11 --> Total execution time: 1.0992
INFO - 2016-02-05 07:10:05 --> Config Class Initialized
INFO - 2016-02-05 07:10:05 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:10:05 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:10:05 --> Utf8 Class Initialized
INFO - 2016-02-05 07:10:05 --> URI Class Initialized
INFO - 2016-02-05 07:10:05 --> Router Class Initialized
INFO - 2016-02-05 07:10:05 --> Output Class Initialized
INFO - 2016-02-05 07:10:05 --> Security Class Initialized
DEBUG - 2016-02-05 07:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:10:05 --> Input Class Initialized
INFO - 2016-02-05 07:10:05 --> Language Class Initialized
INFO - 2016-02-05 07:10:05 --> Loader Class Initialized
INFO - 2016-02-05 07:10:05 --> Helper loaded: url_helper
INFO - 2016-02-05 07:10:05 --> Helper loaded: file_helper
INFO - 2016-02-05 07:10:05 --> Helper loaded: date_helper
INFO - 2016-02-05 07:10:05 --> Helper loaded: form_helper
INFO - 2016-02-05 07:10:05 --> Database Driver Class Initialized
INFO - 2016-02-05 07:10:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:10:06 --> Controller Class Initialized
INFO - 2016-02-05 07:10:06 --> Model Class Initialized
INFO - 2016-02-05 07:10:06 --> Model Class Initialized
INFO - 2016-02-05 07:10:06 --> Form Validation Class Initialized
INFO - 2016-02-05 07:10:06 --> Helper loaded: text_helper
INFO - 2016-02-05 07:10:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:10:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:10:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:10:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:10:06 --> Final output sent to browser
DEBUG - 2016-02-05 07:10:06 --> Total execution time: 1.1641
INFO - 2016-02-05 07:10:08 --> Config Class Initialized
INFO - 2016-02-05 07:10:08 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:10:08 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:10:08 --> Utf8 Class Initialized
INFO - 2016-02-05 07:10:08 --> URI Class Initialized
INFO - 2016-02-05 07:10:08 --> Router Class Initialized
INFO - 2016-02-05 07:10:08 --> Output Class Initialized
INFO - 2016-02-05 07:10:08 --> Security Class Initialized
DEBUG - 2016-02-05 07:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:10:08 --> Input Class Initialized
INFO - 2016-02-05 07:10:08 --> Language Class Initialized
INFO - 2016-02-05 07:10:08 --> Loader Class Initialized
INFO - 2016-02-05 07:10:08 --> Helper loaded: url_helper
INFO - 2016-02-05 07:10:08 --> Helper loaded: file_helper
INFO - 2016-02-05 07:10:08 --> Helper loaded: date_helper
INFO - 2016-02-05 07:10:08 --> Helper loaded: form_helper
INFO - 2016-02-05 07:10:08 --> Database Driver Class Initialized
INFO - 2016-02-05 07:10:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:10:09 --> Controller Class Initialized
INFO - 2016-02-05 07:10:09 --> Model Class Initialized
INFO - 2016-02-05 07:10:09 --> Model Class Initialized
INFO - 2016-02-05 07:10:09 --> Form Validation Class Initialized
INFO - 2016-02-05 07:10:09 --> Helper loaded: text_helper
INFO - 2016-02-05 07:10:09 --> Final output sent to browser
DEBUG - 2016-02-05 07:10:09 --> Total execution time: 1.2115
INFO - 2016-02-05 07:10:09 --> Config Class Initialized
INFO - 2016-02-05 07:10:09 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:10:09 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:10:09 --> Utf8 Class Initialized
INFO - 2016-02-05 07:10:09 --> URI Class Initialized
INFO - 2016-02-05 07:10:09 --> Router Class Initialized
INFO - 2016-02-05 07:10:09 --> Output Class Initialized
INFO - 2016-02-05 07:10:09 --> Security Class Initialized
DEBUG - 2016-02-05 07:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:10:09 --> Input Class Initialized
INFO - 2016-02-05 07:10:09 --> Language Class Initialized
INFO - 2016-02-05 07:10:09 --> Loader Class Initialized
INFO - 2016-02-05 07:10:09 --> Helper loaded: url_helper
INFO - 2016-02-05 07:10:09 --> Helper loaded: file_helper
INFO - 2016-02-05 07:10:09 --> Helper loaded: date_helper
INFO - 2016-02-05 07:10:09 --> Helper loaded: form_helper
INFO - 2016-02-05 07:10:09 --> Database Driver Class Initialized
INFO - 2016-02-05 07:10:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:10:10 --> Controller Class Initialized
INFO - 2016-02-05 07:10:10 --> Model Class Initialized
INFO - 2016-02-05 07:10:10 --> Model Class Initialized
INFO - 2016-02-05 07:10:10 --> Form Validation Class Initialized
INFO - 2016-02-05 07:10:10 --> Helper loaded: text_helper
INFO - 2016-02-05 07:10:11 --> Final output sent to browser
DEBUG - 2016-02-05 07:10:11 --> Total execution time: 1.2318
INFO - 2016-02-05 07:10:14 --> Config Class Initialized
INFO - 2016-02-05 07:10:14 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:10:14 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:10:14 --> Utf8 Class Initialized
INFO - 2016-02-05 07:10:14 --> URI Class Initialized
INFO - 2016-02-05 07:10:14 --> Router Class Initialized
INFO - 2016-02-05 07:10:14 --> Output Class Initialized
INFO - 2016-02-05 07:10:14 --> Security Class Initialized
DEBUG - 2016-02-05 07:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:10:14 --> Input Class Initialized
INFO - 2016-02-05 07:10:14 --> Language Class Initialized
INFO - 2016-02-05 07:10:14 --> Loader Class Initialized
INFO - 2016-02-05 07:10:14 --> Helper loaded: url_helper
INFO - 2016-02-05 07:10:14 --> Helper loaded: file_helper
INFO - 2016-02-05 07:10:14 --> Helper loaded: date_helper
INFO - 2016-02-05 07:10:14 --> Helper loaded: form_helper
INFO - 2016-02-05 07:10:14 --> Database Driver Class Initialized
INFO - 2016-02-05 07:10:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:10:15 --> Controller Class Initialized
INFO - 2016-02-05 07:10:15 --> Model Class Initialized
INFO - 2016-02-05 07:10:15 --> Model Class Initialized
INFO - 2016-02-05 07:10:15 --> Form Validation Class Initialized
INFO - 2016-02-05 07:10:15 --> Helper loaded: text_helper
INFO - 2016-02-05 07:10:15 --> Final output sent to browser
DEBUG - 2016-02-05 07:10:15 --> Total execution time: 1.1631
INFO - 2016-02-05 07:11:12 --> Config Class Initialized
INFO - 2016-02-05 07:11:12 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:11:12 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:11:13 --> Utf8 Class Initialized
INFO - 2016-02-05 07:11:13 --> URI Class Initialized
INFO - 2016-02-05 07:11:13 --> Router Class Initialized
INFO - 2016-02-05 07:11:13 --> Output Class Initialized
INFO - 2016-02-05 07:11:13 --> Security Class Initialized
DEBUG - 2016-02-05 07:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:11:13 --> Input Class Initialized
INFO - 2016-02-05 07:11:13 --> Language Class Initialized
INFO - 2016-02-05 07:11:13 --> Loader Class Initialized
INFO - 2016-02-05 07:11:13 --> Helper loaded: url_helper
INFO - 2016-02-05 07:11:13 --> Helper loaded: file_helper
INFO - 2016-02-05 07:11:13 --> Helper loaded: date_helper
INFO - 2016-02-05 07:11:13 --> Helper loaded: form_helper
INFO - 2016-02-05 07:11:13 --> Database Driver Class Initialized
INFO - 2016-02-05 07:11:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:11:14 --> Controller Class Initialized
INFO - 2016-02-05 07:11:14 --> Model Class Initialized
INFO - 2016-02-05 07:11:14 --> Model Class Initialized
INFO - 2016-02-05 07:11:14 --> Form Validation Class Initialized
INFO - 2016-02-05 07:11:14 --> Helper loaded: text_helper
INFO - 2016-02-05 07:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:11:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:11:14 --> Final output sent to browser
DEBUG - 2016-02-05 07:11:14 --> Total execution time: 1.1677
INFO - 2016-02-05 07:11:16 --> Config Class Initialized
INFO - 2016-02-05 07:11:16 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:11:16 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:11:16 --> Utf8 Class Initialized
INFO - 2016-02-05 07:11:16 --> URI Class Initialized
INFO - 2016-02-05 07:11:16 --> Router Class Initialized
INFO - 2016-02-05 07:11:16 --> Output Class Initialized
INFO - 2016-02-05 07:11:16 --> Security Class Initialized
DEBUG - 2016-02-05 07:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:11:16 --> Input Class Initialized
INFO - 2016-02-05 07:11:16 --> Language Class Initialized
INFO - 2016-02-05 07:11:16 --> Loader Class Initialized
INFO - 2016-02-05 07:11:16 --> Helper loaded: url_helper
INFO - 2016-02-05 07:11:16 --> Helper loaded: file_helper
INFO - 2016-02-05 07:11:16 --> Helper loaded: date_helper
INFO - 2016-02-05 07:11:16 --> Helper loaded: form_helper
INFO - 2016-02-05 07:11:16 --> Database Driver Class Initialized
INFO - 2016-02-05 07:11:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:11:17 --> Controller Class Initialized
INFO - 2016-02-05 07:11:17 --> Model Class Initialized
INFO - 2016-02-05 07:11:17 --> Model Class Initialized
INFO - 2016-02-05 07:11:17 --> Form Validation Class Initialized
INFO - 2016-02-05 07:11:17 --> Helper loaded: text_helper
INFO - 2016-02-05 07:11:17 --> Final output sent to browser
DEBUG - 2016-02-05 07:11:17 --> Total execution time: 1.2425
INFO - 2016-02-05 07:11:18 --> Config Class Initialized
INFO - 2016-02-05 07:11:18 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:11:18 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:11:18 --> Utf8 Class Initialized
INFO - 2016-02-05 07:11:18 --> URI Class Initialized
INFO - 2016-02-05 07:11:18 --> Router Class Initialized
INFO - 2016-02-05 07:11:18 --> Output Class Initialized
INFO - 2016-02-05 07:11:18 --> Security Class Initialized
DEBUG - 2016-02-05 07:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:11:18 --> Input Class Initialized
INFO - 2016-02-05 07:11:18 --> Language Class Initialized
INFO - 2016-02-05 07:11:18 --> Loader Class Initialized
INFO - 2016-02-05 07:11:18 --> Helper loaded: url_helper
INFO - 2016-02-05 07:11:18 --> Helper loaded: file_helper
INFO - 2016-02-05 07:11:18 --> Helper loaded: date_helper
INFO - 2016-02-05 07:11:18 --> Helper loaded: form_helper
INFO - 2016-02-05 07:11:18 --> Database Driver Class Initialized
INFO - 2016-02-05 07:11:19 --> Config Class Initialized
INFO - 2016-02-05 07:11:19 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:11:19 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:11:19 --> Utf8 Class Initialized
INFO - 2016-02-05 07:11:19 --> URI Class Initialized
INFO - 2016-02-05 07:11:19 --> Router Class Initialized
INFO - 2016-02-05 07:11:19 --> Output Class Initialized
INFO - 2016-02-05 07:11:19 --> Security Class Initialized
DEBUG - 2016-02-05 07:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:11:19 --> Input Class Initialized
INFO - 2016-02-05 07:11:19 --> Language Class Initialized
INFO - 2016-02-05 07:11:19 --> Loader Class Initialized
INFO - 2016-02-05 07:11:19 --> Helper loaded: url_helper
INFO - 2016-02-05 07:11:19 --> Helper loaded: file_helper
INFO - 2016-02-05 07:11:19 --> Helper loaded: date_helper
INFO - 2016-02-05 07:11:19 --> Helper loaded: form_helper
INFO - 2016-02-05 07:11:19 --> Database Driver Class Initialized
INFO - 2016-02-05 07:11:19 --> Config Class Initialized
INFO - 2016-02-05 07:11:19 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:11:19 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:11:19 --> Utf8 Class Initialized
INFO - 2016-02-05 07:11:19 --> URI Class Initialized
INFO - 2016-02-05 07:11:19 --> Router Class Initialized
INFO - 2016-02-05 07:11:19 --> Output Class Initialized
INFO - 2016-02-05 07:11:19 --> Security Class Initialized
DEBUG - 2016-02-05 07:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:11:19 --> Input Class Initialized
INFO - 2016-02-05 07:11:19 --> Language Class Initialized
INFO - 2016-02-05 07:11:19 --> Loader Class Initialized
INFO - 2016-02-05 07:11:19 --> Helper loaded: url_helper
INFO - 2016-02-05 07:11:19 --> Helper loaded: file_helper
INFO - 2016-02-05 07:11:19 --> Helper loaded: date_helper
INFO - 2016-02-05 07:11:19 --> Helper loaded: form_helper
INFO - 2016-02-05 07:11:19 --> Database Driver Class Initialized
INFO - 2016-02-05 07:11:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:11:19 --> Controller Class Initialized
INFO - 2016-02-05 07:11:19 --> Model Class Initialized
INFO - 2016-02-05 07:11:19 --> Model Class Initialized
INFO - 2016-02-05 07:11:19 --> Form Validation Class Initialized
INFO - 2016-02-05 07:11:19 --> Helper loaded: text_helper
INFO - 2016-02-05 07:11:20 --> Final output sent to browser
DEBUG - 2016-02-05 07:11:20 --> Total execution time: 1.1611
INFO - 2016-02-05 07:11:20 --> Config Class Initialized
INFO - 2016-02-05 07:11:20 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:11:20 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:11:20 --> Utf8 Class Initialized
INFO - 2016-02-05 07:11:20 --> URI Class Initialized
INFO - 2016-02-05 07:11:20 --> Router Class Initialized
INFO - 2016-02-05 07:11:20 --> Output Class Initialized
INFO - 2016-02-05 07:11:20 --> Security Class Initialized
DEBUG - 2016-02-05 07:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:11:20 --> Input Class Initialized
INFO - 2016-02-05 07:11:20 --> Language Class Initialized
INFO - 2016-02-05 07:11:20 --> Loader Class Initialized
INFO - 2016-02-05 07:11:20 --> Helper loaded: url_helper
INFO - 2016-02-05 07:11:20 --> Helper loaded: file_helper
INFO - 2016-02-05 07:11:20 --> Helper loaded: date_helper
INFO - 2016-02-05 07:11:20 --> Helper loaded: form_helper
INFO - 2016-02-05 07:11:20 --> Database Driver Class Initialized
INFO - 2016-02-05 07:11:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:11:20 --> Controller Class Initialized
INFO - 2016-02-05 07:11:20 --> Model Class Initialized
INFO - 2016-02-05 07:11:20 --> Model Class Initialized
INFO - 2016-02-05 07:11:20 --> Form Validation Class Initialized
INFO - 2016-02-05 07:11:20 --> Helper loaded: text_helper
INFO - 2016-02-05 07:11:20 --> Final output sent to browser
DEBUG - 2016-02-05 07:11:20 --> Total execution time: 1.1588
INFO - 2016-02-05 07:11:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:11:20 --> Controller Class Initialized
INFO - 2016-02-05 07:11:20 --> Model Class Initialized
INFO - 2016-02-05 07:11:20 --> Model Class Initialized
INFO - 2016-02-05 07:11:20 --> Form Validation Class Initialized
INFO - 2016-02-05 07:11:20 --> Helper loaded: text_helper
INFO - 2016-02-05 07:11:21 --> Final output sent to browser
DEBUG - 2016-02-05 07:11:21 --> Total execution time: 1.1813
INFO - 2016-02-05 07:11:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:11:21 --> Controller Class Initialized
INFO - 2016-02-05 07:11:21 --> Model Class Initialized
INFO - 2016-02-05 07:11:21 --> Model Class Initialized
INFO - 2016-02-05 07:11:21 --> Form Validation Class Initialized
INFO - 2016-02-05 07:11:21 --> Helper loaded: text_helper
INFO - 2016-02-05 07:11:21 --> Final output sent to browser
DEBUG - 2016-02-05 07:11:21 --> Total execution time: 1.1863
INFO - 2016-02-05 07:13:08 --> Config Class Initialized
INFO - 2016-02-05 07:13:08 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:13:08 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:13:08 --> Utf8 Class Initialized
INFO - 2016-02-05 07:13:08 --> URI Class Initialized
INFO - 2016-02-05 07:13:08 --> Router Class Initialized
INFO - 2016-02-05 07:13:08 --> Output Class Initialized
INFO - 2016-02-05 07:13:08 --> Security Class Initialized
DEBUG - 2016-02-05 07:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:13:08 --> Input Class Initialized
INFO - 2016-02-05 07:13:08 --> Language Class Initialized
INFO - 2016-02-05 07:13:08 --> Loader Class Initialized
INFO - 2016-02-05 07:13:08 --> Helper loaded: url_helper
INFO - 2016-02-05 07:13:08 --> Helper loaded: file_helper
INFO - 2016-02-05 07:13:08 --> Helper loaded: date_helper
INFO - 2016-02-05 07:13:08 --> Helper loaded: form_helper
INFO - 2016-02-05 07:13:08 --> Database Driver Class Initialized
INFO - 2016-02-05 07:13:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:13:09 --> Controller Class Initialized
INFO - 2016-02-05 07:13:09 --> Model Class Initialized
INFO - 2016-02-05 07:13:09 --> Model Class Initialized
INFO - 2016-02-05 07:13:09 --> Form Validation Class Initialized
INFO - 2016-02-05 07:13:09 --> Helper loaded: text_helper
INFO - 2016-02-05 07:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:13:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:13:09 --> Final output sent to browser
DEBUG - 2016-02-05 07:13:09 --> Total execution time: 1.1779
INFO - 2016-02-05 07:13:12 --> Config Class Initialized
INFO - 2016-02-05 07:13:12 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:13:12 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:13:12 --> Utf8 Class Initialized
INFO - 2016-02-05 07:13:12 --> URI Class Initialized
INFO - 2016-02-05 07:13:12 --> Router Class Initialized
INFO - 2016-02-05 07:13:12 --> Output Class Initialized
INFO - 2016-02-05 07:13:12 --> Security Class Initialized
DEBUG - 2016-02-05 07:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:13:12 --> Input Class Initialized
INFO - 2016-02-05 07:13:12 --> Language Class Initialized
INFO - 2016-02-05 07:13:12 --> Loader Class Initialized
INFO - 2016-02-05 07:13:12 --> Helper loaded: url_helper
INFO - 2016-02-05 07:13:12 --> Helper loaded: file_helper
INFO - 2016-02-05 07:13:12 --> Helper loaded: date_helper
INFO - 2016-02-05 07:13:12 --> Helper loaded: form_helper
INFO - 2016-02-05 07:13:12 --> Database Driver Class Initialized
INFO - 2016-02-05 07:13:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:13:13 --> Controller Class Initialized
INFO - 2016-02-05 07:13:13 --> Model Class Initialized
INFO - 2016-02-05 07:13:13 --> Model Class Initialized
INFO - 2016-02-05 07:13:13 --> Form Validation Class Initialized
INFO - 2016-02-05 07:13:13 --> Helper loaded: text_helper
INFO - 2016-02-05 07:13:13 --> Final output sent to browser
DEBUG - 2016-02-05 07:13:13 --> Total execution time: 1.1765
INFO - 2016-02-05 07:15:39 --> Config Class Initialized
INFO - 2016-02-05 07:15:39 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:15:39 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:15:39 --> Utf8 Class Initialized
INFO - 2016-02-05 07:15:39 --> URI Class Initialized
INFO - 2016-02-05 07:15:39 --> Router Class Initialized
INFO - 2016-02-05 07:15:39 --> Output Class Initialized
INFO - 2016-02-05 07:15:39 --> Security Class Initialized
DEBUG - 2016-02-05 07:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:15:39 --> Input Class Initialized
INFO - 2016-02-05 07:15:39 --> Language Class Initialized
INFO - 2016-02-05 07:15:39 --> Loader Class Initialized
INFO - 2016-02-05 07:15:39 --> Helper loaded: url_helper
INFO - 2016-02-05 07:15:39 --> Helper loaded: file_helper
INFO - 2016-02-05 07:15:39 --> Helper loaded: date_helper
INFO - 2016-02-05 07:15:39 --> Helper loaded: form_helper
INFO - 2016-02-05 07:15:39 --> Database Driver Class Initialized
INFO - 2016-02-05 07:15:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:15:40 --> Controller Class Initialized
INFO - 2016-02-05 07:15:40 --> Model Class Initialized
INFO - 2016-02-05 07:15:40 --> Model Class Initialized
INFO - 2016-02-05 07:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:15:40 --> Pagination Class Initialized
INFO - 2016-02-05 07:15:40 --> Final output sent to browser
DEBUG - 2016-02-05 07:15:40 --> Total execution time: 1.1305
INFO - 2016-02-05 07:21:28 --> Config Class Initialized
INFO - 2016-02-05 07:21:28 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:21:28 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:21:28 --> Utf8 Class Initialized
INFO - 2016-02-05 07:21:28 --> URI Class Initialized
INFO - 2016-02-05 07:21:28 --> Router Class Initialized
INFO - 2016-02-05 07:21:28 --> Output Class Initialized
INFO - 2016-02-05 07:21:28 --> Security Class Initialized
DEBUG - 2016-02-05 07:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:21:28 --> Input Class Initialized
INFO - 2016-02-05 07:21:28 --> Language Class Initialized
INFO - 2016-02-05 07:21:28 --> Loader Class Initialized
INFO - 2016-02-05 07:21:28 --> Helper loaded: url_helper
INFO - 2016-02-05 07:21:28 --> Helper loaded: file_helper
INFO - 2016-02-05 07:21:28 --> Helper loaded: date_helper
INFO - 2016-02-05 07:21:28 --> Helper loaded: form_helper
INFO - 2016-02-05 07:21:28 --> Database Driver Class Initialized
INFO - 2016-02-05 07:21:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:21:29 --> Controller Class Initialized
INFO - 2016-02-05 07:21:29 --> Model Class Initialized
INFO - 2016-02-05 07:21:29 --> Model Class Initialized
INFO - 2016-02-05 07:21:29 --> Form Validation Class Initialized
INFO - 2016-02-05 07:21:29 --> Helper loaded: text_helper
INFO - 2016-02-05 07:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:21:29 --> Final output sent to browser
DEBUG - 2016-02-05 07:21:29 --> Total execution time: 1.1463
INFO - 2016-02-05 07:21:34 --> Config Class Initialized
INFO - 2016-02-05 07:21:34 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:21:34 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:21:34 --> Utf8 Class Initialized
INFO - 2016-02-05 07:21:34 --> URI Class Initialized
INFO - 2016-02-05 07:21:34 --> Router Class Initialized
INFO - 2016-02-05 07:21:34 --> Output Class Initialized
INFO - 2016-02-05 07:21:34 --> Security Class Initialized
DEBUG - 2016-02-05 07:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:21:34 --> Input Class Initialized
INFO - 2016-02-05 07:21:34 --> Language Class Initialized
INFO - 2016-02-05 07:21:34 --> Loader Class Initialized
INFO - 2016-02-05 07:21:34 --> Helper loaded: url_helper
INFO - 2016-02-05 07:21:34 --> Helper loaded: file_helper
INFO - 2016-02-05 07:21:34 --> Helper loaded: date_helper
INFO - 2016-02-05 07:21:34 --> Helper loaded: form_helper
INFO - 2016-02-05 07:21:34 --> Database Driver Class Initialized
INFO - 2016-02-05 07:21:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:21:35 --> Controller Class Initialized
INFO - 2016-02-05 07:21:35 --> Model Class Initialized
INFO - 2016-02-05 07:21:35 --> Model Class Initialized
INFO - 2016-02-05 07:21:35 --> Form Validation Class Initialized
INFO - 2016-02-05 07:21:35 --> Helper loaded: text_helper
INFO - 2016-02-05 07:21:35 --> Final output sent to browser
DEBUG - 2016-02-05 07:21:35 --> Total execution time: 1.1682
INFO - 2016-02-05 07:35:16 --> Config Class Initialized
INFO - 2016-02-05 07:35:16 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:35:16 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:35:16 --> Utf8 Class Initialized
INFO - 2016-02-05 07:35:16 --> URI Class Initialized
DEBUG - 2016-02-05 07:35:16 --> No URI present. Default controller set.
INFO - 2016-02-05 07:35:16 --> Router Class Initialized
INFO - 2016-02-05 07:35:16 --> Output Class Initialized
INFO - 2016-02-05 07:35:16 --> Security Class Initialized
DEBUG - 2016-02-05 07:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:35:16 --> Input Class Initialized
INFO - 2016-02-05 07:35:16 --> Language Class Initialized
INFO - 2016-02-05 07:35:16 --> Loader Class Initialized
INFO - 2016-02-05 07:35:16 --> Helper loaded: url_helper
INFO - 2016-02-05 07:35:16 --> Helper loaded: file_helper
INFO - 2016-02-05 07:35:16 --> Helper loaded: date_helper
INFO - 2016-02-05 07:35:16 --> Helper loaded: form_helper
INFO - 2016-02-05 07:35:16 --> Database Driver Class Initialized
INFO - 2016-02-05 07:35:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:35:17 --> Controller Class Initialized
INFO - 2016-02-05 07:35:17 --> Model Class Initialized
INFO - 2016-02-05 07:35:17 --> Model Class Initialized
INFO - 2016-02-05 07:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:35:17 --> Pagination Class Initialized
INFO - 2016-02-05 07:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:35:17 --> Final output sent to browser
DEBUG - 2016-02-05 07:35:17 --> Total execution time: 1.1372
INFO - 2016-02-05 07:35:20 --> Config Class Initialized
INFO - 2016-02-05 07:35:20 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:35:20 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:35:20 --> Utf8 Class Initialized
INFO - 2016-02-05 07:35:20 --> URI Class Initialized
INFO - 2016-02-05 07:35:20 --> Router Class Initialized
INFO - 2016-02-05 07:35:20 --> Output Class Initialized
INFO - 2016-02-05 07:35:20 --> Security Class Initialized
DEBUG - 2016-02-05 07:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:35:20 --> Input Class Initialized
INFO - 2016-02-05 07:35:20 --> Language Class Initialized
INFO - 2016-02-05 07:35:20 --> Loader Class Initialized
INFO - 2016-02-05 07:35:20 --> Helper loaded: url_helper
INFO - 2016-02-05 07:35:20 --> Helper loaded: file_helper
INFO - 2016-02-05 07:35:20 --> Helper loaded: date_helper
INFO - 2016-02-05 07:35:20 --> Helper loaded: form_helper
INFO - 2016-02-05 07:35:20 --> Database Driver Class Initialized
INFO - 2016-02-05 07:35:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:35:21 --> Controller Class Initialized
INFO - 2016-02-05 07:35:21 --> Model Class Initialized
INFO - 2016-02-05 07:35:21 --> Model Class Initialized
INFO - 2016-02-05 07:35:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:35:21 --> Pagination Class Initialized
INFO - 2016-02-05 07:35:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:35:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:35:21 --> Helper loaded: text_helper
INFO - 2016-02-05 07:35:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:35:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:35:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:35:21 --> Final output sent to browser
DEBUG - 2016-02-05 07:35:21 --> Total execution time: 1.2500
INFO - 2016-02-05 07:35:37 --> Config Class Initialized
INFO - 2016-02-05 07:35:37 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:35:37 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:35:37 --> Utf8 Class Initialized
INFO - 2016-02-05 07:35:37 --> URI Class Initialized
INFO - 2016-02-05 07:35:37 --> Router Class Initialized
INFO - 2016-02-05 07:35:37 --> Output Class Initialized
INFO - 2016-02-05 07:35:37 --> Security Class Initialized
DEBUG - 2016-02-05 07:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:35:37 --> Input Class Initialized
INFO - 2016-02-05 07:35:37 --> Language Class Initialized
INFO - 2016-02-05 07:35:37 --> Loader Class Initialized
INFO - 2016-02-05 07:35:37 --> Helper loaded: url_helper
INFO - 2016-02-05 07:35:37 --> Helper loaded: file_helper
INFO - 2016-02-05 07:35:37 --> Helper loaded: date_helper
INFO - 2016-02-05 07:35:37 --> Helper loaded: form_helper
INFO - 2016-02-05 07:35:37 --> Database Driver Class Initialized
INFO - 2016-02-05 07:35:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:35:38 --> Controller Class Initialized
INFO - 2016-02-05 07:35:38 --> Model Class Initialized
INFO - 2016-02-05 07:35:38 --> Model Class Initialized
INFO - 2016-02-05 07:35:38 --> Form Validation Class Initialized
INFO - 2016-02-05 07:35:38 --> Helper loaded: text_helper
INFO - 2016-02-05 07:35:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:35:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:35:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:35:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:35:38 --> Final output sent to browser
DEBUG - 2016-02-05 07:35:38 --> Total execution time: 1.1685
INFO - 2016-02-05 07:35:42 --> Config Class Initialized
INFO - 2016-02-05 07:35:42 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:35:42 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:35:42 --> Utf8 Class Initialized
INFO - 2016-02-05 07:35:42 --> URI Class Initialized
INFO - 2016-02-05 07:35:42 --> Router Class Initialized
INFO - 2016-02-05 07:35:42 --> Output Class Initialized
INFO - 2016-02-05 07:35:42 --> Security Class Initialized
DEBUG - 2016-02-05 07:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:35:42 --> Input Class Initialized
INFO - 2016-02-05 07:35:42 --> Language Class Initialized
INFO - 2016-02-05 07:35:42 --> Loader Class Initialized
INFO - 2016-02-05 07:35:42 --> Helper loaded: url_helper
INFO - 2016-02-05 07:35:42 --> Helper loaded: file_helper
INFO - 2016-02-05 07:35:42 --> Helper loaded: date_helper
INFO - 2016-02-05 07:35:42 --> Helper loaded: form_helper
INFO - 2016-02-05 07:35:42 --> Database Driver Class Initialized
INFO - 2016-02-05 07:35:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:35:44 --> Controller Class Initialized
INFO - 2016-02-05 07:35:44 --> Model Class Initialized
INFO - 2016-02-05 07:35:44 --> Model Class Initialized
INFO - 2016-02-05 07:35:44 --> Form Validation Class Initialized
INFO - 2016-02-05 07:35:44 --> Helper loaded: text_helper
INFO - 2016-02-05 07:35:44 --> Config Class Initialized
INFO - 2016-02-05 07:35:44 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:35:44 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:35:44 --> Utf8 Class Initialized
INFO - 2016-02-05 07:35:44 --> URI Class Initialized
INFO - 2016-02-05 07:35:44 --> Router Class Initialized
INFO - 2016-02-05 07:35:44 --> Output Class Initialized
INFO - 2016-02-05 07:35:44 --> Security Class Initialized
DEBUG - 2016-02-05 07:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:35:44 --> Input Class Initialized
INFO - 2016-02-05 07:35:44 --> Language Class Initialized
INFO - 2016-02-05 07:35:44 --> Loader Class Initialized
INFO - 2016-02-05 07:35:44 --> Helper loaded: url_helper
INFO - 2016-02-05 07:35:44 --> Helper loaded: file_helper
INFO - 2016-02-05 07:35:44 --> Helper loaded: date_helper
INFO - 2016-02-05 07:35:44 --> Helper loaded: form_helper
INFO - 2016-02-05 07:35:44 --> Database Driver Class Initialized
INFO - 2016-02-05 07:35:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:35:45 --> Controller Class Initialized
INFO - 2016-02-05 07:35:45 --> Model Class Initialized
INFO - 2016-02-05 07:35:45 --> Model Class Initialized
INFO - 2016-02-05 07:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:35:45 --> Pagination Class Initialized
INFO - 2016-02-05 07:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:35:45 --> Final output sent to browser
DEBUG - 2016-02-05 07:35:45 --> Total execution time: 1.1228
INFO - 2016-02-05 07:36:14 --> Config Class Initialized
INFO - 2016-02-05 07:36:14 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:36:14 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:36:14 --> Utf8 Class Initialized
INFO - 2016-02-05 07:36:14 --> URI Class Initialized
INFO - 2016-02-05 07:36:14 --> Router Class Initialized
INFO - 2016-02-05 07:36:14 --> Output Class Initialized
INFO - 2016-02-05 07:36:14 --> Security Class Initialized
DEBUG - 2016-02-05 07:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:36:14 --> Input Class Initialized
INFO - 2016-02-05 07:36:14 --> Language Class Initialized
INFO - 2016-02-05 07:36:14 --> Loader Class Initialized
INFO - 2016-02-05 07:36:14 --> Helper loaded: url_helper
INFO - 2016-02-05 07:36:14 --> Helper loaded: file_helper
INFO - 2016-02-05 07:36:14 --> Helper loaded: date_helper
INFO - 2016-02-05 07:36:14 --> Helper loaded: form_helper
INFO - 2016-02-05 07:36:14 --> Database Driver Class Initialized
INFO - 2016-02-05 07:36:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:36:15 --> Controller Class Initialized
INFO - 2016-02-05 07:36:15 --> Model Class Initialized
INFO - 2016-02-05 07:36:15 --> Model Class Initialized
INFO - 2016-02-05 07:36:15 --> Form Validation Class Initialized
INFO - 2016-02-05 07:36:15 --> Helper loaded: text_helper
INFO - 2016-02-05 07:36:15 --> Config Class Initialized
INFO - 2016-02-05 07:36:15 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:36:15 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:36:15 --> Utf8 Class Initialized
INFO - 2016-02-05 07:36:15 --> URI Class Initialized
INFO - 2016-02-05 07:36:16 --> Router Class Initialized
INFO - 2016-02-05 07:36:16 --> Output Class Initialized
INFO - 2016-02-05 07:36:16 --> Security Class Initialized
DEBUG - 2016-02-05 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:36:16 --> Input Class Initialized
INFO - 2016-02-05 07:36:16 --> Language Class Initialized
INFO - 2016-02-05 07:36:16 --> Loader Class Initialized
INFO - 2016-02-05 07:36:16 --> Helper loaded: url_helper
INFO - 2016-02-05 07:36:16 --> Helper loaded: file_helper
INFO - 2016-02-05 07:36:16 --> Helper loaded: date_helper
INFO - 2016-02-05 07:36:16 --> Helper loaded: form_helper
INFO - 2016-02-05 07:36:16 --> Database Driver Class Initialized
INFO - 2016-02-05 07:36:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:36:17 --> Controller Class Initialized
INFO - 2016-02-05 07:36:17 --> Model Class Initialized
INFO - 2016-02-05 07:36:17 --> Model Class Initialized
INFO - 2016-02-05 07:36:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:36:17 --> Pagination Class Initialized
INFO - 2016-02-05 07:36:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:36:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:36:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:36:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:36:17 --> Final output sent to browser
DEBUG - 2016-02-05 07:36:17 --> Total execution time: 1.1702
INFO - 2016-02-05 07:36:17 --> Config Class Initialized
INFO - 2016-02-05 07:36:17 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:36:17 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:36:17 --> Utf8 Class Initialized
INFO - 2016-02-05 07:36:17 --> URI Class Initialized
INFO - 2016-02-05 07:36:17 --> Router Class Initialized
INFO - 2016-02-05 07:36:17 --> Output Class Initialized
INFO - 2016-02-05 07:36:17 --> Security Class Initialized
DEBUG - 2016-02-05 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:36:17 --> Input Class Initialized
INFO - 2016-02-05 07:36:17 --> Language Class Initialized
INFO - 2016-02-05 07:36:17 --> Loader Class Initialized
INFO - 2016-02-05 07:36:17 --> Helper loaded: url_helper
INFO - 2016-02-05 07:36:17 --> Helper loaded: file_helper
INFO - 2016-02-05 07:36:17 --> Helper loaded: date_helper
INFO - 2016-02-05 07:36:17 --> Helper loaded: form_helper
INFO - 2016-02-05 07:36:17 --> Database Driver Class Initialized
INFO - 2016-02-05 07:36:17 --> Config Class Initialized
INFO - 2016-02-05 07:36:17 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:36:17 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:36:17 --> Utf8 Class Initialized
INFO - 2016-02-05 07:36:17 --> URI Class Initialized
INFO - 2016-02-05 07:36:17 --> Router Class Initialized
INFO - 2016-02-05 07:36:17 --> Output Class Initialized
INFO - 2016-02-05 07:36:17 --> Security Class Initialized
DEBUG - 2016-02-05 07:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:36:17 --> Input Class Initialized
INFO - 2016-02-05 07:36:17 --> Language Class Initialized
INFO - 2016-02-05 07:36:17 --> Loader Class Initialized
INFO - 2016-02-05 07:36:17 --> Helper loaded: url_helper
INFO - 2016-02-05 07:36:17 --> Helper loaded: file_helper
INFO - 2016-02-05 07:36:17 --> Helper loaded: date_helper
INFO - 2016-02-05 07:36:17 --> Helper loaded: form_helper
INFO - 2016-02-05 07:36:17 --> Database Driver Class Initialized
INFO - 2016-02-05 07:36:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:36:18 --> Controller Class Initialized
INFO - 2016-02-05 07:36:18 --> Model Class Initialized
INFO - 2016-02-05 07:36:18 --> Model Class Initialized
INFO - 2016-02-05 07:36:18 --> Form Validation Class Initialized
INFO - 2016-02-05 07:36:18 --> Helper loaded: text_helper
INFO - 2016-02-05 07:36:18 --> Config Class Initialized
INFO - 2016-02-05 07:36:18 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:36:18 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:36:18 --> Utf8 Class Initialized
INFO - 2016-02-05 07:36:18 --> URI Class Initialized
INFO - 2016-02-05 07:36:18 --> Router Class Initialized
INFO - 2016-02-05 07:36:18 --> Output Class Initialized
INFO - 2016-02-05 07:36:18 --> Security Class Initialized
DEBUG - 2016-02-05 07:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:36:18 --> Input Class Initialized
INFO - 2016-02-05 07:36:18 --> Language Class Initialized
INFO - 2016-02-05 07:36:18 --> Loader Class Initialized
INFO - 2016-02-05 07:36:18 --> Helper loaded: url_helper
INFO - 2016-02-05 07:36:18 --> Helper loaded: file_helper
INFO - 2016-02-05 07:36:18 --> Helper loaded: date_helper
INFO - 2016-02-05 07:36:18 --> Helper loaded: form_helper
INFO - 2016-02-05 07:36:18 --> Database Driver Class Initialized
INFO - 2016-02-05 07:36:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:36:18 --> Controller Class Initialized
INFO - 2016-02-05 07:36:18 --> Model Class Initialized
INFO - 2016-02-05 07:36:18 --> Model Class Initialized
INFO - 2016-02-05 07:36:18 --> Form Validation Class Initialized
INFO - 2016-02-05 07:36:18 --> Helper loaded: text_helper
INFO - 2016-02-05 07:36:18 --> Config Class Initialized
INFO - 2016-02-05 07:36:18 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:36:18 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:36:18 --> Utf8 Class Initialized
INFO - 2016-02-05 07:36:18 --> URI Class Initialized
INFO - 2016-02-05 07:36:18 --> Router Class Initialized
INFO - 2016-02-05 07:36:18 --> Output Class Initialized
INFO - 2016-02-05 07:36:18 --> Security Class Initialized
DEBUG - 2016-02-05 07:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:36:18 --> Input Class Initialized
INFO - 2016-02-05 07:36:18 --> Language Class Initialized
INFO - 2016-02-05 07:36:18 --> Loader Class Initialized
INFO - 2016-02-05 07:36:18 --> Helper loaded: url_helper
INFO - 2016-02-05 07:36:18 --> Helper loaded: file_helper
INFO - 2016-02-05 07:36:18 --> Helper loaded: date_helper
INFO - 2016-02-05 07:36:18 --> Helper loaded: form_helper
INFO - 2016-02-05 07:36:18 --> Database Driver Class Initialized
INFO - 2016-02-05 07:36:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:36:19 --> Controller Class Initialized
INFO - 2016-02-05 07:36:19 --> Model Class Initialized
INFO - 2016-02-05 07:36:19 --> Model Class Initialized
INFO - 2016-02-05 07:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:36:19 --> Pagination Class Initialized
INFO - 2016-02-05 07:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:36:19 --> Final output sent to browser
DEBUG - 2016-02-05 07:36:19 --> Total execution time: 1.1346
INFO - 2016-02-05 07:36:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:36:19 --> Controller Class Initialized
INFO - 2016-02-05 07:36:19 --> Model Class Initialized
INFO - 2016-02-05 07:36:19 --> Model Class Initialized
INFO - 2016-02-05 07:36:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:36:19 --> Pagination Class Initialized
INFO - 2016-02-05 07:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:36:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:36:20 --> Final output sent to browser
DEBUG - 2016-02-05 07:36:20 --> Total execution time: 1.1721
INFO - 2016-02-05 07:37:25 --> Config Class Initialized
INFO - 2016-02-05 07:37:25 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:37:25 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:37:25 --> Utf8 Class Initialized
INFO - 2016-02-05 07:37:25 --> URI Class Initialized
DEBUG - 2016-02-05 07:37:25 --> No URI present. Default controller set.
INFO - 2016-02-05 07:37:25 --> Router Class Initialized
INFO - 2016-02-05 07:37:25 --> Output Class Initialized
INFO - 2016-02-05 07:37:25 --> Security Class Initialized
DEBUG - 2016-02-05 07:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:37:25 --> Input Class Initialized
INFO - 2016-02-05 07:37:25 --> Language Class Initialized
INFO - 2016-02-05 07:37:25 --> Loader Class Initialized
INFO - 2016-02-05 07:37:25 --> Helper loaded: url_helper
INFO - 2016-02-05 07:37:25 --> Helper loaded: file_helper
INFO - 2016-02-05 07:37:25 --> Helper loaded: date_helper
INFO - 2016-02-05 07:37:25 --> Helper loaded: form_helper
INFO - 2016-02-05 07:37:25 --> Database Driver Class Initialized
INFO - 2016-02-05 07:37:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:37:26 --> Controller Class Initialized
INFO - 2016-02-05 07:37:26 --> Model Class Initialized
INFO - 2016-02-05 07:37:26 --> Model Class Initialized
INFO - 2016-02-05 07:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:37:26 --> Pagination Class Initialized
INFO - 2016-02-05 07:37:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:37:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:37:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:37:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:37:26 --> Final output sent to browser
DEBUG - 2016-02-05 07:37:26 --> Total execution time: 1.1303
INFO - 2016-02-05 07:37:45 --> Config Class Initialized
INFO - 2016-02-05 07:37:45 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:37:45 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:37:45 --> Utf8 Class Initialized
INFO - 2016-02-05 07:37:45 --> URI Class Initialized
DEBUG - 2016-02-05 07:37:45 --> No URI present. Default controller set.
INFO - 2016-02-05 07:37:45 --> Router Class Initialized
INFO - 2016-02-05 07:37:45 --> Output Class Initialized
INFO - 2016-02-05 07:37:45 --> Security Class Initialized
DEBUG - 2016-02-05 07:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:37:45 --> Input Class Initialized
INFO - 2016-02-05 07:37:45 --> Language Class Initialized
INFO - 2016-02-05 07:37:45 --> Loader Class Initialized
INFO - 2016-02-05 07:37:45 --> Helper loaded: url_helper
INFO - 2016-02-05 07:37:45 --> Helper loaded: file_helper
INFO - 2016-02-05 07:37:45 --> Helper loaded: date_helper
INFO - 2016-02-05 07:37:45 --> Helper loaded: form_helper
INFO - 2016-02-05 07:37:45 --> Database Driver Class Initialized
INFO - 2016-02-05 07:37:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:37:46 --> Controller Class Initialized
INFO - 2016-02-05 07:37:46 --> Model Class Initialized
INFO - 2016-02-05 07:37:46 --> Model Class Initialized
INFO - 2016-02-05 07:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:37:46 --> Pagination Class Initialized
INFO - 2016-02-05 07:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:37:46 --> Final output sent to browser
DEBUG - 2016-02-05 07:37:46 --> Total execution time: 1.1367
INFO - 2016-02-05 07:37:47 --> Config Class Initialized
INFO - 2016-02-05 07:37:47 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:37:47 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:37:47 --> Utf8 Class Initialized
INFO - 2016-02-05 07:37:47 --> URI Class Initialized
INFO - 2016-02-05 07:37:47 --> Router Class Initialized
INFO - 2016-02-05 07:37:47 --> Output Class Initialized
INFO - 2016-02-05 07:37:47 --> Security Class Initialized
DEBUG - 2016-02-05 07:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:37:47 --> Input Class Initialized
INFO - 2016-02-05 07:37:47 --> Language Class Initialized
INFO - 2016-02-05 07:37:47 --> Loader Class Initialized
INFO - 2016-02-05 07:37:47 --> Helper loaded: url_helper
INFO - 2016-02-05 07:37:47 --> Helper loaded: file_helper
INFO - 2016-02-05 07:37:47 --> Helper loaded: date_helper
INFO - 2016-02-05 07:37:47 --> Helper loaded: form_helper
INFO - 2016-02-05 07:37:47 --> Database Driver Class Initialized
INFO - 2016-02-05 07:37:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:37:48 --> Controller Class Initialized
INFO - 2016-02-05 07:37:48 --> Model Class Initialized
INFO - 2016-02-05 07:37:48 --> Model Class Initialized
INFO - 2016-02-05 07:37:48 --> Form Validation Class Initialized
INFO - 2016-02-05 07:37:48 --> Helper loaded: text_helper
INFO - 2016-02-05 07:37:48 --> Config Class Initialized
INFO - 2016-02-05 07:37:48 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:37:48 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:37:48 --> Utf8 Class Initialized
INFO - 2016-02-05 07:37:48 --> URI Class Initialized
INFO - 2016-02-05 07:37:48 --> Router Class Initialized
INFO - 2016-02-05 07:37:48 --> Output Class Initialized
INFO - 2016-02-05 07:37:48 --> Security Class Initialized
DEBUG - 2016-02-05 07:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:37:48 --> Input Class Initialized
INFO - 2016-02-05 07:37:48 --> Language Class Initialized
INFO - 2016-02-05 07:37:48 --> Loader Class Initialized
INFO - 2016-02-05 07:37:48 --> Helper loaded: url_helper
INFO - 2016-02-05 07:37:48 --> Helper loaded: file_helper
INFO - 2016-02-05 07:37:48 --> Helper loaded: date_helper
INFO - 2016-02-05 07:37:48 --> Helper loaded: form_helper
INFO - 2016-02-05 07:37:48 --> Database Driver Class Initialized
INFO - 2016-02-05 07:37:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:37:49 --> Controller Class Initialized
INFO - 2016-02-05 07:37:49 --> Model Class Initialized
INFO - 2016-02-05 07:37:49 --> Model Class Initialized
INFO - 2016-02-05 07:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:37:49 --> Pagination Class Initialized
INFO - 2016-02-05 07:37:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:37:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:37:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:37:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:37:49 --> Final output sent to browser
DEBUG - 2016-02-05 07:37:49 --> Total execution time: 1.1253
INFO - 2016-02-05 07:37:51 --> Config Class Initialized
INFO - 2016-02-05 07:37:51 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:37:51 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:37:51 --> Utf8 Class Initialized
INFO - 2016-02-05 07:37:51 --> URI Class Initialized
INFO - 2016-02-05 07:37:51 --> Router Class Initialized
INFO - 2016-02-05 07:37:51 --> Output Class Initialized
INFO - 2016-02-05 07:37:51 --> Security Class Initialized
DEBUG - 2016-02-05 07:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:37:51 --> Input Class Initialized
INFO - 2016-02-05 07:37:51 --> Language Class Initialized
INFO - 2016-02-05 07:37:51 --> Loader Class Initialized
INFO - 2016-02-05 07:37:51 --> Helper loaded: url_helper
INFO - 2016-02-05 07:37:51 --> Helper loaded: file_helper
INFO - 2016-02-05 07:37:51 --> Helper loaded: date_helper
INFO - 2016-02-05 07:37:51 --> Helper loaded: form_helper
INFO - 2016-02-05 07:37:51 --> Database Driver Class Initialized
INFO - 2016-02-05 07:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:37:52 --> Controller Class Initialized
INFO - 2016-02-05 07:37:52 --> Model Class Initialized
INFO - 2016-02-05 07:37:52 --> Model Class Initialized
INFO - 2016-02-05 07:37:52 --> Form Validation Class Initialized
INFO - 2016-02-05 07:37:52 --> Helper loaded: text_helper
INFO - 2016-02-05 07:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:37:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:37:52 --> Final output sent to browser
DEBUG - 2016-02-05 07:37:52 --> Total execution time: 1.1472
INFO - 2016-02-05 07:37:56 --> Config Class Initialized
INFO - 2016-02-05 07:37:56 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:37:56 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:37:56 --> Utf8 Class Initialized
INFO - 2016-02-05 07:37:56 --> URI Class Initialized
INFO - 2016-02-05 07:37:56 --> Router Class Initialized
INFO - 2016-02-05 07:37:56 --> Output Class Initialized
INFO - 2016-02-05 07:37:56 --> Security Class Initialized
DEBUG - 2016-02-05 07:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:37:56 --> Input Class Initialized
INFO - 2016-02-05 07:37:56 --> Language Class Initialized
INFO - 2016-02-05 07:37:56 --> Loader Class Initialized
INFO - 2016-02-05 07:37:56 --> Helper loaded: url_helper
INFO - 2016-02-05 07:37:56 --> Helper loaded: file_helper
INFO - 2016-02-05 07:37:56 --> Helper loaded: date_helper
INFO - 2016-02-05 07:37:56 --> Helper loaded: form_helper
INFO - 2016-02-05 07:37:56 --> Database Driver Class Initialized
INFO - 2016-02-05 07:37:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:37:57 --> Controller Class Initialized
INFO - 2016-02-05 07:37:57 --> Model Class Initialized
INFO - 2016-02-05 07:37:57 --> Model Class Initialized
INFO - 2016-02-05 07:37:57 --> Form Validation Class Initialized
INFO - 2016-02-05 07:37:57 --> Helper loaded: text_helper
INFO - 2016-02-05 07:37:57 --> Config Class Initialized
INFO - 2016-02-05 07:37:57 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:37:58 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:37:58 --> Utf8 Class Initialized
INFO - 2016-02-05 07:37:58 --> URI Class Initialized
INFO - 2016-02-05 07:37:58 --> Router Class Initialized
INFO - 2016-02-05 07:37:58 --> Output Class Initialized
INFO - 2016-02-05 07:37:58 --> Security Class Initialized
DEBUG - 2016-02-05 07:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:37:58 --> Input Class Initialized
INFO - 2016-02-05 07:37:58 --> Language Class Initialized
INFO - 2016-02-05 07:37:58 --> Loader Class Initialized
INFO - 2016-02-05 07:37:58 --> Helper loaded: url_helper
INFO - 2016-02-05 07:37:58 --> Helper loaded: file_helper
INFO - 2016-02-05 07:37:58 --> Helper loaded: date_helper
INFO - 2016-02-05 07:37:58 --> Helper loaded: form_helper
INFO - 2016-02-05 07:37:58 --> Database Driver Class Initialized
INFO - 2016-02-05 07:37:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:37:59 --> Controller Class Initialized
INFO - 2016-02-05 07:37:59 --> Model Class Initialized
INFO - 2016-02-05 07:37:59 --> Model Class Initialized
INFO - 2016-02-05 07:37:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:37:59 --> Pagination Class Initialized
INFO - 2016-02-05 07:37:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:37:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:37:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:37:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:37:59 --> Final output sent to browser
DEBUG - 2016-02-05 07:37:59 --> Total execution time: 1.1496
INFO - 2016-02-05 07:38:00 --> Config Class Initialized
INFO - 2016-02-05 07:38:00 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:38:00 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:38:00 --> Utf8 Class Initialized
INFO - 2016-02-05 07:38:00 --> URI Class Initialized
INFO - 2016-02-05 07:38:00 --> Router Class Initialized
INFO - 2016-02-05 07:38:00 --> Output Class Initialized
INFO - 2016-02-05 07:38:00 --> Security Class Initialized
DEBUG - 2016-02-05 07:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:38:00 --> Input Class Initialized
INFO - 2016-02-05 07:38:00 --> Language Class Initialized
INFO - 2016-02-05 07:38:00 --> Loader Class Initialized
INFO - 2016-02-05 07:38:00 --> Helper loaded: url_helper
INFO - 2016-02-05 07:38:00 --> Helper loaded: file_helper
INFO - 2016-02-05 07:38:00 --> Helper loaded: date_helper
INFO - 2016-02-05 07:38:00 --> Helper loaded: form_helper
INFO - 2016-02-05 07:38:00 --> Database Driver Class Initialized
INFO - 2016-02-05 07:38:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:38:01 --> Controller Class Initialized
INFO - 2016-02-05 07:38:01 --> Model Class Initialized
INFO - 2016-02-05 07:38:01 --> Model Class Initialized
INFO - 2016-02-05 07:38:01 --> Form Validation Class Initialized
INFO - 2016-02-05 07:38:01 --> Helper loaded: text_helper
INFO - 2016-02-05 07:38:01 --> Config Class Initialized
INFO - 2016-02-05 07:38:01 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:38:01 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:38:01 --> Utf8 Class Initialized
INFO - 2016-02-05 07:38:01 --> URI Class Initialized
INFO - 2016-02-05 07:38:01 --> Router Class Initialized
INFO - 2016-02-05 07:38:01 --> Output Class Initialized
INFO - 2016-02-05 07:38:01 --> Security Class Initialized
DEBUG - 2016-02-05 07:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:38:01 --> Input Class Initialized
INFO - 2016-02-05 07:38:01 --> Language Class Initialized
INFO - 2016-02-05 07:38:02 --> Loader Class Initialized
INFO - 2016-02-05 07:38:02 --> Helper loaded: url_helper
INFO - 2016-02-05 07:38:02 --> Helper loaded: file_helper
INFO - 2016-02-05 07:38:02 --> Helper loaded: date_helper
INFO - 2016-02-05 07:38:02 --> Helper loaded: form_helper
INFO - 2016-02-05 07:38:02 --> Database Driver Class Initialized
INFO - 2016-02-05 07:38:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:38:03 --> Controller Class Initialized
INFO - 2016-02-05 07:38:03 --> Model Class Initialized
INFO - 2016-02-05 07:38:03 --> Model Class Initialized
INFO - 2016-02-05 07:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:38:03 --> Pagination Class Initialized
INFO - 2016-02-05 07:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:38:03 --> Final output sent to browser
DEBUG - 2016-02-05 07:38:03 --> Total execution time: 1.3076
INFO - 2016-02-05 07:38:05 --> Config Class Initialized
INFO - 2016-02-05 07:38:05 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:38:05 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:38:05 --> Utf8 Class Initialized
INFO - 2016-02-05 07:38:05 --> URI Class Initialized
INFO - 2016-02-05 07:38:05 --> Router Class Initialized
INFO - 2016-02-05 07:38:05 --> Output Class Initialized
INFO - 2016-02-05 07:38:05 --> Security Class Initialized
DEBUG - 2016-02-05 07:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:38:05 --> Input Class Initialized
INFO - 2016-02-05 07:38:05 --> Language Class Initialized
INFO - 2016-02-05 07:38:05 --> Loader Class Initialized
INFO - 2016-02-05 07:38:05 --> Helper loaded: url_helper
INFO - 2016-02-05 07:38:05 --> Helper loaded: file_helper
INFO - 2016-02-05 07:38:05 --> Helper loaded: date_helper
INFO - 2016-02-05 07:38:05 --> Helper loaded: form_helper
INFO - 2016-02-05 07:38:05 --> Database Driver Class Initialized
INFO - 2016-02-05 07:38:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:38:06 --> Controller Class Initialized
INFO - 2016-02-05 07:38:06 --> Model Class Initialized
INFO - 2016-02-05 07:38:06 --> Model Class Initialized
INFO - 2016-02-05 07:38:06 --> Form Validation Class Initialized
INFO - 2016-02-05 07:38:06 --> Helper loaded: text_helper
INFO - 2016-02-05 07:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:38:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:38:06 --> Final output sent to browser
DEBUG - 2016-02-05 07:38:06 --> Total execution time: 1.1254
INFO - 2016-02-05 07:38:09 --> Config Class Initialized
INFO - 2016-02-05 07:38:09 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:38:09 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:38:09 --> Utf8 Class Initialized
INFO - 2016-02-05 07:38:09 --> URI Class Initialized
INFO - 2016-02-05 07:38:09 --> Router Class Initialized
INFO - 2016-02-05 07:38:09 --> Output Class Initialized
INFO - 2016-02-05 07:38:09 --> Security Class Initialized
DEBUG - 2016-02-05 07:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:38:09 --> Input Class Initialized
INFO - 2016-02-05 07:38:09 --> Language Class Initialized
INFO - 2016-02-05 07:38:09 --> Loader Class Initialized
INFO - 2016-02-05 07:38:09 --> Helper loaded: url_helper
INFO - 2016-02-05 07:38:09 --> Helper loaded: file_helper
INFO - 2016-02-05 07:38:09 --> Helper loaded: date_helper
INFO - 2016-02-05 07:38:09 --> Helper loaded: form_helper
INFO - 2016-02-05 07:38:09 --> Database Driver Class Initialized
INFO - 2016-02-05 07:38:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:38:10 --> Controller Class Initialized
INFO - 2016-02-05 07:38:10 --> Model Class Initialized
INFO - 2016-02-05 07:38:10 --> Model Class Initialized
INFO - 2016-02-05 07:38:10 --> Form Validation Class Initialized
INFO - 2016-02-05 07:38:10 --> Helper loaded: text_helper
INFO - 2016-02-05 07:38:10 --> Final output sent to browser
DEBUG - 2016-02-05 07:38:10 --> Total execution time: 1.2072
INFO - 2016-02-05 07:38:14 --> Config Class Initialized
INFO - 2016-02-05 07:38:14 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:38:14 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:38:14 --> Utf8 Class Initialized
INFO - 2016-02-05 07:38:14 --> URI Class Initialized
INFO - 2016-02-05 07:38:14 --> Router Class Initialized
INFO - 2016-02-05 07:38:14 --> Output Class Initialized
INFO - 2016-02-05 07:38:14 --> Security Class Initialized
DEBUG - 2016-02-05 07:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:38:14 --> Input Class Initialized
INFO - 2016-02-05 07:38:14 --> Language Class Initialized
INFO - 2016-02-05 07:38:14 --> Loader Class Initialized
INFO - 2016-02-05 07:38:14 --> Helper loaded: url_helper
INFO - 2016-02-05 07:38:14 --> Helper loaded: file_helper
INFO - 2016-02-05 07:38:14 --> Helper loaded: date_helper
INFO - 2016-02-05 07:38:14 --> Helper loaded: form_helper
INFO - 2016-02-05 07:38:15 --> Database Driver Class Initialized
INFO - 2016-02-05 07:38:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:38:16 --> Controller Class Initialized
INFO - 2016-02-05 07:38:16 --> Model Class Initialized
INFO - 2016-02-05 07:38:16 --> Model Class Initialized
INFO - 2016-02-05 07:38:16 --> Form Validation Class Initialized
INFO - 2016-02-05 07:38:16 --> Helper loaded: text_helper
INFO - 2016-02-05 07:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:38:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:38:16 --> Final output sent to browser
DEBUG - 2016-02-05 07:38:16 --> Total execution time: 1.1136
INFO - 2016-02-05 07:38:18 --> Config Class Initialized
INFO - 2016-02-05 07:38:18 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:38:18 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:38:18 --> Utf8 Class Initialized
INFO - 2016-02-05 07:38:18 --> URI Class Initialized
DEBUG - 2016-02-05 07:38:18 --> No URI present. Default controller set.
INFO - 2016-02-05 07:38:18 --> Router Class Initialized
INFO - 2016-02-05 07:38:18 --> Output Class Initialized
INFO - 2016-02-05 07:38:18 --> Security Class Initialized
DEBUG - 2016-02-05 07:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:38:18 --> Input Class Initialized
INFO - 2016-02-05 07:38:18 --> Language Class Initialized
INFO - 2016-02-05 07:38:18 --> Loader Class Initialized
INFO - 2016-02-05 07:38:18 --> Helper loaded: url_helper
INFO - 2016-02-05 07:38:18 --> Helper loaded: file_helper
INFO - 2016-02-05 07:38:18 --> Helper loaded: date_helper
INFO - 2016-02-05 07:38:18 --> Helper loaded: form_helper
INFO - 2016-02-05 07:38:18 --> Database Driver Class Initialized
INFO - 2016-02-05 07:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:38:19 --> Controller Class Initialized
INFO - 2016-02-05 07:38:19 --> Model Class Initialized
INFO - 2016-02-05 07:38:19 --> Model Class Initialized
INFO - 2016-02-05 07:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:38:19 --> Pagination Class Initialized
INFO - 2016-02-05 07:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:38:19 --> Final output sent to browser
DEBUG - 2016-02-05 07:38:19 --> Total execution time: 1.1481
INFO - 2016-02-05 07:38:25 --> Config Class Initialized
INFO - 2016-02-05 07:38:25 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:38:25 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:38:25 --> Utf8 Class Initialized
INFO - 2016-02-05 07:38:25 --> URI Class Initialized
INFO - 2016-02-05 07:38:25 --> Router Class Initialized
INFO - 2016-02-05 07:38:25 --> Output Class Initialized
INFO - 2016-02-05 07:38:25 --> Security Class Initialized
DEBUG - 2016-02-05 07:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:38:25 --> Input Class Initialized
INFO - 2016-02-05 07:38:25 --> Language Class Initialized
INFO - 2016-02-05 07:38:25 --> Loader Class Initialized
INFO - 2016-02-05 07:38:25 --> Helper loaded: url_helper
INFO - 2016-02-05 07:38:25 --> Helper loaded: file_helper
INFO - 2016-02-05 07:38:25 --> Helper loaded: date_helper
INFO - 2016-02-05 07:38:25 --> Helper loaded: form_helper
INFO - 2016-02-05 07:38:25 --> Database Driver Class Initialized
INFO - 2016-02-05 07:38:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:38:26 --> Controller Class Initialized
INFO - 2016-02-05 07:38:26 --> Model Class Initialized
INFO - 2016-02-05 07:38:26 --> Model Class Initialized
INFO - 2016-02-05 07:38:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:38:26 --> Pagination Class Initialized
INFO - 2016-02-05 07:38:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:38:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:38:26 --> Helper loaded: text_helper
INFO - 2016-02-05 07:38:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:38:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:38:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:38:26 --> Final output sent to browser
DEBUG - 2016-02-05 07:38:26 --> Total execution time: 1.1679
INFO - 2016-02-05 07:40:54 --> Config Class Initialized
INFO - 2016-02-05 07:40:54 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:40:54 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:40:54 --> Utf8 Class Initialized
INFO - 2016-02-05 07:40:54 --> URI Class Initialized
INFO - 2016-02-05 07:40:54 --> Router Class Initialized
INFO - 2016-02-05 07:40:54 --> Output Class Initialized
INFO - 2016-02-05 07:40:54 --> Security Class Initialized
DEBUG - 2016-02-05 07:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:40:54 --> Input Class Initialized
INFO - 2016-02-05 07:40:54 --> Language Class Initialized
INFO - 2016-02-05 07:40:54 --> Loader Class Initialized
INFO - 2016-02-05 07:40:54 --> Helper loaded: url_helper
INFO - 2016-02-05 07:40:54 --> Helper loaded: file_helper
INFO - 2016-02-05 07:40:54 --> Helper loaded: date_helper
INFO - 2016-02-05 07:40:54 --> Helper loaded: form_helper
INFO - 2016-02-05 07:40:54 --> Database Driver Class Initialized
INFO - 2016-02-05 07:40:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:40:55 --> Controller Class Initialized
INFO - 2016-02-05 07:40:55 --> Model Class Initialized
INFO - 2016-02-05 07:40:55 --> Model Class Initialized
INFO - 2016-02-05 07:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:40:55 --> Pagination Class Initialized
INFO - 2016-02-05 07:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:40:56 --> Helper loaded: text_helper
INFO - 2016-02-05 07:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:40:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:40:56 --> Final output sent to browser
DEBUG - 2016-02-05 07:40:56 --> Total execution time: 1.2090
INFO - 2016-02-05 07:42:44 --> Config Class Initialized
INFO - 2016-02-05 07:42:44 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:42:44 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:42:44 --> Utf8 Class Initialized
INFO - 2016-02-05 07:42:44 --> URI Class Initialized
INFO - 2016-02-05 07:42:44 --> Router Class Initialized
INFO - 2016-02-05 07:42:44 --> Output Class Initialized
INFO - 2016-02-05 07:42:44 --> Security Class Initialized
DEBUG - 2016-02-05 07:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:42:44 --> Input Class Initialized
INFO - 2016-02-05 07:42:44 --> Language Class Initialized
INFO - 2016-02-05 07:42:44 --> Loader Class Initialized
INFO - 2016-02-05 07:42:44 --> Helper loaded: url_helper
INFO - 2016-02-05 07:42:44 --> Helper loaded: file_helper
INFO - 2016-02-05 07:42:44 --> Helper loaded: date_helper
INFO - 2016-02-05 07:42:44 --> Helper loaded: form_helper
INFO - 2016-02-05 07:42:44 --> Database Driver Class Initialized
INFO - 2016-02-05 07:42:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:42:45 --> Controller Class Initialized
INFO - 2016-02-05 07:42:45 --> Model Class Initialized
INFO - 2016-02-05 07:42:45 --> Model Class Initialized
INFO - 2016-02-05 07:42:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:42:45 --> Pagination Class Initialized
INFO - 2016-02-05 07:42:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:42:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:42:45 --> Helper loaded: text_helper
INFO - 2016-02-05 07:42:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:42:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:42:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:42:46 --> Final output sent to browser
DEBUG - 2016-02-05 07:42:46 --> Total execution time: 1.1979
INFO - 2016-02-05 07:42:52 --> Config Class Initialized
INFO - 2016-02-05 07:42:52 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:42:52 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:42:52 --> Utf8 Class Initialized
INFO - 2016-02-05 07:42:52 --> URI Class Initialized
INFO - 2016-02-05 07:42:52 --> Router Class Initialized
INFO - 2016-02-05 07:42:52 --> Output Class Initialized
INFO - 2016-02-05 07:42:52 --> Security Class Initialized
DEBUG - 2016-02-05 07:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:42:52 --> Input Class Initialized
INFO - 2016-02-05 07:42:52 --> Language Class Initialized
INFO - 2016-02-05 07:42:52 --> Loader Class Initialized
INFO - 2016-02-05 07:42:52 --> Helper loaded: url_helper
INFO - 2016-02-05 07:42:52 --> Helper loaded: file_helper
INFO - 2016-02-05 07:42:52 --> Helper loaded: date_helper
INFO - 2016-02-05 07:42:52 --> Helper loaded: form_helper
INFO - 2016-02-05 07:42:52 --> Database Driver Class Initialized
INFO - 2016-02-05 07:42:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:42:53 --> Controller Class Initialized
INFO - 2016-02-05 07:42:53 --> Model Class Initialized
INFO - 2016-02-05 07:42:53 --> Model Class Initialized
INFO - 2016-02-05 07:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:42:53 --> Pagination Class Initialized
INFO - 2016-02-05 07:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:42:53 --> Helper loaded: text_helper
INFO - 2016-02-05 07:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:42:53 --> Final output sent to browser
DEBUG - 2016-02-05 07:42:53 --> Total execution time: 1.1557
INFO - 2016-02-05 07:44:32 --> Config Class Initialized
INFO - 2016-02-05 07:44:32 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:44:32 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:44:32 --> Utf8 Class Initialized
INFO - 2016-02-05 07:44:32 --> URI Class Initialized
INFO - 2016-02-05 07:44:32 --> Router Class Initialized
INFO - 2016-02-05 07:44:32 --> Output Class Initialized
INFO - 2016-02-05 07:44:32 --> Security Class Initialized
DEBUG - 2016-02-05 07:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:44:32 --> Input Class Initialized
INFO - 2016-02-05 07:44:32 --> Language Class Initialized
INFO - 2016-02-05 07:44:32 --> Loader Class Initialized
INFO - 2016-02-05 07:44:32 --> Helper loaded: url_helper
INFO - 2016-02-05 07:44:32 --> Helper loaded: file_helper
INFO - 2016-02-05 07:44:32 --> Helper loaded: date_helper
INFO - 2016-02-05 07:44:32 --> Helper loaded: form_helper
INFO - 2016-02-05 07:44:32 --> Database Driver Class Initialized
INFO - 2016-02-05 07:44:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:44:33 --> Controller Class Initialized
INFO - 2016-02-05 07:44:33 --> Model Class Initialized
INFO - 2016-02-05 07:44:33 --> Model Class Initialized
INFO - 2016-02-05 07:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:44:33 --> Pagination Class Initialized
ERROR - 2016-02-05 07:44:33 --> Severity: Warning --> Missing argument 1 for Jboard::up_vote() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 409
ERROR - 2016-02-05 07:44:33 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 413
INFO - 2016-02-05 07:44:33 --> Config Class Initialized
INFO - 2016-02-05 07:44:33 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:44:33 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:44:33 --> Utf8 Class Initialized
INFO - 2016-02-05 07:44:33 --> URI Class Initialized
INFO - 2016-02-05 07:44:34 --> Router Class Initialized
INFO - 2016-02-05 07:44:34 --> Output Class Initialized
INFO - 2016-02-05 07:44:34 --> Security Class Initialized
DEBUG - 2016-02-05 07:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:44:34 --> Input Class Initialized
INFO - 2016-02-05 07:44:34 --> Language Class Initialized
INFO - 2016-02-05 07:44:34 --> Loader Class Initialized
INFO - 2016-02-05 07:44:34 --> Helper loaded: url_helper
INFO - 2016-02-05 07:44:34 --> Helper loaded: file_helper
INFO - 2016-02-05 07:44:34 --> Helper loaded: date_helper
INFO - 2016-02-05 07:44:34 --> Helper loaded: form_helper
INFO - 2016-02-05 07:44:34 --> Database Driver Class Initialized
INFO - 2016-02-05 07:44:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:44:35 --> Controller Class Initialized
INFO - 2016-02-05 07:44:35 --> Model Class Initialized
INFO - 2016-02-05 07:44:35 --> Model Class Initialized
INFO - 2016-02-05 07:44:35 --> Form Validation Class Initialized
INFO - 2016-02-05 07:44:35 --> Helper loaded: text_helper
INFO - 2016-02-05 07:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:44:35 --> Final output sent to browser
DEBUG - 2016-02-05 07:44:35 --> Total execution time: 1.1431
INFO - 2016-02-05 07:44:44 --> Config Class Initialized
INFO - 2016-02-05 07:44:44 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:44:44 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:44:44 --> Utf8 Class Initialized
INFO - 2016-02-05 07:44:44 --> URI Class Initialized
DEBUG - 2016-02-05 07:44:44 --> No URI present. Default controller set.
INFO - 2016-02-05 07:44:44 --> Router Class Initialized
INFO - 2016-02-05 07:44:44 --> Output Class Initialized
INFO - 2016-02-05 07:44:44 --> Security Class Initialized
DEBUG - 2016-02-05 07:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:44:44 --> Input Class Initialized
INFO - 2016-02-05 07:44:44 --> Language Class Initialized
INFO - 2016-02-05 07:44:44 --> Loader Class Initialized
INFO - 2016-02-05 07:44:44 --> Helper loaded: url_helper
INFO - 2016-02-05 07:44:44 --> Helper loaded: file_helper
INFO - 2016-02-05 07:44:44 --> Helper loaded: date_helper
INFO - 2016-02-05 07:44:44 --> Helper loaded: form_helper
INFO - 2016-02-05 07:44:44 --> Database Driver Class Initialized
INFO - 2016-02-05 07:44:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:44:45 --> Controller Class Initialized
INFO - 2016-02-05 07:44:45 --> Model Class Initialized
INFO - 2016-02-05 07:44:45 --> Model Class Initialized
INFO - 2016-02-05 07:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:44:45 --> Pagination Class Initialized
INFO - 2016-02-05 07:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:44:45 --> Final output sent to browser
DEBUG - 2016-02-05 07:44:45 --> Total execution time: 1.1207
INFO - 2016-02-05 07:44:47 --> Config Class Initialized
INFO - 2016-02-05 07:44:47 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:44:47 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:44:47 --> Utf8 Class Initialized
INFO - 2016-02-05 07:44:47 --> URI Class Initialized
INFO - 2016-02-05 07:44:47 --> Router Class Initialized
INFO - 2016-02-05 07:44:47 --> Output Class Initialized
INFO - 2016-02-05 07:44:47 --> Security Class Initialized
DEBUG - 2016-02-05 07:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:44:47 --> Input Class Initialized
INFO - 2016-02-05 07:44:47 --> Language Class Initialized
INFO - 2016-02-05 07:44:47 --> Loader Class Initialized
INFO - 2016-02-05 07:44:47 --> Helper loaded: url_helper
INFO - 2016-02-05 07:44:47 --> Helper loaded: file_helper
INFO - 2016-02-05 07:44:47 --> Helper loaded: date_helper
INFO - 2016-02-05 07:44:47 --> Helper loaded: form_helper
INFO - 2016-02-05 07:44:47 --> Database Driver Class Initialized
INFO - 2016-02-05 07:44:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:44:48 --> Controller Class Initialized
INFO - 2016-02-05 07:44:48 --> Model Class Initialized
INFO - 2016-02-05 07:44:48 --> Model Class Initialized
INFO - 2016-02-05 07:44:48 --> Form Validation Class Initialized
INFO - 2016-02-05 07:44:48 --> Helper loaded: text_helper
INFO - 2016-02-05 07:44:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:44:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:44:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 07:44:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:44:48 --> Final output sent to browser
DEBUG - 2016-02-05 07:44:48 --> Total execution time: 1.1230
INFO - 2016-02-05 07:44:52 --> Config Class Initialized
INFO - 2016-02-05 07:44:52 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:44:52 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:44:52 --> Utf8 Class Initialized
INFO - 2016-02-05 07:44:52 --> URI Class Initialized
INFO - 2016-02-05 07:44:52 --> Router Class Initialized
INFO - 2016-02-05 07:44:52 --> Output Class Initialized
INFO - 2016-02-05 07:44:52 --> Security Class Initialized
DEBUG - 2016-02-05 07:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:44:52 --> Input Class Initialized
INFO - 2016-02-05 07:44:52 --> Language Class Initialized
INFO - 2016-02-05 07:44:52 --> Loader Class Initialized
INFO - 2016-02-05 07:44:52 --> Helper loaded: url_helper
INFO - 2016-02-05 07:44:52 --> Helper loaded: file_helper
INFO - 2016-02-05 07:44:52 --> Helper loaded: date_helper
INFO - 2016-02-05 07:44:52 --> Helper loaded: form_helper
INFO - 2016-02-05 07:44:52 --> Database Driver Class Initialized
INFO - 2016-02-05 07:44:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:44:53 --> Controller Class Initialized
INFO - 2016-02-05 07:44:53 --> Model Class Initialized
INFO - 2016-02-05 07:44:53 --> Model Class Initialized
INFO - 2016-02-05 07:44:53 --> Form Validation Class Initialized
INFO - 2016-02-05 07:44:53 --> Helper loaded: text_helper
INFO - 2016-02-05 07:44:53 --> Config Class Initialized
INFO - 2016-02-05 07:44:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:44:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:44:53 --> Utf8 Class Initialized
INFO - 2016-02-05 07:44:53 --> URI Class Initialized
INFO - 2016-02-05 07:44:53 --> Router Class Initialized
INFO - 2016-02-05 07:44:53 --> Output Class Initialized
INFO - 2016-02-05 07:44:53 --> Security Class Initialized
DEBUG - 2016-02-05 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:44:53 --> Input Class Initialized
INFO - 2016-02-05 07:44:53 --> Language Class Initialized
INFO - 2016-02-05 07:44:53 --> Loader Class Initialized
INFO - 2016-02-05 07:44:53 --> Helper loaded: url_helper
INFO - 2016-02-05 07:44:53 --> Helper loaded: file_helper
INFO - 2016-02-05 07:44:53 --> Helper loaded: date_helper
INFO - 2016-02-05 07:44:53 --> Helper loaded: form_helper
INFO - 2016-02-05 07:44:53 --> Database Driver Class Initialized
INFO - 2016-02-05 07:44:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:44:54 --> Controller Class Initialized
INFO - 2016-02-05 07:44:54 --> Model Class Initialized
INFO - 2016-02-05 07:44:54 --> Model Class Initialized
INFO - 2016-02-05 07:44:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:44:54 --> Pagination Class Initialized
INFO - 2016-02-05 07:44:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:44:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:44:55 --> Final output sent to browser
DEBUG - 2016-02-05 07:44:55 --> Total execution time: 1.1388
INFO - 2016-02-05 07:45:02 --> Config Class Initialized
INFO - 2016-02-05 07:45:02 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:45:02 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:45:02 --> Utf8 Class Initialized
INFO - 2016-02-05 07:45:02 --> URI Class Initialized
INFO - 2016-02-05 07:45:02 --> Router Class Initialized
INFO - 2016-02-05 07:45:02 --> Output Class Initialized
INFO - 2016-02-05 07:45:02 --> Security Class Initialized
DEBUG - 2016-02-05 07:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:45:02 --> Input Class Initialized
INFO - 2016-02-05 07:45:02 --> Language Class Initialized
INFO - 2016-02-05 07:45:02 --> Loader Class Initialized
INFO - 2016-02-05 07:45:02 --> Helper loaded: url_helper
INFO - 2016-02-05 07:45:02 --> Helper loaded: file_helper
INFO - 2016-02-05 07:45:02 --> Helper loaded: date_helper
INFO - 2016-02-05 07:45:02 --> Helper loaded: form_helper
INFO - 2016-02-05 07:45:02 --> Database Driver Class Initialized
INFO - 2016-02-05 07:45:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:45:03 --> Controller Class Initialized
INFO - 2016-02-05 07:45:03 --> Model Class Initialized
INFO - 2016-02-05 07:45:03 --> Model Class Initialized
INFO - 2016-02-05 07:45:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:45:03 --> Pagination Class Initialized
ERROR - 2016-02-05 07:45:03 --> Severity: Warning --> Missing argument 1 for Jboard::up_vote() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 409
ERROR - 2016-02-05 07:45:03 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 419
INFO - 2016-02-05 07:45:03 --> Final output sent to browser
DEBUG - 2016-02-05 07:45:03 --> Total execution time: 1.1134
INFO - 2016-02-05 07:50:42 --> Config Class Initialized
INFO - 2016-02-05 07:50:42 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:50:42 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:50:42 --> Utf8 Class Initialized
INFO - 2016-02-05 07:50:42 --> URI Class Initialized
INFO - 2016-02-05 07:50:42 --> Router Class Initialized
INFO - 2016-02-05 07:50:42 --> Output Class Initialized
INFO - 2016-02-05 07:50:42 --> Security Class Initialized
DEBUG - 2016-02-05 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:50:42 --> Input Class Initialized
INFO - 2016-02-05 07:50:42 --> Language Class Initialized
INFO - 2016-02-05 07:50:42 --> Loader Class Initialized
INFO - 2016-02-05 07:50:43 --> Helper loaded: url_helper
INFO - 2016-02-05 07:50:43 --> Helper loaded: file_helper
INFO - 2016-02-05 07:50:43 --> Helper loaded: date_helper
INFO - 2016-02-05 07:50:43 --> Helper loaded: form_helper
INFO - 2016-02-05 07:50:43 --> Database Driver Class Initialized
INFO - 2016-02-05 07:50:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:50:44 --> Controller Class Initialized
INFO - 2016-02-05 07:50:44 --> Model Class Initialized
INFO - 2016-02-05 07:50:44 --> Model Class Initialized
INFO - 2016-02-05 07:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:50:44 --> Pagination Class Initialized
ERROR - 2016-02-05 07:50:44 --> Severity: Warning --> Missing argument 1 for Jboard::up_vote() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 411
ERROR - 2016-02-05 07:50:44 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 421
ERROR - 2016-02-05 07:50:44 --> Severity: Notice --> Undefined variable: query C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 150
ERROR - 2016-02-05 07:50:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 150
ERROR - 2016-02-05 07:50:44 --> Severity: Error --> Call to a member function get() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 150
INFO - 2016-02-05 07:50:49 --> Config Class Initialized
INFO - 2016-02-05 07:50:49 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:50:49 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:50:49 --> Utf8 Class Initialized
INFO - 2016-02-05 07:50:49 --> URI Class Initialized
INFO - 2016-02-05 07:50:49 --> Router Class Initialized
INFO - 2016-02-05 07:50:49 --> Output Class Initialized
INFO - 2016-02-05 07:50:49 --> Security Class Initialized
DEBUG - 2016-02-05 07:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:50:49 --> Input Class Initialized
INFO - 2016-02-05 07:50:49 --> Language Class Initialized
INFO - 2016-02-05 07:50:49 --> Loader Class Initialized
INFO - 2016-02-05 07:50:49 --> Helper loaded: url_helper
INFO - 2016-02-05 07:50:49 --> Helper loaded: file_helper
INFO - 2016-02-05 07:50:49 --> Helper loaded: date_helper
INFO - 2016-02-05 07:50:49 --> Helper loaded: form_helper
INFO - 2016-02-05 07:50:49 --> Database Driver Class Initialized
INFO - 2016-02-05 07:50:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:50:50 --> Controller Class Initialized
INFO - 2016-02-05 07:50:50 --> Model Class Initialized
INFO - 2016-02-05 07:50:50 --> Model Class Initialized
INFO - 2016-02-05 07:50:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:50:50 --> Pagination Class Initialized
INFO - 2016-02-05 07:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 07:50:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:50:50 --> Final output sent to browser
DEBUG - 2016-02-05 07:50:50 --> Total execution time: 1.1133
INFO - 2016-02-05 07:50:53 --> Config Class Initialized
INFO - 2016-02-05 07:50:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:50:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:50:53 --> Utf8 Class Initialized
INFO - 2016-02-05 07:50:53 --> URI Class Initialized
INFO - 2016-02-05 07:50:53 --> Router Class Initialized
INFO - 2016-02-05 07:50:53 --> Output Class Initialized
INFO - 2016-02-05 07:50:53 --> Security Class Initialized
DEBUG - 2016-02-05 07:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:50:53 --> Input Class Initialized
INFO - 2016-02-05 07:50:53 --> Language Class Initialized
INFO - 2016-02-05 07:50:53 --> Loader Class Initialized
INFO - 2016-02-05 07:50:53 --> Helper loaded: url_helper
INFO - 2016-02-05 07:50:53 --> Helper loaded: file_helper
INFO - 2016-02-05 07:50:53 --> Helper loaded: date_helper
INFO - 2016-02-05 07:50:53 --> Helper loaded: form_helper
INFO - 2016-02-05 07:50:53 --> Database Driver Class Initialized
INFO - 2016-02-05 07:50:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:50:54 --> Controller Class Initialized
INFO - 2016-02-05 07:50:54 --> Model Class Initialized
INFO - 2016-02-05 07:50:54 --> Model Class Initialized
INFO - 2016-02-05 07:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:50:54 --> Pagination Class Initialized
INFO - 2016-02-05 07:50:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:50:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:50:54 --> Helper loaded: text_helper
ERROR - 2016-02-05 07:50:54 --> Severity: Notice --> Undefined variable: query C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 150
ERROR - 2016-02-05 07:50:54 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 150
ERROR - 2016-02-05 07:50:54 --> Severity: Error --> Call to a member function get() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 150
INFO - 2016-02-05 07:51:31 --> Config Class Initialized
INFO - 2016-02-05 07:51:31 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:51:31 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:51:31 --> Utf8 Class Initialized
INFO - 2016-02-05 07:51:31 --> URI Class Initialized
INFO - 2016-02-05 07:51:31 --> Router Class Initialized
INFO - 2016-02-05 07:51:31 --> Output Class Initialized
INFO - 2016-02-05 07:51:31 --> Security Class Initialized
DEBUG - 2016-02-05 07:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:51:31 --> Input Class Initialized
INFO - 2016-02-05 07:51:31 --> Language Class Initialized
INFO - 2016-02-05 07:51:31 --> Loader Class Initialized
INFO - 2016-02-05 07:51:31 --> Helper loaded: url_helper
INFO - 2016-02-05 07:51:31 --> Helper loaded: file_helper
INFO - 2016-02-05 07:51:31 --> Helper loaded: date_helper
INFO - 2016-02-05 07:51:31 --> Helper loaded: form_helper
INFO - 2016-02-05 07:51:31 --> Database Driver Class Initialized
INFO - 2016-02-05 07:51:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:51:32 --> Controller Class Initialized
INFO - 2016-02-05 07:51:32 --> Model Class Initialized
INFO - 2016-02-05 07:51:32 --> Model Class Initialized
INFO - 2016-02-05 07:51:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:51:32 --> Pagination Class Initialized
INFO - 2016-02-05 07:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:51:32 --> Helper loaded: text_helper
INFO - 2016-02-05 07:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:51:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:51:32 --> Final output sent to browser
DEBUG - 2016-02-05 07:51:32 --> Total execution time: 1.2580
INFO - 2016-02-05 07:52:17 --> Config Class Initialized
INFO - 2016-02-05 07:52:17 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:52:17 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:52:17 --> Utf8 Class Initialized
INFO - 2016-02-05 07:52:17 --> URI Class Initialized
INFO - 2016-02-05 07:52:17 --> Router Class Initialized
INFO - 2016-02-05 07:52:17 --> Output Class Initialized
INFO - 2016-02-05 07:52:17 --> Security Class Initialized
DEBUG - 2016-02-05 07:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:52:17 --> Input Class Initialized
INFO - 2016-02-05 07:52:17 --> Language Class Initialized
INFO - 2016-02-05 07:52:17 --> Loader Class Initialized
INFO - 2016-02-05 07:52:17 --> Helper loaded: url_helper
INFO - 2016-02-05 07:52:17 --> Helper loaded: file_helper
INFO - 2016-02-05 07:52:17 --> Helper loaded: date_helper
INFO - 2016-02-05 07:52:17 --> Helper loaded: form_helper
INFO - 2016-02-05 07:52:17 --> Database Driver Class Initialized
INFO - 2016-02-05 07:52:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:52:18 --> Controller Class Initialized
INFO - 2016-02-05 07:52:18 --> Model Class Initialized
INFO - 2016-02-05 07:52:18 --> Model Class Initialized
INFO - 2016-02-05 07:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:52:18 --> Pagination Class Initialized
INFO - 2016-02-05 07:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:52:18 --> Helper loaded: text_helper
ERROR - 2016-02-05 07:52:18 --> Severity: Notice --> Undefined variable: total_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 127
INFO - 2016-02-05 07:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:52:18 --> Final output sent to browser
DEBUG - 2016-02-05 07:52:18 --> Total execution time: 1.2277
INFO - 2016-02-05 07:53:14 --> Config Class Initialized
INFO - 2016-02-05 07:53:14 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:53:14 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:53:14 --> Utf8 Class Initialized
INFO - 2016-02-05 07:53:14 --> URI Class Initialized
INFO - 2016-02-05 07:53:14 --> Router Class Initialized
INFO - 2016-02-05 07:53:14 --> Output Class Initialized
INFO - 2016-02-05 07:53:14 --> Security Class Initialized
DEBUG - 2016-02-05 07:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:53:14 --> Input Class Initialized
INFO - 2016-02-05 07:53:14 --> Language Class Initialized
INFO - 2016-02-05 07:53:14 --> Loader Class Initialized
INFO - 2016-02-05 07:53:14 --> Helper loaded: url_helper
INFO - 2016-02-05 07:53:14 --> Helper loaded: file_helper
INFO - 2016-02-05 07:53:14 --> Helper loaded: date_helper
INFO - 2016-02-05 07:53:14 --> Helper loaded: form_helper
INFO - 2016-02-05 07:53:14 --> Database Driver Class Initialized
INFO - 2016-02-05 07:53:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:53:15 --> Controller Class Initialized
INFO - 2016-02-05 07:53:15 --> Model Class Initialized
INFO - 2016-02-05 07:53:15 --> Model Class Initialized
INFO - 2016-02-05 07:53:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:53:15 --> Pagination Class Initialized
INFO - 2016-02-05 07:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:53:15 --> Helper loaded: text_helper
INFO - 2016-02-05 07:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:53:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:53:15 --> Final output sent to browser
DEBUG - 2016-02-05 07:53:15 --> Total execution time: 1.2361
INFO - 2016-02-05 07:55:07 --> Config Class Initialized
INFO - 2016-02-05 07:55:07 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:55:07 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:55:07 --> Utf8 Class Initialized
INFO - 2016-02-05 07:55:07 --> URI Class Initialized
INFO - 2016-02-05 07:55:07 --> Router Class Initialized
INFO - 2016-02-05 07:55:07 --> Output Class Initialized
INFO - 2016-02-05 07:55:07 --> Security Class Initialized
DEBUG - 2016-02-05 07:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:55:07 --> Input Class Initialized
INFO - 2016-02-05 07:55:07 --> Language Class Initialized
INFO - 2016-02-05 07:55:07 --> Loader Class Initialized
INFO - 2016-02-05 07:55:07 --> Helper loaded: url_helper
INFO - 2016-02-05 07:55:07 --> Helper loaded: file_helper
INFO - 2016-02-05 07:55:07 --> Helper loaded: date_helper
INFO - 2016-02-05 07:55:07 --> Helper loaded: form_helper
INFO - 2016-02-05 07:55:07 --> Database Driver Class Initialized
INFO - 2016-02-05 07:55:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:55:08 --> Controller Class Initialized
INFO - 2016-02-05 07:55:08 --> Model Class Initialized
INFO - 2016-02-05 07:55:08 --> Model Class Initialized
INFO - 2016-02-05 07:55:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:55:08 --> Pagination Class Initialized
INFO - 2016-02-05 07:55:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:55:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:55:08 --> Helper loaded: text_helper
ERROR - 2016-02-05 07:55:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
INFO - 2016-02-05 07:55:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:55:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:55:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:55:08 --> Final output sent to browser
DEBUG - 2016-02-05 07:55:08 --> Total execution time: 1.3098
INFO - 2016-02-05 07:56:20 --> Config Class Initialized
INFO - 2016-02-05 07:56:21 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:56:21 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:56:21 --> Utf8 Class Initialized
INFO - 2016-02-05 07:56:21 --> URI Class Initialized
INFO - 2016-02-05 07:56:21 --> Router Class Initialized
INFO - 2016-02-05 07:56:21 --> Output Class Initialized
INFO - 2016-02-05 07:56:21 --> Security Class Initialized
DEBUG - 2016-02-05 07:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:56:21 --> Input Class Initialized
INFO - 2016-02-05 07:56:21 --> Language Class Initialized
INFO - 2016-02-05 07:56:21 --> Loader Class Initialized
INFO - 2016-02-05 07:56:21 --> Helper loaded: url_helper
INFO - 2016-02-05 07:56:21 --> Helper loaded: file_helper
INFO - 2016-02-05 07:56:21 --> Helper loaded: date_helper
INFO - 2016-02-05 07:56:21 --> Helper loaded: form_helper
INFO - 2016-02-05 07:56:21 --> Database Driver Class Initialized
INFO - 2016-02-05 07:56:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:56:22 --> Controller Class Initialized
INFO - 2016-02-05 07:56:22 --> Model Class Initialized
INFO - 2016-02-05 07:56:22 --> Model Class Initialized
INFO - 2016-02-05 07:56:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:56:22 --> Pagination Class Initialized
INFO - 2016-02-05 07:56:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:56:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:56:22 --> Helper loaded: text_helper
ERROR - 2016-02-05 07:56:22 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
INFO - 2016-02-05 07:56:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:56:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:56:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:56:22 --> Final output sent to browser
DEBUG - 2016-02-05 07:56:22 --> Total execution time: 1.2648
INFO - 2016-02-05 07:57:48 --> Config Class Initialized
INFO - 2016-02-05 07:57:48 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:57:48 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:57:48 --> Utf8 Class Initialized
INFO - 2016-02-05 07:57:48 --> URI Class Initialized
INFO - 2016-02-05 07:57:48 --> Router Class Initialized
INFO - 2016-02-05 07:57:48 --> Output Class Initialized
INFO - 2016-02-05 07:57:48 --> Security Class Initialized
DEBUG - 2016-02-05 07:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:57:48 --> Input Class Initialized
INFO - 2016-02-05 07:57:48 --> Language Class Initialized
INFO - 2016-02-05 07:57:48 --> Loader Class Initialized
INFO - 2016-02-05 07:57:48 --> Helper loaded: url_helper
INFO - 2016-02-05 07:57:48 --> Helper loaded: file_helper
INFO - 2016-02-05 07:57:48 --> Helper loaded: date_helper
INFO - 2016-02-05 07:57:48 --> Helper loaded: form_helper
INFO - 2016-02-05 07:57:48 --> Database Driver Class Initialized
INFO - 2016-02-05 07:57:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:57:49 --> Controller Class Initialized
INFO - 2016-02-05 07:57:49 --> Model Class Initialized
INFO - 2016-02-05 07:57:49 --> Model Class Initialized
INFO - 2016-02-05 07:57:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:57:49 --> Pagination Class Initialized
INFO - 2016-02-05 07:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:57:49 --> Helper loaded: text_helper
INFO - 2016-02-05 07:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:57:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:57:49 --> Final output sent to browser
DEBUG - 2016-02-05 07:57:49 --> Total execution time: 1.2261
INFO - 2016-02-05 07:58:17 --> Config Class Initialized
INFO - 2016-02-05 07:58:17 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:58:17 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:58:17 --> Utf8 Class Initialized
INFO - 2016-02-05 07:58:17 --> URI Class Initialized
INFO - 2016-02-05 07:58:17 --> Router Class Initialized
INFO - 2016-02-05 07:58:17 --> Output Class Initialized
INFO - 2016-02-05 07:58:17 --> Security Class Initialized
DEBUG - 2016-02-05 07:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:58:17 --> Input Class Initialized
INFO - 2016-02-05 07:58:17 --> Language Class Initialized
INFO - 2016-02-05 07:58:17 --> Loader Class Initialized
INFO - 2016-02-05 07:58:17 --> Helper loaded: url_helper
INFO - 2016-02-05 07:58:17 --> Helper loaded: file_helper
INFO - 2016-02-05 07:58:17 --> Helper loaded: date_helper
INFO - 2016-02-05 07:58:17 --> Helper loaded: form_helper
INFO - 2016-02-05 07:58:17 --> Database Driver Class Initialized
INFO - 2016-02-05 07:58:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:58:18 --> Controller Class Initialized
INFO - 2016-02-05 07:58:18 --> Model Class Initialized
INFO - 2016-02-05 07:58:18 --> Model Class Initialized
INFO - 2016-02-05 07:58:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:58:18 --> Pagination Class Initialized
INFO - 2016-02-05 07:58:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:58:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:58:18 --> Helper loaded: text_helper
INFO - 2016-02-05 07:58:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:58:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:58:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:58:18 --> Final output sent to browser
DEBUG - 2016-02-05 07:58:18 --> Total execution time: 1.2848
INFO - 2016-02-05 07:59:13 --> Config Class Initialized
INFO - 2016-02-05 07:59:13 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:59:13 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:59:13 --> Utf8 Class Initialized
INFO - 2016-02-05 07:59:13 --> URI Class Initialized
INFO - 2016-02-05 07:59:13 --> Router Class Initialized
INFO - 2016-02-05 07:59:13 --> Output Class Initialized
INFO - 2016-02-05 07:59:13 --> Security Class Initialized
DEBUG - 2016-02-05 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:59:13 --> Input Class Initialized
INFO - 2016-02-05 07:59:13 --> Language Class Initialized
INFO - 2016-02-05 07:59:13 --> Loader Class Initialized
INFO - 2016-02-05 07:59:13 --> Helper loaded: url_helper
INFO - 2016-02-05 07:59:13 --> Helper loaded: file_helper
INFO - 2016-02-05 07:59:13 --> Helper loaded: date_helper
INFO - 2016-02-05 07:59:13 --> Helper loaded: form_helper
INFO - 2016-02-05 07:59:13 --> Database Driver Class Initialized
INFO - 2016-02-05 07:59:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:59:14 --> Controller Class Initialized
INFO - 2016-02-05 07:59:14 --> Model Class Initialized
INFO - 2016-02-05 07:59:14 --> Model Class Initialized
INFO - 2016-02-05 07:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:59:14 --> Pagination Class Initialized
INFO - 2016-02-05 07:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:59:14 --> Helper loaded: text_helper
ERROR - 2016-02-05 07:59:14 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
INFO - 2016-02-05 07:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:59:14 --> Final output sent to browser
DEBUG - 2016-02-05 07:59:14 --> Total execution time: 1.2349
INFO - 2016-02-05 07:59:36 --> Config Class Initialized
INFO - 2016-02-05 07:59:36 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:59:36 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:59:36 --> Utf8 Class Initialized
INFO - 2016-02-05 07:59:36 --> URI Class Initialized
INFO - 2016-02-05 07:59:36 --> Router Class Initialized
INFO - 2016-02-05 07:59:36 --> Output Class Initialized
INFO - 2016-02-05 07:59:36 --> Security Class Initialized
DEBUG - 2016-02-05 07:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:59:36 --> Input Class Initialized
INFO - 2016-02-05 07:59:36 --> Language Class Initialized
INFO - 2016-02-05 07:59:36 --> Loader Class Initialized
INFO - 2016-02-05 07:59:36 --> Helper loaded: url_helper
INFO - 2016-02-05 07:59:36 --> Helper loaded: file_helper
INFO - 2016-02-05 07:59:36 --> Helper loaded: date_helper
INFO - 2016-02-05 07:59:36 --> Helper loaded: form_helper
INFO - 2016-02-05 07:59:36 --> Database Driver Class Initialized
INFO - 2016-02-05 07:59:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:59:37 --> Controller Class Initialized
INFO - 2016-02-05 07:59:37 --> Model Class Initialized
INFO - 2016-02-05 07:59:37 --> Model Class Initialized
INFO - 2016-02-05 07:59:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:59:37 --> Pagination Class Initialized
INFO - 2016-02-05 07:59:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:59:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:59:37 --> Helper loaded: text_helper
ERROR - 2016-02-05 07:59:37 --> Severity: Notice --> Undefined variable: total_like C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-02-05 07:59:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
INFO - 2016-02-05 07:59:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:59:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:59:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:59:37 --> Final output sent to browser
DEBUG - 2016-02-05 07:59:37 --> Total execution time: 1.2389
INFO - 2016-02-05 07:59:46 --> Config Class Initialized
INFO - 2016-02-05 07:59:46 --> Hooks Class Initialized
DEBUG - 2016-02-05 07:59:46 --> UTF-8 Support Enabled
INFO - 2016-02-05 07:59:46 --> Utf8 Class Initialized
INFO - 2016-02-05 07:59:46 --> URI Class Initialized
INFO - 2016-02-05 07:59:46 --> Router Class Initialized
INFO - 2016-02-05 07:59:46 --> Output Class Initialized
INFO - 2016-02-05 07:59:46 --> Security Class Initialized
DEBUG - 2016-02-05 07:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 07:59:46 --> Input Class Initialized
INFO - 2016-02-05 07:59:46 --> Language Class Initialized
INFO - 2016-02-05 07:59:46 --> Loader Class Initialized
INFO - 2016-02-05 07:59:46 --> Helper loaded: url_helper
INFO - 2016-02-05 07:59:46 --> Helper loaded: file_helper
INFO - 2016-02-05 07:59:46 --> Helper loaded: date_helper
INFO - 2016-02-05 07:59:46 --> Helper loaded: form_helper
INFO - 2016-02-05 07:59:46 --> Database Driver Class Initialized
INFO - 2016-02-05 07:59:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 07:59:47 --> Controller Class Initialized
INFO - 2016-02-05 07:59:47 --> Model Class Initialized
INFO - 2016-02-05 07:59:47 --> Model Class Initialized
INFO - 2016-02-05 07:59:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 07:59:47 --> Pagination Class Initialized
INFO - 2016-02-05 07:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 07:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 07:59:47 --> Helper loaded: text_helper
INFO - 2016-02-05 07:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 07:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 07:59:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 07:59:47 --> Final output sent to browser
DEBUG - 2016-02-05 07:59:47 --> Total execution time: 1.2785
INFO - 2016-02-05 09:08:45 --> Config Class Initialized
INFO - 2016-02-05 09:08:45 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:08:45 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:08:45 --> Utf8 Class Initialized
INFO - 2016-02-05 09:08:45 --> URI Class Initialized
DEBUG - 2016-02-05 09:08:45 --> No URI present. Default controller set.
INFO - 2016-02-05 09:08:45 --> Router Class Initialized
INFO - 2016-02-05 09:08:45 --> Output Class Initialized
INFO - 2016-02-05 09:08:45 --> Security Class Initialized
DEBUG - 2016-02-05 09:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:08:45 --> Input Class Initialized
INFO - 2016-02-05 09:08:45 --> Language Class Initialized
INFO - 2016-02-05 09:08:45 --> Loader Class Initialized
INFO - 2016-02-05 09:08:45 --> Helper loaded: url_helper
INFO - 2016-02-05 09:08:45 --> Helper loaded: file_helper
INFO - 2016-02-05 09:08:45 --> Helper loaded: date_helper
INFO - 2016-02-05 09:08:45 --> Helper loaded: form_helper
INFO - 2016-02-05 09:08:45 --> Database Driver Class Initialized
INFO - 2016-02-05 09:08:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:08:46 --> Controller Class Initialized
INFO - 2016-02-05 09:08:46 --> Model Class Initialized
INFO - 2016-02-05 09:08:46 --> Model Class Initialized
INFO - 2016-02-05 09:08:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 09:08:46 --> Pagination Class Initialized
INFO - 2016-02-05 09:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 09:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:08:46 --> Final output sent to browser
DEBUG - 2016-02-05 09:08:46 --> Total execution time: 1.1188
INFO - 2016-02-05 09:08:49 --> Config Class Initialized
INFO - 2016-02-05 09:08:49 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:08:49 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:08:49 --> Utf8 Class Initialized
INFO - 2016-02-05 09:08:49 --> URI Class Initialized
INFO - 2016-02-05 09:08:49 --> Router Class Initialized
INFO - 2016-02-05 09:08:49 --> Output Class Initialized
INFO - 2016-02-05 09:08:49 --> Security Class Initialized
DEBUG - 2016-02-05 09:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:08:49 --> Input Class Initialized
INFO - 2016-02-05 09:08:49 --> Language Class Initialized
INFO - 2016-02-05 09:08:49 --> Loader Class Initialized
INFO - 2016-02-05 09:08:49 --> Helper loaded: url_helper
INFO - 2016-02-05 09:08:49 --> Helper loaded: file_helper
INFO - 2016-02-05 09:08:49 --> Helper loaded: date_helper
INFO - 2016-02-05 09:08:49 --> Helper loaded: form_helper
INFO - 2016-02-05 09:08:49 --> Database Driver Class Initialized
INFO - 2016-02-05 09:08:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:08:50 --> Controller Class Initialized
INFO - 2016-02-05 09:08:50 --> Model Class Initialized
INFO - 2016-02-05 09:08:50 --> Model Class Initialized
INFO - 2016-02-05 09:08:50 --> Form Validation Class Initialized
INFO - 2016-02-05 09:08:50 --> Helper loaded: text_helper
INFO - 2016-02-05 09:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:08:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:08:50 --> Final output sent to browser
DEBUG - 2016-02-05 09:08:50 --> Total execution time: 1.1116
INFO - 2016-02-05 09:09:04 --> Config Class Initialized
INFO - 2016-02-05 09:09:04 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:09:04 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:09:04 --> Utf8 Class Initialized
INFO - 2016-02-05 09:09:04 --> URI Class Initialized
INFO - 2016-02-05 09:09:04 --> Router Class Initialized
INFO - 2016-02-05 09:09:04 --> Output Class Initialized
INFO - 2016-02-05 09:09:04 --> Security Class Initialized
DEBUG - 2016-02-05 09:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:09:05 --> Input Class Initialized
INFO - 2016-02-05 09:09:05 --> Language Class Initialized
INFO - 2016-02-05 09:09:05 --> Loader Class Initialized
INFO - 2016-02-05 09:09:05 --> Helper loaded: url_helper
INFO - 2016-02-05 09:09:05 --> Helper loaded: file_helper
INFO - 2016-02-05 09:09:05 --> Helper loaded: date_helper
INFO - 2016-02-05 09:09:05 --> Helper loaded: form_helper
INFO - 2016-02-05 09:09:05 --> Database Driver Class Initialized
INFO - 2016-02-05 09:09:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:09:06 --> Controller Class Initialized
INFO - 2016-02-05 09:09:06 --> Model Class Initialized
INFO - 2016-02-05 09:09:06 --> Model Class Initialized
INFO - 2016-02-05 09:09:06 --> Form Validation Class Initialized
INFO - 2016-02-05 09:09:06 --> Helper loaded: text_helper
INFO - 2016-02-05 09:09:06 --> Config Class Initialized
INFO - 2016-02-05 09:09:06 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:09:06 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:09:06 --> Utf8 Class Initialized
INFO - 2016-02-05 09:09:06 --> URI Class Initialized
INFO - 2016-02-05 09:09:06 --> Router Class Initialized
INFO - 2016-02-05 09:09:06 --> Output Class Initialized
INFO - 2016-02-05 09:09:06 --> Security Class Initialized
DEBUG - 2016-02-05 09:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:09:06 --> Input Class Initialized
INFO - 2016-02-05 09:09:06 --> Language Class Initialized
INFO - 2016-02-05 09:09:06 --> Loader Class Initialized
INFO - 2016-02-05 09:09:06 --> Helper loaded: url_helper
INFO - 2016-02-05 09:09:06 --> Helper loaded: file_helper
INFO - 2016-02-05 09:09:06 --> Helper loaded: date_helper
INFO - 2016-02-05 09:09:06 --> Helper loaded: form_helper
INFO - 2016-02-05 09:09:06 --> Database Driver Class Initialized
INFO - 2016-02-05 09:09:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:09:07 --> Controller Class Initialized
INFO - 2016-02-05 09:09:07 --> Model Class Initialized
INFO - 2016-02-05 09:09:07 --> Model Class Initialized
INFO - 2016-02-05 09:09:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 09:09:07 --> Pagination Class Initialized
INFO - 2016-02-05 09:09:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:09:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:09:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 09:09:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:09:07 --> Final output sent to browser
DEBUG - 2016-02-05 09:09:07 --> Total execution time: 1.1358
INFO - 2016-02-05 09:11:26 --> Config Class Initialized
INFO - 2016-02-05 09:11:26 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:11:26 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:11:26 --> Utf8 Class Initialized
INFO - 2016-02-05 09:11:26 --> URI Class Initialized
INFO - 2016-02-05 09:11:26 --> Router Class Initialized
INFO - 2016-02-05 09:11:26 --> Output Class Initialized
INFO - 2016-02-05 09:11:26 --> Security Class Initialized
DEBUG - 2016-02-05 09:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:11:26 --> Input Class Initialized
INFO - 2016-02-05 09:11:26 --> Language Class Initialized
INFO - 2016-02-05 09:11:26 --> Loader Class Initialized
INFO - 2016-02-05 09:11:26 --> Helper loaded: url_helper
INFO - 2016-02-05 09:11:26 --> Helper loaded: file_helper
INFO - 2016-02-05 09:11:26 --> Helper loaded: date_helper
INFO - 2016-02-05 09:11:26 --> Helper loaded: form_helper
INFO - 2016-02-05 09:11:26 --> Database Driver Class Initialized
INFO - 2016-02-05 09:11:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:11:27 --> Controller Class Initialized
INFO - 2016-02-05 09:11:27 --> Model Class Initialized
INFO - 2016-02-05 09:11:27 --> Model Class Initialized
INFO - 2016-02-05 09:11:27 --> Form Validation Class Initialized
INFO - 2016-02-05 09:11:27 --> Helper loaded: text_helper
INFO - 2016-02-05 09:11:27 --> Config Class Initialized
INFO - 2016-02-05 09:11:27 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:11:27 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:11:27 --> Utf8 Class Initialized
INFO - 2016-02-05 09:11:27 --> URI Class Initialized
INFO - 2016-02-05 09:11:27 --> Router Class Initialized
INFO - 2016-02-05 09:11:27 --> Output Class Initialized
INFO - 2016-02-05 09:11:27 --> Security Class Initialized
DEBUG - 2016-02-05 09:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:11:27 --> Input Class Initialized
INFO - 2016-02-05 09:11:27 --> Language Class Initialized
INFO - 2016-02-05 09:11:27 --> Loader Class Initialized
INFO - 2016-02-05 09:11:27 --> Helper loaded: url_helper
INFO - 2016-02-05 09:11:27 --> Helper loaded: file_helper
INFO - 2016-02-05 09:11:27 --> Helper loaded: date_helper
INFO - 2016-02-05 09:11:27 --> Helper loaded: form_helper
INFO - 2016-02-05 09:11:27 --> Database Driver Class Initialized
INFO - 2016-02-05 09:11:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:11:28 --> Controller Class Initialized
INFO - 2016-02-05 09:11:28 --> Model Class Initialized
INFO - 2016-02-05 09:11:28 --> Model Class Initialized
INFO - 2016-02-05 09:11:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 09:11:28 --> Pagination Class Initialized
INFO - 2016-02-05 09:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 09:11:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:11:28 --> Final output sent to browser
DEBUG - 2016-02-05 09:11:28 --> Total execution time: 1.1315
INFO - 2016-02-05 09:11:30 --> Config Class Initialized
INFO - 2016-02-05 09:11:30 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:11:30 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:11:30 --> Utf8 Class Initialized
INFO - 2016-02-05 09:11:30 --> URI Class Initialized
INFO - 2016-02-05 09:11:30 --> Router Class Initialized
INFO - 2016-02-05 09:11:30 --> Output Class Initialized
INFO - 2016-02-05 09:11:30 --> Security Class Initialized
DEBUG - 2016-02-05 09:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:11:30 --> Input Class Initialized
INFO - 2016-02-05 09:11:30 --> Language Class Initialized
INFO - 2016-02-05 09:11:31 --> Loader Class Initialized
INFO - 2016-02-05 09:11:31 --> Helper loaded: url_helper
INFO - 2016-02-05 09:11:31 --> Helper loaded: file_helper
INFO - 2016-02-05 09:11:31 --> Helper loaded: date_helper
INFO - 2016-02-05 09:11:31 --> Helper loaded: form_helper
INFO - 2016-02-05 09:11:31 --> Database Driver Class Initialized
INFO - 2016-02-05 09:11:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:11:32 --> Controller Class Initialized
INFO - 2016-02-05 09:11:32 --> Model Class Initialized
INFO - 2016-02-05 09:11:32 --> Model Class Initialized
INFO - 2016-02-05 09:11:32 --> Form Validation Class Initialized
INFO - 2016-02-05 09:11:32 --> Helper loaded: text_helper
INFO - 2016-02-05 09:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:11:32 --> Final output sent to browser
DEBUG - 2016-02-05 09:11:32 --> Total execution time: 1.0998
INFO - 2016-02-05 09:12:13 --> Config Class Initialized
INFO - 2016-02-05 09:12:13 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:12:13 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:12:13 --> Utf8 Class Initialized
INFO - 2016-02-05 09:12:13 --> URI Class Initialized
INFO - 2016-02-05 09:12:13 --> Router Class Initialized
INFO - 2016-02-05 09:12:13 --> Output Class Initialized
INFO - 2016-02-05 09:12:13 --> Security Class Initialized
DEBUG - 2016-02-05 09:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:12:13 --> Input Class Initialized
INFO - 2016-02-05 09:12:13 --> Language Class Initialized
INFO - 2016-02-05 09:12:13 --> Loader Class Initialized
INFO - 2016-02-05 09:12:13 --> Helper loaded: url_helper
INFO - 2016-02-05 09:12:13 --> Helper loaded: file_helper
INFO - 2016-02-05 09:12:13 --> Helper loaded: date_helper
INFO - 2016-02-05 09:12:13 --> Helper loaded: form_helper
INFO - 2016-02-05 09:12:13 --> Database Driver Class Initialized
INFO - 2016-02-05 09:12:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:12:14 --> Controller Class Initialized
INFO - 2016-02-05 09:12:14 --> Model Class Initialized
INFO - 2016-02-05 09:12:14 --> Model Class Initialized
INFO - 2016-02-05 09:12:14 --> Form Validation Class Initialized
INFO - 2016-02-05 09:12:14 --> Helper loaded: text_helper
INFO - 2016-02-05 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:12:14 --> Final output sent to browser
DEBUG - 2016-02-05 09:12:14 --> Total execution time: 1.1054
INFO - 2016-02-05 09:13:09 --> Config Class Initialized
INFO - 2016-02-05 09:13:09 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:13:09 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:13:09 --> Utf8 Class Initialized
INFO - 2016-02-05 09:13:09 --> URI Class Initialized
INFO - 2016-02-05 09:13:09 --> Router Class Initialized
INFO - 2016-02-05 09:13:09 --> Output Class Initialized
INFO - 2016-02-05 09:13:09 --> Security Class Initialized
DEBUG - 2016-02-05 09:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:13:09 --> Input Class Initialized
INFO - 2016-02-05 09:13:09 --> Language Class Initialized
INFO - 2016-02-05 09:13:09 --> Loader Class Initialized
INFO - 2016-02-05 09:13:09 --> Helper loaded: url_helper
INFO - 2016-02-05 09:13:09 --> Helper loaded: file_helper
INFO - 2016-02-05 09:13:09 --> Helper loaded: date_helper
INFO - 2016-02-05 09:13:09 --> Helper loaded: form_helper
INFO - 2016-02-05 09:13:09 --> Database Driver Class Initialized
INFO - 2016-02-05 09:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:13:10 --> Controller Class Initialized
INFO - 2016-02-05 09:13:10 --> Model Class Initialized
INFO - 2016-02-05 09:13:10 --> Model Class Initialized
INFO - 2016-02-05 09:13:10 --> Form Validation Class Initialized
INFO - 2016-02-05 09:13:10 --> Helper loaded: text_helper
INFO - 2016-02-05 09:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:13:10 --> Final output sent to browser
DEBUG - 2016-02-05 09:13:10 --> Total execution time: 1.1085
INFO - 2016-02-05 09:15:29 --> Config Class Initialized
INFO - 2016-02-05 09:15:29 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:15:29 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:15:29 --> Utf8 Class Initialized
INFO - 2016-02-05 09:15:29 --> URI Class Initialized
INFO - 2016-02-05 09:15:29 --> Router Class Initialized
INFO - 2016-02-05 09:15:29 --> Output Class Initialized
INFO - 2016-02-05 09:15:29 --> Security Class Initialized
DEBUG - 2016-02-05 09:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:15:29 --> Input Class Initialized
INFO - 2016-02-05 09:15:29 --> Language Class Initialized
INFO - 2016-02-05 09:15:29 --> Loader Class Initialized
INFO - 2016-02-05 09:15:29 --> Helper loaded: url_helper
INFO - 2016-02-05 09:15:29 --> Helper loaded: file_helper
INFO - 2016-02-05 09:15:29 --> Helper loaded: date_helper
INFO - 2016-02-05 09:15:29 --> Helper loaded: form_helper
INFO - 2016-02-05 09:15:29 --> Database Driver Class Initialized
INFO - 2016-02-05 09:15:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:15:30 --> Controller Class Initialized
INFO - 2016-02-05 09:15:30 --> Model Class Initialized
INFO - 2016-02-05 09:15:30 --> Model Class Initialized
INFO - 2016-02-05 09:15:30 --> Form Validation Class Initialized
INFO - 2016-02-05 09:15:30 --> Helper loaded: text_helper
INFO - 2016-02-05 09:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:15:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:15:30 --> Final output sent to browser
DEBUG - 2016-02-05 09:15:30 --> Total execution time: 1.1215
INFO - 2016-02-05 09:15:52 --> Config Class Initialized
INFO - 2016-02-05 09:15:52 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:15:52 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:15:52 --> Utf8 Class Initialized
INFO - 2016-02-05 09:15:52 --> URI Class Initialized
INFO - 2016-02-05 09:15:52 --> Router Class Initialized
INFO - 2016-02-05 09:15:52 --> Output Class Initialized
INFO - 2016-02-05 09:15:52 --> Security Class Initialized
DEBUG - 2016-02-05 09:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:15:52 --> Input Class Initialized
INFO - 2016-02-05 09:15:52 --> Language Class Initialized
INFO - 2016-02-05 09:15:52 --> Loader Class Initialized
INFO - 2016-02-05 09:15:52 --> Helper loaded: url_helper
INFO - 2016-02-05 09:15:52 --> Helper loaded: file_helper
INFO - 2016-02-05 09:15:52 --> Helper loaded: date_helper
INFO - 2016-02-05 09:15:52 --> Helper loaded: form_helper
INFO - 2016-02-05 09:15:52 --> Database Driver Class Initialized
INFO - 2016-02-05 09:15:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:15:53 --> Controller Class Initialized
INFO - 2016-02-05 09:15:53 --> Model Class Initialized
INFO - 2016-02-05 09:15:53 --> Model Class Initialized
INFO - 2016-02-05 09:15:53 --> Form Validation Class Initialized
INFO - 2016-02-05 09:15:53 --> Helper loaded: text_helper
INFO - 2016-02-05 09:15:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:15:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:15:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:15:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:15:53 --> Final output sent to browser
DEBUG - 2016-02-05 09:15:53 --> Total execution time: 1.1060
INFO - 2016-02-05 09:16:16 --> Config Class Initialized
INFO - 2016-02-05 09:16:16 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:16:16 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:16:16 --> Utf8 Class Initialized
INFO - 2016-02-05 09:16:16 --> URI Class Initialized
INFO - 2016-02-05 09:16:16 --> Router Class Initialized
INFO - 2016-02-05 09:16:16 --> Output Class Initialized
INFO - 2016-02-05 09:16:16 --> Security Class Initialized
DEBUG - 2016-02-05 09:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:16:16 --> Input Class Initialized
INFO - 2016-02-05 09:16:16 --> Language Class Initialized
INFO - 2016-02-05 09:16:16 --> Loader Class Initialized
INFO - 2016-02-05 09:16:16 --> Helper loaded: url_helper
INFO - 2016-02-05 09:16:16 --> Helper loaded: file_helper
INFO - 2016-02-05 09:16:16 --> Helper loaded: date_helper
INFO - 2016-02-05 09:16:16 --> Helper loaded: form_helper
INFO - 2016-02-05 09:16:16 --> Database Driver Class Initialized
INFO - 2016-02-05 09:16:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:16:17 --> Controller Class Initialized
INFO - 2016-02-05 09:16:17 --> Model Class Initialized
INFO - 2016-02-05 09:16:17 --> Model Class Initialized
INFO - 2016-02-05 09:16:17 --> Form Validation Class Initialized
INFO - 2016-02-05 09:16:17 --> Helper loaded: text_helper
INFO - 2016-02-05 09:16:17 --> Config Class Initialized
INFO - 2016-02-05 09:16:17 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:16:17 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:16:17 --> Utf8 Class Initialized
INFO - 2016-02-05 09:16:17 --> URI Class Initialized
INFO - 2016-02-05 09:16:17 --> Router Class Initialized
INFO - 2016-02-05 09:16:17 --> Output Class Initialized
INFO - 2016-02-05 09:16:17 --> Security Class Initialized
DEBUG - 2016-02-05 09:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:16:17 --> Input Class Initialized
INFO - 2016-02-05 09:16:17 --> Language Class Initialized
INFO - 2016-02-05 09:16:17 --> Loader Class Initialized
INFO - 2016-02-05 09:16:17 --> Helper loaded: url_helper
INFO - 2016-02-05 09:16:17 --> Helper loaded: file_helper
INFO - 2016-02-05 09:16:17 --> Helper loaded: date_helper
INFO - 2016-02-05 09:16:17 --> Helper loaded: form_helper
INFO - 2016-02-05 09:16:17 --> Database Driver Class Initialized
INFO - 2016-02-05 09:16:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:16:18 --> Controller Class Initialized
INFO - 2016-02-05 09:16:18 --> Model Class Initialized
INFO - 2016-02-05 09:16:18 --> Model Class Initialized
INFO - 2016-02-05 09:16:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 09:16:18 --> Pagination Class Initialized
INFO - 2016-02-05 09:16:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:16:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:16:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 09:16:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:16:18 --> Final output sent to browser
DEBUG - 2016-02-05 09:16:18 --> Total execution time: 1.1047
INFO - 2016-02-05 09:27:26 --> Config Class Initialized
INFO - 2016-02-05 09:27:26 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:27:26 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:27:26 --> Utf8 Class Initialized
INFO - 2016-02-05 09:27:26 --> URI Class Initialized
DEBUG - 2016-02-05 09:27:26 --> No URI present. Default controller set.
INFO - 2016-02-05 09:27:26 --> Router Class Initialized
INFO - 2016-02-05 09:27:26 --> Output Class Initialized
INFO - 2016-02-05 09:27:26 --> Security Class Initialized
DEBUG - 2016-02-05 09:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:27:26 --> Input Class Initialized
INFO - 2016-02-05 09:27:26 --> Language Class Initialized
INFO - 2016-02-05 09:27:26 --> Loader Class Initialized
INFO - 2016-02-05 09:27:26 --> Helper loaded: url_helper
INFO - 2016-02-05 09:27:26 --> Helper loaded: file_helper
INFO - 2016-02-05 09:27:26 --> Helper loaded: date_helper
INFO - 2016-02-05 09:27:26 --> Helper loaded: form_helper
INFO - 2016-02-05 09:27:26 --> Database Driver Class Initialized
INFO - 2016-02-05 09:27:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:27:27 --> Controller Class Initialized
INFO - 2016-02-05 09:27:27 --> Model Class Initialized
INFO - 2016-02-05 09:27:27 --> Model Class Initialized
INFO - 2016-02-05 09:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 09:27:27 --> Pagination Class Initialized
INFO - 2016-02-05 09:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 09:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:27:27 --> Final output sent to browser
DEBUG - 2016-02-05 09:27:27 --> Total execution time: 1.1197
INFO - 2016-02-05 09:27:28 --> Config Class Initialized
INFO - 2016-02-05 09:27:28 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:27:28 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:27:28 --> Utf8 Class Initialized
INFO - 2016-02-05 09:27:28 --> URI Class Initialized
INFO - 2016-02-05 09:27:28 --> Router Class Initialized
INFO - 2016-02-05 09:27:28 --> Output Class Initialized
INFO - 2016-02-05 09:27:28 --> Security Class Initialized
DEBUG - 2016-02-05 09:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:27:28 --> Input Class Initialized
INFO - 2016-02-05 09:27:28 --> Language Class Initialized
INFO - 2016-02-05 09:27:28 --> Loader Class Initialized
INFO - 2016-02-05 09:27:28 --> Helper loaded: url_helper
INFO - 2016-02-05 09:27:28 --> Helper loaded: file_helper
INFO - 2016-02-05 09:27:29 --> Helper loaded: date_helper
INFO - 2016-02-05 09:27:29 --> Helper loaded: form_helper
INFO - 2016-02-05 09:27:29 --> Database Driver Class Initialized
INFO - 2016-02-05 09:27:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:27:30 --> Controller Class Initialized
INFO - 2016-02-05 09:27:30 --> Model Class Initialized
INFO - 2016-02-05 09:27:30 --> Model Class Initialized
INFO - 2016-02-05 09:27:30 --> Form Validation Class Initialized
INFO - 2016-02-05 09:27:30 --> Helper loaded: text_helper
INFO - 2016-02-05 09:27:30 --> Config Class Initialized
INFO - 2016-02-05 09:27:30 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:27:30 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:27:30 --> Utf8 Class Initialized
INFO - 2016-02-05 09:27:30 --> URI Class Initialized
INFO - 2016-02-05 09:27:30 --> Router Class Initialized
INFO - 2016-02-05 09:27:30 --> Output Class Initialized
INFO - 2016-02-05 09:27:30 --> Security Class Initialized
DEBUG - 2016-02-05 09:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:27:30 --> Input Class Initialized
INFO - 2016-02-05 09:27:30 --> Language Class Initialized
INFO - 2016-02-05 09:27:30 --> Loader Class Initialized
INFO - 2016-02-05 09:27:30 --> Helper loaded: url_helper
INFO - 2016-02-05 09:27:30 --> Helper loaded: file_helper
INFO - 2016-02-05 09:27:30 --> Helper loaded: date_helper
INFO - 2016-02-05 09:27:30 --> Helper loaded: form_helper
INFO - 2016-02-05 09:27:30 --> Database Driver Class Initialized
INFO - 2016-02-05 09:27:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:27:31 --> Controller Class Initialized
INFO - 2016-02-05 09:27:31 --> Model Class Initialized
INFO - 2016-02-05 09:27:31 --> Model Class Initialized
INFO - 2016-02-05 09:27:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 09:27:31 --> Pagination Class Initialized
INFO - 2016-02-05 09:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 09:27:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:27:31 --> Final output sent to browser
DEBUG - 2016-02-05 09:27:31 --> Total execution time: 1.1271
INFO - 2016-02-05 09:27:32 --> Config Class Initialized
INFO - 2016-02-05 09:27:32 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:27:32 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:27:32 --> Utf8 Class Initialized
INFO - 2016-02-05 09:27:32 --> URI Class Initialized
INFO - 2016-02-05 09:27:32 --> Router Class Initialized
INFO - 2016-02-05 09:27:32 --> Output Class Initialized
INFO - 2016-02-05 09:27:32 --> Security Class Initialized
DEBUG - 2016-02-05 09:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:27:32 --> Input Class Initialized
INFO - 2016-02-05 09:27:32 --> Language Class Initialized
INFO - 2016-02-05 09:27:32 --> Loader Class Initialized
INFO - 2016-02-05 09:27:32 --> Helper loaded: url_helper
INFO - 2016-02-05 09:27:32 --> Helper loaded: file_helper
INFO - 2016-02-05 09:27:32 --> Helper loaded: date_helper
INFO - 2016-02-05 09:27:32 --> Helper loaded: form_helper
INFO - 2016-02-05 09:27:32 --> Database Driver Class Initialized
INFO - 2016-02-05 09:27:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:27:33 --> Controller Class Initialized
INFO - 2016-02-05 09:27:33 --> Model Class Initialized
INFO - 2016-02-05 09:27:33 --> Model Class Initialized
INFO - 2016-02-05 09:27:33 --> Form Validation Class Initialized
INFO - 2016-02-05 09:27:33 --> Helper loaded: text_helper
INFO - 2016-02-05 09:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:27:33 --> Final output sent to browser
DEBUG - 2016-02-05 09:27:33 --> Total execution time: 1.1394
INFO - 2016-02-05 09:27:43 --> Config Class Initialized
INFO - 2016-02-05 09:27:43 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:27:43 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:27:43 --> Utf8 Class Initialized
INFO - 2016-02-05 09:27:43 --> URI Class Initialized
INFO - 2016-02-05 09:27:43 --> Router Class Initialized
INFO - 2016-02-05 09:27:43 --> Output Class Initialized
INFO - 2016-02-05 09:27:43 --> Security Class Initialized
DEBUG - 2016-02-05 09:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:27:43 --> Input Class Initialized
INFO - 2016-02-05 09:27:43 --> Language Class Initialized
INFO - 2016-02-05 09:27:43 --> Loader Class Initialized
INFO - 2016-02-05 09:27:43 --> Helper loaded: url_helper
INFO - 2016-02-05 09:27:43 --> Helper loaded: file_helper
INFO - 2016-02-05 09:27:43 --> Helper loaded: date_helper
INFO - 2016-02-05 09:27:43 --> Helper loaded: form_helper
INFO - 2016-02-05 09:27:43 --> Database Driver Class Initialized
INFO - 2016-02-05 09:27:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:27:44 --> Controller Class Initialized
INFO - 2016-02-05 09:27:44 --> Model Class Initialized
INFO - 2016-02-05 09:27:44 --> Model Class Initialized
INFO - 2016-02-05 09:27:44 --> Form Validation Class Initialized
INFO - 2016-02-05 09:27:44 --> Helper loaded: text_helper
INFO - 2016-02-05 09:27:44 --> Final output sent to browser
DEBUG - 2016-02-05 09:27:44 --> Total execution time: 1.1745
INFO - 2016-02-05 09:28:22 --> Config Class Initialized
INFO - 2016-02-05 09:28:22 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:28:22 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:28:22 --> Utf8 Class Initialized
INFO - 2016-02-05 09:28:22 --> URI Class Initialized
INFO - 2016-02-05 09:28:22 --> Router Class Initialized
INFO - 2016-02-05 09:28:22 --> Output Class Initialized
INFO - 2016-02-05 09:28:22 --> Security Class Initialized
DEBUG - 2016-02-05 09:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:28:22 --> Input Class Initialized
INFO - 2016-02-05 09:28:22 --> Language Class Initialized
INFO - 2016-02-05 09:28:22 --> Loader Class Initialized
INFO - 2016-02-05 09:28:22 --> Helper loaded: url_helper
INFO - 2016-02-05 09:28:22 --> Helper loaded: file_helper
INFO - 2016-02-05 09:28:22 --> Helper loaded: date_helper
INFO - 2016-02-05 09:28:22 --> Helper loaded: form_helper
INFO - 2016-02-05 09:28:22 --> Database Driver Class Initialized
INFO - 2016-02-05 09:28:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:28:23 --> Controller Class Initialized
INFO - 2016-02-05 09:28:23 --> Model Class Initialized
INFO - 2016-02-05 09:28:23 --> Model Class Initialized
INFO - 2016-02-05 09:28:23 --> Form Validation Class Initialized
INFO - 2016-02-05 09:28:23 --> Helper loaded: text_helper
INFO - 2016-02-05 09:28:23 --> Final output sent to browser
DEBUG - 2016-02-05 09:28:23 --> Total execution time: 1.2299
INFO - 2016-02-05 09:28:25 --> Config Class Initialized
INFO - 2016-02-05 09:28:25 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:28:25 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:28:25 --> Utf8 Class Initialized
INFO - 2016-02-05 09:28:25 --> URI Class Initialized
INFO - 2016-02-05 09:28:25 --> Router Class Initialized
INFO - 2016-02-05 09:28:25 --> Output Class Initialized
INFO - 2016-02-05 09:28:25 --> Security Class Initialized
DEBUG - 2016-02-05 09:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:28:25 --> Input Class Initialized
INFO - 2016-02-05 09:28:25 --> Language Class Initialized
INFO - 2016-02-05 09:28:25 --> Loader Class Initialized
INFO - 2016-02-05 09:28:25 --> Helper loaded: url_helper
INFO - 2016-02-05 09:28:25 --> Helper loaded: file_helper
INFO - 2016-02-05 09:28:25 --> Helper loaded: date_helper
INFO - 2016-02-05 09:28:25 --> Helper loaded: form_helper
INFO - 2016-02-05 09:28:25 --> Database Driver Class Initialized
INFO - 2016-02-05 09:28:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:28:26 --> Controller Class Initialized
INFO - 2016-02-05 09:28:26 --> Model Class Initialized
INFO - 2016-02-05 09:28:26 --> Model Class Initialized
INFO - 2016-02-05 09:28:26 --> Form Validation Class Initialized
INFO - 2016-02-05 09:28:26 --> Helper loaded: text_helper
INFO - 2016-02-05 09:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:28:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:28:26 --> Final output sent to browser
DEBUG - 2016-02-05 09:28:26 --> Total execution time: 1.1740
INFO - 2016-02-05 09:29:11 --> Config Class Initialized
INFO - 2016-02-05 09:29:11 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:29:11 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:29:11 --> Utf8 Class Initialized
INFO - 2016-02-05 09:29:11 --> URI Class Initialized
INFO - 2016-02-05 09:29:11 --> Router Class Initialized
INFO - 2016-02-05 09:29:11 --> Output Class Initialized
INFO - 2016-02-05 09:29:11 --> Security Class Initialized
DEBUG - 2016-02-05 09:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:29:11 --> Input Class Initialized
INFO - 2016-02-05 09:29:11 --> Language Class Initialized
ERROR - 2016-02-05 09:29:11 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 108
INFO - 2016-02-05 09:29:23 --> Config Class Initialized
INFO - 2016-02-05 09:29:23 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:29:23 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:29:23 --> Utf8 Class Initialized
INFO - 2016-02-05 09:29:23 --> URI Class Initialized
INFO - 2016-02-05 09:29:23 --> Router Class Initialized
INFO - 2016-02-05 09:29:23 --> Output Class Initialized
INFO - 2016-02-05 09:29:23 --> Security Class Initialized
DEBUG - 2016-02-05 09:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:29:23 --> Input Class Initialized
INFO - 2016-02-05 09:29:23 --> Language Class Initialized
INFO - 2016-02-05 09:29:23 --> Loader Class Initialized
INFO - 2016-02-05 09:29:23 --> Helper loaded: url_helper
INFO - 2016-02-05 09:29:23 --> Helper loaded: file_helper
INFO - 2016-02-05 09:29:23 --> Helper loaded: date_helper
INFO - 2016-02-05 09:29:23 --> Helper loaded: form_helper
INFO - 2016-02-05 09:29:23 --> Database Driver Class Initialized
INFO - 2016-02-05 09:29:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:29:24 --> Controller Class Initialized
INFO - 2016-02-05 09:29:24 --> Model Class Initialized
INFO - 2016-02-05 09:29:24 --> Model Class Initialized
INFO - 2016-02-05 09:29:24 --> Form Validation Class Initialized
INFO - 2016-02-05 09:29:24 --> Helper loaded: text_helper
INFO - 2016-02-05 09:29:24 --> Final output sent to browser
DEBUG - 2016-02-05 09:29:24 --> Total execution time: 1.2015
INFO - 2016-02-05 09:30:16 --> Config Class Initialized
INFO - 2016-02-05 09:30:16 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:30:16 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:30:16 --> Utf8 Class Initialized
INFO - 2016-02-05 09:30:16 --> URI Class Initialized
INFO - 2016-02-05 09:30:16 --> Router Class Initialized
INFO - 2016-02-05 09:30:16 --> Output Class Initialized
INFO - 2016-02-05 09:30:16 --> Security Class Initialized
DEBUG - 2016-02-05 09:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:30:16 --> Input Class Initialized
INFO - 2016-02-05 09:30:16 --> Language Class Initialized
INFO - 2016-02-05 09:30:16 --> Loader Class Initialized
INFO - 2016-02-05 09:30:16 --> Helper loaded: url_helper
INFO - 2016-02-05 09:30:16 --> Helper loaded: file_helper
INFO - 2016-02-05 09:30:16 --> Helper loaded: date_helper
INFO - 2016-02-05 09:30:16 --> Helper loaded: form_helper
INFO - 2016-02-05 09:30:16 --> Database Driver Class Initialized
INFO - 2016-02-05 09:30:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:30:17 --> Controller Class Initialized
INFO - 2016-02-05 09:30:17 --> Model Class Initialized
INFO - 2016-02-05 09:30:17 --> Model Class Initialized
INFO - 2016-02-05 09:30:17 --> Form Validation Class Initialized
INFO - 2016-02-05 09:30:17 --> Helper loaded: text_helper
INFO - 2016-02-05 09:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 09:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 09:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 09:30:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 09:30:17 --> Final output sent to browser
DEBUG - 2016-02-05 09:30:17 --> Total execution time: 1.1625
INFO - 2016-02-05 09:30:19 --> Config Class Initialized
INFO - 2016-02-05 09:30:19 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:30:19 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:30:19 --> Utf8 Class Initialized
INFO - 2016-02-05 09:30:19 --> URI Class Initialized
INFO - 2016-02-05 09:30:19 --> Router Class Initialized
INFO - 2016-02-05 09:30:19 --> Output Class Initialized
INFO - 2016-02-05 09:30:19 --> Security Class Initialized
DEBUG - 2016-02-05 09:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:30:19 --> Input Class Initialized
INFO - 2016-02-05 09:30:19 --> Language Class Initialized
INFO - 2016-02-05 09:30:19 --> Loader Class Initialized
INFO - 2016-02-05 09:30:19 --> Helper loaded: url_helper
INFO - 2016-02-05 09:30:19 --> Helper loaded: file_helper
INFO - 2016-02-05 09:30:19 --> Helper loaded: date_helper
INFO - 2016-02-05 09:30:19 --> Helper loaded: form_helper
INFO - 2016-02-05 09:30:19 --> Database Driver Class Initialized
INFO - 2016-02-05 09:30:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:30:20 --> Controller Class Initialized
INFO - 2016-02-05 09:30:20 --> Model Class Initialized
INFO - 2016-02-05 09:30:20 --> Model Class Initialized
INFO - 2016-02-05 09:30:20 --> Form Validation Class Initialized
INFO - 2016-02-05 09:30:20 --> Helper loaded: text_helper
INFO - 2016-02-05 09:30:20 --> Final output sent to browser
DEBUG - 2016-02-05 09:30:20 --> Total execution time: 1.2408
INFO - 2016-02-05 09:31:28 --> Config Class Initialized
INFO - 2016-02-05 09:31:28 --> Hooks Class Initialized
DEBUG - 2016-02-05 09:31:28 --> UTF-8 Support Enabled
INFO - 2016-02-05 09:31:28 --> Utf8 Class Initialized
INFO - 2016-02-05 09:31:28 --> URI Class Initialized
INFO - 2016-02-05 09:31:28 --> Router Class Initialized
INFO - 2016-02-05 09:31:28 --> Output Class Initialized
INFO - 2016-02-05 09:31:28 --> Security Class Initialized
DEBUG - 2016-02-05 09:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 09:31:28 --> Input Class Initialized
INFO - 2016-02-05 09:31:28 --> Language Class Initialized
INFO - 2016-02-05 09:31:28 --> Loader Class Initialized
INFO - 2016-02-05 09:31:28 --> Helper loaded: url_helper
INFO - 2016-02-05 09:31:28 --> Helper loaded: file_helper
INFO - 2016-02-05 09:31:28 --> Helper loaded: date_helper
INFO - 2016-02-05 09:31:28 --> Helper loaded: form_helper
INFO - 2016-02-05 09:31:28 --> Database Driver Class Initialized
INFO - 2016-02-05 09:31:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 09:31:29 --> Controller Class Initialized
INFO - 2016-02-05 09:31:29 --> Model Class Initialized
INFO - 2016-02-05 09:31:29 --> Model Class Initialized
INFO - 2016-02-05 09:31:29 --> Form Validation Class Initialized
INFO - 2016-02-05 09:31:29 --> Helper loaded: text_helper
INFO - 2016-02-05 09:31:29 --> Final output sent to browser
DEBUG - 2016-02-05 09:31:29 --> Total execution time: 1.2030
INFO - 2016-02-05 10:08:05 --> Config Class Initialized
INFO - 2016-02-05 10:08:05 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:08:05 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:08:05 --> Utf8 Class Initialized
INFO - 2016-02-05 10:08:05 --> URI Class Initialized
INFO - 2016-02-05 10:08:05 --> Router Class Initialized
INFO - 2016-02-05 10:08:05 --> Output Class Initialized
INFO - 2016-02-05 10:08:05 --> Security Class Initialized
DEBUG - 2016-02-05 10:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:08:05 --> Input Class Initialized
INFO - 2016-02-05 10:08:05 --> Language Class Initialized
INFO - 2016-02-05 10:08:05 --> Loader Class Initialized
INFO - 2016-02-05 10:08:05 --> Helper loaded: url_helper
INFO - 2016-02-05 10:08:05 --> Helper loaded: file_helper
INFO - 2016-02-05 10:08:05 --> Helper loaded: date_helper
INFO - 2016-02-05 10:08:05 --> Helper loaded: form_helper
INFO - 2016-02-05 10:08:05 --> Database Driver Class Initialized
INFO - 2016-02-05 10:08:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:08:06 --> Controller Class Initialized
INFO - 2016-02-05 10:08:06 --> Model Class Initialized
INFO - 2016-02-05 10:08:06 --> Model Class Initialized
INFO - 2016-02-05 10:08:06 --> Form Validation Class Initialized
INFO - 2016-02-05 10:08:06 --> Helper loaded: text_helper
INFO - 2016-02-05 10:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:08:06 --> Final output sent to browser
DEBUG - 2016-02-05 10:08:06 --> Total execution time: 1.1335
INFO - 2016-02-05 10:08:09 --> Config Class Initialized
INFO - 2016-02-05 10:08:09 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:08:09 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:08:09 --> Utf8 Class Initialized
INFO - 2016-02-05 10:08:09 --> URI Class Initialized
DEBUG - 2016-02-05 10:08:09 --> No URI present. Default controller set.
INFO - 2016-02-05 10:08:09 --> Router Class Initialized
INFO - 2016-02-05 10:08:09 --> Output Class Initialized
INFO - 2016-02-05 10:08:09 --> Security Class Initialized
DEBUG - 2016-02-05 10:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:08:09 --> Input Class Initialized
INFO - 2016-02-05 10:08:09 --> Language Class Initialized
INFO - 2016-02-05 10:08:09 --> Loader Class Initialized
INFO - 2016-02-05 10:08:09 --> Helper loaded: url_helper
INFO - 2016-02-05 10:08:09 --> Helper loaded: file_helper
INFO - 2016-02-05 10:08:09 --> Helper loaded: date_helper
INFO - 2016-02-05 10:08:09 --> Helper loaded: form_helper
INFO - 2016-02-05 10:08:09 --> Database Driver Class Initialized
INFO - 2016-02-05 10:08:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:08:10 --> Controller Class Initialized
INFO - 2016-02-05 10:08:10 --> Model Class Initialized
INFO - 2016-02-05 10:08:10 --> Model Class Initialized
INFO - 2016-02-05 10:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 10:08:10 --> Pagination Class Initialized
INFO - 2016-02-05 10:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 10:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:08:10 --> Final output sent to browser
DEBUG - 2016-02-05 10:08:10 --> Total execution time: 1.1293
INFO - 2016-02-05 10:08:12 --> Config Class Initialized
INFO - 2016-02-05 10:08:12 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:08:12 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:08:12 --> Utf8 Class Initialized
INFO - 2016-02-05 10:08:12 --> URI Class Initialized
INFO - 2016-02-05 10:08:12 --> Router Class Initialized
INFO - 2016-02-05 10:08:12 --> Output Class Initialized
INFO - 2016-02-05 10:08:12 --> Security Class Initialized
DEBUG - 2016-02-05 10:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:08:12 --> Input Class Initialized
INFO - 2016-02-05 10:08:12 --> Language Class Initialized
INFO - 2016-02-05 10:08:12 --> Loader Class Initialized
INFO - 2016-02-05 10:08:12 --> Helper loaded: url_helper
INFO - 2016-02-05 10:08:12 --> Helper loaded: file_helper
INFO - 2016-02-05 10:08:12 --> Helper loaded: date_helper
INFO - 2016-02-05 10:08:12 --> Helper loaded: form_helper
INFO - 2016-02-05 10:08:12 --> Database Driver Class Initialized
INFO - 2016-02-05 10:08:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:08:13 --> Controller Class Initialized
INFO - 2016-02-05 10:08:13 --> Model Class Initialized
INFO - 2016-02-05 10:08:13 --> Model Class Initialized
INFO - 2016-02-05 10:08:13 --> Form Validation Class Initialized
INFO - 2016-02-05 10:08:13 --> Helper loaded: text_helper
INFO - 2016-02-05 10:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:08:13 --> Final output sent to browser
DEBUG - 2016-02-05 10:08:13 --> Total execution time: 1.1357
INFO - 2016-02-05 10:08:20 --> Config Class Initialized
INFO - 2016-02-05 10:08:20 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:08:20 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:08:20 --> Utf8 Class Initialized
INFO - 2016-02-05 10:08:20 --> URI Class Initialized
INFO - 2016-02-05 10:08:20 --> Router Class Initialized
INFO - 2016-02-05 10:08:20 --> Output Class Initialized
INFO - 2016-02-05 10:08:20 --> Security Class Initialized
DEBUG - 2016-02-05 10:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:08:20 --> Input Class Initialized
INFO - 2016-02-05 10:08:20 --> Language Class Initialized
INFO - 2016-02-05 10:08:20 --> Loader Class Initialized
INFO - 2016-02-05 10:08:20 --> Helper loaded: url_helper
INFO - 2016-02-05 10:08:20 --> Helper loaded: file_helper
INFO - 2016-02-05 10:08:20 --> Helper loaded: date_helper
INFO - 2016-02-05 10:08:20 --> Helper loaded: form_helper
INFO - 2016-02-05 10:08:20 --> Database Driver Class Initialized
INFO - 2016-02-05 10:08:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:08:21 --> Controller Class Initialized
INFO - 2016-02-05 10:08:21 --> Model Class Initialized
INFO - 2016-02-05 10:08:21 --> Model Class Initialized
INFO - 2016-02-05 10:08:21 --> Form Validation Class Initialized
INFO - 2016-02-05 10:08:21 --> Helper loaded: text_helper
INFO - 2016-02-05 10:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:08:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:08:21 --> Final output sent to browser
DEBUG - 2016-02-05 10:08:21 --> Total execution time: 1.1433
INFO - 2016-02-05 10:09:49 --> Config Class Initialized
INFO - 2016-02-05 10:09:49 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:09:49 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:09:49 --> Utf8 Class Initialized
INFO - 2016-02-05 10:09:49 --> URI Class Initialized
DEBUG - 2016-02-05 10:09:49 --> No URI present. Default controller set.
INFO - 2016-02-05 10:09:49 --> Router Class Initialized
INFO - 2016-02-05 10:09:49 --> Output Class Initialized
INFO - 2016-02-05 10:09:49 --> Security Class Initialized
DEBUG - 2016-02-05 10:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:09:49 --> Input Class Initialized
INFO - 2016-02-05 10:09:49 --> Language Class Initialized
INFO - 2016-02-05 10:09:49 --> Loader Class Initialized
INFO - 2016-02-05 10:09:49 --> Helper loaded: url_helper
INFO - 2016-02-05 10:09:49 --> Helper loaded: file_helper
INFO - 2016-02-05 10:09:49 --> Helper loaded: date_helper
INFO - 2016-02-05 10:09:49 --> Helper loaded: form_helper
INFO - 2016-02-05 10:09:49 --> Database Driver Class Initialized
INFO - 2016-02-05 10:09:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:09:50 --> Controller Class Initialized
INFO - 2016-02-05 10:09:50 --> Model Class Initialized
INFO - 2016-02-05 10:09:50 --> Model Class Initialized
INFO - 2016-02-05 10:09:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 10:09:50 --> Pagination Class Initialized
INFO - 2016-02-05 10:09:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:09:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:09:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 10:09:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:09:50 --> Final output sent to browser
DEBUG - 2016-02-05 10:09:50 --> Total execution time: 1.1373
INFO - 2016-02-05 10:09:52 --> Config Class Initialized
INFO - 2016-02-05 10:09:52 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:09:52 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:09:52 --> Utf8 Class Initialized
INFO - 2016-02-05 10:09:52 --> URI Class Initialized
INFO - 2016-02-05 10:09:52 --> Router Class Initialized
INFO - 2016-02-05 10:09:52 --> Output Class Initialized
INFO - 2016-02-05 10:09:52 --> Security Class Initialized
DEBUG - 2016-02-05 10:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:09:52 --> Input Class Initialized
INFO - 2016-02-05 10:09:52 --> Language Class Initialized
INFO - 2016-02-05 10:09:52 --> Loader Class Initialized
INFO - 2016-02-05 10:09:52 --> Helper loaded: url_helper
INFO - 2016-02-05 10:09:52 --> Helper loaded: file_helper
INFO - 2016-02-05 10:09:52 --> Helper loaded: date_helper
INFO - 2016-02-05 10:09:52 --> Helper loaded: form_helper
INFO - 2016-02-05 10:09:52 --> Database Driver Class Initialized
INFO - 2016-02-05 10:09:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:09:53 --> Controller Class Initialized
INFO - 2016-02-05 10:09:53 --> Model Class Initialized
INFO - 2016-02-05 10:09:53 --> Model Class Initialized
INFO - 2016-02-05 10:09:53 --> Form Validation Class Initialized
INFO - 2016-02-05 10:09:53 --> Helper loaded: text_helper
INFO - 2016-02-05 10:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:09:53 --> Final output sent to browser
DEBUG - 2016-02-05 10:09:53 --> Total execution time: 1.1372
INFO - 2016-02-05 10:09:58 --> Config Class Initialized
INFO - 2016-02-05 10:09:58 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:09:58 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:09:58 --> Utf8 Class Initialized
INFO - 2016-02-05 10:09:58 --> URI Class Initialized
INFO - 2016-02-05 10:09:58 --> Router Class Initialized
INFO - 2016-02-05 10:09:58 --> Output Class Initialized
INFO - 2016-02-05 10:09:58 --> Security Class Initialized
DEBUG - 2016-02-05 10:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:09:58 --> Input Class Initialized
INFO - 2016-02-05 10:09:58 --> Language Class Initialized
INFO - 2016-02-05 10:09:58 --> Loader Class Initialized
INFO - 2016-02-05 10:09:58 --> Helper loaded: url_helper
INFO - 2016-02-05 10:09:58 --> Helper loaded: file_helper
INFO - 2016-02-05 10:09:58 --> Helper loaded: date_helper
INFO - 2016-02-05 10:09:58 --> Helper loaded: form_helper
INFO - 2016-02-05 10:09:58 --> Database Driver Class Initialized
INFO - 2016-02-05 10:09:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:09:59 --> Controller Class Initialized
INFO - 2016-02-05 10:09:59 --> Model Class Initialized
INFO - 2016-02-05 10:09:59 --> Model Class Initialized
INFO - 2016-02-05 10:09:59 --> Form Validation Class Initialized
INFO - 2016-02-05 10:09:59 --> Helper loaded: text_helper
INFO - 2016-02-05 10:09:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:09:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:09:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:09:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:09:59 --> Final output sent to browser
DEBUG - 2016-02-05 10:09:59 --> Total execution time: 1.1456
INFO - 2016-02-05 10:10:33 --> Config Class Initialized
INFO - 2016-02-05 10:10:33 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:10:33 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:10:33 --> Utf8 Class Initialized
INFO - 2016-02-05 10:10:33 --> URI Class Initialized
DEBUG - 2016-02-05 10:10:33 --> No URI present. Default controller set.
INFO - 2016-02-05 10:10:33 --> Router Class Initialized
INFO - 2016-02-05 10:10:33 --> Output Class Initialized
INFO - 2016-02-05 10:10:33 --> Security Class Initialized
DEBUG - 2016-02-05 10:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:10:33 --> Input Class Initialized
INFO - 2016-02-05 10:10:33 --> Language Class Initialized
INFO - 2016-02-05 10:10:33 --> Loader Class Initialized
INFO - 2016-02-05 10:10:33 --> Helper loaded: url_helper
INFO - 2016-02-05 10:10:33 --> Helper loaded: file_helper
INFO - 2016-02-05 10:10:33 --> Helper loaded: date_helper
INFO - 2016-02-05 10:10:33 --> Helper loaded: form_helper
INFO - 2016-02-05 10:10:33 --> Database Driver Class Initialized
INFO - 2016-02-05 10:10:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:10:35 --> Controller Class Initialized
INFO - 2016-02-05 10:10:35 --> Model Class Initialized
INFO - 2016-02-05 10:10:35 --> Model Class Initialized
INFO - 2016-02-05 10:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 10:10:35 --> Pagination Class Initialized
INFO - 2016-02-05 10:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 10:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:10:35 --> Final output sent to browser
DEBUG - 2016-02-05 10:10:35 --> Total execution time: 1.1353
INFO - 2016-02-05 10:10:36 --> Config Class Initialized
INFO - 2016-02-05 10:10:36 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:10:36 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:10:36 --> Utf8 Class Initialized
INFO - 2016-02-05 10:10:36 --> URI Class Initialized
INFO - 2016-02-05 10:10:36 --> Router Class Initialized
INFO - 2016-02-05 10:10:36 --> Output Class Initialized
INFO - 2016-02-05 10:10:36 --> Security Class Initialized
DEBUG - 2016-02-05 10:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:10:36 --> Input Class Initialized
INFO - 2016-02-05 10:10:36 --> Language Class Initialized
INFO - 2016-02-05 10:10:36 --> Loader Class Initialized
INFO - 2016-02-05 10:10:36 --> Helper loaded: url_helper
INFO - 2016-02-05 10:10:36 --> Helper loaded: file_helper
INFO - 2016-02-05 10:10:36 --> Helper loaded: date_helper
INFO - 2016-02-05 10:10:36 --> Helper loaded: form_helper
INFO - 2016-02-05 10:10:36 --> Database Driver Class Initialized
INFO - 2016-02-05 10:10:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:10:37 --> Controller Class Initialized
INFO - 2016-02-05 10:10:37 --> Model Class Initialized
INFO - 2016-02-05 10:10:37 --> Model Class Initialized
INFO - 2016-02-05 10:10:37 --> Form Validation Class Initialized
INFO - 2016-02-05 10:10:37 --> Helper loaded: text_helper
INFO - 2016-02-05 10:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:10:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:10:37 --> Final output sent to browser
DEBUG - 2016-02-05 10:10:37 --> Total execution time: 1.0944
INFO - 2016-02-05 10:10:41 --> Config Class Initialized
INFO - 2016-02-05 10:10:41 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:10:41 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:10:41 --> Utf8 Class Initialized
INFO - 2016-02-05 10:10:41 --> URI Class Initialized
INFO - 2016-02-05 10:10:41 --> Router Class Initialized
INFO - 2016-02-05 10:10:41 --> Output Class Initialized
INFO - 2016-02-05 10:10:41 --> Security Class Initialized
DEBUG - 2016-02-05 10:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:10:41 --> Input Class Initialized
INFO - 2016-02-05 10:10:41 --> Language Class Initialized
INFO - 2016-02-05 10:10:41 --> Loader Class Initialized
INFO - 2016-02-05 10:10:41 --> Helper loaded: url_helper
INFO - 2016-02-05 10:10:41 --> Helper loaded: file_helper
INFO - 2016-02-05 10:10:41 --> Helper loaded: date_helper
INFO - 2016-02-05 10:10:41 --> Helper loaded: form_helper
INFO - 2016-02-05 10:10:41 --> Database Driver Class Initialized
INFO - 2016-02-05 10:10:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:10:42 --> Controller Class Initialized
INFO - 2016-02-05 10:10:42 --> Model Class Initialized
INFO - 2016-02-05 10:10:42 --> Model Class Initialized
INFO - 2016-02-05 10:10:42 --> Form Validation Class Initialized
INFO - 2016-02-05 10:10:42 --> Helper loaded: text_helper
INFO - 2016-02-05 10:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:10:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:10:42 --> Final output sent to browser
DEBUG - 2016-02-05 10:10:42 --> Total execution time: 1.1230
INFO - 2016-02-05 10:10:53 --> Config Class Initialized
INFO - 2016-02-05 10:10:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:10:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:10:53 --> Utf8 Class Initialized
INFO - 2016-02-05 10:10:53 --> URI Class Initialized
INFO - 2016-02-05 10:10:53 --> Router Class Initialized
INFO - 2016-02-05 10:10:53 --> Output Class Initialized
INFO - 2016-02-05 10:10:53 --> Security Class Initialized
DEBUG - 2016-02-05 10:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:10:53 --> Input Class Initialized
INFO - 2016-02-05 10:10:53 --> Language Class Initialized
INFO - 2016-02-05 10:10:53 --> Loader Class Initialized
INFO - 2016-02-05 10:10:53 --> Helper loaded: url_helper
INFO - 2016-02-05 10:10:53 --> Helper loaded: file_helper
INFO - 2016-02-05 10:10:53 --> Helper loaded: date_helper
INFO - 2016-02-05 10:10:53 --> Helper loaded: form_helper
INFO - 2016-02-05 10:10:53 --> Database Driver Class Initialized
INFO - 2016-02-05 10:10:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:10:54 --> Controller Class Initialized
INFO - 2016-02-05 10:10:54 --> Model Class Initialized
INFO - 2016-02-05 10:10:54 --> Model Class Initialized
INFO - 2016-02-05 10:10:54 --> Form Validation Class Initialized
INFO - 2016-02-05 10:10:54 --> Helper loaded: text_helper
INFO - 2016-02-05 10:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:10:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:10:54 --> Final output sent to browser
DEBUG - 2016-02-05 10:10:54 --> Total execution time: 1.1490
INFO - 2016-02-05 10:12:29 --> Config Class Initialized
INFO - 2016-02-05 10:12:29 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:12:29 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:12:29 --> Utf8 Class Initialized
INFO - 2016-02-05 10:12:29 --> URI Class Initialized
DEBUG - 2016-02-05 10:12:29 --> No URI present. Default controller set.
INFO - 2016-02-05 10:12:29 --> Router Class Initialized
INFO - 2016-02-05 10:12:29 --> Output Class Initialized
INFO - 2016-02-05 10:12:29 --> Security Class Initialized
DEBUG - 2016-02-05 10:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:12:29 --> Input Class Initialized
INFO - 2016-02-05 10:12:29 --> Language Class Initialized
INFO - 2016-02-05 10:12:29 --> Loader Class Initialized
INFO - 2016-02-05 10:12:29 --> Helper loaded: url_helper
INFO - 2016-02-05 10:12:29 --> Helper loaded: file_helper
INFO - 2016-02-05 10:12:29 --> Helper loaded: date_helper
INFO - 2016-02-05 10:12:29 --> Helper loaded: form_helper
INFO - 2016-02-05 10:12:29 --> Database Driver Class Initialized
INFO - 2016-02-05 10:12:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:12:30 --> Controller Class Initialized
INFO - 2016-02-05 10:12:30 --> Model Class Initialized
INFO - 2016-02-05 10:12:30 --> Model Class Initialized
INFO - 2016-02-05 10:12:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 10:12:30 --> Pagination Class Initialized
INFO - 2016-02-05 10:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 10:12:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:12:30 --> Final output sent to browser
DEBUG - 2016-02-05 10:12:30 --> Total execution time: 1.1477
INFO - 2016-02-05 10:12:31 --> Config Class Initialized
INFO - 2016-02-05 10:12:31 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:12:31 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:12:31 --> Utf8 Class Initialized
INFO - 2016-02-05 10:12:31 --> URI Class Initialized
INFO - 2016-02-05 10:12:31 --> Router Class Initialized
INFO - 2016-02-05 10:12:31 --> Output Class Initialized
INFO - 2016-02-05 10:12:31 --> Security Class Initialized
DEBUG - 2016-02-05 10:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:12:31 --> Input Class Initialized
INFO - 2016-02-05 10:12:31 --> Language Class Initialized
INFO - 2016-02-05 10:12:31 --> Loader Class Initialized
INFO - 2016-02-05 10:12:31 --> Helper loaded: url_helper
INFO - 2016-02-05 10:12:31 --> Helper loaded: file_helper
INFO - 2016-02-05 10:12:31 --> Helper loaded: date_helper
INFO - 2016-02-05 10:12:31 --> Helper loaded: form_helper
INFO - 2016-02-05 10:12:31 --> Database Driver Class Initialized
INFO - 2016-02-05 10:12:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:12:32 --> Controller Class Initialized
INFO - 2016-02-05 10:12:32 --> Model Class Initialized
INFO - 2016-02-05 10:12:32 --> Model Class Initialized
INFO - 2016-02-05 10:12:32 --> Form Validation Class Initialized
INFO - 2016-02-05 10:12:32 --> Helper loaded: text_helper
INFO - 2016-02-05 10:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:12:32 --> Final output sent to browser
DEBUG - 2016-02-05 10:12:32 --> Total execution time: 1.0955
INFO - 2016-02-05 10:12:34 --> Config Class Initialized
INFO - 2016-02-05 10:12:34 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:12:34 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:12:34 --> Utf8 Class Initialized
INFO - 2016-02-05 10:12:34 --> URI Class Initialized
INFO - 2016-02-05 10:12:34 --> Router Class Initialized
INFO - 2016-02-05 10:12:34 --> Output Class Initialized
INFO - 2016-02-05 10:12:34 --> Security Class Initialized
DEBUG - 2016-02-05 10:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:12:34 --> Input Class Initialized
INFO - 2016-02-05 10:12:34 --> Language Class Initialized
INFO - 2016-02-05 10:12:34 --> Loader Class Initialized
INFO - 2016-02-05 10:12:34 --> Helper loaded: url_helper
INFO - 2016-02-05 10:12:34 --> Helper loaded: file_helper
INFO - 2016-02-05 10:12:34 --> Helper loaded: date_helper
INFO - 2016-02-05 10:12:34 --> Helper loaded: form_helper
INFO - 2016-02-05 10:12:34 --> Database Driver Class Initialized
INFO - 2016-02-05 10:12:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:12:35 --> Controller Class Initialized
INFO - 2016-02-05 10:12:35 --> Model Class Initialized
INFO - 2016-02-05 10:12:35 --> Model Class Initialized
INFO - 2016-02-05 10:12:35 --> Form Validation Class Initialized
INFO - 2016-02-05 10:12:35 --> Helper loaded: text_helper
INFO - 2016-02-05 10:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:12:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:12:35 --> Final output sent to browser
DEBUG - 2016-02-05 10:12:35 --> Total execution time: 1.1148
INFO - 2016-02-05 10:12:42 --> Config Class Initialized
INFO - 2016-02-05 10:12:42 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:12:42 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:12:42 --> Utf8 Class Initialized
INFO - 2016-02-05 10:12:42 --> URI Class Initialized
INFO - 2016-02-05 10:12:42 --> Router Class Initialized
INFO - 2016-02-05 10:12:42 --> Output Class Initialized
INFO - 2016-02-05 10:12:42 --> Security Class Initialized
DEBUG - 2016-02-05 10:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:12:42 --> Input Class Initialized
INFO - 2016-02-05 10:12:42 --> Language Class Initialized
INFO - 2016-02-05 10:12:42 --> Loader Class Initialized
INFO - 2016-02-05 10:12:42 --> Helper loaded: url_helper
INFO - 2016-02-05 10:12:42 --> Helper loaded: file_helper
INFO - 2016-02-05 10:12:42 --> Helper loaded: date_helper
INFO - 2016-02-05 10:12:42 --> Helper loaded: form_helper
INFO - 2016-02-05 10:12:42 --> Database Driver Class Initialized
INFO - 2016-02-05 10:12:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:12:43 --> Controller Class Initialized
INFO - 2016-02-05 10:12:43 --> Model Class Initialized
INFO - 2016-02-05 10:12:43 --> Model Class Initialized
INFO - 2016-02-05 10:12:43 --> Form Validation Class Initialized
INFO - 2016-02-05 10:12:43 --> Helper loaded: text_helper
INFO - 2016-02-05 10:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:12:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:12:43 --> Final output sent to browser
DEBUG - 2016-02-05 10:12:43 --> Total execution time: 1.1439
INFO - 2016-02-05 10:12:51 --> Config Class Initialized
INFO - 2016-02-05 10:12:51 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:12:51 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:12:51 --> Utf8 Class Initialized
INFO - 2016-02-05 10:12:51 --> URI Class Initialized
INFO - 2016-02-05 10:12:51 --> Router Class Initialized
INFO - 2016-02-05 10:12:51 --> Output Class Initialized
INFO - 2016-02-05 10:12:51 --> Security Class Initialized
DEBUG - 2016-02-05 10:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:12:51 --> Input Class Initialized
INFO - 2016-02-05 10:12:51 --> Language Class Initialized
INFO - 2016-02-05 10:12:51 --> Loader Class Initialized
INFO - 2016-02-05 10:12:51 --> Helper loaded: url_helper
INFO - 2016-02-05 10:12:51 --> Helper loaded: file_helper
INFO - 2016-02-05 10:12:51 --> Helper loaded: date_helper
INFO - 2016-02-05 10:12:51 --> Helper loaded: form_helper
INFO - 2016-02-05 10:12:51 --> Database Driver Class Initialized
INFO - 2016-02-05 10:12:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:12:52 --> Controller Class Initialized
INFO - 2016-02-05 10:12:52 --> Model Class Initialized
INFO - 2016-02-05 10:12:52 --> Model Class Initialized
INFO - 2016-02-05 10:12:52 --> Form Validation Class Initialized
INFO - 2016-02-05 10:12:52 --> Helper loaded: text_helper
INFO - 2016-02-05 10:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:12:52 --> Final output sent to browser
DEBUG - 2016-02-05 10:12:52 --> Total execution time: 1.1441
INFO - 2016-02-05 10:18:28 --> Config Class Initialized
INFO - 2016-02-05 10:18:29 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:18:29 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:18:29 --> Utf8 Class Initialized
INFO - 2016-02-05 10:18:29 --> URI Class Initialized
INFO - 2016-02-05 10:18:29 --> Router Class Initialized
INFO - 2016-02-05 10:18:29 --> Output Class Initialized
INFO - 2016-02-05 10:18:29 --> Security Class Initialized
DEBUG - 2016-02-05 10:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:18:29 --> Input Class Initialized
INFO - 2016-02-05 10:18:29 --> Language Class Initialized
INFO - 2016-02-05 10:18:29 --> Loader Class Initialized
INFO - 2016-02-05 10:18:29 --> Helper loaded: url_helper
INFO - 2016-02-05 10:18:29 --> Helper loaded: file_helper
INFO - 2016-02-05 10:18:29 --> Helper loaded: date_helper
INFO - 2016-02-05 10:18:29 --> Helper loaded: form_helper
INFO - 2016-02-05 10:18:29 --> Database Driver Class Initialized
INFO - 2016-02-05 10:18:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:18:30 --> Controller Class Initialized
INFO - 2016-02-05 10:18:30 --> Model Class Initialized
INFO - 2016-02-05 10:18:30 --> Model Class Initialized
INFO - 2016-02-05 10:18:30 --> Form Validation Class Initialized
INFO - 2016-02-05 10:18:30 --> Helper loaded: text_helper
INFO - 2016-02-05 10:18:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:18:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:18:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:18:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:18:30 --> Final output sent to browser
DEBUG - 2016-02-05 10:18:30 --> Total execution time: 1.1549
INFO - 2016-02-05 10:18:32 --> Config Class Initialized
INFO - 2016-02-05 10:18:32 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:18:32 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:18:32 --> Utf8 Class Initialized
INFO - 2016-02-05 10:18:32 --> URI Class Initialized
INFO - 2016-02-05 10:18:32 --> Router Class Initialized
INFO - 2016-02-05 10:18:32 --> Output Class Initialized
INFO - 2016-02-05 10:18:32 --> Security Class Initialized
DEBUG - 2016-02-05 10:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:18:32 --> Input Class Initialized
INFO - 2016-02-05 10:18:32 --> Language Class Initialized
INFO - 2016-02-05 10:18:32 --> Loader Class Initialized
INFO - 2016-02-05 10:18:32 --> Helper loaded: url_helper
INFO - 2016-02-05 10:18:32 --> Helper loaded: file_helper
INFO - 2016-02-05 10:18:32 --> Helper loaded: date_helper
INFO - 2016-02-05 10:18:32 --> Helper loaded: form_helper
INFO - 2016-02-05 10:18:32 --> Database Driver Class Initialized
INFO - 2016-02-05 10:18:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:18:34 --> Controller Class Initialized
INFO - 2016-02-05 10:18:34 --> Model Class Initialized
INFO - 2016-02-05 10:18:34 --> Model Class Initialized
INFO - 2016-02-05 10:18:34 --> Form Validation Class Initialized
INFO - 2016-02-05 10:18:34 --> Helper loaded: text_helper
INFO - 2016-02-05 10:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:18:34 --> Final output sent to browser
DEBUG - 2016-02-05 10:18:34 --> Total execution time: 1.1335
INFO - 2016-02-05 10:20:46 --> Config Class Initialized
INFO - 2016-02-05 10:20:46 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:20:46 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:20:46 --> Utf8 Class Initialized
INFO - 2016-02-05 10:20:46 --> URI Class Initialized
DEBUG - 2016-02-05 10:20:46 --> No URI present. Default controller set.
INFO - 2016-02-05 10:20:46 --> Router Class Initialized
INFO - 2016-02-05 10:20:46 --> Output Class Initialized
INFO - 2016-02-05 10:20:46 --> Security Class Initialized
DEBUG - 2016-02-05 10:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:20:46 --> Input Class Initialized
INFO - 2016-02-05 10:20:46 --> Language Class Initialized
INFO - 2016-02-05 10:20:46 --> Loader Class Initialized
INFO - 2016-02-05 10:20:46 --> Helper loaded: url_helper
INFO - 2016-02-05 10:20:46 --> Helper loaded: file_helper
INFO - 2016-02-05 10:20:46 --> Helper loaded: date_helper
INFO - 2016-02-05 10:20:46 --> Helper loaded: form_helper
INFO - 2016-02-05 10:20:46 --> Database Driver Class Initialized
INFO - 2016-02-05 10:20:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:20:47 --> Controller Class Initialized
INFO - 2016-02-05 10:20:47 --> Model Class Initialized
INFO - 2016-02-05 10:20:47 --> Model Class Initialized
INFO - 2016-02-05 10:20:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 10:20:47 --> Pagination Class Initialized
INFO - 2016-02-05 10:20:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:20:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:20:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 10:20:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:20:47 --> Final output sent to browser
DEBUG - 2016-02-05 10:20:47 --> Total execution time: 1.1584
INFO - 2016-02-05 10:20:49 --> Config Class Initialized
INFO - 2016-02-05 10:20:49 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:20:49 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:20:49 --> Utf8 Class Initialized
INFO - 2016-02-05 10:20:49 --> URI Class Initialized
INFO - 2016-02-05 10:20:49 --> Router Class Initialized
INFO - 2016-02-05 10:20:49 --> Output Class Initialized
INFO - 2016-02-05 10:20:49 --> Security Class Initialized
DEBUG - 2016-02-05 10:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:20:49 --> Input Class Initialized
INFO - 2016-02-05 10:20:49 --> Language Class Initialized
INFO - 2016-02-05 10:20:49 --> Loader Class Initialized
INFO - 2016-02-05 10:20:49 --> Helper loaded: url_helper
INFO - 2016-02-05 10:20:49 --> Helper loaded: file_helper
INFO - 2016-02-05 10:20:49 --> Helper loaded: date_helper
INFO - 2016-02-05 10:20:49 --> Helper loaded: form_helper
INFO - 2016-02-05 10:20:49 --> Database Driver Class Initialized
INFO - 2016-02-05 10:20:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:20:50 --> Controller Class Initialized
INFO - 2016-02-05 10:20:50 --> Model Class Initialized
INFO - 2016-02-05 10:20:50 --> Model Class Initialized
INFO - 2016-02-05 10:20:50 --> Form Validation Class Initialized
INFO - 2016-02-05 10:20:50 --> Helper loaded: text_helper
INFO - 2016-02-05 10:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:20:50 --> Final output sent to browser
DEBUG - 2016-02-05 10:20:50 --> Total execution time: 1.1417
INFO - 2016-02-05 10:20:53 --> Config Class Initialized
INFO - 2016-02-05 10:20:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 10:20:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 10:20:53 --> Utf8 Class Initialized
INFO - 2016-02-05 10:20:53 --> URI Class Initialized
INFO - 2016-02-05 10:20:53 --> Router Class Initialized
INFO - 2016-02-05 10:20:53 --> Output Class Initialized
INFO - 2016-02-05 10:20:53 --> Security Class Initialized
DEBUG - 2016-02-05 10:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 10:20:53 --> Input Class Initialized
INFO - 2016-02-05 10:20:53 --> Language Class Initialized
INFO - 2016-02-05 10:20:53 --> Loader Class Initialized
INFO - 2016-02-05 10:20:53 --> Helper loaded: url_helper
INFO - 2016-02-05 10:20:53 --> Helper loaded: file_helper
INFO - 2016-02-05 10:20:53 --> Helper loaded: date_helper
INFO - 2016-02-05 10:20:53 --> Helper loaded: form_helper
INFO - 2016-02-05 10:20:53 --> Database Driver Class Initialized
INFO - 2016-02-05 10:20:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 10:20:54 --> Controller Class Initialized
INFO - 2016-02-05 10:20:54 --> Model Class Initialized
INFO - 2016-02-05 10:20:54 --> Model Class Initialized
INFO - 2016-02-05 10:20:54 --> Form Validation Class Initialized
INFO - 2016-02-05 10:20:54 --> Helper loaded: text_helper
INFO - 2016-02-05 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 10:20:54 --> Final output sent to browser
DEBUG - 2016-02-05 10:20:54 --> Total execution time: 1.1238
INFO - 2016-02-05 11:46:53 --> Config Class Initialized
INFO - 2016-02-05 11:46:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:46:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:46:53 --> Utf8 Class Initialized
INFO - 2016-02-05 11:46:53 --> URI Class Initialized
DEBUG - 2016-02-05 11:46:53 --> No URI present. Default controller set.
INFO - 2016-02-05 11:46:53 --> Router Class Initialized
INFO - 2016-02-05 11:46:53 --> Output Class Initialized
INFO - 2016-02-05 11:46:53 --> Security Class Initialized
DEBUG - 2016-02-05 11:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:46:53 --> Input Class Initialized
INFO - 2016-02-05 11:46:53 --> Language Class Initialized
INFO - 2016-02-05 11:46:53 --> Loader Class Initialized
INFO - 2016-02-05 11:46:53 --> Helper loaded: url_helper
INFO - 2016-02-05 11:46:53 --> Helper loaded: file_helper
INFO - 2016-02-05 11:46:53 --> Helper loaded: date_helper
INFO - 2016-02-05 11:46:53 --> Helper loaded: form_helper
INFO - 2016-02-05 11:46:53 --> Database Driver Class Initialized
INFO - 2016-02-05 11:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:46:54 --> Controller Class Initialized
INFO - 2016-02-05 11:46:54 --> Model Class Initialized
INFO - 2016-02-05 11:46:54 --> Model Class Initialized
INFO - 2016-02-05 11:46:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 11:46:54 --> Pagination Class Initialized
INFO - 2016-02-05 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 11:46:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:46:54 --> Final output sent to browser
DEBUG - 2016-02-05 11:46:54 --> Total execution time: 1.1229
INFO - 2016-02-05 11:46:55 --> Config Class Initialized
INFO - 2016-02-05 11:46:55 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:46:55 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:46:55 --> Utf8 Class Initialized
INFO - 2016-02-05 11:46:55 --> URI Class Initialized
INFO - 2016-02-05 11:46:55 --> Router Class Initialized
INFO - 2016-02-05 11:46:55 --> Output Class Initialized
INFO - 2016-02-05 11:46:55 --> Security Class Initialized
DEBUG - 2016-02-05 11:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:46:55 --> Input Class Initialized
INFO - 2016-02-05 11:46:55 --> Language Class Initialized
INFO - 2016-02-05 11:46:55 --> Loader Class Initialized
INFO - 2016-02-05 11:46:55 --> Helper loaded: url_helper
INFO - 2016-02-05 11:46:55 --> Helper loaded: file_helper
INFO - 2016-02-05 11:46:55 --> Helper loaded: date_helper
INFO - 2016-02-05 11:46:55 --> Helper loaded: form_helper
INFO - 2016-02-05 11:46:55 --> Database Driver Class Initialized
INFO - 2016-02-05 11:46:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:46:56 --> Controller Class Initialized
INFO - 2016-02-05 11:46:56 --> Model Class Initialized
INFO - 2016-02-05 11:46:56 --> Model Class Initialized
INFO - 2016-02-05 11:46:56 --> Form Validation Class Initialized
INFO - 2016-02-05 11:46:56 --> Helper loaded: text_helper
INFO - 2016-02-05 11:46:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:46:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:46:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:46:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:46:56 --> Final output sent to browser
DEBUG - 2016-02-05 11:46:56 --> Total execution time: 1.1025
INFO - 2016-02-05 11:46:59 --> Config Class Initialized
INFO - 2016-02-05 11:46:59 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:46:59 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:46:59 --> Utf8 Class Initialized
INFO - 2016-02-05 11:46:59 --> URI Class Initialized
INFO - 2016-02-05 11:46:59 --> Router Class Initialized
INFO - 2016-02-05 11:46:59 --> Output Class Initialized
INFO - 2016-02-05 11:46:59 --> Security Class Initialized
DEBUG - 2016-02-05 11:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:46:59 --> Input Class Initialized
INFO - 2016-02-05 11:46:59 --> Language Class Initialized
INFO - 2016-02-05 11:46:59 --> Loader Class Initialized
INFO - 2016-02-05 11:46:59 --> Helper loaded: url_helper
INFO - 2016-02-05 11:46:59 --> Helper loaded: file_helper
INFO - 2016-02-05 11:46:59 --> Helper loaded: date_helper
INFO - 2016-02-05 11:46:59 --> Helper loaded: form_helper
INFO - 2016-02-05 11:46:59 --> Database Driver Class Initialized
INFO - 2016-02-05 11:47:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:47:00 --> Controller Class Initialized
INFO - 2016-02-05 11:47:00 --> Model Class Initialized
INFO - 2016-02-05 11:47:00 --> Model Class Initialized
INFO - 2016-02-05 11:47:00 --> Form Validation Class Initialized
INFO - 2016-02-05 11:47:00 --> Helper loaded: text_helper
INFO - 2016-02-05 11:47:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:47:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:47:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:47:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:47:00 --> Final output sent to browser
DEBUG - 2016-02-05 11:47:00 --> Total execution time: 1.1696
INFO - 2016-02-05 11:47:48 --> Config Class Initialized
INFO - 2016-02-05 11:47:48 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:47:48 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:47:48 --> Utf8 Class Initialized
INFO - 2016-02-05 11:47:48 --> URI Class Initialized
DEBUG - 2016-02-05 11:47:48 --> No URI present. Default controller set.
INFO - 2016-02-05 11:47:48 --> Router Class Initialized
INFO - 2016-02-05 11:47:48 --> Output Class Initialized
INFO - 2016-02-05 11:47:48 --> Security Class Initialized
DEBUG - 2016-02-05 11:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:47:48 --> Input Class Initialized
INFO - 2016-02-05 11:47:48 --> Language Class Initialized
INFO - 2016-02-05 11:47:48 --> Loader Class Initialized
INFO - 2016-02-05 11:47:48 --> Helper loaded: url_helper
INFO - 2016-02-05 11:47:48 --> Helper loaded: file_helper
INFO - 2016-02-05 11:47:48 --> Helper loaded: date_helper
INFO - 2016-02-05 11:47:48 --> Helper loaded: form_helper
INFO - 2016-02-05 11:47:48 --> Database Driver Class Initialized
INFO - 2016-02-05 11:47:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:47:49 --> Controller Class Initialized
INFO - 2016-02-05 11:47:49 --> Model Class Initialized
INFO - 2016-02-05 11:47:49 --> Model Class Initialized
INFO - 2016-02-05 11:47:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 11:47:49 --> Pagination Class Initialized
INFO - 2016-02-05 11:47:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:47:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:47:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 11:47:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:47:49 --> Final output sent to browser
DEBUG - 2016-02-05 11:47:49 --> Total execution time: 1.1583
INFO - 2016-02-05 11:47:50 --> Config Class Initialized
INFO - 2016-02-05 11:47:50 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:47:50 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:47:50 --> Utf8 Class Initialized
INFO - 2016-02-05 11:47:50 --> URI Class Initialized
INFO - 2016-02-05 11:47:50 --> Router Class Initialized
INFO - 2016-02-05 11:47:50 --> Output Class Initialized
INFO - 2016-02-05 11:47:50 --> Security Class Initialized
DEBUG - 2016-02-05 11:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:47:50 --> Input Class Initialized
INFO - 2016-02-05 11:47:50 --> Language Class Initialized
INFO - 2016-02-05 11:47:50 --> Loader Class Initialized
INFO - 2016-02-05 11:47:50 --> Helper loaded: url_helper
INFO - 2016-02-05 11:47:50 --> Helper loaded: file_helper
INFO - 2016-02-05 11:47:50 --> Helper loaded: date_helper
INFO - 2016-02-05 11:47:50 --> Helper loaded: form_helper
INFO - 2016-02-05 11:47:50 --> Database Driver Class Initialized
INFO - 2016-02-05 11:47:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:47:51 --> Controller Class Initialized
INFO - 2016-02-05 11:47:51 --> Model Class Initialized
INFO - 2016-02-05 11:47:51 --> Model Class Initialized
INFO - 2016-02-05 11:47:51 --> Form Validation Class Initialized
INFO - 2016-02-05 11:47:51 --> Helper loaded: text_helper
INFO - 2016-02-05 11:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:47:51 --> Final output sent to browser
DEBUG - 2016-02-05 11:47:51 --> Total execution time: 1.1487
INFO - 2016-02-05 11:47:53 --> Config Class Initialized
INFO - 2016-02-05 11:47:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:47:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:47:53 --> Utf8 Class Initialized
INFO - 2016-02-05 11:47:53 --> URI Class Initialized
INFO - 2016-02-05 11:47:53 --> Router Class Initialized
INFO - 2016-02-05 11:47:53 --> Output Class Initialized
INFO - 2016-02-05 11:47:53 --> Security Class Initialized
DEBUG - 2016-02-05 11:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:47:53 --> Input Class Initialized
INFO - 2016-02-05 11:47:53 --> Language Class Initialized
INFO - 2016-02-05 11:47:53 --> Loader Class Initialized
INFO - 2016-02-05 11:47:53 --> Helper loaded: url_helper
INFO - 2016-02-05 11:47:53 --> Helper loaded: file_helper
INFO - 2016-02-05 11:47:53 --> Helper loaded: date_helper
INFO - 2016-02-05 11:47:53 --> Helper loaded: form_helper
INFO - 2016-02-05 11:47:53 --> Database Driver Class Initialized
INFO - 2016-02-05 11:47:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:47:54 --> Controller Class Initialized
INFO - 2016-02-05 11:47:54 --> Model Class Initialized
INFO - 2016-02-05 11:47:54 --> Model Class Initialized
INFO - 2016-02-05 11:47:54 --> Form Validation Class Initialized
INFO - 2016-02-05 11:47:54 --> Helper loaded: text_helper
INFO - 2016-02-05 11:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:47:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:47:54 --> Final output sent to browser
DEBUG - 2016-02-05 11:47:54 --> Total execution time: 1.1130
INFO - 2016-02-05 11:47:57 --> Config Class Initialized
INFO - 2016-02-05 11:47:57 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:47:57 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:47:57 --> Utf8 Class Initialized
INFO - 2016-02-05 11:47:57 --> URI Class Initialized
INFO - 2016-02-05 11:47:57 --> Router Class Initialized
INFO - 2016-02-05 11:47:57 --> Output Class Initialized
INFO - 2016-02-05 11:47:57 --> Security Class Initialized
DEBUG - 2016-02-05 11:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:47:57 --> Input Class Initialized
INFO - 2016-02-05 11:47:57 --> Language Class Initialized
INFO - 2016-02-05 11:47:57 --> Loader Class Initialized
INFO - 2016-02-05 11:47:57 --> Helper loaded: url_helper
INFO - 2016-02-05 11:47:57 --> Helper loaded: file_helper
INFO - 2016-02-05 11:47:57 --> Helper loaded: date_helper
INFO - 2016-02-05 11:47:57 --> Helper loaded: form_helper
INFO - 2016-02-05 11:47:57 --> Database Driver Class Initialized
INFO - 2016-02-05 11:47:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:47:58 --> Controller Class Initialized
INFO - 2016-02-05 11:47:58 --> Model Class Initialized
INFO - 2016-02-05 11:47:58 --> Model Class Initialized
INFO - 2016-02-05 11:47:58 --> Form Validation Class Initialized
INFO - 2016-02-05 11:47:58 --> Helper loaded: text_helper
INFO - 2016-02-05 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:47:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:47:58 --> Final output sent to browser
DEBUG - 2016-02-05 11:47:58 --> Total execution time: 1.1201
INFO - 2016-02-05 11:48:47 --> Config Class Initialized
INFO - 2016-02-05 11:48:47 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:48:47 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:48:47 --> Utf8 Class Initialized
INFO - 2016-02-05 11:48:47 --> URI Class Initialized
INFO - 2016-02-05 11:48:47 --> Router Class Initialized
INFO - 2016-02-05 11:48:47 --> Output Class Initialized
INFO - 2016-02-05 11:48:47 --> Security Class Initialized
DEBUG - 2016-02-05 11:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:48:47 --> Input Class Initialized
INFO - 2016-02-05 11:48:47 --> Language Class Initialized
INFO - 2016-02-05 11:48:47 --> Loader Class Initialized
INFO - 2016-02-05 11:48:47 --> Helper loaded: url_helper
INFO - 2016-02-05 11:48:47 --> Helper loaded: file_helper
INFO - 2016-02-05 11:48:47 --> Helper loaded: date_helper
INFO - 2016-02-05 11:48:47 --> Helper loaded: form_helper
INFO - 2016-02-05 11:48:47 --> Database Driver Class Initialized
INFO - 2016-02-05 11:48:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:48:49 --> Controller Class Initialized
INFO - 2016-02-05 11:48:49 --> Model Class Initialized
INFO - 2016-02-05 11:48:49 --> Model Class Initialized
INFO - 2016-02-05 11:48:49 --> Form Validation Class Initialized
INFO - 2016-02-05 11:48:49 --> Helper loaded: text_helper
INFO - 2016-02-05 11:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:48:49 --> Final output sent to browser
DEBUG - 2016-02-05 11:48:49 --> Total execution time: 1.1745
INFO - 2016-02-05 11:48:50 --> Config Class Initialized
INFO - 2016-02-05 11:48:50 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:48:50 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:48:50 --> Utf8 Class Initialized
INFO - 2016-02-05 11:48:50 --> URI Class Initialized
INFO - 2016-02-05 11:48:50 --> Router Class Initialized
INFO - 2016-02-05 11:48:50 --> Output Class Initialized
INFO - 2016-02-05 11:48:50 --> Security Class Initialized
DEBUG - 2016-02-05 11:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:48:50 --> Input Class Initialized
INFO - 2016-02-05 11:48:50 --> Language Class Initialized
INFO - 2016-02-05 11:48:50 --> Loader Class Initialized
INFO - 2016-02-05 11:48:50 --> Helper loaded: url_helper
INFO - 2016-02-05 11:48:50 --> Helper loaded: file_helper
INFO - 2016-02-05 11:48:50 --> Helper loaded: date_helper
INFO - 2016-02-05 11:48:50 --> Helper loaded: form_helper
INFO - 2016-02-05 11:48:50 --> Database Driver Class Initialized
INFO - 2016-02-05 11:48:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:48:51 --> Controller Class Initialized
INFO - 2016-02-05 11:48:51 --> Model Class Initialized
INFO - 2016-02-05 11:48:51 --> Model Class Initialized
INFO - 2016-02-05 11:48:51 --> Form Validation Class Initialized
INFO - 2016-02-05 11:48:51 --> Helper loaded: text_helper
INFO - 2016-02-05 11:48:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:48:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:48:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:48:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:48:51 --> Final output sent to browser
DEBUG - 2016-02-05 11:48:51 --> Total execution time: 1.1691
INFO - 2016-02-05 11:48:53 --> Config Class Initialized
INFO - 2016-02-05 11:48:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:48:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:48:53 --> Utf8 Class Initialized
INFO - 2016-02-05 11:48:53 --> URI Class Initialized
INFO - 2016-02-05 11:48:53 --> Router Class Initialized
INFO - 2016-02-05 11:48:53 --> Output Class Initialized
INFO - 2016-02-05 11:48:53 --> Security Class Initialized
DEBUG - 2016-02-05 11:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:48:53 --> Input Class Initialized
INFO - 2016-02-05 11:48:53 --> Language Class Initialized
INFO - 2016-02-05 11:48:53 --> Loader Class Initialized
INFO - 2016-02-05 11:48:53 --> Helper loaded: url_helper
INFO - 2016-02-05 11:48:53 --> Helper loaded: file_helper
INFO - 2016-02-05 11:48:53 --> Helper loaded: date_helper
INFO - 2016-02-05 11:48:53 --> Helper loaded: form_helper
INFO - 2016-02-05 11:48:53 --> Database Driver Class Initialized
INFO - 2016-02-05 11:48:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:48:54 --> Controller Class Initialized
INFO - 2016-02-05 11:48:54 --> Model Class Initialized
INFO - 2016-02-05 11:48:54 --> Model Class Initialized
INFO - 2016-02-05 11:48:54 --> Form Validation Class Initialized
INFO - 2016-02-05 11:48:54 --> Helper loaded: text_helper
INFO - 2016-02-05 11:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:48:54 --> Final output sent to browser
DEBUG - 2016-02-05 11:48:54 --> Total execution time: 1.1270
INFO - 2016-02-05 11:52:34 --> Config Class Initialized
INFO - 2016-02-05 11:52:34 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:52:34 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:52:34 --> Utf8 Class Initialized
INFO - 2016-02-05 11:52:34 --> URI Class Initialized
INFO - 2016-02-05 11:52:34 --> Router Class Initialized
INFO - 2016-02-05 11:52:34 --> Output Class Initialized
INFO - 2016-02-05 11:52:34 --> Security Class Initialized
DEBUG - 2016-02-05 11:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:52:34 --> Input Class Initialized
INFO - 2016-02-05 11:52:34 --> Language Class Initialized
INFO - 2016-02-05 11:52:34 --> Loader Class Initialized
INFO - 2016-02-05 11:52:34 --> Helper loaded: url_helper
INFO - 2016-02-05 11:52:34 --> Helper loaded: file_helper
INFO - 2016-02-05 11:52:34 --> Helper loaded: date_helper
INFO - 2016-02-05 11:52:34 --> Helper loaded: form_helper
INFO - 2016-02-05 11:52:34 --> Database Driver Class Initialized
INFO - 2016-02-05 11:52:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:52:35 --> Controller Class Initialized
INFO - 2016-02-05 11:52:35 --> Model Class Initialized
INFO - 2016-02-05 11:52:35 --> Model Class Initialized
INFO - 2016-02-05 11:52:35 --> Form Validation Class Initialized
INFO - 2016-02-05 11:52:35 --> Helper loaded: text_helper
INFO - 2016-02-05 11:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:52:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:52:35 --> Final output sent to browser
DEBUG - 2016-02-05 11:52:35 --> Total execution time: 1.1783
INFO - 2016-02-05 11:52:37 --> Config Class Initialized
INFO - 2016-02-05 11:52:37 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:52:37 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:52:37 --> Utf8 Class Initialized
INFO - 2016-02-05 11:52:37 --> URI Class Initialized
INFO - 2016-02-05 11:52:37 --> Router Class Initialized
INFO - 2016-02-05 11:52:37 --> Output Class Initialized
INFO - 2016-02-05 11:52:37 --> Security Class Initialized
DEBUG - 2016-02-05 11:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:52:37 --> Input Class Initialized
INFO - 2016-02-05 11:52:37 --> Language Class Initialized
INFO - 2016-02-05 11:52:37 --> Loader Class Initialized
INFO - 2016-02-05 11:52:37 --> Helper loaded: url_helper
INFO - 2016-02-05 11:52:37 --> Helper loaded: file_helper
INFO - 2016-02-05 11:52:37 --> Helper loaded: date_helper
INFO - 2016-02-05 11:52:37 --> Helper loaded: form_helper
INFO - 2016-02-05 11:52:37 --> Database Driver Class Initialized
INFO - 2016-02-05 11:52:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:52:38 --> Controller Class Initialized
INFO - 2016-02-05 11:52:38 --> Model Class Initialized
INFO - 2016-02-05 11:52:38 --> Model Class Initialized
INFO - 2016-02-05 11:52:38 --> Form Validation Class Initialized
INFO - 2016-02-05 11:52:39 --> Helper loaded: text_helper
INFO - 2016-02-05 11:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:52:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:52:39 --> Final output sent to browser
DEBUG - 2016-02-05 11:52:39 --> Total execution time: 1.1587
INFO - 2016-02-05 11:59:17 --> Config Class Initialized
INFO - 2016-02-05 11:59:17 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:59:17 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:59:17 --> Utf8 Class Initialized
INFO - 2016-02-05 11:59:17 --> URI Class Initialized
INFO - 2016-02-05 11:59:17 --> Router Class Initialized
INFO - 2016-02-05 11:59:17 --> Output Class Initialized
INFO - 2016-02-05 11:59:17 --> Security Class Initialized
DEBUG - 2016-02-05 11:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:59:17 --> Input Class Initialized
INFO - 2016-02-05 11:59:17 --> Language Class Initialized
INFO - 2016-02-05 11:59:17 --> Loader Class Initialized
INFO - 2016-02-05 11:59:17 --> Helper loaded: url_helper
INFO - 2016-02-05 11:59:17 --> Helper loaded: file_helper
INFO - 2016-02-05 11:59:17 --> Helper loaded: date_helper
INFO - 2016-02-05 11:59:17 --> Helper loaded: form_helper
INFO - 2016-02-05 11:59:17 --> Database Driver Class Initialized
INFO - 2016-02-05 11:59:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:59:18 --> Controller Class Initialized
INFO - 2016-02-05 11:59:18 --> Model Class Initialized
INFO - 2016-02-05 11:59:18 --> Model Class Initialized
INFO - 2016-02-05 11:59:18 --> Form Validation Class Initialized
INFO - 2016-02-05 11:59:18 --> Helper loaded: text_helper
INFO - 2016-02-05 11:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:59:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:59:18 --> Final output sent to browser
DEBUG - 2016-02-05 11:59:18 --> Total execution time: 1.1314
INFO - 2016-02-05 11:59:19 --> Config Class Initialized
INFO - 2016-02-05 11:59:19 --> Hooks Class Initialized
DEBUG - 2016-02-05 11:59:19 --> UTF-8 Support Enabled
INFO - 2016-02-05 11:59:19 --> Utf8 Class Initialized
INFO - 2016-02-05 11:59:19 --> URI Class Initialized
INFO - 2016-02-05 11:59:19 --> Router Class Initialized
INFO - 2016-02-05 11:59:19 --> Output Class Initialized
INFO - 2016-02-05 11:59:19 --> Security Class Initialized
DEBUG - 2016-02-05 11:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 11:59:19 --> Input Class Initialized
INFO - 2016-02-05 11:59:19 --> Language Class Initialized
INFO - 2016-02-05 11:59:19 --> Loader Class Initialized
INFO - 2016-02-05 11:59:19 --> Helper loaded: url_helper
INFO - 2016-02-05 11:59:19 --> Helper loaded: file_helper
INFO - 2016-02-05 11:59:19 --> Helper loaded: date_helper
INFO - 2016-02-05 11:59:19 --> Helper loaded: form_helper
INFO - 2016-02-05 11:59:19 --> Database Driver Class Initialized
INFO - 2016-02-05 11:59:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 11:59:20 --> Controller Class Initialized
INFO - 2016-02-05 11:59:20 --> Model Class Initialized
INFO - 2016-02-05 11:59:20 --> Model Class Initialized
INFO - 2016-02-05 11:59:20 --> Form Validation Class Initialized
INFO - 2016-02-05 11:59:20 --> Helper loaded: text_helper
INFO - 2016-02-05 11:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 11:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 11:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 11:59:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 11:59:20 --> Final output sent to browser
DEBUG - 2016-02-05 11:59:20 --> Total execution time: 1.1561
INFO - 2016-02-05 12:00:52 --> Config Class Initialized
INFO - 2016-02-05 12:00:52 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:00:52 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:00:52 --> Utf8 Class Initialized
INFO - 2016-02-05 12:00:52 --> URI Class Initialized
INFO - 2016-02-05 12:00:52 --> Router Class Initialized
INFO - 2016-02-05 12:00:52 --> Output Class Initialized
INFO - 2016-02-05 12:00:52 --> Security Class Initialized
DEBUG - 2016-02-05 12:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:00:52 --> Input Class Initialized
INFO - 2016-02-05 12:00:52 --> Language Class Initialized
INFO - 2016-02-05 12:00:52 --> Loader Class Initialized
INFO - 2016-02-05 12:00:52 --> Helper loaded: url_helper
INFO - 2016-02-05 12:00:52 --> Helper loaded: file_helper
INFO - 2016-02-05 12:00:52 --> Helper loaded: date_helper
INFO - 2016-02-05 12:00:52 --> Helper loaded: form_helper
INFO - 2016-02-05 12:00:52 --> Database Driver Class Initialized
INFO - 2016-02-05 12:00:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:00:53 --> Controller Class Initialized
INFO - 2016-02-05 12:00:53 --> Model Class Initialized
INFO - 2016-02-05 12:00:53 --> Model Class Initialized
INFO - 2016-02-05 12:00:53 --> Form Validation Class Initialized
INFO - 2016-02-05 12:00:53 --> Helper loaded: text_helper
INFO - 2016-02-05 12:00:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:00:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:00:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:00:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:00:53 --> Final output sent to browser
DEBUG - 2016-02-05 12:00:53 --> Total execution time: 1.1597
INFO - 2016-02-05 12:00:55 --> Config Class Initialized
INFO - 2016-02-05 12:00:55 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:00:55 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:00:55 --> Utf8 Class Initialized
INFO - 2016-02-05 12:00:55 --> URI Class Initialized
INFO - 2016-02-05 12:00:55 --> Router Class Initialized
INFO - 2016-02-05 12:00:55 --> Output Class Initialized
INFO - 2016-02-05 12:00:55 --> Security Class Initialized
DEBUG - 2016-02-05 12:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:00:55 --> Input Class Initialized
INFO - 2016-02-05 12:00:55 --> Language Class Initialized
INFO - 2016-02-05 12:00:55 --> Loader Class Initialized
INFO - 2016-02-05 12:00:55 --> Helper loaded: url_helper
INFO - 2016-02-05 12:00:55 --> Helper loaded: file_helper
INFO - 2016-02-05 12:00:55 --> Helper loaded: date_helper
INFO - 2016-02-05 12:00:55 --> Helper loaded: form_helper
INFO - 2016-02-05 12:00:55 --> Database Driver Class Initialized
INFO - 2016-02-05 12:00:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:00:56 --> Controller Class Initialized
INFO - 2016-02-05 12:00:56 --> Model Class Initialized
INFO - 2016-02-05 12:00:56 --> Model Class Initialized
INFO - 2016-02-05 12:00:56 --> Form Validation Class Initialized
INFO - 2016-02-05 12:00:56 --> Helper loaded: text_helper
INFO - 2016-02-05 12:00:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:00:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:00:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:00:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:00:56 --> Final output sent to browser
DEBUG - 2016-02-05 12:00:56 --> Total execution time: 1.1847
INFO - 2016-02-05 12:03:33 --> Config Class Initialized
INFO - 2016-02-05 12:03:33 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:03:33 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:03:33 --> Utf8 Class Initialized
INFO - 2016-02-05 12:03:33 --> URI Class Initialized
INFO - 2016-02-05 12:03:33 --> Router Class Initialized
INFO - 2016-02-05 12:03:33 --> Output Class Initialized
INFO - 2016-02-05 12:03:33 --> Security Class Initialized
DEBUG - 2016-02-05 12:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:03:33 --> Input Class Initialized
INFO - 2016-02-05 12:03:33 --> Language Class Initialized
INFO - 2016-02-05 12:03:33 --> Loader Class Initialized
INFO - 2016-02-05 12:03:33 --> Helper loaded: url_helper
INFO - 2016-02-05 12:03:33 --> Helper loaded: file_helper
INFO - 2016-02-05 12:03:33 --> Helper loaded: date_helper
INFO - 2016-02-05 12:03:33 --> Helper loaded: form_helper
INFO - 2016-02-05 12:03:33 --> Database Driver Class Initialized
INFO - 2016-02-05 12:03:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:03:34 --> Controller Class Initialized
INFO - 2016-02-05 12:03:34 --> Model Class Initialized
INFO - 2016-02-05 12:03:34 --> Model Class Initialized
INFO - 2016-02-05 12:03:34 --> Form Validation Class Initialized
INFO - 2016-02-05 12:03:34 --> Helper loaded: text_helper
INFO - 2016-02-05 12:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:03:34 --> Final output sent to browser
DEBUG - 2016-02-05 12:03:34 --> Total execution time: 1.1829
INFO - 2016-02-05 12:04:51 --> Config Class Initialized
INFO - 2016-02-05 12:04:51 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:04:51 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:04:51 --> Utf8 Class Initialized
INFO - 2016-02-05 12:04:51 --> URI Class Initialized
INFO - 2016-02-05 12:04:51 --> Router Class Initialized
INFO - 2016-02-05 12:04:51 --> Output Class Initialized
INFO - 2016-02-05 12:04:51 --> Security Class Initialized
DEBUG - 2016-02-05 12:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:04:51 --> Input Class Initialized
INFO - 2016-02-05 12:04:51 --> Language Class Initialized
INFO - 2016-02-05 12:04:51 --> Loader Class Initialized
INFO - 2016-02-05 12:04:51 --> Helper loaded: url_helper
INFO - 2016-02-05 12:04:51 --> Helper loaded: file_helper
INFO - 2016-02-05 12:04:51 --> Helper loaded: date_helper
INFO - 2016-02-05 12:04:51 --> Helper loaded: form_helper
INFO - 2016-02-05 12:04:51 --> Database Driver Class Initialized
INFO - 2016-02-05 12:04:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:04:52 --> Controller Class Initialized
INFO - 2016-02-05 12:04:52 --> Model Class Initialized
INFO - 2016-02-05 12:04:52 --> Model Class Initialized
INFO - 2016-02-05 12:04:52 --> Form Validation Class Initialized
INFO - 2016-02-05 12:04:52 --> Helper loaded: text_helper
INFO - 2016-02-05 12:04:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:04:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:04:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:04:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:04:52 --> Final output sent to browser
DEBUG - 2016-02-05 12:04:52 --> Total execution time: 1.1862
INFO - 2016-02-05 12:04:53 --> Config Class Initialized
INFO - 2016-02-05 12:04:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:04:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:04:53 --> Utf8 Class Initialized
INFO - 2016-02-05 12:04:53 --> URI Class Initialized
INFO - 2016-02-05 12:04:53 --> Router Class Initialized
INFO - 2016-02-05 12:04:53 --> Output Class Initialized
INFO - 2016-02-05 12:04:53 --> Security Class Initialized
DEBUG - 2016-02-05 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:04:53 --> Input Class Initialized
INFO - 2016-02-05 12:04:53 --> Language Class Initialized
INFO - 2016-02-05 12:04:53 --> Loader Class Initialized
INFO - 2016-02-05 12:04:53 --> Helper loaded: url_helper
INFO - 2016-02-05 12:04:53 --> Helper loaded: file_helper
INFO - 2016-02-05 12:04:53 --> Helper loaded: date_helper
INFO - 2016-02-05 12:04:53 --> Helper loaded: form_helper
INFO - 2016-02-05 12:04:53 --> Database Driver Class Initialized
INFO - 2016-02-05 12:04:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:04:54 --> Controller Class Initialized
INFO - 2016-02-05 12:04:55 --> Model Class Initialized
INFO - 2016-02-05 12:04:55 --> Model Class Initialized
INFO - 2016-02-05 12:04:55 --> Form Validation Class Initialized
INFO - 2016-02-05 12:04:55 --> Helper loaded: text_helper
INFO - 2016-02-05 12:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:04:55 --> Final output sent to browser
DEBUG - 2016-02-05 12:04:55 --> Total execution time: 1.1896
INFO - 2016-02-05 12:05:19 --> Config Class Initialized
INFO - 2016-02-05 12:05:19 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:05:19 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:05:19 --> Utf8 Class Initialized
INFO - 2016-02-05 12:05:19 --> URI Class Initialized
INFO - 2016-02-05 12:05:19 --> Router Class Initialized
INFO - 2016-02-05 12:05:19 --> Output Class Initialized
INFO - 2016-02-05 12:05:19 --> Security Class Initialized
DEBUG - 2016-02-05 12:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:05:19 --> Input Class Initialized
INFO - 2016-02-05 12:05:19 --> Language Class Initialized
INFO - 2016-02-05 12:05:19 --> Loader Class Initialized
INFO - 2016-02-05 12:05:19 --> Helper loaded: url_helper
INFO - 2016-02-05 12:05:19 --> Helper loaded: file_helper
INFO - 2016-02-05 12:05:19 --> Helper loaded: date_helper
INFO - 2016-02-05 12:05:19 --> Helper loaded: form_helper
INFO - 2016-02-05 12:05:19 --> Database Driver Class Initialized
INFO - 2016-02-05 12:05:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:05:20 --> Controller Class Initialized
INFO - 2016-02-05 12:05:20 --> Model Class Initialized
INFO - 2016-02-05 12:05:20 --> Model Class Initialized
INFO - 2016-02-05 12:05:20 --> Form Validation Class Initialized
INFO - 2016-02-05 12:05:20 --> Helper loaded: text_helper
INFO - 2016-02-05 12:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:05:20 --> Final output sent to browser
DEBUG - 2016-02-05 12:05:20 --> Total execution time: 1.1569
INFO - 2016-02-05 12:05:42 --> Config Class Initialized
INFO - 2016-02-05 12:05:42 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:05:42 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:05:42 --> Utf8 Class Initialized
INFO - 2016-02-05 12:05:42 --> URI Class Initialized
INFO - 2016-02-05 12:05:42 --> Router Class Initialized
INFO - 2016-02-05 12:05:42 --> Output Class Initialized
INFO - 2016-02-05 12:05:42 --> Security Class Initialized
DEBUG - 2016-02-05 12:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:05:42 --> Input Class Initialized
INFO - 2016-02-05 12:05:42 --> Language Class Initialized
INFO - 2016-02-05 12:05:42 --> Loader Class Initialized
INFO - 2016-02-05 12:05:42 --> Helper loaded: url_helper
INFO - 2016-02-05 12:05:42 --> Helper loaded: file_helper
INFO - 2016-02-05 12:05:42 --> Helper loaded: date_helper
INFO - 2016-02-05 12:05:42 --> Helper loaded: form_helper
INFO - 2016-02-05 12:05:42 --> Database Driver Class Initialized
INFO - 2016-02-05 12:05:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:05:43 --> Controller Class Initialized
INFO - 2016-02-05 12:05:43 --> Model Class Initialized
INFO - 2016-02-05 12:05:43 --> Model Class Initialized
INFO - 2016-02-05 12:05:43 --> Form Validation Class Initialized
INFO - 2016-02-05 12:05:43 --> Helper loaded: text_helper
INFO - 2016-02-05 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:05:43 --> Final output sent to browser
DEBUG - 2016-02-05 12:05:43 --> Total execution time: 1.1455
INFO - 2016-02-05 12:05:57 --> Config Class Initialized
INFO - 2016-02-05 12:05:57 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:05:57 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:05:57 --> Utf8 Class Initialized
INFO - 2016-02-05 12:05:57 --> URI Class Initialized
INFO - 2016-02-05 12:05:57 --> Router Class Initialized
INFO - 2016-02-05 12:05:57 --> Output Class Initialized
INFO - 2016-02-05 12:05:57 --> Security Class Initialized
DEBUG - 2016-02-05 12:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:05:57 --> Input Class Initialized
INFO - 2016-02-05 12:05:57 --> Language Class Initialized
INFO - 2016-02-05 12:05:57 --> Loader Class Initialized
INFO - 2016-02-05 12:05:57 --> Helper loaded: url_helper
INFO - 2016-02-05 12:05:57 --> Helper loaded: file_helper
INFO - 2016-02-05 12:05:57 --> Helper loaded: date_helper
INFO - 2016-02-05 12:05:57 --> Helper loaded: form_helper
INFO - 2016-02-05 12:05:57 --> Database Driver Class Initialized
INFO - 2016-02-05 12:05:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:05:58 --> Controller Class Initialized
INFO - 2016-02-05 12:05:58 --> Model Class Initialized
INFO - 2016-02-05 12:05:58 --> Model Class Initialized
INFO - 2016-02-05 12:05:58 --> Form Validation Class Initialized
INFO - 2016-02-05 12:05:58 --> Helper loaded: text_helper
INFO - 2016-02-05 12:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:05:58 --> Final output sent to browser
DEBUG - 2016-02-05 12:05:58 --> Total execution time: 1.1508
INFO - 2016-02-05 12:07:20 --> Config Class Initialized
INFO - 2016-02-05 12:07:20 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:07:20 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:07:20 --> Utf8 Class Initialized
INFO - 2016-02-05 12:07:20 --> URI Class Initialized
INFO - 2016-02-05 12:07:20 --> Router Class Initialized
INFO - 2016-02-05 12:07:20 --> Output Class Initialized
INFO - 2016-02-05 12:07:20 --> Security Class Initialized
DEBUG - 2016-02-05 12:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:07:20 --> Input Class Initialized
INFO - 2016-02-05 12:07:20 --> Language Class Initialized
INFO - 2016-02-05 12:07:20 --> Loader Class Initialized
INFO - 2016-02-05 12:07:20 --> Helper loaded: url_helper
INFO - 2016-02-05 12:07:20 --> Helper loaded: file_helper
INFO - 2016-02-05 12:07:20 --> Helper loaded: date_helper
INFO - 2016-02-05 12:07:20 --> Helper loaded: form_helper
INFO - 2016-02-05 12:07:20 --> Database Driver Class Initialized
INFO - 2016-02-05 12:07:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:07:21 --> Controller Class Initialized
INFO - 2016-02-05 12:07:21 --> Model Class Initialized
INFO - 2016-02-05 12:07:21 --> Model Class Initialized
INFO - 2016-02-05 12:07:21 --> Form Validation Class Initialized
INFO - 2016-02-05 12:07:21 --> Helper loaded: text_helper
INFO - 2016-02-05 12:07:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:07:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:07:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:07:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:07:21 --> Final output sent to browser
DEBUG - 2016-02-05 12:07:21 --> Total execution time: 1.1693
INFO - 2016-02-05 12:10:34 --> Config Class Initialized
INFO - 2016-02-05 12:10:34 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:10:34 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:10:34 --> Utf8 Class Initialized
INFO - 2016-02-05 12:10:34 --> URI Class Initialized
INFO - 2016-02-05 12:10:34 --> Router Class Initialized
INFO - 2016-02-05 12:10:34 --> Output Class Initialized
INFO - 2016-02-05 12:10:34 --> Security Class Initialized
DEBUG - 2016-02-05 12:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:10:34 --> Input Class Initialized
INFO - 2016-02-05 12:10:34 --> Language Class Initialized
ERROR - 2016-02-05 12:10:34 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 88
INFO - 2016-02-05 12:11:00 --> Config Class Initialized
INFO - 2016-02-05 12:11:00 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:11:00 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:11:00 --> Utf8 Class Initialized
INFO - 2016-02-05 12:11:00 --> URI Class Initialized
INFO - 2016-02-05 12:11:00 --> Router Class Initialized
INFO - 2016-02-05 12:11:00 --> Output Class Initialized
INFO - 2016-02-05 12:11:00 --> Security Class Initialized
DEBUG - 2016-02-05 12:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:11:00 --> Input Class Initialized
INFO - 2016-02-05 12:11:00 --> Language Class Initialized
INFO - 2016-02-05 12:11:00 --> Loader Class Initialized
INFO - 2016-02-05 12:11:00 --> Helper loaded: url_helper
INFO - 2016-02-05 12:11:00 --> Helper loaded: file_helper
INFO - 2016-02-05 12:11:00 --> Helper loaded: date_helper
INFO - 2016-02-05 12:11:00 --> Helper loaded: form_helper
INFO - 2016-02-05 12:11:00 --> Database Driver Class Initialized
INFO - 2016-02-05 12:11:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:11:01 --> Controller Class Initialized
INFO - 2016-02-05 12:11:01 --> Model Class Initialized
INFO - 2016-02-05 12:11:01 --> Model Class Initialized
INFO - 2016-02-05 12:11:01 --> Form Validation Class Initialized
INFO - 2016-02-05 12:11:01 --> Helper loaded: text_helper
INFO - 2016-02-05 12:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:11:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:11:01 --> Final output sent to browser
DEBUG - 2016-02-05 12:11:01 --> Total execution time: 1.1843
INFO - 2016-02-05 12:11:03 --> Config Class Initialized
INFO - 2016-02-05 12:11:03 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:11:03 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:11:03 --> Utf8 Class Initialized
INFO - 2016-02-05 12:11:03 --> URI Class Initialized
INFO - 2016-02-05 12:11:03 --> Router Class Initialized
INFO - 2016-02-05 12:11:03 --> Output Class Initialized
INFO - 2016-02-05 12:11:03 --> Security Class Initialized
DEBUG - 2016-02-05 12:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:11:03 --> Input Class Initialized
INFO - 2016-02-05 12:11:03 --> Language Class Initialized
INFO - 2016-02-05 12:11:03 --> Loader Class Initialized
INFO - 2016-02-05 12:11:03 --> Helper loaded: url_helper
INFO - 2016-02-05 12:11:03 --> Helper loaded: file_helper
INFO - 2016-02-05 12:11:03 --> Helper loaded: date_helper
INFO - 2016-02-05 12:11:03 --> Helper loaded: form_helper
INFO - 2016-02-05 12:11:03 --> Database Driver Class Initialized
INFO - 2016-02-05 12:11:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:11:04 --> Controller Class Initialized
INFO - 2016-02-05 12:11:04 --> Model Class Initialized
INFO - 2016-02-05 12:11:04 --> Model Class Initialized
INFO - 2016-02-05 12:11:04 --> Form Validation Class Initialized
INFO - 2016-02-05 12:11:04 --> Helper loaded: text_helper
INFO - 2016-02-05 12:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:11:04 --> Final output sent to browser
DEBUG - 2016-02-05 12:11:04 --> Total execution time: 1.1819
INFO - 2016-02-05 12:12:56 --> Config Class Initialized
INFO - 2016-02-05 12:12:56 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:12:56 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:12:56 --> Utf8 Class Initialized
INFO - 2016-02-05 12:12:56 --> URI Class Initialized
INFO - 2016-02-05 12:12:56 --> Router Class Initialized
INFO - 2016-02-05 12:12:56 --> Output Class Initialized
INFO - 2016-02-05 12:12:56 --> Security Class Initialized
DEBUG - 2016-02-05 12:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:12:56 --> Input Class Initialized
INFO - 2016-02-05 12:12:56 --> Language Class Initialized
INFO - 2016-02-05 12:12:56 --> Loader Class Initialized
INFO - 2016-02-05 12:12:56 --> Helper loaded: url_helper
INFO - 2016-02-05 12:12:56 --> Helper loaded: file_helper
INFO - 2016-02-05 12:12:56 --> Helper loaded: date_helper
INFO - 2016-02-05 12:12:56 --> Helper loaded: form_helper
INFO - 2016-02-05 12:12:56 --> Database Driver Class Initialized
INFO - 2016-02-05 12:12:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:12:57 --> Controller Class Initialized
INFO - 2016-02-05 12:12:57 --> Model Class Initialized
INFO - 2016-02-05 12:12:57 --> Model Class Initialized
INFO - 2016-02-05 12:12:57 --> Form Validation Class Initialized
INFO - 2016-02-05 12:12:57 --> Helper loaded: text_helper
INFO - 2016-02-05 12:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:12:57 --> Final output sent to browser
DEBUG - 2016-02-05 12:12:57 --> Total execution time: 1.1621
INFO - 2016-02-05 12:13:24 --> Config Class Initialized
INFO - 2016-02-05 12:13:24 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:13:24 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:13:24 --> Utf8 Class Initialized
INFO - 2016-02-05 12:13:24 --> URI Class Initialized
INFO - 2016-02-05 12:13:24 --> Router Class Initialized
INFO - 2016-02-05 12:13:24 --> Output Class Initialized
INFO - 2016-02-05 12:13:24 --> Security Class Initialized
DEBUG - 2016-02-05 12:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:13:24 --> Input Class Initialized
INFO - 2016-02-05 12:13:24 --> Language Class Initialized
INFO - 2016-02-05 12:13:24 --> Loader Class Initialized
INFO - 2016-02-05 12:13:24 --> Helper loaded: url_helper
INFO - 2016-02-05 12:13:24 --> Helper loaded: file_helper
INFO - 2016-02-05 12:13:24 --> Helper loaded: date_helper
INFO - 2016-02-05 12:13:24 --> Helper loaded: form_helper
INFO - 2016-02-05 12:13:24 --> Database Driver Class Initialized
INFO - 2016-02-05 12:13:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:13:25 --> Controller Class Initialized
INFO - 2016-02-05 12:13:25 --> Model Class Initialized
INFO - 2016-02-05 12:13:25 --> Model Class Initialized
INFO - 2016-02-05 12:13:25 --> Form Validation Class Initialized
INFO - 2016-02-05 12:13:25 --> Helper loaded: text_helper
INFO - 2016-02-05 12:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:13:25 --> Final output sent to browser
DEBUG - 2016-02-05 12:13:25 --> Total execution time: 1.1814
INFO - 2016-02-05 12:13:26 --> Config Class Initialized
INFO - 2016-02-05 12:13:26 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:13:26 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:13:26 --> Utf8 Class Initialized
INFO - 2016-02-05 12:13:26 --> URI Class Initialized
INFO - 2016-02-05 12:13:26 --> Router Class Initialized
INFO - 2016-02-05 12:13:27 --> Output Class Initialized
INFO - 2016-02-05 12:13:27 --> Security Class Initialized
DEBUG - 2016-02-05 12:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:13:27 --> Input Class Initialized
INFO - 2016-02-05 12:13:27 --> Language Class Initialized
INFO - 2016-02-05 12:13:27 --> Loader Class Initialized
INFO - 2016-02-05 12:13:27 --> Helper loaded: url_helper
INFO - 2016-02-05 12:13:27 --> Helper loaded: file_helper
INFO - 2016-02-05 12:13:27 --> Helper loaded: date_helper
INFO - 2016-02-05 12:13:27 --> Helper loaded: form_helper
INFO - 2016-02-05 12:13:27 --> Database Driver Class Initialized
INFO - 2016-02-05 12:13:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:13:28 --> Controller Class Initialized
INFO - 2016-02-05 12:13:28 --> Model Class Initialized
INFO - 2016-02-05 12:13:28 --> Model Class Initialized
INFO - 2016-02-05 12:13:28 --> Form Validation Class Initialized
INFO - 2016-02-05 12:13:28 --> Helper loaded: text_helper
INFO - 2016-02-05 12:13:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:13:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:13:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:13:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:13:28 --> Final output sent to browser
DEBUG - 2016-02-05 12:13:28 --> Total execution time: 1.1702
INFO - 2016-02-05 12:13:49 --> Config Class Initialized
INFO - 2016-02-05 12:13:49 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:13:49 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:13:49 --> Utf8 Class Initialized
INFO - 2016-02-05 12:13:49 --> URI Class Initialized
INFO - 2016-02-05 12:13:49 --> Router Class Initialized
INFO - 2016-02-05 12:13:49 --> Output Class Initialized
INFO - 2016-02-05 12:13:49 --> Security Class Initialized
DEBUG - 2016-02-05 12:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:13:49 --> Input Class Initialized
INFO - 2016-02-05 12:13:49 --> Language Class Initialized
INFO - 2016-02-05 12:13:49 --> Loader Class Initialized
INFO - 2016-02-05 12:13:49 --> Helper loaded: url_helper
INFO - 2016-02-05 12:13:49 --> Helper loaded: file_helper
INFO - 2016-02-05 12:13:49 --> Helper loaded: date_helper
INFO - 2016-02-05 12:13:49 --> Helper loaded: form_helper
INFO - 2016-02-05 12:13:49 --> Database Driver Class Initialized
INFO - 2016-02-05 12:13:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:13:51 --> Controller Class Initialized
INFO - 2016-02-05 12:13:51 --> Model Class Initialized
INFO - 2016-02-05 12:13:51 --> Model Class Initialized
INFO - 2016-02-05 12:13:51 --> Form Validation Class Initialized
INFO - 2016-02-05 12:13:51 --> Helper loaded: text_helper
INFO - 2016-02-05 12:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:13:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:13:51 --> Final output sent to browser
DEBUG - 2016-02-05 12:13:51 --> Total execution time: 1.1629
INFO - 2016-02-05 12:14:54 --> Config Class Initialized
INFO - 2016-02-05 12:14:54 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:14:54 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:14:54 --> Utf8 Class Initialized
INFO - 2016-02-05 12:14:54 --> URI Class Initialized
INFO - 2016-02-05 12:14:54 --> Router Class Initialized
INFO - 2016-02-05 12:14:54 --> Output Class Initialized
INFO - 2016-02-05 12:14:54 --> Security Class Initialized
DEBUG - 2016-02-05 12:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:14:54 --> Input Class Initialized
INFO - 2016-02-05 12:14:54 --> Language Class Initialized
INFO - 2016-02-05 12:14:54 --> Loader Class Initialized
INFO - 2016-02-05 12:14:54 --> Helper loaded: url_helper
INFO - 2016-02-05 12:14:54 --> Helper loaded: file_helper
INFO - 2016-02-05 12:14:54 --> Helper loaded: date_helper
INFO - 2016-02-05 12:14:54 --> Helper loaded: form_helper
INFO - 2016-02-05 12:14:55 --> Database Driver Class Initialized
INFO - 2016-02-05 12:14:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:14:56 --> Controller Class Initialized
INFO - 2016-02-05 12:14:56 --> Model Class Initialized
INFO - 2016-02-05 12:14:56 --> Model Class Initialized
INFO - 2016-02-05 12:14:56 --> Form Validation Class Initialized
INFO - 2016-02-05 12:14:56 --> Helper loaded: text_helper
INFO - 2016-02-05 12:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:14:56 --> Final output sent to browser
DEBUG - 2016-02-05 12:14:56 --> Total execution time: 1.2028
INFO - 2016-02-05 12:15:12 --> Config Class Initialized
INFO - 2016-02-05 12:15:12 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:15:12 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:15:12 --> Utf8 Class Initialized
INFO - 2016-02-05 12:15:12 --> URI Class Initialized
INFO - 2016-02-05 12:15:12 --> Router Class Initialized
INFO - 2016-02-05 12:15:12 --> Output Class Initialized
INFO - 2016-02-05 12:15:12 --> Security Class Initialized
DEBUG - 2016-02-05 12:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:15:12 --> Input Class Initialized
INFO - 2016-02-05 12:15:12 --> Language Class Initialized
INFO - 2016-02-05 12:15:12 --> Loader Class Initialized
INFO - 2016-02-05 12:15:12 --> Helper loaded: url_helper
INFO - 2016-02-05 12:15:12 --> Helper loaded: file_helper
INFO - 2016-02-05 12:15:12 --> Helper loaded: date_helper
INFO - 2016-02-05 12:15:12 --> Helper loaded: form_helper
INFO - 2016-02-05 12:15:12 --> Database Driver Class Initialized
INFO - 2016-02-05 12:15:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:15:13 --> Controller Class Initialized
INFO - 2016-02-05 12:15:13 --> Model Class Initialized
INFO - 2016-02-05 12:15:13 --> Model Class Initialized
INFO - 2016-02-05 12:15:13 --> Form Validation Class Initialized
INFO - 2016-02-05 12:15:13 --> Helper loaded: text_helper
INFO - 2016-02-05 12:15:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:15:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:15:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:15:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:15:13 --> Final output sent to browser
DEBUG - 2016-02-05 12:15:13 --> Total execution time: 1.1376
INFO - 2016-02-05 12:23:18 --> Config Class Initialized
INFO - 2016-02-05 12:23:18 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:23:18 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:23:18 --> Utf8 Class Initialized
INFO - 2016-02-05 12:23:18 --> URI Class Initialized
INFO - 2016-02-05 12:23:18 --> Router Class Initialized
INFO - 2016-02-05 12:23:18 --> Output Class Initialized
INFO - 2016-02-05 12:23:18 --> Security Class Initialized
DEBUG - 2016-02-05 12:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:23:18 --> Input Class Initialized
INFO - 2016-02-05 12:23:18 --> Language Class Initialized
INFO - 2016-02-05 12:23:18 --> Loader Class Initialized
INFO - 2016-02-05 12:23:18 --> Helper loaded: url_helper
INFO - 2016-02-05 12:23:18 --> Helper loaded: file_helper
INFO - 2016-02-05 12:23:18 --> Helper loaded: date_helper
INFO - 2016-02-05 12:23:18 --> Helper loaded: form_helper
INFO - 2016-02-05 12:23:18 --> Database Driver Class Initialized
INFO - 2016-02-05 12:23:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:23:19 --> Controller Class Initialized
INFO - 2016-02-05 12:23:19 --> Model Class Initialized
INFO - 2016-02-05 12:23:19 --> Model Class Initialized
INFO - 2016-02-05 12:23:19 --> Form Validation Class Initialized
INFO - 2016-02-05 12:23:19 --> Helper loaded: text_helper
INFO - 2016-02-05 12:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:23:19 --> Final output sent to browser
DEBUG - 2016-02-05 12:23:19 --> Total execution time: 1.1750
INFO - 2016-02-05 12:23:41 --> Config Class Initialized
INFO - 2016-02-05 12:23:41 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:23:41 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:23:41 --> Utf8 Class Initialized
INFO - 2016-02-05 12:23:41 --> URI Class Initialized
INFO - 2016-02-05 12:23:41 --> Router Class Initialized
INFO - 2016-02-05 12:23:41 --> Output Class Initialized
INFO - 2016-02-05 12:23:41 --> Security Class Initialized
DEBUG - 2016-02-05 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:23:41 --> Input Class Initialized
INFO - 2016-02-05 12:23:41 --> Language Class Initialized
INFO - 2016-02-05 12:23:41 --> Loader Class Initialized
INFO - 2016-02-05 12:23:41 --> Helper loaded: url_helper
INFO - 2016-02-05 12:23:41 --> Helper loaded: file_helper
INFO - 2016-02-05 12:23:41 --> Helper loaded: date_helper
INFO - 2016-02-05 12:23:41 --> Helper loaded: form_helper
INFO - 2016-02-05 12:23:41 --> Database Driver Class Initialized
INFO - 2016-02-05 12:23:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:23:43 --> Controller Class Initialized
INFO - 2016-02-05 12:23:43 --> Model Class Initialized
INFO - 2016-02-05 12:23:43 --> Model Class Initialized
INFO - 2016-02-05 12:23:43 --> Form Validation Class Initialized
INFO - 2016-02-05 12:23:43 --> Helper loaded: text_helper
INFO - 2016-02-05 12:23:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:23:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:23:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:23:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:23:43 --> Final output sent to browser
DEBUG - 2016-02-05 12:23:43 --> Total execution time: 1.1515
INFO - 2016-02-05 12:23:45 --> Config Class Initialized
INFO - 2016-02-05 12:23:45 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:23:45 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:23:45 --> Utf8 Class Initialized
INFO - 2016-02-05 12:23:45 --> URI Class Initialized
INFO - 2016-02-05 12:23:45 --> Router Class Initialized
INFO - 2016-02-05 12:23:45 --> Output Class Initialized
INFO - 2016-02-05 12:23:45 --> Security Class Initialized
DEBUG - 2016-02-05 12:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:23:45 --> Input Class Initialized
INFO - 2016-02-05 12:23:45 --> Language Class Initialized
INFO - 2016-02-05 12:23:45 --> Loader Class Initialized
INFO - 2016-02-05 12:23:45 --> Helper loaded: url_helper
INFO - 2016-02-05 12:23:45 --> Helper loaded: file_helper
INFO - 2016-02-05 12:23:45 --> Helper loaded: date_helper
INFO - 2016-02-05 12:23:45 --> Helper loaded: form_helper
INFO - 2016-02-05 12:23:45 --> Database Driver Class Initialized
INFO - 2016-02-05 12:23:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:23:46 --> Controller Class Initialized
INFO - 2016-02-05 12:23:46 --> Model Class Initialized
INFO - 2016-02-05 12:23:46 --> Model Class Initialized
INFO - 2016-02-05 12:23:46 --> Form Validation Class Initialized
INFO - 2016-02-05 12:23:46 --> Helper loaded: text_helper
INFO - 2016-02-05 12:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:23:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:23:46 --> Final output sent to browser
DEBUG - 2016-02-05 12:23:46 --> Total execution time: 1.1707
INFO - 2016-02-05 12:27:18 --> Config Class Initialized
INFO - 2016-02-05 12:27:18 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:27:18 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:27:18 --> Utf8 Class Initialized
INFO - 2016-02-05 12:27:18 --> URI Class Initialized
INFO - 2016-02-05 12:27:18 --> Router Class Initialized
INFO - 2016-02-05 12:27:18 --> Output Class Initialized
INFO - 2016-02-05 12:27:18 --> Security Class Initialized
DEBUG - 2016-02-05 12:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:27:18 --> Input Class Initialized
INFO - 2016-02-05 12:27:18 --> Language Class Initialized
INFO - 2016-02-05 12:27:18 --> Loader Class Initialized
INFO - 2016-02-05 12:27:18 --> Helper loaded: url_helper
INFO - 2016-02-05 12:27:18 --> Helper loaded: file_helper
INFO - 2016-02-05 12:27:18 --> Helper loaded: date_helper
INFO - 2016-02-05 12:27:18 --> Helper loaded: form_helper
INFO - 2016-02-05 12:27:18 --> Database Driver Class Initialized
INFO - 2016-02-05 12:27:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:27:19 --> Controller Class Initialized
INFO - 2016-02-05 12:27:19 --> Model Class Initialized
INFO - 2016-02-05 12:27:19 --> Model Class Initialized
INFO - 2016-02-05 12:27:19 --> Form Validation Class Initialized
INFO - 2016-02-05 12:27:19 --> Helper loaded: text_helper
INFO - 2016-02-05 12:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:27:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:27:20 --> Final output sent to browser
DEBUG - 2016-02-05 12:27:20 --> Total execution time: 1.1802
INFO - 2016-02-05 12:28:02 --> Config Class Initialized
INFO - 2016-02-05 12:28:02 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:28:02 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:28:02 --> Utf8 Class Initialized
INFO - 2016-02-05 12:28:02 --> URI Class Initialized
INFO - 2016-02-05 12:28:02 --> Router Class Initialized
INFO - 2016-02-05 12:28:02 --> Output Class Initialized
INFO - 2016-02-05 12:28:02 --> Security Class Initialized
DEBUG - 2016-02-05 12:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:28:02 --> Input Class Initialized
INFO - 2016-02-05 12:28:02 --> Language Class Initialized
INFO - 2016-02-05 12:28:02 --> Loader Class Initialized
INFO - 2016-02-05 12:28:02 --> Helper loaded: url_helper
INFO - 2016-02-05 12:28:02 --> Helper loaded: file_helper
INFO - 2016-02-05 12:28:02 --> Helper loaded: date_helper
INFO - 2016-02-05 12:28:02 --> Helper loaded: form_helper
INFO - 2016-02-05 12:28:02 --> Database Driver Class Initialized
INFO - 2016-02-05 12:28:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:28:04 --> Controller Class Initialized
INFO - 2016-02-05 12:28:04 --> Model Class Initialized
INFO - 2016-02-05 12:28:04 --> Model Class Initialized
INFO - 2016-02-05 12:28:04 --> Form Validation Class Initialized
INFO - 2016-02-05 12:28:04 --> Helper loaded: text_helper
INFO - 2016-02-05 12:28:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:28:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:28:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:28:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:28:04 --> Final output sent to browser
DEBUG - 2016-02-05 12:28:04 --> Total execution time: 1.1654
INFO - 2016-02-05 12:28:07 --> Config Class Initialized
INFO - 2016-02-05 12:28:07 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:28:07 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:28:07 --> Utf8 Class Initialized
INFO - 2016-02-05 12:28:07 --> URI Class Initialized
INFO - 2016-02-05 12:28:07 --> Router Class Initialized
INFO - 2016-02-05 12:28:07 --> Output Class Initialized
INFO - 2016-02-05 12:28:07 --> Security Class Initialized
DEBUG - 2016-02-05 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:28:07 --> Input Class Initialized
INFO - 2016-02-05 12:28:07 --> Language Class Initialized
INFO - 2016-02-05 12:28:07 --> Loader Class Initialized
INFO - 2016-02-05 12:28:07 --> Helper loaded: url_helper
INFO - 2016-02-05 12:28:07 --> Helper loaded: file_helper
INFO - 2016-02-05 12:28:07 --> Helper loaded: date_helper
INFO - 2016-02-05 12:28:07 --> Helper loaded: form_helper
INFO - 2016-02-05 12:28:07 --> Database Driver Class Initialized
INFO - 2016-02-05 12:28:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:28:08 --> Controller Class Initialized
INFO - 2016-02-05 12:28:08 --> Model Class Initialized
INFO - 2016-02-05 12:28:08 --> Model Class Initialized
INFO - 2016-02-05 12:28:08 --> Form Validation Class Initialized
INFO - 2016-02-05 12:28:08 --> Helper loaded: text_helper
INFO - 2016-02-05 12:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:28:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:28:08 --> Final output sent to browser
DEBUG - 2016-02-05 12:28:08 --> Total execution time: 1.1570
INFO - 2016-02-05 12:28:09 --> Config Class Initialized
INFO - 2016-02-05 12:28:09 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:28:09 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:28:09 --> Utf8 Class Initialized
INFO - 2016-02-05 12:28:09 --> URI Class Initialized
INFO - 2016-02-05 12:28:09 --> Router Class Initialized
INFO - 2016-02-05 12:28:09 --> Output Class Initialized
INFO - 2016-02-05 12:28:09 --> Security Class Initialized
DEBUG - 2016-02-05 12:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:28:09 --> Input Class Initialized
INFO - 2016-02-05 12:28:09 --> Language Class Initialized
INFO - 2016-02-05 12:28:09 --> Loader Class Initialized
INFO - 2016-02-05 12:28:09 --> Helper loaded: url_helper
INFO - 2016-02-05 12:28:09 --> Helper loaded: file_helper
INFO - 2016-02-05 12:28:09 --> Helper loaded: date_helper
INFO - 2016-02-05 12:28:09 --> Helper loaded: form_helper
INFO - 2016-02-05 12:28:09 --> Database Driver Class Initialized
INFO - 2016-02-05 12:28:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:28:10 --> Controller Class Initialized
INFO - 2016-02-05 12:28:10 --> Model Class Initialized
INFO - 2016-02-05 12:28:10 --> Model Class Initialized
INFO - 2016-02-05 12:28:10 --> Form Validation Class Initialized
INFO - 2016-02-05 12:28:10 --> Helper loaded: text_helper
INFO - 2016-02-05 12:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:28:10 --> Final output sent to browser
DEBUG - 2016-02-05 12:28:10 --> Total execution time: 1.1413
INFO - 2016-02-05 12:28:13 --> Config Class Initialized
INFO - 2016-02-05 12:28:13 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:28:13 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:28:13 --> Utf8 Class Initialized
INFO - 2016-02-05 12:28:13 --> URI Class Initialized
INFO - 2016-02-05 12:28:13 --> Router Class Initialized
INFO - 2016-02-05 12:28:13 --> Output Class Initialized
INFO - 2016-02-05 12:28:13 --> Security Class Initialized
DEBUG - 2016-02-05 12:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:28:13 --> Input Class Initialized
INFO - 2016-02-05 12:28:13 --> Language Class Initialized
INFO - 2016-02-05 12:28:13 --> Loader Class Initialized
INFO - 2016-02-05 12:28:13 --> Helper loaded: url_helper
INFO - 2016-02-05 12:28:13 --> Helper loaded: file_helper
INFO - 2016-02-05 12:28:13 --> Helper loaded: date_helper
INFO - 2016-02-05 12:28:13 --> Helper loaded: form_helper
INFO - 2016-02-05 12:28:13 --> Database Driver Class Initialized
INFO - 2016-02-05 12:28:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:28:14 --> Controller Class Initialized
INFO - 2016-02-05 12:28:14 --> Model Class Initialized
INFO - 2016-02-05 12:28:14 --> Model Class Initialized
INFO - 2016-02-05 12:28:14 --> Form Validation Class Initialized
INFO - 2016-02-05 12:28:14 --> Helper loaded: text_helper
INFO - 2016-02-05 12:28:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:28:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:28:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:28:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:28:14 --> Final output sent to browser
DEBUG - 2016-02-05 12:28:14 --> Total execution time: 1.1954
INFO - 2016-02-05 12:39:21 --> Config Class Initialized
INFO - 2016-02-05 12:39:21 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:39:21 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:39:21 --> Utf8 Class Initialized
INFO - 2016-02-05 12:39:21 --> URI Class Initialized
INFO - 2016-02-05 12:39:21 --> Router Class Initialized
INFO - 2016-02-05 12:39:22 --> Output Class Initialized
INFO - 2016-02-05 12:39:22 --> Security Class Initialized
DEBUG - 2016-02-05 12:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:39:22 --> Input Class Initialized
INFO - 2016-02-05 12:39:22 --> Language Class Initialized
INFO - 2016-02-05 12:39:22 --> Loader Class Initialized
INFO - 2016-02-05 12:39:22 --> Helper loaded: url_helper
INFO - 2016-02-05 12:39:22 --> Helper loaded: file_helper
INFO - 2016-02-05 12:39:22 --> Helper loaded: date_helper
INFO - 2016-02-05 12:39:22 --> Helper loaded: form_helper
INFO - 2016-02-05 12:39:22 --> Database Driver Class Initialized
INFO - 2016-02-05 12:39:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:39:23 --> Controller Class Initialized
INFO - 2016-02-05 12:39:23 --> Model Class Initialized
INFO - 2016-02-05 12:39:23 --> Model Class Initialized
INFO - 2016-02-05 12:39:23 --> Form Validation Class Initialized
INFO - 2016-02-05 12:39:23 --> Helper loaded: text_helper
INFO - 2016-02-05 12:39:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:39:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:39:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:39:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:39:23 --> Final output sent to browser
DEBUG - 2016-02-05 12:39:23 --> Total execution time: 1.1828
INFO - 2016-02-05 12:39:24 --> Config Class Initialized
INFO - 2016-02-05 12:39:24 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:39:24 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:39:24 --> Utf8 Class Initialized
INFO - 2016-02-05 12:39:24 --> URI Class Initialized
INFO - 2016-02-05 12:39:24 --> Router Class Initialized
INFO - 2016-02-05 12:39:24 --> Output Class Initialized
INFO - 2016-02-05 12:39:24 --> Security Class Initialized
DEBUG - 2016-02-05 12:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:39:24 --> Input Class Initialized
INFO - 2016-02-05 12:39:24 --> Language Class Initialized
INFO - 2016-02-05 12:39:24 --> Loader Class Initialized
INFO - 2016-02-05 12:39:24 --> Helper loaded: url_helper
INFO - 2016-02-05 12:39:24 --> Helper loaded: file_helper
INFO - 2016-02-05 12:39:24 --> Helper loaded: date_helper
INFO - 2016-02-05 12:39:24 --> Helper loaded: form_helper
INFO - 2016-02-05 12:39:24 --> Database Driver Class Initialized
INFO - 2016-02-05 12:39:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:39:25 --> Controller Class Initialized
INFO - 2016-02-05 12:39:25 --> Model Class Initialized
INFO - 2016-02-05 12:39:25 --> Model Class Initialized
INFO - 2016-02-05 12:39:25 --> Form Validation Class Initialized
INFO - 2016-02-05 12:39:25 --> Helper loaded: text_helper
INFO - 2016-02-05 12:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:39:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:39:25 --> Final output sent to browser
DEBUG - 2016-02-05 12:39:25 --> Total execution time: 1.1630
INFO - 2016-02-05 12:39:29 --> Config Class Initialized
INFO - 2016-02-05 12:39:29 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:39:29 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:39:29 --> Utf8 Class Initialized
INFO - 2016-02-05 12:39:29 --> URI Class Initialized
INFO - 2016-02-05 12:39:29 --> Router Class Initialized
INFO - 2016-02-05 12:39:29 --> Output Class Initialized
INFO - 2016-02-05 12:39:29 --> Security Class Initialized
DEBUG - 2016-02-05 12:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:39:29 --> Input Class Initialized
INFO - 2016-02-05 12:39:29 --> Language Class Initialized
INFO - 2016-02-05 12:39:29 --> Loader Class Initialized
INFO - 2016-02-05 12:39:29 --> Helper loaded: url_helper
INFO - 2016-02-05 12:39:29 --> Helper loaded: file_helper
INFO - 2016-02-05 12:39:29 --> Helper loaded: date_helper
INFO - 2016-02-05 12:39:29 --> Helper loaded: form_helper
INFO - 2016-02-05 12:39:29 --> Database Driver Class Initialized
INFO - 2016-02-05 12:39:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:39:30 --> Controller Class Initialized
INFO - 2016-02-05 12:39:30 --> Model Class Initialized
INFO - 2016-02-05 12:39:30 --> Model Class Initialized
INFO - 2016-02-05 12:39:30 --> Form Validation Class Initialized
INFO - 2016-02-05 12:39:30 --> Helper loaded: text_helper
INFO - 2016-02-05 12:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:39:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:39:30 --> Final output sent to browser
DEBUG - 2016-02-05 12:39:30 --> Total execution time: 1.1071
INFO - 2016-02-05 12:41:35 --> Config Class Initialized
INFO - 2016-02-05 12:41:35 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:41:35 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:41:35 --> Utf8 Class Initialized
INFO - 2016-02-05 12:41:35 --> URI Class Initialized
INFO - 2016-02-05 12:41:35 --> Router Class Initialized
INFO - 2016-02-05 12:41:35 --> Output Class Initialized
INFO - 2016-02-05 12:41:35 --> Security Class Initialized
DEBUG - 2016-02-05 12:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:41:35 --> Input Class Initialized
INFO - 2016-02-05 12:41:35 --> Language Class Initialized
INFO - 2016-02-05 12:41:35 --> Loader Class Initialized
INFO - 2016-02-05 12:41:35 --> Helper loaded: url_helper
INFO - 2016-02-05 12:41:35 --> Helper loaded: file_helper
INFO - 2016-02-05 12:41:35 --> Helper loaded: date_helper
INFO - 2016-02-05 12:41:35 --> Helper loaded: form_helper
INFO - 2016-02-05 12:41:35 --> Database Driver Class Initialized
INFO - 2016-02-05 12:41:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:41:36 --> Controller Class Initialized
INFO - 2016-02-05 12:41:36 --> Model Class Initialized
INFO - 2016-02-05 12:41:36 --> Model Class Initialized
INFO - 2016-02-05 12:41:36 --> Form Validation Class Initialized
INFO - 2016-02-05 12:41:36 --> Helper loaded: text_helper
INFO - 2016-02-05 12:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:41:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:41:36 --> Final output sent to browser
DEBUG - 2016-02-05 12:41:36 --> Total execution time: 1.1764
INFO - 2016-02-05 12:41:40 --> Config Class Initialized
INFO - 2016-02-05 12:41:40 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:41:40 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:41:40 --> Utf8 Class Initialized
INFO - 2016-02-05 12:41:40 --> URI Class Initialized
INFO - 2016-02-05 12:41:40 --> Router Class Initialized
INFO - 2016-02-05 12:41:40 --> Output Class Initialized
INFO - 2016-02-05 12:41:40 --> Security Class Initialized
DEBUG - 2016-02-05 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:41:40 --> Input Class Initialized
INFO - 2016-02-05 12:41:40 --> Language Class Initialized
INFO - 2016-02-05 12:41:40 --> Loader Class Initialized
INFO - 2016-02-05 12:41:40 --> Helper loaded: url_helper
INFO - 2016-02-05 12:41:40 --> Helper loaded: file_helper
INFO - 2016-02-05 12:41:40 --> Helper loaded: date_helper
INFO - 2016-02-05 12:41:40 --> Helper loaded: form_helper
INFO - 2016-02-05 12:41:40 --> Database Driver Class Initialized
INFO - 2016-02-05 12:41:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:41:41 --> Controller Class Initialized
INFO - 2016-02-05 12:41:41 --> Model Class Initialized
INFO - 2016-02-05 12:41:41 --> Model Class Initialized
INFO - 2016-02-05 12:41:41 --> Form Validation Class Initialized
INFO - 2016-02-05 12:41:41 --> Helper loaded: text_helper
INFO - 2016-02-05 12:41:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:41:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:41:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:41:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:41:41 --> Final output sent to browser
DEBUG - 2016-02-05 12:41:41 --> Total execution time: 1.1626
INFO - 2016-02-05 12:43:06 --> Config Class Initialized
INFO - 2016-02-05 12:43:06 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:43:06 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:43:06 --> Utf8 Class Initialized
INFO - 2016-02-05 12:43:06 --> URI Class Initialized
INFO - 2016-02-05 12:43:06 --> Router Class Initialized
INFO - 2016-02-05 12:43:06 --> Output Class Initialized
INFO - 2016-02-05 12:43:06 --> Security Class Initialized
DEBUG - 2016-02-05 12:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:43:06 --> Input Class Initialized
INFO - 2016-02-05 12:43:06 --> Language Class Initialized
INFO - 2016-02-05 12:43:06 --> Loader Class Initialized
INFO - 2016-02-05 12:43:06 --> Helper loaded: url_helper
INFO - 2016-02-05 12:43:06 --> Helper loaded: file_helper
INFO - 2016-02-05 12:43:06 --> Helper loaded: date_helper
INFO - 2016-02-05 12:43:06 --> Helper loaded: form_helper
INFO - 2016-02-05 12:43:06 --> Database Driver Class Initialized
INFO - 2016-02-05 12:43:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:43:07 --> Controller Class Initialized
INFO - 2016-02-05 12:43:07 --> Model Class Initialized
INFO - 2016-02-05 12:43:07 --> Model Class Initialized
INFO - 2016-02-05 12:43:07 --> Form Validation Class Initialized
INFO - 2016-02-05 12:43:07 --> Helper loaded: text_helper
INFO - 2016-02-05 12:43:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:43:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:43:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:43:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:43:07 --> Final output sent to browser
DEBUG - 2016-02-05 12:43:07 --> Total execution time: 1.1493
INFO - 2016-02-05 12:43:12 --> Config Class Initialized
INFO - 2016-02-05 12:43:12 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:43:12 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:43:12 --> Utf8 Class Initialized
INFO - 2016-02-05 12:43:12 --> URI Class Initialized
INFO - 2016-02-05 12:43:12 --> Router Class Initialized
INFO - 2016-02-05 12:43:12 --> Output Class Initialized
INFO - 2016-02-05 12:43:12 --> Security Class Initialized
DEBUG - 2016-02-05 12:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:43:12 --> Input Class Initialized
INFO - 2016-02-05 12:43:12 --> Language Class Initialized
INFO - 2016-02-05 12:43:12 --> Loader Class Initialized
INFO - 2016-02-05 12:43:12 --> Helper loaded: url_helper
INFO - 2016-02-05 12:43:12 --> Helper loaded: file_helper
INFO - 2016-02-05 12:43:12 --> Helper loaded: date_helper
INFO - 2016-02-05 12:43:12 --> Helper loaded: form_helper
INFO - 2016-02-05 12:43:12 --> Database Driver Class Initialized
INFO - 2016-02-05 12:43:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:43:14 --> Controller Class Initialized
INFO - 2016-02-05 12:43:14 --> Model Class Initialized
INFO - 2016-02-05 12:43:14 --> Model Class Initialized
INFO - 2016-02-05 12:43:14 --> Form Validation Class Initialized
INFO - 2016-02-05 12:43:14 --> Helper loaded: text_helper
INFO - 2016-02-05 12:43:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:43:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:43:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:43:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:43:14 --> Final output sent to browser
DEBUG - 2016-02-05 12:43:14 --> Total execution time: 1.1333
INFO - 2016-02-05 12:43:45 --> Config Class Initialized
INFO - 2016-02-05 12:43:45 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:43:45 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:43:45 --> Utf8 Class Initialized
INFO - 2016-02-05 12:43:45 --> URI Class Initialized
INFO - 2016-02-05 12:43:45 --> Router Class Initialized
INFO - 2016-02-05 12:43:45 --> Output Class Initialized
INFO - 2016-02-05 12:43:45 --> Security Class Initialized
DEBUG - 2016-02-05 12:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:43:45 --> Input Class Initialized
INFO - 2016-02-05 12:43:45 --> Language Class Initialized
INFO - 2016-02-05 12:43:45 --> Loader Class Initialized
INFO - 2016-02-05 12:43:45 --> Helper loaded: url_helper
INFO - 2016-02-05 12:43:45 --> Helper loaded: file_helper
INFO - 2016-02-05 12:43:45 --> Helper loaded: date_helper
INFO - 2016-02-05 12:43:45 --> Helper loaded: form_helper
INFO - 2016-02-05 12:43:45 --> Database Driver Class Initialized
INFO - 2016-02-05 12:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:43:46 --> Controller Class Initialized
INFO - 2016-02-05 12:43:46 --> Model Class Initialized
INFO - 2016-02-05 12:43:46 --> Model Class Initialized
INFO - 2016-02-05 12:43:46 --> Form Validation Class Initialized
INFO - 2016-02-05 12:43:46 --> Helper loaded: text_helper
INFO - 2016-02-05 12:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:43:46 --> Final output sent to browser
DEBUG - 2016-02-05 12:43:46 --> Total execution time: 1.1572
INFO - 2016-02-05 12:44:36 --> Config Class Initialized
INFO - 2016-02-05 12:44:36 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:44:36 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:44:36 --> Utf8 Class Initialized
INFO - 2016-02-05 12:44:36 --> URI Class Initialized
INFO - 2016-02-05 12:44:36 --> Router Class Initialized
INFO - 2016-02-05 12:44:36 --> Output Class Initialized
INFO - 2016-02-05 12:44:36 --> Security Class Initialized
DEBUG - 2016-02-05 12:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:44:36 --> Input Class Initialized
INFO - 2016-02-05 12:44:36 --> Language Class Initialized
INFO - 2016-02-05 12:44:36 --> Loader Class Initialized
INFO - 2016-02-05 12:44:36 --> Helper loaded: url_helper
INFO - 2016-02-05 12:44:36 --> Helper loaded: file_helper
INFO - 2016-02-05 12:44:36 --> Helper loaded: date_helper
INFO - 2016-02-05 12:44:36 --> Helper loaded: form_helper
INFO - 2016-02-05 12:44:36 --> Database Driver Class Initialized
INFO - 2016-02-05 12:44:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:44:37 --> Controller Class Initialized
INFO - 2016-02-05 12:44:37 --> Model Class Initialized
INFO - 2016-02-05 12:44:37 --> Model Class Initialized
INFO - 2016-02-05 12:44:37 --> Form Validation Class Initialized
INFO - 2016-02-05 12:44:37 --> Helper loaded: text_helper
INFO - 2016-02-05 12:44:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:44:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:44:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:44:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:44:37 --> Final output sent to browser
DEBUG - 2016-02-05 12:44:37 --> Total execution time: 1.1643
INFO - 2016-02-05 12:44:42 --> Config Class Initialized
INFO - 2016-02-05 12:44:42 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:44:42 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:44:42 --> Utf8 Class Initialized
INFO - 2016-02-05 12:44:42 --> URI Class Initialized
INFO - 2016-02-05 12:44:42 --> Router Class Initialized
INFO - 2016-02-05 12:44:42 --> Output Class Initialized
INFO - 2016-02-05 12:44:42 --> Security Class Initialized
DEBUG - 2016-02-05 12:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:44:42 --> Input Class Initialized
INFO - 2016-02-05 12:44:42 --> Language Class Initialized
INFO - 2016-02-05 12:44:42 --> Loader Class Initialized
INFO - 2016-02-05 12:44:42 --> Helper loaded: url_helper
INFO - 2016-02-05 12:44:42 --> Helper loaded: file_helper
INFO - 2016-02-05 12:44:42 --> Helper loaded: date_helper
INFO - 2016-02-05 12:44:42 --> Helper loaded: form_helper
INFO - 2016-02-05 12:44:42 --> Database Driver Class Initialized
INFO - 2016-02-05 12:44:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:44:43 --> Controller Class Initialized
INFO - 2016-02-05 12:44:43 --> Model Class Initialized
INFO - 2016-02-05 12:44:43 --> Model Class Initialized
INFO - 2016-02-05 12:44:43 --> Form Validation Class Initialized
INFO - 2016-02-05 12:44:43 --> Helper loaded: text_helper
INFO - 2016-02-05 12:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:44:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:44:43 --> Final output sent to browser
DEBUG - 2016-02-05 12:44:43 --> Total execution time: 1.1584
INFO - 2016-02-05 12:54:14 --> Config Class Initialized
INFO - 2016-02-05 12:54:14 --> Hooks Class Initialized
DEBUG - 2016-02-05 12:54:14 --> UTF-8 Support Enabled
INFO - 2016-02-05 12:54:14 --> Utf8 Class Initialized
INFO - 2016-02-05 12:54:14 --> URI Class Initialized
INFO - 2016-02-05 12:54:14 --> Router Class Initialized
INFO - 2016-02-05 12:54:14 --> Output Class Initialized
INFO - 2016-02-05 12:54:14 --> Security Class Initialized
DEBUG - 2016-02-05 12:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 12:54:14 --> Input Class Initialized
INFO - 2016-02-05 12:54:14 --> Language Class Initialized
INFO - 2016-02-05 12:54:14 --> Loader Class Initialized
INFO - 2016-02-05 12:54:14 --> Helper loaded: url_helper
INFO - 2016-02-05 12:54:14 --> Helper loaded: file_helper
INFO - 2016-02-05 12:54:14 --> Helper loaded: date_helper
INFO - 2016-02-05 12:54:14 --> Helper loaded: form_helper
INFO - 2016-02-05 12:54:14 --> Database Driver Class Initialized
INFO - 2016-02-05 12:54:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 12:54:15 --> Controller Class Initialized
INFO - 2016-02-05 12:54:15 --> Model Class Initialized
INFO - 2016-02-05 12:54:15 --> Model Class Initialized
INFO - 2016-02-05 12:54:15 --> Form Validation Class Initialized
INFO - 2016-02-05 12:54:15 --> Helper loaded: text_helper
INFO - 2016-02-05 12:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 12:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 12:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 12:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 12:54:15 --> Final output sent to browser
DEBUG - 2016-02-05 12:54:15 --> Total execution time: 1.1334
INFO - 2016-02-05 13:03:09 --> Config Class Initialized
INFO - 2016-02-05 13:03:09 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:09 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:09 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:09 --> URI Class Initialized
DEBUG - 2016-02-05 13:03:09 --> No URI present. Default controller set.
INFO - 2016-02-05 13:03:09 --> Router Class Initialized
INFO - 2016-02-05 13:03:09 --> Output Class Initialized
INFO - 2016-02-05 13:03:09 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:09 --> Input Class Initialized
INFO - 2016-02-05 13:03:09 --> Language Class Initialized
INFO - 2016-02-05 13:03:09 --> Loader Class Initialized
INFO - 2016-02-05 13:03:09 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:09 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:09 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:09 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:09 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:10 --> Controller Class Initialized
INFO - 2016-02-05 13:03:10 --> Model Class Initialized
INFO - 2016-02-05 13:03:10 --> Model Class Initialized
INFO - 2016-02-05 13:03:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:03:10 --> Pagination Class Initialized
INFO - 2016-02-05 13:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:03:10 --> Final output sent to browser
DEBUG - 2016-02-05 13:03:10 --> Total execution time: 1.1384
INFO - 2016-02-05 13:03:13 --> Config Class Initialized
INFO - 2016-02-05 13:03:13 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:13 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:13 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:13 --> URI Class Initialized
INFO - 2016-02-05 13:03:13 --> Router Class Initialized
INFO - 2016-02-05 13:03:13 --> Output Class Initialized
INFO - 2016-02-05 13:03:13 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:13 --> Input Class Initialized
INFO - 2016-02-05 13:03:13 --> Language Class Initialized
INFO - 2016-02-05 13:03:13 --> Loader Class Initialized
INFO - 2016-02-05 13:03:13 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:13 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:13 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:13 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:13 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:14 --> Controller Class Initialized
INFO - 2016-02-05 13:03:14 --> Model Class Initialized
INFO - 2016-02-05 13:03:14 --> Model Class Initialized
INFO - 2016-02-05 13:03:14 --> Form Validation Class Initialized
INFO - 2016-02-05 13:03:14 --> Helper loaded: text_helper
INFO - 2016-02-05 13:03:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:03:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:03:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 13:03:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:03:14 --> Final output sent to browser
DEBUG - 2016-02-05 13:03:14 --> Total execution time: 1.1506
INFO - 2016-02-05 13:03:31 --> Config Class Initialized
INFO - 2016-02-05 13:03:31 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:31 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:31 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:31 --> URI Class Initialized
INFO - 2016-02-05 13:03:31 --> Router Class Initialized
INFO - 2016-02-05 13:03:31 --> Output Class Initialized
INFO - 2016-02-05 13:03:31 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:31 --> Input Class Initialized
INFO - 2016-02-05 13:03:31 --> Language Class Initialized
INFO - 2016-02-05 13:03:31 --> Loader Class Initialized
INFO - 2016-02-05 13:03:31 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:31 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:31 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:31 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:31 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:32 --> Controller Class Initialized
INFO - 2016-02-05 13:03:32 --> Model Class Initialized
INFO - 2016-02-05 13:03:32 --> Model Class Initialized
INFO - 2016-02-05 13:03:32 --> Form Validation Class Initialized
INFO - 2016-02-05 13:03:32 --> Helper loaded: text_helper
INFO - 2016-02-05 13:03:32 --> Config Class Initialized
INFO - 2016-02-05 13:03:32 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:32 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:32 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:32 --> URI Class Initialized
INFO - 2016-02-05 13:03:32 --> Router Class Initialized
INFO - 2016-02-05 13:03:32 --> Output Class Initialized
INFO - 2016-02-05 13:03:32 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:32 --> Input Class Initialized
INFO - 2016-02-05 13:03:32 --> Language Class Initialized
INFO - 2016-02-05 13:03:32 --> Loader Class Initialized
INFO - 2016-02-05 13:03:32 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:32 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:32 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:32 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:32 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:33 --> Controller Class Initialized
INFO - 2016-02-05 13:03:33 --> Model Class Initialized
INFO - 2016-02-05 13:03:33 --> Model Class Initialized
INFO - 2016-02-05 13:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:03:33 --> Pagination Class Initialized
INFO - 2016-02-05 13:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:03:33 --> Final output sent to browser
DEBUG - 2016-02-05 13:03:33 --> Total execution time: 1.1782
INFO - 2016-02-05 13:03:36 --> Config Class Initialized
INFO - 2016-02-05 13:03:36 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:36 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:36 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:36 --> URI Class Initialized
INFO - 2016-02-05 13:03:36 --> Router Class Initialized
INFO - 2016-02-05 13:03:36 --> Output Class Initialized
INFO - 2016-02-05 13:03:36 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:36 --> Input Class Initialized
INFO - 2016-02-05 13:03:36 --> Language Class Initialized
INFO - 2016-02-05 13:03:36 --> Loader Class Initialized
INFO - 2016-02-05 13:03:36 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:36 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:36 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:36 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:36 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:37 --> Controller Class Initialized
INFO - 2016-02-05 13:03:37 --> Model Class Initialized
INFO - 2016-02-05 13:03:37 --> Model Class Initialized
INFO - 2016-02-05 13:03:37 --> Form Validation Class Initialized
INFO - 2016-02-05 13:03:37 --> Helper loaded: text_helper
INFO - 2016-02-05 13:03:37 --> Config Class Initialized
INFO - 2016-02-05 13:03:37 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:37 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:37 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:37 --> URI Class Initialized
INFO - 2016-02-05 13:03:37 --> Router Class Initialized
INFO - 2016-02-05 13:03:37 --> Output Class Initialized
INFO - 2016-02-05 13:03:37 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:37 --> Input Class Initialized
INFO - 2016-02-05 13:03:37 --> Language Class Initialized
INFO - 2016-02-05 13:03:37 --> Loader Class Initialized
INFO - 2016-02-05 13:03:37 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:37 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:37 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:37 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:37 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:38 --> Controller Class Initialized
INFO - 2016-02-05 13:03:38 --> Model Class Initialized
INFO - 2016-02-05 13:03:38 --> Model Class Initialized
INFO - 2016-02-05 13:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:03:38 --> Pagination Class Initialized
INFO - 2016-02-05 13:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:03:38 --> Final output sent to browser
DEBUG - 2016-02-05 13:03:38 --> Total execution time: 1.1391
INFO - 2016-02-05 13:03:53 --> Config Class Initialized
INFO - 2016-02-05 13:03:53 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:53 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:53 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:53 --> URI Class Initialized
INFO - 2016-02-05 13:03:53 --> Router Class Initialized
INFO - 2016-02-05 13:03:53 --> Output Class Initialized
INFO - 2016-02-05 13:03:53 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:53 --> Input Class Initialized
INFO - 2016-02-05 13:03:53 --> Language Class Initialized
INFO - 2016-02-05 13:03:53 --> Loader Class Initialized
INFO - 2016-02-05 13:03:53 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:53 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:53 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:53 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:53 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:54 --> Controller Class Initialized
INFO - 2016-02-05 13:03:54 --> Model Class Initialized
INFO - 2016-02-05 13:03:54 --> Model Class Initialized
INFO - 2016-02-05 13:03:54 --> Form Validation Class Initialized
INFO - 2016-02-05 13:03:54 --> Helper loaded: text_helper
INFO - 2016-02-05 13:03:54 --> Config Class Initialized
INFO - 2016-02-05 13:03:54 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:54 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:54 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:54 --> URI Class Initialized
INFO - 2016-02-05 13:03:54 --> Router Class Initialized
INFO - 2016-02-05 13:03:55 --> Output Class Initialized
INFO - 2016-02-05 13:03:55 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:55 --> Input Class Initialized
INFO - 2016-02-05 13:03:55 --> Language Class Initialized
INFO - 2016-02-05 13:03:55 --> Loader Class Initialized
INFO - 2016-02-05 13:03:55 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:55 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:55 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:55 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:55 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:55 --> Config Class Initialized
INFO - 2016-02-05 13:03:55 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:55 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:55 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:55 --> URI Class Initialized
INFO - 2016-02-05 13:03:55 --> Router Class Initialized
INFO - 2016-02-05 13:03:55 --> Output Class Initialized
INFO - 2016-02-05 13:03:55 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:55 --> Input Class Initialized
INFO - 2016-02-05 13:03:55 --> Language Class Initialized
INFO - 2016-02-05 13:03:55 --> Loader Class Initialized
INFO - 2016-02-05 13:03:55 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:55 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:55 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:55 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:55 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:56 --> Controller Class Initialized
INFO - 2016-02-05 13:03:56 --> Model Class Initialized
INFO - 2016-02-05 13:03:56 --> Model Class Initialized
INFO - 2016-02-05 13:03:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:03:56 --> Pagination Class Initialized
INFO - 2016-02-05 13:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:03:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:03:56 --> Final output sent to browser
DEBUG - 2016-02-05 13:03:56 --> Total execution time: 1.1896
INFO - 2016-02-05 13:03:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:56 --> Controller Class Initialized
INFO - 2016-02-05 13:03:56 --> Model Class Initialized
INFO - 2016-02-05 13:03:56 --> Model Class Initialized
INFO - 2016-02-05 13:03:56 --> Form Validation Class Initialized
INFO - 2016-02-05 13:03:56 --> Helper loaded: text_helper
INFO - 2016-02-05 13:03:56 --> Config Class Initialized
INFO - 2016-02-05 13:03:56 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:56 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:56 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:56 --> URI Class Initialized
INFO - 2016-02-05 13:03:56 --> Router Class Initialized
INFO - 2016-02-05 13:03:56 --> Output Class Initialized
INFO - 2016-02-05 13:03:56 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:56 --> Input Class Initialized
INFO - 2016-02-05 13:03:56 --> Language Class Initialized
INFO - 2016-02-05 13:03:56 --> Loader Class Initialized
INFO - 2016-02-05 13:03:56 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:56 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:56 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:56 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:56 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:57 --> Config Class Initialized
INFO - 2016-02-05 13:03:57 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:57 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:57 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:57 --> URI Class Initialized
INFO - 2016-02-05 13:03:57 --> Router Class Initialized
INFO - 2016-02-05 13:03:57 --> Output Class Initialized
INFO - 2016-02-05 13:03:57 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:57 --> Input Class Initialized
INFO - 2016-02-05 13:03:57 --> Language Class Initialized
INFO - 2016-02-05 13:03:57 --> Loader Class Initialized
INFO - 2016-02-05 13:03:57 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:57 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:57 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:57 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:57 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:57 --> Controller Class Initialized
INFO - 2016-02-05 13:03:57 --> Model Class Initialized
INFO - 2016-02-05 13:03:57 --> Model Class Initialized
INFO - 2016-02-05 13:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:03:57 --> Pagination Class Initialized
INFO - 2016-02-05 13:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:03:57 --> Final output sent to browser
DEBUG - 2016-02-05 13:03:57 --> Total execution time: 1.1173
INFO - 2016-02-05 13:03:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:58 --> Controller Class Initialized
INFO - 2016-02-05 13:03:58 --> Model Class Initialized
INFO - 2016-02-05 13:03:58 --> Model Class Initialized
INFO - 2016-02-05 13:03:58 --> Form Validation Class Initialized
INFO - 2016-02-05 13:03:58 --> Helper loaded: text_helper
INFO - 2016-02-05 13:03:58 --> Config Class Initialized
INFO - 2016-02-05 13:03:58 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:03:58 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:03:58 --> Utf8 Class Initialized
INFO - 2016-02-05 13:03:58 --> URI Class Initialized
INFO - 2016-02-05 13:03:58 --> Router Class Initialized
INFO - 2016-02-05 13:03:58 --> Output Class Initialized
INFO - 2016-02-05 13:03:58 --> Security Class Initialized
DEBUG - 2016-02-05 13:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:03:58 --> Input Class Initialized
INFO - 2016-02-05 13:03:58 --> Language Class Initialized
INFO - 2016-02-05 13:03:58 --> Loader Class Initialized
INFO - 2016-02-05 13:03:58 --> Helper loaded: url_helper
INFO - 2016-02-05 13:03:58 --> Helper loaded: file_helper
INFO - 2016-02-05 13:03:58 --> Helper loaded: date_helper
INFO - 2016-02-05 13:03:58 --> Helper loaded: form_helper
INFO - 2016-02-05 13:03:58 --> Database Driver Class Initialized
INFO - 2016-02-05 13:03:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:03:59 --> Controller Class Initialized
INFO - 2016-02-05 13:03:59 --> Model Class Initialized
INFO - 2016-02-05 13:03:59 --> Model Class Initialized
INFO - 2016-02-05 13:03:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:03:59 --> Pagination Class Initialized
INFO - 2016-02-05 13:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:03:59 --> Final output sent to browser
DEBUG - 2016-02-05 13:03:59 --> Total execution time: 1.1525
INFO - 2016-02-05 13:04:49 --> Config Class Initialized
INFO - 2016-02-05 13:04:49 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:04:49 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:04:49 --> Utf8 Class Initialized
INFO - 2016-02-05 13:04:49 --> URI Class Initialized
DEBUG - 2016-02-05 13:04:49 --> No URI present. Default controller set.
INFO - 2016-02-05 13:04:49 --> Router Class Initialized
INFO - 2016-02-05 13:04:49 --> Output Class Initialized
INFO - 2016-02-05 13:04:49 --> Security Class Initialized
DEBUG - 2016-02-05 13:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:04:49 --> Input Class Initialized
INFO - 2016-02-05 13:04:49 --> Language Class Initialized
INFO - 2016-02-05 13:04:49 --> Loader Class Initialized
INFO - 2016-02-05 13:04:49 --> Helper loaded: url_helper
INFO - 2016-02-05 13:04:49 --> Helper loaded: file_helper
INFO - 2016-02-05 13:04:49 --> Helper loaded: date_helper
INFO - 2016-02-05 13:04:49 --> Helper loaded: form_helper
INFO - 2016-02-05 13:04:49 --> Database Driver Class Initialized
INFO - 2016-02-05 13:04:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:04:50 --> Controller Class Initialized
INFO - 2016-02-05 13:04:50 --> Model Class Initialized
INFO - 2016-02-05 13:04:50 --> Model Class Initialized
INFO - 2016-02-05 13:04:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:04:50 --> Pagination Class Initialized
INFO - 2016-02-05 13:04:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:04:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:04:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:04:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:04:50 --> Final output sent to browser
DEBUG - 2016-02-05 13:04:50 --> Total execution time: 1.1629
INFO - 2016-02-05 13:05:03 --> Config Class Initialized
INFO - 2016-02-05 13:05:03 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:05:03 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:05:03 --> Utf8 Class Initialized
INFO - 2016-02-05 13:05:03 --> URI Class Initialized
INFO - 2016-02-05 13:05:03 --> Router Class Initialized
INFO - 2016-02-05 13:05:03 --> Output Class Initialized
INFO - 2016-02-05 13:05:03 --> Security Class Initialized
DEBUG - 2016-02-05 13:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:05:03 --> Input Class Initialized
INFO - 2016-02-05 13:05:03 --> Language Class Initialized
INFO - 2016-02-05 13:05:03 --> Loader Class Initialized
INFO - 2016-02-05 13:05:03 --> Helper loaded: url_helper
INFO - 2016-02-05 13:05:03 --> Helper loaded: file_helper
INFO - 2016-02-05 13:05:03 --> Helper loaded: date_helper
INFO - 2016-02-05 13:05:03 --> Helper loaded: form_helper
INFO - 2016-02-05 13:05:03 --> Database Driver Class Initialized
INFO - 2016-02-05 13:05:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:05:04 --> Controller Class Initialized
INFO - 2016-02-05 13:05:04 --> Model Class Initialized
INFO - 2016-02-05 13:05:04 --> Model Class Initialized
INFO - 2016-02-05 13:05:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:05:04 --> Pagination Class Initialized
INFO - 2016-02-05 13:05:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:05:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:05:04 --> Helper loaded: text_helper
INFO - 2016-02-05 13:05:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 13:05:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 13:05:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:05:04 --> Final output sent to browser
DEBUG - 2016-02-05 13:05:04 --> Total execution time: 1.1988
INFO - 2016-02-05 13:05:41 --> Config Class Initialized
INFO - 2016-02-05 13:05:41 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:05:41 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:05:41 --> Utf8 Class Initialized
INFO - 2016-02-05 13:05:41 --> URI Class Initialized
INFO - 2016-02-05 13:05:41 --> Router Class Initialized
INFO - 2016-02-05 13:05:41 --> Output Class Initialized
INFO - 2016-02-05 13:05:41 --> Security Class Initialized
DEBUG - 2016-02-05 13:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:05:41 --> Input Class Initialized
INFO - 2016-02-05 13:05:41 --> Language Class Initialized
INFO - 2016-02-05 13:05:41 --> Loader Class Initialized
INFO - 2016-02-05 13:05:41 --> Helper loaded: url_helper
INFO - 2016-02-05 13:05:41 --> Helper loaded: file_helper
INFO - 2016-02-05 13:05:41 --> Helper loaded: date_helper
INFO - 2016-02-05 13:05:41 --> Helper loaded: form_helper
INFO - 2016-02-05 13:05:41 --> Database Driver Class Initialized
INFO - 2016-02-05 13:05:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:05:42 --> Controller Class Initialized
INFO - 2016-02-05 13:05:42 --> Model Class Initialized
INFO - 2016-02-05 13:05:42 --> Model Class Initialized
INFO - 2016-02-05 13:05:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:05:42 --> Pagination Class Initialized
INFO - 2016-02-05 13:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:05:42 --> Helper loaded: text_helper
INFO - 2016-02-05 13:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 13:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 13:05:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:05:42 --> Final output sent to browser
DEBUG - 2016-02-05 13:05:42 --> Total execution time: 1.2387
INFO - 2016-02-05 13:05:55 --> Config Class Initialized
INFO - 2016-02-05 13:05:55 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:05:55 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:05:55 --> Utf8 Class Initialized
INFO - 2016-02-05 13:05:55 --> URI Class Initialized
INFO - 2016-02-05 13:05:55 --> Router Class Initialized
INFO - 2016-02-05 13:05:55 --> Output Class Initialized
INFO - 2016-02-05 13:05:55 --> Security Class Initialized
DEBUG - 2016-02-05 13:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:05:55 --> Input Class Initialized
INFO - 2016-02-05 13:05:55 --> Language Class Initialized
INFO - 2016-02-05 13:05:55 --> Loader Class Initialized
INFO - 2016-02-05 13:05:55 --> Helper loaded: url_helper
INFO - 2016-02-05 13:05:55 --> Helper loaded: file_helper
INFO - 2016-02-05 13:05:55 --> Helper loaded: date_helper
INFO - 2016-02-05 13:05:55 --> Helper loaded: form_helper
INFO - 2016-02-05 13:05:55 --> Database Driver Class Initialized
INFO - 2016-02-05 13:05:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:05:56 --> Controller Class Initialized
INFO - 2016-02-05 13:05:56 --> Model Class Initialized
INFO - 2016-02-05 13:05:56 --> Model Class Initialized
INFO - 2016-02-05 13:05:56 --> Form Validation Class Initialized
INFO - 2016-02-05 13:05:56 --> Helper loaded: text_helper
INFO - 2016-02-05 13:05:56 --> Config Class Initialized
INFO - 2016-02-05 13:05:56 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:05:56 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:05:56 --> Utf8 Class Initialized
INFO - 2016-02-05 13:05:56 --> URI Class Initialized
INFO - 2016-02-05 13:05:56 --> Router Class Initialized
INFO - 2016-02-05 13:05:56 --> Output Class Initialized
INFO - 2016-02-05 13:05:56 --> Security Class Initialized
DEBUG - 2016-02-05 13:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:05:56 --> Input Class Initialized
INFO - 2016-02-05 13:05:56 --> Language Class Initialized
INFO - 2016-02-05 13:05:56 --> Loader Class Initialized
INFO - 2016-02-05 13:05:56 --> Helper loaded: url_helper
INFO - 2016-02-05 13:05:56 --> Helper loaded: file_helper
INFO - 2016-02-05 13:05:56 --> Helper loaded: date_helper
INFO - 2016-02-05 13:05:56 --> Helper loaded: form_helper
INFO - 2016-02-05 13:05:56 --> Database Driver Class Initialized
INFO - 2016-02-05 13:05:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:05:57 --> Controller Class Initialized
INFO - 2016-02-05 13:05:57 --> Model Class Initialized
INFO - 2016-02-05 13:05:57 --> Model Class Initialized
INFO - 2016-02-05 13:05:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:05:57 --> Pagination Class Initialized
INFO - 2016-02-05 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:05:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:05:57 --> Final output sent to browser
DEBUG - 2016-02-05 13:05:57 --> Total execution time: 1.1452
INFO - 2016-02-05 13:05:59 --> Config Class Initialized
INFO - 2016-02-05 13:05:59 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:05:59 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:05:59 --> Utf8 Class Initialized
INFO - 2016-02-05 13:05:59 --> URI Class Initialized
INFO - 2016-02-05 13:05:59 --> Router Class Initialized
INFO - 2016-02-05 13:05:59 --> Output Class Initialized
INFO - 2016-02-05 13:06:00 --> Security Class Initialized
DEBUG - 2016-02-05 13:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:06:00 --> Input Class Initialized
INFO - 2016-02-05 13:06:00 --> Language Class Initialized
INFO - 2016-02-05 13:06:00 --> Loader Class Initialized
INFO - 2016-02-05 13:06:00 --> Helper loaded: url_helper
INFO - 2016-02-05 13:06:00 --> Helper loaded: file_helper
INFO - 2016-02-05 13:06:00 --> Helper loaded: date_helper
INFO - 2016-02-05 13:06:00 --> Helper loaded: form_helper
INFO - 2016-02-05 13:06:00 --> Database Driver Class Initialized
INFO - 2016-02-05 13:06:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:06:01 --> Controller Class Initialized
INFO - 2016-02-05 13:06:01 --> Model Class Initialized
INFO - 2016-02-05 13:06:01 --> Model Class Initialized
INFO - 2016-02-05 13:06:01 --> Form Validation Class Initialized
INFO - 2016-02-05 13:06:01 --> Helper loaded: text_helper
INFO - 2016-02-05 13:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 13:06:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:06:01 --> Final output sent to browser
DEBUG - 2016-02-05 13:06:01 --> Total execution time: 1.1611
INFO - 2016-02-05 13:06:06 --> Config Class Initialized
INFO - 2016-02-05 13:06:06 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:06:06 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:06:06 --> Utf8 Class Initialized
INFO - 2016-02-05 13:06:06 --> URI Class Initialized
INFO - 2016-02-05 13:06:06 --> Router Class Initialized
INFO - 2016-02-05 13:06:06 --> Output Class Initialized
INFO - 2016-02-05 13:06:06 --> Security Class Initialized
DEBUG - 2016-02-05 13:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:06:06 --> Input Class Initialized
INFO - 2016-02-05 13:06:06 --> Language Class Initialized
INFO - 2016-02-05 13:06:06 --> Loader Class Initialized
INFO - 2016-02-05 13:06:06 --> Helper loaded: url_helper
INFO - 2016-02-05 13:06:06 --> Helper loaded: file_helper
INFO - 2016-02-05 13:06:06 --> Helper loaded: date_helper
INFO - 2016-02-05 13:06:06 --> Helper loaded: form_helper
INFO - 2016-02-05 13:06:06 --> Database Driver Class Initialized
INFO - 2016-02-05 13:06:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:06:07 --> Controller Class Initialized
INFO - 2016-02-05 13:06:07 --> Model Class Initialized
INFO - 2016-02-05 13:06:07 --> Model Class Initialized
INFO - 2016-02-05 13:06:07 --> Form Validation Class Initialized
INFO - 2016-02-05 13:06:07 --> Helper loaded: text_helper
INFO - 2016-02-05 13:06:07 --> Config Class Initialized
INFO - 2016-02-05 13:06:07 --> Hooks Class Initialized
DEBUG - 2016-02-05 13:06:07 --> UTF-8 Support Enabled
INFO - 2016-02-05 13:06:07 --> Utf8 Class Initialized
INFO - 2016-02-05 13:06:07 --> URI Class Initialized
INFO - 2016-02-05 13:06:07 --> Router Class Initialized
INFO - 2016-02-05 13:06:07 --> Output Class Initialized
INFO - 2016-02-05 13:06:07 --> Security Class Initialized
DEBUG - 2016-02-05 13:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 13:06:07 --> Input Class Initialized
INFO - 2016-02-05 13:06:07 --> Language Class Initialized
INFO - 2016-02-05 13:06:07 --> Loader Class Initialized
INFO - 2016-02-05 13:06:07 --> Helper loaded: url_helper
INFO - 2016-02-05 13:06:07 --> Helper loaded: file_helper
INFO - 2016-02-05 13:06:07 --> Helper loaded: date_helper
INFO - 2016-02-05 13:06:07 --> Helper loaded: form_helper
INFO - 2016-02-05 13:06:07 --> Database Driver Class Initialized
INFO - 2016-02-05 13:06:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 13:06:08 --> Controller Class Initialized
INFO - 2016-02-05 13:06:08 --> Model Class Initialized
INFO - 2016-02-05 13:06:08 --> Model Class Initialized
INFO - 2016-02-05 13:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 13:06:08 --> Pagination Class Initialized
INFO - 2016-02-05 13:06:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 13:06:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 13:06:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 13:06:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 13:06:08 --> Final output sent to browser
DEBUG - 2016-02-05 13:06:08 --> Total execution time: 1.1601
INFO - 2016-02-05 14:05:02 --> Config Class Initialized
INFO - 2016-02-05 14:05:02 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:02 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:02 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:02 --> URI Class Initialized
DEBUG - 2016-02-05 14:05:02 --> No URI present. Default controller set.
INFO - 2016-02-05 14:05:02 --> Router Class Initialized
INFO - 2016-02-05 14:05:02 --> Output Class Initialized
INFO - 2016-02-05 14:05:02 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:02 --> Input Class Initialized
INFO - 2016-02-05 14:05:02 --> Language Class Initialized
INFO - 2016-02-05 14:05:02 --> Loader Class Initialized
INFO - 2016-02-05 14:05:02 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:02 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:02 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:02 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:02 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:03 --> Controller Class Initialized
INFO - 2016-02-05 14:05:03 --> Model Class Initialized
INFO - 2016-02-05 14:05:03 --> Model Class Initialized
INFO - 2016-02-05 14:05:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:05:03 --> Pagination Class Initialized
INFO - 2016-02-05 14:05:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:05:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:05:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 14:05:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:05:04 --> Final output sent to browser
DEBUG - 2016-02-05 14:05:04 --> Total execution time: 1.1331
INFO - 2016-02-05 14:05:05 --> Config Class Initialized
INFO - 2016-02-05 14:05:05 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:05 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:05 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:05 --> URI Class Initialized
INFO - 2016-02-05 14:05:05 --> Router Class Initialized
INFO - 2016-02-05 14:05:05 --> Output Class Initialized
INFO - 2016-02-05 14:05:05 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:05 --> Input Class Initialized
INFO - 2016-02-05 14:05:05 --> Language Class Initialized
INFO - 2016-02-05 14:05:05 --> Loader Class Initialized
INFO - 2016-02-05 14:05:05 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:05 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:05 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:05 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:05 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:06 --> Controller Class Initialized
INFO - 2016-02-05 14:05:06 --> Model Class Initialized
INFO - 2016-02-05 14:05:06 --> Model Class Initialized
INFO - 2016-02-05 14:05:06 --> Form Validation Class Initialized
INFO - 2016-02-05 14:05:06 --> Helper loaded: text_helper
INFO - 2016-02-05 14:05:06 --> Config Class Initialized
INFO - 2016-02-05 14:05:06 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:06 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:06 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:06 --> URI Class Initialized
INFO - 2016-02-05 14:05:06 --> Router Class Initialized
INFO - 2016-02-05 14:05:06 --> Output Class Initialized
INFO - 2016-02-05 14:05:06 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:06 --> Input Class Initialized
INFO - 2016-02-05 14:05:06 --> Language Class Initialized
INFO - 2016-02-05 14:05:06 --> Loader Class Initialized
INFO - 2016-02-05 14:05:06 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:06 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:06 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:06 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:06 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:07 --> Controller Class Initialized
INFO - 2016-02-05 14:05:07 --> Model Class Initialized
INFO - 2016-02-05 14:05:07 --> Model Class Initialized
INFO - 2016-02-05 14:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:05:07 --> Pagination Class Initialized
INFO - 2016-02-05 14:05:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:05:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:05:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 14:05:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:05:07 --> Final output sent to browser
DEBUG - 2016-02-05 14:05:07 --> Total execution time: 1.1689
INFO - 2016-02-05 14:05:11 --> Config Class Initialized
INFO - 2016-02-05 14:05:11 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:11 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:11 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:11 --> URI Class Initialized
INFO - 2016-02-05 14:05:11 --> Router Class Initialized
INFO - 2016-02-05 14:05:11 --> Output Class Initialized
INFO - 2016-02-05 14:05:11 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:11 --> Input Class Initialized
INFO - 2016-02-05 14:05:11 --> Language Class Initialized
INFO - 2016-02-05 14:05:11 --> Loader Class Initialized
INFO - 2016-02-05 14:05:11 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:11 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:11 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:11 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:11 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:12 --> Controller Class Initialized
INFO - 2016-02-05 14:05:12 --> Model Class Initialized
INFO - 2016-02-05 14:05:12 --> Model Class Initialized
INFO - 2016-02-05 14:05:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:05:12 --> Pagination Class Initialized
INFO - 2016-02-05 14:05:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:05:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:05:12 --> Helper loaded: text_helper
INFO - 2016-02-05 14:05:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:05:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:05:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:05:12 --> Final output sent to browser
DEBUG - 2016-02-05 14:05:12 --> Total execution time: 1.1690
INFO - 2016-02-05 14:05:16 --> Config Class Initialized
INFO - 2016-02-05 14:05:16 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:16 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:16 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:16 --> URI Class Initialized
INFO - 2016-02-05 14:05:16 --> Router Class Initialized
INFO - 2016-02-05 14:05:16 --> Output Class Initialized
INFO - 2016-02-05 14:05:16 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:16 --> Input Class Initialized
INFO - 2016-02-05 14:05:16 --> Language Class Initialized
INFO - 2016-02-05 14:05:16 --> Loader Class Initialized
INFO - 2016-02-05 14:05:16 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:16 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:16 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:16 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:16 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:17 --> Controller Class Initialized
INFO - 2016-02-05 14:05:17 --> Model Class Initialized
INFO - 2016-02-05 14:05:17 --> Model Class Initialized
INFO - 2016-02-05 14:05:18 --> Form Validation Class Initialized
INFO - 2016-02-05 14:05:18 --> Helper loaded: text_helper
INFO - 2016-02-05 14:05:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:05:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:05:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 14:05:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:05:18 --> Final output sent to browser
DEBUG - 2016-02-05 14:05:18 --> Total execution time: 1.1298
INFO - 2016-02-05 14:05:23 --> Config Class Initialized
INFO - 2016-02-05 14:05:23 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:23 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:23 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:23 --> URI Class Initialized
INFO - 2016-02-05 14:05:23 --> Router Class Initialized
INFO - 2016-02-05 14:05:23 --> Output Class Initialized
INFO - 2016-02-05 14:05:23 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:23 --> Input Class Initialized
INFO - 2016-02-05 14:05:23 --> Language Class Initialized
INFO - 2016-02-05 14:05:23 --> Loader Class Initialized
INFO - 2016-02-05 14:05:23 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:23 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:23 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:23 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:23 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:24 --> Controller Class Initialized
INFO - 2016-02-05 14:05:24 --> Model Class Initialized
INFO - 2016-02-05 14:05:24 --> Model Class Initialized
INFO - 2016-02-05 14:05:24 --> Form Validation Class Initialized
INFO - 2016-02-05 14:05:24 --> Helper loaded: text_helper
INFO - 2016-02-05 14:05:24 --> Config Class Initialized
INFO - 2016-02-05 14:05:24 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:24 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:24 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:24 --> URI Class Initialized
INFO - 2016-02-05 14:05:24 --> Router Class Initialized
INFO - 2016-02-05 14:05:24 --> Output Class Initialized
INFO - 2016-02-05 14:05:24 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:24 --> Input Class Initialized
INFO - 2016-02-05 14:05:24 --> Language Class Initialized
INFO - 2016-02-05 14:05:24 --> Loader Class Initialized
INFO - 2016-02-05 14:05:24 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:24 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:24 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:24 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:24 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:25 --> Controller Class Initialized
INFO - 2016-02-05 14:05:25 --> Model Class Initialized
INFO - 2016-02-05 14:05:25 --> Model Class Initialized
INFO - 2016-02-05 14:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:05:25 --> Pagination Class Initialized
INFO - 2016-02-05 14:05:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:05:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:05:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 14:05:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:05:25 --> Final output sent to browser
DEBUG - 2016-02-05 14:05:25 --> Total execution time: 1.1165
INFO - 2016-02-05 14:05:27 --> Config Class Initialized
INFO - 2016-02-05 14:05:27 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:27 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:27 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:27 --> URI Class Initialized
INFO - 2016-02-05 14:05:27 --> Router Class Initialized
INFO - 2016-02-05 14:05:27 --> Output Class Initialized
INFO - 2016-02-05 14:05:27 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:27 --> Input Class Initialized
INFO - 2016-02-05 14:05:27 --> Language Class Initialized
INFO - 2016-02-05 14:05:27 --> Loader Class Initialized
INFO - 2016-02-05 14:05:27 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:27 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:27 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:27 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:27 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:28 --> Controller Class Initialized
INFO - 2016-02-05 14:05:28 --> Model Class Initialized
INFO - 2016-02-05 14:05:28 --> Model Class Initialized
INFO - 2016-02-05 14:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:05:28 --> Pagination Class Initialized
INFO - 2016-02-05 14:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:05:28 --> Helper loaded: text_helper
INFO - 2016-02-05 14:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:05:28 --> Final output sent to browser
DEBUG - 2016-02-05 14:05:28 --> Total execution time: 1.2098
INFO - 2016-02-05 14:05:37 --> Config Class Initialized
INFO - 2016-02-05 14:05:37 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:37 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:37 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:37 --> URI Class Initialized
INFO - 2016-02-05 14:05:37 --> Router Class Initialized
INFO - 2016-02-05 14:05:37 --> Output Class Initialized
INFO - 2016-02-05 14:05:37 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:37 --> Input Class Initialized
INFO - 2016-02-05 14:05:37 --> Language Class Initialized
INFO - 2016-02-05 14:05:37 --> Loader Class Initialized
INFO - 2016-02-05 14:05:37 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:37 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:37 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:37 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:37 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:38 --> Controller Class Initialized
INFO - 2016-02-05 14:05:38 --> Model Class Initialized
INFO - 2016-02-05 14:05:38 --> Model Class Initialized
INFO - 2016-02-05 14:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:05:38 --> Pagination Class Initialized
INFO - 2016-02-05 14:05:38 --> Form Validation Class Initialized
INFO - 2016-02-05 14:05:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-05 14:05:39 --> Model Class Initialized
INFO - 2016-02-05 14:05:39 --> Config Class Initialized
INFO - 2016-02-05 14:05:39 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:05:39 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:05:39 --> Utf8 Class Initialized
INFO - 2016-02-05 14:05:39 --> URI Class Initialized
INFO - 2016-02-05 14:05:39 --> Router Class Initialized
INFO - 2016-02-05 14:05:39 --> Output Class Initialized
INFO - 2016-02-05 14:05:39 --> Security Class Initialized
DEBUG - 2016-02-05 14:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:05:39 --> Input Class Initialized
INFO - 2016-02-05 14:05:39 --> Language Class Initialized
INFO - 2016-02-05 14:05:39 --> Loader Class Initialized
INFO - 2016-02-05 14:05:39 --> Helper loaded: url_helper
INFO - 2016-02-05 14:05:39 --> Helper loaded: file_helper
INFO - 2016-02-05 14:05:39 --> Helper loaded: date_helper
INFO - 2016-02-05 14:05:39 --> Helper loaded: form_helper
INFO - 2016-02-05 14:05:39 --> Database Driver Class Initialized
INFO - 2016-02-05 14:05:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:05:40 --> Controller Class Initialized
INFO - 2016-02-05 14:05:40 --> Model Class Initialized
INFO - 2016-02-05 14:05:40 --> Model Class Initialized
INFO - 2016-02-05 14:05:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:05:40 --> Pagination Class Initialized
INFO - 2016-02-05 14:05:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:05:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:05:40 --> Helper loaded: text_helper
INFO - 2016-02-05 14:05:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:05:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:05:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:05:40 --> Final output sent to browser
DEBUG - 2016-02-05 14:05:40 --> Total execution time: 1.3023
INFO - 2016-02-05 14:29:27 --> Config Class Initialized
INFO - 2016-02-05 14:29:27 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:29:27 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:29:27 --> Utf8 Class Initialized
INFO - 2016-02-05 14:29:27 --> URI Class Initialized
DEBUG - 2016-02-05 14:29:27 --> No URI present. Default controller set.
INFO - 2016-02-05 14:29:27 --> Router Class Initialized
INFO - 2016-02-05 14:29:27 --> Output Class Initialized
INFO - 2016-02-05 14:29:27 --> Security Class Initialized
DEBUG - 2016-02-05 14:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:29:27 --> Input Class Initialized
INFO - 2016-02-05 14:29:27 --> Language Class Initialized
INFO - 2016-02-05 14:29:27 --> Loader Class Initialized
INFO - 2016-02-05 14:29:27 --> Helper loaded: url_helper
INFO - 2016-02-05 14:29:28 --> Helper loaded: file_helper
INFO - 2016-02-05 14:29:28 --> Helper loaded: date_helper
INFO - 2016-02-05 14:29:28 --> Helper loaded: form_helper
INFO - 2016-02-05 14:29:28 --> Database Driver Class Initialized
INFO - 2016-02-05 14:29:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:29:29 --> Controller Class Initialized
INFO - 2016-02-05 14:29:29 --> Model Class Initialized
INFO - 2016-02-05 14:29:29 --> Model Class Initialized
INFO - 2016-02-05 14:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:29:29 --> Pagination Class Initialized
ERROR - 2016-02-05 14:29:29 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:29:29 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:29:29 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 14:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:29:29 --> Final output sent to browser
DEBUG - 2016-02-05 14:29:29 --> Total execution time: 2.7765
INFO - 2016-02-05 14:29:44 --> Config Class Initialized
INFO - 2016-02-05 14:29:44 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:29:44 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:29:44 --> Utf8 Class Initialized
INFO - 2016-02-05 14:29:44 --> URI Class Initialized
INFO - 2016-02-05 14:29:44 --> Router Class Initialized
INFO - 2016-02-05 14:29:44 --> Output Class Initialized
INFO - 2016-02-05 14:29:44 --> Security Class Initialized
DEBUG - 2016-02-05 14:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:29:44 --> Input Class Initialized
INFO - 2016-02-05 14:29:44 --> Language Class Initialized
INFO - 2016-02-05 14:29:44 --> Loader Class Initialized
INFO - 2016-02-05 14:29:44 --> Helper loaded: url_helper
INFO - 2016-02-05 14:29:44 --> Helper loaded: file_helper
INFO - 2016-02-05 14:29:44 --> Helper loaded: date_helper
INFO - 2016-02-05 14:29:44 --> Helper loaded: form_helper
INFO - 2016-02-05 14:29:44 --> Database Driver Class Initialized
INFO - 2016-02-05 14:29:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:29:45 --> Controller Class Initialized
INFO - 2016-02-05 14:29:45 --> Model Class Initialized
INFO - 2016-02-05 14:29:45 --> Model Class Initialized
INFO - 2016-02-05 14:29:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:29:45 --> Pagination Class Initialized
ERROR - 2016-02-05 14:29:45 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:29:45 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:29:45 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:29:45 --> Helper loaded: text_helper
INFO - 2016-02-05 14:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:29:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:29:45 --> Final output sent to browser
DEBUG - 2016-02-05 14:29:45 --> Total execution time: 1.3692
INFO - 2016-02-05 14:30:03 --> Config Class Initialized
INFO - 2016-02-05 14:30:03 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:30:03 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:30:03 --> Utf8 Class Initialized
INFO - 2016-02-05 14:30:03 --> URI Class Initialized
INFO - 2016-02-05 14:30:03 --> Router Class Initialized
INFO - 2016-02-05 14:30:03 --> Output Class Initialized
INFO - 2016-02-05 14:30:03 --> Security Class Initialized
DEBUG - 2016-02-05 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:30:03 --> Input Class Initialized
INFO - 2016-02-05 14:30:03 --> Language Class Initialized
INFO - 2016-02-05 14:30:03 --> Loader Class Initialized
INFO - 2016-02-05 14:30:03 --> Helper loaded: url_helper
INFO - 2016-02-05 14:30:03 --> Helper loaded: file_helper
INFO - 2016-02-05 14:30:03 --> Helper loaded: date_helper
INFO - 2016-02-05 14:30:03 --> Helper loaded: form_helper
INFO - 2016-02-05 14:30:03 --> Database Driver Class Initialized
INFO - 2016-02-05 14:30:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:30:04 --> Controller Class Initialized
INFO - 2016-02-05 14:30:04 --> Model Class Initialized
INFO - 2016-02-05 14:30:04 --> Model Class Initialized
INFO - 2016-02-05 14:30:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:30:04 --> Pagination Class Initialized
INFO - 2016-02-05 14:30:04 --> Form Validation Class Initialized
INFO - 2016-02-05 14:30:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-05 14:30:04 --> Model Class Initialized
INFO - 2016-02-05 14:30:06 --> Config Class Initialized
INFO - 2016-02-05 14:30:06 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:30:06 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:30:06 --> Utf8 Class Initialized
INFO - 2016-02-05 14:30:06 --> URI Class Initialized
INFO - 2016-02-05 14:30:06 --> Router Class Initialized
INFO - 2016-02-05 14:30:06 --> Output Class Initialized
INFO - 2016-02-05 14:30:06 --> Security Class Initialized
DEBUG - 2016-02-05 14:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:30:06 --> Input Class Initialized
INFO - 2016-02-05 14:30:06 --> Language Class Initialized
INFO - 2016-02-05 14:30:06 --> Loader Class Initialized
INFO - 2016-02-05 14:30:06 --> Helper loaded: url_helper
INFO - 2016-02-05 14:30:06 --> Helper loaded: file_helper
INFO - 2016-02-05 14:30:06 --> Helper loaded: date_helper
INFO - 2016-02-05 14:30:06 --> Helper loaded: form_helper
INFO - 2016-02-05 14:30:06 --> Database Driver Class Initialized
INFO - 2016-02-05 14:30:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:30:07 --> Controller Class Initialized
INFO - 2016-02-05 14:30:07 --> Model Class Initialized
INFO - 2016-02-05 14:30:07 --> Model Class Initialized
INFO - 2016-02-05 14:30:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:30:07 --> Pagination Class Initialized
ERROR - 2016-02-05 14:30:07 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:30:07 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:30:07 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:30:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:30:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:30:07 --> Helper loaded: text_helper
INFO - 2016-02-05 14:30:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:30:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:30:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:30:07 --> Final output sent to browser
DEBUG - 2016-02-05 14:30:07 --> Total execution time: 1.1879
INFO - 2016-02-05 14:30:37 --> Config Class Initialized
INFO - 2016-02-05 14:30:37 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:30:37 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:30:37 --> Utf8 Class Initialized
INFO - 2016-02-05 14:30:37 --> URI Class Initialized
DEBUG - 2016-02-05 14:30:37 --> No URI present. Default controller set.
INFO - 2016-02-05 14:30:37 --> Router Class Initialized
INFO - 2016-02-05 14:30:37 --> Output Class Initialized
INFO - 2016-02-05 14:30:37 --> Security Class Initialized
DEBUG - 2016-02-05 14:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:30:37 --> Input Class Initialized
INFO - 2016-02-05 14:30:37 --> Language Class Initialized
INFO - 2016-02-05 14:30:37 --> Loader Class Initialized
INFO - 2016-02-05 14:30:37 --> Helper loaded: url_helper
INFO - 2016-02-05 14:30:37 --> Helper loaded: file_helper
INFO - 2016-02-05 14:30:37 --> Helper loaded: date_helper
INFO - 2016-02-05 14:30:37 --> Helper loaded: form_helper
INFO - 2016-02-05 14:30:37 --> Database Driver Class Initialized
INFO - 2016-02-05 14:30:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:30:38 --> Controller Class Initialized
INFO - 2016-02-05 14:30:38 --> Model Class Initialized
INFO - 2016-02-05 14:30:38 --> Model Class Initialized
INFO - 2016-02-05 14:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:30:38 --> Pagination Class Initialized
ERROR - 2016-02-05 14:30:38 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:30:38 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:30:38 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:30:38 --> Final output sent to browser
DEBUG - 2016-02-05 14:30:38 --> Total execution time: 1.1620
INFO - 2016-02-05 14:30:59 --> Config Class Initialized
INFO - 2016-02-05 14:30:59 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:30:59 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:30:59 --> Utf8 Class Initialized
INFO - 2016-02-05 14:30:59 --> URI Class Initialized
INFO - 2016-02-05 14:30:59 --> Router Class Initialized
INFO - 2016-02-05 14:30:59 --> Output Class Initialized
INFO - 2016-02-05 14:30:59 --> Security Class Initialized
DEBUG - 2016-02-05 14:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:30:59 --> Input Class Initialized
INFO - 2016-02-05 14:30:59 --> Language Class Initialized
INFO - 2016-02-05 14:30:59 --> Loader Class Initialized
INFO - 2016-02-05 14:30:59 --> Helper loaded: url_helper
INFO - 2016-02-05 14:30:59 --> Helper loaded: file_helper
INFO - 2016-02-05 14:30:59 --> Helper loaded: date_helper
INFO - 2016-02-05 14:30:59 --> Helper loaded: form_helper
INFO - 2016-02-05 14:30:59 --> Database Driver Class Initialized
INFO - 2016-02-05 14:31:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:31:00 --> Controller Class Initialized
INFO - 2016-02-05 14:31:00 --> Model Class Initialized
INFO - 2016-02-05 14:31:01 --> Model Class Initialized
INFO - 2016-02-05 14:31:01 --> Form Validation Class Initialized
INFO - 2016-02-05 14:31:01 --> Helper loaded: text_helper
ERROR - 2016-02-05 14:31:01 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:31:01 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:31:01 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-05 14:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:31:01 --> Final output sent to browser
DEBUG - 2016-02-05 14:31:01 --> Total execution time: 1.5234
INFO - 2016-02-05 14:31:18 --> Config Class Initialized
INFO - 2016-02-05 14:31:18 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:31:18 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:31:18 --> Utf8 Class Initialized
INFO - 2016-02-05 14:31:18 --> URI Class Initialized
INFO - 2016-02-05 14:31:18 --> Router Class Initialized
INFO - 2016-02-05 14:31:18 --> Output Class Initialized
INFO - 2016-02-05 14:31:18 --> Security Class Initialized
DEBUG - 2016-02-05 14:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:31:18 --> Input Class Initialized
INFO - 2016-02-05 14:31:18 --> Language Class Initialized
INFO - 2016-02-05 14:31:18 --> Loader Class Initialized
INFO - 2016-02-05 14:31:18 --> Helper loaded: url_helper
INFO - 2016-02-05 14:31:18 --> Helper loaded: file_helper
INFO - 2016-02-05 14:31:18 --> Helper loaded: date_helper
INFO - 2016-02-05 14:31:18 --> Helper loaded: form_helper
INFO - 2016-02-05 14:31:18 --> Database Driver Class Initialized
INFO - 2016-02-05 14:31:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:31:19 --> Controller Class Initialized
INFO - 2016-02-05 14:31:19 --> Model Class Initialized
INFO - 2016-02-05 14:31:19 --> Model Class Initialized
INFO - 2016-02-05 14:31:19 --> Form Validation Class Initialized
INFO - 2016-02-05 14:31:19 --> Helper loaded: text_helper
INFO - 2016-02-05 14:31:20 --> Config Class Initialized
INFO - 2016-02-05 14:31:20 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:31:20 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:31:20 --> Utf8 Class Initialized
INFO - 2016-02-05 14:31:20 --> URI Class Initialized
INFO - 2016-02-05 14:31:20 --> Router Class Initialized
INFO - 2016-02-05 14:31:20 --> Output Class Initialized
INFO - 2016-02-05 14:31:20 --> Security Class Initialized
DEBUG - 2016-02-05 14:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:31:20 --> Input Class Initialized
INFO - 2016-02-05 14:31:20 --> Language Class Initialized
INFO - 2016-02-05 14:31:20 --> Loader Class Initialized
INFO - 2016-02-05 14:31:20 --> Helper loaded: url_helper
INFO - 2016-02-05 14:31:20 --> Helper loaded: file_helper
INFO - 2016-02-05 14:31:20 --> Helper loaded: date_helper
INFO - 2016-02-05 14:31:20 --> Helper loaded: form_helper
INFO - 2016-02-05 14:31:20 --> Database Driver Class Initialized
INFO - 2016-02-05 14:31:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:31:21 --> Controller Class Initialized
INFO - 2016-02-05 14:31:21 --> Model Class Initialized
INFO - 2016-02-05 14:31:21 --> Model Class Initialized
INFO - 2016-02-05 14:31:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:31:21 --> Pagination Class Initialized
ERROR - 2016-02-05 14:31:21 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:31:21 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:31:21 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 14:31:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:31:21 --> Final output sent to browser
DEBUG - 2016-02-05 14:31:21 --> Total execution time: 1.4598
INFO - 2016-02-05 14:31:24 --> Config Class Initialized
INFO - 2016-02-05 14:31:24 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:31:24 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:31:24 --> Utf8 Class Initialized
INFO - 2016-02-05 14:31:24 --> URI Class Initialized
INFO - 2016-02-05 14:31:24 --> Router Class Initialized
INFO - 2016-02-05 14:31:24 --> Output Class Initialized
INFO - 2016-02-05 14:31:24 --> Security Class Initialized
DEBUG - 2016-02-05 14:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:31:24 --> Input Class Initialized
INFO - 2016-02-05 14:31:24 --> Language Class Initialized
INFO - 2016-02-05 14:31:24 --> Loader Class Initialized
INFO - 2016-02-05 14:31:24 --> Helper loaded: url_helper
INFO - 2016-02-05 14:31:24 --> Helper loaded: file_helper
INFO - 2016-02-05 14:31:24 --> Helper loaded: date_helper
INFO - 2016-02-05 14:31:24 --> Helper loaded: form_helper
INFO - 2016-02-05 14:31:24 --> Database Driver Class Initialized
INFO - 2016-02-05 14:31:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:31:25 --> Controller Class Initialized
INFO - 2016-02-05 14:31:25 --> Model Class Initialized
INFO - 2016-02-05 14:31:25 --> Model Class Initialized
INFO - 2016-02-05 14:31:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:31:25 --> Pagination Class Initialized
ERROR - 2016-02-05 14:31:25 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:31:25 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:31:25 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:31:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:31:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:31:25 --> Helper loaded: text_helper
INFO - 2016-02-05 14:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:31:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:31:26 --> Final output sent to browser
DEBUG - 2016-02-05 14:31:26 --> Total execution time: 1.2588
INFO - 2016-02-05 14:31:36 --> Config Class Initialized
INFO - 2016-02-05 14:31:36 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:31:36 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:31:36 --> Utf8 Class Initialized
INFO - 2016-02-05 14:31:36 --> URI Class Initialized
INFO - 2016-02-05 14:31:36 --> Router Class Initialized
INFO - 2016-02-05 14:31:36 --> Output Class Initialized
INFO - 2016-02-05 14:31:36 --> Security Class Initialized
DEBUG - 2016-02-05 14:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:31:36 --> Input Class Initialized
INFO - 2016-02-05 14:31:36 --> Language Class Initialized
INFO - 2016-02-05 14:31:36 --> Loader Class Initialized
INFO - 2016-02-05 14:31:37 --> Helper loaded: url_helper
INFO - 2016-02-05 14:31:37 --> Helper loaded: file_helper
INFO - 2016-02-05 14:31:37 --> Helper loaded: date_helper
INFO - 2016-02-05 14:31:37 --> Helper loaded: form_helper
INFO - 2016-02-05 14:31:37 --> Database Driver Class Initialized
INFO - 2016-02-05 14:31:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:31:38 --> Controller Class Initialized
INFO - 2016-02-05 14:31:38 --> Model Class Initialized
INFO - 2016-02-05 14:31:38 --> Model Class Initialized
INFO - 2016-02-05 14:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:31:38 --> Pagination Class Initialized
ERROR - 2016-02-05 14:31:38 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:31:38 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:31:38 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:31:38 --> Helper loaded: text_helper
INFO - 2016-02-05 14:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:31:38 --> Final output sent to browser
DEBUG - 2016-02-05 14:31:38 --> Total execution time: 1.3947
INFO - 2016-02-05 14:35:42 --> Config Class Initialized
INFO - 2016-02-05 14:35:42 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:35:42 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:35:42 --> Utf8 Class Initialized
INFO - 2016-02-05 14:35:42 --> URI Class Initialized
DEBUG - 2016-02-05 14:35:42 --> No URI present. Default controller set.
INFO - 2016-02-05 14:35:42 --> Router Class Initialized
INFO - 2016-02-05 14:35:42 --> Output Class Initialized
INFO - 2016-02-05 14:35:42 --> Security Class Initialized
DEBUG - 2016-02-05 14:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:35:42 --> Input Class Initialized
INFO - 2016-02-05 14:35:42 --> Language Class Initialized
INFO - 2016-02-05 14:35:42 --> Loader Class Initialized
INFO - 2016-02-05 14:35:42 --> Helper loaded: url_helper
INFO - 2016-02-05 14:35:42 --> Helper loaded: file_helper
INFO - 2016-02-05 14:35:42 --> Helper loaded: date_helper
INFO - 2016-02-05 14:35:42 --> Helper loaded: form_helper
INFO - 2016-02-05 14:35:42 --> Database Driver Class Initialized
INFO - 2016-02-05 14:35:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:35:43 --> Controller Class Initialized
INFO - 2016-02-05 14:35:43 --> Model Class Initialized
INFO - 2016-02-05 14:35:43 --> Model Class Initialized
INFO - 2016-02-05 14:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:35:43 --> Pagination Class Initialized
ERROR - 2016-02-05 14:35:43 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:35:43 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:35:43 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 14:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:35:43 --> Final output sent to browser
DEBUG - 2016-02-05 14:35:44 --> Total execution time: 1.1502
INFO - 2016-02-05 14:35:46 --> Config Class Initialized
INFO - 2016-02-05 14:35:46 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:35:46 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:35:46 --> Utf8 Class Initialized
INFO - 2016-02-05 14:35:46 --> URI Class Initialized
INFO - 2016-02-05 14:35:46 --> Router Class Initialized
INFO - 2016-02-05 14:35:46 --> Output Class Initialized
INFO - 2016-02-05 14:35:46 --> Security Class Initialized
DEBUG - 2016-02-05 14:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:35:46 --> Input Class Initialized
INFO - 2016-02-05 14:35:46 --> Language Class Initialized
INFO - 2016-02-05 14:35:46 --> Loader Class Initialized
INFO - 2016-02-05 14:35:46 --> Helper loaded: url_helper
INFO - 2016-02-05 14:35:46 --> Helper loaded: file_helper
INFO - 2016-02-05 14:35:46 --> Helper loaded: date_helper
INFO - 2016-02-05 14:35:46 --> Helper loaded: form_helper
INFO - 2016-02-05 14:35:46 --> Database Driver Class Initialized
INFO - 2016-02-05 14:35:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:35:47 --> Controller Class Initialized
INFO - 2016-02-05 14:35:47 --> Model Class Initialized
INFO - 2016-02-05 14:35:47 --> Model Class Initialized
INFO - 2016-02-05 14:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:35:47 --> Pagination Class Initialized
ERROR - 2016-02-05 14:35:47 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:35:47 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:35:47 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:35:47 --> Helper loaded: text_helper
INFO - 2016-02-05 14:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:35:47 --> Final output sent to browser
DEBUG - 2016-02-05 14:35:47 --> Total execution time: 1.2772
INFO - 2016-02-05 14:35:52 --> Config Class Initialized
INFO - 2016-02-05 14:35:52 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:35:52 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:35:52 --> Utf8 Class Initialized
INFO - 2016-02-05 14:35:52 --> URI Class Initialized
INFO - 2016-02-05 14:35:52 --> Router Class Initialized
INFO - 2016-02-05 14:35:52 --> Output Class Initialized
INFO - 2016-02-05 14:35:52 --> Security Class Initialized
DEBUG - 2016-02-05 14:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:35:53 --> Input Class Initialized
INFO - 2016-02-05 14:35:53 --> Language Class Initialized
INFO - 2016-02-05 14:35:53 --> Loader Class Initialized
INFO - 2016-02-05 14:35:53 --> Helper loaded: url_helper
INFO - 2016-02-05 14:35:53 --> Helper loaded: file_helper
INFO - 2016-02-05 14:35:53 --> Helper loaded: date_helper
INFO - 2016-02-05 14:35:53 --> Helper loaded: form_helper
INFO - 2016-02-05 14:35:53 --> Database Driver Class Initialized
INFO - 2016-02-05 14:35:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:35:54 --> Controller Class Initialized
INFO - 2016-02-05 14:35:54 --> Model Class Initialized
INFO - 2016-02-05 14:35:54 --> Model Class Initialized
INFO - 2016-02-05 14:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:35:54 --> Pagination Class Initialized
ERROR - 2016-02-05 14:35:54 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:35:54 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:35:54 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:35:54 --> Helper loaded: text_helper
INFO - 2016-02-05 14:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:35:54 --> Final output sent to browser
DEBUG - 2016-02-05 14:35:54 --> Total execution time: 1.3421
INFO - 2016-02-05 14:36:30 --> Config Class Initialized
INFO - 2016-02-05 14:36:30 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:36:30 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:36:30 --> Utf8 Class Initialized
INFO - 2016-02-05 14:36:30 --> URI Class Initialized
INFO - 2016-02-05 14:36:30 --> Router Class Initialized
INFO - 2016-02-05 14:36:30 --> Output Class Initialized
INFO - 2016-02-05 14:36:30 --> Security Class Initialized
DEBUG - 2016-02-05 14:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:36:30 --> Input Class Initialized
INFO - 2016-02-05 14:36:30 --> Language Class Initialized
INFO - 2016-02-05 14:36:31 --> Loader Class Initialized
INFO - 2016-02-05 14:36:31 --> Helper loaded: url_helper
INFO - 2016-02-05 14:36:31 --> Helper loaded: file_helper
INFO - 2016-02-05 14:36:31 --> Helper loaded: date_helper
INFO - 2016-02-05 14:36:31 --> Helper loaded: form_helper
INFO - 2016-02-05 14:36:31 --> Database Driver Class Initialized
INFO - 2016-02-05 14:36:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:36:32 --> Controller Class Initialized
INFO - 2016-02-05 14:36:32 --> Model Class Initialized
INFO - 2016-02-05 14:36:32 --> Model Class Initialized
INFO - 2016-02-05 14:36:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:36:32 --> Pagination Class Initialized
ERROR - 2016-02-05 14:36:32 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:36:32 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:36:32 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:36:32 --> Helper loaded: text_helper
INFO - 2016-02-05 14:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:36:32 --> Final output sent to browser
DEBUG - 2016-02-05 14:36:32 --> Total execution time: 1.1794
INFO - 2016-02-05 14:37:55 --> Config Class Initialized
INFO - 2016-02-05 14:37:55 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:37:55 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:37:55 --> Utf8 Class Initialized
INFO - 2016-02-05 14:37:55 --> URI Class Initialized
INFO - 2016-02-05 14:37:55 --> Router Class Initialized
INFO - 2016-02-05 14:37:55 --> Output Class Initialized
INFO - 2016-02-05 14:37:55 --> Security Class Initialized
DEBUG - 2016-02-05 14:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:37:55 --> Input Class Initialized
INFO - 2016-02-05 14:37:55 --> Language Class Initialized
INFO - 2016-02-05 14:37:55 --> Loader Class Initialized
INFO - 2016-02-05 14:37:55 --> Helper loaded: url_helper
INFO - 2016-02-05 14:37:55 --> Helper loaded: file_helper
INFO - 2016-02-05 14:37:55 --> Helper loaded: date_helper
INFO - 2016-02-05 14:37:55 --> Helper loaded: form_helper
INFO - 2016-02-05 14:37:55 --> Database Driver Class Initialized
INFO - 2016-02-05 14:37:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:37:56 --> Controller Class Initialized
INFO - 2016-02-05 14:37:56 --> Model Class Initialized
INFO - 2016-02-05 14:37:56 --> Model Class Initialized
INFO - 2016-02-05 14:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:37:56 --> Pagination Class Initialized
ERROR - 2016-02-05 14:37:56 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:37:56 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
ERROR - 2016-02-05 14:37:56 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:37:56 --> Helper loaded: text_helper
INFO - 2016-02-05 14:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:37:56 --> Final output sent to browser
DEBUG - 2016-02-05 14:37:56 --> Total execution time: 1.2302
INFO - 2016-02-05 14:40:18 --> Config Class Initialized
INFO - 2016-02-05 14:40:18 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:40:18 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:40:18 --> Utf8 Class Initialized
INFO - 2016-02-05 14:40:18 --> URI Class Initialized
INFO - 2016-02-05 14:40:18 --> Router Class Initialized
INFO - 2016-02-05 14:40:18 --> Output Class Initialized
INFO - 2016-02-05 14:40:18 --> Security Class Initialized
DEBUG - 2016-02-05 14:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:40:18 --> Input Class Initialized
INFO - 2016-02-05 14:40:18 --> Language Class Initialized
INFO - 2016-02-05 14:40:18 --> Loader Class Initialized
INFO - 2016-02-05 14:40:18 --> Helper loaded: url_helper
INFO - 2016-02-05 14:40:18 --> Helper loaded: file_helper
INFO - 2016-02-05 14:40:18 --> Helper loaded: date_helper
INFO - 2016-02-05 14:40:18 --> Helper loaded: form_helper
INFO - 2016-02-05 14:40:18 --> Database Driver Class Initialized
INFO - 2016-02-05 14:40:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:40:19 --> Controller Class Initialized
INFO - 2016-02-05 14:40:19 --> Model Class Initialized
INFO - 2016-02-05 14:40:19 --> Model Class Initialized
INFO - 2016-02-05 14:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:40:19 --> Pagination Class Initialized
ERROR - 2016-02-05 14:40:19 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-05 14:41:02 --> Config Class Initialized
INFO - 2016-02-05 14:41:02 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:41:02 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:41:02 --> Utf8 Class Initialized
INFO - 2016-02-05 14:41:02 --> URI Class Initialized
INFO - 2016-02-05 14:41:02 --> Router Class Initialized
INFO - 2016-02-05 14:41:02 --> Output Class Initialized
INFO - 2016-02-05 14:41:02 --> Security Class Initialized
DEBUG - 2016-02-05 14:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:41:02 --> Input Class Initialized
INFO - 2016-02-05 14:41:02 --> Language Class Initialized
INFO - 2016-02-05 14:41:02 --> Loader Class Initialized
INFO - 2016-02-05 14:41:02 --> Helper loaded: url_helper
INFO - 2016-02-05 14:41:02 --> Helper loaded: file_helper
INFO - 2016-02-05 14:41:02 --> Helper loaded: date_helper
INFO - 2016-02-05 14:41:02 --> Helper loaded: form_helper
INFO - 2016-02-05 14:41:02 --> Database Driver Class Initialized
INFO - 2016-02-05 14:41:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:41:03 --> Controller Class Initialized
INFO - 2016-02-05 14:41:03 --> Model Class Initialized
INFO - 2016-02-05 14:41:03 --> Model Class Initialized
INFO - 2016-02-05 14:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:41:03 --> Pagination Class Initialized
INFO - 2016-02-05 14:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:41:03 --> Helper loaded: text_helper
INFO - 2016-02-05 14:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:41:03 --> Final output sent to browser
DEBUG - 2016-02-05 14:41:03 --> Total execution time: 1.2139
INFO - 2016-02-05 14:41:37 --> Config Class Initialized
INFO - 2016-02-05 14:41:37 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:41:37 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:41:37 --> Utf8 Class Initialized
INFO - 2016-02-05 14:41:37 --> URI Class Initialized
INFO - 2016-02-05 14:41:37 --> Router Class Initialized
INFO - 2016-02-05 14:41:37 --> Output Class Initialized
INFO - 2016-02-05 14:41:37 --> Security Class Initialized
DEBUG - 2016-02-05 14:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:41:37 --> Input Class Initialized
INFO - 2016-02-05 14:41:37 --> Language Class Initialized
INFO - 2016-02-05 14:41:37 --> Loader Class Initialized
INFO - 2016-02-05 14:41:37 --> Helper loaded: url_helper
INFO - 2016-02-05 14:41:37 --> Helper loaded: file_helper
INFO - 2016-02-05 14:41:37 --> Helper loaded: date_helper
INFO - 2016-02-05 14:41:37 --> Helper loaded: form_helper
INFO - 2016-02-05 14:41:37 --> Database Driver Class Initialized
INFO - 2016-02-05 14:41:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:41:38 --> Controller Class Initialized
INFO - 2016-02-05 14:41:38 --> Model Class Initialized
INFO - 2016-02-05 14:41:38 --> Model Class Initialized
INFO - 2016-02-05 14:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:41:38 --> Pagination Class Initialized
INFO - 2016-02-05 14:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:41:38 --> Helper loaded: text_helper
INFO - 2016-02-05 14:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:41:38 --> Final output sent to browser
DEBUG - 2016-02-05 14:41:38 --> Total execution time: 1.2576
INFO - 2016-02-05 14:42:09 --> Config Class Initialized
INFO - 2016-02-05 14:42:09 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:42:09 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:42:09 --> Utf8 Class Initialized
INFO - 2016-02-05 14:42:09 --> URI Class Initialized
INFO - 2016-02-05 14:42:09 --> Router Class Initialized
INFO - 2016-02-05 14:42:09 --> Output Class Initialized
INFO - 2016-02-05 14:42:09 --> Security Class Initialized
DEBUG - 2016-02-05 14:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:42:09 --> Input Class Initialized
INFO - 2016-02-05 14:42:09 --> Language Class Initialized
INFO - 2016-02-05 14:42:09 --> Loader Class Initialized
INFO - 2016-02-05 14:42:09 --> Helper loaded: url_helper
INFO - 2016-02-05 14:42:09 --> Helper loaded: file_helper
INFO - 2016-02-05 14:42:09 --> Helper loaded: date_helper
INFO - 2016-02-05 14:42:09 --> Helper loaded: form_helper
INFO - 2016-02-05 14:42:09 --> Database Driver Class Initialized
INFO - 2016-02-05 14:42:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:42:10 --> Controller Class Initialized
INFO - 2016-02-05 14:42:10 --> Model Class Initialized
INFO - 2016-02-05 14:42:10 --> Model Class Initialized
INFO - 2016-02-05 14:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:42:10 --> Pagination Class Initialized
INFO - 2016-02-05 14:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:42:10 --> Helper loaded: text_helper
INFO - 2016-02-05 14:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:42:10 --> Final output sent to browser
DEBUG - 2016-02-05 14:42:10 --> Total execution time: 1.2238
INFO - 2016-02-05 14:42:20 --> Config Class Initialized
INFO - 2016-02-05 14:42:20 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:42:20 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:42:20 --> Utf8 Class Initialized
INFO - 2016-02-05 14:42:20 --> URI Class Initialized
INFO - 2016-02-05 14:42:20 --> Router Class Initialized
INFO - 2016-02-05 14:42:20 --> Output Class Initialized
INFO - 2016-02-05 14:42:20 --> Security Class Initialized
DEBUG - 2016-02-05 14:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:42:21 --> Input Class Initialized
INFO - 2016-02-05 14:42:21 --> Language Class Initialized
INFO - 2016-02-05 14:42:21 --> Loader Class Initialized
INFO - 2016-02-05 14:42:21 --> Helper loaded: url_helper
INFO - 2016-02-05 14:42:21 --> Helper loaded: file_helper
INFO - 2016-02-05 14:42:21 --> Helper loaded: date_helper
INFO - 2016-02-05 14:42:21 --> Helper loaded: form_helper
INFO - 2016-02-05 14:42:21 --> Database Driver Class Initialized
INFO - 2016-02-05 14:42:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:42:22 --> Controller Class Initialized
INFO - 2016-02-05 14:42:22 --> Model Class Initialized
INFO - 2016-02-05 14:42:22 --> Model Class Initialized
INFO - 2016-02-05 14:42:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:42:22 --> Pagination Class Initialized
ERROR - 2016-02-05 14:42:22 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-05 14:42:22 --> Form Validation Class Initialized
INFO - 2016-02-05 14:42:22 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-05 14:42:22 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-05 14:42:22 --> Model Class Initialized
ERROR - 2016-02-05 14:42:22 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-05 14:42:22 --> Final output sent to browser
DEBUG - 2016-02-05 14:42:22 --> Total execution time: 1.2416
INFO - 2016-02-05 14:43:03 --> Config Class Initialized
INFO - 2016-02-05 14:43:03 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:43:03 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:43:03 --> Utf8 Class Initialized
INFO - 2016-02-05 14:43:03 --> URI Class Initialized
INFO - 2016-02-05 14:43:03 --> Router Class Initialized
INFO - 2016-02-05 14:43:03 --> Output Class Initialized
INFO - 2016-02-05 14:43:03 --> Security Class Initialized
DEBUG - 2016-02-05 14:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:43:03 --> Input Class Initialized
INFO - 2016-02-05 14:43:03 --> Language Class Initialized
INFO - 2016-02-05 14:43:03 --> Loader Class Initialized
INFO - 2016-02-05 14:43:03 --> Helper loaded: url_helper
INFO - 2016-02-05 14:43:03 --> Helper loaded: file_helper
INFO - 2016-02-05 14:43:03 --> Helper loaded: date_helper
INFO - 2016-02-05 14:43:03 --> Helper loaded: form_helper
INFO - 2016-02-05 14:43:03 --> Database Driver Class Initialized
INFO - 2016-02-05 14:43:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:43:04 --> Controller Class Initialized
INFO - 2016-02-05 14:43:04 --> Model Class Initialized
INFO - 2016-02-05 14:43:04 --> Model Class Initialized
INFO - 2016-02-05 14:43:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:43:04 --> Pagination Class Initialized
ERROR - 2016-02-05 14:43:04 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-05 14:43:04 --> Form Validation Class Initialized
INFO - 2016-02-05 14:43:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-05 14:43:04 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-05 14:43:04 --> Model Class Initialized
ERROR - 2016-02-05 14:43:04 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-05 14:43:04 --> Final output sent to browser
DEBUG - 2016-02-05 14:43:04 --> Total execution time: 1.2104
INFO - 2016-02-05 14:43:12 --> Config Class Initialized
INFO - 2016-02-05 14:43:12 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:43:12 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:43:12 --> Utf8 Class Initialized
INFO - 2016-02-05 14:43:12 --> URI Class Initialized
INFO - 2016-02-05 14:43:12 --> Router Class Initialized
INFO - 2016-02-05 14:43:12 --> Output Class Initialized
INFO - 2016-02-05 14:43:12 --> Security Class Initialized
DEBUG - 2016-02-05 14:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:43:12 --> Input Class Initialized
INFO - 2016-02-05 14:43:12 --> Language Class Initialized
INFO - 2016-02-05 14:43:12 --> Loader Class Initialized
INFO - 2016-02-05 14:43:12 --> Helper loaded: url_helper
INFO - 2016-02-05 14:43:12 --> Helper loaded: file_helper
INFO - 2016-02-05 14:43:12 --> Helper loaded: date_helper
INFO - 2016-02-05 14:43:12 --> Helper loaded: form_helper
INFO - 2016-02-05 14:43:12 --> Database Driver Class Initialized
INFO - 2016-02-05 14:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:43:13 --> Controller Class Initialized
INFO - 2016-02-05 14:43:13 --> Model Class Initialized
INFO - 2016-02-05 14:43:13 --> Model Class Initialized
INFO - 2016-02-05 14:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:43:13 --> Pagination Class Initialized
ERROR - 2016-02-05 14:43:13 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-05 14:43:13 --> Form Validation Class Initialized
INFO - 2016-02-05 14:43:13 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-05 14:43:13 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-05 14:43:13 --> Model Class Initialized
ERROR - 2016-02-05 14:43:13 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-05 14:43:13 --> Final output sent to browser
DEBUG - 2016-02-05 14:43:13 --> Total execution time: 1.1884
INFO - 2016-02-05 14:43:19 --> Config Class Initialized
INFO - 2016-02-05 14:43:19 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:43:19 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:43:19 --> Utf8 Class Initialized
INFO - 2016-02-05 14:43:19 --> URI Class Initialized
DEBUG - 2016-02-05 14:43:19 --> No URI present. Default controller set.
INFO - 2016-02-05 14:43:19 --> Router Class Initialized
INFO - 2016-02-05 14:43:20 --> Output Class Initialized
INFO - 2016-02-05 14:43:20 --> Security Class Initialized
DEBUG - 2016-02-05 14:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:43:20 --> Input Class Initialized
INFO - 2016-02-05 14:43:20 --> Language Class Initialized
INFO - 2016-02-05 14:43:20 --> Loader Class Initialized
INFO - 2016-02-05 14:43:20 --> Helper loaded: url_helper
INFO - 2016-02-05 14:43:20 --> Helper loaded: file_helper
INFO - 2016-02-05 14:43:20 --> Helper loaded: date_helper
INFO - 2016-02-05 14:43:20 --> Helper loaded: form_helper
INFO - 2016-02-05 14:43:20 --> Database Driver Class Initialized
INFO - 2016-02-05 14:43:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:43:21 --> Controller Class Initialized
INFO - 2016-02-05 14:43:21 --> Model Class Initialized
INFO - 2016-02-05 14:43:21 --> Model Class Initialized
INFO - 2016-02-05 14:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:43:21 --> Pagination Class Initialized
INFO - 2016-02-05 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-05 14:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:43:21 --> Final output sent to browser
DEBUG - 2016-02-05 14:43:21 --> Total execution time: 1.1673
INFO - 2016-02-05 14:43:23 --> Config Class Initialized
INFO - 2016-02-05 14:43:23 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:43:23 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:43:23 --> Utf8 Class Initialized
INFO - 2016-02-05 14:43:23 --> URI Class Initialized
INFO - 2016-02-05 14:43:23 --> Router Class Initialized
INFO - 2016-02-05 14:43:23 --> Output Class Initialized
INFO - 2016-02-05 14:43:23 --> Security Class Initialized
DEBUG - 2016-02-05 14:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:43:23 --> Input Class Initialized
INFO - 2016-02-05 14:43:23 --> Language Class Initialized
INFO - 2016-02-05 14:43:23 --> Loader Class Initialized
INFO - 2016-02-05 14:43:23 --> Helper loaded: url_helper
INFO - 2016-02-05 14:43:23 --> Helper loaded: file_helper
INFO - 2016-02-05 14:43:23 --> Helper loaded: date_helper
INFO - 2016-02-05 14:43:23 --> Helper loaded: form_helper
INFO - 2016-02-05 14:43:23 --> Database Driver Class Initialized
INFO - 2016-02-05 14:43:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:43:24 --> Controller Class Initialized
INFO - 2016-02-05 14:43:24 --> Model Class Initialized
INFO - 2016-02-05 14:43:24 --> Model Class Initialized
INFO - 2016-02-05 14:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:43:24 --> Pagination Class Initialized
INFO - 2016-02-05 14:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-05 14:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-05 14:43:24 --> Helper loaded: text_helper
INFO - 2016-02-05 14:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-05 14:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-05 14:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-05 14:43:24 --> Final output sent to browser
DEBUG - 2016-02-05 14:43:24 --> Total execution time: 1.1935
INFO - 2016-02-05 14:43:29 --> Config Class Initialized
INFO - 2016-02-05 14:43:29 --> Hooks Class Initialized
DEBUG - 2016-02-05 14:43:29 --> UTF-8 Support Enabled
INFO - 2016-02-05 14:43:29 --> Utf8 Class Initialized
INFO - 2016-02-05 14:43:29 --> URI Class Initialized
INFO - 2016-02-05 14:43:29 --> Router Class Initialized
INFO - 2016-02-05 14:43:29 --> Output Class Initialized
INFO - 2016-02-05 14:43:29 --> Security Class Initialized
DEBUG - 2016-02-05 14:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-05 14:43:29 --> Input Class Initialized
INFO - 2016-02-05 14:43:29 --> Language Class Initialized
INFO - 2016-02-05 14:43:29 --> Loader Class Initialized
INFO - 2016-02-05 14:43:29 --> Helper loaded: url_helper
INFO - 2016-02-05 14:43:29 --> Helper loaded: file_helper
INFO - 2016-02-05 14:43:29 --> Helper loaded: date_helper
INFO - 2016-02-05 14:43:29 --> Helper loaded: form_helper
INFO - 2016-02-05 14:43:29 --> Database Driver Class Initialized
INFO - 2016-02-05 14:43:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-05 14:43:30 --> Controller Class Initialized
INFO - 2016-02-05 14:43:30 --> Model Class Initialized
INFO - 2016-02-05 14:43:30 --> Model Class Initialized
INFO - 2016-02-05 14:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-05 14:43:30 --> Pagination Class Initialized
ERROR - 2016-02-05 14:43:30 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-05 14:43:30 --> Form Validation Class Initialized
INFO - 2016-02-05 14:43:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-05 14:43:30 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-05 14:43:30 --> Model Class Initialized
ERROR - 2016-02-05 14:43:30 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-05 14:43:30 --> Final output sent to browser
DEBUG - 2016-02-05 14:43:30 --> Total execution time: 1.1716
