<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-04-04 08:25:52 --> Config Class Initialized
INFO - 2016-04-04 08:25:52 --> Hooks Class Initialized
DEBUG - 2016-04-04 08:25:52 --> UTF-8 Support Enabled
INFO - 2016-04-04 08:25:52 --> Utf8 Class Initialized
INFO - 2016-04-04 08:25:52 --> URI Class Initialized
DEBUG - 2016-04-04 08:25:52 --> No URI present. Default controller set.
INFO - 2016-04-04 08:25:52 --> Router Class Initialized
INFO - 2016-04-04 08:25:52 --> Output Class Initialized
INFO - 2016-04-04 08:25:52 --> Security Class Initialized
DEBUG - 2016-04-04 08:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-04 08:25:52 --> Input Class Initialized
INFO - 2016-04-04 08:25:52 --> Language Class Initialized
INFO - 2016-04-04 08:25:52 --> Loader Class Initialized
INFO - 2016-04-04 08:25:52 --> Helper loaded: url_helper
INFO - 2016-04-04 08:25:52 --> Helper loaded: file_helper
INFO - 2016-04-04 08:25:52 --> Helper loaded: date_helper
INFO - 2016-04-04 08:25:52 --> Helper loaded: form_helper
INFO - 2016-04-04 08:25:52 --> Database Driver Class Initialized
INFO - 2016-04-04 08:25:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-04 08:25:54 --> Controller Class Initialized
INFO - 2016-04-04 08:25:54 --> Model Class Initialized
INFO - 2016-04-04 08:25:54 --> Model Class Initialized
INFO - 2016-04-04 08:25:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-04 08:25:54 --> Pagination Class Initialized
INFO - 2016-04-04 08:25:54 --> Helper loaded: text_helper
INFO - 2016-04-04 08:25:54 --> Helper loaded: cookie_helper
INFO - 2016-04-04 11:25:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-04 11:25:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-04 11:25:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-04-04 11:25:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-04 11:25:54 --> Final output sent to browser
DEBUG - 2016-04-04 11:25:54 --> Total execution time: 1.7352
