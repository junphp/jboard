<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-06 08:24:35 --> Config Class Initialized
INFO - 2016-02-06 08:24:35 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:24:35 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:24:35 --> Utf8 Class Initialized
INFO - 2016-02-06 08:24:35 --> URI Class Initialized
DEBUG - 2016-02-06 08:24:35 --> No URI present. Default controller set.
INFO - 2016-02-06 08:24:35 --> Router Class Initialized
INFO - 2016-02-06 08:24:35 --> Output Class Initialized
INFO - 2016-02-06 08:24:35 --> Security Class Initialized
DEBUG - 2016-02-06 08:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:24:35 --> Input Class Initialized
INFO - 2016-02-06 08:24:35 --> Language Class Initialized
INFO - 2016-02-06 08:24:35 --> Loader Class Initialized
INFO - 2016-02-06 08:24:35 --> Helper loaded: url_helper
INFO - 2016-02-06 08:24:35 --> Helper loaded: file_helper
INFO - 2016-02-06 08:24:35 --> Helper loaded: date_helper
INFO - 2016-02-06 08:24:35 --> Helper loaded: form_helper
INFO - 2016-02-06 08:24:35 --> Database Driver Class Initialized
INFO - 2016-02-06 08:24:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:24:36 --> Controller Class Initialized
INFO - 2016-02-06 08:24:36 --> Model Class Initialized
INFO - 2016-02-06 08:24:36 --> Model Class Initialized
INFO - 2016-02-06 08:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:24:36 --> Pagination Class Initialized
INFO - 2016-02-06 08:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 08:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:24:36 --> Final output sent to browser
DEBUG - 2016-02-06 08:24:36 --> Total execution time: 1.1049
INFO - 2016-02-06 08:25:51 --> Config Class Initialized
INFO - 2016-02-06 08:25:51 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:25:51 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:25:51 --> Utf8 Class Initialized
INFO - 2016-02-06 08:25:51 --> URI Class Initialized
INFO - 2016-02-06 08:25:51 --> Router Class Initialized
INFO - 2016-02-06 08:25:51 --> Output Class Initialized
INFO - 2016-02-06 08:25:51 --> Security Class Initialized
DEBUG - 2016-02-06 08:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:25:51 --> Input Class Initialized
INFO - 2016-02-06 08:25:51 --> Language Class Initialized
INFO - 2016-02-06 08:25:51 --> Loader Class Initialized
INFO - 2016-02-06 08:25:51 --> Helper loaded: url_helper
INFO - 2016-02-06 08:25:51 --> Helper loaded: file_helper
INFO - 2016-02-06 08:25:51 --> Helper loaded: date_helper
INFO - 2016-02-06 08:25:51 --> Helper loaded: form_helper
INFO - 2016-02-06 08:25:51 --> Database Driver Class Initialized
INFO - 2016-02-06 08:25:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:25:52 --> Controller Class Initialized
INFO - 2016-02-06 08:25:52 --> Model Class Initialized
INFO - 2016-02-06 08:25:52 --> Model Class Initialized
INFO - 2016-02-06 08:25:52 --> Form Validation Class Initialized
INFO - 2016-02-06 08:25:52 --> Helper loaded: text_helper
INFO - 2016-02-06 08:25:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:25:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:25:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-06 08:25:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:25:52 --> Final output sent to browser
DEBUG - 2016-02-06 08:25:52 --> Total execution time: 1.1080
INFO - 2016-02-06 08:25:58 --> Config Class Initialized
INFO - 2016-02-06 08:25:58 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:25:58 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:25:58 --> Utf8 Class Initialized
INFO - 2016-02-06 08:25:58 --> URI Class Initialized
INFO - 2016-02-06 08:25:58 --> Router Class Initialized
INFO - 2016-02-06 08:25:58 --> Output Class Initialized
INFO - 2016-02-06 08:25:58 --> Security Class Initialized
DEBUG - 2016-02-06 08:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:25:58 --> Input Class Initialized
INFO - 2016-02-06 08:25:58 --> Language Class Initialized
INFO - 2016-02-06 08:25:58 --> Loader Class Initialized
INFO - 2016-02-06 08:25:58 --> Helper loaded: url_helper
INFO - 2016-02-06 08:25:58 --> Helper loaded: file_helper
INFO - 2016-02-06 08:25:58 --> Helper loaded: date_helper
INFO - 2016-02-06 08:25:58 --> Helper loaded: form_helper
INFO - 2016-02-06 08:25:58 --> Database Driver Class Initialized
INFO - 2016-02-06 08:25:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:25:59 --> Controller Class Initialized
INFO - 2016-02-06 08:25:59 --> Model Class Initialized
INFO - 2016-02-06 08:25:59 --> Model Class Initialized
INFO - 2016-02-06 08:25:59 --> Form Validation Class Initialized
INFO - 2016-02-06 08:25:59 --> Helper loaded: text_helper
INFO - 2016-02-06 08:25:59 --> Config Class Initialized
INFO - 2016-02-06 08:25:59 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:25:59 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:25:59 --> Utf8 Class Initialized
INFO - 2016-02-06 08:25:59 --> URI Class Initialized
INFO - 2016-02-06 08:25:59 --> Router Class Initialized
INFO - 2016-02-06 08:25:59 --> Output Class Initialized
INFO - 2016-02-06 08:25:59 --> Security Class Initialized
DEBUG - 2016-02-06 08:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:25:59 --> Input Class Initialized
INFO - 2016-02-06 08:25:59 --> Language Class Initialized
INFO - 2016-02-06 08:25:59 --> Loader Class Initialized
INFO - 2016-02-06 08:25:59 --> Helper loaded: url_helper
INFO - 2016-02-06 08:25:59 --> Helper loaded: file_helper
INFO - 2016-02-06 08:25:59 --> Helper loaded: date_helper
INFO - 2016-02-06 08:25:59 --> Helper loaded: form_helper
INFO - 2016-02-06 08:25:59 --> Database Driver Class Initialized
INFO - 2016-02-06 08:26:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:26:00 --> Controller Class Initialized
INFO - 2016-02-06 08:26:00 --> Model Class Initialized
INFO - 2016-02-06 08:26:00 --> Model Class Initialized
INFO - 2016-02-06 08:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:26:00 --> Pagination Class Initialized
INFO - 2016-02-06 08:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 08:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:26:00 --> Final output sent to browser
DEBUG - 2016-02-06 08:26:00 --> Total execution time: 1.1154
INFO - 2016-02-06 08:26:02 --> Config Class Initialized
INFO - 2016-02-06 08:26:02 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:26:02 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:26:02 --> Utf8 Class Initialized
INFO - 2016-02-06 08:26:02 --> URI Class Initialized
INFO - 2016-02-06 08:26:02 --> Router Class Initialized
INFO - 2016-02-06 08:26:02 --> Output Class Initialized
INFO - 2016-02-06 08:26:02 --> Security Class Initialized
DEBUG - 2016-02-06 08:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:26:02 --> Input Class Initialized
INFO - 2016-02-06 08:26:02 --> Language Class Initialized
INFO - 2016-02-06 08:26:02 --> Loader Class Initialized
INFO - 2016-02-06 08:26:02 --> Helper loaded: url_helper
INFO - 2016-02-06 08:26:02 --> Helper loaded: file_helper
INFO - 2016-02-06 08:26:02 --> Helper loaded: date_helper
INFO - 2016-02-06 08:26:02 --> Helper loaded: form_helper
INFO - 2016-02-06 08:26:02 --> Database Driver Class Initialized
INFO - 2016-02-06 08:26:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:26:03 --> Controller Class Initialized
INFO - 2016-02-06 08:26:03 --> Model Class Initialized
INFO - 2016-02-06 08:26:03 --> Model Class Initialized
INFO - 2016-02-06 08:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:26:03 --> Pagination Class Initialized
INFO - 2016-02-06 08:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:26:03 --> Helper loaded: text_helper
INFO - 2016-02-06 08:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 08:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 08:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:26:03 --> Final output sent to browser
DEBUG - 2016-02-06 08:26:03 --> Total execution time: 1.2108
INFO - 2016-02-06 08:26:13 --> Config Class Initialized
INFO - 2016-02-06 08:26:13 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:26:13 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:26:13 --> Utf8 Class Initialized
INFO - 2016-02-06 08:26:13 --> URI Class Initialized
INFO - 2016-02-06 08:26:13 --> Router Class Initialized
INFO - 2016-02-06 08:26:13 --> Output Class Initialized
INFO - 2016-02-06 08:26:13 --> Security Class Initialized
DEBUG - 2016-02-06 08:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:26:13 --> Input Class Initialized
INFO - 2016-02-06 08:26:13 --> Language Class Initialized
INFO - 2016-02-06 08:26:13 --> Loader Class Initialized
INFO - 2016-02-06 08:26:13 --> Helper loaded: url_helper
INFO - 2016-02-06 08:26:13 --> Helper loaded: file_helper
INFO - 2016-02-06 08:26:13 --> Helper loaded: date_helper
INFO - 2016-02-06 08:26:13 --> Helper loaded: form_helper
INFO - 2016-02-06 08:26:13 --> Database Driver Class Initialized
INFO - 2016-02-06 08:26:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:26:14 --> Controller Class Initialized
INFO - 2016-02-06 08:26:14 --> Model Class Initialized
INFO - 2016-02-06 08:26:14 --> Model Class Initialized
INFO - 2016-02-06 08:26:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:26:14 --> Pagination Class Initialized
ERROR - 2016-02-06 08:26:14 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:26:14 --> Form Validation Class Initialized
INFO - 2016-02-06 08:26:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:26:14 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:26:14 --> Model Class Initialized
ERROR - 2016-02-06 08:26:14 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:26:14 --> Final output sent to browser
DEBUG - 2016-02-06 08:26:14 --> Total execution time: 1.2230
INFO - 2016-02-06 08:28:55 --> Config Class Initialized
INFO - 2016-02-06 08:28:55 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:28:55 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:28:55 --> Utf8 Class Initialized
INFO - 2016-02-06 08:28:55 --> URI Class Initialized
INFO - 2016-02-06 08:28:56 --> Router Class Initialized
INFO - 2016-02-06 08:28:56 --> Output Class Initialized
INFO - 2016-02-06 08:28:56 --> Security Class Initialized
DEBUG - 2016-02-06 08:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:28:56 --> Input Class Initialized
INFO - 2016-02-06 08:28:56 --> Language Class Initialized
INFO - 2016-02-06 08:28:56 --> Loader Class Initialized
INFO - 2016-02-06 08:28:56 --> Helper loaded: url_helper
INFO - 2016-02-06 08:28:56 --> Helper loaded: file_helper
INFO - 2016-02-06 08:28:56 --> Helper loaded: date_helper
INFO - 2016-02-06 08:28:56 --> Helper loaded: form_helper
INFO - 2016-02-06 08:28:56 --> Database Driver Class Initialized
INFO - 2016-02-06 08:28:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:28:57 --> Controller Class Initialized
INFO - 2016-02-06 08:28:57 --> Model Class Initialized
INFO - 2016-02-06 08:28:57 --> Model Class Initialized
INFO - 2016-02-06 08:28:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:28:57 --> Pagination Class Initialized
INFO - 2016-02-06 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:28:57 --> Helper loaded: text_helper
INFO - 2016-02-06 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 08:28:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:28:57 --> Final output sent to browser
DEBUG - 2016-02-06 08:28:57 --> Total execution time: 1.2035
INFO - 2016-02-06 08:29:02 --> Config Class Initialized
INFO - 2016-02-06 08:29:02 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:29:02 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:29:02 --> Utf8 Class Initialized
INFO - 2016-02-06 08:29:02 --> URI Class Initialized
INFO - 2016-02-06 08:29:02 --> Router Class Initialized
INFO - 2016-02-06 08:29:02 --> Output Class Initialized
INFO - 2016-02-06 08:29:02 --> Security Class Initialized
DEBUG - 2016-02-06 08:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:29:02 --> Input Class Initialized
INFO - 2016-02-06 08:29:02 --> Language Class Initialized
INFO - 2016-02-06 08:29:02 --> Loader Class Initialized
INFO - 2016-02-06 08:29:02 --> Helper loaded: url_helper
INFO - 2016-02-06 08:29:02 --> Helper loaded: file_helper
INFO - 2016-02-06 08:29:02 --> Helper loaded: date_helper
INFO - 2016-02-06 08:29:02 --> Helper loaded: form_helper
INFO - 2016-02-06 08:29:02 --> Database Driver Class Initialized
INFO - 2016-02-06 08:29:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:29:03 --> Controller Class Initialized
INFO - 2016-02-06 08:29:03 --> Model Class Initialized
INFO - 2016-02-06 08:29:03 --> Model Class Initialized
INFO - 2016-02-06 08:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:29:03 --> Pagination Class Initialized
INFO - 2016-02-06 08:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:29:03 --> Helper loaded: text_helper
INFO - 2016-02-06 08:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 08:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 08:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:29:03 --> Final output sent to browser
DEBUG - 2016-02-06 08:29:03 --> Total execution time: 1.2040
INFO - 2016-02-06 08:29:57 --> Config Class Initialized
INFO - 2016-02-06 08:29:57 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:29:57 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:29:57 --> Utf8 Class Initialized
INFO - 2016-02-06 08:29:57 --> URI Class Initialized
INFO - 2016-02-06 08:29:58 --> Router Class Initialized
INFO - 2016-02-06 08:29:58 --> Output Class Initialized
INFO - 2016-02-06 08:29:58 --> Security Class Initialized
DEBUG - 2016-02-06 08:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:29:58 --> Input Class Initialized
INFO - 2016-02-06 08:29:58 --> Language Class Initialized
INFO - 2016-02-06 08:29:58 --> Loader Class Initialized
INFO - 2016-02-06 08:29:58 --> Helper loaded: url_helper
INFO - 2016-02-06 08:29:58 --> Helper loaded: file_helper
INFO - 2016-02-06 08:29:58 --> Helper loaded: date_helper
INFO - 2016-02-06 08:29:58 --> Helper loaded: form_helper
INFO - 2016-02-06 08:29:58 --> Database Driver Class Initialized
INFO - 2016-02-06 08:29:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:29:59 --> Controller Class Initialized
INFO - 2016-02-06 08:29:59 --> Model Class Initialized
INFO - 2016-02-06 08:29:59 --> Model Class Initialized
INFO - 2016-02-06 08:29:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:29:59 --> Pagination Class Initialized
INFO - 2016-02-06 08:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:29:59 --> Helper loaded: text_helper
INFO - 2016-02-06 08:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 08:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 08:29:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:29:59 --> Final output sent to browser
DEBUG - 2016-02-06 08:29:59 --> Total execution time: 1.1762
INFO - 2016-02-06 08:31:48 --> Config Class Initialized
INFO - 2016-02-06 08:31:48 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:31:48 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:31:48 --> Utf8 Class Initialized
INFO - 2016-02-06 08:31:48 --> URI Class Initialized
INFO - 2016-02-06 08:31:48 --> Router Class Initialized
INFO - 2016-02-06 08:31:48 --> Output Class Initialized
INFO - 2016-02-06 08:31:48 --> Security Class Initialized
DEBUG - 2016-02-06 08:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:31:48 --> Input Class Initialized
INFO - 2016-02-06 08:31:48 --> Language Class Initialized
INFO - 2016-02-06 08:31:48 --> Loader Class Initialized
INFO - 2016-02-06 08:31:48 --> Helper loaded: url_helper
INFO - 2016-02-06 08:31:48 --> Helper loaded: file_helper
INFO - 2016-02-06 08:31:48 --> Helper loaded: date_helper
INFO - 2016-02-06 08:31:48 --> Helper loaded: form_helper
INFO - 2016-02-06 08:31:48 --> Database Driver Class Initialized
INFO - 2016-02-06 08:31:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:31:49 --> Controller Class Initialized
INFO - 2016-02-06 08:31:49 --> Model Class Initialized
INFO - 2016-02-06 08:31:49 --> Model Class Initialized
INFO - 2016-02-06 08:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:31:49 --> Pagination Class Initialized
ERROR - 2016-02-06 08:31:49 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:31:49 --> Form Validation Class Initialized
INFO - 2016-02-06 08:31:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:31:49 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:31:49 --> Model Class Initialized
ERROR - 2016-02-06 08:31:49 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:31:49 --> Final output sent to browser
DEBUG - 2016-02-06 08:31:49 --> Total execution time: 1.1537
INFO - 2016-02-06 08:37:22 --> Config Class Initialized
INFO - 2016-02-06 08:37:22 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:22 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:22 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:22 --> URI Class Initialized
INFO - 2016-02-06 08:37:22 --> Router Class Initialized
INFO - 2016-02-06 08:37:22 --> Output Class Initialized
INFO - 2016-02-06 08:37:22 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:22 --> Input Class Initialized
INFO - 2016-02-06 08:37:22 --> Language Class Initialized
INFO - 2016-02-06 08:37:22 --> Loader Class Initialized
INFO - 2016-02-06 08:37:22 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:22 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:22 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:22 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:22 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:23 --> Controller Class Initialized
INFO - 2016-02-06 08:37:23 --> Model Class Initialized
INFO - 2016-02-06 08:37:23 --> Model Class Initialized
INFO - 2016-02-06 08:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:23 --> Pagination Class Initialized
INFO - 2016-02-06 08:37:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:37:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:37:23 --> Helper loaded: text_helper
INFO - 2016-02-06 08:37:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 08:37:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 08:37:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:37:23 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:23 --> Total execution time: 1.1920
INFO - 2016-02-06 08:37:29 --> Config Class Initialized
INFO - 2016-02-06 08:37:29 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:29 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:29 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:29 --> URI Class Initialized
DEBUG - 2016-02-06 08:37:29 --> No URI present. Default controller set.
INFO - 2016-02-06 08:37:29 --> Router Class Initialized
INFO - 2016-02-06 08:37:29 --> Output Class Initialized
INFO - 2016-02-06 08:37:29 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:29 --> Input Class Initialized
INFO - 2016-02-06 08:37:29 --> Language Class Initialized
INFO - 2016-02-06 08:37:29 --> Loader Class Initialized
INFO - 2016-02-06 08:37:29 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:29 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:29 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:29 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:29 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:30 --> Controller Class Initialized
INFO - 2016-02-06 08:37:30 --> Model Class Initialized
INFO - 2016-02-06 08:37:30 --> Model Class Initialized
INFO - 2016-02-06 08:37:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:30 --> Pagination Class Initialized
INFO - 2016-02-06 08:37:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:37:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:37:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 08:37:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:37:30 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:30 --> Total execution time: 1.1633
INFO - 2016-02-06 08:37:32 --> Config Class Initialized
INFO - 2016-02-06 08:37:32 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:32 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:32 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:32 --> URI Class Initialized
INFO - 2016-02-06 08:37:32 --> Router Class Initialized
INFO - 2016-02-06 08:37:32 --> Output Class Initialized
INFO - 2016-02-06 08:37:32 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:32 --> Input Class Initialized
INFO - 2016-02-06 08:37:32 --> Language Class Initialized
INFO - 2016-02-06 08:37:32 --> Loader Class Initialized
INFO - 2016-02-06 08:37:32 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:32 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:32 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:32 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:32 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:33 --> Controller Class Initialized
INFO - 2016-02-06 08:37:33 --> Model Class Initialized
INFO - 2016-02-06 08:37:33 --> Model Class Initialized
INFO - 2016-02-06 08:37:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:33 --> Pagination Class Initialized
INFO - 2016-02-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:37:33 --> Helper loaded: text_helper
INFO - 2016-02-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 08:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:37:33 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:33 --> Total execution time: 1.2823
INFO - 2016-02-06 08:37:44 --> Config Class Initialized
INFO - 2016-02-06 08:37:44 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:44 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:44 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:44 --> URI Class Initialized
INFO - 2016-02-06 08:37:44 --> Router Class Initialized
INFO - 2016-02-06 08:37:44 --> Output Class Initialized
INFO - 2016-02-06 08:37:44 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:44 --> Input Class Initialized
INFO - 2016-02-06 08:37:44 --> Language Class Initialized
INFO - 2016-02-06 08:37:44 --> Loader Class Initialized
INFO - 2016-02-06 08:37:44 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:44 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:44 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:44 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:44 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:45 --> Controller Class Initialized
INFO - 2016-02-06 08:37:45 --> Model Class Initialized
INFO - 2016-02-06 08:37:45 --> Model Class Initialized
INFO - 2016-02-06 08:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:45 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:45 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:45 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:45 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:45 --> Model Class Initialized
ERROR - 2016-02-06 08:37:45 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:45 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:45 --> Total execution time: 1.2163
INFO - 2016-02-06 08:37:46 --> Config Class Initialized
INFO - 2016-02-06 08:37:46 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:46 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:46 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:46 --> URI Class Initialized
INFO - 2016-02-06 08:37:46 --> Router Class Initialized
INFO - 2016-02-06 08:37:46 --> Output Class Initialized
INFO - 2016-02-06 08:37:46 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:46 --> Input Class Initialized
INFO - 2016-02-06 08:37:46 --> Language Class Initialized
INFO - 2016-02-06 08:37:46 --> Loader Class Initialized
INFO - 2016-02-06 08:37:46 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:46 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:46 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:46 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:46 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:46 --> Config Class Initialized
INFO - 2016-02-06 08:37:46 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:46 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:46 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:46 --> URI Class Initialized
INFO - 2016-02-06 08:37:46 --> Router Class Initialized
INFO - 2016-02-06 08:37:46 --> Output Class Initialized
INFO - 2016-02-06 08:37:46 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:46 --> Input Class Initialized
INFO - 2016-02-06 08:37:46 --> Language Class Initialized
INFO - 2016-02-06 08:37:46 --> Loader Class Initialized
INFO - 2016-02-06 08:37:46 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:46 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:46 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:46 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:46 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:47 --> Config Class Initialized
INFO - 2016-02-06 08:37:47 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:47 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:47 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:47 --> URI Class Initialized
INFO - 2016-02-06 08:37:47 --> Router Class Initialized
INFO - 2016-02-06 08:37:47 --> Output Class Initialized
INFO - 2016-02-06 08:37:47 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:47 --> Input Class Initialized
INFO - 2016-02-06 08:37:47 --> Language Class Initialized
INFO - 2016-02-06 08:37:47 --> Loader Class Initialized
INFO - 2016-02-06 08:37:47 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:47 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:47 --> Controller Class Initialized
INFO - 2016-02-06 08:37:47 --> Model Class Initialized
INFO - 2016-02-06 08:37:47 --> Model Class Initialized
INFO - 2016-02-06 08:37:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:47 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:47 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:47 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:47 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:47 --> Model Class Initialized
ERROR - 2016-02-06 08:37:47 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:47 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:47 --> Total execution time: 1.1870
INFO - 2016-02-06 08:37:47 --> Config Class Initialized
INFO - 2016-02-06 08:37:47 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:47 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:47 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:47 --> URI Class Initialized
INFO - 2016-02-06 08:37:47 --> Router Class Initialized
INFO - 2016-02-06 08:37:47 --> Output Class Initialized
INFO - 2016-02-06 08:37:47 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:47 --> Input Class Initialized
INFO - 2016-02-06 08:37:47 --> Language Class Initialized
INFO - 2016-02-06 08:37:47 --> Loader Class Initialized
INFO - 2016-02-06 08:37:47 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:47 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:47 --> Config Class Initialized
INFO - 2016-02-06 08:37:47 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:47 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:47 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:47 --> URI Class Initialized
INFO - 2016-02-06 08:37:47 --> Router Class Initialized
INFO - 2016-02-06 08:37:47 --> Output Class Initialized
INFO - 2016-02-06 08:37:47 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:47 --> Input Class Initialized
INFO - 2016-02-06 08:37:47 --> Language Class Initialized
INFO - 2016-02-06 08:37:47 --> Loader Class Initialized
INFO - 2016-02-06 08:37:47 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:47 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:47 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:48 --> Controller Class Initialized
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
INFO - 2016-02-06 08:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:48 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:48 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:48 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:48 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
ERROR - 2016-02-06 08:37:48 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:48 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:48 --> Total execution time: 1.2376
INFO - 2016-02-06 08:37:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:48 --> Controller Class Initialized
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
INFO - 2016-02-06 08:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:48 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:48 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:48 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:48 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
ERROR - 2016-02-06 08:37:48 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:48 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:48 --> Total execution time: 1.1478
INFO - 2016-02-06 08:37:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:48 --> Controller Class Initialized
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
INFO - 2016-02-06 08:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:48 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:48 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:48 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:48 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
ERROR - 2016-02-06 08:37:48 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:48 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:48 --> Total execution time: 1.1547
INFO - 2016-02-06 08:37:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:48 --> Controller Class Initialized
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
INFO - 2016-02-06 08:37:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:48 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:48 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:48 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:48 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:48 --> Model Class Initialized
ERROR - 2016-02-06 08:37:48 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:48 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:48 --> Total execution time: 1.1747
INFO - 2016-02-06 08:37:49 --> Config Class Initialized
INFO - 2016-02-06 08:37:49 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:49 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:49 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:49 --> URI Class Initialized
INFO - 2016-02-06 08:37:49 --> Router Class Initialized
INFO - 2016-02-06 08:37:49 --> Output Class Initialized
INFO - 2016-02-06 08:37:49 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:49 --> Input Class Initialized
INFO - 2016-02-06 08:37:49 --> Language Class Initialized
INFO - 2016-02-06 08:37:49 --> Loader Class Initialized
INFO - 2016-02-06 08:37:49 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:49 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:49 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:49 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:49 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:50 --> Config Class Initialized
INFO - 2016-02-06 08:37:50 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:50 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:50 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:50 --> URI Class Initialized
INFO - 2016-02-06 08:37:50 --> Router Class Initialized
INFO - 2016-02-06 08:37:50 --> Output Class Initialized
INFO - 2016-02-06 08:37:50 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:50 --> Input Class Initialized
INFO - 2016-02-06 08:37:50 --> Language Class Initialized
INFO - 2016-02-06 08:37:50 --> Loader Class Initialized
INFO - 2016-02-06 08:37:50 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:50 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:50 --> Config Class Initialized
INFO - 2016-02-06 08:37:50 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:50 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:50 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:50 --> URI Class Initialized
INFO - 2016-02-06 08:37:50 --> Router Class Initialized
INFO - 2016-02-06 08:37:50 --> Output Class Initialized
INFO - 2016-02-06 08:37:50 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:50 --> Input Class Initialized
INFO - 2016-02-06 08:37:50 --> Language Class Initialized
INFO - 2016-02-06 08:37:50 --> Loader Class Initialized
INFO - 2016-02-06 08:37:50 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:50 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:50 --> Config Class Initialized
INFO - 2016-02-06 08:37:50 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:50 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:50 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:50 --> URI Class Initialized
INFO - 2016-02-06 08:37:50 --> Router Class Initialized
INFO - 2016-02-06 08:37:50 --> Output Class Initialized
INFO - 2016-02-06 08:37:50 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:50 --> Input Class Initialized
INFO - 2016-02-06 08:37:50 --> Language Class Initialized
INFO - 2016-02-06 08:37:50 --> Loader Class Initialized
INFO - 2016-02-06 08:37:50 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:50 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:50 --> Controller Class Initialized
INFO - 2016-02-06 08:37:50 --> Model Class Initialized
INFO - 2016-02-06 08:37:50 --> Model Class Initialized
INFO - 2016-02-06 08:37:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:50 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:50 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:50 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:50 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:50 --> Model Class Initialized
ERROR - 2016-02-06 08:37:50 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:50 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:50 --> Total execution time: 1.1487
INFO - 2016-02-06 08:37:50 --> Config Class Initialized
INFO - 2016-02-06 08:37:50 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:50 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:50 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:50 --> URI Class Initialized
INFO - 2016-02-06 08:37:50 --> Router Class Initialized
INFO - 2016-02-06 08:37:50 --> Output Class Initialized
INFO - 2016-02-06 08:37:50 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:50 --> Input Class Initialized
INFO - 2016-02-06 08:37:50 --> Language Class Initialized
INFO - 2016-02-06 08:37:50 --> Loader Class Initialized
INFO - 2016-02-06 08:37:50 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:50 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:50 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:51 --> Controller Class Initialized
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
INFO - 2016-02-06 08:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:51 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:51 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:51 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:51 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
ERROR - 2016-02-06 08:37:51 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:51 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:51 --> Total execution time: 1.1765
INFO - 2016-02-06 08:37:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:51 --> Controller Class Initialized
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
INFO - 2016-02-06 08:37:51 --> Config Class Initialized
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
INFO - 2016-02-06 08:37:51 --> Hooks Class Initialized
INFO - 2016-02-06 08:37:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2016-02-06 08:37:51 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:51 --> Pagination Class Initialized
INFO - 2016-02-06 08:37:51 --> Utf8 Class Initialized
ERROR - 2016-02-06 08:37:51 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:51 --> URI Class Initialized
INFO - 2016-02-06 08:37:51 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:51 --> Router Class Initialized
INFO - 2016-02-06 08:37:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 08:37:51 --> Output Class Initialized
ERROR - 2016-02-06 08:37:51 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:51 --> Security Class Initialized
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
DEBUG - 2016-02-06 08:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:51 --> Input Class Initialized
INFO - 2016-02-06 08:37:51 --> Language Class Initialized
INFO - 2016-02-06 08:37:51 --> Loader Class Initialized
INFO - 2016-02-06 08:37:51 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:51 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:51 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:51 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:51 --> Database Driver Class Initialized
ERROR - 2016-02-06 08:37:51 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:51 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:51 --> Total execution time: 1.1331
INFO - 2016-02-06 08:37:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:51 --> Controller Class Initialized
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
INFO - 2016-02-06 08:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:51 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:51 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:51 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:51 --> Config Class Initialized
INFO - 2016-02-06 08:37:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 08:37:51 --> Hooks Class Initialized
ERROR - 2016-02-06 08:37:51 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:51 --> Model Class Initialized
DEBUG - 2016-02-06 08:37:51 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:51 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:51 --> URI Class Initialized
INFO - 2016-02-06 08:37:51 --> Router Class Initialized
INFO - 2016-02-06 08:37:51 --> Output Class Initialized
INFO - 2016-02-06 08:37:51 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:51 --> Input Class Initialized
INFO - 2016-02-06 08:37:51 --> Language Class Initialized
INFO - 2016-02-06 08:37:51 --> Loader Class Initialized
INFO - 2016-02-06 08:37:51 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:51 --> Helper loaded: file_helper
ERROR - 2016-02-06 08:37:51 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:51 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:51 --> Final output sent to browser
INFO - 2016-02-06 08:37:51 --> Helper loaded: form_helper
DEBUG - 2016-02-06 08:37:51 --> Total execution time: 1.1823
INFO - 2016-02-06 08:37:51 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:52 --> Controller Class Initialized
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
INFO - 2016-02-06 08:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:52 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:52 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:52 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:52 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
ERROR - 2016-02-06 08:37:52 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:52 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:52 --> Total execution time: 1.1852
INFO - 2016-02-06 08:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:52 --> Controller Class Initialized
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
INFO - 2016-02-06 08:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:52 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:52 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:52 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:52 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
ERROR - 2016-02-06 08:37:52 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:52 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:52 --> Total execution time: 1.1572
INFO - 2016-02-06 08:37:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:52 --> Controller Class Initialized
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
INFO - 2016-02-06 08:37:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:52 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:52 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:52 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:52 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:52 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:52 --> Model Class Initialized
ERROR - 2016-02-06 08:37:52 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:52 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:52 --> Total execution time: 1.1849
INFO - 2016-02-06 08:37:53 --> Config Class Initialized
INFO - 2016-02-06 08:37:53 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:37:53 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:37:53 --> Utf8 Class Initialized
INFO - 2016-02-06 08:37:53 --> URI Class Initialized
INFO - 2016-02-06 08:37:53 --> Router Class Initialized
INFO - 2016-02-06 08:37:53 --> Output Class Initialized
INFO - 2016-02-06 08:37:53 --> Security Class Initialized
DEBUG - 2016-02-06 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:37:53 --> Input Class Initialized
INFO - 2016-02-06 08:37:53 --> Language Class Initialized
INFO - 2016-02-06 08:37:53 --> Loader Class Initialized
INFO - 2016-02-06 08:37:53 --> Helper loaded: url_helper
INFO - 2016-02-06 08:37:53 --> Helper loaded: file_helper
INFO - 2016-02-06 08:37:53 --> Helper loaded: date_helper
INFO - 2016-02-06 08:37:53 --> Helper loaded: form_helper
INFO - 2016-02-06 08:37:53 --> Database Driver Class Initialized
INFO - 2016-02-06 08:37:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:37:54 --> Controller Class Initialized
INFO - 2016-02-06 08:37:54 --> Model Class Initialized
INFO - 2016-02-06 08:37:54 --> Model Class Initialized
INFO - 2016-02-06 08:37:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:37:54 --> Pagination Class Initialized
ERROR - 2016-02-06 08:37:54 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:37:54 --> Form Validation Class Initialized
INFO - 2016-02-06 08:37:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:37:54 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:37:54 --> Model Class Initialized
ERROR - 2016-02-06 08:37:54 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:37:54 --> Final output sent to browser
DEBUG - 2016-02-06 08:37:54 --> Total execution time: 1.1939
INFO - 2016-02-06 08:54:11 --> Config Class Initialized
INFO - 2016-02-06 08:54:11 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:54:11 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:54:11 --> Utf8 Class Initialized
INFO - 2016-02-06 08:54:11 --> URI Class Initialized
DEBUG - 2016-02-06 08:54:11 --> No URI present. Default controller set.
INFO - 2016-02-06 08:54:11 --> Router Class Initialized
INFO - 2016-02-06 08:54:11 --> Output Class Initialized
INFO - 2016-02-06 08:54:11 --> Security Class Initialized
DEBUG - 2016-02-06 08:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:54:11 --> Input Class Initialized
INFO - 2016-02-06 08:54:11 --> Language Class Initialized
INFO - 2016-02-06 08:54:11 --> Loader Class Initialized
INFO - 2016-02-06 08:54:11 --> Helper loaded: url_helper
INFO - 2016-02-06 08:54:11 --> Helper loaded: file_helper
INFO - 2016-02-06 08:54:11 --> Helper loaded: date_helper
INFO - 2016-02-06 08:54:11 --> Helper loaded: form_helper
INFO - 2016-02-06 08:54:11 --> Database Driver Class Initialized
INFO - 2016-02-06 08:54:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:54:12 --> Controller Class Initialized
INFO - 2016-02-06 08:54:12 --> Model Class Initialized
INFO - 2016-02-06 08:54:12 --> Model Class Initialized
INFO - 2016-02-06 08:54:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:54:12 --> Pagination Class Initialized
INFO - 2016-02-06 08:54:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:54:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:54:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 08:54:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:54:12 --> Final output sent to browser
DEBUG - 2016-02-06 08:54:12 --> Total execution time: 1.1534
INFO - 2016-02-06 08:54:14 --> Config Class Initialized
INFO - 2016-02-06 08:54:14 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:54:14 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:54:14 --> Utf8 Class Initialized
INFO - 2016-02-06 08:54:14 --> URI Class Initialized
INFO - 2016-02-06 08:54:14 --> Router Class Initialized
INFO - 2016-02-06 08:54:14 --> Output Class Initialized
INFO - 2016-02-06 08:54:14 --> Security Class Initialized
DEBUG - 2016-02-06 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:54:14 --> Input Class Initialized
INFO - 2016-02-06 08:54:14 --> Language Class Initialized
INFO - 2016-02-06 08:54:14 --> Loader Class Initialized
INFO - 2016-02-06 08:54:14 --> Helper loaded: url_helper
INFO - 2016-02-06 08:54:14 --> Helper loaded: file_helper
INFO - 2016-02-06 08:54:14 --> Helper loaded: date_helper
INFO - 2016-02-06 08:54:14 --> Helper loaded: form_helper
INFO - 2016-02-06 08:54:14 --> Database Driver Class Initialized
INFO - 2016-02-06 08:54:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:54:15 --> Controller Class Initialized
INFO - 2016-02-06 08:54:15 --> Model Class Initialized
INFO - 2016-02-06 08:54:15 --> Model Class Initialized
INFO - 2016-02-06 08:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:54:15 --> Pagination Class Initialized
INFO - 2016-02-06 08:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:54:15 --> Helper loaded: text_helper
INFO - 2016-02-06 08:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 08:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 08:54:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:54:15 --> Final output sent to browser
DEBUG - 2016-02-06 08:54:15 --> Total execution time: 1.1897
INFO - 2016-02-06 08:54:18 --> Config Class Initialized
INFO - 2016-02-06 08:54:18 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:54:18 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:54:18 --> Utf8 Class Initialized
INFO - 2016-02-06 08:54:18 --> URI Class Initialized
INFO - 2016-02-06 08:54:18 --> Router Class Initialized
INFO - 2016-02-06 08:54:18 --> Output Class Initialized
INFO - 2016-02-06 08:54:18 --> Security Class Initialized
DEBUG - 2016-02-06 08:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:54:18 --> Input Class Initialized
INFO - 2016-02-06 08:54:18 --> Language Class Initialized
INFO - 2016-02-06 08:54:18 --> Loader Class Initialized
INFO - 2016-02-06 08:54:18 --> Helper loaded: url_helper
INFO - 2016-02-06 08:54:18 --> Helper loaded: file_helper
INFO - 2016-02-06 08:54:18 --> Helper loaded: date_helper
INFO - 2016-02-06 08:54:18 --> Helper loaded: form_helper
INFO - 2016-02-06 08:54:18 --> Database Driver Class Initialized
INFO - 2016-02-06 08:54:19 --> Config Class Initialized
INFO - 2016-02-06 08:54:19 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:54:19 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:54:19 --> Utf8 Class Initialized
INFO - 2016-02-06 08:54:19 --> URI Class Initialized
INFO - 2016-02-06 08:54:19 --> Router Class Initialized
INFO - 2016-02-06 08:54:19 --> Output Class Initialized
INFO - 2016-02-06 08:54:19 --> Security Class Initialized
DEBUG - 2016-02-06 08:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:54:19 --> Input Class Initialized
INFO - 2016-02-06 08:54:19 --> Language Class Initialized
INFO - 2016-02-06 08:54:19 --> Loader Class Initialized
INFO - 2016-02-06 08:54:19 --> Helper loaded: url_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: file_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: date_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: form_helper
INFO - 2016-02-06 08:54:19 --> Database Driver Class Initialized
INFO - 2016-02-06 08:54:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:54:19 --> Controller Class Initialized
INFO - 2016-02-06 08:54:19 --> Model Class Initialized
INFO - 2016-02-06 08:54:19 --> Model Class Initialized
INFO - 2016-02-06 08:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:54:19 --> Pagination Class Initialized
ERROR - 2016-02-06 08:54:19 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:54:19 --> Form Validation Class Initialized
INFO - 2016-02-06 08:54:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:54:19 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:54:19 --> Model Class Initialized
INFO - 2016-02-06 08:54:19 --> Config Class Initialized
INFO - 2016-02-06 08:54:19 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:54:19 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:54:19 --> Utf8 Class Initialized
INFO - 2016-02-06 08:54:19 --> URI Class Initialized
INFO - 2016-02-06 08:54:19 --> Router Class Initialized
INFO - 2016-02-06 08:54:19 --> Output Class Initialized
INFO - 2016-02-06 08:54:19 --> Security Class Initialized
DEBUG - 2016-02-06 08:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2016-02-06 08:54:19 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:54:19 --> Input Class Initialized
INFO - 2016-02-06 08:54:19 --> Language Class Initialized
INFO - 2016-02-06 08:54:19 --> Final output sent to browser
DEBUG - 2016-02-06 08:54:19 --> Total execution time: 1.1876
INFO - 2016-02-06 08:54:19 --> Loader Class Initialized
INFO - 2016-02-06 08:54:19 --> Helper loaded: url_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: file_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: date_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: form_helper
INFO - 2016-02-06 08:54:19 --> Database Driver Class Initialized
INFO - 2016-02-06 08:54:19 --> Config Class Initialized
INFO - 2016-02-06 08:54:19 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:54:19 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:54:19 --> Utf8 Class Initialized
INFO - 2016-02-06 08:54:19 --> URI Class Initialized
INFO - 2016-02-06 08:54:19 --> Router Class Initialized
INFO - 2016-02-06 08:54:19 --> Output Class Initialized
INFO - 2016-02-06 08:54:19 --> Security Class Initialized
DEBUG - 2016-02-06 08:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:54:19 --> Input Class Initialized
INFO - 2016-02-06 08:54:19 --> Language Class Initialized
INFO - 2016-02-06 08:54:19 --> Loader Class Initialized
INFO - 2016-02-06 08:54:19 --> Helper loaded: url_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: file_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: date_helper
INFO - 2016-02-06 08:54:19 --> Helper loaded: form_helper
INFO - 2016-02-06 08:54:19 --> Database Driver Class Initialized
INFO - 2016-02-06 08:54:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:54:20 --> Controller Class Initialized
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
INFO - 2016-02-06 08:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:54:20 --> Pagination Class Initialized
ERROR - 2016-02-06 08:54:20 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:54:20 --> Form Validation Class Initialized
INFO - 2016-02-06 08:54:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:54:20 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
ERROR - 2016-02-06 08:54:20 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:54:20 --> Final output sent to browser
DEBUG - 2016-02-06 08:54:20 --> Total execution time: 1.1397
INFO - 2016-02-06 08:54:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:54:20 --> Controller Class Initialized
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
INFO - 2016-02-06 08:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:54:20 --> Pagination Class Initialized
ERROR - 2016-02-06 08:54:20 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:54:20 --> Form Validation Class Initialized
INFO - 2016-02-06 08:54:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:54:20 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
ERROR - 2016-02-06 08:54:20 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:54:20 --> Final output sent to browser
DEBUG - 2016-02-06 08:54:20 --> Total execution time: 1.1473
INFO - 2016-02-06 08:54:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:54:20 --> Controller Class Initialized
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
INFO - 2016-02-06 08:54:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:54:20 --> Pagination Class Initialized
ERROR - 2016-02-06 08:54:20 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:54:20 --> Form Validation Class Initialized
INFO - 2016-02-06 08:54:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:54:20 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:54:20 --> Model Class Initialized
ERROR - 2016-02-06 08:54:20 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:54:20 --> Final output sent to browser
DEBUG - 2016-02-06 08:54:20 --> Total execution time: 1.1807
INFO - 2016-02-06 08:54:59 --> Config Class Initialized
INFO - 2016-02-06 08:54:59 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:54:59 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:54:59 --> Utf8 Class Initialized
INFO - 2016-02-06 08:54:59 --> URI Class Initialized
DEBUG - 2016-02-06 08:54:59 --> No URI present. Default controller set.
INFO - 2016-02-06 08:54:59 --> Router Class Initialized
INFO - 2016-02-06 08:54:59 --> Output Class Initialized
INFO - 2016-02-06 08:54:59 --> Security Class Initialized
DEBUG - 2016-02-06 08:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:54:59 --> Input Class Initialized
INFO - 2016-02-06 08:54:59 --> Language Class Initialized
INFO - 2016-02-06 08:54:59 --> Loader Class Initialized
INFO - 2016-02-06 08:54:59 --> Helper loaded: url_helper
INFO - 2016-02-06 08:54:59 --> Helper loaded: file_helper
INFO - 2016-02-06 08:54:59 --> Helper loaded: date_helper
INFO - 2016-02-06 08:54:59 --> Helper loaded: form_helper
INFO - 2016-02-06 08:54:59 --> Database Driver Class Initialized
INFO - 2016-02-06 08:55:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:55:00 --> Controller Class Initialized
INFO - 2016-02-06 08:55:00 --> Model Class Initialized
INFO - 2016-02-06 08:55:00 --> Model Class Initialized
INFO - 2016-02-06 08:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:55:00 --> Pagination Class Initialized
INFO - 2016-02-06 08:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 08:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:55:00 --> Final output sent to browser
DEBUG - 2016-02-06 08:55:00 --> Total execution time: 1.1641
INFO - 2016-02-06 08:55:01 --> Config Class Initialized
INFO - 2016-02-06 08:55:01 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:55:01 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:55:01 --> Utf8 Class Initialized
INFO - 2016-02-06 08:55:01 --> URI Class Initialized
INFO - 2016-02-06 08:55:01 --> Router Class Initialized
INFO - 2016-02-06 08:55:01 --> Output Class Initialized
INFO - 2016-02-06 08:55:01 --> Security Class Initialized
DEBUG - 2016-02-06 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:55:01 --> Input Class Initialized
INFO - 2016-02-06 08:55:01 --> Language Class Initialized
INFO - 2016-02-06 08:55:01 --> Loader Class Initialized
INFO - 2016-02-06 08:55:01 --> Helper loaded: url_helper
INFO - 2016-02-06 08:55:01 --> Helper loaded: file_helper
INFO - 2016-02-06 08:55:01 --> Helper loaded: date_helper
INFO - 2016-02-06 08:55:01 --> Helper loaded: form_helper
INFO - 2016-02-06 08:55:01 --> Database Driver Class Initialized
INFO - 2016-02-06 08:55:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:55:02 --> Controller Class Initialized
INFO - 2016-02-06 08:55:02 --> Model Class Initialized
INFO - 2016-02-06 08:55:02 --> Model Class Initialized
INFO - 2016-02-06 08:55:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:55:02 --> Pagination Class Initialized
INFO - 2016-02-06 08:55:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 08:55:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 08:55:02 --> Helper loaded: text_helper
INFO - 2016-02-06 08:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 08:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 08:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 08:55:03 --> Final output sent to browser
DEBUG - 2016-02-06 08:55:03 --> Total execution time: 1.1930
INFO - 2016-02-06 08:55:07 --> Config Class Initialized
INFO - 2016-02-06 08:55:07 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:55:07 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:55:07 --> Utf8 Class Initialized
INFO - 2016-02-06 08:55:07 --> URI Class Initialized
INFO - 2016-02-06 08:55:07 --> Router Class Initialized
INFO - 2016-02-06 08:55:07 --> Output Class Initialized
INFO - 2016-02-06 08:55:07 --> Security Class Initialized
DEBUG - 2016-02-06 08:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:55:07 --> Input Class Initialized
INFO - 2016-02-06 08:55:07 --> Language Class Initialized
INFO - 2016-02-06 08:55:07 --> Loader Class Initialized
INFO - 2016-02-06 08:55:07 --> Helper loaded: url_helper
INFO - 2016-02-06 08:55:07 --> Helper loaded: file_helper
INFO - 2016-02-06 08:55:07 --> Helper loaded: date_helper
INFO - 2016-02-06 08:55:07 --> Helper loaded: form_helper
INFO - 2016-02-06 08:55:07 --> Database Driver Class Initialized
INFO - 2016-02-06 08:55:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:55:08 --> Controller Class Initialized
INFO - 2016-02-06 08:55:08 --> Model Class Initialized
INFO - 2016-02-06 08:55:08 --> Model Class Initialized
INFO - 2016-02-06 08:55:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:55:08 --> Pagination Class Initialized
ERROR - 2016-02-06 08:55:08 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:55:08 --> Form Validation Class Initialized
INFO - 2016-02-06 08:55:08 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:55:08 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:55:08 --> Model Class Initialized
ERROR - 2016-02-06 08:55:08 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:55:08 --> Final output sent to browser
DEBUG - 2016-02-06 08:55:08 --> Total execution time: 1.4094
INFO - 2016-02-06 08:56:10 --> Config Class Initialized
INFO - 2016-02-06 08:56:10 --> Hooks Class Initialized
DEBUG - 2016-02-06 08:56:10 --> UTF-8 Support Enabled
INFO - 2016-02-06 08:56:10 --> Utf8 Class Initialized
INFO - 2016-02-06 08:56:10 --> URI Class Initialized
INFO - 2016-02-06 08:56:10 --> Router Class Initialized
INFO - 2016-02-06 08:56:10 --> Output Class Initialized
INFO - 2016-02-06 08:56:10 --> Security Class Initialized
DEBUG - 2016-02-06 08:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 08:56:10 --> Input Class Initialized
INFO - 2016-02-06 08:56:10 --> Language Class Initialized
INFO - 2016-02-06 08:56:10 --> Loader Class Initialized
INFO - 2016-02-06 08:56:10 --> Helper loaded: url_helper
INFO - 2016-02-06 08:56:10 --> Helper loaded: file_helper
INFO - 2016-02-06 08:56:10 --> Helper loaded: date_helper
INFO - 2016-02-06 08:56:10 --> Helper loaded: form_helper
INFO - 2016-02-06 08:56:10 --> Database Driver Class Initialized
INFO - 2016-02-06 08:56:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 08:56:11 --> Controller Class Initialized
INFO - 2016-02-06 08:56:11 --> Model Class Initialized
INFO - 2016-02-06 08:56:11 --> Model Class Initialized
INFO - 2016-02-06 08:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 08:56:11 --> Pagination Class Initialized
ERROR - 2016-02-06 08:56:11 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 08:56:11 --> Form Validation Class Initialized
INFO - 2016-02-06 08:56:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 08:56:11 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 08:56:11 --> Model Class Initialized
ERROR - 2016-02-06 08:56:11 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 08:56:11 --> Final output sent to browser
DEBUG - 2016-02-06 08:56:11 --> Total execution time: 1.1953
INFO - 2016-02-06 11:01:49 --> Config Class Initialized
INFO - 2016-02-06 11:01:49 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:01:49 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:01:49 --> Utf8 Class Initialized
INFO - 2016-02-06 11:01:49 --> URI Class Initialized
DEBUG - 2016-02-06 11:01:49 --> No URI present. Default controller set.
INFO - 2016-02-06 11:01:49 --> Router Class Initialized
INFO - 2016-02-06 11:01:49 --> Output Class Initialized
INFO - 2016-02-06 11:01:49 --> Security Class Initialized
DEBUG - 2016-02-06 11:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:01:49 --> Input Class Initialized
INFO - 2016-02-06 11:01:49 --> Language Class Initialized
INFO - 2016-02-06 11:01:49 --> Loader Class Initialized
INFO - 2016-02-06 11:01:49 --> Helper loaded: url_helper
INFO - 2016-02-06 11:01:49 --> Helper loaded: file_helper
INFO - 2016-02-06 11:01:49 --> Helper loaded: date_helper
INFO - 2016-02-06 11:01:49 --> Helper loaded: form_helper
INFO - 2016-02-06 11:01:49 --> Database Driver Class Initialized
INFO - 2016-02-06 11:01:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:01:50 --> Controller Class Initialized
INFO - 2016-02-06 11:01:50 --> Model Class Initialized
INFO - 2016-02-06 11:01:50 --> Model Class Initialized
INFO - 2016-02-06 11:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:01:50 --> Pagination Class Initialized
ERROR - 2016-02-06 11:01:50 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:01:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:01:50 --> Final output sent to browser
DEBUG - 2016-02-06 11:01:50 --> Total execution time: 1.1956
INFO - 2016-02-06 11:02:09 --> Config Class Initialized
INFO - 2016-02-06 11:02:09 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:02:09 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:02:09 --> Utf8 Class Initialized
INFO - 2016-02-06 11:02:09 --> URI Class Initialized
INFO - 2016-02-06 11:02:09 --> Router Class Initialized
INFO - 2016-02-06 11:02:09 --> Output Class Initialized
INFO - 2016-02-06 11:02:09 --> Security Class Initialized
DEBUG - 2016-02-06 11:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:02:09 --> Input Class Initialized
INFO - 2016-02-06 11:02:09 --> Language Class Initialized
INFO - 2016-02-06 11:02:09 --> Loader Class Initialized
INFO - 2016-02-06 11:02:09 --> Helper loaded: url_helper
INFO - 2016-02-06 11:02:09 --> Helper loaded: file_helper
INFO - 2016-02-06 11:02:09 --> Helper loaded: date_helper
INFO - 2016-02-06 11:02:09 --> Helper loaded: form_helper
INFO - 2016-02-06 11:02:09 --> Database Driver Class Initialized
INFO - 2016-02-06 11:02:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:02:10 --> Controller Class Initialized
INFO - 2016-02-06 11:02:10 --> Model Class Initialized
INFO - 2016-02-06 11:02:10 --> Model Class Initialized
INFO - 2016-02-06 11:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:02:10 --> Pagination Class Initialized
ERROR - 2016-02-06 11:02:10 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:02:10 --> Helper loaded: text_helper
INFO - 2016-02-06 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:02:10 --> Final output sent to browser
DEBUG - 2016-02-06 11:02:10 --> Total execution time: 1.2038
INFO - 2016-02-06 11:02:39 --> Config Class Initialized
INFO - 2016-02-06 11:02:39 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:02:39 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:02:39 --> Utf8 Class Initialized
INFO - 2016-02-06 11:02:39 --> URI Class Initialized
INFO - 2016-02-06 11:02:39 --> Router Class Initialized
INFO - 2016-02-06 11:02:39 --> Output Class Initialized
INFO - 2016-02-06 11:02:39 --> Security Class Initialized
DEBUG - 2016-02-06 11:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:02:39 --> Input Class Initialized
INFO - 2016-02-06 11:02:39 --> Language Class Initialized
INFO - 2016-02-06 11:02:39 --> Loader Class Initialized
INFO - 2016-02-06 11:02:39 --> Helper loaded: url_helper
INFO - 2016-02-06 11:02:39 --> Helper loaded: file_helper
INFO - 2016-02-06 11:02:39 --> Helper loaded: date_helper
INFO - 2016-02-06 11:02:39 --> Helper loaded: form_helper
INFO - 2016-02-06 11:02:39 --> Database Driver Class Initialized
INFO - 2016-02-06 11:02:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:02:40 --> Controller Class Initialized
INFO - 2016-02-06 11:02:40 --> Model Class Initialized
INFO - 2016-02-06 11:02:40 --> Model Class Initialized
INFO - 2016-02-06 11:02:40 --> Form Validation Class Initialized
INFO - 2016-02-06 11:02:40 --> Helper loaded: text_helper
ERROR - 2016-02-06 11:02:40 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-06 11:02:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:02:40 --> Final output sent to browser
DEBUG - 2016-02-06 11:02:40 --> Total execution time: 1.1563
INFO - 2016-02-06 11:02:45 --> Config Class Initialized
INFO - 2016-02-06 11:02:45 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:02:45 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:02:45 --> Utf8 Class Initialized
INFO - 2016-02-06 11:02:45 --> URI Class Initialized
INFO - 2016-02-06 11:02:45 --> Router Class Initialized
INFO - 2016-02-06 11:02:45 --> Output Class Initialized
INFO - 2016-02-06 11:02:45 --> Security Class Initialized
DEBUG - 2016-02-06 11:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:02:45 --> Input Class Initialized
INFO - 2016-02-06 11:02:45 --> Language Class Initialized
INFO - 2016-02-06 11:02:45 --> Loader Class Initialized
INFO - 2016-02-06 11:02:45 --> Helper loaded: url_helper
INFO - 2016-02-06 11:02:45 --> Helper loaded: file_helper
INFO - 2016-02-06 11:02:45 --> Helper loaded: date_helper
INFO - 2016-02-06 11:02:45 --> Helper loaded: form_helper
INFO - 2016-02-06 11:02:45 --> Database Driver Class Initialized
INFO - 2016-02-06 11:02:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:02:46 --> Controller Class Initialized
INFO - 2016-02-06 11:02:46 --> Model Class Initialized
INFO - 2016-02-06 11:02:46 --> Model Class Initialized
INFO - 2016-02-06 11:02:46 --> Form Validation Class Initialized
INFO - 2016-02-06 11:02:46 --> Helper loaded: text_helper
INFO - 2016-02-06 11:02:47 --> Config Class Initialized
INFO - 2016-02-06 11:02:47 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:02:47 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:02:47 --> Utf8 Class Initialized
INFO - 2016-02-06 11:02:47 --> URI Class Initialized
INFO - 2016-02-06 11:02:47 --> Router Class Initialized
INFO - 2016-02-06 11:02:47 --> Output Class Initialized
INFO - 2016-02-06 11:02:47 --> Security Class Initialized
DEBUG - 2016-02-06 11:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:02:47 --> Input Class Initialized
INFO - 2016-02-06 11:02:47 --> Language Class Initialized
INFO - 2016-02-06 11:02:47 --> Loader Class Initialized
INFO - 2016-02-06 11:02:47 --> Helper loaded: url_helper
INFO - 2016-02-06 11:02:47 --> Helper loaded: file_helper
INFO - 2016-02-06 11:02:47 --> Helper loaded: date_helper
INFO - 2016-02-06 11:02:47 --> Helper loaded: form_helper
INFO - 2016-02-06 11:02:47 --> Database Driver Class Initialized
INFO - 2016-02-06 11:02:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:02:48 --> Controller Class Initialized
INFO - 2016-02-06 11:02:48 --> Model Class Initialized
INFO - 2016-02-06 11:02:48 --> Model Class Initialized
INFO - 2016-02-06 11:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:02:48 --> Pagination Class Initialized
ERROR - 2016-02-06 11:02:48 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:02:48 --> Final output sent to browser
DEBUG - 2016-02-06 11:02:48 --> Total execution time: 1.1643
INFO - 2016-02-06 11:02:52 --> Config Class Initialized
INFO - 2016-02-06 11:02:52 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:02:52 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:02:52 --> Utf8 Class Initialized
INFO - 2016-02-06 11:02:52 --> URI Class Initialized
INFO - 2016-02-06 11:02:52 --> Router Class Initialized
INFO - 2016-02-06 11:02:52 --> Output Class Initialized
INFO - 2016-02-06 11:02:52 --> Security Class Initialized
DEBUG - 2016-02-06 11:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:02:52 --> Input Class Initialized
INFO - 2016-02-06 11:02:52 --> Language Class Initialized
INFO - 2016-02-06 11:02:52 --> Loader Class Initialized
INFO - 2016-02-06 11:02:52 --> Helper loaded: url_helper
INFO - 2016-02-06 11:02:52 --> Helper loaded: file_helper
INFO - 2016-02-06 11:02:52 --> Helper loaded: date_helper
INFO - 2016-02-06 11:02:52 --> Helper loaded: form_helper
INFO - 2016-02-06 11:02:52 --> Database Driver Class Initialized
INFO - 2016-02-06 11:02:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:02:53 --> Controller Class Initialized
INFO - 2016-02-06 11:02:53 --> Model Class Initialized
INFO - 2016-02-06 11:02:53 --> Model Class Initialized
INFO - 2016-02-06 11:02:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:02:53 --> Pagination Class Initialized
ERROR - 2016-02-06 11:02:53 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:02:53 --> Helper loaded: text_helper
INFO - 2016-02-06 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:02:53 --> Final output sent to browser
DEBUG - 2016-02-06 11:02:53 --> Total execution time: 1.1985
INFO - 2016-02-06 11:02:59 --> Config Class Initialized
INFO - 2016-02-06 11:02:59 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:02:59 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:02:59 --> Utf8 Class Initialized
INFO - 2016-02-06 11:02:59 --> URI Class Initialized
INFO - 2016-02-06 11:02:59 --> Router Class Initialized
INFO - 2016-02-06 11:02:59 --> Output Class Initialized
INFO - 2016-02-06 11:02:59 --> Security Class Initialized
DEBUG - 2016-02-06 11:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:02:59 --> Input Class Initialized
INFO - 2016-02-06 11:02:59 --> Language Class Initialized
INFO - 2016-02-06 11:02:59 --> Loader Class Initialized
INFO - 2016-02-06 11:02:59 --> Helper loaded: url_helper
INFO - 2016-02-06 11:02:59 --> Helper loaded: file_helper
INFO - 2016-02-06 11:02:59 --> Helper loaded: date_helper
INFO - 2016-02-06 11:02:59 --> Helper loaded: form_helper
INFO - 2016-02-06 11:02:59 --> Database Driver Class Initialized
INFO - 2016-02-06 11:03:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:03:00 --> Controller Class Initialized
INFO - 2016-02-06 11:03:00 --> Model Class Initialized
INFO - 2016-02-06 11:03:00 --> Model Class Initialized
INFO - 2016-02-06 11:03:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:03:00 --> Pagination Class Initialized
ERROR - 2016-02-06 11:03:00 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:03:00 --> Helper loaded: text_helper
INFO - 2016-02-06 11:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:03:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:03:00 --> Final output sent to browser
DEBUG - 2016-02-06 11:03:00 --> Total execution time: 1.2360
INFO - 2016-02-06 11:07:53 --> Config Class Initialized
INFO - 2016-02-06 11:07:53 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:07:53 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:07:53 --> Utf8 Class Initialized
INFO - 2016-02-06 11:07:53 --> URI Class Initialized
DEBUG - 2016-02-06 11:07:53 --> No URI present. Default controller set.
INFO - 2016-02-06 11:07:53 --> Router Class Initialized
INFO - 2016-02-06 11:07:53 --> Output Class Initialized
INFO - 2016-02-06 11:07:54 --> Security Class Initialized
DEBUG - 2016-02-06 11:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:07:54 --> Input Class Initialized
INFO - 2016-02-06 11:07:54 --> Language Class Initialized
INFO - 2016-02-06 11:07:54 --> Loader Class Initialized
INFO - 2016-02-06 11:07:54 --> Helper loaded: url_helper
INFO - 2016-02-06 11:07:54 --> Helper loaded: file_helper
INFO - 2016-02-06 11:07:54 --> Helper loaded: date_helper
INFO - 2016-02-06 11:07:54 --> Helper loaded: form_helper
INFO - 2016-02-06 11:07:54 --> Database Driver Class Initialized
INFO - 2016-02-06 11:07:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:07:55 --> Controller Class Initialized
INFO - 2016-02-06 11:07:55 --> Model Class Initialized
INFO - 2016-02-06 11:07:55 --> Model Class Initialized
INFO - 2016-02-06 11:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:07:55 --> Pagination Class Initialized
ERROR - 2016-02-06 11:07:55 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:07:55 --> Final output sent to browser
DEBUG - 2016-02-06 11:07:55 --> Total execution time: 1.1785
INFO - 2016-02-06 11:08:02 --> Config Class Initialized
INFO - 2016-02-06 11:08:02 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:08:02 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:08:02 --> Utf8 Class Initialized
INFO - 2016-02-06 11:08:02 --> URI Class Initialized
INFO - 2016-02-06 11:08:02 --> Router Class Initialized
INFO - 2016-02-06 11:08:02 --> Output Class Initialized
INFO - 2016-02-06 11:08:02 --> Security Class Initialized
DEBUG - 2016-02-06 11:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:08:02 --> Input Class Initialized
INFO - 2016-02-06 11:08:02 --> Language Class Initialized
INFO - 2016-02-06 11:08:02 --> Loader Class Initialized
INFO - 2016-02-06 11:08:02 --> Helper loaded: url_helper
INFO - 2016-02-06 11:08:02 --> Helper loaded: file_helper
INFO - 2016-02-06 11:08:02 --> Helper loaded: date_helper
INFO - 2016-02-06 11:08:02 --> Helper loaded: form_helper
INFO - 2016-02-06 11:08:02 --> Database Driver Class Initialized
INFO - 2016-02-06 11:08:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:08:03 --> Controller Class Initialized
INFO - 2016-02-06 11:08:03 --> Model Class Initialized
INFO - 2016-02-06 11:08:03 --> Model Class Initialized
INFO - 2016-02-06 11:08:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:08:03 --> Pagination Class Initialized
ERROR - 2016-02-06 11:08:03 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:08:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:08:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:08:03 --> Helper loaded: text_helper
INFO - 2016-02-06 11:08:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:08:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:08:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:08:03 --> Final output sent to browser
DEBUG - 2016-02-06 11:08:03 --> Total execution time: 1.1682
INFO - 2016-02-06 11:08:15 --> Config Class Initialized
INFO - 2016-02-06 11:08:15 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:08:15 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:08:15 --> Utf8 Class Initialized
INFO - 2016-02-06 11:08:15 --> URI Class Initialized
INFO - 2016-02-06 11:08:15 --> Router Class Initialized
INFO - 2016-02-06 11:08:15 --> Output Class Initialized
INFO - 2016-02-06 11:08:15 --> Security Class Initialized
DEBUG - 2016-02-06 11:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:08:15 --> Input Class Initialized
INFO - 2016-02-06 11:08:15 --> Language Class Initialized
INFO - 2016-02-06 11:08:15 --> Loader Class Initialized
INFO - 2016-02-06 11:08:15 --> Helper loaded: url_helper
INFO - 2016-02-06 11:08:15 --> Helper loaded: file_helper
INFO - 2016-02-06 11:08:15 --> Helper loaded: date_helper
INFO - 2016-02-06 11:08:15 --> Helper loaded: form_helper
INFO - 2016-02-06 11:08:15 --> Database Driver Class Initialized
INFO - 2016-02-06 11:08:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:08:16 --> Controller Class Initialized
INFO - 2016-02-06 11:08:16 --> Model Class Initialized
INFO - 2016-02-06 11:08:16 --> Model Class Initialized
INFO - 2016-02-06 11:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:08:16 --> Pagination Class Initialized
ERROR - 2016-02-06 11:08:16 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 35
INFO - 2016-02-06 11:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:08:16 --> Helper loaded: text_helper
INFO - 2016-02-06 11:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:08:16 --> Final output sent to browser
DEBUG - 2016-02-06 11:08:16 --> Total execution time: 1.2292
INFO - 2016-02-06 11:08:35 --> Config Class Initialized
INFO - 2016-02-06 11:08:35 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:08:35 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:08:35 --> Utf8 Class Initialized
INFO - 2016-02-06 11:08:35 --> URI Class Initialized
DEBUG - 2016-02-06 11:08:35 --> No URI present. Default controller set.
INFO - 2016-02-06 11:08:35 --> Router Class Initialized
INFO - 2016-02-06 11:08:35 --> Output Class Initialized
INFO - 2016-02-06 11:08:35 --> Security Class Initialized
DEBUG - 2016-02-06 11:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:08:35 --> Input Class Initialized
INFO - 2016-02-06 11:08:35 --> Language Class Initialized
INFO - 2016-02-06 11:08:35 --> Loader Class Initialized
INFO - 2016-02-06 11:08:35 --> Helper loaded: url_helper
INFO - 2016-02-06 11:08:35 --> Helper loaded: file_helper
INFO - 2016-02-06 11:08:35 --> Helper loaded: date_helper
INFO - 2016-02-06 11:08:35 --> Helper loaded: form_helper
INFO - 2016-02-06 11:08:35 --> Database Driver Class Initialized
INFO - 2016-02-06 11:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:08:36 --> Controller Class Initialized
INFO - 2016-02-06 11:08:36 --> Model Class Initialized
INFO - 2016-02-06 11:08:36 --> Model Class Initialized
INFO - 2016-02-06 11:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:08:36 --> Pagination Class Initialized
INFO - 2016-02-06 11:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:08:36 --> Final output sent to browser
DEBUG - 2016-02-06 11:08:36 --> Total execution time: 1.1532
INFO - 2016-02-06 11:08:39 --> Config Class Initialized
INFO - 2016-02-06 11:08:39 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:08:39 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:08:39 --> Utf8 Class Initialized
INFO - 2016-02-06 11:08:39 --> URI Class Initialized
INFO - 2016-02-06 11:08:39 --> Router Class Initialized
INFO - 2016-02-06 11:08:39 --> Output Class Initialized
INFO - 2016-02-06 11:08:39 --> Security Class Initialized
DEBUG - 2016-02-06 11:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:08:39 --> Input Class Initialized
INFO - 2016-02-06 11:08:39 --> Language Class Initialized
INFO - 2016-02-06 11:08:39 --> Loader Class Initialized
INFO - 2016-02-06 11:08:39 --> Helper loaded: url_helper
INFO - 2016-02-06 11:08:39 --> Helper loaded: file_helper
INFO - 2016-02-06 11:08:39 --> Helper loaded: date_helper
INFO - 2016-02-06 11:08:39 --> Helper loaded: form_helper
INFO - 2016-02-06 11:08:39 --> Database Driver Class Initialized
INFO - 2016-02-06 11:08:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:08:40 --> Controller Class Initialized
INFO - 2016-02-06 11:08:40 --> Model Class Initialized
INFO - 2016-02-06 11:08:40 --> Model Class Initialized
INFO - 2016-02-06 11:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:08:40 --> Pagination Class Initialized
INFO - 2016-02-06 11:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:08:40 --> Helper loaded: text_helper
INFO - 2016-02-06 11:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:08:40 --> Final output sent to browser
DEBUG - 2016-02-06 11:08:40 --> Total execution time: 1.1966
INFO - 2016-02-06 11:08:46 --> Config Class Initialized
INFO - 2016-02-06 11:08:46 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:08:46 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:08:46 --> Utf8 Class Initialized
INFO - 2016-02-06 11:08:46 --> URI Class Initialized
INFO - 2016-02-06 11:08:46 --> Router Class Initialized
INFO - 2016-02-06 11:08:46 --> Output Class Initialized
INFO - 2016-02-06 11:08:46 --> Security Class Initialized
DEBUG - 2016-02-06 11:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:08:46 --> Input Class Initialized
INFO - 2016-02-06 11:08:46 --> Language Class Initialized
INFO - 2016-02-06 11:08:46 --> Loader Class Initialized
INFO - 2016-02-06 11:08:46 --> Helper loaded: url_helper
INFO - 2016-02-06 11:08:46 --> Helper loaded: file_helper
INFO - 2016-02-06 11:08:46 --> Helper loaded: date_helper
INFO - 2016-02-06 11:08:46 --> Helper loaded: form_helper
INFO - 2016-02-06 11:08:46 --> Database Driver Class Initialized
INFO - 2016-02-06 11:08:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:08:47 --> Controller Class Initialized
INFO - 2016-02-06 11:08:47 --> Model Class Initialized
INFO - 2016-02-06 11:08:47 --> Model Class Initialized
INFO - 2016-02-06 11:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:08:47 --> Pagination Class Initialized
ERROR - 2016-02-06 11:08:47 --> Severity: Error --> Call to undefined method CI_Loader::segment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 181
INFO - 2016-02-06 11:10:24 --> Config Class Initialized
INFO - 2016-02-06 11:10:24 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:10:24 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:10:24 --> Utf8 Class Initialized
INFO - 2016-02-06 11:10:24 --> URI Class Initialized
DEBUG - 2016-02-06 11:10:24 --> No URI present. Default controller set.
INFO - 2016-02-06 11:10:24 --> Router Class Initialized
INFO - 2016-02-06 11:10:24 --> Output Class Initialized
INFO - 2016-02-06 11:10:24 --> Security Class Initialized
DEBUG - 2016-02-06 11:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:10:24 --> Input Class Initialized
INFO - 2016-02-06 11:10:24 --> Language Class Initialized
INFO - 2016-02-06 11:10:24 --> Loader Class Initialized
INFO - 2016-02-06 11:10:25 --> Helper loaded: url_helper
INFO - 2016-02-06 11:10:25 --> Helper loaded: file_helper
INFO - 2016-02-06 11:10:25 --> Helper loaded: date_helper
INFO - 2016-02-06 11:10:25 --> Helper loaded: form_helper
INFO - 2016-02-06 11:10:25 --> Database Driver Class Initialized
INFO - 2016-02-06 11:10:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:10:26 --> Controller Class Initialized
INFO - 2016-02-06 11:10:26 --> Model Class Initialized
INFO - 2016-02-06 11:10:26 --> Model Class Initialized
INFO - 2016-02-06 11:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:10:26 --> Pagination Class Initialized
INFO - 2016-02-06 11:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:10:26 --> Final output sent to browser
DEBUG - 2016-02-06 11:10:26 --> Total execution time: 1.1836
INFO - 2016-02-06 11:10:30 --> Config Class Initialized
INFO - 2016-02-06 11:10:30 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:10:30 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:10:30 --> Utf8 Class Initialized
INFO - 2016-02-06 11:10:30 --> URI Class Initialized
INFO - 2016-02-06 11:10:30 --> Router Class Initialized
INFO - 2016-02-06 11:10:30 --> Output Class Initialized
INFO - 2016-02-06 11:10:30 --> Security Class Initialized
DEBUG - 2016-02-06 11:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:10:30 --> Input Class Initialized
INFO - 2016-02-06 11:10:30 --> Language Class Initialized
INFO - 2016-02-06 11:10:30 --> Loader Class Initialized
INFO - 2016-02-06 11:10:30 --> Helper loaded: url_helper
INFO - 2016-02-06 11:10:30 --> Helper loaded: file_helper
INFO - 2016-02-06 11:10:30 --> Helper loaded: date_helper
INFO - 2016-02-06 11:10:30 --> Helper loaded: form_helper
INFO - 2016-02-06 11:10:30 --> Database Driver Class Initialized
INFO - 2016-02-06 11:10:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:10:31 --> Controller Class Initialized
INFO - 2016-02-06 11:10:31 --> Model Class Initialized
INFO - 2016-02-06 11:10:31 --> Model Class Initialized
INFO - 2016-02-06 11:10:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:10:31 --> Pagination Class Initialized
INFO - 2016-02-06 11:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:10:31 --> Helper loaded: text_helper
INFO - 2016-02-06 11:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:10:31 --> Final output sent to browser
DEBUG - 2016-02-06 11:10:31 --> Total execution time: 1.2036
INFO - 2016-02-06 11:10:38 --> Config Class Initialized
INFO - 2016-02-06 11:10:38 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:10:38 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:10:38 --> Utf8 Class Initialized
INFO - 2016-02-06 11:10:38 --> URI Class Initialized
INFO - 2016-02-06 11:10:38 --> Router Class Initialized
INFO - 2016-02-06 11:10:38 --> Output Class Initialized
INFO - 2016-02-06 11:10:38 --> Security Class Initialized
DEBUG - 2016-02-06 11:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:10:38 --> Input Class Initialized
INFO - 2016-02-06 11:10:38 --> Language Class Initialized
INFO - 2016-02-06 11:10:38 --> Loader Class Initialized
INFO - 2016-02-06 11:10:38 --> Helper loaded: url_helper
INFO - 2016-02-06 11:10:38 --> Helper loaded: file_helper
INFO - 2016-02-06 11:10:38 --> Helper loaded: date_helper
INFO - 2016-02-06 11:10:38 --> Helper loaded: form_helper
INFO - 2016-02-06 11:10:38 --> Database Driver Class Initialized
INFO - 2016-02-06 11:10:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:10:39 --> Controller Class Initialized
INFO - 2016-02-06 11:10:39 --> Model Class Initialized
INFO - 2016-02-06 11:10:39 --> Model Class Initialized
INFO - 2016-02-06 11:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:10:39 --> Pagination Class Initialized
INFO - 2016-02-06 11:10:39 --> Form Validation Class Initialized
INFO - 2016-02-06 11:10:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 11:10:39 --> Model Class Initialized
INFO - 2016-02-06 11:10:40 --> Final output sent to browser
DEBUG - 2016-02-06 11:10:40 --> Total execution time: 1.1966
INFO - 2016-02-06 11:13:00 --> Config Class Initialized
INFO - 2016-02-06 11:13:00 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:13:00 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:13:00 --> Utf8 Class Initialized
INFO - 2016-02-06 11:13:00 --> URI Class Initialized
DEBUG - 2016-02-06 11:13:00 --> No URI present. Default controller set.
INFO - 2016-02-06 11:13:00 --> Router Class Initialized
INFO - 2016-02-06 11:13:00 --> Output Class Initialized
INFO - 2016-02-06 11:13:00 --> Security Class Initialized
DEBUG - 2016-02-06 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:13:00 --> Input Class Initialized
INFO - 2016-02-06 11:13:00 --> Language Class Initialized
INFO - 2016-02-06 11:13:00 --> Loader Class Initialized
INFO - 2016-02-06 11:13:00 --> Helper loaded: url_helper
INFO - 2016-02-06 11:13:00 --> Helper loaded: file_helper
INFO - 2016-02-06 11:13:00 --> Helper loaded: date_helper
INFO - 2016-02-06 11:13:00 --> Helper loaded: form_helper
INFO - 2016-02-06 11:13:00 --> Database Driver Class Initialized
INFO - 2016-02-06 11:13:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:13:01 --> Controller Class Initialized
INFO - 2016-02-06 11:13:01 --> Model Class Initialized
INFO - 2016-02-06 11:13:01 --> Model Class Initialized
INFO - 2016-02-06 11:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:13:01 --> Pagination Class Initialized
INFO - 2016-02-06 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:13:01 --> Final output sent to browser
DEBUG - 2016-02-06 11:13:01 --> Total execution time: 1.1438
INFO - 2016-02-06 11:13:07 --> Config Class Initialized
INFO - 2016-02-06 11:13:07 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:13:07 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:13:07 --> Utf8 Class Initialized
INFO - 2016-02-06 11:13:07 --> URI Class Initialized
INFO - 2016-02-06 11:13:07 --> Router Class Initialized
INFO - 2016-02-06 11:13:07 --> Output Class Initialized
INFO - 2016-02-06 11:13:07 --> Security Class Initialized
DEBUG - 2016-02-06 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:13:07 --> Input Class Initialized
INFO - 2016-02-06 11:13:07 --> Language Class Initialized
INFO - 2016-02-06 11:13:07 --> Loader Class Initialized
INFO - 2016-02-06 11:13:07 --> Helper loaded: url_helper
INFO - 2016-02-06 11:13:07 --> Helper loaded: file_helper
INFO - 2016-02-06 11:13:07 --> Helper loaded: date_helper
INFO - 2016-02-06 11:13:07 --> Helper loaded: form_helper
INFO - 2016-02-06 11:13:07 --> Database Driver Class Initialized
INFO - 2016-02-06 11:13:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:13:08 --> Controller Class Initialized
INFO - 2016-02-06 11:13:08 --> Model Class Initialized
INFO - 2016-02-06 11:13:08 --> Model Class Initialized
INFO - 2016-02-06 11:13:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:13:08 --> Pagination Class Initialized
INFO - 2016-02-06 11:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:13:08 --> Helper loaded: text_helper
INFO - 2016-02-06 11:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:13:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:13:08 --> Final output sent to browser
DEBUG - 2016-02-06 11:13:08 --> Total execution time: 1.1837
INFO - 2016-02-06 11:13:16 --> Config Class Initialized
INFO - 2016-02-06 11:13:16 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:13:16 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:13:16 --> Utf8 Class Initialized
INFO - 2016-02-06 11:13:16 --> URI Class Initialized
INFO - 2016-02-06 11:13:16 --> Router Class Initialized
INFO - 2016-02-06 11:13:16 --> Output Class Initialized
INFO - 2016-02-06 11:13:16 --> Security Class Initialized
DEBUG - 2016-02-06 11:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:13:16 --> Input Class Initialized
INFO - 2016-02-06 11:13:16 --> Language Class Initialized
INFO - 2016-02-06 11:13:16 --> Loader Class Initialized
INFO - 2016-02-06 11:13:16 --> Helper loaded: url_helper
INFO - 2016-02-06 11:13:16 --> Helper loaded: file_helper
INFO - 2016-02-06 11:13:16 --> Helper loaded: date_helper
INFO - 2016-02-06 11:13:16 --> Helper loaded: form_helper
INFO - 2016-02-06 11:13:16 --> Database Driver Class Initialized
INFO - 2016-02-06 11:13:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:13:17 --> Controller Class Initialized
INFO - 2016-02-06 11:13:17 --> Model Class Initialized
INFO - 2016-02-06 11:13:17 --> Model Class Initialized
INFO - 2016-02-06 11:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:13:17 --> Pagination Class Initialized
INFO - 2016-02-06 11:13:17 --> Form Validation Class Initialized
INFO - 2016-02-06 11:13:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 11:13:17 --> Model Class Initialized
INFO - 2016-02-06 11:13:17 --> Final output sent to browser
DEBUG - 2016-02-06 11:13:17 --> Total execution time: 1.3153
INFO - 2016-02-06 11:14:21 --> Config Class Initialized
INFO - 2016-02-06 11:14:21 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:14:21 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:14:21 --> Utf8 Class Initialized
INFO - 2016-02-06 11:14:21 --> URI Class Initialized
DEBUG - 2016-02-06 11:14:21 --> No URI present. Default controller set.
INFO - 2016-02-06 11:14:21 --> Router Class Initialized
INFO - 2016-02-06 11:14:21 --> Output Class Initialized
INFO - 2016-02-06 11:14:21 --> Security Class Initialized
DEBUG - 2016-02-06 11:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:14:21 --> Input Class Initialized
INFO - 2016-02-06 11:14:21 --> Language Class Initialized
INFO - 2016-02-06 11:14:21 --> Loader Class Initialized
INFO - 2016-02-06 11:14:21 --> Helper loaded: url_helper
INFO - 2016-02-06 11:14:21 --> Helper loaded: file_helper
INFO - 2016-02-06 11:14:21 --> Helper loaded: date_helper
INFO - 2016-02-06 11:14:21 --> Helper loaded: form_helper
INFO - 2016-02-06 11:14:21 --> Database Driver Class Initialized
INFO - 2016-02-06 11:14:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:14:22 --> Controller Class Initialized
INFO - 2016-02-06 11:14:22 --> Model Class Initialized
INFO - 2016-02-06 11:14:22 --> Model Class Initialized
INFO - 2016-02-06 11:14:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:14:22 --> Pagination Class Initialized
INFO - 2016-02-06 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:14:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:14:22 --> Final output sent to browser
DEBUG - 2016-02-06 11:14:22 --> Total execution time: 1.1410
INFO - 2016-02-06 11:14:29 --> Config Class Initialized
INFO - 2016-02-06 11:14:29 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:14:29 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:14:29 --> Utf8 Class Initialized
INFO - 2016-02-06 11:14:29 --> URI Class Initialized
INFO - 2016-02-06 11:14:29 --> Router Class Initialized
INFO - 2016-02-06 11:14:29 --> Output Class Initialized
INFO - 2016-02-06 11:14:29 --> Security Class Initialized
DEBUG - 2016-02-06 11:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:14:29 --> Input Class Initialized
INFO - 2016-02-06 11:14:29 --> Language Class Initialized
INFO - 2016-02-06 11:14:29 --> Loader Class Initialized
INFO - 2016-02-06 11:14:29 --> Helper loaded: url_helper
INFO - 2016-02-06 11:14:29 --> Helper loaded: file_helper
INFO - 2016-02-06 11:14:29 --> Helper loaded: date_helper
INFO - 2016-02-06 11:14:29 --> Helper loaded: form_helper
INFO - 2016-02-06 11:14:29 --> Database Driver Class Initialized
INFO - 2016-02-06 11:14:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:14:30 --> Controller Class Initialized
INFO - 2016-02-06 11:14:30 --> Model Class Initialized
INFO - 2016-02-06 11:14:30 --> Model Class Initialized
INFO - 2016-02-06 11:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:14:30 --> Pagination Class Initialized
INFO - 2016-02-06 11:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:14:30 --> Helper loaded: text_helper
INFO - 2016-02-06 11:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:14:30 --> Final output sent to browser
DEBUG - 2016-02-06 11:14:30 --> Total execution time: 1.2037
INFO - 2016-02-06 11:14:44 --> Config Class Initialized
INFO - 2016-02-06 11:14:44 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:14:44 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:14:44 --> Utf8 Class Initialized
INFO - 2016-02-06 11:14:44 --> URI Class Initialized
INFO - 2016-02-06 11:14:44 --> Router Class Initialized
INFO - 2016-02-06 11:14:44 --> Output Class Initialized
INFO - 2016-02-06 11:14:44 --> Security Class Initialized
DEBUG - 2016-02-06 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:14:44 --> Input Class Initialized
INFO - 2016-02-06 11:14:44 --> Language Class Initialized
INFO - 2016-02-06 11:14:44 --> Loader Class Initialized
INFO - 2016-02-06 11:14:44 --> Helper loaded: url_helper
INFO - 2016-02-06 11:14:44 --> Helper loaded: file_helper
INFO - 2016-02-06 11:14:44 --> Helper loaded: date_helper
INFO - 2016-02-06 11:14:44 --> Helper loaded: form_helper
INFO - 2016-02-06 11:14:44 --> Database Driver Class Initialized
INFO - 2016-02-06 11:14:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:14:45 --> Controller Class Initialized
INFO - 2016-02-06 11:14:45 --> Model Class Initialized
INFO - 2016-02-06 11:14:45 --> Model Class Initialized
INFO - 2016-02-06 11:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:14:45 --> Pagination Class Initialized
ERROR - 2016-02-06 11:14:45 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 11:14:45 --> Form Validation Class Initialized
INFO - 2016-02-06 11:14:45 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 11:14:45 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 11:14:45 --> Model Class Initialized
ERROR - 2016-02-06 11:14:45 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 11:14:45 --> Final output sent to browser
DEBUG - 2016-02-06 11:14:45 --> Total execution time: 1.1250
INFO - 2016-02-06 11:24:31 --> Config Class Initialized
INFO - 2016-02-06 11:24:31 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:24:31 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:24:31 --> Utf8 Class Initialized
INFO - 2016-02-06 11:24:31 --> URI Class Initialized
DEBUG - 2016-02-06 11:24:31 --> No URI present. Default controller set.
INFO - 2016-02-06 11:24:31 --> Router Class Initialized
INFO - 2016-02-06 11:24:31 --> Output Class Initialized
INFO - 2016-02-06 11:24:31 --> Security Class Initialized
DEBUG - 2016-02-06 11:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:24:31 --> Input Class Initialized
INFO - 2016-02-06 11:24:31 --> Language Class Initialized
INFO - 2016-02-06 11:24:31 --> Loader Class Initialized
INFO - 2016-02-06 11:24:31 --> Helper loaded: url_helper
INFO - 2016-02-06 11:24:31 --> Helper loaded: file_helper
INFO - 2016-02-06 11:24:31 --> Helper loaded: date_helper
INFO - 2016-02-06 11:24:31 --> Helper loaded: form_helper
INFO - 2016-02-06 11:24:31 --> Database Driver Class Initialized
INFO - 2016-02-06 11:24:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:24:32 --> Controller Class Initialized
INFO - 2016-02-06 11:24:32 --> Model Class Initialized
INFO - 2016-02-06 11:24:32 --> Model Class Initialized
INFO - 2016-02-06 11:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:24:32 --> Pagination Class Initialized
INFO - 2016-02-06 11:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:24:32 --> Final output sent to browser
DEBUG - 2016-02-06 11:24:32 --> Total execution time: 1.1269
INFO - 2016-02-06 11:24:34 --> Config Class Initialized
INFO - 2016-02-06 11:24:34 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:24:34 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:24:34 --> Utf8 Class Initialized
INFO - 2016-02-06 11:24:34 --> URI Class Initialized
INFO - 2016-02-06 11:24:34 --> Router Class Initialized
INFO - 2016-02-06 11:24:34 --> Output Class Initialized
INFO - 2016-02-06 11:24:34 --> Security Class Initialized
DEBUG - 2016-02-06 11:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:24:34 --> Input Class Initialized
INFO - 2016-02-06 11:24:34 --> Language Class Initialized
INFO - 2016-02-06 11:24:34 --> Loader Class Initialized
INFO - 2016-02-06 11:24:34 --> Helper loaded: url_helper
INFO - 2016-02-06 11:24:34 --> Helper loaded: file_helper
INFO - 2016-02-06 11:24:34 --> Helper loaded: date_helper
INFO - 2016-02-06 11:24:34 --> Helper loaded: form_helper
INFO - 2016-02-06 11:24:34 --> Database Driver Class Initialized
INFO - 2016-02-06 11:24:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:24:35 --> Controller Class Initialized
INFO - 2016-02-06 11:24:35 --> Model Class Initialized
INFO - 2016-02-06 11:24:35 --> Model Class Initialized
INFO - 2016-02-06 11:24:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:24:35 --> Pagination Class Initialized
INFO - 2016-02-06 11:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:24:35 --> Helper loaded: text_helper
INFO - 2016-02-06 11:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:24:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:24:35 --> Final output sent to browser
DEBUG - 2016-02-06 11:24:35 --> Total execution time: 1.1954
INFO - 2016-02-06 11:29:50 --> Config Class Initialized
INFO - 2016-02-06 11:29:50 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:29:50 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:29:50 --> Utf8 Class Initialized
INFO - 2016-02-06 11:29:50 --> URI Class Initialized
DEBUG - 2016-02-06 11:29:50 --> No URI present. Default controller set.
INFO - 2016-02-06 11:29:50 --> Router Class Initialized
INFO - 2016-02-06 11:29:50 --> Output Class Initialized
INFO - 2016-02-06 11:29:50 --> Security Class Initialized
DEBUG - 2016-02-06 11:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:29:50 --> Input Class Initialized
INFO - 2016-02-06 11:29:50 --> Language Class Initialized
INFO - 2016-02-06 11:29:50 --> Loader Class Initialized
INFO - 2016-02-06 11:29:50 --> Helper loaded: url_helper
INFO - 2016-02-06 11:29:50 --> Helper loaded: file_helper
INFO - 2016-02-06 11:29:50 --> Helper loaded: date_helper
INFO - 2016-02-06 11:29:50 --> Helper loaded: form_helper
INFO - 2016-02-06 11:29:50 --> Database Driver Class Initialized
INFO - 2016-02-06 11:29:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:29:51 --> Controller Class Initialized
INFO - 2016-02-06 11:29:51 --> Model Class Initialized
INFO - 2016-02-06 11:29:51 --> Model Class Initialized
INFO - 2016-02-06 11:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:29:51 --> Pagination Class Initialized
INFO - 2016-02-06 11:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:29:51 --> Final output sent to browser
DEBUG - 2016-02-06 11:29:51 --> Total execution time: 1.1697
INFO - 2016-02-06 11:29:53 --> Config Class Initialized
INFO - 2016-02-06 11:29:53 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:29:53 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:29:53 --> Utf8 Class Initialized
INFO - 2016-02-06 11:29:53 --> URI Class Initialized
INFO - 2016-02-06 11:29:53 --> Router Class Initialized
INFO - 2016-02-06 11:29:53 --> Output Class Initialized
INFO - 2016-02-06 11:29:53 --> Security Class Initialized
DEBUG - 2016-02-06 11:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:29:53 --> Input Class Initialized
INFO - 2016-02-06 11:29:53 --> Language Class Initialized
INFO - 2016-02-06 11:29:53 --> Loader Class Initialized
INFO - 2016-02-06 11:29:53 --> Helper loaded: url_helper
INFO - 2016-02-06 11:29:53 --> Helper loaded: file_helper
INFO - 2016-02-06 11:29:53 --> Helper loaded: date_helper
INFO - 2016-02-06 11:29:53 --> Helper loaded: form_helper
INFO - 2016-02-06 11:29:53 --> Database Driver Class Initialized
INFO - 2016-02-06 11:29:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:29:54 --> Controller Class Initialized
INFO - 2016-02-06 11:29:54 --> Model Class Initialized
INFO - 2016-02-06 11:29:54 --> Model Class Initialized
INFO - 2016-02-06 11:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:29:54 --> Pagination Class Initialized
INFO - 2016-02-06 11:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:29:54 --> Helper loaded: text_helper
INFO - 2016-02-06 11:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:29:54 --> Final output sent to browser
DEBUG - 2016-02-06 11:29:54 --> Total execution time: 1.1684
INFO - 2016-02-06 11:31:40 --> Config Class Initialized
INFO - 2016-02-06 11:31:40 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:31:40 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:31:40 --> Utf8 Class Initialized
INFO - 2016-02-06 11:31:40 --> URI Class Initialized
DEBUG - 2016-02-06 11:31:40 --> No URI present. Default controller set.
INFO - 2016-02-06 11:31:40 --> Router Class Initialized
INFO - 2016-02-06 11:31:40 --> Output Class Initialized
INFO - 2016-02-06 11:31:40 --> Security Class Initialized
DEBUG - 2016-02-06 11:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:31:40 --> Input Class Initialized
INFO - 2016-02-06 11:31:40 --> Language Class Initialized
INFO - 2016-02-06 11:31:40 --> Loader Class Initialized
INFO - 2016-02-06 11:31:40 --> Helper loaded: url_helper
INFO - 2016-02-06 11:31:40 --> Helper loaded: file_helper
INFO - 2016-02-06 11:31:40 --> Helper loaded: date_helper
INFO - 2016-02-06 11:31:40 --> Helper loaded: form_helper
INFO - 2016-02-06 11:31:40 --> Database Driver Class Initialized
INFO - 2016-02-06 11:31:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:31:41 --> Controller Class Initialized
INFO - 2016-02-06 11:31:41 --> Model Class Initialized
INFO - 2016-02-06 11:31:41 --> Model Class Initialized
INFO - 2016-02-06 11:31:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:31:41 --> Pagination Class Initialized
INFO - 2016-02-06 11:31:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:31:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:31:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:31:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:31:41 --> Final output sent to browser
DEBUG - 2016-02-06 11:31:41 --> Total execution time: 1.1389
INFO - 2016-02-06 11:31:43 --> Config Class Initialized
INFO - 2016-02-06 11:31:43 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:31:43 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:31:43 --> Utf8 Class Initialized
INFO - 2016-02-06 11:31:43 --> URI Class Initialized
INFO - 2016-02-06 11:31:43 --> Router Class Initialized
INFO - 2016-02-06 11:31:43 --> Output Class Initialized
INFO - 2016-02-06 11:31:43 --> Security Class Initialized
DEBUG - 2016-02-06 11:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:31:43 --> Input Class Initialized
INFO - 2016-02-06 11:31:43 --> Language Class Initialized
INFO - 2016-02-06 11:31:43 --> Loader Class Initialized
INFO - 2016-02-06 11:31:43 --> Helper loaded: url_helper
INFO - 2016-02-06 11:31:43 --> Helper loaded: file_helper
INFO - 2016-02-06 11:31:43 --> Helper loaded: date_helper
INFO - 2016-02-06 11:31:43 --> Helper loaded: form_helper
INFO - 2016-02-06 11:31:43 --> Database Driver Class Initialized
INFO - 2016-02-06 11:31:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:31:44 --> Controller Class Initialized
INFO - 2016-02-06 11:31:44 --> Model Class Initialized
INFO - 2016-02-06 11:31:44 --> Model Class Initialized
INFO - 2016-02-06 11:31:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:31:44 --> Pagination Class Initialized
INFO - 2016-02-06 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:31:44 --> Helper loaded: text_helper
INFO - 2016-02-06 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:31:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:31:44 --> Final output sent to browser
DEBUG - 2016-02-06 11:31:44 --> Total execution time: 1.1647
INFO - 2016-02-06 11:34:59 --> Config Class Initialized
INFO - 2016-02-06 11:34:59 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:34:59 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:34:59 --> Utf8 Class Initialized
INFO - 2016-02-06 11:34:59 --> URI Class Initialized
DEBUG - 2016-02-06 11:34:59 --> No URI present. Default controller set.
INFO - 2016-02-06 11:34:59 --> Router Class Initialized
INFO - 2016-02-06 11:34:59 --> Output Class Initialized
INFO - 2016-02-06 11:34:59 --> Security Class Initialized
DEBUG - 2016-02-06 11:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:34:59 --> Input Class Initialized
INFO - 2016-02-06 11:34:59 --> Language Class Initialized
INFO - 2016-02-06 11:34:59 --> Loader Class Initialized
INFO - 2016-02-06 11:34:59 --> Helper loaded: url_helper
INFO - 2016-02-06 11:34:59 --> Helper loaded: file_helper
INFO - 2016-02-06 11:34:59 --> Helper loaded: date_helper
INFO - 2016-02-06 11:34:59 --> Helper loaded: form_helper
INFO - 2016-02-06 11:34:59 --> Database Driver Class Initialized
INFO - 2016-02-06 11:35:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:35:00 --> Controller Class Initialized
INFO - 2016-02-06 11:35:00 --> Model Class Initialized
INFO - 2016-02-06 11:35:00 --> Model Class Initialized
INFO - 2016-02-06 11:35:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:35:00 --> Pagination Class Initialized
ERROR - 2016-02-06 11:35:00 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:35:40 --> Config Class Initialized
INFO - 2016-02-06 11:35:40 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:35:40 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:35:40 --> Utf8 Class Initialized
INFO - 2016-02-06 11:35:40 --> URI Class Initialized
INFO - 2016-02-06 11:35:40 --> Router Class Initialized
INFO - 2016-02-06 11:35:40 --> Output Class Initialized
INFO - 2016-02-06 11:35:40 --> Security Class Initialized
DEBUG - 2016-02-06 11:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:35:40 --> Input Class Initialized
INFO - 2016-02-06 11:35:40 --> Language Class Initialized
INFO - 2016-02-06 11:35:40 --> Loader Class Initialized
INFO - 2016-02-06 11:35:40 --> Helper loaded: url_helper
INFO - 2016-02-06 11:35:40 --> Helper loaded: file_helper
INFO - 2016-02-06 11:35:40 --> Helper loaded: date_helper
INFO - 2016-02-06 11:35:40 --> Helper loaded: form_helper
INFO - 2016-02-06 11:35:40 --> Database Driver Class Initialized
INFO - 2016-02-06 11:35:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:35:41 --> Controller Class Initialized
INFO - 2016-02-06 11:35:41 --> Model Class Initialized
INFO - 2016-02-06 11:35:41 --> Model Class Initialized
INFO - 2016-02-06 11:35:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:35:41 --> Pagination Class Initialized
ERROR - 2016-02-06 11:35:41 --> Severity: Parsing Error --> syntax error, unexpected '',' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 37
INFO - 2016-02-06 11:35:54 --> Config Class Initialized
INFO - 2016-02-06 11:35:54 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:35:54 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:35:54 --> Utf8 Class Initialized
INFO - 2016-02-06 11:35:54 --> URI Class Initialized
INFO - 2016-02-06 11:35:54 --> Router Class Initialized
INFO - 2016-02-06 11:35:54 --> Output Class Initialized
INFO - 2016-02-06 11:35:54 --> Security Class Initialized
DEBUG - 2016-02-06 11:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:35:54 --> Input Class Initialized
INFO - 2016-02-06 11:35:54 --> Language Class Initialized
INFO - 2016-02-06 11:35:54 --> Loader Class Initialized
INFO - 2016-02-06 11:35:54 --> Helper loaded: url_helper
INFO - 2016-02-06 11:35:54 --> Helper loaded: file_helper
INFO - 2016-02-06 11:35:54 --> Helper loaded: date_helper
INFO - 2016-02-06 11:35:54 --> Helper loaded: form_helper
INFO - 2016-02-06 11:35:54 --> Database Driver Class Initialized
INFO - 2016-02-06 11:35:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:35:55 --> Controller Class Initialized
INFO - 2016-02-06 11:35:55 --> Model Class Initialized
INFO - 2016-02-06 11:35:55 --> Model Class Initialized
INFO - 2016-02-06 11:35:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:35:55 --> Pagination Class Initialized
ERROR - 2016-02-06 11:35:55 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:36:22 --> Config Class Initialized
INFO - 2016-02-06 11:36:22 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:36:22 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:36:22 --> Utf8 Class Initialized
INFO - 2016-02-06 11:36:22 --> URI Class Initialized
INFO - 2016-02-06 11:36:22 --> Router Class Initialized
INFO - 2016-02-06 11:36:22 --> Output Class Initialized
INFO - 2016-02-06 11:36:22 --> Security Class Initialized
DEBUG - 2016-02-06 11:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:36:22 --> Input Class Initialized
INFO - 2016-02-06 11:36:22 --> Language Class Initialized
INFO - 2016-02-06 11:36:22 --> Loader Class Initialized
INFO - 2016-02-06 11:36:22 --> Helper loaded: url_helper
INFO - 2016-02-06 11:36:22 --> Helper loaded: file_helper
INFO - 2016-02-06 11:36:22 --> Helper loaded: date_helper
INFO - 2016-02-06 11:36:22 --> Helper loaded: form_helper
INFO - 2016-02-06 11:36:22 --> Database Driver Class Initialized
INFO - 2016-02-06 11:36:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:36:23 --> Controller Class Initialized
INFO - 2016-02-06 11:36:23 --> Model Class Initialized
INFO - 2016-02-06 11:36:23 --> Model Class Initialized
INFO - 2016-02-06 11:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:36:23 --> Pagination Class Initialized
ERROR - 2016-02-06 11:36:23 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:36:49 --> Config Class Initialized
INFO - 2016-02-06 11:36:49 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:36:49 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:36:49 --> Utf8 Class Initialized
INFO - 2016-02-06 11:36:49 --> URI Class Initialized
INFO - 2016-02-06 11:36:49 --> Router Class Initialized
INFO - 2016-02-06 11:36:49 --> Output Class Initialized
INFO - 2016-02-06 11:36:49 --> Security Class Initialized
DEBUG - 2016-02-06 11:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:36:49 --> Input Class Initialized
INFO - 2016-02-06 11:36:49 --> Language Class Initialized
INFO - 2016-02-06 11:36:49 --> Loader Class Initialized
INFO - 2016-02-06 11:36:49 --> Helper loaded: url_helper
INFO - 2016-02-06 11:36:49 --> Helper loaded: file_helper
INFO - 2016-02-06 11:36:49 --> Helper loaded: date_helper
INFO - 2016-02-06 11:36:49 --> Helper loaded: form_helper
INFO - 2016-02-06 11:36:49 --> Database Driver Class Initialized
INFO - 2016-02-06 11:36:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:36:50 --> Controller Class Initialized
INFO - 2016-02-06 11:36:50 --> Model Class Initialized
INFO - 2016-02-06 11:36:50 --> Model Class Initialized
INFO - 2016-02-06 11:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:36:50 --> Pagination Class Initialized
ERROR - 2016-02-06 11:36:50 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:37:36 --> Config Class Initialized
INFO - 2016-02-06 11:37:36 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:37:36 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:37:36 --> Utf8 Class Initialized
INFO - 2016-02-06 11:37:36 --> URI Class Initialized
INFO - 2016-02-06 11:37:36 --> Router Class Initialized
INFO - 2016-02-06 11:37:36 --> Output Class Initialized
INFO - 2016-02-06 11:37:36 --> Security Class Initialized
DEBUG - 2016-02-06 11:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:37:36 --> Input Class Initialized
INFO - 2016-02-06 11:37:36 --> Language Class Initialized
INFO - 2016-02-06 11:37:36 --> Loader Class Initialized
INFO - 2016-02-06 11:37:36 --> Helper loaded: url_helper
INFO - 2016-02-06 11:37:36 --> Helper loaded: file_helper
INFO - 2016-02-06 11:37:36 --> Helper loaded: date_helper
INFO - 2016-02-06 11:37:36 --> Helper loaded: form_helper
INFO - 2016-02-06 11:37:36 --> Database Driver Class Initialized
INFO - 2016-02-06 11:37:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:37:37 --> Controller Class Initialized
INFO - 2016-02-06 11:37:37 --> Model Class Initialized
INFO - 2016-02-06 11:37:37 --> Model Class Initialized
INFO - 2016-02-06 11:37:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:37:37 --> Pagination Class Initialized
INFO - 2016-02-06 11:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:37:37 --> Helper loaded: text_helper
INFO - 2016-02-06 11:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:37:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:37:37 --> Final output sent to browser
DEBUG - 2016-02-06 11:37:37 --> Total execution time: 1.2463
INFO - 2016-02-06 11:37:45 --> Config Class Initialized
INFO - 2016-02-06 11:37:45 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:37:45 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:37:45 --> Utf8 Class Initialized
INFO - 2016-02-06 11:37:45 --> URI Class Initialized
INFO - 2016-02-06 11:37:45 --> Router Class Initialized
INFO - 2016-02-06 11:37:45 --> Output Class Initialized
INFO - 2016-02-06 11:37:45 --> Security Class Initialized
DEBUG - 2016-02-06 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:37:45 --> Input Class Initialized
INFO - 2016-02-06 11:37:45 --> Language Class Initialized
INFO - 2016-02-06 11:37:45 --> Loader Class Initialized
INFO - 2016-02-06 11:37:45 --> Helper loaded: url_helper
INFO - 2016-02-06 11:37:45 --> Helper loaded: file_helper
INFO - 2016-02-06 11:37:45 --> Helper loaded: date_helper
INFO - 2016-02-06 11:37:45 --> Helper loaded: form_helper
INFO - 2016-02-06 11:37:45 --> Database Driver Class Initialized
INFO - 2016-02-06 11:37:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:37:46 --> Controller Class Initialized
INFO - 2016-02-06 11:37:46 --> Model Class Initialized
INFO - 2016-02-06 11:37:46 --> Model Class Initialized
INFO - 2016-02-06 11:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:37:46 --> Pagination Class Initialized
INFO - 2016-02-06 11:37:46 --> Form Validation Class Initialized
INFO - 2016-02-06 11:37:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 11:37:46 --> Model Class Initialized
INFO - 2016-02-06 11:37:46 --> Final output sent to browser
DEBUG - 2016-02-06 11:37:46 --> Total execution time: 1.1728
INFO - 2016-02-06 11:43:40 --> Config Class Initialized
INFO - 2016-02-06 11:43:40 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:43:40 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:43:40 --> Utf8 Class Initialized
INFO - 2016-02-06 11:43:40 --> URI Class Initialized
DEBUG - 2016-02-06 11:43:40 --> No URI present. Default controller set.
INFO - 2016-02-06 11:43:40 --> Router Class Initialized
INFO - 2016-02-06 11:43:40 --> Output Class Initialized
INFO - 2016-02-06 11:43:40 --> Security Class Initialized
DEBUG - 2016-02-06 11:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:43:40 --> Input Class Initialized
INFO - 2016-02-06 11:43:40 --> Language Class Initialized
INFO - 2016-02-06 11:43:40 --> Loader Class Initialized
INFO - 2016-02-06 11:43:40 --> Helper loaded: url_helper
INFO - 2016-02-06 11:43:40 --> Helper loaded: file_helper
INFO - 2016-02-06 11:43:40 --> Helper loaded: date_helper
INFO - 2016-02-06 11:43:40 --> Helper loaded: form_helper
INFO - 2016-02-06 11:43:40 --> Database Driver Class Initialized
INFO - 2016-02-06 11:43:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:43:41 --> Controller Class Initialized
INFO - 2016-02-06 11:43:41 --> Model Class Initialized
INFO - 2016-02-06 11:43:41 --> Model Class Initialized
INFO - 2016-02-06 11:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:43:41 --> Pagination Class Initialized
ERROR - 2016-02-06 11:43:41 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:43:41 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:43:41 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:43:42 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:43:42 --> Final output sent to browser
DEBUG - 2016-02-06 11:43:42 --> Total execution time: 1.1434
INFO - 2016-02-06 11:43:43 --> Config Class Initialized
INFO - 2016-02-06 11:43:43 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:43:43 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:43:43 --> Utf8 Class Initialized
INFO - 2016-02-06 11:43:43 --> URI Class Initialized
INFO - 2016-02-06 11:43:43 --> Router Class Initialized
INFO - 2016-02-06 11:43:43 --> Output Class Initialized
INFO - 2016-02-06 11:43:43 --> Security Class Initialized
DEBUG - 2016-02-06 11:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:43:43 --> Input Class Initialized
INFO - 2016-02-06 11:43:43 --> Language Class Initialized
INFO - 2016-02-06 11:43:43 --> Loader Class Initialized
INFO - 2016-02-06 11:43:43 --> Helper loaded: url_helper
INFO - 2016-02-06 11:43:43 --> Helper loaded: file_helper
INFO - 2016-02-06 11:43:43 --> Helper loaded: date_helper
INFO - 2016-02-06 11:43:43 --> Helper loaded: form_helper
INFO - 2016-02-06 11:43:43 --> Database Driver Class Initialized
INFO - 2016-02-06 11:43:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:43:44 --> Controller Class Initialized
INFO - 2016-02-06 11:43:44 --> Model Class Initialized
INFO - 2016-02-06 11:43:44 --> Model Class Initialized
INFO - 2016-02-06 11:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:43:44 --> Pagination Class Initialized
ERROR - 2016-02-06 11:43:44 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:43:44 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:43:44 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:43:44 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:43:44 --> Helper loaded: text_helper
INFO - 2016-02-06 11:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:43:44 --> Final output sent to browser
DEBUG - 2016-02-06 11:43:44 --> Total execution time: 1.1720
INFO - 2016-02-06 11:43:47 --> Config Class Initialized
INFO - 2016-02-06 11:43:47 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:43:47 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:43:47 --> Utf8 Class Initialized
INFO - 2016-02-06 11:43:47 --> URI Class Initialized
INFO - 2016-02-06 11:43:47 --> Router Class Initialized
INFO - 2016-02-06 11:43:47 --> Output Class Initialized
INFO - 2016-02-06 11:43:47 --> Security Class Initialized
DEBUG - 2016-02-06 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:43:47 --> Input Class Initialized
INFO - 2016-02-06 11:43:47 --> Language Class Initialized
INFO - 2016-02-06 11:43:47 --> Loader Class Initialized
INFO - 2016-02-06 11:43:47 --> Helper loaded: url_helper
INFO - 2016-02-06 11:43:47 --> Helper loaded: file_helper
INFO - 2016-02-06 11:43:47 --> Helper loaded: date_helper
INFO - 2016-02-06 11:43:47 --> Helper loaded: form_helper
INFO - 2016-02-06 11:43:47 --> Database Driver Class Initialized
INFO - 2016-02-06 11:43:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:43:48 --> Controller Class Initialized
INFO - 2016-02-06 11:43:48 --> Model Class Initialized
INFO - 2016-02-06 11:43:48 --> Model Class Initialized
INFO - 2016-02-06 11:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:43:48 --> Pagination Class Initialized
INFO - 2016-02-06 11:43:48 --> Form Validation Class Initialized
INFO - 2016-02-06 11:43:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 11:43:48 --> Model Class Initialized
INFO - 2016-02-06 11:43:48 --> Final output sent to browser
DEBUG - 2016-02-06 11:43:48 --> Total execution time: 1.1723
INFO - 2016-02-06 11:44:37 --> Config Class Initialized
INFO - 2016-02-06 11:44:37 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:44:37 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:44:37 --> Utf8 Class Initialized
INFO - 2016-02-06 11:44:37 --> URI Class Initialized
INFO - 2016-02-06 11:44:37 --> Router Class Initialized
INFO - 2016-02-06 11:44:37 --> Output Class Initialized
INFO - 2016-02-06 11:44:37 --> Security Class Initialized
DEBUG - 2016-02-06 11:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:44:37 --> Input Class Initialized
INFO - 2016-02-06 11:44:37 --> Language Class Initialized
INFO - 2016-02-06 11:44:37 --> Loader Class Initialized
INFO - 2016-02-06 11:44:37 --> Helper loaded: url_helper
INFO - 2016-02-06 11:44:37 --> Helper loaded: file_helper
INFO - 2016-02-06 11:44:37 --> Helper loaded: date_helper
INFO - 2016-02-06 11:44:37 --> Helper loaded: form_helper
INFO - 2016-02-06 11:44:37 --> Database Driver Class Initialized
INFO - 2016-02-06 11:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:44:38 --> Controller Class Initialized
INFO - 2016-02-06 11:44:38 --> Model Class Initialized
INFO - 2016-02-06 11:44:38 --> Model Class Initialized
INFO - 2016-02-06 11:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:44:38 --> Pagination Class Initialized
ERROR - 2016-02-06 11:44:38 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:38 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:38 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:38 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:44:38 --> Helper loaded: text_helper
INFO - 2016-02-06 11:44:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:44:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:44:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:44:39 --> Final output sent to browser
DEBUG - 2016-02-06 11:44:39 --> Total execution time: 1.2416
INFO - 2016-02-06 11:44:41 --> Config Class Initialized
INFO - 2016-02-06 11:44:41 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:44:41 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:44:41 --> Utf8 Class Initialized
INFO - 2016-02-06 11:44:41 --> URI Class Initialized
DEBUG - 2016-02-06 11:44:41 --> No URI present. Default controller set.
INFO - 2016-02-06 11:44:41 --> Router Class Initialized
INFO - 2016-02-06 11:44:41 --> Output Class Initialized
INFO - 2016-02-06 11:44:41 --> Security Class Initialized
DEBUG - 2016-02-06 11:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:44:41 --> Input Class Initialized
INFO - 2016-02-06 11:44:41 --> Language Class Initialized
INFO - 2016-02-06 11:44:41 --> Loader Class Initialized
INFO - 2016-02-06 11:44:41 --> Helper loaded: url_helper
INFO - 2016-02-06 11:44:41 --> Helper loaded: file_helper
INFO - 2016-02-06 11:44:41 --> Helper loaded: date_helper
INFO - 2016-02-06 11:44:41 --> Helper loaded: form_helper
INFO - 2016-02-06 11:44:41 --> Database Driver Class Initialized
INFO - 2016-02-06 11:44:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:44:42 --> Controller Class Initialized
INFO - 2016-02-06 11:44:42 --> Model Class Initialized
INFO - 2016-02-06 11:44:42 --> Model Class Initialized
INFO - 2016-02-06 11:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:44:42 --> Pagination Class Initialized
ERROR - 2016-02-06 11:44:42 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:42 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:42 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:42 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 11:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:44:42 --> Final output sent to browser
DEBUG - 2016-02-06 11:44:42 --> Total execution time: 1.1551
INFO - 2016-02-06 11:44:43 --> Config Class Initialized
INFO - 2016-02-06 11:44:43 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:44:43 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:44:43 --> Utf8 Class Initialized
INFO - 2016-02-06 11:44:43 --> URI Class Initialized
INFO - 2016-02-06 11:44:43 --> Router Class Initialized
INFO - 2016-02-06 11:44:43 --> Output Class Initialized
INFO - 2016-02-06 11:44:43 --> Security Class Initialized
DEBUG - 2016-02-06 11:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:44:43 --> Input Class Initialized
INFO - 2016-02-06 11:44:43 --> Language Class Initialized
INFO - 2016-02-06 11:44:43 --> Loader Class Initialized
INFO - 2016-02-06 11:44:44 --> Helper loaded: url_helper
INFO - 2016-02-06 11:44:44 --> Helper loaded: file_helper
INFO - 2016-02-06 11:44:44 --> Helper loaded: date_helper
INFO - 2016-02-06 11:44:44 --> Helper loaded: form_helper
INFO - 2016-02-06 11:44:44 --> Database Driver Class Initialized
INFO - 2016-02-06 11:44:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:44:45 --> Controller Class Initialized
INFO - 2016-02-06 11:44:45 --> Model Class Initialized
INFO - 2016-02-06 11:44:45 --> Model Class Initialized
INFO - 2016-02-06 11:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:44:45 --> Pagination Class Initialized
ERROR - 2016-02-06 11:44:45 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:45 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:45 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:45 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:44:45 --> Helper loaded: text_helper
INFO - 2016-02-06 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:44:45 --> Final output sent to browser
DEBUG - 2016-02-06 11:44:45 --> Total execution time: 1.2470
INFO - 2016-02-06 11:44:52 --> Config Class Initialized
INFO - 2016-02-06 11:44:52 --> Hooks Class Initialized
DEBUG - 2016-02-06 11:44:52 --> UTF-8 Support Enabled
INFO - 2016-02-06 11:44:52 --> Utf8 Class Initialized
INFO - 2016-02-06 11:44:52 --> URI Class Initialized
INFO - 2016-02-06 11:44:52 --> Router Class Initialized
INFO - 2016-02-06 11:44:52 --> Output Class Initialized
INFO - 2016-02-06 11:44:52 --> Security Class Initialized
DEBUG - 2016-02-06 11:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 11:44:52 --> Input Class Initialized
INFO - 2016-02-06 11:44:52 --> Language Class Initialized
INFO - 2016-02-06 11:44:52 --> Loader Class Initialized
INFO - 2016-02-06 11:44:52 --> Helper loaded: url_helper
INFO - 2016-02-06 11:44:52 --> Helper loaded: file_helper
INFO - 2016-02-06 11:44:52 --> Helper loaded: date_helper
INFO - 2016-02-06 11:44:52 --> Helper loaded: form_helper
INFO - 2016-02-06 11:44:52 --> Database Driver Class Initialized
INFO - 2016-02-06 11:44:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 11:44:53 --> Controller Class Initialized
INFO - 2016-02-06 11:44:53 --> Model Class Initialized
INFO - 2016-02-06 11:44:53 --> Model Class Initialized
INFO - 2016-02-06 11:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 11:44:53 --> Pagination Class Initialized
ERROR - 2016-02-06 11:44:53 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:53 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:53 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 11:44:53 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 11:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 11:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 11:44:53 --> Helper loaded: text_helper
INFO - 2016-02-06 11:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 11:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 11:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 11:44:53 --> Final output sent to browser
DEBUG - 2016-02-06 11:44:53 --> Total execution time: 1.2787
INFO - 2016-02-06 12:06:07 --> Config Class Initialized
INFO - 2016-02-06 12:06:07 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:06:07 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:06:07 --> Utf8 Class Initialized
INFO - 2016-02-06 12:06:07 --> URI Class Initialized
DEBUG - 2016-02-06 12:06:07 --> No URI present. Default controller set.
INFO - 2016-02-06 12:06:07 --> Router Class Initialized
INFO - 2016-02-06 12:06:07 --> Output Class Initialized
INFO - 2016-02-06 12:06:07 --> Security Class Initialized
DEBUG - 2016-02-06 12:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:06:07 --> Input Class Initialized
INFO - 2016-02-06 12:06:07 --> Language Class Initialized
INFO - 2016-02-06 12:06:08 --> Loader Class Initialized
INFO - 2016-02-06 12:06:08 --> Helper loaded: url_helper
INFO - 2016-02-06 12:06:08 --> Helper loaded: file_helper
INFO - 2016-02-06 12:06:08 --> Helper loaded: date_helper
INFO - 2016-02-06 12:06:08 --> Helper loaded: form_helper
INFO - 2016-02-06 12:06:08 --> Database Driver Class Initialized
INFO - 2016-02-06 12:06:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:06:09 --> Controller Class Initialized
INFO - 2016-02-06 12:06:09 --> Model Class Initialized
INFO - 2016-02-06 12:06:09 --> Model Class Initialized
INFO - 2016-02-06 12:06:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:06:09 --> Pagination Class Initialized
ERROR - 2016-02-06 12:06:09 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:09 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:09 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:09 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:06:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:06:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:06:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:06:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:06:09 --> Final output sent to browser
DEBUG - 2016-02-06 12:06:09 --> Total execution time: 1.7609
INFO - 2016-02-06 12:06:11 --> Config Class Initialized
INFO - 2016-02-06 12:06:11 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:06:11 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:06:11 --> Utf8 Class Initialized
INFO - 2016-02-06 12:06:11 --> URI Class Initialized
INFO - 2016-02-06 12:06:11 --> Router Class Initialized
INFO - 2016-02-06 12:06:11 --> Output Class Initialized
INFO - 2016-02-06 12:06:11 --> Security Class Initialized
DEBUG - 2016-02-06 12:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:06:11 --> Input Class Initialized
INFO - 2016-02-06 12:06:11 --> Language Class Initialized
INFO - 2016-02-06 12:06:11 --> Loader Class Initialized
INFO - 2016-02-06 12:06:11 --> Helper loaded: url_helper
INFO - 2016-02-06 12:06:11 --> Helper loaded: file_helper
INFO - 2016-02-06 12:06:11 --> Helper loaded: date_helper
INFO - 2016-02-06 12:06:11 --> Helper loaded: form_helper
INFO - 2016-02-06 12:06:11 --> Database Driver Class Initialized
INFO - 2016-02-06 12:06:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:06:12 --> Controller Class Initialized
INFO - 2016-02-06 12:06:12 --> Model Class Initialized
INFO - 2016-02-06 12:06:12 --> Model Class Initialized
INFO - 2016-02-06 12:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:06:12 --> Pagination Class Initialized
ERROR - 2016-02-06 12:06:12 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:12 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:12 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:12 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:06:12 --> Helper loaded: text_helper
INFO - 2016-02-06 12:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:06:12 --> Final output sent to browser
DEBUG - 2016-02-06 12:06:12 --> Total execution time: 1.2639
INFO - 2016-02-06 12:06:16 --> Config Class Initialized
INFO - 2016-02-06 12:06:16 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:06:16 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:06:16 --> Utf8 Class Initialized
INFO - 2016-02-06 12:06:16 --> URI Class Initialized
INFO - 2016-02-06 12:06:16 --> Router Class Initialized
INFO - 2016-02-06 12:06:16 --> Output Class Initialized
INFO - 2016-02-06 12:06:16 --> Security Class Initialized
DEBUG - 2016-02-06 12:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:06:16 --> Input Class Initialized
INFO - 2016-02-06 12:06:16 --> Language Class Initialized
INFO - 2016-02-06 12:06:16 --> Loader Class Initialized
INFO - 2016-02-06 12:06:16 --> Helper loaded: url_helper
INFO - 2016-02-06 12:06:16 --> Helper loaded: file_helper
INFO - 2016-02-06 12:06:16 --> Helper loaded: date_helper
INFO - 2016-02-06 12:06:16 --> Helper loaded: form_helper
INFO - 2016-02-06 12:06:16 --> Database Driver Class Initialized
INFO - 2016-02-06 12:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:06:17 --> Controller Class Initialized
INFO - 2016-02-06 12:06:17 --> Model Class Initialized
INFO - 2016-02-06 12:06:17 --> Model Class Initialized
INFO - 2016-02-06 12:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:06:17 --> Pagination Class Initialized
ERROR - 2016-02-06 12:06:17 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:17 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:17 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:06:17 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:06:17 --> Helper loaded: text_helper
INFO - 2016-02-06 12:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:06:17 --> Final output sent to browser
DEBUG - 2016-02-06 12:06:17 --> Total execution time: 1.2483
INFO - 2016-02-06 12:07:04 --> Config Class Initialized
INFO - 2016-02-06 12:07:04 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:07:04 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:07:04 --> Utf8 Class Initialized
INFO - 2016-02-06 12:07:04 --> URI Class Initialized
INFO - 2016-02-06 12:07:04 --> Router Class Initialized
INFO - 2016-02-06 12:07:04 --> Output Class Initialized
INFO - 2016-02-06 12:07:04 --> Security Class Initialized
DEBUG - 2016-02-06 12:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:07:04 --> Input Class Initialized
INFO - 2016-02-06 12:07:04 --> Language Class Initialized
INFO - 2016-02-06 12:07:04 --> Loader Class Initialized
INFO - 2016-02-06 12:07:04 --> Helper loaded: url_helper
INFO - 2016-02-06 12:07:04 --> Helper loaded: file_helper
INFO - 2016-02-06 12:07:04 --> Helper loaded: date_helper
INFO - 2016-02-06 12:07:04 --> Helper loaded: form_helper
INFO - 2016-02-06 12:07:04 --> Database Driver Class Initialized
INFO - 2016-02-06 12:07:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:07:05 --> Controller Class Initialized
INFO - 2016-02-06 12:07:05 --> Model Class Initialized
INFO - 2016-02-06 12:07:05 --> Model Class Initialized
INFO - 2016-02-06 12:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:07:05 --> Pagination Class Initialized
ERROR - 2016-02-06 12:07:05 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:07:05 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:07:05 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:07:05 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:07:05 --> Helper loaded: text_helper
INFO - 2016-02-06 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:07:05 --> Final output sent to browser
DEBUG - 2016-02-06 12:07:05 --> Total execution time: 1.2396
INFO - 2016-02-06 12:07:47 --> Config Class Initialized
INFO - 2016-02-06 12:07:47 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:07:47 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:07:47 --> Utf8 Class Initialized
INFO - 2016-02-06 12:07:47 --> URI Class Initialized
DEBUG - 2016-02-06 12:07:47 --> No URI present. Default controller set.
INFO - 2016-02-06 12:07:47 --> Router Class Initialized
INFO - 2016-02-06 12:07:47 --> Output Class Initialized
INFO - 2016-02-06 12:07:47 --> Security Class Initialized
DEBUG - 2016-02-06 12:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:07:47 --> Input Class Initialized
INFO - 2016-02-06 12:07:47 --> Language Class Initialized
INFO - 2016-02-06 12:07:47 --> Loader Class Initialized
INFO - 2016-02-06 12:07:47 --> Helper loaded: url_helper
INFO - 2016-02-06 12:07:47 --> Helper loaded: file_helper
INFO - 2016-02-06 12:07:47 --> Helper loaded: date_helper
INFO - 2016-02-06 12:07:47 --> Helper loaded: form_helper
INFO - 2016-02-06 12:07:47 --> Database Driver Class Initialized
INFO - 2016-02-06 12:07:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:07:48 --> Controller Class Initialized
INFO - 2016-02-06 12:07:48 --> Model Class Initialized
INFO - 2016-02-06 12:07:48 --> Model Class Initialized
INFO - 2016-02-06 12:07:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:07:48 --> Pagination Class Initialized
ERROR - 2016-02-06 12:07:48 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:08:00 --> Config Class Initialized
INFO - 2016-02-06 12:08:00 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:08:00 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:08:00 --> Utf8 Class Initialized
INFO - 2016-02-06 12:08:00 --> URI Class Initialized
DEBUG - 2016-02-06 12:08:00 --> No URI present. Default controller set.
INFO - 2016-02-06 12:08:00 --> Router Class Initialized
INFO - 2016-02-06 12:08:00 --> Output Class Initialized
INFO - 2016-02-06 12:08:00 --> Security Class Initialized
DEBUG - 2016-02-06 12:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:08:00 --> Input Class Initialized
INFO - 2016-02-06 12:08:00 --> Language Class Initialized
INFO - 2016-02-06 12:08:00 --> Loader Class Initialized
INFO - 2016-02-06 12:08:00 --> Helper loaded: url_helper
INFO - 2016-02-06 12:08:00 --> Helper loaded: file_helper
INFO - 2016-02-06 12:08:00 --> Helper loaded: date_helper
INFO - 2016-02-06 12:08:00 --> Helper loaded: form_helper
INFO - 2016-02-06 12:08:00 --> Database Driver Class Initialized
INFO - 2016-02-06 12:08:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:08:01 --> Controller Class Initialized
INFO - 2016-02-06 12:08:01 --> Model Class Initialized
INFO - 2016-02-06 12:08:01 --> Model Class Initialized
INFO - 2016-02-06 12:08:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:08:01 --> Pagination Class Initialized
ERROR - 2016-02-06 12:08:01 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:01 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:01 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:01 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:08:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:08:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:08:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:08:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:08:01 --> Final output sent to browser
DEBUG - 2016-02-06 12:08:01 --> Total execution time: 1.1619
INFO - 2016-02-06 12:08:03 --> Config Class Initialized
INFO - 2016-02-06 12:08:03 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:08:03 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:08:03 --> Utf8 Class Initialized
INFO - 2016-02-06 12:08:03 --> URI Class Initialized
DEBUG - 2016-02-06 12:08:03 --> No URI present. Default controller set.
INFO - 2016-02-06 12:08:03 --> Router Class Initialized
INFO - 2016-02-06 12:08:03 --> Output Class Initialized
INFO - 2016-02-06 12:08:03 --> Security Class Initialized
DEBUG - 2016-02-06 12:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:08:03 --> Input Class Initialized
INFO - 2016-02-06 12:08:03 --> Language Class Initialized
INFO - 2016-02-06 12:08:03 --> Loader Class Initialized
INFO - 2016-02-06 12:08:03 --> Helper loaded: url_helper
INFO - 2016-02-06 12:08:03 --> Helper loaded: file_helper
INFO - 2016-02-06 12:08:03 --> Helper loaded: date_helper
INFO - 2016-02-06 12:08:03 --> Helper loaded: form_helper
INFO - 2016-02-06 12:08:03 --> Database Driver Class Initialized
INFO - 2016-02-06 12:08:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:08:04 --> Controller Class Initialized
INFO - 2016-02-06 12:08:04 --> Model Class Initialized
INFO - 2016-02-06 12:08:04 --> Model Class Initialized
INFO - 2016-02-06 12:08:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:08:04 --> Pagination Class Initialized
ERROR - 2016-02-06 12:08:04 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:04 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:04 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:04 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:08:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:08:04 --> Final output sent to browser
DEBUG - 2016-02-06 12:08:04 --> Total execution time: 1.1465
INFO - 2016-02-06 12:08:07 --> Config Class Initialized
INFO - 2016-02-06 12:08:07 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:08:07 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:08:07 --> Utf8 Class Initialized
INFO - 2016-02-06 12:08:07 --> URI Class Initialized
INFO - 2016-02-06 12:08:07 --> Router Class Initialized
INFO - 2016-02-06 12:08:07 --> Output Class Initialized
INFO - 2016-02-06 12:08:07 --> Security Class Initialized
DEBUG - 2016-02-06 12:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:08:07 --> Input Class Initialized
INFO - 2016-02-06 12:08:07 --> Language Class Initialized
INFO - 2016-02-06 12:08:07 --> Loader Class Initialized
INFO - 2016-02-06 12:08:07 --> Helper loaded: url_helper
INFO - 2016-02-06 12:08:07 --> Helper loaded: file_helper
INFO - 2016-02-06 12:08:07 --> Helper loaded: date_helper
INFO - 2016-02-06 12:08:07 --> Helper loaded: form_helper
INFO - 2016-02-06 12:08:07 --> Database Driver Class Initialized
INFO - 2016-02-06 12:08:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:08:08 --> Controller Class Initialized
INFO - 2016-02-06 12:08:08 --> Model Class Initialized
INFO - 2016-02-06 12:08:08 --> Model Class Initialized
INFO - 2016-02-06 12:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:08:08 --> Pagination Class Initialized
ERROR - 2016-02-06 12:08:08 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:08 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:08 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:08 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:08:08 --> Helper loaded: text_helper
INFO - 2016-02-06 12:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:08:08 --> Final output sent to browser
DEBUG - 2016-02-06 12:08:08 --> Total execution time: 1.1751
INFO - 2016-02-06 12:08:18 --> Config Class Initialized
INFO - 2016-02-06 12:08:18 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:08:18 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:08:18 --> Utf8 Class Initialized
INFO - 2016-02-06 12:08:18 --> URI Class Initialized
INFO - 2016-02-06 12:08:18 --> Router Class Initialized
INFO - 2016-02-06 12:08:18 --> Output Class Initialized
INFO - 2016-02-06 12:08:18 --> Security Class Initialized
DEBUG - 2016-02-06 12:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:08:18 --> Input Class Initialized
INFO - 2016-02-06 12:08:18 --> Language Class Initialized
INFO - 2016-02-06 12:08:18 --> Loader Class Initialized
INFO - 2016-02-06 12:08:18 --> Helper loaded: url_helper
INFO - 2016-02-06 12:08:18 --> Helper loaded: file_helper
INFO - 2016-02-06 12:08:19 --> Helper loaded: date_helper
INFO - 2016-02-06 12:08:19 --> Helper loaded: form_helper
INFO - 2016-02-06 12:08:19 --> Database Driver Class Initialized
INFO - 2016-02-06 12:08:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:08:20 --> Controller Class Initialized
INFO - 2016-02-06 12:08:20 --> Model Class Initialized
INFO - 2016-02-06 12:08:20 --> Model Class Initialized
INFO - 2016-02-06 12:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:08:20 --> Pagination Class Initialized
ERROR - 2016-02-06 12:08:20 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:20 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:20 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:08:20 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:08:20 --> Helper loaded: text_helper
INFO - 2016-02-06 12:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:08:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:08:20 --> Final output sent to browser
DEBUG - 2016-02-06 12:08:20 --> Total execution time: 1.3837
INFO - 2016-02-06 12:09:23 --> Config Class Initialized
INFO - 2016-02-06 12:09:23 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:09:23 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:09:23 --> Utf8 Class Initialized
INFO - 2016-02-06 12:09:23 --> URI Class Initialized
INFO - 2016-02-06 12:09:23 --> Router Class Initialized
INFO - 2016-02-06 12:09:23 --> Output Class Initialized
INFO - 2016-02-06 12:09:23 --> Security Class Initialized
DEBUG - 2016-02-06 12:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:09:24 --> Input Class Initialized
INFO - 2016-02-06 12:09:24 --> Language Class Initialized
INFO - 2016-02-06 12:09:24 --> Loader Class Initialized
INFO - 2016-02-06 12:09:24 --> Helper loaded: url_helper
INFO - 2016-02-06 12:09:24 --> Helper loaded: file_helper
INFO - 2016-02-06 12:09:24 --> Helper loaded: date_helper
INFO - 2016-02-06 12:09:24 --> Helper loaded: form_helper
INFO - 2016-02-06 12:09:24 --> Database Driver Class Initialized
INFO - 2016-02-06 12:09:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:09:25 --> Controller Class Initialized
INFO - 2016-02-06 12:09:25 --> Model Class Initialized
INFO - 2016-02-06 12:09:25 --> Model Class Initialized
INFO - 2016-02-06 12:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:09:25 --> Pagination Class Initialized
ERROR - 2016-02-06 12:09:25 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:09:25 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:09:25 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:09:25 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:09:25 --> Helper loaded: text_helper
INFO - 2016-02-06 12:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:09:25 --> Final output sent to browser
DEBUG - 2016-02-06 12:09:25 --> Total execution time: 1.2353
INFO - 2016-02-06 12:10:12 --> Config Class Initialized
INFO - 2016-02-06 12:10:12 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:10:12 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:10:12 --> Utf8 Class Initialized
INFO - 2016-02-06 12:10:12 --> URI Class Initialized
INFO - 2016-02-06 12:10:12 --> Router Class Initialized
INFO - 2016-02-06 12:10:12 --> Output Class Initialized
INFO - 2016-02-06 12:10:12 --> Security Class Initialized
DEBUG - 2016-02-06 12:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:10:12 --> Input Class Initialized
INFO - 2016-02-06 12:10:12 --> Language Class Initialized
INFO - 2016-02-06 12:10:12 --> Loader Class Initialized
INFO - 2016-02-06 12:10:12 --> Helper loaded: url_helper
INFO - 2016-02-06 12:10:12 --> Helper loaded: file_helper
INFO - 2016-02-06 12:10:12 --> Helper loaded: date_helper
INFO - 2016-02-06 12:10:12 --> Helper loaded: form_helper
INFO - 2016-02-06 12:10:12 --> Database Driver Class Initialized
INFO - 2016-02-06 12:10:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:10:13 --> Controller Class Initialized
INFO - 2016-02-06 12:10:13 --> Model Class Initialized
INFO - 2016-02-06 12:10:13 --> Model Class Initialized
INFO - 2016-02-06 12:10:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:10:13 --> Pagination Class Initialized
ERROR - 2016-02-06 12:10:13 --> Severity: Parsing Error --> syntax error, unexpected 'jboard' (T_STRING), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:10:35 --> Config Class Initialized
INFO - 2016-02-06 12:10:35 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:10:35 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:10:35 --> Utf8 Class Initialized
INFO - 2016-02-06 12:10:35 --> URI Class Initialized
INFO - 2016-02-06 12:10:35 --> Router Class Initialized
INFO - 2016-02-06 12:10:35 --> Output Class Initialized
INFO - 2016-02-06 12:10:35 --> Security Class Initialized
DEBUG - 2016-02-06 12:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:10:35 --> Input Class Initialized
INFO - 2016-02-06 12:10:35 --> Language Class Initialized
INFO - 2016-02-06 12:10:35 --> Loader Class Initialized
INFO - 2016-02-06 12:10:35 --> Helper loaded: url_helper
INFO - 2016-02-06 12:10:35 --> Helper loaded: file_helper
INFO - 2016-02-06 12:10:35 --> Helper loaded: date_helper
INFO - 2016-02-06 12:10:35 --> Helper loaded: form_helper
INFO - 2016-02-06 12:10:35 --> Database Driver Class Initialized
INFO - 2016-02-06 12:10:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:10:36 --> Controller Class Initialized
INFO - 2016-02-06 12:10:36 --> Model Class Initialized
INFO - 2016-02-06 12:10:36 --> Model Class Initialized
INFO - 2016-02-06 12:10:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:10:36 --> Pagination Class Initialized
ERROR - 2016-02-06 12:10:36 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:10:36 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:10:36 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:10:36 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:10:36 --> Helper loaded: text_helper
INFO - 2016-02-06 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:10:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:10:36 --> Final output sent to browser
DEBUG - 2016-02-06 12:10:36 --> Total execution time: 1.2119
INFO - 2016-02-06 12:10:43 --> Config Class Initialized
INFO - 2016-02-06 12:10:43 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:10:43 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:10:43 --> Utf8 Class Initialized
INFO - 2016-02-06 12:10:43 --> URI Class Initialized
INFO - 2016-02-06 12:10:43 --> Router Class Initialized
INFO - 2016-02-06 12:10:43 --> Output Class Initialized
INFO - 2016-02-06 12:10:43 --> Security Class Initialized
DEBUG - 2016-02-06 12:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:10:43 --> Input Class Initialized
INFO - 2016-02-06 12:10:43 --> Language Class Initialized
INFO - 2016-02-06 12:10:43 --> Loader Class Initialized
INFO - 2016-02-06 12:10:43 --> Helper loaded: url_helper
INFO - 2016-02-06 12:10:43 --> Helper loaded: file_helper
INFO - 2016-02-06 12:10:43 --> Helper loaded: date_helper
INFO - 2016-02-06 12:10:43 --> Helper loaded: form_helper
INFO - 2016-02-06 12:10:43 --> Database Driver Class Initialized
INFO - 2016-02-06 12:10:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:10:44 --> Controller Class Initialized
INFO - 2016-02-06 12:10:44 --> Model Class Initialized
INFO - 2016-02-06 12:10:44 --> Model Class Initialized
INFO - 2016-02-06 12:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:10:44 --> Pagination Class Initialized
ERROR - 2016-02-06 12:10:44 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:10:44 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:10:44 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:10:44 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:10:44 --> Helper loaded: text_helper
INFO - 2016-02-06 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:10:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:10:44 --> Final output sent to browser
DEBUG - 2016-02-06 12:10:44 --> Total execution time: 1.2291
INFO - 2016-02-06 12:11:51 --> Config Class Initialized
INFO - 2016-02-06 12:11:51 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:11:51 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:11:51 --> Utf8 Class Initialized
INFO - 2016-02-06 12:11:51 --> URI Class Initialized
DEBUG - 2016-02-06 12:11:51 --> No URI present. Default controller set.
INFO - 2016-02-06 12:11:51 --> Router Class Initialized
INFO - 2016-02-06 12:11:51 --> Output Class Initialized
INFO - 2016-02-06 12:11:51 --> Security Class Initialized
DEBUG - 2016-02-06 12:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:11:51 --> Input Class Initialized
INFO - 2016-02-06 12:11:51 --> Language Class Initialized
INFO - 2016-02-06 12:11:51 --> Loader Class Initialized
INFO - 2016-02-06 12:11:51 --> Helper loaded: url_helper
INFO - 2016-02-06 12:11:51 --> Helper loaded: file_helper
INFO - 2016-02-06 12:11:51 --> Helper loaded: date_helper
INFO - 2016-02-06 12:11:51 --> Helper loaded: form_helper
INFO - 2016-02-06 12:11:51 --> Database Driver Class Initialized
INFO - 2016-02-06 12:11:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:11:52 --> Controller Class Initialized
INFO - 2016-02-06 12:11:52 --> Model Class Initialized
INFO - 2016-02-06 12:11:52 --> Model Class Initialized
INFO - 2016-02-06 12:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:11:52 --> Pagination Class Initialized
INFO - 2016-02-06 12:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:11:52 --> Final output sent to browser
DEBUG - 2016-02-06 12:11:52 --> Total execution time: 1.1279
INFO - 2016-02-06 12:11:54 --> Config Class Initialized
INFO - 2016-02-06 12:11:54 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:11:54 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:11:54 --> Utf8 Class Initialized
INFO - 2016-02-06 12:11:54 --> URI Class Initialized
INFO - 2016-02-06 12:11:54 --> Router Class Initialized
INFO - 2016-02-06 12:11:54 --> Output Class Initialized
INFO - 2016-02-06 12:11:54 --> Security Class Initialized
DEBUG - 2016-02-06 12:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:11:54 --> Input Class Initialized
INFO - 2016-02-06 12:11:54 --> Language Class Initialized
INFO - 2016-02-06 12:11:54 --> Loader Class Initialized
INFO - 2016-02-06 12:11:54 --> Helper loaded: url_helper
INFO - 2016-02-06 12:11:54 --> Helper loaded: file_helper
INFO - 2016-02-06 12:11:54 --> Helper loaded: date_helper
INFO - 2016-02-06 12:11:54 --> Helper loaded: form_helper
INFO - 2016-02-06 12:11:54 --> Database Driver Class Initialized
INFO - 2016-02-06 12:11:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:11:55 --> Controller Class Initialized
INFO - 2016-02-06 12:11:55 --> Model Class Initialized
INFO - 2016-02-06 12:11:55 --> Model Class Initialized
INFO - 2016-02-06 12:11:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:11:55 --> Pagination Class Initialized
INFO - 2016-02-06 12:11:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:11:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:11:55 --> Helper loaded: text_helper
INFO - 2016-02-06 12:11:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:11:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:11:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:11:55 --> Final output sent to browser
DEBUG - 2016-02-06 12:11:55 --> Total execution time: 1.1773
INFO - 2016-02-06 12:11:59 --> Config Class Initialized
INFO - 2016-02-06 12:11:59 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:11:59 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:11:59 --> Utf8 Class Initialized
INFO - 2016-02-06 12:11:59 --> URI Class Initialized
INFO - 2016-02-06 12:11:59 --> Router Class Initialized
INFO - 2016-02-06 12:11:59 --> Output Class Initialized
INFO - 2016-02-06 12:11:59 --> Security Class Initialized
DEBUG - 2016-02-06 12:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:11:59 --> Input Class Initialized
INFO - 2016-02-06 12:11:59 --> Language Class Initialized
INFO - 2016-02-06 12:11:59 --> Loader Class Initialized
INFO - 2016-02-06 12:11:59 --> Helper loaded: url_helper
INFO - 2016-02-06 12:11:59 --> Helper loaded: file_helper
INFO - 2016-02-06 12:11:59 --> Helper loaded: date_helper
INFO - 2016-02-06 12:11:59 --> Helper loaded: form_helper
INFO - 2016-02-06 12:11:59 --> Database Driver Class Initialized
INFO - 2016-02-06 12:12:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:12:00 --> Controller Class Initialized
INFO - 2016-02-06 12:12:00 --> Model Class Initialized
INFO - 2016-02-06 12:12:00 --> Model Class Initialized
INFO - 2016-02-06 12:12:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:12:00 --> Pagination Class Initialized
INFO - 2016-02-06 12:12:00 --> Form Validation Class Initialized
INFO - 2016-02-06 12:12:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 12:12:00 --> Model Class Initialized
INFO - 2016-02-06 12:12:00 --> Final output sent to browser
DEBUG - 2016-02-06 12:12:00 --> Total execution time: 1.2135
INFO - 2016-02-06 12:12:37 --> Config Class Initialized
INFO - 2016-02-06 12:12:37 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:12:37 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:12:37 --> Utf8 Class Initialized
INFO - 2016-02-06 12:12:37 --> URI Class Initialized
INFO - 2016-02-06 12:12:37 --> Router Class Initialized
INFO - 2016-02-06 12:12:37 --> Output Class Initialized
INFO - 2016-02-06 12:12:37 --> Security Class Initialized
DEBUG - 2016-02-06 12:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:12:37 --> Input Class Initialized
INFO - 2016-02-06 12:12:37 --> Language Class Initialized
INFO - 2016-02-06 12:12:37 --> Loader Class Initialized
INFO - 2016-02-06 12:12:37 --> Helper loaded: url_helper
INFO - 2016-02-06 12:12:37 --> Helper loaded: file_helper
INFO - 2016-02-06 12:12:37 --> Helper loaded: date_helper
INFO - 2016-02-06 12:12:37 --> Helper loaded: form_helper
INFO - 2016-02-06 12:12:37 --> Database Driver Class Initialized
INFO - 2016-02-06 12:12:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:12:38 --> Controller Class Initialized
INFO - 2016-02-06 12:12:38 --> Model Class Initialized
INFO - 2016-02-06 12:12:38 --> Model Class Initialized
INFO - 2016-02-06 12:12:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:12:38 --> Pagination Class Initialized
INFO - 2016-02-06 12:12:38 --> Form Validation Class Initialized
INFO - 2016-02-06 12:12:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 12:12:38 --> Model Class Initialized
INFO - 2016-02-06 12:12:38 --> Final output sent to browser
DEBUG - 2016-02-06 12:12:38 --> Total execution time: 1.1770
INFO - 2016-02-06 12:13:21 --> Config Class Initialized
INFO - 2016-02-06 12:13:21 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:13:21 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:13:21 --> Utf8 Class Initialized
INFO - 2016-02-06 12:13:21 --> URI Class Initialized
INFO - 2016-02-06 12:13:21 --> Router Class Initialized
INFO - 2016-02-06 12:13:21 --> Output Class Initialized
INFO - 2016-02-06 12:13:21 --> Security Class Initialized
DEBUG - 2016-02-06 12:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:13:21 --> Input Class Initialized
INFO - 2016-02-06 12:13:21 --> Language Class Initialized
INFO - 2016-02-06 12:13:21 --> Loader Class Initialized
INFO - 2016-02-06 12:13:21 --> Helper loaded: url_helper
INFO - 2016-02-06 12:13:21 --> Helper loaded: file_helper
INFO - 2016-02-06 12:13:21 --> Helper loaded: date_helper
INFO - 2016-02-06 12:13:21 --> Helper loaded: form_helper
INFO - 2016-02-06 12:13:21 --> Database Driver Class Initialized
INFO - 2016-02-06 12:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:13:22 --> Controller Class Initialized
INFO - 2016-02-06 12:13:23 --> Model Class Initialized
INFO - 2016-02-06 12:13:23 --> Model Class Initialized
INFO - 2016-02-06 12:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:13:23 --> Pagination Class Initialized
ERROR - 2016-02-06 12:13:23 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:13:27 --> Config Class Initialized
INFO - 2016-02-06 12:13:27 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:13:27 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:13:27 --> Utf8 Class Initialized
INFO - 2016-02-06 12:13:27 --> URI Class Initialized
INFO - 2016-02-06 12:13:27 --> Router Class Initialized
INFO - 2016-02-06 12:13:27 --> Output Class Initialized
INFO - 2016-02-06 12:13:27 --> Security Class Initialized
DEBUG - 2016-02-06 12:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:13:27 --> Input Class Initialized
INFO - 2016-02-06 12:13:27 --> Language Class Initialized
INFO - 2016-02-06 12:13:27 --> Loader Class Initialized
INFO - 2016-02-06 12:13:27 --> Helper loaded: url_helper
INFO - 2016-02-06 12:13:27 --> Helper loaded: file_helper
INFO - 2016-02-06 12:13:27 --> Helper loaded: date_helper
INFO - 2016-02-06 12:13:27 --> Helper loaded: form_helper
INFO - 2016-02-06 12:13:27 --> Database Driver Class Initialized
INFO - 2016-02-06 12:13:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:13:29 --> Controller Class Initialized
INFO - 2016-02-06 12:13:29 --> Model Class Initialized
INFO - 2016-02-06 12:13:29 --> Model Class Initialized
INFO - 2016-02-06 12:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:13:29 --> Pagination Class Initialized
ERROR - 2016-02-06 12:13:29 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:13:29 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:13:29 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:13:29 --> Helper loaded: text_helper
INFO - 2016-02-06 12:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:13:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:13:29 --> Final output sent to browser
DEBUG - 2016-02-06 12:13:29 --> Total execution time: 1.2274
INFO - 2016-02-06 12:13:31 --> Config Class Initialized
INFO - 2016-02-06 12:13:31 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:13:31 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:13:31 --> Utf8 Class Initialized
INFO - 2016-02-06 12:13:31 --> URI Class Initialized
DEBUG - 2016-02-06 12:13:31 --> No URI present. Default controller set.
INFO - 2016-02-06 12:13:31 --> Router Class Initialized
INFO - 2016-02-06 12:13:31 --> Output Class Initialized
INFO - 2016-02-06 12:13:31 --> Security Class Initialized
DEBUG - 2016-02-06 12:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:13:31 --> Input Class Initialized
INFO - 2016-02-06 12:13:31 --> Language Class Initialized
INFO - 2016-02-06 12:13:31 --> Loader Class Initialized
INFO - 2016-02-06 12:13:31 --> Helper loaded: url_helper
INFO - 2016-02-06 12:13:31 --> Helper loaded: file_helper
INFO - 2016-02-06 12:13:31 --> Helper loaded: date_helper
INFO - 2016-02-06 12:13:31 --> Helper loaded: form_helper
INFO - 2016-02-06 12:13:31 --> Database Driver Class Initialized
INFO - 2016-02-06 12:13:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:13:32 --> Controller Class Initialized
INFO - 2016-02-06 12:13:32 --> Model Class Initialized
INFO - 2016-02-06 12:13:32 --> Model Class Initialized
INFO - 2016-02-06 12:13:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:13:32 --> Pagination Class Initialized
ERROR - 2016-02-06 12:13:32 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:13:32 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:13:32 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:13:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:13:32 --> Final output sent to browser
DEBUG - 2016-02-06 12:13:32 --> Total execution time: 1.1798
INFO - 2016-02-06 12:13:34 --> Config Class Initialized
INFO - 2016-02-06 12:13:34 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:13:34 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:13:34 --> Utf8 Class Initialized
INFO - 2016-02-06 12:13:34 --> URI Class Initialized
INFO - 2016-02-06 12:13:34 --> Router Class Initialized
INFO - 2016-02-06 12:13:34 --> Output Class Initialized
INFO - 2016-02-06 12:13:34 --> Security Class Initialized
DEBUG - 2016-02-06 12:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:13:34 --> Input Class Initialized
INFO - 2016-02-06 12:13:34 --> Language Class Initialized
INFO - 2016-02-06 12:13:34 --> Loader Class Initialized
INFO - 2016-02-06 12:13:34 --> Helper loaded: url_helper
INFO - 2016-02-06 12:13:34 --> Helper loaded: file_helper
INFO - 2016-02-06 12:13:34 --> Helper loaded: date_helper
INFO - 2016-02-06 12:13:34 --> Helper loaded: form_helper
INFO - 2016-02-06 12:13:34 --> Database Driver Class Initialized
INFO - 2016-02-06 12:13:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:13:35 --> Controller Class Initialized
INFO - 2016-02-06 12:13:35 --> Model Class Initialized
INFO - 2016-02-06 12:13:35 --> Model Class Initialized
INFO - 2016-02-06 12:13:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:13:35 --> Pagination Class Initialized
ERROR - 2016-02-06 12:13:35 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:13:35 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:13:35 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:13:35 --> Helper loaded: text_helper
INFO - 2016-02-06 12:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:13:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:13:35 --> Final output sent to browser
DEBUG - 2016-02-06 12:13:35 --> Total execution time: 1.2036
INFO - 2016-02-06 12:13:39 --> Config Class Initialized
INFO - 2016-02-06 12:13:39 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:13:39 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:13:39 --> Utf8 Class Initialized
INFO - 2016-02-06 12:13:39 --> URI Class Initialized
INFO - 2016-02-06 12:13:39 --> Router Class Initialized
INFO - 2016-02-06 12:13:39 --> Output Class Initialized
INFO - 2016-02-06 12:13:39 --> Security Class Initialized
DEBUG - 2016-02-06 12:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:13:39 --> Input Class Initialized
INFO - 2016-02-06 12:13:39 --> Language Class Initialized
INFO - 2016-02-06 12:13:39 --> Loader Class Initialized
INFO - 2016-02-06 12:13:39 --> Helper loaded: url_helper
INFO - 2016-02-06 12:13:39 --> Helper loaded: file_helper
INFO - 2016-02-06 12:13:39 --> Helper loaded: date_helper
INFO - 2016-02-06 12:13:39 --> Helper loaded: form_helper
INFO - 2016-02-06 12:13:40 --> Database Driver Class Initialized
INFO - 2016-02-06 12:13:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:13:41 --> Controller Class Initialized
INFO - 2016-02-06 12:13:41 --> Model Class Initialized
INFO - 2016-02-06 12:13:41 --> Model Class Initialized
INFO - 2016-02-06 12:13:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:13:41 --> Pagination Class Initialized
ERROR - 2016-02-06 12:13:41 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:13:41 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:13:41 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:13:41 --> Helper loaded: text_helper
INFO - 2016-02-06 12:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:13:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:13:41 --> Final output sent to browser
DEBUG - 2016-02-06 12:13:41 --> Total execution time: 1.1981
INFO - 2016-02-06 12:14:05 --> Config Class Initialized
INFO - 2016-02-06 12:14:05 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:14:05 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:14:05 --> Utf8 Class Initialized
INFO - 2016-02-06 12:14:05 --> URI Class Initialized
DEBUG - 2016-02-06 12:14:05 --> No URI present. Default controller set.
INFO - 2016-02-06 12:14:05 --> Router Class Initialized
INFO - 2016-02-06 12:14:05 --> Output Class Initialized
INFO - 2016-02-06 12:14:05 --> Security Class Initialized
DEBUG - 2016-02-06 12:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:14:05 --> Input Class Initialized
INFO - 2016-02-06 12:14:05 --> Language Class Initialized
INFO - 2016-02-06 12:14:05 --> Loader Class Initialized
INFO - 2016-02-06 12:14:05 --> Helper loaded: url_helper
INFO - 2016-02-06 12:14:05 --> Helper loaded: file_helper
INFO - 2016-02-06 12:14:05 --> Helper loaded: date_helper
INFO - 2016-02-06 12:14:05 --> Helper loaded: form_helper
INFO - 2016-02-06 12:14:05 --> Database Driver Class Initialized
INFO - 2016-02-06 12:14:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:14:06 --> Controller Class Initialized
INFO - 2016-02-06 12:14:06 --> Model Class Initialized
INFO - 2016-02-06 12:14:06 --> Model Class Initialized
INFO - 2016-02-06 12:14:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:14:06 --> Pagination Class Initialized
ERROR - 2016-02-06 12:14:06 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:14:06 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:14:06 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:14:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:14:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:14:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:14:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:14:06 --> Final output sent to browser
DEBUG - 2016-02-06 12:14:06 --> Total execution time: 1.1503
INFO - 2016-02-06 12:14:07 --> Config Class Initialized
INFO - 2016-02-06 12:14:07 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:14:07 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:14:07 --> Utf8 Class Initialized
INFO - 2016-02-06 12:14:07 --> URI Class Initialized
INFO - 2016-02-06 12:14:07 --> Router Class Initialized
INFO - 2016-02-06 12:14:07 --> Output Class Initialized
INFO - 2016-02-06 12:14:07 --> Security Class Initialized
DEBUG - 2016-02-06 12:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:14:07 --> Input Class Initialized
INFO - 2016-02-06 12:14:07 --> Language Class Initialized
INFO - 2016-02-06 12:14:07 --> Loader Class Initialized
INFO - 2016-02-06 12:14:07 --> Helper loaded: url_helper
INFO - 2016-02-06 12:14:07 --> Helper loaded: file_helper
INFO - 2016-02-06 12:14:08 --> Helper loaded: date_helper
INFO - 2016-02-06 12:14:08 --> Helper loaded: form_helper
INFO - 2016-02-06 12:14:08 --> Database Driver Class Initialized
INFO - 2016-02-06 12:14:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:14:09 --> Controller Class Initialized
INFO - 2016-02-06 12:14:09 --> Model Class Initialized
INFO - 2016-02-06 12:14:09 --> Model Class Initialized
INFO - 2016-02-06 12:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:14:09 --> Pagination Class Initialized
ERROR - 2016-02-06 12:14:09 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:14:09 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:14:09 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:14:09 --> Helper loaded: text_helper
INFO - 2016-02-06 12:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:14:09 --> Final output sent to browser
DEBUG - 2016-02-06 12:14:09 --> Total execution time: 1.2049
INFO - 2016-02-06 12:14:15 --> Config Class Initialized
INFO - 2016-02-06 12:14:15 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:14:15 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:14:15 --> Utf8 Class Initialized
INFO - 2016-02-06 12:14:15 --> URI Class Initialized
INFO - 2016-02-06 12:14:15 --> Router Class Initialized
INFO - 2016-02-06 12:14:15 --> Output Class Initialized
INFO - 2016-02-06 12:14:15 --> Security Class Initialized
DEBUG - 2016-02-06 12:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:14:15 --> Input Class Initialized
INFO - 2016-02-06 12:14:15 --> Language Class Initialized
INFO - 2016-02-06 12:14:15 --> Loader Class Initialized
INFO - 2016-02-06 12:14:15 --> Helper loaded: url_helper
INFO - 2016-02-06 12:14:15 --> Helper loaded: file_helper
INFO - 2016-02-06 12:14:15 --> Helper loaded: date_helper
INFO - 2016-02-06 12:14:15 --> Helper loaded: form_helper
INFO - 2016-02-06 12:14:15 --> Database Driver Class Initialized
INFO - 2016-02-06 12:14:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:14:16 --> Controller Class Initialized
INFO - 2016-02-06 12:14:16 --> Model Class Initialized
INFO - 2016-02-06 12:14:16 --> Model Class Initialized
INFO - 2016-02-06 12:14:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:14:16 --> Pagination Class Initialized
ERROR - 2016-02-06 12:14:16 --> Severity: Notice --> Use of undefined constant jboard - assumed 'jboard' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:14:16 --> Severity: Notice --> Use of undefined constant insert_comment - assumed 'insert_comment' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
ERROR - 2016-02-06 12:14:16 --> Severity: Warning --> Division by zero C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 36
INFO - 2016-02-06 12:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:14:16 --> Helper loaded: text_helper
INFO - 2016-02-06 12:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:14:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:14:16 --> Final output sent to browser
DEBUG - 2016-02-06 12:14:16 --> Total execution time: 1.2274
INFO - 2016-02-06 12:14:46 --> Config Class Initialized
INFO - 2016-02-06 12:14:46 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:14:46 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:14:46 --> Utf8 Class Initialized
INFO - 2016-02-06 12:14:46 --> URI Class Initialized
INFO - 2016-02-06 12:14:46 --> Router Class Initialized
INFO - 2016-02-06 12:14:46 --> Output Class Initialized
INFO - 2016-02-06 12:14:46 --> Security Class Initialized
DEBUG - 2016-02-06 12:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:14:46 --> Input Class Initialized
INFO - 2016-02-06 12:14:46 --> Language Class Initialized
INFO - 2016-02-06 12:14:46 --> Loader Class Initialized
INFO - 2016-02-06 12:14:46 --> Helper loaded: url_helper
INFO - 2016-02-06 12:14:46 --> Helper loaded: file_helper
INFO - 2016-02-06 12:14:46 --> Helper loaded: date_helper
INFO - 2016-02-06 12:14:46 --> Helper loaded: form_helper
INFO - 2016-02-06 12:14:46 --> Database Driver Class Initialized
INFO - 2016-02-06 12:14:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:14:47 --> Controller Class Initialized
INFO - 2016-02-06 12:14:47 --> Model Class Initialized
INFO - 2016-02-06 12:14:47 --> Model Class Initialized
INFO - 2016-02-06 12:14:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:14:47 --> Pagination Class Initialized
INFO - 2016-02-06 12:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:14:47 --> Helper loaded: text_helper
INFO - 2016-02-06 12:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:14:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:14:47 --> Final output sent to browser
DEBUG - 2016-02-06 12:14:47 --> Total execution time: 1.2328
INFO - 2016-02-06 12:16:03 --> Config Class Initialized
INFO - 2016-02-06 12:16:03 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:16:03 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:16:03 --> Utf8 Class Initialized
INFO - 2016-02-06 12:16:03 --> URI Class Initialized
INFO - 2016-02-06 12:16:03 --> Router Class Initialized
INFO - 2016-02-06 12:16:03 --> Output Class Initialized
INFO - 2016-02-06 12:16:03 --> Security Class Initialized
DEBUG - 2016-02-06 12:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:16:03 --> Input Class Initialized
INFO - 2016-02-06 12:16:03 --> Language Class Initialized
INFO - 2016-02-06 12:16:03 --> Loader Class Initialized
INFO - 2016-02-06 12:16:03 --> Helper loaded: url_helper
INFO - 2016-02-06 12:16:03 --> Helper loaded: file_helper
INFO - 2016-02-06 12:16:03 --> Helper loaded: date_helper
INFO - 2016-02-06 12:16:03 --> Helper loaded: form_helper
INFO - 2016-02-06 12:16:03 --> Database Driver Class Initialized
INFO - 2016-02-06 12:16:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:16:04 --> Controller Class Initialized
INFO - 2016-02-06 12:16:04 --> Model Class Initialized
INFO - 2016-02-06 12:16:04 --> Model Class Initialized
INFO - 2016-02-06 12:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:16:04 --> Pagination Class Initialized
INFO - 2016-02-06 12:16:04 --> Form Validation Class Initialized
INFO - 2016-02-06 12:16:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 12:16:04 --> Model Class Initialized
INFO - 2016-02-06 12:16:04 --> Final output sent to browser
DEBUG - 2016-02-06 12:16:04 --> Total execution time: 1.1915
INFO - 2016-02-06 12:16:43 --> Config Class Initialized
INFO - 2016-02-06 12:16:43 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:16:43 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:16:43 --> Utf8 Class Initialized
INFO - 2016-02-06 12:16:43 --> URI Class Initialized
INFO - 2016-02-06 12:16:43 --> Router Class Initialized
INFO - 2016-02-06 12:16:43 --> Output Class Initialized
INFO - 2016-02-06 12:16:43 --> Security Class Initialized
DEBUG - 2016-02-06 12:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:16:43 --> Input Class Initialized
INFO - 2016-02-06 12:16:43 --> Language Class Initialized
INFO - 2016-02-06 12:16:43 --> Loader Class Initialized
INFO - 2016-02-06 12:16:43 --> Helper loaded: url_helper
INFO - 2016-02-06 12:16:43 --> Helper loaded: file_helper
INFO - 2016-02-06 12:16:43 --> Helper loaded: date_helper
INFO - 2016-02-06 12:16:43 --> Helper loaded: form_helper
INFO - 2016-02-06 12:16:43 --> Database Driver Class Initialized
INFO - 2016-02-06 12:16:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:16:44 --> Controller Class Initialized
INFO - 2016-02-06 12:16:44 --> Model Class Initialized
INFO - 2016-02-06 12:16:44 --> Model Class Initialized
INFO - 2016-02-06 12:16:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:16:44 --> Pagination Class Initialized
INFO - 2016-02-06 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:16:44 --> Helper loaded: text_helper
INFO - 2016-02-06 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:16:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:16:44 --> Final output sent to browser
DEBUG - 2016-02-06 12:16:44 --> Total execution time: 1.2102
INFO - 2016-02-06 12:16:50 --> Config Class Initialized
INFO - 2016-02-06 12:16:50 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:16:50 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:16:50 --> Utf8 Class Initialized
INFO - 2016-02-06 12:16:50 --> URI Class Initialized
INFO - 2016-02-06 12:16:50 --> Router Class Initialized
INFO - 2016-02-06 12:16:50 --> Output Class Initialized
INFO - 2016-02-06 12:16:50 --> Security Class Initialized
DEBUG - 2016-02-06 12:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:16:50 --> Input Class Initialized
INFO - 2016-02-06 12:16:50 --> Language Class Initialized
INFO - 2016-02-06 12:16:50 --> Loader Class Initialized
INFO - 2016-02-06 12:16:50 --> Helper loaded: url_helper
INFO - 2016-02-06 12:16:50 --> Helper loaded: file_helper
INFO - 2016-02-06 12:16:50 --> Helper loaded: date_helper
INFO - 2016-02-06 12:16:50 --> Helper loaded: form_helper
INFO - 2016-02-06 12:16:50 --> Database Driver Class Initialized
INFO - 2016-02-06 12:16:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:16:51 --> Controller Class Initialized
INFO - 2016-02-06 12:16:51 --> Model Class Initialized
INFO - 2016-02-06 12:16:51 --> Model Class Initialized
INFO - 2016-02-06 12:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:16:51 --> Pagination Class Initialized
ERROR - 2016-02-06 12:16:51 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 12:16:51 --> Form Validation Class Initialized
INFO - 2016-02-06 12:16:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 12:16:51 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 12:16:51 --> Model Class Initialized
ERROR - 2016-02-06 12:16:51 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 12:16:51 --> Final output sent to browser
DEBUG - 2016-02-06 12:16:51 --> Total execution time: 1.1773
INFO - 2016-02-06 12:16:56 --> Config Class Initialized
INFO - 2016-02-06 12:16:56 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:16:56 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:16:56 --> Utf8 Class Initialized
INFO - 2016-02-06 12:16:56 --> URI Class Initialized
INFO - 2016-02-06 12:16:56 --> Router Class Initialized
INFO - 2016-02-06 12:16:56 --> Output Class Initialized
INFO - 2016-02-06 12:16:56 --> Security Class Initialized
DEBUG - 2016-02-06 12:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:16:56 --> Input Class Initialized
INFO - 2016-02-06 12:16:56 --> Language Class Initialized
INFO - 2016-02-06 12:16:56 --> Loader Class Initialized
INFO - 2016-02-06 12:16:56 --> Helper loaded: url_helper
INFO - 2016-02-06 12:16:56 --> Helper loaded: file_helper
INFO - 2016-02-06 12:16:56 --> Helper loaded: date_helper
INFO - 2016-02-06 12:16:56 --> Helper loaded: form_helper
INFO - 2016-02-06 12:16:56 --> Database Driver Class Initialized
INFO - 2016-02-06 12:16:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:16:57 --> Controller Class Initialized
INFO - 2016-02-06 12:16:57 --> Model Class Initialized
INFO - 2016-02-06 12:16:57 --> Model Class Initialized
INFO - 2016-02-06 12:16:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:16:57 --> Pagination Class Initialized
ERROR - 2016-02-06 12:16:57 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 12:16:57 --> Form Validation Class Initialized
INFO - 2016-02-06 12:16:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 12:16:57 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 12:16:57 --> Model Class Initialized
ERROR - 2016-02-06 12:16:57 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 12:16:57 --> Final output sent to browser
DEBUG - 2016-02-06 12:16:57 --> Total execution time: 1.1778
INFO - 2016-02-06 12:31:49 --> Config Class Initialized
INFO - 2016-02-06 12:31:49 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:31:49 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:31:49 --> Utf8 Class Initialized
INFO - 2016-02-06 12:31:49 --> URI Class Initialized
INFO - 2016-02-06 12:31:49 --> Router Class Initialized
INFO - 2016-02-06 12:31:49 --> Output Class Initialized
INFO - 2016-02-06 12:31:49 --> Security Class Initialized
DEBUG - 2016-02-06 12:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:31:49 --> Input Class Initialized
INFO - 2016-02-06 12:31:49 --> Language Class Initialized
INFO - 2016-02-06 12:31:49 --> Loader Class Initialized
INFO - 2016-02-06 12:31:49 --> Helper loaded: url_helper
INFO - 2016-02-06 12:31:49 --> Helper loaded: file_helper
INFO - 2016-02-06 12:31:49 --> Helper loaded: date_helper
INFO - 2016-02-06 12:31:49 --> Helper loaded: form_helper
INFO - 2016-02-06 12:31:49 --> Database Driver Class Initialized
INFO - 2016-02-06 12:31:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:31:50 --> Controller Class Initialized
INFO - 2016-02-06 12:31:50 --> Model Class Initialized
INFO - 2016-02-06 12:31:50 --> Model Class Initialized
INFO - 2016-02-06 12:31:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:31:50 --> Pagination Class Initialized
ERROR - 2016-02-06 12:31:50 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 12:31:50 --> Form Validation Class Initialized
INFO - 2016-02-06 12:31:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 12:31:50 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 12:31:50 --> Model Class Initialized
ERROR - 2016-02-06 12:31:50 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 12:31:50 --> Final output sent to browser
DEBUG - 2016-02-06 12:31:50 --> Total execution time: 1.2435
INFO - 2016-02-06 12:31:59 --> Config Class Initialized
INFO - 2016-02-06 12:31:59 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:31:59 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:31:59 --> Utf8 Class Initialized
INFO - 2016-02-06 12:31:59 --> URI Class Initialized
INFO - 2016-02-06 12:31:59 --> Router Class Initialized
INFO - 2016-02-06 12:31:59 --> Output Class Initialized
INFO - 2016-02-06 12:31:59 --> Security Class Initialized
DEBUG - 2016-02-06 12:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:31:59 --> Input Class Initialized
INFO - 2016-02-06 12:31:59 --> Language Class Initialized
INFO - 2016-02-06 12:31:59 --> Loader Class Initialized
INFO - 2016-02-06 12:31:59 --> Helper loaded: url_helper
INFO - 2016-02-06 12:31:59 --> Helper loaded: file_helper
INFO - 2016-02-06 12:31:59 --> Helper loaded: date_helper
INFO - 2016-02-06 12:31:59 --> Helper loaded: form_helper
INFO - 2016-02-06 12:31:59 --> Database Driver Class Initialized
INFO - 2016-02-06 12:32:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:32:00 --> Controller Class Initialized
INFO - 2016-02-06 12:32:00 --> Model Class Initialized
INFO - 2016-02-06 12:32:00 --> Model Class Initialized
INFO - 2016-02-06 12:32:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:32:00 --> Pagination Class Initialized
ERROR - 2016-02-06 12:32:00 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 12:32:00 --> Form Validation Class Initialized
INFO - 2016-02-06 12:32:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 12:32:00 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 12:32:00 --> Model Class Initialized
ERROR - 2016-02-06 12:32:00 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 12:32:00 --> Final output sent to browser
DEBUG - 2016-02-06 12:32:00 --> Total execution time: 1.1623
INFO - 2016-02-06 12:34:15 --> Config Class Initialized
INFO - 2016-02-06 12:34:15 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:34:15 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:34:15 --> Utf8 Class Initialized
INFO - 2016-02-06 12:34:15 --> URI Class Initialized
DEBUG - 2016-02-06 12:34:15 --> No URI present. Default controller set.
INFO - 2016-02-06 12:34:15 --> Router Class Initialized
INFO - 2016-02-06 12:34:15 --> Output Class Initialized
INFO - 2016-02-06 12:34:15 --> Security Class Initialized
DEBUG - 2016-02-06 12:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:34:15 --> Input Class Initialized
INFO - 2016-02-06 12:34:15 --> Language Class Initialized
INFO - 2016-02-06 12:34:15 --> Loader Class Initialized
INFO - 2016-02-06 12:34:15 --> Helper loaded: url_helper
INFO - 2016-02-06 12:34:15 --> Helper loaded: file_helper
INFO - 2016-02-06 12:34:15 --> Helper loaded: date_helper
INFO - 2016-02-06 12:34:15 --> Helper loaded: form_helper
INFO - 2016-02-06 12:34:15 --> Database Driver Class Initialized
INFO - 2016-02-06 12:34:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:34:16 --> Controller Class Initialized
INFO - 2016-02-06 12:34:16 --> Model Class Initialized
INFO - 2016-02-06 12:34:16 --> Model Class Initialized
INFO - 2016-02-06 12:34:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:34:16 --> Pagination Class Initialized
INFO - 2016-02-06 12:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:34:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:34:16 --> Final output sent to browser
DEBUG - 2016-02-06 12:34:16 --> Total execution time: 1.1419
INFO - 2016-02-06 12:34:19 --> Config Class Initialized
INFO - 2016-02-06 12:34:19 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:34:19 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:34:19 --> Utf8 Class Initialized
INFO - 2016-02-06 12:34:19 --> URI Class Initialized
INFO - 2016-02-06 12:34:19 --> Router Class Initialized
INFO - 2016-02-06 12:34:19 --> Output Class Initialized
INFO - 2016-02-06 12:34:19 --> Security Class Initialized
DEBUG - 2016-02-06 12:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:34:19 --> Input Class Initialized
INFO - 2016-02-06 12:34:19 --> Language Class Initialized
INFO - 2016-02-06 12:34:19 --> Loader Class Initialized
INFO - 2016-02-06 12:34:19 --> Helper loaded: url_helper
INFO - 2016-02-06 12:34:19 --> Helper loaded: file_helper
INFO - 2016-02-06 12:34:19 --> Helper loaded: date_helper
INFO - 2016-02-06 12:34:19 --> Helper loaded: form_helper
INFO - 2016-02-06 12:34:19 --> Database Driver Class Initialized
INFO - 2016-02-06 12:34:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:34:20 --> Controller Class Initialized
INFO - 2016-02-06 12:34:20 --> Model Class Initialized
INFO - 2016-02-06 12:34:20 --> Model Class Initialized
INFO - 2016-02-06 12:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:34:20 --> Pagination Class Initialized
INFO - 2016-02-06 12:34:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:34:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:34:20 --> Helper loaded: text_helper
INFO - 2016-02-06 12:34:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:34:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:34:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:34:20 --> Final output sent to browser
DEBUG - 2016-02-06 12:34:20 --> Total execution time: 1.2515
INFO - 2016-02-06 12:36:45 --> Config Class Initialized
INFO - 2016-02-06 12:36:45 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:36:45 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:36:45 --> Utf8 Class Initialized
INFO - 2016-02-06 12:36:45 --> URI Class Initialized
DEBUG - 2016-02-06 12:36:45 --> No URI present. Default controller set.
INFO - 2016-02-06 12:36:45 --> Router Class Initialized
INFO - 2016-02-06 12:36:45 --> Output Class Initialized
INFO - 2016-02-06 12:36:45 --> Security Class Initialized
DEBUG - 2016-02-06 12:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:36:45 --> Input Class Initialized
INFO - 2016-02-06 12:36:45 --> Language Class Initialized
INFO - 2016-02-06 12:36:45 --> Loader Class Initialized
INFO - 2016-02-06 12:36:45 --> Helper loaded: url_helper
INFO - 2016-02-06 12:36:45 --> Helper loaded: file_helper
INFO - 2016-02-06 12:36:45 --> Helper loaded: date_helper
INFO - 2016-02-06 12:36:45 --> Helper loaded: form_helper
INFO - 2016-02-06 12:36:45 --> Database Driver Class Initialized
INFO - 2016-02-06 12:36:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:36:46 --> Controller Class Initialized
INFO - 2016-02-06 12:36:46 --> Model Class Initialized
INFO - 2016-02-06 12:36:46 --> Model Class Initialized
INFO - 2016-02-06 12:36:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:36:46 --> Pagination Class Initialized
INFO - 2016-02-06 12:36:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:36:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:36:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:36:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:36:46 --> Final output sent to browser
DEBUG - 2016-02-06 12:36:46 --> Total execution time: 1.1469
INFO - 2016-02-06 12:36:47 --> Config Class Initialized
INFO - 2016-02-06 12:36:47 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:36:47 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:36:47 --> Utf8 Class Initialized
INFO - 2016-02-06 12:36:47 --> URI Class Initialized
INFO - 2016-02-06 12:36:47 --> Router Class Initialized
INFO - 2016-02-06 12:36:47 --> Output Class Initialized
INFO - 2016-02-06 12:36:47 --> Security Class Initialized
DEBUG - 2016-02-06 12:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:36:47 --> Input Class Initialized
INFO - 2016-02-06 12:36:47 --> Language Class Initialized
INFO - 2016-02-06 12:36:47 --> Loader Class Initialized
INFO - 2016-02-06 12:36:47 --> Helper loaded: url_helper
INFO - 2016-02-06 12:36:47 --> Helper loaded: file_helper
INFO - 2016-02-06 12:36:47 --> Helper loaded: date_helper
INFO - 2016-02-06 12:36:47 --> Helper loaded: form_helper
INFO - 2016-02-06 12:36:47 --> Database Driver Class Initialized
INFO - 2016-02-06 12:36:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:36:48 --> Controller Class Initialized
INFO - 2016-02-06 12:36:48 --> Model Class Initialized
INFO - 2016-02-06 12:36:48 --> Model Class Initialized
INFO - 2016-02-06 12:36:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:36:48 --> Pagination Class Initialized
INFO - 2016-02-06 12:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:36:49 --> Helper loaded: text_helper
INFO - 2016-02-06 12:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:36:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:36:49 --> Final output sent to browser
DEBUG - 2016-02-06 12:36:49 --> Total execution time: 1.2710
INFO - 2016-02-06 12:36:58 --> Config Class Initialized
INFO - 2016-02-06 12:36:58 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:36:58 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:36:58 --> Utf8 Class Initialized
INFO - 2016-02-06 12:36:58 --> URI Class Initialized
INFO - 2016-02-06 12:36:58 --> Router Class Initialized
INFO - 2016-02-06 12:36:58 --> Output Class Initialized
INFO - 2016-02-06 12:36:58 --> Security Class Initialized
DEBUG - 2016-02-06 12:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:36:58 --> Input Class Initialized
INFO - 2016-02-06 12:36:58 --> Language Class Initialized
INFO - 2016-02-06 12:36:58 --> Loader Class Initialized
INFO - 2016-02-06 12:36:58 --> Helper loaded: url_helper
INFO - 2016-02-06 12:36:58 --> Helper loaded: file_helper
INFO - 2016-02-06 12:36:58 --> Helper loaded: date_helper
INFO - 2016-02-06 12:36:58 --> Helper loaded: form_helper
INFO - 2016-02-06 12:36:58 --> Database Driver Class Initialized
INFO - 2016-02-06 12:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:36:59 --> Controller Class Initialized
INFO - 2016-02-06 12:36:59 --> Model Class Initialized
INFO - 2016-02-06 12:36:59 --> Model Class Initialized
INFO - 2016-02-06 12:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:36:59 --> Pagination Class Initialized
ERROR - 2016-02-06 12:36:59 --> Severity: Warning --> Missing argument 1 for Jboard::insert_comment() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 174
INFO - 2016-02-06 12:36:59 --> Form Validation Class Initialized
INFO - 2016-02-06 12:36:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-06 12:36:59 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 192
INFO - 2016-02-06 12:36:59 --> Model Class Initialized
ERROR - 2016-02-06 12:36:59 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 12:36:59 --> Final output sent to browser
DEBUG - 2016-02-06 12:36:59 --> Total execution time: 1.1938
INFO - 2016-02-06 12:39:40 --> Config Class Initialized
INFO - 2016-02-06 12:39:40 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:39:40 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:39:40 --> Utf8 Class Initialized
INFO - 2016-02-06 12:39:40 --> URI Class Initialized
DEBUG - 2016-02-06 12:39:40 --> No URI present. Default controller set.
INFO - 2016-02-06 12:39:40 --> Router Class Initialized
INFO - 2016-02-06 12:39:40 --> Output Class Initialized
INFO - 2016-02-06 12:39:40 --> Security Class Initialized
DEBUG - 2016-02-06 12:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:39:40 --> Input Class Initialized
INFO - 2016-02-06 12:39:40 --> Language Class Initialized
INFO - 2016-02-06 12:39:40 --> Loader Class Initialized
INFO - 2016-02-06 12:39:40 --> Helper loaded: url_helper
INFO - 2016-02-06 12:39:40 --> Helper loaded: file_helper
INFO - 2016-02-06 12:39:40 --> Helper loaded: date_helper
INFO - 2016-02-06 12:39:40 --> Helper loaded: form_helper
INFO - 2016-02-06 12:39:40 --> Database Driver Class Initialized
INFO - 2016-02-06 12:39:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:39:41 --> Controller Class Initialized
INFO - 2016-02-06 12:39:41 --> Model Class Initialized
INFO - 2016-02-06 12:39:41 --> Model Class Initialized
INFO - 2016-02-06 12:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:39:41 --> Pagination Class Initialized
INFO - 2016-02-06 12:39:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:39:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:39:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:39:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:39:41 --> Final output sent to browser
DEBUG - 2016-02-06 12:39:41 --> Total execution time: 1.1174
INFO - 2016-02-06 12:39:43 --> Config Class Initialized
INFO - 2016-02-06 12:39:43 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:39:43 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:39:43 --> Utf8 Class Initialized
INFO - 2016-02-06 12:39:43 --> URI Class Initialized
INFO - 2016-02-06 12:39:43 --> Router Class Initialized
INFO - 2016-02-06 12:39:43 --> Output Class Initialized
INFO - 2016-02-06 12:39:43 --> Security Class Initialized
DEBUG - 2016-02-06 12:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:39:43 --> Input Class Initialized
INFO - 2016-02-06 12:39:43 --> Language Class Initialized
INFO - 2016-02-06 12:39:43 --> Loader Class Initialized
INFO - 2016-02-06 12:39:43 --> Helper loaded: url_helper
INFO - 2016-02-06 12:39:43 --> Helper loaded: file_helper
INFO - 2016-02-06 12:39:43 --> Helper loaded: date_helper
INFO - 2016-02-06 12:39:43 --> Helper loaded: form_helper
INFO - 2016-02-06 12:39:43 --> Database Driver Class Initialized
INFO - 2016-02-06 12:39:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:39:44 --> Controller Class Initialized
INFO - 2016-02-06 12:39:44 --> Model Class Initialized
INFO - 2016-02-06 12:39:44 --> Model Class Initialized
INFO - 2016-02-06 12:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:39:44 --> Pagination Class Initialized
INFO - 2016-02-06 12:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:39:44 --> Helper loaded: text_helper
INFO - 2016-02-06 12:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:39:44 --> Final output sent to browser
DEBUG - 2016-02-06 12:39:44 --> Total execution time: 1.1466
INFO - 2016-02-06 12:39:48 --> Config Class Initialized
INFO - 2016-02-06 12:39:48 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:39:48 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:39:48 --> Utf8 Class Initialized
INFO - 2016-02-06 12:39:48 --> URI Class Initialized
INFO - 2016-02-06 12:39:48 --> Router Class Initialized
INFO - 2016-02-06 12:39:48 --> Output Class Initialized
INFO - 2016-02-06 12:39:48 --> Security Class Initialized
DEBUG - 2016-02-06 12:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:39:48 --> Input Class Initialized
INFO - 2016-02-06 12:39:48 --> Language Class Initialized
INFO - 2016-02-06 12:39:48 --> Loader Class Initialized
INFO - 2016-02-06 12:39:48 --> Helper loaded: url_helper
INFO - 2016-02-06 12:39:48 --> Helper loaded: file_helper
INFO - 2016-02-06 12:39:48 --> Helper loaded: date_helper
INFO - 2016-02-06 12:39:48 --> Helper loaded: form_helper
INFO - 2016-02-06 12:39:48 --> Database Driver Class Initialized
INFO - 2016-02-06 12:39:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:39:49 --> Controller Class Initialized
INFO - 2016-02-06 12:39:49 --> Model Class Initialized
INFO - 2016-02-06 12:39:49 --> Model Class Initialized
INFO - 2016-02-06 12:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:39:49 --> Pagination Class Initialized
INFO - 2016-02-06 12:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:39:49 --> Helper loaded: text_helper
INFO - 2016-02-06 12:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:39:49 --> Final output sent to browser
DEBUG - 2016-02-06 12:39:49 --> Total execution time: 1.2172
INFO - 2016-02-06 12:41:14 --> Config Class Initialized
INFO - 2016-02-06 12:41:14 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:41:15 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:41:15 --> Utf8 Class Initialized
INFO - 2016-02-06 12:41:15 --> URI Class Initialized
INFO - 2016-02-06 12:41:15 --> Router Class Initialized
INFO - 2016-02-06 12:41:15 --> Output Class Initialized
INFO - 2016-02-06 12:41:15 --> Security Class Initialized
DEBUG - 2016-02-06 12:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:41:15 --> Input Class Initialized
INFO - 2016-02-06 12:41:15 --> Language Class Initialized
INFO - 2016-02-06 12:41:15 --> Loader Class Initialized
INFO - 2016-02-06 12:41:15 --> Helper loaded: url_helper
INFO - 2016-02-06 12:41:15 --> Helper loaded: file_helper
INFO - 2016-02-06 12:41:15 --> Helper loaded: date_helper
INFO - 2016-02-06 12:41:15 --> Helper loaded: form_helper
INFO - 2016-02-06 12:41:15 --> Database Driver Class Initialized
INFO - 2016-02-06 12:41:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:41:16 --> Controller Class Initialized
INFO - 2016-02-06 12:41:16 --> Model Class Initialized
INFO - 2016-02-06 12:41:16 --> Model Class Initialized
INFO - 2016-02-06 12:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:41:16 --> Pagination Class Initialized
INFO - 2016-02-06 12:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:41:16 --> Helper loaded: text_helper
INFO - 2016-02-06 12:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:41:16 --> Final output sent to browser
DEBUG - 2016-02-06 12:41:16 --> Total execution time: 1.1796
INFO - 2016-02-06 12:42:02 --> Config Class Initialized
INFO - 2016-02-06 12:42:02 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:42:02 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:42:02 --> Utf8 Class Initialized
INFO - 2016-02-06 12:42:02 --> URI Class Initialized
DEBUG - 2016-02-06 12:42:02 --> No URI present. Default controller set.
INFO - 2016-02-06 12:42:02 --> Router Class Initialized
INFO - 2016-02-06 12:42:02 --> Output Class Initialized
INFO - 2016-02-06 12:42:02 --> Security Class Initialized
DEBUG - 2016-02-06 12:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:42:02 --> Input Class Initialized
INFO - 2016-02-06 12:42:02 --> Language Class Initialized
INFO - 2016-02-06 12:42:02 --> Loader Class Initialized
INFO - 2016-02-06 12:42:02 --> Helper loaded: url_helper
INFO - 2016-02-06 12:42:02 --> Helper loaded: file_helper
INFO - 2016-02-06 12:42:02 --> Helper loaded: date_helper
INFO - 2016-02-06 12:42:02 --> Helper loaded: form_helper
INFO - 2016-02-06 12:42:02 --> Database Driver Class Initialized
INFO - 2016-02-06 12:42:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:42:03 --> Controller Class Initialized
INFO - 2016-02-06 12:42:03 --> Model Class Initialized
INFO - 2016-02-06 12:42:03 --> Model Class Initialized
INFO - 2016-02-06 12:42:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:42:03 --> Pagination Class Initialized
INFO - 2016-02-06 12:42:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:42:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:42:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:42:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:42:03 --> Final output sent to browser
DEBUG - 2016-02-06 12:42:03 --> Total execution time: 1.1321
INFO - 2016-02-06 12:42:04 --> Config Class Initialized
INFO - 2016-02-06 12:42:04 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:42:04 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:42:04 --> Utf8 Class Initialized
INFO - 2016-02-06 12:42:04 --> URI Class Initialized
INFO - 2016-02-06 12:42:04 --> Router Class Initialized
INFO - 2016-02-06 12:42:04 --> Output Class Initialized
INFO - 2016-02-06 12:42:04 --> Security Class Initialized
DEBUG - 2016-02-06 12:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:42:04 --> Input Class Initialized
INFO - 2016-02-06 12:42:04 --> Language Class Initialized
INFO - 2016-02-06 12:42:04 --> Loader Class Initialized
INFO - 2016-02-06 12:42:04 --> Helper loaded: url_helper
INFO - 2016-02-06 12:42:04 --> Helper loaded: file_helper
INFO - 2016-02-06 12:42:04 --> Helper loaded: date_helper
INFO - 2016-02-06 12:42:04 --> Helper loaded: form_helper
INFO - 2016-02-06 12:42:04 --> Database Driver Class Initialized
INFO - 2016-02-06 12:42:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:42:05 --> Controller Class Initialized
INFO - 2016-02-06 12:42:05 --> Model Class Initialized
INFO - 2016-02-06 12:42:05 --> Model Class Initialized
INFO - 2016-02-06 12:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:42:05 --> Pagination Class Initialized
INFO - 2016-02-06 12:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:42:05 --> Helper loaded: text_helper
INFO - 2016-02-06 12:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:42:05 --> Final output sent to browser
DEBUG - 2016-02-06 12:42:05 --> Total execution time: 1.1839
INFO - 2016-02-06 12:42:11 --> Config Class Initialized
INFO - 2016-02-06 12:42:11 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:42:11 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:42:11 --> Utf8 Class Initialized
INFO - 2016-02-06 12:42:11 --> URI Class Initialized
INFO - 2016-02-06 12:42:11 --> Router Class Initialized
INFO - 2016-02-06 12:42:11 --> Output Class Initialized
INFO - 2016-02-06 12:42:11 --> Security Class Initialized
DEBUG - 2016-02-06 12:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:42:11 --> Input Class Initialized
INFO - 2016-02-06 12:42:11 --> Language Class Initialized
INFO - 2016-02-06 12:42:11 --> Loader Class Initialized
INFO - 2016-02-06 12:42:11 --> Helper loaded: url_helper
INFO - 2016-02-06 12:42:11 --> Helper loaded: file_helper
INFO - 2016-02-06 12:42:11 --> Helper loaded: date_helper
INFO - 2016-02-06 12:42:11 --> Helper loaded: form_helper
INFO - 2016-02-06 12:42:11 --> Database Driver Class Initialized
INFO - 2016-02-06 12:42:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:42:12 --> Controller Class Initialized
INFO - 2016-02-06 12:42:12 --> Model Class Initialized
INFO - 2016-02-06 12:42:12 --> Model Class Initialized
INFO - 2016-02-06 12:42:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:42:12 --> Pagination Class Initialized
INFO - 2016-02-06 12:42:12 --> Form Validation Class Initialized
INFO - 2016-02-06 12:42:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 12:42:12 --> Model Class Initialized
ERROR - 2016-02-06 12:42:13 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 12:42:13 --> Final output sent to browser
DEBUG - 2016-02-06 12:42:13 --> Total execution time: 1.1710
INFO - 2016-02-06 12:43:36 --> Config Class Initialized
INFO - 2016-02-06 12:43:36 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:43:36 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:43:36 --> Utf8 Class Initialized
INFO - 2016-02-06 12:43:36 --> URI Class Initialized
DEBUG - 2016-02-06 12:43:36 --> No URI present. Default controller set.
INFO - 2016-02-06 12:43:36 --> Router Class Initialized
INFO - 2016-02-06 12:43:36 --> Output Class Initialized
INFO - 2016-02-06 12:43:36 --> Security Class Initialized
DEBUG - 2016-02-06 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:43:36 --> Input Class Initialized
INFO - 2016-02-06 12:43:36 --> Language Class Initialized
INFO - 2016-02-06 12:43:36 --> Loader Class Initialized
INFO - 2016-02-06 12:43:36 --> Helper loaded: url_helper
INFO - 2016-02-06 12:43:36 --> Helper loaded: file_helper
INFO - 2016-02-06 12:43:36 --> Helper loaded: date_helper
INFO - 2016-02-06 12:43:36 --> Helper loaded: form_helper
INFO - 2016-02-06 12:43:36 --> Database Driver Class Initialized
INFO - 2016-02-06 12:43:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:43:38 --> Controller Class Initialized
INFO - 2016-02-06 12:43:38 --> Model Class Initialized
INFO - 2016-02-06 12:43:38 --> Model Class Initialized
INFO - 2016-02-06 12:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:43:38 --> Pagination Class Initialized
INFO - 2016-02-06 12:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:43:38 --> Final output sent to browser
DEBUG - 2016-02-06 12:43:38 --> Total execution time: 1.2085
INFO - 2016-02-06 12:43:40 --> Config Class Initialized
INFO - 2016-02-06 12:43:40 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:43:40 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:43:40 --> Utf8 Class Initialized
INFO - 2016-02-06 12:43:40 --> URI Class Initialized
INFO - 2016-02-06 12:43:40 --> Router Class Initialized
INFO - 2016-02-06 12:43:40 --> Output Class Initialized
INFO - 2016-02-06 12:43:40 --> Security Class Initialized
DEBUG - 2016-02-06 12:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:43:40 --> Input Class Initialized
INFO - 2016-02-06 12:43:40 --> Language Class Initialized
INFO - 2016-02-06 12:43:40 --> Loader Class Initialized
INFO - 2016-02-06 12:43:40 --> Helper loaded: url_helper
INFO - 2016-02-06 12:43:40 --> Helper loaded: file_helper
INFO - 2016-02-06 12:43:40 --> Helper loaded: date_helper
INFO - 2016-02-06 12:43:40 --> Helper loaded: form_helper
INFO - 2016-02-06 12:43:40 --> Database Driver Class Initialized
INFO - 2016-02-06 12:43:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:43:41 --> Controller Class Initialized
INFO - 2016-02-06 12:43:41 --> Model Class Initialized
INFO - 2016-02-06 12:43:41 --> Model Class Initialized
INFO - 2016-02-06 12:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:43:41 --> Pagination Class Initialized
INFO - 2016-02-06 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:43:41 --> Helper loaded: text_helper
INFO - 2016-02-06 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:43:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:43:41 --> Final output sent to browser
DEBUG - 2016-02-06 12:43:41 --> Total execution time: 1.1528
INFO - 2016-02-06 12:43:45 --> Config Class Initialized
INFO - 2016-02-06 12:43:45 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:43:45 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:43:45 --> Utf8 Class Initialized
INFO - 2016-02-06 12:43:45 --> URI Class Initialized
INFO - 2016-02-06 12:43:45 --> Router Class Initialized
INFO - 2016-02-06 12:43:45 --> Output Class Initialized
INFO - 2016-02-06 12:43:45 --> Security Class Initialized
DEBUG - 2016-02-06 12:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:43:45 --> Input Class Initialized
INFO - 2016-02-06 12:43:45 --> Language Class Initialized
INFO - 2016-02-06 12:43:45 --> Loader Class Initialized
INFO - 2016-02-06 12:43:45 --> Helper loaded: url_helper
INFO - 2016-02-06 12:43:45 --> Helper loaded: file_helper
INFO - 2016-02-06 12:43:45 --> Helper loaded: date_helper
INFO - 2016-02-06 12:43:45 --> Helper loaded: form_helper
INFO - 2016-02-06 12:43:45 --> Database Driver Class Initialized
INFO - 2016-02-06 12:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:43:46 --> Controller Class Initialized
INFO - 2016-02-06 12:43:46 --> Model Class Initialized
INFO - 2016-02-06 12:43:46 --> Model Class Initialized
INFO - 2016-02-06 12:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:43:46 --> Pagination Class Initialized
INFO - 2016-02-06 12:43:46 --> Form Validation Class Initialized
INFO - 2016-02-06 12:43:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 12:43:46 --> Model Class Initialized
ERROR - 2016-02-06 12:43:46 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 12:43:46 --> Final output sent to browser
DEBUG - 2016-02-06 12:43:46 --> Total execution time: 1.1701
INFO - 2016-02-06 12:46:22 --> Config Class Initialized
INFO - 2016-02-06 12:46:22 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:46:22 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:46:22 --> Utf8 Class Initialized
INFO - 2016-02-06 12:46:22 --> URI Class Initialized
DEBUG - 2016-02-06 12:46:22 --> No URI present. Default controller set.
INFO - 2016-02-06 12:46:22 --> Router Class Initialized
INFO - 2016-02-06 12:46:22 --> Output Class Initialized
INFO - 2016-02-06 12:46:22 --> Security Class Initialized
DEBUG - 2016-02-06 12:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:46:22 --> Input Class Initialized
INFO - 2016-02-06 12:46:23 --> Language Class Initialized
INFO - 2016-02-06 12:46:23 --> Loader Class Initialized
INFO - 2016-02-06 12:46:23 --> Helper loaded: url_helper
INFO - 2016-02-06 12:46:23 --> Helper loaded: file_helper
INFO - 2016-02-06 12:46:23 --> Helper loaded: date_helper
INFO - 2016-02-06 12:46:23 --> Helper loaded: form_helper
INFO - 2016-02-06 12:46:23 --> Database Driver Class Initialized
INFO - 2016-02-06 12:46:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:46:24 --> Controller Class Initialized
INFO - 2016-02-06 12:46:24 --> Model Class Initialized
INFO - 2016-02-06 12:46:24 --> Model Class Initialized
INFO - 2016-02-06 12:46:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:46:24 --> Pagination Class Initialized
INFO - 2016-02-06 12:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:46:24 --> Final output sent to browser
DEBUG - 2016-02-06 12:46:24 --> Total execution time: 1.1372
INFO - 2016-02-06 12:46:27 --> Config Class Initialized
INFO - 2016-02-06 12:46:27 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:46:27 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:46:27 --> Utf8 Class Initialized
INFO - 2016-02-06 12:46:27 --> URI Class Initialized
INFO - 2016-02-06 12:46:27 --> Router Class Initialized
INFO - 2016-02-06 12:46:27 --> Output Class Initialized
INFO - 2016-02-06 12:46:27 --> Security Class Initialized
DEBUG - 2016-02-06 12:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:46:27 --> Input Class Initialized
INFO - 2016-02-06 12:46:27 --> Language Class Initialized
INFO - 2016-02-06 12:46:27 --> Loader Class Initialized
INFO - 2016-02-06 12:46:27 --> Helper loaded: url_helper
INFO - 2016-02-06 12:46:27 --> Helper loaded: file_helper
INFO - 2016-02-06 12:46:27 --> Helper loaded: date_helper
INFO - 2016-02-06 12:46:27 --> Helper loaded: form_helper
INFO - 2016-02-06 12:46:27 --> Database Driver Class Initialized
INFO - 2016-02-06 12:46:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:46:28 --> Controller Class Initialized
INFO - 2016-02-06 12:46:28 --> Model Class Initialized
INFO - 2016-02-06 12:46:28 --> Model Class Initialized
INFO - 2016-02-06 12:46:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:46:28 --> Pagination Class Initialized
INFO - 2016-02-06 12:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:46:28 --> Helper loaded: text_helper
INFO - 2016-02-06 12:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:46:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:46:28 --> Final output sent to browser
DEBUG - 2016-02-06 12:46:28 --> Total execution time: 1.2163
INFO - 2016-02-06 12:46:32 --> Config Class Initialized
INFO - 2016-02-06 12:46:32 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:46:32 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:46:32 --> Utf8 Class Initialized
INFO - 2016-02-06 12:46:32 --> URI Class Initialized
INFO - 2016-02-06 12:46:32 --> Router Class Initialized
INFO - 2016-02-06 12:46:32 --> Output Class Initialized
INFO - 2016-02-06 12:46:32 --> Security Class Initialized
DEBUG - 2016-02-06 12:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:46:32 --> Input Class Initialized
INFO - 2016-02-06 12:46:32 --> Language Class Initialized
INFO - 2016-02-06 12:46:32 --> Loader Class Initialized
INFO - 2016-02-06 12:46:32 --> Helper loaded: url_helper
INFO - 2016-02-06 12:46:32 --> Helper loaded: file_helper
INFO - 2016-02-06 12:46:32 --> Helper loaded: date_helper
INFO - 2016-02-06 12:46:32 --> Helper loaded: form_helper
INFO - 2016-02-06 12:46:32 --> Database Driver Class Initialized
INFO - 2016-02-06 12:46:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:46:33 --> Controller Class Initialized
INFO - 2016-02-06 12:46:33 --> Model Class Initialized
INFO - 2016-02-06 12:46:33 --> Model Class Initialized
INFO - 2016-02-06 12:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:46:33 --> Pagination Class Initialized
INFO - 2016-02-06 12:46:33 --> Form Validation Class Initialized
INFO - 2016-02-06 12:46:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 12:46:33 --> Model Class Initialized
ERROR - 2016-02-06 12:46:33 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 203
INFO - 2016-02-06 12:46:33 --> Final output sent to browser
DEBUG - 2016-02-06 12:46:33 --> Total execution time: 1.2966
INFO - 2016-02-06 12:48:56 --> Config Class Initialized
INFO - 2016-02-06 12:48:56 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:48:56 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:48:56 --> Utf8 Class Initialized
INFO - 2016-02-06 12:48:56 --> URI Class Initialized
DEBUG - 2016-02-06 12:48:56 --> No URI present. Default controller set.
INFO - 2016-02-06 12:48:56 --> Router Class Initialized
INFO - 2016-02-06 12:48:56 --> Output Class Initialized
INFO - 2016-02-06 12:48:56 --> Security Class Initialized
DEBUG - 2016-02-06 12:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:48:56 --> Input Class Initialized
INFO - 2016-02-06 12:48:56 --> Language Class Initialized
INFO - 2016-02-06 12:48:56 --> Loader Class Initialized
INFO - 2016-02-06 12:48:56 --> Helper loaded: url_helper
INFO - 2016-02-06 12:48:56 --> Helper loaded: file_helper
INFO - 2016-02-06 12:48:56 --> Helper loaded: date_helper
INFO - 2016-02-06 12:48:56 --> Helper loaded: form_helper
INFO - 2016-02-06 12:48:56 --> Database Driver Class Initialized
INFO - 2016-02-06 12:48:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:48:57 --> Controller Class Initialized
INFO - 2016-02-06 12:48:57 --> Model Class Initialized
INFO - 2016-02-06 12:48:57 --> Model Class Initialized
INFO - 2016-02-06 12:48:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:48:57 --> Pagination Class Initialized
INFO - 2016-02-06 12:48:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:48:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:48:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 12:48:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:48:57 --> Final output sent to browser
DEBUG - 2016-02-06 12:48:57 --> Total execution time: 1.1491
INFO - 2016-02-06 12:49:01 --> Config Class Initialized
INFO - 2016-02-06 12:49:01 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:49:01 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:49:01 --> Utf8 Class Initialized
INFO - 2016-02-06 12:49:01 --> URI Class Initialized
INFO - 2016-02-06 12:49:01 --> Router Class Initialized
INFO - 2016-02-06 12:49:01 --> Output Class Initialized
INFO - 2016-02-06 12:49:01 --> Security Class Initialized
DEBUG - 2016-02-06 12:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:49:01 --> Input Class Initialized
INFO - 2016-02-06 12:49:01 --> Language Class Initialized
INFO - 2016-02-06 12:49:01 --> Loader Class Initialized
INFO - 2016-02-06 12:49:01 --> Helper loaded: url_helper
INFO - 2016-02-06 12:49:01 --> Helper loaded: file_helper
INFO - 2016-02-06 12:49:01 --> Helper loaded: date_helper
INFO - 2016-02-06 12:49:01 --> Helper loaded: form_helper
INFO - 2016-02-06 12:49:01 --> Database Driver Class Initialized
INFO - 2016-02-06 12:49:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:49:02 --> Controller Class Initialized
INFO - 2016-02-06 12:49:02 --> Model Class Initialized
INFO - 2016-02-06 12:49:02 --> Model Class Initialized
INFO - 2016-02-06 12:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:49:02 --> Pagination Class Initialized
INFO - 2016-02-06 12:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 12:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 12:49:02 --> Helper loaded: text_helper
INFO - 2016-02-06 12:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 12:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 12:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 12:49:02 --> Final output sent to browser
DEBUG - 2016-02-06 12:49:02 --> Total execution time: 1.1840
INFO - 2016-02-06 12:49:07 --> Config Class Initialized
INFO - 2016-02-06 12:49:07 --> Hooks Class Initialized
DEBUG - 2016-02-06 12:49:07 --> UTF-8 Support Enabled
INFO - 2016-02-06 12:49:07 --> Utf8 Class Initialized
INFO - 2016-02-06 12:49:07 --> URI Class Initialized
INFO - 2016-02-06 12:49:07 --> Router Class Initialized
INFO - 2016-02-06 12:49:07 --> Output Class Initialized
INFO - 2016-02-06 12:49:07 --> Security Class Initialized
DEBUG - 2016-02-06 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 12:49:07 --> Input Class Initialized
INFO - 2016-02-06 12:49:07 --> Language Class Initialized
INFO - 2016-02-06 12:49:07 --> Loader Class Initialized
INFO - 2016-02-06 12:49:07 --> Helper loaded: url_helper
INFO - 2016-02-06 12:49:07 --> Helper loaded: file_helper
INFO - 2016-02-06 12:49:07 --> Helper loaded: date_helper
INFO - 2016-02-06 12:49:07 --> Helper loaded: form_helper
INFO - 2016-02-06 12:49:07 --> Database Driver Class Initialized
INFO - 2016-02-06 12:49:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 12:49:08 --> Controller Class Initialized
INFO - 2016-02-06 12:49:08 --> Model Class Initialized
INFO - 2016-02-06 12:49:08 --> Model Class Initialized
INFO - 2016-02-06 12:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 12:49:08 --> Pagination Class Initialized
INFO - 2016-02-06 12:49:08 --> Form Validation Class Initialized
INFO - 2016-02-06 12:49:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 12:49:08 --> Model Class Initialized
INFO - 2016-02-06 12:49:08 --> Final output sent to browser
DEBUG - 2016-02-06 12:49:08 --> Total execution time: 1.2352
INFO - 2016-02-06 13:13:35 --> Config Class Initialized
INFO - 2016-02-06 13:13:35 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:13:35 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:13:35 --> Utf8 Class Initialized
INFO - 2016-02-06 13:13:35 --> URI Class Initialized
INFO - 2016-02-06 13:13:35 --> Router Class Initialized
INFO - 2016-02-06 13:13:35 --> Output Class Initialized
INFO - 2016-02-06 13:13:35 --> Security Class Initialized
DEBUG - 2016-02-06 13:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:13:35 --> Input Class Initialized
INFO - 2016-02-06 13:13:35 --> Language Class Initialized
INFO - 2016-02-06 13:13:35 --> Loader Class Initialized
INFO - 2016-02-06 13:13:35 --> Helper loaded: url_helper
INFO - 2016-02-06 13:13:35 --> Helper loaded: file_helper
INFO - 2016-02-06 13:13:35 --> Helper loaded: date_helper
INFO - 2016-02-06 13:13:35 --> Helper loaded: form_helper
INFO - 2016-02-06 13:13:35 --> Database Driver Class Initialized
INFO - 2016-02-06 13:13:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:13:36 --> Controller Class Initialized
INFO - 2016-02-06 13:13:36 --> Model Class Initialized
INFO - 2016-02-06 13:13:36 --> Model Class Initialized
INFO - 2016-02-06 13:13:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:13:36 --> Pagination Class Initialized
INFO - 2016-02-06 13:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:13:36 --> Helper loaded: text_helper
INFO - 2016-02-06 13:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 13:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 13:13:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:13:36 --> Final output sent to browser
DEBUG - 2016-02-06 13:13:36 --> Total execution time: 1.2191
INFO - 2016-02-06 13:13:45 --> Config Class Initialized
INFO - 2016-02-06 13:13:45 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:13:45 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:13:45 --> Utf8 Class Initialized
INFO - 2016-02-06 13:13:45 --> URI Class Initialized
DEBUG - 2016-02-06 13:13:45 --> No URI present. Default controller set.
INFO - 2016-02-06 13:13:45 --> Router Class Initialized
INFO - 2016-02-06 13:13:45 --> Output Class Initialized
INFO - 2016-02-06 13:13:45 --> Security Class Initialized
DEBUG - 2016-02-06 13:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:13:45 --> Input Class Initialized
INFO - 2016-02-06 13:13:45 --> Language Class Initialized
INFO - 2016-02-06 13:13:45 --> Loader Class Initialized
INFO - 2016-02-06 13:13:45 --> Helper loaded: url_helper
INFO - 2016-02-06 13:13:45 --> Helper loaded: file_helper
INFO - 2016-02-06 13:13:45 --> Helper loaded: date_helper
INFO - 2016-02-06 13:13:45 --> Helper loaded: form_helper
INFO - 2016-02-06 13:13:45 --> Database Driver Class Initialized
INFO - 2016-02-06 13:13:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:13:46 --> Controller Class Initialized
INFO - 2016-02-06 13:13:46 --> Model Class Initialized
INFO - 2016-02-06 13:13:46 --> Model Class Initialized
INFO - 2016-02-06 13:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:13:46 --> Pagination Class Initialized
INFO - 2016-02-06 13:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 13:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:13:46 --> Final output sent to browser
DEBUG - 2016-02-06 13:13:46 --> Total execution time: 1.1739
INFO - 2016-02-06 13:14:54 --> Config Class Initialized
INFO - 2016-02-06 13:14:54 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:14:54 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:14:54 --> Utf8 Class Initialized
INFO - 2016-02-06 13:14:54 --> URI Class Initialized
DEBUG - 2016-02-06 13:14:54 --> No URI present. Default controller set.
INFO - 2016-02-06 13:14:54 --> Router Class Initialized
INFO - 2016-02-06 13:14:54 --> Output Class Initialized
INFO - 2016-02-06 13:14:54 --> Security Class Initialized
DEBUG - 2016-02-06 13:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:14:54 --> Input Class Initialized
INFO - 2016-02-06 13:14:54 --> Language Class Initialized
INFO - 2016-02-06 13:14:54 --> Loader Class Initialized
INFO - 2016-02-06 13:14:54 --> Helper loaded: url_helper
INFO - 2016-02-06 13:14:54 --> Helper loaded: file_helper
INFO - 2016-02-06 13:14:54 --> Helper loaded: date_helper
INFO - 2016-02-06 13:14:54 --> Helper loaded: form_helper
INFO - 2016-02-06 13:14:54 --> Database Driver Class Initialized
INFO - 2016-02-06 13:14:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:14:56 --> Controller Class Initialized
INFO - 2016-02-06 13:14:56 --> Model Class Initialized
INFO - 2016-02-06 13:14:56 --> Model Class Initialized
INFO - 2016-02-06 13:14:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:14:56 --> Pagination Class Initialized
INFO - 2016-02-06 13:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 13:14:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:14:56 --> Final output sent to browser
DEBUG - 2016-02-06 13:14:56 --> Total execution time: 1.1670
INFO - 2016-02-06 13:15:14 --> Config Class Initialized
INFO - 2016-02-06 13:15:14 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:15:14 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:15:14 --> Utf8 Class Initialized
INFO - 2016-02-06 13:15:14 --> URI Class Initialized
DEBUG - 2016-02-06 13:15:14 --> No URI present. Default controller set.
INFO - 2016-02-06 13:15:14 --> Router Class Initialized
INFO - 2016-02-06 13:15:14 --> Output Class Initialized
INFO - 2016-02-06 13:15:14 --> Security Class Initialized
DEBUG - 2016-02-06 13:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:15:14 --> Input Class Initialized
INFO - 2016-02-06 13:15:14 --> Language Class Initialized
INFO - 2016-02-06 13:15:14 --> Loader Class Initialized
INFO - 2016-02-06 13:15:14 --> Helper loaded: url_helper
INFO - 2016-02-06 13:15:14 --> Helper loaded: file_helper
INFO - 2016-02-06 13:15:14 --> Helper loaded: date_helper
INFO - 2016-02-06 13:15:14 --> Helper loaded: form_helper
INFO - 2016-02-06 13:15:14 --> Database Driver Class Initialized
INFO - 2016-02-06 13:15:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:15:15 --> Controller Class Initialized
INFO - 2016-02-06 13:15:15 --> Model Class Initialized
INFO - 2016-02-06 13:15:15 --> Model Class Initialized
INFO - 2016-02-06 13:15:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:15:15 --> Pagination Class Initialized
INFO - 2016-02-06 13:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 13:15:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:15:15 --> Final output sent to browser
DEBUG - 2016-02-06 13:15:15 --> Total execution time: 1.1321
INFO - 2016-02-06 13:16:35 --> Config Class Initialized
INFO - 2016-02-06 13:16:35 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:16:35 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:16:35 --> Utf8 Class Initialized
INFO - 2016-02-06 13:16:35 --> URI Class Initialized
INFO - 2016-02-06 13:16:35 --> Router Class Initialized
INFO - 2016-02-06 13:16:35 --> Output Class Initialized
INFO - 2016-02-06 13:16:35 --> Security Class Initialized
DEBUG - 2016-02-06 13:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:16:35 --> Input Class Initialized
INFO - 2016-02-06 13:16:35 --> Language Class Initialized
INFO - 2016-02-06 13:16:35 --> Loader Class Initialized
INFO - 2016-02-06 13:16:35 --> Helper loaded: url_helper
INFO - 2016-02-06 13:16:35 --> Helper loaded: file_helper
INFO - 2016-02-06 13:16:35 --> Helper loaded: date_helper
INFO - 2016-02-06 13:16:35 --> Helper loaded: form_helper
INFO - 2016-02-06 13:16:35 --> Database Driver Class Initialized
INFO - 2016-02-06 13:16:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:16:36 --> Controller Class Initialized
INFO - 2016-02-06 13:16:36 --> Model Class Initialized
INFO - 2016-02-06 13:16:36 --> Model Class Initialized
INFO - 2016-02-06 13:16:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:16:36 --> Pagination Class Initialized
INFO - 2016-02-06 13:16:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:16:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:16:36 --> Helper loaded: text_helper
INFO - 2016-02-06 13:16:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 13:16:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 13:16:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:16:36 --> Final output sent to browser
DEBUG - 2016-02-06 13:16:36 --> Total execution time: 1.2155
INFO - 2016-02-06 13:16:38 --> Config Class Initialized
INFO - 2016-02-06 13:16:38 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:16:38 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:16:38 --> Utf8 Class Initialized
INFO - 2016-02-06 13:16:38 --> URI Class Initialized
INFO - 2016-02-06 13:16:38 --> Router Class Initialized
INFO - 2016-02-06 13:16:38 --> Output Class Initialized
INFO - 2016-02-06 13:16:38 --> Security Class Initialized
DEBUG - 2016-02-06 13:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:16:38 --> Input Class Initialized
INFO - 2016-02-06 13:16:38 --> Language Class Initialized
INFO - 2016-02-06 13:16:38 --> Loader Class Initialized
INFO - 2016-02-06 13:16:38 --> Helper loaded: url_helper
INFO - 2016-02-06 13:16:38 --> Helper loaded: file_helper
INFO - 2016-02-06 13:16:38 --> Helper loaded: date_helper
INFO - 2016-02-06 13:16:38 --> Helper loaded: form_helper
INFO - 2016-02-06 13:16:38 --> Database Driver Class Initialized
INFO - 2016-02-06 13:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:16:39 --> Controller Class Initialized
INFO - 2016-02-06 13:16:39 --> Model Class Initialized
INFO - 2016-02-06 13:16:39 --> Model Class Initialized
INFO - 2016-02-06 13:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:16:39 --> Pagination Class Initialized
INFO - 2016-02-06 13:16:39 --> Form Validation Class Initialized
INFO - 2016-02-06 13:16:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 13:16:39 --> Model Class Initialized
INFO - 2016-02-06 13:16:39 --> Final output sent to browser
DEBUG - 2016-02-06 13:16:39 --> Total execution time: 1.1790
INFO - 2016-02-06 13:17:04 --> Config Class Initialized
INFO - 2016-02-06 13:17:04 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:17:04 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:17:04 --> Utf8 Class Initialized
INFO - 2016-02-06 13:17:04 --> URI Class Initialized
INFO - 2016-02-06 13:17:04 --> Router Class Initialized
INFO - 2016-02-06 13:17:04 --> Output Class Initialized
INFO - 2016-02-06 13:17:04 --> Security Class Initialized
DEBUG - 2016-02-06 13:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:17:04 --> Input Class Initialized
INFO - 2016-02-06 13:17:04 --> Language Class Initialized
INFO - 2016-02-06 13:17:04 --> Loader Class Initialized
INFO - 2016-02-06 13:17:04 --> Helper loaded: url_helper
INFO - 2016-02-06 13:17:04 --> Helper loaded: file_helper
INFO - 2016-02-06 13:17:04 --> Helper loaded: date_helper
INFO - 2016-02-06 13:17:04 --> Helper loaded: form_helper
INFO - 2016-02-06 13:17:04 --> Database Driver Class Initialized
INFO - 2016-02-06 13:17:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:17:05 --> Controller Class Initialized
INFO - 2016-02-06 13:17:05 --> Model Class Initialized
INFO - 2016-02-06 13:17:05 --> Model Class Initialized
INFO - 2016-02-06 13:17:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:17:05 --> Pagination Class Initialized
INFO - 2016-02-06 13:17:05 --> Form Validation Class Initialized
INFO - 2016-02-06 13:17:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 13:17:05 --> Model Class Initialized
INFO - 2016-02-06 13:17:06 --> Final output sent to browser
DEBUG - 2016-02-06 13:17:06 --> Total execution time: 1.1992
INFO - 2016-02-06 13:28:15 --> Config Class Initialized
INFO - 2016-02-06 13:28:15 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:28:15 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:28:15 --> Utf8 Class Initialized
INFO - 2016-02-06 13:28:15 --> URI Class Initialized
DEBUG - 2016-02-06 13:28:15 --> No URI present. Default controller set.
INFO - 2016-02-06 13:28:15 --> Router Class Initialized
INFO - 2016-02-06 13:28:15 --> Output Class Initialized
INFO - 2016-02-06 13:28:15 --> Security Class Initialized
DEBUG - 2016-02-06 13:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:28:15 --> Input Class Initialized
INFO - 2016-02-06 13:28:15 --> Language Class Initialized
INFO - 2016-02-06 13:28:15 --> Loader Class Initialized
INFO - 2016-02-06 13:28:15 --> Helper loaded: url_helper
INFO - 2016-02-06 13:28:15 --> Helper loaded: file_helper
INFO - 2016-02-06 13:28:15 --> Helper loaded: date_helper
INFO - 2016-02-06 13:28:15 --> Helper loaded: form_helper
INFO - 2016-02-06 13:28:15 --> Database Driver Class Initialized
INFO - 2016-02-06 13:28:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:28:16 --> Controller Class Initialized
INFO - 2016-02-06 13:28:16 --> Model Class Initialized
INFO - 2016-02-06 13:28:16 --> Model Class Initialized
INFO - 2016-02-06 13:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:28:16 --> Pagination Class Initialized
INFO - 2016-02-06 13:28:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:28:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:28:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-06 13:28:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:28:16 --> Final output sent to browser
DEBUG - 2016-02-06 13:28:16 --> Total execution time: 1.1618
INFO - 2016-02-06 13:28:18 --> Config Class Initialized
INFO - 2016-02-06 13:28:18 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:28:18 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:28:18 --> Utf8 Class Initialized
INFO - 2016-02-06 13:28:18 --> URI Class Initialized
INFO - 2016-02-06 13:28:18 --> Router Class Initialized
INFO - 2016-02-06 13:28:18 --> Output Class Initialized
INFO - 2016-02-06 13:28:18 --> Security Class Initialized
DEBUG - 2016-02-06 13:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:28:18 --> Input Class Initialized
INFO - 2016-02-06 13:28:18 --> Language Class Initialized
INFO - 2016-02-06 13:28:18 --> Loader Class Initialized
INFO - 2016-02-06 13:28:18 --> Helper loaded: url_helper
INFO - 2016-02-06 13:28:18 --> Helper loaded: file_helper
INFO - 2016-02-06 13:28:18 --> Helper loaded: date_helper
INFO - 2016-02-06 13:28:18 --> Helper loaded: form_helper
INFO - 2016-02-06 13:28:18 --> Database Driver Class Initialized
INFO - 2016-02-06 13:28:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:28:19 --> Controller Class Initialized
INFO - 2016-02-06 13:28:19 --> Model Class Initialized
INFO - 2016-02-06 13:28:19 --> Model Class Initialized
INFO - 2016-02-06 13:28:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:28:19 --> Pagination Class Initialized
INFO - 2016-02-06 13:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:28:19 --> Helper loaded: text_helper
INFO - 2016-02-06 13:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-06 13:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-06 13:28:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:28:19 --> Final output sent to browser
DEBUG - 2016-02-06 13:28:19 --> Total execution time: 1.1717
INFO - 2016-02-06 13:28:23 --> Config Class Initialized
INFO - 2016-02-06 13:28:23 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:28:23 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:28:23 --> Utf8 Class Initialized
INFO - 2016-02-06 13:28:23 --> URI Class Initialized
INFO - 2016-02-06 13:28:23 --> Router Class Initialized
INFO - 2016-02-06 13:28:23 --> Output Class Initialized
INFO - 2016-02-06 13:28:23 --> Security Class Initialized
DEBUG - 2016-02-06 13:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:28:23 --> Input Class Initialized
INFO - 2016-02-06 13:28:23 --> Language Class Initialized
INFO - 2016-02-06 13:28:23 --> Loader Class Initialized
INFO - 2016-02-06 13:28:23 --> Helper loaded: url_helper
INFO - 2016-02-06 13:28:23 --> Helper loaded: file_helper
INFO - 2016-02-06 13:28:23 --> Helper loaded: date_helper
INFO - 2016-02-06 13:28:23 --> Helper loaded: form_helper
INFO - 2016-02-06 13:28:23 --> Database Driver Class Initialized
INFO - 2016-02-06 13:28:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:28:24 --> Controller Class Initialized
INFO - 2016-02-06 13:28:24 --> Model Class Initialized
INFO - 2016-02-06 13:28:24 --> Model Class Initialized
INFO - 2016-02-06 13:28:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:28:24 --> Pagination Class Initialized
INFO - 2016-02-06 13:28:24 --> Form Validation Class Initialized
INFO - 2016-02-06 13:28:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 13:28:24 --> Model Class Initialized
INFO - 2016-02-06 13:28:24 --> Final output sent to browser
DEBUG - 2016-02-06 13:28:24 --> Total execution time: 1.2837
INFO - 2016-02-06 13:32:30 --> Config Class Initialized
INFO - 2016-02-06 13:32:30 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:32:30 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:32:30 --> Utf8 Class Initialized
INFO - 2016-02-06 13:32:30 --> URI Class Initialized
INFO - 2016-02-06 13:32:30 --> Router Class Initialized
INFO - 2016-02-06 13:32:30 --> Output Class Initialized
INFO - 2016-02-06 13:32:30 --> Security Class Initialized
DEBUG - 2016-02-06 13:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:32:30 --> Input Class Initialized
INFO - 2016-02-06 13:32:30 --> Language Class Initialized
INFO - 2016-02-06 13:32:30 --> Loader Class Initialized
INFO - 2016-02-06 13:32:30 --> Helper loaded: url_helper
INFO - 2016-02-06 13:32:30 --> Helper loaded: file_helper
INFO - 2016-02-06 13:32:30 --> Helper loaded: date_helper
INFO - 2016-02-06 13:32:30 --> Helper loaded: form_helper
INFO - 2016-02-06 13:32:30 --> Database Driver Class Initialized
INFO - 2016-02-06 13:32:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:32:31 --> Controller Class Initialized
INFO - 2016-02-06 13:32:31 --> Model Class Initialized
INFO - 2016-02-06 13:32:31 --> Model Class Initialized
INFO - 2016-02-06 13:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:32:31 --> Pagination Class Initialized
INFO - 2016-02-06 13:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:32:31 --> Form Validation Class Initialized
INFO - 2016-02-06 13:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-06 13:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:32:31 --> Final output sent to browser
DEBUG - 2016-02-06 13:32:31 --> Total execution time: 1.1458
INFO - 2016-02-06 13:32:33 --> Config Class Initialized
INFO - 2016-02-06 13:32:33 --> Hooks Class Initialized
DEBUG - 2016-02-06 13:32:33 --> UTF-8 Support Enabled
INFO - 2016-02-06 13:32:33 --> Utf8 Class Initialized
INFO - 2016-02-06 13:32:33 --> URI Class Initialized
INFO - 2016-02-06 13:32:33 --> Router Class Initialized
INFO - 2016-02-06 13:32:33 --> Output Class Initialized
INFO - 2016-02-06 13:32:33 --> Security Class Initialized
DEBUG - 2016-02-06 13:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-06 13:32:33 --> Input Class Initialized
INFO - 2016-02-06 13:32:33 --> Language Class Initialized
INFO - 2016-02-06 13:32:33 --> Loader Class Initialized
INFO - 2016-02-06 13:32:33 --> Helper loaded: url_helper
INFO - 2016-02-06 13:32:33 --> Helper loaded: file_helper
INFO - 2016-02-06 13:32:33 --> Helper loaded: date_helper
INFO - 2016-02-06 13:32:33 --> Helper loaded: form_helper
INFO - 2016-02-06 13:32:33 --> Database Driver Class Initialized
INFO - 2016-02-06 13:32:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-06 13:32:34 --> Controller Class Initialized
INFO - 2016-02-06 13:32:34 --> Model Class Initialized
INFO - 2016-02-06 13:32:34 --> Model Class Initialized
INFO - 2016-02-06 13:32:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-06 13:32:34 --> Pagination Class Initialized
INFO - 2016-02-06 13:32:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-06 13:32:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-06 13:32:34 --> Form Validation Class Initialized
INFO - 2016-02-06 13:32:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-06 13:32:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-06 13:32:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-06 13:32:34 --> Final output sent to browser
DEBUG - 2016-02-06 13:32:34 --> Total execution time: 1.1848
