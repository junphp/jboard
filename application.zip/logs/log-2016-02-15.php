<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-15 07:22:28 --> Config Class Initialized
INFO - 2016-02-15 07:22:28 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:22:29 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:22:29 --> Utf8 Class Initialized
INFO - 2016-02-15 07:22:29 --> URI Class Initialized
INFO - 2016-02-15 07:22:29 --> Router Class Initialized
INFO - 2016-02-15 07:22:29 --> Output Class Initialized
INFO - 2016-02-15 07:22:29 --> Security Class Initialized
DEBUG - 2016-02-15 07:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:22:29 --> Input Class Initialized
INFO - 2016-02-15 07:22:29 --> Language Class Initialized
INFO - 2016-02-15 07:22:29 --> Loader Class Initialized
INFO - 2016-02-15 07:22:29 --> Helper loaded: url_helper
INFO - 2016-02-15 07:22:29 --> Helper loaded: file_helper
INFO - 2016-02-15 07:22:29 --> Helper loaded: date_helper
INFO - 2016-02-15 07:22:29 --> Helper loaded: form_helper
INFO - 2016-02-15 07:22:29 --> Database Driver Class Initialized
INFO - 2016-02-15 07:22:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:22:30 --> Controller Class Initialized
INFO - 2016-02-15 07:22:30 --> Model Class Initialized
INFO - 2016-02-15 07:22:30 --> Model Class Initialized
INFO - 2016-02-15 07:22:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:22:30 --> Pagination Class Initialized
INFO - 2016-02-15 07:22:30 --> Helper loaded: text_helper
INFO - 2016-02-15 10:22:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:22:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 10:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 10:22:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:22:31 --> Final output sent to browser
DEBUG - 2016-02-15 10:22:31 --> Total execution time: 2.4829
INFO - 2016-02-15 07:22:45 --> Config Class Initialized
INFO - 2016-02-15 07:22:45 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:22:45 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:22:45 --> Utf8 Class Initialized
INFO - 2016-02-15 07:22:45 --> URI Class Initialized
INFO - 2016-02-15 07:22:45 --> Router Class Initialized
INFO - 2016-02-15 07:22:45 --> Output Class Initialized
INFO - 2016-02-15 07:22:45 --> Security Class Initialized
DEBUG - 2016-02-15 07:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:22:45 --> Input Class Initialized
INFO - 2016-02-15 07:22:45 --> Language Class Initialized
INFO - 2016-02-15 07:22:45 --> Loader Class Initialized
INFO - 2016-02-15 07:22:45 --> Helper loaded: url_helper
INFO - 2016-02-15 07:22:45 --> Helper loaded: file_helper
INFO - 2016-02-15 07:22:45 --> Helper loaded: date_helper
INFO - 2016-02-15 07:22:45 --> Helper loaded: form_helper
INFO - 2016-02-15 07:22:45 --> Database Driver Class Initialized
INFO - 2016-02-15 07:22:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:22:47 --> Controller Class Initialized
INFO - 2016-02-15 07:22:47 --> Model Class Initialized
INFO - 2016-02-15 07:22:47 --> Model Class Initialized
INFO - 2016-02-15 07:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:22:47 --> Pagination Class Initialized
INFO - 2016-02-15 07:22:47 --> Helper loaded: text_helper
INFO - 2016-02-15 10:22:47 --> Final output sent to browser
DEBUG - 2016-02-15 10:22:47 --> Total execution time: 1.2624
INFO - 2016-02-15 07:22:53 --> Config Class Initialized
INFO - 2016-02-15 07:22:53 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:22:53 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:22:53 --> Utf8 Class Initialized
INFO - 2016-02-15 07:22:53 --> URI Class Initialized
INFO - 2016-02-15 07:22:53 --> Router Class Initialized
INFO - 2016-02-15 07:22:53 --> Output Class Initialized
INFO - 2016-02-15 07:22:53 --> Security Class Initialized
DEBUG - 2016-02-15 07:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:22:53 --> Input Class Initialized
INFO - 2016-02-15 07:22:53 --> Language Class Initialized
INFO - 2016-02-15 07:22:53 --> Loader Class Initialized
INFO - 2016-02-15 07:22:53 --> Helper loaded: url_helper
INFO - 2016-02-15 07:22:53 --> Helper loaded: file_helper
INFO - 2016-02-15 07:22:53 --> Helper loaded: date_helper
INFO - 2016-02-15 07:22:53 --> Helper loaded: form_helper
INFO - 2016-02-15 07:22:53 --> Database Driver Class Initialized
INFO - 2016-02-15 07:22:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:22:54 --> Controller Class Initialized
INFO - 2016-02-15 07:22:54 --> Model Class Initialized
INFO - 2016-02-15 07:22:54 --> Model Class Initialized
INFO - 2016-02-15 07:22:55 --> Form Validation Class Initialized
INFO - 2016-02-15 07:22:55 --> Helper loaded: text_helper
INFO - 2016-02-15 07:22:55 --> Config Class Initialized
INFO - 2016-02-15 07:22:55 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:22:55 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:22:55 --> Utf8 Class Initialized
INFO - 2016-02-15 07:22:55 --> URI Class Initialized
INFO - 2016-02-15 07:22:55 --> Router Class Initialized
INFO - 2016-02-15 07:22:55 --> Output Class Initialized
INFO - 2016-02-15 07:22:55 --> Security Class Initialized
DEBUG - 2016-02-15 07:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:22:55 --> Input Class Initialized
INFO - 2016-02-15 07:22:55 --> Language Class Initialized
INFO - 2016-02-15 07:22:55 --> Loader Class Initialized
INFO - 2016-02-15 07:22:55 --> Helper loaded: url_helper
INFO - 2016-02-15 07:22:55 --> Helper loaded: file_helper
INFO - 2016-02-15 07:22:55 --> Helper loaded: date_helper
INFO - 2016-02-15 07:22:55 --> Helper loaded: form_helper
INFO - 2016-02-15 07:22:55 --> Database Driver Class Initialized
INFO - 2016-02-15 07:22:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:22:56 --> Controller Class Initialized
INFO - 2016-02-15 07:22:56 --> Model Class Initialized
INFO - 2016-02-15 07:22:56 --> Model Class Initialized
INFO - 2016-02-15 07:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:22:56 --> Pagination Class Initialized
INFO - 2016-02-15 07:22:56 --> Helper loaded: text_helper
INFO - 2016-02-15 10:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 10:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 10:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:22:56 --> Final output sent to browser
DEBUG - 2016-02-15 10:22:56 --> Total execution time: 1.3196
INFO - 2016-02-15 07:23:17 --> Config Class Initialized
INFO - 2016-02-15 07:23:17 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:23:17 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:23:17 --> Utf8 Class Initialized
INFO - 2016-02-15 07:23:17 --> URI Class Initialized
INFO - 2016-02-15 07:23:17 --> Router Class Initialized
INFO - 2016-02-15 07:23:17 --> Output Class Initialized
INFO - 2016-02-15 07:23:17 --> Security Class Initialized
DEBUG - 2016-02-15 07:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:23:17 --> Input Class Initialized
INFO - 2016-02-15 07:23:17 --> Language Class Initialized
INFO - 2016-02-15 07:23:17 --> Loader Class Initialized
INFO - 2016-02-15 07:23:17 --> Helper loaded: url_helper
INFO - 2016-02-15 07:23:17 --> Helper loaded: file_helper
INFO - 2016-02-15 07:23:17 --> Helper loaded: date_helper
INFO - 2016-02-15 07:23:17 --> Helper loaded: form_helper
INFO - 2016-02-15 07:23:17 --> Database Driver Class Initialized
INFO - 2016-02-15 07:23:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:23:18 --> Controller Class Initialized
INFO - 2016-02-15 07:23:18 --> Model Class Initialized
INFO - 2016-02-15 07:23:18 --> Model Class Initialized
INFO - 2016-02-15 07:23:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:23:18 --> Pagination Class Initialized
INFO - 2016-02-15 07:23:18 --> Helper loaded: text_helper
INFO - 2016-02-15 10:23:18 --> Final output sent to browser
DEBUG - 2016-02-15 10:23:18 --> Total execution time: 1.1827
INFO - 2016-02-15 07:23:25 --> Config Class Initialized
INFO - 2016-02-15 07:23:25 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:23:25 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:23:25 --> Utf8 Class Initialized
INFO - 2016-02-15 07:23:25 --> URI Class Initialized
INFO - 2016-02-15 07:23:25 --> Router Class Initialized
INFO - 2016-02-15 07:23:25 --> Output Class Initialized
INFO - 2016-02-15 07:23:25 --> Security Class Initialized
DEBUG - 2016-02-15 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:23:25 --> Input Class Initialized
INFO - 2016-02-15 07:23:25 --> Language Class Initialized
INFO - 2016-02-15 07:23:25 --> Loader Class Initialized
INFO - 2016-02-15 07:23:25 --> Helper loaded: url_helper
INFO - 2016-02-15 07:23:25 --> Helper loaded: file_helper
INFO - 2016-02-15 07:23:25 --> Helper loaded: date_helper
INFO - 2016-02-15 07:23:25 --> Helper loaded: form_helper
INFO - 2016-02-15 07:23:25 --> Database Driver Class Initialized
INFO - 2016-02-15 07:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:23:26 --> Controller Class Initialized
INFO - 2016-02-15 07:23:26 --> Model Class Initialized
INFO - 2016-02-15 07:23:26 --> Model Class Initialized
INFO - 2016-02-15 07:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:23:26 --> Pagination Class Initialized
INFO - 2016-02-15 07:23:26 --> Helper loaded: text_helper
INFO - 2016-02-15 10:23:26 --> Final output sent to browser
DEBUG - 2016-02-15 10:23:26 --> Total execution time: 1.1143
INFO - 2016-02-15 07:40:57 --> Config Class Initialized
INFO - 2016-02-15 07:40:57 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:40:57 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:40:57 --> Utf8 Class Initialized
INFO - 2016-02-15 07:40:57 --> URI Class Initialized
INFO - 2016-02-15 07:40:57 --> Router Class Initialized
INFO - 2016-02-15 07:40:57 --> Output Class Initialized
INFO - 2016-02-15 07:40:57 --> Security Class Initialized
DEBUG - 2016-02-15 07:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:40:57 --> Input Class Initialized
INFO - 2016-02-15 07:40:57 --> Language Class Initialized
ERROR - 2016-02-15 07:40:57 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 454
INFO - 2016-02-15 07:42:15 --> Config Class Initialized
INFO - 2016-02-15 07:42:15 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:42:15 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:42:15 --> Utf8 Class Initialized
INFO - 2016-02-15 07:42:15 --> URI Class Initialized
INFO - 2016-02-15 07:42:15 --> Router Class Initialized
INFO - 2016-02-15 07:42:15 --> Output Class Initialized
INFO - 2016-02-15 07:42:15 --> Security Class Initialized
DEBUG - 2016-02-15 07:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:42:15 --> Input Class Initialized
INFO - 2016-02-15 07:42:15 --> Language Class Initialized
ERROR - 2016-02-15 07:42:15 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 454
INFO - 2016-02-15 07:42:42 --> Config Class Initialized
INFO - 2016-02-15 07:42:42 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:42:42 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:42:42 --> Utf8 Class Initialized
INFO - 2016-02-15 07:42:42 --> URI Class Initialized
INFO - 2016-02-15 07:42:42 --> Router Class Initialized
INFO - 2016-02-15 07:42:42 --> Output Class Initialized
INFO - 2016-02-15 07:42:42 --> Security Class Initialized
DEBUG - 2016-02-15 07:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:42:42 --> Input Class Initialized
INFO - 2016-02-15 07:42:42 --> Language Class Initialized
ERROR - 2016-02-15 07:42:43 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 457
INFO - 2016-02-15 07:42:50 --> Config Class Initialized
INFO - 2016-02-15 07:42:50 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:42:50 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:42:50 --> Utf8 Class Initialized
INFO - 2016-02-15 07:42:50 --> URI Class Initialized
INFO - 2016-02-15 07:42:50 --> Router Class Initialized
INFO - 2016-02-15 07:42:50 --> Output Class Initialized
INFO - 2016-02-15 07:42:50 --> Security Class Initialized
DEBUG - 2016-02-15 07:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:42:50 --> Input Class Initialized
INFO - 2016-02-15 07:42:50 --> Language Class Initialized
ERROR - 2016-02-15 07:42:50 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 459
INFO - 2016-02-15 07:42:58 --> Config Class Initialized
INFO - 2016-02-15 07:42:58 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:42:58 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:42:58 --> Utf8 Class Initialized
INFO - 2016-02-15 07:42:58 --> URI Class Initialized
INFO - 2016-02-15 07:42:58 --> Router Class Initialized
INFO - 2016-02-15 07:42:58 --> Output Class Initialized
INFO - 2016-02-15 07:42:58 --> Security Class Initialized
DEBUG - 2016-02-15 07:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:42:58 --> Input Class Initialized
INFO - 2016-02-15 07:42:58 --> Language Class Initialized
INFO - 2016-02-15 07:42:58 --> Loader Class Initialized
INFO - 2016-02-15 07:42:58 --> Helper loaded: url_helper
INFO - 2016-02-15 07:42:58 --> Helper loaded: file_helper
INFO - 2016-02-15 07:42:58 --> Helper loaded: date_helper
INFO - 2016-02-15 07:42:58 --> Helper loaded: form_helper
INFO - 2016-02-15 07:42:58 --> Database Driver Class Initialized
INFO - 2016-02-15 07:42:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:42:59 --> Controller Class Initialized
INFO - 2016-02-15 07:42:59 --> Model Class Initialized
INFO - 2016-02-15 07:42:59 --> Model Class Initialized
INFO - 2016-02-15 07:42:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:42:59 --> Pagination Class Initialized
INFO - 2016-02-15 07:42:59 --> Helper loaded: text_helper
INFO - 2016-02-15 10:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 10:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 10:42:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:42:59 --> Final output sent to browser
DEBUG - 2016-02-15 10:42:59 --> Total execution time: 1.5723
INFO - 2016-02-15 07:43:02 --> Config Class Initialized
INFO - 2016-02-15 07:43:02 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:43:02 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:43:02 --> Utf8 Class Initialized
INFO - 2016-02-15 07:43:02 --> URI Class Initialized
INFO - 2016-02-15 07:43:02 --> Router Class Initialized
INFO - 2016-02-15 07:43:02 --> Output Class Initialized
INFO - 2016-02-15 07:43:02 --> Security Class Initialized
DEBUG - 2016-02-15 07:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:43:02 --> Input Class Initialized
INFO - 2016-02-15 07:43:02 --> Language Class Initialized
INFO - 2016-02-15 07:43:02 --> Loader Class Initialized
INFO - 2016-02-15 07:43:02 --> Helper loaded: url_helper
INFO - 2016-02-15 07:43:02 --> Helper loaded: file_helper
INFO - 2016-02-15 07:43:02 --> Helper loaded: date_helper
INFO - 2016-02-15 07:43:02 --> Helper loaded: form_helper
INFO - 2016-02-15 07:43:02 --> Database Driver Class Initialized
INFO - 2016-02-15 07:43:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:43:03 --> Controller Class Initialized
INFO - 2016-02-15 07:43:03 --> Model Class Initialized
INFO - 2016-02-15 07:43:03 --> Model Class Initialized
INFO - 2016-02-15 07:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:43:03 --> Pagination Class Initialized
INFO - 2016-02-15 07:43:03 --> Helper loaded: text_helper
INFO - 2016-02-15 10:43:03 --> Final output sent to browser
DEBUG - 2016-02-15 10:43:03 --> Total execution time: 1.2028
INFO - 2016-02-15 07:43:11 --> Config Class Initialized
INFO - 2016-02-15 07:43:11 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:43:11 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:43:11 --> Utf8 Class Initialized
INFO - 2016-02-15 07:43:11 --> URI Class Initialized
INFO - 2016-02-15 07:43:11 --> Router Class Initialized
INFO - 2016-02-15 07:43:11 --> Output Class Initialized
INFO - 2016-02-15 07:43:11 --> Security Class Initialized
DEBUG - 2016-02-15 07:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:43:11 --> Input Class Initialized
INFO - 2016-02-15 07:43:11 --> Language Class Initialized
INFO - 2016-02-15 07:43:11 --> Loader Class Initialized
INFO - 2016-02-15 07:43:11 --> Helper loaded: url_helper
INFO - 2016-02-15 07:43:11 --> Helper loaded: file_helper
INFO - 2016-02-15 07:43:11 --> Helper loaded: date_helper
INFO - 2016-02-15 07:43:11 --> Helper loaded: form_helper
INFO - 2016-02-15 07:43:11 --> Database Driver Class Initialized
INFO - 2016-02-15 07:43:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:43:12 --> Controller Class Initialized
INFO - 2016-02-15 07:43:12 --> Model Class Initialized
INFO - 2016-02-15 07:43:12 --> Model Class Initialized
INFO - 2016-02-15 07:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:43:12 --> Pagination Class Initialized
INFO - 2016-02-15 07:43:12 --> Helper loaded: text_helper
INFO - 2016-02-15 10:43:12 --> Final output sent to browser
DEBUG - 2016-02-15 10:43:12 --> Total execution time: 1.1926
INFO - 2016-02-15 07:43:13 --> Config Class Initialized
INFO - 2016-02-15 07:43:13 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:43:13 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:43:13 --> Utf8 Class Initialized
INFO - 2016-02-15 07:43:13 --> URI Class Initialized
INFO - 2016-02-15 07:43:13 --> Router Class Initialized
INFO - 2016-02-15 07:43:13 --> Output Class Initialized
INFO - 2016-02-15 07:43:13 --> Security Class Initialized
DEBUG - 2016-02-15 07:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:43:13 --> Input Class Initialized
INFO - 2016-02-15 07:43:13 --> Language Class Initialized
INFO - 2016-02-15 07:43:13 --> Loader Class Initialized
INFO - 2016-02-15 07:43:13 --> Helper loaded: url_helper
INFO - 2016-02-15 07:43:13 --> Helper loaded: file_helper
INFO - 2016-02-15 07:43:13 --> Helper loaded: date_helper
INFO - 2016-02-15 07:43:13 --> Helper loaded: form_helper
INFO - 2016-02-15 07:43:13 --> Database Driver Class Initialized
INFO - 2016-02-15 07:43:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:43:14 --> Controller Class Initialized
INFO - 2016-02-15 07:43:14 --> Model Class Initialized
INFO - 2016-02-15 07:43:14 --> Model Class Initialized
INFO - 2016-02-15 07:43:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:43:14 --> Pagination Class Initialized
INFO - 2016-02-15 07:43:14 --> Helper loaded: text_helper
INFO - 2016-02-15 10:43:14 --> Final output sent to browser
DEBUG - 2016-02-15 10:43:14 --> Total execution time: 1.1087
INFO - 2016-02-15 07:43:16 --> Config Class Initialized
INFO - 2016-02-15 07:43:16 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:43:16 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:43:16 --> Utf8 Class Initialized
INFO - 2016-02-15 07:43:16 --> URI Class Initialized
INFO - 2016-02-15 07:43:16 --> Router Class Initialized
INFO - 2016-02-15 07:43:16 --> Output Class Initialized
INFO - 2016-02-15 07:43:16 --> Security Class Initialized
DEBUG - 2016-02-15 07:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:43:16 --> Input Class Initialized
INFO - 2016-02-15 07:43:16 --> Language Class Initialized
INFO - 2016-02-15 07:43:16 --> Loader Class Initialized
INFO - 2016-02-15 07:43:16 --> Helper loaded: url_helper
INFO - 2016-02-15 07:43:16 --> Helper loaded: file_helper
INFO - 2016-02-15 07:43:16 --> Helper loaded: date_helper
INFO - 2016-02-15 07:43:16 --> Helper loaded: form_helper
INFO - 2016-02-15 07:43:16 --> Database Driver Class Initialized
INFO - 2016-02-15 07:43:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:43:17 --> Controller Class Initialized
INFO - 2016-02-15 07:43:17 --> Model Class Initialized
INFO - 2016-02-15 07:43:17 --> Model Class Initialized
INFO - 2016-02-15 07:43:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:43:17 --> Pagination Class Initialized
INFO - 2016-02-15 07:43:17 --> Helper loaded: text_helper
INFO - 2016-02-15 10:43:17 --> Final output sent to browser
DEBUG - 2016-02-15 10:43:17 --> Total execution time: 1.1443
INFO - 2016-02-15 07:43:18 --> Config Class Initialized
INFO - 2016-02-15 07:43:18 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:43:18 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:43:18 --> Utf8 Class Initialized
INFO - 2016-02-15 07:43:18 --> URI Class Initialized
INFO - 2016-02-15 07:43:18 --> Router Class Initialized
INFO - 2016-02-15 07:43:18 --> Output Class Initialized
INFO - 2016-02-15 07:43:18 --> Security Class Initialized
DEBUG - 2016-02-15 07:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:43:18 --> Input Class Initialized
INFO - 2016-02-15 07:43:18 --> Language Class Initialized
INFO - 2016-02-15 07:43:18 --> Loader Class Initialized
INFO - 2016-02-15 07:43:18 --> Helper loaded: url_helper
INFO - 2016-02-15 07:43:18 --> Helper loaded: file_helper
INFO - 2016-02-15 07:43:18 --> Helper loaded: date_helper
INFO - 2016-02-15 07:43:18 --> Helper loaded: form_helper
INFO - 2016-02-15 07:43:18 --> Database Driver Class Initialized
INFO - 2016-02-15 07:43:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:43:19 --> Controller Class Initialized
INFO - 2016-02-15 07:43:19 --> Model Class Initialized
INFO - 2016-02-15 07:43:19 --> Model Class Initialized
INFO - 2016-02-15 07:43:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:43:19 --> Pagination Class Initialized
INFO - 2016-02-15 07:43:19 --> Helper loaded: text_helper
INFO - 2016-02-15 10:43:19 --> Final output sent to browser
DEBUG - 2016-02-15 10:43:19 --> Total execution time: 1.2645
INFO - 2016-02-15 07:44:52 --> Config Class Initialized
INFO - 2016-02-15 07:44:52 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:44:52 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:44:52 --> Utf8 Class Initialized
INFO - 2016-02-15 07:44:52 --> URI Class Initialized
DEBUG - 2016-02-15 07:44:52 --> No URI present. Default controller set.
INFO - 2016-02-15 07:44:52 --> Router Class Initialized
INFO - 2016-02-15 07:44:52 --> Output Class Initialized
INFO - 2016-02-15 07:44:52 --> Security Class Initialized
DEBUG - 2016-02-15 07:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:44:52 --> Input Class Initialized
INFO - 2016-02-15 07:44:52 --> Language Class Initialized
INFO - 2016-02-15 07:44:52 --> Loader Class Initialized
INFO - 2016-02-15 07:44:52 --> Helper loaded: url_helper
INFO - 2016-02-15 07:44:52 --> Helper loaded: file_helper
INFO - 2016-02-15 07:44:52 --> Helper loaded: date_helper
INFO - 2016-02-15 07:44:52 --> Helper loaded: form_helper
INFO - 2016-02-15 07:44:52 --> Database Driver Class Initialized
INFO - 2016-02-15 07:44:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:44:53 --> Controller Class Initialized
INFO - 2016-02-15 07:44:53 --> Model Class Initialized
INFO - 2016-02-15 07:44:53 --> Model Class Initialized
INFO - 2016-02-15 07:44:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:44:53 --> Pagination Class Initialized
INFO - 2016-02-15 07:44:53 --> Helper loaded: text_helper
INFO - 2016-02-15 10:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 10:44:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:44:53 --> Final output sent to browser
DEBUG - 2016-02-15 10:44:53 --> Total execution time: 1.1862
INFO - 2016-02-15 07:44:56 --> Config Class Initialized
INFO - 2016-02-15 07:44:56 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:44:56 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:44:56 --> Utf8 Class Initialized
INFO - 2016-02-15 07:44:56 --> URI Class Initialized
INFO - 2016-02-15 07:44:56 --> Router Class Initialized
INFO - 2016-02-15 07:44:56 --> Output Class Initialized
INFO - 2016-02-15 07:44:56 --> Security Class Initialized
DEBUG - 2016-02-15 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:44:56 --> Input Class Initialized
INFO - 2016-02-15 07:44:56 --> Language Class Initialized
INFO - 2016-02-15 07:44:56 --> Loader Class Initialized
INFO - 2016-02-15 07:44:56 --> Helper loaded: url_helper
INFO - 2016-02-15 07:44:56 --> Helper loaded: file_helper
INFO - 2016-02-15 07:44:56 --> Helper loaded: date_helper
INFO - 2016-02-15 07:44:56 --> Helper loaded: form_helper
INFO - 2016-02-15 07:44:56 --> Database Driver Class Initialized
INFO - 2016-02-15 07:44:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:44:57 --> Controller Class Initialized
INFO - 2016-02-15 07:44:57 --> Model Class Initialized
INFO - 2016-02-15 07:44:57 --> Model Class Initialized
INFO - 2016-02-15 07:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:44:57 --> Pagination Class Initialized
INFO - 2016-02-15 07:44:57 --> Helper loaded: text_helper
INFO - 2016-02-15 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:44:57 --> Final output sent to browser
DEBUG - 2016-02-15 10:44:57 --> Total execution time: 1.1737
INFO - 2016-02-15 07:44:58 --> Config Class Initialized
INFO - 2016-02-15 07:44:58 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:44:58 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:44:58 --> Utf8 Class Initialized
INFO - 2016-02-15 07:44:58 --> URI Class Initialized
DEBUG - 2016-02-15 07:44:58 --> No URI present. Default controller set.
INFO - 2016-02-15 07:44:58 --> Router Class Initialized
INFO - 2016-02-15 07:44:58 --> Output Class Initialized
INFO - 2016-02-15 07:44:58 --> Security Class Initialized
DEBUG - 2016-02-15 07:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:44:58 --> Input Class Initialized
INFO - 2016-02-15 07:44:58 --> Language Class Initialized
INFO - 2016-02-15 07:44:58 --> Loader Class Initialized
INFO - 2016-02-15 07:44:58 --> Helper loaded: url_helper
INFO - 2016-02-15 07:44:58 --> Helper loaded: file_helper
INFO - 2016-02-15 07:44:58 --> Helper loaded: date_helper
INFO - 2016-02-15 07:44:58 --> Helper loaded: form_helper
INFO - 2016-02-15 07:44:58 --> Database Driver Class Initialized
INFO - 2016-02-15 07:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:44:59 --> Controller Class Initialized
INFO - 2016-02-15 07:44:59 --> Model Class Initialized
INFO - 2016-02-15 07:44:59 --> Model Class Initialized
INFO - 2016-02-15 07:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:44:59 --> Pagination Class Initialized
INFO - 2016-02-15 07:44:59 --> Helper loaded: text_helper
INFO - 2016-02-15 10:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 10:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:44:59 --> Final output sent to browser
DEBUG - 2016-02-15 10:44:59 --> Total execution time: 1.1130
INFO - 2016-02-15 07:45:01 --> Config Class Initialized
INFO - 2016-02-15 07:45:01 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:45:01 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:45:01 --> Utf8 Class Initialized
INFO - 2016-02-15 07:45:01 --> URI Class Initialized
INFO - 2016-02-15 07:45:01 --> Router Class Initialized
INFO - 2016-02-15 07:45:01 --> Output Class Initialized
INFO - 2016-02-15 07:45:01 --> Security Class Initialized
DEBUG - 2016-02-15 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:45:01 --> Input Class Initialized
INFO - 2016-02-15 07:45:01 --> Language Class Initialized
INFO - 2016-02-15 07:45:01 --> Loader Class Initialized
INFO - 2016-02-15 07:45:01 --> Helper loaded: url_helper
INFO - 2016-02-15 07:45:01 --> Helper loaded: file_helper
INFO - 2016-02-15 07:45:01 --> Helper loaded: date_helper
INFO - 2016-02-15 07:45:01 --> Helper loaded: form_helper
INFO - 2016-02-15 07:45:01 --> Database Driver Class Initialized
INFO - 2016-02-15 07:45:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:45:02 --> Controller Class Initialized
INFO - 2016-02-15 07:45:02 --> Model Class Initialized
INFO - 2016-02-15 07:45:02 --> Model Class Initialized
INFO - 2016-02-15 07:45:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:45:02 --> Pagination Class Initialized
INFO - 2016-02-15 07:45:02 --> Helper loaded: text_helper
INFO - 2016-02-15 10:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 10:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 10:45:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:45:02 --> Final output sent to browser
DEBUG - 2016-02-15 10:45:02 --> Total execution time: 1.1293
INFO - 2016-02-15 07:45:05 --> Config Class Initialized
INFO - 2016-02-15 07:45:05 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:45:05 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:45:05 --> Utf8 Class Initialized
INFO - 2016-02-15 07:45:05 --> URI Class Initialized
INFO - 2016-02-15 07:45:05 --> Router Class Initialized
INFO - 2016-02-15 07:45:05 --> Output Class Initialized
INFO - 2016-02-15 07:45:05 --> Security Class Initialized
DEBUG - 2016-02-15 07:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:45:05 --> Input Class Initialized
INFO - 2016-02-15 07:45:05 --> Language Class Initialized
INFO - 2016-02-15 07:45:05 --> Loader Class Initialized
INFO - 2016-02-15 07:45:05 --> Helper loaded: url_helper
INFO - 2016-02-15 07:45:05 --> Helper loaded: file_helper
INFO - 2016-02-15 07:45:05 --> Helper loaded: date_helper
INFO - 2016-02-15 07:45:05 --> Helper loaded: form_helper
INFO - 2016-02-15 07:45:05 --> Database Driver Class Initialized
INFO - 2016-02-15 07:45:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:45:06 --> Controller Class Initialized
INFO - 2016-02-15 07:45:06 --> Model Class Initialized
INFO - 2016-02-15 07:45:06 --> Model Class Initialized
INFO - 2016-02-15 07:45:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:45:06 --> Pagination Class Initialized
INFO - 2016-02-15 07:45:06 --> Helper loaded: text_helper
INFO - 2016-02-15 10:45:06 --> Final output sent to browser
DEBUG - 2016-02-15 10:45:06 --> Total execution time: 1.1563
INFO - 2016-02-15 07:45:15 --> Config Class Initialized
INFO - 2016-02-15 07:45:15 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:45:15 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:45:15 --> Utf8 Class Initialized
INFO - 2016-02-15 07:45:15 --> URI Class Initialized
INFO - 2016-02-15 07:45:15 --> Router Class Initialized
INFO - 2016-02-15 07:45:15 --> Output Class Initialized
INFO - 2016-02-15 07:45:15 --> Security Class Initialized
DEBUG - 2016-02-15 07:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:45:15 --> Input Class Initialized
INFO - 2016-02-15 07:45:15 --> Language Class Initialized
INFO - 2016-02-15 07:45:15 --> Loader Class Initialized
INFO - 2016-02-15 07:45:15 --> Helper loaded: url_helper
INFO - 2016-02-15 07:45:15 --> Helper loaded: file_helper
INFO - 2016-02-15 07:45:15 --> Helper loaded: date_helper
INFO - 2016-02-15 07:45:15 --> Helper loaded: form_helper
INFO - 2016-02-15 07:45:15 --> Database Driver Class Initialized
INFO - 2016-02-15 07:45:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:45:16 --> Controller Class Initialized
INFO - 2016-02-15 07:45:16 --> Model Class Initialized
INFO - 2016-02-15 07:45:16 --> Model Class Initialized
INFO - 2016-02-15 07:45:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:45:16 --> Pagination Class Initialized
INFO - 2016-02-15 07:45:16 --> Helper loaded: text_helper
INFO - 2016-02-15 10:45:16 --> Final output sent to browser
DEBUG - 2016-02-15 10:45:16 --> Total execution time: 1.1156
INFO - 2016-02-15 07:45:34 --> Config Class Initialized
INFO - 2016-02-15 07:45:34 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:45:34 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:45:34 --> Utf8 Class Initialized
INFO - 2016-02-15 07:45:34 --> URI Class Initialized
INFO - 2016-02-15 07:45:34 --> Router Class Initialized
INFO - 2016-02-15 07:45:34 --> Output Class Initialized
INFO - 2016-02-15 07:45:34 --> Security Class Initialized
DEBUG - 2016-02-15 07:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:45:34 --> Input Class Initialized
INFO - 2016-02-15 07:45:34 --> Language Class Initialized
INFO - 2016-02-15 07:45:34 --> Loader Class Initialized
INFO - 2016-02-15 07:45:34 --> Helper loaded: url_helper
INFO - 2016-02-15 07:45:34 --> Helper loaded: file_helper
INFO - 2016-02-15 07:45:34 --> Helper loaded: date_helper
INFO - 2016-02-15 07:45:34 --> Helper loaded: form_helper
INFO - 2016-02-15 07:45:34 --> Database Driver Class Initialized
INFO - 2016-02-15 07:45:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:45:35 --> Controller Class Initialized
INFO - 2016-02-15 07:45:35 --> Model Class Initialized
INFO - 2016-02-15 07:45:35 --> Model Class Initialized
INFO - 2016-02-15 07:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:45:35 --> Pagination Class Initialized
INFO - 2016-02-15 07:45:35 --> Helper loaded: text_helper
INFO - 2016-02-15 10:45:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:45:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:45:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 10:45:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 10:45:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:45:35 --> Final output sent to browser
DEBUG - 2016-02-15 10:45:35 --> Total execution time: 1.1991
INFO - 2016-02-15 07:45:39 --> Config Class Initialized
INFO - 2016-02-15 07:45:39 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:45:39 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:45:39 --> Utf8 Class Initialized
INFO - 2016-02-15 07:45:39 --> URI Class Initialized
INFO - 2016-02-15 07:45:39 --> Router Class Initialized
INFO - 2016-02-15 07:45:39 --> Output Class Initialized
INFO - 2016-02-15 07:45:39 --> Security Class Initialized
DEBUG - 2016-02-15 07:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:45:39 --> Input Class Initialized
INFO - 2016-02-15 07:45:39 --> Language Class Initialized
INFO - 2016-02-15 07:45:39 --> Loader Class Initialized
INFO - 2016-02-15 07:45:39 --> Helper loaded: url_helper
INFO - 2016-02-15 07:45:39 --> Helper loaded: file_helper
INFO - 2016-02-15 07:45:39 --> Helper loaded: date_helper
INFO - 2016-02-15 07:45:39 --> Helper loaded: form_helper
INFO - 2016-02-15 07:45:39 --> Database Driver Class Initialized
INFO - 2016-02-15 07:45:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:45:40 --> Controller Class Initialized
INFO - 2016-02-15 07:45:40 --> Model Class Initialized
INFO - 2016-02-15 07:45:40 --> Model Class Initialized
INFO - 2016-02-15 07:45:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:45:40 --> Pagination Class Initialized
INFO - 2016-02-15 07:45:40 --> Helper loaded: text_helper
INFO - 2016-02-15 07:45:50 --> Config Class Initialized
INFO - 2016-02-15 07:45:50 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:45:50 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:45:50 --> Utf8 Class Initialized
INFO - 2016-02-15 07:45:50 --> URI Class Initialized
INFO - 2016-02-15 07:45:50 --> Router Class Initialized
INFO - 2016-02-15 07:45:50 --> Output Class Initialized
INFO - 2016-02-15 07:45:50 --> Security Class Initialized
DEBUG - 2016-02-15 07:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:45:50 --> Input Class Initialized
INFO - 2016-02-15 07:45:50 --> Language Class Initialized
INFO - 2016-02-15 07:45:50 --> Loader Class Initialized
INFO - 2016-02-15 07:45:50 --> Helper loaded: url_helper
INFO - 2016-02-15 07:45:50 --> Helper loaded: file_helper
INFO - 2016-02-15 07:45:50 --> Helper loaded: date_helper
INFO - 2016-02-15 07:45:50 --> Helper loaded: form_helper
INFO - 2016-02-15 07:45:50 --> Database Driver Class Initialized
INFO - 2016-02-15 07:45:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:45:51 --> Controller Class Initialized
INFO - 2016-02-15 07:45:51 --> Model Class Initialized
INFO - 2016-02-15 07:45:51 --> Model Class Initialized
INFO - 2016-02-15 07:45:51 --> Form Validation Class Initialized
INFO - 2016-02-15 07:45:51 --> Helper loaded: text_helper
INFO - 2016-02-15 07:45:51 --> Config Class Initialized
INFO - 2016-02-15 07:45:51 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:45:51 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:45:51 --> Utf8 Class Initialized
INFO - 2016-02-15 07:45:51 --> URI Class Initialized
INFO - 2016-02-15 07:45:51 --> Router Class Initialized
INFO - 2016-02-15 07:45:51 --> Output Class Initialized
INFO - 2016-02-15 07:45:51 --> Security Class Initialized
DEBUG - 2016-02-15 07:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:45:51 --> Input Class Initialized
INFO - 2016-02-15 07:45:51 --> Language Class Initialized
INFO - 2016-02-15 07:45:51 --> Loader Class Initialized
INFO - 2016-02-15 07:45:51 --> Helper loaded: url_helper
INFO - 2016-02-15 07:45:51 --> Helper loaded: file_helper
INFO - 2016-02-15 07:45:51 --> Helper loaded: date_helper
INFO - 2016-02-15 07:45:51 --> Helper loaded: form_helper
INFO - 2016-02-15 07:45:51 --> Database Driver Class Initialized
INFO - 2016-02-15 07:45:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:45:53 --> Controller Class Initialized
INFO - 2016-02-15 07:45:53 --> Model Class Initialized
INFO - 2016-02-15 07:45:53 --> Model Class Initialized
INFO - 2016-02-15 07:45:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:45:53 --> Pagination Class Initialized
INFO - 2016-02-15 07:45:53 --> Helper loaded: text_helper
INFO - 2016-02-15 10:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 10:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 10:45:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:45:53 --> Final output sent to browser
DEBUG - 2016-02-15 10:45:53 --> Total execution time: 1.2056
INFO - 2016-02-15 07:45:57 --> Config Class Initialized
INFO - 2016-02-15 07:45:57 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:45:57 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:45:57 --> Utf8 Class Initialized
INFO - 2016-02-15 07:45:57 --> URI Class Initialized
INFO - 2016-02-15 07:45:57 --> Router Class Initialized
INFO - 2016-02-15 07:45:57 --> Output Class Initialized
INFO - 2016-02-15 07:45:57 --> Security Class Initialized
DEBUG - 2016-02-15 07:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:45:57 --> Input Class Initialized
INFO - 2016-02-15 07:45:57 --> Language Class Initialized
INFO - 2016-02-15 07:45:57 --> Loader Class Initialized
INFO - 2016-02-15 07:45:57 --> Helper loaded: url_helper
INFO - 2016-02-15 07:45:57 --> Helper loaded: file_helper
INFO - 2016-02-15 07:45:57 --> Helper loaded: date_helper
INFO - 2016-02-15 07:45:57 --> Helper loaded: form_helper
INFO - 2016-02-15 07:45:57 --> Database Driver Class Initialized
INFO - 2016-02-15 07:45:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:45:58 --> Controller Class Initialized
INFO - 2016-02-15 07:45:58 --> Model Class Initialized
INFO - 2016-02-15 07:45:58 --> Model Class Initialized
INFO - 2016-02-15 07:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:45:58 --> Pagination Class Initialized
INFO - 2016-02-15 07:45:58 --> Helper loaded: text_helper
INFO - 2016-02-15 07:48:02 --> Config Class Initialized
INFO - 2016-02-15 07:48:02 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:48:02 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:48:02 --> Utf8 Class Initialized
INFO - 2016-02-15 07:48:02 --> URI Class Initialized
INFO - 2016-02-15 07:48:02 --> Router Class Initialized
INFO - 2016-02-15 07:48:02 --> Output Class Initialized
INFO - 2016-02-15 07:48:02 --> Security Class Initialized
DEBUG - 2016-02-15 07:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:48:02 --> Input Class Initialized
INFO - 2016-02-15 07:48:02 --> Language Class Initialized
INFO - 2016-02-15 07:48:02 --> Loader Class Initialized
INFO - 2016-02-15 07:48:02 --> Helper loaded: url_helper
INFO - 2016-02-15 07:48:02 --> Helper loaded: file_helper
INFO - 2016-02-15 07:48:02 --> Helper loaded: date_helper
INFO - 2016-02-15 07:48:02 --> Helper loaded: form_helper
INFO - 2016-02-15 07:48:02 --> Database Driver Class Initialized
INFO - 2016-02-15 07:48:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:48:03 --> Controller Class Initialized
INFO - 2016-02-15 07:48:03 --> Model Class Initialized
INFO - 2016-02-15 07:48:03 --> Model Class Initialized
INFO - 2016-02-15 07:48:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:48:03 --> Pagination Class Initialized
INFO - 2016-02-15 07:48:03 --> Helper loaded: text_helper
INFO - 2016-02-15 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 10:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 10:48:03 --> Final output sent to browser
DEBUG - 2016-02-15 10:48:03 --> Total execution time: 1.1924
INFO - 2016-02-15 07:48:05 --> Config Class Initialized
INFO - 2016-02-15 07:48:05 --> Hooks Class Initialized
DEBUG - 2016-02-15 07:48:05 --> UTF-8 Support Enabled
INFO - 2016-02-15 07:48:05 --> Utf8 Class Initialized
INFO - 2016-02-15 07:48:05 --> URI Class Initialized
INFO - 2016-02-15 07:48:05 --> Router Class Initialized
INFO - 2016-02-15 07:48:05 --> Output Class Initialized
INFO - 2016-02-15 07:48:05 --> Security Class Initialized
DEBUG - 2016-02-15 07:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 07:48:05 --> Input Class Initialized
INFO - 2016-02-15 07:48:05 --> Language Class Initialized
INFO - 2016-02-15 07:48:05 --> Loader Class Initialized
INFO - 2016-02-15 07:48:05 --> Helper loaded: url_helper
INFO - 2016-02-15 07:48:05 --> Helper loaded: file_helper
INFO - 2016-02-15 07:48:05 --> Helper loaded: date_helper
INFO - 2016-02-15 07:48:05 --> Helper loaded: form_helper
INFO - 2016-02-15 07:48:05 --> Database Driver Class Initialized
INFO - 2016-02-15 07:48:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 07:48:06 --> Controller Class Initialized
INFO - 2016-02-15 07:48:06 --> Model Class Initialized
INFO - 2016-02-15 07:48:06 --> Model Class Initialized
INFO - 2016-02-15 07:48:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 07:48:06 --> Pagination Class Initialized
INFO - 2016-02-15 07:48:06 --> Helper loaded: text_helper
INFO - 2016-02-15 16:38:09 --> Config Class Initialized
INFO - 2016-02-15 16:38:09 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:38:09 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:38:09 --> Utf8 Class Initialized
INFO - 2016-02-15 16:38:09 --> URI Class Initialized
DEBUG - 2016-02-15 16:38:09 --> No URI present. Default controller set.
INFO - 2016-02-15 16:38:09 --> Router Class Initialized
INFO - 2016-02-15 16:38:09 --> Output Class Initialized
INFO - 2016-02-15 16:38:09 --> Security Class Initialized
DEBUG - 2016-02-15 16:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:38:09 --> Input Class Initialized
INFO - 2016-02-15 16:38:09 --> Language Class Initialized
INFO - 2016-02-15 16:38:09 --> Loader Class Initialized
INFO - 2016-02-15 16:38:09 --> Helper loaded: url_helper
INFO - 2016-02-15 16:38:09 --> Helper loaded: file_helper
INFO - 2016-02-15 16:38:09 --> Helper loaded: date_helper
INFO - 2016-02-15 16:38:09 --> Helper loaded: form_helper
INFO - 2016-02-15 16:38:09 --> Database Driver Class Initialized
INFO - 2016-02-15 16:38:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:38:10 --> Controller Class Initialized
INFO - 2016-02-15 16:38:10 --> Model Class Initialized
INFO - 2016-02-15 16:38:10 --> Model Class Initialized
INFO - 2016-02-15 16:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:38:10 --> Pagination Class Initialized
INFO - 2016-02-15 16:38:10 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 19:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 19:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 19:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 19:38:10 --> Final output sent to browser
DEBUG - 2016-02-15 19:38:10 --> Total execution time: 1.5442
INFO - 2016-02-15 16:38:16 --> Config Class Initialized
INFO - 2016-02-15 16:38:16 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:38:16 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:38:16 --> Utf8 Class Initialized
INFO - 2016-02-15 16:38:16 --> URI Class Initialized
INFO - 2016-02-15 16:38:16 --> Router Class Initialized
INFO - 2016-02-15 16:38:16 --> Output Class Initialized
INFO - 2016-02-15 16:38:16 --> Security Class Initialized
DEBUG - 2016-02-15 16:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:38:16 --> Input Class Initialized
INFO - 2016-02-15 16:38:16 --> Language Class Initialized
INFO - 2016-02-15 16:38:16 --> Loader Class Initialized
INFO - 2016-02-15 16:38:16 --> Helper loaded: url_helper
INFO - 2016-02-15 16:38:16 --> Helper loaded: file_helper
INFO - 2016-02-15 16:38:16 --> Helper loaded: date_helper
INFO - 2016-02-15 16:38:16 --> Helper loaded: form_helper
INFO - 2016-02-15 16:38:16 --> Database Driver Class Initialized
INFO - 2016-02-15 16:38:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:38:17 --> Controller Class Initialized
INFO - 2016-02-15 16:38:17 --> Model Class Initialized
INFO - 2016-02-15 16:38:17 --> Model Class Initialized
INFO - 2016-02-15 16:38:17 --> Form Validation Class Initialized
INFO - 2016-02-15 16:38:17 --> Helper loaded: text_helper
INFO - 2016-02-15 16:38:17 --> Config Class Initialized
INFO - 2016-02-15 16:38:17 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:38:17 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:38:17 --> Utf8 Class Initialized
INFO - 2016-02-15 16:38:17 --> URI Class Initialized
DEBUG - 2016-02-15 16:38:17 --> No URI present. Default controller set.
INFO - 2016-02-15 16:38:17 --> Router Class Initialized
INFO - 2016-02-15 16:38:17 --> Output Class Initialized
INFO - 2016-02-15 16:38:17 --> Security Class Initialized
DEBUG - 2016-02-15 16:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:38:17 --> Input Class Initialized
INFO - 2016-02-15 16:38:17 --> Language Class Initialized
INFO - 2016-02-15 16:38:17 --> Loader Class Initialized
INFO - 2016-02-15 16:38:17 --> Helper loaded: url_helper
INFO - 2016-02-15 16:38:17 --> Helper loaded: file_helper
INFO - 2016-02-15 16:38:17 --> Helper loaded: date_helper
INFO - 2016-02-15 16:38:17 --> Helper loaded: form_helper
INFO - 2016-02-15 16:38:17 --> Database Driver Class Initialized
INFO - 2016-02-15 16:38:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:38:18 --> Controller Class Initialized
INFO - 2016-02-15 16:38:18 --> Model Class Initialized
INFO - 2016-02-15 16:38:18 --> Model Class Initialized
INFO - 2016-02-15 16:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:38:18 --> Pagination Class Initialized
INFO - 2016-02-15 16:38:18 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 19:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 19:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 19:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 19:38:18 --> Final output sent to browser
DEBUG - 2016-02-15 19:38:18 --> Total execution time: 1.1183
INFO - 2016-02-15 16:38:22 --> Config Class Initialized
INFO - 2016-02-15 16:38:22 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:38:22 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:38:22 --> Utf8 Class Initialized
INFO - 2016-02-15 16:38:22 --> URI Class Initialized
INFO - 2016-02-15 16:38:22 --> Router Class Initialized
INFO - 2016-02-15 16:38:22 --> Output Class Initialized
INFO - 2016-02-15 16:38:22 --> Security Class Initialized
DEBUG - 2016-02-15 16:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:38:22 --> Input Class Initialized
INFO - 2016-02-15 16:38:22 --> Language Class Initialized
INFO - 2016-02-15 16:38:22 --> Loader Class Initialized
INFO - 2016-02-15 16:38:22 --> Helper loaded: url_helper
INFO - 2016-02-15 16:38:22 --> Helper loaded: file_helper
INFO - 2016-02-15 16:38:22 --> Helper loaded: date_helper
INFO - 2016-02-15 16:38:22 --> Helper loaded: form_helper
INFO - 2016-02-15 16:38:22 --> Database Driver Class Initialized
INFO - 2016-02-15 16:38:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:38:23 --> Controller Class Initialized
INFO - 2016-02-15 16:38:23 --> Model Class Initialized
INFO - 2016-02-15 16:38:23 --> Model Class Initialized
INFO - 2016-02-15 16:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:38:23 --> Pagination Class Initialized
INFO - 2016-02-15 16:38:23 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 19:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 19:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 19:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 19:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 19:38:24 --> Final output sent to browser
DEBUG - 2016-02-15 19:38:24 --> Total execution time: 1.3253
INFO - 2016-02-15 16:38:26 --> Config Class Initialized
INFO - 2016-02-15 16:38:26 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:38:26 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:38:26 --> Utf8 Class Initialized
INFO - 2016-02-15 16:38:26 --> URI Class Initialized
INFO - 2016-02-15 16:38:26 --> Router Class Initialized
INFO - 2016-02-15 16:38:26 --> Output Class Initialized
INFO - 2016-02-15 16:38:26 --> Security Class Initialized
DEBUG - 2016-02-15 16:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:38:26 --> Input Class Initialized
INFO - 2016-02-15 16:38:26 --> Language Class Initialized
INFO - 2016-02-15 16:38:26 --> Loader Class Initialized
INFO - 2016-02-15 16:38:26 --> Helper loaded: url_helper
INFO - 2016-02-15 16:38:26 --> Helper loaded: file_helper
INFO - 2016-02-15 16:38:26 --> Helper loaded: date_helper
INFO - 2016-02-15 16:38:26 --> Helper loaded: form_helper
INFO - 2016-02-15 16:38:26 --> Database Driver Class Initialized
INFO - 2016-02-15 16:38:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:38:27 --> Controller Class Initialized
INFO - 2016-02-15 16:38:27 --> Model Class Initialized
INFO - 2016-02-15 16:38:27 --> Model Class Initialized
INFO - 2016-02-15 16:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:38:27 --> Pagination Class Initialized
INFO - 2016-02-15 16:38:27 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:27 --> Final output sent to browser
DEBUG - 2016-02-15 19:38:27 --> Total execution time: 1.1433
INFO - 2016-02-15 16:38:33 --> Config Class Initialized
INFO - 2016-02-15 16:38:33 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:38:33 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:38:33 --> Utf8 Class Initialized
INFO - 2016-02-15 16:38:33 --> URI Class Initialized
INFO - 2016-02-15 16:38:33 --> Router Class Initialized
INFO - 2016-02-15 16:38:33 --> Output Class Initialized
INFO - 2016-02-15 16:38:33 --> Security Class Initialized
DEBUG - 2016-02-15 16:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:38:33 --> Input Class Initialized
INFO - 2016-02-15 16:38:33 --> Language Class Initialized
INFO - 2016-02-15 16:38:33 --> Loader Class Initialized
INFO - 2016-02-15 16:38:33 --> Helper loaded: url_helper
INFO - 2016-02-15 16:38:33 --> Helper loaded: file_helper
INFO - 2016-02-15 16:38:33 --> Helper loaded: date_helper
INFO - 2016-02-15 16:38:33 --> Helper loaded: form_helper
INFO - 2016-02-15 16:38:33 --> Database Driver Class Initialized
INFO - 2016-02-15 16:38:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:38:34 --> Controller Class Initialized
INFO - 2016-02-15 16:38:34 --> Model Class Initialized
INFO - 2016-02-15 16:38:34 --> Model Class Initialized
INFO - 2016-02-15 16:38:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:38:34 --> Pagination Class Initialized
INFO - 2016-02-15 16:38:34 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:34 --> Final output sent to browser
DEBUG - 2016-02-15 19:38:34 --> Total execution time: 1.1461
INFO - 2016-02-15 16:40:33 --> Config Class Initialized
INFO - 2016-02-15 16:40:33 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:40:33 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:40:33 --> Utf8 Class Initialized
INFO - 2016-02-15 16:40:33 --> URI Class Initialized
INFO - 2016-02-15 16:40:33 --> Router Class Initialized
INFO - 2016-02-15 16:40:33 --> Output Class Initialized
INFO - 2016-02-15 16:40:33 --> Security Class Initialized
DEBUG - 2016-02-15 16:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:40:33 --> Input Class Initialized
INFO - 2016-02-15 16:40:33 --> Language Class Initialized
ERROR - 2016-02-15 16:40:33 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 440
INFO - 2016-02-15 16:40:44 --> Config Class Initialized
INFO - 2016-02-15 16:40:44 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:40:44 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:40:44 --> Utf8 Class Initialized
INFO - 2016-02-15 16:40:44 --> URI Class Initialized
INFO - 2016-02-15 16:40:44 --> Router Class Initialized
INFO - 2016-02-15 16:40:44 --> Output Class Initialized
INFO - 2016-02-15 16:40:44 --> Security Class Initialized
DEBUG - 2016-02-15 16:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:40:44 --> Input Class Initialized
INFO - 2016-02-15 16:40:44 --> Language Class Initialized
ERROR - 2016-02-15 16:40:44 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 440
INFO - 2016-02-15 16:41:23 --> Config Class Initialized
INFO - 2016-02-15 16:41:23 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:41:23 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:41:23 --> Utf8 Class Initialized
INFO - 2016-02-15 16:41:23 --> URI Class Initialized
INFO - 2016-02-15 16:41:23 --> Router Class Initialized
INFO - 2016-02-15 16:41:23 --> Output Class Initialized
INFO - 2016-02-15 16:41:23 --> Security Class Initialized
DEBUG - 2016-02-15 16:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:41:23 --> Input Class Initialized
INFO - 2016-02-15 16:41:23 --> Language Class Initialized
ERROR - 2016-02-15 16:41:23 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 440
INFO - 2016-02-15 16:48:59 --> Config Class Initialized
INFO - 2016-02-15 16:48:59 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:48:59 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:48:59 --> Utf8 Class Initialized
INFO - 2016-02-15 16:48:59 --> URI Class Initialized
INFO - 2016-02-15 16:48:59 --> Router Class Initialized
INFO - 2016-02-15 16:48:59 --> Output Class Initialized
INFO - 2016-02-15 16:48:59 --> Security Class Initialized
DEBUG - 2016-02-15 16:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:48:59 --> Input Class Initialized
INFO - 2016-02-15 16:48:59 --> Language Class Initialized
ERROR - 2016-02-15 16:48:59 --> Severity: Parsing Error --> syntax error, unexpected '{', expecting '(' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 440
INFO - 2016-02-15 16:49:04 --> Config Class Initialized
INFO - 2016-02-15 16:49:04 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:49:04 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:49:04 --> Utf8 Class Initialized
INFO - 2016-02-15 16:49:04 --> URI Class Initialized
INFO - 2016-02-15 16:49:04 --> Router Class Initialized
INFO - 2016-02-15 16:49:04 --> Output Class Initialized
INFO - 2016-02-15 16:49:04 --> Security Class Initialized
DEBUG - 2016-02-15 16:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:49:04 --> Input Class Initialized
INFO - 2016-02-15 16:49:04 --> Language Class Initialized
ERROR - 2016-02-15 16:49:04 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 444
INFO - 2016-02-15 16:50:07 --> Config Class Initialized
INFO - 2016-02-15 16:50:07 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:50:07 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:50:07 --> Utf8 Class Initialized
INFO - 2016-02-15 16:50:07 --> URI Class Initialized
INFO - 2016-02-15 16:50:07 --> Router Class Initialized
INFO - 2016-02-15 16:50:07 --> Output Class Initialized
INFO - 2016-02-15 16:50:07 --> Security Class Initialized
DEBUG - 2016-02-15 16:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:50:07 --> Input Class Initialized
INFO - 2016-02-15 16:50:07 --> Language Class Initialized
INFO - 2016-02-15 16:50:07 --> Loader Class Initialized
INFO - 2016-02-15 16:50:07 --> Helper loaded: url_helper
INFO - 2016-02-15 16:50:07 --> Helper loaded: file_helper
INFO - 2016-02-15 16:50:07 --> Helper loaded: date_helper
INFO - 2016-02-15 16:50:07 --> Helper loaded: form_helper
INFO - 2016-02-15 16:50:07 --> Database Driver Class Initialized
INFO - 2016-02-15 16:50:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:50:08 --> Controller Class Initialized
INFO - 2016-02-15 16:50:08 --> Model Class Initialized
INFO - 2016-02-15 16:50:08 --> Model Class Initialized
INFO - 2016-02-15 16:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:50:08 --> Pagination Class Initialized
INFO - 2016-02-15 16:50:08 --> Helper loaded: text_helper
INFO - 2016-02-15 19:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 19:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 19:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 19:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 19:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 19:50:08 --> Final output sent to browser
DEBUG - 2016-02-15 19:50:08 --> Total execution time: 1.1898
INFO - 2016-02-15 16:50:11 --> Config Class Initialized
INFO - 2016-02-15 16:50:11 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:50:11 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:50:11 --> Utf8 Class Initialized
INFO - 2016-02-15 16:50:11 --> URI Class Initialized
INFO - 2016-02-15 16:50:11 --> Router Class Initialized
INFO - 2016-02-15 16:50:11 --> Output Class Initialized
INFO - 2016-02-15 16:50:11 --> Security Class Initialized
DEBUG - 2016-02-15 16:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:50:11 --> Input Class Initialized
INFO - 2016-02-15 16:50:11 --> Language Class Initialized
INFO - 2016-02-15 16:50:11 --> Loader Class Initialized
INFO - 2016-02-15 16:50:11 --> Helper loaded: url_helper
INFO - 2016-02-15 16:50:11 --> Helper loaded: file_helper
INFO - 2016-02-15 16:50:11 --> Helper loaded: date_helper
INFO - 2016-02-15 16:50:11 --> Helper loaded: form_helper
INFO - 2016-02-15 16:50:11 --> Database Driver Class Initialized
INFO - 2016-02-15 16:50:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:50:12 --> Controller Class Initialized
INFO - 2016-02-15 16:50:12 --> Model Class Initialized
INFO - 2016-02-15 16:50:12 --> Model Class Initialized
INFO - 2016-02-15 16:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:50:12 --> Pagination Class Initialized
INFO - 2016-02-15 16:50:12 --> Helper loaded: text_helper
INFO - 2016-02-15 19:50:12 --> Final output sent to browser
DEBUG - 2016-02-15 19:50:12 --> Total execution time: 1.1748
INFO - 2016-02-15 16:50:26 --> Config Class Initialized
INFO - 2016-02-15 16:50:26 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:50:26 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:50:26 --> Utf8 Class Initialized
INFO - 2016-02-15 16:50:26 --> URI Class Initialized
INFO - 2016-02-15 16:50:26 --> Router Class Initialized
INFO - 2016-02-15 16:50:26 --> Output Class Initialized
INFO - 2016-02-15 16:50:26 --> Security Class Initialized
DEBUG - 2016-02-15 16:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:50:26 --> Input Class Initialized
INFO - 2016-02-15 16:50:26 --> Language Class Initialized
INFO - 2016-02-15 16:50:26 --> Loader Class Initialized
INFO - 2016-02-15 16:50:26 --> Helper loaded: url_helper
INFO - 2016-02-15 16:50:26 --> Helper loaded: file_helper
INFO - 2016-02-15 16:50:26 --> Helper loaded: date_helper
INFO - 2016-02-15 16:50:26 --> Helper loaded: form_helper
INFO - 2016-02-15 16:50:26 --> Database Driver Class Initialized
INFO - 2016-02-15 16:50:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:50:27 --> Controller Class Initialized
INFO - 2016-02-15 16:50:27 --> Model Class Initialized
INFO - 2016-02-15 16:50:27 --> Model Class Initialized
INFO - 2016-02-15 16:50:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:50:27 --> Pagination Class Initialized
INFO - 2016-02-15 16:50:27 --> Helper loaded: text_helper
INFO - 2016-02-15 19:50:27 --> Final output sent to browser
DEBUG - 2016-02-15 19:50:27 --> Total execution time: 1.1397
INFO - 2016-02-15 16:53:13 --> Config Class Initialized
INFO - 2016-02-15 16:53:13 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:53:13 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:53:13 --> Utf8 Class Initialized
INFO - 2016-02-15 16:53:13 --> URI Class Initialized
INFO - 2016-02-15 16:53:13 --> Router Class Initialized
INFO - 2016-02-15 16:53:13 --> Output Class Initialized
INFO - 2016-02-15 16:53:13 --> Security Class Initialized
DEBUG - 2016-02-15 16:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:53:13 --> Input Class Initialized
INFO - 2016-02-15 16:53:13 --> Language Class Initialized
INFO - 2016-02-15 16:53:13 --> Loader Class Initialized
INFO - 2016-02-15 16:53:13 --> Helper loaded: url_helper
INFO - 2016-02-15 16:53:13 --> Helper loaded: file_helper
INFO - 2016-02-15 16:53:13 --> Helper loaded: date_helper
INFO - 2016-02-15 16:53:13 --> Helper loaded: form_helper
INFO - 2016-02-15 16:53:13 --> Database Driver Class Initialized
INFO - 2016-02-15 16:53:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:53:14 --> Controller Class Initialized
INFO - 2016-02-15 16:53:14 --> Model Class Initialized
INFO - 2016-02-15 16:53:14 --> Model Class Initialized
INFO - 2016-02-15 16:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:53:14 --> Pagination Class Initialized
INFO - 2016-02-15 16:53:14 --> Helper loaded: text_helper
INFO - 2016-02-15 19:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 19:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 19:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 19:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 19:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 19:53:14 --> Final output sent to browser
DEBUG - 2016-02-15 19:53:14 --> Total execution time: 1.1726
INFO - 2016-02-15 16:53:17 --> Config Class Initialized
INFO - 2016-02-15 16:53:17 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:53:17 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:53:17 --> Utf8 Class Initialized
INFO - 2016-02-15 16:53:17 --> URI Class Initialized
INFO - 2016-02-15 16:53:17 --> Router Class Initialized
INFO - 2016-02-15 16:53:17 --> Output Class Initialized
INFO - 2016-02-15 16:53:17 --> Security Class Initialized
DEBUG - 2016-02-15 16:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:53:17 --> Input Class Initialized
INFO - 2016-02-15 16:53:17 --> Language Class Initialized
INFO - 2016-02-15 16:53:17 --> Loader Class Initialized
INFO - 2016-02-15 16:53:17 --> Helper loaded: url_helper
INFO - 2016-02-15 16:53:17 --> Helper loaded: file_helper
INFO - 2016-02-15 16:53:17 --> Helper loaded: date_helper
INFO - 2016-02-15 16:53:17 --> Helper loaded: form_helper
INFO - 2016-02-15 16:53:17 --> Database Driver Class Initialized
INFO - 2016-02-15 16:53:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:53:18 --> Controller Class Initialized
INFO - 2016-02-15 16:53:18 --> Model Class Initialized
INFO - 2016-02-15 16:53:18 --> Model Class Initialized
INFO - 2016-02-15 16:53:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:53:18 --> Pagination Class Initialized
INFO - 2016-02-15 16:53:18 --> Helper loaded: text_helper
INFO - 2016-02-15 19:53:18 --> Final output sent to browser
DEBUG - 2016-02-15 19:53:18 --> Total execution time: 1.1186
INFO - 2016-02-15 16:53:23 --> Config Class Initialized
INFO - 2016-02-15 16:53:23 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:53:23 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:53:23 --> Utf8 Class Initialized
INFO - 2016-02-15 16:53:23 --> URI Class Initialized
INFO - 2016-02-15 16:53:23 --> Router Class Initialized
INFO - 2016-02-15 16:53:23 --> Output Class Initialized
INFO - 2016-02-15 16:53:23 --> Security Class Initialized
DEBUG - 2016-02-15 16:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:53:23 --> Input Class Initialized
INFO - 2016-02-15 16:53:23 --> Language Class Initialized
INFO - 2016-02-15 16:53:23 --> Loader Class Initialized
INFO - 2016-02-15 16:53:23 --> Helper loaded: url_helper
INFO - 2016-02-15 16:53:23 --> Helper loaded: file_helper
INFO - 2016-02-15 16:53:23 --> Helper loaded: date_helper
INFO - 2016-02-15 16:53:23 --> Helper loaded: form_helper
INFO - 2016-02-15 16:53:23 --> Database Driver Class Initialized
INFO - 2016-02-15 16:53:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:53:24 --> Controller Class Initialized
INFO - 2016-02-15 16:53:24 --> Model Class Initialized
INFO - 2016-02-15 16:53:24 --> Model Class Initialized
INFO - 2016-02-15 16:53:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:53:24 --> Pagination Class Initialized
INFO - 2016-02-15 16:53:24 --> Helper loaded: text_helper
INFO - 2016-02-15 19:53:25 --> Final output sent to browser
DEBUG - 2016-02-15 19:53:25 --> Total execution time: 1.1314
INFO - 2016-02-15 16:54:07 --> Config Class Initialized
INFO - 2016-02-15 16:54:07 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:54:07 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:54:07 --> Utf8 Class Initialized
INFO - 2016-02-15 16:54:07 --> URI Class Initialized
INFO - 2016-02-15 16:54:07 --> Router Class Initialized
INFO - 2016-02-15 16:54:07 --> Output Class Initialized
INFO - 2016-02-15 16:54:07 --> Security Class Initialized
DEBUG - 2016-02-15 16:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:54:07 --> Input Class Initialized
INFO - 2016-02-15 16:54:07 --> Language Class Initialized
INFO - 2016-02-15 16:54:07 --> Loader Class Initialized
INFO - 2016-02-15 16:54:07 --> Helper loaded: url_helper
INFO - 2016-02-15 16:54:07 --> Helper loaded: file_helper
INFO - 2016-02-15 16:54:07 --> Helper loaded: date_helper
INFO - 2016-02-15 16:54:07 --> Helper loaded: form_helper
INFO - 2016-02-15 16:54:07 --> Database Driver Class Initialized
INFO - 2016-02-15 16:54:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:54:08 --> Controller Class Initialized
INFO - 2016-02-15 16:54:08 --> Model Class Initialized
INFO - 2016-02-15 16:54:08 --> Model Class Initialized
INFO - 2016-02-15 16:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:54:08 --> Pagination Class Initialized
INFO - 2016-02-15 16:54:08 --> Helper loaded: text_helper
INFO - 2016-02-15 19:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 19:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 19:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 19:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 19:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 19:54:08 --> Final output sent to browser
DEBUG - 2016-02-15 19:54:08 --> Total execution time: 1.1570
INFO - 2016-02-15 16:54:10 --> Config Class Initialized
INFO - 2016-02-15 16:54:10 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:54:10 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:54:10 --> Utf8 Class Initialized
INFO - 2016-02-15 16:54:10 --> URI Class Initialized
INFO - 2016-02-15 16:54:10 --> Router Class Initialized
INFO - 2016-02-15 16:54:10 --> Output Class Initialized
INFO - 2016-02-15 16:54:10 --> Security Class Initialized
DEBUG - 2016-02-15 16:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:54:10 --> Input Class Initialized
INFO - 2016-02-15 16:54:10 --> Language Class Initialized
INFO - 2016-02-15 16:54:10 --> Loader Class Initialized
INFO - 2016-02-15 16:54:10 --> Helper loaded: url_helper
INFO - 2016-02-15 16:54:10 --> Helper loaded: file_helper
INFO - 2016-02-15 16:54:10 --> Helper loaded: date_helper
INFO - 2016-02-15 16:54:10 --> Helper loaded: form_helper
INFO - 2016-02-15 16:54:10 --> Database Driver Class Initialized
INFO - 2016-02-15 16:54:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:54:11 --> Controller Class Initialized
INFO - 2016-02-15 16:54:11 --> Model Class Initialized
INFO - 2016-02-15 16:54:11 --> Model Class Initialized
INFO - 2016-02-15 16:54:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:54:11 --> Pagination Class Initialized
INFO - 2016-02-15 16:54:11 --> Helper loaded: text_helper
INFO - 2016-02-15 19:54:11 --> Final output sent to browser
DEBUG - 2016-02-15 19:54:11 --> Total execution time: 1.2513
INFO - 2016-02-15 16:54:12 --> Config Class Initialized
INFO - 2016-02-15 16:54:12 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:54:12 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:54:12 --> Utf8 Class Initialized
INFO - 2016-02-15 16:54:12 --> URI Class Initialized
INFO - 2016-02-15 16:54:12 --> Router Class Initialized
INFO - 2016-02-15 16:54:12 --> Output Class Initialized
INFO - 2016-02-15 16:54:12 --> Security Class Initialized
DEBUG - 2016-02-15 16:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:54:12 --> Input Class Initialized
INFO - 2016-02-15 16:54:12 --> Language Class Initialized
INFO - 2016-02-15 16:54:12 --> Loader Class Initialized
INFO - 2016-02-15 16:54:12 --> Helper loaded: url_helper
INFO - 2016-02-15 16:54:12 --> Helper loaded: file_helper
INFO - 2016-02-15 16:54:12 --> Helper loaded: date_helper
INFO - 2016-02-15 16:54:12 --> Helper loaded: form_helper
INFO - 2016-02-15 16:54:12 --> Database Driver Class Initialized
INFO - 2016-02-15 16:54:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:54:13 --> Controller Class Initialized
INFO - 2016-02-15 16:54:13 --> Model Class Initialized
INFO - 2016-02-15 16:54:13 --> Model Class Initialized
INFO - 2016-02-15 16:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:54:13 --> Pagination Class Initialized
INFO - 2016-02-15 16:54:13 --> Helper loaded: text_helper
INFO - 2016-02-15 19:54:13 --> Final output sent to browser
DEBUG - 2016-02-15 19:54:13 --> Total execution time: 1.1505
INFO - 2016-02-15 16:58:43 --> Config Class Initialized
INFO - 2016-02-15 16:58:43 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:58:43 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:58:43 --> Utf8 Class Initialized
INFO - 2016-02-15 16:58:43 --> URI Class Initialized
INFO - 2016-02-15 16:58:43 --> Router Class Initialized
INFO - 2016-02-15 16:58:43 --> Output Class Initialized
INFO - 2016-02-15 16:58:43 --> Security Class Initialized
DEBUG - 2016-02-15 16:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:58:43 --> Input Class Initialized
INFO - 2016-02-15 16:58:43 --> Language Class Initialized
INFO - 2016-02-15 16:58:43 --> Loader Class Initialized
INFO - 2016-02-15 16:58:43 --> Helper loaded: url_helper
INFO - 2016-02-15 16:58:43 --> Helper loaded: file_helper
INFO - 2016-02-15 16:58:43 --> Helper loaded: date_helper
INFO - 2016-02-15 16:58:43 --> Helper loaded: form_helper
INFO - 2016-02-15 16:58:43 --> Database Driver Class Initialized
INFO - 2016-02-15 16:58:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:58:44 --> Controller Class Initialized
INFO - 2016-02-15 16:58:44 --> Model Class Initialized
INFO - 2016-02-15 16:58:44 --> Model Class Initialized
INFO - 2016-02-15 16:58:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:58:44 --> Pagination Class Initialized
INFO - 2016-02-15 16:58:44 --> Helper loaded: text_helper
INFO - 2016-02-15 19:58:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 19:58:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 19:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 19:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 19:58:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 19:58:45 --> Final output sent to browser
DEBUG - 2016-02-15 19:58:45 --> Total execution time: 1.1867
INFO - 2016-02-15 16:58:56 --> Config Class Initialized
INFO - 2016-02-15 16:58:56 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:58:56 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:58:56 --> Utf8 Class Initialized
INFO - 2016-02-15 16:58:56 --> URI Class Initialized
INFO - 2016-02-15 16:58:56 --> Router Class Initialized
INFO - 2016-02-15 16:58:56 --> Output Class Initialized
INFO - 2016-02-15 16:58:56 --> Security Class Initialized
DEBUG - 2016-02-15 16:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:58:56 --> Input Class Initialized
INFO - 2016-02-15 16:58:56 --> Language Class Initialized
INFO - 2016-02-15 16:58:56 --> Loader Class Initialized
INFO - 2016-02-15 16:58:56 --> Helper loaded: url_helper
INFO - 2016-02-15 16:58:56 --> Helper loaded: file_helper
INFO - 2016-02-15 16:58:56 --> Helper loaded: date_helper
INFO - 2016-02-15 16:58:56 --> Helper loaded: form_helper
INFO - 2016-02-15 16:58:56 --> Database Driver Class Initialized
INFO - 2016-02-15 16:58:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:58:57 --> Controller Class Initialized
INFO - 2016-02-15 16:58:57 --> Model Class Initialized
INFO - 2016-02-15 16:58:57 --> Model Class Initialized
INFO - 2016-02-15 16:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:58:57 --> Pagination Class Initialized
INFO - 2016-02-15 16:58:57 --> Helper loaded: text_helper
INFO - 2016-02-15 19:58:57 --> Final output sent to browser
DEBUG - 2016-02-15 19:58:57 --> Total execution time: 1.1560
INFO - 2016-02-15 16:59:17 --> Config Class Initialized
INFO - 2016-02-15 16:59:17 --> Hooks Class Initialized
DEBUG - 2016-02-15 16:59:17 --> UTF-8 Support Enabled
INFO - 2016-02-15 16:59:17 --> Utf8 Class Initialized
INFO - 2016-02-15 16:59:17 --> URI Class Initialized
INFO - 2016-02-15 16:59:17 --> Router Class Initialized
INFO - 2016-02-15 16:59:17 --> Output Class Initialized
INFO - 2016-02-15 16:59:17 --> Security Class Initialized
DEBUG - 2016-02-15 16:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 16:59:17 --> Input Class Initialized
INFO - 2016-02-15 16:59:17 --> Language Class Initialized
INFO - 2016-02-15 16:59:17 --> Loader Class Initialized
INFO - 2016-02-15 16:59:17 --> Helper loaded: url_helper
INFO - 2016-02-15 16:59:17 --> Helper loaded: file_helper
INFO - 2016-02-15 16:59:17 --> Helper loaded: date_helper
INFO - 2016-02-15 16:59:17 --> Helper loaded: form_helper
INFO - 2016-02-15 16:59:17 --> Database Driver Class Initialized
INFO - 2016-02-15 16:59:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 16:59:18 --> Controller Class Initialized
INFO - 2016-02-15 16:59:18 --> Model Class Initialized
INFO - 2016-02-15 16:59:18 --> Model Class Initialized
INFO - 2016-02-15 16:59:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 16:59:18 --> Pagination Class Initialized
INFO - 2016-02-15 16:59:18 --> Helper loaded: text_helper
INFO - 2016-02-15 19:59:18 --> Final output sent to browser
DEBUG - 2016-02-15 19:59:18 --> Total execution time: 1.2169
INFO - 2016-02-15 17:01:14 --> Config Class Initialized
INFO - 2016-02-15 17:01:14 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:01:14 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:01:14 --> Utf8 Class Initialized
INFO - 2016-02-15 17:01:14 --> URI Class Initialized
DEBUG - 2016-02-15 17:01:14 --> No URI present. Default controller set.
INFO - 2016-02-15 17:01:14 --> Router Class Initialized
INFO - 2016-02-15 17:01:14 --> Output Class Initialized
INFO - 2016-02-15 17:01:14 --> Security Class Initialized
DEBUG - 2016-02-15 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:01:14 --> Input Class Initialized
INFO - 2016-02-15 17:01:14 --> Language Class Initialized
INFO - 2016-02-15 17:01:14 --> Loader Class Initialized
INFO - 2016-02-15 17:01:14 --> Helper loaded: url_helper
INFO - 2016-02-15 17:01:14 --> Helper loaded: file_helper
INFO - 2016-02-15 17:01:14 --> Helper loaded: date_helper
INFO - 2016-02-15 17:01:14 --> Helper loaded: form_helper
INFO - 2016-02-15 17:01:14 --> Database Driver Class Initialized
INFO - 2016-02-15 17:01:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:01:15 --> Controller Class Initialized
INFO - 2016-02-15 17:01:15 --> Model Class Initialized
INFO - 2016-02-15 17:01:15 --> Model Class Initialized
INFO - 2016-02-15 17:01:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:01:15 --> Pagination Class Initialized
INFO - 2016-02-15 17:01:15 --> Helper loaded: text_helper
INFO - 2016-02-15 20:01:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:01:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:01:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 20:01:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:01:15 --> Final output sent to browser
DEBUG - 2016-02-15 20:01:15 --> Total execution time: 1.1235
INFO - 2016-02-15 17:01:19 --> Config Class Initialized
INFO - 2016-02-15 17:01:19 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:01:19 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:01:19 --> Utf8 Class Initialized
INFO - 2016-02-15 17:01:19 --> URI Class Initialized
INFO - 2016-02-15 17:01:19 --> Router Class Initialized
INFO - 2016-02-15 17:01:19 --> Output Class Initialized
INFO - 2016-02-15 17:01:19 --> Security Class Initialized
DEBUG - 2016-02-15 17:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:01:19 --> Input Class Initialized
INFO - 2016-02-15 17:01:19 --> Language Class Initialized
INFO - 2016-02-15 17:01:19 --> Loader Class Initialized
INFO - 2016-02-15 17:01:19 --> Helper loaded: url_helper
INFO - 2016-02-15 17:01:19 --> Helper loaded: file_helper
INFO - 2016-02-15 17:01:19 --> Helper loaded: date_helper
INFO - 2016-02-15 17:01:19 --> Helper loaded: form_helper
INFO - 2016-02-15 17:01:19 --> Database Driver Class Initialized
INFO - 2016-02-15 17:01:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:01:20 --> Controller Class Initialized
INFO - 2016-02-15 17:01:20 --> Model Class Initialized
INFO - 2016-02-15 17:01:20 --> Model Class Initialized
INFO - 2016-02-15 17:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:01:20 --> Pagination Class Initialized
INFO - 2016-02-15 17:01:20 --> Helper loaded: text_helper
INFO - 2016-02-15 20:01:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:01:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:01:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:01:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:01:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:01:20 --> Final output sent to browser
DEBUG - 2016-02-15 20:01:20 --> Total execution time: 1.1464
INFO - 2016-02-15 17:01:23 --> Config Class Initialized
INFO - 2016-02-15 17:01:23 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:01:23 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:01:23 --> Utf8 Class Initialized
INFO - 2016-02-15 17:01:23 --> URI Class Initialized
INFO - 2016-02-15 17:01:23 --> Router Class Initialized
INFO - 2016-02-15 17:01:23 --> Output Class Initialized
INFO - 2016-02-15 17:01:23 --> Security Class Initialized
DEBUG - 2016-02-15 17:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:01:23 --> Input Class Initialized
INFO - 2016-02-15 17:01:23 --> Language Class Initialized
INFO - 2016-02-15 17:01:23 --> Loader Class Initialized
INFO - 2016-02-15 17:01:23 --> Helper loaded: url_helper
INFO - 2016-02-15 17:01:23 --> Helper loaded: file_helper
INFO - 2016-02-15 17:01:23 --> Helper loaded: date_helper
INFO - 2016-02-15 17:01:23 --> Helper loaded: form_helper
INFO - 2016-02-15 17:01:23 --> Database Driver Class Initialized
INFO - 2016-02-15 17:01:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:01:24 --> Controller Class Initialized
INFO - 2016-02-15 17:01:24 --> Model Class Initialized
INFO - 2016-02-15 17:01:24 --> Model Class Initialized
INFO - 2016-02-15 17:01:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:01:24 --> Pagination Class Initialized
INFO - 2016-02-15 17:01:24 --> Helper loaded: text_helper
INFO - 2016-02-15 20:01:24 --> Final output sent to browser
DEBUG - 2016-02-15 20:01:24 --> Total execution time: 1.1310
INFO - 2016-02-15 17:02:00 --> Config Class Initialized
INFO - 2016-02-15 17:02:00 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:02:00 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:02:00 --> Utf8 Class Initialized
INFO - 2016-02-15 17:02:00 --> URI Class Initialized
INFO - 2016-02-15 17:02:00 --> Router Class Initialized
INFO - 2016-02-15 17:02:00 --> Output Class Initialized
INFO - 2016-02-15 17:02:00 --> Security Class Initialized
DEBUG - 2016-02-15 17:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:02:00 --> Input Class Initialized
INFO - 2016-02-15 17:02:00 --> Language Class Initialized
INFO - 2016-02-15 17:02:00 --> Loader Class Initialized
INFO - 2016-02-15 17:02:00 --> Helper loaded: url_helper
INFO - 2016-02-15 17:02:00 --> Helper loaded: file_helper
INFO - 2016-02-15 17:02:00 --> Helper loaded: date_helper
INFO - 2016-02-15 17:02:00 --> Helper loaded: form_helper
INFO - 2016-02-15 17:02:00 --> Database Driver Class Initialized
INFO - 2016-02-15 17:02:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:02:01 --> Controller Class Initialized
INFO - 2016-02-15 17:02:01 --> Model Class Initialized
INFO - 2016-02-15 17:02:01 --> Model Class Initialized
INFO - 2016-02-15 17:02:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:02:01 --> Pagination Class Initialized
INFO - 2016-02-15 17:02:01 --> Helper loaded: text_helper
INFO - 2016-02-15 20:02:01 --> Final output sent to browser
DEBUG - 2016-02-15 20:02:01 --> Total execution time: 1.1239
INFO - 2016-02-15 17:03:50 --> Config Class Initialized
INFO - 2016-02-15 17:03:50 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:03:50 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:03:50 --> Utf8 Class Initialized
INFO - 2016-02-15 17:03:50 --> URI Class Initialized
INFO - 2016-02-15 17:03:50 --> Router Class Initialized
INFO - 2016-02-15 17:03:50 --> Output Class Initialized
INFO - 2016-02-15 17:03:50 --> Security Class Initialized
DEBUG - 2016-02-15 17:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:03:50 --> Input Class Initialized
INFO - 2016-02-15 17:03:50 --> Language Class Initialized
INFO - 2016-02-15 17:03:50 --> Loader Class Initialized
INFO - 2016-02-15 17:03:50 --> Helper loaded: url_helper
INFO - 2016-02-15 17:03:50 --> Helper loaded: file_helper
INFO - 2016-02-15 17:03:50 --> Helper loaded: date_helper
INFO - 2016-02-15 17:03:50 --> Helper loaded: form_helper
INFO - 2016-02-15 17:03:50 --> Database Driver Class Initialized
INFO - 2016-02-15 17:03:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:03:51 --> Controller Class Initialized
INFO - 2016-02-15 17:03:51 --> Model Class Initialized
INFO - 2016-02-15 17:03:51 --> Model Class Initialized
INFO - 2016-02-15 17:03:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:03:51 --> Pagination Class Initialized
INFO - 2016-02-15 17:03:51 --> Helper loaded: text_helper
INFO - 2016-02-15 20:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:03:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:03:52 --> Final output sent to browser
DEBUG - 2016-02-15 20:03:52 --> Total execution time: 1.1463
INFO - 2016-02-15 17:03:54 --> Config Class Initialized
INFO - 2016-02-15 17:03:54 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:03:54 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:03:54 --> Utf8 Class Initialized
INFO - 2016-02-15 17:03:54 --> URI Class Initialized
INFO - 2016-02-15 17:03:54 --> Router Class Initialized
INFO - 2016-02-15 17:03:54 --> Output Class Initialized
INFO - 2016-02-15 17:03:54 --> Security Class Initialized
DEBUG - 2016-02-15 17:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:03:54 --> Input Class Initialized
INFO - 2016-02-15 17:03:54 --> Language Class Initialized
INFO - 2016-02-15 17:03:54 --> Loader Class Initialized
INFO - 2016-02-15 17:03:54 --> Helper loaded: url_helper
INFO - 2016-02-15 17:03:54 --> Helper loaded: file_helper
INFO - 2016-02-15 17:03:54 --> Helper loaded: date_helper
INFO - 2016-02-15 17:03:54 --> Helper loaded: form_helper
INFO - 2016-02-15 17:03:54 --> Database Driver Class Initialized
INFO - 2016-02-15 17:03:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:03:55 --> Controller Class Initialized
INFO - 2016-02-15 17:03:55 --> Model Class Initialized
INFO - 2016-02-15 17:03:55 --> Model Class Initialized
INFO - 2016-02-15 17:03:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:03:55 --> Pagination Class Initialized
INFO - 2016-02-15 17:03:55 --> Helper loaded: text_helper
INFO - 2016-02-15 20:03:55 --> Final output sent to browser
DEBUG - 2016-02-15 20:03:55 --> Total execution time: 1.1029
INFO - 2016-02-15 17:04:01 --> Config Class Initialized
INFO - 2016-02-15 17:04:01 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:04:01 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:04:01 --> Utf8 Class Initialized
INFO - 2016-02-15 17:04:01 --> URI Class Initialized
INFO - 2016-02-15 17:04:01 --> Router Class Initialized
INFO - 2016-02-15 17:04:01 --> Output Class Initialized
INFO - 2016-02-15 17:04:01 --> Security Class Initialized
DEBUG - 2016-02-15 17:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:04:01 --> Input Class Initialized
INFO - 2016-02-15 17:04:01 --> Language Class Initialized
INFO - 2016-02-15 17:04:01 --> Loader Class Initialized
INFO - 2016-02-15 17:04:01 --> Helper loaded: url_helper
INFO - 2016-02-15 17:04:01 --> Helper loaded: file_helper
INFO - 2016-02-15 17:04:01 --> Helper loaded: date_helper
INFO - 2016-02-15 17:04:01 --> Helper loaded: form_helper
INFO - 2016-02-15 17:04:01 --> Database Driver Class Initialized
INFO - 2016-02-15 17:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:04:02 --> Controller Class Initialized
INFO - 2016-02-15 17:04:02 --> Model Class Initialized
INFO - 2016-02-15 17:04:02 --> Model Class Initialized
INFO - 2016-02-15 17:04:02 --> Form Validation Class Initialized
INFO - 2016-02-15 17:04:02 --> Helper loaded: text_helper
INFO - 2016-02-15 17:04:02 --> Config Class Initialized
INFO - 2016-02-15 17:04:02 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:04:02 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:04:02 --> Utf8 Class Initialized
INFO - 2016-02-15 17:04:02 --> URI Class Initialized
INFO - 2016-02-15 17:04:02 --> Router Class Initialized
INFO - 2016-02-15 17:04:02 --> Output Class Initialized
INFO - 2016-02-15 17:04:02 --> Security Class Initialized
DEBUG - 2016-02-15 17:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:04:02 --> Input Class Initialized
INFO - 2016-02-15 17:04:02 --> Language Class Initialized
INFO - 2016-02-15 17:04:02 --> Loader Class Initialized
INFO - 2016-02-15 17:04:02 --> Helper loaded: url_helper
INFO - 2016-02-15 17:04:02 --> Helper loaded: file_helper
INFO - 2016-02-15 17:04:02 --> Helper loaded: date_helper
INFO - 2016-02-15 17:04:02 --> Helper loaded: form_helper
INFO - 2016-02-15 17:04:02 --> Database Driver Class Initialized
INFO - 2016-02-15 17:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:04:03 --> Controller Class Initialized
INFO - 2016-02-15 17:04:03 --> Model Class Initialized
INFO - 2016-02-15 17:04:03 --> Model Class Initialized
INFO - 2016-02-15 17:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:04:03 --> Pagination Class Initialized
INFO - 2016-02-15 17:04:03 --> Helper loaded: text_helper
INFO - 2016-02-15 20:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:04:03 --> Final output sent to browser
DEBUG - 2016-02-15 20:04:03 --> Total execution time: 1.1425
INFO - 2016-02-15 17:04:05 --> Config Class Initialized
INFO - 2016-02-15 17:04:05 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:04:05 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:04:05 --> Utf8 Class Initialized
INFO - 2016-02-15 17:04:05 --> URI Class Initialized
INFO - 2016-02-15 17:04:05 --> Router Class Initialized
INFO - 2016-02-15 17:04:05 --> Output Class Initialized
INFO - 2016-02-15 17:04:05 --> Security Class Initialized
DEBUG - 2016-02-15 17:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:04:05 --> Input Class Initialized
INFO - 2016-02-15 17:04:05 --> Language Class Initialized
INFO - 2016-02-15 17:04:05 --> Loader Class Initialized
INFO - 2016-02-15 17:04:05 --> Helper loaded: url_helper
INFO - 2016-02-15 17:04:05 --> Helper loaded: file_helper
INFO - 2016-02-15 17:04:05 --> Helper loaded: date_helper
INFO - 2016-02-15 17:04:05 --> Helper loaded: form_helper
INFO - 2016-02-15 17:04:05 --> Database Driver Class Initialized
INFO - 2016-02-15 17:04:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:04:06 --> Controller Class Initialized
INFO - 2016-02-15 17:04:06 --> Model Class Initialized
INFO - 2016-02-15 17:04:06 --> Model Class Initialized
INFO - 2016-02-15 17:04:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:04:06 --> Pagination Class Initialized
INFO - 2016-02-15 17:04:06 --> Helper loaded: text_helper
INFO - 2016-02-15 20:04:06 --> Final output sent to browser
DEBUG - 2016-02-15 20:04:06 --> Total execution time: 1.0867
INFO - 2016-02-15 17:04:45 --> Config Class Initialized
INFO - 2016-02-15 17:04:45 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:04:45 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:04:45 --> Utf8 Class Initialized
INFO - 2016-02-15 17:04:45 --> URI Class Initialized
INFO - 2016-02-15 17:04:45 --> Router Class Initialized
INFO - 2016-02-15 17:04:45 --> Output Class Initialized
INFO - 2016-02-15 17:04:45 --> Security Class Initialized
DEBUG - 2016-02-15 17:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:04:45 --> Input Class Initialized
INFO - 2016-02-15 17:04:45 --> Language Class Initialized
INFO - 2016-02-15 17:04:45 --> Loader Class Initialized
INFO - 2016-02-15 17:04:45 --> Helper loaded: url_helper
INFO - 2016-02-15 17:04:45 --> Helper loaded: file_helper
INFO - 2016-02-15 17:04:45 --> Helper loaded: date_helper
INFO - 2016-02-15 17:04:45 --> Helper loaded: form_helper
INFO - 2016-02-15 17:04:45 --> Database Driver Class Initialized
INFO - 2016-02-15 17:04:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:04:46 --> Controller Class Initialized
INFO - 2016-02-15 17:04:46 --> Model Class Initialized
INFO - 2016-02-15 17:04:46 --> Model Class Initialized
INFO - 2016-02-15 17:04:46 --> Form Validation Class Initialized
INFO - 2016-02-15 17:04:46 --> Helper loaded: text_helper
INFO - 2016-02-15 17:04:46 --> Config Class Initialized
INFO - 2016-02-15 17:04:46 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:04:46 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:04:46 --> Utf8 Class Initialized
INFO - 2016-02-15 17:04:46 --> URI Class Initialized
INFO - 2016-02-15 17:04:46 --> Router Class Initialized
INFO - 2016-02-15 17:04:46 --> Output Class Initialized
INFO - 2016-02-15 17:04:46 --> Security Class Initialized
DEBUG - 2016-02-15 17:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:04:46 --> Input Class Initialized
INFO - 2016-02-15 17:04:46 --> Language Class Initialized
INFO - 2016-02-15 17:04:46 --> Loader Class Initialized
INFO - 2016-02-15 17:04:46 --> Helper loaded: url_helper
INFO - 2016-02-15 17:04:46 --> Helper loaded: file_helper
INFO - 2016-02-15 17:04:46 --> Helper loaded: date_helper
INFO - 2016-02-15 17:04:46 --> Helper loaded: form_helper
INFO - 2016-02-15 17:04:46 --> Database Driver Class Initialized
INFO - 2016-02-15 17:04:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:04:47 --> Controller Class Initialized
INFO - 2016-02-15 17:04:47 --> Model Class Initialized
INFO - 2016-02-15 17:04:47 --> Model Class Initialized
INFO - 2016-02-15 17:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:04:47 --> Pagination Class Initialized
INFO - 2016-02-15 17:04:47 --> Helper loaded: text_helper
INFO - 2016-02-15 20:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:04:47 --> Final output sent to browser
DEBUG - 2016-02-15 20:04:47 --> Total execution time: 1.1342
INFO - 2016-02-15 17:19:24 --> Config Class Initialized
INFO - 2016-02-15 17:19:24 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:19:24 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:19:24 --> Utf8 Class Initialized
INFO - 2016-02-15 17:19:24 --> URI Class Initialized
INFO - 2016-02-15 17:19:24 --> Router Class Initialized
INFO - 2016-02-15 17:19:24 --> Output Class Initialized
INFO - 2016-02-15 17:19:24 --> Security Class Initialized
DEBUG - 2016-02-15 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:19:24 --> Input Class Initialized
INFO - 2016-02-15 17:19:24 --> Language Class Initialized
INFO - 2016-02-15 17:19:24 --> Loader Class Initialized
INFO - 2016-02-15 17:19:24 --> Helper loaded: url_helper
INFO - 2016-02-15 17:19:24 --> Helper loaded: file_helper
INFO - 2016-02-15 17:19:24 --> Helper loaded: date_helper
INFO - 2016-02-15 17:19:24 --> Helper loaded: form_helper
INFO - 2016-02-15 17:19:24 --> Database Driver Class Initialized
INFO - 2016-02-15 17:19:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:19:25 --> Controller Class Initialized
INFO - 2016-02-15 17:19:25 --> Model Class Initialized
INFO - 2016-02-15 17:19:25 --> Model Class Initialized
INFO - 2016-02-15 17:19:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:19:25 --> Pagination Class Initialized
INFO - 2016-02-15 17:19:25 --> Helper loaded: text_helper
INFO - 2016-02-15 20:19:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:19:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:19:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:19:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:19:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:19:25 --> Final output sent to browser
DEBUG - 2016-02-15 20:19:25 --> Total execution time: 1.1594
INFO - 2016-02-15 17:19:30 --> Config Class Initialized
INFO - 2016-02-15 17:19:30 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:19:30 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:19:30 --> Utf8 Class Initialized
INFO - 2016-02-15 17:19:30 --> URI Class Initialized
INFO - 2016-02-15 17:19:30 --> Router Class Initialized
INFO - 2016-02-15 17:19:30 --> Output Class Initialized
INFO - 2016-02-15 17:19:30 --> Security Class Initialized
DEBUG - 2016-02-15 17:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:19:30 --> Input Class Initialized
INFO - 2016-02-15 17:19:30 --> Language Class Initialized
INFO - 2016-02-15 17:19:30 --> Loader Class Initialized
INFO - 2016-02-15 17:19:30 --> Helper loaded: url_helper
INFO - 2016-02-15 17:19:30 --> Helper loaded: file_helper
INFO - 2016-02-15 17:19:30 --> Helper loaded: date_helper
INFO - 2016-02-15 17:19:30 --> Helper loaded: form_helper
INFO - 2016-02-15 17:19:30 --> Database Driver Class Initialized
INFO - 2016-02-15 17:19:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:19:31 --> Controller Class Initialized
INFO - 2016-02-15 17:19:31 --> Model Class Initialized
INFO - 2016-02-15 17:19:31 --> Model Class Initialized
INFO - 2016-02-15 17:19:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:19:31 --> Pagination Class Initialized
INFO - 2016-02-15 17:19:31 --> Helper loaded: text_helper
INFO - 2016-02-15 17:19:50 --> Config Class Initialized
INFO - 2016-02-15 17:19:50 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:19:50 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:19:50 --> Utf8 Class Initialized
INFO - 2016-02-15 17:19:50 --> URI Class Initialized
INFO - 2016-02-15 17:19:50 --> Router Class Initialized
INFO - 2016-02-15 17:19:50 --> Output Class Initialized
INFO - 2016-02-15 17:19:50 --> Security Class Initialized
DEBUG - 2016-02-15 17:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:19:50 --> Input Class Initialized
INFO - 2016-02-15 17:19:50 --> Language Class Initialized
INFO - 2016-02-15 17:19:50 --> Loader Class Initialized
INFO - 2016-02-15 17:19:50 --> Helper loaded: url_helper
INFO - 2016-02-15 17:19:50 --> Helper loaded: file_helper
INFO - 2016-02-15 17:19:50 --> Helper loaded: date_helper
INFO - 2016-02-15 17:19:50 --> Helper loaded: form_helper
INFO - 2016-02-15 17:19:50 --> Database Driver Class Initialized
INFO - 2016-02-15 17:19:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:19:51 --> Controller Class Initialized
INFO - 2016-02-15 17:19:51 --> Model Class Initialized
INFO - 2016-02-15 17:19:51 --> Model Class Initialized
INFO - 2016-02-15 17:19:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:19:51 --> Pagination Class Initialized
INFO - 2016-02-15 17:19:52 --> Helper loaded: text_helper
INFO - 2016-02-15 17:20:00 --> Config Class Initialized
INFO - 2016-02-15 17:20:00 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:20:00 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:20:00 --> Utf8 Class Initialized
INFO - 2016-02-15 17:20:00 --> URI Class Initialized
INFO - 2016-02-15 17:20:00 --> Router Class Initialized
INFO - 2016-02-15 17:20:00 --> Output Class Initialized
INFO - 2016-02-15 17:20:00 --> Security Class Initialized
DEBUG - 2016-02-15 17:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:20:00 --> Input Class Initialized
INFO - 2016-02-15 17:20:00 --> Language Class Initialized
INFO - 2016-02-15 17:20:00 --> Loader Class Initialized
INFO - 2016-02-15 17:20:00 --> Helper loaded: url_helper
INFO - 2016-02-15 17:20:00 --> Helper loaded: file_helper
INFO - 2016-02-15 17:20:00 --> Helper loaded: date_helper
INFO - 2016-02-15 17:20:00 --> Helper loaded: form_helper
INFO - 2016-02-15 17:20:00 --> Database Driver Class Initialized
INFO - 2016-02-15 17:20:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:20:01 --> Controller Class Initialized
INFO - 2016-02-15 17:20:01 --> Model Class Initialized
INFO - 2016-02-15 17:20:01 --> Model Class Initialized
INFO - 2016-02-15 17:20:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:20:01 --> Pagination Class Initialized
INFO - 2016-02-15 17:20:01 --> Helper loaded: text_helper
INFO - 2016-02-15 17:23:57 --> Config Class Initialized
INFO - 2016-02-15 17:23:57 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:23:57 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:23:57 --> Utf8 Class Initialized
INFO - 2016-02-15 17:23:57 --> URI Class Initialized
DEBUG - 2016-02-15 17:23:57 --> No URI present. Default controller set.
INFO - 2016-02-15 17:23:57 --> Router Class Initialized
INFO - 2016-02-15 17:23:57 --> Output Class Initialized
INFO - 2016-02-15 17:23:57 --> Security Class Initialized
DEBUG - 2016-02-15 17:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:23:57 --> Input Class Initialized
INFO - 2016-02-15 17:23:57 --> Language Class Initialized
INFO - 2016-02-15 17:23:57 --> Loader Class Initialized
INFO - 2016-02-15 17:23:57 --> Helper loaded: url_helper
INFO - 2016-02-15 17:23:57 --> Helper loaded: file_helper
INFO - 2016-02-15 17:23:57 --> Helper loaded: date_helper
INFO - 2016-02-15 17:23:57 --> Helper loaded: form_helper
INFO - 2016-02-15 17:23:57 --> Database Driver Class Initialized
INFO - 2016-02-15 17:23:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:23:58 --> Controller Class Initialized
INFO - 2016-02-15 17:23:58 --> Model Class Initialized
INFO - 2016-02-15 17:23:58 --> Model Class Initialized
INFO - 2016-02-15 17:23:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:23:58 --> Pagination Class Initialized
INFO - 2016-02-15 17:23:58 --> Helper loaded: text_helper
INFO - 2016-02-15 20:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 20:23:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:23:58 --> Final output sent to browser
DEBUG - 2016-02-15 20:23:58 --> Total execution time: 1.1845
INFO - 2016-02-15 17:24:02 --> Config Class Initialized
INFO - 2016-02-15 17:24:02 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:24:02 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:24:02 --> Utf8 Class Initialized
INFO - 2016-02-15 17:24:02 --> URI Class Initialized
INFO - 2016-02-15 17:24:02 --> Router Class Initialized
INFO - 2016-02-15 17:24:02 --> Output Class Initialized
INFO - 2016-02-15 17:24:02 --> Security Class Initialized
DEBUG - 2016-02-15 17:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:24:02 --> Input Class Initialized
INFO - 2016-02-15 17:24:02 --> Language Class Initialized
INFO - 2016-02-15 17:24:02 --> Loader Class Initialized
INFO - 2016-02-15 17:24:02 --> Helper loaded: url_helper
INFO - 2016-02-15 17:24:02 --> Helper loaded: file_helper
INFO - 2016-02-15 17:24:02 --> Helper loaded: date_helper
INFO - 2016-02-15 17:24:02 --> Helper loaded: form_helper
INFO - 2016-02-15 17:24:02 --> Database Driver Class Initialized
INFO - 2016-02-15 17:24:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:24:03 --> Controller Class Initialized
INFO - 2016-02-15 17:24:03 --> Model Class Initialized
INFO - 2016-02-15 17:24:03 --> Model Class Initialized
INFO - 2016-02-15 17:24:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:24:03 --> Pagination Class Initialized
INFO - 2016-02-15 17:24:03 --> Helper loaded: text_helper
INFO - 2016-02-15 20:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:24:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:24:03 --> Final output sent to browser
DEBUG - 2016-02-15 20:24:03 --> Total execution time: 1.1506
INFO - 2016-02-15 17:24:07 --> Config Class Initialized
INFO - 2016-02-15 17:24:07 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:24:07 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:24:07 --> Utf8 Class Initialized
INFO - 2016-02-15 17:24:07 --> URI Class Initialized
INFO - 2016-02-15 17:24:07 --> Router Class Initialized
INFO - 2016-02-15 17:24:07 --> Output Class Initialized
INFO - 2016-02-15 17:24:07 --> Security Class Initialized
DEBUG - 2016-02-15 17:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:24:07 --> Input Class Initialized
INFO - 2016-02-15 17:24:07 --> Language Class Initialized
INFO - 2016-02-15 17:24:07 --> Loader Class Initialized
INFO - 2016-02-15 17:24:07 --> Helper loaded: url_helper
INFO - 2016-02-15 17:24:07 --> Helper loaded: file_helper
INFO - 2016-02-15 17:24:07 --> Helper loaded: date_helper
INFO - 2016-02-15 17:24:07 --> Helper loaded: form_helper
INFO - 2016-02-15 17:24:07 --> Database Driver Class Initialized
INFO - 2016-02-15 17:24:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:24:08 --> Controller Class Initialized
INFO - 2016-02-15 17:24:08 --> Model Class Initialized
INFO - 2016-02-15 17:24:08 --> Model Class Initialized
INFO - 2016-02-15 17:24:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:24:08 --> Pagination Class Initialized
INFO - 2016-02-15 17:24:08 --> Helper loaded: text_helper
INFO - 2016-02-15 17:24:17 --> Config Class Initialized
INFO - 2016-02-15 17:24:17 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:24:17 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:24:17 --> Utf8 Class Initialized
INFO - 2016-02-15 17:24:17 --> URI Class Initialized
INFO - 2016-02-15 17:24:17 --> Router Class Initialized
INFO - 2016-02-15 17:24:17 --> Output Class Initialized
INFO - 2016-02-15 17:24:17 --> Security Class Initialized
DEBUG - 2016-02-15 17:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:24:17 --> Input Class Initialized
INFO - 2016-02-15 17:24:17 --> Language Class Initialized
INFO - 2016-02-15 17:24:17 --> Loader Class Initialized
INFO - 2016-02-15 17:24:17 --> Helper loaded: url_helper
INFO - 2016-02-15 17:24:17 --> Helper loaded: file_helper
INFO - 2016-02-15 17:24:17 --> Helper loaded: date_helper
INFO - 2016-02-15 17:24:17 --> Helper loaded: form_helper
INFO - 2016-02-15 17:24:17 --> Database Driver Class Initialized
INFO - 2016-02-15 17:24:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:24:18 --> Controller Class Initialized
INFO - 2016-02-15 17:24:18 --> Model Class Initialized
INFO - 2016-02-15 17:24:18 --> Model Class Initialized
INFO - 2016-02-15 17:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:24:18 --> Pagination Class Initialized
INFO - 2016-02-15 17:24:18 --> Helper loaded: text_helper
INFO - 2016-02-15 17:24:43 --> Config Class Initialized
INFO - 2016-02-15 17:24:43 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:24:43 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:24:43 --> Utf8 Class Initialized
INFO - 2016-02-15 17:24:43 --> URI Class Initialized
DEBUG - 2016-02-15 17:24:43 --> No URI present. Default controller set.
INFO - 2016-02-15 17:24:43 --> Router Class Initialized
INFO - 2016-02-15 17:24:43 --> Output Class Initialized
INFO - 2016-02-15 17:24:43 --> Security Class Initialized
DEBUG - 2016-02-15 17:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:24:43 --> Input Class Initialized
INFO - 2016-02-15 17:24:43 --> Language Class Initialized
INFO - 2016-02-15 17:24:43 --> Loader Class Initialized
INFO - 2016-02-15 17:24:43 --> Helper loaded: url_helper
INFO - 2016-02-15 17:24:43 --> Helper loaded: file_helper
INFO - 2016-02-15 17:24:43 --> Helper loaded: date_helper
INFO - 2016-02-15 17:24:43 --> Helper loaded: form_helper
INFO - 2016-02-15 17:24:43 --> Database Driver Class Initialized
INFO - 2016-02-15 17:24:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:24:44 --> Controller Class Initialized
INFO - 2016-02-15 17:24:44 --> Model Class Initialized
INFO - 2016-02-15 17:24:44 --> Model Class Initialized
INFO - 2016-02-15 17:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:24:44 --> Pagination Class Initialized
INFO - 2016-02-15 17:24:44 --> Helper loaded: text_helper
INFO - 2016-02-15 20:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 20:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:24:44 --> Final output sent to browser
DEBUG - 2016-02-15 20:24:44 --> Total execution time: 1.1141
INFO - 2016-02-15 17:24:52 --> Config Class Initialized
INFO - 2016-02-15 17:24:52 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:24:52 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:24:52 --> Utf8 Class Initialized
INFO - 2016-02-15 17:24:52 --> URI Class Initialized
INFO - 2016-02-15 17:24:52 --> Router Class Initialized
INFO - 2016-02-15 17:24:52 --> Output Class Initialized
INFO - 2016-02-15 17:24:52 --> Security Class Initialized
DEBUG - 2016-02-15 17:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:24:52 --> Input Class Initialized
INFO - 2016-02-15 17:24:52 --> Language Class Initialized
INFO - 2016-02-15 17:24:52 --> Loader Class Initialized
INFO - 2016-02-15 17:24:52 --> Helper loaded: url_helper
INFO - 2016-02-15 17:24:52 --> Helper loaded: file_helper
INFO - 2016-02-15 17:24:52 --> Helper loaded: date_helper
INFO - 2016-02-15 17:24:52 --> Helper loaded: form_helper
INFO - 2016-02-15 17:24:52 --> Database Driver Class Initialized
INFO - 2016-02-15 17:24:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:24:53 --> Controller Class Initialized
INFO - 2016-02-15 17:24:53 --> Model Class Initialized
INFO - 2016-02-15 17:24:53 --> Model Class Initialized
INFO - 2016-02-15 17:24:53 --> Form Validation Class Initialized
INFO - 2016-02-15 17:24:53 --> Helper loaded: text_helper
INFO - 2016-02-15 17:24:53 --> Config Class Initialized
INFO - 2016-02-15 17:24:53 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:24:53 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:24:53 --> Utf8 Class Initialized
INFO - 2016-02-15 17:24:53 --> URI Class Initialized
INFO - 2016-02-15 17:24:53 --> Router Class Initialized
INFO - 2016-02-15 17:24:53 --> Output Class Initialized
INFO - 2016-02-15 17:24:53 --> Security Class Initialized
DEBUG - 2016-02-15 17:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:24:53 --> Input Class Initialized
INFO - 2016-02-15 17:24:53 --> Language Class Initialized
INFO - 2016-02-15 17:24:53 --> Loader Class Initialized
INFO - 2016-02-15 17:24:53 --> Helper loaded: url_helper
INFO - 2016-02-15 17:24:53 --> Helper loaded: file_helper
INFO - 2016-02-15 17:24:53 --> Helper loaded: date_helper
INFO - 2016-02-15 17:24:53 --> Helper loaded: form_helper
INFO - 2016-02-15 17:24:53 --> Database Driver Class Initialized
INFO - 2016-02-15 17:24:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:24:54 --> Controller Class Initialized
INFO - 2016-02-15 17:24:54 --> Model Class Initialized
INFO - 2016-02-15 17:24:54 --> Model Class Initialized
INFO - 2016-02-15 17:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:24:54 --> Pagination Class Initialized
INFO - 2016-02-15 17:24:54 --> Helper loaded: text_helper
INFO - 2016-02-15 20:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 20:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:24:54 --> Final output sent to browser
DEBUG - 2016-02-15 20:24:54 --> Total execution time: 1.1059
INFO - 2016-02-15 17:25:01 --> Config Class Initialized
INFO - 2016-02-15 17:25:01 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:25:01 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:25:01 --> Utf8 Class Initialized
INFO - 2016-02-15 17:25:01 --> URI Class Initialized
INFO - 2016-02-15 17:25:01 --> Router Class Initialized
INFO - 2016-02-15 17:25:01 --> Output Class Initialized
INFO - 2016-02-15 17:25:01 --> Security Class Initialized
DEBUG - 2016-02-15 17:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:25:01 --> Input Class Initialized
INFO - 2016-02-15 17:25:01 --> Language Class Initialized
INFO - 2016-02-15 17:25:01 --> Loader Class Initialized
INFO - 2016-02-15 17:25:01 --> Helper loaded: url_helper
INFO - 2016-02-15 17:25:01 --> Helper loaded: file_helper
INFO - 2016-02-15 17:25:01 --> Helper loaded: date_helper
INFO - 2016-02-15 17:25:01 --> Helper loaded: form_helper
INFO - 2016-02-15 17:25:01 --> Database Driver Class Initialized
INFO - 2016-02-15 17:25:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:25:02 --> Controller Class Initialized
INFO - 2016-02-15 17:25:02 --> Model Class Initialized
INFO - 2016-02-15 17:25:02 --> Model Class Initialized
INFO - 2016-02-15 17:25:02 --> Form Validation Class Initialized
INFO - 2016-02-15 17:25:02 --> Helper loaded: text_helper
INFO - 2016-02-15 17:25:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 17:25:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 17:25:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-15 17:25:02 --> Model Class Initialized
INFO - 2016-02-15 17:25:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 17:25:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 17:25:02 --> Final output sent to browser
DEBUG - 2016-02-15 17:25:02 --> Total execution time: 1.1572
INFO - 2016-02-15 17:25:43 --> Config Class Initialized
INFO - 2016-02-15 17:25:43 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:25:43 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:25:43 --> Utf8 Class Initialized
INFO - 2016-02-15 17:25:43 --> URI Class Initialized
INFO - 2016-02-15 17:25:43 --> Router Class Initialized
INFO - 2016-02-15 17:25:43 --> Output Class Initialized
INFO - 2016-02-15 17:25:43 --> Security Class Initialized
DEBUG - 2016-02-15 17:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:25:43 --> Input Class Initialized
INFO - 2016-02-15 17:25:43 --> Language Class Initialized
INFO - 2016-02-15 17:25:43 --> Loader Class Initialized
INFO - 2016-02-15 17:25:43 --> Helper loaded: url_helper
INFO - 2016-02-15 17:25:43 --> Helper loaded: file_helper
INFO - 2016-02-15 17:25:43 --> Helper loaded: date_helper
INFO - 2016-02-15 17:25:43 --> Helper loaded: form_helper
INFO - 2016-02-15 17:25:43 --> Database Driver Class Initialized
INFO - 2016-02-15 17:25:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:25:44 --> Controller Class Initialized
INFO - 2016-02-15 17:25:44 --> Model Class Initialized
INFO - 2016-02-15 17:25:44 --> Model Class Initialized
INFO - 2016-02-15 17:25:44 --> Form Validation Class Initialized
INFO - 2016-02-15 17:25:44 --> Helper loaded: text_helper
INFO - 2016-02-15 17:25:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-15 17:25:44 --> Final output sent to browser
DEBUG - 2016-02-15 17:25:44 --> Total execution time: 1.2412
INFO - 2016-02-15 17:27:35 --> Config Class Initialized
INFO - 2016-02-15 17:27:35 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:27:35 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:27:35 --> Utf8 Class Initialized
INFO - 2016-02-15 17:27:35 --> URI Class Initialized
INFO - 2016-02-15 17:27:35 --> Router Class Initialized
INFO - 2016-02-15 17:27:35 --> Output Class Initialized
INFO - 2016-02-15 17:27:35 --> Security Class Initialized
DEBUG - 2016-02-15 17:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:27:35 --> Input Class Initialized
INFO - 2016-02-15 17:27:35 --> Language Class Initialized
INFO - 2016-02-15 17:27:35 --> Loader Class Initialized
INFO - 2016-02-15 17:27:35 --> Helper loaded: url_helper
INFO - 2016-02-15 17:27:35 --> Helper loaded: file_helper
INFO - 2016-02-15 17:27:35 --> Helper loaded: date_helper
INFO - 2016-02-15 17:27:35 --> Helper loaded: form_helper
INFO - 2016-02-15 17:27:35 --> Database Driver Class Initialized
INFO - 2016-02-15 17:27:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:27:36 --> Controller Class Initialized
INFO - 2016-02-15 17:27:36 --> Model Class Initialized
INFO - 2016-02-15 17:27:36 --> Model Class Initialized
INFO - 2016-02-15 17:27:36 --> Form Validation Class Initialized
INFO - 2016-02-15 17:27:36 --> Helper loaded: text_helper
INFO - 2016-02-15 17:27:36 --> Final output sent to browser
DEBUG - 2016-02-15 17:27:36 --> Total execution time: 1.0903
INFO - 2016-02-15 17:27:38 --> Config Class Initialized
INFO - 2016-02-15 17:27:38 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:27:38 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:27:38 --> Utf8 Class Initialized
INFO - 2016-02-15 17:27:38 --> URI Class Initialized
INFO - 2016-02-15 17:27:38 --> Router Class Initialized
INFO - 2016-02-15 17:27:38 --> Output Class Initialized
INFO - 2016-02-15 17:27:38 --> Security Class Initialized
DEBUG - 2016-02-15 17:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:27:38 --> Input Class Initialized
INFO - 2016-02-15 17:27:38 --> Language Class Initialized
INFO - 2016-02-15 17:27:38 --> Loader Class Initialized
INFO - 2016-02-15 17:27:38 --> Helper loaded: url_helper
INFO - 2016-02-15 17:27:38 --> Helper loaded: file_helper
INFO - 2016-02-15 17:27:38 --> Helper loaded: date_helper
INFO - 2016-02-15 17:27:38 --> Helper loaded: form_helper
INFO - 2016-02-15 17:27:38 --> Database Driver Class Initialized
INFO - 2016-02-15 17:27:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:27:39 --> Controller Class Initialized
INFO - 2016-02-15 17:27:39 --> Model Class Initialized
INFO - 2016-02-15 17:27:39 --> Model Class Initialized
INFO - 2016-02-15 17:27:39 --> Form Validation Class Initialized
INFO - 2016-02-15 17:27:39 --> Helper loaded: text_helper
INFO - 2016-02-15 17:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 17:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 17:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-15 17:27:39 --> Model Class Initialized
INFO - 2016-02-15 17:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 17:27:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 17:27:39 --> Final output sent to browser
DEBUG - 2016-02-15 17:27:39 --> Total execution time: 1.1036
INFO - 2016-02-15 17:28:04 --> Config Class Initialized
INFO - 2016-02-15 17:28:04 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:28:04 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:28:04 --> Utf8 Class Initialized
INFO - 2016-02-15 17:28:04 --> URI Class Initialized
INFO - 2016-02-15 17:28:04 --> Router Class Initialized
INFO - 2016-02-15 17:28:04 --> Output Class Initialized
INFO - 2016-02-15 17:28:04 --> Security Class Initialized
DEBUG - 2016-02-15 17:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:28:04 --> Input Class Initialized
INFO - 2016-02-15 17:28:04 --> Language Class Initialized
INFO - 2016-02-15 17:28:04 --> Loader Class Initialized
INFO - 2016-02-15 17:28:04 --> Helper loaded: url_helper
INFO - 2016-02-15 17:28:04 --> Helper loaded: file_helper
INFO - 2016-02-15 17:28:04 --> Helper loaded: date_helper
INFO - 2016-02-15 17:28:04 --> Helper loaded: form_helper
INFO - 2016-02-15 17:28:04 --> Database Driver Class Initialized
INFO - 2016-02-15 17:28:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:28:05 --> Controller Class Initialized
INFO - 2016-02-15 17:28:05 --> Model Class Initialized
INFO - 2016-02-15 17:28:05 --> Model Class Initialized
INFO - 2016-02-15 17:28:05 --> Form Validation Class Initialized
INFO - 2016-02-15 17:28:05 --> Helper loaded: text_helper
INFO - 2016-02-15 17:28:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-15 17:28:05 --> Final output sent to browser
DEBUG - 2016-02-15 17:28:05 --> Total execution time: 1.2952
INFO - 2016-02-15 17:28:15 --> Config Class Initialized
INFO - 2016-02-15 17:28:15 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:28:15 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:28:15 --> Utf8 Class Initialized
INFO - 2016-02-15 17:28:15 --> URI Class Initialized
DEBUG - 2016-02-15 17:28:15 --> No URI present. Default controller set.
INFO - 2016-02-15 17:28:15 --> Router Class Initialized
INFO - 2016-02-15 17:28:15 --> Output Class Initialized
INFO - 2016-02-15 17:28:15 --> Security Class Initialized
DEBUG - 2016-02-15 17:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:28:15 --> Input Class Initialized
INFO - 2016-02-15 17:28:15 --> Language Class Initialized
INFO - 2016-02-15 17:28:15 --> Loader Class Initialized
INFO - 2016-02-15 17:28:15 --> Helper loaded: url_helper
INFO - 2016-02-15 17:28:15 --> Helper loaded: file_helper
INFO - 2016-02-15 17:28:15 --> Helper loaded: date_helper
INFO - 2016-02-15 17:28:15 --> Helper loaded: form_helper
INFO - 2016-02-15 17:28:15 --> Database Driver Class Initialized
INFO - 2016-02-15 17:28:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:28:16 --> Controller Class Initialized
INFO - 2016-02-15 17:28:16 --> Model Class Initialized
INFO - 2016-02-15 17:28:16 --> Model Class Initialized
INFO - 2016-02-15 17:28:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:28:16 --> Pagination Class Initialized
INFO - 2016-02-15 17:28:16 --> Helper loaded: text_helper
INFO - 2016-02-15 20:28:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:28:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:28:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 20:28:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:28:16 --> Final output sent to browser
DEBUG - 2016-02-15 20:28:16 --> Total execution time: 1.2223
INFO - 2016-02-15 17:28:33 --> Config Class Initialized
INFO - 2016-02-15 17:28:33 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:28:33 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:28:33 --> Utf8 Class Initialized
INFO - 2016-02-15 17:28:33 --> URI Class Initialized
INFO - 2016-02-15 17:28:33 --> Router Class Initialized
INFO - 2016-02-15 17:28:33 --> Output Class Initialized
INFO - 2016-02-15 17:28:33 --> Security Class Initialized
DEBUG - 2016-02-15 17:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:28:33 --> Input Class Initialized
INFO - 2016-02-15 17:28:33 --> Language Class Initialized
INFO - 2016-02-15 17:28:33 --> Loader Class Initialized
INFO - 2016-02-15 17:28:33 --> Helper loaded: url_helper
INFO - 2016-02-15 17:28:33 --> Helper loaded: file_helper
INFO - 2016-02-15 17:28:33 --> Helper loaded: date_helper
INFO - 2016-02-15 17:28:33 --> Helper loaded: form_helper
INFO - 2016-02-15 17:28:33 --> Database Driver Class Initialized
INFO - 2016-02-15 17:28:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:28:34 --> Controller Class Initialized
INFO - 2016-02-15 17:28:34 --> Model Class Initialized
INFO - 2016-02-15 17:28:34 --> Model Class Initialized
INFO - 2016-02-15 17:28:34 --> Form Validation Class Initialized
INFO - 2016-02-15 17:28:34 --> Helper loaded: text_helper
INFO - 2016-02-15 17:28:34 --> Config Class Initialized
INFO - 2016-02-15 17:28:34 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:28:34 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:28:34 --> Utf8 Class Initialized
INFO - 2016-02-15 17:28:34 --> URI Class Initialized
DEBUG - 2016-02-15 17:28:34 --> No URI present. Default controller set.
INFO - 2016-02-15 17:28:34 --> Router Class Initialized
INFO - 2016-02-15 17:28:34 --> Output Class Initialized
INFO - 2016-02-15 17:28:34 --> Security Class Initialized
DEBUG - 2016-02-15 17:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:28:34 --> Input Class Initialized
INFO - 2016-02-15 17:28:34 --> Language Class Initialized
INFO - 2016-02-15 17:28:34 --> Loader Class Initialized
INFO - 2016-02-15 17:28:34 --> Helper loaded: url_helper
INFO - 2016-02-15 17:28:34 --> Helper loaded: file_helper
INFO - 2016-02-15 17:28:34 --> Helper loaded: date_helper
INFO - 2016-02-15 17:28:34 --> Helper loaded: form_helper
INFO - 2016-02-15 17:28:34 --> Database Driver Class Initialized
INFO - 2016-02-15 17:28:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:28:35 --> Controller Class Initialized
INFO - 2016-02-15 17:28:35 --> Model Class Initialized
INFO - 2016-02-15 17:28:35 --> Model Class Initialized
INFO - 2016-02-15 17:28:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:28:35 --> Pagination Class Initialized
INFO - 2016-02-15 17:28:35 --> Helper loaded: text_helper
INFO - 2016-02-15 20:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 20:28:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:28:35 --> Final output sent to browser
DEBUG - 2016-02-15 20:28:35 --> Total execution time: 1.1242
INFO - 2016-02-15 17:28:39 --> Config Class Initialized
INFO - 2016-02-15 17:28:39 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:28:39 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:28:39 --> Utf8 Class Initialized
INFO - 2016-02-15 17:28:39 --> URI Class Initialized
INFO - 2016-02-15 17:28:39 --> Router Class Initialized
INFO - 2016-02-15 17:28:39 --> Output Class Initialized
INFO - 2016-02-15 17:28:39 --> Security Class Initialized
DEBUG - 2016-02-15 17:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:28:39 --> Input Class Initialized
INFO - 2016-02-15 17:28:39 --> Language Class Initialized
INFO - 2016-02-15 17:28:39 --> Loader Class Initialized
INFO - 2016-02-15 17:28:39 --> Helper loaded: url_helper
INFO - 2016-02-15 17:28:39 --> Helper loaded: file_helper
INFO - 2016-02-15 17:28:39 --> Helper loaded: date_helper
INFO - 2016-02-15 17:28:39 --> Helper loaded: form_helper
INFO - 2016-02-15 17:28:39 --> Database Driver Class Initialized
INFO - 2016-02-15 17:28:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:28:40 --> Controller Class Initialized
INFO - 2016-02-15 17:28:40 --> Model Class Initialized
INFO - 2016-02-15 17:28:40 --> Model Class Initialized
INFO - 2016-02-15 17:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:28:40 --> Pagination Class Initialized
INFO - 2016-02-15 17:28:40 --> Helper loaded: text_helper
INFO - 2016-02-15 20:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:28:40 --> Final output sent to browser
DEBUG - 2016-02-15 20:28:40 --> Total execution time: 1.1968
INFO - 2016-02-15 17:33:34 --> Config Class Initialized
INFO - 2016-02-15 17:33:34 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:33:34 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:33:34 --> Utf8 Class Initialized
INFO - 2016-02-15 17:33:34 --> URI Class Initialized
INFO - 2016-02-15 17:33:34 --> Router Class Initialized
INFO - 2016-02-15 17:33:34 --> Output Class Initialized
INFO - 2016-02-15 17:33:34 --> Security Class Initialized
DEBUG - 2016-02-15 17:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:33:34 --> Input Class Initialized
INFO - 2016-02-15 17:33:34 --> Language Class Initialized
INFO - 2016-02-15 17:33:34 --> Loader Class Initialized
INFO - 2016-02-15 17:33:34 --> Helper loaded: url_helper
INFO - 2016-02-15 17:33:34 --> Helper loaded: file_helper
INFO - 2016-02-15 17:33:34 --> Helper loaded: date_helper
INFO - 2016-02-15 17:33:34 --> Helper loaded: form_helper
INFO - 2016-02-15 17:33:34 --> Database Driver Class Initialized
INFO - 2016-02-15 17:33:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:33:35 --> Controller Class Initialized
INFO - 2016-02-15 17:33:35 --> Model Class Initialized
INFO - 2016-02-15 17:33:35 --> Model Class Initialized
INFO - 2016-02-15 17:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:33:35 --> Pagination Class Initialized
INFO - 2016-02-15 17:33:35 --> Helper loaded: text_helper
INFO - 2016-02-15 17:35:52 --> Config Class Initialized
INFO - 2016-02-15 17:35:52 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:35:52 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:35:52 --> Utf8 Class Initialized
INFO - 2016-02-15 17:35:52 --> URI Class Initialized
DEBUG - 2016-02-15 17:35:52 --> No URI present. Default controller set.
INFO - 2016-02-15 17:35:52 --> Router Class Initialized
INFO - 2016-02-15 17:35:52 --> Output Class Initialized
INFO - 2016-02-15 17:35:52 --> Security Class Initialized
DEBUG - 2016-02-15 17:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:35:52 --> Input Class Initialized
INFO - 2016-02-15 17:35:52 --> Language Class Initialized
INFO - 2016-02-15 17:35:52 --> Loader Class Initialized
INFO - 2016-02-15 17:35:52 --> Helper loaded: url_helper
INFO - 2016-02-15 17:35:52 --> Helper loaded: file_helper
INFO - 2016-02-15 17:35:52 --> Helper loaded: date_helper
INFO - 2016-02-15 17:35:52 --> Helper loaded: form_helper
INFO - 2016-02-15 17:35:52 --> Database Driver Class Initialized
INFO - 2016-02-15 17:35:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:35:53 --> Controller Class Initialized
INFO - 2016-02-15 17:35:53 --> Model Class Initialized
INFO - 2016-02-15 17:35:53 --> Model Class Initialized
INFO - 2016-02-15 17:35:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:35:53 --> Pagination Class Initialized
INFO - 2016-02-15 17:35:53 --> Helper loaded: text_helper
INFO - 2016-02-15 20:35:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:35:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:35:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 20:35:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:35:53 --> Final output sent to browser
DEBUG - 2016-02-15 20:35:53 --> Total execution time: 1.1924
INFO - 2016-02-15 17:35:55 --> Config Class Initialized
INFO - 2016-02-15 17:35:55 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:35:55 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:35:55 --> Utf8 Class Initialized
INFO - 2016-02-15 17:35:55 --> URI Class Initialized
INFO - 2016-02-15 17:35:55 --> Router Class Initialized
INFO - 2016-02-15 17:35:55 --> Output Class Initialized
INFO - 2016-02-15 17:35:55 --> Security Class Initialized
DEBUG - 2016-02-15 17:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:35:55 --> Input Class Initialized
INFO - 2016-02-15 17:35:55 --> Language Class Initialized
INFO - 2016-02-15 17:35:55 --> Loader Class Initialized
INFO - 2016-02-15 17:35:55 --> Helper loaded: url_helper
INFO - 2016-02-15 17:35:55 --> Helper loaded: file_helper
INFO - 2016-02-15 17:35:55 --> Helper loaded: date_helper
INFO - 2016-02-15 17:35:55 --> Helper loaded: form_helper
INFO - 2016-02-15 17:35:55 --> Database Driver Class Initialized
INFO - 2016-02-15 17:35:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:35:56 --> Controller Class Initialized
INFO - 2016-02-15 17:35:56 --> Model Class Initialized
INFO - 2016-02-15 17:35:56 --> Model Class Initialized
INFO - 2016-02-15 17:35:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:35:56 --> Pagination Class Initialized
INFO - 2016-02-15 17:35:56 --> Helper loaded: text_helper
INFO - 2016-02-15 20:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:35:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:35:56 --> Final output sent to browser
DEBUG - 2016-02-15 20:35:56 --> Total execution time: 1.2244
INFO - 2016-02-15 17:36:01 --> Config Class Initialized
INFO - 2016-02-15 17:36:01 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:36:01 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:36:01 --> Utf8 Class Initialized
INFO - 2016-02-15 17:36:01 --> URI Class Initialized
INFO - 2016-02-15 17:36:01 --> Router Class Initialized
INFO - 2016-02-15 17:36:01 --> Output Class Initialized
INFO - 2016-02-15 17:36:01 --> Security Class Initialized
DEBUG - 2016-02-15 17:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:36:01 --> Input Class Initialized
INFO - 2016-02-15 17:36:01 --> Language Class Initialized
INFO - 2016-02-15 17:36:01 --> Loader Class Initialized
INFO - 2016-02-15 17:36:01 --> Helper loaded: url_helper
INFO - 2016-02-15 17:36:01 --> Helper loaded: file_helper
INFO - 2016-02-15 17:36:01 --> Helper loaded: date_helper
INFO - 2016-02-15 17:36:01 --> Helper loaded: form_helper
INFO - 2016-02-15 17:36:01 --> Database Driver Class Initialized
INFO - 2016-02-15 17:36:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:36:02 --> Controller Class Initialized
INFO - 2016-02-15 17:36:02 --> Model Class Initialized
INFO - 2016-02-15 17:36:02 --> Model Class Initialized
INFO - 2016-02-15 17:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:36:02 --> Pagination Class Initialized
INFO - 2016-02-15 17:36:02 --> Helper loaded: text_helper
INFO - 2016-02-15 17:37:04 --> Config Class Initialized
INFO - 2016-02-15 17:37:04 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:37:04 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:37:04 --> Utf8 Class Initialized
INFO - 2016-02-15 17:37:04 --> URI Class Initialized
INFO - 2016-02-15 17:37:04 --> Router Class Initialized
INFO - 2016-02-15 17:37:04 --> Output Class Initialized
INFO - 2016-02-15 17:37:04 --> Security Class Initialized
DEBUG - 2016-02-15 17:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:37:04 --> Input Class Initialized
INFO - 2016-02-15 17:37:04 --> Language Class Initialized
ERROR - 2016-02-15 17:37:05 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 468
INFO - 2016-02-15 17:37:20 --> Config Class Initialized
INFO - 2016-02-15 17:37:20 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:37:20 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:37:20 --> Utf8 Class Initialized
INFO - 2016-02-15 17:37:20 --> URI Class Initialized
INFO - 2016-02-15 17:37:20 --> Router Class Initialized
INFO - 2016-02-15 17:37:20 --> Output Class Initialized
INFO - 2016-02-15 17:37:20 --> Security Class Initialized
DEBUG - 2016-02-15 17:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:37:20 --> Input Class Initialized
INFO - 2016-02-15 17:37:20 --> Language Class Initialized
INFO - 2016-02-15 17:37:20 --> Loader Class Initialized
INFO - 2016-02-15 17:37:20 --> Helper loaded: url_helper
INFO - 2016-02-15 17:37:20 --> Helper loaded: file_helper
INFO - 2016-02-15 17:37:20 --> Helper loaded: date_helper
INFO - 2016-02-15 17:37:20 --> Helper loaded: form_helper
INFO - 2016-02-15 17:37:20 --> Database Driver Class Initialized
INFO - 2016-02-15 17:37:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:37:21 --> Controller Class Initialized
INFO - 2016-02-15 17:37:21 --> Model Class Initialized
INFO - 2016-02-15 17:37:21 --> Model Class Initialized
INFO - 2016-02-15 17:37:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:37:21 --> Pagination Class Initialized
INFO - 2016-02-15 17:37:21 --> Helper loaded: text_helper
INFO - 2016-02-15 20:37:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:37:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:37:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:37:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:37:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:37:21 --> Final output sent to browser
DEBUG - 2016-02-15 20:37:21 --> Total execution time: 1.2159
INFO - 2016-02-15 17:37:25 --> Config Class Initialized
INFO - 2016-02-15 17:37:25 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:37:25 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:37:25 --> Utf8 Class Initialized
INFO - 2016-02-15 17:37:25 --> URI Class Initialized
INFO - 2016-02-15 17:37:25 --> Router Class Initialized
INFO - 2016-02-15 17:37:25 --> Output Class Initialized
INFO - 2016-02-15 17:37:25 --> Security Class Initialized
DEBUG - 2016-02-15 17:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:37:25 --> Input Class Initialized
INFO - 2016-02-15 17:37:25 --> Language Class Initialized
INFO - 2016-02-15 17:37:25 --> Loader Class Initialized
INFO - 2016-02-15 17:37:25 --> Helper loaded: url_helper
INFO - 2016-02-15 17:37:25 --> Helper loaded: file_helper
INFO - 2016-02-15 17:37:25 --> Helper loaded: date_helper
INFO - 2016-02-15 17:37:25 --> Helper loaded: form_helper
INFO - 2016-02-15 17:37:25 --> Database Driver Class Initialized
INFO - 2016-02-15 17:37:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:37:26 --> Controller Class Initialized
INFO - 2016-02-15 17:37:26 --> Model Class Initialized
INFO - 2016-02-15 17:37:26 --> Model Class Initialized
INFO - 2016-02-15 17:37:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:37:26 --> Pagination Class Initialized
INFO - 2016-02-15 17:37:26 --> Helper loaded: text_helper
INFO - 2016-02-15 17:38:42 --> Config Class Initialized
INFO - 2016-02-15 17:38:42 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:38:42 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:38:42 --> Utf8 Class Initialized
INFO - 2016-02-15 17:38:42 --> URI Class Initialized
DEBUG - 2016-02-15 17:38:42 --> No URI present. Default controller set.
INFO - 2016-02-15 17:38:42 --> Router Class Initialized
INFO - 2016-02-15 17:38:42 --> Output Class Initialized
INFO - 2016-02-15 17:38:42 --> Security Class Initialized
DEBUG - 2016-02-15 17:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:38:42 --> Input Class Initialized
INFO - 2016-02-15 17:38:42 --> Language Class Initialized
INFO - 2016-02-15 17:38:42 --> Loader Class Initialized
INFO - 2016-02-15 17:38:42 --> Helper loaded: url_helper
INFO - 2016-02-15 17:38:42 --> Helper loaded: file_helper
INFO - 2016-02-15 17:38:42 --> Helper loaded: date_helper
INFO - 2016-02-15 17:38:42 --> Helper loaded: form_helper
INFO - 2016-02-15 17:38:42 --> Database Driver Class Initialized
INFO - 2016-02-15 17:38:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:38:43 --> Controller Class Initialized
INFO - 2016-02-15 17:38:43 --> Model Class Initialized
INFO - 2016-02-15 17:38:43 --> Model Class Initialized
INFO - 2016-02-15 17:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:38:43 --> Pagination Class Initialized
INFO - 2016-02-15 17:38:43 --> Helper loaded: text_helper
INFO - 2016-02-15 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:38:43 --> Final output sent to browser
DEBUG - 2016-02-15 20:38:43 --> Total execution time: 1.1109
INFO - 2016-02-15 17:38:47 --> Config Class Initialized
INFO - 2016-02-15 17:38:47 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:38:47 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:38:47 --> Utf8 Class Initialized
INFO - 2016-02-15 17:38:47 --> URI Class Initialized
INFO - 2016-02-15 17:38:47 --> Router Class Initialized
INFO - 2016-02-15 17:38:47 --> Output Class Initialized
INFO - 2016-02-15 17:38:47 --> Security Class Initialized
DEBUG - 2016-02-15 17:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:38:47 --> Input Class Initialized
INFO - 2016-02-15 17:38:47 --> Language Class Initialized
INFO - 2016-02-15 17:38:47 --> Loader Class Initialized
INFO - 2016-02-15 17:38:47 --> Helper loaded: url_helper
INFO - 2016-02-15 17:38:47 --> Helper loaded: file_helper
INFO - 2016-02-15 17:38:47 --> Helper loaded: date_helper
INFO - 2016-02-15 17:38:47 --> Helper loaded: form_helper
INFO - 2016-02-15 17:38:47 --> Database Driver Class Initialized
INFO - 2016-02-15 17:38:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:38:48 --> Controller Class Initialized
INFO - 2016-02-15 17:38:48 --> Model Class Initialized
INFO - 2016-02-15 17:38:48 --> Model Class Initialized
INFO - 2016-02-15 17:38:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:38:48 --> Pagination Class Initialized
INFO - 2016-02-15 17:38:48 --> Helper loaded: text_helper
INFO - 2016-02-15 20:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:38:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:38:48 --> Final output sent to browser
DEBUG - 2016-02-15 20:38:48 --> Total execution time: 1.1448
INFO - 2016-02-15 17:38:51 --> Config Class Initialized
INFO - 2016-02-15 17:38:51 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:38:51 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:38:51 --> Utf8 Class Initialized
INFO - 2016-02-15 17:38:51 --> URI Class Initialized
INFO - 2016-02-15 17:38:51 --> Router Class Initialized
INFO - 2016-02-15 17:38:51 --> Output Class Initialized
INFO - 2016-02-15 17:38:51 --> Security Class Initialized
DEBUG - 2016-02-15 17:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:38:51 --> Input Class Initialized
INFO - 2016-02-15 17:38:51 --> Language Class Initialized
INFO - 2016-02-15 17:38:51 --> Loader Class Initialized
INFO - 2016-02-15 17:38:51 --> Helper loaded: url_helper
INFO - 2016-02-15 17:38:51 --> Helper loaded: file_helper
INFO - 2016-02-15 17:38:51 --> Helper loaded: date_helper
INFO - 2016-02-15 17:38:51 --> Helper loaded: form_helper
INFO - 2016-02-15 17:38:51 --> Database Driver Class Initialized
INFO - 2016-02-15 17:38:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:38:52 --> Controller Class Initialized
INFO - 2016-02-15 17:38:52 --> Model Class Initialized
INFO - 2016-02-15 17:38:52 --> Model Class Initialized
INFO - 2016-02-15 17:38:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:38:52 --> Pagination Class Initialized
INFO - 2016-02-15 17:38:52 --> Helper loaded: text_helper
INFO - 2016-02-15 17:47:14 --> Config Class Initialized
INFO - 2016-02-15 17:47:14 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:47:14 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:47:14 --> Utf8 Class Initialized
INFO - 2016-02-15 17:47:14 --> URI Class Initialized
INFO - 2016-02-15 17:47:14 --> Router Class Initialized
INFO - 2016-02-15 17:47:14 --> Output Class Initialized
INFO - 2016-02-15 17:47:14 --> Security Class Initialized
DEBUG - 2016-02-15 17:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:47:14 --> Input Class Initialized
INFO - 2016-02-15 17:47:14 --> Language Class Initialized
INFO - 2016-02-15 17:47:14 --> Loader Class Initialized
INFO - 2016-02-15 17:47:14 --> Helper loaded: url_helper
INFO - 2016-02-15 17:47:14 --> Helper loaded: file_helper
INFO - 2016-02-15 17:47:14 --> Helper loaded: date_helper
INFO - 2016-02-15 17:47:14 --> Helper loaded: form_helper
INFO - 2016-02-15 17:47:14 --> Database Driver Class Initialized
INFO - 2016-02-15 17:47:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:47:16 --> Controller Class Initialized
INFO - 2016-02-15 17:47:16 --> Model Class Initialized
INFO - 2016-02-15 17:47:16 --> Model Class Initialized
INFO - 2016-02-15 17:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:47:16 --> Pagination Class Initialized
INFO - 2016-02-15 17:47:16 --> Helper loaded: text_helper
INFO - 2016-02-15 20:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:47:16 --> Final output sent to browser
DEBUG - 2016-02-15 20:47:16 --> Total execution time: 1.1704
INFO - 2016-02-15 17:47:19 --> Config Class Initialized
INFO - 2016-02-15 17:47:19 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:47:19 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:47:19 --> Utf8 Class Initialized
INFO - 2016-02-15 17:47:19 --> URI Class Initialized
INFO - 2016-02-15 17:47:19 --> Router Class Initialized
INFO - 2016-02-15 17:47:19 --> Output Class Initialized
INFO - 2016-02-15 17:47:19 --> Security Class Initialized
DEBUG - 2016-02-15 17:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:47:19 --> Input Class Initialized
INFO - 2016-02-15 17:47:19 --> Language Class Initialized
INFO - 2016-02-15 17:47:19 --> Loader Class Initialized
INFO - 2016-02-15 17:47:19 --> Helper loaded: url_helper
INFO - 2016-02-15 17:47:19 --> Helper loaded: file_helper
INFO - 2016-02-15 17:47:19 --> Helper loaded: date_helper
INFO - 2016-02-15 17:47:19 --> Helper loaded: form_helper
INFO - 2016-02-15 17:47:19 --> Database Driver Class Initialized
INFO - 2016-02-15 17:47:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:47:20 --> Controller Class Initialized
INFO - 2016-02-15 17:47:20 --> Model Class Initialized
INFO - 2016-02-15 17:47:20 --> Model Class Initialized
INFO - 2016-02-15 17:47:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:47:20 --> Pagination Class Initialized
INFO - 2016-02-15 17:47:20 --> Helper loaded: text_helper
INFO - 2016-02-15 17:47:45 --> Config Class Initialized
INFO - 2016-02-15 17:47:45 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:47:45 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:47:45 --> Utf8 Class Initialized
INFO - 2016-02-15 17:47:45 --> URI Class Initialized
INFO - 2016-02-15 17:47:45 --> Router Class Initialized
INFO - 2016-02-15 17:47:45 --> Output Class Initialized
INFO - 2016-02-15 17:47:45 --> Security Class Initialized
DEBUG - 2016-02-15 17:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:47:45 --> Input Class Initialized
INFO - 2016-02-15 17:47:45 --> Language Class Initialized
INFO - 2016-02-15 17:47:45 --> Loader Class Initialized
INFO - 2016-02-15 17:47:45 --> Helper loaded: url_helper
INFO - 2016-02-15 17:47:45 --> Helper loaded: file_helper
INFO - 2016-02-15 17:47:45 --> Helper loaded: date_helper
INFO - 2016-02-15 17:47:45 --> Helper loaded: form_helper
INFO - 2016-02-15 17:47:45 --> Database Driver Class Initialized
INFO - 2016-02-15 17:47:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:47:46 --> Controller Class Initialized
INFO - 2016-02-15 17:47:46 --> Model Class Initialized
INFO - 2016-02-15 17:47:46 --> Model Class Initialized
INFO - 2016-02-15 17:47:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:47:46 --> Pagination Class Initialized
INFO - 2016-02-15 17:47:46 --> Helper loaded: text_helper
INFO - 2016-02-15 20:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 20:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 20:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 20:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 20:47:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 20:47:46 --> Final output sent to browser
DEBUG - 2016-02-15 20:47:46 --> Total execution time: 1.2031
INFO - 2016-02-15 17:47:47 --> Config Class Initialized
INFO - 2016-02-15 17:47:47 --> Hooks Class Initialized
DEBUG - 2016-02-15 17:47:47 --> UTF-8 Support Enabled
INFO - 2016-02-15 17:47:47 --> Utf8 Class Initialized
INFO - 2016-02-15 17:47:47 --> URI Class Initialized
INFO - 2016-02-15 17:47:47 --> Router Class Initialized
INFO - 2016-02-15 17:47:47 --> Output Class Initialized
INFO - 2016-02-15 17:47:47 --> Security Class Initialized
DEBUG - 2016-02-15 17:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 17:47:47 --> Input Class Initialized
INFO - 2016-02-15 17:47:47 --> Language Class Initialized
INFO - 2016-02-15 17:47:47 --> Loader Class Initialized
INFO - 2016-02-15 17:47:47 --> Helper loaded: url_helper
INFO - 2016-02-15 17:47:47 --> Helper loaded: file_helper
INFO - 2016-02-15 17:47:47 --> Helper loaded: date_helper
INFO - 2016-02-15 17:47:47 --> Helper loaded: form_helper
INFO - 2016-02-15 17:47:47 --> Database Driver Class Initialized
INFO - 2016-02-15 17:47:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 17:47:48 --> Controller Class Initialized
INFO - 2016-02-15 17:47:48 --> Model Class Initialized
INFO - 2016-02-15 17:47:48 --> Model Class Initialized
INFO - 2016-02-15 17:47:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 17:47:48 --> Pagination Class Initialized
INFO - 2016-02-15 17:47:48 --> Helper loaded: text_helper
INFO - 2016-02-15 19:02:37 --> Config Class Initialized
INFO - 2016-02-15 19:02:37 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:02:37 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:02:37 --> Utf8 Class Initialized
INFO - 2016-02-15 19:02:37 --> URI Class Initialized
DEBUG - 2016-02-15 19:02:37 --> No URI present. Default controller set.
INFO - 2016-02-15 19:02:37 --> Router Class Initialized
INFO - 2016-02-15 19:02:37 --> Output Class Initialized
INFO - 2016-02-15 19:02:37 --> Security Class Initialized
DEBUG - 2016-02-15 19:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:02:37 --> Input Class Initialized
INFO - 2016-02-15 19:02:37 --> Language Class Initialized
INFO - 2016-02-15 19:02:37 --> Loader Class Initialized
INFO - 2016-02-15 19:02:37 --> Helper loaded: url_helper
INFO - 2016-02-15 19:02:37 --> Helper loaded: file_helper
INFO - 2016-02-15 19:02:37 --> Helper loaded: date_helper
INFO - 2016-02-15 19:02:37 --> Helper loaded: form_helper
INFO - 2016-02-15 19:02:37 --> Database Driver Class Initialized
INFO - 2016-02-15 19:02:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:02:39 --> Controller Class Initialized
INFO - 2016-02-15 19:02:39 --> Model Class Initialized
INFO - 2016-02-15 19:02:39 --> Model Class Initialized
INFO - 2016-02-15 19:02:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:02:39 --> Pagination Class Initialized
INFO - 2016-02-15 19:02:39 --> Helper loaded: text_helper
INFO - 2016-02-15 22:02:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:02:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:02:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:02:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:02:39 --> Final output sent to browser
DEBUG - 2016-02-15 22:02:39 --> Total execution time: 1.2229
INFO - 2016-02-15 19:02:46 --> Config Class Initialized
INFO - 2016-02-15 19:02:46 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:02:46 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:02:46 --> Utf8 Class Initialized
INFO - 2016-02-15 19:02:46 --> URI Class Initialized
INFO - 2016-02-15 19:02:46 --> Router Class Initialized
INFO - 2016-02-15 19:02:46 --> Output Class Initialized
INFO - 2016-02-15 19:02:46 --> Security Class Initialized
DEBUG - 2016-02-15 19:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:02:46 --> Input Class Initialized
INFO - 2016-02-15 19:02:46 --> Language Class Initialized
INFO - 2016-02-15 19:02:46 --> Loader Class Initialized
INFO - 2016-02-15 19:02:46 --> Helper loaded: url_helper
INFO - 2016-02-15 19:02:46 --> Helper loaded: file_helper
INFO - 2016-02-15 19:02:46 --> Helper loaded: date_helper
INFO - 2016-02-15 19:02:46 --> Helper loaded: form_helper
INFO - 2016-02-15 19:02:46 --> Database Driver Class Initialized
INFO - 2016-02-15 19:02:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:02:47 --> Controller Class Initialized
INFO - 2016-02-15 19:02:47 --> Model Class Initialized
INFO - 2016-02-15 19:02:47 --> Model Class Initialized
INFO - 2016-02-15 19:02:47 --> Form Validation Class Initialized
INFO - 2016-02-15 19:02:47 --> Helper loaded: text_helper
INFO - 2016-02-15 19:02:47 --> Config Class Initialized
INFO - 2016-02-15 19:02:47 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:02:47 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:02:47 --> Utf8 Class Initialized
INFO - 2016-02-15 19:02:47 --> URI Class Initialized
INFO - 2016-02-15 19:02:47 --> Router Class Initialized
INFO - 2016-02-15 19:02:47 --> Output Class Initialized
INFO - 2016-02-15 19:02:47 --> Security Class Initialized
DEBUG - 2016-02-15 19:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:02:47 --> Input Class Initialized
INFO - 2016-02-15 19:02:47 --> Language Class Initialized
INFO - 2016-02-15 19:02:47 --> Loader Class Initialized
INFO - 2016-02-15 19:02:47 --> Helper loaded: url_helper
INFO - 2016-02-15 19:02:47 --> Helper loaded: file_helper
INFO - 2016-02-15 19:02:47 --> Helper loaded: date_helper
INFO - 2016-02-15 19:02:47 --> Helper loaded: form_helper
INFO - 2016-02-15 19:02:47 --> Database Driver Class Initialized
INFO - 2016-02-15 19:02:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:02:48 --> Controller Class Initialized
INFO - 2016-02-15 19:02:48 --> Model Class Initialized
INFO - 2016-02-15 19:02:48 --> Model Class Initialized
INFO - 2016-02-15 19:02:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:02:48 --> Pagination Class Initialized
INFO - 2016-02-15 19:02:48 --> Helper loaded: text_helper
INFO - 2016-02-15 22:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:02:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:02:48 --> Final output sent to browser
DEBUG - 2016-02-15 22:02:48 --> Total execution time: 1.1723
INFO - 2016-02-15 19:02:53 --> Config Class Initialized
INFO - 2016-02-15 19:02:53 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:02:53 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:02:53 --> Utf8 Class Initialized
INFO - 2016-02-15 19:02:53 --> URI Class Initialized
INFO - 2016-02-15 19:02:53 --> Router Class Initialized
INFO - 2016-02-15 19:02:53 --> Output Class Initialized
INFO - 2016-02-15 19:02:53 --> Security Class Initialized
DEBUG - 2016-02-15 19:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:02:53 --> Input Class Initialized
INFO - 2016-02-15 19:02:53 --> Language Class Initialized
INFO - 2016-02-15 19:02:53 --> Loader Class Initialized
INFO - 2016-02-15 19:02:53 --> Helper loaded: url_helper
INFO - 2016-02-15 19:02:53 --> Helper loaded: file_helper
INFO - 2016-02-15 19:02:53 --> Helper loaded: date_helper
INFO - 2016-02-15 19:02:53 --> Helper loaded: form_helper
INFO - 2016-02-15 19:02:53 --> Database Driver Class Initialized
INFO - 2016-02-15 19:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:02:54 --> Controller Class Initialized
INFO - 2016-02-15 19:02:54 --> Model Class Initialized
INFO - 2016-02-15 19:02:54 --> Model Class Initialized
INFO - 2016-02-15 19:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:02:54 --> Pagination Class Initialized
INFO - 2016-02-15 19:02:54 --> Helper loaded: text_helper
INFO - 2016-02-15 22:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:02:54 --> Final output sent to browser
DEBUG - 2016-02-15 22:02:54 --> Total execution time: 1.1862
INFO - 2016-02-15 19:02:56 --> Config Class Initialized
INFO - 2016-02-15 19:02:56 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:02:56 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:02:56 --> Utf8 Class Initialized
INFO - 2016-02-15 19:02:56 --> URI Class Initialized
INFO - 2016-02-15 19:02:56 --> Router Class Initialized
INFO - 2016-02-15 19:02:56 --> Output Class Initialized
INFO - 2016-02-15 19:02:56 --> Security Class Initialized
DEBUG - 2016-02-15 19:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:02:56 --> Input Class Initialized
INFO - 2016-02-15 19:02:56 --> Language Class Initialized
INFO - 2016-02-15 19:02:56 --> Loader Class Initialized
INFO - 2016-02-15 19:02:56 --> Helper loaded: url_helper
INFO - 2016-02-15 19:02:56 --> Helper loaded: file_helper
INFO - 2016-02-15 19:02:56 --> Helper loaded: date_helper
INFO - 2016-02-15 19:02:56 --> Helper loaded: form_helper
INFO - 2016-02-15 19:02:56 --> Database Driver Class Initialized
INFO - 2016-02-15 19:02:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:02:57 --> Controller Class Initialized
INFO - 2016-02-15 19:02:57 --> Model Class Initialized
INFO - 2016-02-15 19:02:57 --> Model Class Initialized
INFO - 2016-02-15 19:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:02:57 --> Pagination Class Initialized
INFO - 2016-02-15 19:02:57 --> Helper loaded: text_helper
INFO - 2016-02-15 22:02:57 --> Final output sent to browser
DEBUG - 2016-02-15 22:02:57 --> Total execution time: 1.2434
INFO - 2016-02-15 19:03:10 --> Config Class Initialized
INFO - 2016-02-15 19:03:10 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:03:10 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:03:10 --> Utf8 Class Initialized
INFO - 2016-02-15 19:03:10 --> URI Class Initialized
INFO - 2016-02-15 19:03:10 --> Router Class Initialized
INFO - 2016-02-15 19:03:10 --> Output Class Initialized
INFO - 2016-02-15 19:03:10 --> Security Class Initialized
DEBUG - 2016-02-15 19:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:03:10 --> Input Class Initialized
INFO - 2016-02-15 19:03:10 --> Language Class Initialized
INFO - 2016-02-15 19:03:10 --> Loader Class Initialized
INFO - 2016-02-15 19:03:10 --> Helper loaded: url_helper
INFO - 2016-02-15 19:03:10 --> Helper loaded: file_helper
INFO - 2016-02-15 19:03:10 --> Helper loaded: date_helper
INFO - 2016-02-15 19:03:10 --> Helper loaded: form_helper
INFO - 2016-02-15 19:03:10 --> Database Driver Class Initialized
INFO - 2016-02-15 19:03:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:03:11 --> Controller Class Initialized
INFO - 2016-02-15 19:03:11 --> Model Class Initialized
INFO - 2016-02-15 19:03:11 --> Model Class Initialized
INFO - 2016-02-15 19:03:11 --> Form Validation Class Initialized
INFO - 2016-02-15 19:03:11 --> Helper loaded: text_helper
INFO - 2016-02-15 19:03:11 --> Config Class Initialized
INFO - 2016-02-15 19:03:11 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:03:11 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:03:11 --> Utf8 Class Initialized
INFO - 2016-02-15 19:03:11 --> URI Class Initialized
INFO - 2016-02-15 19:03:11 --> Router Class Initialized
INFO - 2016-02-15 19:03:11 --> Output Class Initialized
INFO - 2016-02-15 19:03:11 --> Security Class Initialized
DEBUG - 2016-02-15 19:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:03:11 --> Input Class Initialized
INFO - 2016-02-15 19:03:11 --> Language Class Initialized
INFO - 2016-02-15 19:03:11 --> Loader Class Initialized
INFO - 2016-02-15 19:03:11 --> Helper loaded: url_helper
INFO - 2016-02-15 19:03:11 --> Helper loaded: file_helper
INFO - 2016-02-15 19:03:11 --> Helper loaded: date_helper
INFO - 2016-02-15 19:03:11 --> Helper loaded: form_helper
INFO - 2016-02-15 19:03:11 --> Database Driver Class Initialized
INFO - 2016-02-15 19:03:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:03:12 --> Controller Class Initialized
INFO - 2016-02-15 19:03:12 --> Model Class Initialized
INFO - 2016-02-15 19:03:12 --> Model Class Initialized
INFO - 2016-02-15 19:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:03:12 --> Pagination Class Initialized
INFO - 2016-02-15 19:03:12 --> Helper loaded: text_helper
INFO - 2016-02-15 22:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:03:12 --> Final output sent to browser
DEBUG - 2016-02-15 22:03:12 --> Total execution time: 1.1519
INFO - 2016-02-15 19:03:17 --> Config Class Initialized
INFO - 2016-02-15 19:03:17 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:03:17 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:03:17 --> Utf8 Class Initialized
INFO - 2016-02-15 19:03:17 --> URI Class Initialized
INFO - 2016-02-15 19:03:17 --> Router Class Initialized
INFO - 2016-02-15 19:03:17 --> Output Class Initialized
INFO - 2016-02-15 19:03:17 --> Security Class Initialized
DEBUG - 2016-02-15 19:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:03:17 --> Input Class Initialized
INFO - 2016-02-15 19:03:17 --> Language Class Initialized
INFO - 2016-02-15 19:03:17 --> Loader Class Initialized
INFO - 2016-02-15 19:03:17 --> Helper loaded: url_helper
INFO - 2016-02-15 19:03:17 --> Helper loaded: file_helper
INFO - 2016-02-15 19:03:17 --> Helper loaded: date_helper
INFO - 2016-02-15 19:03:17 --> Helper loaded: form_helper
INFO - 2016-02-15 19:03:17 --> Database Driver Class Initialized
INFO - 2016-02-15 19:03:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:03:18 --> Controller Class Initialized
INFO - 2016-02-15 19:03:18 --> Model Class Initialized
INFO - 2016-02-15 19:03:18 --> Model Class Initialized
INFO - 2016-02-15 19:03:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:03:18 --> Pagination Class Initialized
INFO - 2016-02-15 19:03:18 --> Helper loaded: text_helper
INFO - 2016-02-15 19:03:23 --> Config Class Initialized
INFO - 2016-02-15 19:03:23 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:03:23 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:03:23 --> Utf8 Class Initialized
INFO - 2016-02-15 19:03:23 --> URI Class Initialized
INFO - 2016-02-15 19:03:23 --> Router Class Initialized
INFO - 2016-02-15 19:03:23 --> Output Class Initialized
INFO - 2016-02-15 19:03:23 --> Security Class Initialized
DEBUG - 2016-02-15 19:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:03:23 --> Input Class Initialized
INFO - 2016-02-15 19:03:23 --> Language Class Initialized
INFO - 2016-02-15 19:03:23 --> Loader Class Initialized
INFO - 2016-02-15 19:03:23 --> Helper loaded: url_helper
INFO - 2016-02-15 19:03:23 --> Helper loaded: file_helper
INFO - 2016-02-15 19:03:23 --> Helper loaded: date_helper
INFO - 2016-02-15 19:03:23 --> Helper loaded: form_helper
INFO - 2016-02-15 19:03:23 --> Database Driver Class Initialized
INFO - 2016-02-15 19:03:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:03:24 --> Controller Class Initialized
INFO - 2016-02-15 19:03:24 --> Model Class Initialized
INFO - 2016-02-15 19:03:24 --> Model Class Initialized
INFO - 2016-02-15 19:03:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:03:24 --> Pagination Class Initialized
INFO - 2016-02-15 19:03:24 --> Helper loaded: text_helper
INFO - 2016-02-15 19:03:47 --> Config Class Initialized
INFO - 2016-02-15 19:03:47 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:03:47 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:03:47 --> Utf8 Class Initialized
INFO - 2016-02-15 19:03:47 --> URI Class Initialized
INFO - 2016-02-15 19:03:47 --> Router Class Initialized
INFO - 2016-02-15 19:03:47 --> Output Class Initialized
INFO - 2016-02-15 19:03:47 --> Security Class Initialized
DEBUG - 2016-02-15 19:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:03:47 --> Input Class Initialized
INFO - 2016-02-15 19:03:47 --> Language Class Initialized
INFO - 2016-02-15 19:03:47 --> Loader Class Initialized
INFO - 2016-02-15 19:03:47 --> Helper loaded: url_helper
INFO - 2016-02-15 19:03:47 --> Helper loaded: file_helper
INFO - 2016-02-15 19:03:47 --> Helper loaded: date_helper
INFO - 2016-02-15 19:03:47 --> Helper loaded: form_helper
INFO - 2016-02-15 19:03:47 --> Database Driver Class Initialized
INFO - 2016-02-15 19:03:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:03:48 --> Controller Class Initialized
INFO - 2016-02-15 19:03:48 --> Model Class Initialized
INFO - 2016-02-15 19:03:48 --> Model Class Initialized
INFO - 2016-02-15 19:03:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:03:48 --> Pagination Class Initialized
INFO - 2016-02-15 19:03:48 --> Helper loaded: text_helper
INFO - 2016-02-15 22:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:03:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:03:48 --> Final output sent to browser
DEBUG - 2016-02-15 22:03:48 --> Total execution time: 1.2653
INFO - 2016-02-15 19:03:51 --> Config Class Initialized
INFO - 2016-02-15 19:03:51 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:03:51 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:03:51 --> Utf8 Class Initialized
INFO - 2016-02-15 19:03:51 --> URI Class Initialized
DEBUG - 2016-02-15 19:03:51 --> No URI present. Default controller set.
INFO - 2016-02-15 19:03:51 --> Router Class Initialized
INFO - 2016-02-15 19:03:51 --> Output Class Initialized
INFO - 2016-02-15 19:03:51 --> Security Class Initialized
DEBUG - 2016-02-15 19:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:03:51 --> Input Class Initialized
INFO - 2016-02-15 19:03:51 --> Language Class Initialized
INFO - 2016-02-15 19:03:51 --> Loader Class Initialized
INFO - 2016-02-15 19:03:51 --> Helper loaded: url_helper
INFO - 2016-02-15 19:03:51 --> Helper loaded: file_helper
INFO - 2016-02-15 19:03:51 --> Helper loaded: date_helper
INFO - 2016-02-15 19:03:51 --> Helper loaded: form_helper
INFO - 2016-02-15 19:03:51 --> Database Driver Class Initialized
INFO - 2016-02-15 19:03:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:03:53 --> Controller Class Initialized
INFO - 2016-02-15 19:03:53 --> Model Class Initialized
INFO - 2016-02-15 19:03:53 --> Model Class Initialized
INFO - 2016-02-15 19:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:03:53 --> Pagination Class Initialized
INFO - 2016-02-15 19:03:53 --> Helper loaded: text_helper
INFO - 2016-02-15 22:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:03:53 --> Final output sent to browser
DEBUG - 2016-02-15 22:03:53 --> Total execution time: 1.1559
INFO - 2016-02-15 19:03:57 --> Config Class Initialized
INFO - 2016-02-15 19:03:57 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:03:57 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:03:57 --> Utf8 Class Initialized
INFO - 2016-02-15 19:03:57 --> URI Class Initialized
INFO - 2016-02-15 19:03:57 --> Router Class Initialized
INFO - 2016-02-15 19:03:57 --> Output Class Initialized
INFO - 2016-02-15 19:03:57 --> Security Class Initialized
DEBUG - 2016-02-15 19:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:03:57 --> Input Class Initialized
INFO - 2016-02-15 19:03:57 --> Language Class Initialized
INFO - 2016-02-15 19:03:57 --> Loader Class Initialized
INFO - 2016-02-15 19:03:57 --> Helper loaded: url_helper
INFO - 2016-02-15 19:03:57 --> Helper loaded: file_helper
INFO - 2016-02-15 19:03:57 --> Helper loaded: date_helper
INFO - 2016-02-15 19:03:57 --> Helper loaded: form_helper
INFO - 2016-02-15 19:03:57 --> Database Driver Class Initialized
INFO - 2016-02-15 19:03:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:03:58 --> Controller Class Initialized
INFO - 2016-02-15 19:03:58 --> Model Class Initialized
INFO - 2016-02-15 19:03:58 --> Model Class Initialized
INFO - 2016-02-15 19:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:03:58 --> Pagination Class Initialized
INFO - 2016-02-15 19:03:58 --> Helper loaded: text_helper
INFO - 2016-02-15 22:03:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:03:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:03:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:03:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:03:58 --> Final output sent to browser
DEBUG - 2016-02-15 22:03:58 --> Total execution time: 1.1327
INFO - 2016-02-15 19:04:01 --> Config Class Initialized
INFO - 2016-02-15 19:04:01 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:04:01 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:04:01 --> Utf8 Class Initialized
INFO - 2016-02-15 19:04:01 --> URI Class Initialized
INFO - 2016-02-15 19:04:01 --> Router Class Initialized
INFO - 2016-02-15 19:04:01 --> Output Class Initialized
INFO - 2016-02-15 19:04:01 --> Security Class Initialized
DEBUG - 2016-02-15 19:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:04:01 --> Input Class Initialized
INFO - 2016-02-15 19:04:01 --> Language Class Initialized
INFO - 2016-02-15 19:04:01 --> Loader Class Initialized
INFO - 2016-02-15 19:04:01 --> Helper loaded: url_helper
INFO - 2016-02-15 19:04:01 --> Helper loaded: file_helper
INFO - 2016-02-15 19:04:01 --> Helper loaded: date_helper
INFO - 2016-02-15 19:04:01 --> Helper loaded: form_helper
INFO - 2016-02-15 19:04:01 --> Database Driver Class Initialized
INFO - 2016-02-15 19:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:04:02 --> Controller Class Initialized
INFO - 2016-02-15 19:04:02 --> Model Class Initialized
INFO - 2016-02-15 19:04:02 --> Model Class Initialized
INFO - 2016-02-15 19:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:04:02 --> Pagination Class Initialized
INFO - 2016-02-15 19:04:02 --> Helper loaded: text_helper
INFO - 2016-02-15 22:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:04:02 --> Final output sent to browser
DEBUG - 2016-02-15 22:04:02 --> Total execution time: 1.1503
INFO - 2016-02-15 19:04:04 --> Config Class Initialized
INFO - 2016-02-15 19:04:04 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:04:04 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:04:04 --> Utf8 Class Initialized
INFO - 2016-02-15 19:04:04 --> URI Class Initialized
INFO - 2016-02-15 19:04:04 --> Router Class Initialized
INFO - 2016-02-15 19:04:04 --> Output Class Initialized
INFO - 2016-02-15 19:04:04 --> Security Class Initialized
DEBUG - 2016-02-15 19:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:04:04 --> Input Class Initialized
INFO - 2016-02-15 19:04:04 --> Language Class Initialized
INFO - 2016-02-15 19:04:04 --> Loader Class Initialized
INFO - 2016-02-15 19:04:04 --> Helper loaded: url_helper
INFO - 2016-02-15 19:04:04 --> Helper loaded: file_helper
INFO - 2016-02-15 19:04:04 --> Helper loaded: date_helper
INFO - 2016-02-15 19:04:04 --> Helper loaded: form_helper
INFO - 2016-02-15 19:04:04 --> Database Driver Class Initialized
INFO - 2016-02-15 19:04:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:04:05 --> Controller Class Initialized
INFO - 2016-02-15 19:04:05 --> Model Class Initialized
INFO - 2016-02-15 19:04:05 --> Model Class Initialized
INFO - 2016-02-15 19:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:04:05 --> Pagination Class Initialized
INFO - 2016-02-15 19:04:05 --> Helper loaded: text_helper
INFO - 2016-02-15 19:04:29 --> Config Class Initialized
INFO - 2016-02-15 19:04:29 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:04:29 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:04:29 --> Utf8 Class Initialized
INFO - 2016-02-15 19:04:29 --> URI Class Initialized
DEBUG - 2016-02-15 19:04:29 --> No URI present. Default controller set.
INFO - 2016-02-15 19:04:29 --> Router Class Initialized
INFO - 2016-02-15 19:04:29 --> Output Class Initialized
INFO - 2016-02-15 19:04:29 --> Security Class Initialized
DEBUG - 2016-02-15 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:04:29 --> Input Class Initialized
INFO - 2016-02-15 19:04:29 --> Language Class Initialized
INFO - 2016-02-15 19:04:29 --> Loader Class Initialized
INFO - 2016-02-15 19:04:29 --> Helper loaded: url_helper
INFO - 2016-02-15 19:04:29 --> Helper loaded: file_helper
INFO - 2016-02-15 19:04:29 --> Helper loaded: date_helper
INFO - 2016-02-15 19:04:29 --> Helper loaded: form_helper
INFO - 2016-02-15 19:04:29 --> Database Driver Class Initialized
INFO - 2016-02-15 19:04:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:04:30 --> Controller Class Initialized
INFO - 2016-02-15 19:04:30 --> Model Class Initialized
INFO - 2016-02-15 19:04:30 --> Model Class Initialized
INFO - 2016-02-15 19:04:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:04:30 --> Pagination Class Initialized
INFO - 2016-02-15 19:04:30 --> Helper loaded: text_helper
INFO - 2016-02-15 22:04:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:04:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:04:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:04:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:04:30 --> Final output sent to browser
DEBUG - 2016-02-15 22:04:30 --> Total execution time: 1.0963
INFO - 2016-02-15 19:04:32 --> Config Class Initialized
INFO - 2016-02-15 19:04:32 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:04:32 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:04:32 --> Utf8 Class Initialized
INFO - 2016-02-15 19:04:32 --> URI Class Initialized
INFO - 2016-02-15 19:04:32 --> Router Class Initialized
INFO - 2016-02-15 19:04:32 --> Output Class Initialized
INFO - 2016-02-15 19:04:32 --> Security Class Initialized
DEBUG - 2016-02-15 19:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:04:32 --> Input Class Initialized
INFO - 2016-02-15 19:04:32 --> Language Class Initialized
INFO - 2016-02-15 19:04:32 --> Loader Class Initialized
INFO - 2016-02-15 19:04:32 --> Helper loaded: url_helper
INFO - 2016-02-15 19:04:32 --> Helper loaded: file_helper
INFO - 2016-02-15 19:04:32 --> Helper loaded: date_helper
INFO - 2016-02-15 19:04:32 --> Helper loaded: form_helper
INFO - 2016-02-15 19:04:32 --> Database Driver Class Initialized
INFO - 2016-02-15 19:04:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:04:33 --> Controller Class Initialized
INFO - 2016-02-15 19:04:33 --> Model Class Initialized
INFO - 2016-02-15 19:04:33 --> Model Class Initialized
INFO - 2016-02-15 19:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:04:33 --> Pagination Class Initialized
INFO - 2016-02-15 19:04:33 --> Helper loaded: text_helper
INFO - 2016-02-15 22:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:04:33 --> Final output sent to browser
DEBUG - 2016-02-15 22:04:33 --> Total execution time: 1.1785
INFO - 2016-02-15 19:04:35 --> Config Class Initialized
INFO - 2016-02-15 19:04:35 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:04:35 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:04:35 --> Utf8 Class Initialized
INFO - 2016-02-15 19:04:35 --> URI Class Initialized
INFO - 2016-02-15 19:04:35 --> Router Class Initialized
INFO - 2016-02-15 19:04:35 --> Output Class Initialized
INFO - 2016-02-15 19:04:35 --> Security Class Initialized
DEBUG - 2016-02-15 19:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:04:35 --> Input Class Initialized
INFO - 2016-02-15 19:04:35 --> Language Class Initialized
INFO - 2016-02-15 19:04:35 --> Loader Class Initialized
INFO - 2016-02-15 19:04:35 --> Helper loaded: url_helper
INFO - 2016-02-15 19:04:35 --> Helper loaded: file_helper
INFO - 2016-02-15 19:04:35 --> Helper loaded: date_helper
INFO - 2016-02-15 19:04:35 --> Helper loaded: form_helper
INFO - 2016-02-15 19:04:35 --> Database Driver Class Initialized
INFO - 2016-02-15 19:04:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:04:36 --> Controller Class Initialized
INFO - 2016-02-15 19:04:36 --> Model Class Initialized
INFO - 2016-02-15 19:04:36 --> Model Class Initialized
INFO - 2016-02-15 19:04:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:04:36 --> Pagination Class Initialized
INFO - 2016-02-15 19:04:36 --> Helper loaded: text_helper
INFO - 2016-02-15 22:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:04:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:04:36 --> Final output sent to browser
DEBUG - 2016-02-15 22:04:36 --> Total execution time: 1.1629
INFO - 2016-02-15 19:04:38 --> Config Class Initialized
INFO - 2016-02-15 19:04:38 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:04:38 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:04:38 --> Utf8 Class Initialized
INFO - 2016-02-15 19:04:38 --> URI Class Initialized
INFO - 2016-02-15 19:04:38 --> Router Class Initialized
INFO - 2016-02-15 19:04:38 --> Output Class Initialized
INFO - 2016-02-15 19:04:38 --> Security Class Initialized
DEBUG - 2016-02-15 19:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:04:38 --> Input Class Initialized
INFO - 2016-02-15 19:04:38 --> Language Class Initialized
INFO - 2016-02-15 19:04:38 --> Loader Class Initialized
INFO - 2016-02-15 19:04:38 --> Helper loaded: url_helper
INFO - 2016-02-15 19:04:38 --> Helper loaded: file_helper
INFO - 2016-02-15 19:04:38 --> Helper loaded: date_helper
INFO - 2016-02-15 19:04:38 --> Helper loaded: form_helper
INFO - 2016-02-15 19:04:38 --> Database Driver Class Initialized
INFO - 2016-02-15 19:04:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:04:39 --> Controller Class Initialized
INFO - 2016-02-15 19:04:39 --> Model Class Initialized
INFO - 2016-02-15 19:04:39 --> Model Class Initialized
INFO - 2016-02-15 19:04:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:04:39 --> Pagination Class Initialized
INFO - 2016-02-15 19:04:39 --> Helper loaded: text_helper
INFO - 2016-02-15 22:04:39 --> Final output sent to browser
DEBUG - 2016-02-15 22:04:39 --> Total execution time: 1.1902
INFO - 2016-02-15 19:05:45 --> Config Class Initialized
INFO - 2016-02-15 19:05:45 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:05:45 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:05:45 --> Utf8 Class Initialized
INFO - 2016-02-15 19:05:45 --> URI Class Initialized
DEBUG - 2016-02-15 19:05:45 --> No URI present. Default controller set.
INFO - 2016-02-15 19:05:45 --> Router Class Initialized
INFO - 2016-02-15 19:05:45 --> Output Class Initialized
INFO - 2016-02-15 19:05:45 --> Security Class Initialized
DEBUG - 2016-02-15 19:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:05:45 --> Input Class Initialized
INFO - 2016-02-15 19:05:45 --> Language Class Initialized
INFO - 2016-02-15 19:05:45 --> Loader Class Initialized
INFO - 2016-02-15 19:05:45 --> Helper loaded: url_helper
INFO - 2016-02-15 19:05:45 --> Helper loaded: file_helper
INFO - 2016-02-15 19:05:45 --> Helper loaded: date_helper
INFO - 2016-02-15 19:05:45 --> Helper loaded: form_helper
INFO - 2016-02-15 19:05:45 --> Database Driver Class Initialized
INFO - 2016-02-15 19:05:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:05:47 --> Controller Class Initialized
INFO - 2016-02-15 19:05:47 --> Model Class Initialized
INFO - 2016-02-15 19:05:47 --> Model Class Initialized
INFO - 2016-02-15 19:05:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:05:47 --> Pagination Class Initialized
INFO - 2016-02-15 19:05:47 --> Helper loaded: text_helper
INFO - 2016-02-15 22:05:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:05:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:05:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:05:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:05:47 --> Final output sent to browser
DEBUG - 2016-02-15 22:05:47 --> Total execution time: 1.1872
INFO - 2016-02-15 19:05:48 --> Config Class Initialized
INFO - 2016-02-15 19:05:48 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:05:48 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:05:48 --> Utf8 Class Initialized
INFO - 2016-02-15 19:05:48 --> URI Class Initialized
INFO - 2016-02-15 19:05:48 --> Router Class Initialized
INFO - 2016-02-15 19:05:48 --> Output Class Initialized
INFO - 2016-02-15 19:05:48 --> Security Class Initialized
DEBUG - 2016-02-15 19:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:05:48 --> Input Class Initialized
INFO - 2016-02-15 19:05:48 --> Language Class Initialized
INFO - 2016-02-15 19:05:48 --> Loader Class Initialized
INFO - 2016-02-15 19:05:48 --> Helper loaded: url_helper
INFO - 2016-02-15 19:05:48 --> Helper loaded: file_helper
INFO - 2016-02-15 19:05:48 --> Helper loaded: date_helper
INFO - 2016-02-15 19:05:48 --> Helper loaded: form_helper
INFO - 2016-02-15 19:05:49 --> Database Driver Class Initialized
INFO - 2016-02-15 19:05:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:05:50 --> Controller Class Initialized
INFO - 2016-02-15 19:05:50 --> Model Class Initialized
INFO - 2016-02-15 19:05:50 --> Model Class Initialized
INFO - 2016-02-15 19:05:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:05:50 --> Pagination Class Initialized
INFO - 2016-02-15 19:05:50 --> Helper loaded: text_helper
INFO - 2016-02-15 22:05:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:05:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:05:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:05:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:05:50 --> Final output sent to browser
DEBUG - 2016-02-15 22:05:50 --> Total execution time: 1.1608
INFO - 2016-02-15 19:05:53 --> Config Class Initialized
INFO - 2016-02-15 19:05:53 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:05:53 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:05:53 --> Utf8 Class Initialized
INFO - 2016-02-15 19:05:53 --> URI Class Initialized
INFO - 2016-02-15 19:05:53 --> Router Class Initialized
INFO - 2016-02-15 19:05:53 --> Output Class Initialized
INFO - 2016-02-15 19:05:53 --> Security Class Initialized
DEBUG - 2016-02-15 19:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:05:53 --> Input Class Initialized
INFO - 2016-02-15 19:05:53 --> Language Class Initialized
INFO - 2016-02-15 19:05:53 --> Loader Class Initialized
INFO - 2016-02-15 19:05:53 --> Helper loaded: url_helper
INFO - 2016-02-15 19:05:53 --> Helper loaded: file_helper
INFO - 2016-02-15 19:05:53 --> Helper loaded: date_helper
INFO - 2016-02-15 19:05:53 --> Helper loaded: form_helper
INFO - 2016-02-15 19:05:53 --> Database Driver Class Initialized
INFO - 2016-02-15 19:05:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:05:54 --> Controller Class Initialized
INFO - 2016-02-15 19:05:54 --> Model Class Initialized
INFO - 2016-02-15 19:05:54 --> Model Class Initialized
INFO - 2016-02-15 19:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:05:54 --> Pagination Class Initialized
INFO - 2016-02-15 19:05:54 --> Helper loaded: text_helper
INFO - 2016-02-15 22:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:05:54 --> Final output sent to browser
DEBUG - 2016-02-15 22:05:54 --> Total execution time: 1.1979
INFO - 2016-02-15 19:06:19 --> Config Class Initialized
INFO - 2016-02-15 19:06:19 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:06:19 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:06:19 --> Utf8 Class Initialized
INFO - 2016-02-15 19:06:19 --> URI Class Initialized
DEBUG - 2016-02-15 19:06:19 --> No URI present. Default controller set.
INFO - 2016-02-15 19:06:19 --> Router Class Initialized
INFO - 2016-02-15 19:06:19 --> Output Class Initialized
INFO - 2016-02-15 19:06:19 --> Security Class Initialized
DEBUG - 2016-02-15 19:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:06:19 --> Input Class Initialized
INFO - 2016-02-15 19:06:19 --> Language Class Initialized
INFO - 2016-02-15 19:06:19 --> Loader Class Initialized
INFO - 2016-02-15 19:06:19 --> Helper loaded: url_helper
INFO - 2016-02-15 19:06:19 --> Helper loaded: file_helper
INFO - 2016-02-15 19:06:19 --> Helper loaded: date_helper
INFO - 2016-02-15 19:06:19 --> Helper loaded: form_helper
INFO - 2016-02-15 19:06:19 --> Database Driver Class Initialized
INFO - 2016-02-15 19:06:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:06:20 --> Controller Class Initialized
INFO - 2016-02-15 19:06:20 --> Model Class Initialized
INFO - 2016-02-15 19:06:20 --> Model Class Initialized
INFO - 2016-02-15 19:06:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:06:20 --> Pagination Class Initialized
INFO - 2016-02-15 19:06:20 --> Helper loaded: text_helper
INFO - 2016-02-15 22:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:06:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:06:20 --> Final output sent to browser
DEBUG - 2016-02-15 22:06:20 --> Total execution time: 1.1669
INFO - 2016-02-15 19:06:21 --> Config Class Initialized
INFO - 2016-02-15 19:06:21 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:06:21 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:06:21 --> Utf8 Class Initialized
INFO - 2016-02-15 19:06:21 --> URI Class Initialized
INFO - 2016-02-15 19:06:21 --> Router Class Initialized
INFO - 2016-02-15 19:06:21 --> Output Class Initialized
INFO - 2016-02-15 19:06:21 --> Security Class Initialized
DEBUG - 2016-02-15 19:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:06:21 --> Input Class Initialized
INFO - 2016-02-15 19:06:21 --> Language Class Initialized
INFO - 2016-02-15 19:06:21 --> Loader Class Initialized
INFO - 2016-02-15 19:06:21 --> Helper loaded: url_helper
INFO - 2016-02-15 19:06:21 --> Helper loaded: file_helper
INFO - 2016-02-15 19:06:21 --> Helper loaded: date_helper
INFO - 2016-02-15 19:06:21 --> Helper loaded: form_helper
INFO - 2016-02-15 19:06:21 --> Database Driver Class Initialized
INFO - 2016-02-15 19:06:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:06:22 --> Controller Class Initialized
INFO - 2016-02-15 19:06:22 --> Model Class Initialized
INFO - 2016-02-15 19:06:22 --> Model Class Initialized
INFO - 2016-02-15 19:06:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:06:22 --> Pagination Class Initialized
INFO - 2016-02-15 19:06:22 --> Helper loaded: text_helper
INFO - 2016-02-15 22:06:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:06:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:06:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:06:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:06:23 --> Final output sent to browser
DEBUG - 2016-02-15 22:06:23 --> Total execution time: 1.1338
INFO - 2016-02-15 19:06:25 --> Config Class Initialized
INFO - 2016-02-15 19:06:25 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:06:25 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:06:25 --> Utf8 Class Initialized
INFO - 2016-02-15 19:06:25 --> URI Class Initialized
INFO - 2016-02-15 19:06:25 --> Router Class Initialized
INFO - 2016-02-15 19:06:25 --> Output Class Initialized
INFO - 2016-02-15 19:06:25 --> Security Class Initialized
DEBUG - 2016-02-15 19:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:06:25 --> Input Class Initialized
INFO - 2016-02-15 19:06:25 --> Language Class Initialized
INFO - 2016-02-15 19:06:25 --> Loader Class Initialized
INFO - 2016-02-15 19:06:25 --> Helper loaded: url_helper
INFO - 2016-02-15 19:06:25 --> Helper loaded: file_helper
INFO - 2016-02-15 19:06:25 --> Helper loaded: date_helper
INFO - 2016-02-15 19:06:25 --> Helper loaded: form_helper
INFO - 2016-02-15 19:06:25 --> Database Driver Class Initialized
INFO - 2016-02-15 19:06:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:06:26 --> Controller Class Initialized
INFO - 2016-02-15 19:06:26 --> Model Class Initialized
INFO - 2016-02-15 19:06:26 --> Model Class Initialized
INFO - 2016-02-15 19:06:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:06:26 --> Pagination Class Initialized
INFO - 2016-02-15 19:06:26 --> Helper loaded: text_helper
INFO - 2016-02-15 22:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:06:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:06:26 --> Final output sent to browser
DEBUG - 2016-02-15 22:06:26 --> Total execution time: 1.1898
INFO - 2016-02-15 19:07:01 --> Config Class Initialized
INFO - 2016-02-15 19:07:01 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:07:01 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:07:01 --> Utf8 Class Initialized
INFO - 2016-02-15 19:07:01 --> URI Class Initialized
DEBUG - 2016-02-15 19:07:01 --> No URI present. Default controller set.
INFO - 2016-02-15 19:07:01 --> Router Class Initialized
INFO - 2016-02-15 19:07:01 --> Output Class Initialized
INFO - 2016-02-15 19:07:01 --> Security Class Initialized
DEBUG - 2016-02-15 19:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:07:01 --> Input Class Initialized
INFO - 2016-02-15 19:07:01 --> Language Class Initialized
INFO - 2016-02-15 19:07:01 --> Loader Class Initialized
INFO - 2016-02-15 19:07:01 --> Helper loaded: url_helper
INFO - 2016-02-15 19:07:01 --> Helper loaded: file_helper
INFO - 2016-02-15 19:07:01 --> Helper loaded: date_helper
INFO - 2016-02-15 19:07:01 --> Helper loaded: form_helper
INFO - 2016-02-15 19:07:01 --> Database Driver Class Initialized
INFO - 2016-02-15 19:07:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:07:02 --> Controller Class Initialized
INFO - 2016-02-15 19:07:02 --> Model Class Initialized
INFO - 2016-02-15 19:07:02 --> Model Class Initialized
INFO - 2016-02-15 19:07:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:07:02 --> Pagination Class Initialized
INFO - 2016-02-15 19:07:02 --> Helper loaded: text_helper
INFO - 2016-02-15 22:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:07:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:07:02 --> Final output sent to browser
DEBUG - 2016-02-15 22:07:02 --> Total execution time: 1.1561
INFO - 2016-02-15 19:07:04 --> Config Class Initialized
INFO - 2016-02-15 19:07:04 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:07:04 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:07:04 --> Utf8 Class Initialized
INFO - 2016-02-15 19:07:04 --> URI Class Initialized
INFO - 2016-02-15 19:07:04 --> Router Class Initialized
INFO - 2016-02-15 19:07:04 --> Output Class Initialized
INFO - 2016-02-15 19:07:04 --> Security Class Initialized
DEBUG - 2016-02-15 19:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:07:04 --> Input Class Initialized
INFO - 2016-02-15 19:07:04 --> Language Class Initialized
INFO - 2016-02-15 19:07:04 --> Loader Class Initialized
INFO - 2016-02-15 19:07:04 --> Helper loaded: url_helper
INFO - 2016-02-15 19:07:04 --> Helper loaded: file_helper
INFO - 2016-02-15 19:07:04 --> Helper loaded: date_helper
INFO - 2016-02-15 19:07:04 --> Helper loaded: form_helper
INFO - 2016-02-15 19:07:04 --> Database Driver Class Initialized
INFO - 2016-02-15 19:07:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:07:05 --> Controller Class Initialized
INFO - 2016-02-15 19:07:05 --> Model Class Initialized
INFO - 2016-02-15 19:07:05 --> Model Class Initialized
INFO - 2016-02-15 19:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:07:05 --> Pagination Class Initialized
INFO - 2016-02-15 19:07:05 --> Helper loaded: text_helper
INFO - 2016-02-15 22:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:07:05 --> Final output sent to browser
DEBUG - 2016-02-15 22:07:05 --> Total execution time: 1.1275
INFO - 2016-02-15 19:07:08 --> Config Class Initialized
INFO - 2016-02-15 19:07:08 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:07:08 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:07:08 --> Utf8 Class Initialized
INFO - 2016-02-15 19:07:08 --> URI Class Initialized
INFO - 2016-02-15 19:07:08 --> Router Class Initialized
INFO - 2016-02-15 19:07:08 --> Output Class Initialized
INFO - 2016-02-15 19:07:08 --> Security Class Initialized
DEBUG - 2016-02-15 19:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:07:08 --> Input Class Initialized
INFO - 2016-02-15 19:07:08 --> Language Class Initialized
INFO - 2016-02-15 19:07:08 --> Loader Class Initialized
INFO - 2016-02-15 19:07:08 --> Helper loaded: url_helper
INFO - 2016-02-15 19:07:08 --> Helper loaded: file_helper
INFO - 2016-02-15 19:07:08 --> Helper loaded: date_helper
INFO - 2016-02-15 19:07:08 --> Helper loaded: form_helper
INFO - 2016-02-15 19:07:08 --> Database Driver Class Initialized
INFO - 2016-02-15 19:07:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:07:09 --> Controller Class Initialized
INFO - 2016-02-15 19:07:09 --> Model Class Initialized
INFO - 2016-02-15 19:07:09 --> Model Class Initialized
INFO - 2016-02-15 19:07:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:07:09 --> Pagination Class Initialized
INFO - 2016-02-15 19:07:09 --> Helper loaded: text_helper
INFO - 2016-02-15 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:07:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:07:09 --> Final output sent to browser
DEBUG - 2016-02-15 22:07:09 --> Total execution time: 1.1591
INFO - 2016-02-15 19:07:39 --> Config Class Initialized
INFO - 2016-02-15 19:07:39 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:07:39 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:07:39 --> Utf8 Class Initialized
INFO - 2016-02-15 19:07:39 --> URI Class Initialized
INFO - 2016-02-15 19:07:39 --> Router Class Initialized
INFO - 2016-02-15 19:07:39 --> Output Class Initialized
INFO - 2016-02-15 19:07:39 --> Security Class Initialized
DEBUG - 2016-02-15 19:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:07:39 --> Input Class Initialized
INFO - 2016-02-15 19:07:39 --> Language Class Initialized
INFO - 2016-02-15 19:07:39 --> Loader Class Initialized
INFO - 2016-02-15 19:07:39 --> Helper loaded: url_helper
INFO - 2016-02-15 19:07:39 --> Helper loaded: file_helper
INFO - 2016-02-15 19:07:39 --> Helper loaded: date_helper
INFO - 2016-02-15 19:07:39 --> Helper loaded: form_helper
INFO - 2016-02-15 19:07:39 --> Database Driver Class Initialized
INFO - 2016-02-15 19:07:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:07:40 --> Controller Class Initialized
INFO - 2016-02-15 19:07:40 --> Model Class Initialized
INFO - 2016-02-15 19:07:40 --> Model Class Initialized
INFO - 2016-02-15 19:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:07:40 --> Pagination Class Initialized
INFO - 2016-02-15 19:07:40 --> Helper loaded: text_helper
INFO - 2016-02-15 22:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:07:40 --> Final output sent to browser
DEBUG - 2016-02-15 22:07:40 --> Total execution time: 1.1738
INFO - 2016-02-15 19:07:43 --> Config Class Initialized
INFO - 2016-02-15 19:07:43 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:07:43 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:07:43 --> Utf8 Class Initialized
INFO - 2016-02-15 19:07:43 --> URI Class Initialized
INFO - 2016-02-15 19:07:43 --> Router Class Initialized
INFO - 2016-02-15 19:07:43 --> Output Class Initialized
INFO - 2016-02-15 19:07:43 --> Security Class Initialized
DEBUG - 2016-02-15 19:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:07:43 --> Input Class Initialized
INFO - 2016-02-15 19:07:43 --> Language Class Initialized
INFO - 2016-02-15 19:07:43 --> Loader Class Initialized
INFO - 2016-02-15 19:07:43 --> Helper loaded: url_helper
INFO - 2016-02-15 19:07:43 --> Helper loaded: file_helper
INFO - 2016-02-15 19:07:43 --> Helper loaded: date_helper
INFO - 2016-02-15 19:07:43 --> Helper loaded: form_helper
INFO - 2016-02-15 19:07:43 --> Database Driver Class Initialized
INFO - 2016-02-15 19:07:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:07:44 --> Controller Class Initialized
INFO - 2016-02-15 19:07:44 --> Model Class Initialized
INFO - 2016-02-15 19:07:44 --> Model Class Initialized
INFO - 2016-02-15 19:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:07:44 --> Pagination Class Initialized
INFO - 2016-02-15 19:07:44 --> Helper loaded: text_helper
INFO - 2016-02-15 22:07:44 --> Final output sent to browser
DEBUG - 2016-02-15 22:07:44 --> Total execution time: 1.1330
INFO - 2016-02-15 19:08:41 --> Config Class Initialized
INFO - 2016-02-15 19:08:41 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:08:41 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:08:41 --> Utf8 Class Initialized
INFO - 2016-02-15 19:08:41 --> URI Class Initialized
DEBUG - 2016-02-15 19:08:41 --> No URI present. Default controller set.
INFO - 2016-02-15 19:08:41 --> Router Class Initialized
INFO - 2016-02-15 19:08:41 --> Output Class Initialized
INFO - 2016-02-15 19:08:41 --> Security Class Initialized
DEBUG - 2016-02-15 19:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:08:41 --> Input Class Initialized
INFO - 2016-02-15 19:08:41 --> Language Class Initialized
INFO - 2016-02-15 19:08:41 --> Loader Class Initialized
INFO - 2016-02-15 19:08:41 --> Helper loaded: url_helper
INFO - 2016-02-15 19:08:41 --> Helper loaded: file_helper
INFO - 2016-02-15 19:08:41 --> Helper loaded: date_helper
INFO - 2016-02-15 19:08:41 --> Helper loaded: form_helper
INFO - 2016-02-15 19:08:41 --> Database Driver Class Initialized
INFO - 2016-02-15 19:08:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:08:42 --> Controller Class Initialized
INFO - 2016-02-15 19:08:42 --> Model Class Initialized
INFO - 2016-02-15 19:08:42 --> Model Class Initialized
INFO - 2016-02-15 19:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:08:42 --> Pagination Class Initialized
INFO - 2016-02-15 19:08:43 --> Helper loaded: text_helper
INFO - 2016-02-15 22:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:08:43 --> Final output sent to browser
DEBUG - 2016-02-15 22:08:43 --> Total execution time: 1.1273
INFO - 2016-02-15 19:08:44 --> Config Class Initialized
INFO - 2016-02-15 19:08:44 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:08:44 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:08:44 --> Utf8 Class Initialized
INFO - 2016-02-15 19:08:44 --> URI Class Initialized
INFO - 2016-02-15 19:08:44 --> Router Class Initialized
INFO - 2016-02-15 19:08:44 --> Output Class Initialized
INFO - 2016-02-15 19:08:44 --> Security Class Initialized
DEBUG - 2016-02-15 19:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:08:44 --> Input Class Initialized
INFO - 2016-02-15 19:08:44 --> Language Class Initialized
INFO - 2016-02-15 19:08:44 --> Loader Class Initialized
INFO - 2016-02-15 19:08:44 --> Helper loaded: url_helper
INFO - 2016-02-15 19:08:44 --> Helper loaded: file_helper
INFO - 2016-02-15 19:08:44 --> Helper loaded: date_helper
INFO - 2016-02-15 19:08:44 --> Helper loaded: form_helper
INFO - 2016-02-15 19:08:44 --> Database Driver Class Initialized
INFO - 2016-02-15 19:08:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:08:45 --> Controller Class Initialized
INFO - 2016-02-15 19:08:45 --> Model Class Initialized
INFO - 2016-02-15 19:08:45 --> Model Class Initialized
INFO - 2016-02-15 19:08:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:08:45 --> Pagination Class Initialized
INFO - 2016-02-15 19:08:45 --> Helper loaded: text_helper
INFO - 2016-02-15 22:08:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:08:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:08:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:08:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:08:45 --> Final output sent to browser
DEBUG - 2016-02-15 22:08:45 --> Total execution time: 1.1845
INFO - 2016-02-15 19:08:48 --> Config Class Initialized
INFO - 2016-02-15 19:08:48 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:08:48 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:08:48 --> Utf8 Class Initialized
INFO - 2016-02-15 19:08:48 --> URI Class Initialized
INFO - 2016-02-15 19:08:48 --> Router Class Initialized
INFO - 2016-02-15 19:08:48 --> Output Class Initialized
INFO - 2016-02-15 19:08:48 --> Security Class Initialized
DEBUG - 2016-02-15 19:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:08:48 --> Input Class Initialized
INFO - 2016-02-15 19:08:48 --> Language Class Initialized
INFO - 2016-02-15 19:08:48 --> Loader Class Initialized
INFO - 2016-02-15 19:08:48 --> Helper loaded: url_helper
INFO - 2016-02-15 19:08:48 --> Helper loaded: file_helper
INFO - 2016-02-15 19:08:48 --> Helper loaded: date_helper
INFO - 2016-02-15 19:08:48 --> Helper loaded: form_helper
INFO - 2016-02-15 19:08:48 --> Database Driver Class Initialized
INFO - 2016-02-15 19:08:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:08:49 --> Controller Class Initialized
INFO - 2016-02-15 19:08:49 --> Model Class Initialized
INFO - 2016-02-15 19:08:49 --> Model Class Initialized
INFO - 2016-02-15 19:08:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:08:49 --> Pagination Class Initialized
INFO - 2016-02-15 19:08:49 --> Helper loaded: text_helper
INFO - 2016-02-15 22:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:08:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:08:49 --> Final output sent to browser
DEBUG - 2016-02-15 22:08:49 --> Total execution time: 1.1821
INFO - 2016-02-15 19:08:51 --> Config Class Initialized
INFO - 2016-02-15 19:08:51 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:08:51 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:08:51 --> Utf8 Class Initialized
INFO - 2016-02-15 19:08:51 --> URI Class Initialized
INFO - 2016-02-15 19:08:51 --> Router Class Initialized
INFO - 2016-02-15 19:08:51 --> Output Class Initialized
INFO - 2016-02-15 19:08:51 --> Security Class Initialized
DEBUG - 2016-02-15 19:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:08:51 --> Input Class Initialized
INFO - 2016-02-15 19:08:51 --> Language Class Initialized
INFO - 2016-02-15 19:08:51 --> Loader Class Initialized
INFO - 2016-02-15 19:08:51 --> Helper loaded: url_helper
INFO - 2016-02-15 19:08:51 --> Helper loaded: file_helper
INFO - 2016-02-15 19:08:51 --> Helper loaded: date_helper
INFO - 2016-02-15 19:08:51 --> Helper loaded: form_helper
INFO - 2016-02-15 19:08:51 --> Database Driver Class Initialized
INFO - 2016-02-15 19:08:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:08:52 --> Controller Class Initialized
INFO - 2016-02-15 19:08:52 --> Model Class Initialized
INFO - 2016-02-15 19:08:52 --> Model Class Initialized
INFO - 2016-02-15 19:08:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:08:52 --> Pagination Class Initialized
INFO - 2016-02-15 19:08:52 --> Helper loaded: text_helper
INFO - 2016-02-15 19:18:40 --> Config Class Initialized
INFO - 2016-02-15 19:18:40 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:18:40 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:18:40 --> Utf8 Class Initialized
INFO - 2016-02-15 19:18:40 --> URI Class Initialized
DEBUG - 2016-02-15 19:18:40 --> No URI present. Default controller set.
INFO - 2016-02-15 19:18:40 --> Router Class Initialized
INFO - 2016-02-15 19:18:40 --> Output Class Initialized
INFO - 2016-02-15 19:18:40 --> Security Class Initialized
DEBUG - 2016-02-15 19:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:18:40 --> Input Class Initialized
INFO - 2016-02-15 19:18:40 --> Language Class Initialized
INFO - 2016-02-15 19:18:40 --> Loader Class Initialized
INFO - 2016-02-15 19:18:40 --> Helper loaded: url_helper
INFO - 2016-02-15 19:18:40 --> Helper loaded: file_helper
INFO - 2016-02-15 19:18:40 --> Helper loaded: date_helper
INFO - 2016-02-15 19:18:40 --> Helper loaded: form_helper
INFO - 2016-02-15 19:18:40 --> Database Driver Class Initialized
INFO - 2016-02-15 19:18:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:18:41 --> Controller Class Initialized
INFO - 2016-02-15 19:18:41 --> Model Class Initialized
INFO - 2016-02-15 19:18:41 --> Model Class Initialized
INFO - 2016-02-15 19:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:18:41 --> Pagination Class Initialized
INFO - 2016-02-15 19:18:41 --> Helper loaded: text_helper
INFO - 2016-02-15 22:18:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:18:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:18:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:18:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:18:41 --> Final output sent to browser
DEBUG - 2016-02-15 22:18:41 --> Total execution time: 1.1089
INFO - 2016-02-15 19:19:38 --> Config Class Initialized
INFO - 2016-02-15 19:19:38 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:19:38 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:19:38 --> Utf8 Class Initialized
INFO - 2016-02-15 19:19:38 --> URI Class Initialized
INFO - 2016-02-15 19:19:38 --> Router Class Initialized
INFO - 2016-02-15 19:19:38 --> Output Class Initialized
INFO - 2016-02-15 19:19:38 --> Security Class Initialized
DEBUG - 2016-02-15 19:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:19:38 --> Input Class Initialized
INFO - 2016-02-15 19:19:38 --> Language Class Initialized
INFO - 2016-02-15 19:19:38 --> Loader Class Initialized
INFO - 2016-02-15 19:19:38 --> Helper loaded: url_helper
INFO - 2016-02-15 19:19:38 --> Helper loaded: file_helper
INFO - 2016-02-15 19:19:38 --> Helper loaded: date_helper
INFO - 2016-02-15 19:19:38 --> Helper loaded: form_helper
INFO - 2016-02-15 19:19:38 --> Database Driver Class Initialized
INFO - 2016-02-15 19:19:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:19:39 --> Controller Class Initialized
INFO - 2016-02-15 19:19:39 --> Model Class Initialized
INFO - 2016-02-15 19:19:39 --> Model Class Initialized
INFO - 2016-02-15 19:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:19:39 --> Pagination Class Initialized
INFO - 2016-02-15 19:19:39 --> Helper loaded: text_helper
INFO - 2016-02-15 22:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:19:39 --> Form Validation Class Initialized
INFO - 2016-02-15 22:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-15 22:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:19:39 --> Final output sent to browser
DEBUG - 2016-02-15 22:19:39 --> Total execution time: 1.1077
INFO - 2016-02-15 19:37:10 --> Config Class Initialized
INFO - 2016-02-15 19:37:10 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:37:10 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:37:10 --> Utf8 Class Initialized
INFO - 2016-02-15 19:37:10 --> URI Class Initialized
DEBUG - 2016-02-15 19:37:10 --> No URI present. Default controller set.
INFO - 2016-02-15 19:37:10 --> Router Class Initialized
INFO - 2016-02-15 19:37:10 --> Output Class Initialized
INFO - 2016-02-15 19:37:10 --> Security Class Initialized
DEBUG - 2016-02-15 19:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:37:10 --> Input Class Initialized
INFO - 2016-02-15 19:37:10 --> Language Class Initialized
INFO - 2016-02-15 19:37:10 --> Loader Class Initialized
INFO - 2016-02-15 19:37:10 --> Helper loaded: url_helper
INFO - 2016-02-15 19:37:10 --> Helper loaded: file_helper
INFO - 2016-02-15 19:37:10 --> Helper loaded: date_helper
INFO - 2016-02-15 19:37:11 --> Helper loaded: form_helper
INFO - 2016-02-15 19:37:11 --> Database Driver Class Initialized
INFO - 2016-02-15 19:37:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:37:12 --> Controller Class Initialized
INFO - 2016-02-15 19:37:12 --> Model Class Initialized
INFO - 2016-02-15 19:37:12 --> Model Class Initialized
INFO - 2016-02-15 19:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:37:12 --> Pagination Class Initialized
INFO - 2016-02-15 19:37:12 --> Helper loaded: text_helper
INFO - 2016-02-15 19:37:12 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:37:12 --> Final output sent to browser
DEBUG - 2016-02-15 22:37:12 --> Total execution time: 1.1373
INFO - 2016-02-15 19:37:14 --> Config Class Initialized
INFO - 2016-02-15 19:37:14 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:37:14 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:37:14 --> Utf8 Class Initialized
INFO - 2016-02-15 19:37:14 --> URI Class Initialized
INFO - 2016-02-15 19:37:14 --> Router Class Initialized
INFO - 2016-02-15 19:37:14 --> Output Class Initialized
INFO - 2016-02-15 19:37:14 --> Security Class Initialized
DEBUG - 2016-02-15 19:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:37:14 --> Input Class Initialized
INFO - 2016-02-15 19:37:14 --> Language Class Initialized
INFO - 2016-02-15 19:37:14 --> Loader Class Initialized
INFO - 2016-02-15 19:37:14 --> Helper loaded: url_helper
INFO - 2016-02-15 19:37:14 --> Helper loaded: file_helper
INFO - 2016-02-15 19:37:14 --> Helper loaded: date_helper
INFO - 2016-02-15 19:37:14 --> Helper loaded: form_helper
INFO - 2016-02-15 19:37:14 --> Database Driver Class Initialized
INFO - 2016-02-15 19:37:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:37:15 --> Controller Class Initialized
INFO - 2016-02-15 19:37:15 --> Model Class Initialized
INFO - 2016-02-15 19:37:15 --> Model Class Initialized
INFO - 2016-02-15 19:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:37:15 --> Pagination Class Initialized
INFO - 2016-02-15 19:37:15 --> Helper loaded: text_helper
INFO - 2016-02-15 19:37:15 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:37:15 --> Final output sent to browser
DEBUG - 2016-02-15 22:37:15 --> Total execution time: 1.1026
INFO - 2016-02-15 19:37:17 --> Config Class Initialized
INFO - 2016-02-15 19:37:17 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:37:17 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:37:17 --> Utf8 Class Initialized
INFO - 2016-02-15 19:37:17 --> URI Class Initialized
INFO - 2016-02-15 19:37:17 --> Router Class Initialized
INFO - 2016-02-15 19:37:17 --> Output Class Initialized
INFO - 2016-02-15 19:37:17 --> Security Class Initialized
DEBUG - 2016-02-15 19:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:37:17 --> Input Class Initialized
INFO - 2016-02-15 19:37:17 --> Language Class Initialized
INFO - 2016-02-15 19:37:17 --> Loader Class Initialized
INFO - 2016-02-15 19:37:17 --> Helper loaded: url_helper
INFO - 2016-02-15 19:37:17 --> Helper loaded: file_helper
INFO - 2016-02-15 19:37:17 --> Helper loaded: date_helper
INFO - 2016-02-15 19:37:17 --> Helper loaded: form_helper
INFO - 2016-02-15 19:37:17 --> Database Driver Class Initialized
INFO - 2016-02-15 19:37:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:37:18 --> Controller Class Initialized
INFO - 2016-02-15 19:37:18 --> Model Class Initialized
INFO - 2016-02-15 19:37:18 --> Model Class Initialized
INFO - 2016-02-15 19:37:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:37:18 --> Pagination Class Initialized
INFO - 2016-02-15 19:37:18 --> Helper loaded: text_helper
INFO - 2016-02-15 19:37:18 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:37:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:37:18 --> Final output sent to browser
DEBUG - 2016-02-15 22:37:18 --> Total execution time: 1.1453
INFO - 2016-02-15 19:37:23 --> Config Class Initialized
INFO - 2016-02-15 19:37:23 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:37:23 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:37:23 --> Utf8 Class Initialized
INFO - 2016-02-15 19:37:23 --> URI Class Initialized
INFO - 2016-02-15 19:37:23 --> Router Class Initialized
INFO - 2016-02-15 19:37:23 --> Output Class Initialized
INFO - 2016-02-15 19:37:23 --> Security Class Initialized
DEBUG - 2016-02-15 19:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:37:23 --> Input Class Initialized
INFO - 2016-02-15 19:37:23 --> Language Class Initialized
INFO - 2016-02-15 19:37:23 --> Loader Class Initialized
INFO - 2016-02-15 19:37:23 --> Helper loaded: url_helper
INFO - 2016-02-15 19:37:23 --> Helper loaded: file_helper
INFO - 2016-02-15 19:37:23 --> Helper loaded: date_helper
INFO - 2016-02-15 19:37:23 --> Helper loaded: form_helper
INFO - 2016-02-15 19:37:23 --> Database Driver Class Initialized
INFO - 2016-02-15 19:37:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:37:24 --> Controller Class Initialized
INFO - 2016-02-15 19:37:24 --> Model Class Initialized
INFO - 2016-02-15 19:37:24 --> Model Class Initialized
INFO - 2016-02-15 19:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:37:24 --> Pagination Class Initialized
INFO - 2016-02-15 19:37:24 --> Helper loaded: text_helper
INFO - 2016-02-15 19:37:24 --> Helper loaded: cookie_helper
INFO - 2016-02-15 19:38:04 --> Config Class Initialized
INFO - 2016-02-15 19:38:04 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:38:04 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:38:04 --> Utf8 Class Initialized
INFO - 2016-02-15 19:38:04 --> URI Class Initialized
DEBUG - 2016-02-15 19:38:04 --> No URI present. Default controller set.
INFO - 2016-02-15 19:38:04 --> Router Class Initialized
INFO - 2016-02-15 19:38:04 --> Output Class Initialized
INFO - 2016-02-15 19:38:04 --> Security Class Initialized
DEBUG - 2016-02-15 19:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:38:04 --> Input Class Initialized
INFO - 2016-02-15 19:38:04 --> Language Class Initialized
INFO - 2016-02-15 19:38:04 --> Loader Class Initialized
INFO - 2016-02-15 19:38:04 --> Helper loaded: url_helper
INFO - 2016-02-15 19:38:04 --> Helper loaded: file_helper
INFO - 2016-02-15 19:38:04 --> Helper loaded: date_helper
INFO - 2016-02-15 19:38:04 --> Helper loaded: form_helper
INFO - 2016-02-15 19:38:04 --> Database Driver Class Initialized
INFO - 2016-02-15 19:38:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:38:05 --> Controller Class Initialized
INFO - 2016-02-15 19:38:05 --> Model Class Initialized
INFO - 2016-02-15 19:38:05 --> Model Class Initialized
INFO - 2016-02-15 19:38:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:38:05 --> Pagination Class Initialized
INFO - 2016-02-15 19:38:05 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:05 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:38:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:38:05 --> Final output sent to browser
DEBUG - 2016-02-15 22:38:05 --> Total execution time: 1.0934
INFO - 2016-02-15 19:38:07 --> Config Class Initialized
INFO - 2016-02-15 19:38:07 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:38:07 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:38:07 --> Utf8 Class Initialized
INFO - 2016-02-15 19:38:07 --> URI Class Initialized
INFO - 2016-02-15 19:38:07 --> Router Class Initialized
INFO - 2016-02-15 19:38:07 --> Output Class Initialized
INFO - 2016-02-15 19:38:07 --> Security Class Initialized
DEBUG - 2016-02-15 19:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:38:07 --> Input Class Initialized
INFO - 2016-02-15 19:38:07 --> Language Class Initialized
INFO - 2016-02-15 19:38:07 --> Loader Class Initialized
INFO - 2016-02-15 19:38:07 --> Helper loaded: url_helper
INFO - 2016-02-15 19:38:07 --> Helper loaded: file_helper
INFO - 2016-02-15 19:38:07 --> Helper loaded: date_helper
INFO - 2016-02-15 19:38:07 --> Helper loaded: form_helper
INFO - 2016-02-15 19:38:07 --> Database Driver Class Initialized
INFO - 2016-02-15 19:38:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:38:08 --> Controller Class Initialized
INFO - 2016-02-15 19:38:08 --> Model Class Initialized
INFO - 2016-02-15 19:38:08 --> Model Class Initialized
INFO - 2016-02-15 19:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:38:08 --> Pagination Class Initialized
INFO - 2016-02-15 19:38:08 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:08 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:38:08 --> Final output sent to browser
DEBUG - 2016-02-15 22:38:08 --> Total execution time: 1.1418
INFO - 2016-02-15 19:38:11 --> Config Class Initialized
INFO - 2016-02-15 19:38:11 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:38:11 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:38:11 --> Utf8 Class Initialized
INFO - 2016-02-15 19:38:11 --> URI Class Initialized
INFO - 2016-02-15 19:38:11 --> Router Class Initialized
INFO - 2016-02-15 19:38:11 --> Output Class Initialized
INFO - 2016-02-15 19:38:11 --> Security Class Initialized
DEBUG - 2016-02-15 19:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:38:11 --> Input Class Initialized
INFO - 2016-02-15 19:38:11 --> Language Class Initialized
INFO - 2016-02-15 19:38:11 --> Loader Class Initialized
INFO - 2016-02-15 19:38:11 --> Helper loaded: url_helper
INFO - 2016-02-15 19:38:11 --> Helper loaded: file_helper
INFO - 2016-02-15 19:38:11 --> Helper loaded: date_helper
INFO - 2016-02-15 19:38:11 --> Helper loaded: form_helper
INFO - 2016-02-15 19:38:11 --> Database Driver Class Initialized
INFO - 2016-02-15 19:38:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:38:12 --> Controller Class Initialized
INFO - 2016-02-15 19:38:12 --> Model Class Initialized
INFO - 2016-02-15 19:38:12 --> Model Class Initialized
INFO - 2016-02-15 19:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:38:12 --> Pagination Class Initialized
INFO - 2016-02-15 19:38:12 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:12 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:38:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:38:13 --> Final output sent to browser
DEBUG - 2016-02-15 22:38:13 --> Total execution time: 1.2475
INFO - 2016-02-15 19:38:16 --> Config Class Initialized
INFO - 2016-02-15 19:38:16 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:38:16 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:38:16 --> Utf8 Class Initialized
INFO - 2016-02-15 19:38:16 --> URI Class Initialized
INFO - 2016-02-15 19:38:16 --> Router Class Initialized
INFO - 2016-02-15 19:38:16 --> Output Class Initialized
INFO - 2016-02-15 19:38:16 --> Security Class Initialized
DEBUG - 2016-02-15 19:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:38:16 --> Input Class Initialized
INFO - 2016-02-15 19:38:16 --> Language Class Initialized
INFO - 2016-02-15 19:38:16 --> Loader Class Initialized
INFO - 2016-02-15 19:38:16 --> Helper loaded: url_helper
INFO - 2016-02-15 19:38:16 --> Helper loaded: file_helper
INFO - 2016-02-15 19:38:16 --> Helper loaded: date_helper
INFO - 2016-02-15 19:38:16 --> Helper loaded: form_helper
INFO - 2016-02-15 19:38:16 --> Database Driver Class Initialized
INFO - 2016-02-15 19:38:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:38:17 --> Controller Class Initialized
INFO - 2016-02-15 19:38:17 --> Model Class Initialized
INFO - 2016-02-15 19:38:17 --> Model Class Initialized
INFO - 2016-02-15 19:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:38:17 --> Pagination Class Initialized
INFO - 2016-02-15 19:38:17 --> Helper loaded: text_helper
INFO - 2016-02-15 19:38:17 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:38:17 --> Final output sent to browser
DEBUG - 2016-02-15 22:38:17 --> Total execution time: 1.1466
INFO - 2016-02-15 19:40:14 --> Config Class Initialized
INFO - 2016-02-15 19:40:14 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:40:14 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:40:14 --> Utf8 Class Initialized
INFO - 2016-02-15 19:40:14 --> URI Class Initialized
DEBUG - 2016-02-15 19:40:14 --> No URI present. Default controller set.
INFO - 2016-02-15 19:40:14 --> Router Class Initialized
INFO - 2016-02-15 19:40:14 --> Output Class Initialized
INFO - 2016-02-15 19:40:14 --> Security Class Initialized
DEBUG - 2016-02-15 19:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:40:14 --> Input Class Initialized
INFO - 2016-02-15 19:40:14 --> Language Class Initialized
INFO - 2016-02-15 19:40:14 --> Loader Class Initialized
INFO - 2016-02-15 19:40:14 --> Helper loaded: url_helper
INFO - 2016-02-15 19:40:14 --> Helper loaded: file_helper
INFO - 2016-02-15 19:40:14 --> Helper loaded: date_helper
INFO - 2016-02-15 19:40:14 --> Helper loaded: form_helper
INFO - 2016-02-15 19:40:14 --> Database Driver Class Initialized
INFO - 2016-02-15 19:40:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:40:15 --> Controller Class Initialized
INFO - 2016-02-15 19:40:15 --> Model Class Initialized
INFO - 2016-02-15 19:40:15 --> Model Class Initialized
INFO - 2016-02-15 19:40:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:40:15 --> Pagination Class Initialized
INFO - 2016-02-15 19:40:15 --> Helper loaded: text_helper
INFO - 2016-02-15 19:40:15 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:40:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:40:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:40:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:40:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:40:15 --> Final output sent to browser
DEBUG - 2016-02-15 22:40:15 --> Total execution time: 1.1195
INFO - 2016-02-15 19:40:17 --> Config Class Initialized
INFO - 2016-02-15 19:40:17 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:40:17 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:40:17 --> Utf8 Class Initialized
INFO - 2016-02-15 19:40:18 --> URI Class Initialized
INFO - 2016-02-15 19:40:18 --> Router Class Initialized
INFO - 2016-02-15 19:40:18 --> Output Class Initialized
INFO - 2016-02-15 19:40:18 --> Security Class Initialized
DEBUG - 2016-02-15 19:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:40:18 --> Input Class Initialized
INFO - 2016-02-15 19:40:18 --> Language Class Initialized
INFO - 2016-02-15 19:40:18 --> Loader Class Initialized
INFO - 2016-02-15 19:40:18 --> Helper loaded: url_helper
INFO - 2016-02-15 19:40:18 --> Helper loaded: file_helper
INFO - 2016-02-15 19:40:18 --> Helper loaded: date_helper
INFO - 2016-02-15 19:40:18 --> Helper loaded: form_helper
INFO - 2016-02-15 19:40:18 --> Database Driver Class Initialized
INFO - 2016-02-15 19:40:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:40:19 --> Controller Class Initialized
INFO - 2016-02-15 19:40:19 --> Model Class Initialized
INFO - 2016-02-15 19:40:19 --> Model Class Initialized
INFO - 2016-02-15 19:40:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:40:19 --> Pagination Class Initialized
INFO - 2016-02-15 19:40:19 --> Helper loaded: text_helper
INFO - 2016-02-15 19:40:19 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:40:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:40:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:40:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:40:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:40:19 --> Final output sent to browser
DEBUG - 2016-02-15 22:40:19 --> Total execution time: 1.1425
INFO - 2016-02-15 19:40:22 --> Config Class Initialized
INFO - 2016-02-15 19:40:22 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:40:22 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:40:22 --> Utf8 Class Initialized
INFO - 2016-02-15 19:40:22 --> URI Class Initialized
INFO - 2016-02-15 19:40:22 --> Router Class Initialized
INFO - 2016-02-15 19:40:22 --> Output Class Initialized
INFO - 2016-02-15 19:40:22 --> Security Class Initialized
DEBUG - 2016-02-15 19:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:40:22 --> Input Class Initialized
INFO - 2016-02-15 19:40:22 --> Language Class Initialized
INFO - 2016-02-15 19:40:22 --> Loader Class Initialized
INFO - 2016-02-15 19:40:22 --> Helper loaded: url_helper
INFO - 2016-02-15 19:40:22 --> Helper loaded: file_helper
INFO - 2016-02-15 19:40:22 --> Helper loaded: date_helper
INFO - 2016-02-15 19:40:22 --> Helper loaded: form_helper
INFO - 2016-02-15 19:40:22 --> Database Driver Class Initialized
INFO - 2016-02-15 19:40:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:40:23 --> Controller Class Initialized
INFO - 2016-02-15 19:40:23 --> Model Class Initialized
INFO - 2016-02-15 19:40:23 --> Model Class Initialized
INFO - 2016-02-15 19:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:40:23 --> Pagination Class Initialized
INFO - 2016-02-15 19:40:23 --> Helper loaded: text_helper
INFO - 2016-02-15 19:40:23 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:40:23 --> Final output sent to browser
DEBUG - 2016-02-15 22:40:23 --> Total execution time: 1.1703
INFO - 2016-02-15 19:40:28 --> Config Class Initialized
INFO - 2016-02-15 19:40:28 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:40:28 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:40:28 --> Utf8 Class Initialized
INFO - 2016-02-15 19:40:28 --> URI Class Initialized
INFO - 2016-02-15 19:40:28 --> Router Class Initialized
INFO - 2016-02-15 19:40:28 --> Output Class Initialized
INFO - 2016-02-15 19:40:28 --> Security Class Initialized
DEBUG - 2016-02-15 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:40:28 --> Input Class Initialized
INFO - 2016-02-15 19:40:28 --> Language Class Initialized
INFO - 2016-02-15 19:40:28 --> Loader Class Initialized
INFO - 2016-02-15 19:40:28 --> Helper loaded: url_helper
INFO - 2016-02-15 19:40:28 --> Helper loaded: file_helper
INFO - 2016-02-15 19:40:28 --> Helper loaded: date_helper
INFO - 2016-02-15 19:40:28 --> Helper loaded: form_helper
INFO - 2016-02-15 19:40:28 --> Database Driver Class Initialized
INFO - 2016-02-15 19:40:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:40:29 --> Controller Class Initialized
INFO - 2016-02-15 19:40:29 --> Model Class Initialized
INFO - 2016-02-15 19:40:29 --> Model Class Initialized
INFO - 2016-02-15 19:40:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:40:29 --> Pagination Class Initialized
INFO - 2016-02-15 19:40:29 --> Helper loaded: text_helper
INFO - 2016-02-15 19:40:29 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:40:29 --> Final output sent to browser
DEBUG - 2016-02-15 22:40:29 --> Total execution time: 1.1261
INFO - 2016-02-15 19:42:48 --> Config Class Initialized
INFO - 2016-02-15 19:42:48 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:42:48 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:42:48 --> Utf8 Class Initialized
INFO - 2016-02-15 19:42:48 --> URI Class Initialized
DEBUG - 2016-02-15 19:42:48 --> No URI present. Default controller set.
INFO - 2016-02-15 19:42:48 --> Router Class Initialized
INFO - 2016-02-15 19:42:48 --> Output Class Initialized
INFO - 2016-02-15 19:42:48 --> Security Class Initialized
DEBUG - 2016-02-15 19:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:42:48 --> Input Class Initialized
INFO - 2016-02-15 19:42:48 --> Language Class Initialized
INFO - 2016-02-15 19:42:48 --> Loader Class Initialized
INFO - 2016-02-15 19:42:48 --> Helper loaded: url_helper
INFO - 2016-02-15 19:42:48 --> Helper loaded: file_helper
INFO - 2016-02-15 19:42:48 --> Helper loaded: date_helper
INFO - 2016-02-15 19:42:48 --> Helper loaded: form_helper
INFO - 2016-02-15 19:42:48 --> Database Driver Class Initialized
INFO - 2016-02-15 19:42:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:42:49 --> Controller Class Initialized
INFO - 2016-02-15 19:42:49 --> Model Class Initialized
INFO - 2016-02-15 19:42:49 --> Model Class Initialized
INFO - 2016-02-15 19:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:42:49 --> Pagination Class Initialized
INFO - 2016-02-15 19:42:49 --> Helper loaded: text_helper
INFO - 2016-02-15 19:42:49 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:42:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:42:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:42:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:42:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:42:49 --> Final output sent to browser
DEBUG - 2016-02-15 22:42:49 --> Total execution time: 1.0890
INFO - 2016-02-15 19:42:52 --> Config Class Initialized
INFO - 2016-02-15 19:42:52 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:42:52 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:42:52 --> Utf8 Class Initialized
INFO - 2016-02-15 19:42:52 --> URI Class Initialized
INFO - 2016-02-15 19:42:52 --> Router Class Initialized
INFO - 2016-02-15 19:42:52 --> Output Class Initialized
INFO - 2016-02-15 19:42:52 --> Security Class Initialized
DEBUG - 2016-02-15 19:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:42:52 --> Input Class Initialized
INFO - 2016-02-15 19:42:52 --> Language Class Initialized
INFO - 2016-02-15 19:42:52 --> Loader Class Initialized
INFO - 2016-02-15 19:42:52 --> Helper loaded: url_helper
INFO - 2016-02-15 19:42:52 --> Helper loaded: file_helper
INFO - 2016-02-15 19:42:52 --> Helper loaded: date_helper
INFO - 2016-02-15 19:42:52 --> Helper loaded: form_helper
INFO - 2016-02-15 19:42:52 --> Database Driver Class Initialized
INFO - 2016-02-15 19:42:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:42:53 --> Controller Class Initialized
INFO - 2016-02-15 19:42:53 --> Model Class Initialized
INFO - 2016-02-15 19:42:53 --> Model Class Initialized
INFO - 2016-02-15 19:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:42:53 --> Pagination Class Initialized
INFO - 2016-02-15 19:42:53 --> Helper loaded: text_helper
INFO - 2016-02-15 19:42:53 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:42:53 --> Final output sent to browser
DEBUG - 2016-02-15 22:42:53 --> Total execution time: 1.1051
INFO - 2016-02-15 19:42:56 --> Config Class Initialized
INFO - 2016-02-15 19:42:56 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:42:56 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:42:57 --> Utf8 Class Initialized
INFO - 2016-02-15 19:42:57 --> URI Class Initialized
INFO - 2016-02-15 19:42:57 --> Router Class Initialized
INFO - 2016-02-15 19:42:57 --> Output Class Initialized
INFO - 2016-02-15 19:42:57 --> Security Class Initialized
DEBUG - 2016-02-15 19:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:42:57 --> Input Class Initialized
INFO - 2016-02-15 19:42:57 --> Language Class Initialized
INFO - 2016-02-15 19:42:57 --> Loader Class Initialized
INFO - 2016-02-15 19:42:57 --> Helper loaded: url_helper
INFO - 2016-02-15 19:42:57 --> Helper loaded: file_helper
INFO - 2016-02-15 19:42:57 --> Helper loaded: date_helper
INFO - 2016-02-15 19:42:57 --> Helper loaded: form_helper
INFO - 2016-02-15 19:42:57 --> Database Driver Class Initialized
INFO - 2016-02-15 19:42:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:42:58 --> Controller Class Initialized
INFO - 2016-02-15 19:42:58 --> Model Class Initialized
INFO - 2016-02-15 19:42:58 --> Model Class Initialized
INFO - 2016-02-15 19:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:42:58 --> Pagination Class Initialized
INFO - 2016-02-15 19:42:58 --> Helper loaded: text_helper
INFO - 2016-02-15 19:42:58 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:42:58 --> Final output sent to browser
DEBUG - 2016-02-15 22:42:58 --> Total execution time: 1.1399
INFO - 2016-02-15 19:43:01 --> Config Class Initialized
INFO - 2016-02-15 19:43:01 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:43:01 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:43:01 --> Utf8 Class Initialized
INFO - 2016-02-15 19:43:01 --> URI Class Initialized
INFO - 2016-02-15 19:43:01 --> Router Class Initialized
INFO - 2016-02-15 19:43:01 --> Output Class Initialized
INFO - 2016-02-15 19:43:01 --> Security Class Initialized
DEBUG - 2016-02-15 19:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:43:01 --> Input Class Initialized
INFO - 2016-02-15 19:43:01 --> Language Class Initialized
INFO - 2016-02-15 19:43:01 --> Loader Class Initialized
INFO - 2016-02-15 19:43:01 --> Helper loaded: url_helper
INFO - 2016-02-15 19:43:01 --> Helper loaded: file_helper
INFO - 2016-02-15 19:43:01 --> Helper loaded: date_helper
INFO - 2016-02-15 19:43:01 --> Helper loaded: form_helper
INFO - 2016-02-15 19:43:01 --> Database Driver Class Initialized
INFO - 2016-02-15 19:43:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:43:02 --> Controller Class Initialized
INFO - 2016-02-15 19:43:02 --> Model Class Initialized
INFO - 2016-02-15 19:43:02 --> Model Class Initialized
INFO - 2016-02-15 19:43:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:43:02 --> Pagination Class Initialized
INFO - 2016-02-15 19:43:02 --> Helper loaded: text_helper
INFO - 2016-02-15 19:43:02 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:43:02 --> Final output sent to browser
DEBUG - 2016-02-15 22:43:02 --> Total execution time: 1.1097
INFO - 2016-02-15 19:43:30 --> Config Class Initialized
INFO - 2016-02-15 19:43:30 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:43:30 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:43:30 --> Utf8 Class Initialized
INFO - 2016-02-15 19:43:30 --> URI Class Initialized
INFO - 2016-02-15 19:43:30 --> Router Class Initialized
INFO - 2016-02-15 19:43:30 --> Output Class Initialized
INFO - 2016-02-15 19:43:30 --> Security Class Initialized
DEBUG - 2016-02-15 19:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:43:30 --> Input Class Initialized
INFO - 2016-02-15 19:43:30 --> Language Class Initialized
INFO - 2016-02-15 19:43:30 --> Loader Class Initialized
INFO - 2016-02-15 19:43:30 --> Helper loaded: url_helper
INFO - 2016-02-15 19:43:30 --> Helper loaded: file_helper
INFO - 2016-02-15 19:43:30 --> Helper loaded: date_helper
INFO - 2016-02-15 19:43:30 --> Helper loaded: form_helper
INFO - 2016-02-15 19:43:30 --> Database Driver Class Initialized
INFO - 2016-02-15 19:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:43:31 --> Controller Class Initialized
INFO - 2016-02-15 19:43:31 --> Model Class Initialized
INFO - 2016-02-15 19:43:31 --> Model Class Initialized
INFO - 2016-02-15 19:43:31 --> Form Validation Class Initialized
INFO - 2016-02-15 19:43:31 --> Helper loaded: text_helper
INFO - 2016-02-15 19:43:31 --> Config Class Initialized
INFO - 2016-02-15 19:43:31 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:43:31 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:43:31 --> Utf8 Class Initialized
INFO - 2016-02-15 19:43:31 --> URI Class Initialized
INFO - 2016-02-15 19:43:31 --> Router Class Initialized
INFO - 2016-02-15 19:43:31 --> Output Class Initialized
INFO - 2016-02-15 19:43:31 --> Security Class Initialized
DEBUG - 2016-02-15 19:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:43:31 --> Input Class Initialized
INFO - 2016-02-15 19:43:31 --> Language Class Initialized
INFO - 2016-02-15 19:43:31 --> Loader Class Initialized
INFO - 2016-02-15 19:43:31 --> Helper loaded: url_helper
INFO - 2016-02-15 19:43:31 --> Helper loaded: file_helper
INFO - 2016-02-15 19:43:31 --> Helper loaded: date_helper
INFO - 2016-02-15 19:43:31 --> Helper loaded: form_helper
INFO - 2016-02-15 19:43:31 --> Database Driver Class Initialized
INFO - 2016-02-15 19:43:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:43:32 --> Controller Class Initialized
INFO - 2016-02-15 19:43:32 --> Model Class Initialized
INFO - 2016-02-15 19:43:32 --> Model Class Initialized
INFO - 2016-02-15 19:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:43:32 --> Pagination Class Initialized
INFO - 2016-02-15 19:43:32 --> Helper loaded: text_helper
INFO - 2016-02-15 19:43:32 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:43:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:43:32 --> Final output sent to browser
DEBUG - 2016-02-15 22:43:32 --> Total execution time: 1.1297
INFO - 2016-02-15 19:43:43 --> Config Class Initialized
INFO - 2016-02-15 19:43:43 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:43:43 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:43:43 --> Utf8 Class Initialized
INFO - 2016-02-15 19:43:43 --> URI Class Initialized
INFO - 2016-02-15 19:43:43 --> Router Class Initialized
INFO - 2016-02-15 19:43:43 --> Output Class Initialized
INFO - 2016-02-15 19:43:43 --> Security Class Initialized
DEBUG - 2016-02-15 19:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:43:43 --> Input Class Initialized
INFO - 2016-02-15 19:43:43 --> Language Class Initialized
INFO - 2016-02-15 19:43:43 --> Loader Class Initialized
INFO - 2016-02-15 19:43:43 --> Helper loaded: url_helper
INFO - 2016-02-15 19:43:43 --> Helper loaded: file_helper
INFO - 2016-02-15 19:43:43 --> Helper loaded: date_helper
INFO - 2016-02-15 19:43:43 --> Helper loaded: form_helper
INFO - 2016-02-15 19:43:44 --> Database Driver Class Initialized
INFO - 2016-02-15 19:43:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:43:45 --> Controller Class Initialized
INFO - 2016-02-15 19:43:45 --> Model Class Initialized
INFO - 2016-02-15 19:43:45 --> Model Class Initialized
INFO - 2016-02-15 19:43:45 --> Form Validation Class Initialized
INFO - 2016-02-15 19:43:45 --> Helper loaded: text_helper
INFO - 2016-02-15 19:43:45 --> Config Class Initialized
INFO - 2016-02-15 19:43:45 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:43:45 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:43:45 --> Utf8 Class Initialized
INFO - 2016-02-15 19:43:45 --> URI Class Initialized
INFO - 2016-02-15 19:43:45 --> Router Class Initialized
INFO - 2016-02-15 19:43:45 --> Output Class Initialized
INFO - 2016-02-15 19:43:45 --> Security Class Initialized
DEBUG - 2016-02-15 19:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:43:45 --> Input Class Initialized
INFO - 2016-02-15 19:43:45 --> Language Class Initialized
INFO - 2016-02-15 19:43:45 --> Loader Class Initialized
INFO - 2016-02-15 19:43:45 --> Helper loaded: url_helper
INFO - 2016-02-15 19:43:45 --> Helper loaded: file_helper
INFO - 2016-02-15 19:43:45 --> Helper loaded: date_helper
INFO - 2016-02-15 19:43:45 --> Helper loaded: form_helper
INFO - 2016-02-15 19:43:45 --> Database Driver Class Initialized
INFO - 2016-02-15 19:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:43:46 --> Controller Class Initialized
INFO - 2016-02-15 19:43:46 --> Model Class Initialized
INFO - 2016-02-15 19:43:46 --> Model Class Initialized
INFO - 2016-02-15 19:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:43:46 --> Pagination Class Initialized
INFO - 2016-02-15 19:43:46 --> Helper loaded: text_helper
INFO - 2016-02-15 19:43:46 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:43:46 --> Final output sent to browser
DEBUG - 2016-02-15 22:43:46 --> Total execution time: 1.1099
INFO - 2016-02-15 19:43:51 --> Config Class Initialized
INFO - 2016-02-15 19:43:51 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:43:51 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:43:51 --> Utf8 Class Initialized
INFO - 2016-02-15 19:43:51 --> URI Class Initialized
INFO - 2016-02-15 19:43:51 --> Router Class Initialized
INFO - 2016-02-15 19:43:51 --> Output Class Initialized
INFO - 2016-02-15 19:43:51 --> Security Class Initialized
DEBUG - 2016-02-15 19:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:43:51 --> Input Class Initialized
INFO - 2016-02-15 19:43:51 --> Language Class Initialized
INFO - 2016-02-15 19:43:51 --> Loader Class Initialized
INFO - 2016-02-15 19:43:51 --> Helper loaded: url_helper
INFO - 2016-02-15 19:43:51 --> Helper loaded: file_helper
INFO - 2016-02-15 19:43:51 --> Helper loaded: date_helper
INFO - 2016-02-15 19:43:51 --> Helper loaded: form_helper
INFO - 2016-02-15 19:43:51 --> Database Driver Class Initialized
INFO - 2016-02-15 19:43:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:43:52 --> Controller Class Initialized
INFO - 2016-02-15 19:43:52 --> Model Class Initialized
INFO - 2016-02-15 19:43:52 --> Model Class Initialized
INFO - 2016-02-15 19:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:43:52 --> Pagination Class Initialized
INFO - 2016-02-15 19:43:52 --> Helper loaded: text_helper
INFO - 2016-02-15 19:43:52 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:43:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:43:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:43:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-15 22:43:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:43:52 --> Final output sent to browser
DEBUG - 2016-02-15 22:43:52 --> Total execution time: 1.0911
INFO - 2016-02-15 19:44:00 --> Config Class Initialized
INFO - 2016-02-15 19:44:00 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:44:00 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:44:00 --> Utf8 Class Initialized
INFO - 2016-02-15 19:44:00 --> URI Class Initialized
INFO - 2016-02-15 19:44:00 --> Router Class Initialized
INFO - 2016-02-15 19:44:00 --> Output Class Initialized
INFO - 2016-02-15 19:44:00 --> Security Class Initialized
DEBUG - 2016-02-15 19:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:44:00 --> Input Class Initialized
INFO - 2016-02-15 19:44:00 --> Language Class Initialized
INFO - 2016-02-15 19:44:00 --> Loader Class Initialized
INFO - 2016-02-15 19:44:00 --> Helper loaded: url_helper
INFO - 2016-02-15 19:44:00 --> Helper loaded: file_helper
INFO - 2016-02-15 19:44:00 --> Helper loaded: date_helper
INFO - 2016-02-15 19:44:00 --> Helper loaded: form_helper
INFO - 2016-02-15 19:44:00 --> Database Driver Class Initialized
INFO - 2016-02-15 19:44:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:44:01 --> Controller Class Initialized
INFO - 2016-02-15 19:44:01 --> Model Class Initialized
INFO - 2016-02-15 19:44:01 --> Model Class Initialized
INFO - 2016-02-15 19:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:44:01 --> Pagination Class Initialized
INFO - 2016-02-15 19:44:01 --> Helper loaded: text_helper
INFO - 2016-02-15 19:44:01 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:44:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:44:01 --> Final output sent to browser
DEBUG - 2016-02-15 22:44:01 --> Total execution time: 1.1069
INFO - 2016-02-15 19:44:03 --> Config Class Initialized
INFO - 2016-02-15 19:44:03 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:44:03 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:44:03 --> Utf8 Class Initialized
INFO - 2016-02-15 19:44:03 --> URI Class Initialized
INFO - 2016-02-15 19:44:03 --> Router Class Initialized
INFO - 2016-02-15 19:44:03 --> Output Class Initialized
INFO - 2016-02-15 19:44:03 --> Security Class Initialized
DEBUG - 2016-02-15 19:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:44:03 --> Input Class Initialized
INFO - 2016-02-15 19:44:03 --> Language Class Initialized
INFO - 2016-02-15 19:44:03 --> Loader Class Initialized
INFO - 2016-02-15 19:44:03 --> Helper loaded: url_helper
INFO - 2016-02-15 19:44:03 --> Helper loaded: file_helper
INFO - 2016-02-15 19:44:03 --> Helper loaded: date_helper
INFO - 2016-02-15 19:44:03 --> Helper loaded: form_helper
INFO - 2016-02-15 19:44:03 --> Database Driver Class Initialized
INFO - 2016-02-15 19:44:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:44:04 --> Controller Class Initialized
INFO - 2016-02-15 19:44:04 --> Model Class Initialized
INFO - 2016-02-15 19:44:04 --> Model Class Initialized
INFO - 2016-02-15 19:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:44:04 --> Pagination Class Initialized
INFO - 2016-02-15 19:44:04 --> Helper loaded: text_helper
INFO - 2016-02-15 19:44:04 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:44:04 --> Final output sent to browser
DEBUG - 2016-02-15 22:44:04 --> Total execution time: 1.0923
INFO - 2016-02-15 19:47:49 --> Config Class Initialized
INFO - 2016-02-15 19:47:49 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:47:49 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:47:49 --> Utf8 Class Initialized
INFO - 2016-02-15 19:47:49 --> URI Class Initialized
INFO - 2016-02-15 19:47:49 --> Router Class Initialized
INFO - 2016-02-15 19:47:49 --> Output Class Initialized
INFO - 2016-02-15 19:47:49 --> Security Class Initialized
DEBUG - 2016-02-15 19:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:47:50 --> Input Class Initialized
INFO - 2016-02-15 19:47:50 --> Language Class Initialized
INFO - 2016-02-15 19:47:50 --> Loader Class Initialized
INFO - 2016-02-15 19:47:50 --> Helper loaded: url_helper
INFO - 2016-02-15 19:47:50 --> Helper loaded: file_helper
INFO - 2016-02-15 19:47:50 --> Helper loaded: date_helper
INFO - 2016-02-15 19:47:50 --> Helper loaded: form_helper
INFO - 2016-02-15 19:47:50 --> Database Driver Class Initialized
INFO - 2016-02-15 19:47:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:47:51 --> Controller Class Initialized
INFO - 2016-02-15 19:47:51 --> Model Class Initialized
INFO - 2016-02-15 19:47:51 --> Model Class Initialized
INFO - 2016-02-15 19:47:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:47:51 --> Pagination Class Initialized
INFO - 2016-02-15 19:47:51 --> Helper loaded: text_helper
INFO - 2016-02-15 19:47:51 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:47:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:47:51 --> Final output sent to browser
DEBUG - 2016-02-15 22:47:51 --> Total execution time: 1.1493
INFO - 2016-02-15 19:47:53 --> Config Class Initialized
INFO - 2016-02-15 19:47:53 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:47:53 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:47:53 --> Utf8 Class Initialized
INFO - 2016-02-15 19:47:53 --> URI Class Initialized
INFO - 2016-02-15 19:47:53 --> Router Class Initialized
INFO - 2016-02-15 19:47:53 --> Output Class Initialized
INFO - 2016-02-15 19:47:53 --> Security Class Initialized
DEBUG - 2016-02-15 19:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:47:53 --> Input Class Initialized
INFO - 2016-02-15 19:47:53 --> Language Class Initialized
INFO - 2016-02-15 19:47:53 --> Loader Class Initialized
INFO - 2016-02-15 19:47:53 --> Helper loaded: url_helper
INFO - 2016-02-15 19:47:53 --> Helper loaded: file_helper
INFO - 2016-02-15 19:47:53 --> Helper loaded: date_helper
INFO - 2016-02-15 19:47:53 --> Helper loaded: form_helper
INFO - 2016-02-15 19:47:53 --> Database Driver Class Initialized
INFO - 2016-02-15 19:47:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:47:54 --> Controller Class Initialized
INFO - 2016-02-15 19:47:54 --> Model Class Initialized
INFO - 2016-02-15 19:47:54 --> Model Class Initialized
INFO - 2016-02-15 19:47:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:47:54 --> Pagination Class Initialized
INFO - 2016-02-15 19:47:54 --> Helper loaded: text_helper
INFO - 2016-02-15 19:47:54 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:47:54 --> Final output sent to browser
DEBUG - 2016-02-15 22:47:54 --> Total execution time: 1.0782
INFO - 2016-02-15 19:56:01 --> Config Class Initialized
INFO - 2016-02-15 19:56:01 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:56:01 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:56:01 --> Utf8 Class Initialized
INFO - 2016-02-15 19:56:01 --> URI Class Initialized
INFO - 2016-02-15 19:56:01 --> Router Class Initialized
INFO - 2016-02-15 19:56:01 --> Output Class Initialized
INFO - 2016-02-15 19:56:01 --> Security Class Initialized
DEBUG - 2016-02-15 19:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:56:01 --> Input Class Initialized
INFO - 2016-02-15 19:56:01 --> Language Class Initialized
ERROR - 2016-02-15 19:56:01 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 457
INFO - 2016-02-15 19:56:10 --> Config Class Initialized
INFO - 2016-02-15 19:56:10 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:56:10 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:56:10 --> Utf8 Class Initialized
INFO - 2016-02-15 19:56:10 --> URI Class Initialized
INFO - 2016-02-15 19:56:10 --> Router Class Initialized
INFO - 2016-02-15 19:56:10 --> Output Class Initialized
INFO - 2016-02-15 19:56:10 --> Security Class Initialized
DEBUG - 2016-02-15 19:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:56:10 --> Input Class Initialized
INFO - 2016-02-15 19:56:10 --> Language Class Initialized
ERROR - 2016-02-15 19:56:10 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 457
INFO - 2016-02-15 19:56:16 --> Config Class Initialized
INFO - 2016-02-15 19:56:16 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:56:16 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:56:16 --> Utf8 Class Initialized
INFO - 2016-02-15 19:56:16 --> URI Class Initialized
INFO - 2016-02-15 19:56:16 --> Router Class Initialized
INFO - 2016-02-15 19:56:16 --> Output Class Initialized
INFO - 2016-02-15 19:56:16 --> Security Class Initialized
DEBUG - 2016-02-15 19:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:56:16 --> Input Class Initialized
INFO - 2016-02-15 19:56:16 --> Language Class Initialized
INFO - 2016-02-15 19:56:16 --> Loader Class Initialized
INFO - 2016-02-15 19:56:16 --> Helper loaded: url_helper
INFO - 2016-02-15 19:56:16 --> Helper loaded: file_helper
INFO - 2016-02-15 19:56:16 --> Helper loaded: date_helper
INFO - 2016-02-15 19:56:16 --> Helper loaded: form_helper
INFO - 2016-02-15 19:56:16 --> Database Driver Class Initialized
INFO - 2016-02-15 19:56:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:56:17 --> Controller Class Initialized
INFO - 2016-02-15 19:56:17 --> Model Class Initialized
INFO - 2016-02-15 19:56:17 --> Model Class Initialized
INFO - 2016-02-15 19:56:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:56:17 --> Pagination Class Initialized
INFO - 2016-02-15 19:56:17 --> Helper loaded: text_helper
INFO - 2016-02-15 19:56:17 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:56:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:56:17 --> Final output sent to browser
DEBUG - 2016-02-15 22:56:17 --> Total execution time: 1.1600
INFO - 2016-02-15 19:56:33 --> Config Class Initialized
INFO - 2016-02-15 19:56:33 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:56:33 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:56:33 --> Utf8 Class Initialized
INFO - 2016-02-15 19:56:33 --> URI Class Initialized
INFO - 2016-02-15 19:56:33 --> Router Class Initialized
INFO - 2016-02-15 19:56:33 --> Output Class Initialized
INFO - 2016-02-15 19:56:33 --> Security Class Initialized
DEBUG - 2016-02-15 19:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:56:33 --> Input Class Initialized
INFO - 2016-02-15 19:56:33 --> Language Class Initialized
INFO - 2016-02-15 19:56:33 --> Loader Class Initialized
INFO - 2016-02-15 19:56:33 --> Helper loaded: url_helper
INFO - 2016-02-15 19:56:33 --> Helper loaded: file_helper
INFO - 2016-02-15 19:56:33 --> Helper loaded: date_helper
INFO - 2016-02-15 19:56:33 --> Helper loaded: form_helper
INFO - 2016-02-15 19:56:33 --> Database Driver Class Initialized
INFO - 2016-02-15 19:56:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:56:34 --> Controller Class Initialized
INFO - 2016-02-15 19:56:34 --> Model Class Initialized
INFO - 2016-02-15 19:56:34 --> Model Class Initialized
INFO - 2016-02-15 19:56:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:56:34 --> Pagination Class Initialized
INFO - 2016-02-15 19:56:34 --> Helper loaded: text_helper
INFO - 2016-02-15 19:56:34 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:56:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:56:34 --> Final output sent to browser
DEBUG - 2016-02-15 22:56:34 --> Total execution time: 1.1374
INFO - 2016-02-15 19:56:37 --> Config Class Initialized
INFO - 2016-02-15 19:56:37 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:56:37 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:56:37 --> Utf8 Class Initialized
INFO - 2016-02-15 19:56:37 --> URI Class Initialized
INFO - 2016-02-15 19:56:37 --> Router Class Initialized
INFO - 2016-02-15 19:56:37 --> Output Class Initialized
INFO - 2016-02-15 19:56:37 --> Security Class Initialized
DEBUG - 2016-02-15 19:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:56:37 --> Input Class Initialized
INFO - 2016-02-15 19:56:37 --> Language Class Initialized
INFO - 2016-02-15 19:56:37 --> Loader Class Initialized
INFO - 2016-02-15 19:56:37 --> Helper loaded: url_helper
INFO - 2016-02-15 19:56:37 --> Helper loaded: file_helper
INFO - 2016-02-15 19:56:37 --> Helper loaded: date_helper
INFO - 2016-02-15 19:56:37 --> Helper loaded: form_helper
INFO - 2016-02-15 19:56:37 --> Database Driver Class Initialized
INFO - 2016-02-15 19:56:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:56:39 --> Controller Class Initialized
INFO - 2016-02-15 19:56:39 --> Model Class Initialized
INFO - 2016-02-15 19:56:39 --> Model Class Initialized
INFO - 2016-02-15 19:56:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:56:39 --> Pagination Class Initialized
INFO - 2016-02-15 19:56:39 --> Helper loaded: text_helper
INFO - 2016-02-15 19:56:39 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:56:39 --> Final output sent to browser
DEBUG - 2016-02-15 22:56:39 --> Total execution time: 1.1090
INFO - 2016-02-15 19:56:41 --> Config Class Initialized
INFO - 2016-02-15 19:56:42 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:56:42 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:56:42 --> Utf8 Class Initialized
INFO - 2016-02-15 19:56:42 --> URI Class Initialized
INFO - 2016-02-15 19:56:42 --> Router Class Initialized
INFO - 2016-02-15 19:56:42 --> Output Class Initialized
INFO - 2016-02-15 19:56:42 --> Security Class Initialized
DEBUG - 2016-02-15 19:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:56:42 --> Input Class Initialized
INFO - 2016-02-15 19:56:42 --> Language Class Initialized
INFO - 2016-02-15 19:56:42 --> Loader Class Initialized
INFO - 2016-02-15 19:56:42 --> Helper loaded: url_helper
INFO - 2016-02-15 19:56:42 --> Helper loaded: file_helper
INFO - 2016-02-15 19:56:42 --> Helper loaded: date_helper
INFO - 2016-02-15 19:56:42 --> Helper loaded: form_helper
INFO - 2016-02-15 19:56:42 --> Database Driver Class Initialized
INFO - 2016-02-15 19:56:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:56:43 --> Controller Class Initialized
INFO - 2016-02-15 19:56:43 --> Model Class Initialized
INFO - 2016-02-15 19:56:43 --> Model Class Initialized
INFO - 2016-02-15 19:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:56:43 --> Pagination Class Initialized
INFO - 2016-02-15 19:56:43 --> Helper loaded: text_helper
INFO - 2016-02-15 19:56:43 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:56:43 --> Final output sent to browser
DEBUG - 2016-02-15 22:56:43 --> Total execution time: 1.1190
INFO - 2016-02-15 19:57:08 --> Config Class Initialized
INFO - 2016-02-15 19:57:08 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:57:08 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:57:08 --> Utf8 Class Initialized
INFO - 2016-02-15 19:57:08 --> URI Class Initialized
INFO - 2016-02-15 19:57:08 --> Router Class Initialized
INFO - 2016-02-15 19:57:08 --> Output Class Initialized
INFO - 2016-02-15 19:57:08 --> Security Class Initialized
DEBUG - 2016-02-15 19:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:57:08 --> Input Class Initialized
INFO - 2016-02-15 19:57:08 --> Language Class Initialized
INFO - 2016-02-15 19:57:08 --> Loader Class Initialized
INFO - 2016-02-15 19:57:08 --> Helper loaded: url_helper
INFO - 2016-02-15 19:57:08 --> Helper loaded: file_helper
INFO - 2016-02-15 19:57:08 --> Helper loaded: date_helper
INFO - 2016-02-15 19:57:08 --> Helper loaded: form_helper
INFO - 2016-02-15 19:57:08 --> Database Driver Class Initialized
INFO - 2016-02-15 19:57:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:57:09 --> Controller Class Initialized
INFO - 2016-02-15 19:57:09 --> Model Class Initialized
INFO - 2016-02-15 19:57:09 --> Model Class Initialized
INFO - 2016-02-15 19:57:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:57:09 --> Pagination Class Initialized
INFO - 2016-02-15 19:57:09 --> Helper loaded: text_helper
INFO - 2016-02-15 19:57:09 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-15 22:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-15 22:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-15 22:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-15 22:57:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-15 22:57:09 --> Final output sent to browser
DEBUG - 2016-02-15 22:57:09 --> Total execution time: 1.1757
INFO - 2016-02-15 19:57:10 --> Config Class Initialized
INFO - 2016-02-15 19:57:10 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:57:10 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:57:10 --> Utf8 Class Initialized
INFO - 2016-02-15 19:57:10 --> URI Class Initialized
INFO - 2016-02-15 19:57:10 --> Router Class Initialized
INFO - 2016-02-15 19:57:10 --> Output Class Initialized
INFO - 2016-02-15 19:57:10 --> Security Class Initialized
DEBUG - 2016-02-15 19:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:57:10 --> Input Class Initialized
INFO - 2016-02-15 19:57:10 --> Language Class Initialized
INFO - 2016-02-15 19:57:10 --> Loader Class Initialized
INFO - 2016-02-15 19:57:10 --> Helper loaded: url_helper
INFO - 2016-02-15 19:57:10 --> Helper loaded: file_helper
INFO - 2016-02-15 19:57:10 --> Helper loaded: date_helper
INFO - 2016-02-15 19:57:10 --> Helper loaded: form_helper
INFO - 2016-02-15 19:57:10 --> Database Driver Class Initialized
INFO - 2016-02-15 19:57:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:57:11 --> Controller Class Initialized
INFO - 2016-02-15 19:57:11 --> Model Class Initialized
INFO - 2016-02-15 19:57:11 --> Model Class Initialized
INFO - 2016-02-15 19:57:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:57:11 --> Pagination Class Initialized
INFO - 2016-02-15 19:57:11 --> Helper loaded: text_helper
INFO - 2016-02-15 19:57:11 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:57:11 --> Final output sent to browser
DEBUG - 2016-02-15 22:57:11 --> Total execution time: 1.0829
INFO - 2016-02-15 19:57:12 --> Config Class Initialized
INFO - 2016-02-15 19:57:12 --> Hooks Class Initialized
DEBUG - 2016-02-15 19:57:12 --> UTF-8 Support Enabled
INFO - 2016-02-15 19:57:12 --> Utf8 Class Initialized
INFO - 2016-02-15 19:57:12 --> URI Class Initialized
INFO - 2016-02-15 19:57:12 --> Router Class Initialized
INFO - 2016-02-15 19:57:12 --> Output Class Initialized
INFO - 2016-02-15 19:57:12 --> Security Class Initialized
DEBUG - 2016-02-15 19:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-15 19:57:12 --> Input Class Initialized
INFO - 2016-02-15 19:57:12 --> Language Class Initialized
INFO - 2016-02-15 19:57:12 --> Loader Class Initialized
INFO - 2016-02-15 19:57:12 --> Helper loaded: url_helper
INFO - 2016-02-15 19:57:12 --> Helper loaded: file_helper
INFO - 2016-02-15 19:57:12 --> Helper loaded: date_helper
INFO - 2016-02-15 19:57:12 --> Helper loaded: form_helper
INFO - 2016-02-15 19:57:12 --> Database Driver Class Initialized
INFO - 2016-02-15 19:57:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-15 19:57:13 --> Controller Class Initialized
INFO - 2016-02-15 19:57:13 --> Model Class Initialized
INFO - 2016-02-15 19:57:13 --> Model Class Initialized
INFO - 2016-02-15 19:57:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-15 19:57:13 --> Pagination Class Initialized
INFO - 2016-02-15 19:57:13 --> Helper loaded: text_helper
INFO - 2016-02-15 19:57:13 --> Helper loaded: cookie_helper
INFO - 2016-02-15 22:57:13 --> Final output sent to browser
DEBUG - 2016-02-15 22:57:13 --> Total execution time: 1.0953
