<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-01 08:26:14 --> Config Class Initialized
INFO - 2016-02-01 08:26:14 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:26:14 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:26:14 --> Utf8 Class Initialized
INFO - 2016-02-01 08:26:14 --> URI Class Initialized
DEBUG - 2016-02-01 08:26:14 --> No URI present. Default controller set.
INFO - 2016-02-01 08:26:14 --> Router Class Initialized
INFO - 2016-02-01 08:26:14 --> Output Class Initialized
INFO - 2016-02-01 08:26:14 --> Security Class Initialized
DEBUG - 2016-02-01 08:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:26:14 --> Input Class Initialized
INFO - 2016-02-01 08:26:14 --> Language Class Initialized
INFO - 2016-02-01 08:26:14 --> Loader Class Initialized
INFO - 2016-02-01 08:26:14 --> Helper loaded: url_helper
INFO - 2016-02-01 08:26:14 --> Helper loaded: file_helper
INFO - 2016-02-01 08:26:14 --> Helper loaded: date_helper
INFO - 2016-02-01 08:26:14 --> Database Driver Class Initialized
INFO - 2016-02-01 08:26:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:26:15 --> Controller Class Initialized
INFO - 2016-02-01 08:26:15 --> Model Class Initialized
INFO - 2016-02-01 08:26:15 --> Model Class Initialized
INFO - 2016-02-01 08:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:26:15 --> Pagination Class Initialized
INFO - 2016-02-01 08:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:26:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:26:15 --> Final output sent to browser
DEBUG - 2016-02-01 08:26:15 --> Total execution time: 1.4465
INFO - 2016-02-01 08:26:17 --> Config Class Initialized
INFO - 2016-02-01 08:26:17 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:26:17 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:26:17 --> Utf8 Class Initialized
INFO - 2016-02-01 08:26:17 --> URI Class Initialized
INFO - 2016-02-01 08:26:17 --> Router Class Initialized
INFO - 2016-02-01 08:26:17 --> Output Class Initialized
INFO - 2016-02-01 08:26:17 --> Security Class Initialized
DEBUG - 2016-02-01 08:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:26:17 --> Input Class Initialized
INFO - 2016-02-01 08:26:17 --> Language Class Initialized
INFO - 2016-02-01 08:26:17 --> Loader Class Initialized
INFO - 2016-02-01 08:26:17 --> Helper loaded: url_helper
INFO - 2016-02-01 08:26:17 --> Helper loaded: file_helper
INFO - 2016-02-01 08:26:17 --> Helper loaded: date_helper
INFO - 2016-02-01 08:26:17 --> Database Driver Class Initialized
INFO - 2016-02-01 08:26:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:26:18 --> Controller Class Initialized
INFO - 2016-02-01 08:26:18 --> Model Class Initialized
INFO - 2016-02-01 08:26:18 --> Model Class Initialized
INFO - 2016-02-01 08:26:18 --> Helper loaded: form_helper
INFO - 2016-02-01 08:26:18 --> Form Validation Class Initialized
INFO - 2016-02-01 08:26:18 --> Helper loaded: text_helper
INFO - 2016-02-01 08:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-01 08:26:18 --> Final output sent to browser
DEBUG - 2016-02-01 08:26:18 --> Total execution time: 1.1953
INFO - 2016-02-01 08:26:38 --> Config Class Initialized
INFO - 2016-02-01 08:26:38 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:26:38 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:26:38 --> Utf8 Class Initialized
INFO - 2016-02-01 08:26:38 --> URI Class Initialized
DEBUG - 2016-02-01 08:26:38 --> No URI present. Default controller set.
INFO - 2016-02-01 08:26:38 --> Router Class Initialized
INFO - 2016-02-01 08:26:38 --> Output Class Initialized
INFO - 2016-02-01 08:26:38 --> Security Class Initialized
DEBUG - 2016-02-01 08:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:26:38 --> Input Class Initialized
INFO - 2016-02-01 08:26:38 --> Language Class Initialized
INFO - 2016-02-01 08:26:38 --> Loader Class Initialized
INFO - 2016-02-01 08:26:38 --> Helper loaded: url_helper
INFO - 2016-02-01 08:26:38 --> Helper loaded: file_helper
INFO - 2016-02-01 08:26:38 --> Helper loaded: date_helper
INFO - 2016-02-01 08:26:38 --> Database Driver Class Initialized
INFO - 2016-02-01 08:26:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:26:39 --> Controller Class Initialized
INFO - 2016-02-01 08:26:39 --> Model Class Initialized
INFO - 2016-02-01 08:26:39 --> Model Class Initialized
INFO - 2016-02-01 08:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:26:39 --> Pagination Class Initialized
INFO - 2016-02-01 08:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:26:39 --> Final output sent to browser
DEBUG - 2016-02-01 08:26:39 --> Total execution time: 1.0911
INFO - 2016-02-01 08:26:55 --> Config Class Initialized
INFO - 2016-02-01 08:26:55 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:26:55 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:26:55 --> Utf8 Class Initialized
INFO - 2016-02-01 08:26:55 --> URI Class Initialized
DEBUG - 2016-02-01 08:26:55 --> No URI present. Default controller set.
INFO - 2016-02-01 08:26:55 --> Router Class Initialized
INFO - 2016-02-01 08:26:55 --> Output Class Initialized
INFO - 2016-02-01 08:26:55 --> Security Class Initialized
DEBUG - 2016-02-01 08:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:26:55 --> Input Class Initialized
INFO - 2016-02-01 08:26:55 --> Language Class Initialized
INFO - 2016-02-01 08:26:55 --> Loader Class Initialized
INFO - 2016-02-01 08:26:55 --> Helper loaded: url_helper
INFO - 2016-02-01 08:26:55 --> Helper loaded: file_helper
INFO - 2016-02-01 08:26:55 --> Helper loaded: date_helper
INFO - 2016-02-01 08:26:55 --> Database Driver Class Initialized
INFO - 2016-02-01 08:26:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:26:56 --> Controller Class Initialized
INFO - 2016-02-01 08:26:56 --> Model Class Initialized
INFO - 2016-02-01 08:26:56 --> Model Class Initialized
INFO - 2016-02-01 08:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:26:56 --> Pagination Class Initialized
INFO - 2016-02-01 08:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:26:56 --> Final output sent to browser
DEBUG - 2016-02-01 08:26:56 --> Total execution time: 1.0830
INFO - 2016-02-01 08:27:39 --> Config Class Initialized
INFO - 2016-02-01 08:27:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:27:39 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:27:39 --> Utf8 Class Initialized
INFO - 2016-02-01 08:27:39 --> URI Class Initialized
DEBUG - 2016-02-01 08:27:39 --> No URI present. Default controller set.
INFO - 2016-02-01 08:27:39 --> Router Class Initialized
INFO - 2016-02-01 08:27:39 --> Output Class Initialized
INFO - 2016-02-01 08:27:39 --> Security Class Initialized
DEBUG - 2016-02-01 08:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:27:39 --> Input Class Initialized
INFO - 2016-02-01 08:27:39 --> Language Class Initialized
INFO - 2016-02-01 08:27:39 --> Loader Class Initialized
INFO - 2016-02-01 08:27:39 --> Helper loaded: url_helper
INFO - 2016-02-01 08:27:39 --> Helper loaded: file_helper
INFO - 2016-02-01 08:27:39 --> Helper loaded: date_helper
INFO - 2016-02-01 08:27:39 --> Database Driver Class Initialized
INFO - 2016-02-01 08:27:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:27:40 --> Controller Class Initialized
INFO - 2016-02-01 08:27:40 --> Model Class Initialized
INFO - 2016-02-01 08:27:40 --> Model Class Initialized
INFO - 2016-02-01 08:27:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:27:40 --> Pagination Class Initialized
INFO - 2016-02-01 08:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:27:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:27:40 --> Final output sent to browser
DEBUG - 2016-02-01 08:27:40 --> Total execution time: 1.0763
INFO - 2016-02-01 08:29:21 --> Config Class Initialized
INFO - 2016-02-01 08:29:21 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:29:21 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:29:21 --> Utf8 Class Initialized
INFO - 2016-02-01 08:29:21 --> URI Class Initialized
DEBUG - 2016-02-01 08:29:21 --> No URI present. Default controller set.
INFO - 2016-02-01 08:29:21 --> Router Class Initialized
INFO - 2016-02-01 08:29:21 --> Output Class Initialized
INFO - 2016-02-01 08:29:21 --> Security Class Initialized
DEBUG - 2016-02-01 08:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:29:21 --> Input Class Initialized
INFO - 2016-02-01 08:29:21 --> Language Class Initialized
INFO - 2016-02-01 08:29:21 --> Loader Class Initialized
INFO - 2016-02-01 08:29:21 --> Helper loaded: url_helper
INFO - 2016-02-01 08:29:21 --> Helper loaded: file_helper
INFO - 2016-02-01 08:29:21 --> Helper loaded: date_helper
INFO - 2016-02-01 08:29:21 --> Database Driver Class Initialized
INFO - 2016-02-01 08:29:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:29:22 --> Controller Class Initialized
INFO - 2016-02-01 08:29:22 --> Model Class Initialized
INFO - 2016-02-01 08:29:22 --> Model Class Initialized
INFO - 2016-02-01 08:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:29:22 --> Pagination Class Initialized
INFO - 2016-02-01 08:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:29:22 --> Final output sent to browser
DEBUG - 2016-02-01 08:29:22 --> Total execution time: 1.1006
INFO - 2016-02-01 08:29:39 --> Config Class Initialized
INFO - 2016-02-01 08:29:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:29:39 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:29:39 --> Utf8 Class Initialized
INFO - 2016-02-01 08:29:39 --> URI Class Initialized
DEBUG - 2016-02-01 08:29:39 --> No URI present. Default controller set.
INFO - 2016-02-01 08:29:39 --> Router Class Initialized
INFO - 2016-02-01 08:29:39 --> Output Class Initialized
INFO - 2016-02-01 08:29:39 --> Security Class Initialized
DEBUG - 2016-02-01 08:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:29:39 --> Input Class Initialized
INFO - 2016-02-01 08:29:39 --> Language Class Initialized
INFO - 2016-02-01 08:29:39 --> Loader Class Initialized
INFO - 2016-02-01 08:29:39 --> Helper loaded: url_helper
INFO - 2016-02-01 08:29:39 --> Helper loaded: file_helper
INFO - 2016-02-01 08:29:39 --> Helper loaded: date_helper
INFO - 2016-02-01 08:29:39 --> Database Driver Class Initialized
INFO - 2016-02-01 08:29:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:29:40 --> Controller Class Initialized
INFO - 2016-02-01 08:29:40 --> Model Class Initialized
INFO - 2016-02-01 08:29:40 --> Model Class Initialized
INFO - 2016-02-01 08:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:29:40 --> Pagination Class Initialized
INFO - 2016-02-01 08:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:29:40 --> Final output sent to browser
DEBUG - 2016-02-01 08:29:40 --> Total execution time: 1.0844
INFO - 2016-02-01 08:36:28 --> Config Class Initialized
INFO - 2016-02-01 08:36:28 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:36:28 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:36:28 --> Utf8 Class Initialized
INFO - 2016-02-01 08:36:28 --> URI Class Initialized
DEBUG - 2016-02-01 08:36:28 --> No URI present. Default controller set.
INFO - 2016-02-01 08:36:28 --> Router Class Initialized
INFO - 2016-02-01 08:36:28 --> Output Class Initialized
INFO - 2016-02-01 08:36:28 --> Security Class Initialized
DEBUG - 2016-02-01 08:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:36:28 --> Input Class Initialized
INFO - 2016-02-01 08:36:28 --> Language Class Initialized
INFO - 2016-02-01 08:36:28 --> Loader Class Initialized
INFO - 2016-02-01 08:36:28 --> Helper loaded: url_helper
INFO - 2016-02-01 08:36:28 --> Helper loaded: file_helper
INFO - 2016-02-01 08:36:28 --> Helper loaded: date_helper
INFO - 2016-02-01 08:36:28 --> Database Driver Class Initialized
INFO - 2016-02-01 08:36:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:36:29 --> Controller Class Initialized
INFO - 2016-02-01 08:36:29 --> Model Class Initialized
INFO - 2016-02-01 08:36:29 --> Model Class Initialized
INFO - 2016-02-01 08:36:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:36:29 --> Pagination Class Initialized
INFO - 2016-02-01 08:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:36:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:36:29 --> Final output sent to browser
DEBUG - 2016-02-01 08:36:29 --> Total execution time: 1.1167
INFO - 2016-02-01 08:36:32 --> Config Class Initialized
INFO - 2016-02-01 08:36:32 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:36:32 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:36:32 --> Utf8 Class Initialized
INFO - 2016-02-01 08:36:32 --> URI Class Initialized
INFO - 2016-02-01 08:36:32 --> Router Class Initialized
INFO - 2016-02-01 08:36:32 --> Output Class Initialized
INFO - 2016-02-01 08:36:32 --> Security Class Initialized
DEBUG - 2016-02-01 08:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:36:32 --> Input Class Initialized
INFO - 2016-02-01 08:36:32 --> Language Class Initialized
INFO - 2016-02-01 08:36:32 --> Loader Class Initialized
INFO - 2016-02-01 08:36:32 --> Helper loaded: url_helper
INFO - 2016-02-01 08:36:32 --> Helper loaded: file_helper
INFO - 2016-02-01 08:36:32 --> Helper loaded: date_helper
INFO - 2016-02-01 08:36:32 --> Database Driver Class Initialized
INFO - 2016-02-01 08:36:33 --> Config Class Initialized
INFO - 2016-02-01 08:36:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:36:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:36:33 --> Utf8 Class Initialized
INFO - 2016-02-01 08:36:33 --> URI Class Initialized
INFO - 2016-02-01 08:36:33 --> Router Class Initialized
INFO - 2016-02-01 08:36:33 --> Output Class Initialized
INFO - 2016-02-01 08:36:33 --> Security Class Initialized
DEBUG - 2016-02-01 08:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:36:33 --> Input Class Initialized
INFO - 2016-02-01 08:36:33 --> Language Class Initialized
INFO - 2016-02-01 08:36:33 --> Loader Class Initialized
INFO - 2016-02-01 08:36:33 --> Helper loaded: url_helper
INFO - 2016-02-01 08:36:33 --> Helper loaded: file_helper
INFO - 2016-02-01 08:36:33 --> Helper loaded: date_helper
INFO - 2016-02-01 08:36:33 --> Database Driver Class Initialized
INFO - 2016-02-01 08:36:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:36:33 --> Controller Class Initialized
INFO - 2016-02-01 08:36:33 --> Model Class Initialized
INFO - 2016-02-01 08:36:33 --> Model Class Initialized
INFO - 2016-02-01 08:36:33 --> Helper loaded: form_helper
INFO - 2016-02-01 08:36:33 --> Form Validation Class Initialized
INFO - 2016-02-01 08:36:33 --> Helper loaded: text_helper
INFO - 2016-02-01 08:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:36:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-01 08:36:34 --> Model Class Initialized
INFO - 2016-02-01 08:36:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 08:36:34 --> Final output sent to browser
DEBUG - 2016-02-01 08:36:34 --> Total execution time: 1.1252
INFO - 2016-02-01 08:36:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:36:34 --> Controller Class Initialized
INFO - 2016-02-01 08:36:34 --> Model Class Initialized
INFO - 2016-02-01 08:36:34 --> Model Class Initialized
INFO - 2016-02-01 08:36:34 --> Helper loaded: form_helper
INFO - 2016-02-01 08:36:34 --> Form Validation Class Initialized
INFO - 2016-02-01 08:36:34 --> Helper loaded: text_helper
INFO - 2016-02-01 08:36:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:36:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-01 08:36:34 --> Model Class Initialized
INFO - 2016-02-01 08:36:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 08:36:34 --> Final output sent to browser
DEBUG - 2016-02-01 08:36:34 --> Total execution time: 1.0761
INFO - 2016-02-01 08:36:35 --> Config Class Initialized
INFO - 2016-02-01 08:36:35 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:36:35 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:36:35 --> Utf8 Class Initialized
INFO - 2016-02-01 08:36:35 --> URI Class Initialized
DEBUG - 2016-02-01 08:36:35 --> No URI present. Default controller set.
INFO - 2016-02-01 08:36:35 --> Router Class Initialized
INFO - 2016-02-01 08:36:35 --> Output Class Initialized
INFO - 2016-02-01 08:36:35 --> Security Class Initialized
DEBUG - 2016-02-01 08:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:36:35 --> Input Class Initialized
INFO - 2016-02-01 08:36:35 --> Language Class Initialized
INFO - 2016-02-01 08:36:35 --> Loader Class Initialized
INFO - 2016-02-01 08:36:35 --> Helper loaded: url_helper
INFO - 2016-02-01 08:36:35 --> Helper loaded: file_helper
INFO - 2016-02-01 08:36:35 --> Helper loaded: date_helper
INFO - 2016-02-01 08:36:35 --> Database Driver Class Initialized
INFO - 2016-02-01 08:36:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:36:36 --> Controller Class Initialized
INFO - 2016-02-01 08:36:36 --> Model Class Initialized
INFO - 2016-02-01 08:36:36 --> Model Class Initialized
INFO - 2016-02-01 08:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:36:36 --> Pagination Class Initialized
INFO - 2016-02-01 08:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:36:36 --> Final output sent to browser
DEBUG - 2016-02-01 08:36:36 --> Total execution time: 1.1263
INFO - 2016-02-01 08:36:49 --> Config Class Initialized
INFO - 2016-02-01 08:36:49 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:36:49 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:36:49 --> Utf8 Class Initialized
INFO - 2016-02-01 08:36:49 --> URI Class Initialized
DEBUG - 2016-02-01 08:36:49 --> No URI present. Default controller set.
INFO - 2016-02-01 08:36:49 --> Router Class Initialized
INFO - 2016-02-01 08:36:49 --> Output Class Initialized
INFO - 2016-02-01 08:36:49 --> Security Class Initialized
DEBUG - 2016-02-01 08:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:36:49 --> Input Class Initialized
INFO - 2016-02-01 08:36:49 --> Language Class Initialized
INFO - 2016-02-01 08:36:49 --> Loader Class Initialized
INFO - 2016-02-01 08:36:49 --> Helper loaded: url_helper
INFO - 2016-02-01 08:36:49 --> Helper loaded: file_helper
INFO - 2016-02-01 08:36:49 --> Helper loaded: date_helper
INFO - 2016-02-01 08:36:49 --> Database Driver Class Initialized
INFO - 2016-02-01 08:36:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:36:50 --> Controller Class Initialized
INFO - 2016-02-01 08:36:50 --> Model Class Initialized
INFO - 2016-02-01 08:36:50 --> Model Class Initialized
INFO - 2016-02-01 08:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:36:50 --> Pagination Class Initialized
INFO - 2016-02-01 08:36:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:36:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:36:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:36:50 --> Final output sent to browser
DEBUG - 2016-02-01 08:36:50 --> Total execution time: 1.0812
INFO - 2016-02-01 08:37:22 --> Config Class Initialized
INFO - 2016-02-01 08:37:22 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:37:22 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:37:22 --> Utf8 Class Initialized
INFO - 2016-02-01 08:37:22 --> URI Class Initialized
DEBUG - 2016-02-01 08:37:22 --> No URI present. Default controller set.
INFO - 2016-02-01 08:37:22 --> Router Class Initialized
INFO - 2016-02-01 08:37:22 --> Output Class Initialized
INFO - 2016-02-01 08:37:22 --> Security Class Initialized
DEBUG - 2016-02-01 08:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:37:22 --> Input Class Initialized
INFO - 2016-02-01 08:37:22 --> Language Class Initialized
INFO - 2016-02-01 08:37:22 --> Loader Class Initialized
INFO - 2016-02-01 08:37:22 --> Helper loaded: url_helper
INFO - 2016-02-01 08:37:22 --> Helper loaded: file_helper
INFO - 2016-02-01 08:37:22 --> Helper loaded: date_helper
INFO - 2016-02-01 08:37:22 --> Database Driver Class Initialized
INFO - 2016-02-01 08:37:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:37:23 --> Controller Class Initialized
INFO - 2016-02-01 08:37:23 --> Model Class Initialized
INFO - 2016-02-01 08:37:23 --> Model Class Initialized
INFO - 2016-02-01 08:37:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:37:23 --> Pagination Class Initialized
INFO - 2016-02-01 08:37:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:37:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:37:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:37:23 --> Final output sent to browser
DEBUG - 2016-02-01 08:37:23 --> Total execution time: 1.1313
INFO - 2016-02-01 08:38:29 --> Config Class Initialized
INFO - 2016-02-01 08:38:29 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:38:29 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:38:29 --> Utf8 Class Initialized
INFO - 2016-02-01 08:38:29 --> URI Class Initialized
DEBUG - 2016-02-01 08:38:29 --> No URI present. Default controller set.
INFO - 2016-02-01 08:38:29 --> Router Class Initialized
INFO - 2016-02-01 08:38:29 --> Output Class Initialized
INFO - 2016-02-01 08:38:29 --> Security Class Initialized
DEBUG - 2016-02-01 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:38:29 --> Input Class Initialized
INFO - 2016-02-01 08:38:29 --> Language Class Initialized
INFO - 2016-02-01 08:38:29 --> Loader Class Initialized
INFO - 2016-02-01 08:38:29 --> Helper loaded: url_helper
INFO - 2016-02-01 08:38:29 --> Helper loaded: file_helper
INFO - 2016-02-01 08:38:29 --> Helper loaded: date_helper
INFO - 2016-02-01 08:38:29 --> Database Driver Class Initialized
INFO - 2016-02-01 08:38:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:38:30 --> Controller Class Initialized
INFO - 2016-02-01 08:38:30 --> Model Class Initialized
INFO - 2016-02-01 08:38:30 --> Model Class Initialized
INFO - 2016-02-01 08:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:38:30 --> Pagination Class Initialized
INFO - 2016-02-01 08:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:38:30 --> Final output sent to browser
DEBUG - 2016-02-01 08:38:30 --> Total execution time: 1.0965
INFO - 2016-02-01 08:38:39 --> Config Class Initialized
INFO - 2016-02-01 08:38:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:38:40 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:38:40 --> Utf8 Class Initialized
INFO - 2016-02-01 08:38:40 --> URI Class Initialized
DEBUG - 2016-02-01 08:38:40 --> No URI present. Default controller set.
INFO - 2016-02-01 08:38:40 --> Router Class Initialized
INFO - 2016-02-01 08:38:40 --> Output Class Initialized
INFO - 2016-02-01 08:38:40 --> Security Class Initialized
DEBUG - 2016-02-01 08:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:38:40 --> Input Class Initialized
INFO - 2016-02-01 08:38:40 --> Language Class Initialized
INFO - 2016-02-01 08:38:40 --> Loader Class Initialized
INFO - 2016-02-01 08:38:40 --> Helper loaded: url_helper
INFO - 2016-02-01 08:38:40 --> Helper loaded: file_helper
INFO - 2016-02-01 08:38:40 --> Helper loaded: date_helper
INFO - 2016-02-01 08:38:40 --> Database Driver Class Initialized
INFO - 2016-02-01 08:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:38:41 --> Controller Class Initialized
INFO - 2016-02-01 08:38:41 --> Model Class Initialized
INFO - 2016-02-01 08:38:41 --> Model Class Initialized
INFO - 2016-02-01 08:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:38:41 --> Pagination Class Initialized
INFO - 2016-02-01 08:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:38:41 --> Final output sent to browser
DEBUG - 2016-02-01 08:38:41 --> Total execution time: 1.1002
INFO - 2016-02-01 08:40:37 --> Config Class Initialized
INFO - 2016-02-01 08:40:37 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:40:37 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:40:37 --> Utf8 Class Initialized
INFO - 2016-02-01 08:40:37 --> URI Class Initialized
INFO - 2016-02-01 08:40:37 --> Router Class Initialized
INFO - 2016-02-01 08:40:37 --> Output Class Initialized
INFO - 2016-02-01 08:40:37 --> Security Class Initialized
DEBUG - 2016-02-01 08:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:40:37 --> Input Class Initialized
INFO - 2016-02-01 08:40:37 --> Language Class Initialized
INFO - 2016-02-01 08:40:37 --> Loader Class Initialized
INFO - 2016-02-01 08:40:37 --> Helper loaded: url_helper
INFO - 2016-02-01 08:40:37 --> Helper loaded: file_helper
INFO - 2016-02-01 08:40:37 --> Helper loaded: date_helper
INFO - 2016-02-01 08:40:37 --> Database Driver Class Initialized
INFO - 2016-02-01 08:40:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:40:38 --> Controller Class Initialized
INFO - 2016-02-01 08:40:38 --> Model Class Initialized
INFO - 2016-02-01 08:40:38 --> Model Class Initialized
INFO - 2016-02-01 08:40:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:40:38 --> Pagination Class Initialized
INFO - 2016-02-01 08:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:40:38 --> Helper loaded: text_helper
INFO - 2016-02-01 08:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 08:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 08:40:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:40:38 --> Final output sent to browser
DEBUG - 2016-02-01 08:40:38 --> Total execution time: 1.1380
INFO - 2016-02-01 08:40:45 --> Config Class Initialized
INFO - 2016-02-01 08:40:45 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:40:45 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:40:45 --> Utf8 Class Initialized
INFO - 2016-02-01 08:40:45 --> URI Class Initialized
INFO - 2016-02-01 08:40:45 --> Router Class Initialized
INFO - 2016-02-01 08:40:45 --> Output Class Initialized
INFO - 2016-02-01 08:40:45 --> Security Class Initialized
DEBUG - 2016-02-01 08:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:40:45 --> Input Class Initialized
INFO - 2016-02-01 08:40:45 --> Language Class Initialized
INFO - 2016-02-01 08:40:45 --> Loader Class Initialized
INFO - 2016-02-01 08:40:45 --> Helper loaded: url_helper
INFO - 2016-02-01 08:40:45 --> Helper loaded: file_helper
INFO - 2016-02-01 08:40:45 --> Helper loaded: date_helper
INFO - 2016-02-01 08:40:45 --> Database Driver Class Initialized
INFO - 2016-02-01 08:40:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:40:47 --> Controller Class Initialized
INFO - 2016-02-01 08:40:47 --> Model Class Initialized
INFO - 2016-02-01 08:40:47 --> Model Class Initialized
INFO - 2016-02-01 08:40:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:40:47 --> Pagination Class Initialized
INFO - 2016-02-01 08:40:47 --> Config Class Initialized
INFO - 2016-02-01 08:40:47 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:40:47 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:40:47 --> Utf8 Class Initialized
INFO - 2016-02-01 08:40:47 --> URI Class Initialized
INFO - 2016-02-01 08:40:47 --> Router Class Initialized
INFO - 2016-02-01 08:40:47 --> Output Class Initialized
INFO - 2016-02-01 08:40:47 --> Security Class Initialized
DEBUG - 2016-02-01 08:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:40:47 --> Input Class Initialized
INFO - 2016-02-01 08:40:47 --> Language Class Initialized
INFO - 2016-02-01 08:40:47 --> Loader Class Initialized
INFO - 2016-02-01 08:40:47 --> Helper loaded: url_helper
INFO - 2016-02-01 08:40:47 --> Helper loaded: file_helper
INFO - 2016-02-01 08:40:47 --> Helper loaded: date_helper
INFO - 2016-02-01 08:40:47 --> Database Driver Class Initialized
INFO - 2016-02-01 08:40:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:40:48 --> Controller Class Initialized
INFO - 2016-02-01 08:40:48 --> Model Class Initialized
INFO - 2016-02-01 08:40:48 --> Model Class Initialized
INFO - 2016-02-01 08:40:48 --> Helper loaded: form_helper
INFO - 2016-02-01 08:40:48 --> Form Validation Class Initialized
INFO - 2016-02-01 08:40:48 --> Helper loaded: text_helper
INFO - 2016-02-01 08:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:40:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-01 08:40:48 --> Final output sent to browser
DEBUG - 2016-02-01 08:40:48 --> Total execution time: 1.0947
INFO - 2016-02-01 08:40:49 --> Config Class Initialized
INFO - 2016-02-01 08:40:49 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:40:49 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:40:49 --> Utf8 Class Initialized
INFO - 2016-02-01 08:40:49 --> URI Class Initialized
DEBUG - 2016-02-01 08:40:49 --> No URI present. Default controller set.
INFO - 2016-02-01 08:40:49 --> Router Class Initialized
INFO - 2016-02-01 08:40:49 --> Output Class Initialized
INFO - 2016-02-01 08:40:49 --> Security Class Initialized
DEBUG - 2016-02-01 08:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:40:49 --> Input Class Initialized
INFO - 2016-02-01 08:40:49 --> Language Class Initialized
INFO - 2016-02-01 08:40:49 --> Loader Class Initialized
INFO - 2016-02-01 08:40:49 --> Helper loaded: url_helper
INFO - 2016-02-01 08:40:49 --> Helper loaded: file_helper
INFO - 2016-02-01 08:40:49 --> Helper loaded: date_helper
INFO - 2016-02-01 08:40:49 --> Database Driver Class Initialized
INFO - 2016-02-01 08:40:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:40:50 --> Controller Class Initialized
INFO - 2016-02-01 08:40:50 --> Model Class Initialized
INFO - 2016-02-01 08:40:50 --> Model Class Initialized
INFO - 2016-02-01 08:40:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:40:50 --> Pagination Class Initialized
INFO - 2016-02-01 08:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 08:40:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:40:50 --> Final output sent to browser
DEBUG - 2016-02-01 08:40:50 --> Total execution time: 1.0984
INFO - 2016-02-01 08:40:52 --> Config Class Initialized
INFO - 2016-02-01 08:40:52 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:40:52 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:40:52 --> Utf8 Class Initialized
INFO - 2016-02-01 08:40:52 --> URI Class Initialized
INFO - 2016-02-01 08:40:52 --> Router Class Initialized
INFO - 2016-02-01 08:40:52 --> Output Class Initialized
INFO - 2016-02-01 08:40:52 --> Security Class Initialized
DEBUG - 2016-02-01 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:40:52 --> Input Class Initialized
INFO - 2016-02-01 08:40:52 --> Language Class Initialized
INFO - 2016-02-01 08:40:52 --> Loader Class Initialized
INFO - 2016-02-01 08:40:52 --> Helper loaded: url_helper
INFO - 2016-02-01 08:40:52 --> Helper loaded: file_helper
INFO - 2016-02-01 08:40:52 --> Helper loaded: date_helper
INFO - 2016-02-01 08:40:52 --> Database Driver Class Initialized
INFO - 2016-02-01 08:40:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:40:53 --> Controller Class Initialized
INFO - 2016-02-01 08:40:53 --> Model Class Initialized
INFO - 2016-02-01 08:40:53 --> Model Class Initialized
INFO - 2016-02-01 08:40:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:40:53 --> Pagination Class Initialized
INFO - 2016-02-01 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:40:53 --> Helper loaded: text_helper
INFO - 2016-02-01 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 08:40:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:40:53 --> Final output sent to browser
DEBUG - 2016-02-01 08:40:53 --> Total execution time: 1.1423
INFO - 2016-02-01 08:58:02 --> Config Class Initialized
INFO - 2016-02-01 08:58:02 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:58:02 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:58:02 --> Utf8 Class Initialized
INFO - 2016-02-01 08:58:02 --> URI Class Initialized
INFO - 2016-02-01 08:58:02 --> Router Class Initialized
INFO - 2016-02-01 08:58:02 --> Output Class Initialized
INFO - 2016-02-01 08:58:02 --> Security Class Initialized
DEBUG - 2016-02-01 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:58:02 --> Input Class Initialized
INFO - 2016-02-01 08:58:02 --> Language Class Initialized
INFO - 2016-02-01 08:58:02 --> Loader Class Initialized
INFO - 2016-02-01 08:58:02 --> Helper loaded: url_helper
INFO - 2016-02-01 08:58:02 --> Helper loaded: file_helper
INFO - 2016-02-01 08:58:02 --> Helper loaded: date_helper
INFO - 2016-02-01 08:58:02 --> Database Driver Class Initialized
INFO - 2016-02-01 08:58:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:58:03 --> Controller Class Initialized
INFO - 2016-02-01 08:58:03 --> Model Class Initialized
INFO - 2016-02-01 08:58:03 --> Model Class Initialized
INFO - 2016-02-01 08:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:58:03 --> Pagination Class Initialized
INFO - 2016-02-01 08:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:58:03 --> Helper loaded: text_helper
INFO - 2016-02-01 08:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 08:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 08:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:58:03 --> Final output sent to browser
DEBUG - 2016-02-01 08:58:03 --> Total execution time: 1.1679
INFO - 2016-02-01 08:58:40 --> Config Class Initialized
INFO - 2016-02-01 08:58:40 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:58:40 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:58:40 --> Utf8 Class Initialized
INFO - 2016-02-01 08:58:40 --> URI Class Initialized
INFO - 2016-02-01 08:58:40 --> Router Class Initialized
INFO - 2016-02-01 08:58:40 --> Output Class Initialized
INFO - 2016-02-01 08:58:40 --> Security Class Initialized
DEBUG - 2016-02-01 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:58:40 --> Input Class Initialized
INFO - 2016-02-01 08:58:40 --> Language Class Initialized
INFO - 2016-02-01 08:58:40 --> Loader Class Initialized
INFO - 2016-02-01 08:58:40 --> Helper loaded: url_helper
INFO - 2016-02-01 08:58:41 --> Helper loaded: file_helper
INFO - 2016-02-01 08:58:41 --> Helper loaded: date_helper
INFO - 2016-02-01 08:58:41 --> Database Driver Class Initialized
INFO - 2016-02-01 08:58:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:58:42 --> Controller Class Initialized
INFO - 2016-02-01 08:58:42 --> Model Class Initialized
INFO - 2016-02-01 08:58:42 --> Model Class Initialized
INFO - 2016-02-01 08:58:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:58:42 --> Pagination Class Initialized
INFO - 2016-02-01 08:58:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:58:42 --> Helper loaded: text_helper
INFO - 2016-02-01 08:58:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 08:58:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 08:58:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:58:42 --> Final output sent to browser
DEBUG - 2016-02-01 08:58:42 --> Total execution time: 1.1455
INFO - 2016-02-01 08:59:48 --> Config Class Initialized
INFO - 2016-02-01 08:59:48 --> Hooks Class Initialized
DEBUG - 2016-02-01 08:59:48 --> UTF-8 Support Enabled
INFO - 2016-02-01 08:59:48 --> Utf8 Class Initialized
INFO - 2016-02-01 08:59:48 --> URI Class Initialized
INFO - 2016-02-01 08:59:48 --> Router Class Initialized
INFO - 2016-02-01 08:59:48 --> Output Class Initialized
INFO - 2016-02-01 08:59:48 --> Security Class Initialized
DEBUG - 2016-02-01 08:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 08:59:48 --> Input Class Initialized
INFO - 2016-02-01 08:59:48 --> Language Class Initialized
INFO - 2016-02-01 08:59:48 --> Loader Class Initialized
INFO - 2016-02-01 08:59:48 --> Helper loaded: url_helper
INFO - 2016-02-01 08:59:48 --> Helper loaded: file_helper
INFO - 2016-02-01 08:59:48 --> Helper loaded: date_helper
INFO - 2016-02-01 08:59:48 --> Database Driver Class Initialized
INFO - 2016-02-01 08:59:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 08:59:49 --> Controller Class Initialized
INFO - 2016-02-01 08:59:49 --> Model Class Initialized
INFO - 2016-02-01 08:59:49 --> Model Class Initialized
INFO - 2016-02-01 08:59:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 08:59:49 --> Pagination Class Initialized
INFO - 2016-02-01 08:59:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 08:59:49 --> Helper loaded: text_helper
INFO - 2016-02-01 08:59:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 08:59:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 08:59:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 08:59:49 --> Final output sent to browser
DEBUG - 2016-02-01 08:59:49 --> Total execution time: 1.1494
INFO - 2016-02-01 09:00:16 --> Config Class Initialized
INFO - 2016-02-01 09:00:16 --> Hooks Class Initialized
DEBUG - 2016-02-01 09:00:16 --> UTF-8 Support Enabled
INFO - 2016-02-01 09:00:16 --> Utf8 Class Initialized
INFO - 2016-02-01 09:00:16 --> URI Class Initialized
INFO - 2016-02-01 09:00:16 --> Router Class Initialized
INFO - 2016-02-01 09:00:16 --> Output Class Initialized
INFO - 2016-02-01 09:00:16 --> Security Class Initialized
DEBUG - 2016-02-01 09:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 09:00:16 --> Input Class Initialized
INFO - 2016-02-01 09:00:16 --> Language Class Initialized
INFO - 2016-02-01 09:00:16 --> Loader Class Initialized
INFO - 2016-02-01 09:00:16 --> Helper loaded: url_helper
INFO - 2016-02-01 09:00:16 --> Helper loaded: file_helper
INFO - 2016-02-01 09:00:16 --> Helper loaded: date_helper
INFO - 2016-02-01 09:00:16 --> Database Driver Class Initialized
INFO - 2016-02-01 09:00:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 09:00:17 --> Controller Class Initialized
INFO - 2016-02-01 09:00:17 --> Model Class Initialized
INFO - 2016-02-01 09:00:17 --> Model Class Initialized
INFO - 2016-02-01 09:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 09:00:17 --> Pagination Class Initialized
INFO - 2016-02-01 09:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 09:00:17 --> Helper loaded: text_helper
INFO - 2016-02-01 09:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 09:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 09:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 09:00:17 --> Final output sent to browser
DEBUG - 2016-02-01 09:00:17 --> Total execution time: 1.1303
INFO - 2016-02-01 09:00:37 --> Config Class Initialized
INFO - 2016-02-01 09:00:37 --> Hooks Class Initialized
DEBUG - 2016-02-01 09:00:37 --> UTF-8 Support Enabled
INFO - 2016-02-01 09:00:37 --> Utf8 Class Initialized
INFO - 2016-02-01 09:00:37 --> URI Class Initialized
INFO - 2016-02-01 09:00:37 --> Router Class Initialized
INFO - 2016-02-01 09:00:37 --> Output Class Initialized
INFO - 2016-02-01 09:00:37 --> Security Class Initialized
DEBUG - 2016-02-01 09:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 09:00:37 --> Input Class Initialized
INFO - 2016-02-01 09:00:37 --> Language Class Initialized
INFO - 2016-02-01 09:00:37 --> Loader Class Initialized
INFO - 2016-02-01 09:00:37 --> Helper loaded: url_helper
INFO - 2016-02-01 09:00:37 --> Helper loaded: file_helper
INFO - 2016-02-01 09:00:37 --> Helper loaded: date_helper
INFO - 2016-02-01 09:00:37 --> Database Driver Class Initialized
INFO - 2016-02-01 09:00:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 09:00:38 --> Controller Class Initialized
INFO - 2016-02-01 09:00:38 --> Model Class Initialized
INFO - 2016-02-01 09:00:38 --> Model Class Initialized
INFO - 2016-02-01 09:00:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 09:00:38 --> Pagination Class Initialized
INFO - 2016-02-01 09:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 09:00:38 --> Helper loaded: text_helper
INFO - 2016-02-01 09:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 09:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 09:00:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 09:00:38 --> Final output sent to browser
DEBUG - 2016-02-01 09:00:38 --> Total execution time: 1.1543
INFO - 2016-02-01 09:00:43 --> Config Class Initialized
INFO - 2016-02-01 09:00:43 --> Hooks Class Initialized
DEBUG - 2016-02-01 09:00:43 --> UTF-8 Support Enabled
INFO - 2016-02-01 09:00:43 --> Utf8 Class Initialized
INFO - 2016-02-01 09:00:43 --> URI Class Initialized
INFO - 2016-02-01 09:00:43 --> Router Class Initialized
INFO - 2016-02-01 09:00:43 --> Output Class Initialized
INFO - 2016-02-01 09:00:43 --> Security Class Initialized
DEBUG - 2016-02-01 09:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 09:00:43 --> Input Class Initialized
INFO - 2016-02-01 09:00:43 --> Language Class Initialized
INFO - 2016-02-01 09:00:43 --> Loader Class Initialized
INFO - 2016-02-01 09:00:43 --> Helper loaded: url_helper
INFO - 2016-02-01 09:00:43 --> Helper loaded: file_helper
INFO - 2016-02-01 09:00:43 --> Helper loaded: date_helper
INFO - 2016-02-01 09:00:43 --> Database Driver Class Initialized
INFO - 2016-02-01 09:00:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 09:00:44 --> Controller Class Initialized
INFO - 2016-02-01 09:00:44 --> Model Class Initialized
INFO - 2016-02-01 09:00:44 --> Model Class Initialized
INFO - 2016-02-01 09:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 09:00:44 --> Pagination Class Initialized
INFO - 2016-02-01 09:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 09:00:44 --> Helper loaded: text_helper
INFO - 2016-02-01 09:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 09:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 09:00:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 09:00:44 --> Final output sent to browser
DEBUG - 2016-02-01 09:00:44 --> Total execution time: 1.1459
INFO - 2016-02-01 09:08:11 --> Config Class Initialized
INFO - 2016-02-01 09:08:11 --> Hooks Class Initialized
DEBUG - 2016-02-01 09:08:11 --> UTF-8 Support Enabled
INFO - 2016-02-01 09:08:11 --> Utf8 Class Initialized
INFO - 2016-02-01 09:08:11 --> URI Class Initialized
INFO - 2016-02-01 09:08:11 --> Router Class Initialized
INFO - 2016-02-01 09:08:11 --> Output Class Initialized
INFO - 2016-02-01 09:08:11 --> Security Class Initialized
DEBUG - 2016-02-01 09:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 09:08:11 --> Input Class Initialized
INFO - 2016-02-01 09:08:11 --> Language Class Initialized
INFO - 2016-02-01 09:08:11 --> Loader Class Initialized
INFO - 2016-02-01 09:08:11 --> Helper loaded: url_helper
INFO - 2016-02-01 09:08:11 --> Helper loaded: file_helper
INFO - 2016-02-01 09:08:11 --> Helper loaded: date_helper
INFO - 2016-02-01 09:08:11 --> Database Driver Class Initialized
INFO - 2016-02-01 09:08:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 09:08:12 --> Controller Class Initialized
INFO - 2016-02-01 09:08:12 --> Model Class Initialized
INFO - 2016-02-01 09:08:12 --> Model Class Initialized
INFO - 2016-02-01 09:08:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 09:08:12 --> Pagination Class Initialized
INFO - 2016-02-01 09:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 09:08:12 --> Helper loaded: text_helper
INFO - 2016-02-01 09:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 09:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 09:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 09:08:12 --> Final output sent to browser
DEBUG - 2016-02-01 09:08:12 --> Total execution time: 1.1514
INFO - 2016-02-01 09:12:26 --> Config Class Initialized
INFO - 2016-02-01 09:12:26 --> Hooks Class Initialized
DEBUG - 2016-02-01 09:12:26 --> UTF-8 Support Enabled
INFO - 2016-02-01 09:12:26 --> Utf8 Class Initialized
INFO - 2016-02-01 09:12:26 --> URI Class Initialized
INFO - 2016-02-01 09:12:26 --> Router Class Initialized
INFO - 2016-02-01 09:12:26 --> Output Class Initialized
INFO - 2016-02-01 09:12:26 --> Security Class Initialized
DEBUG - 2016-02-01 09:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 09:12:26 --> Input Class Initialized
INFO - 2016-02-01 09:12:26 --> Language Class Initialized
INFO - 2016-02-01 09:12:26 --> Loader Class Initialized
INFO - 2016-02-01 09:12:26 --> Helper loaded: url_helper
INFO - 2016-02-01 09:12:26 --> Helper loaded: file_helper
INFO - 2016-02-01 09:12:26 --> Helper loaded: date_helper
INFO - 2016-02-01 09:12:26 --> Database Driver Class Initialized
INFO - 2016-02-01 09:12:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 09:12:27 --> Controller Class Initialized
INFO - 2016-02-01 09:12:27 --> Model Class Initialized
INFO - 2016-02-01 09:12:27 --> Model Class Initialized
INFO - 2016-02-01 09:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 09:12:27 --> Pagination Class Initialized
INFO - 2016-02-01 09:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 09:12:27 --> Helper loaded: text_helper
INFO - 2016-02-01 09:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 09:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 09:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 09:12:27 --> Final output sent to browser
DEBUG - 2016-02-01 09:12:27 --> Total execution time: 1.1553
INFO - 2016-02-01 09:17:03 --> Config Class Initialized
INFO - 2016-02-01 09:17:03 --> Hooks Class Initialized
DEBUG - 2016-02-01 09:17:03 --> UTF-8 Support Enabled
INFO - 2016-02-01 09:17:03 --> Utf8 Class Initialized
INFO - 2016-02-01 09:17:03 --> URI Class Initialized
INFO - 2016-02-01 09:17:03 --> Router Class Initialized
INFO - 2016-02-01 09:17:03 --> Output Class Initialized
INFO - 2016-02-01 09:17:03 --> Security Class Initialized
DEBUG - 2016-02-01 09:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 09:17:03 --> Input Class Initialized
INFO - 2016-02-01 09:17:03 --> Language Class Initialized
INFO - 2016-02-01 09:17:03 --> Loader Class Initialized
INFO - 2016-02-01 09:17:03 --> Helper loaded: url_helper
INFO - 2016-02-01 09:17:03 --> Helper loaded: file_helper
INFO - 2016-02-01 09:17:03 --> Helper loaded: date_helper
INFO - 2016-02-01 09:17:03 --> Database Driver Class Initialized
INFO - 2016-02-01 09:17:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 09:17:04 --> Controller Class Initialized
INFO - 2016-02-01 09:17:04 --> Model Class Initialized
INFO - 2016-02-01 09:17:04 --> Model Class Initialized
INFO - 2016-02-01 09:17:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 09:17:04 --> Pagination Class Initialized
INFO - 2016-02-01 09:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 09:17:04 --> Helper loaded: text_helper
INFO - 2016-02-01 09:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 09:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 09:17:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 09:17:04 --> Final output sent to browser
DEBUG - 2016-02-01 09:17:04 --> Total execution time: 1.1467
INFO - 2016-02-01 09:17:33 --> Config Class Initialized
INFO - 2016-02-01 09:17:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 09:17:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 09:17:33 --> Utf8 Class Initialized
INFO - 2016-02-01 09:17:33 --> URI Class Initialized
INFO - 2016-02-01 09:17:33 --> Router Class Initialized
INFO - 2016-02-01 09:17:33 --> Output Class Initialized
INFO - 2016-02-01 09:17:33 --> Security Class Initialized
DEBUG - 2016-02-01 09:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 09:17:33 --> Input Class Initialized
INFO - 2016-02-01 09:17:33 --> Language Class Initialized
INFO - 2016-02-01 09:17:33 --> Loader Class Initialized
INFO - 2016-02-01 09:17:33 --> Helper loaded: url_helper
INFO - 2016-02-01 09:17:33 --> Helper loaded: file_helper
INFO - 2016-02-01 09:17:33 --> Helper loaded: date_helper
INFO - 2016-02-01 09:17:33 --> Database Driver Class Initialized
INFO - 2016-02-01 09:17:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 09:17:34 --> Controller Class Initialized
INFO - 2016-02-01 09:17:34 --> Model Class Initialized
INFO - 2016-02-01 09:17:34 --> Model Class Initialized
INFO - 2016-02-01 09:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 09:17:34 --> Pagination Class Initialized
INFO - 2016-02-01 09:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 09:17:34 --> Helper loaded: text_helper
INFO - 2016-02-01 09:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 09:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 09:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 09:17:34 --> Final output sent to browser
DEBUG - 2016-02-01 09:17:34 --> Total execution time: 1.1452
INFO - 2016-02-01 09:59:44 --> Config Class Initialized
INFO - 2016-02-01 09:59:44 --> Hooks Class Initialized
DEBUG - 2016-02-01 09:59:44 --> UTF-8 Support Enabled
INFO - 2016-02-01 09:59:44 --> Utf8 Class Initialized
INFO - 2016-02-01 09:59:44 --> URI Class Initialized
DEBUG - 2016-02-01 09:59:44 --> No URI present. Default controller set.
INFO - 2016-02-01 09:59:44 --> Router Class Initialized
INFO - 2016-02-01 09:59:44 --> Output Class Initialized
INFO - 2016-02-01 09:59:44 --> Security Class Initialized
DEBUG - 2016-02-01 09:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 09:59:44 --> Input Class Initialized
INFO - 2016-02-01 09:59:44 --> Language Class Initialized
INFO - 2016-02-01 09:59:44 --> Loader Class Initialized
INFO - 2016-02-01 09:59:44 --> Helper loaded: url_helper
INFO - 2016-02-01 09:59:44 --> Helper loaded: file_helper
INFO - 2016-02-01 09:59:44 --> Helper loaded: date_helper
INFO - 2016-02-01 09:59:44 --> Database Driver Class Initialized
INFO - 2016-02-01 09:59:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 09:59:45 --> Controller Class Initialized
INFO - 2016-02-01 09:59:45 --> Model Class Initialized
INFO - 2016-02-01 09:59:45 --> Model Class Initialized
INFO - 2016-02-01 09:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 09:59:45 --> Pagination Class Initialized
INFO - 2016-02-01 09:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 09:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 09:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 09:59:45 --> Final output sent to browser
DEBUG - 2016-02-01 09:59:45 --> Total execution time: 1.1362
INFO - 2016-02-01 10:00:10 --> Config Class Initialized
INFO - 2016-02-01 10:00:10 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:00:10 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:00:10 --> Utf8 Class Initialized
INFO - 2016-02-01 10:00:10 --> URI Class Initialized
DEBUG - 2016-02-01 10:00:10 --> No URI present. Default controller set.
INFO - 2016-02-01 10:00:10 --> Router Class Initialized
INFO - 2016-02-01 10:00:10 --> Output Class Initialized
INFO - 2016-02-01 10:00:10 --> Security Class Initialized
DEBUG - 2016-02-01 10:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:00:10 --> Input Class Initialized
INFO - 2016-02-01 10:00:10 --> Language Class Initialized
INFO - 2016-02-01 10:00:10 --> Loader Class Initialized
INFO - 2016-02-01 10:00:10 --> Helper loaded: url_helper
INFO - 2016-02-01 10:00:10 --> Helper loaded: file_helper
INFO - 2016-02-01 10:00:10 --> Helper loaded: date_helper
INFO - 2016-02-01 10:00:10 --> Database Driver Class Initialized
INFO - 2016-02-01 10:00:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:00:11 --> Controller Class Initialized
INFO - 2016-02-01 10:00:11 --> Model Class Initialized
INFO - 2016-02-01 10:00:11 --> Model Class Initialized
INFO - 2016-02-01 10:00:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:00:11 --> Pagination Class Initialized
INFO - 2016-02-01 10:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:00:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:00:11 --> Final output sent to browser
DEBUG - 2016-02-01 10:00:11 --> Total execution time: 1.1477
INFO - 2016-02-01 10:00:16 --> Config Class Initialized
INFO - 2016-02-01 10:00:16 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:00:16 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:00:16 --> Utf8 Class Initialized
INFO - 2016-02-01 10:00:16 --> URI Class Initialized
INFO - 2016-02-01 10:00:16 --> Router Class Initialized
INFO - 2016-02-01 10:00:16 --> Output Class Initialized
INFO - 2016-02-01 10:00:16 --> Security Class Initialized
DEBUG - 2016-02-01 10:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:00:16 --> Input Class Initialized
INFO - 2016-02-01 10:00:16 --> Language Class Initialized
INFO - 2016-02-01 10:00:16 --> Loader Class Initialized
INFO - 2016-02-01 10:00:16 --> Helper loaded: url_helper
INFO - 2016-02-01 10:00:16 --> Helper loaded: file_helper
INFO - 2016-02-01 10:00:16 --> Helper loaded: date_helper
INFO - 2016-02-01 10:00:16 --> Database Driver Class Initialized
INFO - 2016-02-01 10:00:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:00:17 --> Controller Class Initialized
INFO - 2016-02-01 10:00:17 --> Model Class Initialized
INFO - 2016-02-01 10:00:17 --> Model Class Initialized
INFO - 2016-02-01 10:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:00:17 --> Pagination Class Initialized
INFO - 2016-02-01 10:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:00:17 --> Final output sent to browser
DEBUG - 2016-02-01 10:00:17 --> Total execution time: 1.1341
INFO - 2016-02-01 10:01:33 --> Config Class Initialized
INFO - 2016-02-01 10:01:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:01:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:01:33 --> Utf8 Class Initialized
INFO - 2016-02-01 10:01:33 --> URI Class Initialized
INFO - 2016-02-01 10:01:33 --> Router Class Initialized
INFO - 2016-02-01 10:01:33 --> Output Class Initialized
INFO - 2016-02-01 10:01:33 --> Security Class Initialized
DEBUG - 2016-02-01 10:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:01:33 --> Input Class Initialized
INFO - 2016-02-01 10:01:33 --> Language Class Initialized
INFO - 2016-02-01 10:01:33 --> Loader Class Initialized
INFO - 2016-02-01 10:01:33 --> Helper loaded: url_helper
INFO - 2016-02-01 10:01:33 --> Helper loaded: file_helper
INFO - 2016-02-01 10:01:33 --> Helper loaded: date_helper
INFO - 2016-02-01 10:01:33 --> Database Driver Class Initialized
INFO - 2016-02-01 10:01:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:01:34 --> Controller Class Initialized
INFO - 2016-02-01 10:01:34 --> Model Class Initialized
INFO - 2016-02-01 10:01:34 --> Model Class Initialized
INFO - 2016-02-01 10:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:01:34 --> Pagination Class Initialized
INFO - 2016-02-01 10:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:01:34 --> Severity: Notice --> Undefined index: page_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 79
INFO - 2016-02-01 10:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:01:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:01:34 --> Final output sent to browser
DEBUG - 2016-02-01 10:01:34 --> Total execution time: 1.1517
INFO - 2016-02-01 10:01:59 --> Config Class Initialized
INFO - 2016-02-01 10:01:59 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:01:59 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:01:59 --> Utf8 Class Initialized
INFO - 2016-02-01 10:01:59 --> URI Class Initialized
INFO - 2016-02-01 10:01:59 --> Router Class Initialized
INFO - 2016-02-01 10:01:59 --> Output Class Initialized
INFO - 2016-02-01 10:01:59 --> Security Class Initialized
DEBUG - 2016-02-01 10:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:01:59 --> Input Class Initialized
INFO - 2016-02-01 10:01:59 --> Language Class Initialized
INFO - 2016-02-01 10:01:59 --> Loader Class Initialized
INFO - 2016-02-01 10:01:59 --> Helper loaded: url_helper
INFO - 2016-02-01 10:01:59 --> Helper loaded: file_helper
INFO - 2016-02-01 10:01:59 --> Helper loaded: date_helper
INFO - 2016-02-01 10:01:59 --> Database Driver Class Initialized
INFO - 2016-02-01 10:02:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:02:00 --> Controller Class Initialized
INFO - 2016-02-01 10:02:00 --> Model Class Initialized
INFO - 2016-02-01 10:02:00 --> Model Class Initialized
INFO - 2016-02-01 10:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:02:00 --> Pagination Class Initialized
INFO - 2016-02-01 10:02:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:02:00 --> Severity: Notice --> Undefined index: page_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 79
INFO - 2016-02-01 10:02:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:02:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:02:00 --> Final output sent to browser
DEBUG - 2016-02-01 10:02:00 --> Total execution time: 1.1433
INFO - 2016-02-01 10:02:10 --> Config Class Initialized
INFO - 2016-02-01 10:02:10 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:02:10 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:02:10 --> Utf8 Class Initialized
INFO - 2016-02-01 10:02:10 --> URI Class Initialized
INFO - 2016-02-01 10:02:10 --> Router Class Initialized
INFO - 2016-02-01 10:02:10 --> Output Class Initialized
INFO - 2016-02-01 10:02:10 --> Security Class Initialized
DEBUG - 2016-02-01 10:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:02:10 --> Input Class Initialized
INFO - 2016-02-01 10:02:10 --> Language Class Initialized
INFO - 2016-02-01 10:02:10 --> Loader Class Initialized
INFO - 2016-02-01 10:02:10 --> Helper loaded: url_helper
INFO - 2016-02-01 10:02:10 --> Helper loaded: file_helper
INFO - 2016-02-01 10:02:10 --> Helper loaded: date_helper
INFO - 2016-02-01 10:02:10 --> Database Driver Class Initialized
INFO - 2016-02-01 10:02:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:02:11 --> Controller Class Initialized
INFO - 2016-02-01 10:02:11 --> Model Class Initialized
INFO - 2016-02-01 10:02:11 --> Model Class Initialized
INFO - 2016-02-01 10:02:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:02:11 --> Pagination Class Initialized
INFO - 2016-02-01 10:02:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:02:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:02:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:02:11 --> Final output sent to browser
DEBUG - 2016-02-01 10:02:11 --> Total execution time: 1.1103
INFO - 2016-02-01 10:02:13 --> Config Class Initialized
INFO - 2016-02-01 10:02:13 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:02:13 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:02:13 --> Utf8 Class Initialized
INFO - 2016-02-01 10:02:13 --> URI Class Initialized
INFO - 2016-02-01 10:02:13 --> Router Class Initialized
INFO - 2016-02-01 10:02:13 --> Output Class Initialized
INFO - 2016-02-01 10:02:13 --> Security Class Initialized
DEBUG - 2016-02-01 10:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:02:13 --> Input Class Initialized
INFO - 2016-02-01 10:02:13 --> Language Class Initialized
INFO - 2016-02-01 10:02:13 --> Loader Class Initialized
INFO - 2016-02-01 10:02:13 --> Helper loaded: url_helper
INFO - 2016-02-01 10:02:13 --> Helper loaded: file_helper
INFO - 2016-02-01 10:02:13 --> Helper loaded: date_helper
INFO - 2016-02-01 10:02:13 --> Database Driver Class Initialized
INFO - 2016-02-01 10:02:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:02:14 --> Controller Class Initialized
INFO - 2016-02-01 10:02:14 --> Model Class Initialized
INFO - 2016-02-01 10:02:14 --> Model Class Initialized
INFO - 2016-02-01 10:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:02:14 --> Pagination Class Initialized
INFO - 2016-02-01 10:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:02:14 --> Final output sent to browser
DEBUG - 2016-02-01 10:02:14 --> Total execution time: 1.1228
INFO - 2016-02-01 10:02:33 --> Config Class Initialized
INFO - 2016-02-01 10:02:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:02:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:02:33 --> Utf8 Class Initialized
INFO - 2016-02-01 10:02:33 --> URI Class Initialized
INFO - 2016-02-01 10:02:33 --> Router Class Initialized
INFO - 2016-02-01 10:02:33 --> Output Class Initialized
INFO - 2016-02-01 10:02:33 --> Security Class Initialized
DEBUG - 2016-02-01 10:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:02:33 --> Input Class Initialized
INFO - 2016-02-01 10:02:33 --> Language Class Initialized
INFO - 2016-02-01 10:02:33 --> Loader Class Initialized
INFO - 2016-02-01 10:02:33 --> Helper loaded: url_helper
INFO - 2016-02-01 10:02:33 --> Helper loaded: file_helper
INFO - 2016-02-01 10:02:33 --> Helper loaded: date_helper
INFO - 2016-02-01 10:02:33 --> Database Driver Class Initialized
INFO - 2016-02-01 10:02:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:02:34 --> Controller Class Initialized
INFO - 2016-02-01 10:02:34 --> Model Class Initialized
INFO - 2016-02-01 10:02:34 --> Model Class Initialized
INFO - 2016-02-01 10:02:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:02:34 --> Pagination Class Initialized
INFO - 2016-02-01 10:02:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:02:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:02:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:02:34 --> Final output sent to browser
DEBUG - 2016-02-01 10:02:34 --> Total execution time: 1.1299
INFO - 2016-02-01 10:02:36 --> Config Class Initialized
INFO - 2016-02-01 10:02:36 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:02:36 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:02:36 --> Utf8 Class Initialized
INFO - 2016-02-01 10:02:36 --> URI Class Initialized
INFO - 2016-02-01 10:02:36 --> Router Class Initialized
INFO - 2016-02-01 10:02:36 --> Output Class Initialized
INFO - 2016-02-01 10:02:36 --> Security Class Initialized
DEBUG - 2016-02-01 10:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:02:36 --> Input Class Initialized
INFO - 2016-02-01 10:02:36 --> Language Class Initialized
INFO - 2016-02-01 10:02:36 --> Loader Class Initialized
INFO - 2016-02-01 10:02:36 --> Helper loaded: url_helper
INFO - 2016-02-01 10:02:36 --> Helper loaded: file_helper
INFO - 2016-02-01 10:02:36 --> Helper loaded: date_helper
INFO - 2016-02-01 10:02:36 --> Database Driver Class Initialized
INFO - 2016-02-01 10:02:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:02:37 --> Controller Class Initialized
INFO - 2016-02-01 10:02:37 --> Model Class Initialized
INFO - 2016-02-01 10:02:37 --> Model Class Initialized
INFO - 2016-02-01 10:02:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:02:37 --> Pagination Class Initialized
INFO - 2016-02-01 10:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:02:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:02:37 --> Final output sent to browser
DEBUG - 2016-02-01 10:02:37 --> Total execution time: 1.1068
INFO - 2016-02-01 10:02:57 --> Config Class Initialized
INFO - 2016-02-01 10:02:57 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:02:57 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:02:57 --> Utf8 Class Initialized
INFO - 2016-02-01 10:02:57 --> URI Class Initialized
INFO - 2016-02-01 10:02:57 --> Router Class Initialized
INFO - 2016-02-01 10:02:57 --> Output Class Initialized
INFO - 2016-02-01 10:02:57 --> Security Class Initialized
DEBUG - 2016-02-01 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:02:57 --> Input Class Initialized
INFO - 2016-02-01 10:02:57 --> Language Class Initialized
INFO - 2016-02-01 10:02:57 --> Loader Class Initialized
INFO - 2016-02-01 10:02:57 --> Helper loaded: url_helper
INFO - 2016-02-01 10:02:57 --> Helper loaded: file_helper
INFO - 2016-02-01 10:02:57 --> Helper loaded: date_helper
INFO - 2016-02-01 10:02:57 --> Database Driver Class Initialized
INFO - 2016-02-01 10:02:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:02:58 --> Controller Class Initialized
INFO - 2016-02-01 10:02:58 --> Model Class Initialized
INFO - 2016-02-01 10:02:58 --> Model Class Initialized
INFO - 2016-02-01 10:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:02:58 --> Pagination Class Initialized
INFO - 2016-02-01 10:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:02:58 --> Final output sent to browser
DEBUG - 2016-02-01 10:02:58 --> Total execution time: 1.1050
INFO - 2016-02-01 10:03:00 --> Config Class Initialized
INFO - 2016-02-01 10:03:00 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:03:00 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:03:00 --> Utf8 Class Initialized
INFO - 2016-02-01 10:03:00 --> URI Class Initialized
INFO - 2016-02-01 10:03:00 --> Router Class Initialized
INFO - 2016-02-01 10:03:00 --> Output Class Initialized
INFO - 2016-02-01 10:03:00 --> Security Class Initialized
DEBUG - 2016-02-01 10:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:03:00 --> Input Class Initialized
INFO - 2016-02-01 10:03:00 --> Language Class Initialized
INFO - 2016-02-01 10:03:00 --> Loader Class Initialized
INFO - 2016-02-01 10:03:00 --> Helper loaded: url_helper
INFO - 2016-02-01 10:03:00 --> Helper loaded: file_helper
INFO - 2016-02-01 10:03:00 --> Helper loaded: date_helper
INFO - 2016-02-01 10:03:00 --> Database Driver Class Initialized
INFO - 2016-02-01 10:03:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:03:01 --> Controller Class Initialized
INFO - 2016-02-01 10:03:01 --> Model Class Initialized
INFO - 2016-02-01 10:03:01 --> Model Class Initialized
INFO - 2016-02-01 10:03:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:03:01 --> Pagination Class Initialized
INFO - 2016-02-01 10:03:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:03:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:03:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:03:01 --> Final output sent to browser
DEBUG - 2016-02-01 10:03:01 --> Total execution time: 1.1172
INFO - 2016-02-01 10:03:09 --> Config Class Initialized
INFO - 2016-02-01 10:03:09 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:03:09 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:03:09 --> Utf8 Class Initialized
INFO - 2016-02-01 10:03:09 --> URI Class Initialized
DEBUG - 2016-02-01 10:03:09 --> No URI present. Default controller set.
INFO - 2016-02-01 10:03:09 --> Router Class Initialized
INFO - 2016-02-01 10:03:09 --> Output Class Initialized
INFO - 2016-02-01 10:03:09 --> Security Class Initialized
DEBUG - 2016-02-01 10:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:03:09 --> Input Class Initialized
INFO - 2016-02-01 10:03:09 --> Language Class Initialized
INFO - 2016-02-01 10:03:09 --> Loader Class Initialized
INFO - 2016-02-01 10:03:09 --> Helper loaded: url_helper
INFO - 2016-02-01 10:03:09 --> Helper loaded: file_helper
INFO - 2016-02-01 10:03:09 --> Helper loaded: date_helper
INFO - 2016-02-01 10:03:09 --> Database Driver Class Initialized
INFO - 2016-02-01 10:03:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:03:10 --> Controller Class Initialized
INFO - 2016-02-01 10:03:10 --> Model Class Initialized
INFO - 2016-02-01 10:03:10 --> Model Class Initialized
INFO - 2016-02-01 10:03:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:03:10 --> Pagination Class Initialized
INFO - 2016-02-01 10:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:03:10 --> Final output sent to browser
DEBUG - 2016-02-01 10:03:10 --> Total execution time: 1.1287
INFO - 2016-02-01 10:03:11 --> Config Class Initialized
INFO - 2016-02-01 10:03:11 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:03:11 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:03:11 --> Utf8 Class Initialized
INFO - 2016-02-01 10:03:11 --> URI Class Initialized
INFO - 2016-02-01 10:03:11 --> Router Class Initialized
INFO - 2016-02-01 10:03:11 --> Output Class Initialized
INFO - 2016-02-01 10:03:11 --> Security Class Initialized
DEBUG - 2016-02-01 10:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:03:11 --> Input Class Initialized
INFO - 2016-02-01 10:03:11 --> Language Class Initialized
INFO - 2016-02-01 10:03:11 --> Loader Class Initialized
INFO - 2016-02-01 10:03:11 --> Helper loaded: url_helper
INFO - 2016-02-01 10:03:11 --> Helper loaded: file_helper
INFO - 2016-02-01 10:03:11 --> Helper loaded: date_helper
INFO - 2016-02-01 10:03:11 --> Database Driver Class Initialized
INFO - 2016-02-01 10:03:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:03:12 --> Controller Class Initialized
INFO - 2016-02-01 10:03:12 --> Model Class Initialized
INFO - 2016-02-01 10:03:12 --> Model Class Initialized
INFO - 2016-02-01 10:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:03:12 --> Pagination Class Initialized
INFO - 2016-02-01 10:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:03:13 --> Final output sent to browser
DEBUG - 2016-02-01 10:03:13 --> Total execution time: 1.1045
INFO - 2016-02-01 10:10:48 --> Config Class Initialized
INFO - 2016-02-01 10:10:48 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:10:48 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:10:48 --> Utf8 Class Initialized
INFO - 2016-02-01 10:10:48 --> URI Class Initialized
INFO - 2016-02-01 10:10:48 --> Router Class Initialized
INFO - 2016-02-01 10:10:48 --> Output Class Initialized
INFO - 2016-02-01 10:10:48 --> Security Class Initialized
DEBUG - 2016-02-01 10:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:10:48 --> Input Class Initialized
INFO - 2016-02-01 10:10:48 --> Language Class Initialized
INFO - 2016-02-01 10:10:48 --> Loader Class Initialized
INFO - 2016-02-01 10:10:48 --> Helper loaded: url_helper
INFO - 2016-02-01 10:10:48 --> Helper loaded: file_helper
INFO - 2016-02-01 10:10:48 --> Helper loaded: date_helper
INFO - 2016-02-01 10:10:48 --> Database Driver Class Initialized
INFO - 2016-02-01 10:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:10:49 --> Controller Class Initialized
INFO - 2016-02-01 10:10:49 --> Model Class Initialized
INFO - 2016-02-01 10:10:49 --> Model Class Initialized
INFO - 2016-02-01 10:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:10:49 --> Pagination Class Initialized
INFO - 2016-02-01 10:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:10:49 --> Severity: Notice --> Undefined variable: office C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 79
INFO - 2016-02-01 10:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:10:49 --> Final output sent to browser
DEBUG - 2016-02-01 10:10:49 --> Total execution time: 1.1193
INFO - 2016-02-01 10:10:59 --> Config Class Initialized
INFO - 2016-02-01 10:10:59 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:10:59 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:10:59 --> Utf8 Class Initialized
INFO - 2016-02-01 10:10:59 --> URI Class Initialized
INFO - 2016-02-01 10:10:59 --> Router Class Initialized
INFO - 2016-02-01 10:10:59 --> Output Class Initialized
INFO - 2016-02-01 10:10:59 --> Security Class Initialized
DEBUG - 2016-02-01 10:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:10:59 --> Input Class Initialized
INFO - 2016-02-01 10:10:59 --> Language Class Initialized
INFO - 2016-02-01 10:10:59 --> Loader Class Initialized
INFO - 2016-02-01 10:10:59 --> Helper loaded: url_helper
INFO - 2016-02-01 10:10:59 --> Helper loaded: file_helper
INFO - 2016-02-01 10:10:59 --> Helper loaded: date_helper
INFO - 2016-02-01 10:10:59 --> Database Driver Class Initialized
INFO - 2016-02-01 10:11:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:11:00 --> Controller Class Initialized
INFO - 2016-02-01 10:11:00 --> Model Class Initialized
INFO - 2016-02-01 10:11:00 --> Model Class Initialized
INFO - 2016-02-01 10:11:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:11:00 --> Pagination Class Initialized
INFO - 2016-02-01 10:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:11:00 --> Final output sent to browser
DEBUG - 2016-02-01 10:11:00 --> Total execution time: 1.1004
INFO - 2016-02-01 10:11:03 --> Config Class Initialized
INFO - 2016-02-01 10:11:03 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:11:03 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:11:03 --> Utf8 Class Initialized
INFO - 2016-02-01 10:11:03 --> URI Class Initialized
DEBUG - 2016-02-01 10:11:03 --> No URI present. Default controller set.
INFO - 2016-02-01 10:11:03 --> Router Class Initialized
INFO - 2016-02-01 10:11:03 --> Output Class Initialized
INFO - 2016-02-01 10:11:03 --> Security Class Initialized
DEBUG - 2016-02-01 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:11:03 --> Input Class Initialized
INFO - 2016-02-01 10:11:03 --> Language Class Initialized
INFO - 2016-02-01 10:11:03 --> Loader Class Initialized
INFO - 2016-02-01 10:11:03 --> Helper loaded: url_helper
INFO - 2016-02-01 10:11:03 --> Helper loaded: file_helper
INFO - 2016-02-01 10:11:03 --> Helper loaded: date_helper
INFO - 2016-02-01 10:11:03 --> Database Driver Class Initialized
INFO - 2016-02-01 10:11:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:11:04 --> Controller Class Initialized
INFO - 2016-02-01 10:11:04 --> Model Class Initialized
INFO - 2016-02-01 10:11:04 --> Model Class Initialized
INFO - 2016-02-01 10:11:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:11:04 --> Pagination Class Initialized
INFO - 2016-02-01 10:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:11:04 --> Final output sent to browser
DEBUG - 2016-02-01 10:11:04 --> Total execution time: 1.0993
INFO - 2016-02-01 10:11:06 --> Config Class Initialized
INFO - 2016-02-01 10:11:06 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:11:06 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:11:06 --> Utf8 Class Initialized
INFO - 2016-02-01 10:11:06 --> URI Class Initialized
INFO - 2016-02-01 10:11:06 --> Router Class Initialized
INFO - 2016-02-01 10:11:06 --> Output Class Initialized
INFO - 2016-02-01 10:11:06 --> Security Class Initialized
DEBUG - 2016-02-01 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:11:06 --> Input Class Initialized
INFO - 2016-02-01 10:11:06 --> Language Class Initialized
INFO - 2016-02-01 10:11:06 --> Loader Class Initialized
INFO - 2016-02-01 10:11:06 --> Helper loaded: url_helper
INFO - 2016-02-01 10:11:06 --> Helper loaded: file_helper
INFO - 2016-02-01 10:11:06 --> Helper loaded: date_helper
INFO - 2016-02-01 10:11:06 --> Database Driver Class Initialized
INFO - 2016-02-01 10:11:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:11:07 --> Controller Class Initialized
INFO - 2016-02-01 10:11:07 --> Model Class Initialized
INFO - 2016-02-01 10:11:07 --> Model Class Initialized
INFO - 2016-02-01 10:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:11:07 --> Pagination Class Initialized
INFO - 2016-02-01 10:11:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:11:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:11:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:11:07 --> Final output sent to browser
DEBUG - 2016-02-01 10:11:07 --> Total execution time: 1.1278
INFO - 2016-02-01 10:15:37 --> Config Class Initialized
INFO - 2016-02-01 10:15:37 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:15:37 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:15:37 --> Utf8 Class Initialized
INFO - 2016-02-01 10:15:37 --> URI Class Initialized
INFO - 2016-02-01 10:15:37 --> Router Class Initialized
INFO - 2016-02-01 10:15:37 --> Output Class Initialized
INFO - 2016-02-01 10:15:37 --> Security Class Initialized
DEBUG - 2016-02-01 10:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:15:37 --> Input Class Initialized
INFO - 2016-02-01 10:15:37 --> Language Class Initialized
INFO - 2016-02-01 10:15:37 --> Loader Class Initialized
INFO - 2016-02-01 10:15:37 --> Helper loaded: url_helper
INFO - 2016-02-01 10:15:37 --> Helper loaded: file_helper
INFO - 2016-02-01 10:15:37 --> Helper loaded: date_helper
INFO - 2016-02-01 10:15:37 --> Database Driver Class Initialized
INFO - 2016-02-01 10:15:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:15:38 --> Controller Class Initialized
INFO - 2016-02-01 10:15:38 --> Model Class Initialized
INFO - 2016-02-01 10:15:38 --> Model Class Initialized
INFO - 2016-02-01 10:15:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:15:38 --> Pagination Class Initialized
INFO - 2016-02-01 10:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:15:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:15:38 --> Final output sent to browser
DEBUG - 2016-02-01 10:15:38 --> Total execution time: 1.1254
INFO - 2016-02-01 10:15:41 --> Config Class Initialized
INFO - 2016-02-01 10:15:41 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:15:41 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:15:41 --> Utf8 Class Initialized
INFO - 2016-02-01 10:15:41 --> URI Class Initialized
INFO - 2016-02-01 10:15:41 --> Router Class Initialized
INFO - 2016-02-01 10:15:41 --> Output Class Initialized
INFO - 2016-02-01 10:15:41 --> Security Class Initialized
DEBUG - 2016-02-01 10:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:15:41 --> Input Class Initialized
INFO - 2016-02-01 10:15:41 --> Language Class Initialized
INFO - 2016-02-01 10:15:41 --> Loader Class Initialized
INFO - 2016-02-01 10:15:41 --> Helper loaded: url_helper
INFO - 2016-02-01 10:15:41 --> Helper loaded: file_helper
INFO - 2016-02-01 10:15:41 --> Helper loaded: date_helper
INFO - 2016-02-01 10:15:41 --> Database Driver Class Initialized
INFO - 2016-02-01 10:15:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:15:42 --> Controller Class Initialized
INFO - 2016-02-01 10:15:42 --> Model Class Initialized
INFO - 2016-02-01 10:15:42 --> Model Class Initialized
INFO - 2016-02-01 10:15:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:15:42 --> Pagination Class Initialized
INFO - 2016-02-01 10:15:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:15:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-17, 17' at line 4 - Invalid query: SELECT *
FROM `jdmain`
ORDER BY `id` DESC
 LIMIT -17, 17
INFO - 2016-02-01 10:15:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-01 10:17:33 --> Config Class Initialized
INFO - 2016-02-01 10:17:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:17:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:17:33 --> Utf8 Class Initialized
INFO - 2016-02-01 10:17:33 --> URI Class Initialized
INFO - 2016-02-01 10:17:33 --> Router Class Initialized
INFO - 2016-02-01 10:17:33 --> Output Class Initialized
INFO - 2016-02-01 10:17:33 --> Security Class Initialized
DEBUG - 2016-02-01 10:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:17:33 --> Input Class Initialized
INFO - 2016-02-01 10:17:33 --> Language Class Initialized
INFO - 2016-02-01 10:17:33 --> Loader Class Initialized
INFO - 2016-02-01 10:17:33 --> Helper loaded: url_helper
INFO - 2016-02-01 10:17:33 --> Helper loaded: file_helper
INFO - 2016-02-01 10:17:33 --> Helper loaded: date_helper
INFO - 2016-02-01 10:17:33 --> Database Driver Class Initialized
INFO - 2016-02-01 10:17:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:17:34 --> Controller Class Initialized
INFO - 2016-02-01 10:17:34 --> Model Class Initialized
INFO - 2016-02-01 10:17:34 --> Model Class Initialized
INFO - 2016-02-01 10:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:17:34 --> Pagination Class Initialized
INFO - 2016-02-01 10:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:17:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
INFO - 2016-02-01 10:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:17:34 --> Final output sent to browser
DEBUG - 2016-02-01 10:17:34 --> Total execution time: 1.1248
INFO - 2016-02-01 10:17:57 --> Config Class Initialized
INFO - 2016-02-01 10:17:57 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:17:57 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:17:57 --> Utf8 Class Initialized
INFO - 2016-02-01 10:17:57 --> URI Class Initialized
DEBUG - 2016-02-01 10:17:57 --> No URI present. Default controller set.
INFO - 2016-02-01 10:17:57 --> Router Class Initialized
INFO - 2016-02-01 10:17:57 --> Output Class Initialized
INFO - 2016-02-01 10:17:57 --> Security Class Initialized
DEBUG - 2016-02-01 10:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:17:57 --> Input Class Initialized
INFO - 2016-02-01 10:17:57 --> Language Class Initialized
INFO - 2016-02-01 10:17:57 --> Loader Class Initialized
INFO - 2016-02-01 10:17:57 --> Helper loaded: url_helper
INFO - 2016-02-01 10:17:57 --> Helper loaded: file_helper
INFO - 2016-02-01 10:17:57 --> Helper loaded: date_helper
INFO - 2016-02-01 10:17:57 --> Database Driver Class Initialized
INFO - 2016-02-01 10:17:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:17:58 --> Controller Class Initialized
INFO - 2016-02-01 10:17:58 --> Model Class Initialized
INFO - 2016-02-01 10:17:58 --> Model Class Initialized
INFO - 2016-02-01 10:17:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:17:58 --> Pagination Class Initialized
INFO - 2016-02-01 10:17:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:17:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:17:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:17:58 --> Final output sent to browser
DEBUG - 2016-02-01 10:17:58 --> Total execution time: 1.1476
INFO - 2016-02-01 10:18:01 --> Config Class Initialized
INFO - 2016-02-01 10:18:01 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:18:01 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:18:01 --> Utf8 Class Initialized
INFO - 2016-02-01 10:18:01 --> URI Class Initialized
INFO - 2016-02-01 10:18:01 --> Router Class Initialized
INFO - 2016-02-01 10:18:01 --> Output Class Initialized
INFO - 2016-02-01 10:18:01 --> Security Class Initialized
DEBUG - 2016-02-01 10:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:18:01 --> Input Class Initialized
INFO - 2016-02-01 10:18:01 --> Language Class Initialized
INFO - 2016-02-01 10:18:01 --> Loader Class Initialized
INFO - 2016-02-01 10:18:01 --> Helper loaded: url_helper
INFO - 2016-02-01 10:18:01 --> Helper loaded: file_helper
INFO - 2016-02-01 10:18:01 --> Helper loaded: date_helper
INFO - 2016-02-01 10:18:01 --> Database Driver Class Initialized
INFO - 2016-02-01 10:18:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:18:02 --> Controller Class Initialized
INFO - 2016-02-01 10:18:02 --> Model Class Initialized
INFO - 2016-02-01 10:18:02 --> Model Class Initialized
INFO - 2016-02-01 10:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:18:02 --> Pagination Class Initialized
INFO - 2016-02-01 10:18:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:18:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:18:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:18:02 --> Final output sent to browser
DEBUG - 2016-02-01 10:18:02 --> Total execution time: 1.1301
INFO - 2016-02-01 10:18:05 --> Config Class Initialized
INFO - 2016-02-01 10:18:05 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:18:05 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:18:05 --> Utf8 Class Initialized
INFO - 2016-02-01 10:18:05 --> URI Class Initialized
INFO - 2016-02-01 10:18:05 --> Router Class Initialized
INFO - 2016-02-01 10:18:05 --> Output Class Initialized
INFO - 2016-02-01 10:18:05 --> Security Class Initialized
DEBUG - 2016-02-01 10:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:18:05 --> Input Class Initialized
INFO - 2016-02-01 10:18:05 --> Language Class Initialized
INFO - 2016-02-01 10:18:05 --> Loader Class Initialized
INFO - 2016-02-01 10:18:05 --> Helper loaded: url_helper
INFO - 2016-02-01 10:18:05 --> Helper loaded: file_helper
INFO - 2016-02-01 10:18:05 --> Helper loaded: date_helper
INFO - 2016-02-01 10:18:05 --> Database Driver Class Initialized
INFO - 2016-02-01 10:18:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:18:06 --> Controller Class Initialized
INFO - 2016-02-01 10:18:06 --> Model Class Initialized
INFO - 2016-02-01 10:18:06 --> Model Class Initialized
INFO - 2016-02-01 10:18:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:18:06 --> Pagination Class Initialized
INFO - 2016-02-01 10:18:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:18:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:18:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:18:07 --> Final output sent to browser
DEBUG - 2016-02-01 10:18:07 --> Total execution time: 1.1278
INFO - 2016-02-01 10:20:21 --> Config Class Initialized
INFO - 2016-02-01 10:20:21 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:20:21 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:20:21 --> Utf8 Class Initialized
INFO - 2016-02-01 10:20:21 --> URI Class Initialized
DEBUG - 2016-02-01 10:20:21 --> No URI present. Default controller set.
INFO - 2016-02-01 10:20:21 --> Router Class Initialized
INFO - 2016-02-01 10:20:21 --> Output Class Initialized
INFO - 2016-02-01 10:20:21 --> Security Class Initialized
DEBUG - 2016-02-01 10:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:20:21 --> Input Class Initialized
INFO - 2016-02-01 10:20:21 --> Language Class Initialized
INFO - 2016-02-01 10:20:21 --> Loader Class Initialized
INFO - 2016-02-01 10:20:21 --> Helper loaded: url_helper
INFO - 2016-02-01 10:20:21 --> Helper loaded: file_helper
INFO - 2016-02-01 10:20:21 --> Helper loaded: date_helper
INFO - 2016-02-01 10:20:21 --> Database Driver Class Initialized
INFO - 2016-02-01 10:20:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:20:22 --> Controller Class Initialized
INFO - 2016-02-01 10:20:22 --> Model Class Initialized
INFO - 2016-02-01 10:20:22 --> Model Class Initialized
INFO - 2016-02-01 10:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:20:22 --> Pagination Class Initialized
INFO - 2016-02-01 10:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:20:22 --> Final output sent to browser
DEBUG - 2016-02-01 10:20:22 --> Total execution time: 1.1118
INFO - 2016-02-01 10:20:28 --> Config Class Initialized
INFO - 2016-02-01 10:20:28 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:20:28 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:20:28 --> Utf8 Class Initialized
INFO - 2016-02-01 10:20:28 --> URI Class Initialized
INFO - 2016-02-01 10:20:28 --> Router Class Initialized
INFO - 2016-02-01 10:20:28 --> Output Class Initialized
INFO - 2016-02-01 10:20:28 --> Security Class Initialized
DEBUG - 2016-02-01 10:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:20:28 --> Input Class Initialized
INFO - 2016-02-01 10:20:28 --> Language Class Initialized
INFO - 2016-02-01 10:20:28 --> Loader Class Initialized
INFO - 2016-02-01 10:20:28 --> Helper loaded: url_helper
INFO - 2016-02-01 10:20:28 --> Helper loaded: file_helper
INFO - 2016-02-01 10:20:28 --> Helper loaded: date_helper
INFO - 2016-02-01 10:20:28 --> Database Driver Class Initialized
INFO - 2016-02-01 10:20:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:20:29 --> Controller Class Initialized
INFO - 2016-02-01 10:20:29 --> Model Class Initialized
INFO - 2016-02-01 10:20:29 --> Model Class Initialized
INFO - 2016-02-01 10:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:20:29 --> Pagination Class Initialized
INFO - 2016-02-01 10:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:20:29 --> Final output sent to browser
DEBUG - 2016-02-01 10:20:29 --> Total execution time: 1.0900
INFO - 2016-02-01 10:20:33 --> Config Class Initialized
INFO - 2016-02-01 10:20:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:20:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:20:33 --> Utf8 Class Initialized
INFO - 2016-02-01 10:20:33 --> URI Class Initialized
INFO - 2016-02-01 10:20:33 --> Router Class Initialized
INFO - 2016-02-01 10:20:33 --> Output Class Initialized
INFO - 2016-02-01 10:20:33 --> Security Class Initialized
DEBUG - 2016-02-01 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:20:33 --> Input Class Initialized
INFO - 2016-02-01 10:20:33 --> Language Class Initialized
INFO - 2016-02-01 10:20:33 --> Loader Class Initialized
INFO - 2016-02-01 10:20:33 --> Helper loaded: url_helper
INFO - 2016-02-01 10:20:33 --> Helper loaded: file_helper
INFO - 2016-02-01 10:20:33 --> Helper loaded: date_helper
INFO - 2016-02-01 10:20:33 --> Database Driver Class Initialized
INFO - 2016-02-01 10:20:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:20:34 --> Controller Class Initialized
INFO - 2016-02-01 10:20:34 --> Model Class Initialized
INFO - 2016-02-01 10:20:34 --> Model Class Initialized
INFO - 2016-02-01 10:20:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:20:34 --> Pagination Class Initialized
INFO - 2016-02-01 10:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:20:34 --> Final output sent to browser
DEBUG - 2016-02-01 10:20:34 --> Total execution time: 1.0966
INFO - 2016-02-01 10:22:59 --> Config Class Initialized
INFO - 2016-02-01 10:22:59 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:22:59 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:22:59 --> Utf8 Class Initialized
INFO - 2016-02-01 10:22:59 --> URI Class Initialized
INFO - 2016-02-01 10:22:59 --> Router Class Initialized
INFO - 2016-02-01 10:22:59 --> Output Class Initialized
INFO - 2016-02-01 10:22:59 --> Security Class Initialized
DEBUG - 2016-02-01 10:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:22:59 --> Input Class Initialized
INFO - 2016-02-01 10:22:59 --> Language Class Initialized
INFO - 2016-02-01 10:22:59 --> Loader Class Initialized
INFO - 2016-02-01 10:22:59 --> Helper loaded: url_helper
INFO - 2016-02-01 10:22:59 --> Helper loaded: file_helper
INFO - 2016-02-01 10:22:59 --> Helper loaded: date_helper
INFO - 2016-02-01 10:22:59 --> Database Driver Class Initialized
INFO - 2016-02-01 10:23:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:23:00 --> Controller Class Initialized
INFO - 2016-02-01 10:23:00 --> Model Class Initialized
INFO - 2016-02-01 10:23:00 --> Model Class Initialized
INFO - 2016-02-01 10:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:23:00 --> Pagination Class Initialized
INFO - 2016-02-01 10:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:23:00 --> Final output sent to browser
DEBUG - 2016-02-01 10:23:00 --> Total execution time: 1.0999
INFO - 2016-02-01 10:23:03 --> Config Class Initialized
INFO - 2016-02-01 10:23:03 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:23:03 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:23:03 --> Utf8 Class Initialized
INFO - 2016-02-01 10:23:03 --> URI Class Initialized
INFO - 2016-02-01 10:23:03 --> Router Class Initialized
INFO - 2016-02-01 10:23:03 --> Output Class Initialized
INFO - 2016-02-01 10:23:03 --> Security Class Initialized
DEBUG - 2016-02-01 10:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:23:03 --> Input Class Initialized
INFO - 2016-02-01 10:23:03 --> Language Class Initialized
INFO - 2016-02-01 10:23:03 --> Loader Class Initialized
INFO - 2016-02-01 10:23:03 --> Helper loaded: url_helper
INFO - 2016-02-01 10:23:03 --> Helper loaded: file_helper
INFO - 2016-02-01 10:23:03 --> Helper loaded: date_helper
INFO - 2016-02-01 10:23:03 --> Database Driver Class Initialized
INFO - 2016-02-01 10:23:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:23:04 --> Controller Class Initialized
INFO - 2016-02-01 10:23:04 --> Model Class Initialized
INFO - 2016-02-01 10:23:04 --> Model Class Initialized
INFO - 2016-02-01 10:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:23:04 --> Pagination Class Initialized
INFO - 2016-02-01 10:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:23:04 --> Final output sent to browser
DEBUG - 2016-02-01 10:23:04 --> Total execution time: 1.0908
INFO - 2016-02-01 10:23:07 --> Config Class Initialized
INFO - 2016-02-01 10:23:07 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:23:07 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:23:07 --> Utf8 Class Initialized
INFO - 2016-02-01 10:23:07 --> URI Class Initialized
INFO - 2016-02-01 10:23:07 --> Router Class Initialized
INFO - 2016-02-01 10:23:07 --> Output Class Initialized
INFO - 2016-02-01 10:23:07 --> Security Class Initialized
DEBUG - 2016-02-01 10:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:23:07 --> Input Class Initialized
INFO - 2016-02-01 10:23:07 --> Language Class Initialized
INFO - 2016-02-01 10:23:07 --> Loader Class Initialized
INFO - 2016-02-01 10:23:07 --> Helper loaded: url_helper
INFO - 2016-02-01 10:23:07 --> Helper loaded: file_helper
INFO - 2016-02-01 10:23:07 --> Helper loaded: date_helper
INFO - 2016-02-01 10:23:07 --> Database Driver Class Initialized
INFO - 2016-02-01 10:23:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:23:08 --> Controller Class Initialized
INFO - 2016-02-01 10:23:08 --> Model Class Initialized
INFO - 2016-02-01 10:23:08 --> Model Class Initialized
INFO - 2016-02-01 10:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:23:08 --> Pagination Class Initialized
INFO - 2016-02-01 10:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:23:08 --> Final output sent to browser
DEBUG - 2016-02-01 10:23:08 --> Total execution time: 1.1232
INFO - 2016-02-01 10:23:09 --> Config Class Initialized
INFO - 2016-02-01 10:23:09 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:23:09 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:23:09 --> Utf8 Class Initialized
INFO - 2016-02-01 10:23:09 --> URI Class Initialized
INFO - 2016-02-01 10:23:09 --> Router Class Initialized
INFO - 2016-02-01 10:23:09 --> Output Class Initialized
INFO - 2016-02-01 10:23:09 --> Security Class Initialized
DEBUG - 2016-02-01 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:23:09 --> Input Class Initialized
INFO - 2016-02-01 10:23:09 --> Language Class Initialized
INFO - 2016-02-01 10:23:09 --> Loader Class Initialized
INFO - 2016-02-01 10:23:09 --> Helper loaded: url_helper
INFO - 2016-02-01 10:23:09 --> Helper loaded: file_helper
INFO - 2016-02-01 10:23:09 --> Helper loaded: date_helper
INFO - 2016-02-01 10:23:09 --> Database Driver Class Initialized
INFO - 2016-02-01 10:23:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:23:10 --> Controller Class Initialized
INFO - 2016-02-01 10:23:10 --> Model Class Initialized
INFO - 2016-02-01 10:23:10 --> Model Class Initialized
INFO - 2016-02-01 10:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:23:10 --> Pagination Class Initialized
INFO - 2016-02-01 10:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:23:10 --> Final output sent to browser
DEBUG - 2016-02-01 10:23:10 --> Total execution time: 1.1077
INFO - 2016-02-01 10:23:47 --> Config Class Initialized
INFO - 2016-02-01 10:23:47 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:23:47 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:23:47 --> Utf8 Class Initialized
INFO - 2016-02-01 10:23:47 --> URI Class Initialized
DEBUG - 2016-02-01 10:23:47 --> No URI present. Default controller set.
INFO - 2016-02-01 10:23:47 --> Router Class Initialized
INFO - 2016-02-01 10:23:47 --> Output Class Initialized
INFO - 2016-02-01 10:23:47 --> Security Class Initialized
DEBUG - 2016-02-01 10:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:23:47 --> Input Class Initialized
INFO - 2016-02-01 10:23:47 --> Language Class Initialized
INFO - 2016-02-01 10:23:47 --> Loader Class Initialized
INFO - 2016-02-01 10:23:47 --> Helper loaded: url_helper
INFO - 2016-02-01 10:23:47 --> Helper loaded: file_helper
INFO - 2016-02-01 10:23:47 --> Helper loaded: date_helper
INFO - 2016-02-01 10:23:47 --> Database Driver Class Initialized
INFO - 2016-02-01 10:23:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:23:48 --> Controller Class Initialized
INFO - 2016-02-01 10:23:48 --> Model Class Initialized
INFO - 2016-02-01 10:23:48 --> Model Class Initialized
INFO - 2016-02-01 10:23:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:23:48 --> Pagination Class Initialized
INFO - 2016-02-01 10:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 18
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli::$tcomment C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 18
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli_result::$tcomment C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 18
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 18
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 18
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 18
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 18
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 18
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 19
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 21
ERROR - 2016-02-01 10:23:48 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 22
INFO - 2016-02-01 10:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:23:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:23:48 --> Final output sent to browser
DEBUG - 2016-02-01 10:23:48 --> Total execution time: 1.2433
INFO - 2016-02-01 10:24:30 --> Config Class Initialized
INFO - 2016-02-01 10:24:30 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:24:30 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:24:30 --> Utf8 Class Initialized
INFO - 2016-02-01 10:24:30 --> URI Class Initialized
DEBUG - 2016-02-01 10:24:30 --> No URI present. Default controller set.
INFO - 2016-02-01 10:24:30 --> Router Class Initialized
INFO - 2016-02-01 10:24:30 --> Output Class Initialized
INFO - 2016-02-01 10:24:30 --> Security Class Initialized
DEBUG - 2016-02-01 10:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:24:30 --> Input Class Initialized
INFO - 2016-02-01 10:24:30 --> Language Class Initialized
INFO - 2016-02-01 10:24:30 --> Loader Class Initialized
INFO - 2016-02-01 10:24:30 --> Helper loaded: url_helper
INFO - 2016-02-01 10:24:30 --> Helper loaded: file_helper
INFO - 2016-02-01 10:24:30 --> Helper loaded: date_helper
INFO - 2016-02-01 10:24:30 --> Database Driver Class Initialized
INFO - 2016-02-01 10:24:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:24:31 --> Controller Class Initialized
INFO - 2016-02-01 10:24:31 --> Model Class Initialized
INFO - 2016-02-01 10:24:31 --> Model Class Initialized
INFO - 2016-02-01 10:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:24:31 --> Pagination Class Initialized
INFO - 2016-02-01 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:24:31 --> Final output sent to browser
DEBUG - 2016-02-01 10:24:31 --> Total execution time: 1.0933
INFO - 2016-02-01 10:24:33 --> Config Class Initialized
INFO - 2016-02-01 10:24:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:24:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:24:33 --> Utf8 Class Initialized
INFO - 2016-02-01 10:24:33 --> URI Class Initialized
INFO - 2016-02-01 10:24:33 --> Router Class Initialized
INFO - 2016-02-01 10:24:33 --> Output Class Initialized
INFO - 2016-02-01 10:24:33 --> Security Class Initialized
DEBUG - 2016-02-01 10:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:24:33 --> Input Class Initialized
INFO - 2016-02-01 10:24:33 --> Language Class Initialized
INFO - 2016-02-01 10:24:33 --> Loader Class Initialized
INFO - 2016-02-01 10:24:33 --> Helper loaded: url_helper
INFO - 2016-02-01 10:24:33 --> Helper loaded: file_helper
INFO - 2016-02-01 10:24:33 --> Helper loaded: date_helper
INFO - 2016-02-01 10:24:33 --> Database Driver Class Initialized
INFO - 2016-02-01 10:24:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:24:34 --> Controller Class Initialized
INFO - 2016-02-01 10:24:34 --> Model Class Initialized
INFO - 2016-02-01 10:24:34 --> Model Class Initialized
INFO - 2016-02-01 10:24:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:24:34 --> Pagination Class Initialized
INFO - 2016-02-01 10:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:24:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:24:34 --> Final output sent to browser
DEBUG - 2016-02-01 10:24:34 --> Total execution time: 1.1325
INFO - 2016-02-01 10:24:37 --> Config Class Initialized
INFO - 2016-02-01 10:24:37 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:24:37 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:24:37 --> Utf8 Class Initialized
INFO - 2016-02-01 10:24:37 --> URI Class Initialized
INFO - 2016-02-01 10:24:37 --> Router Class Initialized
INFO - 2016-02-01 10:24:37 --> Output Class Initialized
INFO - 2016-02-01 10:24:37 --> Security Class Initialized
DEBUG - 2016-02-01 10:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:24:37 --> Input Class Initialized
INFO - 2016-02-01 10:24:37 --> Language Class Initialized
INFO - 2016-02-01 10:24:37 --> Loader Class Initialized
INFO - 2016-02-01 10:24:37 --> Helper loaded: url_helper
INFO - 2016-02-01 10:24:37 --> Helper loaded: file_helper
INFO - 2016-02-01 10:24:37 --> Helper loaded: date_helper
INFO - 2016-02-01 10:24:37 --> Database Driver Class Initialized
INFO - 2016-02-01 10:24:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:24:38 --> Controller Class Initialized
INFO - 2016-02-01 10:24:38 --> Model Class Initialized
INFO - 2016-02-01 10:24:38 --> Model Class Initialized
INFO - 2016-02-01 10:24:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:24:38 --> Pagination Class Initialized
INFO - 2016-02-01 10:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:24:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:24:38 --> Final output sent to browser
DEBUG - 2016-02-01 10:24:38 --> Total execution time: 1.1295
INFO - 2016-02-01 10:24:40 --> Config Class Initialized
INFO - 2016-02-01 10:24:40 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:24:40 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:24:40 --> Utf8 Class Initialized
INFO - 2016-02-01 10:24:40 --> URI Class Initialized
INFO - 2016-02-01 10:24:40 --> Router Class Initialized
INFO - 2016-02-01 10:24:40 --> Output Class Initialized
INFO - 2016-02-01 10:24:40 --> Security Class Initialized
DEBUG - 2016-02-01 10:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:24:40 --> Input Class Initialized
INFO - 2016-02-01 10:24:40 --> Language Class Initialized
INFO - 2016-02-01 10:24:40 --> Loader Class Initialized
INFO - 2016-02-01 10:24:40 --> Helper loaded: url_helper
INFO - 2016-02-01 10:24:40 --> Helper loaded: file_helper
INFO - 2016-02-01 10:24:40 --> Helper loaded: date_helper
INFO - 2016-02-01 10:24:40 --> Database Driver Class Initialized
INFO - 2016-02-01 10:24:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:24:41 --> Controller Class Initialized
INFO - 2016-02-01 10:24:41 --> Model Class Initialized
INFO - 2016-02-01 10:24:41 --> Model Class Initialized
INFO - 2016-02-01 10:24:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:24:41 --> Pagination Class Initialized
INFO - 2016-02-01 10:24:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:24:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:24:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:24:41 --> Final output sent to browser
DEBUG - 2016-02-01 10:24:41 --> Total execution time: 1.0954
INFO - 2016-02-01 10:24:43 --> Config Class Initialized
INFO - 2016-02-01 10:24:43 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:24:43 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:24:43 --> Utf8 Class Initialized
INFO - 2016-02-01 10:24:43 --> URI Class Initialized
INFO - 2016-02-01 10:24:43 --> Router Class Initialized
INFO - 2016-02-01 10:24:43 --> Output Class Initialized
INFO - 2016-02-01 10:24:43 --> Security Class Initialized
DEBUG - 2016-02-01 10:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:24:43 --> Input Class Initialized
INFO - 2016-02-01 10:24:43 --> Language Class Initialized
INFO - 2016-02-01 10:24:43 --> Loader Class Initialized
INFO - 2016-02-01 10:24:43 --> Helper loaded: url_helper
INFO - 2016-02-01 10:24:43 --> Helper loaded: file_helper
INFO - 2016-02-01 10:24:43 --> Helper loaded: date_helper
INFO - 2016-02-01 10:24:43 --> Database Driver Class Initialized
INFO - 2016-02-01 10:24:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:24:44 --> Controller Class Initialized
INFO - 2016-02-01 10:24:44 --> Model Class Initialized
INFO - 2016-02-01 10:24:44 --> Model Class Initialized
INFO - 2016-02-01 10:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:24:44 --> Pagination Class Initialized
INFO - 2016-02-01 10:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:24:44 --> Final output sent to browser
DEBUG - 2016-02-01 10:24:44 --> Total execution time: 1.1118
INFO - 2016-02-01 10:24:45 --> Config Class Initialized
INFO - 2016-02-01 10:24:45 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:24:45 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:24:45 --> Utf8 Class Initialized
INFO - 2016-02-01 10:24:45 --> URI Class Initialized
INFO - 2016-02-01 10:24:45 --> Router Class Initialized
INFO - 2016-02-01 10:24:45 --> Output Class Initialized
INFO - 2016-02-01 10:24:45 --> Security Class Initialized
DEBUG - 2016-02-01 10:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:24:45 --> Input Class Initialized
INFO - 2016-02-01 10:24:45 --> Language Class Initialized
INFO - 2016-02-01 10:24:45 --> Loader Class Initialized
INFO - 2016-02-01 10:24:45 --> Helper loaded: url_helper
INFO - 2016-02-01 10:24:45 --> Helper loaded: file_helper
INFO - 2016-02-01 10:24:45 --> Helper loaded: date_helper
INFO - 2016-02-01 10:24:45 --> Database Driver Class Initialized
INFO - 2016-02-01 10:24:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:24:46 --> Controller Class Initialized
INFO - 2016-02-01 10:24:46 --> Model Class Initialized
INFO - 2016-02-01 10:24:46 --> Model Class Initialized
INFO - 2016-02-01 10:24:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:24:46 --> Pagination Class Initialized
INFO - 2016-02-01 10:24:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:24:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:24:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:24:46 --> Final output sent to browser
DEBUG - 2016-02-01 10:24:46 --> Total execution time: 1.0853
INFO - 2016-02-01 10:24:48 --> Config Class Initialized
INFO - 2016-02-01 10:24:48 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:24:48 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:24:48 --> Utf8 Class Initialized
INFO - 2016-02-01 10:24:48 --> URI Class Initialized
INFO - 2016-02-01 10:24:48 --> Router Class Initialized
INFO - 2016-02-01 10:24:48 --> Output Class Initialized
INFO - 2016-02-01 10:24:48 --> Security Class Initialized
DEBUG - 2016-02-01 10:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:24:48 --> Input Class Initialized
INFO - 2016-02-01 10:24:48 --> Language Class Initialized
INFO - 2016-02-01 10:24:48 --> Loader Class Initialized
INFO - 2016-02-01 10:24:48 --> Helper loaded: url_helper
INFO - 2016-02-01 10:24:48 --> Helper loaded: file_helper
INFO - 2016-02-01 10:24:48 --> Helper loaded: date_helper
INFO - 2016-02-01 10:24:48 --> Database Driver Class Initialized
INFO - 2016-02-01 10:24:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:24:49 --> Controller Class Initialized
INFO - 2016-02-01 10:24:49 --> Model Class Initialized
INFO - 2016-02-01 10:24:49 --> Model Class Initialized
INFO - 2016-02-01 10:24:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:24:49 --> Pagination Class Initialized
INFO - 2016-02-01 10:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:24:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:24:49 --> Final output sent to browser
DEBUG - 2016-02-01 10:24:49 --> Total execution time: 1.1252
INFO - 2016-02-01 10:25:14 --> Config Class Initialized
INFO - 2016-02-01 10:25:14 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:25:14 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:25:14 --> Utf8 Class Initialized
INFO - 2016-02-01 10:25:14 --> URI Class Initialized
DEBUG - 2016-02-01 10:25:14 --> No URI present. Default controller set.
INFO - 2016-02-01 10:25:14 --> Router Class Initialized
INFO - 2016-02-01 10:25:14 --> Output Class Initialized
INFO - 2016-02-01 10:25:14 --> Security Class Initialized
DEBUG - 2016-02-01 10:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:25:14 --> Input Class Initialized
INFO - 2016-02-01 10:25:14 --> Language Class Initialized
INFO - 2016-02-01 10:25:14 --> Loader Class Initialized
INFO - 2016-02-01 10:25:14 --> Helper loaded: url_helper
INFO - 2016-02-01 10:25:14 --> Helper loaded: file_helper
INFO - 2016-02-01 10:25:14 --> Helper loaded: date_helper
INFO - 2016-02-01 10:25:14 --> Database Driver Class Initialized
INFO - 2016-02-01 10:25:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:25:15 --> Controller Class Initialized
INFO - 2016-02-01 10:25:15 --> Model Class Initialized
INFO - 2016-02-01 10:25:15 --> Model Class Initialized
INFO - 2016-02-01 10:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:25:15 --> Pagination Class Initialized
INFO - 2016-02-01 10:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:25:15 --> Severity: Notice --> Undefined variable: page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 80
ERROR - 2016-02-01 10:25:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-17' at line 4 - Invalid query: SELECT *
FROM `jdmain`
ORDER BY `id` DESC
 LIMIT -17
INFO - 2016-02-01 10:25:15 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-01 10:25:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-17' at line 3 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1454351115
WHERE `id` = 'b40ad6c0110fbd99f7f343150ee362e165a51cf1'
ORDER BY `id` DESC LIMIT -17
INFO - 2016-02-01 10:25:59 --> Config Class Initialized
INFO - 2016-02-01 10:25:59 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:25:59 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:25:59 --> Utf8 Class Initialized
INFO - 2016-02-01 10:25:59 --> URI Class Initialized
INFO - 2016-02-01 10:25:59 --> Router Class Initialized
INFO - 2016-02-01 10:25:59 --> Output Class Initialized
INFO - 2016-02-01 10:25:59 --> Security Class Initialized
DEBUG - 2016-02-01 10:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:25:59 --> Input Class Initialized
INFO - 2016-02-01 10:25:59 --> Language Class Initialized
INFO - 2016-02-01 10:25:59 --> Loader Class Initialized
INFO - 2016-02-01 10:25:59 --> Helper loaded: url_helper
INFO - 2016-02-01 10:25:59 --> Helper loaded: file_helper
INFO - 2016-02-01 10:25:59 --> Helper loaded: date_helper
INFO - 2016-02-01 10:25:59 --> Database Driver Class Initialized
INFO - 2016-02-01 10:26:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:26:00 --> Controller Class Initialized
INFO - 2016-02-01 10:26:00 --> Model Class Initialized
INFO - 2016-02-01 10:26:00 --> Model Class Initialized
INFO - 2016-02-01 10:26:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:26:00 --> Pagination Class Initialized
INFO - 2016-02-01 10:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:26:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:26:00 --> Final output sent to browser
DEBUG - 2016-02-01 10:26:00 --> Total execution time: 1.1086
INFO - 2016-02-01 10:26:01 --> Config Class Initialized
INFO - 2016-02-01 10:26:01 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:26:01 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:26:01 --> Utf8 Class Initialized
INFO - 2016-02-01 10:26:01 --> URI Class Initialized
DEBUG - 2016-02-01 10:26:01 --> No URI present. Default controller set.
INFO - 2016-02-01 10:26:01 --> Router Class Initialized
INFO - 2016-02-01 10:26:01 --> Output Class Initialized
INFO - 2016-02-01 10:26:01 --> Security Class Initialized
DEBUG - 2016-02-01 10:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:26:01 --> Input Class Initialized
INFO - 2016-02-01 10:26:01 --> Language Class Initialized
INFO - 2016-02-01 10:26:01 --> Loader Class Initialized
INFO - 2016-02-01 10:26:01 --> Helper loaded: url_helper
INFO - 2016-02-01 10:26:01 --> Helper loaded: file_helper
INFO - 2016-02-01 10:26:01 --> Helper loaded: date_helper
INFO - 2016-02-01 10:26:01 --> Database Driver Class Initialized
INFO - 2016-02-01 10:26:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:26:02 --> Controller Class Initialized
INFO - 2016-02-01 10:26:02 --> Model Class Initialized
INFO - 2016-02-01 10:26:02 --> Model Class Initialized
INFO - 2016-02-01 10:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:26:02 --> Pagination Class Initialized
INFO - 2016-02-01 10:26:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:26:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:26:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:26:02 --> Final output sent to browser
DEBUG - 2016-02-01 10:26:02 --> Total execution time: 1.1334
INFO - 2016-02-01 10:26:04 --> Config Class Initialized
INFO - 2016-02-01 10:26:04 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:26:04 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:26:04 --> Utf8 Class Initialized
INFO - 2016-02-01 10:26:04 --> URI Class Initialized
INFO - 2016-02-01 10:26:04 --> Router Class Initialized
INFO - 2016-02-01 10:26:04 --> Output Class Initialized
INFO - 2016-02-01 10:26:04 --> Security Class Initialized
DEBUG - 2016-02-01 10:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:26:04 --> Input Class Initialized
INFO - 2016-02-01 10:26:04 --> Language Class Initialized
INFO - 2016-02-01 10:26:04 --> Loader Class Initialized
INFO - 2016-02-01 10:26:04 --> Helper loaded: url_helper
INFO - 2016-02-01 10:26:04 --> Helper loaded: file_helper
INFO - 2016-02-01 10:26:04 --> Helper loaded: date_helper
INFO - 2016-02-01 10:26:04 --> Database Driver Class Initialized
INFO - 2016-02-01 10:26:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:26:05 --> Controller Class Initialized
INFO - 2016-02-01 10:26:05 --> Model Class Initialized
INFO - 2016-02-01 10:26:05 --> Model Class Initialized
INFO - 2016-02-01 10:26:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:26:05 --> Pagination Class Initialized
INFO - 2016-02-01 10:26:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:26:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:26:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:26:05 --> Final output sent to browser
DEBUG - 2016-02-01 10:26:05 --> Total execution time: 1.1190
INFO - 2016-02-01 10:26:45 --> Config Class Initialized
INFO - 2016-02-01 10:26:45 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:26:45 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:26:45 --> Utf8 Class Initialized
INFO - 2016-02-01 10:26:45 --> URI Class Initialized
DEBUG - 2016-02-01 10:26:45 --> No URI present. Default controller set.
INFO - 2016-02-01 10:26:45 --> Router Class Initialized
INFO - 2016-02-01 10:26:45 --> Output Class Initialized
INFO - 2016-02-01 10:26:45 --> Security Class Initialized
DEBUG - 2016-02-01 10:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:26:45 --> Input Class Initialized
INFO - 2016-02-01 10:26:45 --> Language Class Initialized
INFO - 2016-02-01 10:26:45 --> Loader Class Initialized
INFO - 2016-02-01 10:26:45 --> Helper loaded: url_helper
INFO - 2016-02-01 10:26:45 --> Helper loaded: file_helper
INFO - 2016-02-01 10:26:45 --> Helper loaded: date_helper
INFO - 2016-02-01 10:26:45 --> Database Driver Class Initialized
INFO - 2016-02-01 10:26:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:26:46 --> Controller Class Initialized
INFO - 2016-02-01 10:26:46 --> Model Class Initialized
INFO - 2016-02-01 10:26:46 --> Model Class Initialized
INFO - 2016-02-01 10:26:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:26:46 --> Pagination Class Initialized
INFO - 2016-02-01 10:26:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:26:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:26:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:26:46 --> Final output sent to browser
DEBUG - 2016-02-01 10:26:46 --> Total execution time: 1.1418
INFO - 2016-02-01 10:26:47 --> Config Class Initialized
INFO - 2016-02-01 10:26:47 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:26:47 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:26:47 --> Utf8 Class Initialized
INFO - 2016-02-01 10:26:47 --> URI Class Initialized
INFO - 2016-02-01 10:26:47 --> Router Class Initialized
INFO - 2016-02-01 10:26:47 --> Output Class Initialized
INFO - 2016-02-01 10:26:47 --> Security Class Initialized
DEBUG - 2016-02-01 10:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:26:47 --> Input Class Initialized
INFO - 2016-02-01 10:26:47 --> Language Class Initialized
INFO - 2016-02-01 10:26:47 --> Loader Class Initialized
INFO - 2016-02-01 10:26:47 --> Helper loaded: url_helper
INFO - 2016-02-01 10:26:47 --> Helper loaded: file_helper
INFO - 2016-02-01 10:26:47 --> Helper loaded: date_helper
INFO - 2016-02-01 10:26:47 --> Database Driver Class Initialized
INFO - 2016-02-01 10:26:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:26:48 --> Controller Class Initialized
INFO - 2016-02-01 10:26:48 --> Model Class Initialized
INFO - 2016-02-01 10:26:48 --> Model Class Initialized
INFO - 2016-02-01 10:26:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:26:49 --> Pagination Class Initialized
INFO - 2016-02-01 10:26:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:26:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:26:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:26:49 --> Final output sent to browser
DEBUG - 2016-02-01 10:26:49 --> Total execution time: 1.1180
INFO - 2016-02-01 10:26:50 --> Config Class Initialized
INFO - 2016-02-01 10:26:50 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:26:50 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:26:50 --> Utf8 Class Initialized
INFO - 2016-02-01 10:26:50 --> URI Class Initialized
INFO - 2016-02-01 10:26:50 --> Router Class Initialized
INFO - 2016-02-01 10:26:50 --> Output Class Initialized
INFO - 2016-02-01 10:26:50 --> Security Class Initialized
DEBUG - 2016-02-01 10:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:26:50 --> Input Class Initialized
INFO - 2016-02-01 10:26:50 --> Language Class Initialized
INFO - 2016-02-01 10:26:50 --> Loader Class Initialized
INFO - 2016-02-01 10:26:50 --> Helper loaded: url_helper
INFO - 2016-02-01 10:26:50 --> Helper loaded: file_helper
INFO - 2016-02-01 10:26:50 --> Helper loaded: date_helper
INFO - 2016-02-01 10:26:50 --> Database Driver Class Initialized
INFO - 2016-02-01 10:26:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:26:51 --> Controller Class Initialized
INFO - 2016-02-01 10:26:51 --> Model Class Initialized
INFO - 2016-02-01 10:26:52 --> Model Class Initialized
INFO - 2016-02-01 10:26:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:26:52 --> Pagination Class Initialized
INFO - 2016-02-01 10:26:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:26:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:26:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:26:52 --> Final output sent to browser
DEBUG - 2016-02-01 10:26:52 --> Total execution time: 1.1319
INFO - 2016-02-01 10:27:00 --> Config Class Initialized
INFO - 2016-02-01 10:27:00 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:27:00 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:27:00 --> Utf8 Class Initialized
INFO - 2016-02-01 10:27:00 --> URI Class Initialized
INFO - 2016-02-01 10:27:00 --> Router Class Initialized
INFO - 2016-02-01 10:27:00 --> Output Class Initialized
INFO - 2016-02-01 10:27:00 --> Security Class Initialized
DEBUG - 2016-02-01 10:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:27:00 --> Input Class Initialized
INFO - 2016-02-01 10:27:00 --> Language Class Initialized
INFO - 2016-02-01 10:27:00 --> Loader Class Initialized
INFO - 2016-02-01 10:27:00 --> Helper loaded: url_helper
INFO - 2016-02-01 10:27:00 --> Helper loaded: file_helper
INFO - 2016-02-01 10:27:00 --> Helper loaded: date_helper
INFO - 2016-02-01 10:27:00 --> Database Driver Class Initialized
INFO - 2016-02-01 10:27:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:27:01 --> Controller Class Initialized
INFO - 2016-02-01 10:27:01 --> Model Class Initialized
INFO - 2016-02-01 10:27:01 --> Model Class Initialized
INFO - 2016-02-01 10:27:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:27:01 --> Pagination Class Initialized
INFO - 2016-02-01 10:27:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:27:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:27:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:27:01 --> Final output sent to browser
DEBUG - 2016-02-01 10:27:01 --> Total execution time: 1.1155
INFO - 2016-02-01 10:27:04 --> Config Class Initialized
INFO - 2016-02-01 10:27:04 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:27:04 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:27:04 --> Utf8 Class Initialized
INFO - 2016-02-01 10:27:04 --> URI Class Initialized
INFO - 2016-02-01 10:27:04 --> Router Class Initialized
INFO - 2016-02-01 10:27:04 --> Output Class Initialized
INFO - 2016-02-01 10:27:04 --> Security Class Initialized
DEBUG - 2016-02-01 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:27:04 --> Input Class Initialized
INFO - 2016-02-01 10:27:04 --> Language Class Initialized
INFO - 2016-02-01 10:27:04 --> Loader Class Initialized
INFO - 2016-02-01 10:27:04 --> Helper loaded: url_helper
INFO - 2016-02-01 10:27:04 --> Helper loaded: file_helper
INFO - 2016-02-01 10:27:04 --> Helper loaded: date_helper
INFO - 2016-02-01 10:27:04 --> Database Driver Class Initialized
INFO - 2016-02-01 10:27:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:27:05 --> Controller Class Initialized
INFO - 2016-02-01 10:27:05 --> Model Class Initialized
INFO - 2016-02-01 10:27:05 --> Model Class Initialized
INFO - 2016-02-01 10:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:27:05 --> Pagination Class Initialized
INFO - 2016-02-01 10:27:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:27:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:27:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:27:05 --> Final output sent to browser
DEBUG - 2016-02-01 10:27:05 --> Total execution time: 1.0939
INFO - 2016-02-01 10:37:11 --> Config Class Initialized
INFO - 2016-02-01 10:37:11 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:37:11 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:37:11 --> Utf8 Class Initialized
INFO - 2016-02-01 10:37:11 --> URI Class Initialized
INFO - 2016-02-01 10:37:11 --> Router Class Initialized
INFO - 2016-02-01 10:37:11 --> Output Class Initialized
INFO - 2016-02-01 10:37:11 --> Security Class Initialized
DEBUG - 2016-02-01 10:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:37:11 --> Input Class Initialized
INFO - 2016-02-01 10:37:11 --> Language Class Initialized
INFO - 2016-02-01 10:37:11 --> Loader Class Initialized
INFO - 2016-02-01 10:37:11 --> Helper loaded: url_helper
INFO - 2016-02-01 10:37:11 --> Helper loaded: file_helper
INFO - 2016-02-01 10:37:11 --> Helper loaded: date_helper
INFO - 2016-02-01 10:37:11 --> Database Driver Class Initialized
INFO - 2016-02-01 10:37:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:37:12 --> Controller Class Initialized
INFO - 2016-02-01 10:37:12 --> Model Class Initialized
INFO - 2016-02-01 10:37:12 --> Model Class Initialized
INFO - 2016-02-01 10:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:37:12 --> Pagination Class Initialized
INFO - 2016-02-01 10:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:37:12 --> Final output sent to browser
DEBUG - 2016-02-01 10:37:12 --> Total execution time: 1.1140
INFO - 2016-02-01 10:37:15 --> Config Class Initialized
INFO - 2016-02-01 10:37:15 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:37:15 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:37:15 --> Utf8 Class Initialized
INFO - 2016-02-01 10:37:15 --> URI Class Initialized
INFO - 2016-02-01 10:37:15 --> Router Class Initialized
INFO - 2016-02-01 10:37:15 --> Output Class Initialized
INFO - 2016-02-01 10:37:15 --> Security Class Initialized
DEBUG - 2016-02-01 10:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:37:15 --> Input Class Initialized
INFO - 2016-02-01 10:37:15 --> Language Class Initialized
INFO - 2016-02-01 10:37:15 --> Loader Class Initialized
INFO - 2016-02-01 10:37:15 --> Helper loaded: url_helper
INFO - 2016-02-01 10:37:15 --> Helper loaded: file_helper
INFO - 2016-02-01 10:37:15 --> Helper loaded: date_helper
INFO - 2016-02-01 10:37:15 --> Database Driver Class Initialized
INFO - 2016-02-01 10:37:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:37:16 --> Controller Class Initialized
INFO - 2016-02-01 10:37:16 --> Model Class Initialized
INFO - 2016-02-01 10:37:16 --> Model Class Initialized
INFO - 2016-02-01 10:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:37:16 --> Pagination Class Initialized
INFO - 2016-02-01 10:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:37:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-17, 17' at line 4 - Invalid query: SELECT *
FROM `jdmain`
ORDER BY `id` DESC
 LIMIT -17, 17
INFO - 2016-02-01 10:37:16 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-01 10:38:55 --> Config Class Initialized
INFO - 2016-02-01 10:38:55 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:38:55 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:38:55 --> Utf8 Class Initialized
INFO - 2016-02-01 10:38:55 --> URI Class Initialized
INFO - 2016-02-01 10:38:55 --> Router Class Initialized
INFO - 2016-02-01 10:38:55 --> Output Class Initialized
INFO - 2016-02-01 10:38:55 --> Security Class Initialized
DEBUG - 2016-02-01 10:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:38:55 --> Input Class Initialized
INFO - 2016-02-01 10:38:55 --> Language Class Initialized
INFO - 2016-02-01 10:38:55 --> Loader Class Initialized
INFO - 2016-02-01 10:38:55 --> Helper loaded: url_helper
INFO - 2016-02-01 10:38:55 --> Helper loaded: file_helper
INFO - 2016-02-01 10:38:55 --> Helper loaded: date_helper
INFO - 2016-02-01 10:38:56 --> Database Driver Class Initialized
INFO - 2016-02-01 10:38:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:38:57 --> Controller Class Initialized
INFO - 2016-02-01 10:38:57 --> Model Class Initialized
INFO - 2016-02-01 10:38:57 --> Model Class Initialized
INFO - 2016-02-01 10:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:38:57 --> Pagination Class Initialized
INFO - 2016-02-01 10:38:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:38:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:38:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:38:57 --> Final output sent to browser
DEBUG - 2016-02-01 10:38:57 --> Total execution time: 1.1417
INFO - 2016-02-01 10:38:58 --> Config Class Initialized
INFO - 2016-02-01 10:38:58 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:38:58 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:38:58 --> Utf8 Class Initialized
INFO - 2016-02-01 10:38:58 --> URI Class Initialized
INFO - 2016-02-01 10:38:58 --> Router Class Initialized
INFO - 2016-02-01 10:38:58 --> Output Class Initialized
INFO - 2016-02-01 10:38:58 --> Security Class Initialized
DEBUG - 2016-02-01 10:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:38:58 --> Input Class Initialized
INFO - 2016-02-01 10:38:58 --> Language Class Initialized
INFO - 2016-02-01 10:38:58 --> Loader Class Initialized
INFO - 2016-02-01 10:38:58 --> Helper loaded: url_helper
INFO - 2016-02-01 10:38:58 --> Helper loaded: file_helper
INFO - 2016-02-01 10:38:58 --> Helper loaded: date_helper
INFO - 2016-02-01 10:38:58 --> Database Driver Class Initialized
INFO - 2016-02-01 10:39:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:39:00 --> Controller Class Initialized
INFO - 2016-02-01 10:39:00 --> Model Class Initialized
INFO - 2016-02-01 10:39:00 --> Model Class Initialized
INFO - 2016-02-01 10:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:39:00 --> Pagination Class Initialized
INFO - 2016-02-01 10:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-01 10:39:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 15
INFO - 2016-02-01 10:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:39:00 --> Final output sent to browser
DEBUG - 2016-02-01 10:39:00 --> Total execution time: 1.1337
INFO - 2016-02-01 10:39:12 --> Config Class Initialized
INFO - 2016-02-01 10:39:12 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:39:12 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:39:12 --> Utf8 Class Initialized
INFO - 2016-02-01 10:39:12 --> URI Class Initialized
DEBUG - 2016-02-01 10:39:12 --> No URI present. Default controller set.
INFO - 2016-02-01 10:39:12 --> Router Class Initialized
INFO - 2016-02-01 10:39:12 --> Output Class Initialized
INFO - 2016-02-01 10:39:12 --> Security Class Initialized
DEBUG - 2016-02-01 10:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:39:12 --> Input Class Initialized
INFO - 2016-02-01 10:39:12 --> Language Class Initialized
INFO - 2016-02-01 10:39:12 --> Loader Class Initialized
INFO - 2016-02-01 10:39:12 --> Helper loaded: url_helper
INFO - 2016-02-01 10:39:12 --> Helper loaded: file_helper
INFO - 2016-02-01 10:39:12 --> Helper loaded: date_helper
INFO - 2016-02-01 10:39:12 --> Database Driver Class Initialized
INFO - 2016-02-01 10:39:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:39:13 --> Controller Class Initialized
INFO - 2016-02-01 10:39:13 --> Model Class Initialized
INFO - 2016-02-01 10:39:13 --> Model Class Initialized
INFO - 2016-02-01 10:39:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:39:13 --> Pagination Class Initialized
INFO - 2016-02-01 10:39:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:39:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:39:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:39:13 --> Final output sent to browser
DEBUG - 2016-02-01 10:39:13 --> Total execution time: 1.1632
INFO - 2016-02-01 10:39:15 --> Config Class Initialized
INFO - 2016-02-01 10:39:15 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:39:15 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:39:15 --> Utf8 Class Initialized
INFO - 2016-02-01 10:39:15 --> URI Class Initialized
INFO - 2016-02-01 10:39:15 --> Router Class Initialized
INFO - 2016-02-01 10:39:15 --> Output Class Initialized
INFO - 2016-02-01 10:39:15 --> Security Class Initialized
DEBUG - 2016-02-01 10:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:39:15 --> Input Class Initialized
INFO - 2016-02-01 10:39:15 --> Language Class Initialized
INFO - 2016-02-01 10:39:15 --> Loader Class Initialized
INFO - 2016-02-01 10:39:15 --> Helper loaded: url_helper
INFO - 2016-02-01 10:39:15 --> Helper loaded: file_helper
INFO - 2016-02-01 10:39:15 --> Helper loaded: date_helper
INFO - 2016-02-01 10:39:15 --> Database Driver Class Initialized
INFO - 2016-02-01 10:39:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:39:16 --> Controller Class Initialized
INFO - 2016-02-01 10:39:16 --> Model Class Initialized
INFO - 2016-02-01 10:39:16 --> Model Class Initialized
INFO - 2016-02-01 10:39:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:39:16 --> Pagination Class Initialized
INFO - 2016-02-01 10:39:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:39:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:39:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:39:16 --> Final output sent to browser
DEBUG - 2016-02-01 10:39:16 --> Total execution time: 1.0916
INFO - 2016-02-01 10:39:18 --> Config Class Initialized
INFO - 2016-02-01 10:39:18 --> Hooks Class Initialized
DEBUG - 2016-02-01 10:39:18 --> UTF-8 Support Enabled
INFO - 2016-02-01 10:39:18 --> Utf8 Class Initialized
INFO - 2016-02-01 10:39:18 --> URI Class Initialized
INFO - 2016-02-01 10:39:18 --> Router Class Initialized
INFO - 2016-02-01 10:39:18 --> Output Class Initialized
INFO - 2016-02-01 10:39:18 --> Security Class Initialized
DEBUG - 2016-02-01 10:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 10:39:18 --> Input Class Initialized
INFO - 2016-02-01 10:39:18 --> Language Class Initialized
INFO - 2016-02-01 10:39:18 --> Loader Class Initialized
INFO - 2016-02-01 10:39:18 --> Helper loaded: url_helper
INFO - 2016-02-01 10:39:18 --> Helper loaded: file_helper
INFO - 2016-02-01 10:39:18 --> Helper loaded: date_helper
INFO - 2016-02-01 10:39:18 --> Database Driver Class Initialized
INFO - 2016-02-01 10:39:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 10:39:19 --> Controller Class Initialized
INFO - 2016-02-01 10:39:19 --> Model Class Initialized
INFO - 2016-02-01 10:39:19 --> Model Class Initialized
INFO - 2016-02-01 10:39:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 10:39:19 --> Pagination Class Initialized
INFO - 2016-02-01 10:39:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 10:39:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 10:39:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 10:39:19 --> Final output sent to browser
DEBUG - 2016-02-01 10:39:19 --> Total execution time: 1.1036
INFO - 2016-02-01 11:14:32 --> Config Class Initialized
INFO - 2016-02-01 11:14:32 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:14:32 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:14:32 --> Utf8 Class Initialized
INFO - 2016-02-01 11:14:32 --> URI Class Initialized
INFO - 2016-02-01 11:14:32 --> Router Class Initialized
INFO - 2016-02-01 11:14:32 --> Output Class Initialized
INFO - 2016-02-01 11:14:32 --> Security Class Initialized
DEBUG - 2016-02-01 11:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:14:32 --> Input Class Initialized
INFO - 2016-02-01 11:14:32 --> Language Class Initialized
INFO - 2016-02-01 11:14:32 --> Loader Class Initialized
INFO - 2016-02-01 11:14:32 --> Helper loaded: url_helper
INFO - 2016-02-01 11:14:32 --> Helper loaded: file_helper
INFO - 2016-02-01 11:14:32 --> Helper loaded: date_helper
INFO - 2016-02-01 11:14:32 --> Database Driver Class Initialized
INFO - 2016-02-01 11:14:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:14:33 --> Controller Class Initialized
INFO - 2016-02-01 11:14:33 --> Model Class Initialized
INFO - 2016-02-01 11:14:33 --> Model Class Initialized
INFO - 2016-02-01 11:14:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:14:33 --> Pagination Class Initialized
INFO - 2016-02-01 11:14:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:14:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:14:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:14:33 --> Final output sent to browser
DEBUG - 2016-02-01 11:14:33 --> Total execution time: 1.1013
INFO - 2016-02-01 11:14:36 --> Config Class Initialized
INFO - 2016-02-01 11:14:36 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:14:36 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:14:36 --> Utf8 Class Initialized
INFO - 2016-02-01 11:14:36 --> URI Class Initialized
INFO - 2016-02-01 11:14:36 --> Router Class Initialized
INFO - 2016-02-01 11:14:36 --> Output Class Initialized
INFO - 2016-02-01 11:14:36 --> Security Class Initialized
DEBUG - 2016-02-01 11:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:14:36 --> Input Class Initialized
INFO - 2016-02-01 11:14:36 --> Language Class Initialized
INFO - 2016-02-01 11:14:36 --> Loader Class Initialized
INFO - 2016-02-01 11:14:36 --> Helper loaded: url_helper
INFO - 2016-02-01 11:14:36 --> Helper loaded: file_helper
INFO - 2016-02-01 11:14:36 --> Helper loaded: date_helper
INFO - 2016-02-01 11:14:36 --> Database Driver Class Initialized
INFO - 2016-02-01 11:14:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:14:37 --> Controller Class Initialized
INFO - 2016-02-01 11:14:37 --> Model Class Initialized
INFO - 2016-02-01 11:14:37 --> Model Class Initialized
INFO - 2016-02-01 11:14:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:14:37 --> Pagination Class Initialized
INFO - 2016-02-01 11:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:14:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:14:37 --> Final output sent to browser
DEBUG - 2016-02-01 11:14:37 --> Total execution time: 1.1418
INFO - 2016-02-01 11:29:04 --> Config Class Initialized
INFO - 2016-02-01 11:29:04 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:29:04 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:29:04 --> Utf8 Class Initialized
INFO - 2016-02-01 11:29:04 --> URI Class Initialized
DEBUG - 2016-02-01 11:29:04 --> No URI present. Default controller set.
INFO - 2016-02-01 11:29:04 --> Router Class Initialized
INFO - 2016-02-01 11:29:04 --> Output Class Initialized
INFO - 2016-02-01 11:29:04 --> Security Class Initialized
DEBUG - 2016-02-01 11:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:29:04 --> Input Class Initialized
INFO - 2016-02-01 11:29:04 --> Language Class Initialized
INFO - 2016-02-01 11:29:04 --> Loader Class Initialized
INFO - 2016-02-01 11:29:04 --> Helper loaded: url_helper
INFO - 2016-02-01 11:29:04 --> Helper loaded: file_helper
INFO - 2016-02-01 11:29:04 --> Helper loaded: date_helper
INFO - 2016-02-01 11:29:04 --> Database Driver Class Initialized
INFO - 2016-02-01 11:29:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:29:05 --> Controller Class Initialized
INFO - 2016-02-01 11:29:05 --> Model Class Initialized
INFO - 2016-02-01 11:29:05 --> Model Class Initialized
INFO - 2016-02-01 11:29:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:29:05 --> Pagination Class Initialized
INFO - 2016-02-01 11:29:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:29:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:29:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:29:05 --> Final output sent to browser
DEBUG - 2016-02-01 11:29:05 --> Total execution time: 1.1614
INFO - 2016-02-01 11:29:11 --> Config Class Initialized
INFO - 2016-02-01 11:29:11 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:29:11 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:29:11 --> Utf8 Class Initialized
INFO - 2016-02-01 11:29:11 --> URI Class Initialized
INFO - 2016-02-01 11:29:11 --> Router Class Initialized
INFO - 2016-02-01 11:29:11 --> Output Class Initialized
INFO - 2016-02-01 11:29:11 --> Security Class Initialized
DEBUG - 2016-02-01 11:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:29:11 --> Input Class Initialized
INFO - 2016-02-01 11:29:11 --> Language Class Initialized
INFO - 2016-02-01 11:29:11 --> Loader Class Initialized
INFO - 2016-02-01 11:29:11 --> Helper loaded: url_helper
INFO - 2016-02-01 11:29:11 --> Helper loaded: file_helper
INFO - 2016-02-01 11:29:11 --> Helper loaded: date_helper
INFO - 2016-02-01 11:29:11 --> Database Driver Class Initialized
INFO - 2016-02-01 11:29:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:29:12 --> Controller Class Initialized
INFO - 2016-02-01 11:29:12 --> Model Class Initialized
INFO - 2016-02-01 11:29:12 --> Model Class Initialized
INFO - 2016-02-01 11:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:29:12 --> Pagination Class Initialized
INFO - 2016-02-01 11:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 11:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:29:12 --> Final output sent to browser
DEBUG - 2016-02-01 11:29:12 --> Total execution time: 1.1441
INFO - 2016-02-01 11:29:14 --> Config Class Initialized
INFO - 2016-02-01 11:29:14 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:29:14 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:29:14 --> Utf8 Class Initialized
INFO - 2016-02-01 11:29:14 --> URI Class Initialized
INFO - 2016-02-01 11:29:14 --> Router Class Initialized
INFO - 2016-02-01 11:29:14 --> Output Class Initialized
INFO - 2016-02-01 11:29:14 --> Security Class Initialized
DEBUG - 2016-02-01 11:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:29:14 --> Input Class Initialized
INFO - 2016-02-01 11:29:14 --> Language Class Initialized
INFO - 2016-02-01 11:29:14 --> Loader Class Initialized
INFO - 2016-02-01 11:29:14 --> Helper loaded: url_helper
INFO - 2016-02-01 11:29:14 --> Helper loaded: file_helper
INFO - 2016-02-01 11:29:14 --> Helper loaded: date_helper
INFO - 2016-02-01 11:29:14 --> Database Driver Class Initialized
INFO - 2016-02-01 11:29:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:29:15 --> Controller Class Initialized
INFO - 2016-02-01 11:29:15 --> Model Class Initialized
INFO - 2016-02-01 11:29:15 --> Model Class Initialized
INFO - 2016-02-01 11:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:29:15 --> Pagination Class Initialized
INFO - 2016-02-01 11:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 11:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:29:15 --> Final output sent to browser
DEBUG - 2016-02-01 11:29:15 --> Total execution time: 1.1481
INFO - 2016-02-01 11:29:25 --> Config Class Initialized
INFO - 2016-02-01 11:29:25 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:29:25 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:29:25 --> Utf8 Class Initialized
INFO - 2016-02-01 11:29:25 --> URI Class Initialized
DEBUG - 2016-02-01 11:29:25 --> No URI present. Default controller set.
INFO - 2016-02-01 11:29:25 --> Router Class Initialized
INFO - 2016-02-01 11:29:25 --> Output Class Initialized
INFO - 2016-02-01 11:29:25 --> Security Class Initialized
DEBUG - 2016-02-01 11:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:29:25 --> Input Class Initialized
INFO - 2016-02-01 11:29:25 --> Language Class Initialized
INFO - 2016-02-01 11:29:25 --> Loader Class Initialized
INFO - 2016-02-01 11:29:25 --> Helper loaded: url_helper
INFO - 2016-02-01 11:29:25 --> Helper loaded: file_helper
INFO - 2016-02-01 11:29:25 --> Helper loaded: date_helper
INFO - 2016-02-01 11:29:25 --> Database Driver Class Initialized
INFO - 2016-02-01 11:29:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:29:27 --> Controller Class Initialized
INFO - 2016-02-01 11:29:27 --> Model Class Initialized
INFO - 2016-02-01 11:29:27 --> Model Class Initialized
INFO - 2016-02-01 11:29:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:29:27 --> Pagination Class Initialized
INFO - 2016-02-01 11:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:29:27 --> Final output sent to browser
DEBUG - 2016-02-01 11:29:27 --> Total execution time: 1.1074
INFO - 2016-02-01 11:29:28 --> Config Class Initialized
INFO - 2016-02-01 11:29:28 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:29:28 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:29:28 --> Utf8 Class Initialized
INFO - 2016-02-01 11:29:28 --> URI Class Initialized
INFO - 2016-02-01 11:29:28 --> Router Class Initialized
INFO - 2016-02-01 11:29:28 --> Output Class Initialized
INFO - 2016-02-01 11:29:28 --> Security Class Initialized
DEBUG - 2016-02-01 11:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:29:28 --> Input Class Initialized
INFO - 2016-02-01 11:29:28 --> Language Class Initialized
INFO - 2016-02-01 11:29:28 --> Loader Class Initialized
INFO - 2016-02-01 11:29:28 --> Helper loaded: url_helper
INFO - 2016-02-01 11:29:28 --> Helper loaded: file_helper
INFO - 2016-02-01 11:29:28 --> Helper loaded: date_helper
INFO - 2016-02-01 11:29:28 --> Database Driver Class Initialized
INFO - 2016-02-01 11:29:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:29:29 --> Controller Class Initialized
INFO - 2016-02-01 11:29:29 --> Model Class Initialized
INFO - 2016-02-01 11:29:29 --> Model Class Initialized
INFO - 2016-02-01 11:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:29:29 --> Pagination Class Initialized
INFO - 2016-02-01 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:29:29 --> Final output sent to browser
DEBUG - 2016-02-01 11:29:29 --> Total execution time: 1.1068
INFO - 2016-02-01 11:29:31 --> Config Class Initialized
INFO - 2016-02-01 11:29:31 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:29:31 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:29:31 --> Utf8 Class Initialized
INFO - 2016-02-01 11:29:31 --> URI Class Initialized
INFO - 2016-02-01 11:29:31 --> Router Class Initialized
INFO - 2016-02-01 11:29:31 --> Output Class Initialized
INFO - 2016-02-01 11:29:31 --> Security Class Initialized
DEBUG - 2016-02-01 11:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:29:31 --> Input Class Initialized
INFO - 2016-02-01 11:29:31 --> Language Class Initialized
INFO - 2016-02-01 11:29:31 --> Loader Class Initialized
INFO - 2016-02-01 11:29:31 --> Helper loaded: url_helper
INFO - 2016-02-01 11:29:31 --> Helper loaded: file_helper
INFO - 2016-02-01 11:29:31 --> Helper loaded: date_helper
INFO - 2016-02-01 11:29:31 --> Database Driver Class Initialized
INFO - 2016-02-01 11:29:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:29:32 --> Controller Class Initialized
INFO - 2016-02-01 11:29:32 --> Model Class Initialized
INFO - 2016-02-01 11:29:32 --> Model Class Initialized
INFO - 2016-02-01 11:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:29:32 --> Pagination Class Initialized
INFO - 2016-02-01 11:29:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:29:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:29:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:29:32 --> Final output sent to browser
DEBUG - 2016-02-01 11:29:32 --> Total execution time: 1.0914
INFO - 2016-02-01 11:30:07 --> Config Class Initialized
INFO - 2016-02-01 11:30:07 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:30:07 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:30:07 --> Utf8 Class Initialized
INFO - 2016-02-01 11:30:07 --> URI Class Initialized
INFO - 2016-02-01 11:30:07 --> Router Class Initialized
INFO - 2016-02-01 11:30:07 --> Output Class Initialized
INFO - 2016-02-01 11:30:07 --> Security Class Initialized
DEBUG - 2016-02-01 11:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:30:07 --> Input Class Initialized
INFO - 2016-02-01 11:30:07 --> Language Class Initialized
INFO - 2016-02-01 11:30:07 --> Loader Class Initialized
INFO - 2016-02-01 11:30:07 --> Helper loaded: url_helper
INFO - 2016-02-01 11:30:07 --> Helper loaded: file_helper
INFO - 2016-02-01 11:30:07 --> Helper loaded: date_helper
INFO - 2016-02-01 11:30:07 --> Database Driver Class Initialized
INFO - 2016-02-01 11:30:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:30:08 --> Controller Class Initialized
INFO - 2016-02-01 11:30:08 --> Model Class Initialized
INFO - 2016-02-01 11:30:08 --> Model Class Initialized
INFO - 2016-02-01 11:30:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:30:08 --> Pagination Class Initialized
INFO - 2016-02-01 11:30:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:30:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 11:30:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:30:08 --> Final output sent to browser
DEBUG - 2016-02-01 11:30:08 --> Total execution time: 1.1044
INFO - 2016-02-01 11:30:11 --> Config Class Initialized
INFO - 2016-02-01 11:30:11 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:30:11 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:30:11 --> Utf8 Class Initialized
INFO - 2016-02-01 11:30:11 --> URI Class Initialized
INFO - 2016-02-01 11:30:11 --> Router Class Initialized
INFO - 2016-02-01 11:30:11 --> Output Class Initialized
INFO - 2016-02-01 11:30:11 --> Security Class Initialized
DEBUG - 2016-02-01 11:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:30:11 --> Input Class Initialized
INFO - 2016-02-01 11:30:11 --> Language Class Initialized
INFO - 2016-02-01 11:30:11 --> Loader Class Initialized
INFO - 2016-02-01 11:30:11 --> Helper loaded: url_helper
INFO - 2016-02-01 11:30:11 --> Helper loaded: file_helper
INFO - 2016-02-01 11:30:11 --> Helper loaded: date_helper
INFO - 2016-02-01 11:30:11 --> Database Driver Class Initialized
INFO - 2016-02-01 11:30:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:30:12 --> Controller Class Initialized
INFO - 2016-02-01 11:30:12 --> Model Class Initialized
INFO - 2016-02-01 11:30:12 --> Model Class Initialized
INFO - 2016-02-01 11:30:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:30:12 --> Pagination Class Initialized
INFO - 2016-02-01 11:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 11:30:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:30:12 --> Final output sent to browser
DEBUG - 2016-02-01 11:30:12 --> Total execution time: 1.1422
INFO - 2016-02-01 11:30:15 --> Config Class Initialized
INFO - 2016-02-01 11:30:15 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:30:15 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:30:15 --> Utf8 Class Initialized
INFO - 2016-02-01 11:30:15 --> URI Class Initialized
INFO - 2016-02-01 11:30:15 --> Router Class Initialized
INFO - 2016-02-01 11:30:15 --> Output Class Initialized
INFO - 2016-02-01 11:30:15 --> Security Class Initialized
DEBUG - 2016-02-01 11:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:30:15 --> Input Class Initialized
INFO - 2016-02-01 11:30:15 --> Language Class Initialized
INFO - 2016-02-01 11:30:15 --> Loader Class Initialized
INFO - 2016-02-01 11:30:15 --> Helper loaded: url_helper
INFO - 2016-02-01 11:30:15 --> Helper loaded: file_helper
INFO - 2016-02-01 11:30:15 --> Helper loaded: date_helper
INFO - 2016-02-01 11:30:15 --> Database Driver Class Initialized
INFO - 2016-02-01 11:30:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:30:16 --> Controller Class Initialized
INFO - 2016-02-01 11:30:16 --> Model Class Initialized
INFO - 2016-02-01 11:30:16 --> Model Class Initialized
INFO - 2016-02-01 11:30:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:30:16 --> Pagination Class Initialized
INFO - 2016-02-01 11:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 11:30:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:30:16 --> Final output sent to browser
DEBUG - 2016-02-01 11:30:16 --> Total execution time: 1.0937
INFO - 2016-02-01 11:30:23 --> Config Class Initialized
INFO - 2016-02-01 11:30:23 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:30:23 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:30:24 --> Utf8 Class Initialized
INFO - 2016-02-01 11:30:24 --> URI Class Initialized
INFO - 2016-02-01 11:30:24 --> Router Class Initialized
INFO - 2016-02-01 11:30:24 --> Output Class Initialized
INFO - 2016-02-01 11:30:24 --> Security Class Initialized
DEBUG - 2016-02-01 11:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:30:24 --> Input Class Initialized
INFO - 2016-02-01 11:30:24 --> Language Class Initialized
INFO - 2016-02-01 11:30:24 --> Loader Class Initialized
INFO - 2016-02-01 11:30:24 --> Helper loaded: url_helper
INFO - 2016-02-01 11:30:24 --> Helper loaded: file_helper
INFO - 2016-02-01 11:30:24 --> Helper loaded: date_helper
INFO - 2016-02-01 11:30:24 --> Database Driver Class Initialized
INFO - 2016-02-01 11:30:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:30:25 --> Controller Class Initialized
INFO - 2016-02-01 11:30:25 --> Model Class Initialized
INFO - 2016-02-01 11:30:25 --> Model Class Initialized
INFO - 2016-02-01 11:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:30:25 --> Pagination Class Initialized
INFO - 2016-02-01 11:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 11:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:30:25 --> Final output sent to browser
DEBUG - 2016-02-01 11:30:25 --> Total execution time: 1.1408
INFO - 2016-02-01 11:32:01 --> Config Class Initialized
INFO - 2016-02-01 11:32:01 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:32:01 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:32:01 --> Utf8 Class Initialized
INFO - 2016-02-01 11:32:01 --> URI Class Initialized
INFO - 2016-02-01 11:32:01 --> Router Class Initialized
INFO - 2016-02-01 11:32:01 --> Output Class Initialized
INFO - 2016-02-01 11:32:01 --> Security Class Initialized
DEBUG - 2016-02-01 11:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:32:01 --> Input Class Initialized
INFO - 2016-02-01 11:32:01 --> Language Class Initialized
INFO - 2016-02-01 11:32:01 --> Loader Class Initialized
INFO - 2016-02-01 11:32:01 --> Helper loaded: url_helper
INFO - 2016-02-01 11:32:01 --> Helper loaded: file_helper
INFO - 2016-02-01 11:32:01 --> Helper loaded: date_helper
INFO - 2016-02-01 11:32:01 --> Database Driver Class Initialized
INFO - 2016-02-01 11:32:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:32:02 --> Controller Class Initialized
INFO - 2016-02-01 11:32:02 --> Model Class Initialized
INFO - 2016-02-01 11:32:02 --> Model Class Initialized
INFO - 2016-02-01 11:32:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:32:02 --> Pagination Class Initialized
INFO - 2016-02-01 11:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 11:32:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:32:02 --> Final output sent to browser
DEBUG - 2016-02-01 11:32:02 --> Total execution time: 1.0893
INFO - 2016-02-01 11:32:05 --> Config Class Initialized
INFO - 2016-02-01 11:32:05 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:32:05 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:32:05 --> Utf8 Class Initialized
INFO - 2016-02-01 11:32:05 --> URI Class Initialized
INFO - 2016-02-01 11:32:05 --> Router Class Initialized
INFO - 2016-02-01 11:32:05 --> Output Class Initialized
INFO - 2016-02-01 11:32:05 --> Security Class Initialized
DEBUG - 2016-02-01 11:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:32:05 --> Input Class Initialized
INFO - 2016-02-01 11:32:05 --> Language Class Initialized
INFO - 2016-02-01 11:32:05 --> Loader Class Initialized
INFO - 2016-02-01 11:32:05 --> Helper loaded: url_helper
INFO - 2016-02-01 11:32:05 --> Helper loaded: file_helper
INFO - 2016-02-01 11:32:05 --> Helper loaded: date_helper
INFO - 2016-02-01 11:32:05 --> Database Driver Class Initialized
INFO - 2016-02-01 11:32:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:32:06 --> Controller Class Initialized
INFO - 2016-02-01 11:32:06 --> Model Class Initialized
INFO - 2016-02-01 11:32:06 --> Model Class Initialized
INFO - 2016-02-01 11:32:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:32:06 --> Pagination Class Initialized
INFO - 2016-02-01 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:32:06 --> Helper loaded: text_helper
INFO - 2016-02-01 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:32:06 --> Final output sent to browser
DEBUG - 2016-02-01 11:32:06 --> Total execution time: 1.1840
INFO - 2016-02-01 11:32:13 --> Config Class Initialized
INFO - 2016-02-01 11:32:13 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:32:13 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:32:13 --> Utf8 Class Initialized
INFO - 2016-02-01 11:32:13 --> URI Class Initialized
DEBUG - 2016-02-01 11:32:13 --> No URI present. Default controller set.
INFO - 2016-02-01 11:32:13 --> Router Class Initialized
INFO - 2016-02-01 11:32:13 --> Output Class Initialized
INFO - 2016-02-01 11:32:13 --> Security Class Initialized
DEBUG - 2016-02-01 11:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:32:13 --> Input Class Initialized
INFO - 2016-02-01 11:32:13 --> Language Class Initialized
INFO - 2016-02-01 11:32:13 --> Loader Class Initialized
INFO - 2016-02-01 11:32:13 --> Helper loaded: url_helper
INFO - 2016-02-01 11:32:13 --> Helper loaded: file_helper
INFO - 2016-02-01 11:32:13 --> Helper loaded: date_helper
INFO - 2016-02-01 11:32:13 --> Database Driver Class Initialized
INFO - 2016-02-01 11:32:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:32:14 --> Controller Class Initialized
INFO - 2016-02-01 11:32:14 --> Model Class Initialized
INFO - 2016-02-01 11:32:14 --> Model Class Initialized
INFO - 2016-02-01 11:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:32:14 --> Pagination Class Initialized
INFO - 2016-02-01 11:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:32:14 --> Final output sent to browser
DEBUG - 2016-02-01 11:32:14 --> Total execution time: 1.1029
INFO - 2016-02-01 11:32:26 --> Config Class Initialized
INFO - 2016-02-01 11:32:26 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:32:26 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:32:26 --> Utf8 Class Initialized
INFO - 2016-02-01 11:32:26 --> URI Class Initialized
INFO - 2016-02-01 11:32:26 --> Router Class Initialized
INFO - 2016-02-01 11:32:26 --> Output Class Initialized
INFO - 2016-02-01 11:32:26 --> Security Class Initialized
DEBUG - 2016-02-01 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:32:26 --> Input Class Initialized
INFO - 2016-02-01 11:32:26 --> Language Class Initialized
INFO - 2016-02-01 11:32:26 --> Loader Class Initialized
INFO - 2016-02-01 11:32:26 --> Helper loaded: url_helper
INFO - 2016-02-01 11:32:26 --> Helper loaded: file_helper
INFO - 2016-02-01 11:32:26 --> Helper loaded: date_helper
INFO - 2016-02-01 11:32:26 --> Database Driver Class Initialized
INFO - 2016-02-01 11:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:32:27 --> Controller Class Initialized
INFO - 2016-02-01 11:32:27 --> Model Class Initialized
INFO - 2016-02-01 11:32:27 --> Model Class Initialized
INFO - 2016-02-01 11:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:32:27 --> Pagination Class Initialized
INFO - 2016-02-01 11:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:32:27 --> Final output sent to browser
DEBUG - 2016-02-01 11:32:27 --> Total execution time: 1.1117
INFO - 2016-02-01 11:32:31 --> Config Class Initialized
INFO - 2016-02-01 11:32:31 --> Hooks Class Initialized
DEBUG - 2016-02-01 11:32:31 --> UTF-8 Support Enabled
INFO - 2016-02-01 11:32:31 --> Utf8 Class Initialized
INFO - 2016-02-01 11:32:31 --> URI Class Initialized
INFO - 2016-02-01 11:32:31 --> Router Class Initialized
INFO - 2016-02-01 11:32:31 --> Output Class Initialized
INFO - 2016-02-01 11:32:31 --> Security Class Initialized
DEBUG - 2016-02-01 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 11:32:31 --> Input Class Initialized
INFO - 2016-02-01 11:32:31 --> Language Class Initialized
INFO - 2016-02-01 11:32:31 --> Loader Class Initialized
INFO - 2016-02-01 11:32:31 --> Helper loaded: url_helper
INFO - 2016-02-01 11:32:31 --> Helper loaded: file_helper
INFO - 2016-02-01 11:32:31 --> Helper loaded: date_helper
INFO - 2016-02-01 11:32:31 --> Database Driver Class Initialized
INFO - 2016-02-01 11:32:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 11:32:32 --> Controller Class Initialized
INFO - 2016-02-01 11:32:32 --> Model Class Initialized
INFO - 2016-02-01 11:32:32 --> Model Class Initialized
INFO - 2016-02-01 11:32:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 11:32:32 --> Pagination Class Initialized
INFO - 2016-02-01 11:32:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 11:32:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 11:32:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 11:32:32 --> Final output sent to browser
DEBUG - 2016-02-01 11:32:32 --> Total execution time: 1.1164
INFO - 2016-02-01 12:04:07 --> Config Class Initialized
INFO - 2016-02-01 12:04:07 --> Hooks Class Initialized
DEBUG - 2016-02-01 12:04:07 --> UTF-8 Support Enabled
INFO - 2016-02-01 12:04:07 --> Utf8 Class Initialized
INFO - 2016-02-01 12:04:07 --> URI Class Initialized
INFO - 2016-02-01 12:04:07 --> Router Class Initialized
INFO - 2016-02-01 12:04:07 --> Output Class Initialized
INFO - 2016-02-01 12:04:07 --> Security Class Initialized
DEBUG - 2016-02-01 12:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 12:04:07 --> Input Class Initialized
INFO - 2016-02-01 12:04:07 --> Language Class Initialized
INFO - 2016-02-01 12:04:07 --> Loader Class Initialized
INFO - 2016-02-01 12:04:07 --> Helper loaded: url_helper
INFO - 2016-02-01 12:04:07 --> Helper loaded: file_helper
INFO - 2016-02-01 12:04:07 --> Helper loaded: date_helper
INFO - 2016-02-01 12:04:07 --> Database Driver Class Initialized
INFO - 2016-02-01 12:04:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 12:04:08 --> Controller Class Initialized
INFO - 2016-02-01 12:04:08 --> Model Class Initialized
INFO - 2016-02-01 12:04:08 --> Model Class Initialized
INFO - 2016-02-01 12:04:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 12:04:08 --> Pagination Class Initialized
INFO - 2016-02-01 12:04:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 12:04:08 --> Helper loaded: text_helper
INFO - 2016-02-01 12:04:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 12:04:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 12:04:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 12:04:08 --> Final output sent to browser
DEBUG - 2016-02-01 12:04:08 --> Total execution time: 1.1432
INFO - 2016-02-01 12:24:38 --> Config Class Initialized
INFO - 2016-02-01 12:24:38 --> Hooks Class Initialized
DEBUG - 2016-02-01 12:24:38 --> UTF-8 Support Enabled
INFO - 2016-02-01 12:24:38 --> Utf8 Class Initialized
INFO - 2016-02-01 12:24:38 --> URI Class Initialized
INFO - 2016-02-01 12:24:38 --> Router Class Initialized
INFO - 2016-02-01 12:24:38 --> Output Class Initialized
INFO - 2016-02-01 12:24:38 --> Security Class Initialized
DEBUG - 2016-02-01 12:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 12:24:38 --> Input Class Initialized
INFO - 2016-02-01 12:24:38 --> Language Class Initialized
INFO - 2016-02-01 12:24:38 --> Loader Class Initialized
INFO - 2016-02-01 12:24:38 --> Helper loaded: url_helper
INFO - 2016-02-01 12:24:38 --> Helper loaded: file_helper
INFO - 2016-02-01 12:24:38 --> Helper loaded: date_helper
INFO - 2016-02-01 12:24:38 --> Database Driver Class Initialized
INFO - 2016-02-01 12:24:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 12:24:39 --> Controller Class Initialized
INFO - 2016-02-01 12:24:39 --> Model Class Initialized
INFO - 2016-02-01 12:24:39 --> Model Class Initialized
INFO - 2016-02-01 12:24:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 12:24:39 --> Pagination Class Initialized
INFO - 2016-02-01 12:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 12:24:39 --> Helper loaded: text_helper
ERROR - 2016-02-01 12:24:39 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 122
INFO - 2016-02-01 12:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 12:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 12:24:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 12:24:39 --> Final output sent to browser
DEBUG - 2016-02-01 12:24:39 --> Total execution time: 1.1844
INFO - 2016-02-01 12:26:25 --> Config Class Initialized
INFO - 2016-02-01 12:26:25 --> Hooks Class Initialized
DEBUG - 2016-02-01 12:26:25 --> UTF-8 Support Enabled
INFO - 2016-02-01 12:26:25 --> Utf8 Class Initialized
INFO - 2016-02-01 12:26:25 --> URI Class Initialized
INFO - 2016-02-01 12:26:25 --> Router Class Initialized
INFO - 2016-02-01 12:26:25 --> Output Class Initialized
INFO - 2016-02-01 12:26:25 --> Security Class Initialized
DEBUG - 2016-02-01 12:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 12:26:25 --> Input Class Initialized
INFO - 2016-02-01 12:26:25 --> Language Class Initialized
INFO - 2016-02-01 12:26:25 --> Loader Class Initialized
INFO - 2016-02-01 12:26:25 --> Helper loaded: url_helper
INFO - 2016-02-01 12:26:25 --> Helper loaded: file_helper
INFO - 2016-02-01 12:26:25 --> Helper loaded: date_helper
INFO - 2016-02-01 12:26:25 --> Database Driver Class Initialized
INFO - 2016-02-01 12:26:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 12:26:26 --> Controller Class Initialized
INFO - 2016-02-01 12:26:26 --> Model Class Initialized
INFO - 2016-02-01 12:26:26 --> Model Class Initialized
INFO - 2016-02-01 12:26:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 12:26:26 --> Pagination Class Initialized
INFO - 2016-02-01 12:26:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 12:26:26 --> Helper loaded: text_helper
ERROR - 2016-02-01 12:26:26 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 122
INFO - 2016-02-01 12:26:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 12:26:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 12:26:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 12:26:26 --> Final output sent to browser
DEBUG - 2016-02-01 12:26:26 --> Total execution time: 1.1549
INFO - 2016-02-01 12:27:36 --> Config Class Initialized
INFO - 2016-02-01 12:27:36 --> Hooks Class Initialized
DEBUG - 2016-02-01 12:27:36 --> UTF-8 Support Enabled
INFO - 2016-02-01 12:27:36 --> Utf8 Class Initialized
INFO - 2016-02-01 12:27:36 --> URI Class Initialized
INFO - 2016-02-01 12:27:36 --> Router Class Initialized
INFO - 2016-02-01 12:27:36 --> Output Class Initialized
INFO - 2016-02-01 12:27:36 --> Security Class Initialized
DEBUG - 2016-02-01 12:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 12:27:36 --> Input Class Initialized
INFO - 2016-02-01 12:27:36 --> Language Class Initialized
INFO - 2016-02-01 12:27:36 --> Loader Class Initialized
INFO - 2016-02-01 12:27:36 --> Helper loaded: url_helper
INFO - 2016-02-01 12:27:36 --> Helper loaded: file_helper
INFO - 2016-02-01 12:27:36 --> Helper loaded: date_helper
INFO - 2016-02-01 12:27:36 --> Database Driver Class Initialized
INFO - 2016-02-01 12:27:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 12:27:37 --> Controller Class Initialized
INFO - 2016-02-01 12:27:37 --> Model Class Initialized
INFO - 2016-02-01 12:27:37 --> Model Class Initialized
INFO - 2016-02-01 12:27:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 12:27:37 --> Pagination Class Initialized
INFO - 2016-02-01 12:27:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 12:27:37 --> Helper loaded: text_helper
ERROR - 2016-02-01 12:27:38 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 122
ERROR - 2016-02-01 12:27:38 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 39
ERROR - 2016-02-01 12:27:38 --> Severity: Notice --> Object of class stdClass to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 39
ERROR - 2016-02-01 12:27:38 --> Severity: Notice --> Undefined variable: Object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 39
ERROR - 2016-02-01 12:27:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 39
INFO - 2016-02-01 12:27:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 12:27:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 12:27:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 12:27:38 --> Final output sent to browser
DEBUG - 2016-02-01 12:27:38 --> Total execution time: 1.1616
INFO - 2016-02-01 12:27:49 --> Config Class Initialized
INFO - 2016-02-01 12:27:49 --> Hooks Class Initialized
DEBUG - 2016-02-01 12:27:49 --> UTF-8 Support Enabled
INFO - 2016-02-01 12:27:49 --> Utf8 Class Initialized
INFO - 2016-02-01 12:27:49 --> URI Class Initialized
INFO - 2016-02-01 12:27:49 --> Router Class Initialized
INFO - 2016-02-01 12:27:49 --> Output Class Initialized
INFO - 2016-02-01 12:27:49 --> Security Class Initialized
DEBUG - 2016-02-01 12:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 12:27:49 --> Input Class Initialized
INFO - 2016-02-01 12:27:49 --> Language Class Initialized
INFO - 2016-02-01 12:27:49 --> Loader Class Initialized
INFO - 2016-02-01 12:27:49 --> Helper loaded: url_helper
INFO - 2016-02-01 12:27:49 --> Helper loaded: file_helper
INFO - 2016-02-01 12:27:49 --> Helper loaded: date_helper
INFO - 2016-02-01 12:27:49 --> Database Driver Class Initialized
INFO - 2016-02-01 12:27:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 12:27:50 --> Controller Class Initialized
INFO - 2016-02-01 12:27:50 --> Model Class Initialized
INFO - 2016-02-01 12:27:50 --> Model Class Initialized
INFO - 2016-02-01 12:27:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 12:27:50 --> Pagination Class Initialized
INFO - 2016-02-01 12:27:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 12:27:50 --> Helper loaded: text_helper
ERROR - 2016-02-01 12:27:50 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 122
INFO - 2016-02-01 12:27:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 12:27:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 12:27:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 12:27:50 --> Final output sent to browser
DEBUG - 2016-02-01 12:27:50 --> Total execution time: 1.1613
INFO - 2016-02-01 13:20:21 --> Config Class Initialized
INFO - 2016-02-01 13:20:21 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:20:21 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:20:21 --> Utf8 Class Initialized
INFO - 2016-02-01 13:20:21 --> URI Class Initialized
INFO - 2016-02-01 13:20:21 --> Router Class Initialized
INFO - 2016-02-01 13:20:21 --> Output Class Initialized
INFO - 2016-02-01 13:20:21 --> Security Class Initialized
DEBUG - 2016-02-01 13:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:20:21 --> Input Class Initialized
INFO - 2016-02-01 13:20:21 --> Language Class Initialized
INFO - 2016-02-01 13:20:21 --> Loader Class Initialized
INFO - 2016-02-01 13:20:21 --> Helper loaded: url_helper
INFO - 2016-02-01 13:20:21 --> Helper loaded: file_helper
INFO - 2016-02-01 13:20:21 --> Helper loaded: date_helper
INFO - 2016-02-01 13:20:21 --> Database Driver Class Initialized
INFO - 2016-02-01 13:20:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:20:22 --> Controller Class Initialized
INFO - 2016-02-01 13:20:22 --> Model Class Initialized
INFO - 2016-02-01 13:20:22 --> Model Class Initialized
INFO - 2016-02-01 13:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:20:22 --> Pagination Class Initialized
INFO - 2016-02-01 13:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:20:22 --> Helper loaded: text_helper
ERROR - 2016-02-01 13:20:22 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 122
INFO - 2016-02-01 13:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:20:22 --> Final output sent to browser
DEBUG - 2016-02-01 13:20:22 --> Total execution time: 1.1551
INFO - 2016-02-01 13:20:31 --> Config Class Initialized
INFO - 2016-02-01 13:20:31 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:20:31 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:20:31 --> Utf8 Class Initialized
INFO - 2016-02-01 13:20:31 --> URI Class Initialized
INFO - 2016-02-01 13:20:31 --> Router Class Initialized
INFO - 2016-02-01 13:20:31 --> Output Class Initialized
INFO - 2016-02-01 13:20:31 --> Security Class Initialized
DEBUG - 2016-02-01 13:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:20:31 --> Input Class Initialized
INFO - 2016-02-01 13:20:31 --> Language Class Initialized
INFO - 2016-02-01 13:20:31 --> Loader Class Initialized
INFO - 2016-02-01 13:20:31 --> Helper loaded: url_helper
INFO - 2016-02-01 13:20:31 --> Helper loaded: file_helper
INFO - 2016-02-01 13:20:31 --> Helper loaded: date_helper
INFO - 2016-02-01 13:20:31 --> Database Driver Class Initialized
INFO - 2016-02-01 13:20:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:20:32 --> Controller Class Initialized
INFO - 2016-02-01 13:20:32 --> Model Class Initialized
INFO - 2016-02-01 13:20:32 --> Model Class Initialized
INFO - 2016-02-01 13:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:20:32 --> Pagination Class Initialized
INFO - 2016-02-01 13:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:20:32 --> Helper loaded: text_helper
ERROR - 2016-02-01 13:20:32 --> Severity: Notice --> Undefined variable: page_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 122
INFO - 2016-02-01 13:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:20:32 --> Final output sent to browser
DEBUG - 2016-02-01 13:20:32 --> Total execution time: 1.1537
INFO - 2016-02-01 13:21:03 --> Config Class Initialized
INFO - 2016-02-01 13:21:03 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:21:03 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:21:03 --> Utf8 Class Initialized
INFO - 2016-02-01 13:21:03 --> URI Class Initialized
INFO - 2016-02-01 13:21:03 --> Router Class Initialized
INFO - 2016-02-01 13:21:03 --> Output Class Initialized
INFO - 2016-02-01 13:21:03 --> Security Class Initialized
DEBUG - 2016-02-01 13:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:21:03 --> Input Class Initialized
INFO - 2016-02-01 13:21:03 --> Language Class Initialized
INFO - 2016-02-01 13:21:03 --> Loader Class Initialized
INFO - 2016-02-01 13:21:03 --> Helper loaded: url_helper
INFO - 2016-02-01 13:21:03 --> Helper loaded: file_helper
INFO - 2016-02-01 13:21:03 --> Helper loaded: date_helper
INFO - 2016-02-01 13:21:03 --> Database Driver Class Initialized
INFO - 2016-02-01 13:21:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:21:04 --> Controller Class Initialized
INFO - 2016-02-01 13:21:04 --> Model Class Initialized
INFO - 2016-02-01 13:21:04 --> Model Class Initialized
INFO - 2016-02-01 13:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:21:04 --> Pagination Class Initialized
INFO - 2016-02-01 13:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:21:04 --> Helper loaded: text_helper
INFO - 2016-02-01 13:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:21:04 --> Final output sent to browser
DEBUG - 2016-02-01 13:21:04 --> Total execution time: 1.1523
INFO - 2016-02-01 13:23:51 --> Config Class Initialized
INFO - 2016-02-01 13:23:51 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:23:51 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:23:51 --> Utf8 Class Initialized
INFO - 2016-02-01 13:23:51 --> URI Class Initialized
INFO - 2016-02-01 13:23:51 --> Router Class Initialized
INFO - 2016-02-01 13:23:51 --> Output Class Initialized
INFO - 2016-02-01 13:23:51 --> Security Class Initialized
DEBUG - 2016-02-01 13:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:23:51 --> Input Class Initialized
INFO - 2016-02-01 13:23:51 --> Language Class Initialized
INFO - 2016-02-01 13:23:51 --> Loader Class Initialized
INFO - 2016-02-01 13:23:51 --> Helper loaded: url_helper
INFO - 2016-02-01 13:23:51 --> Helper loaded: file_helper
INFO - 2016-02-01 13:23:51 --> Helper loaded: date_helper
INFO - 2016-02-01 13:23:51 --> Database Driver Class Initialized
INFO - 2016-02-01 13:23:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:23:52 --> Controller Class Initialized
INFO - 2016-02-01 13:23:52 --> Model Class Initialized
INFO - 2016-02-01 13:23:52 --> Model Class Initialized
INFO - 2016-02-01 13:23:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:23:52 --> Pagination Class Initialized
INFO - 2016-02-01 13:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:23:52 --> Helper loaded: text_helper
INFO - 2016-02-01 13:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:23:52 --> Final output sent to browser
DEBUG - 2016-02-01 13:23:52 --> Total execution time: 1.1607
INFO - 2016-02-01 13:24:39 --> Config Class Initialized
INFO - 2016-02-01 13:24:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:24:39 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:24:39 --> Utf8 Class Initialized
INFO - 2016-02-01 13:24:39 --> URI Class Initialized
INFO - 2016-02-01 13:24:39 --> Router Class Initialized
INFO - 2016-02-01 13:24:39 --> Output Class Initialized
INFO - 2016-02-01 13:24:39 --> Security Class Initialized
DEBUG - 2016-02-01 13:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:24:39 --> Input Class Initialized
INFO - 2016-02-01 13:24:39 --> Language Class Initialized
INFO - 2016-02-01 13:24:39 --> Loader Class Initialized
INFO - 2016-02-01 13:24:39 --> Helper loaded: url_helper
INFO - 2016-02-01 13:24:39 --> Helper loaded: file_helper
INFO - 2016-02-01 13:24:39 --> Helper loaded: date_helper
INFO - 2016-02-01 13:24:39 --> Database Driver Class Initialized
INFO - 2016-02-01 13:24:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:24:40 --> Controller Class Initialized
INFO - 2016-02-01 13:24:40 --> Model Class Initialized
INFO - 2016-02-01 13:24:40 --> Model Class Initialized
INFO - 2016-02-01 13:24:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:24:40 --> Pagination Class Initialized
INFO - 2016-02-01 13:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:24:40 --> Helper loaded: text_helper
INFO - 2016-02-01 13:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:24:40 --> Final output sent to browser
DEBUG - 2016-02-01 13:24:40 --> Total execution time: 1.1484
INFO - 2016-02-01 13:24:55 --> Config Class Initialized
INFO - 2016-02-01 13:24:55 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:24:55 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:24:55 --> Utf8 Class Initialized
INFO - 2016-02-01 13:24:55 --> URI Class Initialized
INFO - 2016-02-01 13:24:55 --> Router Class Initialized
INFO - 2016-02-01 13:24:55 --> Output Class Initialized
INFO - 2016-02-01 13:24:55 --> Security Class Initialized
DEBUG - 2016-02-01 13:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:24:55 --> Input Class Initialized
INFO - 2016-02-01 13:24:55 --> Language Class Initialized
INFO - 2016-02-01 13:24:55 --> Loader Class Initialized
INFO - 2016-02-01 13:24:55 --> Helper loaded: url_helper
INFO - 2016-02-01 13:24:55 --> Helper loaded: file_helper
INFO - 2016-02-01 13:24:55 --> Helper loaded: date_helper
INFO - 2016-02-01 13:24:55 --> Database Driver Class Initialized
INFO - 2016-02-01 13:24:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:24:56 --> Controller Class Initialized
INFO - 2016-02-01 13:24:56 --> Model Class Initialized
INFO - 2016-02-01 13:24:56 --> Model Class Initialized
INFO - 2016-02-01 13:24:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:24:56 --> Pagination Class Initialized
INFO - 2016-02-01 13:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:24:56 --> Helper loaded: text_helper
INFO - 2016-02-01 13:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:24:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:24:56 --> Final output sent to browser
DEBUG - 2016-02-01 13:24:56 --> Total execution time: 1.1353
INFO - 2016-02-01 13:26:21 --> Config Class Initialized
INFO - 2016-02-01 13:26:21 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:26:21 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:26:21 --> Utf8 Class Initialized
INFO - 2016-02-01 13:26:21 --> URI Class Initialized
INFO - 2016-02-01 13:26:21 --> Router Class Initialized
INFO - 2016-02-01 13:26:21 --> Output Class Initialized
INFO - 2016-02-01 13:26:21 --> Security Class Initialized
DEBUG - 2016-02-01 13:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:26:21 --> Input Class Initialized
INFO - 2016-02-01 13:26:21 --> Language Class Initialized
INFO - 2016-02-01 13:26:21 --> Loader Class Initialized
INFO - 2016-02-01 13:26:21 --> Helper loaded: url_helper
INFO - 2016-02-01 13:26:21 --> Helper loaded: file_helper
INFO - 2016-02-01 13:26:21 --> Helper loaded: date_helper
INFO - 2016-02-01 13:26:21 --> Database Driver Class Initialized
INFO - 2016-02-01 13:26:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:26:22 --> Controller Class Initialized
INFO - 2016-02-01 13:26:22 --> Model Class Initialized
INFO - 2016-02-01 13:26:22 --> Model Class Initialized
INFO - 2016-02-01 13:26:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:26:22 --> Pagination Class Initialized
INFO - 2016-02-01 13:26:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:26:22 --> Helper loaded: text_helper
INFO - 2016-02-01 13:26:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:26:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:26:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:26:22 --> Final output sent to browser
DEBUG - 2016-02-01 13:26:22 --> Total execution time: 1.1450
INFO - 2016-02-01 13:30:22 --> Config Class Initialized
INFO - 2016-02-01 13:30:22 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:30:22 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:30:22 --> Utf8 Class Initialized
INFO - 2016-02-01 13:30:22 --> URI Class Initialized
INFO - 2016-02-01 13:30:22 --> Router Class Initialized
INFO - 2016-02-01 13:30:22 --> Output Class Initialized
INFO - 2016-02-01 13:30:22 --> Security Class Initialized
DEBUG - 2016-02-01 13:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:30:22 --> Input Class Initialized
INFO - 2016-02-01 13:30:22 --> Language Class Initialized
INFO - 2016-02-01 13:30:22 --> Loader Class Initialized
INFO - 2016-02-01 13:30:22 --> Helper loaded: url_helper
INFO - 2016-02-01 13:30:22 --> Helper loaded: file_helper
INFO - 2016-02-01 13:30:22 --> Helper loaded: date_helper
INFO - 2016-02-01 13:30:22 --> Database Driver Class Initialized
INFO - 2016-02-01 13:30:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:30:23 --> Controller Class Initialized
INFO - 2016-02-01 13:30:23 --> Model Class Initialized
INFO - 2016-02-01 13:30:23 --> Model Class Initialized
INFO - 2016-02-01 13:30:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:30:23 --> Pagination Class Initialized
INFO - 2016-02-01 13:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:30:23 --> Helper loaded: text_helper
ERROR - 2016-02-01 13:30:23 --> Severity: Notice --> Undefined variable: vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 37
INFO - 2016-02-01 13:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:30:23 --> Final output sent to browser
DEBUG - 2016-02-01 13:30:23 --> Total execution time: 1.1541
INFO - 2016-02-01 13:30:56 --> Config Class Initialized
INFO - 2016-02-01 13:30:56 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:30:56 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:30:56 --> Utf8 Class Initialized
INFO - 2016-02-01 13:30:56 --> URI Class Initialized
INFO - 2016-02-01 13:30:56 --> Router Class Initialized
INFO - 2016-02-01 13:30:56 --> Output Class Initialized
INFO - 2016-02-01 13:30:56 --> Security Class Initialized
DEBUG - 2016-02-01 13:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:30:56 --> Input Class Initialized
INFO - 2016-02-01 13:30:56 --> Language Class Initialized
INFO - 2016-02-01 13:30:56 --> Loader Class Initialized
INFO - 2016-02-01 13:30:56 --> Helper loaded: url_helper
INFO - 2016-02-01 13:30:56 --> Helper loaded: file_helper
INFO - 2016-02-01 13:30:56 --> Helper loaded: date_helper
INFO - 2016-02-01 13:30:56 --> Database Driver Class Initialized
INFO - 2016-02-01 13:30:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:30:57 --> Controller Class Initialized
INFO - 2016-02-01 13:30:57 --> Model Class Initialized
INFO - 2016-02-01 13:30:57 --> Model Class Initialized
INFO - 2016-02-01 13:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:30:57 --> Pagination Class Initialized
INFO - 2016-02-01 13:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:30:57 --> Helper loaded: text_helper
INFO - 2016-02-01 13:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:30:57 --> Final output sent to browser
DEBUG - 2016-02-01 13:30:57 --> Total execution time: 1.1296
INFO - 2016-02-01 13:30:59 --> Config Class Initialized
INFO - 2016-02-01 13:30:59 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:30:59 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:30:59 --> Utf8 Class Initialized
INFO - 2016-02-01 13:30:59 --> URI Class Initialized
INFO - 2016-02-01 13:30:59 --> Router Class Initialized
INFO - 2016-02-01 13:30:59 --> Output Class Initialized
INFO - 2016-02-01 13:30:59 --> Security Class Initialized
DEBUG - 2016-02-01 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:30:59 --> Input Class Initialized
INFO - 2016-02-01 13:30:59 --> Language Class Initialized
INFO - 2016-02-01 13:30:59 --> Loader Class Initialized
INFO - 2016-02-01 13:30:59 --> Helper loaded: url_helper
INFO - 2016-02-01 13:30:59 --> Helper loaded: file_helper
INFO - 2016-02-01 13:30:59 --> Helper loaded: date_helper
INFO - 2016-02-01 13:30:59 --> Database Driver Class Initialized
INFO - 2016-02-01 13:31:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:31:00 --> Controller Class Initialized
INFO - 2016-02-01 13:31:00 --> Model Class Initialized
INFO - 2016-02-01 13:31:00 --> Model Class Initialized
INFO - 2016-02-01 13:31:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:31:00 --> Pagination Class Initialized
ERROR - 2016-02-01 13:31:00 --> Severity: Warning --> Missing argument 1 for Jboard::up_vote() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 403
ERROR - 2016-02-01 13:31:00 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 405
ERROR - 2016-02-01 13:31:00 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 405
ERROR - 2016-02-01 13:31:00 --> Severity: Error --> Call to a member function userdata() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 405
INFO - 2016-02-01 13:31:39 --> Config Class Initialized
INFO - 2016-02-01 13:31:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:31:39 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:31:39 --> Utf8 Class Initialized
INFO - 2016-02-01 13:31:39 --> URI Class Initialized
INFO - 2016-02-01 13:31:39 --> Router Class Initialized
INFO - 2016-02-01 13:31:39 --> Output Class Initialized
INFO - 2016-02-01 13:31:39 --> Security Class Initialized
DEBUG - 2016-02-01 13:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:31:39 --> Input Class Initialized
INFO - 2016-02-01 13:31:39 --> Language Class Initialized
INFO - 2016-02-01 13:31:39 --> Loader Class Initialized
INFO - 2016-02-01 13:31:39 --> Helper loaded: url_helper
INFO - 2016-02-01 13:31:39 --> Helper loaded: file_helper
INFO - 2016-02-01 13:31:39 --> Helper loaded: date_helper
INFO - 2016-02-01 13:31:39 --> Database Driver Class Initialized
INFO - 2016-02-01 13:31:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:31:40 --> Controller Class Initialized
INFO - 2016-02-01 13:31:40 --> Model Class Initialized
INFO - 2016-02-01 13:31:40 --> Model Class Initialized
INFO - 2016-02-01 13:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:31:40 --> Pagination Class Initialized
INFO - 2016-02-01 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:31:40 --> Helper loaded: text_helper
INFO - 2016-02-01 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:31:40 --> Final output sent to browser
DEBUG - 2016-02-01 13:31:40 --> Total execution time: 1.1578
INFO - 2016-02-01 13:31:41 --> Config Class Initialized
INFO - 2016-02-01 13:31:41 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:31:41 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:31:41 --> Utf8 Class Initialized
INFO - 2016-02-01 13:31:41 --> URI Class Initialized
INFO - 2016-02-01 13:31:41 --> Router Class Initialized
INFO - 2016-02-01 13:31:41 --> Output Class Initialized
INFO - 2016-02-01 13:31:41 --> Security Class Initialized
DEBUG - 2016-02-01 13:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:31:41 --> Input Class Initialized
INFO - 2016-02-01 13:31:42 --> Language Class Initialized
INFO - 2016-02-01 13:31:42 --> Loader Class Initialized
INFO - 2016-02-01 13:31:42 --> Helper loaded: url_helper
INFO - 2016-02-01 13:31:42 --> Helper loaded: file_helper
INFO - 2016-02-01 13:31:42 --> Helper loaded: date_helper
INFO - 2016-02-01 13:31:42 --> Database Driver Class Initialized
INFO - 2016-02-01 13:31:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:31:43 --> Controller Class Initialized
INFO - 2016-02-01 13:31:43 --> Model Class Initialized
INFO - 2016-02-01 13:31:43 --> Model Class Initialized
INFO - 2016-02-01 13:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:31:43 --> Pagination Class Initialized
ERROR - 2016-02-01 13:31:43 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 405
ERROR - 2016-02-01 13:31:43 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 405
ERROR - 2016-02-01 13:31:43 --> Severity: Error --> Call to a member function userdata() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 405
INFO - 2016-02-01 13:32:26 --> Config Class Initialized
INFO - 2016-02-01 13:32:26 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:32:26 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:32:26 --> Utf8 Class Initialized
INFO - 2016-02-01 13:32:26 --> URI Class Initialized
INFO - 2016-02-01 13:32:26 --> Router Class Initialized
INFO - 2016-02-01 13:32:26 --> Output Class Initialized
INFO - 2016-02-01 13:32:26 --> Security Class Initialized
DEBUG - 2016-02-01 13:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:32:26 --> Input Class Initialized
INFO - 2016-02-01 13:32:26 --> Language Class Initialized
INFO - 2016-02-01 13:32:26 --> Loader Class Initialized
INFO - 2016-02-01 13:32:26 --> Helper loaded: url_helper
INFO - 2016-02-01 13:32:26 --> Helper loaded: file_helper
INFO - 2016-02-01 13:32:26 --> Helper loaded: date_helper
INFO - 2016-02-01 13:32:26 --> Database Driver Class Initialized
INFO - 2016-02-01 13:32:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:32:27 --> Controller Class Initialized
INFO - 2016-02-01 13:32:27 --> Model Class Initialized
INFO - 2016-02-01 13:32:27 --> Model Class Initialized
INFO - 2016-02-01 13:32:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:32:27 --> Pagination Class Initialized
INFO - 2016-02-01 13:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:32:27 --> Helper loaded: text_helper
INFO - 2016-02-01 13:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:32:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:32:27 --> Final output sent to browser
DEBUG - 2016-02-01 13:32:27 --> Total execution time: 1.1656
INFO - 2016-02-01 13:32:28 --> Config Class Initialized
INFO - 2016-02-01 13:32:28 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:32:28 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:32:28 --> Utf8 Class Initialized
INFO - 2016-02-01 13:32:28 --> URI Class Initialized
INFO - 2016-02-01 13:32:28 --> Router Class Initialized
INFO - 2016-02-01 13:32:28 --> Output Class Initialized
INFO - 2016-02-01 13:32:28 --> Security Class Initialized
DEBUG - 2016-02-01 13:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:32:28 --> Input Class Initialized
INFO - 2016-02-01 13:32:28 --> Language Class Initialized
INFO - 2016-02-01 13:32:28 --> Loader Class Initialized
INFO - 2016-02-01 13:32:28 --> Helper loaded: url_helper
INFO - 2016-02-01 13:32:28 --> Helper loaded: file_helper
INFO - 2016-02-01 13:32:28 --> Helper loaded: date_helper
INFO - 2016-02-01 13:32:28 --> Database Driver Class Initialized
INFO - 2016-02-01 13:32:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:32:29 --> Controller Class Initialized
INFO - 2016-02-01 13:32:29 --> Model Class Initialized
INFO - 2016-02-01 13:32:29 --> Model Class Initialized
INFO - 2016-02-01 13:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:32:29 --> Pagination Class Initialized
INFO - 2016-02-01 13:32:29 --> Config Class Initialized
INFO - 2016-02-01 13:32:29 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:32:29 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:32:29 --> Utf8 Class Initialized
INFO - 2016-02-01 13:32:29 --> URI Class Initialized
INFO - 2016-02-01 13:32:29 --> Router Class Initialized
INFO - 2016-02-01 13:32:29 --> Output Class Initialized
INFO - 2016-02-01 13:32:29 --> Security Class Initialized
DEBUG - 2016-02-01 13:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:32:29 --> Input Class Initialized
INFO - 2016-02-01 13:32:29 --> Language Class Initialized
INFO - 2016-02-01 13:32:29 --> Loader Class Initialized
INFO - 2016-02-01 13:32:29 --> Helper loaded: url_helper
INFO - 2016-02-01 13:32:29 --> Helper loaded: file_helper
INFO - 2016-02-01 13:32:29 --> Helper loaded: date_helper
INFO - 2016-02-01 13:32:29 --> Database Driver Class Initialized
INFO - 2016-02-01 13:32:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:32:30 --> Controller Class Initialized
INFO - 2016-02-01 13:32:30 --> Model Class Initialized
INFO - 2016-02-01 13:32:30 --> Model Class Initialized
INFO - 2016-02-01 13:32:30 --> Helper loaded: form_helper
INFO - 2016-02-01 13:32:30 --> Form Validation Class Initialized
INFO - 2016-02-01 13:32:30 --> Helper loaded: text_helper
INFO - 2016-02-01 13:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:32:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-01 13:32:30 --> Final output sent to browser
DEBUG - 2016-02-01 13:32:30 --> Total execution time: 1.1207
INFO - 2016-02-01 13:32:38 --> Config Class Initialized
INFO - 2016-02-01 13:32:38 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:32:38 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:32:38 --> Utf8 Class Initialized
INFO - 2016-02-01 13:32:38 --> URI Class Initialized
INFO - 2016-02-01 13:32:38 --> Router Class Initialized
INFO - 2016-02-01 13:32:38 --> Output Class Initialized
INFO - 2016-02-01 13:32:38 --> Security Class Initialized
DEBUG - 2016-02-01 13:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:32:38 --> Input Class Initialized
INFO - 2016-02-01 13:32:38 --> Language Class Initialized
INFO - 2016-02-01 13:32:38 --> Loader Class Initialized
INFO - 2016-02-01 13:32:38 --> Helper loaded: url_helper
INFO - 2016-02-01 13:32:38 --> Helper loaded: file_helper
INFO - 2016-02-01 13:32:38 --> Helper loaded: date_helper
INFO - 2016-02-01 13:32:38 --> Database Driver Class Initialized
INFO - 2016-02-01 13:32:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:32:39 --> Controller Class Initialized
INFO - 2016-02-01 13:32:39 --> Model Class Initialized
INFO - 2016-02-01 13:32:39 --> Model Class Initialized
INFO - 2016-02-01 13:32:39 --> Helper loaded: form_helper
INFO - 2016-02-01 13:32:39 --> Form Validation Class Initialized
INFO - 2016-02-01 13:32:39 --> Helper loaded: text_helper
INFO - 2016-02-01 13:32:39 --> Config Class Initialized
INFO - 2016-02-01 13:32:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:32:39 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:32:39 --> Utf8 Class Initialized
INFO - 2016-02-01 13:32:39 --> URI Class Initialized
INFO - 2016-02-01 13:32:39 --> Router Class Initialized
INFO - 2016-02-01 13:32:39 --> Output Class Initialized
INFO - 2016-02-01 13:32:39 --> Security Class Initialized
DEBUG - 2016-02-01 13:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:32:39 --> Input Class Initialized
INFO - 2016-02-01 13:32:39 --> Language Class Initialized
INFO - 2016-02-01 13:32:39 --> Loader Class Initialized
INFO - 2016-02-01 13:32:39 --> Helper loaded: url_helper
INFO - 2016-02-01 13:32:39 --> Helper loaded: file_helper
INFO - 2016-02-01 13:32:39 --> Helper loaded: date_helper
INFO - 2016-02-01 13:32:39 --> Database Driver Class Initialized
INFO - 2016-02-01 13:32:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:32:40 --> Controller Class Initialized
INFO - 2016-02-01 13:32:40 --> Model Class Initialized
INFO - 2016-02-01 13:32:40 --> Model Class Initialized
INFO - 2016-02-01 13:32:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:32:40 --> Pagination Class Initialized
INFO - 2016-02-01 13:32:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:32:40 --> Helper loaded: text_helper
INFO - 2016-02-01 13:32:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:32:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:32:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:32:40 --> Final output sent to browser
DEBUG - 2016-02-01 13:32:40 --> Total execution time: 1.1640
INFO - 2016-02-01 13:32:43 --> Config Class Initialized
INFO - 2016-02-01 13:32:43 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:32:43 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:32:43 --> Utf8 Class Initialized
INFO - 2016-02-01 13:32:43 --> URI Class Initialized
INFO - 2016-02-01 13:32:43 --> Router Class Initialized
INFO - 2016-02-01 13:32:43 --> Output Class Initialized
INFO - 2016-02-01 13:32:43 --> Security Class Initialized
DEBUG - 2016-02-01 13:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:32:43 --> Input Class Initialized
INFO - 2016-02-01 13:32:43 --> Language Class Initialized
INFO - 2016-02-01 13:32:43 --> Loader Class Initialized
INFO - 2016-02-01 13:32:43 --> Helper loaded: url_helper
INFO - 2016-02-01 13:32:43 --> Helper loaded: file_helper
INFO - 2016-02-01 13:32:43 --> Helper loaded: date_helper
INFO - 2016-02-01 13:32:43 --> Database Driver Class Initialized
INFO - 2016-02-01 13:32:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:32:44 --> Controller Class Initialized
INFO - 2016-02-01 13:32:44 --> Model Class Initialized
INFO - 2016-02-01 13:32:44 --> Model Class Initialized
INFO - 2016-02-01 13:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:32:44 --> Pagination Class Initialized
INFO - 2016-02-01 13:32:44 --> Final output sent to browser
DEBUG - 2016-02-01 13:32:44 --> Total execution time: 1.1201
INFO - 2016-02-01 13:34:20 --> Config Class Initialized
INFO - 2016-02-01 13:34:20 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:34:20 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:34:20 --> Utf8 Class Initialized
INFO - 2016-02-01 13:34:20 --> URI Class Initialized
INFO - 2016-02-01 13:34:20 --> Router Class Initialized
INFO - 2016-02-01 13:34:20 --> Output Class Initialized
INFO - 2016-02-01 13:34:20 --> Security Class Initialized
DEBUG - 2016-02-01 13:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:34:20 --> Input Class Initialized
INFO - 2016-02-01 13:34:20 --> Language Class Initialized
INFO - 2016-02-01 13:34:20 --> Loader Class Initialized
INFO - 2016-02-01 13:34:20 --> Helper loaded: url_helper
INFO - 2016-02-01 13:34:20 --> Helper loaded: file_helper
INFO - 2016-02-01 13:34:20 --> Helper loaded: date_helper
INFO - 2016-02-01 13:34:21 --> Database Driver Class Initialized
INFO - 2016-02-01 13:34:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:34:22 --> Controller Class Initialized
INFO - 2016-02-01 13:34:22 --> Model Class Initialized
INFO - 2016-02-01 13:34:22 --> Model Class Initialized
INFO - 2016-02-01 13:34:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:34:22 --> Pagination Class Initialized
INFO - 2016-02-01 13:34:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:34:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 13:34:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:34:22 --> Final output sent to browser
DEBUG - 2016-02-01 13:34:22 --> Total execution time: 1.1114
INFO - 2016-02-01 13:34:23 --> Config Class Initialized
INFO - 2016-02-01 13:34:23 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:34:23 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:34:23 --> Utf8 Class Initialized
INFO - 2016-02-01 13:34:23 --> URI Class Initialized
INFO - 2016-02-01 13:34:23 --> Router Class Initialized
INFO - 2016-02-01 13:34:23 --> Output Class Initialized
INFO - 2016-02-01 13:34:23 --> Security Class Initialized
DEBUG - 2016-02-01 13:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:34:23 --> Input Class Initialized
INFO - 2016-02-01 13:34:23 --> Language Class Initialized
INFO - 2016-02-01 13:34:23 --> Loader Class Initialized
INFO - 2016-02-01 13:34:23 --> Helper loaded: url_helper
INFO - 2016-02-01 13:34:23 --> Helper loaded: file_helper
INFO - 2016-02-01 13:34:23 --> Helper loaded: date_helper
INFO - 2016-02-01 13:34:23 --> Database Driver Class Initialized
INFO - 2016-02-01 13:34:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:34:24 --> Controller Class Initialized
INFO - 2016-02-01 13:34:24 --> Model Class Initialized
INFO - 2016-02-01 13:34:24 --> Model Class Initialized
INFO - 2016-02-01 13:34:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:34:24 --> Pagination Class Initialized
INFO - 2016-02-01 13:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:34:24 --> Helper loaded: text_helper
INFO - 2016-02-01 13:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:34:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:34:24 --> Final output sent to browser
DEBUG - 2016-02-01 13:34:24 --> Total execution time: 1.1247
INFO - 2016-02-01 13:35:25 --> Config Class Initialized
INFO - 2016-02-01 13:35:25 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:35:25 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:35:25 --> Utf8 Class Initialized
INFO - 2016-02-01 13:35:25 --> URI Class Initialized
INFO - 2016-02-01 13:35:25 --> Router Class Initialized
INFO - 2016-02-01 13:35:25 --> Output Class Initialized
INFO - 2016-02-01 13:35:25 --> Security Class Initialized
DEBUG - 2016-02-01 13:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:35:25 --> Input Class Initialized
INFO - 2016-02-01 13:35:25 --> Language Class Initialized
INFO - 2016-02-01 13:35:25 --> Loader Class Initialized
INFO - 2016-02-01 13:35:25 --> Helper loaded: url_helper
INFO - 2016-02-01 13:35:26 --> Helper loaded: file_helper
INFO - 2016-02-01 13:35:26 --> Helper loaded: date_helper
INFO - 2016-02-01 13:35:26 --> Database Driver Class Initialized
INFO - 2016-02-01 13:35:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:35:27 --> Controller Class Initialized
INFO - 2016-02-01 13:35:27 --> Model Class Initialized
INFO - 2016-02-01 13:35:27 --> Model Class Initialized
INFO - 2016-02-01 13:35:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:35:27 --> Pagination Class Initialized
INFO - 2016-02-01 13:35:27 --> Config Class Initialized
INFO - 2016-02-01 13:35:27 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:35:27 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:35:27 --> Utf8 Class Initialized
INFO - 2016-02-01 13:35:27 --> URI Class Initialized
INFO - 2016-02-01 13:35:27 --> Router Class Initialized
INFO - 2016-02-01 13:35:27 --> Output Class Initialized
INFO - 2016-02-01 13:35:27 --> Security Class Initialized
DEBUG - 2016-02-01 13:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:35:27 --> Input Class Initialized
INFO - 2016-02-01 13:35:27 --> Language Class Initialized
INFO - 2016-02-01 13:35:27 --> Loader Class Initialized
INFO - 2016-02-01 13:35:27 --> Helper loaded: url_helper
INFO - 2016-02-01 13:35:27 --> Helper loaded: file_helper
INFO - 2016-02-01 13:35:27 --> Helper loaded: date_helper
INFO - 2016-02-01 13:35:27 --> Database Driver Class Initialized
INFO - 2016-02-01 13:35:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:35:28 --> Controller Class Initialized
INFO - 2016-02-01 13:35:28 --> Model Class Initialized
INFO - 2016-02-01 13:35:28 --> Model Class Initialized
INFO - 2016-02-01 13:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:35:28 --> Pagination Class Initialized
INFO - 2016-02-01 13:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:35:28 --> Helper loaded: text_helper
INFO - 2016-02-01 13:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:35:28 --> Final output sent to browser
DEBUG - 2016-02-01 13:35:28 --> Total execution time: 1.1568
INFO - 2016-02-01 13:36:06 --> Config Class Initialized
INFO - 2016-02-01 13:36:06 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:36:06 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:36:06 --> Utf8 Class Initialized
INFO - 2016-02-01 13:36:06 --> URI Class Initialized
INFO - 2016-02-01 13:36:06 --> Router Class Initialized
INFO - 2016-02-01 13:36:06 --> Output Class Initialized
INFO - 2016-02-01 13:36:06 --> Security Class Initialized
DEBUG - 2016-02-01 13:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:36:06 --> Input Class Initialized
INFO - 2016-02-01 13:36:06 --> Language Class Initialized
INFO - 2016-02-01 13:36:06 --> Loader Class Initialized
INFO - 2016-02-01 13:36:06 --> Helper loaded: url_helper
INFO - 2016-02-01 13:36:06 --> Helper loaded: file_helper
INFO - 2016-02-01 13:36:06 --> Helper loaded: date_helper
INFO - 2016-02-01 13:36:06 --> Database Driver Class Initialized
INFO - 2016-02-01 13:36:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:36:07 --> Controller Class Initialized
INFO - 2016-02-01 13:36:07 --> Model Class Initialized
INFO - 2016-02-01 13:36:07 --> Model Class Initialized
INFO - 2016-02-01 13:36:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:36:07 --> Pagination Class Initialized
INFO - 2016-02-01 13:36:07 --> Config Class Initialized
INFO - 2016-02-01 13:36:07 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:36:07 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:36:07 --> Utf8 Class Initialized
INFO - 2016-02-01 13:36:07 --> URI Class Initialized
INFO - 2016-02-01 13:36:07 --> Router Class Initialized
INFO - 2016-02-01 13:36:07 --> Output Class Initialized
INFO - 2016-02-01 13:36:07 --> Security Class Initialized
DEBUG - 2016-02-01 13:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:36:07 --> Input Class Initialized
INFO - 2016-02-01 13:36:07 --> Language Class Initialized
INFO - 2016-02-01 13:36:07 --> Loader Class Initialized
INFO - 2016-02-01 13:36:07 --> Helper loaded: url_helper
INFO - 2016-02-01 13:36:07 --> Helper loaded: file_helper
INFO - 2016-02-01 13:36:07 --> Helper loaded: date_helper
INFO - 2016-02-01 13:36:07 --> Database Driver Class Initialized
INFO - 2016-02-01 13:36:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:36:08 --> Controller Class Initialized
INFO - 2016-02-01 13:36:08 --> Model Class Initialized
INFO - 2016-02-01 13:36:08 --> Model Class Initialized
INFO - 2016-02-01 13:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:36:08 --> Pagination Class Initialized
INFO - 2016-02-01 13:36:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:36:08 --> Helper loaded: text_helper
INFO - 2016-02-01 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:36:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:36:09 --> Final output sent to browser
DEBUG - 2016-02-01 13:36:09 --> Total execution time: 1.2604
INFO - 2016-02-01 13:40:16 --> Config Class Initialized
INFO - 2016-02-01 13:40:16 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:40:16 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:40:16 --> Utf8 Class Initialized
INFO - 2016-02-01 13:40:16 --> URI Class Initialized
INFO - 2016-02-01 13:40:16 --> Router Class Initialized
INFO - 2016-02-01 13:40:16 --> Output Class Initialized
INFO - 2016-02-01 13:40:16 --> Security Class Initialized
DEBUG - 2016-02-01 13:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:40:16 --> Input Class Initialized
INFO - 2016-02-01 13:40:16 --> Language Class Initialized
INFO - 2016-02-01 13:40:16 --> Loader Class Initialized
INFO - 2016-02-01 13:40:16 --> Helper loaded: url_helper
INFO - 2016-02-01 13:40:16 --> Helper loaded: file_helper
INFO - 2016-02-01 13:40:16 --> Helper loaded: date_helper
INFO - 2016-02-01 13:40:16 --> Database Driver Class Initialized
INFO - 2016-02-01 13:40:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:40:17 --> Controller Class Initialized
INFO - 2016-02-01 13:40:17 --> Model Class Initialized
INFO - 2016-02-01 13:40:17 --> Model Class Initialized
INFO - 2016-02-01 13:40:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:40:17 --> Pagination Class Initialized
INFO - 2016-02-01 13:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:40:17 --> Helper loaded: text_helper
INFO - 2016-02-01 13:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:40:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:40:17 --> Final output sent to browser
DEBUG - 2016-02-01 13:40:17 --> Total execution time: 1.1556
INFO - 2016-02-01 13:40:19 --> Config Class Initialized
INFO - 2016-02-01 13:40:19 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:40:19 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:40:19 --> Utf8 Class Initialized
INFO - 2016-02-01 13:40:19 --> URI Class Initialized
INFO - 2016-02-01 13:40:19 --> Router Class Initialized
INFO - 2016-02-01 13:40:19 --> Output Class Initialized
INFO - 2016-02-01 13:40:19 --> Security Class Initialized
DEBUG - 2016-02-01 13:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:40:19 --> Input Class Initialized
INFO - 2016-02-01 13:40:19 --> Language Class Initialized
INFO - 2016-02-01 13:40:19 --> Loader Class Initialized
INFO - 2016-02-01 13:40:19 --> Helper loaded: url_helper
INFO - 2016-02-01 13:40:19 --> Helper loaded: file_helper
INFO - 2016-02-01 13:40:19 --> Helper loaded: date_helper
INFO - 2016-02-01 13:40:19 --> Database Driver Class Initialized
INFO - 2016-02-01 13:40:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:40:20 --> Controller Class Initialized
INFO - 2016-02-01 13:40:20 --> Model Class Initialized
INFO - 2016-02-01 13:40:20 --> Model Class Initialized
INFO - 2016-02-01 13:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:40:20 --> Pagination Class Initialized
INFO - 2016-02-01 13:40:20 --> Config Class Initialized
INFO - 2016-02-01 13:40:20 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:40:20 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:40:20 --> Utf8 Class Initialized
INFO - 2016-02-01 13:40:20 --> URI Class Initialized
INFO - 2016-02-01 13:40:20 --> Router Class Initialized
INFO - 2016-02-01 13:40:20 --> Output Class Initialized
INFO - 2016-02-01 13:40:20 --> Security Class Initialized
DEBUG - 2016-02-01 13:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:40:20 --> Input Class Initialized
INFO - 2016-02-01 13:40:20 --> Language Class Initialized
INFO - 2016-02-01 13:40:20 --> Loader Class Initialized
INFO - 2016-02-01 13:40:20 --> Helper loaded: url_helper
INFO - 2016-02-01 13:40:20 --> Helper loaded: file_helper
INFO - 2016-02-01 13:40:20 --> Helper loaded: date_helper
INFO - 2016-02-01 13:40:20 --> Database Driver Class Initialized
INFO - 2016-02-01 13:40:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:40:21 --> Controller Class Initialized
INFO - 2016-02-01 13:40:21 --> Model Class Initialized
INFO - 2016-02-01 13:40:21 --> Model Class Initialized
INFO - 2016-02-01 13:40:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:40:21 --> Pagination Class Initialized
INFO - 2016-02-01 13:40:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:40:21 --> Helper loaded: text_helper
INFO - 2016-02-01 13:40:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 13:40:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:40:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:40:22 --> Final output sent to browser
DEBUG - 2016-02-01 13:40:22 --> Total execution time: 1.1360
INFO - 2016-02-01 13:54:52 --> Config Class Initialized
INFO - 2016-02-01 13:54:52 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:54:52 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:54:52 --> Utf8 Class Initialized
INFO - 2016-02-01 13:54:52 --> URI Class Initialized
INFO - 2016-02-01 13:54:52 --> Router Class Initialized
INFO - 2016-02-01 13:54:52 --> Output Class Initialized
INFO - 2016-02-01 13:54:52 --> Security Class Initialized
DEBUG - 2016-02-01 13:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:54:52 --> Input Class Initialized
INFO - 2016-02-01 13:54:52 --> Language Class Initialized
INFO - 2016-02-01 13:54:52 --> Loader Class Initialized
INFO - 2016-02-01 13:54:52 --> Helper loaded: url_helper
INFO - 2016-02-01 13:54:52 --> Helper loaded: file_helper
INFO - 2016-02-01 13:54:52 --> Helper loaded: date_helper
INFO - 2016-02-01 13:54:52 --> Database Driver Class Initialized
INFO - 2016-02-01 13:54:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:54:53 --> Controller Class Initialized
INFO - 2016-02-01 13:54:53 --> Model Class Initialized
INFO - 2016-02-01 13:54:53 --> Model Class Initialized
INFO - 2016-02-01 13:54:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:54:53 --> Pagination Class Initialized
INFO - 2016-02-01 13:54:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:54:53 --> Helper loaded: text_helper
INFO - 2016-02-01 13:54:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 13:54:54 --> Severity: Notice --> Undefined property: stdClass::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
ERROR - 2016-02-01 13:54:54 --> Severity: Notice --> Undefined property: stdClass::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 21
INFO - 2016-02-01 13:54:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:54:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:54:54 --> Final output sent to browser
DEBUG - 2016-02-01 13:54:54 --> Total execution time: 1.1930
INFO - 2016-02-01 13:58:21 --> Config Class Initialized
INFO - 2016-02-01 13:58:21 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:58:21 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:58:21 --> Utf8 Class Initialized
INFO - 2016-02-01 13:58:21 --> URI Class Initialized
INFO - 2016-02-01 13:58:21 --> Router Class Initialized
INFO - 2016-02-01 13:58:21 --> Output Class Initialized
INFO - 2016-02-01 13:58:21 --> Security Class Initialized
DEBUG - 2016-02-01 13:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:58:21 --> Input Class Initialized
INFO - 2016-02-01 13:58:21 --> Language Class Initialized
INFO - 2016-02-01 13:58:21 --> Loader Class Initialized
INFO - 2016-02-01 13:58:21 --> Helper loaded: url_helper
INFO - 2016-02-01 13:58:21 --> Helper loaded: file_helper
INFO - 2016-02-01 13:58:21 --> Helper loaded: date_helper
INFO - 2016-02-01 13:58:21 --> Database Driver Class Initialized
INFO - 2016-02-01 13:58:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:58:22 --> Controller Class Initialized
INFO - 2016-02-01 13:58:22 --> Model Class Initialized
INFO - 2016-02-01 13:58:22 --> Model Class Initialized
INFO - 2016-02-01 13:58:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:58:22 --> Pagination Class Initialized
INFO - 2016-02-01 13:58:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:58:22 --> Helper loaded: text_helper
INFO - 2016-02-01 13:58:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 13:58:22 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 13:58:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:58:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:58:22 --> Final output sent to browser
DEBUG - 2016-02-01 13:58:22 --> Total execution time: 1.1503
INFO - 2016-02-01 13:58:46 --> Config Class Initialized
INFO - 2016-02-01 13:58:46 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:58:46 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:58:46 --> Utf8 Class Initialized
INFO - 2016-02-01 13:58:46 --> URI Class Initialized
INFO - 2016-02-01 13:58:46 --> Router Class Initialized
INFO - 2016-02-01 13:58:46 --> Output Class Initialized
INFO - 2016-02-01 13:58:46 --> Security Class Initialized
DEBUG - 2016-02-01 13:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:58:46 --> Input Class Initialized
INFO - 2016-02-01 13:58:46 --> Language Class Initialized
INFO - 2016-02-01 13:58:46 --> Loader Class Initialized
INFO - 2016-02-01 13:58:46 --> Helper loaded: url_helper
INFO - 2016-02-01 13:58:46 --> Helper loaded: file_helper
INFO - 2016-02-01 13:58:46 --> Helper loaded: date_helper
INFO - 2016-02-01 13:58:46 --> Database Driver Class Initialized
INFO - 2016-02-01 13:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:58:47 --> Controller Class Initialized
INFO - 2016-02-01 13:58:47 --> Model Class Initialized
INFO - 2016-02-01 13:58:47 --> Model Class Initialized
INFO - 2016-02-01 13:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:58:47 --> Pagination Class Initialized
INFO - 2016-02-01 13:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:58:47 --> Helper loaded: text_helper
INFO - 2016-02-01 13:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 13:58:47 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 13:59:08 --> Config Class Initialized
INFO - 2016-02-01 13:59:08 --> Hooks Class Initialized
DEBUG - 2016-02-01 13:59:08 --> UTF-8 Support Enabled
INFO - 2016-02-01 13:59:08 --> Utf8 Class Initialized
INFO - 2016-02-01 13:59:08 --> URI Class Initialized
INFO - 2016-02-01 13:59:08 --> Router Class Initialized
INFO - 2016-02-01 13:59:08 --> Output Class Initialized
INFO - 2016-02-01 13:59:08 --> Security Class Initialized
DEBUG - 2016-02-01 13:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 13:59:08 --> Input Class Initialized
INFO - 2016-02-01 13:59:08 --> Language Class Initialized
INFO - 2016-02-01 13:59:08 --> Loader Class Initialized
INFO - 2016-02-01 13:59:08 --> Helper loaded: url_helper
INFO - 2016-02-01 13:59:08 --> Helper loaded: file_helper
INFO - 2016-02-01 13:59:08 --> Helper loaded: date_helper
INFO - 2016-02-01 13:59:08 --> Database Driver Class Initialized
INFO - 2016-02-01 13:59:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 13:59:09 --> Controller Class Initialized
INFO - 2016-02-01 13:59:09 --> Model Class Initialized
INFO - 2016-02-01 13:59:09 --> Model Class Initialized
INFO - 2016-02-01 13:59:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 13:59:09 --> Pagination Class Initialized
INFO - 2016-02-01 13:59:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 13:59:09 --> Helper loaded: text_helper
INFO - 2016-02-01 13:59:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 13:59:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 13:59:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 13:59:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 13:59:09 --> Final output sent to browser
DEBUG - 2016-02-01 13:59:09 --> Total execution time: 1.2801
INFO - 2016-02-01 14:01:15 --> Config Class Initialized
INFO - 2016-02-01 14:01:15 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:01:15 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:01:15 --> Utf8 Class Initialized
INFO - 2016-02-01 14:01:15 --> URI Class Initialized
INFO - 2016-02-01 14:01:15 --> Router Class Initialized
INFO - 2016-02-01 14:01:15 --> Output Class Initialized
INFO - 2016-02-01 14:01:15 --> Security Class Initialized
DEBUG - 2016-02-01 14:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:01:15 --> Input Class Initialized
INFO - 2016-02-01 14:01:15 --> Language Class Initialized
INFO - 2016-02-01 14:01:15 --> Loader Class Initialized
INFO - 2016-02-01 14:01:15 --> Helper loaded: url_helper
INFO - 2016-02-01 14:01:15 --> Helper loaded: file_helper
INFO - 2016-02-01 14:01:15 --> Helper loaded: date_helper
INFO - 2016-02-01 14:01:15 --> Database Driver Class Initialized
INFO - 2016-02-01 14:01:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:01:16 --> Controller Class Initialized
INFO - 2016-02-01 14:01:16 --> Model Class Initialized
INFO - 2016-02-01 14:01:16 --> Model Class Initialized
INFO - 2016-02-01 14:01:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:01:16 --> Pagination Class Initialized
INFO - 2016-02-01 14:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:01:16 --> Helper loaded: text_helper
INFO - 2016-02-01 14:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:01:16 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:01:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:01:16 --> Final output sent to browser
DEBUG - 2016-02-01 14:01:16 --> Total execution time: 1.1710
INFO - 2016-02-01 14:01:39 --> Config Class Initialized
INFO - 2016-02-01 14:01:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:01:39 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:01:39 --> Utf8 Class Initialized
INFO - 2016-02-01 14:01:39 --> URI Class Initialized
INFO - 2016-02-01 14:01:39 --> Router Class Initialized
INFO - 2016-02-01 14:01:39 --> Output Class Initialized
INFO - 2016-02-01 14:01:39 --> Security Class Initialized
DEBUG - 2016-02-01 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:01:39 --> Input Class Initialized
INFO - 2016-02-01 14:01:39 --> Language Class Initialized
INFO - 2016-02-01 14:01:39 --> Loader Class Initialized
INFO - 2016-02-01 14:01:39 --> Helper loaded: url_helper
INFO - 2016-02-01 14:01:39 --> Helper loaded: file_helper
INFO - 2016-02-01 14:01:39 --> Helper loaded: date_helper
INFO - 2016-02-01 14:01:39 --> Database Driver Class Initialized
INFO - 2016-02-01 14:01:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:01:40 --> Controller Class Initialized
INFO - 2016-02-01 14:01:40 --> Model Class Initialized
INFO - 2016-02-01 14:01:40 --> Model Class Initialized
INFO - 2016-02-01 14:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:01:40 --> Pagination Class Initialized
INFO - 2016-02-01 14:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:01:40 --> Helper loaded: text_helper
ERROR - 2016-02-01 14:01:40 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 123
INFO - 2016-02-01 14:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:01:40 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:01:40 --> Final output sent to browser
DEBUG - 2016-02-01 14:01:40 --> Total execution time: 1.3093
INFO - 2016-02-01 14:02:01 --> Config Class Initialized
INFO - 2016-02-01 14:02:01 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:02:01 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:02:01 --> Utf8 Class Initialized
INFO - 2016-02-01 14:02:01 --> URI Class Initialized
INFO - 2016-02-01 14:02:01 --> Router Class Initialized
INFO - 2016-02-01 14:02:01 --> Output Class Initialized
INFO - 2016-02-01 14:02:01 --> Security Class Initialized
DEBUG - 2016-02-01 14:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:02:01 --> Input Class Initialized
INFO - 2016-02-01 14:02:01 --> Language Class Initialized
INFO - 2016-02-01 14:02:01 --> Loader Class Initialized
INFO - 2016-02-01 14:02:01 --> Helper loaded: url_helper
INFO - 2016-02-01 14:02:01 --> Helper loaded: file_helper
INFO - 2016-02-01 14:02:01 --> Helper loaded: date_helper
INFO - 2016-02-01 14:02:01 --> Database Driver Class Initialized
INFO - 2016-02-01 14:02:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:02:02 --> Controller Class Initialized
INFO - 2016-02-01 14:02:02 --> Model Class Initialized
INFO - 2016-02-01 14:02:02 --> Model Class Initialized
INFO - 2016-02-01 14:02:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:02:02 --> Pagination Class Initialized
INFO - 2016-02-01 14:02:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:02:02 --> Helper loaded: text_helper
ERROR - 2016-02-01 14:02:02 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 123
INFO - 2016-02-01 14:02:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:02:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:02:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:02:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:02:02 --> Final output sent to browser
DEBUG - 2016-02-01 14:02:02 --> Total execution time: 1.1631
INFO - 2016-02-01 14:08:06 --> Config Class Initialized
INFO - 2016-02-01 14:08:06 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:08:06 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:08:06 --> Utf8 Class Initialized
INFO - 2016-02-01 14:08:06 --> URI Class Initialized
INFO - 2016-02-01 14:08:06 --> Router Class Initialized
INFO - 2016-02-01 14:08:06 --> Output Class Initialized
INFO - 2016-02-01 14:08:06 --> Security Class Initialized
DEBUG - 2016-02-01 14:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:08:06 --> Input Class Initialized
INFO - 2016-02-01 14:08:06 --> Language Class Initialized
INFO - 2016-02-01 14:08:06 --> Loader Class Initialized
INFO - 2016-02-01 14:08:06 --> Helper loaded: url_helper
INFO - 2016-02-01 14:08:06 --> Helper loaded: file_helper
INFO - 2016-02-01 14:08:06 --> Helper loaded: date_helper
INFO - 2016-02-01 14:08:06 --> Database Driver Class Initialized
INFO - 2016-02-01 14:08:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:08:07 --> Controller Class Initialized
INFO - 2016-02-01 14:08:07 --> Model Class Initialized
INFO - 2016-02-01 14:08:07 --> Model Class Initialized
INFO - 2016-02-01 14:08:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:08:07 --> Pagination Class Initialized
INFO - 2016-02-01 14:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:08:07 --> Helper loaded: text_helper
INFO - 2016-02-01 14:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:08:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:08:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:08:07 --> Final output sent to browser
DEBUG - 2016-02-01 14:08:07 --> Total execution time: 1.1578
INFO - 2016-02-01 14:08:30 --> Config Class Initialized
INFO - 2016-02-01 14:08:30 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:08:30 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:08:30 --> Utf8 Class Initialized
INFO - 2016-02-01 14:08:30 --> URI Class Initialized
INFO - 2016-02-01 14:08:30 --> Router Class Initialized
INFO - 2016-02-01 14:08:30 --> Output Class Initialized
INFO - 2016-02-01 14:08:30 --> Security Class Initialized
DEBUG - 2016-02-01 14:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:08:30 --> Input Class Initialized
INFO - 2016-02-01 14:08:30 --> Language Class Initialized
INFO - 2016-02-01 14:08:30 --> Loader Class Initialized
INFO - 2016-02-01 14:08:30 --> Helper loaded: url_helper
INFO - 2016-02-01 14:08:30 --> Helper loaded: file_helper
INFO - 2016-02-01 14:08:30 --> Helper loaded: date_helper
INFO - 2016-02-01 14:08:30 --> Database Driver Class Initialized
INFO - 2016-02-01 14:08:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:08:31 --> Controller Class Initialized
INFO - 2016-02-01 14:08:31 --> Model Class Initialized
INFO - 2016-02-01 14:08:31 --> Model Class Initialized
INFO - 2016-02-01 14:08:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:08:31 --> Pagination Class Initialized
INFO - 2016-02-01 14:08:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:08:31 --> Helper loaded: text_helper
INFO - 2016-02-01 14:08:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:08:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:08:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:08:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:08:31 --> Final output sent to browser
DEBUG - 2016-02-01 14:08:31 --> Total execution time: 1.1691
INFO - 2016-02-01 14:09:16 --> Config Class Initialized
INFO - 2016-02-01 14:09:16 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:09:16 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:09:16 --> Utf8 Class Initialized
INFO - 2016-02-01 14:09:16 --> URI Class Initialized
INFO - 2016-02-01 14:09:16 --> Router Class Initialized
INFO - 2016-02-01 14:09:16 --> Output Class Initialized
INFO - 2016-02-01 14:09:16 --> Security Class Initialized
DEBUG - 2016-02-01 14:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:09:16 --> Input Class Initialized
INFO - 2016-02-01 14:09:16 --> Language Class Initialized
INFO - 2016-02-01 14:09:16 --> Loader Class Initialized
INFO - 2016-02-01 14:09:16 --> Helper loaded: url_helper
INFO - 2016-02-01 14:09:16 --> Helper loaded: file_helper
INFO - 2016-02-01 14:09:16 --> Helper loaded: date_helper
INFO - 2016-02-01 14:09:16 --> Database Driver Class Initialized
INFO - 2016-02-01 14:09:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:09:17 --> Controller Class Initialized
INFO - 2016-02-01 14:09:17 --> Model Class Initialized
INFO - 2016-02-01 14:09:17 --> Model Class Initialized
INFO - 2016-02-01 14:09:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:09:17 --> Pagination Class Initialized
INFO - 2016-02-01 14:09:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:09:17 --> Helper loaded: text_helper
INFO - 2016-02-01 14:09:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:09:17 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:09:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:09:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:09:17 --> Final output sent to browser
DEBUG - 2016-02-01 14:09:17 --> Total execution time: 1.1585
INFO - 2016-02-01 14:09:55 --> Config Class Initialized
INFO - 2016-02-01 14:09:55 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:09:55 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:09:55 --> Utf8 Class Initialized
INFO - 2016-02-01 14:09:55 --> URI Class Initialized
INFO - 2016-02-01 14:09:55 --> Router Class Initialized
INFO - 2016-02-01 14:09:55 --> Output Class Initialized
INFO - 2016-02-01 14:09:55 --> Security Class Initialized
DEBUG - 2016-02-01 14:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:09:55 --> Input Class Initialized
INFO - 2016-02-01 14:09:55 --> Language Class Initialized
INFO - 2016-02-01 14:09:55 --> Loader Class Initialized
INFO - 2016-02-01 14:09:55 --> Helper loaded: url_helper
INFO - 2016-02-01 14:09:55 --> Helper loaded: file_helper
INFO - 2016-02-01 14:09:55 --> Helper loaded: date_helper
INFO - 2016-02-01 14:09:55 --> Database Driver Class Initialized
INFO - 2016-02-01 14:09:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:09:56 --> Controller Class Initialized
INFO - 2016-02-01 14:09:56 --> Model Class Initialized
INFO - 2016-02-01 14:09:56 --> Model Class Initialized
INFO - 2016-02-01 14:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:09:56 --> Pagination Class Initialized
INFO - 2016-02-01 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:09:56 --> Helper loaded: text_helper
INFO - 2016-02-01 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:09:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:09:56 --> Final output sent to browser
DEBUG - 2016-02-01 14:09:56 --> Total execution time: 1.1384
INFO - 2016-02-01 14:10:08 --> Config Class Initialized
INFO - 2016-02-01 14:10:08 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:10:08 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:10:08 --> Utf8 Class Initialized
INFO - 2016-02-01 14:10:08 --> URI Class Initialized
INFO - 2016-02-01 14:10:08 --> Router Class Initialized
INFO - 2016-02-01 14:10:08 --> Output Class Initialized
INFO - 2016-02-01 14:10:08 --> Security Class Initialized
DEBUG - 2016-02-01 14:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:10:08 --> Input Class Initialized
INFO - 2016-02-01 14:10:08 --> Language Class Initialized
INFO - 2016-02-01 14:10:08 --> Loader Class Initialized
INFO - 2016-02-01 14:10:08 --> Helper loaded: url_helper
INFO - 2016-02-01 14:10:08 --> Helper loaded: file_helper
INFO - 2016-02-01 14:10:08 --> Helper loaded: date_helper
INFO - 2016-02-01 14:10:08 --> Database Driver Class Initialized
INFO - 2016-02-01 14:10:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:10:09 --> Controller Class Initialized
INFO - 2016-02-01 14:10:09 --> Model Class Initialized
INFO - 2016-02-01 14:10:09 --> Model Class Initialized
INFO - 2016-02-01 14:10:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:10:09 --> Pagination Class Initialized
INFO - 2016-02-01 14:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:10:09 --> Helper loaded: text_helper
INFO - 2016-02-01 14:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:10:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:10:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:10:09 --> Final output sent to browser
DEBUG - 2016-02-01 14:10:09 --> Total execution time: 1.1672
INFO - 2016-02-01 14:11:48 --> Config Class Initialized
INFO - 2016-02-01 14:11:48 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:11:48 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:11:48 --> Utf8 Class Initialized
INFO - 2016-02-01 14:11:48 --> URI Class Initialized
INFO - 2016-02-01 14:11:48 --> Router Class Initialized
INFO - 2016-02-01 14:11:48 --> Output Class Initialized
INFO - 2016-02-01 14:11:48 --> Security Class Initialized
DEBUG - 2016-02-01 14:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:11:48 --> Input Class Initialized
INFO - 2016-02-01 14:11:48 --> Language Class Initialized
INFO - 2016-02-01 14:11:48 --> Loader Class Initialized
INFO - 2016-02-01 14:11:48 --> Helper loaded: url_helper
INFO - 2016-02-01 14:11:48 --> Helper loaded: file_helper
INFO - 2016-02-01 14:11:48 --> Helper loaded: date_helper
INFO - 2016-02-01 14:11:48 --> Database Driver Class Initialized
INFO - 2016-02-01 14:11:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:11:49 --> Controller Class Initialized
INFO - 2016-02-01 14:11:49 --> Model Class Initialized
INFO - 2016-02-01 14:11:49 --> Model Class Initialized
INFO - 2016-02-01 14:11:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:11:49 --> Pagination Class Initialized
INFO - 2016-02-01 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:11:49 --> Helper loaded: text_helper
INFO - 2016-02-01 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:11:49 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:11:49 --> Final output sent to browser
DEBUG - 2016-02-01 14:11:49 --> Total execution time: 1.1308
INFO - 2016-02-01 14:14:42 --> Config Class Initialized
INFO - 2016-02-01 14:14:42 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:14:42 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:14:42 --> Utf8 Class Initialized
INFO - 2016-02-01 14:14:42 --> URI Class Initialized
INFO - 2016-02-01 14:14:42 --> Router Class Initialized
INFO - 2016-02-01 14:14:42 --> Output Class Initialized
INFO - 2016-02-01 14:14:42 --> Security Class Initialized
DEBUG - 2016-02-01 14:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:14:42 --> Input Class Initialized
INFO - 2016-02-01 14:14:42 --> Language Class Initialized
INFO - 2016-02-01 14:14:43 --> Loader Class Initialized
INFO - 2016-02-01 14:14:43 --> Helper loaded: url_helper
INFO - 2016-02-01 14:14:43 --> Helper loaded: file_helper
INFO - 2016-02-01 14:14:43 --> Helper loaded: date_helper
INFO - 2016-02-01 14:14:43 --> Database Driver Class Initialized
INFO - 2016-02-01 14:14:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:14:44 --> Controller Class Initialized
INFO - 2016-02-01 14:14:44 --> Model Class Initialized
ERROR - 2016-02-01 14:14:44 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 59
INFO - 2016-02-01 14:14:50 --> Config Class Initialized
INFO - 2016-02-01 14:14:50 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:14:50 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:14:50 --> Utf8 Class Initialized
INFO - 2016-02-01 14:14:50 --> URI Class Initialized
INFO - 2016-02-01 14:14:50 --> Router Class Initialized
INFO - 2016-02-01 14:14:50 --> Output Class Initialized
INFO - 2016-02-01 14:14:50 --> Security Class Initialized
DEBUG - 2016-02-01 14:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:14:50 --> Input Class Initialized
INFO - 2016-02-01 14:14:50 --> Language Class Initialized
INFO - 2016-02-01 14:14:50 --> Loader Class Initialized
INFO - 2016-02-01 14:14:50 --> Helper loaded: url_helper
INFO - 2016-02-01 14:14:50 --> Helper loaded: file_helper
INFO - 2016-02-01 14:14:50 --> Helper loaded: date_helper
INFO - 2016-02-01 14:14:50 --> Database Driver Class Initialized
INFO - 2016-02-01 14:14:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:14:51 --> Controller Class Initialized
INFO - 2016-02-01 14:14:51 --> Model Class Initialized
ERROR - 2016-02-01 14:14:51 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 59
INFO - 2016-02-01 14:15:03 --> Config Class Initialized
INFO - 2016-02-01 14:15:03 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:15:03 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:15:03 --> Utf8 Class Initialized
INFO - 2016-02-01 14:15:03 --> URI Class Initialized
INFO - 2016-02-01 14:15:03 --> Router Class Initialized
INFO - 2016-02-01 14:15:03 --> Output Class Initialized
INFO - 2016-02-01 14:15:03 --> Security Class Initialized
DEBUG - 2016-02-01 14:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:15:03 --> Input Class Initialized
INFO - 2016-02-01 14:15:03 --> Language Class Initialized
INFO - 2016-02-01 14:15:03 --> Loader Class Initialized
INFO - 2016-02-01 14:15:03 --> Helper loaded: url_helper
INFO - 2016-02-01 14:15:03 --> Helper loaded: file_helper
INFO - 2016-02-01 14:15:03 --> Helper loaded: date_helper
INFO - 2016-02-01 14:15:03 --> Database Driver Class Initialized
INFO - 2016-02-01 14:15:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:15:04 --> Controller Class Initialized
INFO - 2016-02-01 14:15:04 --> Model Class Initialized
INFO - 2016-02-01 14:15:04 --> Model Class Initialized
INFO - 2016-02-01 14:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:15:04 --> Pagination Class Initialized
INFO - 2016-02-01 14:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:15:04 --> Helper loaded: text_helper
ERROR - 2016-02-01 14:15:04 --> Query error: Unknown column 'max_vote' in 'field list' - Invalid query: SELECT `max_vote`, MAX(`vote`) AS `vote`
FROM `jdmain`
 LIMIT 3
INFO - 2016-02-01 14:15:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-01 14:16:16 --> Config Class Initialized
INFO - 2016-02-01 14:16:16 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:16:16 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:16:16 --> Utf8 Class Initialized
INFO - 2016-02-01 14:16:16 --> URI Class Initialized
INFO - 2016-02-01 14:16:16 --> Router Class Initialized
INFO - 2016-02-01 14:16:16 --> Output Class Initialized
INFO - 2016-02-01 14:16:16 --> Security Class Initialized
DEBUG - 2016-02-01 14:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:16:16 --> Input Class Initialized
INFO - 2016-02-01 14:16:16 --> Language Class Initialized
INFO - 2016-02-01 14:16:16 --> Loader Class Initialized
INFO - 2016-02-01 14:16:16 --> Helper loaded: url_helper
INFO - 2016-02-01 14:16:16 --> Helper loaded: file_helper
INFO - 2016-02-01 14:16:16 --> Helper loaded: date_helper
INFO - 2016-02-01 14:16:16 --> Database Driver Class Initialized
INFO - 2016-02-01 14:16:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:16:17 --> Controller Class Initialized
INFO - 2016-02-01 14:16:17 --> Model Class Initialized
INFO - 2016-02-01 14:16:17 --> Model Class Initialized
INFO - 2016-02-01 14:16:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:16:17 --> Pagination Class Initialized
INFO - 2016-02-01 14:16:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:16:17 --> Helper loaded: text_helper
INFO - 2016-02-01 14:16:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:16:17 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:16:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:16:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:16:17 --> Final output sent to browser
DEBUG - 2016-02-01 14:16:17 --> Total execution time: 1.2747
INFO - 2016-02-01 14:16:37 --> Config Class Initialized
INFO - 2016-02-01 14:16:37 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:16:37 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:16:37 --> Utf8 Class Initialized
INFO - 2016-02-01 14:16:37 --> URI Class Initialized
INFO - 2016-02-01 14:16:37 --> Router Class Initialized
INFO - 2016-02-01 14:16:38 --> Output Class Initialized
INFO - 2016-02-01 14:16:38 --> Security Class Initialized
DEBUG - 2016-02-01 14:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:16:38 --> Input Class Initialized
INFO - 2016-02-01 14:16:38 --> Language Class Initialized
INFO - 2016-02-01 14:16:38 --> Loader Class Initialized
INFO - 2016-02-01 14:16:38 --> Helper loaded: url_helper
INFO - 2016-02-01 14:16:38 --> Helper loaded: file_helper
INFO - 2016-02-01 14:16:38 --> Helper loaded: date_helper
INFO - 2016-02-01 14:16:38 --> Database Driver Class Initialized
INFO - 2016-02-01 14:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:16:39 --> Controller Class Initialized
INFO - 2016-02-01 14:16:39 --> Model Class Initialized
INFO - 2016-02-01 14:16:39 --> Model Class Initialized
INFO - 2016-02-01 14:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:16:39 --> Pagination Class Initialized
INFO - 2016-02-01 14:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:16:39 --> Helper loaded: text_helper
INFO - 2016-02-01 14:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:16:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:16:39 --> Final output sent to browser
DEBUG - 2016-02-01 14:16:39 --> Total execution time: 1.1337
INFO - 2016-02-01 14:17:41 --> Config Class Initialized
INFO - 2016-02-01 14:17:41 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:17:41 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:17:41 --> Utf8 Class Initialized
INFO - 2016-02-01 14:17:41 --> URI Class Initialized
INFO - 2016-02-01 14:17:41 --> Router Class Initialized
INFO - 2016-02-01 14:17:41 --> Output Class Initialized
INFO - 2016-02-01 14:17:41 --> Security Class Initialized
DEBUG - 2016-02-01 14:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:17:41 --> Input Class Initialized
INFO - 2016-02-01 14:17:41 --> Language Class Initialized
INFO - 2016-02-01 14:17:41 --> Loader Class Initialized
INFO - 2016-02-01 14:17:41 --> Helper loaded: url_helper
INFO - 2016-02-01 14:17:41 --> Helper loaded: file_helper
INFO - 2016-02-01 14:17:41 --> Helper loaded: date_helper
INFO - 2016-02-01 14:17:41 --> Database Driver Class Initialized
INFO - 2016-02-01 14:17:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:17:42 --> Controller Class Initialized
INFO - 2016-02-01 14:17:42 --> Model Class Initialized
INFO - 2016-02-01 14:17:42 --> Model Class Initialized
INFO - 2016-02-01 14:17:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:17:42 --> Pagination Class Initialized
INFO - 2016-02-01 14:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:17:42 --> Helper loaded: text_helper
INFO - 2016-02-01 14:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:17:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:17:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:17:42 --> Final output sent to browser
DEBUG - 2016-02-01 14:17:42 --> Total execution time: 1.1351
INFO - 2016-02-01 14:18:38 --> Config Class Initialized
INFO - 2016-02-01 14:18:38 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:18:38 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:18:38 --> Utf8 Class Initialized
INFO - 2016-02-01 14:18:38 --> URI Class Initialized
INFO - 2016-02-01 14:18:38 --> Router Class Initialized
INFO - 2016-02-01 14:18:38 --> Output Class Initialized
INFO - 2016-02-01 14:18:39 --> Security Class Initialized
DEBUG - 2016-02-01 14:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:18:39 --> Input Class Initialized
INFO - 2016-02-01 14:18:39 --> Language Class Initialized
INFO - 2016-02-01 14:18:39 --> Loader Class Initialized
INFO - 2016-02-01 14:18:39 --> Helper loaded: url_helper
INFO - 2016-02-01 14:18:39 --> Helper loaded: file_helper
INFO - 2016-02-01 14:18:39 --> Helper loaded: date_helper
INFO - 2016-02-01 14:18:39 --> Database Driver Class Initialized
INFO - 2016-02-01 14:18:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:18:40 --> Controller Class Initialized
INFO - 2016-02-01 14:18:40 --> Model Class Initialized
INFO - 2016-02-01 14:18:40 --> Model Class Initialized
INFO - 2016-02-01 14:18:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:18:40 --> Pagination Class Initialized
INFO - 2016-02-01 14:18:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:18:40 --> Helper loaded: text_helper
INFO - 2016-02-01 14:18:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:18:40 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:18:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:18:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:18:40 --> Final output sent to browser
DEBUG - 2016-02-01 14:18:40 --> Total execution time: 1.1497
INFO - 2016-02-01 14:19:27 --> Config Class Initialized
INFO - 2016-02-01 14:19:27 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:19:27 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:19:27 --> Utf8 Class Initialized
INFO - 2016-02-01 14:19:27 --> URI Class Initialized
INFO - 2016-02-01 14:19:27 --> Router Class Initialized
INFO - 2016-02-01 14:19:27 --> Output Class Initialized
INFO - 2016-02-01 14:19:27 --> Security Class Initialized
DEBUG - 2016-02-01 14:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:19:27 --> Input Class Initialized
INFO - 2016-02-01 14:19:27 --> Language Class Initialized
INFO - 2016-02-01 14:19:27 --> Loader Class Initialized
INFO - 2016-02-01 14:19:27 --> Helper loaded: url_helper
INFO - 2016-02-01 14:19:27 --> Helper loaded: file_helper
INFO - 2016-02-01 14:19:27 --> Helper loaded: date_helper
INFO - 2016-02-01 14:19:27 --> Database Driver Class Initialized
INFO - 2016-02-01 14:19:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:19:28 --> Controller Class Initialized
INFO - 2016-02-01 14:19:28 --> Model Class Initialized
INFO - 2016-02-01 14:19:28 --> Model Class Initialized
INFO - 2016-02-01 14:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:19:28 --> Pagination Class Initialized
INFO - 2016-02-01 14:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:19:28 --> Helper loaded: text_helper
INFO - 2016-02-01 14:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:19:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:19:28 --> Final output sent to browser
DEBUG - 2016-02-01 14:19:28 --> Total execution time: 1.1528
INFO - 2016-02-01 14:21:29 --> Config Class Initialized
INFO - 2016-02-01 14:21:30 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:21:30 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:21:30 --> Utf8 Class Initialized
INFO - 2016-02-01 14:21:30 --> URI Class Initialized
INFO - 2016-02-01 14:21:30 --> Router Class Initialized
INFO - 2016-02-01 14:21:30 --> Output Class Initialized
INFO - 2016-02-01 14:21:30 --> Security Class Initialized
DEBUG - 2016-02-01 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:21:30 --> Input Class Initialized
INFO - 2016-02-01 14:21:30 --> Language Class Initialized
INFO - 2016-02-01 14:21:30 --> Loader Class Initialized
INFO - 2016-02-01 14:21:30 --> Helper loaded: url_helper
INFO - 2016-02-01 14:21:30 --> Helper loaded: file_helper
INFO - 2016-02-01 14:21:30 --> Helper loaded: date_helper
INFO - 2016-02-01 14:21:30 --> Database Driver Class Initialized
INFO - 2016-02-01 14:21:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:21:31 --> Controller Class Initialized
INFO - 2016-02-01 14:21:31 --> Model Class Initialized
INFO - 2016-02-01 14:21:31 --> Model Class Initialized
INFO - 2016-02-01 14:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:21:31 --> Pagination Class Initialized
INFO - 2016-02-01 14:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:21:31 --> Helper loaded: text_helper
INFO - 2016-02-01 14:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
ERROR - 2016-02-01 14:21:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 19
INFO - 2016-02-01 14:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:21:31 --> Final output sent to browser
DEBUG - 2016-02-01 14:21:31 --> Total execution time: 1.1357
INFO - 2016-02-01 14:22:37 --> Config Class Initialized
INFO - 2016-02-01 14:22:37 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:22:37 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:22:37 --> Utf8 Class Initialized
INFO - 2016-02-01 14:22:37 --> URI Class Initialized
DEBUG - 2016-02-01 14:22:37 --> No URI present. Default controller set.
INFO - 2016-02-01 14:22:37 --> Router Class Initialized
INFO - 2016-02-01 14:22:37 --> Output Class Initialized
INFO - 2016-02-01 14:22:37 --> Security Class Initialized
DEBUG - 2016-02-01 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:22:37 --> Input Class Initialized
INFO - 2016-02-01 14:22:37 --> Language Class Initialized
INFO - 2016-02-01 14:22:37 --> Loader Class Initialized
INFO - 2016-02-01 14:22:37 --> Helper loaded: url_helper
INFO - 2016-02-01 14:22:37 --> Helper loaded: file_helper
INFO - 2016-02-01 14:22:37 --> Helper loaded: date_helper
INFO - 2016-02-01 14:22:37 --> Database Driver Class Initialized
INFO - 2016-02-01 14:22:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:22:38 --> Controller Class Initialized
INFO - 2016-02-01 14:22:38 --> Model Class Initialized
INFO - 2016-02-01 14:22:38 --> Model Class Initialized
INFO - 2016-02-01 14:22:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:22:38 --> Pagination Class Initialized
INFO - 2016-02-01 14:22:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:22:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 14:22:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:22:38 --> Final output sent to browser
DEBUG - 2016-02-01 14:22:38 --> Total execution time: 1.1899
INFO - 2016-02-01 14:22:40 --> Config Class Initialized
INFO - 2016-02-01 14:22:40 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:22:40 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:22:40 --> Utf8 Class Initialized
INFO - 2016-02-01 14:22:40 --> URI Class Initialized
INFO - 2016-02-01 14:22:40 --> Router Class Initialized
INFO - 2016-02-01 14:22:40 --> Output Class Initialized
INFO - 2016-02-01 14:22:40 --> Security Class Initialized
DEBUG - 2016-02-01 14:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:22:40 --> Input Class Initialized
INFO - 2016-02-01 14:22:40 --> Language Class Initialized
INFO - 2016-02-01 14:22:40 --> Loader Class Initialized
INFO - 2016-02-01 14:22:40 --> Helper loaded: url_helper
INFO - 2016-02-01 14:22:40 --> Helper loaded: file_helper
INFO - 2016-02-01 14:22:40 --> Helper loaded: date_helper
INFO - 2016-02-01 14:22:40 --> Database Driver Class Initialized
INFO - 2016-02-01 14:22:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:22:41 --> Controller Class Initialized
INFO - 2016-02-01 14:22:41 --> Model Class Initialized
INFO - 2016-02-01 14:22:41 --> Model Class Initialized
INFO - 2016-02-01 14:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:22:41 --> Pagination Class Initialized
INFO - 2016-02-01 14:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:22:41 --> Helper loaded: text_helper
INFO - 2016-02-01 14:22:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:22:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:22:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:22:42 --> Final output sent to browser
DEBUG - 2016-02-01 14:22:42 --> Total execution time: 1.4824
INFO - 2016-02-01 14:23:29 --> Config Class Initialized
INFO - 2016-02-01 14:23:29 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:23:29 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:23:29 --> Utf8 Class Initialized
INFO - 2016-02-01 14:23:29 --> URI Class Initialized
INFO - 2016-02-01 14:23:29 --> Router Class Initialized
INFO - 2016-02-01 14:23:29 --> Output Class Initialized
INFO - 2016-02-01 14:23:29 --> Security Class Initialized
DEBUG - 2016-02-01 14:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:23:29 --> Input Class Initialized
INFO - 2016-02-01 14:23:29 --> Language Class Initialized
INFO - 2016-02-01 14:23:29 --> Loader Class Initialized
INFO - 2016-02-01 14:23:29 --> Helper loaded: url_helper
INFO - 2016-02-01 14:23:29 --> Helper loaded: file_helper
INFO - 2016-02-01 14:23:29 --> Helper loaded: date_helper
INFO - 2016-02-01 14:23:29 --> Database Driver Class Initialized
INFO - 2016-02-01 14:23:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:23:30 --> Controller Class Initialized
INFO - 2016-02-01 14:23:30 --> Model Class Initialized
INFO - 2016-02-01 14:23:30 --> Model Class Initialized
INFO - 2016-02-01 14:23:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:23:30 --> Pagination Class Initialized
INFO - 2016-02-01 14:23:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:23:30 --> Helper loaded: text_helper
INFO - 2016-02-01 14:23:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:23:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:23:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:23:30 --> Final output sent to browser
DEBUG - 2016-02-01 14:23:30 --> Total execution time: 1.6976
INFO - 2016-02-01 14:25:47 --> Config Class Initialized
INFO - 2016-02-01 14:25:47 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:25:47 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:25:47 --> Utf8 Class Initialized
INFO - 2016-02-01 14:25:47 --> URI Class Initialized
INFO - 2016-02-01 14:25:47 --> Router Class Initialized
INFO - 2016-02-01 14:25:47 --> Output Class Initialized
INFO - 2016-02-01 14:25:47 --> Security Class Initialized
DEBUG - 2016-02-01 14:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:25:47 --> Input Class Initialized
INFO - 2016-02-01 14:25:47 --> Language Class Initialized
INFO - 2016-02-01 14:25:47 --> Loader Class Initialized
INFO - 2016-02-01 14:25:47 --> Helper loaded: url_helper
INFO - 2016-02-01 14:25:47 --> Helper loaded: file_helper
INFO - 2016-02-01 14:25:47 --> Helper loaded: date_helper
INFO - 2016-02-01 14:25:47 --> Database Driver Class Initialized
INFO - 2016-02-01 14:25:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:25:48 --> Controller Class Initialized
INFO - 2016-02-01 14:25:48 --> Model Class Initialized
INFO - 2016-02-01 14:25:48 --> Model Class Initialized
INFO - 2016-02-01 14:25:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:25:48 --> Pagination Class Initialized
INFO - 2016-02-01 14:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:25:48 --> Helper loaded: text_helper
INFO - 2016-02-01 14:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:25:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:25:48 --> Final output sent to browser
DEBUG - 2016-02-01 14:25:48 --> Total execution time: 1.4517
INFO - 2016-02-01 14:26:01 --> Config Class Initialized
INFO - 2016-02-01 14:26:01 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:26:01 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:26:01 --> Utf8 Class Initialized
INFO - 2016-02-01 14:26:01 --> URI Class Initialized
DEBUG - 2016-02-01 14:26:01 --> No URI present. Default controller set.
INFO - 2016-02-01 14:26:01 --> Router Class Initialized
INFO - 2016-02-01 14:26:01 --> Output Class Initialized
INFO - 2016-02-01 14:26:01 --> Security Class Initialized
DEBUG - 2016-02-01 14:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:26:01 --> Input Class Initialized
INFO - 2016-02-01 14:26:01 --> Language Class Initialized
INFO - 2016-02-01 14:26:01 --> Loader Class Initialized
INFO - 2016-02-01 14:26:01 --> Helper loaded: url_helper
INFO - 2016-02-01 14:26:01 --> Helper loaded: file_helper
INFO - 2016-02-01 14:26:01 --> Helper loaded: date_helper
INFO - 2016-02-01 14:26:01 --> Database Driver Class Initialized
INFO - 2016-02-01 14:26:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:26:02 --> Controller Class Initialized
INFO - 2016-02-01 14:26:02 --> Model Class Initialized
INFO - 2016-02-01 14:26:02 --> Model Class Initialized
INFO - 2016-02-01 14:26:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:26:02 --> Pagination Class Initialized
INFO - 2016-02-01 14:26:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:26:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 14:26:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:26:02 --> Final output sent to browser
DEBUG - 2016-02-01 14:26:02 --> Total execution time: 1.2173
INFO - 2016-02-01 14:26:15 --> Config Class Initialized
INFO - 2016-02-01 14:26:15 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:26:15 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:26:15 --> Utf8 Class Initialized
INFO - 2016-02-01 14:26:15 --> URI Class Initialized
INFO - 2016-02-01 14:26:15 --> Router Class Initialized
INFO - 2016-02-01 14:26:15 --> Output Class Initialized
INFO - 2016-02-01 14:26:15 --> Security Class Initialized
DEBUG - 2016-02-01 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:26:15 --> Input Class Initialized
INFO - 2016-02-01 14:26:15 --> Language Class Initialized
INFO - 2016-02-01 14:26:15 --> Loader Class Initialized
INFO - 2016-02-01 14:26:15 --> Helper loaded: url_helper
INFO - 2016-02-01 14:26:15 --> Helper loaded: file_helper
INFO - 2016-02-01 14:26:15 --> Helper loaded: date_helper
INFO - 2016-02-01 14:26:15 --> Database Driver Class Initialized
INFO - 2016-02-01 14:26:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:26:16 --> Controller Class Initialized
INFO - 2016-02-01 14:26:16 --> Model Class Initialized
INFO - 2016-02-01 14:26:16 --> Model Class Initialized
INFO - 2016-02-01 14:26:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:26:16 --> Pagination Class Initialized
INFO - 2016-02-01 14:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 14:26:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:26:16 --> Final output sent to browser
DEBUG - 2016-02-01 14:26:16 --> Total execution time: 1.1594
INFO - 2016-02-01 14:26:19 --> Config Class Initialized
INFO - 2016-02-01 14:26:19 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:26:19 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:26:19 --> Utf8 Class Initialized
INFO - 2016-02-01 14:26:19 --> URI Class Initialized
INFO - 2016-02-01 14:26:19 --> Router Class Initialized
INFO - 2016-02-01 14:26:19 --> Output Class Initialized
INFO - 2016-02-01 14:26:19 --> Security Class Initialized
DEBUG - 2016-02-01 14:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:26:19 --> Input Class Initialized
INFO - 2016-02-01 14:26:19 --> Language Class Initialized
INFO - 2016-02-01 14:26:19 --> Loader Class Initialized
INFO - 2016-02-01 14:26:19 --> Helper loaded: url_helper
INFO - 2016-02-01 14:26:19 --> Helper loaded: file_helper
INFO - 2016-02-01 14:26:19 --> Helper loaded: date_helper
INFO - 2016-02-01 14:26:19 --> Database Driver Class Initialized
INFO - 2016-02-01 14:26:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:26:20 --> Controller Class Initialized
INFO - 2016-02-01 14:26:20 --> Model Class Initialized
INFO - 2016-02-01 14:26:20 --> Model Class Initialized
INFO - 2016-02-01 14:26:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:26:20 --> Pagination Class Initialized
INFO - 2016-02-01 14:26:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:26:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 14:26:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:26:20 --> Final output sent to browser
DEBUG - 2016-02-01 14:26:20 --> Total execution time: 1.1276
INFO - 2016-02-01 14:26:23 --> Config Class Initialized
INFO - 2016-02-01 14:26:23 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:26:23 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:26:23 --> Utf8 Class Initialized
INFO - 2016-02-01 14:26:23 --> URI Class Initialized
INFO - 2016-02-01 14:26:23 --> Router Class Initialized
INFO - 2016-02-01 14:26:23 --> Output Class Initialized
INFO - 2016-02-01 14:26:23 --> Security Class Initialized
DEBUG - 2016-02-01 14:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:26:23 --> Input Class Initialized
INFO - 2016-02-01 14:26:23 --> Language Class Initialized
INFO - 2016-02-01 14:26:23 --> Loader Class Initialized
INFO - 2016-02-01 14:26:23 --> Helper loaded: url_helper
INFO - 2016-02-01 14:26:23 --> Helper loaded: file_helper
INFO - 2016-02-01 14:26:23 --> Helper loaded: date_helper
INFO - 2016-02-01 14:26:23 --> Database Driver Class Initialized
INFO - 2016-02-01 14:26:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:26:24 --> Controller Class Initialized
INFO - 2016-02-01 14:26:24 --> Model Class Initialized
INFO - 2016-02-01 14:26:24 --> Model Class Initialized
INFO - 2016-02-01 14:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:26:24 --> Pagination Class Initialized
INFO - 2016-02-01 14:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 14:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:26:24 --> Final output sent to browser
DEBUG - 2016-02-01 14:26:24 --> Total execution time: 1.1293
INFO - 2016-02-01 14:26:26 --> Config Class Initialized
INFO - 2016-02-01 14:26:26 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:26:26 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:26:26 --> Utf8 Class Initialized
INFO - 2016-02-01 14:26:26 --> URI Class Initialized
INFO - 2016-02-01 14:26:26 --> Router Class Initialized
INFO - 2016-02-01 14:26:26 --> Output Class Initialized
INFO - 2016-02-01 14:26:26 --> Security Class Initialized
DEBUG - 2016-02-01 14:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:26:26 --> Input Class Initialized
INFO - 2016-02-01 14:26:26 --> Language Class Initialized
INFO - 2016-02-01 14:26:26 --> Loader Class Initialized
INFO - 2016-02-01 14:26:26 --> Helper loaded: url_helper
INFO - 2016-02-01 14:26:26 --> Helper loaded: file_helper
INFO - 2016-02-01 14:26:26 --> Helper loaded: date_helper
INFO - 2016-02-01 14:26:26 --> Database Driver Class Initialized
INFO - 2016-02-01 14:26:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:26:27 --> Controller Class Initialized
INFO - 2016-02-01 14:26:27 --> Model Class Initialized
INFO - 2016-02-01 14:26:27 --> Model Class Initialized
INFO - 2016-02-01 14:26:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:26:27 --> Pagination Class Initialized
INFO - 2016-02-01 14:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 14:26:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:26:27 --> Final output sent to browser
DEBUG - 2016-02-01 14:26:27 --> Total execution time: 1.1683
INFO - 2016-02-01 14:26:33 --> Config Class Initialized
INFO - 2016-02-01 14:26:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:26:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:26:33 --> Utf8 Class Initialized
INFO - 2016-02-01 14:26:33 --> URI Class Initialized
INFO - 2016-02-01 14:26:33 --> Router Class Initialized
INFO - 2016-02-01 14:26:33 --> Output Class Initialized
INFO - 2016-02-01 14:26:33 --> Security Class Initialized
DEBUG - 2016-02-01 14:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:26:33 --> Input Class Initialized
INFO - 2016-02-01 14:26:33 --> Language Class Initialized
INFO - 2016-02-01 14:26:33 --> Loader Class Initialized
INFO - 2016-02-01 14:26:33 --> Helper loaded: url_helper
INFO - 2016-02-01 14:26:33 --> Helper loaded: file_helper
INFO - 2016-02-01 14:26:33 --> Helper loaded: date_helper
INFO - 2016-02-01 14:26:33 --> Database Driver Class Initialized
INFO - 2016-02-01 14:26:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:26:34 --> Controller Class Initialized
INFO - 2016-02-01 14:26:34 --> Model Class Initialized
INFO - 2016-02-01 14:26:34 --> Model Class Initialized
INFO - 2016-02-01 14:26:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:26:34 --> Pagination Class Initialized
INFO - 2016-02-01 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:26:34 --> Final output sent to browser
DEBUG - 2016-02-01 14:26:34 --> Total execution time: 1.1450
INFO - 2016-02-01 14:26:36 --> Config Class Initialized
INFO - 2016-02-01 14:26:36 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:26:36 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:26:36 --> Utf8 Class Initialized
INFO - 2016-02-01 14:26:36 --> URI Class Initialized
DEBUG - 2016-02-01 14:26:36 --> No URI present. Default controller set.
INFO - 2016-02-01 14:26:36 --> Router Class Initialized
INFO - 2016-02-01 14:26:36 --> Output Class Initialized
INFO - 2016-02-01 14:26:36 --> Security Class Initialized
DEBUG - 2016-02-01 14:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:26:36 --> Input Class Initialized
INFO - 2016-02-01 14:26:36 --> Language Class Initialized
INFO - 2016-02-01 14:26:36 --> Loader Class Initialized
INFO - 2016-02-01 14:26:36 --> Helper loaded: url_helper
INFO - 2016-02-01 14:26:36 --> Helper loaded: file_helper
INFO - 2016-02-01 14:26:36 --> Helper loaded: date_helper
INFO - 2016-02-01 14:26:36 --> Database Driver Class Initialized
INFO - 2016-02-01 14:26:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:26:37 --> Controller Class Initialized
INFO - 2016-02-01 14:26:37 --> Model Class Initialized
INFO - 2016-02-01 14:26:37 --> Model Class Initialized
INFO - 2016-02-01 14:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:26:37 --> Pagination Class Initialized
INFO - 2016-02-01 14:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 14:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:26:37 --> Final output sent to browser
DEBUG - 2016-02-01 14:26:37 --> Total execution time: 1.1100
INFO - 2016-02-01 14:26:40 --> Config Class Initialized
INFO - 2016-02-01 14:26:40 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:26:40 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:26:40 --> Utf8 Class Initialized
INFO - 2016-02-01 14:26:40 --> URI Class Initialized
DEBUG - 2016-02-01 14:26:40 --> No URI present. Default controller set.
INFO - 2016-02-01 14:26:40 --> Router Class Initialized
INFO - 2016-02-01 14:26:40 --> Output Class Initialized
INFO - 2016-02-01 14:26:40 --> Security Class Initialized
DEBUG - 2016-02-01 14:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:26:40 --> Input Class Initialized
INFO - 2016-02-01 14:26:40 --> Language Class Initialized
INFO - 2016-02-01 14:26:40 --> Loader Class Initialized
INFO - 2016-02-01 14:26:40 --> Helper loaded: url_helper
INFO - 2016-02-01 14:26:40 --> Helper loaded: file_helper
INFO - 2016-02-01 14:26:40 --> Helper loaded: date_helper
INFO - 2016-02-01 14:26:40 --> Database Driver Class Initialized
INFO - 2016-02-01 14:26:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:26:41 --> Controller Class Initialized
INFO - 2016-02-01 14:26:41 --> Model Class Initialized
INFO - 2016-02-01 14:26:41 --> Model Class Initialized
INFO - 2016-02-01 14:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:26:41 --> Pagination Class Initialized
INFO - 2016-02-01 14:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 14:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:26:41 --> Final output sent to browser
DEBUG - 2016-02-01 14:26:41 --> Total execution time: 1.0933
INFO - 2016-02-01 14:27:13 --> Config Class Initialized
INFO - 2016-02-01 14:27:13 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:27:13 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:27:13 --> Utf8 Class Initialized
INFO - 2016-02-01 14:27:13 --> URI Class Initialized
INFO - 2016-02-01 14:27:13 --> Router Class Initialized
INFO - 2016-02-01 14:27:13 --> Output Class Initialized
INFO - 2016-02-01 14:27:13 --> Security Class Initialized
DEBUG - 2016-02-01 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:27:13 --> Input Class Initialized
INFO - 2016-02-01 14:27:13 --> Language Class Initialized
INFO - 2016-02-01 14:27:13 --> Loader Class Initialized
INFO - 2016-02-01 14:27:13 --> Helper loaded: url_helper
INFO - 2016-02-01 14:27:13 --> Helper loaded: file_helper
INFO - 2016-02-01 14:27:13 --> Helper loaded: date_helper
INFO - 2016-02-01 14:27:13 --> Database Driver Class Initialized
INFO - 2016-02-01 14:27:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:27:14 --> Controller Class Initialized
INFO - 2016-02-01 14:27:14 --> Model Class Initialized
INFO - 2016-02-01 14:27:14 --> Model Class Initialized
INFO - 2016-02-01 14:27:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:27:14 --> Pagination Class Initialized
INFO - 2016-02-01 14:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:27:14 --> Helper loaded: text_helper
INFO - 2016-02-01 14:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:27:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:27:14 --> Final output sent to browser
DEBUG - 2016-02-01 14:27:14 --> Total execution time: 1.1476
INFO - 2016-02-01 14:27:37 --> Config Class Initialized
INFO - 2016-02-01 14:27:37 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:27:37 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:27:37 --> Utf8 Class Initialized
INFO - 2016-02-01 14:27:37 --> URI Class Initialized
DEBUG - 2016-02-01 14:27:37 --> No URI present. Default controller set.
INFO - 2016-02-01 14:27:37 --> Router Class Initialized
INFO - 2016-02-01 14:27:37 --> Output Class Initialized
INFO - 2016-02-01 14:27:37 --> Security Class Initialized
DEBUG - 2016-02-01 14:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:27:37 --> Input Class Initialized
INFO - 2016-02-01 14:27:37 --> Language Class Initialized
INFO - 2016-02-01 14:27:37 --> Loader Class Initialized
INFO - 2016-02-01 14:27:37 --> Helper loaded: url_helper
INFO - 2016-02-01 14:27:37 --> Helper loaded: file_helper
INFO - 2016-02-01 14:27:37 --> Helper loaded: date_helper
INFO - 2016-02-01 14:27:37 --> Database Driver Class Initialized
INFO - 2016-02-01 14:27:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:27:38 --> Controller Class Initialized
INFO - 2016-02-01 14:27:38 --> Model Class Initialized
INFO - 2016-02-01 14:27:38 --> Model Class Initialized
INFO - 2016-02-01 14:27:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:27:38 --> Pagination Class Initialized
INFO - 2016-02-01 14:27:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:27:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 14:27:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:27:38 --> Final output sent to browser
DEBUG - 2016-02-01 14:27:38 --> Total execution time: 1.0895
INFO - 2016-02-01 14:27:44 --> Config Class Initialized
INFO - 2016-02-01 14:27:44 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:27:44 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:27:44 --> Utf8 Class Initialized
INFO - 2016-02-01 14:27:44 --> URI Class Initialized
INFO - 2016-02-01 14:27:44 --> Router Class Initialized
INFO - 2016-02-01 14:27:44 --> Output Class Initialized
INFO - 2016-02-01 14:27:44 --> Security Class Initialized
DEBUG - 2016-02-01 14:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:27:44 --> Input Class Initialized
INFO - 2016-02-01 14:27:44 --> Language Class Initialized
INFO - 2016-02-01 14:27:44 --> Loader Class Initialized
INFO - 2016-02-01 14:27:44 --> Helper loaded: url_helper
INFO - 2016-02-01 14:27:44 --> Helper loaded: file_helper
INFO - 2016-02-01 14:27:44 --> Helper loaded: date_helper
INFO - 2016-02-01 14:27:44 --> Database Driver Class Initialized
INFO - 2016-02-01 14:27:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:27:45 --> Controller Class Initialized
INFO - 2016-02-01 14:27:45 --> Model Class Initialized
INFO - 2016-02-01 14:27:45 --> Model Class Initialized
INFO - 2016-02-01 14:27:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:27:45 --> Pagination Class Initialized
INFO - 2016-02-01 14:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:27:45 --> Helper loaded: text_helper
INFO - 2016-02-01 14:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:27:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:27:45 --> Final output sent to browser
DEBUG - 2016-02-01 14:27:45 --> Total execution time: 1.1566
INFO - 2016-02-01 14:27:48 --> Config Class Initialized
INFO - 2016-02-01 14:27:48 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:27:48 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:27:48 --> Utf8 Class Initialized
INFO - 2016-02-01 14:27:48 --> URI Class Initialized
INFO - 2016-02-01 14:27:48 --> Router Class Initialized
INFO - 2016-02-01 14:27:48 --> Output Class Initialized
INFO - 2016-02-01 14:27:48 --> Security Class Initialized
DEBUG - 2016-02-01 14:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:27:48 --> Input Class Initialized
INFO - 2016-02-01 14:27:48 --> Language Class Initialized
INFO - 2016-02-01 14:27:48 --> Loader Class Initialized
INFO - 2016-02-01 14:27:48 --> Helper loaded: url_helper
INFO - 2016-02-01 14:27:48 --> Helper loaded: file_helper
INFO - 2016-02-01 14:27:48 --> Helper loaded: date_helper
INFO - 2016-02-01 14:27:48 --> Database Driver Class Initialized
INFO - 2016-02-01 14:27:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:27:49 --> Controller Class Initialized
INFO - 2016-02-01 14:27:49 --> Model Class Initialized
INFO - 2016-02-01 14:27:49 --> Model Class Initialized
INFO - 2016-02-01 14:27:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:27:49 --> Pagination Class Initialized
INFO - 2016-02-01 14:27:50 --> Config Class Initialized
INFO - 2016-02-01 14:27:50 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:27:50 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:27:50 --> Utf8 Class Initialized
INFO - 2016-02-01 14:27:50 --> URI Class Initialized
INFO - 2016-02-01 14:27:50 --> Router Class Initialized
INFO - 2016-02-01 14:27:50 --> Output Class Initialized
INFO - 2016-02-01 14:27:50 --> Security Class Initialized
DEBUG - 2016-02-01 14:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:27:50 --> Input Class Initialized
INFO - 2016-02-01 14:27:50 --> Language Class Initialized
INFO - 2016-02-01 14:27:50 --> Loader Class Initialized
INFO - 2016-02-01 14:27:50 --> Helper loaded: url_helper
INFO - 2016-02-01 14:27:50 --> Helper loaded: file_helper
INFO - 2016-02-01 14:27:50 --> Helper loaded: date_helper
INFO - 2016-02-01 14:27:50 --> Database Driver Class Initialized
INFO - 2016-02-01 14:27:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:27:51 --> Controller Class Initialized
INFO - 2016-02-01 14:27:51 --> Model Class Initialized
INFO - 2016-02-01 14:27:51 --> Model Class Initialized
INFO - 2016-02-01 14:27:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:27:51 --> Pagination Class Initialized
INFO - 2016-02-01 14:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:27:51 --> Helper loaded: text_helper
INFO - 2016-02-01 14:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:27:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:27:51 --> Final output sent to browser
DEBUG - 2016-02-01 14:27:51 --> Total execution time: 1.1502
INFO - 2016-02-01 14:41:52 --> Config Class Initialized
INFO - 2016-02-01 14:41:52 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:41:53 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:41:53 --> Utf8 Class Initialized
INFO - 2016-02-01 14:41:53 --> URI Class Initialized
INFO - 2016-02-01 14:41:53 --> Router Class Initialized
INFO - 2016-02-01 14:41:53 --> Output Class Initialized
INFO - 2016-02-01 14:41:53 --> Security Class Initialized
DEBUG - 2016-02-01 14:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:41:53 --> Input Class Initialized
INFO - 2016-02-01 14:41:53 --> Language Class Initialized
INFO - 2016-02-01 14:41:53 --> Loader Class Initialized
INFO - 2016-02-01 14:41:53 --> Helper loaded: url_helper
INFO - 2016-02-01 14:41:53 --> Helper loaded: file_helper
INFO - 2016-02-01 14:41:53 --> Helper loaded: date_helper
INFO - 2016-02-01 14:41:53 --> Database Driver Class Initialized
INFO - 2016-02-01 14:41:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:41:54 --> Controller Class Initialized
INFO - 2016-02-01 14:41:54 --> Model Class Initialized
INFO - 2016-02-01 14:41:54 --> Model Class Initialized
INFO - 2016-02-01 14:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:41:54 --> Pagination Class Initialized
INFO - 2016-02-01 14:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:41:54 --> Helper loaded: text_helper
INFO - 2016-02-01 14:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:41:54 --> Final output sent to browser
DEBUG - 2016-02-01 14:41:54 --> Total execution time: 1.1710
INFO - 2016-02-01 14:42:12 --> Config Class Initialized
INFO - 2016-02-01 14:42:12 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:42:12 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:42:12 --> Utf8 Class Initialized
INFO - 2016-02-01 14:42:12 --> URI Class Initialized
INFO - 2016-02-01 14:42:12 --> Router Class Initialized
INFO - 2016-02-01 14:42:12 --> Output Class Initialized
INFO - 2016-02-01 14:42:12 --> Security Class Initialized
DEBUG - 2016-02-01 14:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:42:12 --> Input Class Initialized
INFO - 2016-02-01 14:42:12 --> Language Class Initialized
INFO - 2016-02-01 14:42:12 --> Loader Class Initialized
INFO - 2016-02-01 14:42:12 --> Helper loaded: url_helper
INFO - 2016-02-01 14:42:12 --> Helper loaded: file_helper
INFO - 2016-02-01 14:42:12 --> Helper loaded: date_helper
INFO - 2016-02-01 14:42:12 --> Database Driver Class Initialized
INFO - 2016-02-01 14:42:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:42:13 --> Controller Class Initialized
INFO - 2016-02-01 14:42:13 --> Model Class Initialized
INFO - 2016-02-01 14:42:13 --> Model Class Initialized
INFO - 2016-02-01 14:42:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:42:13 --> Pagination Class Initialized
INFO - 2016-02-01 14:42:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:42:13 --> Helper loaded: text_helper
INFO - 2016-02-01 14:42:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:42:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:42:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:42:13 --> Final output sent to browser
DEBUG - 2016-02-01 14:42:13 --> Total execution time: 1.1689
INFO - 2016-02-01 14:42:29 --> Config Class Initialized
INFO - 2016-02-01 14:42:29 --> Hooks Class Initialized
DEBUG - 2016-02-01 14:42:29 --> UTF-8 Support Enabled
INFO - 2016-02-01 14:42:29 --> Utf8 Class Initialized
INFO - 2016-02-01 14:42:29 --> URI Class Initialized
INFO - 2016-02-01 14:42:29 --> Router Class Initialized
INFO - 2016-02-01 14:42:29 --> Output Class Initialized
INFO - 2016-02-01 14:42:29 --> Security Class Initialized
DEBUG - 2016-02-01 14:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 14:42:29 --> Input Class Initialized
INFO - 2016-02-01 14:42:29 --> Language Class Initialized
INFO - 2016-02-01 14:42:29 --> Loader Class Initialized
INFO - 2016-02-01 14:42:29 --> Helper loaded: url_helper
INFO - 2016-02-01 14:42:29 --> Helper loaded: file_helper
INFO - 2016-02-01 14:42:29 --> Helper loaded: date_helper
INFO - 2016-02-01 14:42:29 --> Database Driver Class Initialized
INFO - 2016-02-01 14:42:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 14:42:30 --> Controller Class Initialized
INFO - 2016-02-01 14:42:30 --> Model Class Initialized
INFO - 2016-02-01 14:42:30 --> Model Class Initialized
INFO - 2016-02-01 14:42:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 14:42:30 --> Pagination Class Initialized
INFO - 2016-02-01 14:42:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 14:42:30 --> Helper loaded: text_helper
INFO - 2016-02-01 14:42:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 14:42:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 14:42:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 14:42:30 --> Final output sent to browser
DEBUG - 2016-02-01 14:42:30 --> Total execution time: 1.1753
INFO - 2016-02-01 17:24:53 --> Config Class Initialized
INFO - 2016-02-01 17:24:53 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:24:53 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:24:53 --> Utf8 Class Initialized
INFO - 2016-02-01 17:24:53 --> URI Class Initialized
DEBUG - 2016-02-01 17:24:53 --> No URI present. Default controller set.
INFO - 2016-02-01 17:24:53 --> Router Class Initialized
INFO - 2016-02-01 17:24:53 --> Output Class Initialized
INFO - 2016-02-01 17:24:53 --> Security Class Initialized
DEBUG - 2016-02-01 17:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:24:53 --> Input Class Initialized
INFO - 2016-02-01 17:24:53 --> Language Class Initialized
INFO - 2016-02-01 17:24:53 --> Loader Class Initialized
INFO - 2016-02-01 17:24:53 --> Helper loaded: url_helper
INFO - 2016-02-01 17:24:53 --> Helper loaded: file_helper
INFO - 2016-02-01 17:24:53 --> Helper loaded: date_helper
INFO - 2016-02-01 17:24:53 --> Database Driver Class Initialized
INFO - 2016-02-01 17:24:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:24:54 --> Controller Class Initialized
INFO - 2016-02-01 17:24:54 --> Model Class Initialized
INFO - 2016-02-01 17:24:54 --> Model Class Initialized
INFO - 2016-02-01 17:24:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:24:54 --> Pagination Class Initialized
INFO - 2016-02-01 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 17:24:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:24:54 --> Final output sent to browser
DEBUG - 2016-02-01 17:24:54 --> Total execution time: 1.1737
INFO - 2016-02-01 17:24:56 --> Config Class Initialized
INFO - 2016-02-01 17:24:56 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:24:56 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:24:56 --> Utf8 Class Initialized
INFO - 2016-02-01 17:24:56 --> URI Class Initialized
INFO - 2016-02-01 17:24:56 --> Router Class Initialized
INFO - 2016-02-01 17:24:56 --> Output Class Initialized
INFO - 2016-02-01 17:24:56 --> Security Class Initialized
DEBUG - 2016-02-01 17:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:24:56 --> Input Class Initialized
INFO - 2016-02-01 17:24:56 --> Language Class Initialized
INFO - 2016-02-01 17:24:56 --> Loader Class Initialized
INFO - 2016-02-01 17:24:56 --> Helper loaded: url_helper
INFO - 2016-02-01 17:24:56 --> Helper loaded: file_helper
INFO - 2016-02-01 17:24:56 --> Helper loaded: date_helper
INFO - 2016-02-01 17:24:56 --> Database Driver Class Initialized
INFO - 2016-02-01 17:24:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:24:57 --> Controller Class Initialized
INFO - 2016-02-01 17:24:57 --> Model Class Initialized
INFO - 2016-02-01 17:24:57 --> Model Class Initialized
INFO - 2016-02-01 17:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:24:57 --> Pagination Class Initialized
INFO - 2016-02-01 17:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:24:57 --> Helper loaded: text_helper
INFO - 2016-02-01 17:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:24:58 --> Final output sent to browser
DEBUG - 2016-02-01 17:24:58 --> Total execution time: 1.1690
INFO - 2016-02-01 17:25:31 --> Config Class Initialized
INFO - 2016-02-01 17:25:31 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:25:31 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:25:31 --> Utf8 Class Initialized
INFO - 2016-02-01 17:25:31 --> URI Class Initialized
INFO - 2016-02-01 17:25:31 --> Router Class Initialized
INFO - 2016-02-01 17:25:31 --> Output Class Initialized
INFO - 2016-02-01 17:25:31 --> Security Class Initialized
DEBUG - 2016-02-01 17:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:25:31 --> Input Class Initialized
INFO - 2016-02-01 17:25:31 --> Language Class Initialized
INFO - 2016-02-01 17:25:31 --> Loader Class Initialized
INFO - 2016-02-01 17:25:31 --> Helper loaded: url_helper
INFO - 2016-02-01 17:25:31 --> Helper loaded: file_helper
INFO - 2016-02-01 17:25:31 --> Helper loaded: date_helper
INFO - 2016-02-01 17:25:31 --> Database Driver Class Initialized
INFO - 2016-02-01 17:25:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:25:32 --> Controller Class Initialized
INFO - 2016-02-01 17:25:32 --> Model Class Initialized
INFO - 2016-02-01 17:25:32 --> Model Class Initialized
INFO - 2016-02-01 17:25:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:25:32 --> Pagination Class Initialized
INFO - 2016-02-01 17:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-01 17:25:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:25:32 --> Final output sent to browser
DEBUG - 2016-02-01 17:25:32 --> Total execution time: 1.1503
INFO - 2016-02-01 17:25:38 --> Config Class Initialized
INFO - 2016-02-01 17:25:38 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:25:38 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:25:38 --> Utf8 Class Initialized
INFO - 2016-02-01 17:25:38 --> URI Class Initialized
DEBUG - 2016-02-01 17:25:38 --> No URI present. Default controller set.
INFO - 2016-02-01 17:25:38 --> Router Class Initialized
INFO - 2016-02-01 17:25:38 --> Output Class Initialized
INFO - 2016-02-01 17:25:38 --> Security Class Initialized
DEBUG - 2016-02-01 17:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:25:38 --> Input Class Initialized
INFO - 2016-02-01 17:25:38 --> Language Class Initialized
INFO - 2016-02-01 17:25:38 --> Loader Class Initialized
INFO - 2016-02-01 17:25:38 --> Helper loaded: url_helper
INFO - 2016-02-01 17:25:38 --> Helper loaded: file_helper
INFO - 2016-02-01 17:25:38 --> Helper loaded: date_helper
INFO - 2016-02-01 17:25:38 --> Database Driver Class Initialized
INFO - 2016-02-01 17:25:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:25:39 --> Controller Class Initialized
INFO - 2016-02-01 17:25:39 --> Model Class Initialized
INFO - 2016-02-01 17:25:39 --> Model Class Initialized
INFO - 2016-02-01 17:25:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:25:39 --> Pagination Class Initialized
INFO - 2016-02-01 17:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 17:25:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:25:39 --> Final output sent to browser
DEBUG - 2016-02-01 17:25:39 --> Total execution time: 1.1142
INFO - 2016-02-01 17:27:18 --> Config Class Initialized
INFO - 2016-02-01 17:27:18 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:27:18 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:27:18 --> Utf8 Class Initialized
INFO - 2016-02-01 17:27:18 --> URI Class Initialized
INFO - 2016-02-01 17:27:18 --> Router Class Initialized
INFO - 2016-02-01 17:27:18 --> Output Class Initialized
INFO - 2016-02-01 17:27:18 --> Security Class Initialized
DEBUG - 2016-02-01 17:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:27:18 --> Input Class Initialized
INFO - 2016-02-01 17:27:18 --> Language Class Initialized
INFO - 2016-02-01 17:27:18 --> Loader Class Initialized
INFO - 2016-02-01 17:27:18 --> Helper loaded: url_helper
INFO - 2016-02-01 17:27:18 --> Helper loaded: file_helper
INFO - 2016-02-01 17:27:18 --> Helper loaded: date_helper
INFO - 2016-02-01 17:27:18 --> Database Driver Class Initialized
INFO - 2016-02-01 17:27:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:27:19 --> Controller Class Initialized
INFO - 2016-02-01 17:27:19 --> Model Class Initialized
INFO - 2016-02-01 17:27:19 --> Model Class Initialized
INFO - 2016-02-01 17:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:27:19 --> Pagination Class Initialized
INFO - 2016-02-01 17:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:27:19 --> Helper loaded: text_helper
INFO - 2016-02-01 17:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:27:19 --> Final output sent to browser
DEBUG - 2016-02-01 17:27:19 --> Total execution time: 1.2325
INFO - 2016-02-01 17:28:29 --> Config Class Initialized
INFO - 2016-02-01 17:28:29 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:28:29 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:28:29 --> Utf8 Class Initialized
INFO - 2016-02-01 17:28:29 --> URI Class Initialized
INFO - 2016-02-01 17:28:29 --> Router Class Initialized
INFO - 2016-02-01 17:28:29 --> Output Class Initialized
INFO - 2016-02-01 17:28:29 --> Security Class Initialized
DEBUG - 2016-02-01 17:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:28:29 --> Input Class Initialized
INFO - 2016-02-01 17:28:29 --> Language Class Initialized
INFO - 2016-02-01 17:28:29 --> Loader Class Initialized
INFO - 2016-02-01 17:28:29 --> Helper loaded: url_helper
INFO - 2016-02-01 17:28:29 --> Helper loaded: file_helper
INFO - 2016-02-01 17:28:29 --> Helper loaded: date_helper
INFO - 2016-02-01 17:28:29 --> Database Driver Class Initialized
INFO - 2016-02-01 17:28:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:28:30 --> Controller Class Initialized
INFO - 2016-02-01 17:28:30 --> Model Class Initialized
INFO - 2016-02-01 17:28:30 --> Model Class Initialized
INFO - 2016-02-01 17:28:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:28:30 --> Pagination Class Initialized
INFO - 2016-02-01 17:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:28:30 --> Helper loaded: text_helper
INFO - 2016-02-01 17:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:28:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:28:30 --> Final output sent to browser
DEBUG - 2016-02-01 17:28:30 --> Total execution time: 1.2185
INFO - 2016-02-01 17:28:51 --> Config Class Initialized
INFO - 2016-02-01 17:28:51 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:28:51 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:28:51 --> Utf8 Class Initialized
INFO - 2016-02-01 17:28:51 --> URI Class Initialized
INFO - 2016-02-01 17:28:51 --> Router Class Initialized
INFO - 2016-02-01 17:28:51 --> Output Class Initialized
INFO - 2016-02-01 17:28:51 --> Security Class Initialized
DEBUG - 2016-02-01 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:28:51 --> Input Class Initialized
INFO - 2016-02-01 17:28:51 --> Language Class Initialized
INFO - 2016-02-01 17:28:51 --> Loader Class Initialized
INFO - 2016-02-01 17:28:51 --> Helper loaded: url_helper
INFO - 2016-02-01 17:28:51 --> Helper loaded: file_helper
INFO - 2016-02-01 17:28:51 --> Helper loaded: date_helper
INFO - 2016-02-01 17:28:51 --> Database Driver Class Initialized
INFO - 2016-02-01 17:28:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:28:52 --> Controller Class Initialized
INFO - 2016-02-01 17:28:52 --> Model Class Initialized
INFO - 2016-02-01 17:28:52 --> Model Class Initialized
INFO - 2016-02-01 17:28:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:28:52 --> Pagination Class Initialized
INFO - 2016-02-01 17:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:28:52 --> Helper loaded: text_helper
INFO - 2016-02-01 17:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:28:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:28:52 --> Final output sent to browser
DEBUG - 2016-02-01 17:28:52 --> Total execution time: 1.2318
INFO - 2016-02-01 17:30:21 --> Config Class Initialized
INFO - 2016-02-01 17:30:21 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:30:21 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:30:21 --> Utf8 Class Initialized
INFO - 2016-02-01 17:30:21 --> URI Class Initialized
DEBUG - 2016-02-01 17:30:21 --> No URI present. Default controller set.
INFO - 2016-02-01 17:30:21 --> Router Class Initialized
INFO - 2016-02-01 17:30:21 --> Output Class Initialized
INFO - 2016-02-01 17:30:21 --> Security Class Initialized
DEBUG - 2016-02-01 17:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:30:21 --> Input Class Initialized
INFO - 2016-02-01 17:30:21 --> Language Class Initialized
INFO - 2016-02-01 17:30:21 --> Loader Class Initialized
INFO - 2016-02-01 17:30:21 --> Helper loaded: url_helper
INFO - 2016-02-01 17:30:21 --> Helper loaded: file_helper
INFO - 2016-02-01 17:30:21 --> Helper loaded: date_helper
INFO - 2016-02-01 17:30:21 --> Database Driver Class Initialized
INFO - 2016-02-01 17:30:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:30:22 --> Controller Class Initialized
INFO - 2016-02-01 17:30:22 --> Model Class Initialized
INFO - 2016-02-01 17:30:22 --> Model Class Initialized
INFO - 2016-02-01 17:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:30:22 --> Pagination Class Initialized
INFO - 2016-02-01 17:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 17:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:30:22 --> Final output sent to browser
DEBUG - 2016-02-01 17:30:22 --> Total execution time: 1.1532
INFO - 2016-02-01 17:34:53 --> Config Class Initialized
INFO - 2016-02-01 17:34:53 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:34:53 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:34:53 --> Utf8 Class Initialized
INFO - 2016-02-01 17:34:53 --> URI Class Initialized
INFO - 2016-02-01 17:34:53 --> Router Class Initialized
INFO - 2016-02-01 17:34:53 --> Output Class Initialized
INFO - 2016-02-01 17:34:53 --> Security Class Initialized
DEBUG - 2016-02-01 17:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:34:53 --> Input Class Initialized
INFO - 2016-02-01 17:34:53 --> Language Class Initialized
INFO - 2016-02-01 17:34:53 --> Loader Class Initialized
INFO - 2016-02-01 17:34:53 --> Helper loaded: url_helper
INFO - 2016-02-01 17:34:53 --> Helper loaded: file_helper
INFO - 2016-02-01 17:34:53 --> Helper loaded: date_helper
INFO - 2016-02-01 17:34:53 --> Database Driver Class Initialized
INFO - 2016-02-01 17:34:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:34:54 --> Controller Class Initialized
INFO - 2016-02-01 17:34:54 --> Model Class Initialized
INFO - 2016-02-01 17:34:54 --> Model Class Initialized
INFO - 2016-02-01 17:34:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:34:54 --> Pagination Class Initialized
INFO - 2016-02-01 17:34:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:34:54 --> Helper loaded: text_helper
INFO - 2016-02-01 17:34:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:34:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:34:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:34:54 --> Final output sent to browser
DEBUG - 2016-02-01 17:34:54 --> Total execution time: 1.1689
INFO - 2016-02-01 17:37:30 --> Config Class Initialized
INFO - 2016-02-01 17:37:30 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:37:30 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:37:30 --> Utf8 Class Initialized
INFO - 2016-02-01 17:37:30 --> URI Class Initialized
DEBUG - 2016-02-01 17:37:30 --> No URI present. Default controller set.
INFO - 2016-02-01 17:37:30 --> Router Class Initialized
INFO - 2016-02-01 17:37:30 --> Output Class Initialized
INFO - 2016-02-01 17:37:30 --> Security Class Initialized
DEBUG - 2016-02-01 17:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:37:30 --> Input Class Initialized
INFO - 2016-02-01 17:37:30 --> Language Class Initialized
INFO - 2016-02-01 17:37:30 --> Loader Class Initialized
INFO - 2016-02-01 17:37:30 --> Helper loaded: url_helper
INFO - 2016-02-01 17:37:30 --> Helper loaded: file_helper
INFO - 2016-02-01 17:37:30 --> Helper loaded: date_helper
INFO - 2016-02-01 17:37:30 --> Database Driver Class Initialized
INFO - 2016-02-01 17:37:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:37:32 --> Controller Class Initialized
INFO - 2016-02-01 17:37:32 --> Model Class Initialized
INFO - 2016-02-01 17:37:32 --> Model Class Initialized
INFO - 2016-02-01 17:37:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:37:32 --> Pagination Class Initialized
INFO - 2016-02-01 17:37:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:37:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 17:37:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:37:32 --> Final output sent to browser
DEBUG - 2016-02-01 17:37:32 --> Total execution time: 1.1193
INFO - 2016-02-01 17:37:39 --> Config Class Initialized
INFO - 2016-02-01 17:37:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:37:39 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:37:39 --> Utf8 Class Initialized
INFO - 2016-02-01 17:37:39 --> URI Class Initialized
INFO - 2016-02-01 17:37:39 --> Router Class Initialized
INFO - 2016-02-01 17:37:39 --> Output Class Initialized
INFO - 2016-02-01 17:37:39 --> Security Class Initialized
DEBUG - 2016-02-01 17:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:37:39 --> Input Class Initialized
INFO - 2016-02-01 17:37:39 --> Language Class Initialized
INFO - 2016-02-01 17:37:39 --> Loader Class Initialized
INFO - 2016-02-01 17:37:39 --> Helper loaded: url_helper
INFO - 2016-02-01 17:37:39 --> Helper loaded: file_helper
INFO - 2016-02-01 17:37:39 --> Helper loaded: date_helper
INFO - 2016-02-01 17:37:39 --> Database Driver Class Initialized
INFO - 2016-02-01 17:37:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:37:40 --> Controller Class Initialized
INFO - 2016-02-01 17:37:40 --> Model Class Initialized
INFO - 2016-02-01 17:37:40 --> Model Class Initialized
INFO - 2016-02-01 17:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:37:40 --> Pagination Class Initialized
INFO - 2016-02-01 17:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:37:40 --> Helper loaded: text_helper
INFO - 2016-02-01 17:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:37:40 --> Final output sent to browser
DEBUG - 2016-02-01 17:37:40 --> Total execution time: 1.1701
INFO - 2016-02-01 17:38:21 --> Config Class Initialized
INFO - 2016-02-01 17:38:21 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:38:21 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:38:21 --> Utf8 Class Initialized
INFO - 2016-02-01 17:38:21 --> URI Class Initialized
INFO - 2016-02-01 17:38:21 --> Router Class Initialized
INFO - 2016-02-01 17:38:21 --> Output Class Initialized
INFO - 2016-02-01 17:38:21 --> Security Class Initialized
DEBUG - 2016-02-01 17:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:38:21 --> Input Class Initialized
INFO - 2016-02-01 17:38:21 --> Language Class Initialized
INFO - 2016-02-01 17:38:21 --> Loader Class Initialized
INFO - 2016-02-01 17:38:21 --> Helper loaded: url_helper
INFO - 2016-02-01 17:38:21 --> Helper loaded: file_helper
INFO - 2016-02-01 17:38:21 --> Helper loaded: date_helper
INFO - 2016-02-01 17:38:21 --> Database Driver Class Initialized
INFO - 2016-02-01 17:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:38:22 --> Controller Class Initialized
INFO - 2016-02-01 17:38:22 --> Model Class Initialized
INFO - 2016-02-01 17:38:22 --> Model Class Initialized
INFO - 2016-02-01 17:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:38:22 --> Pagination Class Initialized
INFO - 2016-02-01 17:38:22 --> Config Class Initialized
INFO - 2016-02-01 17:38:22 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:38:22 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:38:22 --> Utf8 Class Initialized
INFO - 2016-02-01 17:38:22 --> URI Class Initialized
INFO - 2016-02-01 17:38:22 --> Router Class Initialized
INFO - 2016-02-01 17:38:22 --> Output Class Initialized
INFO - 2016-02-01 17:38:22 --> Security Class Initialized
DEBUG - 2016-02-01 17:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:38:22 --> Input Class Initialized
INFO - 2016-02-01 17:38:22 --> Language Class Initialized
INFO - 2016-02-01 17:38:22 --> Loader Class Initialized
INFO - 2016-02-01 17:38:22 --> Helper loaded: url_helper
INFO - 2016-02-01 17:38:22 --> Helper loaded: file_helper
INFO - 2016-02-01 17:38:22 --> Helper loaded: date_helper
INFO - 2016-02-01 17:38:22 --> Database Driver Class Initialized
INFO - 2016-02-01 17:38:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:38:23 --> Controller Class Initialized
INFO - 2016-02-01 17:38:23 --> Model Class Initialized
INFO - 2016-02-01 17:38:23 --> Model Class Initialized
INFO - 2016-02-01 17:38:23 --> Helper loaded: form_helper
INFO - 2016-02-01 17:38:23 --> Form Validation Class Initialized
INFO - 2016-02-01 17:38:23 --> Helper loaded: text_helper
INFO - 2016-02-01 17:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:38:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-01 17:38:23 --> Final output sent to browser
DEBUG - 2016-02-01 17:38:23 --> Total execution time: 1.3279
INFO - 2016-02-01 17:38:32 --> Config Class Initialized
INFO - 2016-02-01 17:38:32 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:38:32 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:38:32 --> Utf8 Class Initialized
INFO - 2016-02-01 17:38:32 --> URI Class Initialized
INFO - 2016-02-01 17:38:32 --> Router Class Initialized
INFO - 2016-02-01 17:38:32 --> Output Class Initialized
INFO - 2016-02-01 17:38:32 --> Security Class Initialized
DEBUG - 2016-02-01 17:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:38:32 --> Input Class Initialized
INFO - 2016-02-01 17:38:32 --> Language Class Initialized
INFO - 2016-02-01 17:38:32 --> Loader Class Initialized
INFO - 2016-02-01 17:38:32 --> Helper loaded: url_helper
INFO - 2016-02-01 17:38:32 --> Helper loaded: file_helper
INFO - 2016-02-01 17:38:32 --> Helper loaded: date_helper
INFO - 2016-02-01 17:38:32 --> Database Driver Class Initialized
INFO - 2016-02-01 17:38:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:38:33 --> Controller Class Initialized
INFO - 2016-02-01 17:38:33 --> Model Class Initialized
INFO - 2016-02-01 17:38:33 --> Model Class Initialized
INFO - 2016-02-01 17:38:33 --> Helper loaded: form_helper
INFO - 2016-02-01 17:38:33 --> Form Validation Class Initialized
INFO - 2016-02-01 17:38:33 --> Helper loaded: text_helper
INFO - 2016-02-01 17:38:33 --> Config Class Initialized
INFO - 2016-02-01 17:38:33 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:38:33 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:38:33 --> Utf8 Class Initialized
INFO - 2016-02-01 17:38:33 --> URI Class Initialized
INFO - 2016-02-01 17:38:34 --> Router Class Initialized
INFO - 2016-02-01 17:38:34 --> Output Class Initialized
INFO - 2016-02-01 17:38:34 --> Security Class Initialized
DEBUG - 2016-02-01 17:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:38:34 --> Input Class Initialized
INFO - 2016-02-01 17:38:34 --> Language Class Initialized
INFO - 2016-02-01 17:38:34 --> Loader Class Initialized
INFO - 2016-02-01 17:38:34 --> Helper loaded: url_helper
INFO - 2016-02-01 17:38:34 --> Helper loaded: file_helper
INFO - 2016-02-01 17:38:34 --> Helper loaded: date_helper
INFO - 2016-02-01 17:38:34 --> Database Driver Class Initialized
INFO - 2016-02-01 17:38:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:38:35 --> Controller Class Initialized
INFO - 2016-02-01 17:38:35 --> Model Class Initialized
INFO - 2016-02-01 17:38:35 --> Model Class Initialized
INFO - 2016-02-01 17:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:38:35 --> Pagination Class Initialized
INFO - 2016-02-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:38:35 --> Helper loaded: text_helper
INFO - 2016-02-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:38:35 --> Final output sent to browser
DEBUG - 2016-02-01 17:38:35 --> Total execution time: 1.1756
INFO - 2016-02-01 17:38:39 --> Config Class Initialized
INFO - 2016-02-01 17:38:39 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:38:39 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:38:39 --> Utf8 Class Initialized
INFO - 2016-02-01 17:38:39 --> URI Class Initialized
INFO - 2016-02-01 17:38:39 --> Router Class Initialized
INFO - 2016-02-01 17:38:39 --> Output Class Initialized
INFO - 2016-02-01 17:38:39 --> Security Class Initialized
DEBUG - 2016-02-01 17:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:38:39 --> Input Class Initialized
INFO - 2016-02-01 17:38:39 --> Language Class Initialized
INFO - 2016-02-01 17:38:39 --> Loader Class Initialized
INFO - 2016-02-01 17:38:39 --> Helper loaded: url_helper
INFO - 2016-02-01 17:38:39 --> Helper loaded: file_helper
INFO - 2016-02-01 17:38:39 --> Helper loaded: date_helper
INFO - 2016-02-01 17:38:39 --> Database Driver Class Initialized
INFO - 2016-02-01 17:38:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:38:40 --> Controller Class Initialized
INFO - 2016-02-01 17:38:40 --> Model Class Initialized
INFO - 2016-02-01 17:38:40 --> Model Class Initialized
INFO - 2016-02-01 17:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:38:40 --> Pagination Class Initialized
INFO - 2016-02-01 17:38:40 --> Config Class Initialized
INFO - 2016-02-01 17:38:40 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:38:40 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:38:40 --> Utf8 Class Initialized
INFO - 2016-02-01 17:38:40 --> URI Class Initialized
INFO - 2016-02-01 17:38:40 --> Router Class Initialized
INFO - 2016-02-01 17:38:40 --> Output Class Initialized
INFO - 2016-02-01 17:38:40 --> Security Class Initialized
DEBUG - 2016-02-01 17:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:38:40 --> Input Class Initialized
INFO - 2016-02-01 17:38:40 --> Language Class Initialized
INFO - 2016-02-01 17:38:40 --> Loader Class Initialized
INFO - 2016-02-01 17:38:40 --> Helper loaded: url_helper
INFO - 2016-02-01 17:38:40 --> Helper loaded: file_helper
INFO - 2016-02-01 17:38:40 --> Helper loaded: date_helper
INFO - 2016-02-01 17:38:40 --> Database Driver Class Initialized
INFO - 2016-02-01 17:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:38:41 --> Controller Class Initialized
INFO - 2016-02-01 17:38:41 --> Model Class Initialized
INFO - 2016-02-01 17:38:41 --> Model Class Initialized
INFO - 2016-02-01 17:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:38:41 --> Pagination Class Initialized
INFO - 2016-02-01 17:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:38:41 --> Helper loaded: text_helper
INFO - 2016-02-01 17:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:38:41 --> Final output sent to browser
DEBUG - 2016-02-01 17:38:41 --> Total execution time: 1.2094
INFO - 2016-02-01 17:41:02 --> Config Class Initialized
INFO - 2016-02-01 17:41:02 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:41:02 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:41:02 --> Utf8 Class Initialized
INFO - 2016-02-01 17:41:02 --> URI Class Initialized
DEBUG - 2016-02-01 17:41:02 --> No URI present. Default controller set.
INFO - 2016-02-01 17:41:02 --> Router Class Initialized
INFO - 2016-02-01 17:41:02 --> Output Class Initialized
INFO - 2016-02-01 17:41:02 --> Security Class Initialized
DEBUG - 2016-02-01 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:41:02 --> Input Class Initialized
INFO - 2016-02-01 17:41:02 --> Language Class Initialized
INFO - 2016-02-01 17:41:02 --> Loader Class Initialized
INFO - 2016-02-01 17:41:02 --> Helper loaded: url_helper
INFO - 2016-02-01 17:41:02 --> Helper loaded: file_helper
INFO - 2016-02-01 17:41:02 --> Helper loaded: date_helper
INFO - 2016-02-01 17:41:02 --> Database Driver Class Initialized
INFO - 2016-02-01 17:41:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:41:03 --> Controller Class Initialized
INFO - 2016-02-01 17:41:03 --> Model Class Initialized
INFO - 2016-02-01 17:41:03 --> Model Class Initialized
INFO - 2016-02-01 17:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:41:03 --> Pagination Class Initialized
INFO - 2016-02-01 17:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 17:41:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:41:03 --> Final output sent to browser
DEBUG - 2016-02-01 17:41:03 --> Total execution time: 1.1086
INFO - 2016-02-01 17:43:40 --> Config Class Initialized
INFO - 2016-02-01 17:43:40 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:43:40 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:43:40 --> Utf8 Class Initialized
INFO - 2016-02-01 17:43:40 --> URI Class Initialized
INFO - 2016-02-01 17:43:40 --> Router Class Initialized
INFO - 2016-02-01 17:43:40 --> Output Class Initialized
INFO - 2016-02-01 17:43:40 --> Security Class Initialized
DEBUG - 2016-02-01 17:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:43:40 --> Input Class Initialized
INFO - 2016-02-01 17:43:40 --> Language Class Initialized
INFO - 2016-02-01 17:43:40 --> Loader Class Initialized
INFO - 2016-02-01 17:43:40 --> Helper loaded: url_helper
INFO - 2016-02-01 17:43:40 --> Helper loaded: file_helper
INFO - 2016-02-01 17:43:40 --> Helper loaded: date_helper
INFO - 2016-02-01 17:43:40 --> Database Driver Class Initialized
INFO - 2016-02-01 17:43:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:43:41 --> Controller Class Initialized
INFO - 2016-02-01 17:43:41 --> Model Class Initialized
INFO - 2016-02-01 17:43:41 --> Model Class Initialized
INFO - 2016-02-01 17:43:41 --> Helper loaded: form_helper
INFO - 2016-02-01 17:43:41 --> Form Validation Class Initialized
INFO - 2016-02-01 17:43:41 --> Helper loaded: text_helper
INFO - 2016-02-01 17:43:41 --> Config Class Initialized
INFO - 2016-02-01 17:43:41 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:43:41 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:43:41 --> Utf8 Class Initialized
INFO - 2016-02-01 17:43:41 --> URI Class Initialized
INFO - 2016-02-01 17:43:41 --> Router Class Initialized
INFO - 2016-02-01 17:43:41 --> Output Class Initialized
INFO - 2016-02-01 17:43:41 --> Security Class Initialized
DEBUG - 2016-02-01 17:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:43:41 --> Input Class Initialized
INFO - 2016-02-01 17:43:41 --> Language Class Initialized
INFO - 2016-02-01 17:43:41 --> Loader Class Initialized
INFO - 2016-02-01 17:43:41 --> Helper loaded: url_helper
INFO - 2016-02-01 17:43:41 --> Helper loaded: file_helper
INFO - 2016-02-01 17:43:41 --> Helper loaded: date_helper
INFO - 2016-02-01 17:43:41 --> Database Driver Class Initialized
INFO - 2016-02-01 17:43:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:43:42 --> Controller Class Initialized
INFO - 2016-02-01 17:43:42 --> Model Class Initialized
INFO - 2016-02-01 17:43:42 --> Model Class Initialized
INFO - 2016-02-01 17:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:43:42 --> Pagination Class Initialized
INFO - 2016-02-01 17:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 17:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:43:42 --> Final output sent to browser
DEBUG - 2016-02-01 17:43:42 --> Total execution time: 1.1149
INFO - 2016-02-01 17:43:44 --> Config Class Initialized
INFO - 2016-02-01 17:43:44 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:43:44 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:43:44 --> Utf8 Class Initialized
INFO - 2016-02-01 17:43:44 --> URI Class Initialized
INFO - 2016-02-01 17:43:44 --> Router Class Initialized
INFO - 2016-02-01 17:43:44 --> Output Class Initialized
INFO - 2016-02-01 17:43:44 --> Security Class Initialized
DEBUG - 2016-02-01 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:43:44 --> Input Class Initialized
INFO - 2016-02-01 17:43:44 --> Language Class Initialized
INFO - 2016-02-01 17:43:44 --> Loader Class Initialized
INFO - 2016-02-01 17:43:44 --> Helper loaded: url_helper
INFO - 2016-02-01 17:43:44 --> Helper loaded: file_helper
INFO - 2016-02-01 17:43:44 --> Helper loaded: date_helper
INFO - 2016-02-01 17:43:44 --> Database Driver Class Initialized
INFO - 2016-02-01 17:43:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:43:45 --> Controller Class Initialized
INFO - 2016-02-01 17:43:45 --> Model Class Initialized
INFO - 2016-02-01 17:43:45 --> Model Class Initialized
INFO - 2016-02-01 17:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:43:45 --> Pagination Class Initialized
INFO - 2016-02-01 17:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:43:45 --> Helper loaded: text_helper
INFO - 2016-02-01 17:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:43:45 --> Final output sent to browser
DEBUG - 2016-02-01 17:43:45 --> Total execution time: 1.1974
INFO - 2016-02-01 17:43:47 --> Config Class Initialized
INFO - 2016-02-01 17:43:47 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:43:47 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:43:47 --> Utf8 Class Initialized
INFO - 2016-02-01 17:43:47 --> URI Class Initialized
INFO - 2016-02-01 17:43:47 --> Router Class Initialized
INFO - 2016-02-01 17:43:47 --> Output Class Initialized
INFO - 2016-02-01 17:43:47 --> Security Class Initialized
DEBUG - 2016-02-01 17:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:43:47 --> Input Class Initialized
INFO - 2016-02-01 17:43:47 --> Language Class Initialized
INFO - 2016-02-01 17:43:47 --> Loader Class Initialized
INFO - 2016-02-01 17:43:47 --> Helper loaded: url_helper
INFO - 2016-02-01 17:43:47 --> Helper loaded: file_helper
INFO - 2016-02-01 17:43:47 --> Helper loaded: date_helper
INFO - 2016-02-01 17:43:47 --> Database Driver Class Initialized
INFO - 2016-02-01 17:43:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:43:48 --> Controller Class Initialized
INFO - 2016-02-01 17:43:48 --> Model Class Initialized
INFO - 2016-02-01 17:43:48 --> Model Class Initialized
INFO - 2016-02-01 17:43:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:43:48 --> Pagination Class Initialized
INFO - 2016-02-01 17:43:49 --> Config Class Initialized
INFO - 2016-02-01 17:43:49 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:43:49 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:43:49 --> Utf8 Class Initialized
INFO - 2016-02-01 17:43:49 --> URI Class Initialized
INFO - 2016-02-01 17:43:49 --> Router Class Initialized
INFO - 2016-02-01 17:43:49 --> Output Class Initialized
INFO - 2016-02-01 17:43:49 --> Security Class Initialized
DEBUG - 2016-02-01 17:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:43:49 --> Input Class Initialized
INFO - 2016-02-01 17:43:49 --> Language Class Initialized
INFO - 2016-02-01 17:43:49 --> Loader Class Initialized
INFO - 2016-02-01 17:43:49 --> Helper loaded: url_helper
INFO - 2016-02-01 17:43:49 --> Helper loaded: file_helper
INFO - 2016-02-01 17:43:49 --> Helper loaded: date_helper
INFO - 2016-02-01 17:43:49 --> Database Driver Class Initialized
INFO - 2016-02-01 17:43:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:43:50 --> Controller Class Initialized
INFO - 2016-02-01 17:43:50 --> Model Class Initialized
INFO - 2016-02-01 17:43:50 --> Model Class Initialized
INFO - 2016-02-01 17:43:50 --> Helper loaded: form_helper
INFO - 2016-02-01 17:43:50 --> Form Validation Class Initialized
INFO - 2016-02-01 17:43:50 --> Helper loaded: text_helper
INFO - 2016-02-01 17:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:43:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-01 17:43:50 --> Final output sent to browser
DEBUG - 2016-02-01 17:43:50 --> Total execution time: 1.1391
INFO - 2016-02-01 17:43:52 --> Config Class Initialized
INFO - 2016-02-01 17:43:52 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:43:52 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:43:52 --> Utf8 Class Initialized
INFO - 2016-02-01 17:43:52 --> URI Class Initialized
DEBUG - 2016-02-01 17:43:52 --> No URI present. Default controller set.
INFO - 2016-02-01 17:43:52 --> Router Class Initialized
INFO - 2016-02-01 17:43:52 --> Output Class Initialized
INFO - 2016-02-01 17:43:52 --> Security Class Initialized
DEBUG - 2016-02-01 17:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:43:52 --> Input Class Initialized
INFO - 2016-02-01 17:43:52 --> Language Class Initialized
INFO - 2016-02-01 17:43:52 --> Loader Class Initialized
INFO - 2016-02-01 17:43:52 --> Helper loaded: url_helper
INFO - 2016-02-01 17:43:52 --> Helper loaded: file_helper
INFO - 2016-02-01 17:43:52 --> Helper loaded: date_helper
INFO - 2016-02-01 17:43:52 --> Database Driver Class Initialized
INFO - 2016-02-01 17:43:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:43:53 --> Controller Class Initialized
INFO - 2016-02-01 17:43:53 --> Model Class Initialized
INFO - 2016-02-01 17:43:53 --> Model Class Initialized
INFO - 2016-02-01 17:43:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:43:53 --> Pagination Class Initialized
INFO - 2016-02-01 17:43:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:43:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 17:43:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:43:53 --> Final output sent to browser
DEBUG - 2016-02-01 17:43:53 --> Total execution time: 1.1021
INFO - 2016-02-01 17:58:17 --> Config Class Initialized
INFO - 2016-02-01 17:58:17 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:58:17 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:58:17 --> Utf8 Class Initialized
INFO - 2016-02-01 17:58:17 --> URI Class Initialized
INFO - 2016-02-01 17:58:17 --> Router Class Initialized
INFO - 2016-02-01 17:58:17 --> Output Class Initialized
INFO - 2016-02-01 17:58:17 --> Security Class Initialized
DEBUG - 2016-02-01 17:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:58:17 --> Input Class Initialized
INFO - 2016-02-01 17:58:17 --> Language Class Initialized
ERROR - 2016-02-01 17:58:17 --> Severity: Parsing Error --> syntax error, unexpected 'redirect' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 413
INFO - 2016-02-01 17:58:18 --> Config Class Initialized
INFO - 2016-02-01 17:58:18 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:58:18 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:58:18 --> Utf8 Class Initialized
INFO - 2016-02-01 17:58:18 --> URI Class Initialized
DEBUG - 2016-02-01 17:58:18 --> No URI present. Default controller set.
INFO - 2016-02-01 17:58:18 --> Router Class Initialized
INFO - 2016-02-01 17:58:18 --> Output Class Initialized
INFO - 2016-02-01 17:58:18 --> Security Class Initialized
DEBUG - 2016-02-01 17:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:58:18 --> Input Class Initialized
INFO - 2016-02-01 17:58:18 --> Language Class Initialized
ERROR - 2016-02-01 17:58:18 --> Severity: Parsing Error --> syntax error, unexpected 'redirect' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 413
INFO - 2016-02-01 17:58:25 --> Config Class Initialized
INFO - 2016-02-01 17:58:25 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:58:25 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:58:25 --> Utf8 Class Initialized
INFO - 2016-02-01 17:58:25 --> URI Class Initialized
INFO - 2016-02-01 17:58:25 --> Router Class Initialized
INFO - 2016-02-01 17:58:25 --> Output Class Initialized
INFO - 2016-02-01 17:58:25 --> Security Class Initialized
DEBUG - 2016-02-01 17:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:58:25 --> Input Class Initialized
INFO - 2016-02-01 17:58:25 --> Language Class Initialized
INFO - 2016-02-01 17:58:25 --> Loader Class Initialized
INFO - 2016-02-01 17:58:25 --> Helper loaded: url_helper
INFO - 2016-02-01 17:58:25 --> Helper loaded: file_helper
INFO - 2016-02-01 17:58:25 --> Helper loaded: date_helper
INFO - 2016-02-01 17:58:25 --> Database Driver Class Initialized
INFO - 2016-02-01 17:58:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:58:26 --> Controller Class Initialized
INFO - 2016-02-01 17:58:26 --> Model Class Initialized
INFO - 2016-02-01 17:58:26 --> Model Class Initialized
INFO - 2016-02-01 17:58:26 --> Helper loaded: form_helper
INFO - 2016-02-01 17:58:26 --> Form Validation Class Initialized
INFO - 2016-02-01 17:58:26 --> Helper loaded: text_helper
INFO - 2016-02-01 17:58:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:58:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-01 17:58:26 --> Final output sent to browser
DEBUG - 2016-02-01 17:58:26 --> Total execution time: 1.0984
INFO - 2016-02-01 17:58:28 --> Config Class Initialized
INFO - 2016-02-01 17:58:28 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:58:28 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:58:28 --> Utf8 Class Initialized
INFO - 2016-02-01 17:58:28 --> URI Class Initialized
DEBUG - 2016-02-01 17:58:28 --> No URI present. Default controller set.
INFO - 2016-02-01 17:58:28 --> Router Class Initialized
INFO - 2016-02-01 17:58:28 --> Output Class Initialized
INFO - 2016-02-01 17:58:28 --> Security Class Initialized
DEBUG - 2016-02-01 17:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:58:28 --> Input Class Initialized
INFO - 2016-02-01 17:58:28 --> Language Class Initialized
INFO - 2016-02-01 17:58:28 --> Loader Class Initialized
INFO - 2016-02-01 17:58:28 --> Helper loaded: url_helper
INFO - 2016-02-01 17:58:28 --> Helper loaded: file_helper
INFO - 2016-02-01 17:58:28 --> Helper loaded: date_helper
INFO - 2016-02-01 17:58:28 --> Database Driver Class Initialized
INFO - 2016-02-01 17:58:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:58:29 --> Controller Class Initialized
INFO - 2016-02-01 17:58:29 --> Model Class Initialized
INFO - 2016-02-01 17:58:29 --> Model Class Initialized
INFO - 2016-02-01 17:58:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:58:29 --> Pagination Class Initialized
INFO - 2016-02-01 17:58:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:58:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 17:58:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:58:29 --> Final output sent to browser
DEBUG - 2016-02-01 17:58:29 --> Total execution time: 1.1046
INFO - 2016-02-01 17:58:30 --> Config Class Initialized
INFO - 2016-02-01 17:58:30 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:58:30 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:58:30 --> Utf8 Class Initialized
INFO - 2016-02-01 17:58:30 --> URI Class Initialized
INFO - 2016-02-01 17:58:30 --> Router Class Initialized
INFO - 2016-02-01 17:58:30 --> Output Class Initialized
INFO - 2016-02-01 17:58:30 --> Security Class Initialized
DEBUG - 2016-02-01 17:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:58:30 --> Input Class Initialized
INFO - 2016-02-01 17:58:30 --> Language Class Initialized
INFO - 2016-02-01 17:58:30 --> Loader Class Initialized
INFO - 2016-02-01 17:58:30 --> Helper loaded: url_helper
INFO - 2016-02-01 17:58:30 --> Helper loaded: file_helper
INFO - 2016-02-01 17:58:30 --> Helper loaded: date_helper
INFO - 2016-02-01 17:58:30 --> Database Driver Class Initialized
INFO - 2016-02-01 17:58:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:58:31 --> Controller Class Initialized
INFO - 2016-02-01 17:58:31 --> Model Class Initialized
INFO - 2016-02-01 17:58:31 --> Model Class Initialized
INFO - 2016-02-01 17:58:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:58:31 --> Pagination Class Initialized
INFO - 2016-02-01 17:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:58:31 --> Helper loaded: text_helper
INFO - 2016-02-01 17:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 17:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 17:58:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 17:58:31 --> Final output sent to browser
DEBUG - 2016-02-01 17:58:31 --> Total execution time: 1.1581
INFO - 2016-02-01 17:58:34 --> Config Class Initialized
INFO - 2016-02-01 17:58:34 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:58:34 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:58:34 --> Utf8 Class Initialized
INFO - 2016-02-01 17:58:34 --> URI Class Initialized
INFO - 2016-02-01 17:58:34 --> Router Class Initialized
INFO - 2016-02-01 17:58:34 --> Output Class Initialized
INFO - 2016-02-01 17:58:34 --> Security Class Initialized
DEBUG - 2016-02-01 17:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:58:34 --> Input Class Initialized
INFO - 2016-02-01 17:58:34 --> Language Class Initialized
INFO - 2016-02-01 17:58:34 --> Loader Class Initialized
INFO - 2016-02-01 17:58:34 --> Helper loaded: url_helper
INFO - 2016-02-01 17:58:34 --> Helper loaded: file_helper
INFO - 2016-02-01 17:58:34 --> Helper loaded: date_helper
INFO - 2016-02-01 17:58:34 --> Database Driver Class Initialized
INFO - 2016-02-01 17:58:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:58:35 --> Controller Class Initialized
INFO - 2016-02-01 17:58:35 --> Model Class Initialized
INFO - 2016-02-01 17:58:35 --> Model Class Initialized
INFO - 2016-02-01 17:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 17:58:35 --> Pagination Class Initialized
INFO - 2016-02-01 17:58:35 --> Config Class Initialized
INFO - 2016-02-01 17:58:35 --> Hooks Class Initialized
DEBUG - 2016-02-01 17:58:35 --> UTF-8 Support Enabled
INFO - 2016-02-01 17:58:35 --> Utf8 Class Initialized
INFO - 2016-02-01 17:58:35 --> URI Class Initialized
INFO - 2016-02-01 17:58:35 --> Router Class Initialized
INFO - 2016-02-01 17:58:35 --> Output Class Initialized
INFO - 2016-02-01 17:58:35 --> Security Class Initialized
DEBUG - 2016-02-01 17:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 17:58:35 --> Input Class Initialized
INFO - 2016-02-01 17:58:35 --> Language Class Initialized
INFO - 2016-02-01 17:58:35 --> Loader Class Initialized
INFO - 2016-02-01 17:58:35 --> Helper loaded: url_helper
INFO - 2016-02-01 17:58:35 --> Helper loaded: file_helper
INFO - 2016-02-01 17:58:35 --> Helper loaded: date_helper
INFO - 2016-02-01 17:58:35 --> Database Driver Class Initialized
INFO - 2016-02-01 17:58:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 17:58:36 --> Controller Class Initialized
INFO - 2016-02-01 17:58:36 --> Model Class Initialized
INFO - 2016-02-01 17:58:36 --> Model Class Initialized
INFO - 2016-02-01 17:58:36 --> Helper loaded: form_helper
INFO - 2016-02-01 17:58:36 --> Form Validation Class Initialized
INFO - 2016-02-01 17:58:36 --> Helper loaded: text_helper
INFO - 2016-02-01 17:58:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 17:58:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-01 17:58:36 --> Final output sent to browser
DEBUG - 2016-02-01 17:58:36 --> Total execution time: 1.1570
INFO - 2016-02-01 18:00:01 --> Config Class Initialized
INFO - 2016-02-01 18:00:01 --> Hooks Class Initialized
DEBUG - 2016-02-01 18:00:01 --> UTF-8 Support Enabled
INFO - 2016-02-01 18:00:01 --> Utf8 Class Initialized
INFO - 2016-02-01 18:00:01 --> URI Class Initialized
DEBUG - 2016-02-01 18:00:01 --> No URI present. Default controller set.
INFO - 2016-02-01 18:00:01 --> Router Class Initialized
INFO - 2016-02-01 18:00:01 --> Output Class Initialized
INFO - 2016-02-01 18:00:01 --> Security Class Initialized
DEBUG - 2016-02-01 18:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 18:00:01 --> Input Class Initialized
INFO - 2016-02-01 18:00:01 --> Language Class Initialized
INFO - 2016-02-01 18:00:01 --> Loader Class Initialized
INFO - 2016-02-01 18:00:01 --> Helper loaded: url_helper
INFO - 2016-02-01 18:00:01 --> Helper loaded: file_helper
INFO - 2016-02-01 18:00:01 --> Helper loaded: date_helper
INFO - 2016-02-01 18:00:01 --> Database Driver Class Initialized
INFO - 2016-02-01 18:00:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 18:00:02 --> Controller Class Initialized
INFO - 2016-02-01 18:00:02 --> Model Class Initialized
INFO - 2016-02-01 18:00:02 --> Model Class Initialized
INFO - 2016-02-01 18:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 18:00:02 --> Pagination Class Initialized
INFO - 2016-02-01 18:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 18:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-01 18:00:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 18:00:02 --> Final output sent to browser
DEBUG - 2016-02-01 18:00:02 --> Total execution time: 1.1258
INFO - 2016-02-01 18:00:09 --> Config Class Initialized
INFO - 2016-02-01 18:00:09 --> Hooks Class Initialized
DEBUG - 2016-02-01 18:00:09 --> UTF-8 Support Enabled
INFO - 2016-02-01 18:00:09 --> Utf8 Class Initialized
INFO - 2016-02-01 18:00:09 --> URI Class Initialized
INFO - 2016-02-01 18:00:09 --> Router Class Initialized
INFO - 2016-02-01 18:00:09 --> Output Class Initialized
INFO - 2016-02-01 18:00:09 --> Security Class Initialized
DEBUG - 2016-02-01 18:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-01 18:00:09 --> Input Class Initialized
INFO - 2016-02-01 18:00:09 --> Language Class Initialized
INFO - 2016-02-01 18:00:09 --> Loader Class Initialized
INFO - 2016-02-01 18:00:09 --> Helper loaded: url_helper
INFO - 2016-02-01 18:00:09 --> Helper loaded: file_helper
INFO - 2016-02-01 18:00:09 --> Helper loaded: date_helper
INFO - 2016-02-01 18:00:09 --> Database Driver Class Initialized
INFO - 2016-02-01 18:00:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-01 18:00:10 --> Controller Class Initialized
INFO - 2016-02-01 18:00:10 --> Model Class Initialized
INFO - 2016-02-01 18:00:10 --> Model Class Initialized
INFO - 2016-02-01 18:00:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-01 18:00:10 --> Pagination Class Initialized
INFO - 2016-02-01 18:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-01 18:00:10 --> Helper loaded: text_helper
INFO - 2016-02-01 18:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-01 18:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-01 18:00:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-01 18:00:10 --> Final output sent to browser
DEBUG - 2016-02-01 18:00:10 --> Total execution time: 1.1824
