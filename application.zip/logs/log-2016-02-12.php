<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-12 05:02:04 --> Config Class Initialized
INFO - 2016-02-12 05:02:04 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:02:04 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:02:04 --> Utf8 Class Initialized
INFO - 2016-02-12 05:02:04 --> URI Class Initialized
INFO - 2016-02-12 05:02:04 --> Router Class Initialized
INFO - 2016-02-12 05:02:04 --> Output Class Initialized
INFO - 2016-02-12 05:02:04 --> Security Class Initialized
DEBUG - 2016-02-12 05:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:02:04 --> Input Class Initialized
INFO - 2016-02-12 05:02:05 --> Language Class Initialized
INFO - 2016-02-12 05:02:05 --> Loader Class Initialized
INFO - 2016-02-12 05:02:05 --> Helper loaded: url_helper
INFO - 2016-02-12 05:02:05 --> Helper loaded: file_helper
INFO - 2016-02-12 05:02:05 --> Helper loaded: date_helper
INFO - 2016-02-12 05:02:05 --> Helper loaded: form_helper
INFO - 2016-02-12 05:02:05 --> Database Driver Class Initialized
INFO - 2016-02-12 05:02:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:02:06 --> Controller Class Initialized
INFO - 2016-02-12 05:02:06 --> Model Class Initialized
INFO - 2016-02-12 05:02:06 --> Model Class Initialized
INFO - 2016-02-12 05:02:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:02:06 --> Pagination Class Initialized
INFO - 2016-02-12 08:02:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:02:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:02:06 --> Helper loaded: text_helper
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-12 08:02:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
INFO - 2016-02-12 08:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 08:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 08:02:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:02:07 --> Final output sent to browser
DEBUG - 2016-02-12 08:02:07 --> Total execution time: 2.4274
INFO - 2016-02-12 05:16:04 --> Config Class Initialized
INFO - 2016-02-12 05:16:04 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:16:04 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:16:04 --> Utf8 Class Initialized
INFO - 2016-02-12 05:16:04 --> URI Class Initialized
INFO - 2016-02-12 05:16:04 --> Router Class Initialized
INFO - 2016-02-12 05:16:04 --> Output Class Initialized
INFO - 2016-02-12 05:16:04 --> Security Class Initialized
DEBUG - 2016-02-12 05:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:16:04 --> Input Class Initialized
INFO - 2016-02-12 05:16:04 --> Language Class Initialized
INFO - 2016-02-12 05:16:04 --> Loader Class Initialized
INFO - 2016-02-12 05:16:04 --> Helper loaded: url_helper
INFO - 2016-02-12 05:16:04 --> Helper loaded: file_helper
INFO - 2016-02-12 05:16:04 --> Helper loaded: date_helper
INFO - 2016-02-12 05:16:04 --> Helper loaded: form_helper
INFO - 2016-02-12 05:16:04 --> Database Driver Class Initialized
INFO - 2016-02-12 05:16:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:16:05 --> Controller Class Initialized
INFO - 2016-02-12 05:16:05 --> Model Class Initialized
INFO - 2016-02-12 05:16:05 --> Model Class Initialized
INFO - 2016-02-12 05:16:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:16:05 --> Pagination Class Initialized
INFO - 2016-02-12 08:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:16:05 --> Helper loaded: text_helper
INFO - 2016-02-12 08:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 08:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 08:16:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:16:05 --> Final output sent to browser
DEBUG - 2016-02-12 08:16:05 --> Total execution time: 1.1821
INFO - 2016-02-12 05:16:15 --> Config Class Initialized
INFO - 2016-02-12 05:16:15 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:16:15 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:16:15 --> Utf8 Class Initialized
INFO - 2016-02-12 05:16:15 --> URI Class Initialized
INFO - 2016-02-12 05:16:15 --> Router Class Initialized
INFO - 2016-02-12 05:16:15 --> Output Class Initialized
INFO - 2016-02-12 05:16:15 --> Security Class Initialized
DEBUG - 2016-02-12 05:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:16:15 --> Input Class Initialized
INFO - 2016-02-12 05:16:15 --> Language Class Initialized
INFO - 2016-02-12 05:16:15 --> Loader Class Initialized
INFO - 2016-02-12 05:16:15 --> Helper loaded: url_helper
INFO - 2016-02-12 05:16:15 --> Helper loaded: file_helper
INFO - 2016-02-12 05:16:15 --> Helper loaded: date_helper
INFO - 2016-02-12 05:16:15 --> Helper loaded: form_helper
INFO - 2016-02-12 05:16:15 --> Database Driver Class Initialized
INFO - 2016-02-12 05:16:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:16:16 --> Controller Class Initialized
INFO - 2016-02-12 05:16:16 --> Model Class Initialized
INFO - 2016-02-12 05:16:16 --> Model Class Initialized
INFO - 2016-02-12 05:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:16:16 --> Pagination Class Initialized
INFO - 2016-02-12 08:16:16 --> Form Validation Class Initialized
INFO - 2016-02-12 08:16:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-12 08:16:16 --> Final output sent to browser
DEBUG - 2016-02-12 08:16:16 --> Total execution time: 1.1436
INFO - 2016-02-12 05:16:18 --> Config Class Initialized
INFO - 2016-02-12 05:16:18 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:16:18 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:16:18 --> Utf8 Class Initialized
INFO - 2016-02-12 05:16:18 --> URI Class Initialized
INFO - 2016-02-12 05:16:18 --> Router Class Initialized
INFO - 2016-02-12 05:16:18 --> Output Class Initialized
INFO - 2016-02-12 05:16:18 --> Security Class Initialized
DEBUG - 2016-02-12 05:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:16:18 --> Input Class Initialized
INFO - 2016-02-12 05:16:18 --> Language Class Initialized
INFO - 2016-02-12 05:16:18 --> Loader Class Initialized
INFO - 2016-02-12 05:16:18 --> Helper loaded: url_helper
INFO - 2016-02-12 05:16:18 --> Helper loaded: file_helper
INFO - 2016-02-12 05:16:18 --> Helper loaded: date_helper
INFO - 2016-02-12 05:16:18 --> Helper loaded: form_helper
INFO - 2016-02-12 05:16:18 --> Database Driver Class Initialized
INFO - 2016-02-12 05:16:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:16:19 --> Controller Class Initialized
INFO - 2016-02-12 05:16:19 --> Model Class Initialized
INFO - 2016-02-12 05:16:19 --> Model Class Initialized
INFO - 2016-02-12 05:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:16:19 --> Pagination Class Initialized
INFO - 2016-02-12 08:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:16:19 --> Helper loaded: text_helper
INFO - 2016-02-12 08:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 08:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 08:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:16:19 --> Final output sent to browser
DEBUG - 2016-02-12 08:16:19 --> Total execution time: 1.1428
INFO - 2016-02-12 05:46:09 --> Config Class Initialized
INFO - 2016-02-12 05:46:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:46:09 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:46:09 --> Utf8 Class Initialized
INFO - 2016-02-12 05:46:09 --> URI Class Initialized
DEBUG - 2016-02-12 05:46:09 --> No URI present. Default controller set.
INFO - 2016-02-12 05:46:09 --> Router Class Initialized
INFO - 2016-02-12 05:46:09 --> Output Class Initialized
INFO - 2016-02-12 05:46:09 --> Security Class Initialized
DEBUG - 2016-02-12 05:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:46:09 --> Input Class Initialized
INFO - 2016-02-12 05:46:09 --> Language Class Initialized
INFO - 2016-02-12 05:46:09 --> Loader Class Initialized
INFO - 2016-02-12 05:46:09 --> Helper loaded: url_helper
INFO - 2016-02-12 05:46:09 --> Helper loaded: file_helper
INFO - 2016-02-12 05:46:09 --> Helper loaded: date_helper
INFO - 2016-02-12 05:46:09 --> Helper loaded: form_helper
INFO - 2016-02-12 05:46:09 --> Database Driver Class Initialized
INFO - 2016-02-12 05:46:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:46:10 --> Controller Class Initialized
INFO - 2016-02-12 05:46:10 --> Model Class Initialized
INFO - 2016-02-12 05:46:10 --> Model Class Initialized
INFO - 2016-02-12 05:46:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:46:10 --> Pagination Class Initialized
INFO - 2016-02-12 08:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:46:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:46:10 --> Final output sent to browser
DEBUG - 2016-02-12 08:46:10 --> Total execution time: 1.1957
INFO - 2016-02-12 05:46:12 --> Config Class Initialized
INFO - 2016-02-12 05:46:12 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:46:12 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:46:12 --> Utf8 Class Initialized
INFO - 2016-02-12 05:46:12 --> URI Class Initialized
INFO - 2016-02-12 05:46:12 --> Router Class Initialized
INFO - 2016-02-12 05:46:12 --> Output Class Initialized
INFO - 2016-02-12 05:46:12 --> Security Class Initialized
DEBUG - 2016-02-12 05:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:46:12 --> Input Class Initialized
INFO - 2016-02-12 05:46:12 --> Language Class Initialized
INFO - 2016-02-12 05:46:12 --> Loader Class Initialized
INFO - 2016-02-12 05:46:12 --> Helper loaded: url_helper
INFO - 2016-02-12 05:46:12 --> Helper loaded: file_helper
INFO - 2016-02-12 05:46:12 --> Helper loaded: date_helper
INFO - 2016-02-12 05:46:12 --> Helper loaded: form_helper
INFO - 2016-02-12 05:46:12 --> Database Driver Class Initialized
INFO - 2016-02-12 05:46:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:46:13 --> Controller Class Initialized
INFO - 2016-02-12 05:46:13 --> Model Class Initialized
INFO - 2016-02-12 05:46:13 --> Model Class Initialized
INFO - 2016-02-12 05:46:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:46:13 --> Pagination Class Initialized
INFO - 2016-02-12 08:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:46:13 --> Helper loaded: text_helper
INFO - 2016-02-12 08:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 08:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 08:46:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:46:13 --> Final output sent to browser
DEBUG - 2016-02-12 08:46:13 --> Total execution time: 1.1387
INFO - 2016-02-12 05:47:22 --> Config Class Initialized
INFO - 2016-02-12 05:47:22 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:47:22 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:47:22 --> Utf8 Class Initialized
INFO - 2016-02-12 05:47:22 --> URI Class Initialized
INFO - 2016-02-12 05:47:22 --> Router Class Initialized
INFO - 2016-02-12 05:47:22 --> Output Class Initialized
INFO - 2016-02-12 05:47:22 --> Security Class Initialized
DEBUG - 2016-02-12 05:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:47:22 --> Input Class Initialized
INFO - 2016-02-12 05:47:22 --> Language Class Initialized
INFO - 2016-02-12 05:47:22 --> Loader Class Initialized
INFO - 2016-02-12 05:47:22 --> Helper loaded: url_helper
INFO - 2016-02-12 05:47:22 --> Helper loaded: file_helper
INFO - 2016-02-12 05:47:22 --> Helper loaded: date_helper
INFO - 2016-02-12 05:47:22 --> Helper loaded: form_helper
INFO - 2016-02-12 05:47:22 --> Database Driver Class Initialized
INFO - 2016-02-12 05:47:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:47:23 --> Controller Class Initialized
INFO - 2016-02-12 05:47:23 --> Model Class Initialized
INFO - 2016-02-12 05:47:23 --> Model Class Initialized
INFO - 2016-02-12 05:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:47:23 --> Pagination Class Initialized
INFO - 2016-02-12 08:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:47:23 --> Helper loaded: text_helper
INFO - 2016-02-12 08:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 08:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 08:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:47:23 --> Final output sent to browser
DEBUG - 2016-02-12 08:47:23 --> Total execution time: 1.1386
INFO - 2016-02-12 05:47:30 --> Config Class Initialized
INFO - 2016-02-12 05:47:30 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:47:30 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:47:30 --> Utf8 Class Initialized
INFO - 2016-02-12 05:47:30 --> URI Class Initialized
DEBUG - 2016-02-12 05:47:30 --> No URI present. Default controller set.
INFO - 2016-02-12 05:47:30 --> Router Class Initialized
INFO - 2016-02-12 05:47:30 --> Output Class Initialized
INFO - 2016-02-12 05:47:30 --> Security Class Initialized
DEBUG - 2016-02-12 05:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:47:30 --> Input Class Initialized
INFO - 2016-02-12 05:47:30 --> Language Class Initialized
INFO - 2016-02-12 05:47:30 --> Loader Class Initialized
INFO - 2016-02-12 05:47:30 --> Helper loaded: url_helper
INFO - 2016-02-12 05:47:30 --> Helper loaded: file_helper
INFO - 2016-02-12 05:47:30 --> Helper loaded: date_helper
INFO - 2016-02-12 05:47:30 --> Helper loaded: form_helper
INFO - 2016-02-12 05:47:30 --> Database Driver Class Initialized
INFO - 2016-02-12 05:47:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:47:31 --> Controller Class Initialized
INFO - 2016-02-12 05:47:31 --> Model Class Initialized
INFO - 2016-02-12 05:47:31 --> Model Class Initialized
INFO - 2016-02-12 05:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:47:31 --> Pagination Class Initialized
INFO - 2016-02-12 08:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:47:31 --> Final output sent to browser
DEBUG - 2016-02-12 08:47:31 --> Total execution time: 1.1186
INFO - 2016-02-12 05:48:02 --> Config Class Initialized
INFO - 2016-02-12 05:48:02 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:48:02 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:48:02 --> Utf8 Class Initialized
INFO - 2016-02-12 05:48:02 --> URI Class Initialized
INFO - 2016-02-12 05:48:02 --> Router Class Initialized
INFO - 2016-02-12 05:48:02 --> Output Class Initialized
INFO - 2016-02-12 05:48:02 --> Security Class Initialized
DEBUG - 2016-02-12 05:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:48:02 --> Input Class Initialized
INFO - 2016-02-12 05:48:02 --> Language Class Initialized
INFO - 2016-02-12 05:48:02 --> Loader Class Initialized
INFO - 2016-02-12 05:48:02 --> Helper loaded: url_helper
INFO - 2016-02-12 05:48:02 --> Helper loaded: file_helper
INFO - 2016-02-12 05:48:02 --> Helper loaded: date_helper
INFO - 2016-02-12 05:48:02 --> Helper loaded: form_helper
INFO - 2016-02-12 05:48:02 --> Database Driver Class Initialized
INFO - 2016-02-12 05:48:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:48:03 --> Controller Class Initialized
INFO - 2016-02-12 05:48:03 --> Model Class Initialized
INFO - 2016-02-12 05:48:03 --> Model Class Initialized
INFO - 2016-02-12 05:48:03 --> Form Validation Class Initialized
INFO - 2016-02-12 05:48:03 --> Helper loaded: text_helper
INFO - 2016-02-12 05:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 05:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 05:48:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-12 05:48:03 --> Final output sent to browser
DEBUG - 2016-02-12 05:48:03 --> Total execution time: 1.1485
INFO - 2016-02-12 05:48:06 --> Config Class Initialized
INFO - 2016-02-12 05:48:06 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:48:06 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:48:06 --> Utf8 Class Initialized
INFO - 2016-02-12 05:48:06 --> URI Class Initialized
DEBUG - 2016-02-12 05:48:06 --> No URI present. Default controller set.
INFO - 2016-02-12 05:48:06 --> Router Class Initialized
INFO - 2016-02-12 05:48:06 --> Output Class Initialized
INFO - 2016-02-12 05:48:06 --> Security Class Initialized
DEBUG - 2016-02-12 05:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:48:06 --> Input Class Initialized
INFO - 2016-02-12 05:48:06 --> Language Class Initialized
INFO - 2016-02-12 05:48:06 --> Loader Class Initialized
INFO - 2016-02-12 05:48:06 --> Helper loaded: url_helper
INFO - 2016-02-12 05:48:06 --> Helper loaded: file_helper
INFO - 2016-02-12 05:48:06 --> Helper loaded: date_helper
INFO - 2016-02-12 05:48:06 --> Helper loaded: form_helper
INFO - 2016-02-12 05:48:06 --> Database Driver Class Initialized
INFO - 2016-02-12 05:48:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:48:07 --> Controller Class Initialized
INFO - 2016-02-12 05:48:07 --> Model Class Initialized
INFO - 2016-02-12 05:48:07 --> Model Class Initialized
INFO - 2016-02-12 05:48:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:48:07 --> Pagination Class Initialized
INFO - 2016-02-12 08:48:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:48:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:48:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:48:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:48:07 --> Final output sent to browser
DEBUG - 2016-02-12 08:48:07 --> Total execution time: 1.1336
INFO - 2016-02-12 05:52:24 --> Config Class Initialized
INFO - 2016-02-12 05:52:24 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:52:24 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:52:24 --> Utf8 Class Initialized
INFO - 2016-02-12 05:52:24 --> URI Class Initialized
INFO - 2016-02-12 05:52:24 --> Router Class Initialized
INFO - 2016-02-12 05:52:24 --> Output Class Initialized
INFO - 2016-02-12 05:52:24 --> Security Class Initialized
DEBUG - 2016-02-12 05:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:52:24 --> Input Class Initialized
INFO - 2016-02-12 05:52:24 --> Language Class Initialized
INFO - 2016-02-12 05:52:24 --> Loader Class Initialized
INFO - 2016-02-12 05:52:24 --> Helper loaded: url_helper
INFO - 2016-02-12 05:52:24 --> Helper loaded: file_helper
INFO - 2016-02-12 05:52:24 --> Helper loaded: date_helper
INFO - 2016-02-12 05:52:24 --> Helper loaded: form_helper
INFO - 2016-02-12 05:52:24 --> Database Driver Class Initialized
INFO - 2016-02-12 05:52:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:52:25 --> Controller Class Initialized
INFO - 2016-02-12 05:52:25 --> Model Class Initialized
INFO - 2016-02-12 05:52:25 --> Model Class Initialized
INFO - 2016-02-12 05:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:52:25 --> Pagination Class Initialized
INFO - 2016-02-12 08:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:52:25 --> Final output sent to browser
DEBUG - 2016-02-12 08:52:25 --> Total execution time: 1.1276
INFO - 2016-02-12 05:55:55 --> Config Class Initialized
INFO - 2016-02-12 05:55:55 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:55:55 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:55:55 --> Utf8 Class Initialized
INFO - 2016-02-12 05:55:55 --> URI Class Initialized
INFO - 2016-02-12 05:55:55 --> Router Class Initialized
INFO - 2016-02-12 05:55:55 --> Output Class Initialized
INFO - 2016-02-12 05:55:55 --> Security Class Initialized
DEBUG - 2016-02-12 05:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:55:55 --> Input Class Initialized
INFO - 2016-02-12 05:55:55 --> Language Class Initialized
INFO - 2016-02-12 05:55:55 --> Loader Class Initialized
INFO - 2016-02-12 05:55:55 --> Helper loaded: url_helper
INFO - 2016-02-12 05:55:55 --> Helper loaded: file_helper
INFO - 2016-02-12 05:55:55 --> Helper loaded: date_helper
INFO - 2016-02-12 05:55:55 --> Helper loaded: form_helper
INFO - 2016-02-12 05:55:55 --> Database Driver Class Initialized
INFO - 2016-02-12 05:55:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:55:56 --> Controller Class Initialized
INFO - 2016-02-12 05:55:56 --> Model Class Initialized
INFO - 2016-02-12 05:55:56 --> Model Class Initialized
INFO - 2016-02-12 05:55:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:55:56 --> Pagination Class Initialized
INFO - 2016-02-12 08:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:55:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:55:56 --> Final output sent to browser
DEBUG - 2016-02-12 08:55:56 --> Total execution time: 1.1041
INFO - 2016-02-12 05:56:23 --> Config Class Initialized
INFO - 2016-02-12 05:56:23 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:56:23 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:56:23 --> Utf8 Class Initialized
INFO - 2016-02-12 05:56:23 --> URI Class Initialized
INFO - 2016-02-12 05:56:23 --> Router Class Initialized
INFO - 2016-02-12 05:56:23 --> Output Class Initialized
INFO - 2016-02-12 05:56:23 --> Security Class Initialized
DEBUG - 2016-02-12 05:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:56:23 --> Input Class Initialized
INFO - 2016-02-12 05:56:23 --> Language Class Initialized
INFO - 2016-02-12 05:56:23 --> Loader Class Initialized
INFO - 2016-02-12 05:56:23 --> Helper loaded: url_helper
INFO - 2016-02-12 05:56:23 --> Helper loaded: file_helper
INFO - 2016-02-12 05:56:23 --> Helper loaded: date_helper
INFO - 2016-02-12 05:56:23 --> Helper loaded: form_helper
INFO - 2016-02-12 05:56:23 --> Database Driver Class Initialized
INFO - 2016-02-12 05:56:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:56:24 --> Controller Class Initialized
INFO - 2016-02-12 05:56:24 --> Model Class Initialized
INFO - 2016-02-12 05:56:24 --> Model Class Initialized
INFO - 2016-02-12 05:56:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:56:24 --> Pagination Class Initialized
INFO - 2016-02-12 08:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:56:24 --> Helper loaded: text_helper
INFO - 2016-02-12 08:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 08:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 08:56:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:56:24 --> Final output sent to browser
DEBUG - 2016-02-12 08:56:24 --> Total execution time: 1.1383
INFO - 2016-02-12 05:56:28 --> Config Class Initialized
INFO - 2016-02-12 05:56:28 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:56:28 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:56:28 --> Utf8 Class Initialized
INFO - 2016-02-12 05:56:28 --> URI Class Initialized
DEBUG - 2016-02-12 05:56:28 --> No URI present. Default controller set.
INFO - 2016-02-12 05:56:28 --> Router Class Initialized
INFO - 2016-02-12 05:56:28 --> Output Class Initialized
INFO - 2016-02-12 05:56:28 --> Security Class Initialized
DEBUG - 2016-02-12 05:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:56:28 --> Input Class Initialized
INFO - 2016-02-12 05:56:28 --> Language Class Initialized
INFO - 2016-02-12 05:56:28 --> Loader Class Initialized
INFO - 2016-02-12 05:56:28 --> Helper loaded: url_helper
INFO - 2016-02-12 05:56:28 --> Helper loaded: file_helper
INFO - 2016-02-12 05:56:28 --> Helper loaded: date_helper
INFO - 2016-02-12 05:56:28 --> Helper loaded: form_helper
INFO - 2016-02-12 05:56:28 --> Database Driver Class Initialized
INFO - 2016-02-12 05:56:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:56:29 --> Controller Class Initialized
INFO - 2016-02-12 05:56:29 --> Model Class Initialized
INFO - 2016-02-12 05:56:29 --> Model Class Initialized
INFO - 2016-02-12 05:56:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:56:29 --> Pagination Class Initialized
INFO - 2016-02-12 08:56:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:56:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:56:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:56:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:56:29 --> Final output sent to browser
DEBUG - 2016-02-12 08:56:29 --> Total execution time: 1.1077
INFO - 2016-02-12 05:57:25 --> Config Class Initialized
INFO - 2016-02-12 05:57:25 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:57:25 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:57:25 --> Utf8 Class Initialized
INFO - 2016-02-12 05:57:25 --> URI Class Initialized
DEBUG - 2016-02-12 05:57:25 --> No URI present. Default controller set.
INFO - 2016-02-12 05:57:25 --> Router Class Initialized
INFO - 2016-02-12 05:57:25 --> Output Class Initialized
INFO - 2016-02-12 05:57:25 --> Security Class Initialized
DEBUG - 2016-02-12 05:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:57:25 --> Input Class Initialized
INFO - 2016-02-12 05:57:25 --> Language Class Initialized
INFO - 2016-02-12 05:57:25 --> Loader Class Initialized
INFO - 2016-02-12 05:57:25 --> Helper loaded: url_helper
INFO - 2016-02-12 05:57:25 --> Helper loaded: file_helper
INFO - 2016-02-12 05:57:25 --> Helper loaded: date_helper
INFO - 2016-02-12 05:57:25 --> Helper loaded: form_helper
INFO - 2016-02-12 05:57:25 --> Database Driver Class Initialized
INFO - 2016-02-12 05:57:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:57:26 --> Controller Class Initialized
INFO - 2016-02-12 05:57:26 --> Model Class Initialized
INFO - 2016-02-12 05:57:26 --> Model Class Initialized
INFO - 2016-02-12 05:57:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:57:26 --> Pagination Class Initialized
INFO - 2016-02-12 08:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:57:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:57:26 --> Final output sent to browser
DEBUG - 2016-02-12 08:57:26 --> Total execution time: 1.1060
INFO - 2016-02-12 05:57:28 --> Config Class Initialized
INFO - 2016-02-12 05:57:28 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:57:28 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:57:28 --> Utf8 Class Initialized
INFO - 2016-02-12 05:57:28 --> URI Class Initialized
INFO - 2016-02-12 05:57:28 --> Router Class Initialized
INFO - 2016-02-12 05:57:28 --> Output Class Initialized
INFO - 2016-02-12 05:57:28 --> Security Class Initialized
DEBUG - 2016-02-12 05:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:57:28 --> Input Class Initialized
INFO - 2016-02-12 05:57:28 --> Language Class Initialized
INFO - 2016-02-12 05:57:28 --> Loader Class Initialized
INFO - 2016-02-12 05:57:28 --> Helper loaded: url_helper
INFO - 2016-02-12 05:57:28 --> Helper loaded: file_helper
INFO - 2016-02-12 05:57:28 --> Helper loaded: date_helper
INFO - 2016-02-12 05:57:28 --> Helper loaded: form_helper
INFO - 2016-02-12 05:57:28 --> Database Driver Class Initialized
INFO - 2016-02-12 05:57:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:57:29 --> Controller Class Initialized
INFO - 2016-02-12 05:57:29 --> Model Class Initialized
INFO - 2016-02-12 05:57:29 --> Model Class Initialized
INFO - 2016-02-12 05:57:29 --> Form Validation Class Initialized
INFO - 2016-02-12 05:57:29 --> Helper loaded: text_helper
INFO - 2016-02-12 05:57:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 05:57:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 05:57:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-12 05:57:29 --> Final output sent to browser
DEBUG - 2016-02-12 05:57:29 --> Total execution time: 1.0898
INFO - 2016-02-12 05:57:31 --> Config Class Initialized
INFO - 2016-02-12 05:57:31 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:57:31 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:57:31 --> Utf8 Class Initialized
INFO - 2016-02-12 05:57:31 --> URI Class Initialized
DEBUG - 2016-02-12 05:57:31 --> No URI present. Default controller set.
INFO - 2016-02-12 05:57:31 --> Router Class Initialized
INFO - 2016-02-12 05:57:31 --> Output Class Initialized
INFO - 2016-02-12 05:57:31 --> Security Class Initialized
DEBUG - 2016-02-12 05:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:57:31 --> Input Class Initialized
INFO - 2016-02-12 05:57:31 --> Language Class Initialized
INFO - 2016-02-12 05:57:31 --> Loader Class Initialized
INFO - 2016-02-12 05:57:31 --> Helper loaded: url_helper
INFO - 2016-02-12 05:57:31 --> Helper loaded: file_helper
INFO - 2016-02-12 05:57:31 --> Helper loaded: date_helper
INFO - 2016-02-12 05:57:31 --> Helper loaded: form_helper
INFO - 2016-02-12 05:57:31 --> Database Driver Class Initialized
INFO - 2016-02-12 05:57:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:57:32 --> Controller Class Initialized
INFO - 2016-02-12 05:57:32 --> Model Class Initialized
INFO - 2016-02-12 05:57:32 --> Model Class Initialized
INFO - 2016-02-12 05:57:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:57:32 --> Pagination Class Initialized
INFO - 2016-02-12 08:57:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:57:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:57:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:57:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:57:32 --> Final output sent to browser
DEBUG - 2016-02-12 08:57:32 --> Total execution time: 1.1138
INFO - 2016-02-12 05:57:52 --> Config Class Initialized
INFO - 2016-02-12 05:57:52 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:57:52 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:57:52 --> Utf8 Class Initialized
INFO - 2016-02-12 05:57:52 --> URI Class Initialized
DEBUG - 2016-02-12 05:57:52 --> No URI present. Default controller set.
INFO - 2016-02-12 05:57:52 --> Router Class Initialized
INFO - 2016-02-12 05:57:52 --> Output Class Initialized
INFO - 2016-02-12 05:57:52 --> Security Class Initialized
DEBUG - 2016-02-12 05:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:57:52 --> Input Class Initialized
INFO - 2016-02-12 05:57:52 --> Language Class Initialized
INFO - 2016-02-12 05:57:52 --> Loader Class Initialized
INFO - 2016-02-12 05:57:52 --> Helper loaded: url_helper
INFO - 2016-02-12 05:57:52 --> Helper loaded: file_helper
INFO - 2016-02-12 05:57:52 --> Helper loaded: date_helper
INFO - 2016-02-12 05:57:52 --> Helper loaded: form_helper
INFO - 2016-02-12 05:57:52 --> Database Driver Class Initialized
INFO - 2016-02-12 05:57:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:57:53 --> Controller Class Initialized
INFO - 2016-02-12 05:57:53 --> Model Class Initialized
INFO - 2016-02-12 05:57:53 --> Model Class Initialized
INFO - 2016-02-12 05:57:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:57:53 --> Pagination Class Initialized
INFO - 2016-02-12 08:57:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:57:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:57:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:57:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:57:53 --> Final output sent to browser
DEBUG - 2016-02-12 08:57:53 --> Total execution time: 1.0937
INFO - 2016-02-12 05:59:03 --> Config Class Initialized
INFO - 2016-02-12 05:59:03 --> Hooks Class Initialized
DEBUG - 2016-02-12 05:59:03 --> UTF-8 Support Enabled
INFO - 2016-02-12 05:59:03 --> Utf8 Class Initialized
INFO - 2016-02-12 05:59:03 --> URI Class Initialized
DEBUG - 2016-02-12 05:59:03 --> No URI present. Default controller set.
INFO - 2016-02-12 05:59:03 --> Router Class Initialized
INFO - 2016-02-12 05:59:03 --> Output Class Initialized
INFO - 2016-02-12 05:59:03 --> Security Class Initialized
DEBUG - 2016-02-12 05:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 05:59:03 --> Input Class Initialized
INFO - 2016-02-12 05:59:03 --> Language Class Initialized
INFO - 2016-02-12 05:59:03 --> Loader Class Initialized
INFO - 2016-02-12 05:59:03 --> Helper loaded: url_helper
INFO - 2016-02-12 05:59:03 --> Helper loaded: file_helper
INFO - 2016-02-12 05:59:03 --> Helper loaded: date_helper
INFO - 2016-02-12 05:59:03 --> Helper loaded: form_helper
INFO - 2016-02-12 05:59:03 --> Database Driver Class Initialized
INFO - 2016-02-12 05:59:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 05:59:04 --> Controller Class Initialized
INFO - 2016-02-12 05:59:04 --> Model Class Initialized
INFO - 2016-02-12 05:59:04 --> Model Class Initialized
INFO - 2016-02-12 05:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 05:59:04 --> Pagination Class Initialized
INFO - 2016-02-12 08:59:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:59:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:59:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 08:59:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:59:04 --> Final output sent to browser
DEBUG - 2016-02-12 08:59:04 --> Total execution time: 1.0990
INFO - 2016-02-12 06:04:03 --> Config Class Initialized
INFO - 2016-02-12 06:04:03 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:04:03 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:04:03 --> Utf8 Class Initialized
INFO - 2016-02-12 06:04:03 --> URI Class Initialized
DEBUG - 2016-02-12 06:04:03 --> No URI present. Default controller set.
INFO - 2016-02-12 06:04:03 --> Router Class Initialized
INFO - 2016-02-12 06:04:03 --> Output Class Initialized
INFO - 2016-02-12 06:04:03 --> Security Class Initialized
DEBUG - 2016-02-12 06:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:04:03 --> Input Class Initialized
INFO - 2016-02-12 06:04:03 --> Language Class Initialized
INFO - 2016-02-12 06:04:03 --> Loader Class Initialized
INFO - 2016-02-12 06:04:03 --> Helper loaded: url_helper
INFO - 2016-02-12 06:04:03 --> Helper loaded: file_helper
INFO - 2016-02-12 06:04:03 --> Helper loaded: date_helper
INFO - 2016-02-12 06:04:03 --> Helper loaded: form_helper
INFO - 2016-02-12 06:04:03 --> Database Driver Class Initialized
INFO - 2016-02-12 06:04:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:04:04 --> Controller Class Initialized
INFO - 2016-02-12 06:04:04 --> Model Class Initialized
INFO - 2016-02-12 06:04:04 --> Model Class Initialized
INFO - 2016-02-12 06:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 06:04:04 --> Pagination Class Initialized
INFO - 2016-02-12 09:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 09:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 09:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 09:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 09:04:04 --> Final output sent to browser
DEBUG - 2016-02-12 09:04:04 --> Total execution time: 1.0892
INFO - 2016-02-12 06:06:05 --> Config Class Initialized
INFO - 2016-02-12 06:06:05 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:06:05 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:06:05 --> Utf8 Class Initialized
INFO - 2016-02-12 06:06:05 --> URI Class Initialized
DEBUG - 2016-02-12 06:06:05 --> No URI present. Default controller set.
INFO - 2016-02-12 06:06:05 --> Router Class Initialized
INFO - 2016-02-12 06:06:05 --> Output Class Initialized
INFO - 2016-02-12 06:06:05 --> Security Class Initialized
DEBUG - 2016-02-12 06:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:06:05 --> Input Class Initialized
INFO - 2016-02-12 06:06:05 --> Language Class Initialized
INFO - 2016-02-12 06:06:05 --> Loader Class Initialized
INFO - 2016-02-12 06:06:05 --> Helper loaded: url_helper
INFO - 2016-02-12 06:06:05 --> Helper loaded: file_helper
INFO - 2016-02-12 06:06:05 --> Helper loaded: date_helper
INFO - 2016-02-12 06:06:05 --> Helper loaded: form_helper
INFO - 2016-02-12 06:06:05 --> Database Driver Class Initialized
INFO - 2016-02-12 06:06:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:06:06 --> Controller Class Initialized
INFO - 2016-02-12 06:06:06 --> Model Class Initialized
INFO - 2016-02-12 06:06:06 --> Model Class Initialized
INFO - 2016-02-12 06:06:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 06:06:06 --> Pagination Class Initialized
INFO - 2016-02-12 09:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 09:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 09:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 09:06:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 09:06:06 --> Final output sent to browser
DEBUG - 2016-02-12 09:06:06 --> Total execution time: 1.1339
INFO - 2016-02-12 06:09:19 --> Config Class Initialized
INFO - 2016-02-12 06:09:19 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:09:19 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:09:19 --> Utf8 Class Initialized
INFO - 2016-02-12 06:09:19 --> URI Class Initialized
DEBUG - 2016-02-12 06:09:19 --> No URI present. Default controller set.
INFO - 2016-02-12 06:09:19 --> Router Class Initialized
INFO - 2016-02-12 06:09:19 --> Output Class Initialized
INFO - 2016-02-12 06:09:19 --> Security Class Initialized
DEBUG - 2016-02-12 06:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:09:19 --> Input Class Initialized
INFO - 2016-02-12 06:09:19 --> Language Class Initialized
INFO - 2016-02-12 06:09:19 --> Loader Class Initialized
INFO - 2016-02-12 06:09:19 --> Helper loaded: url_helper
INFO - 2016-02-12 06:09:19 --> Helper loaded: file_helper
INFO - 2016-02-12 06:09:19 --> Helper loaded: date_helper
INFO - 2016-02-12 06:09:19 --> Helper loaded: form_helper
INFO - 2016-02-12 06:09:19 --> Database Driver Class Initialized
INFO - 2016-02-12 06:09:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:09:20 --> Controller Class Initialized
INFO - 2016-02-12 06:09:20 --> Model Class Initialized
INFO - 2016-02-12 06:09:20 --> Model Class Initialized
INFO - 2016-02-12 06:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 06:09:20 --> Pagination Class Initialized
INFO - 2016-02-12 09:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 09:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 09:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 09:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 09:09:20 --> Final output sent to browser
DEBUG - 2016-02-12 09:09:20 --> Total execution time: 1.1192
INFO - 2016-02-12 06:10:28 --> Config Class Initialized
INFO - 2016-02-12 06:10:28 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:10:28 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:10:28 --> Utf8 Class Initialized
INFO - 2016-02-12 06:10:28 --> URI Class Initialized
DEBUG - 2016-02-12 06:10:28 --> No URI present. Default controller set.
INFO - 2016-02-12 06:10:28 --> Router Class Initialized
INFO - 2016-02-12 06:10:28 --> Output Class Initialized
INFO - 2016-02-12 06:10:28 --> Security Class Initialized
DEBUG - 2016-02-12 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:10:28 --> Input Class Initialized
INFO - 2016-02-12 06:10:28 --> Language Class Initialized
INFO - 2016-02-12 06:10:28 --> Loader Class Initialized
INFO - 2016-02-12 06:10:28 --> Helper loaded: url_helper
INFO - 2016-02-12 06:10:28 --> Helper loaded: file_helper
INFO - 2016-02-12 06:10:28 --> Helper loaded: date_helper
INFO - 2016-02-12 06:10:28 --> Helper loaded: form_helper
INFO - 2016-02-12 06:10:28 --> Database Driver Class Initialized
INFO - 2016-02-12 06:10:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:10:29 --> Controller Class Initialized
INFO - 2016-02-12 06:10:29 --> Model Class Initialized
INFO - 2016-02-12 06:10:29 --> Model Class Initialized
INFO - 2016-02-12 06:10:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 06:10:29 --> Pagination Class Initialized
INFO - 2016-02-12 09:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 09:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 09:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 09:10:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 09:10:29 --> Final output sent to browser
DEBUG - 2016-02-12 09:10:29 --> Total execution time: 1.1029
INFO - 2016-02-12 06:10:46 --> Config Class Initialized
INFO - 2016-02-12 06:10:46 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:10:46 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:10:46 --> Utf8 Class Initialized
INFO - 2016-02-12 06:10:46 --> URI Class Initialized
DEBUG - 2016-02-12 06:10:46 --> No URI present. Default controller set.
INFO - 2016-02-12 06:10:46 --> Router Class Initialized
INFO - 2016-02-12 06:10:46 --> Output Class Initialized
INFO - 2016-02-12 06:10:46 --> Security Class Initialized
DEBUG - 2016-02-12 06:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:10:46 --> Input Class Initialized
INFO - 2016-02-12 06:10:46 --> Language Class Initialized
INFO - 2016-02-12 06:10:46 --> Loader Class Initialized
INFO - 2016-02-12 06:10:46 --> Helper loaded: url_helper
INFO - 2016-02-12 06:10:46 --> Helper loaded: file_helper
INFO - 2016-02-12 06:10:46 --> Helper loaded: date_helper
INFO - 2016-02-12 06:10:46 --> Helper loaded: form_helper
INFO - 2016-02-12 06:10:46 --> Database Driver Class Initialized
INFO - 2016-02-12 06:10:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:10:47 --> Controller Class Initialized
INFO - 2016-02-12 06:10:47 --> Model Class Initialized
INFO - 2016-02-12 06:10:47 --> Model Class Initialized
INFO - 2016-02-12 06:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 06:10:47 --> Pagination Class Initialized
INFO - 2016-02-12 09:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 09:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 09:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 09:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 09:10:47 --> Final output sent to browser
DEBUG - 2016-02-12 09:10:47 --> Total execution time: 1.1130
INFO - 2016-02-12 06:12:27 --> Config Class Initialized
INFO - 2016-02-12 06:12:27 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:12:27 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:12:27 --> Utf8 Class Initialized
INFO - 2016-02-12 06:12:27 --> URI Class Initialized
DEBUG - 2016-02-12 06:12:27 --> No URI present. Default controller set.
INFO - 2016-02-12 06:12:27 --> Router Class Initialized
INFO - 2016-02-12 06:12:27 --> Output Class Initialized
INFO - 2016-02-12 06:12:27 --> Security Class Initialized
DEBUG - 2016-02-12 06:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:12:27 --> Input Class Initialized
INFO - 2016-02-12 06:12:27 --> Language Class Initialized
INFO - 2016-02-12 06:12:27 --> Loader Class Initialized
INFO - 2016-02-12 06:12:27 --> Helper loaded: url_helper
INFO - 2016-02-12 06:12:27 --> Helper loaded: file_helper
INFO - 2016-02-12 06:12:27 --> Helper loaded: date_helper
INFO - 2016-02-12 06:12:27 --> Helper loaded: form_helper
INFO - 2016-02-12 06:12:27 --> Database Driver Class Initialized
INFO - 2016-02-12 06:12:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:12:28 --> Controller Class Initialized
INFO - 2016-02-12 06:12:28 --> Model Class Initialized
INFO - 2016-02-12 06:12:28 --> Model Class Initialized
INFO - 2016-02-12 06:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 06:12:28 --> Pagination Class Initialized
INFO - 2016-02-12 09:12:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 09:12:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 09:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 09:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 09:12:29 --> Final output sent to browser
DEBUG - 2016-02-12 09:12:29 --> Total execution time: 1.0978
INFO - 2016-02-12 06:56:58 --> Config Class Initialized
INFO - 2016-02-12 06:56:58 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:56:58 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:56:58 --> Utf8 Class Initialized
INFO - 2016-02-12 06:56:58 --> URI Class Initialized
INFO - 2016-02-12 06:56:58 --> Router Class Initialized
INFO - 2016-02-12 06:56:58 --> Output Class Initialized
INFO - 2016-02-12 06:56:58 --> Security Class Initialized
DEBUG - 2016-02-12 06:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:56:58 --> Input Class Initialized
INFO - 2016-02-12 06:56:58 --> Language Class Initialized
INFO - 2016-02-12 06:56:58 --> Loader Class Initialized
INFO - 2016-02-12 06:56:58 --> Helper loaded: url_helper
INFO - 2016-02-12 06:56:58 --> Helper loaded: file_helper
INFO - 2016-02-12 06:56:58 --> Helper loaded: date_helper
INFO - 2016-02-12 06:56:58 --> Helper loaded: form_helper
INFO - 2016-02-12 06:56:58 --> Database Driver Class Initialized
INFO - 2016-02-12 06:56:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:56:59 --> Controller Class Initialized
INFO - 2016-02-12 06:56:59 --> Model Class Initialized
INFO - 2016-02-12 06:56:59 --> Model Class Initialized
INFO - 2016-02-12 06:56:59 --> Form Validation Class Initialized
INFO - 2016-02-12 06:56:59 --> Helper loaded: text_helper
INFO - 2016-02-12 06:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 06:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 06:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 06:56:59 --> Model Class Initialized
INFO - 2016-02-12 06:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 06:56:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 06:56:59 --> Final output sent to browser
DEBUG - 2016-02-12 06:56:59 --> Total execution time: 1.1138
INFO - 2016-02-12 06:58:47 --> Config Class Initialized
INFO - 2016-02-12 06:58:47 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:58:47 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:58:47 --> Utf8 Class Initialized
INFO - 2016-02-12 06:58:47 --> URI Class Initialized
INFO - 2016-02-12 06:58:47 --> Router Class Initialized
INFO - 2016-02-12 06:58:47 --> Output Class Initialized
INFO - 2016-02-12 06:58:47 --> Security Class Initialized
DEBUG - 2016-02-12 06:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:58:47 --> Input Class Initialized
INFO - 2016-02-12 06:58:47 --> Language Class Initialized
ERROR - 2016-02-12 06:58:47 --> 404 Page Not Found: Auth/48
INFO - 2016-02-12 06:58:50 --> Config Class Initialized
INFO - 2016-02-12 06:58:50 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:58:50 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:58:50 --> Utf8 Class Initialized
INFO - 2016-02-12 06:58:50 --> URI Class Initialized
INFO - 2016-02-12 06:58:50 --> Router Class Initialized
INFO - 2016-02-12 06:58:50 --> Output Class Initialized
INFO - 2016-02-12 06:58:50 --> Security Class Initialized
DEBUG - 2016-02-12 06:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:58:50 --> Input Class Initialized
INFO - 2016-02-12 06:58:50 --> Language Class Initialized
INFO - 2016-02-12 06:58:50 --> Loader Class Initialized
INFO - 2016-02-12 06:58:50 --> Helper loaded: url_helper
INFO - 2016-02-12 06:58:50 --> Helper loaded: file_helper
INFO - 2016-02-12 06:58:50 --> Helper loaded: date_helper
INFO - 2016-02-12 06:58:50 --> Helper loaded: form_helper
INFO - 2016-02-12 06:58:50 --> Database Driver Class Initialized
INFO - 2016-02-12 06:58:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:58:52 --> Controller Class Initialized
INFO - 2016-02-12 06:58:52 --> Model Class Initialized
INFO - 2016-02-12 06:58:52 --> Model Class Initialized
INFO - 2016-02-12 06:58:52 --> Form Validation Class Initialized
INFO - 2016-02-12 06:58:52 --> Helper loaded: text_helper
INFO - 2016-02-12 06:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 06:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 06:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 06:58:52 --> Model Class Initialized
INFO - 2016-02-12 06:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 06:58:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 06:58:52 --> Final output sent to browser
DEBUG - 2016-02-12 06:58:52 --> Total execution time: 1.1252
INFO - 2016-02-12 06:58:54 --> Config Class Initialized
INFO - 2016-02-12 06:58:54 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:58:54 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:58:54 --> Utf8 Class Initialized
INFO - 2016-02-12 06:58:54 --> URI Class Initialized
INFO - 2016-02-12 06:58:54 --> Router Class Initialized
INFO - 2016-02-12 06:58:54 --> Output Class Initialized
INFO - 2016-02-12 06:58:54 --> Security Class Initialized
DEBUG - 2016-02-12 06:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:58:54 --> Input Class Initialized
INFO - 2016-02-12 06:58:54 --> Language Class Initialized
ERROR - 2016-02-12 06:58:54 --> 404 Page Not Found: Auth/47
INFO - 2016-02-12 06:58:55 --> Config Class Initialized
INFO - 2016-02-12 06:58:55 --> Hooks Class Initialized
DEBUG - 2016-02-12 06:58:55 --> UTF-8 Support Enabled
INFO - 2016-02-12 06:58:55 --> Utf8 Class Initialized
INFO - 2016-02-12 06:58:55 --> URI Class Initialized
INFO - 2016-02-12 06:58:55 --> Router Class Initialized
INFO - 2016-02-12 06:58:55 --> Output Class Initialized
INFO - 2016-02-12 06:58:55 --> Security Class Initialized
DEBUG - 2016-02-12 06:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 06:58:55 --> Input Class Initialized
INFO - 2016-02-12 06:58:55 --> Language Class Initialized
INFO - 2016-02-12 06:58:55 --> Loader Class Initialized
INFO - 2016-02-12 06:58:55 --> Helper loaded: url_helper
INFO - 2016-02-12 06:58:55 --> Helper loaded: file_helper
INFO - 2016-02-12 06:58:55 --> Helper loaded: date_helper
INFO - 2016-02-12 06:58:55 --> Helper loaded: form_helper
INFO - 2016-02-12 06:58:55 --> Database Driver Class Initialized
INFO - 2016-02-12 06:58:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 06:58:56 --> Controller Class Initialized
INFO - 2016-02-12 06:58:56 --> Model Class Initialized
INFO - 2016-02-12 06:58:56 --> Model Class Initialized
INFO - 2016-02-12 06:58:56 --> Form Validation Class Initialized
INFO - 2016-02-12 06:58:56 --> Helper loaded: text_helper
INFO - 2016-02-12 06:58:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 06:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 06:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 06:58:57 --> Model Class Initialized
INFO - 2016-02-12 06:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 06:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 06:58:57 --> Final output sent to browser
DEBUG - 2016-02-12 06:58:57 --> Total execution time: 1.1076
INFO - 2016-02-12 07:00:58 --> Config Class Initialized
INFO - 2016-02-12 07:00:58 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:00:58 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:00:58 --> Utf8 Class Initialized
INFO - 2016-02-12 07:00:58 --> URI Class Initialized
INFO - 2016-02-12 07:00:58 --> Router Class Initialized
INFO - 2016-02-12 07:00:58 --> Output Class Initialized
INFO - 2016-02-12 07:00:58 --> Security Class Initialized
DEBUG - 2016-02-12 07:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:00:58 --> Input Class Initialized
INFO - 2016-02-12 07:00:58 --> Language Class Initialized
ERROR - 2016-02-12 07:00:58 --> 404 Page Not Found: Auth/47
INFO - 2016-02-12 07:01:02 --> Config Class Initialized
INFO - 2016-02-12 07:01:02 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:01:02 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:01:02 --> Utf8 Class Initialized
INFO - 2016-02-12 07:01:02 --> URI Class Initialized
INFO - 2016-02-12 07:01:02 --> Router Class Initialized
INFO - 2016-02-12 07:01:02 --> Output Class Initialized
INFO - 2016-02-12 07:01:02 --> Security Class Initialized
DEBUG - 2016-02-12 07:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:01:02 --> Input Class Initialized
INFO - 2016-02-12 07:01:02 --> Language Class Initialized
INFO - 2016-02-12 07:01:02 --> Loader Class Initialized
INFO - 2016-02-12 07:01:02 --> Helper loaded: url_helper
INFO - 2016-02-12 07:01:02 --> Helper loaded: file_helper
INFO - 2016-02-12 07:01:02 --> Helper loaded: date_helper
INFO - 2016-02-12 07:01:02 --> Helper loaded: form_helper
INFO - 2016-02-12 07:01:02 --> Database Driver Class Initialized
INFO - 2016-02-12 07:01:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:01:03 --> Controller Class Initialized
INFO - 2016-02-12 07:01:03 --> Model Class Initialized
INFO - 2016-02-12 07:01:03 --> Model Class Initialized
INFO - 2016-02-12 07:01:03 --> Form Validation Class Initialized
INFO - 2016-02-12 07:01:03 --> Helper loaded: text_helper
INFO - 2016-02-12 07:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 07:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 07:01:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
ERROR - 2016-02-12 07:01:03 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 193
INFO - 2016-02-12 07:01:30 --> Config Class Initialized
INFO - 2016-02-12 07:01:30 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:01:30 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:01:30 --> Utf8 Class Initialized
INFO - 2016-02-12 07:01:30 --> URI Class Initialized
INFO - 2016-02-12 07:01:30 --> Router Class Initialized
INFO - 2016-02-12 07:01:30 --> Output Class Initialized
INFO - 2016-02-12 07:01:30 --> Security Class Initialized
DEBUG - 2016-02-12 07:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:01:30 --> Input Class Initialized
INFO - 2016-02-12 07:01:30 --> Language Class Initialized
INFO - 2016-02-12 07:01:30 --> Loader Class Initialized
INFO - 2016-02-12 07:01:30 --> Helper loaded: url_helper
INFO - 2016-02-12 07:01:30 --> Helper loaded: file_helper
INFO - 2016-02-12 07:01:30 --> Helper loaded: date_helper
INFO - 2016-02-12 07:01:30 --> Helper loaded: form_helper
INFO - 2016-02-12 07:01:30 --> Database Driver Class Initialized
INFO - 2016-02-12 07:01:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:01:31 --> Controller Class Initialized
INFO - 2016-02-12 07:01:31 --> Model Class Initialized
INFO - 2016-02-12 07:01:31 --> Model Class Initialized
INFO - 2016-02-12 07:01:31 --> Form Validation Class Initialized
INFO - 2016-02-12 07:01:31 --> Helper loaded: text_helper
INFO - 2016-02-12 07:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 07:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 07:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 07:01:31 --> Model Class Initialized
INFO - 2016-02-12 07:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 07:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 07:01:31 --> Final output sent to browser
DEBUG - 2016-02-12 07:01:31 --> Total execution time: 1.1174
INFO - 2016-02-12 07:01:33 --> Config Class Initialized
INFO - 2016-02-12 07:01:33 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:01:33 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:01:33 --> Utf8 Class Initialized
INFO - 2016-02-12 07:01:33 --> URI Class Initialized
INFO - 2016-02-12 07:01:33 --> Router Class Initialized
INFO - 2016-02-12 07:01:33 --> Output Class Initialized
INFO - 2016-02-12 07:01:33 --> Security Class Initialized
DEBUG - 2016-02-12 07:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:01:33 --> Input Class Initialized
INFO - 2016-02-12 07:01:33 --> Language Class Initialized
ERROR - 2016-02-12 07:01:33 --> 404 Page Not Found: Auth/47
INFO - 2016-02-12 07:01:34 --> Config Class Initialized
INFO - 2016-02-12 07:01:34 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:01:34 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:01:34 --> Utf8 Class Initialized
INFO - 2016-02-12 07:01:34 --> URI Class Initialized
INFO - 2016-02-12 07:01:34 --> Router Class Initialized
INFO - 2016-02-12 07:01:34 --> Output Class Initialized
INFO - 2016-02-12 07:01:34 --> Security Class Initialized
DEBUG - 2016-02-12 07:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:01:34 --> Input Class Initialized
INFO - 2016-02-12 07:01:34 --> Language Class Initialized
INFO - 2016-02-12 07:01:34 --> Loader Class Initialized
INFO - 2016-02-12 07:01:34 --> Helper loaded: url_helper
INFO - 2016-02-12 07:01:34 --> Helper loaded: file_helper
INFO - 2016-02-12 07:01:34 --> Helper loaded: date_helper
INFO - 2016-02-12 07:01:34 --> Helper loaded: form_helper
INFO - 2016-02-12 07:01:34 --> Database Driver Class Initialized
INFO - 2016-02-12 07:01:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:01:35 --> Controller Class Initialized
INFO - 2016-02-12 07:01:35 --> Model Class Initialized
INFO - 2016-02-12 07:01:35 --> Model Class Initialized
INFO - 2016-02-12 07:01:35 --> Form Validation Class Initialized
INFO - 2016-02-12 07:01:35 --> Helper loaded: text_helper
INFO - 2016-02-12 07:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 07:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 07:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 07:01:35 --> Model Class Initialized
INFO - 2016-02-12 07:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 07:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 07:01:35 --> Final output sent to browser
DEBUG - 2016-02-12 07:01:35 --> Total execution time: 1.0974
INFO - 2016-02-12 07:03:14 --> Config Class Initialized
INFO - 2016-02-12 07:03:14 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:03:14 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:03:14 --> Utf8 Class Initialized
INFO - 2016-02-12 07:03:14 --> URI Class Initialized
INFO - 2016-02-12 07:03:14 --> Router Class Initialized
INFO - 2016-02-12 07:03:14 --> Output Class Initialized
INFO - 2016-02-12 07:03:14 --> Security Class Initialized
DEBUG - 2016-02-12 07:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:03:14 --> Input Class Initialized
INFO - 2016-02-12 07:03:14 --> Language Class Initialized
INFO - 2016-02-12 07:03:14 --> Loader Class Initialized
INFO - 2016-02-12 07:03:14 --> Helper loaded: url_helper
INFO - 2016-02-12 07:03:14 --> Helper loaded: file_helper
INFO - 2016-02-12 07:03:14 --> Helper loaded: date_helper
INFO - 2016-02-12 07:03:14 --> Helper loaded: form_helper
INFO - 2016-02-12 07:03:14 --> Database Driver Class Initialized
INFO - 2016-02-12 07:03:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:03:15 --> Controller Class Initialized
INFO - 2016-02-12 07:03:15 --> Model Class Initialized
INFO - 2016-02-12 07:03:15 --> Model Class Initialized
INFO - 2016-02-12 07:03:15 --> Form Validation Class Initialized
INFO - 2016-02-12 07:03:15 --> Helper loaded: text_helper
INFO - 2016-02-12 07:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 07:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 07:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 07:03:15 --> Model Class Initialized
INFO - 2016-02-12 07:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 07:03:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 07:03:15 --> Final output sent to browser
DEBUG - 2016-02-12 07:03:15 --> Total execution time: 1.1231
INFO - 2016-02-12 07:03:16 --> Config Class Initialized
INFO - 2016-02-12 07:03:16 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:03:16 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:03:16 --> Utf8 Class Initialized
INFO - 2016-02-12 07:03:16 --> URI Class Initialized
INFO - 2016-02-12 07:03:16 --> Router Class Initialized
INFO - 2016-02-12 07:03:16 --> Output Class Initialized
INFO - 2016-02-12 07:03:16 --> Security Class Initialized
DEBUG - 2016-02-12 07:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:03:16 --> Input Class Initialized
INFO - 2016-02-12 07:03:16 --> Language Class Initialized
ERROR - 2016-02-12 07:03:16 --> 404 Page Not Found: Auth/%3C
INFO - 2016-02-12 07:03:25 --> Config Class Initialized
INFO - 2016-02-12 07:03:25 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:03:25 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:03:25 --> Utf8 Class Initialized
INFO - 2016-02-12 07:03:25 --> URI Class Initialized
INFO - 2016-02-12 07:03:25 --> Router Class Initialized
INFO - 2016-02-12 07:03:25 --> Output Class Initialized
INFO - 2016-02-12 07:03:25 --> Security Class Initialized
DEBUG - 2016-02-12 07:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:03:25 --> Input Class Initialized
INFO - 2016-02-12 07:03:25 --> Language Class Initialized
ERROR - 2016-02-12 07:03:25 --> 404 Page Not Found: Auth/%3C
INFO - 2016-02-12 07:03:26 --> Config Class Initialized
INFO - 2016-02-12 07:03:26 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:03:26 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:03:26 --> Utf8 Class Initialized
INFO - 2016-02-12 07:03:26 --> URI Class Initialized
INFO - 2016-02-12 07:03:26 --> Router Class Initialized
INFO - 2016-02-12 07:03:26 --> Output Class Initialized
INFO - 2016-02-12 07:03:26 --> Security Class Initialized
DEBUG - 2016-02-12 07:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:03:26 --> Input Class Initialized
INFO - 2016-02-12 07:03:26 --> Language Class Initialized
INFO - 2016-02-12 07:03:26 --> Loader Class Initialized
INFO - 2016-02-12 07:03:26 --> Helper loaded: url_helper
INFO - 2016-02-12 07:03:26 --> Helper loaded: file_helper
INFO - 2016-02-12 07:03:26 --> Helper loaded: date_helper
INFO - 2016-02-12 07:03:26 --> Helper loaded: form_helper
INFO - 2016-02-12 07:03:26 --> Database Driver Class Initialized
INFO - 2016-02-12 07:03:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:03:27 --> Controller Class Initialized
INFO - 2016-02-12 07:03:27 --> Model Class Initialized
INFO - 2016-02-12 07:03:27 --> Model Class Initialized
INFO - 2016-02-12 07:03:27 --> Form Validation Class Initialized
INFO - 2016-02-12 07:03:27 --> Helper loaded: text_helper
INFO - 2016-02-12 07:03:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 07:03:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 07:03:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 07:03:27 --> Model Class Initialized
INFO - 2016-02-12 07:03:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 07:03:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 07:03:27 --> Final output sent to browser
DEBUG - 2016-02-12 07:03:27 --> Total execution time: 1.1453
INFO - 2016-02-12 07:03:29 --> Config Class Initialized
INFO - 2016-02-12 07:03:29 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:03:29 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:03:29 --> Utf8 Class Initialized
INFO - 2016-02-12 07:03:29 --> URI Class Initialized
INFO - 2016-02-12 07:03:29 --> Router Class Initialized
INFO - 2016-02-12 07:03:29 --> Output Class Initialized
INFO - 2016-02-12 07:03:29 --> Security Class Initialized
DEBUG - 2016-02-12 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:03:29 --> Input Class Initialized
INFO - 2016-02-12 07:03:29 --> Language Class Initialized
INFO - 2016-02-12 07:03:29 --> Loader Class Initialized
INFO - 2016-02-12 07:03:29 --> Helper loaded: url_helper
INFO - 2016-02-12 07:03:29 --> Helper loaded: file_helper
INFO - 2016-02-12 07:03:29 --> Helper loaded: date_helper
INFO - 2016-02-12 07:03:29 --> Helper loaded: form_helper
INFO - 2016-02-12 07:03:29 --> Database Driver Class Initialized
INFO - 2016-02-12 07:03:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:03:30 --> Controller Class Initialized
INFO - 2016-02-12 07:03:30 --> Model Class Initialized
INFO - 2016-02-12 07:03:30 --> Model Class Initialized
INFO - 2016-02-12 07:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:03:30 --> Pagination Class Initialized
INFO - 2016-02-12 10:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:03:30 --> Helper loaded: text_helper
INFO - 2016-02-12 10:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:03:30 --> Final output sent to browser
DEBUG - 2016-02-12 10:03:30 --> Total execution time: 1.1849
INFO - 2016-02-12 07:03:32 --> Config Class Initialized
INFO - 2016-02-12 07:03:32 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:03:32 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:03:32 --> Utf8 Class Initialized
INFO - 2016-02-12 07:03:32 --> URI Class Initialized
INFO - 2016-02-12 07:03:32 --> Router Class Initialized
INFO - 2016-02-12 07:03:32 --> Output Class Initialized
INFO - 2016-02-12 07:03:32 --> Security Class Initialized
DEBUG - 2016-02-12 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:03:32 --> Input Class Initialized
INFO - 2016-02-12 07:03:32 --> Language Class Initialized
INFO - 2016-02-12 07:03:32 --> Loader Class Initialized
INFO - 2016-02-12 07:03:32 --> Helper loaded: url_helper
INFO - 2016-02-12 07:03:32 --> Helper loaded: file_helper
INFO - 2016-02-12 07:03:32 --> Helper loaded: date_helper
INFO - 2016-02-12 07:03:32 --> Helper loaded: form_helper
INFO - 2016-02-12 07:03:32 --> Database Driver Class Initialized
INFO - 2016-02-12 07:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:03:33 --> Controller Class Initialized
INFO - 2016-02-12 07:03:33 --> Model Class Initialized
INFO - 2016-02-12 07:03:33 --> Model Class Initialized
INFO - 2016-02-12 07:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:03:33 --> Pagination Class Initialized
INFO - 2016-02-12 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:03:33 --> Helper loaded: text_helper
INFO - 2016-02-12 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:03:33 --> Final output sent to browser
DEBUG - 2016-02-12 10:03:33 --> Total execution time: 1.1810
INFO - 2016-02-12 07:03:35 --> Config Class Initialized
INFO - 2016-02-12 07:03:35 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:03:35 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:03:35 --> Utf8 Class Initialized
INFO - 2016-02-12 07:03:35 --> URI Class Initialized
INFO - 2016-02-12 07:03:35 --> Router Class Initialized
INFO - 2016-02-12 07:03:35 --> Output Class Initialized
INFO - 2016-02-12 07:03:35 --> Security Class Initialized
DEBUG - 2016-02-12 07:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:03:35 --> Input Class Initialized
INFO - 2016-02-12 07:03:35 --> Language Class Initialized
INFO - 2016-02-12 07:03:35 --> Loader Class Initialized
INFO - 2016-02-12 07:03:35 --> Helper loaded: url_helper
INFO - 2016-02-12 07:03:35 --> Helper loaded: file_helper
INFO - 2016-02-12 07:03:35 --> Helper loaded: date_helper
INFO - 2016-02-12 07:03:35 --> Helper loaded: form_helper
INFO - 2016-02-12 07:03:35 --> Database Driver Class Initialized
INFO - 2016-02-12 07:03:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:03:36 --> Controller Class Initialized
INFO - 2016-02-12 07:03:36 --> Model Class Initialized
INFO - 2016-02-12 07:03:36 --> Model Class Initialized
INFO - 2016-02-12 07:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:03:36 --> Pagination Class Initialized
INFO - 2016-02-12 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:03:36 --> Helper loaded: text_helper
INFO - 2016-02-12 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:03:36 --> Final output sent to browser
DEBUG - 2016-02-12 10:03:36 --> Total execution time: 1.2832
INFO - 2016-02-12 07:03:38 --> Config Class Initialized
INFO - 2016-02-12 07:03:38 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:03:38 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:03:38 --> Utf8 Class Initialized
INFO - 2016-02-12 07:03:38 --> URI Class Initialized
INFO - 2016-02-12 07:03:38 --> Router Class Initialized
INFO - 2016-02-12 07:03:38 --> Output Class Initialized
INFO - 2016-02-12 07:03:38 --> Security Class Initialized
DEBUG - 2016-02-12 07:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:03:38 --> Input Class Initialized
INFO - 2016-02-12 07:03:38 --> Language Class Initialized
INFO - 2016-02-12 07:03:38 --> Loader Class Initialized
INFO - 2016-02-12 07:03:38 --> Helper loaded: url_helper
INFO - 2016-02-12 07:03:38 --> Helper loaded: file_helper
INFO - 2016-02-12 07:03:38 --> Helper loaded: date_helper
INFO - 2016-02-12 07:03:38 --> Helper loaded: form_helper
INFO - 2016-02-12 07:03:38 --> Database Driver Class Initialized
INFO - 2016-02-12 07:03:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:03:39 --> Controller Class Initialized
INFO - 2016-02-12 07:03:39 --> Model Class Initialized
INFO - 2016-02-12 07:03:39 --> Model Class Initialized
INFO - 2016-02-12 07:03:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:03:39 --> Pagination Class Initialized
INFO - 2016-02-12 10:03:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:03:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:03:39 --> Helper loaded: text_helper
INFO - 2016-02-12 10:03:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:03:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:03:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:03:39 --> Final output sent to browser
DEBUG - 2016-02-12 10:03:39 --> Total execution time: 1.1375
INFO - 2016-02-12 07:04:02 --> Config Class Initialized
INFO - 2016-02-12 07:04:02 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:04:02 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:04:02 --> Utf8 Class Initialized
INFO - 2016-02-12 07:04:02 --> URI Class Initialized
INFO - 2016-02-12 07:04:02 --> Router Class Initialized
INFO - 2016-02-12 07:04:02 --> Output Class Initialized
INFO - 2016-02-12 07:04:02 --> Security Class Initialized
DEBUG - 2016-02-12 07:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:04:02 --> Input Class Initialized
INFO - 2016-02-12 07:04:02 --> Language Class Initialized
INFO - 2016-02-12 07:04:02 --> Loader Class Initialized
INFO - 2016-02-12 07:04:02 --> Helper loaded: url_helper
INFO - 2016-02-12 07:04:02 --> Helper loaded: file_helper
INFO - 2016-02-12 07:04:02 --> Helper loaded: date_helper
INFO - 2016-02-12 07:04:02 --> Helper loaded: form_helper
INFO - 2016-02-12 07:04:02 --> Database Driver Class Initialized
INFO - 2016-02-12 07:04:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:04:03 --> Controller Class Initialized
INFO - 2016-02-12 07:04:03 --> Model Class Initialized
INFO - 2016-02-12 07:04:03 --> Model Class Initialized
INFO - 2016-02-12 07:04:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:04:03 --> Pagination Class Initialized
INFO - 2016-02-12 10:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:04:03 --> Helper loaded: text_helper
INFO - 2016-02-12 10:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:04:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:04:03 --> Final output sent to browser
DEBUG - 2016-02-12 10:04:03 --> Total execution time: 1.1706
INFO - 2016-02-12 07:04:06 --> Config Class Initialized
INFO - 2016-02-12 07:04:06 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:04:06 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:04:06 --> Utf8 Class Initialized
INFO - 2016-02-12 07:04:06 --> URI Class Initialized
DEBUG - 2016-02-12 07:04:06 --> No URI present. Default controller set.
INFO - 2016-02-12 07:04:06 --> Router Class Initialized
INFO - 2016-02-12 07:04:06 --> Output Class Initialized
INFO - 2016-02-12 07:04:06 --> Security Class Initialized
DEBUG - 2016-02-12 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:04:06 --> Input Class Initialized
INFO - 2016-02-12 07:04:06 --> Language Class Initialized
INFO - 2016-02-12 07:04:06 --> Loader Class Initialized
INFO - 2016-02-12 07:04:06 --> Helper loaded: url_helper
INFO - 2016-02-12 07:04:06 --> Helper loaded: file_helper
INFO - 2016-02-12 07:04:06 --> Helper loaded: date_helper
INFO - 2016-02-12 07:04:06 --> Helper loaded: form_helper
INFO - 2016-02-12 07:04:06 --> Database Driver Class Initialized
INFO - 2016-02-12 07:04:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:04:07 --> Controller Class Initialized
INFO - 2016-02-12 07:04:07 --> Model Class Initialized
INFO - 2016-02-12 07:04:07 --> Model Class Initialized
INFO - 2016-02-12 07:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:04:07 --> Pagination Class Initialized
INFO - 2016-02-12 10:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:04:07 --> Final output sent to browser
DEBUG - 2016-02-12 10:04:07 --> Total execution time: 1.0848
INFO - 2016-02-12 07:06:58 --> Config Class Initialized
INFO - 2016-02-12 07:06:58 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:06:58 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:06:58 --> Utf8 Class Initialized
INFO - 2016-02-12 07:06:58 --> URI Class Initialized
DEBUG - 2016-02-12 07:06:58 --> No URI present. Default controller set.
INFO - 2016-02-12 07:06:58 --> Router Class Initialized
INFO - 2016-02-12 07:06:58 --> Output Class Initialized
INFO - 2016-02-12 07:06:58 --> Security Class Initialized
DEBUG - 2016-02-12 07:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:06:58 --> Input Class Initialized
INFO - 2016-02-12 07:06:58 --> Language Class Initialized
INFO - 2016-02-12 07:06:58 --> Loader Class Initialized
INFO - 2016-02-12 07:06:58 --> Helper loaded: url_helper
INFO - 2016-02-12 07:06:58 --> Helper loaded: file_helper
INFO - 2016-02-12 07:06:58 --> Helper loaded: date_helper
INFO - 2016-02-12 07:06:58 --> Helper loaded: form_helper
INFO - 2016-02-12 07:06:58 --> Database Driver Class Initialized
INFO - 2016-02-12 07:06:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:06:59 --> Controller Class Initialized
INFO - 2016-02-12 07:06:59 --> Model Class Initialized
INFO - 2016-02-12 07:06:59 --> Model Class Initialized
INFO - 2016-02-12 07:06:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:06:59 --> Pagination Class Initialized
INFO - 2016-02-12 10:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-12 10:06:59 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 80
INFO - 2016-02-12 10:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:06:59 --> Final output sent to browser
DEBUG - 2016-02-12 10:06:59 --> Total execution time: 1.1677
INFO - 2016-02-12 07:09:26 --> Config Class Initialized
INFO - 2016-02-12 07:09:26 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:09:26 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:09:26 --> Utf8 Class Initialized
INFO - 2016-02-12 07:09:26 --> URI Class Initialized
DEBUG - 2016-02-12 07:09:26 --> No URI present. Default controller set.
INFO - 2016-02-12 07:09:26 --> Router Class Initialized
INFO - 2016-02-12 07:09:26 --> Output Class Initialized
INFO - 2016-02-12 07:09:26 --> Security Class Initialized
DEBUG - 2016-02-12 07:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:09:26 --> Input Class Initialized
INFO - 2016-02-12 07:09:26 --> Language Class Initialized
INFO - 2016-02-12 07:09:26 --> Loader Class Initialized
INFO - 2016-02-12 07:09:26 --> Helper loaded: url_helper
INFO - 2016-02-12 07:09:26 --> Helper loaded: file_helper
INFO - 2016-02-12 07:09:26 --> Helper loaded: date_helper
INFO - 2016-02-12 07:09:26 --> Helper loaded: form_helper
INFO - 2016-02-12 07:09:26 --> Database Driver Class Initialized
INFO - 2016-02-12 07:09:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:09:27 --> Controller Class Initialized
INFO - 2016-02-12 07:09:27 --> Model Class Initialized
INFO - 2016-02-12 07:09:27 --> Model Class Initialized
INFO - 2016-02-12 07:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:09:27 --> Pagination Class Initialized
INFO - 2016-02-12 10:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-12 10:09:27 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 80
INFO - 2016-02-12 10:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:09:27 --> Final output sent to browser
DEBUG - 2016-02-12 10:09:27 --> Total execution time: 1.1173
INFO - 2016-02-12 07:20:58 --> Config Class Initialized
INFO - 2016-02-12 07:20:58 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:20:58 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:20:58 --> Utf8 Class Initialized
INFO - 2016-02-12 07:20:58 --> URI Class Initialized
INFO - 2016-02-12 07:20:58 --> Router Class Initialized
INFO - 2016-02-12 07:20:58 --> Output Class Initialized
INFO - 2016-02-12 07:20:58 --> Security Class Initialized
DEBUG - 2016-02-12 07:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:20:58 --> Input Class Initialized
INFO - 2016-02-12 07:20:58 --> Language Class Initialized
INFO - 2016-02-12 07:20:58 --> Loader Class Initialized
INFO - 2016-02-12 07:20:58 --> Helper loaded: url_helper
INFO - 2016-02-12 07:20:58 --> Helper loaded: file_helper
INFO - 2016-02-12 07:20:58 --> Helper loaded: date_helper
INFO - 2016-02-12 07:20:58 --> Helper loaded: form_helper
INFO - 2016-02-12 07:20:58 --> Database Driver Class Initialized
INFO - 2016-02-12 07:20:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:20:59 --> Controller Class Initialized
INFO - 2016-02-12 07:20:59 --> Model Class Initialized
INFO - 2016-02-12 07:20:59 --> Model Class Initialized
INFO - 2016-02-12 07:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:20:59 --> Pagination Class Initialized
INFO - 2016-02-12 10:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-12 10:20:59 --> Severity: Notice --> Undefined variable: returnURL C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 80
INFO - 2016-02-12 10:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:20:59 --> Helper loaded: text_helper
INFO - 2016-02-12 10:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
ERROR - 2016-02-12 10:20:59 --> Severity: Notice --> Undefined property: Jboard::$agent C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 142
ERROR - 2016-02-12 10:20:59 --> Severity: Error --> Call to a member function is_referral() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 142
INFO - 2016-02-12 07:28:20 --> Config Class Initialized
INFO - 2016-02-12 07:28:20 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:28:20 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:28:20 --> Utf8 Class Initialized
INFO - 2016-02-12 07:28:20 --> URI Class Initialized
INFO - 2016-02-12 07:28:20 --> Router Class Initialized
INFO - 2016-02-12 07:28:20 --> Output Class Initialized
INFO - 2016-02-12 07:28:20 --> Security Class Initialized
DEBUG - 2016-02-12 07:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:28:20 --> Input Class Initialized
INFO - 2016-02-12 07:28:20 --> Language Class Initialized
INFO - 2016-02-12 07:28:20 --> Loader Class Initialized
INFO - 2016-02-12 07:28:20 --> Helper loaded: url_helper
INFO - 2016-02-12 07:28:20 --> Helper loaded: file_helper
INFO - 2016-02-12 07:28:20 --> Helper loaded: date_helper
INFO - 2016-02-12 07:28:20 --> Helper loaded: form_helper
INFO - 2016-02-12 07:28:20 --> Database Driver Class Initialized
INFO - 2016-02-12 07:28:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:28:21 --> Controller Class Initialized
INFO - 2016-02-12 07:28:21 --> Model Class Initialized
INFO - 2016-02-12 07:28:21 --> Model Class Initialized
INFO - 2016-02-12 07:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:28:21 --> Pagination Class Initialized
INFO - 2016-02-12 10:28:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-12 10:28:21 --> Severity: Notice --> Undefined property: CI_Loader::$agent C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 81
ERROR - 2016-02-12 10:28:21 --> Severity: Error --> Call to a member function referrer() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 81
INFO - 2016-02-12 07:28:45 --> Config Class Initialized
INFO - 2016-02-12 07:28:45 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:28:45 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:28:45 --> Utf8 Class Initialized
INFO - 2016-02-12 07:28:45 --> URI Class Initialized
INFO - 2016-02-12 07:28:45 --> Router Class Initialized
INFO - 2016-02-12 07:28:45 --> Output Class Initialized
INFO - 2016-02-12 07:28:45 --> Security Class Initialized
DEBUG - 2016-02-12 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:28:45 --> Input Class Initialized
INFO - 2016-02-12 07:28:45 --> Language Class Initialized
INFO - 2016-02-12 07:28:45 --> Loader Class Initialized
INFO - 2016-02-12 07:28:45 --> Helper loaded: url_helper
INFO - 2016-02-12 07:28:45 --> Helper loaded: file_helper
INFO - 2016-02-12 07:28:45 --> Helper loaded: date_helper
INFO - 2016-02-12 07:28:45 --> Helper loaded: form_helper
INFO - 2016-02-12 07:28:45 --> Database Driver Class Initialized
INFO - 2016-02-12 07:28:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:28:47 --> Controller Class Initialized
INFO - 2016-02-12 07:28:47 --> Model Class Initialized
INFO - 2016-02-12 07:28:47 --> Model Class Initialized
INFO - 2016-02-12 07:28:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:28:47 --> Pagination Class Initialized
INFO - 2016-02-12 10:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:28:47 --> Helper loaded: text_helper
INFO - 2016-02-12 10:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:28:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
ERROR - 2016-02-12 10:28:47 --> Severity: Notice --> Undefined property: Jboard::$agent C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 142
ERROR - 2016-02-12 10:28:47 --> Severity: Error --> Call to a member function is_referral() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 142
INFO - 2016-02-12 07:29:01 --> Config Class Initialized
INFO - 2016-02-12 07:29:01 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:29:01 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:29:01 --> Utf8 Class Initialized
INFO - 2016-02-12 07:29:01 --> URI Class Initialized
INFO - 2016-02-12 07:29:01 --> Router Class Initialized
INFO - 2016-02-12 07:29:01 --> Output Class Initialized
INFO - 2016-02-12 07:29:01 --> Security Class Initialized
DEBUG - 2016-02-12 07:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:29:01 --> Input Class Initialized
INFO - 2016-02-12 07:29:02 --> Language Class Initialized
INFO - 2016-02-12 07:29:02 --> Loader Class Initialized
INFO - 2016-02-12 07:29:02 --> Helper loaded: url_helper
INFO - 2016-02-12 07:29:02 --> Helper loaded: file_helper
INFO - 2016-02-12 07:29:02 --> Helper loaded: date_helper
INFO - 2016-02-12 07:29:02 --> Helper loaded: form_helper
INFO - 2016-02-12 07:29:02 --> Database Driver Class Initialized
INFO - 2016-02-12 07:29:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:29:03 --> Controller Class Initialized
INFO - 2016-02-12 07:29:03 --> Model Class Initialized
INFO - 2016-02-12 07:29:03 --> Model Class Initialized
INFO - 2016-02-12 07:29:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:29:03 --> Pagination Class Initialized
INFO - 2016-02-12 10:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:29:03 --> Helper loaded: text_helper
INFO - 2016-02-12 10:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:29:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:29:03 --> Final output sent to browser
DEBUG - 2016-02-12 10:29:03 --> Total execution time: 1.1465
INFO - 2016-02-12 07:32:11 --> Config Class Initialized
INFO - 2016-02-12 07:32:11 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:32:11 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:32:11 --> Utf8 Class Initialized
INFO - 2016-02-12 07:32:11 --> URI Class Initialized
INFO - 2016-02-12 07:32:11 --> Router Class Initialized
INFO - 2016-02-12 07:32:11 --> Output Class Initialized
INFO - 2016-02-12 07:32:11 --> Security Class Initialized
DEBUG - 2016-02-12 07:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:32:11 --> Input Class Initialized
INFO - 2016-02-12 07:32:11 --> Language Class Initialized
INFO - 2016-02-12 07:32:11 --> Loader Class Initialized
INFO - 2016-02-12 07:32:11 --> Helper loaded: url_helper
INFO - 2016-02-12 07:32:11 --> Helper loaded: file_helper
INFO - 2016-02-12 07:32:11 --> Helper loaded: date_helper
INFO - 2016-02-12 07:32:11 --> Helper loaded: form_helper
INFO - 2016-02-12 07:32:11 --> Database Driver Class Initialized
INFO - 2016-02-12 07:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:32:12 --> Controller Class Initialized
INFO - 2016-02-12 07:32:12 --> Model Class Initialized
INFO - 2016-02-12 07:32:12 --> Model Class Initialized
INFO - 2016-02-12 07:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:32:12 --> Pagination Class Initialized
INFO - 2016-02-12 10:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-12 10:32:12 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 94
INFO - 2016-02-12 07:32:50 --> Config Class Initialized
INFO - 2016-02-12 07:32:50 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:32:50 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:32:50 --> Utf8 Class Initialized
INFO - 2016-02-12 07:32:50 --> URI Class Initialized
INFO - 2016-02-12 07:32:50 --> Router Class Initialized
INFO - 2016-02-12 07:32:50 --> Output Class Initialized
INFO - 2016-02-12 07:32:50 --> Security Class Initialized
DEBUG - 2016-02-12 07:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:32:50 --> Input Class Initialized
INFO - 2016-02-12 07:32:50 --> Language Class Initialized
INFO - 2016-02-12 07:32:50 --> Loader Class Initialized
INFO - 2016-02-12 07:32:50 --> Helper loaded: url_helper
INFO - 2016-02-12 07:32:50 --> Helper loaded: file_helper
INFO - 2016-02-12 07:32:50 --> Helper loaded: date_helper
INFO - 2016-02-12 07:32:50 --> Helper loaded: form_helper
INFO - 2016-02-12 07:32:50 --> Database Driver Class Initialized
INFO - 2016-02-12 07:32:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:32:51 --> Controller Class Initialized
INFO - 2016-02-12 07:32:51 --> Model Class Initialized
INFO - 2016-02-12 07:32:51 --> Model Class Initialized
INFO - 2016-02-12 07:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:32:51 --> Pagination Class Initialized
INFO - 2016-02-12 10:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:32:51 --> Helper loaded: text_helper
INFO - 2016-02-12 10:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:32:51 --> Final output sent to browser
DEBUG - 2016-02-12 10:32:51 --> Total execution time: 1.2026
INFO - 2016-02-12 07:32:53 --> Config Class Initialized
INFO - 2016-02-12 07:32:53 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:32:53 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:32:53 --> Utf8 Class Initialized
INFO - 2016-02-12 07:32:53 --> URI Class Initialized
DEBUG - 2016-02-12 07:32:53 --> No URI present. Default controller set.
INFO - 2016-02-12 07:32:53 --> Router Class Initialized
INFO - 2016-02-12 07:32:53 --> Output Class Initialized
INFO - 2016-02-12 07:32:53 --> Security Class Initialized
DEBUG - 2016-02-12 07:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:32:53 --> Input Class Initialized
INFO - 2016-02-12 07:32:53 --> Language Class Initialized
INFO - 2016-02-12 07:32:53 --> Loader Class Initialized
INFO - 2016-02-12 07:32:53 --> Helper loaded: url_helper
INFO - 2016-02-12 07:32:53 --> Helper loaded: file_helper
INFO - 2016-02-12 07:32:53 --> Helper loaded: date_helper
INFO - 2016-02-12 07:32:53 --> Helper loaded: form_helper
INFO - 2016-02-12 07:32:53 --> Database Driver Class Initialized
INFO - 2016-02-12 07:32:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:32:54 --> Controller Class Initialized
INFO - 2016-02-12 07:32:54 --> Model Class Initialized
INFO - 2016-02-12 07:32:54 --> Model Class Initialized
INFO - 2016-02-12 07:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:32:54 --> Pagination Class Initialized
INFO - 2016-02-12 10:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:32:54 --> Final output sent to browser
DEBUG - 2016-02-12 10:32:54 --> Total execution time: 1.0988
INFO - 2016-02-12 07:34:05 --> Config Class Initialized
INFO - 2016-02-12 07:34:05 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:34:05 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:34:05 --> Utf8 Class Initialized
INFO - 2016-02-12 07:34:05 --> URI Class Initialized
DEBUG - 2016-02-12 07:34:05 --> No URI present. Default controller set.
INFO - 2016-02-12 07:34:05 --> Router Class Initialized
INFO - 2016-02-12 07:34:05 --> Output Class Initialized
INFO - 2016-02-12 07:34:05 --> Security Class Initialized
DEBUG - 2016-02-12 07:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:34:05 --> Input Class Initialized
INFO - 2016-02-12 07:34:05 --> Language Class Initialized
INFO - 2016-02-12 07:34:05 --> Loader Class Initialized
INFO - 2016-02-12 07:34:05 --> Helper loaded: url_helper
INFO - 2016-02-12 07:34:05 --> Helper loaded: file_helper
INFO - 2016-02-12 07:34:05 --> Helper loaded: date_helper
INFO - 2016-02-12 07:34:05 --> Helper loaded: form_helper
INFO - 2016-02-12 07:34:05 --> Database Driver Class Initialized
INFO - 2016-02-12 07:34:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:34:07 --> Controller Class Initialized
INFO - 2016-02-12 07:34:07 --> Model Class Initialized
INFO - 2016-02-12 07:34:07 --> Model Class Initialized
INFO - 2016-02-12 07:34:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:34:07 --> Pagination Class Initialized
INFO - 2016-02-12 10:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:34:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:34:07 --> Final output sent to browser
DEBUG - 2016-02-12 10:34:07 --> Total execution time: 1.0827
INFO - 2016-02-12 07:35:27 --> Config Class Initialized
INFO - 2016-02-12 07:35:27 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:35:27 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:35:27 --> Utf8 Class Initialized
INFO - 2016-02-12 07:35:27 --> URI Class Initialized
INFO - 2016-02-12 07:35:27 --> Router Class Initialized
INFO - 2016-02-12 07:35:27 --> Output Class Initialized
INFO - 2016-02-12 07:35:27 --> Security Class Initialized
DEBUG - 2016-02-12 07:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:35:27 --> Input Class Initialized
INFO - 2016-02-12 07:35:27 --> Language Class Initialized
ERROR - 2016-02-12 07:35:27 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
INFO - 2016-02-12 07:44:14 --> Config Class Initialized
INFO - 2016-02-12 07:44:14 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:44:14 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:44:14 --> Utf8 Class Initialized
INFO - 2016-02-12 07:44:14 --> URI Class Initialized
INFO - 2016-02-12 07:44:14 --> Router Class Initialized
INFO - 2016-02-12 07:44:14 --> Output Class Initialized
INFO - 2016-02-12 07:44:14 --> Security Class Initialized
DEBUG - 2016-02-12 07:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:44:14 --> Input Class Initialized
INFO - 2016-02-12 07:44:14 --> Language Class Initialized
ERROR - 2016-02-12 07:44:14 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
INFO - 2016-02-12 07:44:18 --> Config Class Initialized
INFO - 2016-02-12 07:44:18 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:44:18 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:44:18 --> Utf8 Class Initialized
INFO - 2016-02-12 07:44:18 --> URI Class Initialized
INFO - 2016-02-12 07:44:18 --> Router Class Initialized
INFO - 2016-02-12 07:44:18 --> Output Class Initialized
INFO - 2016-02-12 07:44:18 --> Security Class Initialized
DEBUG - 2016-02-12 07:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:44:18 --> Input Class Initialized
INFO - 2016-02-12 07:44:18 --> Language Class Initialized
ERROR - 2016-02-12 07:44:18 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 99
INFO - 2016-02-12 07:44:31 --> Config Class Initialized
INFO - 2016-02-12 07:44:31 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:44:31 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:44:31 --> Utf8 Class Initialized
INFO - 2016-02-12 07:44:31 --> URI Class Initialized
INFO - 2016-02-12 07:44:31 --> Router Class Initialized
INFO - 2016-02-12 07:44:31 --> Output Class Initialized
INFO - 2016-02-12 07:44:31 --> Security Class Initialized
DEBUG - 2016-02-12 07:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:44:31 --> Input Class Initialized
INFO - 2016-02-12 07:44:31 --> Language Class Initialized
INFO - 2016-02-12 07:44:31 --> Loader Class Initialized
INFO - 2016-02-12 07:44:31 --> Helper loaded: url_helper
INFO - 2016-02-12 07:44:31 --> Helper loaded: file_helper
INFO - 2016-02-12 07:44:31 --> Helper loaded: date_helper
INFO - 2016-02-12 07:44:31 --> Helper loaded: form_helper
INFO - 2016-02-12 07:44:31 --> Database Driver Class Initialized
INFO - 2016-02-12 07:44:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:44:32 --> Controller Class Initialized
INFO - 2016-02-12 07:44:32 --> Model Class Initialized
INFO - 2016-02-12 07:44:32 --> Model Class Initialized
INFO - 2016-02-12 07:44:32 --> Form Validation Class Initialized
INFO - 2016-02-12 07:44:32 --> Helper loaded: text_helper
INFO - 2016-02-12 07:44:32 --> Config Class Initialized
INFO - 2016-02-12 07:44:32 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:44:32 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:44:32 --> Utf8 Class Initialized
INFO - 2016-02-12 07:44:32 --> URI Class Initialized
INFO - 2016-02-12 07:44:32 --> Router Class Initialized
INFO - 2016-02-12 07:44:32 --> Output Class Initialized
INFO - 2016-02-12 07:44:32 --> Security Class Initialized
DEBUG - 2016-02-12 07:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:44:32 --> Input Class Initialized
INFO - 2016-02-12 07:44:32 --> Language Class Initialized
INFO - 2016-02-12 07:44:32 --> Loader Class Initialized
INFO - 2016-02-12 07:44:32 --> Helper loaded: url_helper
INFO - 2016-02-12 07:44:32 --> Helper loaded: file_helper
INFO - 2016-02-12 07:44:32 --> Helper loaded: date_helper
INFO - 2016-02-12 07:44:32 --> Helper loaded: form_helper
INFO - 2016-02-12 07:44:32 --> Database Driver Class Initialized
INFO - 2016-02-12 07:44:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:44:33 --> Controller Class Initialized
INFO - 2016-02-12 07:44:33 --> Model Class Initialized
INFO - 2016-02-12 07:44:33 --> Model Class Initialized
INFO - 2016-02-12 07:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:44:33 --> Pagination Class Initialized
INFO - 2016-02-12 10:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-12 10:44:33 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 80
INFO - 2016-02-12 07:44:56 --> Config Class Initialized
INFO - 2016-02-12 07:44:56 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:44:56 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:44:56 --> Utf8 Class Initialized
INFO - 2016-02-12 07:44:56 --> URI Class Initialized
INFO - 2016-02-12 07:44:56 --> Router Class Initialized
INFO - 2016-02-12 07:44:56 --> Output Class Initialized
INFO - 2016-02-12 07:44:56 --> Security Class Initialized
DEBUG - 2016-02-12 07:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:44:56 --> Input Class Initialized
INFO - 2016-02-12 07:44:56 --> Language Class Initialized
INFO - 2016-02-12 07:44:56 --> Loader Class Initialized
INFO - 2016-02-12 07:44:56 --> Helper loaded: url_helper
INFO - 2016-02-12 07:44:56 --> Helper loaded: file_helper
INFO - 2016-02-12 07:44:56 --> Helper loaded: date_helper
INFO - 2016-02-12 07:44:56 --> Helper loaded: form_helper
INFO - 2016-02-12 07:44:56 --> Database Driver Class Initialized
INFO - 2016-02-12 07:44:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:44:57 --> Controller Class Initialized
INFO - 2016-02-12 07:44:57 --> Model Class Initialized
INFO - 2016-02-12 07:44:57 --> Model Class Initialized
INFO - 2016-02-12 07:44:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:44:57 --> Pagination Class Initialized
INFO - 2016-02-12 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:44:57 --> Final output sent to browser
DEBUG - 2016-02-12 10:44:57 --> Total execution time: 1.1068
INFO - 2016-02-12 07:45:01 --> Config Class Initialized
INFO - 2016-02-12 07:45:01 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:45:01 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:45:01 --> Utf8 Class Initialized
INFO - 2016-02-12 07:45:01 --> URI Class Initialized
INFO - 2016-02-12 07:45:01 --> Router Class Initialized
INFO - 2016-02-12 07:45:01 --> Output Class Initialized
INFO - 2016-02-12 07:45:01 --> Security Class Initialized
DEBUG - 2016-02-12 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:45:01 --> Input Class Initialized
INFO - 2016-02-12 07:45:01 --> Language Class Initialized
INFO - 2016-02-12 07:45:01 --> Loader Class Initialized
INFO - 2016-02-12 07:45:01 --> Helper loaded: url_helper
INFO - 2016-02-12 07:45:01 --> Helper loaded: file_helper
INFO - 2016-02-12 07:45:01 --> Helper loaded: date_helper
INFO - 2016-02-12 07:45:01 --> Helper loaded: form_helper
INFO - 2016-02-12 07:45:01 --> Database Driver Class Initialized
INFO - 2016-02-12 07:45:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:45:02 --> Controller Class Initialized
INFO - 2016-02-12 07:45:02 --> Model Class Initialized
INFO - 2016-02-12 07:45:02 --> Model Class Initialized
INFO - 2016-02-12 07:45:02 --> Form Validation Class Initialized
INFO - 2016-02-12 07:45:02 --> Helper loaded: text_helper
INFO - 2016-02-12 07:45:02 --> Config Class Initialized
INFO - 2016-02-12 07:45:02 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:45:03 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:45:03 --> Utf8 Class Initialized
INFO - 2016-02-12 07:45:03 --> URI Class Initialized
INFO - 2016-02-12 07:45:03 --> Router Class Initialized
INFO - 2016-02-12 07:45:03 --> Output Class Initialized
INFO - 2016-02-12 07:45:03 --> Security Class Initialized
DEBUG - 2016-02-12 07:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:45:03 --> Input Class Initialized
INFO - 2016-02-12 07:45:03 --> Language Class Initialized
INFO - 2016-02-12 07:45:03 --> Loader Class Initialized
INFO - 2016-02-12 07:45:03 --> Helper loaded: url_helper
INFO - 2016-02-12 07:45:03 --> Helper loaded: file_helper
INFO - 2016-02-12 07:45:03 --> Helper loaded: date_helper
INFO - 2016-02-12 07:45:03 --> Helper loaded: form_helper
INFO - 2016-02-12 07:45:03 --> Database Driver Class Initialized
INFO - 2016-02-12 07:45:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:45:04 --> Controller Class Initialized
INFO - 2016-02-12 07:45:04 --> Model Class Initialized
INFO - 2016-02-12 07:45:04 --> Model Class Initialized
INFO - 2016-02-12 07:45:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:45:04 --> Pagination Class Initialized
INFO - 2016-02-12 10:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:45:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:45:04 --> Final output sent to browser
DEBUG - 2016-02-12 10:45:04 --> Total execution time: 1.1143
INFO - 2016-02-12 07:45:09 --> Config Class Initialized
INFO - 2016-02-12 07:45:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:45:09 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:45:09 --> Utf8 Class Initialized
INFO - 2016-02-12 07:45:09 --> URI Class Initialized
INFO - 2016-02-12 07:45:09 --> Router Class Initialized
INFO - 2016-02-12 07:45:09 --> Output Class Initialized
INFO - 2016-02-12 07:45:09 --> Security Class Initialized
DEBUG - 2016-02-12 07:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:45:09 --> Input Class Initialized
INFO - 2016-02-12 07:45:09 --> Language Class Initialized
INFO - 2016-02-12 07:45:09 --> Loader Class Initialized
INFO - 2016-02-12 07:45:09 --> Helper loaded: url_helper
INFO - 2016-02-12 07:45:09 --> Helper loaded: file_helper
INFO - 2016-02-12 07:45:09 --> Helper loaded: date_helper
INFO - 2016-02-12 07:45:09 --> Helper loaded: form_helper
INFO - 2016-02-12 07:45:09 --> Database Driver Class Initialized
INFO - 2016-02-12 07:45:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:45:10 --> Controller Class Initialized
INFO - 2016-02-12 07:45:10 --> Model Class Initialized
INFO - 2016-02-12 07:45:10 --> Model Class Initialized
INFO - 2016-02-12 07:45:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:45:10 --> Pagination Class Initialized
INFO - 2016-02-12 10:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:45:10 --> Helper loaded: text_helper
INFO - 2016-02-12 10:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:45:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:45:10 --> Final output sent to browser
DEBUG - 2016-02-12 10:45:10 --> Total execution time: 1.2829
INFO - 2016-02-12 07:45:20 --> Config Class Initialized
INFO - 2016-02-12 07:45:20 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:45:20 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:45:20 --> Utf8 Class Initialized
INFO - 2016-02-12 07:45:20 --> URI Class Initialized
INFO - 2016-02-12 07:45:20 --> Router Class Initialized
INFO - 2016-02-12 07:45:20 --> Output Class Initialized
INFO - 2016-02-12 07:45:20 --> Security Class Initialized
DEBUG - 2016-02-12 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:45:20 --> Input Class Initialized
INFO - 2016-02-12 07:45:20 --> Language Class Initialized
INFO - 2016-02-12 07:45:20 --> Loader Class Initialized
INFO - 2016-02-12 07:45:20 --> Helper loaded: url_helper
INFO - 2016-02-12 07:45:20 --> Helper loaded: file_helper
INFO - 2016-02-12 07:45:20 --> Helper loaded: date_helper
INFO - 2016-02-12 07:45:20 --> Helper loaded: form_helper
INFO - 2016-02-12 07:45:20 --> Database Driver Class Initialized
INFO - 2016-02-12 07:45:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:45:21 --> Controller Class Initialized
INFO - 2016-02-12 07:45:21 --> Model Class Initialized
INFO - 2016-02-12 07:45:21 --> Model Class Initialized
INFO - 2016-02-12 07:45:21 --> Form Validation Class Initialized
INFO - 2016-02-12 07:45:21 --> Helper loaded: text_helper
INFO - 2016-02-12 07:45:22 --> Config Class Initialized
INFO - 2016-02-12 07:45:22 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:45:22 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:45:22 --> Utf8 Class Initialized
INFO - 2016-02-12 07:45:22 --> URI Class Initialized
INFO - 2016-02-12 07:45:22 --> Router Class Initialized
INFO - 2016-02-12 07:45:22 --> Output Class Initialized
INFO - 2016-02-12 07:45:22 --> Security Class Initialized
DEBUG - 2016-02-12 07:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:45:22 --> Input Class Initialized
INFO - 2016-02-12 07:45:22 --> Language Class Initialized
INFO - 2016-02-12 07:45:22 --> Loader Class Initialized
INFO - 2016-02-12 07:45:22 --> Helper loaded: url_helper
INFO - 2016-02-12 07:45:22 --> Helper loaded: file_helper
INFO - 2016-02-12 07:45:22 --> Helper loaded: date_helper
INFO - 2016-02-12 07:45:22 --> Helper loaded: form_helper
INFO - 2016-02-12 07:45:22 --> Database Driver Class Initialized
INFO - 2016-02-12 07:45:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:45:23 --> Controller Class Initialized
INFO - 2016-02-12 07:45:23 --> Model Class Initialized
INFO - 2016-02-12 07:45:23 --> Model Class Initialized
INFO - 2016-02-12 07:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:45:23 --> Pagination Class Initialized
INFO - 2016-02-12 10:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:45:23 --> Helper loaded: text_helper
INFO - 2016-02-12 10:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:45:23 --> Final output sent to browser
DEBUG - 2016-02-12 10:45:23 --> Total execution time: 1.1326
INFO - 2016-02-12 07:46:15 --> Config Class Initialized
INFO - 2016-02-12 07:46:15 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:46:15 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:46:15 --> Utf8 Class Initialized
INFO - 2016-02-12 07:46:15 --> URI Class Initialized
INFO - 2016-02-12 07:46:15 --> Router Class Initialized
INFO - 2016-02-12 07:46:15 --> Output Class Initialized
INFO - 2016-02-12 07:46:15 --> Security Class Initialized
DEBUG - 2016-02-12 07:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:46:15 --> Input Class Initialized
INFO - 2016-02-12 07:46:15 --> Language Class Initialized
INFO - 2016-02-12 07:46:15 --> Loader Class Initialized
INFO - 2016-02-12 07:46:15 --> Helper loaded: url_helper
INFO - 2016-02-12 07:46:15 --> Helper loaded: file_helper
INFO - 2016-02-12 07:46:15 --> Helper loaded: date_helper
INFO - 2016-02-12 07:46:15 --> Helper loaded: form_helper
INFO - 2016-02-12 07:46:15 --> Database Driver Class Initialized
INFO - 2016-02-12 07:46:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:46:16 --> Controller Class Initialized
INFO - 2016-02-12 07:46:16 --> Model Class Initialized
INFO - 2016-02-12 07:46:16 --> Model Class Initialized
INFO - 2016-02-12 07:46:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:46:16 --> Pagination Class Initialized
INFO - 2016-02-12 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:46:16 --> Helper loaded: text_helper
INFO - 2016-02-12 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:46:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:46:16 --> Final output sent to browser
DEBUG - 2016-02-12 10:46:16 --> Total execution time: 1.1316
INFO - 2016-02-12 07:46:24 --> Config Class Initialized
INFO - 2016-02-12 07:46:24 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:46:24 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:46:24 --> Utf8 Class Initialized
INFO - 2016-02-12 07:46:24 --> URI Class Initialized
INFO - 2016-02-12 07:46:24 --> Router Class Initialized
INFO - 2016-02-12 07:46:24 --> Output Class Initialized
INFO - 2016-02-12 07:46:24 --> Security Class Initialized
DEBUG - 2016-02-12 07:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:46:24 --> Input Class Initialized
INFO - 2016-02-12 07:46:24 --> Language Class Initialized
INFO - 2016-02-12 07:46:24 --> Loader Class Initialized
INFO - 2016-02-12 07:46:24 --> Helper loaded: url_helper
INFO - 2016-02-12 07:46:24 --> Helper loaded: file_helper
INFO - 2016-02-12 07:46:24 --> Helper loaded: date_helper
INFO - 2016-02-12 07:46:24 --> Helper loaded: form_helper
INFO - 2016-02-12 07:46:24 --> Database Driver Class Initialized
INFO - 2016-02-12 07:46:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:46:25 --> Controller Class Initialized
INFO - 2016-02-12 07:46:25 --> Model Class Initialized
INFO - 2016-02-12 07:46:25 --> Model Class Initialized
INFO - 2016-02-12 07:46:25 --> Form Validation Class Initialized
INFO - 2016-02-12 07:46:25 --> Helper loaded: text_helper
INFO - 2016-02-12 07:46:25 --> Config Class Initialized
INFO - 2016-02-12 07:46:25 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:46:25 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:46:25 --> Utf8 Class Initialized
INFO - 2016-02-12 07:46:25 --> URI Class Initialized
INFO - 2016-02-12 07:46:25 --> Router Class Initialized
INFO - 2016-02-12 07:46:25 --> Output Class Initialized
INFO - 2016-02-12 07:46:25 --> Security Class Initialized
DEBUG - 2016-02-12 07:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:46:25 --> Input Class Initialized
INFO - 2016-02-12 07:46:25 --> Language Class Initialized
INFO - 2016-02-12 07:46:25 --> Loader Class Initialized
INFO - 2016-02-12 07:46:25 --> Helper loaded: url_helper
INFO - 2016-02-12 07:46:25 --> Helper loaded: file_helper
INFO - 2016-02-12 07:46:25 --> Helper loaded: date_helper
INFO - 2016-02-12 07:46:25 --> Helper loaded: form_helper
INFO - 2016-02-12 07:46:25 --> Database Driver Class Initialized
INFO - 2016-02-12 07:46:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:46:26 --> Controller Class Initialized
INFO - 2016-02-12 07:46:26 --> Model Class Initialized
INFO - 2016-02-12 07:46:26 --> Model Class Initialized
INFO - 2016-02-12 07:46:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:46:26 --> Pagination Class Initialized
INFO - 2016-02-12 10:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:46:26 --> Final output sent to browser
DEBUG - 2016-02-12 10:46:26 --> Total execution time: 1.1353
INFO - 2016-02-12 07:46:30 --> Config Class Initialized
INFO - 2016-02-12 07:46:30 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:46:30 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:46:30 --> Utf8 Class Initialized
INFO - 2016-02-12 07:46:30 --> URI Class Initialized
INFO - 2016-02-12 07:46:30 --> Router Class Initialized
INFO - 2016-02-12 07:46:30 --> Output Class Initialized
INFO - 2016-02-12 07:46:30 --> Security Class Initialized
DEBUG - 2016-02-12 07:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:46:30 --> Input Class Initialized
INFO - 2016-02-12 07:46:30 --> Language Class Initialized
INFO - 2016-02-12 07:46:30 --> Loader Class Initialized
INFO - 2016-02-12 07:46:30 --> Helper loaded: url_helper
INFO - 2016-02-12 07:46:30 --> Helper loaded: file_helper
INFO - 2016-02-12 07:46:30 --> Helper loaded: date_helper
INFO - 2016-02-12 07:46:30 --> Helper loaded: form_helper
INFO - 2016-02-12 07:46:30 --> Database Driver Class Initialized
INFO - 2016-02-12 07:46:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:46:31 --> Controller Class Initialized
INFO - 2016-02-12 07:46:31 --> Model Class Initialized
INFO - 2016-02-12 07:46:31 --> Model Class Initialized
INFO - 2016-02-12 07:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:46:31 --> Pagination Class Initialized
INFO - 2016-02-12 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:46:31 --> Final output sent to browser
DEBUG - 2016-02-12 10:46:31 --> Total execution time: 1.1407
INFO - 2016-02-12 07:46:33 --> Config Class Initialized
INFO - 2016-02-12 07:46:33 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:46:33 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:46:33 --> Utf8 Class Initialized
INFO - 2016-02-12 07:46:33 --> URI Class Initialized
INFO - 2016-02-12 07:46:33 --> Router Class Initialized
INFO - 2016-02-12 07:46:33 --> Output Class Initialized
INFO - 2016-02-12 07:46:33 --> Security Class Initialized
DEBUG - 2016-02-12 07:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:46:33 --> Input Class Initialized
INFO - 2016-02-12 07:46:33 --> Language Class Initialized
INFO - 2016-02-12 07:46:33 --> Loader Class Initialized
INFO - 2016-02-12 07:46:33 --> Helper loaded: url_helper
INFO - 2016-02-12 07:46:33 --> Helper loaded: file_helper
INFO - 2016-02-12 07:46:33 --> Helper loaded: date_helper
INFO - 2016-02-12 07:46:33 --> Helper loaded: form_helper
INFO - 2016-02-12 07:46:33 --> Database Driver Class Initialized
INFO - 2016-02-12 07:46:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:46:34 --> Controller Class Initialized
INFO - 2016-02-12 07:46:34 --> Model Class Initialized
INFO - 2016-02-12 07:46:34 --> Model Class Initialized
INFO - 2016-02-12 07:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:46:34 --> Pagination Class Initialized
INFO - 2016-02-12 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:46:34 --> Helper loaded: text_helper
INFO - 2016-02-12 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:46:34 --> Final output sent to browser
DEBUG - 2016-02-12 10:46:34 --> Total execution time: 1.1496
INFO - 2016-02-12 07:46:36 --> Config Class Initialized
INFO - 2016-02-12 07:46:36 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:46:36 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:46:36 --> Utf8 Class Initialized
INFO - 2016-02-12 07:46:36 --> URI Class Initialized
INFO - 2016-02-12 07:46:36 --> Router Class Initialized
INFO - 2016-02-12 07:46:36 --> Output Class Initialized
INFO - 2016-02-12 07:46:36 --> Security Class Initialized
DEBUG - 2016-02-12 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:46:36 --> Input Class Initialized
INFO - 2016-02-12 07:46:36 --> Language Class Initialized
INFO - 2016-02-12 07:46:36 --> Loader Class Initialized
INFO - 2016-02-12 07:46:36 --> Helper loaded: url_helper
INFO - 2016-02-12 07:46:36 --> Helper loaded: file_helper
INFO - 2016-02-12 07:46:37 --> Helper loaded: date_helper
INFO - 2016-02-12 07:46:37 --> Helper loaded: form_helper
INFO - 2016-02-12 07:46:37 --> Database Driver Class Initialized
INFO - 2016-02-12 07:46:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:46:38 --> Controller Class Initialized
INFO - 2016-02-12 07:46:38 --> Model Class Initialized
INFO - 2016-02-12 07:46:38 --> Model Class Initialized
INFO - 2016-02-12 07:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:46:38 --> Pagination Class Initialized
INFO - 2016-02-12 10:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:46:38 --> Helper loaded: text_helper
INFO - 2016-02-12 10:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:46:38 --> Final output sent to browser
DEBUG - 2016-02-12 10:46:38 --> Total execution time: 1.2233
INFO - 2016-02-12 07:46:40 --> Config Class Initialized
INFO - 2016-02-12 07:46:40 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:46:40 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:46:40 --> Utf8 Class Initialized
INFO - 2016-02-12 07:46:40 --> URI Class Initialized
INFO - 2016-02-12 07:46:40 --> Router Class Initialized
INFO - 2016-02-12 07:46:40 --> Output Class Initialized
INFO - 2016-02-12 07:46:40 --> Security Class Initialized
DEBUG - 2016-02-12 07:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:46:40 --> Input Class Initialized
INFO - 2016-02-12 07:46:40 --> Language Class Initialized
INFO - 2016-02-12 07:46:40 --> Loader Class Initialized
INFO - 2016-02-12 07:46:40 --> Helper loaded: url_helper
INFO - 2016-02-12 07:46:40 --> Helper loaded: file_helper
INFO - 2016-02-12 07:46:40 --> Helper loaded: date_helper
INFO - 2016-02-12 07:46:40 --> Helper loaded: form_helper
INFO - 2016-02-12 07:46:40 --> Database Driver Class Initialized
INFO - 2016-02-12 07:46:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:46:41 --> Controller Class Initialized
INFO - 2016-02-12 07:46:41 --> Model Class Initialized
INFO - 2016-02-12 07:46:41 --> Model Class Initialized
INFO - 2016-02-12 07:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:46:41 --> Pagination Class Initialized
INFO - 2016-02-12 10:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:46:41 --> Helper loaded: text_helper
INFO - 2016-02-12 10:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:46:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:46:41 --> Final output sent to browser
DEBUG - 2016-02-12 10:46:41 --> Total execution time: 1.2462
INFO - 2016-02-12 07:46:49 --> Config Class Initialized
INFO - 2016-02-12 07:46:49 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:46:49 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:46:49 --> Utf8 Class Initialized
INFO - 2016-02-12 07:46:49 --> URI Class Initialized
INFO - 2016-02-12 07:46:49 --> Router Class Initialized
INFO - 2016-02-12 07:46:49 --> Output Class Initialized
INFO - 2016-02-12 07:46:49 --> Security Class Initialized
DEBUG - 2016-02-12 07:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:46:49 --> Input Class Initialized
INFO - 2016-02-12 07:46:49 --> Language Class Initialized
INFO - 2016-02-12 07:46:49 --> Loader Class Initialized
INFO - 2016-02-12 07:46:49 --> Helper loaded: url_helper
INFO - 2016-02-12 07:46:49 --> Helper loaded: file_helper
INFO - 2016-02-12 07:46:49 --> Helper loaded: date_helper
INFO - 2016-02-12 07:46:49 --> Helper loaded: form_helper
INFO - 2016-02-12 07:46:49 --> Database Driver Class Initialized
INFO - 2016-02-12 07:46:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:46:50 --> Controller Class Initialized
INFO - 2016-02-12 07:46:50 --> Model Class Initialized
INFO - 2016-02-12 07:46:50 --> Model Class Initialized
INFO - 2016-02-12 07:46:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:46:50 --> Pagination Class Initialized
INFO - 2016-02-12 10:46:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:46:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:46:50 --> Helper loaded: text_helper
INFO - 2016-02-12 10:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:46:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:46:51 --> Final output sent to browser
DEBUG - 2016-02-12 10:46:51 --> Total execution time: 1.1394
INFO - 2016-02-12 07:47:00 --> Config Class Initialized
INFO - 2016-02-12 07:47:00 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:47:00 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:47:00 --> Utf8 Class Initialized
INFO - 2016-02-12 07:47:00 --> URI Class Initialized
INFO - 2016-02-12 07:47:00 --> Router Class Initialized
INFO - 2016-02-12 07:47:00 --> Output Class Initialized
INFO - 2016-02-12 07:47:00 --> Security Class Initialized
DEBUG - 2016-02-12 07:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:47:00 --> Input Class Initialized
INFO - 2016-02-12 07:47:00 --> Language Class Initialized
INFO - 2016-02-12 07:47:00 --> Loader Class Initialized
INFO - 2016-02-12 07:47:00 --> Helper loaded: url_helper
INFO - 2016-02-12 07:47:00 --> Helper loaded: file_helper
INFO - 2016-02-12 07:47:00 --> Helper loaded: date_helper
INFO - 2016-02-12 07:47:00 --> Helper loaded: form_helper
INFO - 2016-02-12 07:47:00 --> Database Driver Class Initialized
INFO - 2016-02-12 07:47:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:47:01 --> Controller Class Initialized
INFO - 2016-02-12 07:47:01 --> Model Class Initialized
INFO - 2016-02-12 07:47:01 --> Model Class Initialized
INFO - 2016-02-12 07:47:01 --> Form Validation Class Initialized
INFO - 2016-02-12 07:47:01 --> Helper loaded: text_helper
INFO - 2016-02-12 07:47:02 --> Config Class Initialized
INFO - 2016-02-12 07:47:02 --> Hooks Class Initialized
DEBUG - 2016-02-12 07:47:02 --> UTF-8 Support Enabled
INFO - 2016-02-12 07:47:02 --> Utf8 Class Initialized
INFO - 2016-02-12 07:47:02 --> URI Class Initialized
INFO - 2016-02-12 07:47:02 --> Router Class Initialized
INFO - 2016-02-12 07:47:02 --> Output Class Initialized
INFO - 2016-02-12 07:47:02 --> Security Class Initialized
DEBUG - 2016-02-12 07:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 07:47:02 --> Input Class Initialized
INFO - 2016-02-12 07:47:02 --> Language Class Initialized
INFO - 2016-02-12 07:47:02 --> Loader Class Initialized
INFO - 2016-02-12 07:47:02 --> Helper loaded: url_helper
INFO - 2016-02-12 07:47:02 --> Helper loaded: file_helper
INFO - 2016-02-12 07:47:02 --> Helper loaded: date_helper
INFO - 2016-02-12 07:47:02 --> Helper loaded: form_helper
INFO - 2016-02-12 07:47:02 --> Database Driver Class Initialized
INFO - 2016-02-12 07:47:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 07:47:03 --> Controller Class Initialized
INFO - 2016-02-12 07:47:03 --> Model Class Initialized
INFO - 2016-02-12 07:47:03 --> Model Class Initialized
INFO - 2016-02-12 07:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 07:47:03 --> Pagination Class Initialized
INFO - 2016-02-12 10:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 10:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 10:47:03 --> Helper loaded: text_helper
INFO - 2016-02-12 10:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 10:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 10:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 10:47:03 --> Final output sent to browser
DEBUG - 2016-02-12 10:47:03 --> Total execution time: 1.1915
INFO - 2016-02-12 08:24:10 --> Config Class Initialized
INFO - 2016-02-12 08:24:10 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:24:10 --> UTF-8 Support Enabled
INFO - 2016-02-12 08:24:10 --> Utf8 Class Initialized
INFO - 2016-02-12 08:24:10 --> URI Class Initialized
INFO - 2016-02-12 08:24:10 --> Router Class Initialized
INFO - 2016-02-12 08:24:10 --> Output Class Initialized
INFO - 2016-02-12 08:24:10 --> Security Class Initialized
DEBUG - 2016-02-12 08:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 08:24:10 --> Input Class Initialized
INFO - 2016-02-12 08:24:10 --> Language Class Initialized
INFO - 2016-02-12 08:24:10 --> Loader Class Initialized
INFO - 2016-02-12 08:24:10 --> Helper loaded: url_helper
INFO - 2016-02-12 08:24:10 --> Helper loaded: file_helper
INFO - 2016-02-12 08:24:10 --> Helper loaded: date_helper
INFO - 2016-02-12 08:24:10 --> Helper loaded: form_helper
INFO - 2016-02-12 08:24:10 --> Database Driver Class Initialized
INFO - 2016-02-12 08:24:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 08:24:11 --> Controller Class Initialized
INFO - 2016-02-12 08:24:11 --> Model Class Initialized
INFO - 2016-02-12 08:24:11 --> Model Class Initialized
INFO - 2016-02-12 08:24:11 --> Form Validation Class Initialized
INFO - 2016-02-12 08:24:11 --> Helper loaded: text_helper
INFO - 2016-02-12 08:24:11 --> Config Class Initialized
INFO - 2016-02-12 08:24:11 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:24:11 --> UTF-8 Support Enabled
INFO - 2016-02-12 08:24:11 --> Utf8 Class Initialized
INFO - 2016-02-12 08:24:11 --> URI Class Initialized
INFO - 2016-02-12 08:24:11 --> Router Class Initialized
INFO - 2016-02-12 08:24:11 --> Output Class Initialized
INFO - 2016-02-12 08:24:11 --> Security Class Initialized
DEBUG - 2016-02-12 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 08:24:11 --> Input Class Initialized
INFO - 2016-02-12 08:24:11 --> Language Class Initialized
INFO - 2016-02-12 08:24:11 --> Loader Class Initialized
INFO - 2016-02-12 08:24:11 --> Helper loaded: url_helper
INFO - 2016-02-12 08:24:11 --> Helper loaded: file_helper
INFO - 2016-02-12 08:24:11 --> Helper loaded: date_helper
INFO - 2016-02-12 08:24:11 --> Helper loaded: form_helper
INFO - 2016-02-12 08:24:11 --> Database Driver Class Initialized
INFO - 2016-02-12 08:24:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 08:24:12 --> Controller Class Initialized
INFO - 2016-02-12 08:24:12 --> Model Class Initialized
INFO - 2016-02-12 08:24:12 --> Model Class Initialized
INFO - 2016-02-12 08:24:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 08:24:12 --> Pagination Class Initialized
INFO - 2016-02-12 11:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 11:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 11:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 11:24:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 11:24:12 --> Final output sent to browser
DEBUG - 2016-02-12 11:24:12 --> Total execution time: 1.0875
INFO - 2016-02-12 08:24:14 --> Config Class Initialized
INFO - 2016-02-12 08:24:14 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:24:14 --> UTF-8 Support Enabled
INFO - 2016-02-12 08:24:14 --> Utf8 Class Initialized
INFO - 2016-02-12 08:24:14 --> URI Class Initialized
INFO - 2016-02-12 08:24:14 --> Router Class Initialized
INFO - 2016-02-12 08:24:14 --> Output Class Initialized
INFO - 2016-02-12 08:24:14 --> Security Class Initialized
DEBUG - 2016-02-12 08:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 08:24:14 --> Input Class Initialized
INFO - 2016-02-12 08:24:14 --> Language Class Initialized
INFO - 2016-02-12 08:24:14 --> Loader Class Initialized
INFO - 2016-02-12 08:24:14 --> Helper loaded: url_helper
INFO - 2016-02-12 08:24:14 --> Helper loaded: file_helper
INFO - 2016-02-12 08:24:14 --> Helper loaded: date_helper
INFO - 2016-02-12 08:24:14 --> Helper loaded: form_helper
INFO - 2016-02-12 08:24:14 --> Database Driver Class Initialized
INFO - 2016-02-12 08:24:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 08:24:15 --> Controller Class Initialized
INFO - 2016-02-12 08:24:15 --> Model Class Initialized
INFO - 2016-02-12 08:24:15 --> Model Class Initialized
INFO - 2016-02-12 08:24:15 --> Form Validation Class Initialized
INFO - 2016-02-12 08:24:15 --> Helper loaded: text_helper
INFO - 2016-02-12 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 08:24:15 --> Model Class Initialized
INFO - 2016-02-12 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:24:15 --> Final output sent to browser
DEBUG - 2016-02-12 08:24:15 --> Total execution time: 1.1253
INFO - 2016-02-12 08:24:33 --> Config Class Initialized
INFO - 2016-02-12 08:24:33 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:24:33 --> UTF-8 Support Enabled
INFO - 2016-02-12 08:24:33 --> Utf8 Class Initialized
INFO - 2016-02-12 08:24:33 --> URI Class Initialized
INFO - 2016-02-12 08:24:33 --> Router Class Initialized
INFO - 2016-02-12 08:24:33 --> Output Class Initialized
INFO - 2016-02-12 08:24:33 --> Security Class Initialized
DEBUG - 2016-02-12 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 08:24:33 --> Input Class Initialized
INFO - 2016-02-12 08:24:33 --> Language Class Initialized
INFO - 2016-02-12 08:24:33 --> Loader Class Initialized
INFO - 2016-02-12 08:24:33 --> Helper loaded: url_helper
INFO - 2016-02-12 08:24:33 --> Helper loaded: file_helper
INFO - 2016-02-12 08:24:33 --> Helper loaded: date_helper
INFO - 2016-02-12 08:24:33 --> Helper loaded: form_helper
INFO - 2016-02-12 08:24:33 --> Database Driver Class Initialized
INFO - 2016-02-12 08:24:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 08:24:34 --> Controller Class Initialized
INFO - 2016-02-12 08:24:34 --> Model Class Initialized
INFO - 2016-02-12 08:24:34 --> Model Class Initialized
INFO - 2016-02-12 08:24:34 --> Form Validation Class Initialized
INFO - 2016-02-12 08:24:34 --> Helper loaded: text_helper
INFO - 2016-02-12 08:24:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-12 08:24:34 --> Final output sent to browser
DEBUG - 2016-02-12 08:24:34 --> Total execution time: 1.1746
INFO - 2016-02-12 08:24:39 --> Config Class Initialized
INFO - 2016-02-12 08:24:39 --> Hooks Class Initialized
DEBUG - 2016-02-12 08:24:39 --> UTF-8 Support Enabled
INFO - 2016-02-12 08:24:39 --> Utf8 Class Initialized
INFO - 2016-02-12 08:24:39 --> URI Class Initialized
INFO - 2016-02-12 08:24:39 --> Router Class Initialized
INFO - 2016-02-12 08:24:39 --> Output Class Initialized
INFO - 2016-02-12 08:24:39 --> Security Class Initialized
DEBUG - 2016-02-12 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 08:24:39 --> Input Class Initialized
INFO - 2016-02-12 08:24:39 --> Language Class Initialized
INFO - 2016-02-12 08:24:39 --> Loader Class Initialized
INFO - 2016-02-12 08:24:39 --> Helper loaded: url_helper
INFO - 2016-02-12 08:24:39 --> Helper loaded: file_helper
INFO - 2016-02-12 08:24:39 --> Helper loaded: date_helper
INFO - 2016-02-12 08:24:39 --> Helper loaded: form_helper
INFO - 2016-02-12 08:24:39 --> Database Driver Class Initialized
INFO - 2016-02-12 08:24:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 08:24:40 --> Controller Class Initialized
INFO - 2016-02-12 08:24:40 --> Model Class Initialized
INFO - 2016-02-12 08:24:40 --> Model Class Initialized
INFO - 2016-02-12 08:24:40 --> Form Validation Class Initialized
INFO - 2016-02-12 08:24:40 --> Helper loaded: text_helper
INFO - 2016-02-12 08:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 08:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 08:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-12 08:24:40 --> Model Class Initialized
INFO - 2016-02-12 08:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 08:24:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 08:24:40 --> Final output sent to browser
DEBUG - 2016-02-12 08:24:40 --> Total execution time: 1.1215
INFO - 2016-02-12 09:53:08 --> Config Class Initialized
INFO - 2016-02-12 09:53:08 --> Hooks Class Initialized
DEBUG - 2016-02-12 09:53:08 --> UTF-8 Support Enabled
INFO - 2016-02-12 09:53:08 --> Utf8 Class Initialized
INFO - 2016-02-12 09:53:08 --> URI Class Initialized
DEBUG - 2016-02-12 09:53:08 --> No URI present. Default controller set.
INFO - 2016-02-12 09:53:08 --> Router Class Initialized
INFO - 2016-02-12 09:53:08 --> Output Class Initialized
INFO - 2016-02-12 09:53:08 --> Security Class Initialized
DEBUG - 2016-02-12 09:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 09:53:08 --> Input Class Initialized
INFO - 2016-02-12 09:53:08 --> Language Class Initialized
INFO - 2016-02-12 09:53:08 --> Loader Class Initialized
INFO - 2016-02-12 09:53:08 --> Helper loaded: url_helper
INFO - 2016-02-12 09:53:08 --> Helper loaded: file_helper
INFO - 2016-02-12 09:53:08 --> Helper loaded: date_helper
INFO - 2016-02-12 09:53:08 --> Helper loaded: form_helper
INFO - 2016-02-12 09:53:08 --> Database Driver Class Initialized
INFO - 2016-02-12 09:53:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 09:53:09 --> Controller Class Initialized
INFO - 2016-02-12 09:53:09 --> Model Class Initialized
INFO - 2016-02-12 09:53:09 --> Model Class Initialized
INFO - 2016-02-12 09:53:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 09:53:09 --> Pagination Class Initialized
INFO - 2016-02-12 12:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 12:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 12:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 12:53:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 12:53:09 --> Final output sent to browser
DEBUG - 2016-02-12 12:53:09 --> Total execution time: 1.1239
INFO - 2016-02-12 10:29:23 --> Config Class Initialized
INFO - 2016-02-12 10:29:23 --> Hooks Class Initialized
DEBUG - 2016-02-12 10:29:23 --> UTF-8 Support Enabled
INFO - 2016-02-12 10:29:23 --> Utf8 Class Initialized
INFO - 2016-02-12 10:29:23 --> URI Class Initialized
DEBUG - 2016-02-12 10:29:23 --> No URI present. Default controller set.
INFO - 2016-02-12 10:29:23 --> Router Class Initialized
INFO - 2016-02-12 10:29:23 --> Output Class Initialized
INFO - 2016-02-12 10:29:23 --> Security Class Initialized
DEBUG - 2016-02-12 10:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 10:29:23 --> Input Class Initialized
INFO - 2016-02-12 10:29:23 --> Language Class Initialized
ERROR - 2016-02-12 10:29:23 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 331
INFO - 2016-02-12 10:29:34 --> Config Class Initialized
INFO - 2016-02-12 10:29:34 --> Hooks Class Initialized
DEBUG - 2016-02-12 10:29:34 --> UTF-8 Support Enabled
INFO - 2016-02-12 10:29:34 --> Utf8 Class Initialized
INFO - 2016-02-12 10:29:34 --> URI Class Initialized
DEBUG - 2016-02-12 10:29:34 --> No URI present. Default controller set.
INFO - 2016-02-12 10:29:34 --> Router Class Initialized
INFO - 2016-02-12 10:29:34 --> Output Class Initialized
INFO - 2016-02-12 10:29:34 --> Security Class Initialized
DEBUG - 2016-02-12 10:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 10:29:34 --> Input Class Initialized
INFO - 2016-02-12 10:29:34 --> Language Class Initialized
INFO - 2016-02-12 10:29:34 --> Loader Class Initialized
INFO - 2016-02-12 10:29:34 --> Helper loaded: url_helper
INFO - 2016-02-12 10:29:34 --> Helper loaded: file_helper
INFO - 2016-02-12 10:29:34 --> Helper loaded: date_helper
INFO - 2016-02-12 10:29:34 --> Helper loaded: form_helper
INFO - 2016-02-12 10:29:34 --> Database Driver Class Initialized
INFO - 2016-02-12 10:29:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 10:29:35 --> Controller Class Initialized
INFO - 2016-02-12 10:29:35 --> Model Class Initialized
INFO - 2016-02-12 10:29:35 --> Model Class Initialized
INFO - 2016-02-12 10:29:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 10:29:35 --> Pagination Class Initialized
INFO - 2016-02-12 13:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 13:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 13:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 13:29:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 13:29:35 --> Final output sent to browser
DEBUG - 2016-02-12 13:29:35 --> Total execution time: 1.1173
INFO - 2016-02-12 10:29:37 --> Config Class Initialized
INFO - 2016-02-12 10:29:37 --> Hooks Class Initialized
DEBUG - 2016-02-12 10:29:37 --> UTF-8 Support Enabled
INFO - 2016-02-12 10:29:37 --> Utf8 Class Initialized
INFO - 2016-02-12 10:29:37 --> URI Class Initialized
DEBUG - 2016-02-12 10:29:37 --> No URI present. Default controller set.
INFO - 2016-02-12 10:29:37 --> Router Class Initialized
INFO - 2016-02-12 10:29:37 --> Output Class Initialized
INFO - 2016-02-12 10:29:37 --> Security Class Initialized
DEBUG - 2016-02-12 10:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 10:29:37 --> Input Class Initialized
INFO - 2016-02-12 10:29:37 --> Language Class Initialized
INFO - 2016-02-12 10:29:37 --> Loader Class Initialized
INFO - 2016-02-12 10:29:37 --> Helper loaded: url_helper
INFO - 2016-02-12 10:29:37 --> Helper loaded: file_helper
INFO - 2016-02-12 10:29:37 --> Helper loaded: date_helper
INFO - 2016-02-12 10:29:37 --> Helper loaded: form_helper
INFO - 2016-02-12 10:29:37 --> Database Driver Class Initialized
INFO - 2016-02-12 10:29:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 10:29:38 --> Controller Class Initialized
INFO - 2016-02-12 10:29:38 --> Model Class Initialized
INFO - 2016-02-12 10:29:38 --> Model Class Initialized
INFO - 2016-02-12 10:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 10:29:38 --> Pagination Class Initialized
INFO - 2016-02-12 13:29:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 13:29:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 13:29:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 13:29:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 13:29:38 --> Final output sent to browser
DEBUG - 2016-02-12 13:29:38 --> Total execution time: 1.1107
INFO - 2016-02-12 10:29:47 --> Config Class Initialized
INFO - 2016-02-12 10:29:47 --> Hooks Class Initialized
DEBUG - 2016-02-12 10:29:47 --> UTF-8 Support Enabled
INFO - 2016-02-12 10:29:47 --> Utf8 Class Initialized
INFO - 2016-02-12 10:29:47 --> URI Class Initialized
INFO - 2016-02-12 10:29:47 --> Router Class Initialized
INFO - 2016-02-12 10:29:47 --> Output Class Initialized
INFO - 2016-02-12 10:29:47 --> Security Class Initialized
DEBUG - 2016-02-12 10:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 10:29:47 --> Input Class Initialized
INFO - 2016-02-12 10:29:47 --> Language Class Initialized
INFO - 2016-02-12 10:29:47 --> Loader Class Initialized
INFO - 2016-02-12 10:29:47 --> Helper loaded: url_helper
INFO - 2016-02-12 10:29:47 --> Helper loaded: file_helper
INFO - 2016-02-12 10:29:47 --> Helper loaded: date_helper
INFO - 2016-02-12 10:29:47 --> Helper loaded: form_helper
INFO - 2016-02-12 10:29:47 --> Database Driver Class Initialized
INFO - 2016-02-12 10:29:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 10:29:48 --> Controller Class Initialized
INFO - 2016-02-12 10:29:48 --> Model Class Initialized
INFO - 2016-02-12 10:29:49 --> Model Class Initialized
INFO - 2016-02-12 10:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 10:29:49 --> Pagination Class Initialized
INFO - 2016-02-12 13:29:49 --> Final output sent to browser
DEBUG - 2016-02-12 13:29:49 --> Total execution time: 1.0977
INFO - 2016-02-12 11:37:45 --> Config Class Initialized
INFO - 2016-02-12 11:37:45 --> Hooks Class Initialized
DEBUG - 2016-02-12 11:37:45 --> UTF-8 Support Enabled
INFO - 2016-02-12 11:37:45 --> Utf8 Class Initialized
INFO - 2016-02-12 11:37:45 --> URI Class Initialized
INFO - 2016-02-12 11:37:45 --> Router Class Initialized
INFO - 2016-02-12 11:37:45 --> Output Class Initialized
INFO - 2016-02-12 11:37:45 --> Security Class Initialized
DEBUG - 2016-02-12 11:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 11:37:45 --> Input Class Initialized
INFO - 2016-02-12 11:37:45 --> Language Class Initialized
INFO - 2016-02-12 11:37:45 --> Loader Class Initialized
INFO - 2016-02-12 11:37:45 --> Helper loaded: url_helper
INFO - 2016-02-12 11:37:45 --> Helper loaded: file_helper
INFO - 2016-02-12 11:37:45 --> Helper loaded: date_helper
INFO - 2016-02-12 11:37:45 --> Helper loaded: form_helper
INFO - 2016-02-12 11:37:45 --> Database Driver Class Initialized
INFO - 2016-02-12 11:37:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 11:37:46 --> Controller Class Initialized
INFO - 2016-02-12 11:37:46 --> Model Class Initialized
INFO - 2016-02-12 11:37:46 --> Model Class Initialized
INFO - 2016-02-12 11:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 11:37:46 --> Pagination Class Initialized
INFO - 2016-02-12 14:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-12 14:37:46 --> Severity: Parsing Error --> syntax error, unexpected 'submit' (T_STRING), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 37
INFO - 2016-02-12 11:38:10 --> Config Class Initialized
INFO - 2016-02-12 11:38:10 --> Hooks Class Initialized
DEBUG - 2016-02-12 11:38:10 --> UTF-8 Support Enabled
INFO - 2016-02-12 11:38:10 --> Utf8 Class Initialized
INFO - 2016-02-12 11:38:10 --> URI Class Initialized
INFO - 2016-02-12 11:38:10 --> Router Class Initialized
INFO - 2016-02-12 11:38:10 --> Output Class Initialized
INFO - 2016-02-12 11:38:10 --> Security Class Initialized
DEBUG - 2016-02-12 11:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 11:38:10 --> Input Class Initialized
INFO - 2016-02-12 11:38:10 --> Language Class Initialized
INFO - 2016-02-12 11:38:10 --> Loader Class Initialized
INFO - 2016-02-12 11:38:11 --> Helper loaded: url_helper
INFO - 2016-02-12 11:38:11 --> Helper loaded: file_helper
INFO - 2016-02-12 11:38:11 --> Helper loaded: date_helper
INFO - 2016-02-12 11:38:11 --> Helper loaded: form_helper
INFO - 2016-02-12 11:38:11 --> Database Driver Class Initialized
INFO - 2016-02-12 11:38:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 11:38:12 --> Controller Class Initialized
INFO - 2016-02-12 11:38:12 --> Model Class Initialized
INFO - 2016-02-12 11:38:12 --> Model Class Initialized
INFO - 2016-02-12 11:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 11:38:12 --> Pagination Class Initialized
INFO - 2016-02-12 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
ERROR - 2016-02-12 14:38:12 --> Severity: Notice --> Undefined variable: search_terms C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php 35
INFO - 2016-02-12 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 14:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 14:38:12 --> Final output sent to browser
DEBUG - 2016-02-12 14:38:12 --> Total execution time: 1.1094
INFO - 2016-02-12 11:38:27 --> Config Class Initialized
INFO - 2016-02-12 11:38:27 --> Hooks Class Initialized
DEBUG - 2016-02-12 11:38:27 --> UTF-8 Support Enabled
INFO - 2016-02-12 11:38:27 --> Utf8 Class Initialized
INFO - 2016-02-12 11:38:27 --> URI Class Initialized
INFO - 2016-02-12 11:38:27 --> Router Class Initialized
INFO - 2016-02-12 11:38:27 --> Output Class Initialized
INFO - 2016-02-12 11:38:27 --> Security Class Initialized
DEBUG - 2016-02-12 11:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 11:38:27 --> Input Class Initialized
INFO - 2016-02-12 11:38:27 --> Language Class Initialized
INFO - 2016-02-12 11:38:27 --> Loader Class Initialized
INFO - 2016-02-12 11:38:27 --> Helper loaded: url_helper
INFO - 2016-02-12 11:38:27 --> Helper loaded: file_helper
INFO - 2016-02-12 11:38:27 --> Helper loaded: date_helper
INFO - 2016-02-12 11:38:27 --> Helper loaded: form_helper
INFO - 2016-02-12 11:38:28 --> Database Driver Class Initialized
INFO - 2016-02-12 11:38:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 11:38:29 --> Controller Class Initialized
INFO - 2016-02-12 11:38:29 --> Model Class Initialized
INFO - 2016-02-12 11:38:29 --> Model Class Initialized
INFO - 2016-02-12 11:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 11:38:29 --> Pagination Class Initialized
INFO - 2016-02-12 14:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 14:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 14:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 14:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 14:38:29 --> Final output sent to browser
DEBUG - 2016-02-12 14:38:29 --> Total execution time: 1.1202
INFO - 2016-02-12 11:55:11 --> Config Class Initialized
INFO - 2016-02-12 11:55:11 --> Hooks Class Initialized
DEBUG - 2016-02-12 11:55:11 --> UTF-8 Support Enabled
INFO - 2016-02-12 11:55:11 --> Utf8 Class Initialized
INFO - 2016-02-12 11:55:11 --> URI Class Initialized
INFO - 2016-02-12 11:55:11 --> Router Class Initialized
INFO - 2016-02-12 11:55:11 --> Output Class Initialized
INFO - 2016-02-12 11:55:11 --> Security Class Initialized
DEBUG - 2016-02-12 11:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 11:55:11 --> Input Class Initialized
INFO - 2016-02-12 11:55:11 --> Language Class Initialized
INFO - 2016-02-12 11:55:11 --> Loader Class Initialized
INFO - 2016-02-12 11:55:11 --> Helper loaded: url_helper
INFO - 2016-02-12 11:55:11 --> Helper loaded: file_helper
INFO - 2016-02-12 11:55:11 --> Helper loaded: date_helper
INFO - 2016-02-12 11:55:11 --> Helper loaded: form_helper
INFO - 2016-02-12 11:55:11 --> Database Driver Class Initialized
INFO - 2016-02-12 11:55:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 11:55:12 --> Controller Class Initialized
INFO - 2016-02-12 11:55:12 --> Model Class Initialized
INFO - 2016-02-12 11:55:12 --> Model Class Initialized
INFO - 2016-02-12 11:55:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 11:55:12 --> Pagination Class Initialized
ERROR - 2016-02-12 14:55:12 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 14:55:12 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:55:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:55:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:55:12 --> Severity: Error --> Call to a member function search() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
INFO - 2016-02-12 11:58:10 --> Config Class Initialized
INFO - 2016-02-12 11:58:10 --> Hooks Class Initialized
DEBUG - 2016-02-12 11:58:10 --> UTF-8 Support Enabled
INFO - 2016-02-12 11:58:10 --> Utf8 Class Initialized
INFO - 2016-02-12 11:58:10 --> URI Class Initialized
INFO - 2016-02-12 11:58:10 --> Router Class Initialized
INFO - 2016-02-12 11:58:10 --> Output Class Initialized
INFO - 2016-02-12 11:58:10 --> Security Class Initialized
DEBUG - 2016-02-12 11:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 11:58:10 --> Input Class Initialized
INFO - 2016-02-12 11:58:10 --> Language Class Initialized
INFO - 2016-02-12 11:58:10 --> Loader Class Initialized
INFO - 2016-02-12 11:58:10 --> Helper loaded: url_helper
INFO - 2016-02-12 11:58:10 --> Helper loaded: file_helper
INFO - 2016-02-12 11:58:10 --> Helper loaded: date_helper
INFO - 2016-02-12 11:58:10 --> Helper loaded: form_helper
INFO - 2016-02-12 11:58:10 --> Database Driver Class Initialized
INFO - 2016-02-12 11:58:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 11:58:11 --> Controller Class Initialized
INFO - 2016-02-12 11:58:11 --> Model Class Initialized
INFO - 2016-02-12 11:58:11 --> Model Class Initialized
INFO - 2016-02-12 11:58:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 11:58:11 --> Pagination Class Initialized
ERROR - 2016-02-12 14:58:11 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 14:58:11 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:58:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:58:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:58:11 --> Severity: Error --> Call to a member function search() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
INFO - 2016-02-12 11:58:15 --> Config Class Initialized
INFO - 2016-02-12 11:58:15 --> Hooks Class Initialized
DEBUG - 2016-02-12 11:58:15 --> UTF-8 Support Enabled
INFO - 2016-02-12 11:58:15 --> Utf8 Class Initialized
INFO - 2016-02-12 11:58:15 --> URI Class Initialized
INFO - 2016-02-12 11:58:15 --> Router Class Initialized
INFO - 2016-02-12 11:58:15 --> Output Class Initialized
INFO - 2016-02-12 11:58:15 --> Security Class Initialized
DEBUG - 2016-02-12 11:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 11:58:15 --> Input Class Initialized
INFO - 2016-02-12 11:58:15 --> Language Class Initialized
INFO - 2016-02-12 11:58:15 --> Loader Class Initialized
INFO - 2016-02-12 11:58:15 --> Helper loaded: url_helper
INFO - 2016-02-12 11:58:15 --> Helper loaded: file_helper
INFO - 2016-02-12 11:58:15 --> Helper loaded: date_helper
INFO - 2016-02-12 11:58:15 --> Helper loaded: form_helper
INFO - 2016-02-12 11:58:15 --> Database Driver Class Initialized
INFO - 2016-02-12 11:58:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 11:58:16 --> Controller Class Initialized
INFO - 2016-02-12 11:58:16 --> Model Class Initialized
INFO - 2016-02-12 11:58:16 --> Model Class Initialized
INFO - 2016-02-12 11:58:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 11:58:16 --> Pagination Class Initialized
INFO - 2016-02-12 14:58:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 14:58:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 14:58:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 14:58:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 14:58:16 --> Final output sent to browser
DEBUG - 2016-02-12 14:58:16 --> Total execution time: 1.1180
INFO - 2016-02-12 11:58:19 --> Config Class Initialized
INFO - 2016-02-12 11:58:19 --> Hooks Class Initialized
DEBUG - 2016-02-12 11:58:19 --> UTF-8 Support Enabled
INFO - 2016-02-12 11:58:19 --> Utf8 Class Initialized
INFO - 2016-02-12 11:58:19 --> URI Class Initialized
INFO - 2016-02-12 11:58:19 --> Router Class Initialized
INFO - 2016-02-12 11:58:19 --> Output Class Initialized
INFO - 2016-02-12 11:58:19 --> Security Class Initialized
DEBUG - 2016-02-12 11:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 11:58:19 --> Input Class Initialized
INFO - 2016-02-12 11:58:19 --> Language Class Initialized
INFO - 2016-02-12 11:58:19 --> Loader Class Initialized
INFO - 2016-02-12 11:58:19 --> Helper loaded: url_helper
INFO - 2016-02-12 11:58:19 --> Helper loaded: file_helper
INFO - 2016-02-12 11:58:19 --> Helper loaded: date_helper
INFO - 2016-02-12 11:58:19 --> Helper loaded: form_helper
INFO - 2016-02-12 11:58:19 --> Database Driver Class Initialized
INFO - 2016-02-12 11:58:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 11:58:20 --> Controller Class Initialized
INFO - 2016-02-12 11:58:20 --> Model Class Initialized
INFO - 2016-02-12 11:58:20 --> Model Class Initialized
INFO - 2016-02-12 11:58:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 11:58:20 --> Pagination Class Initialized
ERROR - 2016-02-12 14:58:20 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 14:58:21 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:58:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:58:21 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 14:58:21 --> Severity: Error --> Call to a member function search() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
INFO - 2016-02-12 12:01:30 --> Config Class Initialized
INFO - 2016-02-12 12:01:30 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:01:30 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:01:30 --> Utf8 Class Initialized
INFO - 2016-02-12 12:01:30 --> URI Class Initialized
INFO - 2016-02-12 12:01:30 --> Router Class Initialized
INFO - 2016-02-12 12:01:30 --> Output Class Initialized
INFO - 2016-02-12 12:01:30 --> Security Class Initialized
DEBUG - 2016-02-12 12:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:01:30 --> Input Class Initialized
INFO - 2016-02-12 12:01:30 --> Language Class Initialized
INFO - 2016-02-12 12:01:30 --> Loader Class Initialized
INFO - 2016-02-12 12:01:30 --> Helper loaded: url_helper
INFO - 2016-02-12 12:01:30 --> Helper loaded: file_helper
INFO - 2016-02-12 12:01:30 --> Helper loaded: date_helper
INFO - 2016-02-12 12:01:30 --> Helper loaded: form_helper
INFO - 2016-02-12 12:01:30 --> Database Driver Class Initialized
INFO - 2016-02-12 12:01:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:01:31 --> Controller Class Initialized
INFO - 2016-02-12 12:01:31 --> Model Class Initialized
INFO - 2016-02-12 12:01:31 --> Model Class Initialized
INFO - 2016-02-12 12:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:01:31 --> Pagination Class Initialized
INFO - 2016-02-12 15:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 15:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 15:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 15:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 15:01:31 --> Final output sent to browser
DEBUG - 2016-02-12 15:01:31 --> Total execution time: 1.1260
INFO - 2016-02-12 12:01:35 --> Config Class Initialized
INFO - 2016-02-12 12:01:35 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:01:35 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:01:35 --> Utf8 Class Initialized
INFO - 2016-02-12 12:01:35 --> URI Class Initialized
INFO - 2016-02-12 12:01:35 --> Router Class Initialized
INFO - 2016-02-12 12:01:35 --> Output Class Initialized
INFO - 2016-02-12 12:01:35 --> Security Class Initialized
DEBUG - 2016-02-12 12:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:01:35 --> Input Class Initialized
INFO - 2016-02-12 12:01:35 --> Language Class Initialized
INFO - 2016-02-12 12:01:35 --> Loader Class Initialized
INFO - 2016-02-12 12:01:35 --> Helper loaded: url_helper
INFO - 2016-02-12 12:01:35 --> Helper loaded: file_helper
INFO - 2016-02-12 12:01:35 --> Helper loaded: date_helper
INFO - 2016-02-12 12:01:35 --> Helper loaded: form_helper
INFO - 2016-02-12 12:01:35 --> Database Driver Class Initialized
INFO - 2016-02-12 12:01:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:01:36 --> Controller Class Initialized
INFO - 2016-02-12 12:01:36 --> Model Class Initialized
INFO - 2016-02-12 12:01:36 --> Model Class Initialized
INFO - 2016-02-12 12:01:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:01:36 --> Pagination Class Initialized
ERROR - 2016-02-12 15:01:36 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:01:36 --> Severity: Notice --> Undefined variable: search_terms C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 332
ERROR - 2016-02-12 15:01:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?) > 0' at line 3 - Invalid query: SELECT url, title
                    FROM pages
                    WHERE MATCH (content) AGAINST (?) > 0
INFO - 2016-02-12 15:01:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 12:02:35 --> Config Class Initialized
INFO - 2016-02-12 12:02:35 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:02:35 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:02:35 --> Utf8 Class Initialized
INFO - 2016-02-12 12:02:35 --> URI Class Initialized
INFO - 2016-02-12 12:02:35 --> Router Class Initialized
INFO - 2016-02-12 12:02:35 --> Output Class Initialized
INFO - 2016-02-12 12:02:35 --> Security Class Initialized
DEBUG - 2016-02-12 12:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:02:35 --> Input Class Initialized
INFO - 2016-02-12 12:02:35 --> Language Class Initialized
INFO - 2016-02-12 12:02:35 --> Loader Class Initialized
INFO - 2016-02-12 12:02:35 --> Helper loaded: url_helper
INFO - 2016-02-12 12:02:35 --> Helper loaded: file_helper
INFO - 2016-02-12 12:02:35 --> Helper loaded: date_helper
INFO - 2016-02-12 12:02:35 --> Helper loaded: form_helper
INFO - 2016-02-12 12:02:35 --> Database Driver Class Initialized
INFO - 2016-02-12 12:02:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:02:36 --> Controller Class Initialized
INFO - 2016-02-12 12:02:36 --> Model Class Initialized
INFO - 2016-02-12 12:02:36 --> Model Class Initialized
INFO - 2016-02-12 12:02:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:02:36 --> Pagination Class Initialized
INFO - 2016-02-12 15:02:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 15:02:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 15:02:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 15:02:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 15:02:36 --> Final output sent to browser
DEBUG - 2016-02-12 15:02:36 --> Total execution time: 1.1401
INFO - 2016-02-12 12:02:40 --> Config Class Initialized
INFO - 2016-02-12 12:02:40 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:02:40 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:02:40 --> Utf8 Class Initialized
INFO - 2016-02-12 12:02:40 --> URI Class Initialized
INFO - 2016-02-12 12:02:40 --> Router Class Initialized
INFO - 2016-02-12 12:02:40 --> Output Class Initialized
INFO - 2016-02-12 12:02:40 --> Security Class Initialized
DEBUG - 2016-02-12 12:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:02:40 --> Input Class Initialized
INFO - 2016-02-12 12:02:40 --> Language Class Initialized
INFO - 2016-02-12 12:02:40 --> Loader Class Initialized
INFO - 2016-02-12 12:02:40 --> Helper loaded: url_helper
INFO - 2016-02-12 12:02:40 --> Helper loaded: file_helper
INFO - 2016-02-12 12:02:40 --> Helper loaded: date_helper
INFO - 2016-02-12 12:02:40 --> Helper loaded: form_helper
INFO - 2016-02-12 12:02:40 --> Database Driver Class Initialized
INFO - 2016-02-12 12:02:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:02:41 --> Controller Class Initialized
INFO - 2016-02-12 12:02:41 --> Model Class Initialized
INFO - 2016-02-12 12:02:41 --> Model Class Initialized
INFO - 2016-02-12 12:02:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:02:41 --> Pagination Class Initialized
ERROR - 2016-02-12 15:02:41 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:02:41 --> Severity: Notice --> Undefined variable: search_terms C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 332
ERROR - 2016-02-12 15:02:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?) > 0' at line 3 - Invalid query: SELECT*
                    FROM jdmain
                    WHERE MATCH (content) AGAINST (?) > 0
INFO - 2016-02-12 15:02:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 12:21:50 --> Config Class Initialized
INFO - 2016-02-12 12:21:50 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:21:50 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:21:50 --> Utf8 Class Initialized
INFO - 2016-02-12 12:21:50 --> URI Class Initialized
DEBUG - 2016-02-12 12:21:50 --> No URI present. Default controller set.
INFO - 2016-02-12 12:21:50 --> Router Class Initialized
INFO - 2016-02-12 12:21:50 --> Output Class Initialized
INFO - 2016-02-12 12:21:50 --> Security Class Initialized
DEBUG - 2016-02-12 12:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:21:50 --> Input Class Initialized
INFO - 2016-02-12 12:21:50 --> Language Class Initialized
INFO - 2016-02-12 12:21:50 --> Loader Class Initialized
INFO - 2016-02-12 12:21:50 --> Helper loaded: url_helper
INFO - 2016-02-12 12:21:50 --> Helper loaded: file_helper
INFO - 2016-02-12 12:21:50 --> Helper loaded: date_helper
INFO - 2016-02-12 12:21:50 --> Helper loaded: form_helper
INFO - 2016-02-12 12:21:50 --> Database Driver Class Initialized
INFO - 2016-02-12 12:21:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:21:51 --> Controller Class Initialized
INFO - 2016-02-12 12:21:51 --> Model Class Initialized
ERROR - 2016-02-12 12:21:51 --> Severity: Parsing Error --> syntax error, unexpected '$terms' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 177
INFO - 2016-02-12 12:23:25 --> Config Class Initialized
INFO - 2016-02-12 12:23:25 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:23:25 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:23:25 --> Utf8 Class Initialized
INFO - 2016-02-12 12:23:25 --> URI Class Initialized
DEBUG - 2016-02-12 12:23:25 --> No URI present. Default controller set.
INFO - 2016-02-12 12:23:25 --> Router Class Initialized
INFO - 2016-02-12 12:23:25 --> Output Class Initialized
INFO - 2016-02-12 12:23:25 --> Security Class Initialized
DEBUG - 2016-02-12 12:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:23:25 --> Input Class Initialized
INFO - 2016-02-12 12:23:25 --> Language Class Initialized
INFO - 2016-02-12 12:23:25 --> Loader Class Initialized
INFO - 2016-02-12 12:23:25 --> Helper loaded: url_helper
INFO - 2016-02-12 12:23:25 --> Helper loaded: file_helper
INFO - 2016-02-12 12:23:25 --> Helper loaded: date_helper
INFO - 2016-02-12 12:23:25 --> Helper loaded: form_helper
INFO - 2016-02-12 12:23:25 --> Database Driver Class Initialized
INFO - 2016-02-12 12:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:23:26 --> Controller Class Initialized
INFO - 2016-02-12 12:23:26 --> Model Class Initialized
INFO - 2016-02-12 12:23:26 --> Model Class Initialized
INFO - 2016-02-12 12:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:23:26 --> Pagination Class Initialized
INFO - 2016-02-12 15:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 15:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 15:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 15:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 15:23:26 --> Final output sent to browser
DEBUG - 2016-02-12 15:23:26 --> Total execution time: 1.1001
INFO - 2016-02-12 12:23:30 --> Config Class Initialized
INFO - 2016-02-12 12:23:30 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:23:30 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:23:30 --> Utf8 Class Initialized
INFO - 2016-02-12 12:23:30 --> URI Class Initialized
INFO - 2016-02-12 12:23:30 --> Router Class Initialized
INFO - 2016-02-12 12:23:30 --> Output Class Initialized
INFO - 2016-02-12 12:23:30 --> Security Class Initialized
DEBUG - 2016-02-12 12:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:23:30 --> Input Class Initialized
INFO - 2016-02-12 12:23:30 --> Language Class Initialized
INFO - 2016-02-12 12:23:30 --> Loader Class Initialized
INFO - 2016-02-12 12:23:30 --> Helper loaded: url_helper
INFO - 2016-02-12 12:23:30 --> Helper loaded: file_helper
INFO - 2016-02-12 12:23:30 --> Helper loaded: date_helper
INFO - 2016-02-12 12:23:30 --> Helper loaded: form_helper
INFO - 2016-02-12 12:23:30 --> Database Driver Class Initialized
INFO - 2016-02-12 12:23:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:23:31 --> Controller Class Initialized
INFO - 2016-02-12 12:23:31 --> Model Class Initialized
INFO - 2016-02-12 12:23:31 --> Model Class Initialized
INFO - 2016-02-12 12:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:23:31 --> Pagination Class Initialized
ERROR - 2016-02-12 15:23:31 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:23:31 --> Severity: Notice --> Undefined variable: search_terms C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 332
ERROR - 2016-02-12 15:23:31 --> Query error: Can't find FULLTEXT index matching the column list - Invalid query: SELECT*
                    FROM jdmain
                    WHERE MATCH (jdmain.description,jdmain.title) AGAINST ('..')
INFO - 2016-02-12 15:23:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 12:25:49 --> Config Class Initialized
INFO - 2016-02-12 12:25:49 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:25:49 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:25:49 --> Utf8 Class Initialized
INFO - 2016-02-12 12:25:49 --> URI Class Initialized
INFO - 2016-02-12 12:25:49 --> Router Class Initialized
INFO - 2016-02-12 12:25:49 --> Output Class Initialized
INFO - 2016-02-12 12:25:49 --> Security Class Initialized
DEBUG - 2016-02-12 12:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:25:49 --> Input Class Initialized
INFO - 2016-02-12 12:25:49 --> Language Class Initialized
INFO - 2016-02-12 12:25:49 --> Loader Class Initialized
INFO - 2016-02-12 12:25:49 --> Helper loaded: url_helper
INFO - 2016-02-12 12:25:49 --> Helper loaded: file_helper
INFO - 2016-02-12 12:25:49 --> Helper loaded: date_helper
INFO - 2016-02-12 12:25:49 --> Helper loaded: form_helper
INFO - 2016-02-12 12:25:49 --> Database Driver Class Initialized
INFO - 2016-02-12 12:25:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:25:50 --> Controller Class Initialized
INFO - 2016-02-12 12:25:50 --> Model Class Initialized
INFO - 2016-02-12 12:25:50 --> Model Class Initialized
INFO - 2016-02-12 12:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:25:50 --> Pagination Class Initialized
ERROR - 2016-02-12 15:25:50 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:25:50 --> Severity: Notice --> Undefined variable: search_terms C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 332
ERROR - 2016-02-12 15:25:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '?) > 0' at line 3 - Invalid query: SELECT*
                    FROM jdmain
                    WHERE MATCH (jdmain.description,jdmain.title) AGAINST (?) > 0
INFO - 2016-02-12 15:25:50 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 12:28:08 --> Config Class Initialized
INFO - 2016-02-12 12:28:08 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:28:08 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:28:08 --> Utf8 Class Initialized
INFO - 2016-02-12 12:28:08 --> URI Class Initialized
INFO - 2016-02-12 12:28:08 --> Router Class Initialized
INFO - 2016-02-12 12:28:08 --> Output Class Initialized
INFO - 2016-02-12 12:28:08 --> Security Class Initialized
DEBUG - 2016-02-12 12:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:28:08 --> Input Class Initialized
INFO - 2016-02-12 12:28:08 --> Language Class Initialized
INFO - 2016-02-12 12:28:08 --> Loader Class Initialized
INFO - 2016-02-12 12:28:08 --> Helper loaded: url_helper
INFO - 2016-02-12 12:28:08 --> Helper loaded: file_helper
INFO - 2016-02-12 12:28:08 --> Helper loaded: date_helper
INFO - 2016-02-12 12:28:08 --> Helper loaded: form_helper
INFO - 2016-02-12 12:28:09 --> Database Driver Class Initialized
INFO - 2016-02-12 12:28:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:28:10 --> Controller Class Initialized
INFO - 2016-02-12 12:28:10 --> Model Class Initialized
INFO - 2016-02-12 12:28:10 --> Model Class Initialized
INFO - 2016-02-12 12:28:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:28:10 --> Pagination Class Initialized
INFO - 2016-02-12 15:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 15:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 15:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 15:28:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 15:28:10 --> Final output sent to browser
DEBUG - 2016-02-12 15:28:10 --> Total execution time: 1.1178
INFO - 2016-02-12 12:28:13 --> Config Class Initialized
INFO - 2016-02-12 12:28:13 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:28:13 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:28:13 --> Utf8 Class Initialized
INFO - 2016-02-12 12:28:13 --> URI Class Initialized
INFO - 2016-02-12 12:28:13 --> Router Class Initialized
INFO - 2016-02-12 12:28:13 --> Output Class Initialized
INFO - 2016-02-12 12:28:13 --> Security Class Initialized
DEBUG - 2016-02-12 12:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:28:13 --> Input Class Initialized
INFO - 2016-02-12 12:28:13 --> Language Class Initialized
INFO - 2016-02-12 12:28:13 --> Loader Class Initialized
INFO - 2016-02-12 12:28:13 --> Helper loaded: url_helper
INFO - 2016-02-12 12:28:13 --> Helper loaded: file_helper
INFO - 2016-02-12 12:28:13 --> Helper loaded: date_helper
INFO - 2016-02-12 12:28:13 --> Helper loaded: form_helper
INFO - 2016-02-12 12:28:13 --> Database Driver Class Initialized
INFO - 2016-02-12 12:28:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:28:14 --> Controller Class Initialized
INFO - 2016-02-12 12:28:14 --> Model Class Initialized
INFO - 2016-02-12 12:28:14 --> Model Class Initialized
INFO - 2016-02-12 12:28:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:28:14 --> Pagination Class Initialized
ERROR - 2016-02-12 15:28:14 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:28:14 --> Severity: Notice --> Undefined variable: search_terms C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 332
ERROR - 2016-02-12 15:28:14 --> Query error: Can't find FULLTEXT index matching the column list - Invalid query: SELECT*
                    FROM jdmain
                    WHERE MATCH (jdmain.description,jdmain.title) AGAINST (''in boolean mode) > 0
INFO - 2016-02-12 15:28:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 12:39:06 --> Config Class Initialized
INFO - 2016-02-12 12:39:06 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:39:06 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:39:06 --> Utf8 Class Initialized
INFO - 2016-02-12 12:39:06 --> URI Class Initialized
INFO - 2016-02-12 12:39:06 --> Router Class Initialized
INFO - 2016-02-12 12:39:06 --> Output Class Initialized
INFO - 2016-02-12 12:39:06 --> Security Class Initialized
DEBUG - 2016-02-12 12:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:39:06 --> Input Class Initialized
INFO - 2016-02-12 12:39:06 --> Language Class Initialized
INFO - 2016-02-12 12:39:07 --> Loader Class Initialized
INFO - 2016-02-12 12:39:07 --> Helper loaded: url_helper
INFO - 2016-02-12 12:39:07 --> Helper loaded: file_helper
INFO - 2016-02-12 12:39:07 --> Helper loaded: date_helper
INFO - 2016-02-12 12:39:07 --> Helper loaded: form_helper
INFO - 2016-02-12 12:39:07 --> Database Driver Class Initialized
INFO - 2016-02-12 12:39:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:39:08 --> Controller Class Initialized
INFO - 2016-02-12 12:39:08 --> Model Class Initialized
INFO - 2016-02-12 12:39:08 --> Model Class Initialized
INFO - 2016-02-12 12:39:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:39:08 --> Pagination Class Initialized
INFO - 2016-02-12 15:39:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 15:39:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 15:39:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 15:39:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 15:39:08 --> Final output sent to browser
DEBUG - 2016-02-12 15:39:08 --> Total execution time: 1.1217
INFO - 2016-02-12 12:39:11 --> Config Class Initialized
INFO - 2016-02-12 12:39:11 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:39:11 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:39:11 --> Utf8 Class Initialized
INFO - 2016-02-12 12:39:11 --> URI Class Initialized
INFO - 2016-02-12 12:39:11 --> Router Class Initialized
INFO - 2016-02-12 12:39:11 --> Output Class Initialized
INFO - 2016-02-12 12:39:11 --> Security Class Initialized
DEBUG - 2016-02-12 12:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:39:11 --> Input Class Initialized
INFO - 2016-02-12 12:39:11 --> Language Class Initialized
INFO - 2016-02-12 12:39:11 --> Loader Class Initialized
INFO - 2016-02-12 12:39:11 --> Helper loaded: url_helper
INFO - 2016-02-12 12:39:11 --> Helper loaded: file_helper
INFO - 2016-02-12 12:39:11 --> Helper loaded: date_helper
INFO - 2016-02-12 12:39:11 --> Helper loaded: form_helper
INFO - 2016-02-12 12:39:11 --> Database Driver Class Initialized
INFO - 2016-02-12 12:39:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:39:12 --> Controller Class Initialized
INFO - 2016-02-12 12:39:12 --> Model Class Initialized
INFO - 2016-02-12 12:39:12 --> Model Class Initialized
INFO - 2016-02-12 12:39:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:39:12 --> Pagination Class Initialized
ERROR - 2016-02-12 15:39:12 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:39:12 --> Severity: Notice --> Undefined variable: search_terms C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 332
ERROR - 2016-02-12 15:39:12 --> Query error: Can't find FULLTEXT index matching the column list - Invalid query: SELECT*
                    FROM jdmain
                    WHERE MATCH (jdmain.description,jdmain.title) AGAINST (''in boolean mode) > 0
INFO - 2016-02-12 15:39:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 12:45:35 --> Config Class Initialized
INFO - 2016-02-12 12:45:35 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:45:35 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:45:35 --> Utf8 Class Initialized
INFO - 2016-02-12 12:45:35 --> URI Class Initialized
INFO - 2016-02-12 12:45:35 --> Router Class Initialized
INFO - 2016-02-12 12:45:35 --> Output Class Initialized
INFO - 2016-02-12 12:45:35 --> Security Class Initialized
DEBUG - 2016-02-12 12:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:45:35 --> Input Class Initialized
INFO - 2016-02-12 12:45:35 --> Language Class Initialized
INFO - 2016-02-12 12:45:35 --> Loader Class Initialized
INFO - 2016-02-12 12:45:35 --> Helper loaded: url_helper
INFO - 2016-02-12 12:45:35 --> Helper loaded: file_helper
INFO - 2016-02-12 12:45:35 --> Helper loaded: date_helper
INFO - 2016-02-12 12:45:35 --> Helper loaded: form_helper
INFO - 2016-02-12 12:45:35 --> Database Driver Class Initialized
INFO - 2016-02-12 12:45:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:45:36 --> Controller Class Initialized
INFO - 2016-02-12 12:45:36 --> Model Class Initialized
INFO - 2016-02-12 12:45:36 --> Model Class Initialized
INFO - 2016-02-12 12:45:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:45:36 --> Pagination Class Initialized
ERROR - 2016-02-12 15:45:36 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:45:36 --> Severity: Notice --> Undefined variable: search_terms C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 332
ERROR - 2016-02-12 15:45:36 --> Query error: Can't find FULLTEXT index matching the column list - Invalid query: SELECT*
                    FROM jdmain
                    WHERE MATCH (jdmain.description,jdmain.title) AGAINST (''in boolean mode) > 0
INFO - 2016-02-12 15:45:36 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 12:46:32 --> Config Class Initialized
INFO - 2016-02-12 12:46:32 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:46:32 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:46:32 --> Utf8 Class Initialized
INFO - 2016-02-12 12:46:32 --> URI Class Initialized
INFO - 2016-02-12 12:46:32 --> Router Class Initialized
INFO - 2016-02-12 12:46:32 --> Output Class Initialized
INFO - 2016-02-12 12:46:32 --> Security Class Initialized
DEBUG - 2016-02-12 12:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:46:32 --> Input Class Initialized
INFO - 2016-02-12 12:46:32 --> Language Class Initialized
INFO - 2016-02-12 12:46:32 --> Loader Class Initialized
INFO - 2016-02-12 12:46:32 --> Helper loaded: url_helper
INFO - 2016-02-12 12:46:32 --> Helper loaded: file_helper
INFO - 2016-02-12 12:46:32 --> Helper loaded: date_helper
INFO - 2016-02-12 12:46:32 --> Helper loaded: form_helper
INFO - 2016-02-12 12:46:32 --> Database Driver Class Initialized
INFO - 2016-02-12 12:46:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:46:33 --> Controller Class Initialized
INFO - 2016-02-12 12:46:33 --> Model Class Initialized
INFO - 2016-02-12 12:46:33 --> Model Class Initialized
INFO - 2016-02-12 12:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:46:33 --> Pagination Class Initialized
ERROR - 2016-02-12 15:46:33 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:46:33 --> Severity: Notice --> Undefined variable: p C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 15:46:33 --> Query error: Can't find FULLTEXT index matching the column list - Invalid query: SELECT*
                    FROM jdmain
                    WHERE MATCH (jdmain.description,jdmain.title) AGAINST (''in boolean mode) > 0
INFO - 2016-02-12 15:46:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 12:53:05 --> Config Class Initialized
INFO - 2016-02-12 12:53:05 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:53:05 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:53:05 --> Utf8 Class Initialized
INFO - 2016-02-12 12:53:05 --> URI Class Initialized
INFO - 2016-02-12 12:53:05 --> Router Class Initialized
INFO - 2016-02-12 12:53:05 --> Output Class Initialized
INFO - 2016-02-12 12:53:05 --> Security Class Initialized
DEBUG - 2016-02-12 12:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:53:05 --> Input Class Initialized
INFO - 2016-02-12 12:53:05 --> Language Class Initialized
INFO - 2016-02-12 12:53:05 --> Loader Class Initialized
INFO - 2016-02-12 12:53:05 --> Helper loaded: url_helper
INFO - 2016-02-12 12:53:05 --> Helper loaded: file_helper
INFO - 2016-02-12 12:53:05 --> Helper loaded: date_helper
INFO - 2016-02-12 12:53:05 --> Helper loaded: form_helper
INFO - 2016-02-12 12:53:05 --> Database Driver Class Initialized
INFO - 2016-02-12 12:53:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:53:06 --> Controller Class Initialized
INFO - 2016-02-12 12:53:06 --> Model Class Initialized
INFO - 2016-02-12 12:53:06 --> Model Class Initialized
INFO - 2016-02-12 12:53:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:53:06 --> Pagination Class Initialized
INFO - 2016-02-12 15:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 15:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 15:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 15:53:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 15:53:06 --> Final output sent to browser
DEBUG - 2016-02-12 15:53:06 --> Total execution time: 1.1134
INFO - 2016-02-12 12:53:10 --> Config Class Initialized
INFO - 2016-02-12 12:53:10 --> Hooks Class Initialized
DEBUG - 2016-02-12 12:53:10 --> UTF-8 Support Enabled
INFO - 2016-02-12 12:53:10 --> Utf8 Class Initialized
INFO - 2016-02-12 12:53:10 --> URI Class Initialized
INFO - 2016-02-12 12:53:10 --> Router Class Initialized
INFO - 2016-02-12 12:53:10 --> Output Class Initialized
INFO - 2016-02-12 12:53:10 --> Security Class Initialized
DEBUG - 2016-02-12 12:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 12:53:10 --> Input Class Initialized
INFO - 2016-02-12 12:53:10 --> Language Class Initialized
INFO - 2016-02-12 12:53:10 --> Loader Class Initialized
INFO - 2016-02-12 12:53:10 --> Helper loaded: url_helper
INFO - 2016-02-12 12:53:10 --> Helper loaded: file_helper
INFO - 2016-02-12 12:53:10 --> Helper loaded: date_helper
INFO - 2016-02-12 12:53:10 --> Helper loaded: form_helper
INFO - 2016-02-12 12:53:10 --> Database Driver Class Initialized
INFO - 2016-02-12 12:53:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 12:53:11 --> Controller Class Initialized
INFO - 2016-02-12 12:53:11 --> Model Class Initialized
INFO - 2016-02-12 12:53:11 --> Model Class Initialized
INFO - 2016-02-12 12:53:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 12:53:11 --> Pagination Class Initialized
ERROR - 2016-02-12 15:53:11 --> Severity: Warning --> Missing argument 1 for Jboard::search() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 327
ERROR - 2016-02-12 15:53:11 --> Severity: Notice --> Undefined variable: p C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
ERROR - 2016-02-12 15:53:11 --> Query error: Can't find FULLTEXT index matching the column list - Invalid query: SELECT*
                    FROM jdmain
                    WHERE MATCH (jdmain.description,jdmain.title) AGAINST (''in boolean mode) > 0
INFO - 2016-02-12 15:53:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-12 13:02:16 --> Config Class Initialized
INFO - 2016-02-12 13:02:16 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:02:16 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:02:16 --> Utf8 Class Initialized
INFO - 2016-02-12 13:02:16 --> URI Class Initialized
INFO - 2016-02-12 13:02:16 --> Router Class Initialized
INFO - 2016-02-12 13:02:16 --> Output Class Initialized
INFO - 2016-02-12 13:02:16 --> Security Class Initialized
DEBUG - 2016-02-12 13:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:02:16 --> Input Class Initialized
INFO - 2016-02-12 13:02:16 --> Language Class Initialized
ERROR - 2016-02-12 13:02:16 --> 404 Page Not Found: Jboard/search_test
INFO - 2016-02-12 13:02:35 --> Config Class Initialized
INFO - 2016-02-12 13:02:35 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:02:35 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:02:35 --> Utf8 Class Initialized
INFO - 2016-02-12 13:02:35 --> URI Class Initialized
INFO - 2016-02-12 13:02:35 --> Router Class Initialized
INFO - 2016-02-12 13:02:35 --> Output Class Initialized
INFO - 2016-02-12 13:02:35 --> Security Class Initialized
DEBUG - 2016-02-12 13:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:02:35 --> Input Class Initialized
INFO - 2016-02-12 13:02:35 --> Language Class Initialized
ERROR - 2016-02-12 13:02:35 --> 404 Page Not Found: Jboard/search_test
INFO - 2016-02-12 13:02:39 --> Config Class Initialized
INFO - 2016-02-12 13:02:39 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:02:39 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:02:39 --> Utf8 Class Initialized
INFO - 2016-02-12 13:02:39 --> URI Class Initialized
INFO - 2016-02-12 13:02:39 --> Router Class Initialized
INFO - 2016-02-12 13:02:39 --> Output Class Initialized
INFO - 2016-02-12 13:02:39 --> Security Class Initialized
DEBUG - 2016-02-12 13:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:02:39 --> Input Class Initialized
INFO - 2016-02-12 13:02:39 --> Language Class Initialized
ERROR - 2016-02-12 13:02:39 --> 404 Page Not Found: Jboard/search_test
INFO - 2016-02-12 13:02:40 --> Config Class Initialized
INFO - 2016-02-12 13:02:40 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:02:40 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:02:40 --> Utf8 Class Initialized
INFO - 2016-02-12 13:02:40 --> URI Class Initialized
INFO - 2016-02-12 13:02:40 --> Router Class Initialized
INFO - 2016-02-12 13:02:40 --> Output Class Initialized
INFO - 2016-02-12 13:02:40 --> Security Class Initialized
DEBUG - 2016-02-12 13:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:02:40 --> Input Class Initialized
INFO - 2016-02-12 13:02:40 --> Language Class Initialized
ERROR - 2016-02-12 13:02:40 --> 404 Page Not Found: Jboard/search_test
INFO - 2016-02-12 13:43:04 --> Config Class Initialized
INFO - 2016-02-12 13:43:04 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:43:04 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:43:04 --> Utf8 Class Initialized
INFO - 2016-02-12 13:43:04 --> URI Class Initialized
DEBUG - 2016-02-12 13:43:04 --> No URI present. Default controller set.
INFO - 2016-02-12 13:43:04 --> Router Class Initialized
INFO - 2016-02-12 13:43:05 --> Output Class Initialized
INFO - 2016-02-12 13:43:05 --> Security Class Initialized
DEBUG - 2016-02-12 13:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:43:05 --> Input Class Initialized
INFO - 2016-02-12 13:43:05 --> Language Class Initialized
ERROR - 2016-02-12 13:43:05 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 330
INFO - 2016-02-12 13:43:26 --> Config Class Initialized
INFO - 2016-02-12 13:43:26 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:43:26 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:43:26 --> Utf8 Class Initialized
INFO - 2016-02-12 13:43:26 --> URI Class Initialized
DEBUG - 2016-02-12 13:43:26 --> No URI present. Default controller set.
INFO - 2016-02-12 13:43:26 --> Router Class Initialized
INFO - 2016-02-12 13:43:26 --> Output Class Initialized
INFO - 2016-02-12 13:43:26 --> Security Class Initialized
DEBUG - 2016-02-12 13:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:43:26 --> Input Class Initialized
INFO - 2016-02-12 13:43:26 --> Language Class Initialized
INFO - 2016-02-12 13:43:26 --> Loader Class Initialized
INFO - 2016-02-12 13:43:26 --> Helper loaded: url_helper
INFO - 2016-02-12 13:43:26 --> Helper loaded: file_helper
INFO - 2016-02-12 13:43:26 --> Helper loaded: date_helper
INFO - 2016-02-12 13:43:26 --> Helper loaded: form_helper
INFO - 2016-02-12 13:43:26 --> Database Driver Class Initialized
INFO - 2016-02-12 13:43:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 13:43:27 --> Controller Class Initialized
INFO - 2016-02-12 13:43:27 --> Model Class Initialized
INFO - 2016-02-12 13:43:27 --> Model Class Initialized
INFO - 2016-02-12 13:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 13:43:27 --> Pagination Class Initialized
INFO - 2016-02-12 16:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 16:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 16:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 16:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 16:43:27 --> Final output sent to browser
DEBUG - 2016-02-12 16:43:27 --> Total execution time: 1.1067
INFO - 2016-02-12 13:43:31 --> Config Class Initialized
INFO - 2016-02-12 13:43:31 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:43:31 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:43:31 --> Utf8 Class Initialized
INFO - 2016-02-12 13:43:31 --> URI Class Initialized
INFO - 2016-02-12 13:43:31 --> Router Class Initialized
INFO - 2016-02-12 13:43:31 --> Output Class Initialized
INFO - 2016-02-12 13:43:31 --> Security Class Initialized
DEBUG - 2016-02-12 13:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:43:31 --> Input Class Initialized
INFO - 2016-02-12 13:43:31 --> Language Class Initialized
INFO - 2016-02-12 13:43:31 --> Loader Class Initialized
INFO - 2016-02-12 13:43:31 --> Helper loaded: url_helper
INFO - 2016-02-12 13:43:31 --> Helper loaded: file_helper
INFO - 2016-02-12 13:43:31 --> Helper loaded: date_helper
INFO - 2016-02-12 13:43:31 --> Helper loaded: form_helper
INFO - 2016-02-12 13:43:31 --> Database Driver Class Initialized
INFO - 2016-02-12 13:43:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 13:43:32 --> Controller Class Initialized
INFO - 2016-02-12 13:43:32 --> Model Class Initialized
INFO - 2016-02-12 13:43:32 --> Model Class Initialized
INFO - 2016-02-12 13:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 13:43:32 --> Pagination Class Initialized
ERROR - 2016-02-12 16:43:32 --> Query error: Not unique table/alias: 'jdmain' - Invalid query: SELECT *
FROM `jdmain`, `jdmain`
WHERE `title` LIKE '%minion%' ESCAPE '!'
INFO - 2016-02-12 16:43:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-12 16:43:32 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455313412
WHERE `title` LIKE '%minion%' ESCAPE '!'
AND `id` = '20f58693a0143c39939c0f54abccb279b834532d'
INFO - 2016-02-12 13:47:17 --> Config Class Initialized
INFO - 2016-02-12 13:47:17 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:47:17 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:47:17 --> Utf8 Class Initialized
INFO - 2016-02-12 13:47:17 --> URI Class Initialized
INFO - 2016-02-12 13:47:17 --> Router Class Initialized
INFO - 2016-02-12 13:47:18 --> Output Class Initialized
INFO - 2016-02-12 13:47:18 --> Security Class Initialized
DEBUG - 2016-02-12 13:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:47:18 --> Input Class Initialized
INFO - 2016-02-12 13:47:18 --> Language Class Initialized
INFO - 2016-02-12 13:47:18 --> Loader Class Initialized
INFO - 2016-02-12 13:47:18 --> Helper loaded: url_helper
INFO - 2016-02-12 13:47:18 --> Helper loaded: file_helper
INFO - 2016-02-12 13:47:18 --> Helper loaded: date_helper
INFO - 2016-02-12 13:47:18 --> Helper loaded: form_helper
INFO - 2016-02-12 13:47:18 --> Database Driver Class Initialized
INFO - 2016-02-12 13:47:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 13:47:19 --> Controller Class Initialized
INFO - 2016-02-12 13:47:19 --> Model Class Initialized
INFO - 2016-02-12 13:47:19 --> Model Class Initialized
INFO - 2016-02-12 13:47:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 13:47:19 --> Pagination Class Initialized
INFO - 2016-02-12 16:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 16:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 16:47:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-12 16:47:19 --> Final output sent to browser
DEBUG - 2016-02-12 16:47:19 --> Total execution time: 1.1262
INFO - 2016-02-12 13:49:29 --> Config Class Initialized
INFO - 2016-02-12 13:49:29 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:49:29 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:49:29 --> Utf8 Class Initialized
INFO - 2016-02-12 13:49:29 --> URI Class Initialized
DEBUG - 2016-02-12 13:49:29 --> No URI present. Default controller set.
INFO - 2016-02-12 13:49:29 --> Router Class Initialized
INFO - 2016-02-12 13:49:29 --> Output Class Initialized
INFO - 2016-02-12 13:49:29 --> Security Class Initialized
DEBUG - 2016-02-12 13:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:49:29 --> Input Class Initialized
INFO - 2016-02-12 13:49:29 --> Language Class Initialized
INFO - 2016-02-12 13:49:29 --> Loader Class Initialized
INFO - 2016-02-12 13:49:29 --> Helper loaded: url_helper
INFO - 2016-02-12 13:49:29 --> Helper loaded: file_helper
INFO - 2016-02-12 13:49:29 --> Helper loaded: date_helper
INFO - 2016-02-12 13:49:29 --> Helper loaded: form_helper
INFO - 2016-02-12 13:49:29 --> Database Driver Class Initialized
INFO - 2016-02-12 13:49:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 13:49:30 --> Controller Class Initialized
INFO - 2016-02-12 13:49:30 --> Model Class Initialized
INFO - 2016-02-12 13:49:30 --> Model Class Initialized
INFO - 2016-02-12 13:49:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 13:49:30 --> Pagination Class Initialized
INFO - 2016-02-12 16:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 16:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 16:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 16:49:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 16:49:30 --> Final output sent to browser
DEBUG - 2016-02-12 16:49:30 --> Total execution time: 1.1442
INFO - 2016-02-12 13:49:41 --> Config Class Initialized
INFO - 2016-02-12 13:49:41 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:49:41 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:49:41 --> Utf8 Class Initialized
INFO - 2016-02-12 13:49:41 --> URI Class Initialized
INFO - 2016-02-12 13:49:41 --> Router Class Initialized
INFO - 2016-02-12 13:49:41 --> Output Class Initialized
INFO - 2016-02-12 13:49:41 --> Security Class Initialized
DEBUG - 2016-02-12 13:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:49:41 --> Input Class Initialized
INFO - 2016-02-12 13:49:41 --> Language Class Initialized
INFO - 2016-02-12 13:49:41 --> Loader Class Initialized
INFO - 2016-02-12 13:49:41 --> Helper loaded: url_helper
INFO - 2016-02-12 13:49:41 --> Helper loaded: file_helper
INFO - 2016-02-12 13:49:41 --> Helper loaded: date_helper
INFO - 2016-02-12 13:49:41 --> Helper loaded: form_helper
INFO - 2016-02-12 13:49:41 --> Database Driver Class Initialized
INFO - 2016-02-12 13:49:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 13:49:42 --> Controller Class Initialized
INFO - 2016-02-12 13:49:42 --> Model Class Initialized
INFO - 2016-02-12 13:49:42 --> Model Class Initialized
INFO - 2016-02-12 13:49:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 13:49:42 --> Pagination Class Initialized
INFO - 2016-02-12 16:49:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 16:49:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 16:49:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
ERROR - 2016-02-12 16:49:42 --> Severity: Error --> Call to undefined function character_limiter() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 9
INFO - 2016-02-12 13:51:05 --> Config Class Initialized
INFO - 2016-02-12 13:51:05 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:51:05 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:51:05 --> Utf8 Class Initialized
INFO - 2016-02-12 13:51:05 --> URI Class Initialized
INFO - 2016-02-12 13:51:05 --> Router Class Initialized
INFO - 2016-02-12 13:51:05 --> Output Class Initialized
INFO - 2016-02-12 13:51:05 --> Security Class Initialized
DEBUG - 2016-02-12 13:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:51:05 --> Input Class Initialized
INFO - 2016-02-12 13:51:05 --> Language Class Initialized
INFO - 2016-02-12 13:51:05 --> Loader Class Initialized
INFO - 2016-02-12 13:51:05 --> Helper loaded: url_helper
INFO - 2016-02-12 13:51:05 --> Helper loaded: file_helper
INFO - 2016-02-12 13:51:05 --> Helper loaded: date_helper
INFO - 2016-02-12 13:51:05 --> Helper loaded: form_helper
INFO - 2016-02-12 13:51:05 --> Database Driver Class Initialized
INFO - 2016-02-12 13:51:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 13:51:06 --> Controller Class Initialized
INFO - 2016-02-12 13:51:06 --> Model Class Initialized
INFO - 2016-02-12 13:51:06 --> Model Class Initialized
INFO - 2016-02-12 13:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 13:51:06 --> Pagination Class Initialized
INFO - 2016-02-12 16:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 16:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 16:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
ERROR - 2016-02-12 16:51:06 --> Severity: Error --> Call to undefined function character_limiter() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php 9
INFO - 2016-02-12 13:52:26 --> Config Class Initialized
INFO - 2016-02-12 13:52:26 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:52:26 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:52:26 --> Utf8 Class Initialized
INFO - 2016-02-12 13:52:26 --> URI Class Initialized
INFO - 2016-02-12 13:52:26 --> Router Class Initialized
INFO - 2016-02-12 13:52:26 --> Output Class Initialized
INFO - 2016-02-12 13:52:26 --> Security Class Initialized
DEBUG - 2016-02-12 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:52:26 --> Input Class Initialized
INFO - 2016-02-12 13:52:26 --> Language Class Initialized
INFO - 2016-02-12 13:52:26 --> Loader Class Initialized
INFO - 2016-02-12 13:52:26 --> Helper loaded: url_helper
INFO - 2016-02-12 13:52:26 --> Helper loaded: file_helper
INFO - 2016-02-12 13:52:26 --> Helper loaded: date_helper
INFO - 2016-02-12 13:52:26 --> Helper loaded: form_helper
INFO - 2016-02-12 13:52:26 --> Database Driver Class Initialized
INFO - 2016-02-12 13:52:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 13:52:27 --> Controller Class Initialized
INFO - 2016-02-12 13:52:27 --> Model Class Initialized
INFO - 2016-02-12 13:52:27 --> Model Class Initialized
INFO - 2016-02-12 13:52:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 13:52:27 --> Pagination Class Initialized
INFO - 2016-02-12 13:52:27 --> Helper loaded: text_helper
INFO - 2016-02-12 16:52:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 16:52:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 16:52:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 16:52:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 16:52:27 --> Final output sent to browser
DEBUG - 2016-02-12 16:52:27 --> Total execution time: 1.1562
INFO - 2016-02-12 13:52:31 --> Config Class Initialized
INFO - 2016-02-12 13:52:31 --> Hooks Class Initialized
DEBUG - 2016-02-12 13:52:31 --> UTF-8 Support Enabled
INFO - 2016-02-12 13:52:31 --> Utf8 Class Initialized
INFO - 2016-02-12 13:52:31 --> URI Class Initialized
INFO - 2016-02-12 13:52:31 --> Router Class Initialized
INFO - 2016-02-12 13:52:31 --> Output Class Initialized
INFO - 2016-02-12 13:52:31 --> Security Class Initialized
DEBUG - 2016-02-12 13:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 13:52:31 --> Input Class Initialized
INFO - 2016-02-12 13:52:31 --> Language Class Initialized
INFO - 2016-02-12 13:52:31 --> Loader Class Initialized
INFO - 2016-02-12 13:52:31 --> Helper loaded: url_helper
INFO - 2016-02-12 13:52:31 --> Helper loaded: file_helper
INFO - 2016-02-12 13:52:31 --> Helper loaded: date_helper
INFO - 2016-02-12 13:52:31 --> Helper loaded: form_helper
INFO - 2016-02-12 13:52:31 --> Database Driver Class Initialized
INFO - 2016-02-12 13:52:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 13:52:32 --> Controller Class Initialized
INFO - 2016-02-12 13:52:32 --> Model Class Initialized
INFO - 2016-02-12 13:52:32 --> Model Class Initialized
INFO - 2016-02-12 13:52:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 13:52:32 --> Pagination Class Initialized
INFO - 2016-02-12 13:52:32 --> Helper loaded: text_helper
INFO - 2016-02-12 16:52:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 16:52:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 16:52:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-12 16:52:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 16:52:32 --> Final output sent to browser
DEBUG - 2016-02-12 16:52:32 --> Total execution time: 1.1252
INFO - 2016-02-12 14:08:42 --> Config Class Initialized
INFO - 2016-02-12 14:08:42 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:08:42 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:08:42 --> Utf8 Class Initialized
INFO - 2016-02-12 14:08:42 --> URI Class Initialized
DEBUG - 2016-02-12 14:08:42 --> No URI present. Default controller set.
INFO - 2016-02-12 14:08:42 --> Router Class Initialized
INFO - 2016-02-12 14:08:42 --> Output Class Initialized
INFO - 2016-02-12 14:08:42 --> Security Class Initialized
DEBUG - 2016-02-12 14:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:08:42 --> Input Class Initialized
INFO - 2016-02-12 14:08:42 --> Language Class Initialized
INFO - 2016-02-12 14:08:42 --> Loader Class Initialized
INFO - 2016-02-12 14:08:42 --> Helper loaded: url_helper
INFO - 2016-02-12 14:08:42 --> Helper loaded: file_helper
INFO - 2016-02-12 14:08:42 --> Helper loaded: date_helper
INFO - 2016-02-12 14:08:42 --> Helper loaded: form_helper
INFO - 2016-02-12 14:08:42 --> Database Driver Class Initialized
INFO - 2016-02-12 14:08:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:08:43 --> Controller Class Initialized
INFO - 2016-02-12 14:08:43 --> Model Class Initialized
INFO - 2016-02-12 14:08:43 --> Model Class Initialized
INFO - 2016-02-12 14:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:08:43 --> Pagination Class Initialized
INFO - 2016-02-12 14:08:43 --> Helper loaded: text_helper
INFO - 2016-02-12 17:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:08:43 --> Final output sent to browser
DEBUG - 2016-02-12 17:08:43 --> Total execution time: 1.1009
INFO - 2016-02-12 14:08:44 --> Config Class Initialized
INFO - 2016-02-12 14:08:44 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:08:44 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:08:44 --> Utf8 Class Initialized
INFO - 2016-02-12 14:08:44 --> URI Class Initialized
INFO - 2016-02-12 14:08:44 --> Router Class Initialized
INFO - 2016-02-12 14:08:44 --> Output Class Initialized
INFO - 2016-02-12 14:08:44 --> Security Class Initialized
DEBUG - 2016-02-12 14:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:08:44 --> Input Class Initialized
INFO - 2016-02-12 14:08:44 --> Language Class Initialized
INFO - 2016-02-12 14:08:44 --> Loader Class Initialized
INFO - 2016-02-12 14:08:44 --> Helper loaded: url_helper
INFO - 2016-02-12 14:08:44 --> Helper loaded: file_helper
INFO - 2016-02-12 14:08:44 --> Helper loaded: date_helper
INFO - 2016-02-12 14:08:44 --> Helper loaded: form_helper
INFO - 2016-02-12 14:08:44 --> Database Driver Class Initialized
INFO - 2016-02-12 14:08:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:08:45 --> Controller Class Initialized
INFO - 2016-02-12 14:08:45 --> Model Class Initialized
INFO - 2016-02-12 14:08:45 --> Model Class Initialized
INFO - 2016-02-12 14:08:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:08:45 --> Pagination Class Initialized
INFO - 2016-02-12 14:08:45 --> Helper loaded: text_helper
INFO - 2016-02-12 17:08:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:08:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-12 17:08:45 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 27
INFO - 2016-02-12 14:09:45 --> Config Class Initialized
INFO - 2016-02-12 14:09:45 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:09:45 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:09:45 --> Utf8 Class Initialized
INFO - 2016-02-12 14:09:45 --> URI Class Initialized
INFO - 2016-02-12 14:09:45 --> Router Class Initialized
INFO - 2016-02-12 14:09:45 --> Output Class Initialized
INFO - 2016-02-12 14:09:45 --> Security Class Initialized
DEBUG - 2016-02-12 14:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:09:45 --> Input Class Initialized
INFO - 2016-02-12 14:09:45 --> Language Class Initialized
INFO - 2016-02-12 14:09:45 --> Loader Class Initialized
INFO - 2016-02-12 14:09:45 --> Helper loaded: url_helper
INFO - 2016-02-12 14:09:45 --> Helper loaded: file_helper
INFO - 2016-02-12 14:09:45 --> Helper loaded: date_helper
INFO - 2016-02-12 14:09:45 --> Helper loaded: form_helper
INFO - 2016-02-12 14:09:45 --> Database Driver Class Initialized
INFO - 2016-02-12 14:09:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:09:46 --> Controller Class Initialized
INFO - 2016-02-12 14:09:46 --> Model Class Initialized
INFO - 2016-02-12 14:09:46 --> Model Class Initialized
INFO - 2016-02-12 14:09:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:09:46 --> Pagination Class Initialized
INFO - 2016-02-12 14:09:46 --> Helper loaded: text_helper
INFO - 2016-02-12 17:09:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:09:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-12 17:09:46 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 23
INFO - 2016-02-12 14:11:38 --> Config Class Initialized
INFO - 2016-02-12 14:11:38 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:11:38 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:11:38 --> Utf8 Class Initialized
INFO - 2016-02-12 14:11:38 --> URI Class Initialized
INFO - 2016-02-12 14:11:38 --> Router Class Initialized
INFO - 2016-02-12 14:11:38 --> Output Class Initialized
INFO - 2016-02-12 14:11:38 --> Security Class Initialized
DEBUG - 2016-02-12 14:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:11:38 --> Input Class Initialized
INFO - 2016-02-12 14:11:38 --> Language Class Initialized
INFO - 2016-02-12 14:11:38 --> Loader Class Initialized
INFO - 2016-02-12 14:11:38 --> Helper loaded: url_helper
INFO - 2016-02-12 14:11:38 --> Helper loaded: file_helper
INFO - 2016-02-12 14:11:38 --> Helper loaded: date_helper
INFO - 2016-02-12 14:11:38 --> Helper loaded: form_helper
INFO - 2016-02-12 14:11:38 --> Database Driver Class Initialized
INFO - 2016-02-12 14:11:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:11:39 --> Controller Class Initialized
INFO - 2016-02-12 14:11:39 --> Model Class Initialized
INFO - 2016-02-12 14:11:39 --> Model Class Initialized
INFO - 2016-02-12 14:11:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:11:39 --> Pagination Class Initialized
INFO - 2016-02-12 14:11:39 --> Helper loaded: text_helper
INFO - 2016-02-12 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-12 17:11:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:11:39 --> Final output sent to browser
DEBUG - 2016-02-12 17:11:39 --> Total execution time: 1.1068
INFO - 2016-02-12 14:11:41 --> Config Class Initialized
INFO - 2016-02-12 14:11:41 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:11:41 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:11:41 --> Utf8 Class Initialized
INFO - 2016-02-12 14:11:41 --> URI Class Initialized
INFO - 2016-02-12 14:11:41 --> Router Class Initialized
INFO - 2016-02-12 14:11:41 --> Output Class Initialized
INFO - 2016-02-12 14:11:41 --> Security Class Initialized
DEBUG - 2016-02-12 14:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:11:41 --> Input Class Initialized
INFO - 2016-02-12 14:11:41 --> Language Class Initialized
INFO - 2016-02-12 14:11:41 --> Loader Class Initialized
INFO - 2016-02-12 14:11:41 --> Helper loaded: url_helper
INFO - 2016-02-12 14:11:41 --> Helper loaded: file_helper
INFO - 2016-02-12 14:11:41 --> Helper loaded: date_helper
INFO - 2016-02-12 14:11:41 --> Helper loaded: form_helper
INFO - 2016-02-12 14:11:41 --> Database Driver Class Initialized
INFO - 2016-02-12 14:11:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:11:42 --> Controller Class Initialized
INFO - 2016-02-12 14:11:42 --> Model Class Initialized
INFO - 2016-02-12 14:11:42 --> Model Class Initialized
INFO - 2016-02-12 14:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:11:42 --> Pagination Class Initialized
INFO - 2016-02-12 14:11:42 --> Helper loaded: text_helper
INFO - 2016-02-12 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-12 17:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:11:42 --> Final output sent to browser
DEBUG - 2016-02-12 17:11:42 --> Total execution time: 1.1254
INFO - 2016-02-12 14:11:44 --> Config Class Initialized
INFO - 2016-02-12 14:11:44 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:11:44 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:11:44 --> Utf8 Class Initialized
INFO - 2016-02-12 14:11:44 --> URI Class Initialized
INFO - 2016-02-12 14:11:44 --> Router Class Initialized
INFO - 2016-02-12 14:11:44 --> Output Class Initialized
INFO - 2016-02-12 14:11:44 --> Security Class Initialized
DEBUG - 2016-02-12 14:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:11:44 --> Input Class Initialized
INFO - 2016-02-12 14:11:44 --> Language Class Initialized
INFO - 2016-02-12 14:11:44 --> Loader Class Initialized
INFO - 2016-02-12 14:11:44 --> Helper loaded: url_helper
INFO - 2016-02-12 14:11:44 --> Helper loaded: file_helper
INFO - 2016-02-12 14:11:44 --> Helper loaded: date_helper
INFO - 2016-02-12 14:11:44 --> Helper loaded: form_helper
INFO - 2016-02-12 14:11:44 --> Database Driver Class Initialized
INFO - 2016-02-12 14:11:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:11:45 --> Controller Class Initialized
INFO - 2016-02-12 14:11:45 --> Model Class Initialized
INFO - 2016-02-12 14:11:45 --> Model Class Initialized
INFO - 2016-02-12 14:11:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:11:45 --> Pagination Class Initialized
INFO - 2016-02-12 14:11:45 --> Helper loaded: text_helper
INFO - 2016-02-12 17:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-12 17:11:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:11:45 --> Final output sent to browser
DEBUG - 2016-02-12 17:11:45 --> Total execution time: 1.0993
INFO - 2016-02-12 14:13:13 --> Config Class Initialized
INFO - 2016-02-12 14:13:13 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:13:13 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:13:13 --> Utf8 Class Initialized
INFO - 2016-02-12 14:13:13 --> URI Class Initialized
INFO - 2016-02-12 14:13:13 --> Router Class Initialized
INFO - 2016-02-12 14:13:13 --> Output Class Initialized
INFO - 2016-02-12 14:13:13 --> Security Class Initialized
DEBUG - 2016-02-12 14:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:13:13 --> Input Class Initialized
INFO - 2016-02-12 14:13:13 --> Language Class Initialized
INFO - 2016-02-12 14:13:13 --> Loader Class Initialized
INFO - 2016-02-12 14:13:13 --> Helper loaded: url_helper
INFO - 2016-02-12 14:13:13 --> Helper loaded: file_helper
INFO - 2016-02-12 14:13:13 --> Helper loaded: date_helper
INFO - 2016-02-12 14:13:13 --> Helper loaded: form_helper
INFO - 2016-02-12 14:13:13 --> Database Driver Class Initialized
INFO - 2016-02-12 14:13:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:13:14 --> Controller Class Initialized
INFO - 2016-02-12 14:13:14 --> Model Class Initialized
INFO - 2016-02-12 14:13:14 --> Model Class Initialized
INFO - 2016-02-12 14:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:13:14 --> Pagination Class Initialized
INFO - 2016-02-12 14:13:14 --> Helper loaded: text_helper
INFO - 2016-02-12 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-12 17:13:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 14
INFO - 2016-02-12 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-12 17:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:13:14 --> Final output sent to browser
DEBUG - 2016-02-12 17:13:14 --> Total execution time: 1.1198
INFO - 2016-02-12 14:15:03 --> Config Class Initialized
INFO - 2016-02-12 14:15:03 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:15:03 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:15:03 --> Utf8 Class Initialized
INFO - 2016-02-12 14:15:03 --> URI Class Initialized
DEBUG - 2016-02-12 14:15:03 --> No URI present. Default controller set.
INFO - 2016-02-12 14:15:03 --> Router Class Initialized
INFO - 2016-02-12 14:15:03 --> Output Class Initialized
INFO - 2016-02-12 14:15:03 --> Security Class Initialized
DEBUG - 2016-02-12 14:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:15:03 --> Input Class Initialized
INFO - 2016-02-12 14:15:03 --> Language Class Initialized
INFO - 2016-02-12 14:15:03 --> Loader Class Initialized
INFO - 2016-02-12 14:15:03 --> Helper loaded: url_helper
INFO - 2016-02-12 14:15:03 --> Helper loaded: file_helper
INFO - 2016-02-12 14:15:03 --> Helper loaded: date_helper
INFO - 2016-02-12 14:15:03 --> Helper loaded: form_helper
INFO - 2016-02-12 14:15:03 --> Database Driver Class Initialized
INFO - 2016-02-12 14:15:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:15:04 --> Controller Class Initialized
INFO - 2016-02-12 14:15:04 --> Model Class Initialized
INFO - 2016-02-12 14:15:04 --> Model Class Initialized
INFO - 2016-02-12 14:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:15:04 --> Pagination Class Initialized
INFO - 2016-02-12 14:15:04 --> Helper loaded: text_helper
INFO - 2016-02-12 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:15:04 --> Final output sent to browser
DEBUG - 2016-02-12 17:15:04 --> Total execution time: 1.0970
INFO - 2016-02-12 14:15:05 --> Config Class Initialized
INFO - 2016-02-12 14:15:05 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:15:05 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:15:05 --> Utf8 Class Initialized
INFO - 2016-02-12 14:15:05 --> URI Class Initialized
INFO - 2016-02-12 14:15:05 --> Router Class Initialized
INFO - 2016-02-12 14:15:05 --> Output Class Initialized
INFO - 2016-02-12 14:15:05 --> Security Class Initialized
DEBUG - 2016-02-12 14:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:15:05 --> Input Class Initialized
INFO - 2016-02-12 14:15:05 --> Language Class Initialized
INFO - 2016-02-12 14:15:05 --> Loader Class Initialized
INFO - 2016-02-12 14:15:05 --> Helper loaded: url_helper
INFO - 2016-02-12 14:15:05 --> Helper loaded: file_helper
INFO - 2016-02-12 14:15:05 --> Helper loaded: date_helper
INFO - 2016-02-12 14:15:05 --> Helper loaded: form_helper
INFO - 2016-02-12 14:15:05 --> Database Driver Class Initialized
INFO - 2016-02-12 14:15:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:15:06 --> Controller Class Initialized
INFO - 2016-02-12 14:15:06 --> Model Class Initialized
INFO - 2016-02-12 14:15:06 --> Model Class Initialized
INFO - 2016-02-12 14:15:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:15:06 --> Pagination Class Initialized
INFO - 2016-02-12 14:15:06 --> Helper loaded: text_helper
INFO - 2016-02-12 17:15:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:15:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-12 17:15:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 14
INFO - 2016-02-12 17:15:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-12 17:15:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:15:06 --> Final output sent to browser
DEBUG - 2016-02-12 17:15:06 --> Total execution time: 1.1203
INFO - 2016-02-12 14:17:15 --> Config Class Initialized
INFO - 2016-02-12 14:17:15 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:17:15 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:17:15 --> Utf8 Class Initialized
INFO - 2016-02-12 14:17:15 --> URI Class Initialized
DEBUG - 2016-02-12 14:17:15 --> No URI present. Default controller set.
INFO - 2016-02-12 14:17:15 --> Router Class Initialized
INFO - 2016-02-12 14:17:15 --> Output Class Initialized
INFO - 2016-02-12 14:17:15 --> Security Class Initialized
DEBUG - 2016-02-12 14:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:17:15 --> Input Class Initialized
INFO - 2016-02-12 14:17:15 --> Language Class Initialized
INFO - 2016-02-12 14:17:16 --> Loader Class Initialized
INFO - 2016-02-12 14:17:16 --> Helper loaded: url_helper
INFO - 2016-02-12 14:17:16 --> Helper loaded: file_helper
INFO - 2016-02-12 14:17:16 --> Helper loaded: date_helper
INFO - 2016-02-12 14:17:16 --> Helper loaded: form_helper
INFO - 2016-02-12 14:17:16 --> Database Driver Class Initialized
INFO - 2016-02-12 14:17:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:17:17 --> Controller Class Initialized
INFO - 2016-02-12 14:17:17 --> Model Class Initialized
INFO - 2016-02-12 14:17:17 --> Model Class Initialized
INFO - 2016-02-12 14:17:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:17:17 --> Pagination Class Initialized
INFO - 2016-02-12 14:17:17 --> Helper loaded: text_helper
INFO - 2016-02-12 17:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:17:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:17:17 --> Final output sent to browser
DEBUG - 2016-02-12 17:17:17 --> Total execution time: 1.1112
INFO - 2016-02-12 14:17:21 --> Config Class Initialized
INFO - 2016-02-12 14:17:21 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:17:21 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:17:21 --> Utf8 Class Initialized
INFO - 2016-02-12 14:17:21 --> URI Class Initialized
INFO - 2016-02-12 14:17:21 --> Router Class Initialized
INFO - 2016-02-12 14:17:21 --> Output Class Initialized
INFO - 2016-02-12 14:17:21 --> Security Class Initialized
DEBUG - 2016-02-12 14:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:17:21 --> Input Class Initialized
INFO - 2016-02-12 14:17:21 --> Language Class Initialized
INFO - 2016-02-12 14:17:21 --> Loader Class Initialized
INFO - 2016-02-12 14:17:21 --> Helper loaded: url_helper
INFO - 2016-02-12 14:17:21 --> Helper loaded: file_helper
INFO - 2016-02-12 14:17:21 --> Helper loaded: date_helper
INFO - 2016-02-12 14:17:21 --> Helper loaded: form_helper
INFO - 2016-02-12 14:17:21 --> Database Driver Class Initialized
INFO - 2016-02-12 14:17:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:17:22 --> Controller Class Initialized
INFO - 2016-02-12 14:17:22 --> Model Class Initialized
INFO - 2016-02-12 14:17:22 --> Model Class Initialized
INFO - 2016-02-12 14:17:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:17:22 --> Pagination Class Initialized
INFO - 2016-02-12 14:17:22 --> Helper loaded: text_helper
INFO - 2016-02-12 17:17:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:17:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-12 17:17:22 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 12
INFO - 2016-02-12 14:18:03 --> Config Class Initialized
INFO - 2016-02-12 14:18:03 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:18:03 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:18:03 --> Utf8 Class Initialized
INFO - 2016-02-12 14:18:03 --> URI Class Initialized
INFO - 2016-02-12 14:18:03 --> Router Class Initialized
INFO - 2016-02-12 14:18:03 --> Output Class Initialized
INFO - 2016-02-12 14:18:03 --> Security Class Initialized
DEBUG - 2016-02-12 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:18:03 --> Input Class Initialized
INFO - 2016-02-12 14:18:03 --> Language Class Initialized
INFO - 2016-02-12 14:18:03 --> Loader Class Initialized
INFO - 2016-02-12 14:18:03 --> Helper loaded: url_helper
INFO - 2016-02-12 14:18:03 --> Helper loaded: file_helper
INFO - 2016-02-12 14:18:03 --> Helper loaded: date_helper
INFO - 2016-02-12 14:18:03 --> Helper loaded: form_helper
INFO - 2016-02-12 14:18:03 --> Database Driver Class Initialized
INFO - 2016-02-12 14:18:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:18:04 --> Controller Class Initialized
INFO - 2016-02-12 14:18:04 --> Model Class Initialized
INFO - 2016-02-12 14:18:04 --> Model Class Initialized
INFO - 2016-02-12 14:18:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:18:04 --> Pagination Class Initialized
INFO - 2016-02-12 14:18:04 --> Helper loaded: text_helper
INFO - 2016-02-12 17:18:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:18:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:18:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:18:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:18:04 --> Final output sent to browser
DEBUG - 2016-02-12 17:18:04 --> Total execution time: 1.1018
INFO - 2016-02-12 14:18:07 --> Config Class Initialized
INFO - 2016-02-12 14:18:07 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:18:07 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:18:07 --> Utf8 Class Initialized
INFO - 2016-02-12 14:18:07 --> URI Class Initialized
INFO - 2016-02-12 14:18:07 --> Router Class Initialized
INFO - 2016-02-12 14:18:07 --> Output Class Initialized
INFO - 2016-02-12 14:18:07 --> Security Class Initialized
DEBUG - 2016-02-12 14:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:18:07 --> Input Class Initialized
INFO - 2016-02-12 14:18:07 --> Language Class Initialized
INFO - 2016-02-12 14:18:07 --> Loader Class Initialized
INFO - 2016-02-12 14:18:07 --> Helper loaded: url_helper
INFO - 2016-02-12 14:18:07 --> Helper loaded: file_helper
INFO - 2016-02-12 14:18:07 --> Helper loaded: date_helper
INFO - 2016-02-12 14:18:07 --> Helper loaded: form_helper
INFO - 2016-02-12 14:18:07 --> Database Driver Class Initialized
INFO - 2016-02-12 14:18:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:18:08 --> Controller Class Initialized
INFO - 2016-02-12 14:18:08 --> Model Class Initialized
INFO - 2016-02-12 14:18:08 --> Model Class Initialized
INFO - 2016-02-12 14:18:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:18:08 --> Pagination Class Initialized
INFO - 2016-02-12 14:18:08 --> Helper loaded: text_helper
INFO - 2016-02-12 17:18:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:18:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-12 17:18:08 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 12
INFO - 2016-02-12 14:18:19 --> Config Class Initialized
INFO - 2016-02-12 14:18:19 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:18:19 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:18:19 --> Utf8 Class Initialized
INFO - 2016-02-12 14:18:19 --> URI Class Initialized
INFO - 2016-02-12 14:18:19 --> Router Class Initialized
INFO - 2016-02-12 14:18:19 --> Output Class Initialized
INFO - 2016-02-12 14:18:19 --> Security Class Initialized
DEBUG - 2016-02-12 14:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:18:19 --> Input Class Initialized
INFO - 2016-02-12 14:18:19 --> Language Class Initialized
INFO - 2016-02-12 14:18:19 --> Loader Class Initialized
INFO - 2016-02-12 14:18:19 --> Helper loaded: url_helper
INFO - 2016-02-12 14:18:19 --> Helper loaded: file_helper
INFO - 2016-02-12 14:18:19 --> Helper loaded: date_helper
INFO - 2016-02-12 14:18:19 --> Helper loaded: form_helper
INFO - 2016-02-12 14:18:19 --> Database Driver Class Initialized
INFO - 2016-02-12 14:18:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:18:20 --> Controller Class Initialized
INFO - 2016-02-12 14:18:20 --> Model Class Initialized
INFO - 2016-02-12 14:18:20 --> Model Class Initialized
INFO - 2016-02-12 14:18:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:18:20 --> Pagination Class Initialized
INFO - 2016-02-12 14:18:20 --> Helper loaded: text_helper
INFO - 2016-02-12 17:18:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:18:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:18:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:18:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:18:20 --> Final output sent to browser
DEBUG - 2016-02-12 17:18:20 --> Total execution time: 1.1220
INFO - 2016-02-12 14:18:24 --> Config Class Initialized
INFO - 2016-02-12 14:18:24 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:18:24 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:18:24 --> Utf8 Class Initialized
INFO - 2016-02-12 14:18:24 --> URI Class Initialized
INFO - 2016-02-12 14:18:24 --> Router Class Initialized
INFO - 2016-02-12 14:18:24 --> Output Class Initialized
INFO - 2016-02-12 14:18:24 --> Security Class Initialized
DEBUG - 2016-02-12 14:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:18:24 --> Input Class Initialized
INFO - 2016-02-12 14:18:24 --> Language Class Initialized
INFO - 2016-02-12 14:18:24 --> Loader Class Initialized
INFO - 2016-02-12 14:18:24 --> Helper loaded: url_helper
INFO - 2016-02-12 14:18:24 --> Helper loaded: file_helper
INFO - 2016-02-12 14:18:24 --> Helper loaded: date_helper
INFO - 2016-02-12 14:18:24 --> Helper loaded: form_helper
INFO - 2016-02-12 14:18:24 --> Database Driver Class Initialized
INFO - 2016-02-12 14:18:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:18:25 --> Controller Class Initialized
INFO - 2016-02-12 14:18:25 --> Model Class Initialized
INFO - 2016-02-12 14:18:25 --> Model Class Initialized
INFO - 2016-02-12 14:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:18:25 --> Pagination Class Initialized
INFO - 2016-02-12 14:18:25 --> Helper loaded: text_helper
INFO - 2016-02-12 17:18:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:18:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-12 17:18:25 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 12
INFO - 2016-02-12 14:18:31 --> Config Class Initialized
INFO - 2016-02-12 14:18:31 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:18:31 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:18:31 --> Utf8 Class Initialized
INFO - 2016-02-12 14:18:31 --> URI Class Initialized
INFO - 2016-02-12 14:18:31 --> Router Class Initialized
INFO - 2016-02-12 14:18:31 --> Output Class Initialized
INFO - 2016-02-12 14:18:31 --> Security Class Initialized
DEBUG - 2016-02-12 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:18:31 --> Input Class Initialized
INFO - 2016-02-12 14:18:31 --> Language Class Initialized
INFO - 2016-02-12 14:18:31 --> Loader Class Initialized
INFO - 2016-02-12 14:18:31 --> Helper loaded: url_helper
INFO - 2016-02-12 14:18:31 --> Helper loaded: file_helper
INFO - 2016-02-12 14:18:31 --> Helper loaded: date_helper
INFO - 2016-02-12 14:18:31 --> Helper loaded: form_helper
INFO - 2016-02-12 14:18:31 --> Database Driver Class Initialized
INFO - 2016-02-12 14:18:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:18:32 --> Controller Class Initialized
INFO - 2016-02-12 14:18:32 --> Model Class Initialized
INFO - 2016-02-12 14:18:32 --> Model Class Initialized
INFO - 2016-02-12 14:18:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:18:32 --> Pagination Class Initialized
INFO - 2016-02-12 14:18:32 --> Helper loaded: text_helper
INFO - 2016-02-12 17:18:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:18:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:18:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:18:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:18:32 --> Final output sent to browser
DEBUG - 2016-02-12 17:18:32 --> Total execution time: 1.1314
INFO - 2016-02-12 14:21:34 --> Config Class Initialized
INFO - 2016-02-12 14:21:34 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:21:34 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:21:34 --> Utf8 Class Initialized
INFO - 2016-02-12 14:21:34 --> URI Class Initialized
INFO - 2016-02-12 14:21:34 --> Router Class Initialized
INFO - 2016-02-12 14:21:34 --> Output Class Initialized
INFO - 2016-02-12 14:21:34 --> Security Class Initialized
DEBUG - 2016-02-12 14:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:21:34 --> Input Class Initialized
INFO - 2016-02-12 14:21:34 --> Language Class Initialized
INFO - 2016-02-12 14:21:34 --> Loader Class Initialized
INFO - 2016-02-12 14:21:34 --> Helper loaded: url_helper
INFO - 2016-02-12 14:21:34 --> Helper loaded: file_helper
INFO - 2016-02-12 14:21:34 --> Helper loaded: date_helper
INFO - 2016-02-12 14:21:34 --> Helper loaded: form_helper
INFO - 2016-02-12 14:21:34 --> Database Driver Class Initialized
INFO - 2016-02-12 14:21:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:21:35 --> Controller Class Initialized
INFO - 2016-02-12 14:21:35 --> Model Class Initialized
INFO - 2016-02-12 14:21:35 --> Model Class Initialized
INFO - 2016-02-12 14:21:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:21:35 --> Pagination Class Initialized
INFO - 2016-02-12 14:21:35 --> Helper loaded: text_helper
INFO - 2016-02-12 17:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:21:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:21:35 --> Final output sent to browser
DEBUG - 2016-02-12 17:21:35 --> Total execution time: 1.0914
INFO - 2016-02-12 14:22:09 --> Config Class Initialized
INFO - 2016-02-12 14:22:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:22:09 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:22:09 --> Utf8 Class Initialized
INFO - 2016-02-12 14:22:09 --> URI Class Initialized
INFO - 2016-02-12 14:22:09 --> Router Class Initialized
INFO - 2016-02-12 14:22:09 --> Output Class Initialized
INFO - 2016-02-12 14:22:09 --> Security Class Initialized
DEBUG - 2016-02-12 14:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:22:09 --> Input Class Initialized
INFO - 2016-02-12 14:22:09 --> Language Class Initialized
INFO - 2016-02-12 14:22:09 --> Loader Class Initialized
INFO - 2016-02-12 14:22:09 --> Helper loaded: url_helper
INFO - 2016-02-12 14:22:09 --> Helper loaded: file_helper
INFO - 2016-02-12 14:22:09 --> Helper loaded: date_helper
INFO - 2016-02-12 14:22:09 --> Helper loaded: form_helper
INFO - 2016-02-12 14:22:09 --> Database Driver Class Initialized
INFO - 2016-02-12 14:22:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:22:10 --> Controller Class Initialized
INFO - 2016-02-12 14:22:10 --> Model Class Initialized
INFO - 2016-02-12 14:22:10 --> Model Class Initialized
INFO - 2016-02-12 14:22:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:22:10 --> Pagination Class Initialized
INFO - 2016-02-12 14:22:10 --> Helper loaded: text_helper
INFO - 2016-02-12 17:22:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:22:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:22:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:22:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:22:10 --> Final output sent to browser
DEBUG - 2016-02-12 17:22:10 --> Total execution time: 1.1724
INFO - 2016-02-12 14:24:21 --> Config Class Initialized
INFO - 2016-02-12 14:24:21 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:24:21 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:24:21 --> Utf8 Class Initialized
INFO - 2016-02-12 14:24:21 --> URI Class Initialized
INFO - 2016-02-12 14:24:21 --> Router Class Initialized
INFO - 2016-02-12 14:24:21 --> Output Class Initialized
INFO - 2016-02-12 14:24:21 --> Security Class Initialized
DEBUG - 2016-02-12 14:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:24:21 --> Input Class Initialized
INFO - 2016-02-12 14:24:21 --> Language Class Initialized
INFO - 2016-02-12 14:24:21 --> Loader Class Initialized
INFO - 2016-02-12 14:24:21 --> Helper loaded: url_helper
INFO - 2016-02-12 14:24:21 --> Helper loaded: file_helper
INFO - 2016-02-12 14:24:21 --> Helper loaded: date_helper
INFO - 2016-02-12 14:24:21 --> Helper loaded: form_helper
INFO - 2016-02-12 14:24:21 --> Database Driver Class Initialized
INFO - 2016-02-12 14:24:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:24:22 --> Controller Class Initialized
INFO - 2016-02-12 14:24:22 --> Model Class Initialized
INFO - 2016-02-12 14:24:22 --> Model Class Initialized
INFO - 2016-02-12 14:24:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:24:22 --> Pagination Class Initialized
INFO - 2016-02-12 14:24:22 --> Helper loaded: text_helper
INFO - 2016-02-12 17:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:24:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:24:22 --> Final output sent to browser
DEBUG - 2016-02-12 17:24:22 --> Total execution time: 1.0904
INFO - 2016-02-12 14:26:40 --> Config Class Initialized
INFO - 2016-02-12 14:26:40 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:26:40 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:26:40 --> Utf8 Class Initialized
INFO - 2016-02-12 14:26:40 --> URI Class Initialized
INFO - 2016-02-12 14:26:40 --> Router Class Initialized
INFO - 2016-02-12 14:26:40 --> Output Class Initialized
INFO - 2016-02-12 14:26:40 --> Security Class Initialized
DEBUG - 2016-02-12 14:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:26:40 --> Input Class Initialized
INFO - 2016-02-12 14:26:40 --> Language Class Initialized
INFO - 2016-02-12 14:26:40 --> Loader Class Initialized
INFO - 2016-02-12 14:26:40 --> Helper loaded: url_helper
INFO - 2016-02-12 14:26:40 --> Helper loaded: file_helper
INFO - 2016-02-12 14:26:40 --> Helper loaded: date_helper
INFO - 2016-02-12 14:26:40 --> Helper loaded: form_helper
INFO - 2016-02-12 14:26:40 --> Database Driver Class Initialized
INFO - 2016-02-12 14:26:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:26:41 --> Controller Class Initialized
INFO - 2016-02-12 14:26:41 --> Model Class Initialized
INFO - 2016-02-12 14:26:41 --> Model Class Initialized
INFO - 2016-02-12 14:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:26:41 --> Pagination Class Initialized
INFO - 2016-02-12 14:26:41 --> Helper loaded: text_helper
INFO - 2016-02-12 17:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:26:41 --> Final output sent to browser
DEBUG - 2016-02-12 17:26:41 --> Total execution time: 1.1144
INFO - 2016-02-12 14:28:39 --> Config Class Initialized
INFO - 2016-02-12 14:28:39 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:28:39 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:28:39 --> Utf8 Class Initialized
INFO - 2016-02-12 14:28:39 --> URI Class Initialized
INFO - 2016-02-12 14:28:39 --> Router Class Initialized
INFO - 2016-02-12 14:28:39 --> Output Class Initialized
INFO - 2016-02-12 14:28:39 --> Security Class Initialized
DEBUG - 2016-02-12 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:28:39 --> Input Class Initialized
INFO - 2016-02-12 14:28:39 --> Language Class Initialized
INFO - 2016-02-12 14:28:39 --> Loader Class Initialized
INFO - 2016-02-12 14:28:39 --> Helper loaded: url_helper
INFO - 2016-02-12 14:28:39 --> Helper loaded: file_helper
INFO - 2016-02-12 14:28:39 --> Helper loaded: date_helper
INFO - 2016-02-12 14:28:39 --> Helper loaded: form_helper
INFO - 2016-02-12 14:28:39 --> Database Driver Class Initialized
INFO - 2016-02-12 14:28:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:28:40 --> Controller Class Initialized
INFO - 2016-02-12 14:28:40 --> Model Class Initialized
INFO - 2016-02-12 14:28:40 --> Model Class Initialized
INFO - 2016-02-12 14:28:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:28:40 --> Pagination Class Initialized
INFO - 2016-02-12 14:28:40 --> Helper loaded: text_helper
INFO - 2016-02-12 17:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:28:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:28:40 --> Final output sent to browser
DEBUG - 2016-02-12 17:28:40 --> Total execution time: 1.1000
INFO - 2016-02-12 14:29:32 --> Config Class Initialized
INFO - 2016-02-12 14:29:32 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:29:32 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:29:32 --> Utf8 Class Initialized
INFO - 2016-02-12 14:29:32 --> URI Class Initialized
INFO - 2016-02-12 14:29:32 --> Router Class Initialized
INFO - 2016-02-12 14:29:32 --> Output Class Initialized
INFO - 2016-02-12 14:29:32 --> Security Class Initialized
DEBUG - 2016-02-12 14:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:29:32 --> Input Class Initialized
INFO - 2016-02-12 14:29:32 --> Language Class Initialized
INFO - 2016-02-12 14:29:32 --> Loader Class Initialized
INFO - 2016-02-12 14:29:32 --> Helper loaded: url_helper
INFO - 2016-02-12 14:29:32 --> Helper loaded: file_helper
INFO - 2016-02-12 14:29:32 --> Helper loaded: date_helper
INFO - 2016-02-12 14:29:32 --> Helper loaded: form_helper
INFO - 2016-02-12 14:29:32 --> Database Driver Class Initialized
INFO - 2016-02-12 14:29:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:29:33 --> Controller Class Initialized
INFO - 2016-02-12 14:29:33 --> Model Class Initialized
INFO - 2016-02-12 14:29:33 --> Model Class Initialized
INFO - 2016-02-12 14:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:29:33 --> Pagination Class Initialized
INFO - 2016-02-12 14:29:33 --> Helper loaded: text_helper
INFO - 2016-02-12 17:29:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:29:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:29:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:29:34 --> Final output sent to browser
DEBUG - 2016-02-12 17:29:34 --> Total execution time: 1.3574
INFO - 2016-02-12 14:37:09 --> Config Class Initialized
INFO - 2016-02-12 14:37:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:37:09 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:37:09 --> Utf8 Class Initialized
INFO - 2016-02-12 14:37:09 --> URI Class Initialized
INFO - 2016-02-12 14:37:09 --> Router Class Initialized
INFO - 2016-02-12 14:37:09 --> Output Class Initialized
INFO - 2016-02-12 14:37:09 --> Security Class Initialized
DEBUG - 2016-02-12 14:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:37:09 --> Input Class Initialized
INFO - 2016-02-12 14:37:09 --> Language Class Initialized
INFO - 2016-02-12 14:37:09 --> Loader Class Initialized
INFO - 2016-02-12 14:37:10 --> Helper loaded: url_helper
INFO - 2016-02-12 14:37:10 --> Helper loaded: file_helper
INFO - 2016-02-12 14:37:10 --> Helper loaded: date_helper
INFO - 2016-02-12 14:37:10 --> Helper loaded: form_helper
INFO - 2016-02-12 14:37:10 --> Database Driver Class Initialized
INFO - 2016-02-12 14:37:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:37:11 --> Controller Class Initialized
INFO - 2016-02-12 14:37:11 --> Model Class Initialized
INFO - 2016-02-12 14:37:11 --> Model Class Initialized
INFO - 2016-02-12 14:37:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:37:11 --> Pagination Class Initialized
INFO - 2016-02-12 14:37:11 --> Helper loaded: text_helper
INFO - 2016-02-12 17:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:37:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:37:11 --> Final output sent to browser
DEBUG - 2016-02-12 17:37:11 --> Total execution time: 1.0944
INFO - 2016-02-12 14:40:19 --> Config Class Initialized
INFO - 2016-02-12 14:40:19 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:40:19 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:40:19 --> Utf8 Class Initialized
INFO - 2016-02-12 14:40:19 --> URI Class Initialized
INFO - 2016-02-12 14:40:19 --> Router Class Initialized
INFO - 2016-02-12 14:40:19 --> Output Class Initialized
INFO - 2016-02-12 14:40:19 --> Security Class Initialized
DEBUG - 2016-02-12 14:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:40:19 --> Input Class Initialized
INFO - 2016-02-12 14:40:19 --> Language Class Initialized
INFO - 2016-02-12 14:40:19 --> Loader Class Initialized
INFO - 2016-02-12 14:40:19 --> Helper loaded: url_helper
INFO - 2016-02-12 14:40:19 --> Helper loaded: file_helper
INFO - 2016-02-12 14:40:19 --> Helper loaded: date_helper
INFO - 2016-02-12 14:40:19 --> Helper loaded: form_helper
INFO - 2016-02-12 14:40:19 --> Database Driver Class Initialized
INFO - 2016-02-12 14:40:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:40:20 --> Controller Class Initialized
INFO - 2016-02-12 14:40:20 --> Model Class Initialized
INFO - 2016-02-12 14:40:20 --> Model Class Initialized
INFO - 2016-02-12 14:40:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:40:20 --> Pagination Class Initialized
INFO - 2016-02-12 14:40:20 --> Helper loaded: text_helper
INFO - 2016-02-12 17:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:40:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:40:20 --> Final output sent to browser
DEBUG - 2016-02-12 17:40:20 --> Total execution time: 1.1027
INFO - 2016-02-12 14:41:12 --> Config Class Initialized
INFO - 2016-02-12 14:41:12 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:41:12 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:41:12 --> Utf8 Class Initialized
INFO - 2016-02-12 14:41:12 --> URI Class Initialized
DEBUG - 2016-02-12 14:41:12 --> No URI present. Default controller set.
INFO - 2016-02-12 14:41:12 --> Router Class Initialized
INFO - 2016-02-12 14:41:12 --> Output Class Initialized
INFO - 2016-02-12 14:41:12 --> Security Class Initialized
DEBUG - 2016-02-12 14:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:41:12 --> Input Class Initialized
INFO - 2016-02-12 14:41:12 --> Language Class Initialized
INFO - 2016-02-12 14:41:12 --> Loader Class Initialized
INFO - 2016-02-12 14:41:12 --> Helper loaded: url_helper
INFO - 2016-02-12 14:41:12 --> Helper loaded: file_helper
INFO - 2016-02-12 14:41:12 --> Helper loaded: date_helper
INFO - 2016-02-12 14:41:12 --> Helper loaded: form_helper
INFO - 2016-02-12 14:41:12 --> Database Driver Class Initialized
INFO - 2016-02-12 14:41:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:41:13 --> Controller Class Initialized
INFO - 2016-02-12 14:41:13 --> Model Class Initialized
INFO - 2016-02-12 14:41:13 --> Model Class Initialized
INFO - 2016-02-12 14:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:41:13 --> Pagination Class Initialized
INFO - 2016-02-12 14:41:13 --> Helper loaded: text_helper
INFO - 2016-02-12 17:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:41:13 --> Final output sent to browser
DEBUG - 2016-02-12 17:41:13 --> Total execution time: 1.0988
INFO - 2016-02-12 14:42:24 --> Config Class Initialized
INFO - 2016-02-12 14:42:24 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:42:24 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:42:24 --> Utf8 Class Initialized
INFO - 2016-02-12 14:42:24 --> URI Class Initialized
DEBUG - 2016-02-12 14:42:24 --> No URI present. Default controller set.
INFO - 2016-02-12 14:42:24 --> Router Class Initialized
INFO - 2016-02-12 14:42:24 --> Output Class Initialized
INFO - 2016-02-12 14:42:24 --> Security Class Initialized
DEBUG - 2016-02-12 14:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:42:24 --> Input Class Initialized
INFO - 2016-02-12 14:42:24 --> Language Class Initialized
INFO - 2016-02-12 14:42:24 --> Loader Class Initialized
INFO - 2016-02-12 14:42:24 --> Helper loaded: url_helper
INFO - 2016-02-12 14:42:24 --> Helper loaded: file_helper
INFO - 2016-02-12 14:42:24 --> Helper loaded: date_helper
INFO - 2016-02-12 14:42:24 --> Helper loaded: form_helper
INFO - 2016-02-12 14:42:24 --> Database Driver Class Initialized
INFO - 2016-02-12 14:42:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:42:25 --> Controller Class Initialized
INFO - 2016-02-12 14:42:25 --> Model Class Initialized
INFO - 2016-02-12 14:42:25 --> Model Class Initialized
INFO - 2016-02-12 14:42:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:42:25 --> Pagination Class Initialized
INFO - 2016-02-12 14:42:25 --> Helper loaded: text_helper
INFO - 2016-02-12 17:42:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:42:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:42:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:42:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:42:25 --> Final output sent to browser
DEBUG - 2016-02-12 17:42:25 --> Total execution time: 1.0948
INFO - 2016-02-12 14:42:40 --> Config Class Initialized
INFO - 2016-02-12 14:42:40 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:42:40 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:42:40 --> Utf8 Class Initialized
INFO - 2016-02-12 14:42:40 --> URI Class Initialized
DEBUG - 2016-02-12 14:42:40 --> No URI present. Default controller set.
INFO - 2016-02-12 14:42:40 --> Router Class Initialized
INFO - 2016-02-12 14:42:40 --> Output Class Initialized
INFO - 2016-02-12 14:42:40 --> Security Class Initialized
DEBUG - 2016-02-12 14:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:42:40 --> Input Class Initialized
INFO - 2016-02-12 14:42:40 --> Language Class Initialized
INFO - 2016-02-12 14:42:40 --> Loader Class Initialized
INFO - 2016-02-12 14:42:40 --> Helper loaded: url_helper
INFO - 2016-02-12 14:42:40 --> Helper loaded: file_helper
INFO - 2016-02-12 14:42:40 --> Helper loaded: date_helper
INFO - 2016-02-12 14:42:40 --> Helper loaded: form_helper
INFO - 2016-02-12 14:42:40 --> Database Driver Class Initialized
INFO - 2016-02-12 14:42:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:42:41 --> Controller Class Initialized
INFO - 2016-02-12 14:42:41 --> Model Class Initialized
INFO - 2016-02-12 14:42:41 --> Model Class Initialized
INFO - 2016-02-12 14:42:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:42:41 --> Pagination Class Initialized
INFO - 2016-02-12 14:42:41 --> Helper loaded: text_helper
INFO - 2016-02-12 17:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:42:41 --> Final output sent to browser
DEBUG - 2016-02-12 17:42:41 --> Total execution time: 1.1073
INFO - 2016-02-12 14:42:43 --> Config Class Initialized
INFO - 2016-02-12 14:42:43 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:42:43 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:42:43 --> Utf8 Class Initialized
INFO - 2016-02-12 14:42:43 --> URI Class Initialized
INFO - 2016-02-12 14:42:43 --> Router Class Initialized
INFO - 2016-02-12 14:42:43 --> Output Class Initialized
INFO - 2016-02-12 14:42:43 --> Security Class Initialized
DEBUG - 2016-02-12 14:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:42:43 --> Input Class Initialized
INFO - 2016-02-12 14:42:43 --> Language Class Initialized
INFO - 2016-02-12 14:42:43 --> Loader Class Initialized
INFO - 2016-02-12 14:42:43 --> Helper loaded: url_helper
INFO - 2016-02-12 14:42:43 --> Helper loaded: file_helper
INFO - 2016-02-12 14:42:43 --> Helper loaded: date_helper
INFO - 2016-02-12 14:42:43 --> Helper loaded: form_helper
INFO - 2016-02-12 14:42:43 --> Database Driver Class Initialized
INFO - 2016-02-12 14:42:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:42:44 --> Controller Class Initialized
INFO - 2016-02-12 14:42:44 --> Model Class Initialized
INFO - 2016-02-12 14:42:44 --> Model Class Initialized
INFO - 2016-02-12 14:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:42:44 --> Pagination Class Initialized
INFO - 2016-02-12 14:42:44 --> Helper loaded: text_helper
INFO - 2016-02-12 17:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:42:44 --> Final output sent to browser
DEBUG - 2016-02-12 17:42:44 --> Total execution time: 1.1054
INFO - 2016-02-12 14:42:51 --> Config Class Initialized
INFO - 2016-02-12 14:42:51 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:42:51 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:42:51 --> Utf8 Class Initialized
INFO - 2016-02-12 14:42:51 --> URI Class Initialized
INFO - 2016-02-12 14:42:51 --> Router Class Initialized
INFO - 2016-02-12 14:42:51 --> Output Class Initialized
INFO - 2016-02-12 14:42:51 --> Security Class Initialized
DEBUG - 2016-02-12 14:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:42:51 --> Input Class Initialized
INFO - 2016-02-12 14:42:51 --> Language Class Initialized
INFO - 2016-02-12 14:42:51 --> Loader Class Initialized
INFO - 2016-02-12 14:42:51 --> Helper loaded: url_helper
INFO - 2016-02-12 14:42:51 --> Helper loaded: file_helper
INFO - 2016-02-12 14:42:51 --> Helper loaded: date_helper
INFO - 2016-02-12 14:42:51 --> Helper loaded: form_helper
INFO - 2016-02-12 14:42:51 --> Database Driver Class Initialized
INFO - 2016-02-12 14:42:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:42:52 --> Controller Class Initialized
INFO - 2016-02-12 14:42:52 --> Model Class Initialized
INFO - 2016-02-12 14:42:52 --> Model Class Initialized
INFO - 2016-02-12 14:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:42:52 --> Pagination Class Initialized
INFO - 2016-02-12 14:42:52 --> Helper loaded: text_helper
INFO - 2016-02-12 17:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 17:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:42:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:42:52 --> Final output sent to browser
DEBUG - 2016-02-12 17:42:52 --> Total execution time: 1.1400
INFO - 2016-02-12 14:42:56 --> Config Class Initialized
INFO - 2016-02-12 14:42:56 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:42:56 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:42:56 --> Utf8 Class Initialized
INFO - 2016-02-12 14:42:56 --> URI Class Initialized
INFO - 2016-02-12 14:42:56 --> Router Class Initialized
INFO - 2016-02-12 14:42:56 --> Output Class Initialized
INFO - 2016-02-12 14:42:56 --> Security Class Initialized
DEBUG - 2016-02-12 14:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:42:56 --> Input Class Initialized
INFO - 2016-02-12 14:42:56 --> Language Class Initialized
INFO - 2016-02-12 14:42:56 --> Loader Class Initialized
INFO - 2016-02-12 14:42:56 --> Helper loaded: url_helper
INFO - 2016-02-12 14:42:56 --> Helper loaded: file_helper
INFO - 2016-02-12 14:42:56 --> Helper loaded: date_helper
INFO - 2016-02-12 14:42:56 --> Helper loaded: form_helper
INFO - 2016-02-12 14:42:56 --> Database Driver Class Initialized
INFO - 2016-02-12 14:42:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:42:57 --> Controller Class Initialized
INFO - 2016-02-12 14:42:57 --> Model Class Initialized
INFO - 2016-02-12 14:42:57 --> Model Class Initialized
INFO - 2016-02-12 14:42:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:42:57 --> Pagination Class Initialized
INFO - 2016-02-12 14:42:57 --> Helper loaded: text_helper
INFO - 2016-02-12 17:42:57 --> Final output sent to browser
DEBUG - 2016-02-12 17:42:57 --> Total execution time: 1.0806
INFO - 2016-02-12 14:43:02 --> Config Class Initialized
INFO - 2016-02-12 14:43:02 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:43:02 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:43:02 --> Utf8 Class Initialized
INFO - 2016-02-12 14:43:02 --> URI Class Initialized
INFO - 2016-02-12 14:43:02 --> Router Class Initialized
INFO - 2016-02-12 14:43:02 --> Output Class Initialized
INFO - 2016-02-12 14:43:02 --> Security Class Initialized
DEBUG - 2016-02-12 14:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:43:02 --> Input Class Initialized
INFO - 2016-02-12 14:43:02 --> Language Class Initialized
INFO - 2016-02-12 14:43:02 --> Loader Class Initialized
INFO - 2016-02-12 14:43:02 --> Helper loaded: url_helper
INFO - 2016-02-12 14:43:02 --> Helper loaded: file_helper
INFO - 2016-02-12 14:43:02 --> Helper loaded: date_helper
INFO - 2016-02-12 14:43:02 --> Helper loaded: form_helper
INFO - 2016-02-12 14:43:02 --> Database Driver Class Initialized
INFO - 2016-02-12 14:43:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:43:03 --> Controller Class Initialized
INFO - 2016-02-12 14:43:03 --> Model Class Initialized
INFO - 2016-02-12 14:43:03 --> Model Class Initialized
INFO - 2016-02-12 14:43:03 --> Form Validation Class Initialized
INFO - 2016-02-12 14:43:03 --> Helper loaded: text_helper
INFO - 2016-02-12 14:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 14:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 14:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-12 14:43:03 --> Final output sent to browser
DEBUG - 2016-02-12 14:43:03 --> Total execution time: 1.1846
INFO - 2016-02-12 14:43:22 --> Config Class Initialized
INFO - 2016-02-12 14:43:22 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:43:22 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:43:22 --> Utf8 Class Initialized
INFO - 2016-02-12 14:43:22 --> URI Class Initialized
DEBUG - 2016-02-12 14:43:22 --> No URI present. Default controller set.
INFO - 2016-02-12 14:43:22 --> Router Class Initialized
INFO - 2016-02-12 14:43:22 --> Output Class Initialized
INFO - 2016-02-12 14:43:22 --> Security Class Initialized
DEBUG - 2016-02-12 14:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:43:22 --> Input Class Initialized
INFO - 2016-02-12 14:43:22 --> Language Class Initialized
INFO - 2016-02-12 14:43:22 --> Loader Class Initialized
INFO - 2016-02-12 14:43:22 --> Helper loaded: url_helper
INFO - 2016-02-12 14:43:22 --> Helper loaded: file_helper
INFO - 2016-02-12 14:43:22 --> Helper loaded: date_helper
INFO - 2016-02-12 14:43:22 --> Helper loaded: form_helper
INFO - 2016-02-12 14:43:22 --> Database Driver Class Initialized
INFO - 2016-02-12 14:43:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:43:23 --> Controller Class Initialized
INFO - 2016-02-12 14:43:23 --> Model Class Initialized
INFO - 2016-02-12 14:43:23 --> Model Class Initialized
INFO - 2016-02-12 14:43:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:43:23 --> Pagination Class Initialized
INFO - 2016-02-12 14:43:23 --> Helper loaded: text_helper
INFO - 2016-02-12 17:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:43:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:43:23 --> Final output sent to browser
DEBUG - 2016-02-12 17:43:23 --> Total execution time: 1.1005
INFO - 2016-02-12 14:43:25 --> Config Class Initialized
INFO - 2016-02-12 14:43:25 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:43:25 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:43:25 --> Utf8 Class Initialized
INFO - 2016-02-12 14:43:25 --> URI Class Initialized
INFO - 2016-02-12 14:43:25 --> Router Class Initialized
INFO - 2016-02-12 14:43:25 --> Output Class Initialized
INFO - 2016-02-12 14:43:25 --> Security Class Initialized
DEBUG - 2016-02-12 14:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:43:25 --> Input Class Initialized
INFO - 2016-02-12 14:43:25 --> Language Class Initialized
INFO - 2016-02-12 14:43:25 --> Loader Class Initialized
INFO - 2016-02-12 14:43:25 --> Helper loaded: url_helper
INFO - 2016-02-12 14:43:25 --> Helper loaded: file_helper
INFO - 2016-02-12 14:43:25 --> Helper loaded: date_helper
INFO - 2016-02-12 14:43:25 --> Helper loaded: form_helper
INFO - 2016-02-12 14:43:25 --> Database Driver Class Initialized
INFO - 2016-02-12 14:43:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:43:26 --> Controller Class Initialized
INFO - 2016-02-12 14:43:26 --> Model Class Initialized
INFO - 2016-02-12 14:43:26 --> Model Class Initialized
INFO - 2016-02-12 14:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:43:26 --> Pagination Class Initialized
INFO - 2016-02-12 14:43:26 --> Helper loaded: text_helper
INFO - 2016-02-12 17:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:43:26 --> Final output sent to browser
DEBUG - 2016-02-12 17:43:26 --> Total execution time: 1.1001
INFO - 2016-02-12 14:43:28 --> Config Class Initialized
INFO - 2016-02-12 14:43:28 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:43:28 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:43:28 --> Utf8 Class Initialized
INFO - 2016-02-12 14:43:28 --> URI Class Initialized
INFO - 2016-02-12 14:43:28 --> Router Class Initialized
INFO - 2016-02-12 14:43:28 --> Output Class Initialized
INFO - 2016-02-12 14:43:28 --> Security Class Initialized
DEBUG - 2016-02-12 14:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:43:28 --> Input Class Initialized
INFO - 2016-02-12 14:43:28 --> Language Class Initialized
INFO - 2016-02-12 14:43:28 --> Loader Class Initialized
INFO - 2016-02-12 14:43:28 --> Helper loaded: url_helper
INFO - 2016-02-12 14:43:28 --> Helper loaded: file_helper
INFO - 2016-02-12 14:43:28 --> Helper loaded: date_helper
INFO - 2016-02-12 14:43:28 --> Helper loaded: form_helper
INFO - 2016-02-12 14:43:28 --> Database Driver Class Initialized
INFO - 2016-02-12 14:43:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:43:29 --> Controller Class Initialized
INFO - 2016-02-12 14:43:29 --> Model Class Initialized
INFO - 2016-02-12 14:43:29 --> Model Class Initialized
INFO - 2016-02-12 14:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:43:29 --> Pagination Class Initialized
INFO - 2016-02-12 14:43:29 --> Helper loaded: text_helper
INFO - 2016-02-12 17:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 17:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:43:30 --> Final output sent to browser
DEBUG - 2016-02-12 17:43:30 --> Total execution time: 1.2796
INFO - 2016-02-12 14:49:14 --> Config Class Initialized
INFO - 2016-02-12 14:49:14 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:49:14 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:49:14 --> Utf8 Class Initialized
INFO - 2016-02-12 14:49:14 --> URI Class Initialized
DEBUG - 2016-02-12 14:49:14 --> No URI present. Default controller set.
INFO - 2016-02-12 14:49:14 --> Router Class Initialized
INFO - 2016-02-12 14:49:14 --> Output Class Initialized
INFO - 2016-02-12 14:49:14 --> Security Class Initialized
DEBUG - 2016-02-12 14:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:49:14 --> Input Class Initialized
INFO - 2016-02-12 14:49:14 --> Language Class Initialized
INFO - 2016-02-12 14:49:14 --> Loader Class Initialized
INFO - 2016-02-12 14:49:14 --> Helper loaded: url_helper
INFO - 2016-02-12 14:49:14 --> Helper loaded: file_helper
INFO - 2016-02-12 14:49:14 --> Helper loaded: date_helper
INFO - 2016-02-12 14:49:14 --> Helper loaded: form_helper
INFO - 2016-02-12 14:49:14 --> Database Driver Class Initialized
INFO - 2016-02-12 14:49:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:49:15 --> Controller Class Initialized
INFO - 2016-02-12 14:49:15 --> Model Class Initialized
INFO - 2016-02-12 14:49:15 --> Model Class Initialized
INFO - 2016-02-12 14:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:49:15 --> Pagination Class Initialized
INFO - 2016-02-12 14:49:15 --> Helper loaded: text_helper
INFO - 2016-02-12 17:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:49:15 --> Final output sent to browser
DEBUG - 2016-02-12 17:49:15 --> Total execution time: 1.1184
INFO - 2016-02-12 14:49:20 --> Config Class Initialized
INFO - 2016-02-12 14:49:20 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:49:20 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:49:20 --> Utf8 Class Initialized
INFO - 2016-02-12 14:49:20 --> URI Class Initialized
INFO - 2016-02-12 14:49:20 --> Router Class Initialized
INFO - 2016-02-12 14:49:20 --> Output Class Initialized
INFO - 2016-02-12 14:49:20 --> Security Class Initialized
DEBUG - 2016-02-12 14:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:49:20 --> Input Class Initialized
INFO - 2016-02-12 14:49:20 --> Language Class Initialized
INFO - 2016-02-12 14:49:20 --> Loader Class Initialized
INFO - 2016-02-12 14:49:20 --> Helper loaded: url_helper
INFO - 2016-02-12 14:49:20 --> Helper loaded: file_helper
INFO - 2016-02-12 14:49:20 --> Helper loaded: date_helper
INFO - 2016-02-12 14:49:20 --> Helper loaded: form_helper
INFO - 2016-02-12 14:49:20 --> Database Driver Class Initialized
INFO - 2016-02-12 14:49:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:49:21 --> Controller Class Initialized
INFO - 2016-02-12 14:49:21 --> Model Class Initialized
INFO - 2016-02-12 14:49:21 --> Model Class Initialized
INFO - 2016-02-12 14:49:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:49:21 --> Pagination Class Initialized
INFO - 2016-02-12 14:49:21 --> Helper loaded: text_helper
INFO - 2016-02-12 17:49:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:49:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:49:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 17:49:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:49:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:49:21 --> Final output sent to browser
DEBUG - 2016-02-12 17:49:21 --> Total execution time: 1.1319
INFO - 2016-02-12 14:49:22 --> Config Class Initialized
INFO - 2016-02-12 14:49:22 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:49:22 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:49:22 --> Utf8 Class Initialized
INFO - 2016-02-12 14:49:22 --> URI Class Initialized
INFO - 2016-02-12 14:49:22 --> Router Class Initialized
INFO - 2016-02-12 14:49:22 --> Output Class Initialized
INFO - 2016-02-12 14:49:22 --> Security Class Initialized
DEBUG - 2016-02-12 14:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:49:22 --> Input Class Initialized
INFO - 2016-02-12 14:49:22 --> Language Class Initialized
INFO - 2016-02-12 14:49:22 --> Loader Class Initialized
INFO - 2016-02-12 14:49:22 --> Helper loaded: url_helper
INFO - 2016-02-12 14:49:22 --> Helper loaded: file_helper
INFO - 2016-02-12 14:49:22 --> Helper loaded: date_helper
INFO - 2016-02-12 14:49:22 --> Helper loaded: form_helper
INFO - 2016-02-12 14:49:22 --> Database Driver Class Initialized
INFO - 2016-02-12 14:49:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:49:23 --> Controller Class Initialized
INFO - 2016-02-12 14:49:23 --> Model Class Initialized
INFO - 2016-02-12 14:49:23 --> Model Class Initialized
INFO - 2016-02-12 14:49:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:49:23 --> Pagination Class Initialized
INFO - 2016-02-12 14:49:23 --> Helper loaded: text_helper
INFO - 2016-02-12 17:49:23 --> Final output sent to browser
DEBUG - 2016-02-12 17:49:23 --> Total execution time: 1.0767
INFO - 2016-02-12 14:50:04 --> Config Class Initialized
INFO - 2016-02-12 14:50:04 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:50:04 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:50:04 --> Utf8 Class Initialized
INFO - 2016-02-12 14:50:04 --> URI Class Initialized
DEBUG - 2016-02-12 14:50:04 --> No URI present. Default controller set.
INFO - 2016-02-12 14:50:04 --> Router Class Initialized
INFO - 2016-02-12 14:50:04 --> Output Class Initialized
INFO - 2016-02-12 14:50:04 --> Security Class Initialized
DEBUG - 2016-02-12 14:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:50:04 --> Input Class Initialized
INFO - 2016-02-12 14:50:04 --> Language Class Initialized
INFO - 2016-02-12 14:50:04 --> Loader Class Initialized
INFO - 2016-02-12 14:50:04 --> Helper loaded: url_helper
INFO - 2016-02-12 14:50:04 --> Helper loaded: file_helper
INFO - 2016-02-12 14:50:04 --> Helper loaded: date_helper
INFO - 2016-02-12 14:50:04 --> Helper loaded: form_helper
INFO - 2016-02-12 14:50:04 --> Database Driver Class Initialized
INFO - 2016-02-12 14:50:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:50:05 --> Controller Class Initialized
INFO - 2016-02-12 14:50:05 --> Model Class Initialized
INFO - 2016-02-12 14:50:05 --> Model Class Initialized
INFO - 2016-02-12 14:50:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:50:05 --> Pagination Class Initialized
INFO - 2016-02-12 14:50:05 --> Helper loaded: text_helper
INFO - 2016-02-12 17:50:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:50:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:50:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-12 17:50:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:50:05 --> Final output sent to browser
DEBUG - 2016-02-12 17:50:05 --> Total execution time: 1.1377
INFO - 2016-02-12 14:50:07 --> Config Class Initialized
INFO - 2016-02-12 14:50:07 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:50:07 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:50:07 --> Utf8 Class Initialized
INFO - 2016-02-12 14:50:07 --> URI Class Initialized
INFO - 2016-02-12 14:50:07 --> Router Class Initialized
INFO - 2016-02-12 14:50:07 --> Output Class Initialized
INFO - 2016-02-12 14:50:07 --> Security Class Initialized
DEBUG - 2016-02-12 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:50:07 --> Input Class Initialized
INFO - 2016-02-12 14:50:07 --> Language Class Initialized
INFO - 2016-02-12 14:50:07 --> Loader Class Initialized
INFO - 2016-02-12 14:50:07 --> Helper loaded: url_helper
INFO - 2016-02-12 14:50:07 --> Helper loaded: file_helper
INFO - 2016-02-12 14:50:07 --> Helper loaded: date_helper
INFO - 2016-02-12 14:50:07 --> Helper loaded: form_helper
INFO - 2016-02-12 14:50:07 --> Database Driver Class Initialized
INFO - 2016-02-12 14:50:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:50:08 --> Controller Class Initialized
INFO - 2016-02-12 14:50:08 --> Model Class Initialized
INFO - 2016-02-12 14:50:08 --> Model Class Initialized
INFO - 2016-02-12 14:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:50:08 --> Pagination Class Initialized
INFO - 2016-02-12 14:50:08 --> Helper loaded: text_helper
INFO - 2016-02-12 17:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-12 17:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-12 17:50:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-12 17:50:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-12 17:50:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-12 17:50:09 --> Final output sent to browser
DEBUG - 2016-02-12 17:50:09 --> Total execution time: 1.1304
INFO - 2016-02-12 14:50:10 --> Config Class Initialized
INFO - 2016-02-12 14:50:10 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:50:10 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:50:10 --> Utf8 Class Initialized
INFO - 2016-02-12 14:50:10 --> URI Class Initialized
INFO - 2016-02-12 14:50:10 --> Router Class Initialized
INFO - 2016-02-12 14:50:10 --> Output Class Initialized
INFO - 2016-02-12 14:50:10 --> Security Class Initialized
DEBUG - 2016-02-12 14:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:50:10 --> Input Class Initialized
INFO - 2016-02-12 14:50:10 --> Language Class Initialized
INFO - 2016-02-12 14:50:10 --> Loader Class Initialized
INFO - 2016-02-12 14:50:10 --> Helper loaded: url_helper
INFO - 2016-02-12 14:50:10 --> Helper loaded: file_helper
INFO - 2016-02-12 14:50:10 --> Helper loaded: date_helper
INFO - 2016-02-12 14:50:10 --> Helper loaded: form_helper
INFO - 2016-02-12 14:50:10 --> Database Driver Class Initialized
INFO - 2016-02-12 14:50:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:50:11 --> Controller Class Initialized
INFO - 2016-02-12 14:50:11 --> Model Class Initialized
INFO - 2016-02-12 14:50:11 --> Model Class Initialized
INFO - 2016-02-12 14:50:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:50:11 --> Pagination Class Initialized
INFO - 2016-02-12 14:50:11 --> Helper loaded: text_helper
INFO - 2016-02-12 17:50:11 --> Final output sent to browser
DEBUG - 2016-02-12 17:50:11 --> Total execution time: 1.1015
INFO - 2016-02-12 14:50:30 --> Config Class Initialized
INFO - 2016-02-12 14:50:30 --> Hooks Class Initialized
DEBUG - 2016-02-12 14:50:30 --> UTF-8 Support Enabled
INFO - 2016-02-12 14:50:30 --> Utf8 Class Initialized
INFO - 2016-02-12 14:50:30 --> URI Class Initialized
INFO - 2016-02-12 14:50:30 --> Router Class Initialized
INFO - 2016-02-12 14:50:30 --> Output Class Initialized
INFO - 2016-02-12 14:50:30 --> Security Class Initialized
DEBUG - 2016-02-12 14:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-12 14:50:30 --> Input Class Initialized
INFO - 2016-02-12 14:50:30 --> Language Class Initialized
INFO - 2016-02-12 14:50:30 --> Loader Class Initialized
INFO - 2016-02-12 14:50:30 --> Helper loaded: url_helper
INFO - 2016-02-12 14:50:30 --> Helper loaded: file_helper
INFO - 2016-02-12 14:50:30 --> Helper loaded: date_helper
INFO - 2016-02-12 14:50:30 --> Helper loaded: form_helper
INFO - 2016-02-12 14:50:30 --> Database Driver Class Initialized
INFO - 2016-02-12 14:50:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-12 14:50:31 --> Controller Class Initialized
INFO - 2016-02-12 14:50:31 --> Model Class Initialized
INFO - 2016-02-12 14:50:31 --> Model Class Initialized
INFO - 2016-02-12 14:50:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-12 14:50:31 --> Pagination Class Initialized
INFO - 2016-02-12 14:50:31 --> Helper loaded: text_helper
INFO - 2016-02-12 17:50:31 --> Final output sent to browser
DEBUG - 2016-02-12 17:50:31 --> Total execution time: 1.0787
