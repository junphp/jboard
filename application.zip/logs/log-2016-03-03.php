<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-03 05:04:33 --> Config Class Initialized
INFO - 2016-03-03 05:04:33 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:04:33 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:04:33 --> Utf8 Class Initialized
INFO - 2016-03-03 05:04:33 --> URI Class Initialized
INFO - 2016-03-03 05:04:33 --> Router Class Initialized
INFO - 2016-03-03 05:04:33 --> Output Class Initialized
INFO - 2016-03-03 05:04:33 --> Security Class Initialized
DEBUG - 2016-03-03 05:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:04:33 --> Input Class Initialized
INFO - 2016-03-03 05:04:33 --> Language Class Initialized
INFO - 2016-03-03 05:04:33 --> Loader Class Initialized
INFO - 2016-03-03 05:04:33 --> Helper loaded: url_helper
INFO - 2016-03-03 05:04:33 --> Helper loaded: file_helper
INFO - 2016-03-03 05:04:33 --> Helper loaded: date_helper
INFO - 2016-03-03 05:04:33 --> Helper loaded: form_helper
INFO - 2016-03-03 05:04:33 --> Database Driver Class Initialized
INFO - 2016-03-03 05:04:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:04:34 --> Controller Class Initialized
INFO - 2016-03-03 05:04:34 --> Model Class Initialized
INFO - 2016-03-03 05:04:34 --> Model Class Initialized
INFO - 2016-03-03 05:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:04:34 --> Pagination Class Initialized
INFO - 2016-03-03 05:04:34 --> Helper loaded: text_helper
INFO - 2016-03-03 05:04:34 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 08:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:04:34 --> Final output sent to browser
DEBUG - 2016-03-03 08:04:34 --> Total execution time: 1.0856
INFO - 2016-03-03 05:04:47 --> Config Class Initialized
INFO - 2016-03-03 05:04:47 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:04:47 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:04:47 --> Utf8 Class Initialized
INFO - 2016-03-03 05:04:47 --> URI Class Initialized
INFO - 2016-03-03 05:04:47 --> Router Class Initialized
INFO - 2016-03-03 05:04:47 --> Output Class Initialized
INFO - 2016-03-03 05:04:47 --> Security Class Initialized
DEBUG - 2016-03-03 05:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:04:47 --> Input Class Initialized
INFO - 2016-03-03 05:04:47 --> Language Class Initialized
INFO - 2016-03-03 05:04:47 --> Loader Class Initialized
INFO - 2016-03-03 05:04:47 --> Helper loaded: url_helper
INFO - 2016-03-03 05:04:47 --> Helper loaded: file_helper
INFO - 2016-03-03 05:04:47 --> Helper loaded: date_helper
INFO - 2016-03-03 05:04:47 --> Helper loaded: form_helper
INFO - 2016-03-03 05:04:47 --> Database Driver Class Initialized
INFO - 2016-03-03 05:04:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:04:48 --> Controller Class Initialized
INFO - 2016-03-03 05:04:48 --> Model Class Initialized
INFO - 2016-03-03 05:04:48 --> Model Class Initialized
INFO - 2016-03-03 05:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:04:48 --> Pagination Class Initialized
INFO - 2016-03-03 05:04:48 --> Helper loaded: text_helper
INFO - 2016-03-03 05:04:48 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 08:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:04:48 --> Final output sent to browser
DEBUG - 2016-03-03 08:04:48 --> Total execution time: 1.0782
INFO - 2016-03-03 05:10:21 --> Config Class Initialized
INFO - 2016-03-03 05:10:21 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:10:21 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:10:21 --> Utf8 Class Initialized
INFO - 2016-03-03 05:10:21 --> URI Class Initialized
INFO - 2016-03-03 05:10:21 --> Router Class Initialized
INFO - 2016-03-03 05:10:21 --> Output Class Initialized
INFO - 2016-03-03 05:10:21 --> Security Class Initialized
DEBUG - 2016-03-03 05:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:10:21 --> Input Class Initialized
INFO - 2016-03-03 05:10:21 --> Language Class Initialized
INFO - 2016-03-03 05:10:21 --> Loader Class Initialized
INFO - 2016-03-03 05:10:21 --> Helper loaded: url_helper
INFO - 2016-03-03 05:10:21 --> Helper loaded: file_helper
INFO - 2016-03-03 05:10:22 --> Helper loaded: date_helper
INFO - 2016-03-03 05:10:22 --> Helper loaded: form_helper
INFO - 2016-03-03 05:10:22 --> Database Driver Class Initialized
INFO - 2016-03-03 05:10:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:10:23 --> Controller Class Initialized
INFO - 2016-03-03 05:10:23 --> Model Class Initialized
INFO - 2016-03-03 05:10:23 --> Model Class Initialized
INFO - 2016-03-03 05:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:10:23 --> Pagination Class Initialized
INFO - 2016-03-03 05:10:23 --> Helper loaded: text_helper
INFO - 2016-03-03 05:10:23 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 08:10:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:10:23 --> Final output sent to browser
DEBUG - 2016-03-03 08:10:23 --> Total execution time: 1.1284
INFO - 2016-03-03 05:10:31 --> Config Class Initialized
INFO - 2016-03-03 05:10:31 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:10:31 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:10:31 --> Utf8 Class Initialized
INFO - 2016-03-03 05:10:31 --> URI Class Initialized
INFO - 2016-03-03 05:10:31 --> Router Class Initialized
INFO - 2016-03-03 05:10:31 --> Output Class Initialized
INFO - 2016-03-03 05:10:31 --> Security Class Initialized
DEBUG - 2016-03-03 05:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:10:31 --> Input Class Initialized
INFO - 2016-03-03 05:10:31 --> Language Class Initialized
INFO - 2016-03-03 05:10:31 --> Loader Class Initialized
INFO - 2016-03-03 05:10:31 --> Helper loaded: url_helper
INFO - 2016-03-03 05:10:31 --> Helper loaded: file_helper
INFO - 2016-03-03 05:10:31 --> Helper loaded: date_helper
INFO - 2016-03-03 05:10:31 --> Helper loaded: form_helper
INFO - 2016-03-03 05:10:31 --> Database Driver Class Initialized
INFO - 2016-03-03 05:10:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:10:32 --> Controller Class Initialized
INFO - 2016-03-03 05:10:32 --> Model Class Initialized
INFO - 2016-03-03 05:10:32 --> Model Class Initialized
INFO - 2016-03-03 05:10:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:10:32 --> Pagination Class Initialized
INFO - 2016-03-03 05:10:32 --> Helper loaded: text_helper
INFO - 2016-03-03 05:10:32 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:10:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:10:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:10:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 08:10:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:10:32 --> Final output sent to browser
DEBUG - 2016-03-03 08:10:32 --> Total execution time: 1.0966
INFO - 2016-03-03 05:12:05 --> Config Class Initialized
INFO - 2016-03-03 05:12:05 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:12:05 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:12:05 --> Utf8 Class Initialized
INFO - 2016-03-03 05:12:05 --> URI Class Initialized
INFO - 2016-03-03 05:12:05 --> Router Class Initialized
INFO - 2016-03-03 05:12:05 --> Output Class Initialized
INFO - 2016-03-03 05:12:05 --> Security Class Initialized
DEBUG - 2016-03-03 05:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:12:05 --> Input Class Initialized
INFO - 2016-03-03 05:12:05 --> Language Class Initialized
INFO - 2016-03-03 05:12:05 --> Loader Class Initialized
INFO - 2016-03-03 05:12:05 --> Helper loaded: url_helper
INFO - 2016-03-03 05:12:05 --> Helper loaded: file_helper
INFO - 2016-03-03 05:12:05 --> Helper loaded: date_helper
INFO - 2016-03-03 05:12:05 --> Helper loaded: form_helper
INFO - 2016-03-03 05:12:05 --> Database Driver Class Initialized
INFO - 2016-03-03 05:12:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:12:06 --> Controller Class Initialized
INFO - 2016-03-03 05:12:06 --> Model Class Initialized
INFO - 2016-03-03 05:12:06 --> Model Class Initialized
INFO - 2016-03-03 05:12:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:12:06 --> Pagination Class Initialized
INFO - 2016-03-03 05:12:06 --> Helper loaded: text_helper
INFO - 2016-03-03 05:12:06 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 08:12:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:12:06 --> Final output sent to browser
DEBUG - 2016-03-03 08:12:06 --> Total execution time: 1.1227
INFO - 2016-03-03 05:12:28 --> Config Class Initialized
INFO - 2016-03-03 05:12:28 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:12:28 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:12:28 --> Utf8 Class Initialized
INFO - 2016-03-03 05:12:28 --> URI Class Initialized
INFO - 2016-03-03 05:12:28 --> Router Class Initialized
INFO - 2016-03-03 05:12:28 --> Output Class Initialized
INFO - 2016-03-03 05:12:28 --> Security Class Initialized
DEBUG - 2016-03-03 05:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:12:28 --> Input Class Initialized
INFO - 2016-03-03 05:12:28 --> Language Class Initialized
INFO - 2016-03-03 05:12:28 --> Loader Class Initialized
INFO - 2016-03-03 05:12:28 --> Helper loaded: url_helper
INFO - 2016-03-03 05:12:28 --> Helper loaded: file_helper
INFO - 2016-03-03 05:12:28 --> Helper loaded: date_helper
INFO - 2016-03-03 05:12:28 --> Helper loaded: form_helper
INFO - 2016-03-03 05:12:28 --> Database Driver Class Initialized
INFO - 2016-03-03 05:12:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:12:29 --> Controller Class Initialized
INFO - 2016-03-03 05:12:29 --> Model Class Initialized
INFO - 2016-03-03 05:12:29 --> Model Class Initialized
INFO - 2016-03-03 05:12:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:12:29 --> Pagination Class Initialized
INFO - 2016-03-03 05:12:29 --> Helper loaded: text_helper
INFO - 2016-03-03 05:12:29 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 08:12:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:12:29 --> Final output sent to browser
DEBUG - 2016-03-03 08:12:29 --> Total execution time: 1.1029
INFO - 2016-03-03 05:14:09 --> Config Class Initialized
INFO - 2016-03-03 05:14:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:14:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:14:09 --> Utf8 Class Initialized
INFO - 2016-03-03 05:14:09 --> URI Class Initialized
INFO - 2016-03-03 05:14:09 --> Router Class Initialized
INFO - 2016-03-03 05:14:09 --> Output Class Initialized
INFO - 2016-03-03 05:14:09 --> Security Class Initialized
DEBUG - 2016-03-03 05:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:14:09 --> Input Class Initialized
INFO - 2016-03-03 05:14:09 --> Language Class Initialized
INFO - 2016-03-03 05:14:09 --> Loader Class Initialized
INFO - 2016-03-03 05:14:09 --> Helper loaded: url_helper
INFO - 2016-03-03 05:14:09 --> Helper loaded: file_helper
INFO - 2016-03-03 05:14:09 --> Helper loaded: date_helper
INFO - 2016-03-03 05:14:09 --> Helper loaded: form_helper
INFO - 2016-03-03 05:14:09 --> Database Driver Class Initialized
INFO - 2016-03-03 05:14:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:14:10 --> Controller Class Initialized
INFO - 2016-03-03 05:14:10 --> Model Class Initialized
INFO - 2016-03-03 05:14:10 --> Model Class Initialized
INFO - 2016-03-03 05:14:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:14:10 --> Pagination Class Initialized
INFO - 2016-03-03 05:14:11 --> Helper loaded: text_helper
INFO - 2016-03-03 05:14:11 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 08:14:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:14:11 --> Final output sent to browser
DEBUG - 2016-03-03 08:14:11 --> Total execution time: 1.1278
INFO - 2016-03-03 05:16:53 --> Config Class Initialized
INFO - 2016-03-03 05:16:53 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:16:53 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:16:53 --> Utf8 Class Initialized
INFO - 2016-03-03 05:16:53 --> URI Class Initialized
INFO - 2016-03-03 05:16:53 --> Router Class Initialized
INFO - 2016-03-03 05:16:53 --> Output Class Initialized
INFO - 2016-03-03 05:16:53 --> Security Class Initialized
DEBUG - 2016-03-03 05:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:16:53 --> Input Class Initialized
INFO - 2016-03-03 05:16:53 --> Language Class Initialized
INFO - 2016-03-03 05:16:53 --> Loader Class Initialized
INFO - 2016-03-03 05:16:53 --> Helper loaded: url_helper
INFO - 2016-03-03 05:16:53 --> Helper loaded: file_helper
INFO - 2016-03-03 05:16:53 --> Helper loaded: date_helper
INFO - 2016-03-03 05:16:53 --> Helper loaded: form_helper
INFO - 2016-03-03 05:16:53 --> Database Driver Class Initialized
INFO - 2016-03-03 05:16:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:16:54 --> Controller Class Initialized
INFO - 2016-03-03 05:16:54 --> Model Class Initialized
INFO - 2016-03-03 05:16:54 --> Model Class Initialized
INFO - 2016-03-03 05:16:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:16:54 --> Pagination Class Initialized
INFO - 2016-03-03 05:16:54 --> Helper loaded: text_helper
INFO - 2016-03-03 05:16:54 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 08:16:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:16:54 --> Final output sent to browser
DEBUG - 2016-03-03 08:16:54 --> Total execution time: 1.1564
INFO - 2016-03-03 05:17:18 --> Config Class Initialized
INFO - 2016-03-03 05:17:18 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:17:18 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:17:18 --> Utf8 Class Initialized
INFO - 2016-03-03 05:17:18 --> URI Class Initialized
INFO - 2016-03-03 05:17:18 --> Router Class Initialized
INFO - 2016-03-03 05:17:18 --> Output Class Initialized
INFO - 2016-03-03 05:17:18 --> Security Class Initialized
DEBUG - 2016-03-03 05:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:17:18 --> Input Class Initialized
INFO - 2016-03-03 05:17:18 --> Language Class Initialized
INFO - 2016-03-03 05:17:18 --> Loader Class Initialized
INFO - 2016-03-03 05:17:18 --> Helper loaded: url_helper
INFO - 2016-03-03 05:17:18 --> Helper loaded: file_helper
INFO - 2016-03-03 05:17:18 --> Helper loaded: date_helper
INFO - 2016-03-03 05:17:18 --> Helper loaded: form_helper
INFO - 2016-03-03 05:17:18 --> Database Driver Class Initialized
INFO - 2016-03-03 05:17:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:17:19 --> Controller Class Initialized
INFO - 2016-03-03 05:17:19 --> Model Class Initialized
INFO - 2016-03-03 05:17:19 --> Model Class Initialized
INFO - 2016-03-03 05:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:17:20 --> Pagination Class Initialized
INFO - 2016-03-03 05:17:20 --> Helper loaded: text_helper
INFO - 2016-03-03 05:17:20 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:17:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:17:20 --> Final output sent to browser
DEBUG - 2016-03-03 08:17:20 --> Total execution time: 1.1430
INFO - 2016-03-03 05:19:09 --> Config Class Initialized
INFO - 2016-03-03 05:19:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:19:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:19:09 --> Utf8 Class Initialized
INFO - 2016-03-03 05:19:09 --> URI Class Initialized
INFO - 2016-03-03 05:19:09 --> Router Class Initialized
INFO - 2016-03-03 05:19:09 --> Output Class Initialized
INFO - 2016-03-03 05:19:09 --> Security Class Initialized
DEBUG - 2016-03-03 05:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:19:09 --> Input Class Initialized
INFO - 2016-03-03 05:19:09 --> Language Class Initialized
INFO - 2016-03-03 05:19:09 --> Loader Class Initialized
INFO - 2016-03-03 05:19:09 --> Helper loaded: url_helper
INFO - 2016-03-03 05:19:09 --> Helper loaded: file_helper
INFO - 2016-03-03 05:19:09 --> Helper loaded: date_helper
INFO - 2016-03-03 05:19:09 --> Helper loaded: form_helper
INFO - 2016-03-03 05:19:09 --> Database Driver Class Initialized
INFO - 2016-03-03 05:19:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:19:10 --> Controller Class Initialized
INFO - 2016-03-03 05:19:10 --> Model Class Initialized
INFO - 2016-03-03 05:19:11 --> Model Class Initialized
INFO - 2016-03-03 05:19:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:19:11 --> Pagination Class Initialized
INFO - 2016-03-03 05:19:11 --> Helper loaded: text_helper
INFO - 2016-03-03 05:19:11 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:19:11 --> Final output sent to browser
DEBUG - 2016-03-03 08:19:11 --> Total execution time: 1.1678
INFO - 2016-03-03 05:19:58 --> Config Class Initialized
INFO - 2016-03-03 05:19:58 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:19:58 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:19:58 --> Utf8 Class Initialized
INFO - 2016-03-03 05:19:58 --> URI Class Initialized
INFO - 2016-03-03 05:19:58 --> Router Class Initialized
INFO - 2016-03-03 05:19:58 --> Output Class Initialized
INFO - 2016-03-03 05:19:58 --> Security Class Initialized
DEBUG - 2016-03-03 05:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:19:58 --> Input Class Initialized
INFO - 2016-03-03 05:19:58 --> Language Class Initialized
INFO - 2016-03-03 05:19:58 --> Loader Class Initialized
INFO - 2016-03-03 05:19:58 --> Helper loaded: url_helper
INFO - 2016-03-03 05:19:58 --> Helper loaded: file_helper
INFO - 2016-03-03 05:19:58 --> Helper loaded: date_helper
INFO - 2016-03-03 05:19:58 --> Helper loaded: form_helper
INFO - 2016-03-03 05:19:58 --> Database Driver Class Initialized
INFO - 2016-03-03 05:19:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:19:59 --> Controller Class Initialized
INFO - 2016-03-03 05:19:59 --> Model Class Initialized
INFO - 2016-03-03 05:19:59 --> Model Class Initialized
INFO - 2016-03-03 05:19:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:19:59 --> Pagination Class Initialized
INFO - 2016-03-03 05:19:59 --> Helper loaded: text_helper
INFO - 2016-03-03 05:19:59 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:19:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:19:59 --> Final output sent to browser
DEBUG - 2016-03-03 08:19:59 --> Total execution time: 1.1816
INFO - 2016-03-03 05:20:31 --> Config Class Initialized
INFO - 2016-03-03 05:20:31 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:20:31 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:20:31 --> Utf8 Class Initialized
INFO - 2016-03-03 05:20:31 --> URI Class Initialized
INFO - 2016-03-03 05:20:31 --> Router Class Initialized
INFO - 2016-03-03 05:20:31 --> Output Class Initialized
INFO - 2016-03-03 05:20:31 --> Security Class Initialized
DEBUG - 2016-03-03 05:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:20:31 --> Input Class Initialized
INFO - 2016-03-03 05:20:31 --> Language Class Initialized
INFO - 2016-03-03 05:20:31 --> Loader Class Initialized
INFO - 2016-03-03 05:20:31 --> Helper loaded: url_helper
INFO - 2016-03-03 05:20:31 --> Helper loaded: file_helper
INFO - 2016-03-03 05:20:31 --> Helper loaded: date_helper
INFO - 2016-03-03 05:20:31 --> Helper loaded: form_helper
INFO - 2016-03-03 05:20:31 --> Database Driver Class Initialized
INFO - 2016-03-03 05:20:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:20:32 --> Controller Class Initialized
INFO - 2016-03-03 05:20:32 --> Model Class Initialized
INFO - 2016-03-03 05:20:32 --> Model Class Initialized
INFO - 2016-03-03 05:20:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:20:32 --> Pagination Class Initialized
INFO - 2016-03-03 05:20:32 --> Helper loaded: text_helper
INFO - 2016-03-03 05:20:32 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:20:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:20:32 --> Final output sent to browser
DEBUG - 2016-03-03 08:20:32 --> Total execution time: 1.1807
INFO - 2016-03-03 05:20:48 --> Config Class Initialized
INFO - 2016-03-03 05:20:48 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:20:48 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:20:48 --> Utf8 Class Initialized
INFO - 2016-03-03 05:20:48 --> URI Class Initialized
INFO - 2016-03-03 05:20:48 --> Router Class Initialized
INFO - 2016-03-03 05:20:48 --> Output Class Initialized
INFO - 2016-03-03 05:20:48 --> Security Class Initialized
DEBUG - 2016-03-03 05:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:20:48 --> Input Class Initialized
INFO - 2016-03-03 05:20:48 --> Language Class Initialized
INFO - 2016-03-03 05:20:48 --> Loader Class Initialized
INFO - 2016-03-03 05:20:48 --> Helper loaded: url_helper
INFO - 2016-03-03 05:20:48 --> Helper loaded: file_helper
INFO - 2016-03-03 05:20:48 --> Helper loaded: date_helper
INFO - 2016-03-03 05:20:48 --> Helper loaded: form_helper
INFO - 2016-03-03 05:20:48 --> Database Driver Class Initialized
INFO - 2016-03-03 05:20:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:20:50 --> Controller Class Initialized
INFO - 2016-03-03 05:20:50 --> Model Class Initialized
INFO - 2016-03-03 05:20:50 --> Model Class Initialized
INFO - 2016-03-03 05:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:20:50 --> Pagination Class Initialized
INFO - 2016-03-03 05:20:50 --> Helper loaded: text_helper
INFO - 2016-03-03 05:20:50 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:20:50 --> Final output sent to browser
DEBUG - 2016-03-03 08:20:50 --> Total execution time: 1.1355
INFO - 2016-03-03 05:21:14 --> Config Class Initialized
INFO - 2016-03-03 05:21:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:21:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:21:14 --> Utf8 Class Initialized
INFO - 2016-03-03 05:21:14 --> URI Class Initialized
INFO - 2016-03-03 05:21:14 --> Router Class Initialized
INFO - 2016-03-03 05:21:14 --> Output Class Initialized
INFO - 2016-03-03 05:21:14 --> Security Class Initialized
DEBUG - 2016-03-03 05:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:21:14 --> Input Class Initialized
INFO - 2016-03-03 05:21:14 --> Language Class Initialized
INFO - 2016-03-03 05:21:14 --> Loader Class Initialized
INFO - 2016-03-03 05:21:14 --> Helper loaded: url_helper
INFO - 2016-03-03 05:21:14 --> Helper loaded: file_helper
INFO - 2016-03-03 05:21:14 --> Helper loaded: date_helper
INFO - 2016-03-03 05:21:14 --> Helper loaded: form_helper
INFO - 2016-03-03 05:21:14 --> Database Driver Class Initialized
INFO - 2016-03-03 05:21:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:21:15 --> Controller Class Initialized
INFO - 2016-03-03 05:21:15 --> Model Class Initialized
INFO - 2016-03-03 05:21:15 --> Model Class Initialized
INFO - 2016-03-03 05:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:21:15 --> Pagination Class Initialized
INFO - 2016-03-03 05:21:15 --> Helper loaded: text_helper
INFO - 2016-03-03 05:21:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:21:15 --> Final output sent to browser
DEBUG - 2016-03-03 08:21:15 --> Total execution time: 1.1651
INFO - 2016-03-03 05:21:34 --> Config Class Initialized
INFO - 2016-03-03 05:21:34 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:21:34 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:21:34 --> Utf8 Class Initialized
INFO - 2016-03-03 05:21:34 --> URI Class Initialized
INFO - 2016-03-03 05:21:34 --> Router Class Initialized
INFO - 2016-03-03 05:21:34 --> Output Class Initialized
INFO - 2016-03-03 05:21:34 --> Security Class Initialized
DEBUG - 2016-03-03 05:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:21:34 --> Input Class Initialized
INFO - 2016-03-03 05:21:34 --> Language Class Initialized
INFO - 2016-03-03 05:21:35 --> Loader Class Initialized
INFO - 2016-03-03 05:21:35 --> Helper loaded: url_helper
INFO - 2016-03-03 05:21:35 --> Helper loaded: file_helper
INFO - 2016-03-03 05:21:35 --> Helper loaded: date_helper
INFO - 2016-03-03 05:21:35 --> Helper loaded: form_helper
INFO - 2016-03-03 05:21:35 --> Database Driver Class Initialized
INFO - 2016-03-03 05:21:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:21:36 --> Controller Class Initialized
INFO - 2016-03-03 05:21:36 --> Model Class Initialized
INFO - 2016-03-03 05:21:36 --> Model Class Initialized
INFO - 2016-03-03 05:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:21:36 --> Pagination Class Initialized
INFO - 2016-03-03 05:21:36 --> Helper loaded: text_helper
INFO - 2016-03-03 05:21:36 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:21:36 --> Final output sent to browser
DEBUG - 2016-03-03 08:21:36 --> Total execution time: 1.1534
INFO - 2016-03-03 05:21:54 --> Config Class Initialized
INFO - 2016-03-03 05:21:54 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:21:54 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:21:54 --> Utf8 Class Initialized
INFO - 2016-03-03 05:21:54 --> URI Class Initialized
INFO - 2016-03-03 05:21:54 --> Router Class Initialized
INFO - 2016-03-03 05:21:54 --> Output Class Initialized
INFO - 2016-03-03 05:21:54 --> Security Class Initialized
DEBUG - 2016-03-03 05:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:21:54 --> Input Class Initialized
INFO - 2016-03-03 05:21:54 --> Language Class Initialized
INFO - 2016-03-03 05:21:54 --> Loader Class Initialized
INFO - 2016-03-03 05:21:54 --> Helper loaded: url_helper
INFO - 2016-03-03 05:21:54 --> Helper loaded: file_helper
INFO - 2016-03-03 05:21:54 --> Helper loaded: date_helper
INFO - 2016-03-03 05:21:54 --> Helper loaded: form_helper
INFO - 2016-03-03 05:21:54 --> Database Driver Class Initialized
INFO - 2016-03-03 05:21:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:21:55 --> Controller Class Initialized
INFO - 2016-03-03 05:21:55 --> Model Class Initialized
INFO - 2016-03-03 05:21:55 --> Model Class Initialized
INFO - 2016-03-03 05:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:21:55 --> Pagination Class Initialized
INFO - 2016-03-03 05:21:55 --> Helper loaded: text_helper
INFO - 2016-03-03 05:21:55 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:21:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:21:55 --> Final output sent to browser
DEBUG - 2016-03-03 08:21:55 --> Total execution time: 1.2419
INFO - 2016-03-03 05:22:25 --> Config Class Initialized
INFO - 2016-03-03 05:22:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:22:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:22:25 --> Utf8 Class Initialized
INFO - 2016-03-03 05:22:25 --> URI Class Initialized
INFO - 2016-03-03 05:22:25 --> Router Class Initialized
INFO - 2016-03-03 05:22:25 --> Output Class Initialized
INFO - 2016-03-03 05:22:25 --> Security Class Initialized
DEBUG - 2016-03-03 05:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:22:25 --> Input Class Initialized
INFO - 2016-03-03 05:22:25 --> Language Class Initialized
INFO - 2016-03-03 05:22:25 --> Loader Class Initialized
INFO - 2016-03-03 05:22:25 --> Helper loaded: url_helper
INFO - 2016-03-03 05:22:25 --> Helper loaded: file_helper
INFO - 2016-03-03 05:22:25 --> Helper loaded: date_helper
INFO - 2016-03-03 05:22:25 --> Helper loaded: form_helper
INFO - 2016-03-03 05:22:25 --> Database Driver Class Initialized
INFO - 2016-03-03 05:22:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:22:26 --> Controller Class Initialized
INFO - 2016-03-03 05:22:26 --> Model Class Initialized
INFO - 2016-03-03 05:22:26 --> Model Class Initialized
INFO - 2016-03-03 05:22:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:22:26 --> Pagination Class Initialized
INFO - 2016-03-03 05:22:26 --> Helper loaded: text_helper
INFO - 2016-03-03 05:22:26 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:22:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:22:26 --> Final output sent to browser
DEBUG - 2016-03-03 08:22:26 --> Total execution time: 1.1482
INFO - 2016-03-03 05:24:06 --> Config Class Initialized
INFO - 2016-03-03 05:24:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:24:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:24:06 --> Utf8 Class Initialized
INFO - 2016-03-03 05:24:06 --> URI Class Initialized
INFO - 2016-03-03 05:24:06 --> Router Class Initialized
INFO - 2016-03-03 05:24:06 --> Output Class Initialized
INFO - 2016-03-03 05:24:06 --> Security Class Initialized
DEBUG - 2016-03-03 05:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:24:06 --> Input Class Initialized
INFO - 2016-03-03 05:24:06 --> Language Class Initialized
INFO - 2016-03-03 05:24:06 --> Loader Class Initialized
INFO - 2016-03-03 05:24:06 --> Helper loaded: url_helper
INFO - 2016-03-03 05:24:06 --> Helper loaded: file_helper
INFO - 2016-03-03 05:24:06 --> Helper loaded: date_helper
INFO - 2016-03-03 05:24:06 --> Helper loaded: form_helper
INFO - 2016-03-03 05:24:06 --> Database Driver Class Initialized
INFO - 2016-03-03 05:24:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:24:07 --> Controller Class Initialized
INFO - 2016-03-03 05:24:07 --> Model Class Initialized
INFO - 2016-03-03 05:24:07 --> Model Class Initialized
INFO - 2016-03-03 05:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:24:07 --> Pagination Class Initialized
INFO - 2016-03-03 05:24:07 --> Helper loaded: text_helper
INFO - 2016-03-03 05:24:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:24:07 --> Final output sent to browser
DEBUG - 2016-03-03 08:24:07 --> Total execution time: 1.1750
INFO - 2016-03-03 05:24:07 --> Config Class Initialized
INFO - 2016-03-03 05:24:07 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:24:07 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:24:07 --> Utf8 Class Initialized
INFO - 2016-03-03 05:24:07 --> URI Class Initialized
INFO - 2016-03-03 05:24:07 --> Router Class Initialized
INFO - 2016-03-03 05:24:07 --> Output Class Initialized
INFO - 2016-03-03 05:24:07 --> Security Class Initialized
DEBUG - 2016-03-03 05:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:24:07 --> Input Class Initialized
INFO - 2016-03-03 05:24:07 --> Language Class Initialized
ERROR - 2016-03-03 05:24:07 --> 404 Page Not Found: Img/fighternew_31601.png
INFO - 2016-03-03 05:24:24 --> Config Class Initialized
INFO - 2016-03-03 05:24:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:24:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:24:24 --> Utf8 Class Initialized
INFO - 2016-03-03 05:24:24 --> URI Class Initialized
INFO - 2016-03-03 05:24:24 --> Router Class Initialized
INFO - 2016-03-03 05:24:24 --> Output Class Initialized
INFO - 2016-03-03 05:24:24 --> Security Class Initialized
DEBUG - 2016-03-03 05:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:24:24 --> Input Class Initialized
INFO - 2016-03-03 05:24:24 --> Language Class Initialized
INFO - 2016-03-03 05:24:24 --> Loader Class Initialized
INFO - 2016-03-03 05:24:24 --> Helper loaded: url_helper
INFO - 2016-03-03 05:24:24 --> Helper loaded: file_helper
INFO - 2016-03-03 05:24:24 --> Helper loaded: date_helper
INFO - 2016-03-03 05:24:24 --> Helper loaded: form_helper
INFO - 2016-03-03 05:24:24 --> Database Driver Class Initialized
INFO - 2016-03-03 05:24:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:24:25 --> Controller Class Initialized
INFO - 2016-03-03 05:24:25 --> Model Class Initialized
INFO - 2016-03-03 05:24:25 --> Model Class Initialized
INFO - 2016-03-03 05:24:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:24:25 --> Pagination Class Initialized
INFO - 2016-03-03 05:24:25 --> Helper loaded: text_helper
INFO - 2016-03-03 05:24:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:24:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:24:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:24:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:24:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:24:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:24:25 --> Final output sent to browser
DEBUG - 2016-03-03 08:24:25 --> Total execution time: 1.1557
INFO - 2016-03-03 05:24:25 --> Config Class Initialized
INFO - 2016-03-03 05:24:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:24:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:24:25 --> Utf8 Class Initialized
INFO - 2016-03-03 05:24:25 --> URI Class Initialized
INFO - 2016-03-03 05:24:25 --> Router Class Initialized
INFO - 2016-03-03 05:24:25 --> Output Class Initialized
INFO - 2016-03-03 05:24:25 --> Security Class Initialized
DEBUG - 2016-03-03 05:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:24:25 --> Input Class Initialized
INFO - 2016-03-03 05:24:25 --> Language Class Initialized
INFO - 2016-03-03 05:24:25 --> Loader Class Initialized
INFO - 2016-03-03 05:24:25 --> Helper loaded: url_helper
INFO - 2016-03-03 05:24:25 --> Helper loaded: file_helper
INFO - 2016-03-03 05:24:25 --> Helper loaded: date_helper
INFO - 2016-03-03 05:24:25 --> Helper loaded: form_helper
INFO - 2016-03-03 05:24:25 --> Database Driver Class Initialized
INFO - 2016-03-03 05:24:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:24:26 --> Controller Class Initialized
INFO - 2016-03-03 05:24:26 --> Model Class Initialized
INFO - 2016-03-03 05:24:26 --> Model Class Initialized
INFO - 2016-03-03 05:24:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:24:26 --> Pagination Class Initialized
INFO - 2016-03-03 05:24:26 --> Helper loaded: text_helper
INFO - 2016-03-03 05:24:26 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 20
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:24:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:24:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:24:26 --> Final output sent to browser
DEBUG - 2016-03-03 08:24:26 --> Total execution time: 1.2029
INFO - 2016-03-03 05:25:04 --> Config Class Initialized
INFO - 2016-03-03 05:25:04 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:25:04 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:25:04 --> Utf8 Class Initialized
INFO - 2016-03-03 05:25:04 --> URI Class Initialized
INFO - 2016-03-03 05:25:04 --> Router Class Initialized
INFO - 2016-03-03 05:25:04 --> Output Class Initialized
INFO - 2016-03-03 05:25:04 --> Security Class Initialized
DEBUG - 2016-03-03 05:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:25:04 --> Input Class Initialized
INFO - 2016-03-03 05:25:04 --> Language Class Initialized
INFO - 2016-03-03 05:25:04 --> Loader Class Initialized
INFO - 2016-03-03 05:25:04 --> Helper loaded: url_helper
INFO - 2016-03-03 05:25:04 --> Helper loaded: file_helper
INFO - 2016-03-03 05:25:04 --> Helper loaded: date_helper
INFO - 2016-03-03 05:25:04 --> Helper loaded: form_helper
INFO - 2016-03-03 05:25:04 --> Database Driver Class Initialized
INFO - 2016-03-03 05:25:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:25:05 --> Controller Class Initialized
INFO - 2016-03-03 05:25:05 --> Model Class Initialized
INFO - 2016-03-03 05:25:05 --> Model Class Initialized
INFO - 2016-03-03 05:25:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:25:05 --> Pagination Class Initialized
INFO - 2016-03-03 05:25:05 --> Helper loaded: text_helper
INFO - 2016-03-03 05:25:05 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:25:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:25:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:25:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:25:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:25:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:25:05 --> Final output sent to browser
DEBUG - 2016-03-03 08:25:05 --> Total execution time: 1.1649
INFO - 2016-03-03 05:25:06 --> Config Class Initialized
INFO - 2016-03-03 05:25:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:25:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:25:06 --> Utf8 Class Initialized
INFO - 2016-03-03 05:25:06 --> URI Class Initialized
INFO - 2016-03-03 05:25:06 --> Router Class Initialized
INFO - 2016-03-03 05:25:06 --> Output Class Initialized
INFO - 2016-03-03 05:25:06 --> Security Class Initialized
DEBUG - 2016-03-03 05:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:25:06 --> Input Class Initialized
INFO - 2016-03-03 05:25:06 --> Language Class Initialized
INFO - 2016-03-03 05:25:06 --> Loader Class Initialized
INFO - 2016-03-03 05:25:06 --> Helper loaded: url_helper
INFO - 2016-03-03 05:25:06 --> Helper loaded: file_helper
INFO - 2016-03-03 05:25:06 --> Helper loaded: date_helper
INFO - 2016-03-03 05:25:06 --> Helper loaded: form_helper
INFO - 2016-03-03 05:25:06 --> Database Driver Class Initialized
INFO - 2016-03-03 05:25:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:25:07 --> Controller Class Initialized
INFO - 2016-03-03 05:25:07 --> Model Class Initialized
INFO - 2016-03-03 05:25:07 --> Model Class Initialized
INFO - 2016-03-03 05:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:25:07 --> Pagination Class Initialized
INFO - 2016-03-03 05:25:07 --> Helper loaded: text_helper
INFO - 2016-03-03 05:25:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:25:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:25:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 20
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:25:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:25:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:25:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:25:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:25:07 --> Final output sent to browser
DEBUG - 2016-03-03 08:25:07 --> Total execution time: 1.1546
INFO - 2016-03-03 05:25:26 --> Config Class Initialized
INFO - 2016-03-03 05:25:26 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:25:26 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:25:26 --> Utf8 Class Initialized
INFO - 2016-03-03 05:25:26 --> URI Class Initialized
INFO - 2016-03-03 05:25:26 --> Router Class Initialized
INFO - 2016-03-03 05:25:26 --> Output Class Initialized
INFO - 2016-03-03 05:25:26 --> Security Class Initialized
DEBUG - 2016-03-03 05:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:25:26 --> Input Class Initialized
INFO - 2016-03-03 05:25:26 --> Language Class Initialized
INFO - 2016-03-03 05:25:26 --> Loader Class Initialized
INFO - 2016-03-03 05:25:26 --> Helper loaded: url_helper
INFO - 2016-03-03 05:25:26 --> Helper loaded: file_helper
INFO - 2016-03-03 05:25:26 --> Helper loaded: date_helper
INFO - 2016-03-03 05:25:26 --> Helper loaded: form_helper
INFO - 2016-03-03 05:25:26 --> Database Driver Class Initialized
INFO - 2016-03-03 05:25:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:25:27 --> Controller Class Initialized
INFO - 2016-03-03 05:25:27 --> Model Class Initialized
INFO - 2016-03-03 05:25:27 --> Model Class Initialized
INFO - 2016-03-03 05:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:25:27 --> Pagination Class Initialized
INFO - 2016-03-03 05:25:27 --> Helper loaded: text_helper
INFO - 2016-03-03 05:25:27 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:25:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:25:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 20
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:25:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:25:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:25:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:25:28 --> Final output sent to browser
DEBUG - 2016-03-03 08:25:28 --> Total execution time: 1.1402
INFO - 2016-03-03 05:25:34 --> Config Class Initialized
INFO - 2016-03-03 05:25:34 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:25:34 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:25:34 --> Utf8 Class Initialized
INFO - 2016-03-03 05:25:34 --> URI Class Initialized
INFO - 2016-03-03 05:25:34 --> Router Class Initialized
INFO - 2016-03-03 05:25:34 --> Output Class Initialized
INFO - 2016-03-03 05:25:34 --> Security Class Initialized
DEBUG - 2016-03-03 05:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:25:34 --> Input Class Initialized
INFO - 2016-03-03 05:25:34 --> Language Class Initialized
INFO - 2016-03-03 05:25:34 --> Loader Class Initialized
INFO - 2016-03-03 05:25:34 --> Helper loaded: url_helper
INFO - 2016-03-03 05:25:34 --> Helper loaded: file_helper
INFO - 2016-03-03 05:25:34 --> Helper loaded: date_helper
INFO - 2016-03-03 05:25:34 --> Helper loaded: form_helper
INFO - 2016-03-03 05:25:34 --> Database Driver Class Initialized
INFO - 2016-03-03 05:25:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:25:35 --> Controller Class Initialized
INFO - 2016-03-03 05:25:35 --> Model Class Initialized
INFO - 2016-03-03 05:25:35 --> Model Class Initialized
INFO - 2016-03-03 05:25:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:25:35 --> Pagination Class Initialized
INFO - 2016-03-03 05:25:35 --> Helper loaded: text_helper
INFO - 2016-03-03 05:25:35 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 20
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:25:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:25:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:25:35 --> Final output sent to browser
DEBUG - 2016-03-03 08:25:35 --> Total execution time: 1.1549
INFO - 2016-03-03 05:26:06 --> Config Class Initialized
INFO - 2016-03-03 05:26:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:06 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:06 --> URI Class Initialized
INFO - 2016-03-03 05:26:06 --> Router Class Initialized
INFO - 2016-03-03 05:26:06 --> Output Class Initialized
INFO - 2016-03-03 05:26:06 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:06 --> Input Class Initialized
INFO - 2016-03-03 05:26:06 --> Language Class Initialized
INFO - 2016-03-03 05:26:06 --> Loader Class Initialized
INFO - 2016-03-03 05:26:06 --> Helper loaded: url_helper
INFO - 2016-03-03 05:26:06 --> Helper loaded: file_helper
INFO - 2016-03-03 05:26:06 --> Helper loaded: date_helper
INFO - 2016-03-03 05:26:06 --> Helper loaded: form_helper
INFO - 2016-03-03 05:26:06 --> Database Driver Class Initialized
INFO - 2016-03-03 05:26:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:26:07 --> Controller Class Initialized
INFO - 2016-03-03 05:26:07 --> Model Class Initialized
INFO - 2016-03-03 05:26:07 --> Model Class Initialized
INFO - 2016-03-03 05:26:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:26:07 --> Pagination Class Initialized
INFO - 2016-03-03 05:26:07 --> Helper loaded: text_helper
INFO - 2016-03-03 05:26:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:26:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:26:07 --> Final output sent to browser
DEBUG - 2016-03-03 08:26:07 --> Total execution time: 1.1463
INFO - 2016-03-03 05:26:08 --> Config Class Initialized
INFO - 2016-03-03 05:26:08 --> Config Class Initialized
INFO - 2016-03-03 05:26:08 --> Hooks Class Initialized
INFO - 2016-03-03 05:26:08 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:08 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:08 --> Utf8 Class Initialized
DEBUG - 2016-03-03 05:26:08 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:08 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:08 --> URI Class Initialized
INFO - 2016-03-03 05:26:08 --> URI Class Initialized
INFO - 2016-03-03 05:26:08 --> Router Class Initialized
INFO - 2016-03-03 05:26:08 --> Router Class Initialized
INFO - 2016-03-03 05:26:08 --> Output Class Initialized
INFO - 2016-03-03 05:26:08 --> Output Class Initialized
INFO - 2016-03-03 05:26:08 --> Security Class Initialized
INFO - 2016-03-03 05:26:08 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-03-03 05:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:08 --> Input Class Initialized
INFO - 2016-03-03 05:26:08 --> Input Class Initialized
INFO - 2016-03-03 05:26:08 --> Language Class Initialized
INFO - 2016-03-03 05:26:08 --> Language Class Initialized
ERROR - 2016-03-03 05:26:08 --> 404 Page Not Found: Img/fighternew_31601.png
INFO - 2016-03-03 05:26:08 --> Loader Class Initialized
INFO - 2016-03-03 05:26:08 --> Helper loaded: url_helper
INFO - 2016-03-03 05:26:08 --> Helper loaded: file_helper
INFO - 2016-03-03 05:26:08 --> Helper loaded: date_helper
INFO - 2016-03-03 05:26:08 --> Helper loaded: form_helper
INFO - 2016-03-03 05:26:08 --> Database Driver Class Initialized
INFO - 2016-03-03 05:26:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:26:09 --> Controller Class Initialized
INFO - 2016-03-03 05:26:09 --> Model Class Initialized
INFO - 2016-03-03 05:26:09 --> Model Class Initialized
INFO - 2016-03-03 05:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:26:09 --> Pagination Class Initialized
INFO - 2016-03-03 05:26:09 --> Helper loaded: text_helper
INFO - 2016-03-03 05:26:09 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 20
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:26:09 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:26:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:26:09 --> Final output sent to browser
DEBUG - 2016-03-03 08:26:09 --> Total execution time: 1.1765
INFO - 2016-03-03 05:26:13 --> Config Class Initialized
INFO - 2016-03-03 05:26:13 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:13 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:13 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:13 --> URI Class Initialized
INFO - 2016-03-03 05:26:13 --> Router Class Initialized
INFO - 2016-03-03 05:26:13 --> Output Class Initialized
INFO - 2016-03-03 05:26:13 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:13 --> Input Class Initialized
INFO - 2016-03-03 05:26:13 --> Language Class Initialized
ERROR - 2016-03-03 05:26:13 --> 404 Page Not Found: Img/fighternew_31601.png
INFO - 2016-03-03 05:26:17 --> Config Class Initialized
INFO - 2016-03-03 05:26:17 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:17 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:17 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:17 --> URI Class Initialized
INFO - 2016-03-03 05:26:17 --> Router Class Initialized
INFO - 2016-03-03 05:26:17 --> Output Class Initialized
INFO - 2016-03-03 05:26:17 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:17 --> Input Class Initialized
INFO - 2016-03-03 05:26:17 --> Language Class Initialized
INFO - 2016-03-03 05:26:17 --> Loader Class Initialized
INFO - 2016-03-03 05:26:17 --> Helper loaded: url_helper
INFO - 2016-03-03 05:26:17 --> Helper loaded: file_helper
INFO - 2016-03-03 05:26:17 --> Helper loaded: date_helper
INFO - 2016-03-03 05:26:17 --> Helper loaded: form_helper
INFO - 2016-03-03 05:26:17 --> Database Driver Class Initialized
INFO - 2016-03-03 05:26:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:26:18 --> Controller Class Initialized
INFO - 2016-03-03 05:26:18 --> Model Class Initialized
INFO - 2016-03-03 05:26:18 --> Model Class Initialized
INFO - 2016-03-03 05:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:26:18 --> Pagination Class Initialized
INFO - 2016-03-03 05:26:18 --> Helper loaded: text_helper
INFO - 2016-03-03 05:26:18 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 20
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:26:18 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:26:18 --> Final output sent to browser
DEBUG - 2016-03-03 08:26:18 --> Total execution time: 1.1692
INFO - 2016-03-03 05:26:23 --> Config Class Initialized
INFO - 2016-03-03 05:26:23 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:23 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:23 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:23 --> URI Class Initialized
INFO - 2016-03-03 05:26:23 --> Router Class Initialized
INFO - 2016-03-03 05:26:23 --> Output Class Initialized
INFO - 2016-03-03 05:26:23 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:23 --> Input Class Initialized
INFO - 2016-03-03 05:26:23 --> Language Class Initialized
INFO - 2016-03-03 05:26:23 --> Loader Class Initialized
INFO - 2016-03-03 05:26:23 --> Helper loaded: url_helper
INFO - 2016-03-03 05:26:23 --> Helper loaded: file_helper
INFO - 2016-03-03 05:26:23 --> Helper loaded: date_helper
INFO - 2016-03-03 05:26:23 --> Helper loaded: form_helper
INFO - 2016-03-03 05:26:23 --> Database Driver Class Initialized
INFO - 2016-03-03 05:26:23 --> Config Class Initialized
INFO - 2016-03-03 05:26:23 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:23 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:23 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:23 --> URI Class Initialized
INFO - 2016-03-03 05:26:23 --> Router Class Initialized
INFO - 2016-03-03 05:26:23 --> Output Class Initialized
INFO - 2016-03-03 05:26:23 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:23 --> Input Class Initialized
INFO - 2016-03-03 05:26:23 --> Language Class Initialized
INFO - 2016-03-03 05:26:23 --> Loader Class Initialized
INFO - 2016-03-03 05:26:23 --> Helper loaded: url_helper
INFO - 2016-03-03 05:26:23 --> Helper loaded: file_helper
INFO - 2016-03-03 05:26:23 --> Helper loaded: date_helper
INFO - 2016-03-03 05:26:23 --> Helper loaded: form_helper
INFO - 2016-03-03 05:26:24 --> Database Driver Class Initialized
INFO - 2016-03-03 05:26:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:26:24 --> Controller Class Initialized
INFO - 2016-03-03 05:26:24 --> Model Class Initialized
INFO - 2016-03-03 05:26:24 --> Model Class Initialized
INFO - 2016-03-03 05:26:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:26:24 --> Pagination Class Initialized
INFO - 2016-03-03 05:26:24 --> Helper loaded: text_helper
INFO - 2016-03-03 05:26:24 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:26:24 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:26:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:26:24 --> Final output sent to browser
DEBUG - 2016-03-03 08:26:24 --> Total execution time: 1.1714
INFO - 2016-03-03 05:26:24 --> Config Class Initialized
INFO - 2016-03-03 05:26:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:24 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:24 --> URI Class Initialized
INFO - 2016-03-03 05:26:24 --> Router Class Initialized
INFO - 2016-03-03 05:26:24 --> Output Class Initialized
INFO - 2016-03-03 05:26:24 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:24 --> Input Class Initialized
INFO - 2016-03-03 05:26:24 --> Language Class Initialized
ERROR - 2016-03-03 05:26:24 --> 404 Page Not Found: Wall/img
INFO - 2016-03-03 05:26:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:26:25 --> Controller Class Initialized
INFO - 2016-03-03 05:26:25 --> Model Class Initialized
INFO - 2016-03-03 05:26:25 --> Model Class Initialized
INFO - 2016-03-03 05:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:26:25 --> Pagination Class Initialized
INFO - 2016-03-03 05:26:25 --> Helper loaded: text_helper
INFO - 2016-03-03 05:26:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:26:25 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:26:25 --> Final output sent to browser
DEBUG - 2016-03-03 08:26:25 --> Total execution time: 1.1524
INFO - 2016-03-03 05:26:25 --> Config Class Initialized
INFO - 2016-03-03 05:26:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:25 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:25 --> URI Class Initialized
INFO - 2016-03-03 05:26:25 --> Router Class Initialized
INFO - 2016-03-03 05:26:25 --> Output Class Initialized
INFO - 2016-03-03 05:26:25 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:25 --> Input Class Initialized
INFO - 2016-03-03 05:26:25 --> Language Class Initialized
ERROR - 2016-03-03 05:26:25 --> 404 Page Not Found: Wall/img
INFO - 2016-03-03 05:26:55 --> Config Class Initialized
INFO - 2016-03-03 05:26:55 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:55 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:55 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:55 --> URI Class Initialized
INFO - 2016-03-03 05:26:55 --> Router Class Initialized
INFO - 2016-03-03 05:26:55 --> Output Class Initialized
INFO - 2016-03-03 05:26:55 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:55 --> Input Class Initialized
INFO - 2016-03-03 05:26:55 --> Language Class Initialized
INFO - 2016-03-03 05:26:55 --> Loader Class Initialized
INFO - 2016-03-03 05:26:55 --> Helper loaded: url_helper
INFO - 2016-03-03 05:26:55 --> Helper loaded: file_helper
INFO - 2016-03-03 05:26:55 --> Helper loaded: date_helper
INFO - 2016-03-03 05:26:55 --> Helper loaded: form_helper
INFO - 2016-03-03 05:26:55 --> Database Driver Class Initialized
INFO - 2016-03-03 05:26:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:26:56 --> Controller Class Initialized
INFO - 2016-03-03 05:26:56 --> Model Class Initialized
INFO - 2016-03-03 05:26:56 --> Model Class Initialized
INFO - 2016-03-03 05:26:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:26:56 --> Pagination Class Initialized
INFO - 2016-03-03 05:26:56 --> Helper loaded: text_helper
INFO - 2016-03-03 05:26:56 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:26:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:26:56 --> Final output sent to browser
DEBUG - 2016-03-03 08:26:56 --> Total execution time: 1.1752
INFO - 2016-03-03 05:26:57 --> Config Class Initialized
INFO - 2016-03-03 05:26:57 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:26:57 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:26:57 --> Utf8 Class Initialized
INFO - 2016-03-03 05:26:57 --> URI Class Initialized
INFO - 2016-03-03 05:26:57 --> Router Class Initialized
INFO - 2016-03-03 05:26:57 --> Output Class Initialized
INFO - 2016-03-03 05:26:57 --> Security Class Initialized
DEBUG - 2016-03-03 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:26:57 --> Input Class Initialized
INFO - 2016-03-03 05:26:57 --> Language Class Initialized
INFO - 2016-03-03 05:26:57 --> Loader Class Initialized
INFO - 2016-03-03 05:26:57 --> Helper loaded: url_helper
INFO - 2016-03-03 05:26:57 --> Helper loaded: file_helper
INFO - 2016-03-03 05:26:57 --> Helper loaded: date_helper
INFO - 2016-03-03 05:26:57 --> Helper loaded: form_helper
INFO - 2016-03-03 05:26:57 --> Database Driver Class Initialized
INFO - 2016-03-03 05:26:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:26:58 --> Controller Class Initialized
INFO - 2016-03-03 05:26:58 --> Model Class Initialized
INFO - 2016-03-03 05:26:58 --> Model Class Initialized
INFO - 2016-03-03 05:26:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:26:58 --> Pagination Class Initialized
INFO - 2016-03-03 05:26:58 --> Helper loaded: text_helper
INFO - 2016-03-03 05:26:58 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:26:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:26:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 8
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 9
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 20
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 41
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 53
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 55
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 68
ERROR - 2016-03-03 08:26:58 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 138
INFO - 2016-03-03 08:26:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:26:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:26:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:26:58 --> Final output sent to browser
DEBUG - 2016-03-03 08:26:58 --> Total execution time: 1.1807
INFO - 2016-03-03 05:29:10 --> Config Class Initialized
INFO - 2016-03-03 05:29:10 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:29:10 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:29:10 --> Utf8 Class Initialized
INFO - 2016-03-03 05:29:10 --> URI Class Initialized
INFO - 2016-03-03 05:29:10 --> Router Class Initialized
INFO - 2016-03-03 05:29:10 --> Output Class Initialized
INFO - 2016-03-03 05:29:10 --> Security Class Initialized
DEBUG - 2016-03-03 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:29:11 --> Input Class Initialized
INFO - 2016-03-03 05:29:11 --> Language Class Initialized
INFO - 2016-03-03 05:29:11 --> Loader Class Initialized
INFO - 2016-03-03 05:29:11 --> Helper loaded: url_helper
INFO - 2016-03-03 05:29:11 --> Helper loaded: file_helper
INFO - 2016-03-03 05:29:11 --> Helper loaded: date_helper
INFO - 2016-03-03 05:29:11 --> Helper loaded: form_helper
INFO - 2016-03-03 05:29:11 --> Database Driver Class Initialized
INFO - 2016-03-03 05:29:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:29:12 --> Controller Class Initialized
INFO - 2016-03-03 05:29:12 --> Model Class Initialized
INFO - 2016-03-03 05:29:12 --> Model Class Initialized
INFO - 2016-03-03 05:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:29:12 --> Pagination Class Initialized
INFO - 2016-03-03 05:29:12 --> Helper loaded: text_helper
INFO - 2016-03-03 05:29:12 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:29:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:29:12 --> Final output sent to browser
DEBUG - 2016-03-03 08:29:12 --> Total execution time: 1.1501
INFO - 2016-03-03 05:29:52 --> Config Class Initialized
INFO - 2016-03-03 05:29:52 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:29:52 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:29:52 --> Utf8 Class Initialized
INFO - 2016-03-03 05:29:52 --> URI Class Initialized
INFO - 2016-03-03 05:29:52 --> Router Class Initialized
INFO - 2016-03-03 05:29:52 --> Output Class Initialized
INFO - 2016-03-03 05:29:52 --> Security Class Initialized
DEBUG - 2016-03-03 05:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:29:52 --> Input Class Initialized
INFO - 2016-03-03 05:29:52 --> Language Class Initialized
INFO - 2016-03-03 05:29:52 --> Loader Class Initialized
INFO - 2016-03-03 05:29:52 --> Helper loaded: url_helper
INFO - 2016-03-03 05:29:52 --> Helper loaded: file_helper
INFO - 2016-03-03 05:29:52 --> Helper loaded: date_helper
INFO - 2016-03-03 05:29:52 --> Helper loaded: form_helper
INFO - 2016-03-03 05:29:52 --> Database Driver Class Initialized
INFO - 2016-03-03 05:29:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:29:53 --> Controller Class Initialized
INFO - 2016-03-03 05:29:53 --> Model Class Initialized
INFO - 2016-03-03 05:29:53 --> Model Class Initialized
INFO - 2016-03-03 05:29:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:29:53 --> Pagination Class Initialized
INFO - 2016-03-03 05:29:53 --> Helper loaded: text_helper
INFO - 2016-03-03 05:29:53 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:29:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:29:53 --> Final output sent to browser
DEBUG - 2016-03-03 08:29:53 --> Total execution time: 1.1795
INFO - 2016-03-03 05:30:22 --> Config Class Initialized
INFO - 2016-03-03 05:30:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 05:30:22 --> UTF-8 Support Enabled
INFO - 2016-03-03 05:30:22 --> Utf8 Class Initialized
INFO - 2016-03-03 05:30:22 --> URI Class Initialized
INFO - 2016-03-03 05:30:22 --> Router Class Initialized
INFO - 2016-03-03 05:30:22 --> Output Class Initialized
INFO - 2016-03-03 05:30:22 --> Security Class Initialized
DEBUG - 2016-03-03 05:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 05:30:22 --> Input Class Initialized
INFO - 2016-03-03 05:30:22 --> Language Class Initialized
INFO - 2016-03-03 05:30:22 --> Loader Class Initialized
INFO - 2016-03-03 05:30:22 --> Helper loaded: url_helper
INFO - 2016-03-03 05:30:22 --> Helper loaded: file_helper
INFO - 2016-03-03 05:30:22 --> Helper loaded: date_helper
INFO - 2016-03-03 05:30:22 --> Helper loaded: form_helper
INFO - 2016-03-03 05:30:22 --> Database Driver Class Initialized
INFO - 2016-03-03 05:30:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 05:30:24 --> Controller Class Initialized
INFO - 2016-03-03 05:30:24 --> Model Class Initialized
INFO - 2016-03-03 05:30:24 --> Model Class Initialized
INFO - 2016-03-03 05:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 05:30:24 --> Pagination Class Initialized
INFO - 2016-03-03 05:30:24 --> Helper loaded: text_helper
INFO - 2016-03-03 05:30:24 --> Helper loaded: cookie_helper
INFO - 2016-03-03 08:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 08:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 08:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 08:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 08:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 08:30:24 --> Final output sent to browser
DEBUG - 2016-03-03 08:30:24 --> Total execution time: 1.2601
INFO - 2016-03-03 06:44:24 --> Config Class Initialized
INFO - 2016-03-03 06:44:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:44:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:44:24 --> Utf8 Class Initialized
INFO - 2016-03-03 06:44:24 --> URI Class Initialized
INFO - 2016-03-03 06:44:24 --> Router Class Initialized
INFO - 2016-03-03 06:44:24 --> Output Class Initialized
INFO - 2016-03-03 06:44:24 --> Security Class Initialized
DEBUG - 2016-03-03 06:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:44:24 --> Input Class Initialized
INFO - 2016-03-03 06:44:24 --> Language Class Initialized
INFO - 2016-03-03 06:44:24 --> Loader Class Initialized
INFO - 2016-03-03 06:44:24 --> Helper loaded: url_helper
INFO - 2016-03-03 06:44:24 --> Helper loaded: file_helper
INFO - 2016-03-03 06:44:24 --> Helper loaded: date_helper
INFO - 2016-03-03 06:44:24 --> Helper loaded: form_helper
INFO - 2016-03-03 06:44:24 --> Database Driver Class Initialized
INFO - 2016-03-03 06:44:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:44:25 --> Controller Class Initialized
INFO - 2016-03-03 06:44:25 --> Model Class Initialized
INFO - 2016-03-03 06:44:25 --> Model Class Initialized
INFO - 2016-03-03 06:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:44:25 --> Pagination Class Initialized
INFO - 2016-03-03 06:44:25 --> Helper loaded: text_helper
INFO - 2016-03-03 06:44:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:44:25 --> Final output sent to browser
DEBUG - 2016-03-03 09:44:25 --> Total execution time: 1.3166
INFO - 2016-03-03 06:46:26 --> Config Class Initialized
INFO - 2016-03-03 06:46:26 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:46:26 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:46:26 --> Utf8 Class Initialized
INFO - 2016-03-03 06:46:26 --> URI Class Initialized
INFO - 2016-03-03 06:46:26 --> Router Class Initialized
INFO - 2016-03-03 06:46:26 --> Output Class Initialized
INFO - 2016-03-03 06:46:26 --> Security Class Initialized
DEBUG - 2016-03-03 06:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:46:26 --> Input Class Initialized
INFO - 2016-03-03 06:46:26 --> Language Class Initialized
INFO - 2016-03-03 06:46:26 --> Loader Class Initialized
INFO - 2016-03-03 06:46:26 --> Helper loaded: url_helper
INFO - 2016-03-03 06:46:26 --> Helper loaded: file_helper
INFO - 2016-03-03 06:46:26 --> Helper loaded: date_helper
INFO - 2016-03-03 06:46:26 --> Helper loaded: form_helper
INFO - 2016-03-03 06:46:26 --> Database Driver Class Initialized
INFO - 2016-03-03 06:46:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:46:27 --> Controller Class Initialized
INFO - 2016-03-03 06:46:27 --> Model Class Initialized
INFO - 2016-03-03 06:46:27 --> Model Class Initialized
INFO - 2016-03-03 06:46:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:46:27 --> Pagination Class Initialized
INFO - 2016-03-03 06:46:27 --> Helper loaded: text_helper
INFO - 2016-03-03 06:46:27 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:46:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:46:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:46:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:46:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:46:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:46:27 --> Final output sent to browser
DEBUG - 2016-03-03 09:46:27 --> Total execution time: 1.2807
INFO - 2016-03-03 06:47:22 --> Config Class Initialized
INFO - 2016-03-03 06:47:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:47:22 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:47:22 --> Utf8 Class Initialized
INFO - 2016-03-03 06:47:22 --> URI Class Initialized
INFO - 2016-03-03 06:47:22 --> Router Class Initialized
INFO - 2016-03-03 06:47:22 --> Output Class Initialized
INFO - 2016-03-03 06:47:22 --> Security Class Initialized
DEBUG - 2016-03-03 06:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:47:22 --> Input Class Initialized
INFO - 2016-03-03 06:47:22 --> Language Class Initialized
INFO - 2016-03-03 06:47:22 --> Loader Class Initialized
INFO - 2016-03-03 06:47:22 --> Helper loaded: url_helper
INFO - 2016-03-03 06:47:22 --> Helper loaded: file_helper
INFO - 2016-03-03 06:47:22 --> Helper loaded: date_helper
INFO - 2016-03-03 06:47:22 --> Helper loaded: form_helper
INFO - 2016-03-03 06:47:22 --> Database Driver Class Initialized
INFO - 2016-03-03 06:47:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:47:23 --> Controller Class Initialized
INFO - 2016-03-03 06:47:23 --> Model Class Initialized
INFO - 2016-03-03 06:47:23 --> Model Class Initialized
INFO - 2016-03-03 06:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:47:23 --> Pagination Class Initialized
INFO - 2016-03-03 06:47:23 --> Helper loaded: text_helper
INFO - 2016-03-03 06:47:23 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:47:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:47:23 --> Final output sent to browser
DEBUG - 2016-03-03 09:47:23 --> Total execution time: 1.2162
INFO - 2016-03-03 06:47:26 --> Config Class Initialized
INFO - 2016-03-03 06:47:26 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:47:26 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:47:26 --> Utf8 Class Initialized
INFO - 2016-03-03 06:47:26 --> URI Class Initialized
INFO - 2016-03-03 06:47:26 --> Router Class Initialized
INFO - 2016-03-03 06:47:26 --> Output Class Initialized
INFO - 2016-03-03 06:47:26 --> Security Class Initialized
DEBUG - 2016-03-03 06:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:47:26 --> Input Class Initialized
INFO - 2016-03-03 06:47:26 --> Language Class Initialized
INFO - 2016-03-03 06:47:26 --> Loader Class Initialized
INFO - 2016-03-03 06:47:26 --> Helper loaded: url_helper
INFO - 2016-03-03 06:47:26 --> Helper loaded: file_helper
INFO - 2016-03-03 06:47:26 --> Helper loaded: date_helper
INFO - 2016-03-03 06:47:26 --> Helper loaded: form_helper
INFO - 2016-03-03 06:47:26 --> Database Driver Class Initialized
INFO - 2016-03-03 06:47:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:47:27 --> Controller Class Initialized
INFO - 2016-03-03 06:47:27 --> Model Class Initialized
INFO - 2016-03-03 06:47:27 --> Model Class Initialized
INFO - 2016-03-03 06:47:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:47:27 --> Pagination Class Initialized
INFO - 2016-03-03 06:47:27 --> Helper loaded: text_helper
INFO - 2016-03-03 06:47:27 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:47:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:47:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:47:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:47:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:47:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:47:27 --> Final output sent to browser
DEBUG - 2016-03-03 09:47:27 --> Total execution time: 1.1618
INFO - 2016-03-03 06:48:45 --> Config Class Initialized
INFO - 2016-03-03 06:48:45 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:48:45 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:48:45 --> Utf8 Class Initialized
INFO - 2016-03-03 06:48:45 --> URI Class Initialized
INFO - 2016-03-03 06:48:45 --> Router Class Initialized
INFO - 2016-03-03 06:48:45 --> Output Class Initialized
INFO - 2016-03-03 06:48:45 --> Security Class Initialized
DEBUG - 2016-03-03 06:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:48:45 --> Input Class Initialized
INFO - 2016-03-03 06:48:45 --> Language Class Initialized
INFO - 2016-03-03 06:48:45 --> Loader Class Initialized
INFO - 2016-03-03 06:48:45 --> Helper loaded: url_helper
INFO - 2016-03-03 06:48:45 --> Helper loaded: file_helper
INFO - 2016-03-03 06:48:45 --> Helper loaded: date_helper
INFO - 2016-03-03 06:48:45 --> Helper loaded: form_helper
INFO - 2016-03-03 06:48:45 --> Database Driver Class Initialized
INFO - 2016-03-03 06:48:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:48:46 --> Controller Class Initialized
INFO - 2016-03-03 06:48:46 --> Model Class Initialized
INFO - 2016-03-03 06:48:46 --> Model Class Initialized
INFO - 2016-03-03 06:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:48:46 --> Pagination Class Initialized
INFO - 2016-03-03 06:48:46 --> Helper loaded: text_helper
INFO - 2016-03-03 06:48:46 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:48:46 --> Final output sent to browser
DEBUG - 2016-03-03 09:48:46 --> Total execution time: 1.1983
INFO - 2016-03-03 06:50:09 --> Config Class Initialized
INFO - 2016-03-03 06:50:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:50:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:50:09 --> Utf8 Class Initialized
INFO - 2016-03-03 06:50:09 --> URI Class Initialized
INFO - 2016-03-03 06:50:09 --> Router Class Initialized
INFO - 2016-03-03 06:50:09 --> Output Class Initialized
INFO - 2016-03-03 06:50:09 --> Security Class Initialized
DEBUG - 2016-03-03 06:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:50:09 --> Input Class Initialized
INFO - 2016-03-03 06:50:09 --> Language Class Initialized
INFO - 2016-03-03 06:50:09 --> Loader Class Initialized
INFO - 2016-03-03 06:50:09 --> Helper loaded: url_helper
INFO - 2016-03-03 06:50:09 --> Helper loaded: file_helper
INFO - 2016-03-03 06:50:09 --> Helper loaded: date_helper
INFO - 2016-03-03 06:50:09 --> Helper loaded: form_helper
INFO - 2016-03-03 06:50:09 --> Database Driver Class Initialized
INFO - 2016-03-03 06:50:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:50:10 --> Controller Class Initialized
INFO - 2016-03-03 06:50:10 --> Model Class Initialized
INFO - 2016-03-03 06:50:10 --> Model Class Initialized
INFO - 2016-03-03 06:50:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:50:10 --> Pagination Class Initialized
INFO - 2016-03-03 06:50:10 --> Helper loaded: text_helper
INFO - 2016-03-03 06:50:10 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:50:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:50:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:50:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:50:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:50:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:50:10 --> Final output sent to browser
DEBUG - 2016-03-03 09:50:10 --> Total execution time: 1.1443
INFO - 2016-03-03 06:50:57 --> Config Class Initialized
INFO - 2016-03-03 06:50:57 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:50:57 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:50:57 --> Utf8 Class Initialized
INFO - 2016-03-03 06:50:57 --> URI Class Initialized
INFO - 2016-03-03 06:50:57 --> Router Class Initialized
INFO - 2016-03-03 06:50:57 --> Output Class Initialized
INFO - 2016-03-03 06:50:57 --> Security Class Initialized
DEBUG - 2016-03-03 06:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:50:57 --> Input Class Initialized
INFO - 2016-03-03 06:50:57 --> Language Class Initialized
INFO - 2016-03-03 06:50:57 --> Loader Class Initialized
INFO - 2016-03-03 06:50:57 --> Helper loaded: url_helper
INFO - 2016-03-03 06:50:57 --> Helper loaded: file_helper
INFO - 2016-03-03 06:50:57 --> Helper loaded: date_helper
INFO - 2016-03-03 06:50:57 --> Helper loaded: form_helper
INFO - 2016-03-03 06:50:57 --> Database Driver Class Initialized
INFO - 2016-03-03 06:50:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:50:58 --> Controller Class Initialized
INFO - 2016-03-03 06:50:58 --> Model Class Initialized
INFO - 2016-03-03 06:50:58 --> Model Class Initialized
INFO - 2016-03-03 06:50:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:50:58 --> Pagination Class Initialized
INFO - 2016-03-03 06:50:58 --> Helper loaded: text_helper
INFO - 2016-03-03 06:50:58 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:50:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:50:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:50:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:50:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:50:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:50:58 --> Final output sent to browser
DEBUG - 2016-03-03 09:50:58 --> Total execution time: 1.1766
INFO - 2016-03-03 06:51:43 --> Config Class Initialized
INFO - 2016-03-03 06:51:43 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:51:43 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:51:43 --> Utf8 Class Initialized
INFO - 2016-03-03 06:51:43 --> URI Class Initialized
INFO - 2016-03-03 06:51:43 --> Router Class Initialized
INFO - 2016-03-03 06:51:43 --> Output Class Initialized
INFO - 2016-03-03 06:51:43 --> Security Class Initialized
DEBUG - 2016-03-03 06:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:51:43 --> Input Class Initialized
INFO - 2016-03-03 06:51:43 --> Language Class Initialized
INFO - 2016-03-03 06:51:43 --> Loader Class Initialized
INFO - 2016-03-03 06:51:43 --> Helper loaded: url_helper
INFO - 2016-03-03 06:51:43 --> Helper loaded: file_helper
INFO - 2016-03-03 06:51:43 --> Helper loaded: date_helper
INFO - 2016-03-03 06:51:43 --> Helper loaded: form_helper
INFO - 2016-03-03 06:51:43 --> Database Driver Class Initialized
INFO - 2016-03-03 06:51:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:51:44 --> Controller Class Initialized
INFO - 2016-03-03 06:51:44 --> Model Class Initialized
INFO - 2016-03-03 06:51:44 --> Model Class Initialized
INFO - 2016-03-03 06:51:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:51:44 --> Pagination Class Initialized
INFO - 2016-03-03 06:51:44 --> Helper loaded: text_helper
INFO - 2016-03-03 06:51:44 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:51:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:51:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:51:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:51:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:51:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:51:44 --> Final output sent to browser
DEBUG - 2016-03-03 09:51:44 --> Total execution time: 1.1674
INFO - 2016-03-03 06:52:14 --> Config Class Initialized
INFO - 2016-03-03 06:52:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:52:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:52:14 --> Utf8 Class Initialized
INFO - 2016-03-03 06:52:14 --> URI Class Initialized
INFO - 2016-03-03 06:52:14 --> Router Class Initialized
INFO - 2016-03-03 06:52:14 --> Output Class Initialized
INFO - 2016-03-03 06:52:14 --> Security Class Initialized
DEBUG - 2016-03-03 06:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:52:14 --> Input Class Initialized
INFO - 2016-03-03 06:52:14 --> Language Class Initialized
INFO - 2016-03-03 06:52:14 --> Loader Class Initialized
INFO - 2016-03-03 06:52:14 --> Helper loaded: url_helper
INFO - 2016-03-03 06:52:14 --> Helper loaded: file_helper
INFO - 2016-03-03 06:52:14 --> Helper loaded: date_helper
INFO - 2016-03-03 06:52:14 --> Helper loaded: form_helper
INFO - 2016-03-03 06:52:14 --> Database Driver Class Initialized
INFO - 2016-03-03 06:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:52:15 --> Controller Class Initialized
INFO - 2016-03-03 06:52:15 --> Model Class Initialized
INFO - 2016-03-03 06:52:15 --> Model Class Initialized
INFO - 2016-03-03 06:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:52:15 --> Pagination Class Initialized
INFO - 2016-03-03 06:52:15 --> Helper loaded: text_helper
INFO - 2016-03-03 06:52:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:52:15 --> Final output sent to browser
DEBUG - 2016-03-03 09:52:15 --> Total execution time: 1.1301
INFO - 2016-03-03 06:52:22 --> Config Class Initialized
INFO - 2016-03-03 06:52:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:52:22 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:52:22 --> Utf8 Class Initialized
INFO - 2016-03-03 06:52:22 --> URI Class Initialized
INFO - 2016-03-03 06:52:22 --> Router Class Initialized
INFO - 2016-03-03 06:52:22 --> Output Class Initialized
INFO - 2016-03-03 06:52:22 --> Security Class Initialized
DEBUG - 2016-03-03 06:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:52:22 --> Input Class Initialized
INFO - 2016-03-03 06:52:22 --> Language Class Initialized
INFO - 2016-03-03 06:52:22 --> Loader Class Initialized
INFO - 2016-03-03 06:52:22 --> Helper loaded: url_helper
INFO - 2016-03-03 06:52:22 --> Helper loaded: file_helper
INFO - 2016-03-03 06:52:22 --> Helper loaded: date_helper
INFO - 2016-03-03 06:52:22 --> Helper loaded: form_helper
INFO - 2016-03-03 06:52:22 --> Database Driver Class Initialized
INFO - 2016-03-03 06:52:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:52:23 --> Controller Class Initialized
INFO - 2016-03-03 06:52:23 --> Model Class Initialized
INFO - 2016-03-03 06:52:23 --> Model Class Initialized
INFO - 2016-03-03 06:52:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:52:23 --> Pagination Class Initialized
INFO - 2016-03-03 06:52:23 --> Helper loaded: text_helper
INFO - 2016-03-03 06:52:23 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:52:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:52:23 --> Final output sent to browser
DEBUG - 2016-03-03 09:52:23 --> Total execution time: 1.1885
INFO - 2016-03-03 06:52:49 --> Config Class Initialized
INFO - 2016-03-03 06:52:49 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:52:49 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:52:49 --> Utf8 Class Initialized
INFO - 2016-03-03 06:52:49 --> URI Class Initialized
INFO - 2016-03-03 06:52:49 --> Router Class Initialized
INFO - 2016-03-03 06:52:49 --> Output Class Initialized
INFO - 2016-03-03 06:52:49 --> Security Class Initialized
DEBUG - 2016-03-03 06:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:52:49 --> Input Class Initialized
INFO - 2016-03-03 06:52:49 --> Language Class Initialized
INFO - 2016-03-03 06:52:49 --> Loader Class Initialized
INFO - 2016-03-03 06:52:49 --> Helper loaded: url_helper
INFO - 2016-03-03 06:52:49 --> Helper loaded: file_helper
INFO - 2016-03-03 06:52:49 --> Helper loaded: date_helper
INFO - 2016-03-03 06:52:49 --> Helper loaded: form_helper
INFO - 2016-03-03 06:52:49 --> Database Driver Class Initialized
INFO - 2016-03-03 06:52:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:52:50 --> Controller Class Initialized
INFO - 2016-03-03 06:52:50 --> Model Class Initialized
INFO - 2016-03-03 06:52:50 --> Model Class Initialized
INFO - 2016-03-03 06:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:52:50 --> Pagination Class Initialized
INFO - 2016-03-03 06:52:50 --> Helper loaded: text_helper
INFO - 2016-03-03 06:52:50 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:52:50 --> Final output sent to browser
DEBUG - 2016-03-03 09:52:50 --> Total execution time: 1.1529
INFO - 2016-03-03 06:53:12 --> Config Class Initialized
INFO - 2016-03-03 06:53:12 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:53:12 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:53:12 --> Utf8 Class Initialized
INFO - 2016-03-03 06:53:12 --> URI Class Initialized
INFO - 2016-03-03 06:53:12 --> Router Class Initialized
INFO - 2016-03-03 06:53:12 --> Output Class Initialized
INFO - 2016-03-03 06:53:12 --> Security Class Initialized
DEBUG - 2016-03-03 06:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:53:12 --> Input Class Initialized
INFO - 2016-03-03 06:53:12 --> Language Class Initialized
INFO - 2016-03-03 06:53:12 --> Loader Class Initialized
INFO - 2016-03-03 06:53:12 --> Helper loaded: url_helper
INFO - 2016-03-03 06:53:12 --> Helper loaded: file_helper
INFO - 2016-03-03 06:53:12 --> Helper loaded: date_helper
INFO - 2016-03-03 06:53:12 --> Helper loaded: form_helper
INFO - 2016-03-03 06:53:12 --> Database Driver Class Initialized
INFO - 2016-03-03 06:53:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:53:13 --> Controller Class Initialized
INFO - 2016-03-03 06:53:13 --> Model Class Initialized
INFO - 2016-03-03 06:53:13 --> Model Class Initialized
INFO - 2016-03-03 06:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:53:13 --> Pagination Class Initialized
INFO - 2016-03-03 06:53:13 --> Helper loaded: text_helper
INFO - 2016-03-03 06:53:13 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:53:13 --> Final output sent to browser
DEBUG - 2016-03-03 09:53:13 --> Total execution time: 1.1490
INFO - 2016-03-03 06:54:00 --> Config Class Initialized
INFO - 2016-03-03 06:54:00 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:54:00 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:54:00 --> Utf8 Class Initialized
INFO - 2016-03-03 06:54:00 --> URI Class Initialized
INFO - 2016-03-03 06:54:00 --> Router Class Initialized
INFO - 2016-03-03 06:54:00 --> Output Class Initialized
INFO - 2016-03-03 06:54:00 --> Security Class Initialized
DEBUG - 2016-03-03 06:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:54:00 --> Input Class Initialized
INFO - 2016-03-03 06:54:00 --> Language Class Initialized
INFO - 2016-03-03 06:54:00 --> Loader Class Initialized
INFO - 2016-03-03 06:54:00 --> Helper loaded: url_helper
INFO - 2016-03-03 06:54:00 --> Helper loaded: file_helper
INFO - 2016-03-03 06:54:00 --> Helper loaded: date_helper
INFO - 2016-03-03 06:54:00 --> Helper loaded: form_helper
INFO - 2016-03-03 06:54:00 --> Database Driver Class Initialized
INFO - 2016-03-03 06:54:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:54:01 --> Controller Class Initialized
INFO - 2016-03-03 06:54:01 --> Model Class Initialized
INFO - 2016-03-03 06:54:01 --> Model Class Initialized
INFO - 2016-03-03 06:54:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:54:01 --> Pagination Class Initialized
INFO - 2016-03-03 06:54:01 --> Helper loaded: text_helper
INFO - 2016-03-03 06:54:01 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:54:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:54:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:54:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:54:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:54:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:54:02 --> Final output sent to browser
DEBUG - 2016-03-03 09:54:02 --> Total execution time: 1.2421
INFO - 2016-03-03 06:54:15 --> Config Class Initialized
INFO - 2016-03-03 06:54:15 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:54:15 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:54:15 --> Utf8 Class Initialized
INFO - 2016-03-03 06:54:15 --> URI Class Initialized
INFO - 2016-03-03 06:54:15 --> Router Class Initialized
INFO - 2016-03-03 06:54:15 --> Output Class Initialized
INFO - 2016-03-03 06:54:15 --> Security Class Initialized
DEBUG - 2016-03-03 06:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:54:15 --> Input Class Initialized
INFO - 2016-03-03 06:54:15 --> Language Class Initialized
INFO - 2016-03-03 06:54:15 --> Loader Class Initialized
INFO - 2016-03-03 06:54:15 --> Helper loaded: url_helper
INFO - 2016-03-03 06:54:15 --> Helper loaded: file_helper
INFO - 2016-03-03 06:54:15 --> Helper loaded: date_helper
INFO - 2016-03-03 06:54:15 --> Helper loaded: form_helper
INFO - 2016-03-03 06:54:15 --> Database Driver Class Initialized
INFO - 2016-03-03 06:54:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:54:16 --> Controller Class Initialized
INFO - 2016-03-03 06:54:16 --> Model Class Initialized
INFO - 2016-03-03 06:54:16 --> Model Class Initialized
INFO - 2016-03-03 06:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:54:16 --> Pagination Class Initialized
INFO - 2016-03-03 06:54:16 --> Helper loaded: text_helper
INFO - 2016-03-03 06:54:16 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:54:16 --> Final output sent to browser
DEBUG - 2016-03-03 09:54:16 --> Total execution time: 1.1584
INFO - 2016-03-03 06:54:44 --> Config Class Initialized
INFO - 2016-03-03 06:54:44 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:54:44 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:54:44 --> Utf8 Class Initialized
INFO - 2016-03-03 06:54:44 --> URI Class Initialized
INFO - 2016-03-03 06:54:44 --> Router Class Initialized
INFO - 2016-03-03 06:54:44 --> Output Class Initialized
INFO - 2016-03-03 06:54:44 --> Security Class Initialized
DEBUG - 2016-03-03 06:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:54:44 --> Input Class Initialized
INFO - 2016-03-03 06:54:44 --> Language Class Initialized
INFO - 2016-03-03 06:54:44 --> Loader Class Initialized
INFO - 2016-03-03 06:54:44 --> Helper loaded: url_helper
INFO - 2016-03-03 06:54:44 --> Helper loaded: file_helper
INFO - 2016-03-03 06:54:44 --> Helper loaded: date_helper
INFO - 2016-03-03 06:54:44 --> Helper loaded: form_helper
INFO - 2016-03-03 06:54:44 --> Database Driver Class Initialized
INFO - 2016-03-03 06:54:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:54:45 --> Controller Class Initialized
INFO - 2016-03-03 06:54:45 --> Model Class Initialized
INFO - 2016-03-03 06:54:45 --> Model Class Initialized
INFO - 2016-03-03 06:54:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:54:45 --> Pagination Class Initialized
INFO - 2016-03-03 06:54:45 --> Helper loaded: text_helper
INFO - 2016-03-03 06:54:45 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:54:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:54:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:54:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:54:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:54:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:54:46 --> Final output sent to browser
DEBUG - 2016-03-03 09:54:46 --> Total execution time: 1.1472
INFO - 2016-03-03 06:55:24 --> Config Class Initialized
INFO - 2016-03-03 06:55:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:55:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:55:24 --> Utf8 Class Initialized
INFO - 2016-03-03 06:55:24 --> URI Class Initialized
INFO - 2016-03-03 06:55:24 --> Router Class Initialized
INFO - 2016-03-03 06:55:24 --> Output Class Initialized
INFO - 2016-03-03 06:55:24 --> Security Class Initialized
DEBUG - 2016-03-03 06:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:55:24 --> Input Class Initialized
INFO - 2016-03-03 06:55:24 --> Language Class Initialized
INFO - 2016-03-03 06:55:24 --> Loader Class Initialized
INFO - 2016-03-03 06:55:24 --> Helper loaded: url_helper
INFO - 2016-03-03 06:55:24 --> Helper loaded: file_helper
INFO - 2016-03-03 06:55:24 --> Helper loaded: date_helper
INFO - 2016-03-03 06:55:24 --> Helper loaded: form_helper
INFO - 2016-03-03 06:55:24 --> Database Driver Class Initialized
INFO - 2016-03-03 06:55:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:55:25 --> Controller Class Initialized
INFO - 2016-03-03 06:55:25 --> Model Class Initialized
INFO - 2016-03-03 06:55:25 --> Model Class Initialized
INFO - 2016-03-03 06:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:55:25 --> Pagination Class Initialized
INFO - 2016-03-03 06:55:25 --> Helper loaded: text_helper
INFO - 2016-03-03 06:55:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:55:25 --> Final output sent to browser
DEBUG - 2016-03-03 09:55:25 --> Total execution time: 1.2146
INFO - 2016-03-03 06:55:53 --> Config Class Initialized
INFO - 2016-03-03 06:55:53 --> Hooks Class Initialized
DEBUG - 2016-03-03 06:55:53 --> UTF-8 Support Enabled
INFO - 2016-03-03 06:55:53 --> Utf8 Class Initialized
INFO - 2016-03-03 06:55:53 --> URI Class Initialized
INFO - 2016-03-03 06:55:53 --> Router Class Initialized
INFO - 2016-03-03 06:55:53 --> Output Class Initialized
INFO - 2016-03-03 06:55:53 --> Security Class Initialized
DEBUG - 2016-03-03 06:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 06:55:53 --> Input Class Initialized
INFO - 2016-03-03 06:55:53 --> Language Class Initialized
INFO - 2016-03-03 06:55:53 --> Loader Class Initialized
INFO - 2016-03-03 06:55:53 --> Helper loaded: url_helper
INFO - 2016-03-03 06:55:53 --> Helper loaded: file_helper
INFO - 2016-03-03 06:55:53 --> Helper loaded: date_helper
INFO - 2016-03-03 06:55:53 --> Helper loaded: form_helper
INFO - 2016-03-03 06:55:53 --> Database Driver Class Initialized
INFO - 2016-03-03 06:55:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 06:55:54 --> Controller Class Initialized
INFO - 2016-03-03 06:55:54 --> Model Class Initialized
INFO - 2016-03-03 06:55:54 --> Model Class Initialized
INFO - 2016-03-03 06:55:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 06:55:54 --> Pagination Class Initialized
INFO - 2016-03-03 06:55:54 --> Helper loaded: text_helper
INFO - 2016-03-03 06:55:54 --> Helper loaded: cookie_helper
INFO - 2016-03-03 09:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 09:55:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 09:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 09:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 09:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 09:55:55 --> Final output sent to browser
DEBUG - 2016-03-03 09:55:55 --> Total execution time: 1.1440
INFO - 2016-03-03 07:04:18 --> Config Class Initialized
INFO - 2016-03-03 07:04:18 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:04:18 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:04:18 --> Utf8 Class Initialized
INFO - 2016-03-03 07:04:18 --> URI Class Initialized
DEBUG - 2016-03-03 07:04:18 --> No URI present. Default controller set.
INFO - 2016-03-03 07:04:18 --> Router Class Initialized
INFO - 2016-03-03 07:04:18 --> Output Class Initialized
INFO - 2016-03-03 07:04:18 --> Security Class Initialized
DEBUG - 2016-03-03 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:04:18 --> Input Class Initialized
INFO - 2016-03-03 07:04:18 --> Language Class Initialized
INFO - 2016-03-03 07:04:18 --> Loader Class Initialized
INFO - 2016-03-03 07:04:18 --> Helper loaded: url_helper
INFO - 2016-03-03 07:04:18 --> Helper loaded: file_helper
INFO - 2016-03-03 07:04:18 --> Helper loaded: date_helper
INFO - 2016-03-03 07:04:18 --> Helper loaded: form_helper
INFO - 2016-03-03 07:04:18 --> Database Driver Class Initialized
INFO - 2016-03-03 07:04:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:04:19 --> Controller Class Initialized
INFO - 2016-03-03 07:04:19 --> Model Class Initialized
INFO - 2016-03-03 07:04:19 --> Model Class Initialized
INFO - 2016-03-03 07:04:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 07:04:19 --> Pagination Class Initialized
INFO - 2016-03-03 07:04:19 --> Helper loaded: text_helper
INFO - 2016-03-03 07:04:19 --> Helper loaded: cookie_helper
INFO - 2016-03-03 10:04:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 10:04:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 10:04:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 10:04:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 10:04:19 --> Final output sent to browser
DEBUG - 2016-03-03 10:04:19 --> Total execution time: 1.2769
INFO - 2016-03-03 07:04:32 --> Config Class Initialized
INFO - 2016-03-03 07:04:32 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:04:32 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:04:32 --> Utf8 Class Initialized
INFO - 2016-03-03 07:04:32 --> URI Class Initialized
DEBUG - 2016-03-03 07:04:32 --> No URI present. Default controller set.
INFO - 2016-03-03 07:04:32 --> Router Class Initialized
INFO - 2016-03-03 07:04:32 --> Output Class Initialized
INFO - 2016-03-03 07:04:32 --> Security Class Initialized
DEBUG - 2016-03-03 07:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:04:32 --> Input Class Initialized
INFO - 2016-03-03 07:04:32 --> Language Class Initialized
INFO - 2016-03-03 07:04:32 --> Loader Class Initialized
INFO - 2016-03-03 07:04:32 --> Helper loaded: url_helper
INFO - 2016-03-03 07:04:32 --> Helper loaded: file_helper
INFO - 2016-03-03 07:04:32 --> Helper loaded: date_helper
INFO - 2016-03-03 07:04:32 --> Helper loaded: form_helper
INFO - 2016-03-03 07:04:32 --> Database Driver Class Initialized
INFO - 2016-03-03 07:04:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:04:33 --> Controller Class Initialized
INFO - 2016-03-03 07:04:33 --> Model Class Initialized
INFO - 2016-03-03 07:04:33 --> Model Class Initialized
INFO - 2016-03-03 07:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 07:04:33 --> Pagination Class Initialized
INFO - 2016-03-03 07:04:33 --> Helper loaded: text_helper
INFO - 2016-03-03 07:04:33 --> Helper loaded: cookie_helper
INFO - 2016-03-03 10:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 10:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 10:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 10:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 10:04:33 --> Final output sent to browser
DEBUG - 2016-03-03 10:04:33 --> Total execution time: 1.1289
INFO - 2016-03-03 07:04:55 --> Config Class Initialized
INFO - 2016-03-03 07:04:55 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:04:55 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:04:55 --> Utf8 Class Initialized
INFO - 2016-03-03 07:04:55 --> URI Class Initialized
INFO - 2016-03-03 07:04:55 --> Router Class Initialized
INFO - 2016-03-03 07:04:55 --> Output Class Initialized
INFO - 2016-03-03 07:04:55 --> Security Class Initialized
DEBUG - 2016-03-03 07:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:04:55 --> Input Class Initialized
INFO - 2016-03-03 07:04:55 --> Language Class Initialized
INFO - 2016-03-03 07:04:55 --> Loader Class Initialized
INFO - 2016-03-03 07:04:55 --> Helper loaded: url_helper
INFO - 2016-03-03 07:04:55 --> Helper loaded: file_helper
INFO - 2016-03-03 07:04:55 --> Helper loaded: date_helper
INFO - 2016-03-03 07:04:55 --> Helper loaded: form_helper
INFO - 2016-03-03 07:04:55 --> Database Driver Class Initialized
INFO - 2016-03-03 07:04:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:04:56 --> Controller Class Initialized
INFO - 2016-03-03 07:04:56 --> Model Class Initialized
INFO - 2016-03-03 07:04:56 --> Model Class Initialized
INFO - 2016-03-03 07:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 07:04:56 --> Pagination Class Initialized
INFO - 2016-03-03 07:04:56 --> Helper loaded: text_helper
INFO - 2016-03-03 07:04:56 --> Helper loaded: cookie_helper
INFO - 2016-03-03 10:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 10:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 10:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 10:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 10:04:56 --> Final output sent to browser
DEBUG - 2016-03-03 10:04:56 --> Total execution time: 1.2257
INFO - 2016-03-03 07:05:22 --> Config Class Initialized
INFO - 2016-03-03 07:05:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:05:22 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:05:22 --> Utf8 Class Initialized
INFO - 2016-03-03 07:05:22 --> URI Class Initialized
INFO - 2016-03-03 07:05:22 --> Router Class Initialized
INFO - 2016-03-03 07:05:22 --> Output Class Initialized
INFO - 2016-03-03 07:05:22 --> Security Class Initialized
DEBUG - 2016-03-03 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:05:22 --> Input Class Initialized
INFO - 2016-03-03 07:05:22 --> Language Class Initialized
INFO - 2016-03-03 07:05:22 --> Loader Class Initialized
INFO - 2016-03-03 07:05:22 --> Helper loaded: url_helper
INFO - 2016-03-03 07:05:22 --> Helper loaded: file_helper
INFO - 2016-03-03 07:05:22 --> Helper loaded: date_helper
INFO - 2016-03-03 07:05:22 --> Helper loaded: form_helper
INFO - 2016-03-03 07:05:22 --> Database Driver Class Initialized
INFO - 2016-03-03 07:05:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:05:23 --> Controller Class Initialized
INFO - 2016-03-03 07:05:23 --> Model Class Initialized
INFO - 2016-03-03 07:05:23 --> Model Class Initialized
INFO - 2016-03-03 07:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 07:05:23 --> Pagination Class Initialized
INFO - 2016-03-03 07:05:23 --> Helper loaded: text_helper
INFO - 2016-03-03 07:05:23 --> Helper loaded: cookie_helper
INFO - 2016-03-03 10:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 10:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 10:05:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 10:05:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 10:05:24 --> Final output sent to browser
DEBUG - 2016-03-03 10:05:24 --> Total execution time: 1.1748
INFO - 2016-03-03 07:19:34 --> Config Class Initialized
INFO - 2016-03-03 07:19:34 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:19:35 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:19:35 --> Utf8 Class Initialized
INFO - 2016-03-03 07:19:35 --> URI Class Initialized
INFO - 2016-03-03 07:19:35 --> Router Class Initialized
INFO - 2016-03-03 07:19:35 --> Output Class Initialized
INFO - 2016-03-03 07:19:35 --> Security Class Initialized
DEBUG - 2016-03-03 07:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:19:35 --> Input Class Initialized
INFO - 2016-03-03 07:19:35 --> Language Class Initialized
INFO - 2016-03-03 07:19:35 --> Loader Class Initialized
INFO - 2016-03-03 07:19:35 --> Helper loaded: url_helper
INFO - 2016-03-03 07:19:35 --> Helper loaded: file_helper
INFO - 2016-03-03 07:19:35 --> Helper loaded: date_helper
INFO - 2016-03-03 07:19:35 --> Helper loaded: form_helper
INFO - 2016-03-03 07:19:35 --> Database Driver Class Initialized
INFO - 2016-03-03 07:19:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:19:36 --> Controller Class Initialized
INFO - 2016-03-03 07:19:36 --> Model Class Initialized
INFO - 2016-03-03 07:19:36 --> Model Class Initialized
INFO - 2016-03-03 07:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 07:19:36 --> Pagination Class Initialized
INFO - 2016-03-03 07:19:36 --> Helper loaded: text_helper
INFO - 2016-03-03 07:19:36 --> Helper loaded: cookie_helper
INFO - 2016-03-03 10:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 10:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 10:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 10:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 10:19:36 --> Final output sent to browser
DEBUG - 2016-03-03 10:19:36 --> Total execution time: 1.1683
INFO - 2016-03-03 07:52:41 --> Config Class Initialized
INFO - 2016-03-03 07:52:41 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:52:41 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:52:41 --> Utf8 Class Initialized
INFO - 2016-03-03 07:52:41 --> URI Class Initialized
INFO - 2016-03-03 07:52:41 --> Router Class Initialized
INFO - 2016-03-03 07:52:41 --> Output Class Initialized
INFO - 2016-03-03 07:52:41 --> Security Class Initialized
DEBUG - 2016-03-03 07:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:52:41 --> Input Class Initialized
INFO - 2016-03-03 07:52:41 --> Language Class Initialized
INFO - 2016-03-03 07:52:41 --> Loader Class Initialized
INFO - 2016-03-03 07:52:41 --> Helper loaded: url_helper
INFO - 2016-03-03 07:52:41 --> Helper loaded: file_helper
INFO - 2016-03-03 07:52:41 --> Helper loaded: date_helper
INFO - 2016-03-03 07:52:41 --> Helper loaded: form_helper
INFO - 2016-03-03 07:52:41 --> Database Driver Class Initialized
INFO - 2016-03-03 07:52:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:52:42 --> Controller Class Initialized
INFO - 2016-03-03 07:52:42 --> Model Class Initialized
ERROR - 2016-03-03 07:52:42 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 299
INFO - 2016-03-03 07:53:03 --> Config Class Initialized
INFO - 2016-03-03 07:53:03 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:53:03 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:53:03 --> Utf8 Class Initialized
INFO - 2016-03-03 07:53:03 --> URI Class Initialized
INFO - 2016-03-03 07:53:03 --> Router Class Initialized
INFO - 2016-03-03 07:53:03 --> Output Class Initialized
INFO - 2016-03-03 07:53:03 --> Security Class Initialized
DEBUG - 2016-03-03 07:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:53:03 --> Input Class Initialized
INFO - 2016-03-03 07:53:03 --> Language Class Initialized
INFO - 2016-03-03 07:53:03 --> Loader Class Initialized
INFO - 2016-03-03 07:53:03 --> Helper loaded: url_helper
INFO - 2016-03-03 07:53:03 --> Helper loaded: file_helper
INFO - 2016-03-03 07:53:03 --> Helper loaded: date_helper
INFO - 2016-03-03 07:53:03 --> Helper loaded: form_helper
INFO - 2016-03-03 07:53:03 --> Database Driver Class Initialized
INFO - 2016-03-03 07:53:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:53:04 --> Controller Class Initialized
INFO - 2016-03-03 07:53:04 --> Model Class Initialized
INFO - 2016-03-03 07:53:04 --> Model Class Initialized
INFO - 2016-03-03 07:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 07:53:04 --> Pagination Class Initialized
INFO - 2016-03-03 07:53:04 --> Helper loaded: text_helper
INFO - 2016-03-03 07:53:04 --> Helper loaded: cookie_helper
INFO - 2016-03-03 10:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 10:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 10:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 10:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 10:53:04 --> Final output sent to browser
DEBUG - 2016-03-03 10:53:04 --> Total execution time: 1.1930
INFO - 2016-03-03 07:53:13 --> Config Class Initialized
INFO - 2016-03-03 07:53:13 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:53:13 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:53:13 --> Utf8 Class Initialized
INFO - 2016-03-03 07:53:13 --> URI Class Initialized
INFO - 2016-03-03 07:53:13 --> Router Class Initialized
INFO - 2016-03-03 07:53:13 --> Output Class Initialized
INFO - 2016-03-03 07:53:13 --> Security Class Initialized
DEBUG - 2016-03-03 07:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:53:13 --> Input Class Initialized
INFO - 2016-03-03 07:53:13 --> Language Class Initialized
INFO - 2016-03-03 07:53:13 --> Loader Class Initialized
INFO - 2016-03-03 07:53:13 --> Helper loaded: url_helper
INFO - 2016-03-03 07:53:13 --> Helper loaded: file_helper
INFO - 2016-03-03 07:53:13 --> Helper loaded: date_helper
INFO - 2016-03-03 07:53:13 --> Helper loaded: form_helper
INFO - 2016-03-03 07:53:13 --> Database Driver Class Initialized
INFO - 2016-03-03 07:53:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:53:14 --> Controller Class Initialized
INFO - 2016-03-03 07:53:14 --> Model Class Initialized
INFO - 2016-03-03 07:53:14 --> Model Class Initialized
INFO - 2016-03-03 07:53:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 07:53:14 --> Pagination Class Initialized
INFO - 2016-03-03 07:53:14 --> Helper loaded: text_helper
INFO - 2016-03-03 07:53:14 --> Helper loaded: cookie_helper
INFO - 2016-03-03 10:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 10:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 10:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 10:53:14 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 10:53:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 10:53:14 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 10:53:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 10:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 10:53:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 10:53:14 --> Final output sent to browser
DEBUG - 2016-03-03 10:53:14 --> Total execution time: 1.1389
INFO - 2016-03-03 07:53:53 --> Config Class Initialized
INFO - 2016-03-03 07:53:53 --> Hooks Class Initialized
DEBUG - 2016-03-03 07:53:53 --> UTF-8 Support Enabled
INFO - 2016-03-03 07:53:53 --> Utf8 Class Initialized
INFO - 2016-03-03 07:53:53 --> URI Class Initialized
INFO - 2016-03-03 07:53:53 --> Router Class Initialized
INFO - 2016-03-03 07:53:53 --> Output Class Initialized
INFO - 2016-03-03 07:53:53 --> Security Class Initialized
DEBUG - 2016-03-03 07:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 07:53:53 --> Input Class Initialized
INFO - 2016-03-03 07:53:53 --> Language Class Initialized
INFO - 2016-03-03 07:53:53 --> Loader Class Initialized
INFO - 2016-03-03 07:53:53 --> Helper loaded: url_helper
INFO - 2016-03-03 07:53:53 --> Helper loaded: file_helper
INFO - 2016-03-03 07:53:53 --> Helper loaded: date_helper
INFO - 2016-03-03 07:53:53 --> Helper loaded: form_helper
INFO - 2016-03-03 07:53:53 --> Database Driver Class Initialized
INFO - 2016-03-03 07:53:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 07:53:54 --> Controller Class Initialized
INFO - 2016-03-03 07:53:54 --> Model Class Initialized
INFO - 2016-03-03 07:53:54 --> Model Class Initialized
INFO - 2016-03-03 07:53:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 07:53:54 --> Pagination Class Initialized
INFO - 2016-03-03 07:53:54 --> Helper loaded: text_helper
INFO - 2016-03-03 07:53:54 --> Helper loaded: cookie_helper
INFO - 2016-03-03 10:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 10:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 10:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 10:53:54 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 10:53:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 10:53:54 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 10:53:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 10:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 10:53:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 10:53:54 --> Final output sent to browser
DEBUG - 2016-03-03 10:53:54 --> Total execution time: 1.2123
INFO - 2016-03-03 08:02:15 --> Config Class Initialized
INFO - 2016-03-03 08:02:15 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:02:15 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:02:15 --> Utf8 Class Initialized
INFO - 2016-03-03 08:02:15 --> URI Class Initialized
INFO - 2016-03-03 08:02:15 --> Router Class Initialized
INFO - 2016-03-03 08:02:15 --> Output Class Initialized
INFO - 2016-03-03 08:02:15 --> Security Class Initialized
DEBUG - 2016-03-03 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:02:15 --> Input Class Initialized
INFO - 2016-03-03 08:02:15 --> Language Class Initialized
INFO - 2016-03-03 08:02:15 --> Loader Class Initialized
INFO - 2016-03-03 08:02:15 --> Helper loaded: url_helper
INFO - 2016-03-03 08:02:15 --> Helper loaded: file_helper
INFO - 2016-03-03 08:02:15 --> Helper loaded: date_helper
INFO - 2016-03-03 08:02:15 --> Helper loaded: form_helper
INFO - 2016-03-03 08:02:15 --> Database Driver Class Initialized
INFO - 2016-03-03 08:02:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:02:16 --> Controller Class Initialized
INFO - 2016-03-03 08:02:16 --> Model Class Initialized
INFO - 2016-03-03 08:02:16 --> Model Class Initialized
INFO - 2016-03-03 08:02:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:02:16 --> Pagination Class Initialized
INFO - 2016-03-03 08:02:16 --> Helper loaded: text_helper
INFO - 2016-03-03 08:02:16 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:02:16 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:02:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:02:16 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:02:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 11:02:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:02:16 --> Final output sent to browser
DEBUG - 2016-03-03 11:02:16 --> Total execution time: 1.1272
INFO - 2016-03-03 08:03:52 --> Config Class Initialized
INFO - 2016-03-03 08:03:52 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:03:52 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:03:52 --> Utf8 Class Initialized
INFO - 2016-03-03 08:03:52 --> URI Class Initialized
INFO - 2016-03-03 08:03:52 --> Router Class Initialized
INFO - 2016-03-03 08:03:52 --> Output Class Initialized
INFO - 2016-03-03 08:03:52 --> Security Class Initialized
DEBUG - 2016-03-03 08:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:03:52 --> Input Class Initialized
INFO - 2016-03-03 08:03:52 --> Language Class Initialized
INFO - 2016-03-03 08:03:52 --> Loader Class Initialized
INFO - 2016-03-03 08:03:52 --> Helper loaded: url_helper
INFO - 2016-03-03 08:03:52 --> Helper loaded: file_helper
INFO - 2016-03-03 08:03:52 --> Helper loaded: date_helper
INFO - 2016-03-03 08:03:52 --> Helper loaded: form_helper
INFO - 2016-03-03 08:03:52 --> Database Driver Class Initialized
INFO - 2016-03-03 08:03:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:03:53 --> Controller Class Initialized
INFO - 2016-03-03 08:03:53 --> Model Class Initialized
INFO - 2016-03-03 08:03:53 --> Model Class Initialized
INFO - 2016-03-03 08:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:03:53 --> Pagination Class Initialized
INFO - 2016-03-03 08:03:53 --> Helper loaded: text_helper
INFO - 2016-03-03 08:03:53 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:03:53 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:03:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:03:53 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:03:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 11:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:03:53 --> Final output sent to browser
DEBUG - 2016-03-03 11:03:53 --> Total execution time: 1.1343
INFO - 2016-03-03 08:22:15 --> Config Class Initialized
INFO - 2016-03-03 08:22:15 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:22:15 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:22:15 --> Utf8 Class Initialized
INFO - 2016-03-03 08:22:15 --> URI Class Initialized
DEBUG - 2016-03-03 08:22:15 --> No URI present. Default controller set.
INFO - 2016-03-03 08:22:15 --> Router Class Initialized
INFO - 2016-03-03 08:22:15 --> Output Class Initialized
INFO - 2016-03-03 08:22:15 --> Security Class Initialized
DEBUG - 2016-03-03 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:22:15 --> Input Class Initialized
INFO - 2016-03-03 08:22:15 --> Language Class Initialized
INFO - 2016-03-03 08:22:15 --> Loader Class Initialized
INFO - 2016-03-03 08:22:15 --> Helper loaded: url_helper
INFO - 2016-03-03 08:22:15 --> Helper loaded: file_helper
INFO - 2016-03-03 08:22:15 --> Helper loaded: date_helper
INFO - 2016-03-03 08:22:15 --> Helper loaded: form_helper
INFO - 2016-03-03 08:22:15 --> Database Driver Class Initialized
INFO - 2016-03-03 08:22:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:22:16 --> Controller Class Initialized
INFO - 2016-03-03 08:22:16 --> Model Class Initialized
INFO - 2016-03-03 08:22:16 --> Model Class Initialized
INFO - 2016-03-03 08:22:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:22:16 --> Pagination Class Initialized
INFO - 2016-03-03 08:22:17 --> Helper loaded: text_helper
INFO - 2016-03-03 08:22:17 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:22:17 --> Final output sent to browser
DEBUG - 2016-03-03 11:22:17 --> Total execution time: 1.1784
INFO - 2016-03-03 08:23:01 --> Config Class Initialized
INFO - 2016-03-03 08:23:01 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:23:01 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:23:01 --> Utf8 Class Initialized
INFO - 2016-03-03 08:23:01 --> URI Class Initialized
INFO - 2016-03-03 08:23:01 --> Router Class Initialized
INFO - 2016-03-03 08:23:01 --> Output Class Initialized
INFO - 2016-03-03 08:23:01 --> Security Class Initialized
DEBUG - 2016-03-03 08:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:23:01 --> Input Class Initialized
INFO - 2016-03-03 08:23:01 --> Language Class Initialized
INFO - 2016-03-03 08:23:01 --> Loader Class Initialized
INFO - 2016-03-03 08:23:01 --> Helper loaded: url_helper
INFO - 2016-03-03 08:23:01 --> Helper loaded: file_helper
INFO - 2016-03-03 08:23:01 --> Helper loaded: date_helper
INFO - 2016-03-03 08:23:01 --> Helper loaded: form_helper
INFO - 2016-03-03 08:23:01 --> Database Driver Class Initialized
INFO - 2016-03-03 08:23:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:23:02 --> Controller Class Initialized
INFO - 2016-03-03 08:23:02 --> Model Class Initialized
INFO - 2016-03-03 08:23:02 --> Model Class Initialized
INFO - 2016-03-03 08:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:23:02 --> Pagination Class Initialized
INFO - 2016-03-03 08:23:02 --> Helper loaded: text_helper
INFO - 2016-03-03 08:23:02 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 11:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 11:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:23:02 --> Final output sent to browser
DEBUG - 2016-03-03 11:23:02 --> Total execution time: 1.1701
INFO - 2016-03-03 08:23:16 --> Config Class Initialized
INFO - 2016-03-03 08:23:16 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:23:16 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:23:16 --> Utf8 Class Initialized
INFO - 2016-03-03 08:23:16 --> URI Class Initialized
INFO - 2016-03-03 08:23:16 --> Router Class Initialized
INFO - 2016-03-03 08:23:16 --> Output Class Initialized
INFO - 2016-03-03 08:23:16 --> Security Class Initialized
DEBUG - 2016-03-03 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:23:16 --> Input Class Initialized
INFO - 2016-03-03 08:23:16 --> Language Class Initialized
INFO - 2016-03-03 08:23:16 --> Loader Class Initialized
INFO - 2016-03-03 08:23:16 --> Helper loaded: url_helper
INFO - 2016-03-03 08:23:16 --> Helper loaded: file_helper
INFO - 2016-03-03 08:23:16 --> Helper loaded: date_helper
INFO - 2016-03-03 08:23:16 --> Helper loaded: form_helper
INFO - 2016-03-03 08:23:16 --> Database Driver Class Initialized
INFO - 2016-03-03 08:23:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:23:17 --> Controller Class Initialized
INFO - 2016-03-03 08:23:17 --> Model Class Initialized
INFO - 2016-03-03 08:23:17 --> Model Class Initialized
INFO - 2016-03-03 08:23:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:23:17 --> Pagination Class Initialized
INFO - 2016-03-03 08:23:17 --> Helper loaded: text_helper
INFO - 2016-03-03 08:23:17 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:23:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:23:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:23:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:23:17 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:23:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:23:17 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:23:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:23:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 11:23:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:23:17 --> Final output sent to browser
DEBUG - 2016-03-03 11:23:17 --> Total execution time: 1.1394
INFO - 2016-03-03 08:26:31 --> Config Class Initialized
INFO - 2016-03-03 08:26:31 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:26:31 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:26:31 --> Utf8 Class Initialized
INFO - 2016-03-03 08:26:31 --> URI Class Initialized
INFO - 2016-03-03 08:26:31 --> Router Class Initialized
INFO - 2016-03-03 08:26:31 --> Output Class Initialized
INFO - 2016-03-03 08:26:31 --> Security Class Initialized
DEBUG - 2016-03-03 08:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:26:31 --> Input Class Initialized
INFO - 2016-03-03 08:26:31 --> Language Class Initialized
INFO - 2016-03-03 08:26:31 --> Loader Class Initialized
INFO - 2016-03-03 08:26:31 --> Helper loaded: url_helper
INFO - 2016-03-03 08:26:31 --> Helper loaded: file_helper
INFO - 2016-03-03 08:26:31 --> Helper loaded: date_helper
INFO - 2016-03-03 08:26:31 --> Helper loaded: form_helper
INFO - 2016-03-03 08:26:31 --> Database Driver Class Initialized
INFO - 2016-03-03 08:26:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:26:32 --> Controller Class Initialized
INFO - 2016-03-03 08:26:32 --> Model Class Initialized
INFO - 2016-03-03 08:26:32 --> Model Class Initialized
INFO - 2016-03-03 08:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:26:32 --> Pagination Class Initialized
INFO - 2016-03-03 08:26:32 --> Helper loaded: text_helper
INFO - 2016-03-03 08:26:32 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:26:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:26:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:26:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:26:32 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:26:32 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:26:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:26:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:26:32 --> Query error: Unknown column 'created_at' in 'where clause' - Invalid query: SELECT * FROM wall WHERE created > DATE_SUB(NOW(), INTERVAL 7 DAY )
AND created_at < curdate() + 1  ;
INFO - 2016-03-03 11:26:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 08:29:55 --> Config Class Initialized
INFO - 2016-03-03 08:29:55 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:29:55 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:29:55 --> Utf8 Class Initialized
INFO - 2016-03-03 08:29:55 --> URI Class Initialized
INFO - 2016-03-03 08:29:55 --> Router Class Initialized
INFO - 2016-03-03 08:29:55 --> Output Class Initialized
INFO - 2016-03-03 08:29:55 --> Security Class Initialized
DEBUG - 2016-03-03 08:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:29:55 --> Input Class Initialized
INFO - 2016-03-03 08:29:55 --> Language Class Initialized
INFO - 2016-03-03 08:29:55 --> Loader Class Initialized
INFO - 2016-03-03 08:29:55 --> Helper loaded: url_helper
INFO - 2016-03-03 08:29:55 --> Helper loaded: file_helper
INFO - 2016-03-03 08:29:55 --> Helper loaded: date_helper
INFO - 2016-03-03 08:29:55 --> Helper loaded: form_helper
INFO - 2016-03-03 08:29:55 --> Database Driver Class Initialized
INFO - 2016-03-03 08:29:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:29:56 --> Controller Class Initialized
INFO - 2016-03-03 08:29:56 --> Model Class Initialized
INFO - 2016-03-03 08:29:56 --> Model Class Initialized
INFO - 2016-03-03 08:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:29:56 --> Pagination Class Initialized
INFO - 2016-03-03 08:29:56 --> Helper loaded: text_helper
INFO - 2016-03-03 08:29:56 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:29:56 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:29:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:29:56 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:29:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:29:56 --> Final output sent to browser
DEBUG - 2016-03-03 11:29:56 --> Total execution time: 1.1512
INFO - 2016-03-03 08:31:22 --> Config Class Initialized
INFO - 2016-03-03 08:31:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:31:22 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:31:22 --> Utf8 Class Initialized
INFO - 2016-03-03 08:31:22 --> URI Class Initialized
INFO - 2016-03-03 08:31:22 --> Router Class Initialized
INFO - 2016-03-03 08:31:22 --> Output Class Initialized
INFO - 2016-03-03 08:31:22 --> Security Class Initialized
DEBUG - 2016-03-03 08:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:31:22 --> Input Class Initialized
INFO - 2016-03-03 08:31:22 --> Language Class Initialized
INFO - 2016-03-03 08:31:22 --> Loader Class Initialized
INFO - 2016-03-03 08:31:22 --> Helper loaded: url_helper
INFO - 2016-03-03 08:31:22 --> Helper loaded: file_helper
INFO - 2016-03-03 08:31:22 --> Helper loaded: date_helper
INFO - 2016-03-03 08:31:22 --> Helper loaded: form_helper
INFO - 2016-03-03 08:31:22 --> Database Driver Class Initialized
INFO - 2016-03-03 08:31:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:31:23 --> Controller Class Initialized
INFO - 2016-03-03 08:31:23 --> Model Class Initialized
ERROR - 2016-03-03 08:31:23 --> Severity: Parsing Error --> syntax error, unexpected '7' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 294
INFO - 2016-03-03 08:31:35 --> Config Class Initialized
INFO - 2016-03-03 08:31:35 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:31:35 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:31:35 --> Utf8 Class Initialized
INFO - 2016-03-03 08:31:35 --> URI Class Initialized
INFO - 2016-03-03 08:31:35 --> Router Class Initialized
INFO - 2016-03-03 08:31:35 --> Output Class Initialized
INFO - 2016-03-03 08:31:35 --> Security Class Initialized
DEBUG - 2016-03-03 08:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:31:35 --> Input Class Initialized
INFO - 2016-03-03 08:31:35 --> Language Class Initialized
INFO - 2016-03-03 08:31:35 --> Loader Class Initialized
INFO - 2016-03-03 08:31:35 --> Helper loaded: url_helper
INFO - 2016-03-03 08:31:35 --> Helper loaded: file_helper
INFO - 2016-03-03 08:31:35 --> Helper loaded: date_helper
INFO - 2016-03-03 08:31:35 --> Helper loaded: form_helper
INFO - 2016-03-03 08:31:35 --> Database Driver Class Initialized
INFO - 2016-03-03 08:31:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:31:36 --> Controller Class Initialized
INFO - 2016-03-03 08:31:36 --> Model Class Initialized
INFO - 2016-03-03 08:31:36 --> Model Class Initialized
INFO - 2016-03-03 08:31:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:31:36 --> Pagination Class Initialized
INFO - 2016-03-03 08:31:36 --> Helper loaded: text_helper
INFO - 2016-03-03 08:31:36 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:31:36 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:31:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:31:36 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:31:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:31:36 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, integer given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 294
INFO - 2016-03-03 11:31:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:31:36 --> Final output sent to browser
DEBUG - 2016-03-03 11:31:36 --> Total execution time: 1.1552
ERROR - 2016-03-03 11:31:36 --> Query error: Unknown column 'created' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1457022696
WHERE `created` >0
AND `created_at` < curdate() + 1
AND `id` = '806ccb94c5c6cce324fdfe64af45fbbf97b25aed'
INFO - 2016-03-03 11:31:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-03-03 11:31:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Output.php:528) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-03-03 08:32:05 --> Config Class Initialized
INFO - 2016-03-03 08:32:05 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:32:05 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:32:05 --> Utf8 Class Initialized
INFO - 2016-03-03 08:32:05 --> URI Class Initialized
INFO - 2016-03-03 08:32:05 --> Router Class Initialized
INFO - 2016-03-03 08:32:05 --> Output Class Initialized
INFO - 2016-03-03 08:32:05 --> Security Class Initialized
DEBUG - 2016-03-03 08:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:32:05 --> Input Class Initialized
INFO - 2016-03-03 08:32:05 --> Language Class Initialized
INFO - 2016-03-03 08:32:05 --> Loader Class Initialized
INFO - 2016-03-03 08:32:05 --> Helper loaded: url_helper
INFO - 2016-03-03 08:32:05 --> Helper loaded: file_helper
INFO - 2016-03-03 08:32:05 --> Helper loaded: date_helper
INFO - 2016-03-03 08:32:05 --> Helper loaded: form_helper
INFO - 2016-03-03 08:32:05 --> Database Driver Class Initialized
INFO - 2016-03-03 08:32:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:32:06 --> Controller Class Initialized
INFO - 2016-03-03 08:32:06 --> Model Class Initialized
ERROR - 2016-03-03 08:32:06 --> Severity: Parsing Error --> syntax error, unexpected ''7'' (T_CONSTANT_ENCAPSED_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 294
INFO - 2016-03-03 08:32:23 --> Config Class Initialized
INFO - 2016-03-03 08:32:23 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:32:23 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:32:23 --> Utf8 Class Initialized
INFO - 2016-03-03 08:32:23 --> URI Class Initialized
INFO - 2016-03-03 08:32:23 --> Router Class Initialized
INFO - 2016-03-03 08:32:23 --> Output Class Initialized
INFO - 2016-03-03 08:32:23 --> Security Class Initialized
DEBUG - 2016-03-03 08:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:32:23 --> Input Class Initialized
INFO - 2016-03-03 08:32:23 --> Language Class Initialized
INFO - 2016-03-03 08:32:23 --> Loader Class Initialized
INFO - 2016-03-03 08:32:23 --> Helper loaded: url_helper
INFO - 2016-03-03 08:32:23 --> Helper loaded: file_helper
INFO - 2016-03-03 08:32:23 --> Helper loaded: date_helper
INFO - 2016-03-03 08:32:23 --> Helper loaded: form_helper
INFO - 2016-03-03 08:32:23 --> Database Driver Class Initialized
INFO - 2016-03-03 08:32:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:32:24 --> Controller Class Initialized
INFO - 2016-03-03 08:32:24 --> Model Class Initialized
ERROR - 2016-03-03 08:32:24 --> Severity: Parsing Error --> syntax error, unexpected '7' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 294
INFO - 2016-03-03 08:37:08 --> Config Class Initialized
INFO - 2016-03-03 08:37:08 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:37:08 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:37:08 --> Utf8 Class Initialized
INFO - 2016-03-03 08:37:08 --> URI Class Initialized
INFO - 2016-03-03 08:37:08 --> Router Class Initialized
INFO - 2016-03-03 08:37:08 --> Output Class Initialized
INFO - 2016-03-03 08:37:08 --> Security Class Initialized
DEBUG - 2016-03-03 08:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:37:08 --> Input Class Initialized
INFO - 2016-03-03 08:37:08 --> Language Class Initialized
INFO - 2016-03-03 08:37:08 --> Loader Class Initialized
INFO - 2016-03-03 08:37:08 --> Helper loaded: url_helper
INFO - 2016-03-03 08:37:08 --> Helper loaded: file_helper
INFO - 2016-03-03 08:37:08 --> Helper loaded: date_helper
INFO - 2016-03-03 08:37:08 --> Helper loaded: form_helper
INFO - 2016-03-03 08:37:08 --> Database Driver Class Initialized
INFO - 2016-03-03 08:37:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:37:09 --> Controller Class Initialized
INFO - 2016-03-03 08:37:09 --> Model Class Initialized
ERROR - 2016-03-03 08:37:09 --> Severity: Parsing Error --> syntax error, unexpected '7' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 294
INFO - 2016-03-03 08:41:53 --> Config Class Initialized
INFO - 2016-03-03 08:41:53 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:41:53 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:41:53 --> Utf8 Class Initialized
INFO - 2016-03-03 08:41:53 --> URI Class Initialized
INFO - 2016-03-03 08:41:53 --> Router Class Initialized
INFO - 2016-03-03 08:41:53 --> Output Class Initialized
INFO - 2016-03-03 08:41:53 --> Security Class Initialized
DEBUG - 2016-03-03 08:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:41:53 --> Input Class Initialized
INFO - 2016-03-03 08:41:53 --> Language Class Initialized
INFO - 2016-03-03 08:41:53 --> Loader Class Initialized
INFO - 2016-03-03 08:41:53 --> Helper loaded: url_helper
INFO - 2016-03-03 08:41:53 --> Helper loaded: file_helper
INFO - 2016-03-03 08:41:53 --> Helper loaded: date_helper
INFO - 2016-03-03 08:41:53 --> Helper loaded: form_helper
INFO - 2016-03-03 08:41:53 --> Database Driver Class Initialized
INFO - 2016-03-03 08:41:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:41:54 --> Controller Class Initialized
INFO - 2016-03-03 08:41:54 --> Model Class Initialized
INFO - 2016-03-03 08:41:54 --> Model Class Initialized
INFO - 2016-03-03 08:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:41:54 --> Pagination Class Initialized
INFO - 2016-03-03 08:41:54 --> Helper loaded: text_helper
INFO - 2016-03-03 08:41:54 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 11:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 11:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:41:54 --> Final output sent to browser
DEBUG - 2016-03-03 11:41:54 --> Total execution time: 1.3939
INFO - 2016-03-03 08:42:00 --> Config Class Initialized
INFO - 2016-03-03 08:42:00 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:42:00 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:42:00 --> Utf8 Class Initialized
INFO - 2016-03-03 08:42:00 --> URI Class Initialized
INFO - 2016-03-03 08:42:00 --> Router Class Initialized
INFO - 2016-03-03 08:42:00 --> Output Class Initialized
INFO - 2016-03-03 08:42:01 --> Security Class Initialized
DEBUG - 2016-03-03 08:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:42:01 --> Input Class Initialized
INFO - 2016-03-03 08:42:01 --> Language Class Initialized
INFO - 2016-03-03 08:42:01 --> Loader Class Initialized
INFO - 2016-03-03 08:42:01 --> Helper loaded: url_helper
INFO - 2016-03-03 08:42:01 --> Helper loaded: file_helper
INFO - 2016-03-03 08:42:01 --> Helper loaded: date_helper
INFO - 2016-03-03 08:42:01 --> Helper loaded: form_helper
INFO - 2016-03-03 08:42:01 --> Database Driver Class Initialized
INFO - 2016-03-03 08:42:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:42:02 --> Controller Class Initialized
INFO - 2016-03-03 08:42:02 --> Model Class Initialized
INFO - 2016-03-03 08:42:02 --> Model Class Initialized
INFO - 2016-03-03 08:42:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:42:02 --> Pagination Class Initialized
INFO - 2016-03-03 08:42:02 --> Helper loaded: text_helper
INFO - 2016-03-03 08:42:02 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:42:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:42:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:42:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:42:02 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:42:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:42:02 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:42:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:42:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 11:42:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:42:02 --> Final output sent to browser
DEBUG - 2016-03-03 11:42:02 --> Total execution time: 1.2316
INFO - 2016-03-03 08:44:31 --> Config Class Initialized
INFO - 2016-03-03 08:44:31 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:44:31 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:44:31 --> Utf8 Class Initialized
INFO - 2016-03-03 08:44:31 --> URI Class Initialized
INFO - 2016-03-03 08:44:31 --> Router Class Initialized
INFO - 2016-03-03 08:44:31 --> Output Class Initialized
INFO - 2016-03-03 08:44:31 --> Security Class Initialized
DEBUG - 2016-03-03 08:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:44:31 --> Input Class Initialized
INFO - 2016-03-03 08:44:31 --> Language Class Initialized
ERROR - 2016-03-03 08:44:31 --> Severity: Parsing Error --> syntax error, unexpected '1' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 106
INFO - 2016-03-03 08:44:43 --> Config Class Initialized
INFO - 2016-03-03 08:44:43 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:44:43 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:44:43 --> Utf8 Class Initialized
INFO - 2016-03-03 08:44:43 --> URI Class Initialized
INFO - 2016-03-03 08:44:43 --> Router Class Initialized
INFO - 2016-03-03 08:44:43 --> Output Class Initialized
INFO - 2016-03-03 08:44:43 --> Security Class Initialized
DEBUG - 2016-03-03 08:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:44:43 --> Input Class Initialized
INFO - 2016-03-03 08:44:43 --> Language Class Initialized
ERROR - 2016-03-03 08:44:43 --> Severity: Parsing Error --> syntax error, unexpected '1' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 106
INFO - 2016-03-03 08:46:30 --> Config Class Initialized
INFO - 2016-03-03 08:46:30 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:46:30 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:46:30 --> Utf8 Class Initialized
INFO - 2016-03-03 08:46:30 --> URI Class Initialized
INFO - 2016-03-03 08:46:30 --> Router Class Initialized
INFO - 2016-03-03 08:46:30 --> Output Class Initialized
INFO - 2016-03-03 08:46:30 --> Security Class Initialized
DEBUG - 2016-03-03 08:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:46:30 --> Input Class Initialized
INFO - 2016-03-03 08:46:30 --> Language Class Initialized
ERROR - 2016-03-03 08:46:30 --> Severity: Parsing Error --> syntax error, unexpected '1' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 106
INFO - 2016-03-03 08:46:36 --> Config Class Initialized
INFO - 2016-03-03 08:46:36 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:46:36 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:46:36 --> Utf8 Class Initialized
INFO - 2016-03-03 08:46:36 --> URI Class Initialized
INFO - 2016-03-03 08:46:36 --> Router Class Initialized
INFO - 2016-03-03 08:46:36 --> Output Class Initialized
INFO - 2016-03-03 08:46:36 --> Security Class Initialized
DEBUG - 2016-03-03 08:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:46:36 --> Input Class Initialized
INFO - 2016-03-03 08:46:36 --> Language Class Initialized
INFO - 2016-03-03 08:46:36 --> Loader Class Initialized
INFO - 2016-03-03 08:46:36 --> Helper loaded: url_helper
INFO - 2016-03-03 08:46:36 --> Helper loaded: file_helper
INFO - 2016-03-03 08:46:36 --> Helper loaded: date_helper
INFO - 2016-03-03 08:46:36 --> Helper loaded: form_helper
INFO - 2016-03-03 08:46:36 --> Database Driver Class Initialized
INFO - 2016-03-03 08:46:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:46:37 --> Controller Class Initialized
INFO - 2016-03-03 08:46:37 --> Model Class Initialized
INFO - 2016-03-03 08:46:37 --> Model Class Initialized
INFO - 2016-03-03 08:46:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:46:37 --> Pagination Class Initialized
INFO - 2016-03-03 08:46:37 --> Helper loaded: text_helper
INFO - 2016-03-03 08:46:37 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:46:37 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:46:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:46:37 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:46:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:46:37 --> Severity: Notice --> Undefined variable: mama C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 115
INFO - 2016-03-03 11:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:46:37 --> Final output sent to browser
DEBUG - 2016-03-03 11:46:37 --> Total execution time: 1.1704
INFO - 2016-03-03 08:46:51 --> Config Class Initialized
INFO - 2016-03-03 08:46:51 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:46:51 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:46:51 --> Utf8 Class Initialized
INFO - 2016-03-03 08:46:51 --> URI Class Initialized
INFO - 2016-03-03 08:46:51 --> Router Class Initialized
INFO - 2016-03-03 08:46:51 --> Output Class Initialized
INFO - 2016-03-03 08:46:51 --> Security Class Initialized
DEBUG - 2016-03-03 08:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:46:51 --> Input Class Initialized
INFO - 2016-03-03 08:46:51 --> Language Class Initialized
INFO - 2016-03-03 08:46:51 --> Loader Class Initialized
INFO - 2016-03-03 08:46:51 --> Helper loaded: url_helper
INFO - 2016-03-03 08:46:51 --> Helper loaded: file_helper
INFO - 2016-03-03 08:46:51 --> Helper loaded: date_helper
INFO - 2016-03-03 08:46:51 --> Helper loaded: form_helper
INFO - 2016-03-03 08:46:51 --> Database Driver Class Initialized
INFO - 2016-03-03 08:46:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:46:52 --> Controller Class Initialized
INFO - 2016-03-03 08:46:52 --> Model Class Initialized
INFO - 2016-03-03 08:46:52 --> Model Class Initialized
INFO - 2016-03-03 08:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:46:52 --> Pagination Class Initialized
INFO - 2016-03-03 08:46:52 --> Helper loaded: text_helper
INFO - 2016-03-03 08:46:52 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:46:52 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:46:52 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:46:52 --> Final output sent to browser
DEBUG - 2016-03-03 11:46:52 --> Total execution time: 1.1633
INFO - 2016-03-03 08:47:51 --> Config Class Initialized
INFO - 2016-03-03 08:47:51 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:47:51 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:47:51 --> Utf8 Class Initialized
INFO - 2016-03-03 08:47:51 --> URI Class Initialized
INFO - 2016-03-03 08:47:51 --> Router Class Initialized
INFO - 2016-03-03 08:47:51 --> Output Class Initialized
INFO - 2016-03-03 08:47:51 --> Security Class Initialized
DEBUG - 2016-03-03 08:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:47:51 --> Input Class Initialized
INFO - 2016-03-03 08:47:51 --> Language Class Initialized
INFO - 2016-03-03 08:47:51 --> Loader Class Initialized
INFO - 2016-03-03 08:47:51 --> Helper loaded: url_helper
INFO - 2016-03-03 08:47:51 --> Helper loaded: file_helper
INFO - 2016-03-03 08:47:51 --> Helper loaded: date_helper
INFO - 2016-03-03 08:47:51 --> Helper loaded: form_helper
INFO - 2016-03-03 08:47:51 --> Database Driver Class Initialized
INFO - 2016-03-03 08:47:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:47:52 --> Controller Class Initialized
INFO - 2016-03-03 08:47:52 --> Model Class Initialized
INFO - 2016-03-03 08:47:52 --> Model Class Initialized
INFO - 2016-03-03 08:47:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:47:52 --> Pagination Class Initialized
INFO - 2016-03-03 08:47:52 --> Helper loaded: text_helper
INFO - 2016-03-03 08:47:52 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:47:52 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:47:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:47:52 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:47:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:47:52 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, boolean given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 11:47:52 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, boolean given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 110
INFO - 2016-03-03 11:47:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:47:52 --> Final output sent to browser
DEBUG - 2016-03-03 11:47:52 --> Total execution time: 1.1717
INFO - 2016-03-03 08:48:07 --> Config Class Initialized
INFO - 2016-03-03 08:48:07 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:48:07 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:48:07 --> Utf8 Class Initialized
INFO - 2016-03-03 08:48:07 --> URI Class Initialized
INFO - 2016-03-03 08:48:07 --> Router Class Initialized
INFO - 2016-03-03 08:48:07 --> Output Class Initialized
INFO - 2016-03-03 08:48:07 --> Security Class Initialized
DEBUG - 2016-03-03 08:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:48:07 --> Input Class Initialized
INFO - 2016-03-03 08:48:07 --> Language Class Initialized
INFO - 2016-03-03 08:48:07 --> Loader Class Initialized
INFO - 2016-03-03 08:48:07 --> Helper loaded: url_helper
INFO - 2016-03-03 08:48:07 --> Helper loaded: file_helper
INFO - 2016-03-03 08:48:07 --> Helper loaded: date_helper
INFO - 2016-03-03 08:48:07 --> Helper loaded: form_helper
INFO - 2016-03-03 08:48:07 --> Database Driver Class Initialized
INFO - 2016-03-03 08:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:48:08 --> Controller Class Initialized
INFO - 2016-03-03 08:48:08 --> Model Class Initialized
INFO - 2016-03-03 08:48:08 --> Model Class Initialized
INFO - 2016-03-03 08:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:48:08 --> Pagination Class Initialized
INFO - 2016-03-03 08:48:08 --> Helper loaded: text_helper
INFO - 2016-03-03 08:48:08 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:48:08 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:48:08 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:48:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:48:08 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, integer given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 11:48:08 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, integer given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 110
INFO - 2016-03-03 11:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:48:08 --> Final output sent to browser
DEBUG - 2016-03-03 11:48:08 --> Total execution time: 1.1318
INFO - 2016-03-03 08:48:34 --> Config Class Initialized
INFO - 2016-03-03 08:48:34 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:48:34 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:48:34 --> Utf8 Class Initialized
INFO - 2016-03-03 08:48:34 --> URI Class Initialized
INFO - 2016-03-03 08:48:34 --> Router Class Initialized
INFO - 2016-03-03 08:48:34 --> Output Class Initialized
INFO - 2016-03-03 08:48:34 --> Security Class Initialized
DEBUG - 2016-03-03 08:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:48:34 --> Input Class Initialized
INFO - 2016-03-03 08:48:34 --> Language Class Initialized
INFO - 2016-03-03 08:48:34 --> Loader Class Initialized
INFO - 2016-03-03 08:48:34 --> Helper loaded: url_helper
INFO - 2016-03-03 08:48:34 --> Helper loaded: file_helper
INFO - 2016-03-03 08:48:34 --> Helper loaded: date_helper
INFO - 2016-03-03 08:48:34 --> Helper loaded: form_helper
INFO - 2016-03-03 08:48:34 --> Database Driver Class Initialized
INFO - 2016-03-03 08:48:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:48:35 --> Controller Class Initialized
INFO - 2016-03-03 08:48:35 --> Model Class Initialized
INFO - 2016-03-03 08:48:35 --> Model Class Initialized
INFO - 2016-03-03 08:48:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:48:35 --> Pagination Class Initialized
INFO - 2016-03-03 08:48:35 --> Helper loaded: text_helper
INFO - 2016-03-03 08:48:35 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:48:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:48:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:48:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:48:35 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:48:35 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:48:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:48:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:48:35 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, integer given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 11:48:35 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, integer given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 110
INFO - 2016-03-03 11:48:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:48:35 --> Final output sent to browser
DEBUG - 2016-03-03 11:48:35 --> Total execution time: 1.1606
INFO - 2016-03-03 08:52:42 --> Config Class Initialized
INFO - 2016-03-03 08:52:42 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:52:42 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:52:42 --> Utf8 Class Initialized
INFO - 2016-03-03 08:52:42 --> URI Class Initialized
INFO - 2016-03-03 08:52:42 --> Router Class Initialized
INFO - 2016-03-03 08:52:42 --> Output Class Initialized
INFO - 2016-03-03 08:52:42 --> Security Class Initialized
DEBUG - 2016-03-03 08:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:52:42 --> Input Class Initialized
INFO - 2016-03-03 08:52:42 --> Language Class Initialized
INFO - 2016-03-03 08:52:42 --> Loader Class Initialized
INFO - 2016-03-03 08:52:42 --> Helper loaded: url_helper
INFO - 2016-03-03 08:52:42 --> Helper loaded: file_helper
INFO - 2016-03-03 08:52:42 --> Helper loaded: date_helper
INFO - 2016-03-03 08:52:42 --> Helper loaded: form_helper
INFO - 2016-03-03 08:52:42 --> Database Driver Class Initialized
INFO - 2016-03-03 08:52:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:52:43 --> Controller Class Initialized
INFO - 2016-03-03 08:52:43 --> Model Class Initialized
INFO - 2016-03-03 08:52:43 --> Model Class Initialized
INFO - 2016-03-03 08:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:52:43 --> Pagination Class Initialized
INFO - 2016-03-03 08:52:43 --> Helper loaded: text_helper
INFO - 2016-03-03 08:52:43 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:52:43 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:52:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:52:43 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:52:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:52:43 --> Severity: Error --> Call to undefined function data() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
INFO - 2016-03-03 08:52:58 --> Config Class Initialized
INFO - 2016-03-03 08:52:58 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:52:58 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:52:58 --> Utf8 Class Initialized
INFO - 2016-03-03 08:52:58 --> URI Class Initialized
INFO - 2016-03-03 08:52:58 --> Router Class Initialized
INFO - 2016-03-03 08:52:58 --> Output Class Initialized
INFO - 2016-03-03 08:52:58 --> Security Class Initialized
DEBUG - 2016-03-03 08:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:52:58 --> Input Class Initialized
INFO - 2016-03-03 08:52:58 --> Language Class Initialized
INFO - 2016-03-03 08:52:58 --> Loader Class Initialized
INFO - 2016-03-03 08:52:58 --> Helper loaded: url_helper
INFO - 2016-03-03 08:52:58 --> Helper loaded: file_helper
INFO - 2016-03-03 08:52:58 --> Helper loaded: date_helper
INFO - 2016-03-03 08:52:58 --> Helper loaded: form_helper
INFO - 2016-03-03 08:52:58 --> Database Driver Class Initialized
INFO - 2016-03-03 08:52:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:52:59 --> Controller Class Initialized
INFO - 2016-03-03 08:52:59 --> Model Class Initialized
INFO - 2016-03-03 08:52:59 --> Model Class Initialized
INFO - 2016-03-03 08:52:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:52:59 --> Pagination Class Initialized
INFO - 2016-03-03 08:52:59 --> Helper loaded: text_helper
INFO - 2016-03-03 08:52:59 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:52:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:52:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:52:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:52:59 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:52:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:52:59 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:52:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:52:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:52:59 --> Severity: Error --> Call to undefined function data() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 110
INFO - 2016-03-03 08:53:59 --> Config Class Initialized
INFO - 2016-03-03 08:53:59 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:53:59 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:53:59 --> Utf8 Class Initialized
INFO - 2016-03-03 08:53:59 --> URI Class Initialized
INFO - 2016-03-03 08:53:59 --> Router Class Initialized
INFO - 2016-03-03 08:53:59 --> Output Class Initialized
INFO - 2016-03-03 08:53:59 --> Security Class Initialized
DEBUG - 2016-03-03 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:53:59 --> Input Class Initialized
INFO - 2016-03-03 08:53:59 --> Language Class Initialized
INFO - 2016-03-03 08:53:59 --> Loader Class Initialized
INFO - 2016-03-03 08:53:59 --> Helper loaded: url_helper
INFO - 2016-03-03 08:53:59 --> Helper loaded: file_helper
INFO - 2016-03-03 08:53:59 --> Helper loaded: date_helper
INFO - 2016-03-03 08:53:59 --> Helper loaded: form_helper
INFO - 2016-03-03 08:53:59 --> Database Driver Class Initialized
INFO - 2016-03-03 08:54:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:54:00 --> Controller Class Initialized
INFO - 2016-03-03 08:54:00 --> Model Class Initialized
INFO - 2016-03-03 08:54:00 --> Model Class Initialized
INFO - 2016-03-03 08:54:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:54:00 --> Pagination Class Initialized
INFO - 2016-03-03 08:54:00 --> Helper loaded: text_helper
INFO - 2016-03-03 08:54:00 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:54:00 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:54:00 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:54:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:54:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:54:00 --> Severity: Error --> Call to undefined function data() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 108
INFO - 2016-03-03 08:54:09 --> Config Class Initialized
INFO - 2016-03-03 08:54:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:54:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:54:09 --> Utf8 Class Initialized
INFO - 2016-03-03 08:54:09 --> URI Class Initialized
INFO - 2016-03-03 08:54:09 --> Router Class Initialized
INFO - 2016-03-03 08:54:09 --> Output Class Initialized
INFO - 2016-03-03 08:54:09 --> Security Class Initialized
DEBUG - 2016-03-03 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:54:09 --> Input Class Initialized
INFO - 2016-03-03 08:54:09 --> Language Class Initialized
INFO - 2016-03-03 08:54:09 --> Loader Class Initialized
INFO - 2016-03-03 08:54:09 --> Helper loaded: url_helper
INFO - 2016-03-03 08:54:09 --> Helper loaded: file_helper
INFO - 2016-03-03 08:54:09 --> Helper loaded: date_helper
INFO - 2016-03-03 08:54:09 --> Helper loaded: form_helper
INFO - 2016-03-03 08:54:09 --> Database Driver Class Initialized
INFO - 2016-03-03 08:54:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:54:10 --> Controller Class Initialized
INFO - 2016-03-03 08:54:10 --> Model Class Initialized
INFO - 2016-03-03 08:54:10 --> Model Class Initialized
INFO - 2016-03-03 08:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:54:10 --> Pagination Class Initialized
INFO - 2016-03-03 08:54:10 --> Helper loaded: text_helper
INFO - 2016-03-03 08:54:10 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:54:10 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:54:10 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 11:54:10 --> Severity: Error --> Call to undefined function data() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 110
INFO - 2016-03-03 08:56:42 --> Config Class Initialized
INFO - 2016-03-03 08:56:42 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:56:42 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:56:42 --> Utf8 Class Initialized
INFO - 2016-03-03 08:56:42 --> URI Class Initialized
INFO - 2016-03-03 08:56:42 --> Router Class Initialized
INFO - 2016-03-03 08:56:42 --> Output Class Initialized
INFO - 2016-03-03 08:56:42 --> Security Class Initialized
DEBUG - 2016-03-03 08:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:56:42 --> Input Class Initialized
INFO - 2016-03-03 08:56:42 --> Language Class Initialized
INFO - 2016-03-03 08:56:42 --> Loader Class Initialized
INFO - 2016-03-03 08:56:42 --> Helper loaded: url_helper
INFO - 2016-03-03 08:56:42 --> Helper loaded: file_helper
INFO - 2016-03-03 08:56:42 --> Helper loaded: date_helper
INFO - 2016-03-03 08:56:42 --> Helper loaded: form_helper
INFO - 2016-03-03 08:56:42 --> Database Driver Class Initialized
INFO - 2016-03-03 08:56:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:56:43 --> Controller Class Initialized
INFO - 2016-03-03 08:56:43 --> Model Class Initialized
INFO - 2016-03-03 08:56:43 --> Model Class Initialized
INFO - 2016-03-03 08:56:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:56:43 --> Pagination Class Initialized
INFO - 2016-03-03 08:56:43 --> Helper loaded: text_helper
INFO - 2016-03-03 08:56:43 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:56:43 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:56:43 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:56:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 11:56:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:56:43 --> Final output sent to browser
DEBUG - 2016-03-03 11:56:43 --> Total execution time: 1.1246
INFO - 2016-03-03 08:57:14 --> Config Class Initialized
INFO - 2016-03-03 08:57:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 08:57:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 08:57:14 --> Utf8 Class Initialized
INFO - 2016-03-03 08:57:14 --> URI Class Initialized
INFO - 2016-03-03 08:57:14 --> Router Class Initialized
INFO - 2016-03-03 08:57:14 --> Output Class Initialized
INFO - 2016-03-03 08:57:14 --> Security Class Initialized
DEBUG - 2016-03-03 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 08:57:14 --> Input Class Initialized
INFO - 2016-03-03 08:57:14 --> Language Class Initialized
INFO - 2016-03-03 08:57:14 --> Loader Class Initialized
INFO - 2016-03-03 08:57:14 --> Helper loaded: url_helper
INFO - 2016-03-03 08:57:14 --> Helper loaded: file_helper
INFO - 2016-03-03 08:57:14 --> Helper loaded: date_helper
INFO - 2016-03-03 08:57:14 --> Helper loaded: form_helper
INFO - 2016-03-03 08:57:14 --> Database Driver Class Initialized
INFO - 2016-03-03 08:57:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 08:57:15 --> Controller Class Initialized
INFO - 2016-03-03 08:57:15 --> Model Class Initialized
INFO - 2016-03-03 08:57:15 --> Model Class Initialized
INFO - 2016-03-03 08:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 08:57:15 --> Pagination Class Initialized
INFO - 2016-03-03 08:57:15 --> Helper loaded: text_helper
INFO - 2016-03-03 08:57:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 11:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 11:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 11:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 11:57:15 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:57:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 11:57:15 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 11:57:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 11:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 11:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 11:57:15 --> Final output sent to browser
DEBUG - 2016-03-03 11:57:15 --> Total execution time: 1.1389
INFO - 2016-03-03 09:02:56 --> Config Class Initialized
INFO - 2016-03-03 09:02:56 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:02:56 --> UTF-8 Support Enabled
INFO - 2016-03-03 09:02:56 --> Utf8 Class Initialized
INFO - 2016-03-03 09:02:56 --> URI Class Initialized
INFO - 2016-03-03 09:02:56 --> Router Class Initialized
INFO - 2016-03-03 09:02:56 --> Output Class Initialized
INFO - 2016-03-03 09:02:56 --> Security Class Initialized
DEBUG - 2016-03-03 09:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 09:02:56 --> Input Class Initialized
INFO - 2016-03-03 09:02:56 --> Language Class Initialized
INFO - 2016-03-03 09:02:56 --> Loader Class Initialized
INFO - 2016-03-03 09:02:56 --> Helper loaded: url_helper
INFO - 2016-03-03 09:02:56 --> Helper loaded: file_helper
INFO - 2016-03-03 09:02:56 --> Helper loaded: date_helper
INFO - 2016-03-03 09:02:56 --> Helper loaded: form_helper
INFO - 2016-03-03 09:02:56 --> Database Driver Class Initialized
INFO - 2016-03-03 09:02:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 09:02:57 --> Controller Class Initialized
INFO - 2016-03-03 09:02:57 --> Model Class Initialized
INFO - 2016-03-03 09:02:57 --> Model Class Initialized
INFO - 2016-03-03 09:02:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 09:02:57 --> Pagination Class Initialized
INFO - 2016-03-03 09:02:57 --> Helper loaded: text_helper
INFO - 2016-03-03 09:02:57 --> Helper loaded: cookie_helper
INFO - 2016-03-03 12:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 12:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 12:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 12:02:57 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:02:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:02:57 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 12:02:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 12:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 12:02:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 12:02:57 --> Final output sent to browser
DEBUG - 2016-03-03 12:02:57 --> Total execution time: 1.1290
INFO - 2016-03-03 09:08:14 --> Config Class Initialized
INFO - 2016-03-03 09:08:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:08:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 09:08:14 --> Utf8 Class Initialized
INFO - 2016-03-03 09:08:14 --> URI Class Initialized
INFO - 2016-03-03 09:08:14 --> Router Class Initialized
INFO - 2016-03-03 09:08:14 --> Output Class Initialized
INFO - 2016-03-03 09:08:14 --> Security Class Initialized
DEBUG - 2016-03-03 09:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 09:08:14 --> Input Class Initialized
INFO - 2016-03-03 09:08:14 --> Language Class Initialized
INFO - 2016-03-03 09:08:14 --> Loader Class Initialized
INFO - 2016-03-03 09:08:14 --> Helper loaded: url_helper
INFO - 2016-03-03 09:08:14 --> Helper loaded: file_helper
INFO - 2016-03-03 09:08:14 --> Helper loaded: date_helper
INFO - 2016-03-03 09:08:14 --> Helper loaded: form_helper
INFO - 2016-03-03 09:08:14 --> Database Driver Class Initialized
INFO - 2016-03-03 09:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 09:08:15 --> Controller Class Initialized
INFO - 2016-03-03 09:08:15 --> Model Class Initialized
INFO - 2016-03-03 09:08:15 --> Model Class Initialized
INFO - 2016-03-03 09:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 09:08:15 --> Pagination Class Initialized
INFO - 2016-03-03 09:08:15 --> Helper loaded: text_helper
INFO - 2016-03-03 09:08:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 12:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 12:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 12:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 12:08:15 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:08:15 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 12:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 12:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 12:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 12:08:15 --> Final output sent to browser
DEBUG - 2016-03-03 12:08:15 --> Total execution time: 1.1531
INFO - 2016-03-03 09:09:28 --> Config Class Initialized
INFO - 2016-03-03 09:09:28 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:09:28 --> UTF-8 Support Enabled
INFO - 2016-03-03 09:09:28 --> Utf8 Class Initialized
INFO - 2016-03-03 09:09:28 --> URI Class Initialized
INFO - 2016-03-03 09:09:28 --> Router Class Initialized
INFO - 2016-03-03 09:09:28 --> Output Class Initialized
INFO - 2016-03-03 09:09:28 --> Security Class Initialized
DEBUG - 2016-03-03 09:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 09:09:28 --> Input Class Initialized
INFO - 2016-03-03 09:09:28 --> Language Class Initialized
INFO - 2016-03-03 09:09:28 --> Loader Class Initialized
INFO - 2016-03-03 09:09:28 --> Helper loaded: url_helper
INFO - 2016-03-03 09:09:28 --> Helper loaded: file_helper
INFO - 2016-03-03 09:09:28 --> Helper loaded: date_helper
INFO - 2016-03-03 09:09:28 --> Helper loaded: form_helper
INFO - 2016-03-03 09:09:28 --> Database Driver Class Initialized
INFO - 2016-03-03 09:09:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 09:09:29 --> Controller Class Initialized
INFO - 2016-03-03 09:09:29 --> Model Class Initialized
INFO - 2016-03-03 09:09:29 --> Model Class Initialized
INFO - 2016-03-03 09:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 09:09:29 --> Pagination Class Initialized
INFO - 2016-03-03 09:09:29 --> Helper loaded: text_helper
INFO - 2016-03-03 09:09:29 --> Helper loaded: cookie_helper
INFO - 2016-03-03 12:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 12:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 12:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 12:09:29 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:09:29 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 12:09:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 12:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 12:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 12:09:29 --> Final output sent to browser
DEBUG - 2016-03-03 12:09:29 --> Total execution time: 1.1487
INFO - 2016-03-03 09:14:07 --> Config Class Initialized
INFO - 2016-03-03 09:14:07 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:14:07 --> UTF-8 Support Enabled
INFO - 2016-03-03 09:14:07 --> Utf8 Class Initialized
INFO - 2016-03-03 09:14:07 --> URI Class Initialized
INFO - 2016-03-03 09:14:07 --> Router Class Initialized
INFO - 2016-03-03 09:14:07 --> Output Class Initialized
INFO - 2016-03-03 09:14:07 --> Security Class Initialized
DEBUG - 2016-03-03 09:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 09:14:07 --> Input Class Initialized
INFO - 2016-03-03 09:14:07 --> Language Class Initialized
INFO - 2016-03-03 09:14:07 --> Loader Class Initialized
INFO - 2016-03-03 09:14:07 --> Helper loaded: url_helper
INFO - 2016-03-03 09:14:07 --> Helper loaded: file_helper
INFO - 2016-03-03 09:14:07 --> Helper loaded: date_helper
INFO - 2016-03-03 09:14:07 --> Helper loaded: form_helper
INFO - 2016-03-03 09:14:07 --> Database Driver Class Initialized
INFO - 2016-03-03 09:14:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 09:14:08 --> Controller Class Initialized
INFO - 2016-03-03 09:14:08 --> Model Class Initialized
INFO - 2016-03-03 09:14:08 --> Model Class Initialized
INFO - 2016-03-03 09:14:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 09:14:08 --> Pagination Class Initialized
INFO - 2016-03-03 09:14:08 --> Helper loaded: text_helper
INFO - 2016-03-03 09:14:08 --> Helper loaded: cookie_helper
INFO - 2016-03-03 12:14:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 12:14:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 12:14:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 12:14:08 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:14:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:14:08 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 12:14:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 12:14:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 12:14:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 12:14:08 --> Final output sent to browser
DEBUG - 2016-03-03 12:14:08 --> Total execution time: 1.1287
INFO - 2016-03-03 09:14:36 --> Config Class Initialized
INFO - 2016-03-03 09:14:36 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:14:36 --> UTF-8 Support Enabled
INFO - 2016-03-03 09:14:36 --> Utf8 Class Initialized
INFO - 2016-03-03 09:14:36 --> URI Class Initialized
INFO - 2016-03-03 09:14:36 --> Router Class Initialized
INFO - 2016-03-03 09:14:36 --> Output Class Initialized
INFO - 2016-03-03 09:14:36 --> Security Class Initialized
DEBUG - 2016-03-03 09:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 09:14:36 --> Input Class Initialized
INFO - 2016-03-03 09:14:36 --> Language Class Initialized
ERROR - 2016-03-03 09:14:36 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 119
INFO - 2016-03-03 09:14:42 --> Config Class Initialized
INFO - 2016-03-03 09:14:42 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:14:42 --> UTF-8 Support Enabled
INFO - 2016-03-03 09:14:42 --> Utf8 Class Initialized
INFO - 2016-03-03 09:14:42 --> URI Class Initialized
INFO - 2016-03-03 09:14:42 --> Router Class Initialized
INFO - 2016-03-03 09:14:42 --> Output Class Initialized
INFO - 2016-03-03 09:14:42 --> Security Class Initialized
DEBUG - 2016-03-03 09:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 09:14:42 --> Input Class Initialized
INFO - 2016-03-03 09:14:42 --> Language Class Initialized
INFO - 2016-03-03 09:14:42 --> Loader Class Initialized
INFO - 2016-03-03 09:14:42 --> Helper loaded: url_helper
INFO - 2016-03-03 09:14:42 --> Helper loaded: file_helper
INFO - 2016-03-03 09:14:42 --> Helper loaded: date_helper
INFO - 2016-03-03 09:14:42 --> Helper loaded: form_helper
INFO - 2016-03-03 09:14:42 --> Database Driver Class Initialized
INFO - 2016-03-03 09:14:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 09:14:43 --> Controller Class Initialized
INFO - 2016-03-03 09:14:43 --> Model Class Initialized
INFO - 2016-03-03 09:14:43 --> Model Class Initialized
INFO - 2016-03-03 09:14:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 09:14:43 --> Pagination Class Initialized
INFO - 2016-03-03 09:14:43 --> Helper loaded: text_helper
INFO - 2016-03-03 09:14:43 --> Helper loaded: cookie_helper
INFO - 2016-03-03 12:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 12:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 12:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 12:14:43 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:14:43 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 12:14:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 12:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 12:14:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 12:14:43 --> Final output sent to browser
DEBUG - 2016-03-03 12:14:43 --> Total execution time: 1.1425
INFO - 2016-03-03 09:15:53 --> Config Class Initialized
INFO - 2016-03-03 09:15:53 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:15:53 --> UTF-8 Support Enabled
INFO - 2016-03-03 09:15:53 --> Utf8 Class Initialized
INFO - 2016-03-03 09:15:53 --> URI Class Initialized
INFO - 2016-03-03 09:15:53 --> Router Class Initialized
INFO - 2016-03-03 09:15:53 --> Output Class Initialized
INFO - 2016-03-03 09:15:53 --> Security Class Initialized
DEBUG - 2016-03-03 09:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 09:15:53 --> Input Class Initialized
INFO - 2016-03-03 09:15:53 --> Language Class Initialized
INFO - 2016-03-03 09:15:53 --> Loader Class Initialized
INFO - 2016-03-03 09:15:53 --> Helper loaded: url_helper
INFO - 2016-03-03 09:15:53 --> Helper loaded: file_helper
INFO - 2016-03-03 09:15:53 --> Helper loaded: date_helper
INFO - 2016-03-03 09:15:53 --> Helper loaded: form_helper
INFO - 2016-03-03 09:15:53 --> Database Driver Class Initialized
INFO - 2016-03-03 09:15:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 09:15:54 --> Controller Class Initialized
INFO - 2016-03-03 09:15:54 --> Model Class Initialized
INFO - 2016-03-03 09:15:54 --> Model Class Initialized
INFO - 2016-03-03 09:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 09:15:54 --> Pagination Class Initialized
INFO - 2016-03-03 09:15:54 --> Helper loaded: text_helper
INFO - 2016-03-03 09:15:54 --> Helper loaded: cookie_helper
INFO - 2016-03-03 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 12:15:54 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:15:54 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 12:15:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 12:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 12:15:54 --> Final output sent to browser
DEBUG - 2016-03-03 12:15:54 --> Total execution time: 1.1278
INFO - 2016-03-03 09:16:05 --> Config Class Initialized
INFO - 2016-03-03 09:16:05 --> Hooks Class Initialized
DEBUG - 2016-03-03 09:16:05 --> UTF-8 Support Enabled
INFO - 2016-03-03 09:16:05 --> Utf8 Class Initialized
INFO - 2016-03-03 09:16:05 --> URI Class Initialized
INFO - 2016-03-03 09:16:05 --> Router Class Initialized
INFO - 2016-03-03 09:16:05 --> Output Class Initialized
INFO - 2016-03-03 09:16:05 --> Security Class Initialized
DEBUG - 2016-03-03 09:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 09:16:05 --> Input Class Initialized
INFO - 2016-03-03 09:16:05 --> Language Class Initialized
INFO - 2016-03-03 09:16:05 --> Loader Class Initialized
INFO - 2016-03-03 09:16:05 --> Helper loaded: url_helper
INFO - 2016-03-03 09:16:05 --> Helper loaded: file_helper
INFO - 2016-03-03 09:16:05 --> Helper loaded: date_helper
INFO - 2016-03-03 09:16:05 --> Helper loaded: form_helper
INFO - 2016-03-03 09:16:05 --> Database Driver Class Initialized
INFO - 2016-03-03 09:16:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 09:16:06 --> Controller Class Initialized
INFO - 2016-03-03 09:16:06 --> Model Class Initialized
INFO - 2016-03-03 09:16:06 --> Model Class Initialized
INFO - 2016-03-03 09:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 09:16:06 --> Pagination Class Initialized
INFO - 2016-03-03 09:16:06 --> Helper loaded: text_helper
INFO - 2016-03-03 09:16:06 --> Helper loaded: cookie_helper
INFO - 2016-03-03 12:16:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 12:16:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 12:16:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 12:16:06 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 12:16:06 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 12:16:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 12:16:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 12:16:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 12:16:06 --> Final output sent to browser
DEBUG - 2016-03-03 12:16:06 --> Total execution time: 1.1198
INFO - 2016-03-03 10:29:18 --> Config Class Initialized
INFO - 2016-03-03 10:29:18 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:29:18 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:29:18 --> Utf8 Class Initialized
INFO - 2016-03-03 10:29:18 --> URI Class Initialized
INFO - 2016-03-03 10:29:18 --> Router Class Initialized
INFO - 2016-03-03 10:29:18 --> Output Class Initialized
INFO - 2016-03-03 10:29:18 --> Security Class Initialized
DEBUG - 2016-03-03 10:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:29:18 --> Input Class Initialized
INFO - 2016-03-03 10:29:18 --> Language Class Initialized
INFO - 2016-03-03 10:29:18 --> Loader Class Initialized
INFO - 2016-03-03 10:29:18 --> Helper loaded: url_helper
INFO - 2016-03-03 10:29:18 --> Helper loaded: file_helper
INFO - 2016-03-03 10:29:18 --> Helper loaded: date_helper
INFO - 2016-03-03 10:29:18 --> Helper loaded: form_helper
INFO - 2016-03-03 10:29:18 --> Database Driver Class Initialized
INFO - 2016-03-03 10:29:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:29:19 --> Controller Class Initialized
INFO - 2016-03-03 10:29:19 --> Model Class Initialized
INFO - 2016-03-03 10:29:19 --> Model Class Initialized
INFO - 2016-03-03 10:29:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:29:19 --> Pagination Class Initialized
INFO - 2016-03-03 10:29:19 --> Helper loaded: text_helper
INFO - 2016-03-03 10:29:19 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:29:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:29:19 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:29:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:29:19 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:29:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 13:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:29:20 --> Final output sent to browser
DEBUG - 2016-03-03 13:29:20 --> Total execution time: 1.1732
INFO - 2016-03-03 10:31:33 --> Config Class Initialized
INFO - 2016-03-03 10:31:33 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:31:33 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:31:33 --> Utf8 Class Initialized
INFO - 2016-03-03 10:31:33 --> URI Class Initialized
INFO - 2016-03-03 10:31:33 --> Router Class Initialized
INFO - 2016-03-03 10:31:33 --> Output Class Initialized
INFO - 2016-03-03 10:31:33 --> Security Class Initialized
DEBUG - 2016-03-03 10:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:31:33 --> Input Class Initialized
INFO - 2016-03-03 10:31:33 --> Language Class Initialized
ERROR - 2016-03-03 10:31:33 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 124
INFO - 2016-03-03 10:31:39 --> Config Class Initialized
INFO - 2016-03-03 10:31:39 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:31:39 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:31:39 --> Utf8 Class Initialized
INFO - 2016-03-03 10:31:39 --> URI Class Initialized
INFO - 2016-03-03 10:31:39 --> Router Class Initialized
INFO - 2016-03-03 10:31:39 --> Output Class Initialized
INFO - 2016-03-03 10:31:39 --> Security Class Initialized
DEBUG - 2016-03-03 10:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:31:39 --> Input Class Initialized
INFO - 2016-03-03 10:31:39 --> Language Class Initialized
INFO - 2016-03-03 10:31:39 --> Loader Class Initialized
INFO - 2016-03-03 10:31:39 --> Helper loaded: url_helper
INFO - 2016-03-03 10:31:39 --> Helper loaded: file_helper
INFO - 2016-03-03 10:31:39 --> Helper loaded: date_helper
INFO - 2016-03-03 10:31:39 --> Helper loaded: form_helper
INFO - 2016-03-03 10:31:39 --> Database Driver Class Initialized
INFO - 2016-03-03 10:31:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:31:40 --> Controller Class Initialized
INFO - 2016-03-03 10:31:40 --> Model Class Initialized
INFO - 2016-03-03 10:31:40 --> Model Class Initialized
INFO - 2016-03-03 10:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:31:40 --> Pagination Class Initialized
INFO - 2016-03-03 10:31:40 --> Helper loaded: text_helper
INFO - 2016-03-03 10:31:40 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:31:40 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:31:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:31:40 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:31:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 13:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:31:40 --> Final output sent to browser
DEBUG - 2016-03-03 13:31:40 --> Total execution time: 1.1301
INFO - 2016-03-03 10:32:24 --> Config Class Initialized
INFO - 2016-03-03 10:32:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:32:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:32:24 --> Utf8 Class Initialized
INFO - 2016-03-03 10:32:24 --> URI Class Initialized
INFO - 2016-03-03 10:32:24 --> Router Class Initialized
INFO - 2016-03-03 10:32:24 --> Output Class Initialized
INFO - 2016-03-03 10:32:24 --> Security Class Initialized
DEBUG - 2016-03-03 10:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:32:24 --> Input Class Initialized
INFO - 2016-03-03 10:32:24 --> Language Class Initialized
INFO - 2016-03-03 10:32:24 --> Loader Class Initialized
INFO - 2016-03-03 10:32:24 --> Helper loaded: url_helper
INFO - 2016-03-03 10:32:24 --> Helper loaded: file_helper
INFO - 2016-03-03 10:32:24 --> Helper loaded: date_helper
INFO - 2016-03-03 10:32:24 --> Helper loaded: form_helper
INFO - 2016-03-03 10:32:24 --> Database Driver Class Initialized
INFO - 2016-03-03 10:32:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:32:25 --> Controller Class Initialized
INFO - 2016-03-03 10:32:25 --> Model Class Initialized
INFO - 2016-03-03 10:32:25 --> Model Class Initialized
INFO - 2016-03-03 10:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:32:25 --> Pagination Class Initialized
INFO - 2016-03-03 10:32:25 --> Helper loaded: text_helper
INFO - 2016-03-03 10:32:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:32:25 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:32:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:32:25 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:32:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 13:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:32:25 --> Final output sent to browser
DEBUG - 2016-03-03 13:32:25 --> Total execution time: 1.1440
INFO - 2016-03-03 10:38:38 --> Config Class Initialized
INFO - 2016-03-03 10:38:38 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:38:38 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:38:38 --> Utf8 Class Initialized
INFO - 2016-03-03 10:38:38 --> URI Class Initialized
INFO - 2016-03-03 10:38:38 --> Router Class Initialized
INFO - 2016-03-03 10:38:38 --> Output Class Initialized
INFO - 2016-03-03 10:38:38 --> Security Class Initialized
DEBUG - 2016-03-03 10:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:38:38 --> Input Class Initialized
INFO - 2016-03-03 10:38:38 --> Language Class Initialized
INFO - 2016-03-03 10:38:38 --> Loader Class Initialized
INFO - 2016-03-03 10:38:38 --> Helper loaded: url_helper
INFO - 2016-03-03 10:38:38 --> Helper loaded: file_helper
INFO - 2016-03-03 10:38:38 --> Helper loaded: date_helper
INFO - 2016-03-03 10:38:38 --> Helper loaded: form_helper
INFO - 2016-03-03 10:38:38 --> Database Driver Class Initialized
INFO - 2016-03-03 10:38:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:38:39 --> Controller Class Initialized
INFO - 2016-03-03 10:38:39 --> Model Class Initialized
INFO - 2016-03-03 10:38:39 --> Model Class Initialized
INFO - 2016-03-03 10:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:38:39 --> Pagination Class Initialized
INFO - 2016-03-03 10:38:39 --> Helper loaded: text_helper
INFO - 2016-03-03 10:38:39 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:38:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:38:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:38:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:38:39 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:38:39 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:38:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:38:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:38:39 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: select * from wall WHERE date BETWEEN date_sub(now(),INTERVAL 1 WEEK) and now()
INFO - 2016-03-03 13:38:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 10:38:59 --> Config Class Initialized
INFO - 2016-03-03 10:38:59 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:38:59 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:38:59 --> Utf8 Class Initialized
INFO - 2016-03-03 10:38:59 --> URI Class Initialized
INFO - 2016-03-03 10:38:59 --> Router Class Initialized
INFO - 2016-03-03 10:38:59 --> Output Class Initialized
INFO - 2016-03-03 10:38:59 --> Security Class Initialized
DEBUG - 2016-03-03 10:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:38:59 --> Input Class Initialized
INFO - 2016-03-03 10:38:59 --> Language Class Initialized
INFO - 2016-03-03 10:38:59 --> Loader Class Initialized
INFO - 2016-03-03 10:38:59 --> Helper loaded: url_helper
INFO - 2016-03-03 10:38:59 --> Helper loaded: file_helper
INFO - 2016-03-03 10:38:59 --> Helper loaded: date_helper
INFO - 2016-03-03 10:38:59 --> Helper loaded: form_helper
INFO - 2016-03-03 10:38:59 --> Database Driver Class Initialized
INFO - 2016-03-03 10:39:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:39:01 --> Controller Class Initialized
INFO - 2016-03-03 10:39:01 --> Model Class Initialized
INFO - 2016-03-03 10:39:01 --> Model Class Initialized
INFO - 2016-03-03 10:39:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:39:01 --> Pagination Class Initialized
INFO - 2016-03-03 10:39:01 --> Helper loaded: text_helper
INFO - 2016-03-03 10:39:01 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:39:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:39:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:39:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:39:01 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:39:01 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:39:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:39:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 13:39:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:39:01 --> Final output sent to browser
DEBUG - 2016-03-03 13:39:01 --> Total execution time: 1.1772
INFO - 2016-03-03 10:41:22 --> Config Class Initialized
INFO - 2016-03-03 10:41:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:41:22 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:41:22 --> Utf8 Class Initialized
INFO - 2016-03-03 10:41:22 --> URI Class Initialized
INFO - 2016-03-03 10:41:22 --> Router Class Initialized
INFO - 2016-03-03 10:41:22 --> Output Class Initialized
INFO - 2016-03-03 10:41:22 --> Security Class Initialized
DEBUG - 2016-03-03 10:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:41:22 --> Input Class Initialized
INFO - 2016-03-03 10:41:22 --> Language Class Initialized
INFO - 2016-03-03 10:41:22 --> Loader Class Initialized
INFO - 2016-03-03 10:41:22 --> Helper loaded: url_helper
INFO - 2016-03-03 10:41:22 --> Helper loaded: file_helper
INFO - 2016-03-03 10:41:22 --> Helper loaded: date_helper
INFO - 2016-03-03 10:41:22 --> Helper loaded: form_helper
INFO - 2016-03-03 10:41:22 --> Database Driver Class Initialized
INFO - 2016-03-03 10:41:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:41:23 --> Controller Class Initialized
INFO - 2016-03-03 10:41:23 --> Model Class Initialized
INFO - 2016-03-03 10:41:23 --> Model Class Initialized
INFO - 2016-03-03 10:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:41:23 --> Pagination Class Initialized
INFO - 2016-03-03 10:41:23 --> Helper loaded: text_helper
INFO - 2016-03-03 10:41:23 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:41:23 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:41:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:41:23 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:41:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:41:23 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 113
INFO - 2016-03-03 13:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:41:23 --> Final output sent to browser
DEBUG - 2016-03-03 13:41:23 --> Total execution time: 1.1537
INFO - 2016-03-03 10:41:51 --> Config Class Initialized
INFO - 2016-03-03 10:41:51 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:41:51 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:41:51 --> Utf8 Class Initialized
INFO - 2016-03-03 10:41:51 --> URI Class Initialized
INFO - 2016-03-03 10:41:51 --> Router Class Initialized
INFO - 2016-03-03 10:41:51 --> Output Class Initialized
INFO - 2016-03-03 10:41:51 --> Security Class Initialized
DEBUG - 2016-03-03 10:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:41:51 --> Input Class Initialized
INFO - 2016-03-03 10:41:51 --> Language Class Initialized
INFO - 2016-03-03 10:41:51 --> Loader Class Initialized
INFO - 2016-03-03 10:41:51 --> Helper loaded: url_helper
INFO - 2016-03-03 10:41:51 --> Helper loaded: file_helper
INFO - 2016-03-03 10:41:51 --> Helper loaded: date_helper
INFO - 2016-03-03 10:41:51 --> Helper loaded: form_helper
INFO - 2016-03-03 10:41:51 --> Database Driver Class Initialized
INFO - 2016-03-03 10:41:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:41:52 --> Controller Class Initialized
INFO - 2016-03-03 10:41:52 --> Model Class Initialized
INFO - 2016-03-03 10:41:52 --> Model Class Initialized
INFO - 2016-03-03 10:41:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:41:52 --> Pagination Class Initialized
INFO - 2016-03-03 10:41:52 --> Helper loaded: text_helper
INFO - 2016-03-03 10:41:52 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:41:52 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:41:52 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:41:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 13:41:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:41:52 --> Final output sent to browser
DEBUG - 2016-03-03 13:41:52 --> Total execution time: 1.1642
INFO - 2016-03-03 10:43:55 --> Config Class Initialized
INFO - 2016-03-03 10:43:55 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:43:55 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:43:55 --> Utf8 Class Initialized
INFO - 2016-03-03 10:43:55 --> URI Class Initialized
INFO - 2016-03-03 10:43:55 --> Router Class Initialized
INFO - 2016-03-03 10:43:55 --> Output Class Initialized
INFO - 2016-03-03 10:43:55 --> Security Class Initialized
DEBUG - 2016-03-03 10:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:43:55 --> Input Class Initialized
INFO - 2016-03-03 10:43:55 --> Language Class Initialized
INFO - 2016-03-03 10:43:55 --> Loader Class Initialized
INFO - 2016-03-03 10:43:55 --> Helper loaded: url_helper
INFO - 2016-03-03 10:43:55 --> Helper loaded: file_helper
INFO - 2016-03-03 10:43:55 --> Helper loaded: date_helper
INFO - 2016-03-03 10:43:55 --> Helper loaded: form_helper
INFO - 2016-03-03 10:43:55 --> Database Driver Class Initialized
INFO - 2016-03-03 10:43:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:43:56 --> Controller Class Initialized
INFO - 2016-03-03 10:43:56 --> Model Class Initialized
INFO - 2016-03-03 10:43:56 --> Model Class Initialized
INFO - 2016-03-03 10:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:43:56 --> Pagination Class Initialized
INFO - 2016-03-03 10:43:56 --> Helper loaded: text_helper
INFO - 2016-03-03 10:43:56 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:43:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:43:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:43:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:43:56 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:43:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:43:56 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:43:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:43:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:43:56 --> Severity: Notice --> Undefined variable: date C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:43:56 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, null given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
INFO - 2016-03-03 13:43:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:43:56 --> Final output sent to browser
DEBUG - 2016-03-03 13:43:56 --> Total execution time: 1.1493
INFO - 2016-03-03 10:44:19 --> Config Class Initialized
INFO - 2016-03-03 10:44:19 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:44:19 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:44:19 --> Utf8 Class Initialized
INFO - 2016-03-03 10:44:19 --> URI Class Initialized
INFO - 2016-03-03 10:44:19 --> Router Class Initialized
INFO - 2016-03-03 10:44:19 --> Output Class Initialized
INFO - 2016-03-03 10:44:19 --> Security Class Initialized
DEBUG - 2016-03-03 10:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:44:19 --> Input Class Initialized
INFO - 2016-03-03 10:44:19 --> Language Class Initialized
INFO - 2016-03-03 10:44:19 --> Loader Class Initialized
INFO - 2016-03-03 10:44:19 --> Helper loaded: url_helper
INFO - 2016-03-03 10:44:19 --> Helper loaded: file_helper
INFO - 2016-03-03 10:44:19 --> Helper loaded: date_helper
INFO - 2016-03-03 10:44:19 --> Helper loaded: form_helper
INFO - 2016-03-03 10:44:20 --> Database Driver Class Initialized
INFO - 2016-03-03 10:44:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:44:21 --> Controller Class Initialized
INFO - 2016-03-03 10:44:21 --> Model Class Initialized
INFO - 2016-03-03 10:44:21 --> Model Class Initialized
INFO - 2016-03-03 10:44:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:44:21 --> Pagination Class Initialized
INFO - 2016-03-03 10:44:21 --> Helper loaded: text_helper
INFO - 2016-03-03 10:44:21 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:44:21 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:44:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:44:21 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:44:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:44:21 --> Severity: Notice --> Undefined variable: date C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:44:21 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, null given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
INFO - 2016-03-03 13:44:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:44:21 --> Final output sent to browser
DEBUG - 2016-03-03 13:44:21 --> Total execution time: 1.2276
INFO - 2016-03-03 10:44:44 --> Config Class Initialized
INFO - 2016-03-03 10:44:44 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:44:44 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:44:44 --> Utf8 Class Initialized
INFO - 2016-03-03 10:44:44 --> URI Class Initialized
INFO - 2016-03-03 10:44:44 --> Router Class Initialized
INFO - 2016-03-03 10:44:44 --> Output Class Initialized
INFO - 2016-03-03 10:44:44 --> Security Class Initialized
DEBUG - 2016-03-03 10:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:44:44 --> Input Class Initialized
INFO - 2016-03-03 10:44:44 --> Language Class Initialized
INFO - 2016-03-03 10:44:44 --> Loader Class Initialized
INFO - 2016-03-03 10:44:44 --> Helper loaded: url_helper
INFO - 2016-03-03 10:44:44 --> Helper loaded: file_helper
INFO - 2016-03-03 10:44:44 --> Helper loaded: date_helper
INFO - 2016-03-03 10:44:44 --> Helper loaded: form_helper
INFO - 2016-03-03 10:44:44 --> Database Driver Class Initialized
INFO - 2016-03-03 10:44:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:44:45 --> Controller Class Initialized
INFO - 2016-03-03 10:44:45 --> Model Class Initialized
INFO - 2016-03-03 10:44:45 --> Model Class Initialized
INFO - 2016-03-03 10:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:44:45 --> Pagination Class Initialized
INFO - 2016-03-03 10:44:45 --> Helper loaded: text_helper
INFO - 2016-03-03 10:44:45 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:44:45 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:44:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:44:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:44:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:44:45 --> Severity: Notice --> Undefined variable: date C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:44:45 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, null given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:44:45 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 114
INFO - 2016-03-03 13:44:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:44:45 --> Final output sent to browser
DEBUG - 2016-03-03 13:44:45 --> Total execution time: 1.1410
INFO - 2016-03-03 10:46:07 --> Config Class Initialized
INFO - 2016-03-03 10:46:07 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:46:07 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:46:07 --> Utf8 Class Initialized
INFO - 2016-03-03 10:46:07 --> URI Class Initialized
DEBUG - 2016-03-03 10:46:07 --> No URI present. Default controller set.
INFO - 2016-03-03 10:46:07 --> Router Class Initialized
INFO - 2016-03-03 10:46:07 --> Output Class Initialized
INFO - 2016-03-03 10:46:07 --> Security Class Initialized
DEBUG - 2016-03-03 10:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:46:07 --> Input Class Initialized
INFO - 2016-03-03 10:46:07 --> Language Class Initialized
INFO - 2016-03-03 10:46:07 --> Loader Class Initialized
INFO - 2016-03-03 10:46:07 --> Helper loaded: url_helper
INFO - 2016-03-03 10:46:07 --> Helper loaded: file_helper
INFO - 2016-03-03 10:46:07 --> Helper loaded: date_helper
INFO - 2016-03-03 10:46:07 --> Helper loaded: form_helper
INFO - 2016-03-03 10:46:07 --> Database Driver Class Initialized
INFO - 2016-03-03 10:46:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:46:08 --> Controller Class Initialized
INFO - 2016-03-03 10:46:08 --> Model Class Initialized
INFO - 2016-03-03 10:46:08 --> Model Class Initialized
INFO - 2016-03-03 10:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:46:08 --> Pagination Class Initialized
INFO - 2016-03-03 10:46:08 --> Helper loaded: text_helper
INFO - 2016-03-03 10:46:08 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 13:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:46:08 --> Final output sent to browser
DEBUG - 2016-03-03 13:46:08 --> Total execution time: 1.1268
INFO - 2016-03-03 10:46:32 --> Config Class Initialized
INFO - 2016-03-03 10:46:32 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:46:32 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:46:32 --> Utf8 Class Initialized
INFO - 2016-03-03 10:46:32 --> URI Class Initialized
INFO - 2016-03-03 10:46:32 --> Router Class Initialized
INFO - 2016-03-03 10:46:32 --> Output Class Initialized
INFO - 2016-03-03 10:46:32 --> Security Class Initialized
DEBUG - 2016-03-03 10:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:46:32 --> Input Class Initialized
INFO - 2016-03-03 10:46:32 --> Language Class Initialized
INFO - 2016-03-03 10:46:32 --> Loader Class Initialized
INFO - 2016-03-03 10:46:32 --> Helper loaded: url_helper
INFO - 2016-03-03 10:46:32 --> Helper loaded: file_helper
INFO - 2016-03-03 10:46:32 --> Helper loaded: date_helper
INFO - 2016-03-03 10:46:32 --> Helper loaded: form_helper
INFO - 2016-03-03 10:46:32 --> Database Driver Class Initialized
INFO - 2016-03-03 10:46:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:46:33 --> Controller Class Initialized
INFO - 2016-03-03 10:46:33 --> Model Class Initialized
INFO - 2016-03-03 10:46:33 --> Model Class Initialized
INFO - 2016-03-03 10:46:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:46:33 --> Pagination Class Initialized
INFO - 2016-03-03 10:46:33 --> Helper loaded: text_helper
INFO - 2016-03-03 10:46:33 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:46:33 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:46:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:46:33 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:46:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:46:33 --> Severity: Notice --> Undefined variable: date C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:46:33 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, null given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:46:33 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 114
INFO - 2016-03-03 13:46:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:46:33 --> Final output sent to browser
DEBUG - 2016-03-03 13:46:33 --> Total execution time: 1.1843
INFO - 2016-03-03 10:47:38 --> Config Class Initialized
INFO - 2016-03-03 10:47:38 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:47:38 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:47:38 --> Utf8 Class Initialized
INFO - 2016-03-03 10:47:38 --> URI Class Initialized
INFO - 2016-03-03 10:47:38 --> Router Class Initialized
INFO - 2016-03-03 10:47:38 --> Output Class Initialized
INFO - 2016-03-03 10:47:38 --> Security Class Initialized
DEBUG - 2016-03-03 10:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:47:38 --> Input Class Initialized
INFO - 2016-03-03 10:47:38 --> Language Class Initialized
INFO - 2016-03-03 10:47:38 --> Loader Class Initialized
INFO - 2016-03-03 10:47:38 --> Helper loaded: url_helper
INFO - 2016-03-03 10:47:38 --> Helper loaded: file_helper
INFO - 2016-03-03 10:47:38 --> Helper loaded: date_helper
INFO - 2016-03-03 10:47:38 --> Helper loaded: form_helper
INFO - 2016-03-03 10:47:38 --> Database Driver Class Initialized
INFO - 2016-03-03 10:47:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:47:39 --> Controller Class Initialized
INFO - 2016-03-03 10:47:39 --> Model Class Initialized
INFO - 2016-03-03 10:47:39 --> Model Class Initialized
INFO - 2016-03-03 10:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:47:39 --> Pagination Class Initialized
INFO - 2016-03-03 10:47:39 --> Helper loaded: text_helper
INFO - 2016-03-03 10:47:39 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:47:39 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:47:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:47:39 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:47:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:47:39 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:47:39 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 114
INFO - 2016-03-03 13:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:47:39 --> Final output sent to browser
DEBUG - 2016-03-03 13:47:39 --> Total execution time: 1.1482
INFO - 2016-03-03 10:48:21 --> Config Class Initialized
INFO - 2016-03-03 10:48:21 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:48:21 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:48:21 --> Utf8 Class Initialized
INFO - 2016-03-03 10:48:21 --> URI Class Initialized
INFO - 2016-03-03 10:48:21 --> Router Class Initialized
INFO - 2016-03-03 10:48:21 --> Output Class Initialized
INFO - 2016-03-03 10:48:21 --> Security Class Initialized
DEBUG - 2016-03-03 10:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:48:21 --> Input Class Initialized
INFO - 2016-03-03 10:48:21 --> Language Class Initialized
INFO - 2016-03-03 10:48:21 --> Loader Class Initialized
INFO - 2016-03-03 10:48:21 --> Helper loaded: url_helper
INFO - 2016-03-03 10:48:21 --> Helper loaded: file_helper
INFO - 2016-03-03 10:48:21 --> Helper loaded: date_helper
INFO - 2016-03-03 10:48:21 --> Helper loaded: form_helper
INFO - 2016-03-03 10:48:21 --> Database Driver Class Initialized
INFO - 2016-03-03 10:48:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:48:22 --> Controller Class Initialized
INFO - 2016-03-03 10:48:22 --> Model Class Initialized
INFO - 2016-03-03 10:48:22 --> Model Class Initialized
INFO - 2016-03-03 10:48:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:48:22 --> Pagination Class Initialized
INFO - 2016-03-03 10:48:22 --> Helper loaded: text_helper
INFO - 2016-03-03 10:48:22 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:48:22 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:48:22 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:48:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:48:22 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:48:22 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 114
INFO - 2016-03-03 13:48:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:48:22 --> Final output sent to browser
DEBUG - 2016-03-03 13:48:22 --> Total execution time: 1.1338
INFO - 2016-03-03 10:50:11 --> Config Class Initialized
INFO - 2016-03-03 10:50:11 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:50:11 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:50:11 --> Utf8 Class Initialized
INFO - 2016-03-03 10:50:11 --> URI Class Initialized
INFO - 2016-03-03 10:50:11 --> Router Class Initialized
INFO - 2016-03-03 10:50:11 --> Output Class Initialized
INFO - 2016-03-03 10:50:11 --> Security Class Initialized
DEBUG - 2016-03-03 10:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:50:11 --> Input Class Initialized
INFO - 2016-03-03 10:50:11 --> Language Class Initialized
INFO - 2016-03-03 10:50:11 --> Loader Class Initialized
INFO - 2016-03-03 10:50:11 --> Helper loaded: url_helper
INFO - 2016-03-03 10:50:11 --> Helper loaded: file_helper
INFO - 2016-03-03 10:50:11 --> Helper loaded: date_helper
INFO - 2016-03-03 10:50:11 --> Helper loaded: form_helper
INFO - 2016-03-03 10:50:11 --> Database Driver Class Initialized
INFO - 2016-03-03 10:50:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:50:12 --> Controller Class Initialized
INFO - 2016-03-03 10:50:12 --> Model Class Initialized
INFO - 2016-03-03 10:50:12 --> Model Class Initialized
INFO - 2016-03-03 10:50:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:50:12 --> Pagination Class Initialized
INFO - 2016-03-03 10:50:12 --> Helper loaded: text_helper
INFO - 2016-03-03 10:50:12 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:50:12 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:50:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:50:12 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:50:12 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 110
ERROR - 2016-03-03 13:50:12 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 115
INFO - 2016-03-03 13:50:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:50:12 --> Final output sent to browser
DEBUG - 2016-03-03 13:50:12 --> Total execution time: 1.1377
INFO - 2016-03-03 10:51:15 --> Config Class Initialized
INFO - 2016-03-03 10:51:15 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:51:15 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:51:15 --> Utf8 Class Initialized
INFO - 2016-03-03 10:51:15 --> URI Class Initialized
INFO - 2016-03-03 10:51:15 --> Router Class Initialized
INFO - 2016-03-03 10:51:15 --> Output Class Initialized
INFO - 2016-03-03 10:51:15 --> Security Class Initialized
DEBUG - 2016-03-03 10:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:51:15 --> Input Class Initialized
INFO - 2016-03-03 10:51:15 --> Language Class Initialized
INFO - 2016-03-03 10:51:15 --> Loader Class Initialized
INFO - 2016-03-03 10:51:15 --> Helper loaded: url_helper
INFO - 2016-03-03 10:51:15 --> Helper loaded: file_helper
INFO - 2016-03-03 10:51:15 --> Helper loaded: date_helper
INFO - 2016-03-03 10:51:15 --> Helper loaded: form_helper
INFO - 2016-03-03 10:51:15 --> Database Driver Class Initialized
INFO - 2016-03-03 10:51:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:51:16 --> Controller Class Initialized
INFO - 2016-03-03 10:51:16 --> Model Class Initialized
INFO - 2016-03-03 10:51:16 --> Model Class Initialized
INFO - 2016-03-03 10:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:51:16 --> Pagination Class Initialized
INFO - 2016-03-03 10:51:16 --> Helper loaded: text_helper
INFO - 2016-03-03 10:51:16 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:51:16 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:51:16 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:51:16 --> Severity: Warning --> date_sub() expects parameter 1 to be DateTime, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
ERROR - 2016-03-03 13:51:16 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 110
ERROR - 2016-03-03 13:51:16 --> Severity: Notice --> A non well formed numeric value encountered C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 115
INFO - 2016-03-03 13:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 13:51:16 --> Final output sent to browser
DEBUG - 2016-03-03 13:51:16 --> Total execution time: 1.1317
INFO - 2016-03-03 10:53:33 --> Config Class Initialized
INFO - 2016-03-03 10:53:33 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:53:33 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:53:33 --> Utf8 Class Initialized
INFO - 2016-03-03 10:53:33 --> URI Class Initialized
INFO - 2016-03-03 10:53:33 --> Router Class Initialized
INFO - 2016-03-03 10:53:33 --> Output Class Initialized
INFO - 2016-03-03 10:53:33 --> Security Class Initialized
DEBUG - 2016-03-03 10:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:53:33 --> Input Class Initialized
INFO - 2016-03-03 10:53:33 --> Language Class Initialized
INFO - 2016-03-03 10:53:33 --> Loader Class Initialized
INFO - 2016-03-03 10:53:33 --> Helper loaded: url_helper
INFO - 2016-03-03 10:53:33 --> Helper loaded: file_helper
INFO - 2016-03-03 10:53:33 --> Helper loaded: date_helper
INFO - 2016-03-03 10:53:33 --> Helper loaded: form_helper
INFO - 2016-03-03 10:53:33 --> Database Driver Class Initialized
INFO - 2016-03-03 10:53:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:53:34 --> Controller Class Initialized
INFO - 2016-03-03 10:53:34 --> Model Class Initialized
INFO - 2016-03-03 10:53:34 --> Model Class Initialized
INFO - 2016-03-03 10:53:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:53:34 --> Pagination Class Initialized
INFO - 2016-03-03 10:53:34 --> Helper loaded: text_helper
INFO - 2016-03-03 10:53:34 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:53:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:53:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:53:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:53:34 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:53:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:53:34 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:53:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:53:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:53:34 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (Y-m-d) at position 1 (-): Unexpected character C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 108
INFO - 2016-03-03 10:53:56 --> Config Class Initialized
INFO - 2016-03-03 10:53:56 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:53:56 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:53:56 --> Utf8 Class Initialized
INFO - 2016-03-03 10:53:56 --> URI Class Initialized
INFO - 2016-03-03 10:53:56 --> Router Class Initialized
INFO - 2016-03-03 10:53:56 --> Output Class Initialized
INFO - 2016-03-03 10:53:56 --> Security Class Initialized
DEBUG - 2016-03-03 10:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:53:56 --> Input Class Initialized
INFO - 2016-03-03 10:53:56 --> Language Class Initialized
INFO - 2016-03-03 10:53:56 --> Loader Class Initialized
INFO - 2016-03-03 10:53:56 --> Helper loaded: url_helper
INFO - 2016-03-03 10:53:56 --> Helper loaded: file_helper
INFO - 2016-03-03 10:53:56 --> Helper loaded: date_helper
INFO - 2016-03-03 10:53:56 --> Helper loaded: form_helper
INFO - 2016-03-03 10:53:56 --> Database Driver Class Initialized
INFO - 2016-03-03 10:53:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:53:57 --> Controller Class Initialized
INFO - 2016-03-03 10:53:57 --> Model Class Initialized
INFO - 2016-03-03 10:53:57 --> Model Class Initialized
INFO - 2016-03-03 10:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:53:57 --> Pagination Class Initialized
INFO - 2016-03-03 10:53:57 --> Helper loaded: text_helper
INFO - 2016-03-03 10:53:57 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:53:57 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:53:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:53:57 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:53:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:53:57 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (y-m-d) at position 1 (-): Unexpected character C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 108
INFO - 2016-03-03 10:54:06 --> Config Class Initialized
INFO - 2016-03-03 10:54:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:54:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:54:06 --> Utf8 Class Initialized
INFO - 2016-03-03 10:54:06 --> URI Class Initialized
INFO - 2016-03-03 10:54:06 --> Router Class Initialized
INFO - 2016-03-03 10:54:06 --> Output Class Initialized
INFO - 2016-03-03 10:54:06 --> Security Class Initialized
DEBUG - 2016-03-03 10:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:54:06 --> Input Class Initialized
INFO - 2016-03-03 10:54:06 --> Language Class Initialized
INFO - 2016-03-03 10:54:06 --> Loader Class Initialized
INFO - 2016-03-03 10:54:06 --> Helper loaded: url_helper
INFO - 2016-03-03 10:54:06 --> Helper loaded: file_helper
INFO - 2016-03-03 10:54:06 --> Helper loaded: date_helper
INFO - 2016-03-03 10:54:06 --> Helper loaded: form_helper
INFO - 2016-03-03 10:54:06 --> Database Driver Class Initialized
INFO - 2016-03-03 10:54:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:54:07 --> Controller Class Initialized
INFO - 2016-03-03 10:54:07 --> Model Class Initialized
INFO - 2016-03-03 10:54:07 --> Model Class Initialized
INFO - 2016-03-03 10:54:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:54:07 --> Pagination Class Initialized
INFO - 2016-03-03 10:54:07 --> Helper loaded: text_helper
INFO - 2016-03-03 10:54:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:54:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:54:07 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:54:07 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:54:08 --> Severity: Error --> Call to undefined function DateTime() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 108
INFO - 2016-03-03 10:57:33 --> Config Class Initialized
INFO - 2016-03-03 10:57:33 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:57:33 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:57:33 --> Utf8 Class Initialized
INFO - 2016-03-03 10:57:33 --> URI Class Initialized
INFO - 2016-03-03 10:57:33 --> Router Class Initialized
INFO - 2016-03-03 10:57:33 --> Output Class Initialized
INFO - 2016-03-03 10:57:33 --> Security Class Initialized
DEBUG - 2016-03-03 10:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:57:33 --> Input Class Initialized
INFO - 2016-03-03 10:57:33 --> Language Class Initialized
INFO - 2016-03-03 10:57:33 --> Loader Class Initialized
INFO - 2016-03-03 10:57:33 --> Helper loaded: url_helper
INFO - 2016-03-03 10:57:33 --> Helper loaded: file_helper
INFO - 2016-03-03 10:57:33 --> Helper loaded: date_helper
INFO - 2016-03-03 10:57:33 --> Helper loaded: form_helper
INFO - 2016-03-03 10:57:33 --> Database Driver Class Initialized
INFO - 2016-03-03 10:57:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 10:57:34 --> Controller Class Initialized
INFO - 2016-03-03 10:57:34 --> Model Class Initialized
INFO - 2016-03-03 10:57:34 --> Model Class Initialized
INFO - 2016-03-03 10:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 10:57:34 --> Pagination Class Initialized
INFO - 2016-03-03 10:57:34 --> Helper loaded: text_helper
INFO - 2016-03-03 10:57:34 --> Helper loaded: cookie_helper
INFO - 2016-03-03 13:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 13:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 13:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 13:57:34 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 13:57:34 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 13:57:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 13:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 13:57:34 --> Severity: Error --> Undefined class constant 'createFromDateString' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 109
INFO - 2016-03-03 10:59:36 --> Config Class Initialized
INFO - 2016-03-03 10:59:36 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:59:36 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:59:36 --> Utf8 Class Initialized
INFO - 2016-03-03 10:59:36 --> URI Class Initialized
INFO - 2016-03-03 10:59:36 --> Router Class Initialized
INFO - 2016-03-03 10:59:36 --> Output Class Initialized
INFO - 2016-03-03 10:59:36 --> Security Class Initialized
DEBUG - 2016-03-03 10:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:59:36 --> Input Class Initialized
INFO - 2016-03-03 10:59:36 --> Language Class Initialized
ERROR - 2016-03-03 10:59:36 --> Severity: Parsing Error --> syntax error, unexpected '1' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 114
INFO - 2016-03-03 10:59:38 --> Config Class Initialized
INFO - 2016-03-03 10:59:38 --> Hooks Class Initialized
DEBUG - 2016-03-03 10:59:38 --> UTF-8 Support Enabled
INFO - 2016-03-03 10:59:38 --> Utf8 Class Initialized
INFO - 2016-03-03 10:59:38 --> URI Class Initialized
INFO - 2016-03-03 10:59:38 --> Router Class Initialized
INFO - 2016-03-03 10:59:38 --> Output Class Initialized
INFO - 2016-03-03 10:59:38 --> Security Class Initialized
DEBUG - 2016-03-03 10:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 10:59:38 --> Input Class Initialized
INFO - 2016-03-03 10:59:38 --> Language Class Initialized
ERROR - 2016-03-03 10:59:38 --> Severity: Parsing Error --> syntax error, unexpected '1' (T_LNUMBER) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 114
INFO - 2016-03-03 11:04:32 --> Config Class Initialized
INFO - 2016-03-03 11:04:32 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:04:32 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:04:32 --> Utf8 Class Initialized
INFO - 2016-03-03 11:04:32 --> URI Class Initialized
INFO - 2016-03-03 11:04:32 --> Router Class Initialized
INFO - 2016-03-03 11:04:32 --> Output Class Initialized
INFO - 2016-03-03 11:04:32 --> Security Class Initialized
DEBUG - 2016-03-03 11:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:04:32 --> Input Class Initialized
INFO - 2016-03-03 11:04:32 --> Language Class Initialized
INFO - 2016-03-03 11:04:32 --> Loader Class Initialized
INFO - 2016-03-03 11:04:32 --> Helper loaded: url_helper
INFO - 2016-03-03 11:04:32 --> Helper loaded: file_helper
INFO - 2016-03-03 11:04:32 --> Helper loaded: date_helper
INFO - 2016-03-03 11:04:32 --> Helper loaded: form_helper
INFO - 2016-03-03 11:04:32 --> Database Driver Class Initialized
INFO - 2016-03-03 11:04:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:04:33 --> Controller Class Initialized
INFO - 2016-03-03 11:04:33 --> Model Class Initialized
INFO - 2016-03-03 11:04:33 --> Model Class Initialized
INFO - 2016-03-03 11:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:04:33 --> Pagination Class Initialized
INFO - 2016-03-03 11:04:33 --> Helper loaded: text_helper
INFO - 2016-03-03 11:04:33 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:04:33 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:04:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:04:33 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:04:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:04:33 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: select * from wall WHERE WEEKOFYEAR(date)=WEEKOFYEAR(NOW())
INFO - 2016-03-03 14:04:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:05:01 --> Config Class Initialized
INFO - 2016-03-03 11:05:01 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:05:01 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:05:01 --> Utf8 Class Initialized
INFO - 2016-03-03 11:05:01 --> URI Class Initialized
INFO - 2016-03-03 11:05:01 --> Router Class Initialized
INFO - 2016-03-03 11:05:01 --> Output Class Initialized
INFO - 2016-03-03 11:05:01 --> Security Class Initialized
DEBUG - 2016-03-03 11:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:05:01 --> Input Class Initialized
INFO - 2016-03-03 11:05:01 --> Language Class Initialized
INFO - 2016-03-03 11:05:01 --> Loader Class Initialized
INFO - 2016-03-03 11:05:01 --> Helper loaded: url_helper
INFO - 2016-03-03 11:05:01 --> Helper loaded: file_helper
INFO - 2016-03-03 11:05:01 --> Helper loaded: date_helper
INFO - 2016-03-03 11:05:01 --> Helper loaded: form_helper
INFO - 2016-03-03 11:05:01 --> Database Driver Class Initialized
INFO - 2016-03-03 11:05:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:05:02 --> Controller Class Initialized
INFO - 2016-03-03 11:05:02 --> Model Class Initialized
INFO - 2016-03-03 11:05:02 --> Model Class Initialized
INFO - 2016-03-03 11:05:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:05:02 --> Pagination Class Initialized
INFO - 2016-03-03 11:05:02 --> Helper loaded: text_helper
INFO - 2016-03-03 11:05:02 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:05:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:05:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:05:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:05:02 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:05:02 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:05:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:05:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:05:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:05:02 --> Final output sent to browser
DEBUG - 2016-03-03 14:05:02 --> Total execution time: 1.2116
INFO - 2016-03-03 11:06:12 --> Config Class Initialized
INFO - 2016-03-03 11:06:12 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:06:12 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:06:12 --> Utf8 Class Initialized
INFO - 2016-03-03 11:06:12 --> URI Class Initialized
INFO - 2016-03-03 11:06:12 --> Router Class Initialized
INFO - 2016-03-03 11:06:12 --> Output Class Initialized
INFO - 2016-03-03 11:06:12 --> Security Class Initialized
DEBUG - 2016-03-03 11:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:06:12 --> Input Class Initialized
INFO - 2016-03-03 11:06:12 --> Language Class Initialized
INFO - 2016-03-03 11:06:12 --> Loader Class Initialized
INFO - 2016-03-03 11:06:12 --> Helper loaded: url_helper
INFO - 2016-03-03 11:06:12 --> Helper loaded: file_helper
INFO - 2016-03-03 11:06:12 --> Helper loaded: date_helper
INFO - 2016-03-03 11:06:12 --> Helper loaded: form_helper
INFO - 2016-03-03 11:06:12 --> Database Driver Class Initialized
INFO - 2016-03-03 11:06:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:06:13 --> Controller Class Initialized
INFO - 2016-03-03 11:06:13 --> Model Class Initialized
INFO - 2016-03-03 11:06:13 --> Model Class Initialized
INFO - 2016-03-03 11:06:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:06:13 --> Pagination Class Initialized
INFO - 2016-03-03 11:06:13 --> Helper loaded: text_helper
INFO - 2016-03-03 11:06:13 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:06:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:06:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:06:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:06:13 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:06:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:06:13 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:06:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:06:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:06:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:06:13 --> Final output sent to browser
DEBUG - 2016-03-03 14:06:13 --> Total execution time: 1.1884
INFO - 2016-03-03 11:10:11 --> Config Class Initialized
INFO - 2016-03-03 11:10:11 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:10:11 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:10:11 --> Utf8 Class Initialized
INFO - 2016-03-03 11:10:11 --> URI Class Initialized
INFO - 2016-03-03 11:10:11 --> Router Class Initialized
INFO - 2016-03-03 11:10:11 --> Output Class Initialized
INFO - 2016-03-03 11:10:11 --> Security Class Initialized
DEBUG - 2016-03-03 11:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:10:11 --> Input Class Initialized
INFO - 2016-03-03 11:10:11 --> Language Class Initialized
INFO - 2016-03-03 11:10:11 --> Loader Class Initialized
INFO - 2016-03-03 11:10:11 --> Helper loaded: url_helper
INFO - 2016-03-03 11:10:11 --> Helper loaded: file_helper
INFO - 2016-03-03 11:10:11 --> Helper loaded: date_helper
INFO - 2016-03-03 11:10:11 --> Helper loaded: form_helper
INFO - 2016-03-03 11:10:11 --> Database Driver Class Initialized
INFO - 2016-03-03 11:10:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:10:12 --> Controller Class Initialized
INFO - 2016-03-03 11:10:12 --> Model Class Initialized
INFO - 2016-03-03 11:10:12 --> Model Class Initialized
INFO - 2016-03-03 11:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:10:12 --> Pagination Class Initialized
INFO - 2016-03-03 11:10:12 --> Helper loaded: text_helper
INFO - 2016-03-03 11:10:12 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:10:12 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:10:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:10:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:10:12 --> Query error: Unknown column 'u.create' in 'where clause' - Invalid query: select * from wall WHERE year(date(FROM_UNIXTIME(u.create))) = year(CURDATE() - INTERVAL 1 MONTH)
and month(date(FROM_UNIXTIME(u.create))) = month(CURDATE() - INTERVAL 1 MONTH)
INFO - 2016-03-03 14:10:12 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:10:46 --> Config Class Initialized
INFO - 2016-03-03 11:10:46 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:10:46 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:10:46 --> Utf8 Class Initialized
INFO - 2016-03-03 11:10:46 --> URI Class Initialized
INFO - 2016-03-03 11:10:46 --> Router Class Initialized
INFO - 2016-03-03 11:10:46 --> Output Class Initialized
INFO - 2016-03-03 11:10:46 --> Security Class Initialized
DEBUG - 2016-03-03 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:10:46 --> Input Class Initialized
INFO - 2016-03-03 11:10:46 --> Language Class Initialized
INFO - 2016-03-03 11:10:46 --> Loader Class Initialized
INFO - 2016-03-03 11:10:46 --> Helper loaded: url_helper
INFO - 2016-03-03 11:10:46 --> Helper loaded: file_helper
INFO - 2016-03-03 11:10:46 --> Helper loaded: date_helper
INFO - 2016-03-03 11:10:46 --> Helper loaded: form_helper
INFO - 2016-03-03 11:10:46 --> Database Driver Class Initialized
INFO - 2016-03-03 11:10:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:10:47 --> Controller Class Initialized
INFO - 2016-03-03 11:10:47 --> Model Class Initialized
INFO - 2016-03-03 11:10:47 --> Model Class Initialized
INFO - 2016-03-03 11:10:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:10:47 --> Pagination Class Initialized
INFO - 2016-03-03 11:10:47 --> Helper loaded: text_helper
INFO - 2016-03-03 11:10:47 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:10:47 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:10:47 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:10:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:10:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:10:47 --> Final output sent to browser
DEBUG - 2016-03-03 14:10:47 --> Total execution time: 1.1681
INFO - 2016-03-03 11:12:33 --> Config Class Initialized
INFO - 2016-03-03 11:12:33 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:12:33 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:12:33 --> Utf8 Class Initialized
INFO - 2016-03-03 11:12:33 --> URI Class Initialized
INFO - 2016-03-03 11:12:33 --> Router Class Initialized
INFO - 2016-03-03 11:12:33 --> Output Class Initialized
INFO - 2016-03-03 11:12:33 --> Security Class Initialized
DEBUG - 2016-03-03 11:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:12:33 --> Input Class Initialized
INFO - 2016-03-03 11:12:33 --> Language Class Initialized
INFO - 2016-03-03 11:12:33 --> Loader Class Initialized
INFO - 2016-03-03 11:12:33 --> Helper loaded: url_helper
INFO - 2016-03-03 11:12:33 --> Helper loaded: file_helper
INFO - 2016-03-03 11:12:33 --> Helper loaded: date_helper
INFO - 2016-03-03 11:12:33 --> Helper loaded: form_helper
INFO - 2016-03-03 11:12:33 --> Database Driver Class Initialized
INFO - 2016-03-03 11:12:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:12:34 --> Controller Class Initialized
INFO - 2016-03-03 11:12:34 --> Model Class Initialized
INFO - 2016-03-03 11:12:34 --> Model Class Initialized
INFO - 2016-03-03 11:12:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:12:34 --> Pagination Class Initialized
INFO - 2016-03-03 11:12:34 --> Helper loaded: text_helper
INFO - 2016-03-03 11:12:34 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:12:34 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:12:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:12:34 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:12:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:12:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:12:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'fromwallWHERE WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1' at line 1 - Invalid query: select * fromwallWHERE WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1
INFO - 2016-03-03 14:12:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:12:56 --> Config Class Initialized
INFO - 2016-03-03 11:12:56 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:12:56 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:12:56 --> Utf8 Class Initialized
INFO - 2016-03-03 11:12:56 --> URI Class Initialized
INFO - 2016-03-03 11:12:56 --> Router Class Initialized
INFO - 2016-03-03 11:12:56 --> Output Class Initialized
INFO - 2016-03-03 11:12:56 --> Security Class Initialized
DEBUG - 2016-03-03 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:12:56 --> Input Class Initialized
INFO - 2016-03-03 11:12:56 --> Language Class Initialized
INFO - 2016-03-03 11:12:56 --> Loader Class Initialized
INFO - 2016-03-03 11:12:56 --> Helper loaded: url_helper
INFO - 2016-03-03 11:12:56 --> Helper loaded: file_helper
INFO - 2016-03-03 11:12:56 --> Helper loaded: date_helper
INFO - 2016-03-03 11:12:56 --> Helper loaded: form_helper
INFO - 2016-03-03 11:12:56 --> Database Driver Class Initialized
INFO - 2016-03-03 11:12:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:12:57 --> Controller Class Initialized
INFO - 2016-03-03 11:12:57 --> Model Class Initialized
INFO - 2016-03-03 11:12:57 --> Model Class Initialized
INFO - 2016-03-03 11:12:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:12:57 --> Pagination Class Initialized
INFO - 2016-03-03 11:12:57 --> Helper loaded: text_helper
INFO - 2016-03-03 11:12:57 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:12:57 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:12:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:12:57 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:12:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:12:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:12:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'fromwallWHERE WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1' at line 1 - Invalid query: select * fromwallWHERE WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1
INFO - 2016-03-03 14:12:57 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:15:33 --> Config Class Initialized
INFO - 2016-03-03 11:15:33 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:15:33 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:15:33 --> Utf8 Class Initialized
INFO - 2016-03-03 11:15:33 --> URI Class Initialized
INFO - 2016-03-03 11:15:33 --> Router Class Initialized
INFO - 2016-03-03 11:15:33 --> Output Class Initialized
INFO - 2016-03-03 11:15:33 --> Security Class Initialized
DEBUG - 2016-03-03 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:15:33 --> Input Class Initialized
INFO - 2016-03-03 11:15:33 --> Language Class Initialized
INFO - 2016-03-03 11:15:33 --> Loader Class Initialized
INFO - 2016-03-03 11:15:33 --> Helper loaded: url_helper
INFO - 2016-03-03 11:15:33 --> Helper loaded: file_helper
INFO - 2016-03-03 11:15:33 --> Helper loaded: date_helper
INFO - 2016-03-03 11:15:33 --> Helper loaded: form_helper
INFO - 2016-03-03 11:15:33 --> Database Driver Class Initialized
INFO - 2016-03-03 11:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:15:34 --> Controller Class Initialized
INFO - 2016-03-03 11:15:34 --> Model Class Initialized
INFO - 2016-03-03 11:15:34 --> Model Class Initialized
INFO - 2016-03-03 11:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:15:34 --> Pagination Class Initialized
INFO - 2016-03-03 11:15:34 --> Helper loaded: text_helper
INFO - 2016-03-03 11:15:34 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:15:34 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:15:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:15:34 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:15:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:15:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''wall' WHERE WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1' at line 1 - Invalid query: select * from 'wall' WHERE WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1
INFO - 2016-03-03 14:15:34 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:16:38 --> Config Class Initialized
INFO - 2016-03-03 11:16:38 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:16:38 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:16:38 --> Utf8 Class Initialized
INFO - 2016-03-03 11:16:38 --> URI Class Initialized
INFO - 2016-03-03 11:16:38 --> Router Class Initialized
INFO - 2016-03-03 11:16:38 --> Output Class Initialized
INFO - 2016-03-03 11:16:38 --> Security Class Initialized
DEBUG - 2016-03-03 11:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:16:38 --> Input Class Initialized
INFO - 2016-03-03 11:16:38 --> Language Class Initialized
INFO - 2016-03-03 11:16:38 --> Loader Class Initialized
INFO - 2016-03-03 11:16:38 --> Helper loaded: url_helper
INFO - 2016-03-03 11:16:38 --> Helper loaded: file_helper
INFO - 2016-03-03 11:16:38 --> Helper loaded: date_helper
INFO - 2016-03-03 11:16:38 --> Helper loaded: form_helper
INFO - 2016-03-03 11:16:38 --> Database Driver Class Initialized
INFO - 2016-03-03 11:16:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:16:39 --> Controller Class Initialized
INFO - 2016-03-03 11:16:39 --> Model Class Initialized
INFO - 2016-03-03 11:16:39 --> Model Class Initialized
INFO - 2016-03-03 11:16:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:16:39 --> Pagination Class Initialized
INFO - 2016-03-03 11:16:39 --> Helper loaded: text_helper
INFO - 2016-03-03 11:16:39 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:16:39 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:16:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:16:39 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:16:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:16:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:16:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''wall' WHERE WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1' at line 1 - Invalid query: select * from 'wall' WHERE WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1
INFO - 2016-03-03 14:16:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:16:57 --> Config Class Initialized
INFO - 2016-03-03 11:16:57 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:16:57 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:16:57 --> Utf8 Class Initialized
INFO - 2016-03-03 11:16:57 --> URI Class Initialized
INFO - 2016-03-03 11:16:57 --> Router Class Initialized
INFO - 2016-03-03 11:16:57 --> Output Class Initialized
INFO - 2016-03-03 11:16:57 --> Security Class Initialized
DEBUG - 2016-03-03 11:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:16:57 --> Input Class Initialized
INFO - 2016-03-03 11:16:57 --> Language Class Initialized
INFO - 2016-03-03 11:16:57 --> Loader Class Initialized
INFO - 2016-03-03 11:16:57 --> Helper loaded: url_helper
INFO - 2016-03-03 11:16:57 --> Helper loaded: file_helper
INFO - 2016-03-03 11:16:57 --> Helper loaded: date_helper
INFO - 2016-03-03 11:16:57 --> Helper loaded: form_helper
INFO - 2016-03-03 11:16:57 --> Database Driver Class Initialized
INFO - 2016-03-03 11:16:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:16:58 --> Controller Class Initialized
INFO - 2016-03-03 11:16:58 --> Model Class Initialized
INFO - 2016-03-03 11:16:58 --> Model Class Initialized
INFO - 2016-03-03 11:16:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:16:58 --> Pagination Class Initialized
INFO - 2016-03-03 11:16:58 --> Helper loaded: text_helper
INFO - 2016-03-03 11:16:58 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:16:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:16:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:16:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:16:58 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:16:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:16:58 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:16:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:16:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:16:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''wall' where WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1' at line 1 - Invalid query: select * from 'wall' where WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1
INFO - 2016-03-03 14:16:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:18:54 --> Config Class Initialized
INFO - 2016-03-03 11:18:54 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:18:54 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:18:54 --> Utf8 Class Initialized
INFO - 2016-03-03 11:18:54 --> URI Class Initialized
INFO - 2016-03-03 11:18:54 --> Router Class Initialized
INFO - 2016-03-03 11:18:54 --> Output Class Initialized
INFO - 2016-03-03 11:18:54 --> Security Class Initialized
DEBUG - 2016-03-03 11:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:18:54 --> Input Class Initialized
INFO - 2016-03-03 11:18:54 --> Language Class Initialized
INFO - 2016-03-03 11:18:54 --> Loader Class Initialized
INFO - 2016-03-03 11:18:54 --> Helper loaded: url_helper
INFO - 2016-03-03 11:18:54 --> Helper loaded: file_helper
INFO - 2016-03-03 11:18:54 --> Helper loaded: date_helper
INFO - 2016-03-03 11:18:54 --> Helper loaded: form_helper
INFO - 2016-03-03 11:18:54 --> Database Driver Class Initialized
INFO - 2016-03-03 11:18:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:18:55 --> Controller Class Initialized
INFO - 2016-03-03 11:18:55 --> Model Class Initialized
INFO - 2016-03-03 11:18:55 --> Model Class Initialized
INFO - 2016-03-03 11:18:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:18:55 --> Pagination Class Initialized
INFO - 2016-03-03 11:18:55 --> Helper loaded: text_helper
INFO - 2016-03-03 11:18:55 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:18:55 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:18:55 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:18:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:18:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:18:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''wall' where WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1' at line 1 - Invalid query: select * from 'wall' where WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1;
INFO - 2016-03-03 14:18:55 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:20:09 --> Config Class Initialized
INFO - 2016-03-03 11:20:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:20:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:20:09 --> Utf8 Class Initialized
INFO - 2016-03-03 11:20:09 --> URI Class Initialized
INFO - 2016-03-03 11:20:09 --> Router Class Initialized
INFO - 2016-03-03 11:20:09 --> Output Class Initialized
INFO - 2016-03-03 11:20:09 --> Security Class Initialized
DEBUG - 2016-03-03 11:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:20:09 --> Input Class Initialized
INFO - 2016-03-03 11:20:09 --> Language Class Initialized
INFO - 2016-03-03 11:20:09 --> Loader Class Initialized
INFO - 2016-03-03 11:20:09 --> Helper loaded: url_helper
INFO - 2016-03-03 11:20:09 --> Helper loaded: file_helper
INFO - 2016-03-03 11:20:09 --> Helper loaded: date_helper
INFO - 2016-03-03 11:20:09 --> Helper loaded: form_helper
INFO - 2016-03-03 11:20:09 --> Database Driver Class Initialized
INFO - 2016-03-03 11:20:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:20:10 --> Controller Class Initialized
INFO - 2016-03-03 11:20:10 --> Model Class Initialized
INFO - 2016-03-03 11:20:10 --> Model Class Initialized
INFO - 2016-03-03 11:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:20:10 --> Pagination Class Initialized
INFO - 2016-03-03 11:20:10 --> Helper loaded: text_helper
INFO - 2016-03-03 11:20:10 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:20:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:20:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:20:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:20:10 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:20:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:20:10 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:20:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:20:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:20:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''wall' where WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1' at line 1 - Invalid query: select * from 'wall' where WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1;
INFO - 2016-03-03 14:20:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:20:23 --> Config Class Initialized
INFO - 2016-03-03 11:20:23 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:20:23 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:20:23 --> Utf8 Class Initialized
INFO - 2016-03-03 11:20:23 --> URI Class Initialized
INFO - 2016-03-03 11:20:23 --> Router Class Initialized
INFO - 2016-03-03 11:20:23 --> Output Class Initialized
INFO - 2016-03-03 11:20:23 --> Security Class Initialized
DEBUG - 2016-03-03 11:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:20:23 --> Input Class Initialized
INFO - 2016-03-03 11:20:23 --> Language Class Initialized
INFO - 2016-03-03 11:20:23 --> Loader Class Initialized
INFO - 2016-03-03 11:20:23 --> Helper loaded: url_helper
INFO - 2016-03-03 11:20:23 --> Helper loaded: file_helper
INFO - 2016-03-03 11:20:23 --> Helper loaded: date_helper
INFO - 2016-03-03 11:20:23 --> Helper loaded: form_helper
INFO - 2016-03-03 11:20:23 --> Database Driver Class Initialized
INFO - 2016-03-03 11:20:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:20:24 --> Controller Class Initialized
INFO - 2016-03-03 11:20:24 --> Model Class Initialized
INFO - 2016-03-03 11:20:24 --> Model Class Initialized
INFO - 2016-03-03 11:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:20:24 --> Pagination Class Initialized
INFO - 2016-03-03 11:20:24 --> Helper loaded: text_helper
INFO - 2016-03-03 11:20:24 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:20:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:20:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:20:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:20:24 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:20:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:20:24 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:20:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:20:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
ERROR - 2016-03-03 14:20:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' .wall. ' where WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1' at line 1 - Invalid query: select * from ' .wall. ' where WEEKOFYEAR(created)=WEEKOFYEAR(NOW())-1;
INFO - 2016-03-03 14:20:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-03 11:21:35 --> Config Class Initialized
INFO - 2016-03-03 11:21:35 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:21:35 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:21:35 --> Utf8 Class Initialized
INFO - 2016-03-03 11:21:35 --> URI Class Initialized
INFO - 2016-03-03 11:21:35 --> Router Class Initialized
INFO - 2016-03-03 11:21:35 --> Output Class Initialized
INFO - 2016-03-03 11:21:35 --> Security Class Initialized
DEBUG - 2016-03-03 11:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:21:35 --> Input Class Initialized
INFO - 2016-03-03 11:21:35 --> Language Class Initialized
INFO - 2016-03-03 11:21:35 --> Loader Class Initialized
INFO - 2016-03-03 11:21:35 --> Helper loaded: url_helper
INFO - 2016-03-03 11:21:35 --> Helper loaded: file_helper
INFO - 2016-03-03 11:21:35 --> Helper loaded: date_helper
INFO - 2016-03-03 11:21:35 --> Helper loaded: form_helper
INFO - 2016-03-03 11:21:36 --> Database Driver Class Initialized
INFO - 2016-03-03 11:21:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:21:37 --> Controller Class Initialized
INFO - 2016-03-03 11:21:37 --> Model Class Initialized
INFO - 2016-03-03 11:21:37 --> Model Class Initialized
INFO - 2016-03-03 11:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:21:37 --> Pagination Class Initialized
INFO - 2016-03-03 11:21:37 --> Helper loaded: text_helper
INFO - 2016-03-03 11:21:37 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:21:37 --> Severity: Notice --> Undefined variable: latest C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:21:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 7
ERROR - 2016-03-03 14:21:37 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:21:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:21:37 --> Final output sent to browser
DEBUG - 2016-03-03 14:21:37 --> Total execution time: 1.1538
INFO - 2016-03-03 11:26:23 --> Config Class Initialized
INFO - 2016-03-03 11:26:23 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:26:23 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:26:23 --> Utf8 Class Initialized
INFO - 2016-03-03 11:26:23 --> URI Class Initialized
INFO - 2016-03-03 11:26:23 --> Router Class Initialized
INFO - 2016-03-03 11:26:24 --> Output Class Initialized
INFO - 2016-03-03 11:26:24 --> Security Class Initialized
DEBUG - 2016-03-03 11:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:26:24 --> Input Class Initialized
INFO - 2016-03-03 11:26:24 --> Language Class Initialized
INFO - 2016-03-03 11:26:24 --> Loader Class Initialized
INFO - 2016-03-03 11:26:24 --> Helper loaded: url_helper
INFO - 2016-03-03 11:26:24 --> Helper loaded: file_helper
INFO - 2016-03-03 11:26:24 --> Helper loaded: date_helper
INFO - 2016-03-03 11:26:24 --> Helper loaded: form_helper
INFO - 2016-03-03 11:26:24 --> Database Driver Class Initialized
INFO - 2016-03-03 11:26:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:26:25 --> Controller Class Initialized
INFO - 2016-03-03 11:26:25 --> Model Class Initialized
INFO - 2016-03-03 11:26:25 --> Model Class Initialized
INFO - 2016-03-03 11:26:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:26:25 --> Pagination Class Initialized
INFO - 2016-03-03 11:26:25 --> Helper loaded: text_helper
INFO - 2016-03-03 11:26:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:26:25 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:26:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:26:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:26:25 --> Final output sent to browser
DEBUG - 2016-03-03 14:26:25 --> Total execution time: 1.2029
INFO - 2016-03-03 11:27:02 --> Config Class Initialized
INFO - 2016-03-03 11:27:02 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:27:02 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:27:02 --> Utf8 Class Initialized
INFO - 2016-03-03 11:27:02 --> URI Class Initialized
INFO - 2016-03-03 11:27:02 --> Router Class Initialized
INFO - 2016-03-03 11:27:02 --> Output Class Initialized
INFO - 2016-03-03 11:27:02 --> Security Class Initialized
DEBUG - 2016-03-03 11:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:27:02 --> Input Class Initialized
INFO - 2016-03-03 11:27:02 --> Language Class Initialized
INFO - 2016-03-03 11:27:02 --> Loader Class Initialized
INFO - 2016-03-03 11:27:02 --> Helper loaded: url_helper
INFO - 2016-03-03 11:27:02 --> Helper loaded: file_helper
INFO - 2016-03-03 11:27:02 --> Helper loaded: date_helper
INFO - 2016-03-03 11:27:02 --> Helper loaded: form_helper
INFO - 2016-03-03 11:27:02 --> Database Driver Class Initialized
INFO - 2016-03-03 11:27:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:27:03 --> Controller Class Initialized
INFO - 2016-03-03 11:27:03 --> Model Class Initialized
INFO - 2016-03-03 11:27:03 --> Model Class Initialized
INFO - 2016-03-03 11:27:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:27:03 --> Pagination Class Initialized
INFO - 2016-03-03 11:27:03 --> Helper loaded: text_helper
INFO - 2016-03-03 11:27:03 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:27:03 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:27:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:27:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:27:03 --> Final output sent to browser
DEBUG - 2016-03-03 14:27:03 --> Total execution time: 1.1447
INFO - 2016-03-03 11:28:28 --> Config Class Initialized
INFO - 2016-03-03 11:28:28 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:28:28 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:28:28 --> Utf8 Class Initialized
INFO - 2016-03-03 11:28:28 --> URI Class Initialized
INFO - 2016-03-03 11:28:28 --> Router Class Initialized
INFO - 2016-03-03 11:28:28 --> Output Class Initialized
INFO - 2016-03-03 11:28:28 --> Security Class Initialized
DEBUG - 2016-03-03 11:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:28:28 --> Input Class Initialized
INFO - 2016-03-03 11:28:28 --> Language Class Initialized
INFO - 2016-03-03 11:28:28 --> Loader Class Initialized
INFO - 2016-03-03 11:28:28 --> Helper loaded: url_helper
INFO - 2016-03-03 11:28:28 --> Helper loaded: file_helper
INFO - 2016-03-03 11:28:28 --> Helper loaded: date_helper
INFO - 2016-03-03 11:28:28 --> Helper loaded: form_helper
INFO - 2016-03-03 11:28:28 --> Database Driver Class Initialized
INFO - 2016-03-03 11:28:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:28:29 --> Controller Class Initialized
INFO - 2016-03-03 11:28:29 --> Model Class Initialized
INFO - 2016-03-03 11:28:29 --> Model Class Initialized
INFO - 2016-03-03 11:28:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:28:29 --> Pagination Class Initialized
INFO - 2016-03-03 11:28:29 --> Helper loaded: text_helper
INFO - 2016-03-03 11:28:29 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:28:29 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
ERROR - 2016-03-03 14:28:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 21
INFO - 2016-03-03 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:28:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:28:29 --> Final output sent to browser
DEBUG - 2016-03-03 14:28:29 --> Total execution time: 1.1086
INFO - 2016-03-03 11:30:18 --> Config Class Initialized
INFO - 2016-03-03 11:30:18 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:30:18 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:30:18 --> Utf8 Class Initialized
INFO - 2016-03-03 11:30:18 --> URI Class Initialized
INFO - 2016-03-03 11:30:18 --> Router Class Initialized
INFO - 2016-03-03 11:30:18 --> Output Class Initialized
INFO - 2016-03-03 11:30:18 --> Security Class Initialized
DEBUG - 2016-03-03 11:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:30:18 --> Input Class Initialized
INFO - 2016-03-03 11:30:18 --> Language Class Initialized
INFO - 2016-03-03 11:30:18 --> Loader Class Initialized
INFO - 2016-03-03 11:30:18 --> Helper loaded: url_helper
INFO - 2016-03-03 11:30:18 --> Helper loaded: file_helper
INFO - 2016-03-03 11:30:18 --> Helper loaded: date_helper
INFO - 2016-03-03 11:30:18 --> Helper loaded: form_helper
INFO - 2016-03-03 11:30:18 --> Database Driver Class Initialized
INFO - 2016-03-03 11:30:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:30:19 --> Controller Class Initialized
INFO - 2016-03-03 11:30:19 --> Model Class Initialized
INFO - 2016-03-03 11:30:19 --> Model Class Initialized
INFO - 2016-03-03 11:30:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:30:19 --> Pagination Class Initialized
INFO - 2016-03-03 11:30:19 --> Helper loaded: text_helper
INFO - 2016-03-03 11:30:19 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:30:19 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 23
ERROR - 2016-03-03 14:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 23
INFO - 2016-03-03 14:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:30:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:30:19 --> Final output sent to browser
DEBUG - 2016-03-03 14:30:19 --> Total execution time: 1.1354
INFO - 2016-03-03 11:31:30 --> Config Class Initialized
INFO - 2016-03-03 11:31:30 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:31:30 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:31:30 --> Utf8 Class Initialized
INFO - 2016-03-03 11:31:30 --> URI Class Initialized
INFO - 2016-03-03 11:31:30 --> Router Class Initialized
INFO - 2016-03-03 11:31:30 --> Output Class Initialized
INFO - 2016-03-03 11:31:30 --> Security Class Initialized
DEBUG - 2016-03-03 11:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:31:30 --> Input Class Initialized
INFO - 2016-03-03 11:31:30 --> Language Class Initialized
INFO - 2016-03-03 11:31:30 --> Loader Class Initialized
INFO - 2016-03-03 11:31:30 --> Helper loaded: url_helper
INFO - 2016-03-03 11:31:30 --> Helper loaded: file_helper
INFO - 2016-03-03 11:31:30 --> Helper loaded: date_helper
INFO - 2016-03-03 11:31:30 --> Helper loaded: form_helper
INFO - 2016-03-03 11:31:30 --> Database Driver Class Initialized
INFO - 2016-03-03 11:31:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:31:31 --> Controller Class Initialized
INFO - 2016-03-03 11:31:31 --> Model Class Initialized
INFO - 2016-03-03 11:31:31 --> Model Class Initialized
INFO - 2016-03-03 11:31:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:31:31 --> Pagination Class Initialized
INFO - 2016-03-03 11:31:31 --> Helper loaded: text_helper
INFO - 2016-03-03 11:31:31 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:31:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:31:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:31:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:31:31 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 23
ERROR - 2016-03-03 14:31:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 23
INFO - 2016-03-03 14:31:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:31:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:31:31 --> Final output sent to browser
DEBUG - 2016-03-03 14:31:31 --> Total execution time: 1.1381
INFO - 2016-03-03 11:31:48 --> Config Class Initialized
INFO - 2016-03-03 11:31:48 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:31:48 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:31:48 --> Utf8 Class Initialized
INFO - 2016-03-03 11:31:48 --> URI Class Initialized
INFO - 2016-03-03 11:31:48 --> Router Class Initialized
INFO - 2016-03-03 11:31:48 --> Output Class Initialized
INFO - 2016-03-03 11:31:48 --> Security Class Initialized
DEBUG - 2016-03-03 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:31:48 --> Input Class Initialized
INFO - 2016-03-03 11:31:48 --> Language Class Initialized
INFO - 2016-03-03 11:31:48 --> Loader Class Initialized
INFO - 2016-03-03 11:31:48 --> Helper loaded: url_helper
INFO - 2016-03-03 11:31:48 --> Helper loaded: file_helper
INFO - 2016-03-03 11:31:48 --> Helper loaded: date_helper
INFO - 2016-03-03 11:31:48 --> Helper loaded: form_helper
INFO - 2016-03-03 11:31:48 --> Database Driver Class Initialized
INFO - 2016-03-03 11:31:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:31:49 --> Controller Class Initialized
INFO - 2016-03-03 11:31:49 --> Model Class Initialized
INFO - 2016-03-03 11:31:49 --> Model Class Initialized
INFO - 2016-03-03 11:31:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:31:49 --> Pagination Class Initialized
INFO - 2016-03-03 11:31:49 --> Helper loaded: text_helper
INFO - 2016-03-03 11:31:49 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:31:49 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:31:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:31:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:31:49 --> Final output sent to browser
DEBUG - 2016-03-03 14:31:49 --> Total execution time: 1.1422
INFO - 2016-03-03 11:32:10 --> Config Class Initialized
INFO - 2016-03-03 11:32:10 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:32:10 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:32:10 --> Utf8 Class Initialized
INFO - 2016-03-03 11:32:10 --> URI Class Initialized
INFO - 2016-03-03 11:32:10 --> Router Class Initialized
INFO - 2016-03-03 11:32:10 --> Output Class Initialized
INFO - 2016-03-03 11:32:10 --> Security Class Initialized
DEBUG - 2016-03-03 11:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:32:11 --> Input Class Initialized
INFO - 2016-03-03 11:32:11 --> Language Class Initialized
INFO - 2016-03-03 11:32:11 --> Loader Class Initialized
INFO - 2016-03-03 11:32:11 --> Helper loaded: url_helper
INFO - 2016-03-03 11:32:11 --> Helper loaded: file_helper
INFO - 2016-03-03 11:32:11 --> Helper loaded: date_helper
INFO - 2016-03-03 11:32:11 --> Helper loaded: form_helper
INFO - 2016-03-03 11:32:11 --> Database Driver Class Initialized
INFO - 2016-03-03 11:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:32:12 --> Controller Class Initialized
INFO - 2016-03-03 11:32:12 --> Model Class Initialized
INFO - 2016-03-03 11:32:12 --> Model Class Initialized
INFO - 2016-03-03 11:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:32:12 --> Pagination Class Initialized
INFO - 2016-03-03 11:32:12 --> Helper loaded: text_helper
INFO - 2016-03-03 11:32:12 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:32:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:32:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:32:12 --> Final output sent to browser
DEBUG - 2016-03-03 14:32:12 --> Total execution time: 1.1166
INFO - 2016-03-03 11:32:25 --> Config Class Initialized
INFO - 2016-03-03 11:32:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:32:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:32:25 --> Utf8 Class Initialized
INFO - 2016-03-03 11:32:25 --> URI Class Initialized
DEBUG - 2016-03-03 11:32:25 --> No URI present. Default controller set.
INFO - 2016-03-03 11:32:25 --> Router Class Initialized
INFO - 2016-03-03 11:32:25 --> Output Class Initialized
INFO - 2016-03-03 11:32:25 --> Security Class Initialized
DEBUG - 2016-03-03 11:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:32:25 --> Input Class Initialized
INFO - 2016-03-03 11:32:25 --> Language Class Initialized
INFO - 2016-03-03 11:32:25 --> Loader Class Initialized
INFO - 2016-03-03 11:32:25 --> Helper loaded: url_helper
INFO - 2016-03-03 11:32:25 --> Helper loaded: file_helper
INFO - 2016-03-03 11:32:25 --> Helper loaded: date_helper
INFO - 2016-03-03 11:32:25 --> Helper loaded: form_helper
INFO - 2016-03-03 11:32:25 --> Database Driver Class Initialized
INFO - 2016-03-03 11:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:32:26 --> Controller Class Initialized
INFO - 2016-03-03 11:32:26 --> Model Class Initialized
INFO - 2016-03-03 11:32:26 --> Model Class Initialized
INFO - 2016-03-03 11:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:32:26 --> Pagination Class Initialized
INFO - 2016-03-03 11:32:26 --> Helper loaded: text_helper
INFO - 2016-03-03 11:32:26 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 14:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:32:26 --> Final output sent to browser
DEBUG - 2016-03-03 14:32:26 --> Total execution time: 1.1450
INFO - 2016-03-03 11:32:31 --> Config Class Initialized
INFO - 2016-03-03 11:32:31 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:32:31 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:32:31 --> Utf8 Class Initialized
INFO - 2016-03-03 11:32:31 --> URI Class Initialized
INFO - 2016-03-03 11:32:31 --> Router Class Initialized
INFO - 2016-03-03 11:32:31 --> Output Class Initialized
INFO - 2016-03-03 11:32:31 --> Security Class Initialized
DEBUG - 2016-03-03 11:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:32:31 --> Input Class Initialized
INFO - 2016-03-03 11:32:31 --> Language Class Initialized
INFO - 2016-03-03 11:32:31 --> Loader Class Initialized
INFO - 2016-03-03 11:32:31 --> Helper loaded: url_helper
INFO - 2016-03-03 11:32:31 --> Helper loaded: file_helper
INFO - 2016-03-03 11:32:31 --> Helper loaded: date_helper
INFO - 2016-03-03 11:32:31 --> Helper loaded: form_helper
INFO - 2016-03-03 11:32:31 --> Database Driver Class Initialized
INFO - 2016-03-03 11:32:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:32:32 --> Controller Class Initialized
INFO - 2016-03-03 11:32:32 --> Model Class Initialized
INFO - 2016-03-03 11:32:32 --> Model Class Initialized
INFO - 2016-03-03 11:32:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:32:32 --> Pagination Class Initialized
INFO - 2016-03-03 11:32:32 --> Helper loaded: text_helper
INFO - 2016-03-03 11:32:32 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:32:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:32:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:32:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:32:32 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:32:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:32:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:32:32 --> Final output sent to browser
DEBUG - 2016-03-03 14:32:32 --> Total execution time: 1.1408
INFO - 2016-03-03 11:33:56 --> Config Class Initialized
INFO - 2016-03-03 11:33:56 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:33:56 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:33:56 --> Utf8 Class Initialized
INFO - 2016-03-03 11:33:56 --> URI Class Initialized
INFO - 2016-03-03 11:33:56 --> Router Class Initialized
INFO - 2016-03-03 11:33:56 --> Output Class Initialized
INFO - 2016-03-03 11:33:56 --> Security Class Initialized
DEBUG - 2016-03-03 11:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:33:56 --> Input Class Initialized
INFO - 2016-03-03 11:33:56 --> Language Class Initialized
INFO - 2016-03-03 11:33:56 --> Loader Class Initialized
INFO - 2016-03-03 11:33:56 --> Helper loaded: url_helper
INFO - 2016-03-03 11:33:56 --> Helper loaded: file_helper
INFO - 2016-03-03 11:33:56 --> Helper loaded: date_helper
INFO - 2016-03-03 11:33:56 --> Helper loaded: form_helper
INFO - 2016-03-03 11:33:56 --> Database Driver Class Initialized
INFO - 2016-03-03 11:33:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:33:57 --> Controller Class Initialized
INFO - 2016-03-03 11:33:57 --> Model Class Initialized
INFO - 2016-03-03 11:33:57 --> Model Class Initialized
INFO - 2016-03-03 11:33:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:33:57 --> Pagination Class Initialized
INFO - 2016-03-03 11:33:57 --> Helper loaded: text_helper
INFO - 2016-03-03 11:33:57 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:33:57 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:33:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:33:57 --> Final output sent to browser
DEBUG - 2016-03-03 14:33:57 --> Total execution time: 1.1437
INFO - 2016-03-03 11:35:47 --> Config Class Initialized
INFO - 2016-03-03 11:35:47 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:35:47 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:35:47 --> Utf8 Class Initialized
INFO - 2016-03-03 11:35:47 --> URI Class Initialized
INFO - 2016-03-03 11:35:47 --> Router Class Initialized
INFO - 2016-03-03 11:35:47 --> Output Class Initialized
INFO - 2016-03-03 11:35:47 --> Security Class Initialized
DEBUG - 2016-03-03 11:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:35:47 --> Input Class Initialized
INFO - 2016-03-03 11:35:47 --> Language Class Initialized
INFO - 2016-03-03 11:35:47 --> Loader Class Initialized
INFO - 2016-03-03 11:35:47 --> Helper loaded: url_helper
INFO - 2016-03-03 11:35:47 --> Helper loaded: file_helper
INFO - 2016-03-03 11:35:47 --> Helper loaded: date_helper
INFO - 2016-03-03 11:35:47 --> Helper loaded: form_helper
INFO - 2016-03-03 11:35:47 --> Database Driver Class Initialized
INFO - 2016-03-03 11:35:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:35:48 --> Controller Class Initialized
INFO - 2016-03-03 11:35:48 --> Model Class Initialized
INFO - 2016-03-03 11:35:48 --> Model Class Initialized
INFO - 2016-03-03 11:35:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:35:48 --> Pagination Class Initialized
INFO - 2016-03-03 11:35:48 --> Helper loaded: text_helper
INFO - 2016-03-03 11:35:48 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:35:48 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:35:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:35:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:35:48 --> Final output sent to browser
DEBUG - 2016-03-03 14:35:48 --> Total execution time: 1.1254
INFO - 2016-03-03 11:37:59 --> Config Class Initialized
INFO - 2016-03-03 11:37:59 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:37:59 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:37:59 --> Utf8 Class Initialized
INFO - 2016-03-03 11:37:59 --> URI Class Initialized
INFO - 2016-03-03 11:37:59 --> Router Class Initialized
INFO - 2016-03-03 11:37:59 --> Output Class Initialized
INFO - 2016-03-03 11:37:59 --> Security Class Initialized
DEBUG - 2016-03-03 11:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:37:59 --> Input Class Initialized
INFO - 2016-03-03 11:37:59 --> Language Class Initialized
INFO - 2016-03-03 11:37:59 --> Loader Class Initialized
INFO - 2016-03-03 11:37:59 --> Helper loaded: url_helper
INFO - 2016-03-03 11:37:59 --> Helper loaded: file_helper
INFO - 2016-03-03 11:37:59 --> Helper loaded: date_helper
INFO - 2016-03-03 11:37:59 --> Helper loaded: form_helper
INFO - 2016-03-03 11:37:59 --> Database Driver Class Initialized
INFO - 2016-03-03 11:38:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:38:00 --> Controller Class Initialized
INFO - 2016-03-03 11:38:00 --> Model Class Initialized
INFO - 2016-03-03 11:38:00 --> Model Class Initialized
INFO - 2016-03-03 11:38:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:38:00 --> Pagination Class Initialized
INFO - 2016-03-03 11:38:00 --> Helper loaded: text_helper
INFO - 2016-03-03 11:38:00 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:38:00 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:38:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:38:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:38:00 --> Final output sent to browser
DEBUG - 2016-03-03 14:38:00 --> Total execution time: 1.1336
INFO - 2016-03-03 11:38:57 --> Config Class Initialized
INFO - 2016-03-03 11:38:57 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:38:57 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:38:57 --> Utf8 Class Initialized
INFO - 2016-03-03 11:38:57 --> URI Class Initialized
INFO - 2016-03-03 11:38:57 --> Router Class Initialized
INFO - 2016-03-03 11:38:57 --> Output Class Initialized
INFO - 2016-03-03 11:38:57 --> Security Class Initialized
DEBUG - 2016-03-03 11:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:38:57 --> Input Class Initialized
INFO - 2016-03-03 11:38:57 --> Language Class Initialized
INFO - 2016-03-03 11:38:57 --> Loader Class Initialized
INFO - 2016-03-03 11:38:57 --> Helper loaded: url_helper
INFO - 2016-03-03 11:38:57 --> Helper loaded: file_helper
INFO - 2016-03-03 11:38:57 --> Helper loaded: date_helper
INFO - 2016-03-03 11:38:57 --> Helper loaded: form_helper
INFO - 2016-03-03 11:38:57 --> Database Driver Class Initialized
INFO - 2016-03-03 11:38:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:38:58 --> Controller Class Initialized
INFO - 2016-03-03 11:38:58 --> Model Class Initialized
INFO - 2016-03-03 11:38:58 --> Model Class Initialized
INFO - 2016-03-03 11:38:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:38:58 --> Pagination Class Initialized
INFO - 2016-03-03 11:38:58 --> Helper loaded: text_helper
INFO - 2016-03-03 11:38:58 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:38:58 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:38:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:38:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:38:58 --> Final output sent to browser
DEBUG - 2016-03-03 14:38:58 --> Total execution time: 1.1516
INFO - 2016-03-03 11:39:08 --> Config Class Initialized
INFO - 2016-03-03 11:39:08 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:39:08 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:39:08 --> Utf8 Class Initialized
INFO - 2016-03-03 11:39:08 --> URI Class Initialized
INFO - 2016-03-03 11:39:08 --> Router Class Initialized
INFO - 2016-03-03 11:39:08 --> Output Class Initialized
INFO - 2016-03-03 11:39:08 --> Security Class Initialized
DEBUG - 2016-03-03 11:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:39:08 --> Input Class Initialized
INFO - 2016-03-03 11:39:08 --> Language Class Initialized
INFO - 2016-03-03 11:39:08 --> Loader Class Initialized
INFO - 2016-03-03 11:39:08 --> Helper loaded: url_helper
INFO - 2016-03-03 11:39:08 --> Helper loaded: file_helper
INFO - 2016-03-03 11:39:08 --> Helper loaded: date_helper
INFO - 2016-03-03 11:39:08 --> Helper loaded: form_helper
INFO - 2016-03-03 11:39:08 --> Database Driver Class Initialized
INFO - 2016-03-03 11:39:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:39:09 --> Controller Class Initialized
INFO - 2016-03-03 11:39:09 --> Model Class Initialized
INFO - 2016-03-03 11:39:09 --> Model Class Initialized
INFO - 2016-03-03 11:39:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:39:09 --> Pagination Class Initialized
INFO - 2016-03-03 11:39:09 --> Helper loaded: text_helper
INFO - 2016-03-03 11:39:09 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:39:09 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:39:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:39:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:39:09 --> Final output sent to browser
DEBUG - 2016-03-03 14:39:09 --> Total execution time: 1.1018
INFO - 2016-03-03 11:40:45 --> Config Class Initialized
INFO - 2016-03-03 11:40:45 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:40:45 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:40:45 --> Utf8 Class Initialized
INFO - 2016-03-03 11:40:45 --> URI Class Initialized
INFO - 2016-03-03 11:40:45 --> Router Class Initialized
INFO - 2016-03-03 11:40:45 --> Output Class Initialized
INFO - 2016-03-03 11:40:45 --> Security Class Initialized
DEBUG - 2016-03-03 11:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:40:45 --> Input Class Initialized
INFO - 2016-03-03 11:40:45 --> Language Class Initialized
INFO - 2016-03-03 11:40:45 --> Loader Class Initialized
INFO - 2016-03-03 11:40:45 --> Helper loaded: url_helper
INFO - 2016-03-03 11:40:45 --> Helper loaded: file_helper
INFO - 2016-03-03 11:40:45 --> Helper loaded: date_helper
INFO - 2016-03-03 11:40:45 --> Helper loaded: form_helper
INFO - 2016-03-03 11:40:45 --> Database Driver Class Initialized
INFO - 2016-03-03 11:40:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:40:46 --> Controller Class Initialized
INFO - 2016-03-03 11:40:46 --> Model Class Initialized
INFO - 2016-03-03 11:40:46 --> Model Class Initialized
INFO - 2016-03-03 11:40:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:40:46 --> Pagination Class Initialized
INFO - 2016-03-03 11:40:46 --> Helper loaded: text_helper
INFO - 2016-03-03 11:40:46 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:40:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:40:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:40:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:40:47 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:40:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:40:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:40:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:40:47 --> Final output sent to browser
DEBUG - 2016-03-03 14:40:47 --> Total execution time: 1.1635
INFO - 2016-03-03 11:41:47 --> Config Class Initialized
INFO - 2016-03-03 11:41:47 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:41:47 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:41:47 --> Utf8 Class Initialized
INFO - 2016-03-03 11:41:47 --> URI Class Initialized
INFO - 2016-03-03 11:41:47 --> Router Class Initialized
INFO - 2016-03-03 11:41:47 --> Output Class Initialized
INFO - 2016-03-03 11:41:47 --> Security Class Initialized
DEBUG - 2016-03-03 11:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:41:47 --> Input Class Initialized
INFO - 2016-03-03 11:41:47 --> Language Class Initialized
INFO - 2016-03-03 11:41:47 --> Loader Class Initialized
INFO - 2016-03-03 11:41:47 --> Helper loaded: url_helper
INFO - 2016-03-03 11:41:47 --> Helper loaded: file_helper
INFO - 2016-03-03 11:41:47 --> Helper loaded: date_helper
INFO - 2016-03-03 11:41:47 --> Helper loaded: form_helper
INFO - 2016-03-03 11:41:47 --> Database Driver Class Initialized
INFO - 2016-03-03 11:41:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:41:48 --> Controller Class Initialized
INFO - 2016-03-03 11:41:48 --> Model Class Initialized
INFO - 2016-03-03 11:41:48 --> Model Class Initialized
INFO - 2016-03-03 11:41:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:41:48 --> Pagination Class Initialized
INFO - 2016-03-03 11:41:48 --> Helper loaded: text_helper
INFO - 2016-03-03 11:41:48 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:41:48 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:41:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:41:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:41:48 --> Final output sent to browser
DEBUG - 2016-03-03 14:41:48 --> Total execution time: 1.1502
INFO - 2016-03-03 11:42:04 --> Config Class Initialized
INFO - 2016-03-03 11:42:04 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:42:04 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:42:04 --> Utf8 Class Initialized
INFO - 2016-03-03 11:42:04 --> URI Class Initialized
INFO - 2016-03-03 11:42:04 --> Router Class Initialized
INFO - 2016-03-03 11:42:04 --> Output Class Initialized
INFO - 2016-03-03 11:42:04 --> Security Class Initialized
DEBUG - 2016-03-03 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:42:04 --> Input Class Initialized
INFO - 2016-03-03 11:42:04 --> Language Class Initialized
INFO - 2016-03-03 11:42:04 --> Loader Class Initialized
INFO - 2016-03-03 11:42:04 --> Helper loaded: url_helper
INFO - 2016-03-03 11:42:04 --> Helper loaded: file_helper
INFO - 2016-03-03 11:42:04 --> Helper loaded: date_helper
INFO - 2016-03-03 11:42:04 --> Helper loaded: form_helper
INFO - 2016-03-03 11:42:04 --> Database Driver Class Initialized
INFO - 2016-03-03 11:42:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:42:05 --> Controller Class Initialized
INFO - 2016-03-03 11:42:05 --> Model Class Initialized
INFO - 2016-03-03 11:42:05 --> Model Class Initialized
INFO - 2016-03-03 11:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:42:05 --> Pagination Class Initialized
INFO - 2016-03-03 11:42:05 --> Helper loaded: text_helper
INFO - 2016-03-03 11:42:05 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:42:05 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:42:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:42:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:42:05 --> Final output sent to browser
DEBUG - 2016-03-03 14:42:05 --> Total execution time: 1.1298
INFO - 2016-03-03 11:59:11 --> Config Class Initialized
INFO - 2016-03-03 11:59:11 --> Hooks Class Initialized
DEBUG - 2016-03-03 11:59:11 --> UTF-8 Support Enabled
INFO - 2016-03-03 11:59:11 --> Utf8 Class Initialized
INFO - 2016-03-03 11:59:11 --> URI Class Initialized
INFO - 2016-03-03 11:59:11 --> Router Class Initialized
INFO - 2016-03-03 11:59:11 --> Output Class Initialized
INFO - 2016-03-03 11:59:11 --> Security Class Initialized
DEBUG - 2016-03-03 11:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 11:59:11 --> Input Class Initialized
INFO - 2016-03-03 11:59:11 --> Language Class Initialized
INFO - 2016-03-03 11:59:11 --> Loader Class Initialized
INFO - 2016-03-03 11:59:11 --> Helper loaded: url_helper
INFO - 2016-03-03 11:59:11 --> Helper loaded: file_helper
INFO - 2016-03-03 11:59:11 --> Helper loaded: date_helper
INFO - 2016-03-03 11:59:11 --> Helper loaded: form_helper
INFO - 2016-03-03 11:59:11 --> Database Driver Class Initialized
INFO - 2016-03-03 11:59:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 11:59:12 --> Controller Class Initialized
INFO - 2016-03-03 11:59:12 --> Model Class Initialized
INFO - 2016-03-03 11:59:12 --> Model Class Initialized
INFO - 2016-03-03 11:59:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 11:59:12 --> Pagination Class Initialized
INFO - 2016-03-03 11:59:12 --> Helper loaded: text_helper
INFO - 2016-03-03 11:59:12 --> Helper loaded: cookie_helper
INFO - 2016-03-03 14:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 14:59:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 14:59:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 14:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 14:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:59:12 --> Final output sent to browser
DEBUG - 2016-03-03 14:59:12 --> Total execution time: 1.1687
INFO - 2016-03-03 12:42:51 --> Config Class Initialized
INFO - 2016-03-03 12:42:51 --> Hooks Class Initialized
DEBUG - 2016-03-03 12:42:51 --> UTF-8 Support Enabled
INFO - 2016-03-03 12:42:51 --> Utf8 Class Initialized
INFO - 2016-03-03 12:42:51 --> URI Class Initialized
INFO - 2016-03-03 12:42:51 --> Router Class Initialized
INFO - 2016-03-03 12:42:51 --> Output Class Initialized
INFO - 2016-03-03 12:42:51 --> Security Class Initialized
DEBUG - 2016-03-03 12:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 12:42:51 --> Input Class Initialized
INFO - 2016-03-03 12:42:51 --> Language Class Initialized
ERROR - 2016-03-03 12:42:51 --> 404 Page Not Found: Errorhtml/index
INFO - 2016-03-03 12:43:20 --> Config Class Initialized
INFO - 2016-03-03 12:43:20 --> Hooks Class Initialized
DEBUG - 2016-03-03 12:43:20 --> UTF-8 Support Enabled
INFO - 2016-03-03 12:43:20 --> Utf8 Class Initialized
INFO - 2016-03-03 12:43:20 --> URI Class Initialized
INFO - 2016-03-03 12:43:20 --> Router Class Initialized
INFO - 2016-03-03 12:43:20 --> Output Class Initialized
INFO - 2016-03-03 12:43:20 --> Security Class Initialized
DEBUG - 2016-03-03 12:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 12:43:20 --> Input Class Initialized
INFO - 2016-03-03 12:43:20 --> Language Class Initialized
INFO - 2016-03-03 12:43:20 --> Loader Class Initialized
INFO - 2016-03-03 12:43:20 --> Helper loaded: url_helper
INFO - 2016-03-03 12:43:20 --> Helper loaded: file_helper
INFO - 2016-03-03 12:43:20 --> Helper loaded: date_helper
INFO - 2016-03-03 12:43:20 --> Helper loaded: form_helper
INFO - 2016-03-03 12:43:20 --> Database Driver Class Initialized
INFO - 2016-03-03 12:43:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 12:43:21 --> Controller Class Initialized
INFO - 2016-03-03 12:43:21 --> Model Class Initialized
INFO - 2016-03-03 12:43:21 --> Model Class Initialized
INFO - 2016-03-03 12:43:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 12:43:21 --> Pagination Class Initialized
INFO - 2016-03-03 12:43:21 --> Helper loaded: text_helper
INFO - 2016-03-03 12:43:21 --> Helper loaded: cookie_helper
INFO - 2016-03-03 15:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 15:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 15:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 15:43:21 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 15:43:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 15:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 15:43:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 15:43:21 --> Final output sent to browser
DEBUG - 2016-03-03 15:43:21 --> Total execution time: 1.1461
INFO - 2016-03-03 12:44:17 --> Config Class Initialized
INFO - 2016-03-03 12:44:17 --> Hooks Class Initialized
DEBUG - 2016-03-03 12:44:17 --> UTF-8 Support Enabled
INFO - 2016-03-03 12:44:17 --> Utf8 Class Initialized
INFO - 2016-03-03 12:44:17 --> URI Class Initialized
DEBUG - 2016-03-03 12:44:17 --> No URI present. Default controller set.
INFO - 2016-03-03 12:44:17 --> Router Class Initialized
INFO - 2016-03-03 12:44:17 --> Output Class Initialized
INFO - 2016-03-03 12:44:17 --> Security Class Initialized
DEBUG - 2016-03-03 12:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 12:44:17 --> Input Class Initialized
INFO - 2016-03-03 12:44:17 --> Language Class Initialized
INFO - 2016-03-03 12:44:17 --> Loader Class Initialized
INFO - 2016-03-03 12:44:17 --> Helper loaded: url_helper
INFO - 2016-03-03 12:44:17 --> Helper loaded: file_helper
INFO - 2016-03-03 12:44:17 --> Helper loaded: date_helper
INFO - 2016-03-03 12:44:17 --> Helper loaded: form_helper
INFO - 2016-03-03 12:44:17 --> Database Driver Class Initialized
INFO - 2016-03-03 12:44:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 12:44:18 --> Controller Class Initialized
INFO - 2016-03-03 12:44:18 --> Model Class Initialized
INFO - 2016-03-03 12:44:18 --> Model Class Initialized
INFO - 2016-03-03 12:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 12:44:18 --> Pagination Class Initialized
INFO - 2016-03-03 12:44:18 --> Helper loaded: text_helper
INFO - 2016-03-03 12:44:18 --> Helper loaded: cookie_helper
INFO - 2016-03-03 15:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 15:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 15:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 15:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 15:44:18 --> Final output sent to browser
DEBUG - 2016-03-03 15:44:18 --> Total execution time: 1.2132
INFO - 2016-03-03 13:00:12 --> Config Class Initialized
INFO - 2016-03-03 13:00:12 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:00:12 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:00:12 --> Utf8 Class Initialized
INFO - 2016-03-03 13:00:12 --> URI Class Initialized
DEBUG - 2016-03-03 13:00:12 --> No URI present. Default controller set.
INFO - 2016-03-03 13:00:12 --> Router Class Initialized
INFO - 2016-03-03 13:00:12 --> Output Class Initialized
INFO - 2016-03-03 13:00:12 --> Security Class Initialized
DEBUG - 2016-03-03 13:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:00:12 --> Input Class Initialized
INFO - 2016-03-03 13:00:12 --> Language Class Initialized
INFO - 2016-03-03 13:00:12 --> Loader Class Initialized
INFO - 2016-03-03 13:00:12 --> Helper loaded: url_helper
INFO - 2016-03-03 13:00:12 --> Helper loaded: file_helper
INFO - 2016-03-03 13:00:12 --> Helper loaded: date_helper
INFO - 2016-03-03 13:00:12 --> Helper loaded: form_helper
INFO - 2016-03-03 13:00:12 --> Database Driver Class Initialized
INFO - 2016-03-03 13:00:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:00:13 --> Controller Class Initialized
INFO - 2016-03-03 13:00:13 --> Model Class Initialized
INFO - 2016-03-03 13:00:13 --> Model Class Initialized
INFO - 2016-03-03 13:00:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:00:13 --> Pagination Class Initialized
INFO - 2016-03-03 13:00:13 --> Helper loaded: text_helper
INFO - 2016-03-03 13:00:13 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:00:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:00:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:00:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:00:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:00:13 --> Final output sent to browser
DEBUG - 2016-03-03 16:00:13 --> Total execution time: 1.1109
INFO - 2016-03-03 13:00:14 --> Config Class Initialized
INFO - 2016-03-03 13:00:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:00:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:00:14 --> Utf8 Class Initialized
INFO - 2016-03-03 13:00:14 --> URI Class Initialized
INFO - 2016-03-03 13:00:14 --> Router Class Initialized
INFO - 2016-03-03 13:00:14 --> Output Class Initialized
INFO - 2016-03-03 13:00:14 --> Security Class Initialized
DEBUG - 2016-03-03 13:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:00:14 --> Input Class Initialized
INFO - 2016-03-03 13:00:14 --> Language Class Initialized
ERROR - 2016-03-03 13:00:14 --> 404 Page Not Found: Assets/img
INFO - 2016-03-03 13:00:38 --> Config Class Initialized
INFO - 2016-03-03 13:00:38 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:00:38 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:00:38 --> Utf8 Class Initialized
INFO - 2016-03-03 13:00:38 --> URI Class Initialized
DEBUG - 2016-03-03 13:00:38 --> No URI present. Default controller set.
INFO - 2016-03-03 13:00:38 --> Router Class Initialized
INFO - 2016-03-03 13:00:38 --> Output Class Initialized
INFO - 2016-03-03 13:00:38 --> Security Class Initialized
DEBUG - 2016-03-03 13:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:00:38 --> Input Class Initialized
INFO - 2016-03-03 13:00:38 --> Language Class Initialized
INFO - 2016-03-03 13:00:38 --> Loader Class Initialized
INFO - 2016-03-03 13:00:38 --> Helper loaded: url_helper
INFO - 2016-03-03 13:00:38 --> Helper loaded: file_helper
INFO - 2016-03-03 13:00:38 --> Helper loaded: date_helper
INFO - 2016-03-03 13:00:38 --> Helper loaded: form_helper
INFO - 2016-03-03 13:00:38 --> Database Driver Class Initialized
INFO - 2016-03-03 13:00:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:00:39 --> Controller Class Initialized
INFO - 2016-03-03 13:00:39 --> Model Class Initialized
INFO - 2016-03-03 13:00:39 --> Model Class Initialized
INFO - 2016-03-03 13:00:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:00:39 --> Pagination Class Initialized
INFO - 2016-03-03 13:00:39 --> Helper loaded: text_helper
INFO - 2016-03-03 13:00:39 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:00:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:00:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:00:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:00:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:00:39 --> Final output sent to browser
DEBUG - 2016-03-03 16:00:39 --> Total execution time: 1.1472
INFO - 2016-03-03 13:03:29 --> Config Class Initialized
INFO - 2016-03-03 13:03:29 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:03:29 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:03:29 --> Utf8 Class Initialized
INFO - 2016-03-03 13:03:29 --> URI Class Initialized
DEBUG - 2016-03-03 13:03:29 --> No URI present. Default controller set.
INFO - 2016-03-03 13:03:29 --> Router Class Initialized
INFO - 2016-03-03 13:03:29 --> Output Class Initialized
INFO - 2016-03-03 13:03:29 --> Security Class Initialized
DEBUG - 2016-03-03 13:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:03:29 --> Input Class Initialized
INFO - 2016-03-03 13:03:29 --> Language Class Initialized
INFO - 2016-03-03 13:03:29 --> Loader Class Initialized
INFO - 2016-03-03 13:03:29 --> Helper loaded: url_helper
INFO - 2016-03-03 13:03:29 --> Helper loaded: file_helper
INFO - 2016-03-03 13:03:29 --> Helper loaded: date_helper
INFO - 2016-03-03 13:03:29 --> Helper loaded: form_helper
INFO - 2016-03-03 13:03:29 --> Database Driver Class Initialized
INFO - 2016-03-03 13:03:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:03:30 --> Controller Class Initialized
INFO - 2016-03-03 13:03:30 --> Model Class Initialized
INFO - 2016-03-03 13:03:30 --> Model Class Initialized
INFO - 2016-03-03 13:03:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:03:30 --> Pagination Class Initialized
INFO - 2016-03-03 13:03:30 --> Helper loaded: text_helper
INFO - 2016-03-03 13:03:30 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:03:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:03:30 --> Final output sent to browser
DEBUG - 2016-03-03 16:03:30 --> Total execution time: 1.1179
INFO - 2016-03-03 13:05:41 --> Config Class Initialized
INFO - 2016-03-03 13:05:41 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:05:41 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:05:41 --> Utf8 Class Initialized
INFO - 2016-03-03 13:05:41 --> URI Class Initialized
INFO - 2016-03-03 13:05:41 --> Router Class Initialized
INFO - 2016-03-03 13:05:41 --> Output Class Initialized
INFO - 2016-03-03 13:05:41 --> Security Class Initialized
DEBUG - 2016-03-03 13:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:05:41 --> Input Class Initialized
INFO - 2016-03-03 13:05:41 --> Language Class Initialized
ERROR - 2016-03-03 13:05:41 --> 404 Page Not Found: Images/field.2.jpg
INFO - 2016-03-03 13:08:09 --> Config Class Initialized
INFO - 2016-03-03 13:08:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:08:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:08:09 --> Utf8 Class Initialized
INFO - 2016-03-03 13:08:09 --> URI Class Initialized
DEBUG - 2016-03-03 13:08:09 --> No URI present. Default controller set.
INFO - 2016-03-03 13:08:09 --> Router Class Initialized
INFO - 2016-03-03 13:08:09 --> Output Class Initialized
INFO - 2016-03-03 13:08:09 --> Security Class Initialized
DEBUG - 2016-03-03 13:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:08:09 --> Input Class Initialized
INFO - 2016-03-03 13:08:09 --> Language Class Initialized
INFO - 2016-03-03 13:08:09 --> Loader Class Initialized
INFO - 2016-03-03 13:08:09 --> Helper loaded: url_helper
INFO - 2016-03-03 13:08:09 --> Helper loaded: file_helper
INFO - 2016-03-03 13:08:09 --> Helper loaded: date_helper
INFO - 2016-03-03 13:08:09 --> Helper loaded: form_helper
INFO - 2016-03-03 13:08:09 --> Database Driver Class Initialized
INFO - 2016-03-03 13:08:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:08:10 --> Controller Class Initialized
INFO - 2016-03-03 13:08:10 --> Model Class Initialized
INFO - 2016-03-03 13:08:10 --> Model Class Initialized
INFO - 2016-03-03 13:08:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:08:10 --> Pagination Class Initialized
INFO - 2016-03-03 13:08:10 --> Helper loaded: text_helper
INFO - 2016-03-03 13:08:10 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:08:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:08:10 --> Final output sent to browser
DEBUG - 2016-03-03 16:08:10 --> Total execution time: 1.1409
INFO - 2016-03-03 13:09:43 --> Config Class Initialized
INFO - 2016-03-03 13:09:43 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:09:43 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:09:43 --> Utf8 Class Initialized
INFO - 2016-03-03 13:09:43 --> URI Class Initialized
DEBUG - 2016-03-03 13:09:43 --> No URI present. Default controller set.
INFO - 2016-03-03 13:09:43 --> Router Class Initialized
INFO - 2016-03-03 13:09:43 --> Output Class Initialized
INFO - 2016-03-03 13:09:43 --> Security Class Initialized
DEBUG - 2016-03-03 13:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:09:43 --> Input Class Initialized
INFO - 2016-03-03 13:09:43 --> Language Class Initialized
INFO - 2016-03-03 13:09:43 --> Loader Class Initialized
INFO - 2016-03-03 13:09:43 --> Helper loaded: url_helper
INFO - 2016-03-03 13:09:43 --> Helper loaded: file_helper
INFO - 2016-03-03 13:09:43 --> Helper loaded: date_helper
INFO - 2016-03-03 13:09:43 --> Helper loaded: form_helper
INFO - 2016-03-03 13:09:43 --> Database Driver Class Initialized
INFO - 2016-03-03 13:09:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:09:44 --> Controller Class Initialized
INFO - 2016-03-03 13:09:44 --> Model Class Initialized
INFO - 2016-03-03 13:09:44 --> Model Class Initialized
INFO - 2016-03-03 13:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:09:44 --> Pagination Class Initialized
INFO - 2016-03-03 13:09:44 --> Helper loaded: text_helper
INFO - 2016-03-03 13:09:44 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:09:44 --> Final output sent to browser
DEBUG - 2016-03-03 16:09:44 --> Total execution time: 1.1879
INFO - 2016-03-03 13:10:06 --> Config Class Initialized
INFO - 2016-03-03 13:10:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:10:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:10:06 --> Utf8 Class Initialized
INFO - 2016-03-03 13:10:06 --> URI Class Initialized
DEBUG - 2016-03-03 13:10:06 --> No URI present. Default controller set.
INFO - 2016-03-03 13:10:06 --> Router Class Initialized
INFO - 2016-03-03 13:10:06 --> Output Class Initialized
INFO - 2016-03-03 13:10:06 --> Security Class Initialized
DEBUG - 2016-03-03 13:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:10:06 --> Input Class Initialized
INFO - 2016-03-03 13:10:06 --> Language Class Initialized
INFO - 2016-03-03 13:10:06 --> Loader Class Initialized
INFO - 2016-03-03 13:10:06 --> Helper loaded: url_helper
INFO - 2016-03-03 13:10:06 --> Helper loaded: file_helper
INFO - 2016-03-03 13:10:06 --> Helper loaded: date_helper
INFO - 2016-03-03 13:10:06 --> Helper loaded: form_helper
INFO - 2016-03-03 13:10:06 --> Database Driver Class Initialized
INFO - 2016-03-03 13:10:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:10:07 --> Controller Class Initialized
INFO - 2016-03-03 13:10:07 --> Model Class Initialized
INFO - 2016-03-03 13:10:07 --> Model Class Initialized
INFO - 2016-03-03 13:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:10:07 --> Pagination Class Initialized
INFO - 2016-03-03 13:10:07 --> Helper loaded: text_helper
INFO - 2016-03-03 13:10:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:10:07 --> Final output sent to browser
DEBUG - 2016-03-03 16:10:07 --> Total execution time: 1.1260
INFO - 2016-03-03 13:13:40 --> Config Class Initialized
INFO - 2016-03-03 13:13:40 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:13:40 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:13:40 --> Utf8 Class Initialized
INFO - 2016-03-03 13:13:40 --> URI Class Initialized
DEBUG - 2016-03-03 13:13:40 --> No URI present. Default controller set.
INFO - 2016-03-03 13:13:40 --> Router Class Initialized
INFO - 2016-03-03 13:13:40 --> Output Class Initialized
INFO - 2016-03-03 13:13:40 --> Security Class Initialized
DEBUG - 2016-03-03 13:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:13:40 --> Input Class Initialized
INFO - 2016-03-03 13:13:40 --> Language Class Initialized
INFO - 2016-03-03 13:13:40 --> Loader Class Initialized
INFO - 2016-03-03 13:13:40 --> Helper loaded: url_helper
INFO - 2016-03-03 13:13:40 --> Helper loaded: file_helper
INFO - 2016-03-03 13:13:40 --> Helper loaded: date_helper
INFO - 2016-03-03 13:13:40 --> Helper loaded: form_helper
INFO - 2016-03-03 13:13:40 --> Database Driver Class Initialized
INFO - 2016-03-03 13:13:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:13:42 --> Controller Class Initialized
INFO - 2016-03-03 13:13:42 --> Model Class Initialized
INFO - 2016-03-03 13:13:42 --> Model Class Initialized
INFO - 2016-03-03 13:13:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:13:42 --> Pagination Class Initialized
INFO - 2016-03-03 13:13:42 --> Helper loaded: text_helper
INFO - 2016-03-03 13:13:42 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:13:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:13:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:13:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:13:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:13:42 --> Final output sent to browser
DEBUG - 2016-03-03 16:13:42 --> Total execution time: 1.1350
INFO - 2016-03-03 13:14:06 --> Config Class Initialized
INFO - 2016-03-03 13:14:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:14:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:14:06 --> Utf8 Class Initialized
INFO - 2016-03-03 13:14:06 --> URI Class Initialized
DEBUG - 2016-03-03 13:14:06 --> No URI present. Default controller set.
INFO - 2016-03-03 13:14:06 --> Router Class Initialized
INFO - 2016-03-03 13:14:06 --> Output Class Initialized
INFO - 2016-03-03 13:14:06 --> Security Class Initialized
DEBUG - 2016-03-03 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:14:06 --> Input Class Initialized
INFO - 2016-03-03 13:14:06 --> Language Class Initialized
INFO - 2016-03-03 13:14:06 --> Loader Class Initialized
INFO - 2016-03-03 13:14:06 --> Helper loaded: url_helper
INFO - 2016-03-03 13:14:06 --> Helper loaded: file_helper
INFO - 2016-03-03 13:14:06 --> Helper loaded: date_helper
INFO - 2016-03-03 13:14:06 --> Helper loaded: form_helper
INFO - 2016-03-03 13:14:06 --> Database Driver Class Initialized
INFO - 2016-03-03 13:14:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:14:07 --> Controller Class Initialized
INFO - 2016-03-03 13:14:07 --> Model Class Initialized
INFO - 2016-03-03 13:14:07 --> Model Class Initialized
INFO - 2016-03-03 13:14:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:14:07 --> Pagination Class Initialized
INFO - 2016-03-03 13:14:07 --> Helper loaded: text_helper
INFO - 2016-03-03 13:14:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:14:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:14:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:14:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:14:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:14:07 --> Final output sent to browser
DEBUG - 2016-03-03 16:14:07 --> Total execution time: 1.1108
INFO - 2016-03-03 13:16:18 --> Config Class Initialized
INFO - 2016-03-03 13:16:18 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:16:18 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:16:18 --> Utf8 Class Initialized
INFO - 2016-03-03 13:16:18 --> URI Class Initialized
INFO - 2016-03-03 13:16:18 --> Router Class Initialized
INFO - 2016-03-03 13:16:18 --> Output Class Initialized
INFO - 2016-03-03 13:16:18 --> Security Class Initialized
DEBUG - 2016-03-03 13:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:16:18 --> Input Class Initialized
INFO - 2016-03-03 13:16:18 --> Language Class Initialized
INFO - 2016-03-03 13:16:18 --> Loader Class Initialized
INFO - 2016-03-03 13:16:18 --> Helper loaded: url_helper
INFO - 2016-03-03 13:16:18 --> Helper loaded: file_helper
INFO - 2016-03-03 13:16:18 --> Helper loaded: date_helper
INFO - 2016-03-03 13:16:18 --> Helper loaded: form_helper
INFO - 2016-03-03 13:16:18 --> Database Driver Class Initialized
INFO - 2016-03-03 13:16:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:16:19 --> Controller Class Initialized
INFO - 2016-03-03 13:16:19 --> Model Class Initialized
INFO - 2016-03-03 13:16:19 --> Model Class Initialized
INFO - 2016-03-03 13:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:16:19 --> Pagination Class Initialized
INFO - 2016-03-03 13:16:19 --> Helper loaded: text_helper
INFO - 2016-03-03 13:16:19 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:16:19 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:16:19 --> Final output sent to browser
DEBUG - 2016-03-03 16:16:19 --> Total execution time: 1.1717
INFO - 2016-03-03 13:16:34 --> Config Class Initialized
INFO - 2016-03-03 13:16:34 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:16:34 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:16:34 --> Utf8 Class Initialized
INFO - 2016-03-03 13:16:34 --> URI Class Initialized
INFO - 2016-03-03 13:16:34 --> Router Class Initialized
INFO - 2016-03-03 13:16:34 --> Output Class Initialized
INFO - 2016-03-03 13:16:34 --> Security Class Initialized
DEBUG - 2016-03-03 13:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:16:34 --> Input Class Initialized
INFO - 2016-03-03 13:16:34 --> Language Class Initialized
INFO - 2016-03-03 13:16:34 --> Loader Class Initialized
INFO - 2016-03-03 13:16:34 --> Helper loaded: url_helper
INFO - 2016-03-03 13:16:34 --> Helper loaded: file_helper
INFO - 2016-03-03 13:16:34 --> Helper loaded: date_helper
INFO - 2016-03-03 13:16:34 --> Helper loaded: form_helper
INFO - 2016-03-03 13:16:34 --> Database Driver Class Initialized
INFO - 2016-03-03 13:16:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:16:35 --> Controller Class Initialized
INFO - 2016-03-03 13:16:35 --> Model Class Initialized
INFO - 2016-03-03 13:16:35 --> Model Class Initialized
INFO - 2016-03-03 13:16:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:16:35 --> Pagination Class Initialized
INFO - 2016-03-03 13:16:35 --> Helper loaded: text_helper
INFO - 2016-03-03 13:16:35 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:16:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:16:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:16:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 16:16:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 16:16:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:16:35 --> Final output sent to browser
DEBUG - 2016-03-03 16:16:35 --> Total execution time: 1.1600
INFO - 2016-03-03 13:16:44 --> Config Class Initialized
INFO - 2016-03-03 13:16:44 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:16:44 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:16:44 --> Utf8 Class Initialized
INFO - 2016-03-03 13:16:44 --> URI Class Initialized
INFO - 2016-03-03 13:16:44 --> Router Class Initialized
INFO - 2016-03-03 13:16:44 --> Output Class Initialized
INFO - 2016-03-03 13:16:44 --> Security Class Initialized
DEBUG - 2016-03-03 13:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:16:44 --> Input Class Initialized
INFO - 2016-03-03 13:16:44 --> Language Class Initialized
INFO - 2016-03-03 13:16:44 --> Loader Class Initialized
INFO - 2016-03-03 13:16:44 --> Helper loaded: url_helper
INFO - 2016-03-03 13:16:44 --> Helper loaded: file_helper
INFO - 2016-03-03 13:16:44 --> Helper loaded: date_helper
INFO - 2016-03-03 13:16:44 --> Helper loaded: form_helper
INFO - 2016-03-03 13:16:44 --> Database Driver Class Initialized
INFO - 2016-03-03 13:16:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:16:45 --> Controller Class Initialized
INFO - 2016-03-03 13:16:45 --> Model Class Initialized
INFO - 2016-03-03 13:16:45 --> Model Class Initialized
INFO - 2016-03-03 13:16:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:16:45 --> Pagination Class Initialized
INFO - 2016-03-03 13:16:45 --> Helper loaded: text_helper
INFO - 2016-03-03 13:16:45 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:16:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:16:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:16:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:16:45 --> Final output sent to browser
DEBUG - 2016-03-03 16:16:45 --> Total execution time: 1.1373
INFO - 2016-03-03 13:20:22 --> Config Class Initialized
INFO - 2016-03-03 13:20:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:20:22 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:20:22 --> Utf8 Class Initialized
INFO - 2016-03-03 13:20:22 --> URI Class Initialized
INFO - 2016-03-03 13:20:22 --> Router Class Initialized
INFO - 2016-03-03 13:20:22 --> Output Class Initialized
INFO - 2016-03-03 13:20:22 --> Security Class Initialized
DEBUG - 2016-03-03 13:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:20:22 --> Input Class Initialized
INFO - 2016-03-03 13:20:22 --> Language Class Initialized
INFO - 2016-03-03 13:20:22 --> Loader Class Initialized
INFO - 2016-03-03 13:20:22 --> Helper loaded: url_helper
INFO - 2016-03-03 13:20:22 --> Helper loaded: file_helper
INFO - 2016-03-03 13:20:22 --> Helper loaded: date_helper
INFO - 2016-03-03 13:20:22 --> Helper loaded: form_helper
INFO - 2016-03-03 13:20:22 --> Database Driver Class Initialized
INFO - 2016-03-03 13:20:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:20:23 --> Controller Class Initialized
INFO - 2016-03-03 13:20:23 --> Model Class Initialized
INFO - 2016-03-03 13:20:23 --> Model Class Initialized
INFO - 2016-03-03 13:20:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:20:23 --> Pagination Class Initialized
INFO - 2016-03-03 13:20:23 --> Helper loaded: text_helper
INFO - 2016-03-03 13:20:23 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:20:23 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:20:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:20:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:20:23 --> Final output sent to browser
DEBUG - 2016-03-03 16:20:23 --> Total execution time: 1.1093
INFO - 2016-03-03 13:20:47 --> Config Class Initialized
INFO - 2016-03-03 13:20:47 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:20:47 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:20:47 --> Utf8 Class Initialized
INFO - 2016-03-03 13:20:47 --> URI Class Initialized
INFO - 2016-03-03 13:20:47 --> Router Class Initialized
INFO - 2016-03-03 13:20:47 --> Output Class Initialized
INFO - 2016-03-03 13:20:47 --> Security Class Initialized
DEBUG - 2016-03-03 13:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:20:47 --> Input Class Initialized
INFO - 2016-03-03 13:20:47 --> Language Class Initialized
INFO - 2016-03-03 13:20:47 --> Loader Class Initialized
INFO - 2016-03-03 13:20:47 --> Helper loaded: url_helper
INFO - 2016-03-03 13:20:47 --> Helper loaded: file_helper
INFO - 2016-03-03 13:20:47 --> Helper loaded: date_helper
INFO - 2016-03-03 13:20:47 --> Helper loaded: form_helper
INFO - 2016-03-03 13:20:47 --> Database Driver Class Initialized
INFO - 2016-03-03 13:20:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:20:48 --> Controller Class Initialized
INFO - 2016-03-03 13:20:48 --> Model Class Initialized
INFO - 2016-03-03 13:20:48 --> Model Class Initialized
INFO - 2016-03-03 13:20:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:20:48 --> Pagination Class Initialized
INFO - 2016-03-03 13:20:48 --> Helper loaded: text_helper
INFO - 2016-03-03 13:20:48 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:20:48 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:20:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:20:48 --> Final output sent to browser
DEBUG - 2016-03-03 16:20:48 --> Total execution time: 1.1276
INFO - 2016-03-03 13:21:00 --> Config Class Initialized
INFO - 2016-03-03 13:21:00 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:21:00 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:21:00 --> Utf8 Class Initialized
INFO - 2016-03-03 13:21:00 --> URI Class Initialized
INFO - 2016-03-03 13:21:00 --> Router Class Initialized
INFO - 2016-03-03 13:21:00 --> Output Class Initialized
INFO - 2016-03-03 13:21:00 --> Security Class Initialized
DEBUG - 2016-03-03 13:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:21:00 --> Input Class Initialized
INFO - 2016-03-03 13:21:00 --> Language Class Initialized
INFO - 2016-03-03 13:21:00 --> Loader Class Initialized
INFO - 2016-03-03 13:21:00 --> Helper loaded: url_helper
INFO - 2016-03-03 13:21:00 --> Helper loaded: file_helper
INFO - 2016-03-03 13:21:00 --> Helper loaded: date_helper
INFO - 2016-03-03 13:21:00 --> Helper loaded: form_helper
INFO - 2016-03-03 13:21:00 --> Database Driver Class Initialized
INFO - 2016-03-03 13:21:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:21:01 --> Controller Class Initialized
INFO - 2016-03-03 13:21:01 --> Model Class Initialized
INFO - 2016-03-03 13:21:01 --> Model Class Initialized
INFO - 2016-03-03 13:21:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:21:01 --> Pagination Class Initialized
INFO - 2016-03-03 13:21:01 --> Helper loaded: text_helper
INFO - 2016-03-03 13:21:01 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:21:01 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:21:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:21:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:21:01 --> Final output sent to browser
DEBUG - 2016-03-03 16:21:01 --> Total execution time: 1.1487
INFO - 2016-03-03 13:22:34 --> Config Class Initialized
INFO - 2016-03-03 13:22:34 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:22:34 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:22:34 --> Utf8 Class Initialized
INFO - 2016-03-03 13:22:34 --> URI Class Initialized
INFO - 2016-03-03 13:22:34 --> Router Class Initialized
INFO - 2016-03-03 13:22:34 --> Output Class Initialized
INFO - 2016-03-03 13:22:34 --> Security Class Initialized
DEBUG - 2016-03-03 13:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:22:34 --> Input Class Initialized
INFO - 2016-03-03 13:22:34 --> Language Class Initialized
INFO - 2016-03-03 13:22:34 --> Loader Class Initialized
INFO - 2016-03-03 13:22:34 --> Helper loaded: url_helper
INFO - 2016-03-03 13:22:34 --> Helper loaded: file_helper
INFO - 2016-03-03 13:22:34 --> Helper loaded: date_helper
INFO - 2016-03-03 13:22:34 --> Helper loaded: form_helper
INFO - 2016-03-03 13:22:34 --> Database Driver Class Initialized
INFO - 2016-03-03 13:22:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:22:35 --> Controller Class Initialized
INFO - 2016-03-03 13:22:35 --> Model Class Initialized
INFO - 2016-03-03 13:22:35 --> Model Class Initialized
INFO - 2016-03-03 13:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:22:35 --> Pagination Class Initialized
INFO - 2016-03-03 13:22:35 --> Helper loaded: text_helper
INFO - 2016-03-03 13:22:35 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:22:35 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:22:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:22:35 --> Final output sent to browser
DEBUG - 2016-03-03 16:22:35 --> Total execution time: 1.1771
INFO - 2016-03-03 13:23:02 --> Config Class Initialized
INFO - 2016-03-03 13:23:02 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:23:02 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:23:02 --> Utf8 Class Initialized
INFO - 2016-03-03 13:23:02 --> URI Class Initialized
INFO - 2016-03-03 13:23:02 --> Router Class Initialized
INFO - 2016-03-03 13:23:02 --> Output Class Initialized
INFO - 2016-03-03 13:23:02 --> Security Class Initialized
DEBUG - 2016-03-03 13:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:23:02 --> Input Class Initialized
INFO - 2016-03-03 13:23:02 --> Language Class Initialized
INFO - 2016-03-03 13:23:02 --> Loader Class Initialized
INFO - 2016-03-03 13:23:02 --> Helper loaded: url_helper
INFO - 2016-03-03 13:23:02 --> Helper loaded: file_helper
INFO - 2016-03-03 13:23:02 --> Helper loaded: date_helper
INFO - 2016-03-03 13:23:02 --> Helper loaded: form_helper
INFO - 2016-03-03 13:23:02 --> Database Driver Class Initialized
INFO - 2016-03-03 13:23:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:23:03 --> Controller Class Initialized
INFO - 2016-03-03 13:23:03 --> Model Class Initialized
INFO - 2016-03-03 13:23:03 --> Model Class Initialized
INFO - 2016-03-03 13:23:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:23:03 --> Pagination Class Initialized
INFO - 2016-03-03 13:23:03 --> Helper loaded: text_helper
INFO - 2016-03-03 13:23:03 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:23:03 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:23:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:23:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:23:03 --> Final output sent to browser
DEBUG - 2016-03-03 16:23:03 --> Total execution time: 1.1294
INFO - 2016-03-03 13:23:36 --> Config Class Initialized
INFO - 2016-03-03 13:23:36 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:23:36 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:23:36 --> Utf8 Class Initialized
INFO - 2016-03-03 13:23:36 --> URI Class Initialized
INFO - 2016-03-03 13:23:36 --> Router Class Initialized
INFO - 2016-03-03 13:23:36 --> Output Class Initialized
INFO - 2016-03-03 13:23:36 --> Security Class Initialized
DEBUG - 2016-03-03 13:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:23:36 --> Input Class Initialized
INFO - 2016-03-03 13:23:36 --> Language Class Initialized
INFO - 2016-03-03 13:23:36 --> Loader Class Initialized
INFO - 2016-03-03 13:23:36 --> Helper loaded: url_helper
INFO - 2016-03-03 13:23:36 --> Helper loaded: file_helper
INFO - 2016-03-03 13:23:36 --> Helper loaded: date_helper
INFO - 2016-03-03 13:23:36 --> Helper loaded: form_helper
INFO - 2016-03-03 13:23:36 --> Database Driver Class Initialized
INFO - 2016-03-03 13:23:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:23:37 --> Controller Class Initialized
INFO - 2016-03-03 13:23:37 --> Model Class Initialized
INFO - 2016-03-03 13:23:37 --> Model Class Initialized
INFO - 2016-03-03 13:23:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:23:37 --> Pagination Class Initialized
INFO - 2016-03-03 13:23:37 --> Helper loaded: text_helper
INFO - 2016-03-03 13:23:37 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:23:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:23:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:23:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:23:37 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:23:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:23:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:23:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:23:37 --> Final output sent to browser
DEBUG - 2016-03-03 16:23:37 --> Total execution time: 1.1760
INFO - 2016-03-03 13:24:58 --> Config Class Initialized
INFO - 2016-03-03 13:24:58 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:24:58 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:24:58 --> Utf8 Class Initialized
INFO - 2016-03-03 13:24:58 --> URI Class Initialized
INFO - 2016-03-03 13:24:58 --> Router Class Initialized
INFO - 2016-03-03 13:24:58 --> Output Class Initialized
INFO - 2016-03-03 13:24:58 --> Security Class Initialized
DEBUG - 2016-03-03 13:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:24:58 --> Input Class Initialized
INFO - 2016-03-03 13:24:58 --> Language Class Initialized
INFO - 2016-03-03 13:24:58 --> Loader Class Initialized
INFO - 2016-03-03 13:24:58 --> Helper loaded: url_helper
INFO - 2016-03-03 13:24:58 --> Helper loaded: file_helper
INFO - 2016-03-03 13:24:58 --> Helper loaded: date_helper
INFO - 2016-03-03 13:24:58 --> Helper loaded: form_helper
INFO - 2016-03-03 13:24:58 --> Database Driver Class Initialized
INFO - 2016-03-03 13:24:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:24:59 --> Controller Class Initialized
INFO - 2016-03-03 13:24:59 --> Model Class Initialized
INFO - 2016-03-03 13:24:59 --> Model Class Initialized
INFO - 2016-03-03 13:24:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:24:59 --> Pagination Class Initialized
INFO - 2016-03-03 13:24:59 --> Helper loaded: text_helper
INFO - 2016-03-03 13:24:59 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:24:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:24:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:24:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 16:24:59 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 16:24:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 16:24:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 16:24:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:24:59 --> Final output sent to browser
DEBUG - 2016-03-03 16:24:59 --> Total execution time: 1.0939
INFO - 2016-03-03 13:25:16 --> Config Class Initialized
INFO - 2016-03-03 13:25:16 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:25:16 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:25:16 --> Utf8 Class Initialized
INFO - 2016-03-03 13:25:16 --> URI Class Initialized
DEBUG - 2016-03-03 13:25:16 --> No URI present. Default controller set.
INFO - 2016-03-03 13:25:16 --> Router Class Initialized
INFO - 2016-03-03 13:25:16 --> Output Class Initialized
INFO - 2016-03-03 13:25:16 --> Security Class Initialized
DEBUG - 2016-03-03 13:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:25:16 --> Input Class Initialized
INFO - 2016-03-03 13:25:16 --> Language Class Initialized
INFO - 2016-03-03 13:25:16 --> Loader Class Initialized
INFO - 2016-03-03 13:25:16 --> Helper loaded: url_helper
INFO - 2016-03-03 13:25:16 --> Helper loaded: file_helper
INFO - 2016-03-03 13:25:16 --> Helper loaded: date_helper
INFO - 2016-03-03 13:25:16 --> Helper loaded: form_helper
INFO - 2016-03-03 13:25:16 --> Database Driver Class Initialized
INFO - 2016-03-03 13:25:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:25:17 --> Controller Class Initialized
INFO - 2016-03-03 13:25:17 --> Model Class Initialized
INFO - 2016-03-03 13:25:17 --> Model Class Initialized
INFO - 2016-03-03 13:25:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:25:17 --> Pagination Class Initialized
INFO - 2016-03-03 13:25:17 --> Helper loaded: text_helper
INFO - 2016-03-03 13:25:17 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:25:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:25:17 --> Final output sent to browser
DEBUG - 2016-03-03 16:25:17 --> Total execution time: 1.1715
INFO - 2016-03-03 13:49:13 --> Config Class Initialized
INFO - 2016-03-03 13:49:13 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:49:13 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:49:13 --> Utf8 Class Initialized
INFO - 2016-03-03 13:49:13 --> URI Class Initialized
DEBUG - 2016-03-03 13:49:14 --> No URI present. Default controller set.
INFO - 2016-03-03 13:49:14 --> Router Class Initialized
INFO - 2016-03-03 13:49:14 --> Output Class Initialized
INFO - 2016-03-03 13:49:14 --> Security Class Initialized
DEBUG - 2016-03-03 13:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:49:14 --> Input Class Initialized
INFO - 2016-03-03 13:49:14 --> Language Class Initialized
INFO - 2016-03-03 13:49:14 --> Loader Class Initialized
INFO - 2016-03-03 13:49:14 --> Helper loaded: url_helper
INFO - 2016-03-03 13:49:14 --> Helper loaded: file_helper
INFO - 2016-03-03 13:49:14 --> Helper loaded: date_helper
INFO - 2016-03-03 13:49:14 --> Helper loaded: form_helper
INFO - 2016-03-03 13:49:14 --> Database Driver Class Initialized
INFO - 2016-03-03 13:49:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:49:15 --> Controller Class Initialized
INFO - 2016-03-03 13:49:15 --> Model Class Initialized
INFO - 2016-03-03 13:49:15 --> Model Class Initialized
INFO - 2016-03-03 13:49:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:49:15 --> Pagination Class Initialized
INFO - 2016-03-03 13:49:15 --> Helper loaded: text_helper
INFO - 2016-03-03 13:49:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:49:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:49:15 --> Final output sent to browser
DEBUG - 2016-03-03 16:49:15 --> Total execution time: 1.7068
INFO - 2016-03-03 13:50:48 --> Config Class Initialized
INFO - 2016-03-03 13:50:48 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:50:48 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:50:48 --> Utf8 Class Initialized
INFO - 2016-03-03 13:50:48 --> URI Class Initialized
DEBUG - 2016-03-03 13:50:48 --> No URI present. Default controller set.
INFO - 2016-03-03 13:50:48 --> Router Class Initialized
INFO - 2016-03-03 13:50:48 --> Output Class Initialized
INFO - 2016-03-03 13:50:48 --> Security Class Initialized
DEBUG - 2016-03-03 13:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:50:48 --> Input Class Initialized
INFO - 2016-03-03 13:50:48 --> Language Class Initialized
INFO - 2016-03-03 13:50:48 --> Loader Class Initialized
INFO - 2016-03-03 13:50:48 --> Helper loaded: url_helper
INFO - 2016-03-03 13:50:48 --> Helper loaded: file_helper
INFO - 2016-03-03 13:50:48 --> Helper loaded: date_helper
INFO - 2016-03-03 13:50:48 --> Helper loaded: form_helper
INFO - 2016-03-03 13:50:48 --> Database Driver Class Initialized
INFO - 2016-03-03 13:50:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:50:49 --> Controller Class Initialized
INFO - 2016-03-03 13:50:49 --> Model Class Initialized
INFO - 2016-03-03 13:50:49 --> Model Class Initialized
INFO - 2016-03-03 13:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:50:49 --> Pagination Class Initialized
INFO - 2016-03-03 13:50:49 --> Helper loaded: text_helper
INFO - 2016-03-03 13:50:49 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:50:49 --> Final output sent to browser
DEBUG - 2016-03-03 16:50:49 --> Total execution time: 1.1792
INFO - 2016-03-03 13:52:42 --> Config Class Initialized
INFO - 2016-03-03 13:52:42 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:52:42 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:52:42 --> Utf8 Class Initialized
INFO - 2016-03-03 13:52:42 --> URI Class Initialized
DEBUG - 2016-03-03 13:52:42 --> No URI present. Default controller set.
INFO - 2016-03-03 13:52:42 --> Router Class Initialized
INFO - 2016-03-03 13:52:42 --> Output Class Initialized
INFO - 2016-03-03 13:52:42 --> Security Class Initialized
DEBUG - 2016-03-03 13:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:52:42 --> Input Class Initialized
INFO - 2016-03-03 13:52:42 --> Language Class Initialized
INFO - 2016-03-03 13:52:42 --> Loader Class Initialized
INFO - 2016-03-03 13:52:42 --> Helper loaded: url_helper
INFO - 2016-03-03 13:52:42 --> Helper loaded: file_helper
INFO - 2016-03-03 13:52:42 --> Helper loaded: date_helper
INFO - 2016-03-03 13:52:42 --> Helper loaded: form_helper
INFO - 2016-03-03 13:52:42 --> Database Driver Class Initialized
INFO - 2016-03-03 13:52:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:52:43 --> Controller Class Initialized
INFO - 2016-03-03 13:52:43 --> Model Class Initialized
INFO - 2016-03-03 13:52:43 --> Model Class Initialized
INFO - 2016-03-03 13:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:52:43 --> Pagination Class Initialized
INFO - 2016-03-03 13:52:43 --> Helper loaded: text_helper
INFO - 2016-03-03 13:52:43 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:52:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:52:43 --> Final output sent to browser
DEBUG - 2016-03-03 16:52:43 --> Total execution time: 1.1660
INFO - 2016-03-03 13:53:46 --> Config Class Initialized
INFO - 2016-03-03 13:53:46 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:53:47 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:53:47 --> Utf8 Class Initialized
INFO - 2016-03-03 13:53:47 --> URI Class Initialized
DEBUG - 2016-03-03 13:53:47 --> No URI present. Default controller set.
INFO - 2016-03-03 13:53:47 --> Router Class Initialized
INFO - 2016-03-03 13:53:47 --> Output Class Initialized
INFO - 2016-03-03 13:53:47 --> Security Class Initialized
DEBUG - 2016-03-03 13:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:53:47 --> Input Class Initialized
INFO - 2016-03-03 13:53:47 --> Language Class Initialized
INFO - 2016-03-03 13:53:47 --> Loader Class Initialized
INFO - 2016-03-03 13:53:47 --> Helper loaded: url_helper
INFO - 2016-03-03 13:53:47 --> Helper loaded: file_helper
INFO - 2016-03-03 13:53:47 --> Helper loaded: date_helper
INFO - 2016-03-03 13:53:47 --> Helper loaded: form_helper
INFO - 2016-03-03 13:53:47 --> Database Driver Class Initialized
INFO - 2016-03-03 13:53:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:53:48 --> Controller Class Initialized
INFO - 2016-03-03 13:53:48 --> Model Class Initialized
INFO - 2016-03-03 13:53:48 --> Model Class Initialized
INFO - 2016-03-03 13:53:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:53:48 --> Pagination Class Initialized
INFO - 2016-03-03 13:53:48 --> Helper loaded: text_helper
INFO - 2016-03-03 13:53:48 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:53:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:53:48 --> Final output sent to browser
DEBUG - 2016-03-03 16:53:48 --> Total execution time: 1.0952
INFO - 2016-03-03 13:54:19 --> Config Class Initialized
INFO - 2016-03-03 13:54:19 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:54:19 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:54:19 --> Utf8 Class Initialized
INFO - 2016-03-03 13:54:20 --> URI Class Initialized
DEBUG - 2016-03-03 13:54:20 --> No URI present. Default controller set.
INFO - 2016-03-03 13:54:20 --> Router Class Initialized
INFO - 2016-03-03 13:54:20 --> Output Class Initialized
INFO - 2016-03-03 13:54:20 --> Security Class Initialized
DEBUG - 2016-03-03 13:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:54:20 --> Input Class Initialized
INFO - 2016-03-03 13:54:20 --> Language Class Initialized
INFO - 2016-03-03 13:54:20 --> Loader Class Initialized
INFO - 2016-03-03 13:54:20 --> Helper loaded: url_helper
INFO - 2016-03-03 13:54:20 --> Helper loaded: file_helper
INFO - 2016-03-03 13:54:20 --> Helper loaded: date_helper
INFO - 2016-03-03 13:54:20 --> Helper loaded: form_helper
INFO - 2016-03-03 13:54:20 --> Database Driver Class Initialized
INFO - 2016-03-03 13:54:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:54:21 --> Controller Class Initialized
INFO - 2016-03-03 13:54:21 --> Model Class Initialized
INFO - 2016-03-03 13:54:21 --> Model Class Initialized
INFO - 2016-03-03 13:54:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:54:21 --> Pagination Class Initialized
INFO - 2016-03-03 13:54:21 --> Helper loaded: text_helper
INFO - 2016-03-03 13:54:21 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:54:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:54:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:54:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:54:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:54:21 --> Final output sent to browser
DEBUG - 2016-03-03 16:54:21 --> Total execution time: 1.1592
INFO - 2016-03-03 13:54:25 --> Config Class Initialized
INFO - 2016-03-03 13:54:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:54:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:54:25 --> Utf8 Class Initialized
INFO - 2016-03-03 13:54:25 --> URI Class Initialized
DEBUG - 2016-03-03 13:54:25 --> No URI present. Default controller set.
INFO - 2016-03-03 13:54:25 --> Router Class Initialized
INFO - 2016-03-03 13:54:25 --> Output Class Initialized
INFO - 2016-03-03 13:54:25 --> Security Class Initialized
DEBUG - 2016-03-03 13:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:54:25 --> Input Class Initialized
INFO - 2016-03-03 13:54:25 --> Language Class Initialized
INFO - 2016-03-03 13:54:25 --> Loader Class Initialized
INFO - 2016-03-03 13:54:25 --> Helper loaded: url_helper
INFO - 2016-03-03 13:54:25 --> Helper loaded: file_helper
INFO - 2016-03-03 13:54:25 --> Helper loaded: date_helper
INFO - 2016-03-03 13:54:25 --> Helper loaded: form_helper
INFO - 2016-03-03 13:54:25 --> Database Driver Class Initialized
INFO - 2016-03-03 13:54:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:54:26 --> Controller Class Initialized
INFO - 2016-03-03 13:54:26 --> Model Class Initialized
INFO - 2016-03-03 13:54:26 --> Model Class Initialized
INFO - 2016-03-03 13:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:54:26 --> Pagination Class Initialized
INFO - 2016-03-03 13:54:26 --> Helper loaded: text_helper
INFO - 2016-03-03 13:54:26 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:54:26 --> Final output sent to browser
DEBUG - 2016-03-03 16:54:26 --> Total execution time: 1.1698
INFO - 2016-03-03 13:55:14 --> Config Class Initialized
INFO - 2016-03-03 13:55:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:55:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:55:14 --> Utf8 Class Initialized
INFO - 2016-03-03 13:55:14 --> URI Class Initialized
DEBUG - 2016-03-03 13:55:14 --> No URI present. Default controller set.
INFO - 2016-03-03 13:55:14 --> Router Class Initialized
INFO - 2016-03-03 13:55:14 --> Output Class Initialized
INFO - 2016-03-03 13:55:14 --> Security Class Initialized
DEBUG - 2016-03-03 13:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:55:14 --> Input Class Initialized
INFO - 2016-03-03 13:55:14 --> Language Class Initialized
INFO - 2016-03-03 13:55:14 --> Loader Class Initialized
INFO - 2016-03-03 13:55:14 --> Helper loaded: url_helper
INFO - 2016-03-03 13:55:14 --> Helper loaded: file_helper
INFO - 2016-03-03 13:55:14 --> Helper loaded: date_helper
INFO - 2016-03-03 13:55:14 --> Helper loaded: form_helper
INFO - 2016-03-03 13:55:14 --> Database Driver Class Initialized
INFO - 2016-03-03 13:55:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:55:15 --> Controller Class Initialized
INFO - 2016-03-03 13:55:15 --> Model Class Initialized
INFO - 2016-03-03 13:55:15 --> Model Class Initialized
INFO - 2016-03-03 13:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:55:15 --> Pagination Class Initialized
INFO - 2016-03-03 13:55:15 --> Helper loaded: text_helper
INFO - 2016-03-03 13:55:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:55:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:55:15 --> Final output sent to browser
DEBUG - 2016-03-03 16:55:15 --> Total execution time: 1.1684
INFO - 2016-03-03 13:59:53 --> Config Class Initialized
INFO - 2016-03-03 13:59:53 --> Hooks Class Initialized
DEBUG - 2016-03-03 13:59:53 --> UTF-8 Support Enabled
INFO - 2016-03-03 13:59:53 --> Utf8 Class Initialized
INFO - 2016-03-03 13:59:53 --> URI Class Initialized
DEBUG - 2016-03-03 13:59:53 --> No URI present. Default controller set.
INFO - 2016-03-03 13:59:53 --> Router Class Initialized
INFO - 2016-03-03 13:59:53 --> Output Class Initialized
INFO - 2016-03-03 13:59:53 --> Security Class Initialized
DEBUG - 2016-03-03 13:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 13:59:53 --> Input Class Initialized
INFO - 2016-03-03 13:59:53 --> Language Class Initialized
INFO - 2016-03-03 13:59:53 --> Loader Class Initialized
INFO - 2016-03-03 13:59:53 --> Helper loaded: url_helper
INFO - 2016-03-03 13:59:53 --> Helper loaded: file_helper
INFO - 2016-03-03 13:59:53 --> Helper loaded: date_helper
INFO - 2016-03-03 13:59:53 --> Helper loaded: form_helper
INFO - 2016-03-03 13:59:53 --> Database Driver Class Initialized
INFO - 2016-03-03 13:59:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 13:59:54 --> Controller Class Initialized
INFO - 2016-03-03 13:59:54 --> Model Class Initialized
INFO - 2016-03-03 13:59:54 --> Model Class Initialized
INFO - 2016-03-03 13:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 13:59:54 --> Pagination Class Initialized
INFO - 2016-03-03 13:59:54 --> Helper loaded: text_helper
INFO - 2016-03-03 13:59:54 --> Helper loaded: cookie_helper
INFO - 2016-03-03 16:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 16:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 16:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 16:59:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 16:59:54 --> Final output sent to browser
DEBUG - 2016-03-03 16:59:54 --> Total execution time: 1.1347
INFO - 2016-03-03 14:00:36 --> Config Class Initialized
INFO - 2016-03-03 14:00:36 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:00:36 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:00:36 --> Utf8 Class Initialized
INFO - 2016-03-03 14:00:36 --> URI Class Initialized
DEBUG - 2016-03-03 14:00:36 --> No URI present. Default controller set.
INFO - 2016-03-03 14:00:36 --> Router Class Initialized
INFO - 2016-03-03 14:00:36 --> Output Class Initialized
INFO - 2016-03-03 14:00:36 --> Security Class Initialized
DEBUG - 2016-03-03 14:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:00:36 --> Input Class Initialized
INFO - 2016-03-03 14:00:36 --> Language Class Initialized
INFO - 2016-03-03 14:00:36 --> Loader Class Initialized
INFO - 2016-03-03 14:00:36 --> Helper loaded: url_helper
INFO - 2016-03-03 14:00:36 --> Helper loaded: file_helper
INFO - 2016-03-03 14:00:36 --> Helper loaded: date_helper
INFO - 2016-03-03 14:00:36 --> Helper loaded: form_helper
INFO - 2016-03-03 14:00:36 --> Database Driver Class Initialized
INFO - 2016-03-03 14:00:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:00:37 --> Controller Class Initialized
INFO - 2016-03-03 14:00:37 --> Model Class Initialized
INFO - 2016-03-03 14:00:37 --> Model Class Initialized
INFO - 2016-03-03 14:00:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:00:37 --> Pagination Class Initialized
INFO - 2016-03-03 14:00:37 --> Helper loaded: text_helper
INFO - 2016-03-03 14:00:37 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:00:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:00:37 --> Final output sent to browser
DEBUG - 2016-03-03 17:00:37 --> Total execution time: 1.1989
INFO - 2016-03-03 14:00:46 --> Config Class Initialized
INFO - 2016-03-03 14:00:46 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:00:46 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:00:46 --> Utf8 Class Initialized
INFO - 2016-03-03 14:00:46 --> URI Class Initialized
DEBUG - 2016-03-03 14:00:46 --> No URI present. Default controller set.
INFO - 2016-03-03 14:00:46 --> Router Class Initialized
INFO - 2016-03-03 14:00:46 --> Output Class Initialized
INFO - 2016-03-03 14:00:46 --> Security Class Initialized
DEBUG - 2016-03-03 14:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:00:46 --> Input Class Initialized
INFO - 2016-03-03 14:00:46 --> Language Class Initialized
INFO - 2016-03-03 14:00:46 --> Loader Class Initialized
INFO - 2016-03-03 14:00:46 --> Helper loaded: url_helper
INFO - 2016-03-03 14:00:46 --> Helper loaded: file_helper
INFO - 2016-03-03 14:00:46 --> Helper loaded: date_helper
INFO - 2016-03-03 14:00:46 --> Helper loaded: form_helper
INFO - 2016-03-03 14:00:46 --> Database Driver Class Initialized
INFO - 2016-03-03 14:00:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:00:47 --> Controller Class Initialized
INFO - 2016-03-03 14:00:47 --> Model Class Initialized
INFO - 2016-03-03 14:00:47 --> Model Class Initialized
INFO - 2016-03-03 14:00:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:00:47 --> Pagination Class Initialized
INFO - 2016-03-03 14:00:47 --> Helper loaded: text_helper
INFO - 2016-03-03 14:00:47 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:00:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:00:47 --> Final output sent to browser
DEBUG - 2016-03-03 17:00:47 --> Total execution time: 1.1377
INFO - 2016-03-03 14:01:05 --> Config Class Initialized
INFO - 2016-03-03 14:01:05 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:01:05 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:01:05 --> Utf8 Class Initialized
INFO - 2016-03-03 14:01:05 --> URI Class Initialized
DEBUG - 2016-03-03 14:01:05 --> No URI present. Default controller set.
INFO - 2016-03-03 14:01:05 --> Router Class Initialized
INFO - 2016-03-03 14:01:05 --> Output Class Initialized
INFO - 2016-03-03 14:01:05 --> Security Class Initialized
DEBUG - 2016-03-03 14:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:01:05 --> Input Class Initialized
INFO - 2016-03-03 14:01:05 --> Language Class Initialized
INFO - 2016-03-03 14:01:05 --> Loader Class Initialized
INFO - 2016-03-03 14:01:05 --> Helper loaded: url_helper
INFO - 2016-03-03 14:01:05 --> Helper loaded: file_helper
INFO - 2016-03-03 14:01:05 --> Helper loaded: date_helper
INFO - 2016-03-03 14:01:05 --> Helper loaded: form_helper
INFO - 2016-03-03 14:01:05 --> Database Driver Class Initialized
INFO - 2016-03-03 14:01:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:01:06 --> Controller Class Initialized
INFO - 2016-03-03 14:01:06 --> Model Class Initialized
INFO - 2016-03-03 14:01:06 --> Model Class Initialized
INFO - 2016-03-03 14:01:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:01:06 --> Pagination Class Initialized
INFO - 2016-03-03 14:01:06 --> Helper loaded: text_helper
INFO - 2016-03-03 14:01:06 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:01:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:01:06 --> Final output sent to browser
DEBUG - 2016-03-03 17:01:06 --> Total execution time: 1.1621
INFO - 2016-03-03 14:01:52 --> Config Class Initialized
INFO - 2016-03-03 14:01:52 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:01:52 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:01:52 --> Utf8 Class Initialized
INFO - 2016-03-03 14:01:52 --> URI Class Initialized
DEBUG - 2016-03-03 14:01:52 --> No URI present. Default controller set.
INFO - 2016-03-03 14:01:52 --> Router Class Initialized
INFO - 2016-03-03 14:01:52 --> Output Class Initialized
INFO - 2016-03-03 14:01:52 --> Security Class Initialized
DEBUG - 2016-03-03 14:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:01:52 --> Input Class Initialized
INFO - 2016-03-03 14:01:52 --> Language Class Initialized
INFO - 2016-03-03 14:01:52 --> Loader Class Initialized
INFO - 2016-03-03 14:01:52 --> Helper loaded: url_helper
INFO - 2016-03-03 14:01:52 --> Helper loaded: file_helper
INFO - 2016-03-03 14:01:52 --> Helper loaded: date_helper
INFO - 2016-03-03 14:01:52 --> Helper loaded: form_helper
INFO - 2016-03-03 14:01:52 --> Database Driver Class Initialized
INFO - 2016-03-03 14:01:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:01:53 --> Controller Class Initialized
INFO - 2016-03-03 14:01:53 --> Model Class Initialized
INFO - 2016-03-03 14:01:53 --> Model Class Initialized
INFO - 2016-03-03 14:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:01:53 --> Pagination Class Initialized
INFO - 2016-03-03 14:01:53 --> Helper loaded: text_helper
INFO - 2016-03-03 14:01:53 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:01:53 --> Final output sent to browser
DEBUG - 2016-03-03 17:01:53 --> Total execution time: 1.1520
INFO - 2016-03-03 14:02:02 --> Config Class Initialized
INFO - 2016-03-03 14:02:02 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:02:02 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:02:02 --> Utf8 Class Initialized
INFO - 2016-03-03 14:02:02 --> URI Class Initialized
DEBUG - 2016-03-03 14:02:02 --> No URI present. Default controller set.
INFO - 2016-03-03 14:02:02 --> Router Class Initialized
INFO - 2016-03-03 14:02:02 --> Output Class Initialized
INFO - 2016-03-03 14:02:02 --> Security Class Initialized
DEBUG - 2016-03-03 14:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:02:02 --> Input Class Initialized
INFO - 2016-03-03 14:02:02 --> Language Class Initialized
INFO - 2016-03-03 14:02:02 --> Loader Class Initialized
INFO - 2016-03-03 14:02:02 --> Helper loaded: url_helper
INFO - 2016-03-03 14:02:02 --> Helper loaded: file_helper
INFO - 2016-03-03 14:02:02 --> Helper loaded: date_helper
INFO - 2016-03-03 14:02:02 --> Helper loaded: form_helper
INFO - 2016-03-03 14:02:02 --> Database Driver Class Initialized
INFO - 2016-03-03 14:02:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:02:03 --> Controller Class Initialized
INFO - 2016-03-03 14:02:03 --> Model Class Initialized
INFO - 2016-03-03 14:02:03 --> Model Class Initialized
INFO - 2016-03-03 14:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:02:03 --> Pagination Class Initialized
INFO - 2016-03-03 14:02:03 --> Helper loaded: text_helper
INFO - 2016-03-03 14:02:03 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:02:03 --> Final output sent to browser
DEBUG - 2016-03-03 17:02:03 --> Total execution time: 1.1785
INFO - 2016-03-03 14:02:12 --> Config Class Initialized
INFO - 2016-03-03 14:02:12 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:02:12 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:02:12 --> Utf8 Class Initialized
INFO - 2016-03-03 14:02:12 --> URI Class Initialized
DEBUG - 2016-03-03 14:02:12 --> No URI present. Default controller set.
INFO - 2016-03-03 14:02:12 --> Router Class Initialized
INFO - 2016-03-03 14:02:12 --> Output Class Initialized
INFO - 2016-03-03 14:02:12 --> Security Class Initialized
DEBUG - 2016-03-03 14:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:02:12 --> Input Class Initialized
INFO - 2016-03-03 14:02:12 --> Language Class Initialized
INFO - 2016-03-03 14:02:12 --> Loader Class Initialized
INFO - 2016-03-03 14:02:12 --> Helper loaded: url_helper
INFO - 2016-03-03 14:02:12 --> Helper loaded: file_helper
INFO - 2016-03-03 14:02:12 --> Helper loaded: date_helper
INFO - 2016-03-03 14:02:12 --> Helper loaded: form_helper
INFO - 2016-03-03 14:02:12 --> Database Driver Class Initialized
INFO - 2016-03-03 14:02:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:02:13 --> Controller Class Initialized
INFO - 2016-03-03 14:02:13 --> Model Class Initialized
INFO - 2016-03-03 14:02:13 --> Model Class Initialized
INFO - 2016-03-03 14:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:02:13 --> Pagination Class Initialized
INFO - 2016-03-03 14:02:13 --> Helper loaded: text_helper
INFO - 2016-03-03 14:02:13 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:02:13 --> Final output sent to browser
DEBUG - 2016-03-03 17:02:13 --> Total execution time: 1.1751
INFO - 2016-03-03 14:03:18 --> Config Class Initialized
INFO - 2016-03-03 14:03:18 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:03:18 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:03:18 --> Utf8 Class Initialized
INFO - 2016-03-03 14:03:18 --> URI Class Initialized
DEBUG - 2016-03-03 14:03:18 --> No URI present. Default controller set.
INFO - 2016-03-03 14:03:18 --> Router Class Initialized
INFO - 2016-03-03 14:03:18 --> Output Class Initialized
INFO - 2016-03-03 14:03:18 --> Security Class Initialized
DEBUG - 2016-03-03 14:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:03:18 --> Input Class Initialized
INFO - 2016-03-03 14:03:18 --> Language Class Initialized
INFO - 2016-03-03 14:03:18 --> Loader Class Initialized
INFO - 2016-03-03 14:03:18 --> Helper loaded: url_helper
INFO - 2016-03-03 14:03:18 --> Helper loaded: file_helper
INFO - 2016-03-03 14:03:18 --> Helper loaded: date_helper
INFO - 2016-03-03 14:03:18 --> Helper loaded: form_helper
INFO - 2016-03-03 14:03:18 --> Database Driver Class Initialized
INFO - 2016-03-03 14:03:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:03:19 --> Controller Class Initialized
INFO - 2016-03-03 14:03:19 --> Model Class Initialized
INFO - 2016-03-03 14:03:19 --> Model Class Initialized
INFO - 2016-03-03 14:03:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:03:19 --> Pagination Class Initialized
INFO - 2016-03-03 14:03:19 --> Helper loaded: text_helper
INFO - 2016-03-03 14:03:19 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:03:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:03:19 --> Final output sent to browser
DEBUG - 2016-03-03 17:03:19 --> Total execution time: 1.2323
INFO - 2016-03-03 14:05:09 --> Config Class Initialized
INFO - 2016-03-03 14:05:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:05:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:05:09 --> Utf8 Class Initialized
INFO - 2016-03-03 14:05:09 --> URI Class Initialized
DEBUG - 2016-03-03 14:05:09 --> No URI present. Default controller set.
INFO - 2016-03-03 14:05:09 --> Router Class Initialized
INFO - 2016-03-03 14:05:09 --> Output Class Initialized
INFO - 2016-03-03 14:05:09 --> Security Class Initialized
DEBUG - 2016-03-03 14:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:05:09 --> Input Class Initialized
INFO - 2016-03-03 14:05:09 --> Language Class Initialized
INFO - 2016-03-03 14:05:09 --> Loader Class Initialized
INFO - 2016-03-03 14:05:09 --> Helper loaded: url_helper
INFO - 2016-03-03 14:05:09 --> Helper loaded: file_helper
INFO - 2016-03-03 14:05:09 --> Helper loaded: date_helper
INFO - 2016-03-03 14:05:09 --> Helper loaded: form_helper
INFO - 2016-03-03 14:05:09 --> Database Driver Class Initialized
INFO - 2016-03-03 14:05:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:05:10 --> Controller Class Initialized
INFO - 2016-03-03 14:05:10 --> Model Class Initialized
INFO - 2016-03-03 14:05:10 --> Model Class Initialized
INFO - 2016-03-03 14:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:05:10 --> Pagination Class Initialized
INFO - 2016-03-03 14:05:10 --> Helper loaded: text_helper
INFO - 2016-03-03 14:05:10 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:05:10 --> Final output sent to browser
DEBUG - 2016-03-03 17:05:10 --> Total execution time: 1.1588
INFO - 2016-03-03 14:05:25 --> Config Class Initialized
INFO - 2016-03-03 14:05:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:05:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:05:25 --> Utf8 Class Initialized
INFO - 2016-03-03 14:05:25 --> URI Class Initialized
DEBUG - 2016-03-03 14:05:25 --> No URI present. Default controller set.
INFO - 2016-03-03 14:05:25 --> Router Class Initialized
INFO - 2016-03-03 14:05:25 --> Output Class Initialized
INFO - 2016-03-03 14:05:25 --> Security Class Initialized
DEBUG - 2016-03-03 14:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:05:25 --> Input Class Initialized
INFO - 2016-03-03 14:05:25 --> Language Class Initialized
INFO - 2016-03-03 14:05:25 --> Loader Class Initialized
INFO - 2016-03-03 14:05:25 --> Helper loaded: url_helper
INFO - 2016-03-03 14:05:25 --> Helper loaded: file_helper
INFO - 2016-03-03 14:05:25 --> Helper loaded: date_helper
INFO - 2016-03-03 14:05:25 --> Helper loaded: form_helper
INFO - 2016-03-03 14:05:25 --> Database Driver Class Initialized
INFO - 2016-03-03 14:05:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:05:26 --> Controller Class Initialized
INFO - 2016-03-03 14:05:26 --> Model Class Initialized
INFO - 2016-03-03 14:05:26 --> Model Class Initialized
INFO - 2016-03-03 14:05:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:05:26 --> Pagination Class Initialized
INFO - 2016-03-03 14:05:26 --> Helper loaded: text_helper
INFO - 2016-03-03 14:05:26 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:05:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:05:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:05:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:05:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:05:26 --> Final output sent to browser
DEBUG - 2016-03-03 17:05:26 --> Total execution time: 1.1132
INFO - 2016-03-03 14:07:41 --> Config Class Initialized
INFO - 2016-03-03 14:07:41 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:07:41 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:07:41 --> Utf8 Class Initialized
INFO - 2016-03-03 14:07:41 --> URI Class Initialized
DEBUG - 2016-03-03 14:07:41 --> No URI present. Default controller set.
INFO - 2016-03-03 14:07:41 --> Router Class Initialized
INFO - 2016-03-03 14:07:41 --> Output Class Initialized
INFO - 2016-03-03 14:07:41 --> Security Class Initialized
DEBUG - 2016-03-03 14:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:07:41 --> Input Class Initialized
INFO - 2016-03-03 14:07:41 --> Language Class Initialized
INFO - 2016-03-03 14:07:41 --> Loader Class Initialized
INFO - 2016-03-03 14:07:41 --> Helper loaded: url_helper
INFO - 2016-03-03 14:07:41 --> Helper loaded: file_helper
INFO - 2016-03-03 14:07:41 --> Helper loaded: date_helper
INFO - 2016-03-03 14:07:41 --> Helper loaded: form_helper
INFO - 2016-03-03 14:07:41 --> Database Driver Class Initialized
INFO - 2016-03-03 14:07:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:07:42 --> Controller Class Initialized
INFO - 2016-03-03 14:07:42 --> Model Class Initialized
INFO - 2016-03-03 14:07:42 --> Model Class Initialized
INFO - 2016-03-03 14:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:07:42 --> Pagination Class Initialized
INFO - 2016-03-03 14:07:42 --> Helper loaded: text_helper
INFO - 2016-03-03 14:07:42 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:07:42 --> Final output sent to browser
DEBUG - 2016-03-03 17:07:42 --> Total execution time: 1.1508
INFO - 2016-03-03 14:07:57 --> Config Class Initialized
INFO - 2016-03-03 14:07:57 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:07:57 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:07:57 --> Utf8 Class Initialized
INFO - 2016-03-03 14:07:57 --> URI Class Initialized
DEBUG - 2016-03-03 14:07:57 --> No URI present. Default controller set.
INFO - 2016-03-03 14:07:57 --> Router Class Initialized
INFO - 2016-03-03 14:07:57 --> Output Class Initialized
INFO - 2016-03-03 14:07:57 --> Security Class Initialized
DEBUG - 2016-03-03 14:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:07:57 --> Input Class Initialized
INFO - 2016-03-03 14:07:57 --> Language Class Initialized
INFO - 2016-03-03 14:07:57 --> Loader Class Initialized
INFO - 2016-03-03 14:07:57 --> Helper loaded: url_helper
INFO - 2016-03-03 14:07:57 --> Helper loaded: file_helper
INFO - 2016-03-03 14:07:57 --> Helper loaded: date_helper
INFO - 2016-03-03 14:07:57 --> Helper loaded: form_helper
INFO - 2016-03-03 14:07:57 --> Database Driver Class Initialized
INFO - 2016-03-03 14:07:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:07:58 --> Controller Class Initialized
INFO - 2016-03-03 14:07:58 --> Model Class Initialized
INFO - 2016-03-03 14:07:58 --> Model Class Initialized
INFO - 2016-03-03 14:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:07:58 --> Pagination Class Initialized
INFO - 2016-03-03 14:07:58 --> Helper loaded: text_helper
INFO - 2016-03-03 14:07:58 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:07:58 --> Final output sent to browser
DEBUG - 2016-03-03 17:07:58 --> Total execution time: 1.1661
INFO - 2016-03-03 14:08:15 --> Config Class Initialized
INFO - 2016-03-03 14:08:15 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:08:15 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:08:15 --> Utf8 Class Initialized
INFO - 2016-03-03 14:08:15 --> URI Class Initialized
DEBUG - 2016-03-03 14:08:15 --> No URI present. Default controller set.
INFO - 2016-03-03 14:08:15 --> Router Class Initialized
INFO - 2016-03-03 14:08:15 --> Output Class Initialized
INFO - 2016-03-03 14:08:15 --> Security Class Initialized
DEBUG - 2016-03-03 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:08:15 --> Input Class Initialized
INFO - 2016-03-03 14:08:15 --> Language Class Initialized
INFO - 2016-03-03 14:08:15 --> Loader Class Initialized
INFO - 2016-03-03 14:08:15 --> Helper loaded: url_helper
INFO - 2016-03-03 14:08:15 --> Helper loaded: file_helper
INFO - 2016-03-03 14:08:15 --> Helper loaded: date_helper
INFO - 2016-03-03 14:08:15 --> Helper loaded: form_helper
INFO - 2016-03-03 14:08:15 --> Database Driver Class Initialized
INFO - 2016-03-03 14:08:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:08:16 --> Controller Class Initialized
INFO - 2016-03-03 14:08:16 --> Model Class Initialized
INFO - 2016-03-03 14:08:16 --> Model Class Initialized
INFO - 2016-03-03 14:08:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:08:16 --> Pagination Class Initialized
INFO - 2016-03-03 14:08:16 --> Helper loaded: text_helper
INFO - 2016-03-03 14:08:16 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:08:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:08:16 --> Final output sent to browser
DEBUG - 2016-03-03 17:08:16 --> Total execution time: 1.1787
INFO - 2016-03-03 14:08:38 --> Config Class Initialized
INFO - 2016-03-03 14:08:38 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:08:38 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:08:38 --> Utf8 Class Initialized
INFO - 2016-03-03 14:08:38 --> URI Class Initialized
DEBUG - 2016-03-03 14:08:38 --> No URI present. Default controller set.
INFO - 2016-03-03 14:08:38 --> Router Class Initialized
INFO - 2016-03-03 14:08:38 --> Output Class Initialized
INFO - 2016-03-03 14:08:38 --> Security Class Initialized
DEBUG - 2016-03-03 14:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:08:38 --> Input Class Initialized
INFO - 2016-03-03 14:08:38 --> Language Class Initialized
INFO - 2016-03-03 14:08:38 --> Loader Class Initialized
INFO - 2016-03-03 14:08:38 --> Helper loaded: url_helper
INFO - 2016-03-03 14:08:38 --> Helper loaded: file_helper
INFO - 2016-03-03 14:08:38 --> Helper loaded: date_helper
INFO - 2016-03-03 14:08:38 --> Helper loaded: form_helper
INFO - 2016-03-03 14:08:38 --> Database Driver Class Initialized
INFO - 2016-03-03 14:08:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:08:39 --> Controller Class Initialized
INFO - 2016-03-03 14:08:39 --> Model Class Initialized
INFO - 2016-03-03 14:08:39 --> Model Class Initialized
INFO - 2016-03-03 14:08:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:08:39 --> Pagination Class Initialized
INFO - 2016-03-03 14:08:39 --> Helper loaded: text_helper
INFO - 2016-03-03 14:08:39 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:08:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:08:39 --> Final output sent to browser
DEBUG - 2016-03-03 17:08:39 --> Total execution time: 1.1329
INFO - 2016-03-03 14:09:18 --> Config Class Initialized
INFO - 2016-03-03 14:09:18 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:09:18 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:09:18 --> Utf8 Class Initialized
INFO - 2016-03-03 14:09:18 --> URI Class Initialized
DEBUG - 2016-03-03 14:09:18 --> No URI present. Default controller set.
INFO - 2016-03-03 14:09:18 --> Router Class Initialized
INFO - 2016-03-03 14:09:18 --> Output Class Initialized
INFO - 2016-03-03 14:09:18 --> Security Class Initialized
DEBUG - 2016-03-03 14:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:09:18 --> Input Class Initialized
INFO - 2016-03-03 14:09:18 --> Language Class Initialized
INFO - 2016-03-03 14:09:18 --> Loader Class Initialized
INFO - 2016-03-03 14:09:18 --> Helper loaded: url_helper
INFO - 2016-03-03 14:09:18 --> Helper loaded: file_helper
INFO - 2016-03-03 14:09:18 --> Helper loaded: date_helper
INFO - 2016-03-03 14:09:18 --> Helper loaded: form_helper
INFO - 2016-03-03 14:09:18 --> Database Driver Class Initialized
INFO - 2016-03-03 14:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:09:19 --> Controller Class Initialized
INFO - 2016-03-03 14:09:19 --> Model Class Initialized
INFO - 2016-03-03 14:09:19 --> Model Class Initialized
INFO - 2016-03-03 14:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:09:19 --> Pagination Class Initialized
INFO - 2016-03-03 14:09:19 --> Helper loaded: text_helper
INFO - 2016-03-03 14:09:19 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:09:19 --> Final output sent to browser
DEBUG - 2016-03-03 17:09:19 --> Total execution time: 1.1130
INFO - 2016-03-03 14:09:24 --> Config Class Initialized
INFO - 2016-03-03 14:09:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:09:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:09:24 --> Utf8 Class Initialized
INFO - 2016-03-03 14:09:24 --> URI Class Initialized
DEBUG - 2016-03-03 14:09:24 --> No URI present. Default controller set.
INFO - 2016-03-03 14:09:24 --> Router Class Initialized
INFO - 2016-03-03 14:09:24 --> Output Class Initialized
INFO - 2016-03-03 14:09:24 --> Security Class Initialized
DEBUG - 2016-03-03 14:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:09:24 --> Input Class Initialized
INFO - 2016-03-03 14:09:24 --> Language Class Initialized
INFO - 2016-03-03 14:09:24 --> Loader Class Initialized
INFO - 2016-03-03 14:09:24 --> Helper loaded: url_helper
INFO - 2016-03-03 14:09:24 --> Helper loaded: file_helper
INFO - 2016-03-03 14:09:24 --> Helper loaded: date_helper
INFO - 2016-03-03 14:09:24 --> Helper loaded: form_helper
INFO - 2016-03-03 14:09:24 --> Database Driver Class Initialized
INFO - 2016-03-03 14:09:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:09:25 --> Controller Class Initialized
INFO - 2016-03-03 14:09:25 --> Model Class Initialized
INFO - 2016-03-03 14:09:25 --> Model Class Initialized
INFO - 2016-03-03 14:09:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:09:25 --> Pagination Class Initialized
INFO - 2016-03-03 14:09:25 --> Helper loaded: text_helper
INFO - 2016-03-03 14:09:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:09:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:09:25 --> Final output sent to browser
DEBUG - 2016-03-03 17:09:25 --> Total execution time: 1.1021
INFO - 2016-03-03 14:10:14 --> Config Class Initialized
INFO - 2016-03-03 14:10:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:10:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:10:14 --> Utf8 Class Initialized
INFO - 2016-03-03 14:10:14 --> URI Class Initialized
DEBUG - 2016-03-03 14:10:14 --> No URI present. Default controller set.
INFO - 2016-03-03 14:10:14 --> Router Class Initialized
INFO - 2016-03-03 14:10:14 --> Output Class Initialized
INFO - 2016-03-03 14:10:14 --> Security Class Initialized
DEBUG - 2016-03-03 14:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:10:14 --> Input Class Initialized
INFO - 2016-03-03 14:10:14 --> Language Class Initialized
INFO - 2016-03-03 14:10:14 --> Loader Class Initialized
INFO - 2016-03-03 14:10:14 --> Helper loaded: url_helper
INFO - 2016-03-03 14:10:14 --> Helper loaded: file_helper
INFO - 2016-03-03 14:10:14 --> Helper loaded: date_helper
INFO - 2016-03-03 14:10:14 --> Helper loaded: form_helper
INFO - 2016-03-03 14:10:14 --> Database Driver Class Initialized
INFO - 2016-03-03 14:10:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:10:15 --> Controller Class Initialized
INFO - 2016-03-03 14:10:15 --> Model Class Initialized
INFO - 2016-03-03 14:10:15 --> Model Class Initialized
INFO - 2016-03-03 14:10:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:10:15 --> Pagination Class Initialized
INFO - 2016-03-03 14:10:15 --> Helper loaded: text_helper
INFO - 2016-03-03 14:10:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:10:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:10:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:10:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:10:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:10:15 --> Final output sent to browser
DEBUG - 2016-03-03 17:10:15 --> Total execution time: 1.2028
INFO - 2016-03-03 14:11:16 --> Config Class Initialized
INFO - 2016-03-03 14:11:16 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:11:16 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:11:16 --> Utf8 Class Initialized
INFO - 2016-03-03 14:11:16 --> URI Class Initialized
DEBUG - 2016-03-03 14:11:16 --> No URI present. Default controller set.
INFO - 2016-03-03 14:11:16 --> Router Class Initialized
INFO - 2016-03-03 14:11:16 --> Output Class Initialized
INFO - 2016-03-03 14:11:16 --> Security Class Initialized
DEBUG - 2016-03-03 14:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:11:16 --> Input Class Initialized
INFO - 2016-03-03 14:11:16 --> Language Class Initialized
INFO - 2016-03-03 14:11:16 --> Loader Class Initialized
INFO - 2016-03-03 14:11:16 --> Helper loaded: url_helper
INFO - 2016-03-03 14:11:16 --> Helper loaded: file_helper
INFO - 2016-03-03 14:11:16 --> Helper loaded: date_helper
INFO - 2016-03-03 14:11:16 --> Helper loaded: form_helper
INFO - 2016-03-03 14:11:16 --> Database Driver Class Initialized
INFO - 2016-03-03 14:11:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:11:17 --> Controller Class Initialized
INFO - 2016-03-03 14:11:17 --> Model Class Initialized
INFO - 2016-03-03 14:11:17 --> Model Class Initialized
INFO - 2016-03-03 14:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:11:17 --> Pagination Class Initialized
INFO - 2016-03-03 14:11:17 --> Helper loaded: text_helper
INFO - 2016-03-03 14:11:17 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:11:17 --> Final output sent to browser
DEBUG - 2016-03-03 17:11:17 --> Total execution time: 1.1443
INFO - 2016-03-03 14:13:16 --> Config Class Initialized
INFO - 2016-03-03 14:13:16 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:13:16 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:13:16 --> Utf8 Class Initialized
INFO - 2016-03-03 14:13:16 --> URI Class Initialized
DEBUG - 2016-03-03 14:13:16 --> No URI present. Default controller set.
INFO - 2016-03-03 14:13:16 --> Router Class Initialized
INFO - 2016-03-03 14:13:16 --> Output Class Initialized
INFO - 2016-03-03 14:13:16 --> Security Class Initialized
DEBUG - 2016-03-03 14:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:13:16 --> Input Class Initialized
INFO - 2016-03-03 14:13:16 --> Language Class Initialized
INFO - 2016-03-03 14:13:16 --> Loader Class Initialized
INFO - 2016-03-03 14:13:16 --> Helper loaded: url_helper
INFO - 2016-03-03 14:13:16 --> Helper loaded: file_helper
INFO - 2016-03-03 14:13:16 --> Helper loaded: date_helper
INFO - 2016-03-03 14:13:16 --> Helper loaded: form_helper
INFO - 2016-03-03 14:13:16 --> Database Driver Class Initialized
INFO - 2016-03-03 14:13:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:13:17 --> Controller Class Initialized
INFO - 2016-03-03 14:13:17 --> Model Class Initialized
INFO - 2016-03-03 14:13:17 --> Model Class Initialized
INFO - 2016-03-03 14:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:13:17 --> Pagination Class Initialized
INFO - 2016-03-03 14:13:17 --> Helper loaded: text_helper
INFO - 2016-03-03 14:13:17 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:13:17 --> Final output sent to browser
DEBUG - 2016-03-03 17:13:17 --> Total execution time: 1.0922
INFO - 2016-03-03 14:14:00 --> Config Class Initialized
INFO - 2016-03-03 14:14:00 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:14:00 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:14:00 --> Utf8 Class Initialized
INFO - 2016-03-03 14:14:00 --> URI Class Initialized
DEBUG - 2016-03-03 14:14:00 --> No URI present. Default controller set.
INFO - 2016-03-03 14:14:00 --> Router Class Initialized
INFO - 2016-03-03 14:14:00 --> Output Class Initialized
INFO - 2016-03-03 14:14:00 --> Security Class Initialized
DEBUG - 2016-03-03 14:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:14:00 --> Input Class Initialized
INFO - 2016-03-03 14:14:00 --> Language Class Initialized
INFO - 2016-03-03 14:14:00 --> Loader Class Initialized
INFO - 2016-03-03 14:14:00 --> Helper loaded: url_helper
INFO - 2016-03-03 14:14:00 --> Helper loaded: file_helper
INFO - 2016-03-03 14:14:00 --> Helper loaded: date_helper
INFO - 2016-03-03 14:14:00 --> Helper loaded: form_helper
INFO - 2016-03-03 14:14:00 --> Database Driver Class Initialized
INFO - 2016-03-03 14:14:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:14:02 --> Controller Class Initialized
INFO - 2016-03-03 14:14:02 --> Model Class Initialized
INFO - 2016-03-03 14:14:02 --> Model Class Initialized
INFO - 2016-03-03 14:14:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:14:02 --> Pagination Class Initialized
INFO - 2016-03-03 14:14:02 --> Helper loaded: text_helper
INFO - 2016-03-03 14:14:02 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:14:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:14:02 --> Final output sent to browser
DEBUG - 2016-03-03 17:14:02 --> Total execution time: 1.1998
INFO - 2016-03-03 14:15:50 --> Config Class Initialized
INFO - 2016-03-03 14:15:50 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:15:50 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:15:50 --> Utf8 Class Initialized
INFO - 2016-03-03 14:15:50 --> URI Class Initialized
DEBUG - 2016-03-03 14:15:50 --> No URI present. Default controller set.
INFO - 2016-03-03 14:15:50 --> Router Class Initialized
INFO - 2016-03-03 14:15:50 --> Output Class Initialized
INFO - 2016-03-03 14:15:50 --> Security Class Initialized
DEBUG - 2016-03-03 14:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:15:50 --> Input Class Initialized
INFO - 2016-03-03 14:15:50 --> Language Class Initialized
INFO - 2016-03-03 14:15:50 --> Loader Class Initialized
INFO - 2016-03-03 14:15:51 --> Helper loaded: url_helper
INFO - 2016-03-03 14:15:51 --> Helper loaded: file_helper
INFO - 2016-03-03 14:15:51 --> Helper loaded: date_helper
INFO - 2016-03-03 14:15:51 --> Helper loaded: form_helper
INFO - 2016-03-03 14:15:51 --> Database Driver Class Initialized
INFO - 2016-03-03 14:15:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:15:52 --> Controller Class Initialized
INFO - 2016-03-03 14:15:52 --> Model Class Initialized
INFO - 2016-03-03 14:15:52 --> Model Class Initialized
INFO - 2016-03-03 14:15:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:15:52 --> Pagination Class Initialized
INFO - 2016-03-03 14:15:52 --> Helper loaded: text_helper
INFO - 2016-03-03 14:15:52 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:15:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:15:52 --> Final output sent to browser
DEBUG - 2016-03-03 17:15:52 --> Total execution time: 1.1508
INFO - 2016-03-03 14:16:01 --> Config Class Initialized
INFO - 2016-03-03 14:16:01 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:16:01 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:16:01 --> Utf8 Class Initialized
INFO - 2016-03-03 14:16:01 --> URI Class Initialized
DEBUG - 2016-03-03 14:16:01 --> No URI present. Default controller set.
INFO - 2016-03-03 14:16:01 --> Router Class Initialized
INFO - 2016-03-03 14:16:01 --> Output Class Initialized
INFO - 2016-03-03 14:16:01 --> Security Class Initialized
DEBUG - 2016-03-03 14:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:16:01 --> Input Class Initialized
INFO - 2016-03-03 14:16:02 --> Language Class Initialized
INFO - 2016-03-03 14:16:02 --> Loader Class Initialized
INFO - 2016-03-03 14:16:02 --> Helper loaded: url_helper
INFO - 2016-03-03 14:16:02 --> Helper loaded: file_helper
INFO - 2016-03-03 14:16:02 --> Helper loaded: date_helper
INFO - 2016-03-03 14:16:02 --> Helper loaded: form_helper
INFO - 2016-03-03 14:16:02 --> Database Driver Class Initialized
INFO - 2016-03-03 14:16:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:16:03 --> Controller Class Initialized
INFO - 2016-03-03 14:16:03 --> Model Class Initialized
INFO - 2016-03-03 14:16:03 --> Model Class Initialized
INFO - 2016-03-03 14:16:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:16:03 --> Pagination Class Initialized
INFO - 2016-03-03 14:16:03 --> Helper loaded: text_helper
INFO - 2016-03-03 14:16:03 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:16:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:16:03 --> Final output sent to browser
DEBUG - 2016-03-03 17:16:03 --> Total execution time: 1.1168
INFO - 2016-03-03 14:17:12 --> Config Class Initialized
INFO - 2016-03-03 14:17:12 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:17:12 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:17:12 --> Utf8 Class Initialized
INFO - 2016-03-03 14:17:12 --> URI Class Initialized
DEBUG - 2016-03-03 14:17:12 --> No URI present. Default controller set.
INFO - 2016-03-03 14:17:12 --> Router Class Initialized
INFO - 2016-03-03 14:17:12 --> Output Class Initialized
INFO - 2016-03-03 14:17:12 --> Security Class Initialized
DEBUG - 2016-03-03 14:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:17:12 --> Input Class Initialized
INFO - 2016-03-03 14:17:12 --> Language Class Initialized
INFO - 2016-03-03 14:17:12 --> Loader Class Initialized
INFO - 2016-03-03 14:17:12 --> Helper loaded: url_helper
INFO - 2016-03-03 14:17:12 --> Helper loaded: file_helper
INFO - 2016-03-03 14:17:12 --> Helper loaded: date_helper
INFO - 2016-03-03 14:17:12 --> Helper loaded: form_helper
INFO - 2016-03-03 14:17:12 --> Database Driver Class Initialized
INFO - 2016-03-03 14:17:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:17:13 --> Controller Class Initialized
INFO - 2016-03-03 14:17:13 --> Model Class Initialized
INFO - 2016-03-03 14:17:13 --> Model Class Initialized
INFO - 2016-03-03 14:17:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:17:13 --> Pagination Class Initialized
INFO - 2016-03-03 14:17:13 --> Helper loaded: text_helper
INFO - 2016-03-03 14:17:13 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:17:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:17:13 --> Final output sent to browser
DEBUG - 2016-03-03 17:17:13 --> Total execution time: 1.1746
INFO - 2016-03-03 14:17:32 --> Config Class Initialized
INFO - 2016-03-03 14:17:32 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:17:32 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:17:32 --> Utf8 Class Initialized
INFO - 2016-03-03 14:17:32 --> URI Class Initialized
DEBUG - 2016-03-03 14:17:32 --> No URI present. Default controller set.
INFO - 2016-03-03 14:17:32 --> Router Class Initialized
INFO - 2016-03-03 14:17:32 --> Output Class Initialized
INFO - 2016-03-03 14:17:32 --> Security Class Initialized
DEBUG - 2016-03-03 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:17:32 --> Input Class Initialized
INFO - 2016-03-03 14:17:32 --> Language Class Initialized
INFO - 2016-03-03 14:17:32 --> Loader Class Initialized
INFO - 2016-03-03 14:17:32 --> Helper loaded: url_helper
INFO - 2016-03-03 14:17:32 --> Helper loaded: file_helper
INFO - 2016-03-03 14:17:32 --> Helper loaded: date_helper
INFO - 2016-03-03 14:17:32 --> Helper loaded: form_helper
INFO - 2016-03-03 14:17:32 --> Database Driver Class Initialized
INFO - 2016-03-03 14:17:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:17:33 --> Controller Class Initialized
INFO - 2016-03-03 14:17:33 --> Model Class Initialized
INFO - 2016-03-03 14:17:33 --> Model Class Initialized
INFO - 2016-03-03 14:17:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:17:33 --> Pagination Class Initialized
INFO - 2016-03-03 14:17:33 --> Helper loaded: text_helper
INFO - 2016-03-03 14:17:33 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:17:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:17:33 --> Final output sent to browser
DEBUG - 2016-03-03 17:17:33 --> Total execution time: 1.1227
INFO - 2016-03-03 14:18:13 --> Config Class Initialized
INFO - 2016-03-03 14:18:13 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:18:13 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:18:13 --> Utf8 Class Initialized
INFO - 2016-03-03 14:18:13 --> URI Class Initialized
INFO - 2016-03-03 14:18:13 --> Router Class Initialized
INFO - 2016-03-03 14:18:13 --> Output Class Initialized
INFO - 2016-03-03 14:18:13 --> Security Class Initialized
DEBUG - 2016-03-03 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:18:13 --> Input Class Initialized
INFO - 2016-03-03 14:18:13 --> Language Class Initialized
INFO - 2016-03-03 14:18:13 --> Loader Class Initialized
INFO - 2016-03-03 14:18:13 --> Helper loaded: url_helper
INFO - 2016-03-03 14:18:13 --> Helper loaded: file_helper
INFO - 2016-03-03 14:18:13 --> Helper loaded: date_helper
INFO - 2016-03-03 14:18:13 --> Helper loaded: form_helper
INFO - 2016-03-03 14:18:13 --> Database Driver Class Initialized
INFO - 2016-03-03 14:18:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:18:14 --> Controller Class Initialized
INFO - 2016-03-03 14:18:14 --> Model Class Initialized
INFO - 2016-03-03 14:18:14 --> Model Class Initialized
INFO - 2016-03-03 14:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:18:14 --> Pagination Class Initialized
INFO - 2016-03-03 14:18:14 --> Helper loaded: text_helper
INFO - 2016-03-03 14:18:14 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:18:14 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:18:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:18:14 --> Final output sent to browser
DEBUG - 2016-03-03 17:18:14 --> Total execution time: 1.2247
INFO - 2016-03-03 14:22:45 --> Config Class Initialized
INFO - 2016-03-03 14:22:45 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:22:45 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:22:45 --> Utf8 Class Initialized
INFO - 2016-03-03 14:22:45 --> URI Class Initialized
INFO - 2016-03-03 14:22:45 --> Router Class Initialized
INFO - 2016-03-03 14:22:45 --> Output Class Initialized
INFO - 2016-03-03 14:22:45 --> Security Class Initialized
DEBUG - 2016-03-03 14:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:22:45 --> Input Class Initialized
INFO - 2016-03-03 14:22:45 --> Language Class Initialized
INFO - 2016-03-03 14:22:46 --> Loader Class Initialized
INFO - 2016-03-03 14:22:46 --> Helper loaded: url_helper
INFO - 2016-03-03 14:22:46 --> Helper loaded: file_helper
INFO - 2016-03-03 14:22:46 --> Helper loaded: date_helper
INFO - 2016-03-03 14:22:46 --> Helper loaded: form_helper
INFO - 2016-03-03 14:22:46 --> Database Driver Class Initialized
INFO - 2016-03-03 14:22:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:22:47 --> Controller Class Initialized
INFO - 2016-03-03 14:22:47 --> Model Class Initialized
INFO - 2016-03-03 14:22:47 --> Model Class Initialized
INFO - 2016-03-03 14:22:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:22:47 --> Pagination Class Initialized
INFO - 2016-03-03 14:22:47 --> Helper loaded: text_helper
INFO - 2016-03-03 14:22:47 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:22:47 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:22:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:22:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:22:47 --> Final output sent to browser
DEBUG - 2016-03-03 17:22:47 --> Total execution time: 1.1947
INFO - 2016-03-03 14:23:06 --> Config Class Initialized
INFO - 2016-03-03 14:23:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:23:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:23:06 --> Utf8 Class Initialized
INFO - 2016-03-03 14:23:06 --> URI Class Initialized
INFO - 2016-03-03 14:23:06 --> Router Class Initialized
INFO - 2016-03-03 14:23:06 --> Output Class Initialized
INFO - 2016-03-03 14:23:06 --> Security Class Initialized
DEBUG - 2016-03-03 14:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:23:06 --> Input Class Initialized
INFO - 2016-03-03 14:23:06 --> Language Class Initialized
INFO - 2016-03-03 14:23:06 --> Loader Class Initialized
INFO - 2016-03-03 14:23:06 --> Helper loaded: url_helper
INFO - 2016-03-03 14:23:06 --> Helper loaded: file_helper
INFO - 2016-03-03 14:23:06 --> Helper loaded: date_helper
INFO - 2016-03-03 14:23:06 --> Helper loaded: form_helper
INFO - 2016-03-03 14:23:06 --> Database Driver Class Initialized
INFO - 2016-03-03 14:23:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:23:07 --> Controller Class Initialized
INFO - 2016-03-03 14:23:07 --> Model Class Initialized
INFO - 2016-03-03 14:23:07 --> Model Class Initialized
INFO - 2016-03-03 14:23:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:23:07 --> Pagination Class Initialized
INFO - 2016-03-03 14:23:07 --> Helper loaded: text_helper
INFO - 2016-03-03 14:23:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:23:07 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:23:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:23:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:23:07 --> Final output sent to browser
DEBUG - 2016-03-03 17:23:07 --> Total execution time: 1.1383
INFO - 2016-03-03 14:24:05 --> Config Class Initialized
INFO - 2016-03-03 14:24:05 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:24:05 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:24:05 --> Utf8 Class Initialized
INFO - 2016-03-03 14:24:05 --> URI Class Initialized
INFO - 2016-03-03 14:24:05 --> Router Class Initialized
INFO - 2016-03-03 14:24:05 --> Output Class Initialized
INFO - 2016-03-03 14:24:05 --> Security Class Initialized
DEBUG - 2016-03-03 14:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:24:05 --> Input Class Initialized
INFO - 2016-03-03 14:24:05 --> Language Class Initialized
INFO - 2016-03-03 14:24:05 --> Loader Class Initialized
INFO - 2016-03-03 14:24:05 --> Helper loaded: url_helper
INFO - 2016-03-03 14:24:05 --> Helper loaded: file_helper
INFO - 2016-03-03 14:24:05 --> Helper loaded: date_helper
INFO - 2016-03-03 14:24:05 --> Helper loaded: form_helper
INFO - 2016-03-03 14:24:05 --> Database Driver Class Initialized
INFO - 2016-03-03 14:24:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:24:06 --> Controller Class Initialized
INFO - 2016-03-03 14:24:06 --> Model Class Initialized
INFO - 2016-03-03 14:24:06 --> Model Class Initialized
INFO - 2016-03-03 14:24:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:24:06 --> Pagination Class Initialized
INFO - 2016-03-03 14:24:06 --> Helper loaded: text_helper
INFO - 2016-03-03 14:24:06 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:24:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:24:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:24:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:24:06 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:24:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:24:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:24:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:24:06 --> Final output sent to browser
DEBUG - 2016-03-03 17:24:06 --> Total execution time: 1.1517
INFO - 2016-03-03 14:24:29 --> Config Class Initialized
INFO - 2016-03-03 14:24:29 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:24:29 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:24:29 --> Utf8 Class Initialized
INFO - 2016-03-03 14:24:29 --> URI Class Initialized
INFO - 2016-03-03 14:24:29 --> Router Class Initialized
INFO - 2016-03-03 14:24:29 --> Output Class Initialized
INFO - 2016-03-03 14:24:29 --> Security Class Initialized
DEBUG - 2016-03-03 14:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:24:29 --> Input Class Initialized
INFO - 2016-03-03 14:24:29 --> Language Class Initialized
INFO - 2016-03-03 14:24:29 --> Loader Class Initialized
INFO - 2016-03-03 14:24:29 --> Helper loaded: url_helper
INFO - 2016-03-03 14:24:29 --> Helper loaded: file_helper
INFO - 2016-03-03 14:24:29 --> Helper loaded: date_helper
INFO - 2016-03-03 14:24:29 --> Helper loaded: form_helper
INFO - 2016-03-03 14:24:29 --> Database Driver Class Initialized
INFO - 2016-03-03 14:24:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:24:30 --> Controller Class Initialized
INFO - 2016-03-03 14:24:30 --> Model Class Initialized
INFO - 2016-03-03 14:24:30 --> Model Class Initialized
INFO - 2016-03-03 14:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:24:30 --> Pagination Class Initialized
INFO - 2016-03-03 14:24:30 --> Helper loaded: text_helper
INFO - 2016-03-03 14:24:30 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:24:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:24:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:24:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:24:30 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:24:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:24:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:24:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:24:30 --> Final output sent to browser
DEBUG - 2016-03-03 17:24:30 --> Total execution time: 1.1647
INFO - 2016-03-03 14:24:56 --> Config Class Initialized
INFO - 2016-03-03 14:24:56 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:24:56 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:24:56 --> Utf8 Class Initialized
INFO - 2016-03-03 14:24:56 --> URI Class Initialized
INFO - 2016-03-03 14:24:56 --> Router Class Initialized
INFO - 2016-03-03 14:24:56 --> Output Class Initialized
INFO - 2016-03-03 14:24:56 --> Security Class Initialized
DEBUG - 2016-03-03 14:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:24:56 --> Input Class Initialized
INFO - 2016-03-03 14:24:56 --> Language Class Initialized
INFO - 2016-03-03 14:24:56 --> Loader Class Initialized
INFO - 2016-03-03 14:24:56 --> Helper loaded: url_helper
INFO - 2016-03-03 14:24:56 --> Helper loaded: file_helper
INFO - 2016-03-03 14:24:56 --> Helper loaded: date_helper
INFO - 2016-03-03 14:24:56 --> Helper loaded: form_helper
INFO - 2016-03-03 14:24:56 --> Database Driver Class Initialized
INFO - 2016-03-03 14:24:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:24:57 --> Controller Class Initialized
INFO - 2016-03-03 14:24:57 --> Model Class Initialized
INFO - 2016-03-03 14:24:57 --> Model Class Initialized
INFO - 2016-03-03 14:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:24:57 --> Pagination Class Initialized
INFO - 2016-03-03 14:24:57 --> Helper loaded: text_helper
INFO - 2016-03-03 14:24:57 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:24:57 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:24:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:24:57 --> Final output sent to browser
DEBUG - 2016-03-03 17:24:57 --> Total execution time: 1.1356
INFO - 2016-03-03 14:28:43 --> Config Class Initialized
INFO - 2016-03-03 14:28:43 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:28:43 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:28:43 --> Utf8 Class Initialized
INFO - 2016-03-03 14:28:43 --> URI Class Initialized
INFO - 2016-03-03 14:28:43 --> Router Class Initialized
INFO - 2016-03-03 14:28:43 --> Output Class Initialized
INFO - 2016-03-03 14:28:43 --> Security Class Initialized
DEBUG - 2016-03-03 14:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:28:43 --> Input Class Initialized
INFO - 2016-03-03 14:28:43 --> Language Class Initialized
INFO - 2016-03-03 14:28:43 --> Loader Class Initialized
INFO - 2016-03-03 14:28:43 --> Helper loaded: url_helper
INFO - 2016-03-03 14:28:43 --> Helper loaded: file_helper
INFO - 2016-03-03 14:28:43 --> Helper loaded: date_helper
INFO - 2016-03-03 14:28:43 --> Helper loaded: form_helper
INFO - 2016-03-03 14:28:43 --> Database Driver Class Initialized
INFO - 2016-03-03 14:28:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:28:44 --> Controller Class Initialized
INFO - 2016-03-03 14:28:44 --> Model Class Initialized
INFO - 2016-03-03 14:28:44 --> Model Class Initialized
INFO - 2016-03-03 14:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:28:44 --> Pagination Class Initialized
INFO - 2016-03-03 14:28:44 --> Helper loaded: text_helper
INFO - 2016-03-03 14:28:44 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:28:44 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:28:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:28:44 --> Final output sent to browser
DEBUG - 2016-03-03 17:28:44 --> Total execution time: 1.1898
INFO - 2016-03-03 14:29:06 --> Config Class Initialized
INFO - 2016-03-03 14:29:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:29:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:29:06 --> Utf8 Class Initialized
INFO - 2016-03-03 14:29:06 --> URI Class Initialized
INFO - 2016-03-03 14:29:06 --> Router Class Initialized
INFO - 2016-03-03 14:29:06 --> Output Class Initialized
INFO - 2016-03-03 14:29:06 --> Security Class Initialized
DEBUG - 2016-03-03 14:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:29:06 --> Input Class Initialized
INFO - 2016-03-03 14:29:06 --> Language Class Initialized
INFO - 2016-03-03 14:29:06 --> Loader Class Initialized
INFO - 2016-03-03 14:29:06 --> Helper loaded: url_helper
INFO - 2016-03-03 14:29:06 --> Helper loaded: file_helper
INFO - 2016-03-03 14:29:06 --> Helper loaded: date_helper
INFO - 2016-03-03 14:29:06 --> Helper loaded: form_helper
INFO - 2016-03-03 14:29:06 --> Database Driver Class Initialized
INFO - 2016-03-03 14:29:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:29:07 --> Controller Class Initialized
INFO - 2016-03-03 14:29:07 --> Model Class Initialized
INFO - 2016-03-03 14:29:07 --> Model Class Initialized
INFO - 2016-03-03 14:29:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:29:07 --> Pagination Class Initialized
INFO - 2016-03-03 14:29:07 --> Helper loaded: text_helper
INFO - 2016-03-03 14:29:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:29:07 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:29:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:29:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:29:07 --> Final output sent to browser
DEBUG - 2016-03-03 17:29:07 --> Total execution time: 1.1879
INFO - 2016-03-03 14:30:23 --> Config Class Initialized
INFO - 2016-03-03 14:30:23 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:30:23 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:30:23 --> Utf8 Class Initialized
INFO - 2016-03-03 14:30:23 --> URI Class Initialized
INFO - 2016-03-03 14:30:23 --> Router Class Initialized
INFO - 2016-03-03 14:30:23 --> Output Class Initialized
INFO - 2016-03-03 14:30:23 --> Security Class Initialized
DEBUG - 2016-03-03 14:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:30:23 --> Input Class Initialized
INFO - 2016-03-03 14:30:23 --> Language Class Initialized
INFO - 2016-03-03 14:30:23 --> Loader Class Initialized
INFO - 2016-03-03 14:30:23 --> Helper loaded: url_helper
INFO - 2016-03-03 14:30:23 --> Helper loaded: file_helper
INFO - 2016-03-03 14:30:23 --> Helper loaded: date_helper
INFO - 2016-03-03 14:30:23 --> Helper loaded: form_helper
INFO - 2016-03-03 14:30:23 --> Database Driver Class Initialized
INFO - 2016-03-03 14:30:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:30:24 --> Controller Class Initialized
INFO - 2016-03-03 14:30:24 --> Model Class Initialized
INFO - 2016-03-03 14:30:24 --> Model Class Initialized
INFO - 2016-03-03 14:30:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:30:24 --> Pagination Class Initialized
INFO - 2016-03-03 14:30:24 --> Helper loaded: text_helper
INFO - 2016-03-03 14:30:24 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:30:24 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:30:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:30:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:30:24 --> Final output sent to browser
DEBUG - 2016-03-03 17:30:24 --> Total execution time: 1.1709
INFO - 2016-03-03 14:32:13 --> Config Class Initialized
INFO - 2016-03-03 14:32:13 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:32:13 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:32:13 --> Utf8 Class Initialized
INFO - 2016-03-03 14:32:13 --> URI Class Initialized
INFO - 2016-03-03 14:32:13 --> Router Class Initialized
INFO - 2016-03-03 14:32:13 --> Output Class Initialized
INFO - 2016-03-03 14:32:13 --> Security Class Initialized
DEBUG - 2016-03-03 14:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:32:13 --> Input Class Initialized
INFO - 2016-03-03 14:32:13 --> Language Class Initialized
INFO - 2016-03-03 14:32:13 --> Loader Class Initialized
INFO - 2016-03-03 14:32:13 --> Helper loaded: url_helper
INFO - 2016-03-03 14:32:13 --> Helper loaded: file_helper
INFO - 2016-03-03 14:32:13 --> Helper loaded: date_helper
INFO - 2016-03-03 14:32:13 --> Helper loaded: form_helper
INFO - 2016-03-03 14:32:13 --> Database Driver Class Initialized
INFO - 2016-03-03 14:32:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:32:14 --> Controller Class Initialized
INFO - 2016-03-03 14:32:14 --> Model Class Initialized
INFO - 2016-03-03 14:32:14 --> Model Class Initialized
INFO - 2016-03-03 14:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:32:14 --> Pagination Class Initialized
INFO - 2016-03-03 14:32:14 --> Helper loaded: text_helper
INFO - 2016-03-03 14:32:14 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:32:14 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:32:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:32:14 --> Final output sent to browser
DEBUG - 2016-03-03 17:32:14 --> Total execution time: 1.1779
INFO - 2016-03-03 14:32:28 --> Config Class Initialized
INFO - 2016-03-03 14:32:28 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:32:28 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:32:28 --> Utf8 Class Initialized
INFO - 2016-03-03 14:32:28 --> URI Class Initialized
INFO - 2016-03-03 14:32:28 --> Router Class Initialized
INFO - 2016-03-03 14:32:28 --> Output Class Initialized
INFO - 2016-03-03 14:32:28 --> Security Class Initialized
DEBUG - 2016-03-03 14:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:32:28 --> Input Class Initialized
INFO - 2016-03-03 14:32:28 --> Language Class Initialized
INFO - 2016-03-03 14:32:28 --> Loader Class Initialized
INFO - 2016-03-03 14:32:28 --> Helper loaded: url_helper
INFO - 2016-03-03 14:32:28 --> Helper loaded: file_helper
INFO - 2016-03-03 14:32:28 --> Helper loaded: date_helper
INFO - 2016-03-03 14:32:28 --> Helper loaded: form_helper
INFO - 2016-03-03 14:32:28 --> Database Driver Class Initialized
INFO - 2016-03-03 14:32:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:32:29 --> Controller Class Initialized
INFO - 2016-03-03 14:32:29 --> Model Class Initialized
INFO - 2016-03-03 14:32:29 --> Model Class Initialized
INFO - 2016-03-03 14:32:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:32:29 --> Pagination Class Initialized
INFO - 2016-03-03 14:32:29 --> Helper loaded: text_helper
INFO - 2016-03-03 14:32:29 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:32:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:32:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:32:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:32:29 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:32:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:32:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:32:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:32:29 --> Final output sent to browser
DEBUG - 2016-03-03 17:32:29 --> Total execution time: 1.1422
INFO - 2016-03-03 14:33:54 --> Config Class Initialized
INFO - 2016-03-03 14:33:54 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:33:54 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:33:54 --> Utf8 Class Initialized
INFO - 2016-03-03 14:33:54 --> URI Class Initialized
INFO - 2016-03-03 14:33:54 --> Router Class Initialized
INFO - 2016-03-03 14:33:54 --> Output Class Initialized
INFO - 2016-03-03 14:33:54 --> Security Class Initialized
DEBUG - 2016-03-03 14:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:33:54 --> Input Class Initialized
INFO - 2016-03-03 14:33:54 --> Language Class Initialized
INFO - 2016-03-03 14:33:54 --> Loader Class Initialized
INFO - 2016-03-03 14:33:54 --> Helper loaded: url_helper
INFO - 2016-03-03 14:33:54 --> Helper loaded: file_helper
INFO - 2016-03-03 14:33:54 --> Helper loaded: date_helper
INFO - 2016-03-03 14:33:54 --> Helper loaded: form_helper
INFO - 2016-03-03 14:33:54 --> Database Driver Class Initialized
INFO - 2016-03-03 14:33:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:33:55 --> Controller Class Initialized
INFO - 2016-03-03 14:33:55 --> Model Class Initialized
INFO - 2016-03-03 14:33:55 --> Model Class Initialized
INFO - 2016-03-03 14:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:33:55 --> Pagination Class Initialized
INFO - 2016-03-03 14:33:55 --> Helper loaded: text_helper
INFO - 2016-03-03 14:33:55 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:33:55 --> Final output sent to browser
DEBUG - 2016-03-03 17:33:55 --> Total execution time: 1.1631
INFO - 2016-03-03 14:34:30 --> Config Class Initialized
INFO - 2016-03-03 14:34:30 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:34:30 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:34:30 --> Utf8 Class Initialized
INFO - 2016-03-03 14:34:30 --> URI Class Initialized
INFO - 2016-03-03 14:34:30 --> Router Class Initialized
INFO - 2016-03-03 14:34:30 --> Output Class Initialized
INFO - 2016-03-03 14:34:30 --> Security Class Initialized
DEBUG - 2016-03-03 14:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:34:30 --> Input Class Initialized
INFO - 2016-03-03 14:34:30 --> Language Class Initialized
INFO - 2016-03-03 14:34:30 --> Loader Class Initialized
INFO - 2016-03-03 14:34:30 --> Helper loaded: url_helper
INFO - 2016-03-03 14:34:30 --> Helper loaded: file_helper
INFO - 2016-03-03 14:34:30 --> Helper loaded: date_helper
INFO - 2016-03-03 14:34:30 --> Helper loaded: form_helper
INFO - 2016-03-03 14:34:30 --> Database Driver Class Initialized
INFO - 2016-03-03 14:34:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:34:31 --> Controller Class Initialized
INFO - 2016-03-03 14:34:31 --> Model Class Initialized
INFO - 2016-03-03 14:34:31 --> Model Class Initialized
INFO - 2016-03-03 14:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:34:31 --> Pagination Class Initialized
INFO - 2016-03-03 14:34:31 --> Helper loaded: text_helper
INFO - 2016-03-03 14:34:31 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:34:31 --> Final output sent to browser
DEBUG - 2016-03-03 17:34:31 --> Total execution time: 1.2036
INFO - 2016-03-03 14:36:25 --> Config Class Initialized
INFO - 2016-03-03 14:36:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:36:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:36:25 --> Utf8 Class Initialized
INFO - 2016-03-03 14:36:25 --> URI Class Initialized
INFO - 2016-03-03 14:36:25 --> Router Class Initialized
INFO - 2016-03-03 14:36:25 --> Output Class Initialized
INFO - 2016-03-03 14:36:25 --> Security Class Initialized
DEBUG - 2016-03-03 14:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:36:25 --> Input Class Initialized
INFO - 2016-03-03 14:36:25 --> Language Class Initialized
INFO - 2016-03-03 14:36:25 --> Loader Class Initialized
INFO - 2016-03-03 14:36:25 --> Helper loaded: url_helper
INFO - 2016-03-03 14:36:25 --> Helper loaded: file_helper
INFO - 2016-03-03 14:36:25 --> Helper loaded: date_helper
INFO - 2016-03-03 14:36:25 --> Helper loaded: form_helper
INFO - 2016-03-03 14:36:25 --> Database Driver Class Initialized
INFO - 2016-03-03 14:36:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:36:26 --> Controller Class Initialized
INFO - 2016-03-03 14:36:26 --> Model Class Initialized
INFO - 2016-03-03 14:36:26 --> Model Class Initialized
INFO - 2016-03-03 14:36:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:36:26 --> Pagination Class Initialized
INFO - 2016-03-03 14:36:26 --> Helper loaded: text_helper
INFO - 2016-03-03 14:36:26 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-03 17:36:26 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
INFO - 2016-03-03 14:36:53 --> Config Class Initialized
INFO - 2016-03-03 14:36:53 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:36:53 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:36:53 --> Utf8 Class Initialized
INFO - 2016-03-03 14:36:53 --> URI Class Initialized
INFO - 2016-03-03 14:36:53 --> Router Class Initialized
INFO - 2016-03-03 14:36:53 --> Output Class Initialized
INFO - 2016-03-03 14:36:53 --> Security Class Initialized
DEBUG - 2016-03-03 14:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:36:53 --> Input Class Initialized
INFO - 2016-03-03 14:36:53 --> Language Class Initialized
INFO - 2016-03-03 14:36:53 --> Loader Class Initialized
INFO - 2016-03-03 14:36:53 --> Helper loaded: url_helper
INFO - 2016-03-03 14:36:53 --> Helper loaded: file_helper
INFO - 2016-03-03 14:36:53 --> Helper loaded: date_helper
INFO - 2016-03-03 14:36:53 --> Helper loaded: form_helper
INFO - 2016-03-03 14:36:53 --> Database Driver Class Initialized
INFO - 2016-03-03 14:36:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:36:54 --> Controller Class Initialized
INFO - 2016-03-03 14:36:54 --> Model Class Initialized
INFO - 2016-03-03 14:36:54 --> Model Class Initialized
INFO - 2016-03-03 14:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:36:54 --> Pagination Class Initialized
INFO - 2016-03-03 14:36:54 --> Helper loaded: text_helper
INFO - 2016-03-03 14:36:55 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:36:55 --> Final output sent to browser
DEBUG - 2016-03-03 17:36:55 --> Total execution time: 1.2153
INFO - 2016-03-03 14:36:59 --> Config Class Initialized
INFO - 2016-03-03 14:36:59 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:36:59 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:36:59 --> Utf8 Class Initialized
INFO - 2016-03-03 14:36:59 --> URI Class Initialized
INFO - 2016-03-03 14:36:59 --> Router Class Initialized
INFO - 2016-03-03 14:36:59 --> Output Class Initialized
INFO - 2016-03-03 14:36:59 --> Security Class Initialized
DEBUG - 2016-03-03 14:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:36:59 --> Input Class Initialized
INFO - 2016-03-03 14:36:59 --> Language Class Initialized
INFO - 2016-03-03 14:36:59 --> Loader Class Initialized
INFO - 2016-03-03 14:36:59 --> Helper loaded: url_helper
INFO - 2016-03-03 14:36:59 --> Helper loaded: file_helper
INFO - 2016-03-03 14:36:59 --> Helper loaded: date_helper
INFO - 2016-03-03 14:36:59 --> Helper loaded: form_helper
INFO - 2016-03-03 14:36:59 --> Database Driver Class Initialized
INFO - 2016-03-03 14:37:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:37:00 --> Controller Class Initialized
INFO - 2016-03-03 14:37:00 --> Model Class Initialized
INFO - 2016-03-03 14:37:00 --> Model Class Initialized
INFO - 2016-03-03 14:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:37:00 --> Pagination Class Initialized
INFO - 2016-03-03 14:37:00 --> Helper loaded: text_helper
INFO - 2016-03-03 14:37:00 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-03 17:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:37:00 --> Final output sent to browser
DEBUG - 2016-03-03 17:37:00 --> Total execution time: 1.2335
INFO - 2016-03-03 14:37:06 --> Config Class Initialized
INFO - 2016-03-03 14:37:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:37:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:37:06 --> Utf8 Class Initialized
INFO - 2016-03-03 14:37:06 --> URI Class Initialized
INFO - 2016-03-03 14:37:06 --> Router Class Initialized
INFO - 2016-03-03 14:37:06 --> Output Class Initialized
INFO - 2016-03-03 14:37:06 --> Security Class Initialized
DEBUG - 2016-03-03 14:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:37:06 --> Input Class Initialized
INFO - 2016-03-03 14:37:06 --> Language Class Initialized
INFO - 2016-03-03 14:37:06 --> Loader Class Initialized
INFO - 2016-03-03 14:37:06 --> Helper loaded: url_helper
INFO - 2016-03-03 14:37:06 --> Helper loaded: file_helper
INFO - 2016-03-03 14:37:06 --> Helper loaded: date_helper
INFO - 2016-03-03 14:37:06 --> Helper loaded: form_helper
INFO - 2016-03-03 14:37:06 --> Database Driver Class Initialized
INFO - 2016-03-03 14:37:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:37:07 --> Controller Class Initialized
INFO - 2016-03-03 14:37:07 --> Model Class Initialized
INFO - 2016-03-03 14:37:07 --> Model Class Initialized
INFO - 2016-03-03 14:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:37:07 --> Pagination Class Initialized
INFO - 2016-03-03 14:37:07 --> Helper loaded: text_helper
INFO - 2016-03-03 14:37:07 --> Helper loaded: cookie_helper
ERROR - 2016-03-03 17:37:07 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 175
INFO - 2016-03-03 14:37:08 --> Config Class Initialized
INFO - 2016-03-03 14:37:08 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:37:08 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:37:08 --> Utf8 Class Initialized
INFO - 2016-03-03 14:37:08 --> URI Class Initialized
INFO - 2016-03-03 14:37:08 --> Router Class Initialized
INFO - 2016-03-03 14:37:08 --> Output Class Initialized
INFO - 2016-03-03 14:37:08 --> Security Class Initialized
DEBUG - 2016-03-03 14:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:37:08 --> Input Class Initialized
INFO - 2016-03-03 14:37:08 --> Language Class Initialized
INFO - 2016-03-03 14:37:08 --> Loader Class Initialized
INFO - 2016-03-03 14:37:08 --> Helper loaded: url_helper
INFO - 2016-03-03 14:37:08 --> Helper loaded: file_helper
INFO - 2016-03-03 14:37:08 --> Helper loaded: date_helper
INFO - 2016-03-03 14:37:08 --> Helper loaded: form_helper
INFO - 2016-03-03 14:37:08 --> Database Driver Class Initialized
INFO - 2016-03-03 14:37:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:37:09 --> Controller Class Initialized
INFO - 2016-03-03 14:37:09 --> Model Class Initialized
INFO - 2016-03-03 14:37:09 --> Model Class Initialized
INFO - 2016-03-03 14:37:09 --> Form Validation Class Initialized
INFO - 2016-03-03 14:37:09 --> Helper loaded: text_helper
INFO - 2016-03-03 14:37:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:37:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:37:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-03-03 14:37:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:37:09 --> Final output sent to browser
DEBUG - 2016-03-03 14:37:09 --> Total execution time: 1.2579
INFO - 2016-03-03 14:37:43 --> Config Class Initialized
INFO - 2016-03-03 14:37:43 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:37:43 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:37:43 --> Utf8 Class Initialized
INFO - 2016-03-03 14:37:43 --> URI Class Initialized
INFO - 2016-03-03 14:37:43 --> Router Class Initialized
INFO - 2016-03-03 14:37:43 --> Output Class Initialized
INFO - 2016-03-03 14:37:43 --> Security Class Initialized
DEBUG - 2016-03-03 14:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:37:43 --> Input Class Initialized
INFO - 2016-03-03 14:37:43 --> Language Class Initialized
INFO - 2016-03-03 14:37:43 --> Loader Class Initialized
INFO - 2016-03-03 14:37:43 --> Helper loaded: url_helper
INFO - 2016-03-03 14:37:43 --> Helper loaded: file_helper
INFO - 2016-03-03 14:37:43 --> Helper loaded: date_helper
INFO - 2016-03-03 14:37:43 --> Helper loaded: form_helper
INFO - 2016-03-03 14:37:43 --> Database Driver Class Initialized
INFO - 2016-03-03 14:37:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:37:44 --> Controller Class Initialized
INFO - 2016-03-03 14:37:44 --> Model Class Initialized
INFO - 2016-03-03 14:37:44 --> Model Class Initialized
INFO - 2016-03-03 14:37:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:37:44 --> Pagination Class Initialized
INFO - 2016-03-03 14:37:44 --> Helper loaded: text_helper
INFO - 2016-03-03 14:37:44 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-03 17:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:37:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:37:44 --> Final output sent to browser
DEBUG - 2016-03-03 17:37:44 --> Total execution time: 1.1283
INFO - 2016-03-03 14:37:50 --> Config Class Initialized
INFO - 2016-03-03 14:37:50 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:37:50 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:37:50 --> Utf8 Class Initialized
INFO - 2016-03-03 14:37:50 --> URI Class Initialized
DEBUG - 2016-03-03 14:37:50 --> No URI present. Default controller set.
INFO - 2016-03-03 14:37:50 --> Router Class Initialized
INFO - 2016-03-03 14:37:50 --> Output Class Initialized
INFO - 2016-03-03 14:37:50 --> Security Class Initialized
DEBUG - 2016-03-03 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:37:50 --> Input Class Initialized
INFO - 2016-03-03 14:37:50 --> Language Class Initialized
INFO - 2016-03-03 14:37:50 --> Loader Class Initialized
INFO - 2016-03-03 14:37:50 --> Helper loaded: url_helper
INFO - 2016-03-03 14:37:50 --> Helper loaded: file_helper
INFO - 2016-03-03 14:37:50 --> Helper loaded: date_helper
INFO - 2016-03-03 14:37:50 --> Helper loaded: form_helper
INFO - 2016-03-03 14:37:50 --> Database Driver Class Initialized
INFO - 2016-03-03 14:37:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:37:51 --> Controller Class Initialized
INFO - 2016-03-03 14:37:51 --> Model Class Initialized
INFO - 2016-03-03 14:37:51 --> Model Class Initialized
INFO - 2016-03-03 14:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:37:51 --> Pagination Class Initialized
INFO - 2016-03-03 14:37:51 --> Helper loaded: text_helper
INFO - 2016-03-03 14:37:51 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:37:51 --> Final output sent to browser
DEBUG - 2016-03-03 17:37:51 --> Total execution time: 1.1341
INFO - 2016-03-03 14:38:03 --> Config Class Initialized
INFO - 2016-03-03 14:38:03 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:38:03 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:38:03 --> Utf8 Class Initialized
INFO - 2016-03-03 14:38:03 --> URI Class Initialized
INFO - 2016-03-03 14:38:03 --> Router Class Initialized
INFO - 2016-03-03 14:38:03 --> Output Class Initialized
INFO - 2016-03-03 14:38:03 --> Security Class Initialized
DEBUG - 2016-03-03 14:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:38:03 --> Input Class Initialized
INFO - 2016-03-03 14:38:03 --> Language Class Initialized
INFO - 2016-03-03 14:38:03 --> Loader Class Initialized
INFO - 2016-03-03 14:38:03 --> Helper loaded: url_helper
INFO - 2016-03-03 14:38:03 --> Helper loaded: file_helper
INFO - 2016-03-03 14:38:03 --> Helper loaded: date_helper
INFO - 2016-03-03 14:38:03 --> Helper loaded: form_helper
INFO - 2016-03-03 14:38:03 --> Database Driver Class Initialized
INFO - 2016-03-03 14:38:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:38:04 --> Controller Class Initialized
INFO - 2016-03-03 14:38:04 --> Model Class Initialized
INFO - 2016-03-03 14:38:04 --> Model Class Initialized
INFO - 2016-03-03 14:38:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:38:04 --> Pagination Class Initialized
INFO - 2016-03-03 14:38:04 --> Helper loaded: text_helper
INFO - 2016-03-03 14:38:04 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:38:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:38:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:38:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:38:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:38:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:38:04 --> Final output sent to browser
DEBUG - 2016-03-03 17:38:04 --> Total execution time: 1.2544
INFO - 2016-03-03 14:38:07 --> Config Class Initialized
INFO - 2016-03-03 14:38:07 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:38:07 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:38:07 --> Utf8 Class Initialized
INFO - 2016-03-03 14:38:07 --> URI Class Initialized
INFO - 2016-03-03 14:38:07 --> Router Class Initialized
INFO - 2016-03-03 14:38:07 --> Output Class Initialized
INFO - 2016-03-03 14:38:07 --> Security Class Initialized
DEBUG - 2016-03-03 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:38:07 --> Input Class Initialized
INFO - 2016-03-03 14:38:07 --> Language Class Initialized
INFO - 2016-03-03 14:38:07 --> Loader Class Initialized
INFO - 2016-03-03 14:38:07 --> Helper loaded: url_helper
INFO - 2016-03-03 14:38:07 --> Helper loaded: file_helper
INFO - 2016-03-03 14:38:07 --> Helper loaded: date_helper
INFO - 2016-03-03 14:38:07 --> Helper loaded: form_helper
INFO - 2016-03-03 14:38:07 --> Database Driver Class Initialized
INFO - 2016-03-03 14:38:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:38:08 --> Controller Class Initialized
INFO - 2016-03-03 14:38:08 --> Model Class Initialized
INFO - 2016-03-03 14:38:08 --> Model Class Initialized
INFO - 2016-03-03 14:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:38:08 --> Pagination Class Initialized
INFO - 2016-03-03 14:38:08 --> Helper loaded: text_helper
INFO - 2016-03-03 14:38:08 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-03 17:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:38:08 --> Final output sent to browser
DEBUG - 2016-03-03 17:38:08 --> Total execution time: 1.1517
INFO - 2016-03-03 14:38:22 --> Config Class Initialized
INFO - 2016-03-03 14:38:22 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:38:22 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:38:22 --> Utf8 Class Initialized
INFO - 2016-03-03 14:38:22 --> URI Class Initialized
INFO - 2016-03-03 14:38:22 --> Router Class Initialized
INFO - 2016-03-03 14:38:22 --> Output Class Initialized
INFO - 2016-03-03 14:38:22 --> Security Class Initialized
DEBUG - 2016-03-03 14:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:38:22 --> Input Class Initialized
INFO - 2016-03-03 14:38:22 --> Language Class Initialized
INFO - 2016-03-03 14:38:22 --> Loader Class Initialized
INFO - 2016-03-03 14:38:22 --> Helper loaded: url_helper
INFO - 2016-03-03 14:38:22 --> Helper loaded: file_helper
INFO - 2016-03-03 14:38:22 --> Helper loaded: date_helper
INFO - 2016-03-03 14:38:22 --> Helper loaded: form_helper
INFO - 2016-03-03 14:38:22 --> Database Driver Class Initialized
INFO - 2016-03-03 14:38:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:38:23 --> Controller Class Initialized
INFO - 2016-03-03 14:38:23 --> Model Class Initialized
INFO - 2016-03-03 14:38:23 --> Model Class Initialized
INFO - 2016-03-03 14:38:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:38:23 --> Pagination Class Initialized
INFO - 2016-03-03 14:38:23 --> Helper loaded: text_helper
INFO - 2016-03-03 14:38:23 --> Helper loaded: cookie_helper
ERROR - 2016-03-03 17:38:23 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 175
INFO - 2016-03-03 14:38:23 --> Config Class Initialized
INFO - 2016-03-03 14:38:23 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:38:23 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:38:23 --> Utf8 Class Initialized
INFO - 2016-03-03 14:38:23 --> URI Class Initialized
INFO - 2016-03-03 14:38:23 --> Router Class Initialized
INFO - 2016-03-03 14:38:23 --> Output Class Initialized
INFO - 2016-03-03 14:38:23 --> Security Class Initialized
DEBUG - 2016-03-03 14:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:38:23 --> Input Class Initialized
INFO - 2016-03-03 14:38:23 --> Language Class Initialized
INFO - 2016-03-03 14:38:23 --> Loader Class Initialized
INFO - 2016-03-03 14:38:23 --> Helper loaded: url_helper
INFO - 2016-03-03 14:38:23 --> Helper loaded: file_helper
INFO - 2016-03-03 14:38:23 --> Helper loaded: date_helper
INFO - 2016-03-03 14:38:23 --> Helper loaded: form_helper
INFO - 2016-03-03 14:38:23 --> Database Driver Class Initialized
INFO - 2016-03-03 14:38:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:38:24 --> Controller Class Initialized
INFO - 2016-03-03 14:38:24 --> Model Class Initialized
INFO - 2016-03-03 14:38:24 --> Model Class Initialized
INFO - 2016-03-03 14:38:24 --> Form Validation Class Initialized
INFO - 2016-03-03 14:38:24 --> Helper loaded: text_helper
INFO - 2016-03-03 14:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 14:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 14:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-03-03 14:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 14:38:24 --> Final output sent to browser
DEBUG - 2016-03-03 14:38:24 --> Total execution time: 1.1425
INFO - 2016-03-03 14:39:06 --> Config Class Initialized
INFO - 2016-03-03 14:39:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:39:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:39:06 --> Utf8 Class Initialized
INFO - 2016-03-03 14:39:06 --> URI Class Initialized
INFO - 2016-03-03 14:39:06 --> Router Class Initialized
INFO - 2016-03-03 14:39:06 --> Output Class Initialized
INFO - 2016-03-03 14:39:06 --> Security Class Initialized
DEBUG - 2016-03-03 14:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:39:06 --> Input Class Initialized
INFO - 2016-03-03 14:39:06 --> Language Class Initialized
INFO - 2016-03-03 14:39:06 --> Loader Class Initialized
INFO - 2016-03-03 14:39:06 --> Helper loaded: url_helper
INFO - 2016-03-03 14:39:06 --> Helper loaded: file_helper
INFO - 2016-03-03 14:39:06 --> Helper loaded: date_helper
INFO - 2016-03-03 14:39:06 --> Helper loaded: form_helper
INFO - 2016-03-03 14:39:06 --> Database Driver Class Initialized
INFO - 2016-03-03 14:39:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:39:07 --> Controller Class Initialized
INFO - 2016-03-03 14:39:07 --> Model Class Initialized
INFO - 2016-03-03 14:39:07 --> Model Class Initialized
INFO - 2016-03-03 14:39:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:39:07 --> Pagination Class Initialized
INFO - 2016-03-03 14:39:07 --> Helper loaded: text_helper
INFO - 2016-03-03 14:39:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:39:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:39:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:39:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-03 17:39:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:39:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:39:08 --> Final output sent to browser
DEBUG - 2016-03-03 17:39:08 --> Total execution time: 1.1546
INFO - 2016-03-03 14:39:10 --> Config Class Initialized
INFO - 2016-03-03 14:39:10 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:39:10 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:39:10 --> Utf8 Class Initialized
INFO - 2016-03-03 14:39:10 --> URI Class Initialized
INFO - 2016-03-03 14:39:10 --> Router Class Initialized
INFO - 2016-03-03 14:39:10 --> Output Class Initialized
INFO - 2016-03-03 14:39:10 --> Security Class Initialized
DEBUG - 2016-03-03 14:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:39:10 --> Input Class Initialized
INFO - 2016-03-03 14:39:10 --> Language Class Initialized
INFO - 2016-03-03 14:39:10 --> Loader Class Initialized
INFO - 2016-03-03 14:39:10 --> Helper loaded: url_helper
INFO - 2016-03-03 14:39:10 --> Helper loaded: file_helper
INFO - 2016-03-03 14:39:10 --> Helper loaded: date_helper
INFO - 2016-03-03 14:39:10 --> Helper loaded: form_helper
INFO - 2016-03-03 14:39:10 --> Database Driver Class Initialized
INFO - 2016-03-03 14:39:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:39:11 --> Controller Class Initialized
INFO - 2016-03-03 14:39:11 --> Model Class Initialized
INFO - 2016-03-03 14:39:11 --> Model Class Initialized
INFO - 2016-03-03 14:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:39:11 --> Pagination Class Initialized
INFO - 2016-03-03 14:39:11 --> Helper loaded: text_helper
INFO - 2016-03-03 14:39:11 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:39:11 --> Final output sent to browser
DEBUG - 2016-03-03 17:39:11 --> Total execution time: 1.2006
INFO - 2016-03-03 14:49:54 --> Config Class Initialized
INFO - 2016-03-03 14:49:54 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:49:54 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:49:54 --> Utf8 Class Initialized
INFO - 2016-03-03 14:49:54 --> URI Class Initialized
INFO - 2016-03-03 14:49:54 --> Router Class Initialized
INFO - 2016-03-03 14:49:54 --> Output Class Initialized
INFO - 2016-03-03 14:49:54 --> Security Class Initialized
DEBUG - 2016-03-03 14:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:49:54 --> Input Class Initialized
INFO - 2016-03-03 14:49:54 --> Language Class Initialized
INFO - 2016-03-03 14:49:54 --> Loader Class Initialized
INFO - 2016-03-03 14:49:54 --> Helper loaded: url_helper
INFO - 2016-03-03 14:49:54 --> Helper loaded: file_helper
INFO - 2016-03-03 14:49:54 --> Helper loaded: date_helper
INFO - 2016-03-03 14:49:54 --> Helper loaded: form_helper
INFO - 2016-03-03 14:49:54 --> Database Driver Class Initialized
INFO - 2016-03-03 14:49:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:49:55 --> Controller Class Initialized
INFO - 2016-03-03 14:49:55 --> Model Class Initialized
INFO - 2016-03-03 14:49:55 --> Model Class Initialized
INFO - 2016-03-03 14:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:49:55 --> Pagination Class Initialized
INFO - 2016-03-03 14:49:55 --> Helper loaded: text_helper
INFO - 2016-03-03 14:49:55 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:49:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:49:55 --> Final output sent to browser
DEBUG - 2016-03-03 17:49:55 --> Total execution time: 1.2076
INFO - 2016-03-03 14:50:00 --> Config Class Initialized
INFO - 2016-03-03 14:50:00 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:00 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:00 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:00 --> URI Class Initialized
DEBUG - 2016-03-03 14:50:00 --> No URI present. Default controller set.
INFO - 2016-03-03 14:50:00 --> Router Class Initialized
INFO - 2016-03-03 14:50:00 --> Output Class Initialized
INFO - 2016-03-03 14:50:00 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:00 --> Input Class Initialized
INFO - 2016-03-03 14:50:00 --> Language Class Initialized
INFO - 2016-03-03 14:50:00 --> Loader Class Initialized
INFO - 2016-03-03 14:50:00 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:00 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:00 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:00 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:00 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:01 --> Controller Class Initialized
INFO - 2016-03-03 14:50:01 --> Model Class Initialized
INFO - 2016-03-03 14:50:01 --> Model Class Initialized
INFO - 2016-03-03 14:50:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:50:01 --> Pagination Class Initialized
INFO - 2016-03-03 14:50:01 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:01 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:50:01 --> Final output sent to browser
DEBUG - 2016-03-03 17:50:01 --> Total execution time: 1.1412
INFO - 2016-03-03 14:50:07 --> Config Class Initialized
INFO - 2016-03-03 14:50:07 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:07 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:07 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:07 --> URI Class Initialized
INFO - 2016-03-03 14:50:07 --> Router Class Initialized
INFO - 2016-03-03 14:50:07 --> Output Class Initialized
INFO - 2016-03-03 14:50:07 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:07 --> Input Class Initialized
INFO - 2016-03-03 14:50:07 --> Language Class Initialized
INFO - 2016-03-03 14:50:07 --> Loader Class Initialized
INFO - 2016-03-03 14:50:07 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:07 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:07 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:07 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:07 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:08 --> Controller Class Initialized
INFO - 2016-03-03 14:50:08 --> Model Class Initialized
INFO - 2016-03-03 14:50:08 --> Model Class Initialized
INFO - 2016-03-03 14:50:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:50:08 --> Pagination Class Initialized
INFO - 2016-03-03 14:50:08 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:08 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:50:08 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:50:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:50:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:50:08 --> Final output sent to browser
DEBUG - 2016-03-03 17:50:08 --> Total execution time: 1.2083
INFO - 2016-03-03 14:50:14 --> Config Class Initialized
INFO - 2016-03-03 14:50:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:14 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:14 --> URI Class Initialized
INFO - 2016-03-03 14:50:14 --> Router Class Initialized
INFO - 2016-03-03 14:50:14 --> Output Class Initialized
INFO - 2016-03-03 14:50:14 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:14 --> Input Class Initialized
INFO - 2016-03-03 14:50:14 --> Language Class Initialized
INFO - 2016-03-03 14:50:14 --> Loader Class Initialized
INFO - 2016-03-03 14:50:14 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:14 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:14 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:14 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:14 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:15 --> Controller Class Initialized
INFO - 2016-03-03 14:50:15 --> Model Class Initialized
INFO - 2016-03-03 14:50:15 --> Model Class Initialized
INFO - 2016-03-03 14:50:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:50:15 --> Pagination Class Initialized
INFO - 2016-03-03 14:50:15 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:50:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:50:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:50:16 --> Final output sent to browser
DEBUG - 2016-03-03 17:50:16 --> Total execution time: 1.2962
INFO - 2016-03-03 14:50:28 --> Config Class Initialized
INFO - 2016-03-03 14:50:28 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:28 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:28 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:28 --> URI Class Initialized
INFO - 2016-03-03 14:50:28 --> Router Class Initialized
INFO - 2016-03-03 14:50:28 --> Output Class Initialized
INFO - 2016-03-03 14:50:28 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:28 --> Input Class Initialized
INFO - 2016-03-03 14:50:28 --> Language Class Initialized
INFO - 2016-03-03 14:50:28 --> Loader Class Initialized
INFO - 2016-03-03 14:50:28 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:28 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:28 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:28 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:28 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:29 --> Controller Class Initialized
INFO - 2016-03-03 14:50:29 --> Model Class Initialized
INFO - 2016-03-03 14:50:29 --> Model Class Initialized
INFO - 2016-03-03 14:50:29 --> Form Validation Class Initialized
INFO - 2016-03-03 14:50:29 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:29 --> Final output sent to browser
DEBUG - 2016-03-03 14:50:29 --> Total execution time: 1.2155
INFO - 2016-03-03 14:50:29 --> Config Class Initialized
INFO - 2016-03-03 14:50:29 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:29 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:29 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:29 --> URI Class Initialized
INFO - 2016-03-03 14:50:29 --> Router Class Initialized
INFO - 2016-03-03 14:50:29 --> Output Class Initialized
INFO - 2016-03-03 14:50:29 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:29 --> Input Class Initialized
INFO - 2016-03-03 14:50:29 --> Language Class Initialized
INFO - 2016-03-03 14:50:29 --> Loader Class Initialized
INFO - 2016-03-03 14:50:29 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:29 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:29 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:29 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:29 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:30 --> Controller Class Initialized
INFO - 2016-03-03 14:50:30 --> Model Class Initialized
INFO - 2016-03-03 14:50:30 --> Model Class Initialized
INFO - 2016-03-03 14:50:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:50:30 --> Pagination Class Initialized
INFO - 2016-03-03 14:50:30 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:30 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:50:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:50:30 --> Final output sent to browser
DEBUG - 2016-03-03 17:50:30 --> Total execution time: 1.1866
INFO - 2016-03-03 14:50:35 --> Config Class Initialized
INFO - 2016-03-03 14:50:35 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:35 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:35 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:35 --> URI Class Initialized
INFO - 2016-03-03 14:50:35 --> Router Class Initialized
INFO - 2016-03-03 14:50:35 --> Output Class Initialized
INFO - 2016-03-03 14:50:35 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:35 --> Input Class Initialized
INFO - 2016-03-03 14:50:35 --> Language Class Initialized
INFO - 2016-03-03 14:50:35 --> Loader Class Initialized
INFO - 2016-03-03 14:50:35 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:35 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:35 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:35 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:35 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:36 --> Controller Class Initialized
INFO - 2016-03-03 14:50:36 --> Model Class Initialized
INFO - 2016-03-03 14:50:36 --> Model Class Initialized
INFO - 2016-03-03 14:50:36 --> Form Validation Class Initialized
INFO - 2016-03-03 14:50:36 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:36 --> Config Class Initialized
INFO - 2016-03-03 14:50:36 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:36 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:36 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:36 --> URI Class Initialized
DEBUG - 2016-03-03 14:50:36 --> No URI present. Default controller set.
INFO - 2016-03-03 14:50:36 --> Router Class Initialized
INFO - 2016-03-03 14:50:36 --> Output Class Initialized
INFO - 2016-03-03 14:50:36 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:36 --> Input Class Initialized
INFO - 2016-03-03 14:50:36 --> Language Class Initialized
INFO - 2016-03-03 14:50:36 --> Loader Class Initialized
INFO - 2016-03-03 14:50:36 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:36 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:36 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:36 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:36 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:37 --> Controller Class Initialized
INFO - 2016-03-03 14:50:37 --> Model Class Initialized
INFO - 2016-03-03 14:50:37 --> Model Class Initialized
INFO - 2016-03-03 14:50:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:50:37 --> Pagination Class Initialized
INFO - 2016-03-03 14:50:37 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:37 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 17:50:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:50:37 --> Final output sent to browser
DEBUG - 2016-03-03 17:50:37 --> Total execution time: 1.1108
INFO - 2016-03-03 14:50:40 --> Config Class Initialized
INFO - 2016-03-03 14:50:40 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:40 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:40 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:40 --> URI Class Initialized
INFO - 2016-03-03 14:50:40 --> Router Class Initialized
INFO - 2016-03-03 14:50:40 --> Output Class Initialized
INFO - 2016-03-03 14:50:40 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:40 --> Input Class Initialized
INFO - 2016-03-03 14:50:40 --> Language Class Initialized
INFO - 2016-03-03 14:50:40 --> Loader Class Initialized
INFO - 2016-03-03 14:50:40 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:40 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:40 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:40 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:41 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:42 --> Controller Class Initialized
INFO - 2016-03-03 14:50:42 --> Model Class Initialized
INFO - 2016-03-03 14:50:42 --> Model Class Initialized
INFO - 2016-03-03 14:50:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:50:42 --> Pagination Class Initialized
INFO - 2016-03-03 14:50:42 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:42 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 17:50:42 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 17:50:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 17:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 17:50:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:50:42 --> Final output sent to browser
DEBUG - 2016-03-03 17:50:42 --> Total execution time: 1.1402
INFO - 2016-03-03 14:50:43 --> Config Class Initialized
INFO - 2016-03-03 14:50:43 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:43 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:43 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:43 --> URI Class Initialized
INFO - 2016-03-03 14:50:43 --> Router Class Initialized
INFO - 2016-03-03 14:50:43 --> Output Class Initialized
INFO - 2016-03-03 14:50:43 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:43 --> Input Class Initialized
INFO - 2016-03-03 14:50:43 --> Language Class Initialized
INFO - 2016-03-03 14:50:43 --> Loader Class Initialized
INFO - 2016-03-03 14:50:43 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:43 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:43 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:43 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:43 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:45 --> Controller Class Initialized
INFO - 2016-03-03 14:50:45 --> Model Class Initialized
INFO - 2016-03-03 14:50:45 --> Model Class Initialized
INFO - 2016-03-03 14:50:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:50:45 --> Pagination Class Initialized
INFO - 2016-03-03 14:50:45 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:45 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:50:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:50:45 --> Final output sent to browser
DEBUG - 2016-03-03 17:50:45 --> Total execution time: 1.1805
INFO - 2016-03-03 14:50:54 --> Config Class Initialized
INFO - 2016-03-03 14:50:54 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:54 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:54 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:54 --> URI Class Initialized
INFO - 2016-03-03 14:50:54 --> Router Class Initialized
INFO - 2016-03-03 14:50:54 --> Output Class Initialized
INFO - 2016-03-03 14:50:54 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:54 --> Input Class Initialized
INFO - 2016-03-03 14:50:54 --> Language Class Initialized
INFO - 2016-03-03 14:50:54 --> Loader Class Initialized
INFO - 2016-03-03 14:50:54 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:54 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:54 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:54 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:54 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:55 --> Controller Class Initialized
INFO - 2016-03-03 14:50:55 --> Model Class Initialized
INFO - 2016-03-03 14:50:55 --> Model Class Initialized
INFO - 2016-03-03 14:50:55 --> Form Validation Class Initialized
INFO - 2016-03-03 14:50:55 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:55 --> Final output sent to browser
DEBUG - 2016-03-03 14:50:55 --> Total execution time: 1.1764
INFO - 2016-03-03 14:50:55 --> Config Class Initialized
INFO - 2016-03-03 14:50:55 --> Hooks Class Initialized
DEBUG - 2016-03-03 14:50:55 --> UTF-8 Support Enabled
INFO - 2016-03-03 14:50:55 --> Utf8 Class Initialized
INFO - 2016-03-03 14:50:55 --> URI Class Initialized
INFO - 2016-03-03 14:50:55 --> Router Class Initialized
INFO - 2016-03-03 14:50:55 --> Output Class Initialized
INFO - 2016-03-03 14:50:55 --> Security Class Initialized
DEBUG - 2016-03-03 14:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 14:50:55 --> Input Class Initialized
INFO - 2016-03-03 14:50:55 --> Language Class Initialized
INFO - 2016-03-03 14:50:55 --> Loader Class Initialized
INFO - 2016-03-03 14:50:55 --> Helper loaded: url_helper
INFO - 2016-03-03 14:50:55 --> Helper loaded: file_helper
INFO - 2016-03-03 14:50:55 --> Helper loaded: date_helper
INFO - 2016-03-03 14:50:55 --> Helper loaded: form_helper
INFO - 2016-03-03 14:50:55 --> Database Driver Class Initialized
INFO - 2016-03-03 14:50:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 14:50:56 --> Controller Class Initialized
INFO - 2016-03-03 14:50:56 --> Model Class Initialized
INFO - 2016-03-03 14:50:56 --> Model Class Initialized
INFO - 2016-03-03 14:50:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 14:50:56 --> Pagination Class Initialized
INFO - 2016-03-03 14:50:56 --> Helper loaded: text_helper
INFO - 2016-03-03 14:50:56 --> Helper loaded: cookie_helper
INFO - 2016-03-03 17:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 17:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 17:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 17:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 17:50:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 17:50:56 --> Final output sent to browser
DEBUG - 2016-03-03 17:50:56 --> Total execution time: 1.2156
INFO - 2016-03-03 16:05:22 --> Config Class Initialized
INFO - 2016-03-03 16:05:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 16:05:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 16:05:24 --> Utf8 Class Initialized
INFO - 2016-03-03 16:05:24 --> URI Class Initialized
INFO - 2016-03-03 16:05:24 --> Router Class Initialized
INFO - 2016-03-03 16:05:24 --> Output Class Initialized
INFO - 2016-03-03 16:05:24 --> Security Class Initialized
DEBUG - 2016-03-03 16:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 16:05:24 --> Input Class Initialized
INFO - 2016-03-03 16:05:24 --> Language Class Initialized
INFO - 2016-03-03 16:05:25 --> Loader Class Initialized
INFO - 2016-03-03 16:05:25 --> Helper loaded: url_helper
INFO - 2016-03-03 16:05:25 --> Helper loaded: file_helper
INFO - 2016-03-03 16:05:25 --> Helper loaded: date_helper
INFO - 2016-03-03 16:05:25 --> Helper loaded: form_helper
INFO - 2016-03-03 16:05:25 --> Database Driver Class Initialized
INFO - 2016-03-03 16:05:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 16:05:26 --> Controller Class Initialized
INFO - 2016-03-03 16:05:26 --> Model Class Initialized
INFO - 2016-03-03 16:05:26 --> Model Class Initialized
INFO - 2016-03-03 16:05:26 --> Form Validation Class Initialized
INFO - 2016-03-03 16:05:26 --> Helper loaded: text_helper
INFO - 2016-03-03 16:05:26 --> Config Class Initialized
INFO - 2016-03-03 16:05:26 --> Hooks Class Initialized
DEBUG - 2016-03-03 16:05:26 --> UTF-8 Support Enabled
INFO - 2016-03-03 16:05:26 --> Utf8 Class Initialized
INFO - 2016-03-03 16:05:26 --> URI Class Initialized
DEBUG - 2016-03-03 16:05:26 --> No URI present. Default controller set.
INFO - 2016-03-03 16:05:26 --> Router Class Initialized
INFO - 2016-03-03 16:05:26 --> Output Class Initialized
INFO - 2016-03-03 16:05:26 --> Security Class Initialized
DEBUG - 2016-03-03 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 16:05:27 --> Input Class Initialized
INFO - 2016-03-03 16:05:27 --> Language Class Initialized
INFO - 2016-03-03 16:05:27 --> Loader Class Initialized
INFO - 2016-03-03 16:05:27 --> Helper loaded: url_helper
INFO - 2016-03-03 16:05:27 --> Helper loaded: file_helper
INFO - 2016-03-03 16:05:27 --> Helper loaded: date_helper
INFO - 2016-03-03 16:05:27 --> Helper loaded: form_helper
INFO - 2016-03-03 16:05:27 --> Database Driver Class Initialized
INFO - 2016-03-03 16:05:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 16:05:28 --> Controller Class Initialized
INFO - 2016-03-03 16:05:28 --> Model Class Initialized
INFO - 2016-03-03 16:05:28 --> Model Class Initialized
INFO - 2016-03-03 16:05:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 16:05:28 --> Pagination Class Initialized
INFO - 2016-03-03 16:05:28 --> Helper loaded: text_helper
INFO - 2016-03-03 16:05:28 --> Helper loaded: cookie_helper
INFO - 2016-03-03 19:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 19:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 19:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 19:05:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 19:05:28 --> Final output sent to browser
DEBUG - 2016-03-03 19:05:28 --> Total execution time: 1.6385
INFO - 2016-03-03 16:06:09 --> Config Class Initialized
INFO - 2016-03-03 16:06:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 16:06:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 16:06:09 --> Utf8 Class Initialized
INFO - 2016-03-03 16:06:09 --> URI Class Initialized
INFO - 2016-03-03 16:06:09 --> Router Class Initialized
INFO - 2016-03-03 16:06:09 --> Output Class Initialized
INFO - 2016-03-03 16:06:09 --> Security Class Initialized
DEBUG - 2016-03-03 16:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 16:06:09 --> Input Class Initialized
INFO - 2016-03-03 16:06:09 --> Language Class Initialized
INFO - 2016-03-03 16:06:09 --> Loader Class Initialized
INFO - 2016-03-03 16:06:09 --> Helper loaded: url_helper
INFO - 2016-03-03 16:06:09 --> Helper loaded: file_helper
INFO - 2016-03-03 16:06:09 --> Helper loaded: date_helper
INFO - 2016-03-03 16:06:09 --> Helper loaded: form_helper
INFO - 2016-03-03 16:06:10 --> Database Driver Class Initialized
INFO - 2016-03-03 16:06:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 16:06:11 --> Controller Class Initialized
INFO - 2016-03-03 16:06:11 --> Model Class Initialized
INFO - 2016-03-03 16:06:11 --> Model Class Initialized
INFO - 2016-03-03 16:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 16:06:11 --> Pagination Class Initialized
INFO - 2016-03-03 16:06:11 --> Helper loaded: text_helper
INFO - 2016-03-03 16:06:11 --> Helper loaded: cookie_helper
INFO - 2016-03-03 19:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 19:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 19:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 19:06:11 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 19:06:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 19:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 19:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 19:06:11 --> Final output sent to browser
DEBUG - 2016-03-03 19:06:11 --> Total execution time: 1.2100
INFO - 2016-03-03 16:06:16 --> Config Class Initialized
INFO - 2016-03-03 16:06:16 --> Hooks Class Initialized
DEBUG - 2016-03-03 16:06:16 --> UTF-8 Support Enabled
INFO - 2016-03-03 16:06:16 --> Utf8 Class Initialized
INFO - 2016-03-03 16:06:16 --> URI Class Initialized
INFO - 2016-03-03 16:06:16 --> Router Class Initialized
INFO - 2016-03-03 16:06:16 --> Output Class Initialized
INFO - 2016-03-03 16:06:16 --> Security Class Initialized
DEBUG - 2016-03-03 16:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 16:06:16 --> Input Class Initialized
INFO - 2016-03-03 16:06:16 --> Language Class Initialized
INFO - 2016-03-03 16:06:16 --> Loader Class Initialized
INFO - 2016-03-03 16:06:16 --> Helper loaded: url_helper
INFO - 2016-03-03 16:06:16 --> Helper loaded: file_helper
INFO - 2016-03-03 16:06:16 --> Helper loaded: date_helper
INFO - 2016-03-03 16:06:16 --> Helper loaded: form_helper
INFO - 2016-03-03 16:06:16 --> Database Driver Class Initialized
INFO - 2016-03-03 16:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 16:06:17 --> Controller Class Initialized
INFO - 2016-03-03 16:06:17 --> Model Class Initialized
INFO - 2016-03-03 16:06:17 --> Model Class Initialized
INFO - 2016-03-03 16:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 16:06:17 --> Pagination Class Initialized
INFO - 2016-03-03 16:06:17 --> Helper loaded: text_helper
INFO - 2016-03-03 16:06:17 --> Helper loaded: cookie_helper
INFO - 2016-03-03 19:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 19:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 19:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 19:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 19:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 19:06:17 --> Final output sent to browser
DEBUG - 2016-03-03 19:06:17 --> Total execution time: 1.3038
INFO - 2016-03-03 16:08:27 --> Config Class Initialized
INFO - 2016-03-03 16:08:27 --> Hooks Class Initialized
DEBUG - 2016-03-03 16:08:27 --> UTF-8 Support Enabled
INFO - 2016-03-03 16:08:27 --> Utf8 Class Initialized
INFO - 2016-03-03 16:08:27 --> URI Class Initialized
INFO - 2016-03-03 16:08:27 --> Router Class Initialized
INFO - 2016-03-03 16:08:27 --> Output Class Initialized
INFO - 2016-03-03 16:08:27 --> Security Class Initialized
DEBUG - 2016-03-03 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 16:08:27 --> Input Class Initialized
INFO - 2016-03-03 16:08:27 --> Language Class Initialized
INFO - 2016-03-03 16:08:27 --> Loader Class Initialized
INFO - 2016-03-03 16:08:27 --> Helper loaded: url_helper
INFO - 2016-03-03 16:08:27 --> Helper loaded: file_helper
INFO - 2016-03-03 16:08:27 --> Helper loaded: date_helper
INFO - 2016-03-03 16:08:27 --> Helper loaded: form_helper
INFO - 2016-03-03 16:08:27 --> Database Driver Class Initialized
INFO - 2016-03-03 16:08:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 16:08:28 --> Controller Class Initialized
INFO - 2016-03-03 16:08:28 --> Model Class Initialized
INFO - 2016-03-03 16:08:28 --> Model Class Initialized
INFO - 2016-03-03 16:08:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 16:08:28 --> Pagination Class Initialized
INFO - 2016-03-03 16:08:28 --> Helper loaded: text_helper
INFO - 2016-03-03 16:08:28 --> Helper loaded: cookie_helper
INFO - 2016-03-03 19:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 19:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 19:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 19:08:28 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 19:08:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 19:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 19:08:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 19:08:28 --> Final output sent to browser
DEBUG - 2016-03-03 19:08:28 --> Total execution time: 1.1697
INFO - 2016-03-03 16:09:07 --> Config Class Initialized
INFO - 2016-03-03 16:09:07 --> Hooks Class Initialized
DEBUG - 2016-03-03 16:09:07 --> UTF-8 Support Enabled
INFO - 2016-03-03 16:09:07 --> Utf8 Class Initialized
INFO - 2016-03-03 16:09:07 --> URI Class Initialized
INFO - 2016-03-03 16:09:07 --> Router Class Initialized
INFO - 2016-03-03 16:09:07 --> Output Class Initialized
INFO - 2016-03-03 16:09:07 --> Security Class Initialized
DEBUG - 2016-03-03 16:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 16:09:07 --> Input Class Initialized
INFO - 2016-03-03 16:09:07 --> Language Class Initialized
INFO - 2016-03-03 16:09:07 --> Loader Class Initialized
INFO - 2016-03-03 16:09:07 --> Helper loaded: url_helper
INFO - 2016-03-03 16:09:07 --> Helper loaded: file_helper
INFO - 2016-03-03 16:09:07 --> Helper loaded: date_helper
INFO - 2016-03-03 16:09:07 --> Helper loaded: form_helper
INFO - 2016-03-03 16:09:07 --> Database Driver Class Initialized
INFO - 2016-03-03 16:09:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 16:09:08 --> Controller Class Initialized
INFO - 2016-03-03 16:09:08 --> Model Class Initialized
INFO - 2016-03-03 16:09:08 --> Model Class Initialized
INFO - 2016-03-03 16:09:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 16:09:08 --> Pagination Class Initialized
INFO - 2016-03-03 16:09:08 --> Helper loaded: text_helper
INFO - 2016-03-03 16:09:08 --> Helper loaded: cookie_helper
INFO - 2016-03-03 19:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 19:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 19:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-03 19:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-03 19:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 19:09:08 --> Final output sent to browser
DEBUG - 2016-03-03 19:09:08 --> Total execution time: 1.1948
INFO - 2016-03-03 16:09:13 --> Config Class Initialized
INFO - 2016-03-03 16:09:13 --> Hooks Class Initialized
DEBUG - 2016-03-03 16:09:13 --> UTF-8 Support Enabled
INFO - 2016-03-03 16:09:13 --> Utf8 Class Initialized
INFO - 2016-03-03 16:09:13 --> URI Class Initialized
DEBUG - 2016-03-03 16:09:13 --> No URI present. Default controller set.
INFO - 2016-03-03 16:09:13 --> Router Class Initialized
INFO - 2016-03-03 16:09:13 --> Output Class Initialized
INFO - 2016-03-03 16:09:13 --> Security Class Initialized
DEBUG - 2016-03-03 16:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 16:09:13 --> Input Class Initialized
INFO - 2016-03-03 16:09:13 --> Language Class Initialized
INFO - 2016-03-03 16:09:13 --> Loader Class Initialized
INFO - 2016-03-03 16:09:13 --> Helper loaded: url_helper
INFO - 2016-03-03 16:09:13 --> Helper loaded: file_helper
INFO - 2016-03-03 16:09:13 --> Helper loaded: date_helper
INFO - 2016-03-03 16:09:13 --> Helper loaded: form_helper
INFO - 2016-03-03 16:09:13 --> Database Driver Class Initialized
INFO - 2016-03-03 16:09:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 16:09:14 --> Controller Class Initialized
INFO - 2016-03-03 16:09:14 --> Model Class Initialized
INFO - 2016-03-03 16:09:14 --> Model Class Initialized
INFO - 2016-03-03 16:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 16:09:14 --> Pagination Class Initialized
INFO - 2016-03-03 16:09:14 --> Helper loaded: text_helper
INFO - 2016-03-03 16:09:14 --> Helper loaded: cookie_helper
INFO - 2016-03-03 19:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 19:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 19:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-03 19:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 19:09:14 --> Final output sent to browser
DEBUG - 2016-03-03 19:09:14 --> Total execution time: 1.1072
INFO - 2016-03-03 18:04:41 --> Config Class Initialized
INFO - 2016-03-03 18:04:41 --> Hooks Class Initialized
DEBUG - 2016-03-03 18:04:41 --> UTF-8 Support Enabled
INFO - 2016-03-03 18:04:41 --> Utf8 Class Initialized
INFO - 2016-03-03 18:04:41 --> URI Class Initialized
INFO - 2016-03-03 18:04:41 --> Router Class Initialized
INFO - 2016-03-03 18:04:41 --> Output Class Initialized
INFO - 2016-03-03 18:04:41 --> Security Class Initialized
DEBUG - 2016-03-03 18:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 18:04:41 --> Input Class Initialized
INFO - 2016-03-03 18:04:41 --> Language Class Initialized
INFO - 2016-03-03 18:04:41 --> Loader Class Initialized
INFO - 2016-03-03 18:04:41 --> Helper loaded: url_helper
INFO - 2016-03-03 18:04:41 --> Helper loaded: file_helper
INFO - 2016-03-03 18:04:41 --> Helper loaded: date_helper
INFO - 2016-03-03 18:04:41 --> Helper loaded: form_helper
INFO - 2016-03-03 18:04:41 --> Database Driver Class Initialized
INFO - 2016-03-03 18:04:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 18:04:42 --> Controller Class Initialized
INFO - 2016-03-03 18:04:42 --> Model Class Initialized
INFO - 2016-03-03 18:04:42 --> Model Class Initialized
INFO - 2016-03-03 18:04:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 18:04:42 --> Pagination Class Initialized
INFO - 2016-03-03 18:04:42 --> Helper loaded: text_helper
INFO - 2016-03-03 18:04:42 --> Helper loaded: cookie_helper
INFO - 2016-03-03 21:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 21:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 21:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 21:04:42 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 21:04:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 21:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 21:04:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 21:04:42 --> Final output sent to browser
DEBUG - 2016-03-03 21:04:42 --> Total execution time: 1.1399
INFO - 2016-03-03 20:13:00 --> Config Class Initialized
INFO - 2016-03-03 20:13:00 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:13:00 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:13:00 --> Utf8 Class Initialized
INFO - 2016-03-03 20:13:00 --> URI Class Initialized
INFO - 2016-03-03 20:13:00 --> Router Class Initialized
INFO - 2016-03-03 20:13:00 --> Output Class Initialized
INFO - 2016-03-03 20:13:00 --> Security Class Initialized
DEBUG - 2016-03-03 20:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:13:00 --> Input Class Initialized
INFO - 2016-03-03 20:13:00 --> Language Class Initialized
INFO - 2016-03-03 20:13:00 --> Loader Class Initialized
INFO - 2016-03-03 20:13:00 --> Helper loaded: url_helper
INFO - 2016-03-03 20:13:00 --> Helper loaded: file_helper
INFO - 2016-03-03 20:13:00 --> Helper loaded: date_helper
INFO - 2016-03-03 20:13:00 --> Helper loaded: form_helper
INFO - 2016-03-03 20:13:00 --> Database Driver Class Initialized
INFO - 2016-03-03 20:13:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:13:01 --> Controller Class Initialized
INFO - 2016-03-03 20:13:01 --> Model Class Initialized
INFO - 2016-03-03 20:13:01 --> Model Class Initialized
INFO - 2016-03-03 20:13:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:13:01 --> Pagination Class Initialized
INFO - 2016-03-03 20:13:01 --> Helper loaded: text_helper
INFO - 2016-03-03 20:13:01 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:13:01 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:13:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:13:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:13:01 --> Final output sent to browser
DEBUG - 2016-03-03 23:13:01 --> Total execution time: 1.1790
INFO - 2016-03-03 20:13:10 --> Config Class Initialized
INFO - 2016-03-03 20:13:10 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:13:10 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:13:10 --> Utf8 Class Initialized
INFO - 2016-03-03 20:13:10 --> URI Class Initialized
INFO - 2016-03-03 20:13:10 --> Router Class Initialized
INFO - 2016-03-03 20:13:10 --> Output Class Initialized
INFO - 2016-03-03 20:13:10 --> Security Class Initialized
DEBUG - 2016-03-03 20:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:13:10 --> Input Class Initialized
INFO - 2016-03-03 20:13:10 --> Language Class Initialized
INFO - 2016-03-03 20:13:10 --> Loader Class Initialized
INFO - 2016-03-03 20:13:10 --> Helper loaded: url_helper
INFO - 2016-03-03 20:13:10 --> Helper loaded: file_helper
INFO - 2016-03-03 20:13:10 --> Helper loaded: date_helper
INFO - 2016-03-03 20:13:10 --> Helper loaded: form_helper
INFO - 2016-03-03 20:13:10 --> Database Driver Class Initialized
INFO - 2016-03-03 20:13:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:13:11 --> Controller Class Initialized
INFO - 2016-03-03 20:13:11 --> Model Class Initialized
INFO - 2016-03-03 20:13:11 --> Model Class Initialized
INFO - 2016-03-03 20:13:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:13:11 --> Pagination Class Initialized
INFO - 2016-03-03 20:13:11 --> Helper loaded: text_helper
INFO - 2016-03-03 20:13:11 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:13:11 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:13:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:13:11 --> Final output sent to browser
DEBUG - 2016-03-03 23:13:11 --> Total execution time: 1.1704
INFO - 2016-03-03 20:16:14 --> Config Class Initialized
INFO - 2016-03-03 20:16:14 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:16:14 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:16:14 --> Utf8 Class Initialized
INFO - 2016-03-03 20:16:14 --> URI Class Initialized
INFO - 2016-03-03 20:16:14 --> Router Class Initialized
INFO - 2016-03-03 20:16:14 --> Output Class Initialized
INFO - 2016-03-03 20:16:14 --> Security Class Initialized
DEBUG - 2016-03-03 20:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:16:14 --> Input Class Initialized
INFO - 2016-03-03 20:16:14 --> Language Class Initialized
INFO - 2016-03-03 20:16:14 --> Loader Class Initialized
INFO - 2016-03-03 20:16:14 --> Helper loaded: url_helper
INFO - 2016-03-03 20:16:14 --> Helper loaded: file_helper
INFO - 2016-03-03 20:16:14 --> Helper loaded: date_helper
INFO - 2016-03-03 20:16:14 --> Helper loaded: form_helper
INFO - 2016-03-03 20:16:14 --> Database Driver Class Initialized
INFO - 2016-03-03 20:16:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:16:15 --> Controller Class Initialized
INFO - 2016-03-03 20:16:15 --> Model Class Initialized
INFO - 2016-03-03 20:16:15 --> Model Class Initialized
INFO - 2016-03-03 20:16:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:16:15 --> Pagination Class Initialized
INFO - 2016-03-03 20:16:15 --> Helper loaded: text_helper
INFO - 2016-03-03 20:16:15 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:16:15 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:16:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:16:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:16:15 --> Final output sent to browser
DEBUG - 2016-03-03 23:16:15 --> Total execution time: 1.1643
INFO - 2016-03-03 20:16:25 --> Config Class Initialized
INFO - 2016-03-03 20:16:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:16:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:16:25 --> Utf8 Class Initialized
INFO - 2016-03-03 20:16:25 --> URI Class Initialized
INFO - 2016-03-03 20:16:25 --> Router Class Initialized
INFO - 2016-03-03 20:16:25 --> Output Class Initialized
INFO - 2016-03-03 20:16:25 --> Security Class Initialized
DEBUG - 2016-03-03 20:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:16:25 --> Input Class Initialized
INFO - 2016-03-03 20:16:25 --> Language Class Initialized
INFO - 2016-03-03 20:16:25 --> Loader Class Initialized
INFO - 2016-03-03 20:16:25 --> Helper loaded: url_helper
INFO - 2016-03-03 20:16:25 --> Helper loaded: file_helper
INFO - 2016-03-03 20:16:25 --> Helper loaded: date_helper
INFO - 2016-03-03 20:16:25 --> Helper loaded: form_helper
INFO - 2016-03-03 20:16:25 --> Database Driver Class Initialized
INFO - 2016-03-03 20:16:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:16:26 --> Controller Class Initialized
INFO - 2016-03-03 20:16:26 --> Model Class Initialized
INFO - 2016-03-03 20:16:26 --> Model Class Initialized
INFO - 2016-03-03 20:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:16:26 --> Pagination Class Initialized
INFO - 2016-03-03 20:16:26 --> Helper loaded: text_helper
INFO - 2016-03-03 20:16:26 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:16:26 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:16:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:16:26 --> Final output sent to browser
DEBUG - 2016-03-03 23:16:26 --> Total execution time: 1.1191
INFO - 2016-03-03 20:17:39 --> Config Class Initialized
INFO - 2016-03-03 20:17:39 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:17:39 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:17:39 --> Utf8 Class Initialized
INFO - 2016-03-03 20:17:39 --> URI Class Initialized
INFO - 2016-03-03 20:17:39 --> Router Class Initialized
INFO - 2016-03-03 20:17:39 --> Output Class Initialized
INFO - 2016-03-03 20:17:39 --> Security Class Initialized
DEBUG - 2016-03-03 20:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:17:39 --> Input Class Initialized
INFO - 2016-03-03 20:17:39 --> Language Class Initialized
INFO - 2016-03-03 20:17:39 --> Loader Class Initialized
INFO - 2016-03-03 20:17:39 --> Helper loaded: url_helper
INFO - 2016-03-03 20:17:39 --> Helper loaded: file_helper
INFO - 2016-03-03 20:17:39 --> Helper loaded: date_helper
INFO - 2016-03-03 20:17:39 --> Helper loaded: form_helper
INFO - 2016-03-03 20:17:39 --> Database Driver Class Initialized
INFO - 2016-03-03 20:17:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:17:40 --> Controller Class Initialized
INFO - 2016-03-03 20:17:40 --> Model Class Initialized
INFO - 2016-03-03 20:17:40 --> Model Class Initialized
INFO - 2016-03-03 20:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:17:40 --> Pagination Class Initialized
INFO - 2016-03-03 20:17:40 --> Helper loaded: text_helper
INFO - 2016-03-03 20:17:40 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:17:40 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:17:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:17:40 --> Final output sent to browser
DEBUG - 2016-03-03 23:17:40 --> Total execution time: 1.1266
INFO - 2016-03-03 20:19:29 --> Config Class Initialized
INFO - 2016-03-03 20:19:29 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:19:29 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:19:29 --> Utf8 Class Initialized
INFO - 2016-03-03 20:19:29 --> URI Class Initialized
INFO - 2016-03-03 20:19:29 --> Router Class Initialized
INFO - 2016-03-03 20:19:29 --> Output Class Initialized
INFO - 2016-03-03 20:19:29 --> Security Class Initialized
DEBUG - 2016-03-03 20:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:19:29 --> Input Class Initialized
INFO - 2016-03-03 20:19:29 --> Language Class Initialized
INFO - 2016-03-03 20:19:29 --> Loader Class Initialized
INFO - 2016-03-03 20:19:29 --> Helper loaded: url_helper
INFO - 2016-03-03 20:19:29 --> Helper loaded: file_helper
INFO - 2016-03-03 20:19:29 --> Helper loaded: date_helper
INFO - 2016-03-03 20:19:29 --> Helper loaded: form_helper
INFO - 2016-03-03 20:19:29 --> Database Driver Class Initialized
INFO - 2016-03-03 20:19:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:19:30 --> Controller Class Initialized
INFO - 2016-03-03 20:19:30 --> Model Class Initialized
INFO - 2016-03-03 20:19:30 --> Model Class Initialized
INFO - 2016-03-03 20:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:19:30 --> Pagination Class Initialized
INFO - 2016-03-03 20:19:30 --> Helper loaded: text_helper
INFO - 2016-03-03 20:19:30 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:19:30 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:19:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:19:30 --> Final output sent to browser
DEBUG - 2016-03-03 23:19:30 --> Total execution time: 1.1685
INFO - 2016-03-03 20:19:32 --> Config Class Initialized
INFO - 2016-03-03 20:19:32 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:19:32 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:19:32 --> Utf8 Class Initialized
INFO - 2016-03-03 20:19:32 --> URI Class Initialized
INFO - 2016-03-03 20:19:32 --> Router Class Initialized
INFO - 2016-03-03 20:19:32 --> Output Class Initialized
INFO - 2016-03-03 20:19:32 --> Security Class Initialized
DEBUG - 2016-03-03 20:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:19:32 --> Input Class Initialized
INFO - 2016-03-03 20:19:32 --> Language Class Initialized
INFO - 2016-03-03 20:19:32 --> Loader Class Initialized
INFO - 2016-03-03 20:19:32 --> Helper loaded: url_helper
INFO - 2016-03-03 20:19:32 --> Helper loaded: file_helper
INFO - 2016-03-03 20:19:32 --> Helper loaded: date_helper
INFO - 2016-03-03 20:19:32 --> Helper loaded: form_helper
INFO - 2016-03-03 20:19:32 --> Database Driver Class Initialized
INFO - 2016-03-03 20:19:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:19:33 --> Controller Class Initialized
INFO - 2016-03-03 20:19:33 --> Model Class Initialized
INFO - 2016-03-03 20:19:33 --> Model Class Initialized
INFO - 2016-03-03 20:19:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:19:33 --> Pagination Class Initialized
INFO - 2016-03-03 20:19:33 --> Helper loaded: text_helper
INFO - 2016-03-03 20:19:33 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:19:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:19:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:19:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:19:33 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:19:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:19:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:19:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-03 23:19:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:19:33 --> Final output sent to browser
DEBUG - 2016-03-03 23:19:33 --> Total execution time: 1.1345
INFO - 2016-03-03 20:19:42 --> Config Class Initialized
INFO - 2016-03-03 20:19:42 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:19:42 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:19:42 --> Utf8 Class Initialized
INFO - 2016-03-03 20:19:42 --> URI Class Initialized
INFO - 2016-03-03 20:19:42 --> Router Class Initialized
INFO - 2016-03-03 20:19:42 --> Output Class Initialized
INFO - 2016-03-03 20:19:42 --> Security Class Initialized
DEBUG - 2016-03-03 20:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:19:42 --> Input Class Initialized
INFO - 2016-03-03 20:19:42 --> Language Class Initialized
INFO - 2016-03-03 20:19:42 --> Loader Class Initialized
INFO - 2016-03-03 20:19:42 --> Helper loaded: url_helper
INFO - 2016-03-03 20:19:42 --> Helper loaded: file_helper
INFO - 2016-03-03 20:19:42 --> Helper loaded: date_helper
INFO - 2016-03-03 20:19:42 --> Helper loaded: form_helper
INFO - 2016-03-03 20:19:42 --> Database Driver Class Initialized
INFO - 2016-03-03 20:19:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:19:43 --> Controller Class Initialized
INFO - 2016-03-03 20:19:43 --> Model Class Initialized
INFO - 2016-03-03 20:19:43 --> Model Class Initialized
INFO - 2016-03-03 20:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:19:43 --> Pagination Class Initialized
INFO - 2016-03-03 20:19:43 --> Helper loaded: text_helper
INFO - 2016-03-03 20:19:43 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 23:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 23:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:19:43 --> Final output sent to browser
DEBUG - 2016-03-03 23:19:43 --> Total execution time: 1.2022
INFO - 2016-03-03 20:20:03 --> Config Class Initialized
INFO - 2016-03-03 20:20:03 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:20:03 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:20:03 --> Utf8 Class Initialized
INFO - 2016-03-03 20:20:03 --> URI Class Initialized
INFO - 2016-03-03 20:20:03 --> Router Class Initialized
INFO - 2016-03-03 20:20:03 --> Output Class Initialized
INFO - 2016-03-03 20:20:03 --> Security Class Initialized
DEBUG - 2016-03-03 20:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:20:03 --> Input Class Initialized
INFO - 2016-03-03 20:20:03 --> Language Class Initialized
INFO - 2016-03-03 20:20:03 --> Loader Class Initialized
INFO - 2016-03-03 20:20:03 --> Helper loaded: url_helper
INFO - 2016-03-03 20:20:03 --> Helper loaded: file_helper
INFO - 2016-03-03 20:20:03 --> Helper loaded: date_helper
INFO - 2016-03-03 20:20:03 --> Helper loaded: form_helper
INFO - 2016-03-03 20:20:03 --> Database Driver Class Initialized
INFO - 2016-03-03 20:20:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:20:04 --> Controller Class Initialized
INFO - 2016-03-03 20:20:04 --> Model Class Initialized
INFO - 2016-03-03 20:20:04 --> Model Class Initialized
INFO - 2016-03-03 20:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:20:04 --> Pagination Class Initialized
INFO - 2016-03-03 20:20:04 --> Helper loaded: text_helper
INFO - 2016-03-03 20:20:04 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:20:04 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:20:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:20:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:20:04 --> Final output sent to browser
DEBUG - 2016-03-03 23:20:04 --> Total execution time: 1.2096
INFO - 2016-03-03 20:21:27 --> Config Class Initialized
INFO - 2016-03-03 20:21:27 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:21:27 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:21:27 --> Utf8 Class Initialized
INFO - 2016-03-03 20:21:27 --> URI Class Initialized
INFO - 2016-03-03 20:21:27 --> Router Class Initialized
INFO - 2016-03-03 20:21:27 --> Output Class Initialized
INFO - 2016-03-03 20:21:27 --> Security Class Initialized
DEBUG - 2016-03-03 20:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:21:27 --> Input Class Initialized
INFO - 2016-03-03 20:21:27 --> Language Class Initialized
INFO - 2016-03-03 20:21:27 --> Loader Class Initialized
INFO - 2016-03-03 20:21:27 --> Helper loaded: url_helper
INFO - 2016-03-03 20:21:27 --> Helper loaded: file_helper
INFO - 2016-03-03 20:21:27 --> Helper loaded: date_helper
INFO - 2016-03-03 20:21:27 --> Helper loaded: form_helper
INFO - 2016-03-03 20:21:27 --> Database Driver Class Initialized
INFO - 2016-03-03 20:21:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:21:28 --> Controller Class Initialized
INFO - 2016-03-03 20:21:28 --> Model Class Initialized
INFO - 2016-03-03 20:21:28 --> Model Class Initialized
INFO - 2016-03-03 20:21:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:21:28 --> Pagination Class Initialized
INFO - 2016-03-03 20:21:28 --> Helper loaded: text_helper
INFO - 2016-03-03 20:21:28 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:21:28 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-03 23:21:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:21:28 --> Final output sent to browser
DEBUG - 2016-03-03 23:21:28 --> Total execution time: 1.2016
INFO - 2016-03-03 20:21:43 --> Config Class Initialized
INFO - 2016-03-03 20:21:43 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:21:43 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:21:43 --> Utf8 Class Initialized
INFO - 2016-03-03 20:21:43 --> URI Class Initialized
INFO - 2016-03-03 20:21:43 --> Router Class Initialized
INFO - 2016-03-03 20:21:43 --> Output Class Initialized
INFO - 2016-03-03 20:21:43 --> Security Class Initialized
DEBUG - 2016-03-03 20:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:21:43 --> Input Class Initialized
INFO - 2016-03-03 20:21:43 --> Language Class Initialized
INFO - 2016-03-03 20:21:43 --> Loader Class Initialized
INFO - 2016-03-03 20:21:43 --> Helper loaded: url_helper
INFO - 2016-03-03 20:21:43 --> Helper loaded: file_helper
INFO - 2016-03-03 20:21:43 --> Helper loaded: date_helper
INFO - 2016-03-03 20:21:43 --> Helper loaded: form_helper
INFO - 2016-03-03 20:21:43 --> Database Driver Class Initialized
INFO - 2016-03-03 20:21:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:21:44 --> Controller Class Initialized
INFO - 2016-03-03 20:21:44 --> Model Class Initialized
INFO - 2016-03-03 20:21:44 --> Model Class Initialized
INFO - 2016-03-03 20:21:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:21:44 --> Pagination Class Initialized
INFO - 2016-03-03 20:21:44 --> Helper loaded: text_helper
INFO - 2016-03-03 20:21:44 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:21:44 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:21:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:21:44 --> Final output sent to browser
DEBUG - 2016-03-03 23:21:44 --> Total execution time: 1.1329
INFO - 2016-03-03 20:23:00 --> Config Class Initialized
INFO - 2016-03-03 20:23:00 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:23:00 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:23:00 --> Utf8 Class Initialized
INFO - 2016-03-03 20:23:00 --> URI Class Initialized
INFO - 2016-03-03 20:23:00 --> Router Class Initialized
INFO - 2016-03-03 20:23:00 --> Output Class Initialized
INFO - 2016-03-03 20:23:00 --> Security Class Initialized
DEBUG - 2016-03-03 20:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:23:00 --> Input Class Initialized
INFO - 2016-03-03 20:23:00 --> Language Class Initialized
INFO - 2016-03-03 20:23:00 --> Loader Class Initialized
INFO - 2016-03-03 20:23:00 --> Helper loaded: url_helper
INFO - 2016-03-03 20:23:00 --> Helper loaded: file_helper
INFO - 2016-03-03 20:23:00 --> Helper loaded: date_helper
INFO - 2016-03-03 20:23:00 --> Helper loaded: form_helper
INFO - 2016-03-03 20:23:00 --> Database Driver Class Initialized
INFO - 2016-03-03 20:23:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:23:01 --> Controller Class Initialized
INFO - 2016-03-03 20:23:01 --> Model Class Initialized
INFO - 2016-03-03 20:23:01 --> Model Class Initialized
INFO - 2016-03-03 20:23:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:23:01 --> Pagination Class Initialized
INFO - 2016-03-03 20:23:01 --> Helper loaded: text_helper
INFO - 2016-03-03 20:23:01 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:23:01 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:23:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:23:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:23:01 --> Final output sent to browser
DEBUG - 2016-03-03 23:23:01 --> Total execution time: 1.1555
INFO - 2016-03-03 20:23:43 --> Config Class Initialized
INFO - 2016-03-03 20:23:44 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:23:44 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:23:44 --> Utf8 Class Initialized
INFO - 2016-03-03 20:23:44 --> URI Class Initialized
INFO - 2016-03-03 20:23:44 --> Router Class Initialized
INFO - 2016-03-03 20:23:44 --> Output Class Initialized
INFO - 2016-03-03 20:23:44 --> Security Class Initialized
DEBUG - 2016-03-03 20:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:23:44 --> Input Class Initialized
INFO - 2016-03-03 20:23:44 --> Language Class Initialized
INFO - 2016-03-03 20:23:44 --> Loader Class Initialized
INFO - 2016-03-03 20:23:44 --> Helper loaded: url_helper
INFO - 2016-03-03 20:23:44 --> Helper loaded: file_helper
INFO - 2016-03-03 20:23:44 --> Helper loaded: date_helper
INFO - 2016-03-03 20:23:44 --> Helper loaded: form_helper
INFO - 2016-03-03 20:23:44 --> Database Driver Class Initialized
INFO - 2016-03-03 20:23:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:23:45 --> Controller Class Initialized
INFO - 2016-03-03 20:23:45 --> Model Class Initialized
INFO - 2016-03-03 20:23:45 --> Model Class Initialized
INFO - 2016-03-03 20:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:23:45 --> Pagination Class Initialized
INFO - 2016-03-03 20:23:45 --> Helper loaded: text_helper
INFO - 2016-03-03 20:23:45 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:23:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:23:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:23:45 --> Final output sent to browser
DEBUG - 2016-03-03 23:23:45 --> Total execution time: 1.2708
INFO - 2016-03-03 20:28:49 --> Config Class Initialized
INFO - 2016-03-03 20:28:49 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:28:49 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:28:49 --> Utf8 Class Initialized
INFO - 2016-03-03 20:28:49 --> URI Class Initialized
INFO - 2016-03-03 20:28:49 --> Router Class Initialized
INFO - 2016-03-03 20:28:49 --> Output Class Initialized
INFO - 2016-03-03 20:28:49 --> Security Class Initialized
DEBUG - 2016-03-03 20:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:28:49 --> Input Class Initialized
INFO - 2016-03-03 20:28:49 --> Language Class Initialized
INFO - 2016-03-03 20:28:49 --> Loader Class Initialized
INFO - 2016-03-03 20:28:49 --> Helper loaded: url_helper
INFO - 2016-03-03 20:28:49 --> Helper loaded: file_helper
INFO - 2016-03-03 20:28:49 --> Helper loaded: date_helper
INFO - 2016-03-03 20:28:49 --> Helper loaded: form_helper
INFO - 2016-03-03 20:28:49 --> Database Driver Class Initialized
INFO - 2016-03-03 20:28:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:28:50 --> Controller Class Initialized
INFO - 2016-03-03 20:28:50 --> Model Class Initialized
INFO - 2016-03-03 20:28:50 --> Model Class Initialized
INFO - 2016-03-03 20:28:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:28:50 --> Pagination Class Initialized
INFO - 2016-03-03 20:28:50 --> Helper loaded: text_helper
INFO - 2016-03-03 20:28:50 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:28:50 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-03 23:28:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:28:50 --> Final output sent to browser
DEBUG - 2016-03-03 23:28:50 --> Total execution time: 1.1346
INFO - 2016-03-03 20:28:53 --> Config Class Initialized
INFO - 2016-03-03 20:28:53 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:28:53 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:28:53 --> Utf8 Class Initialized
INFO - 2016-03-03 20:28:53 --> URI Class Initialized
INFO - 2016-03-03 20:28:53 --> Router Class Initialized
INFO - 2016-03-03 20:28:53 --> Output Class Initialized
INFO - 2016-03-03 20:28:53 --> Security Class Initialized
DEBUG - 2016-03-03 20:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:28:53 --> Input Class Initialized
INFO - 2016-03-03 20:28:53 --> Language Class Initialized
INFO - 2016-03-03 20:28:53 --> Loader Class Initialized
INFO - 2016-03-03 20:28:53 --> Helper loaded: url_helper
INFO - 2016-03-03 20:28:53 --> Helper loaded: file_helper
INFO - 2016-03-03 20:28:53 --> Helper loaded: date_helper
INFO - 2016-03-03 20:28:53 --> Helper loaded: form_helper
INFO - 2016-03-03 20:28:53 --> Database Driver Class Initialized
INFO - 2016-03-03 20:28:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:28:54 --> Controller Class Initialized
INFO - 2016-03-03 20:28:54 --> Model Class Initialized
INFO - 2016-03-03 20:28:54 --> Model Class Initialized
INFO - 2016-03-03 20:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:28:54 --> Pagination Class Initialized
INFO - 2016-03-03 20:28:54 --> Helper loaded: text_helper
INFO - 2016-03-03 20:28:54 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:28:54 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:28:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:28:54 --> Final output sent to browser
DEBUG - 2016-03-03 23:28:54 --> Total execution time: 1.1491
INFO - 2016-03-03 20:28:58 --> Config Class Initialized
INFO - 2016-03-03 20:28:58 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:28:58 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:28:58 --> Utf8 Class Initialized
INFO - 2016-03-03 20:28:58 --> URI Class Initialized
INFO - 2016-03-03 20:28:58 --> Router Class Initialized
INFO - 2016-03-03 20:28:58 --> Output Class Initialized
INFO - 2016-03-03 20:28:58 --> Security Class Initialized
DEBUG - 2016-03-03 20:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:28:58 --> Input Class Initialized
INFO - 2016-03-03 20:28:58 --> Language Class Initialized
INFO - 2016-03-03 20:28:58 --> Loader Class Initialized
INFO - 2016-03-03 20:28:58 --> Helper loaded: url_helper
INFO - 2016-03-03 20:28:58 --> Helper loaded: file_helper
INFO - 2016-03-03 20:28:58 --> Helper loaded: date_helper
INFO - 2016-03-03 20:28:58 --> Helper loaded: form_helper
INFO - 2016-03-03 20:28:58 --> Database Driver Class Initialized
INFO - 2016-03-03 20:28:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:28:59 --> Controller Class Initialized
INFO - 2016-03-03 20:28:59 --> Model Class Initialized
INFO - 2016-03-03 20:28:59 --> Model Class Initialized
INFO - 2016-03-03 20:28:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:28:59 --> Pagination Class Initialized
INFO - 2016-03-03 20:28:59 --> Helper loaded: text_helper
INFO - 2016-03-03 20:28:59 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 23:28:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:28:59 --> Final output sent to browser
DEBUG - 2016-03-03 23:28:59 --> Total execution time: 1.2634
INFO - 2016-03-03 20:29:27 --> Config Class Initialized
INFO - 2016-03-03 20:29:27 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:29:27 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:29:27 --> Utf8 Class Initialized
INFO - 2016-03-03 20:29:27 --> URI Class Initialized
INFO - 2016-03-03 20:29:27 --> Router Class Initialized
INFO - 2016-03-03 20:29:27 --> Output Class Initialized
INFO - 2016-03-03 20:29:27 --> Security Class Initialized
DEBUG - 2016-03-03 20:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:29:27 --> Input Class Initialized
INFO - 2016-03-03 20:29:27 --> Language Class Initialized
INFO - 2016-03-03 20:29:27 --> Loader Class Initialized
INFO - 2016-03-03 20:29:27 --> Helper loaded: url_helper
INFO - 2016-03-03 20:29:27 --> Helper loaded: file_helper
INFO - 2016-03-03 20:29:27 --> Helper loaded: date_helper
INFO - 2016-03-03 20:29:27 --> Helper loaded: form_helper
INFO - 2016-03-03 20:29:27 --> Database Driver Class Initialized
INFO - 2016-03-03 20:29:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:29:28 --> Controller Class Initialized
INFO - 2016-03-03 20:29:28 --> Model Class Initialized
INFO - 2016-03-03 20:29:28 --> Model Class Initialized
INFO - 2016-03-03 20:29:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:29:28 --> Pagination Class Initialized
INFO - 2016-03-03 20:29:28 --> Helper loaded: text_helper
INFO - 2016-03-03 20:29:28 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 23:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 23:29:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:29:28 --> Final output sent to browser
DEBUG - 2016-03-03 23:29:28 --> Total execution time: 1.2105
INFO - 2016-03-03 20:29:39 --> Config Class Initialized
INFO - 2016-03-03 20:29:39 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:29:39 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:29:39 --> Utf8 Class Initialized
INFO - 2016-03-03 20:29:39 --> URI Class Initialized
INFO - 2016-03-03 20:29:39 --> Router Class Initialized
INFO - 2016-03-03 20:29:39 --> Output Class Initialized
INFO - 2016-03-03 20:29:39 --> Security Class Initialized
DEBUG - 2016-03-03 20:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:29:39 --> Input Class Initialized
INFO - 2016-03-03 20:29:39 --> Language Class Initialized
INFO - 2016-03-03 20:29:39 --> Loader Class Initialized
INFO - 2016-03-03 20:29:39 --> Helper loaded: url_helper
INFO - 2016-03-03 20:29:39 --> Helper loaded: file_helper
INFO - 2016-03-03 20:29:39 --> Helper loaded: date_helper
INFO - 2016-03-03 20:29:39 --> Helper loaded: form_helper
INFO - 2016-03-03 20:29:39 --> Database Driver Class Initialized
INFO - 2016-03-03 20:29:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:29:40 --> Controller Class Initialized
INFO - 2016-03-03 20:29:40 --> Model Class Initialized
INFO - 2016-03-03 20:29:40 --> Model Class Initialized
INFO - 2016-03-03 20:29:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:29:40 --> Pagination Class Initialized
INFO - 2016-03-03 20:29:40 --> Helper loaded: text_helper
INFO - 2016-03-03 20:29:40 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:29:40 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:29:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:29:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:29:40 --> Final output sent to browser
DEBUG - 2016-03-03 23:29:40 --> Total execution time: 1.1445
INFO - 2016-03-03 20:32:12 --> Config Class Initialized
INFO - 2016-03-03 20:32:12 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:32:12 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:32:12 --> Utf8 Class Initialized
INFO - 2016-03-03 20:32:12 --> URI Class Initialized
INFO - 2016-03-03 20:32:12 --> Router Class Initialized
INFO - 2016-03-03 20:32:12 --> Output Class Initialized
INFO - 2016-03-03 20:32:12 --> Security Class Initialized
DEBUG - 2016-03-03 20:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:32:12 --> Input Class Initialized
INFO - 2016-03-03 20:32:12 --> Language Class Initialized
INFO - 2016-03-03 20:32:12 --> Loader Class Initialized
INFO - 2016-03-03 20:32:12 --> Helper loaded: url_helper
INFO - 2016-03-03 20:32:12 --> Helper loaded: file_helper
INFO - 2016-03-03 20:32:12 --> Helper loaded: date_helper
INFO - 2016-03-03 20:32:12 --> Helper loaded: form_helper
INFO - 2016-03-03 20:32:12 --> Database Driver Class Initialized
INFO - 2016-03-03 20:32:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:32:13 --> Controller Class Initialized
INFO - 2016-03-03 20:32:13 --> Model Class Initialized
INFO - 2016-03-03 20:32:13 --> Model Class Initialized
INFO - 2016-03-03 20:32:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:32:13 --> Pagination Class Initialized
INFO - 2016-03-03 20:32:13 --> Helper loaded: text_helper
INFO - 2016-03-03 20:32:13 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:32:13 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:32:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:32:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:32:13 --> Final output sent to browser
DEBUG - 2016-03-03 23:32:13 --> Total execution time: 1.1516
INFO - 2016-03-03 20:33:06 --> Config Class Initialized
INFO - 2016-03-03 20:33:06 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:33:06 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:33:06 --> Utf8 Class Initialized
INFO - 2016-03-03 20:33:06 --> URI Class Initialized
INFO - 2016-03-03 20:33:06 --> Router Class Initialized
INFO - 2016-03-03 20:33:06 --> Output Class Initialized
INFO - 2016-03-03 20:33:06 --> Security Class Initialized
DEBUG - 2016-03-03 20:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:33:06 --> Input Class Initialized
INFO - 2016-03-03 20:33:06 --> Language Class Initialized
INFO - 2016-03-03 20:33:06 --> Loader Class Initialized
INFO - 2016-03-03 20:33:06 --> Helper loaded: url_helper
INFO - 2016-03-03 20:33:06 --> Helper loaded: file_helper
INFO - 2016-03-03 20:33:06 --> Helper loaded: date_helper
INFO - 2016-03-03 20:33:06 --> Helper loaded: form_helper
INFO - 2016-03-03 20:33:06 --> Database Driver Class Initialized
INFO - 2016-03-03 20:33:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:33:07 --> Controller Class Initialized
INFO - 2016-03-03 20:33:07 --> Model Class Initialized
INFO - 2016-03-03 20:33:07 --> Model Class Initialized
INFO - 2016-03-03 20:33:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:33:07 --> Pagination Class Initialized
INFO - 2016-03-03 20:33:07 --> Helper loaded: text_helper
INFO - 2016-03-03 20:33:07 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:33:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:33:07 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:33:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:33:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:33:08 --> Final output sent to browser
DEBUG - 2016-03-03 23:33:08 --> Total execution time: 1.1876
INFO - 2016-03-03 20:34:30 --> Config Class Initialized
INFO - 2016-03-03 20:34:30 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:34:30 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:34:30 --> Utf8 Class Initialized
INFO - 2016-03-03 20:34:30 --> URI Class Initialized
INFO - 2016-03-03 20:34:30 --> Router Class Initialized
INFO - 2016-03-03 20:34:30 --> Output Class Initialized
INFO - 2016-03-03 20:34:30 --> Security Class Initialized
DEBUG - 2016-03-03 20:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:34:30 --> Input Class Initialized
INFO - 2016-03-03 20:34:30 --> Language Class Initialized
INFO - 2016-03-03 20:34:30 --> Loader Class Initialized
INFO - 2016-03-03 20:34:30 --> Helper loaded: url_helper
INFO - 2016-03-03 20:34:30 --> Helper loaded: file_helper
INFO - 2016-03-03 20:34:30 --> Helper loaded: date_helper
INFO - 2016-03-03 20:34:30 --> Helper loaded: form_helper
INFO - 2016-03-03 20:34:30 --> Database Driver Class Initialized
INFO - 2016-03-03 20:34:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:34:31 --> Controller Class Initialized
INFO - 2016-03-03 20:34:31 --> Model Class Initialized
INFO - 2016-03-03 20:34:31 --> Model Class Initialized
INFO - 2016-03-03 20:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:34:31 --> Pagination Class Initialized
INFO - 2016-03-03 20:34:31 --> Helper loaded: text_helper
INFO - 2016-03-03 20:34:31 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:34:31 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:34:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:34:31 --> Final output sent to browser
DEBUG - 2016-03-03 23:34:31 --> Total execution time: 1.1051
INFO - 2016-03-03 20:34:58 --> Config Class Initialized
INFO - 2016-03-03 20:34:58 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:34:58 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:34:58 --> Utf8 Class Initialized
INFO - 2016-03-03 20:34:58 --> URI Class Initialized
INFO - 2016-03-03 20:34:58 --> Router Class Initialized
INFO - 2016-03-03 20:34:58 --> Output Class Initialized
INFO - 2016-03-03 20:34:58 --> Security Class Initialized
DEBUG - 2016-03-03 20:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:34:58 --> Input Class Initialized
INFO - 2016-03-03 20:34:58 --> Language Class Initialized
INFO - 2016-03-03 20:34:58 --> Loader Class Initialized
INFO - 2016-03-03 20:34:58 --> Helper loaded: url_helper
INFO - 2016-03-03 20:34:58 --> Helper loaded: file_helper
INFO - 2016-03-03 20:34:58 --> Helper loaded: date_helper
INFO - 2016-03-03 20:34:58 --> Helper loaded: form_helper
INFO - 2016-03-03 20:34:58 --> Database Driver Class Initialized
INFO - 2016-03-03 20:34:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:34:59 --> Controller Class Initialized
INFO - 2016-03-03 20:34:59 --> Model Class Initialized
INFO - 2016-03-03 20:34:59 --> Model Class Initialized
INFO - 2016-03-03 20:34:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:34:59 --> Pagination Class Initialized
INFO - 2016-03-03 20:34:59 --> Helper loaded: text_helper
INFO - 2016-03-03 20:34:59 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:34:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:34:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:34:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:34:59 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:34:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:34:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:34:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:34:59 --> Final output sent to browser
DEBUG - 2016-03-03 23:34:59 --> Total execution time: 1.1767
INFO - 2016-03-03 20:39:45 --> Config Class Initialized
INFO - 2016-03-03 20:39:45 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:39:45 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:39:45 --> Utf8 Class Initialized
INFO - 2016-03-03 20:39:45 --> URI Class Initialized
INFO - 2016-03-03 20:39:45 --> Router Class Initialized
INFO - 2016-03-03 20:39:45 --> Output Class Initialized
INFO - 2016-03-03 20:39:45 --> Security Class Initialized
DEBUG - 2016-03-03 20:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:39:45 --> Input Class Initialized
INFO - 2016-03-03 20:39:45 --> Language Class Initialized
INFO - 2016-03-03 20:39:45 --> Loader Class Initialized
INFO - 2016-03-03 20:39:45 --> Helper loaded: url_helper
INFO - 2016-03-03 20:39:45 --> Helper loaded: file_helper
INFO - 2016-03-03 20:39:45 --> Helper loaded: date_helper
INFO - 2016-03-03 20:39:45 --> Helper loaded: form_helper
INFO - 2016-03-03 20:39:45 --> Database Driver Class Initialized
INFO - 2016-03-03 20:39:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:39:46 --> Controller Class Initialized
INFO - 2016-03-03 20:39:46 --> Model Class Initialized
INFO - 2016-03-03 20:39:46 --> Model Class Initialized
INFO - 2016-03-03 20:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:39:46 --> Pagination Class Initialized
INFO - 2016-03-03 20:39:46 --> Helper loaded: text_helper
INFO - 2016-03-03 20:39:46 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:39:46 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:39:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:39:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:39:46 --> Final output sent to browser
DEBUG - 2016-03-03 23:39:46 --> Total execution time: 1.1405
INFO - 2016-03-03 20:41:44 --> Config Class Initialized
INFO - 2016-03-03 20:41:44 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:41:44 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:41:44 --> Utf8 Class Initialized
INFO - 2016-03-03 20:41:44 --> URI Class Initialized
INFO - 2016-03-03 20:41:44 --> Router Class Initialized
INFO - 2016-03-03 20:41:44 --> Output Class Initialized
INFO - 2016-03-03 20:41:44 --> Security Class Initialized
DEBUG - 2016-03-03 20:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:41:44 --> Input Class Initialized
INFO - 2016-03-03 20:41:44 --> Language Class Initialized
INFO - 2016-03-03 20:41:44 --> Loader Class Initialized
INFO - 2016-03-03 20:41:44 --> Helper loaded: url_helper
INFO - 2016-03-03 20:41:44 --> Helper loaded: file_helper
INFO - 2016-03-03 20:41:44 --> Helper loaded: date_helper
INFO - 2016-03-03 20:41:44 --> Helper loaded: form_helper
INFO - 2016-03-03 20:41:44 --> Database Driver Class Initialized
INFO - 2016-03-03 20:41:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:41:45 --> Controller Class Initialized
INFO - 2016-03-03 20:41:45 --> Model Class Initialized
INFO - 2016-03-03 20:41:45 --> Model Class Initialized
INFO - 2016-03-03 20:41:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:41:45 --> Pagination Class Initialized
INFO - 2016-03-03 20:41:45 --> Helper loaded: text_helper
INFO - 2016-03-03 20:41:45 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:41:45 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:41:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:41:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:41:45 --> Final output sent to browser
DEBUG - 2016-03-03 23:41:45 --> Total execution time: 1.1836
INFO - 2016-03-03 20:45:39 --> Config Class Initialized
INFO - 2016-03-03 20:45:39 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:45:39 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:45:39 --> Utf8 Class Initialized
INFO - 2016-03-03 20:45:39 --> URI Class Initialized
INFO - 2016-03-03 20:45:39 --> Router Class Initialized
INFO - 2016-03-03 20:45:39 --> Output Class Initialized
INFO - 2016-03-03 20:45:39 --> Security Class Initialized
DEBUG - 2016-03-03 20:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:45:39 --> Input Class Initialized
INFO - 2016-03-03 20:45:39 --> Language Class Initialized
INFO - 2016-03-03 20:45:39 --> Loader Class Initialized
INFO - 2016-03-03 20:45:39 --> Helper loaded: url_helper
INFO - 2016-03-03 20:45:39 --> Helper loaded: file_helper
INFO - 2016-03-03 20:45:39 --> Helper loaded: date_helper
INFO - 2016-03-03 20:45:39 --> Helper loaded: form_helper
INFO - 2016-03-03 20:45:39 --> Database Driver Class Initialized
INFO - 2016-03-03 20:45:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:45:40 --> Controller Class Initialized
INFO - 2016-03-03 20:45:40 --> Model Class Initialized
INFO - 2016-03-03 20:45:40 --> Model Class Initialized
INFO - 2016-03-03 20:45:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:45:41 --> Pagination Class Initialized
INFO - 2016-03-03 20:45:41 --> Helper loaded: text_helper
INFO - 2016-03-03 20:45:41 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:45:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:45:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:45:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:45:41 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:45:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:45:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:45:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:45:41 --> Final output sent to browser
DEBUG - 2016-03-03 23:45:41 --> Total execution time: 1.1599
INFO - 2016-03-03 20:46:11 --> Config Class Initialized
INFO - 2016-03-03 20:46:11 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:46:11 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:46:11 --> Utf8 Class Initialized
INFO - 2016-03-03 20:46:11 --> URI Class Initialized
INFO - 2016-03-03 20:46:11 --> Router Class Initialized
INFO - 2016-03-03 20:46:11 --> Output Class Initialized
INFO - 2016-03-03 20:46:11 --> Security Class Initialized
DEBUG - 2016-03-03 20:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:46:11 --> Input Class Initialized
INFO - 2016-03-03 20:46:11 --> Language Class Initialized
INFO - 2016-03-03 20:46:11 --> Loader Class Initialized
INFO - 2016-03-03 20:46:11 --> Helper loaded: url_helper
INFO - 2016-03-03 20:46:11 --> Helper loaded: file_helper
INFO - 2016-03-03 20:46:11 --> Helper loaded: date_helper
INFO - 2016-03-03 20:46:11 --> Helper loaded: form_helper
INFO - 2016-03-03 20:46:11 --> Database Driver Class Initialized
INFO - 2016-03-03 20:46:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:46:12 --> Controller Class Initialized
INFO - 2016-03-03 20:46:12 --> Model Class Initialized
INFO - 2016-03-03 20:46:12 --> Model Class Initialized
INFO - 2016-03-03 20:46:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:46:12 --> Pagination Class Initialized
INFO - 2016-03-03 20:46:12 --> Helper loaded: text_helper
INFO - 2016-03-03 20:46:12 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:46:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:46:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:46:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:46:12 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:46:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:46:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:46:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:46:12 --> Final output sent to browser
DEBUG - 2016-03-03 23:46:12 --> Total execution time: 1.1239
INFO - 2016-03-03 20:46:24 --> Config Class Initialized
INFO - 2016-03-03 20:46:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:46:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:46:24 --> Utf8 Class Initialized
INFO - 2016-03-03 20:46:24 --> URI Class Initialized
INFO - 2016-03-03 20:46:24 --> Router Class Initialized
INFO - 2016-03-03 20:46:24 --> Output Class Initialized
INFO - 2016-03-03 20:46:24 --> Security Class Initialized
DEBUG - 2016-03-03 20:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:46:24 --> Input Class Initialized
INFO - 2016-03-03 20:46:24 --> Language Class Initialized
INFO - 2016-03-03 20:46:24 --> Loader Class Initialized
INFO - 2016-03-03 20:46:24 --> Helper loaded: url_helper
INFO - 2016-03-03 20:46:24 --> Helper loaded: file_helper
INFO - 2016-03-03 20:46:24 --> Helper loaded: date_helper
INFO - 2016-03-03 20:46:24 --> Helper loaded: form_helper
INFO - 2016-03-03 20:46:24 --> Database Driver Class Initialized
INFO - 2016-03-03 20:46:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:46:25 --> Controller Class Initialized
INFO - 2016-03-03 20:46:25 --> Model Class Initialized
INFO - 2016-03-03 20:46:25 --> Model Class Initialized
INFO - 2016-03-03 20:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:46:25 --> Pagination Class Initialized
INFO - 2016-03-03 20:46:25 --> Helper loaded: text_helper
INFO - 2016-03-03 20:46:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:46:25 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:46:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:46:25 --> Final output sent to browser
DEBUG - 2016-03-03 23:46:25 --> Total execution time: 1.1025
INFO - 2016-03-03 20:46:33 --> Config Class Initialized
INFO - 2016-03-03 20:46:33 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:46:33 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:46:33 --> Utf8 Class Initialized
INFO - 2016-03-03 20:46:33 --> URI Class Initialized
INFO - 2016-03-03 20:46:33 --> Router Class Initialized
INFO - 2016-03-03 20:46:33 --> Output Class Initialized
INFO - 2016-03-03 20:46:33 --> Security Class Initialized
DEBUG - 2016-03-03 20:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:46:33 --> Input Class Initialized
INFO - 2016-03-03 20:46:33 --> Language Class Initialized
INFO - 2016-03-03 20:46:33 --> Loader Class Initialized
INFO - 2016-03-03 20:46:33 --> Helper loaded: url_helper
INFO - 2016-03-03 20:46:33 --> Helper loaded: file_helper
INFO - 2016-03-03 20:46:33 --> Helper loaded: date_helper
INFO - 2016-03-03 20:46:33 --> Helper loaded: form_helper
INFO - 2016-03-03 20:46:33 --> Database Driver Class Initialized
INFO - 2016-03-03 20:46:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:46:34 --> Controller Class Initialized
INFO - 2016-03-03 20:46:34 --> Model Class Initialized
INFO - 2016-03-03 20:46:34 --> Model Class Initialized
INFO - 2016-03-03 20:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:46:34 --> Pagination Class Initialized
INFO - 2016-03-03 20:46:34 --> Helper loaded: text_helper
INFO - 2016-03-03 20:46:34 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:46:34 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:46:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:46:34 --> Final output sent to browser
DEBUG - 2016-03-03 23:46:34 --> Total execution time: 1.1854
INFO - 2016-03-03 20:47:05 --> Config Class Initialized
INFO - 2016-03-03 20:47:05 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:47:05 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:47:05 --> Utf8 Class Initialized
INFO - 2016-03-03 20:47:05 --> URI Class Initialized
INFO - 2016-03-03 20:47:05 --> Router Class Initialized
INFO - 2016-03-03 20:47:05 --> Output Class Initialized
INFO - 2016-03-03 20:47:05 --> Security Class Initialized
DEBUG - 2016-03-03 20:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:47:05 --> Input Class Initialized
INFO - 2016-03-03 20:47:05 --> Language Class Initialized
INFO - 2016-03-03 20:47:05 --> Loader Class Initialized
INFO - 2016-03-03 20:47:05 --> Helper loaded: url_helper
INFO - 2016-03-03 20:47:05 --> Helper loaded: file_helper
INFO - 2016-03-03 20:47:05 --> Helper loaded: date_helper
INFO - 2016-03-03 20:47:05 --> Helper loaded: form_helper
INFO - 2016-03-03 20:47:05 --> Database Driver Class Initialized
INFO - 2016-03-03 20:47:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:47:06 --> Controller Class Initialized
INFO - 2016-03-03 20:47:06 --> Model Class Initialized
INFO - 2016-03-03 20:47:06 --> Model Class Initialized
INFO - 2016-03-03 20:47:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:47:06 --> Pagination Class Initialized
INFO - 2016-03-03 20:47:06 --> Helper loaded: text_helper
INFO - 2016-03-03 20:47:06 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:47:06 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:47:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:47:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:47:06 --> Final output sent to browser
DEBUG - 2016-03-03 23:47:06 --> Total execution time: 1.1795
INFO - 2016-03-03 20:47:09 --> Config Class Initialized
INFO - 2016-03-03 20:47:09 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:47:09 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:47:09 --> Utf8 Class Initialized
INFO - 2016-03-03 20:47:09 --> URI Class Initialized
INFO - 2016-03-03 20:47:09 --> Router Class Initialized
INFO - 2016-03-03 20:47:09 --> Output Class Initialized
INFO - 2016-03-03 20:47:10 --> Security Class Initialized
DEBUG - 2016-03-03 20:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:47:10 --> Input Class Initialized
INFO - 2016-03-03 20:47:10 --> Language Class Initialized
INFO - 2016-03-03 20:47:10 --> Loader Class Initialized
INFO - 2016-03-03 20:47:10 --> Helper loaded: url_helper
INFO - 2016-03-03 20:47:10 --> Helper loaded: file_helper
INFO - 2016-03-03 20:47:10 --> Helper loaded: date_helper
INFO - 2016-03-03 20:47:10 --> Helper loaded: form_helper
INFO - 2016-03-03 20:47:10 --> Database Driver Class Initialized
INFO - 2016-03-03 20:47:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:47:11 --> Controller Class Initialized
INFO - 2016-03-03 20:47:11 --> Model Class Initialized
INFO - 2016-03-03 20:47:11 --> Model Class Initialized
INFO - 2016-03-03 20:47:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:47:11 --> Pagination Class Initialized
INFO - 2016-03-03 20:47:11 --> Helper loaded: text_helper
INFO - 2016-03-03 20:47:11 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:47:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:47:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:47:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:47:11 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:47:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:47:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:47:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:47:11 --> Final output sent to browser
DEBUG - 2016-03-03 23:47:11 --> Total execution time: 1.1607
INFO - 2016-03-03 20:52:24 --> Config Class Initialized
INFO - 2016-03-03 20:52:24 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:52:24 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:52:24 --> Utf8 Class Initialized
INFO - 2016-03-03 20:52:24 --> URI Class Initialized
INFO - 2016-03-03 20:52:24 --> Router Class Initialized
INFO - 2016-03-03 20:52:24 --> Output Class Initialized
INFO - 2016-03-03 20:52:24 --> Security Class Initialized
DEBUG - 2016-03-03 20:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:52:24 --> Input Class Initialized
INFO - 2016-03-03 20:52:24 --> Language Class Initialized
INFO - 2016-03-03 20:52:24 --> Loader Class Initialized
INFO - 2016-03-03 20:52:24 --> Helper loaded: url_helper
INFO - 2016-03-03 20:52:24 --> Helper loaded: file_helper
INFO - 2016-03-03 20:52:24 --> Helper loaded: date_helper
INFO - 2016-03-03 20:52:24 --> Helper loaded: form_helper
INFO - 2016-03-03 20:52:24 --> Database Driver Class Initialized
INFO - 2016-03-03 20:52:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:52:25 --> Controller Class Initialized
INFO - 2016-03-03 20:52:25 --> Model Class Initialized
INFO - 2016-03-03 20:52:25 --> Model Class Initialized
INFO - 2016-03-03 20:52:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:52:25 --> Pagination Class Initialized
INFO - 2016-03-03 20:52:25 --> Helper loaded: text_helper
INFO - 2016-03-03 20:52:25 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:52:25 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:52:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:52:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:52:25 --> Final output sent to browser
DEBUG - 2016-03-03 23:52:25 --> Total execution time: 1.1323
INFO - 2016-03-03 20:55:29 --> Config Class Initialized
INFO - 2016-03-03 20:55:29 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:55:29 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:55:29 --> Utf8 Class Initialized
INFO - 2016-03-03 20:55:29 --> URI Class Initialized
INFO - 2016-03-03 20:55:29 --> Router Class Initialized
INFO - 2016-03-03 20:55:29 --> Output Class Initialized
INFO - 2016-03-03 20:55:29 --> Security Class Initialized
DEBUG - 2016-03-03 20:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:55:29 --> Input Class Initialized
INFO - 2016-03-03 20:55:29 --> Language Class Initialized
INFO - 2016-03-03 20:55:29 --> Loader Class Initialized
INFO - 2016-03-03 20:55:29 --> Helper loaded: url_helper
INFO - 2016-03-03 20:55:29 --> Helper loaded: file_helper
INFO - 2016-03-03 20:55:29 --> Helper loaded: date_helper
INFO - 2016-03-03 20:55:29 --> Helper loaded: form_helper
INFO - 2016-03-03 20:55:29 --> Database Driver Class Initialized
INFO - 2016-03-03 20:55:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:55:30 --> Controller Class Initialized
INFO - 2016-03-03 20:55:30 --> Model Class Initialized
INFO - 2016-03-03 20:55:30 --> Model Class Initialized
INFO - 2016-03-03 20:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:55:30 --> Pagination Class Initialized
INFO - 2016-03-03 20:55:30 --> Helper loaded: text_helper
INFO - 2016-03-03 20:55:30 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:55:30 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:55:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:55:30 --> Final output sent to browser
DEBUG - 2016-03-03 23:55:30 --> Total execution time: 1.1842
INFO - 2016-03-03 20:56:28 --> Config Class Initialized
INFO - 2016-03-03 20:56:28 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:56:28 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:56:28 --> Utf8 Class Initialized
INFO - 2016-03-03 20:56:28 --> URI Class Initialized
INFO - 2016-03-03 20:56:28 --> Router Class Initialized
INFO - 2016-03-03 20:56:28 --> Output Class Initialized
INFO - 2016-03-03 20:56:28 --> Security Class Initialized
DEBUG - 2016-03-03 20:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:56:28 --> Input Class Initialized
INFO - 2016-03-03 20:56:28 --> Language Class Initialized
INFO - 2016-03-03 20:56:28 --> Loader Class Initialized
INFO - 2016-03-03 20:56:28 --> Helper loaded: url_helper
INFO - 2016-03-03 20:56:28 --> Helper loaded: file_helper
INFO - 2016-03-03 20:56:28 --> Helper loaded: date_helper
INFO - 2016-03-03 20:56:28 --> Helper loaded: form_helper
INFO - 2016-03-03 20:56:28 --> Database Driver Class Initialized
INFO - 2016-03-03 20:56:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:56:29 --> Controller Class Initialized
INFO - 2016-03-03 20:56:29 --> Model Class Initialized
INFO - 2016-03-03 20:56:29 --> Model Class Initialized
INFO - 2016-03-03 20:56:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:56:30 --> Pagination Class Initialized
INFO - 2016-03-03 20:56:30 --> Helper loaded: text_helper
INFO - 2016-03-03 20:56:30 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 23:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 23:56:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:56:30 --> Final output sent to browser
DEBUG - 2016-03-03 23:56:30 --> Total execution time: 1.2495
INFO - 2016-03-03 20:56:36 --> Config Class Initialized
INFO - 2016-03-03 20:56:36 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:56:36 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:56:36 --> Utf8 Class Initialized
INFO - 2016-03-03 20:56:36 --> URI Class Initialized
INFO - 2016-03-03 20:56:36 --> Router Class Initialized
INFO - 2016-03-03 20:56:36 --> Output Class Initialized
INFO - 2016-03-03 20:56:36 --> Security Class Initialized
DEBUG - 2016-03-03 20:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:56:36 --> Input Class Initialized
INFO - 2016-03-03 20:56:36 --> Language Class Initialized
INFO - 2016-03-03 20:56:36 --> Loader Class Initialized
INFO - 2016-03-03 20:56:36 --> Helper loaded: url_helper
INFO - 2016-03-03 20:56:36 --> Helper loaded: file_helper
INFO - 2016-03-03 20:56:36 --> Helper loaded: date_helper
INFO - 2016-03-03 20:56:36 --> Helper loaded: form_helper
INFO - 2016-03-03 20:56:36 --> Database Driver Class Initialized
INFO - 2016-03-03 20:56:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:56:37 --> Controller Class Initialized
INFO - 2016-03-03 20:56:37 --> Model Class Initialized
INFO - 2016-03-03 20:56:37 --> Model Class Initialized
INFO - 2016-03-03 20:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:56:37 --> Pagination Class Initialized
INFO - 2016-03-03 20:56:37 --> Helper loaded: text_helper
INFO - 2016-03-03 20:56:37 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
ERROR - 2016-03-03 23:56:37 --> Severity: Notice --> Undefined variable: popular C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
ERROR - 2016-03-03 23:56:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php 22
INFO - 2016-03-03 23:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-03 23:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:56:37 --> Final output sent to browser
DEBUG - 2016-03-03 23:56:37 --> Total execution time: 1.1223
INFO - 2016-03-03 20:56:39 --> Config Class Initialized
INFO - 2016-03-03 20:56:39 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:56:39 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:56:39 --> Utf8 Class Initialized
INFO - 2016-03-03 20:56:39 --> URI Class Initialized
INFO - 2016-03-03 20:56:39 --> Router Class Initialized
INFO - 2016-03-03 20:56:39 --> Output Class Initialized
INFO - 2016-03-03 20:56:39 --> Security Class Initialized
DEBUG - 2016-03-03 20:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:56:39 --> Input Class Initialized
INFO - 2016-03-03 20:56:39 --> Language Class Initialized
INFO - 2016-03-03 20:56:39 --> Loader Class Initialized
INFO - 2016-03-03 20:56:39 --> Helper loaded: url_helper
INFO - 2016-03-03 20:56:39 --> Helper loaded: file_helper
INFO - 2016-03-03 20:56:39 --> Helper loaded: date_helper
INFO - 2016-03-03 20:56:39 --> Helper loaded: form_helper
INFO - 2016-03-03 20:56:39 --> Database Driver Class Initialized
INFO - 2016-03-03 20:56:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:56:40 --> Controller Class Initialized
INFO - 2016-03-03 20:56:40 --> Model Class Initialized
INFO - 2016-03-03 20:56:40 --> Model Class Initialized
INFO - 2016-03-03 20:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:56:40 --> Pagination Class Initialized
INFO - 2016-03-03 20:56:40 --> Helper loaded: text_helper
INFO - 2016-03-03 20:56:40 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 23:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 23:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:56:40 --> Final output sent to browser
DEBUG - 2016-03-03 23:56:40 --> Total execution time: 1.1719
INFO - 2016-03-03 20:58:16 --> Config Class Initialized
INFO - 2016-03-03 20:58:16 --> Hooks Class Initialized
DEBUG - 2016-03-03 20:58:16 --> UTF-8 Support Enabled
INFO - 2016-03-03 20:58:16 --> Utf8 Class Initialized
INFO - 2016-03-03 20:58:16 --> URI Class Initialized
INFO - 2016-03-03 20:58:16 --> Router Class Initialized
INFO - 2016-03-03 20:58:16 --> Output Class Initialized
INFO - 2016-03-03 20:58:16 --> Security Class Initialized
DEBUG - 2016-03-03 20:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 20:58:16 --> Input Class Initialized
INFO - 2016-03-03 20:58:16 --> Language Class Initialized
INFO - 2016-03-03 20:58:16 --> Loader Class Initialized
INFO - 2016-03-03 20:58:16 --> Helper loaded: url_helper
INFO - 2016-03-03 20:58:16 --> Helper loaded: file_helper
INFO - 2016-03-03 20:58:16 --> Helper loaded: date_helper
INFO - 2016-03-03 20:58:16 --> Helper loaded: form_helper
INFO - 2016-03-03 20:58:16 --> Database Driver Class Initialized
INFO - 2016-03-03 20:58:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 20:58:17 --> Controller Class Initialized
INFO - 2016-03-03 20:58:17 --> Model Class Initialized
INFO - 2016-03-03 20:58:17 --> Model Class Initialized
INFO - 2016-03-03 20:58:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 20:58:17 --> Pagination Class Initialized
INFO - 2016-03-03 20:58:17 --> Helper loaded: text_helper
INFO - 2016-03-03 20:58:17 --> Helper loaded: cookie_helper
INFO - 2016-03-03 23:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-03 23:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-03 23:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-03 23:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-03 23:58:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-03 23:58:17 --> Final output sent to browser
DEBUG - 2016-03-03 23:58:17 --> Total execution time: 1.2118
INFO - 2016-03-03 21:02:04 --> Config Class Initialized
INFO - 2016-03-03 21:02:04 --> Hooks Class Initialized
DEBUG - 2016-03-03 21:02:04 --> UTF-8 Support Enabled
INFO - 2016-03-03 21:02:04 --> Utf8 Class Initialized
INFO - 2016-03-03 21:02:04 --> URI Class Initialized
INFO - 2016-03-03 21:02:04 --> Router Class Initialized
INFO - 2016-03-03 21:02:04 --> Output Class Initialized
INFO - 2016-03-03 21:02:04 --> Security Class Initialized
DEBUG - 2016-03-03 21:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 21:02:04 --> Input Class Initialized
INFO - 2016-03-03 21:02:04 --> Language Class Initialized
INFO - 2016-03-03 21:02:04 --> Loader Class Initialized
INFO - 2016-03-03 21:02:04 --> Helper loaded: url_helper
INFO - 2016-03-03 21:02:04 --> Helper loaded: file_helper
INFO - 2016-03-03 21:02:04 --> Helper loaded: date_helper
INFO - 2016-03-03 21:02:04 --> Helper loaded: form_helper
INFO - 2016-03-03 21:02:04 --> Database Driver Class Initialized
INFO - 2016-03-03 21:02:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 21:02:05 --> Controller Class Initialized
INFO - 2016-03-03 21:02:05 --> Model Class Initialized
INFO - 2016-03-03 21:02:05 --> Model Class Initialized
INFO - 2016-03-03 21:02:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 21:02:05 --> Pagination Class Initialized
INFO - 2016-03-03 21:02:05 --> Helper loaded: text_helper
INFO - 2016-03-03 21:02:05 --> Helper loaded: cookie_helper
INFO - 2016-03-03 21:03:25 --> Config Class Initialized
INFO - 2016-03-03 21:03:25 --> Hooks Class Initialized
DEBUG - 2016-03-03 21:03:25 --> UTF-8 Support Enabled
INFO - 2016-03-03 21:03:25 --> Utf8 Class Initialized
INFO - 2016-03-03 21:03:25 --> URI Class Initialized
INFO - 2016-03-03 21:03:25 --> Router Class Initialized
INFO - 2016-03-03 21:03:25 --> Output Class Initialized
INFO - 2016-03-03 21:03:25 --> Security Class Initialized
DEBUG - 2016-03-03 21:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 21:03:25 --> Input Class Initialized
INFO - 2016-03-03 21:03:25 --> Language Class Initialized
INFO - 2016-03-03 21:03:25 --> Loader Class Initialized
INFO - 2016-03-03 21:03:25 --> Helper loaded: url_helper
INFO - 2016-03-03 21:03:25 --> Helper loaded: file_helper
INFO - 2016-03-03 21:03:25 --> Helper loaded: date_helper
INFO - 2016-03-03 21:03:25 --> Helper loaded: form_helper
INFO - 2016-03-03 21:03:25 --> Database Driver Class Initialized
INFO - 2016-03-03 21:03:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 21:03:26 --> Controller Class Initialized
INFO - 2016-03-03 21:03:26 --> Model Class Initialized
INFO - 2016-03-03 21:03:26 --> Model Class Initialized
INFO - 2016-03-03 21:03:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 21:03:26 --> Pagination Class Initialized
INFO - 2016-03-03 21:03:26 --> Helper loaded: text_helper
INFO - 2016-03-03 21:03:26 --> Helper loaded: cookie_helper
INFO - 2016-03-03 21:04:04 --> Config Class Initialized
INFO - 2016-03-03 21:04:04 --> Hooks Class Initialized
DEBUG - 2016-03-03 21:04:04 --> UTF-8 Support Enabled
INFO - 2016-03-03 21:04:04 --> Utf8 Class Initialized
INFO - 2016-03-03 21:04:04 --> URI Class Initialized
INFO - 2016-03-03 21:04:04 --> Router Class Initialized
INFO - 2016-03-03 21:04:04 --> Output Class Initialized
INFO - 2016-03-03 21:04:04 --> Security Class Initialized
DEBUG - 2016-03-03 21:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 21:04:04 --> Input Class Initialized
INFO - 2016-03-03 21:04:04 --> Language Class Initialized
INFO - 2016-03-03 21:04:04 --> Loader Class Initialized
INFO - 2016-03-03 21:04:04 --> Helper loaded: url_helper
INFO - 2016-03-03 21:04:04 --> Helper loaded: file_helper
INFO - 2016-03-03 21:04:04 --> Helper loaded: date_helper
INFO - 2016-03-03 21:04:04 --> Helper loaded: form_helper
INFO - 2016-03-03 21:04:04 --> Database Driver Class Initialized
INFO - 2016-03-03 21:04:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 21:04:05 --> Controller Class Initialized
INFO - 2016-03-03 21:04:05 --> Model Class Initialized
INFO - 2016-03-03 21:04:05 --> Model Class Initialized
INFO - 2016-03-03 21:04:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 21:04:05 --> Pagination Class Initialized
INFO - 2016-03-03 21:04:05 --> Helper loaded: text_helper
INFO - 2016-03-03 21:04:05 --> Helper loaded: cookie_helper
INFO - 2016-03-03 21:04:21 --> Config Class Initialized
INFO - 2016-03-03 21:04:21 --> Hooks Class Initialized
DEBUG - 2016-03-03 21:04:21 --> UTF-8 Support Enabled
INFO - 2016-03-03 21:04:21 --> Utf8 Class Initialized
INFO - 2016-03-03 21:04:21 --> URI Class Initialized
INFO - 2016-03-03 21:04:21 --> Router Class Initialized
INFO - 2016-03-03 21:04:21 --> Output Class Initialized
INFO - 2016-03-03 21:04:21 --> Security Class Initialized
DEBUG - 2016-03-03 21:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 21:04:21 --> Input Class Initialized
INFO - 2016-03-03 21:04:21 --> Language Class Initialized
INFO - 2016-03-03 21:04:21 --> Loader Class Initialized
INFO - 2016-03-03 21:04:21 --> Helper loaded: url_helper
INFO - 2016-03-03 21:04:21 --> Helper loaded: file_helper
INFO - 2016-03-03 21:04:21 --> Helper loaded: date_helper
INFO - 2016-03-03 21:04:21 --> Helper loaded: form_helper
INFO - 2016-03-03 21:04:21 --> Database Driver Class Initialized
INFO - 2016-03-03 21:04:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 21:04:22 --> Controller Class Initialized
INFO - 2016-03-03 21:04:22 --> Model Class Initialized
INFO - 2016-03-03 21:04:22 --> Model Class Initialized
INFO - 2016-03-03 21:04:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 21:04:22 --> Pagination Class Initialized
INFO - 2016-03-03 21:04:22 --> Helper loaded: text_helper
INFO - 2016-03-03 21:04:22 --> Helper loaded: cookie_helper
INFO - 2016-03-03 21:04:30 --> Config Class Initialized
INFO - 2016-03-03 21:04:30 --> Hooks Class Initialized
DEBUG - 2016-03-03 21:04:30 --> UTF-8 Support Enabled
INFO - 2016-03-03 21:04:30 --> Utf8 Class Initialized
INFO - 2016-03-03 21:04:30 --> URI Class Initialized
INFO - 2016-03-03 21:04:30 --> Router Class Initialized
INFO - 2016-03-03 21:04:30 --> Output Class Initialized
INFO - 2016-03-03 21:04:30 --> Security Class Initialized
DEBUG - 2016-03-03 21:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 21:04:30 --> Input Class Initialized
INFO - 2016-03-03 21:04:30 --> Language Class Initialized
INFO - 2016-03-03 21:04:30 --> Loader Class Initialized
INFO - 2016-03-03 21:04:30 --> Helper loaded: url_helper
INFO - 2016-03-03 21:04:30 --> Helper loaded: file_helper
INFO - 2016-03-03 21:04:30 --> Helper loaded: date_helper
INFO - 2016-03-03 21:04:30 --> Helper loaded: form_helper
INFO - 2016-03-03 21:04:30 --> Database Driver Class Initialized
INFO - 2016-03-03 21:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 21:04:31 --> Controller Class Initialized
INFO - 2016-03-03 21:04:31 --> Model Class Initialized
INFO - 2016-03-03 21:04:31 --> Model Class Initialized
INFO - 2016-03-03 21:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 21:04:31 --> Pagination Class Initialized
INFO - 2016-03-03 21:04:31 --> Helper loaded: text_helper
INFO - 2016-03-03 21:04:31 --> Helper loaded: cookie_helper
INFO - 2016-03-03 21:05:54 --> Config Class Initialized
INFO - 2016-03-03 21:05:54 --> Hooks Class Initialized
DEBUG - 2016-03-03 21:05:54 --> UTF-8 Support Enabled
INFO - 2016-03-03 21:05:54 --> Utf8 Class Initialized
INFO - 2016-03-03 21:05:54 --> URI Class Initialized
INFO - 2016-03-03 21:05:54 --> Router Class Initialized
INFO - 2016-03-03 21:05:54 --> Output Class Initialized
INFO - 2016-03-03 21:05:54 --> Security Class Initialized
DEBUG - 2016-03-03 21:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 21:05:54 --> Input Class Initialized
INFO - 2016-03-03 21:05:54 --> Language Class Initialized
INFO - 2016-03-03 21:05:54 --> Loader Class Initialized
INFO - 2016-03-03 21:05:54 --> Helper loaded: url_helper
INFO - 2016-03-03 21:05:54 --> Helper loaded: file_helper
INFO - 2016-03-03 21:05:54 --> Helper loaded: date_helper
INFO - 2016-03-03 21:05:54 --> Helper loaded: form_helper
INFO - 2016-03-03 21:05:54 --> Database Driver Class Initialized
INFO - 2016-03-03 21:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 21:05:55 --> Controller Class Initialized
INFO - 2016-03-03 21:05:55 --> Model Class Initialized
INFO - 2016-03-03 21:05:55 --> Model Class Initialized
INFO - 2016-03-03 21:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 21:05:55 --> Pagination Class Initialized
INFO - 2016-03-03 21:05:55 --> Helper loaded: text_helper
INFO - 2016-03-03 21:05:55 --> Helper loaded: cookie_helper
INFO - 2016-03-03 21:06:44 --> Config Class Initialized
INFO - 2016-03-03 21:06:44 --> Hooks Class Initialized
DEBUG - 2016-03-03 21:06:44 --> UTF-8 Support Enabled
INFO - 2016-03-03 21:06:44 --> Utf8 Class Initialized
INFO - 2016-03-03 21:06:44 --> URI Class Initialized
INFO - 2016-03-03 21:06:44 --> Router Class Initialized
INFO - 2016-03-03 21:06:44 --> Output Class Initialized
INFO - 2016-03-03 21:06:44 --> Security Class Initialized
DEBUG - 2016-03-03 21:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-03 21:06:44 --> Input Class Initialized
INFO - 2016-03-03 21:06:44 --> Language Class Initialized
INFO - 2016-03-03 21:06:44 --> Loader Class Initialized
INFO - 2016-03-03 21:06:44 --> Helper loaded: url_helper
INFO - 2016-03-03 21:06:44 --> Helper loaded: file_helper
INFO - 2016-03-03 21:06:44 --> Helper loaded: date_helper
INFO - 2016-03-03 21:06:44 --> Helper loaded: form_helper
INFO - 2016-03-03 21:06:44 --> Database Driver Class Initialized
INFO - 2016-03-03 21:06:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-03 21:06:45 --> Controller Class Initialized
INFO - 2016-03-03 21:06:45 --> Model Class Initialized
INFO - 2016-03-03 21:06:45 --> Model Class Initialized
INFO - 2016-03-03 21:06:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-03 21:06:45 --> Pagination Class Initialized
INFO - 2016-03-03 21:06:45 --> Helper loaded: text_helper
INFO - 2016-03-03 21:06:45 --> Helper loaded: cookie_helper
