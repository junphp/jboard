<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-16 07:54:41 --> Config Class Initialized
INFO - 2016-02-16 07:54:41 --> Hooks Class Initialized
DEBUG - 2016-02-16 07:54:41 --> UTF-8 Support Enabled
INFO - 2016-02-16 07:54:41 --> Utf8 Class Initialized
INFO - 2016-02-16 07:54:41 --> URI Class Initialized
INFO - 2016-02-16 07:54:41 --> Router Class Initialized
INFO - 2016-02-16 07:54:41 --> Output Class Initialized
INFO - 2016-02-16 07:54:41 --> Security Class Initialized
DEBUG - 2016-02-16 07:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 07:54:41 --> Input Class Initialized
INFO - 2016-02-16 07:54:41 --> Language Class Initialized
INFO - 2016-02-16 07:54:41 --> Loader Class Initialized
INFO - 2016-02-16 07:54:41 --> Helper loaded: url_helper
INFO - 2016-02-16 07:54:41 --> Helper loaded: file_helper
INFO - 2016-02-16 07:54:41 --> Helper loaded: date_helper
INFO - 2016-02-16 07:54:41 --> Helper loaded: form_helper
INFO - 2016-02-16 07:54:41 --> Database Driver Class Initialized
INFO - 2016-02-16 07:54:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 07:54:42 --> Controller Class Initialized
INFO - 2016-02-16 07:54:42 --> Model Class Initialized
INFO - 2016-02-16 07:54:42 --> Model Class Initialized
INFO - 2016-02-16 07:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 07:54:42 --> Pagination Class Initialized
INFO - 2016-02-16 07:54:42 --> Helper loaded: text_helper
INFO - 2016-02-16 07:54:42 --> Helper loaded: cookie_helper
INFO - 2016-02-16 10:54:42 --> Final output sent to browser
DEBUG - 2016-02-16 10:54:42 --> Total execution time: 1.3871
INFO - 2016-02-16 07:55:00 --> Config Class Initialized
INFO - 2016-02-16 07:55:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 07:55:00 --> UTF-8 Support Enabled
INFO - 2016-02-16 07:55:00 --> Utf8 Class Initialized
INFO - 2016-02-16 07:55:00 --> URI Class Initialized
DEBUG - 2016-02-16 07:55:00 --> No URI present. Default controller set.
INFO - 2016-02-16 07:55:00 --> Router Class Initialized
INFO - 2016-02-16 07:55:00 --> Output Class Initialized
INFO - 2016-02-16 07:55:00 --> Security Class Initialized
DEBUG - 2016-02-16 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 07:55:00 --> Input Class Initialized
INFO - 2016-02-16 07:55:00 --> Language Class Initialized
ERROR - 2016-02-16 07:55:00 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 528
INFO - 2016-02-16 07:56:04 --> Config Class Initialized
INFO - 2016-02-16 07:56:04 --> Hooks Class Initialized
DEBUG - 2016-02-16 07:56:04 --> UTF-8 Support Enabled
INFO - 2016-02-16 07:56:04 --> Utf8 Class Initialized
INFO - 2016-02-16 07:56:04 --> URI Class Initialized
DEBUG - 2016-02-16 07:56:04 --> No URI present. Default controller set.
INFO - 2016-02-16 07:56:04 --> Router Class Initialized
INFO - 2016-02-16 07:56:04 --> Output Class Initialized
INFO - 2016-02-16 07:56:04 --> Security Class Initialized
DEBUG - 2016-02-16 07:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 07:56:04 --> Input Class Initialized
INFO - 2016-02-16 07:56:04 --> Language Class Initialized
ERROR - 2016-02-16 07:56:04 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 519
INFO - 2016-02-16 08:00:46 --> Config Class Initialized
INFO - 2016-02-16 08:00:46 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:00:46 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:00:46 --> Utf8 Class Initialized
INFO - 2016-02-16 08:00:46 --> URI Class Initialized
DEBUG - 2016-02-16 08:00:46 --> No URI present. Default controller set.
INFO - 2016-02-16 08:00:46 --> Router Class Initialized
INFO - 2016-02-16 08:00:46 --> Output Class Initialized
INFO - 2016-02-16 08:00:46 --> Security Class Initialized
DEBUG - 2016-02-16 08:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:00:46 --> Input Class Initialized
INFO - 2016-02-16 08:00:46 --> Language Class Initialized
ERROR - 2016-02-16 08:00:46 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 519
INFO - 2016-02-16 08:01:38 --> Config Class Initialized
INFO - 2016-02-16 08:01:38 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:01:38 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:01:38 --> Utf8 Class Initialized
INFO - 2016-02-16 08:01:38 --> URI Class Initialized
DEBUG - 2016-02-16 08:01:38 --> No URI present. Default controller set.
INFO - 2016-02-16 08:01:38 --> Router Class Initialized
INFO - 2016-02-16 08:01:38 --> Output Class Initialized
INFO - 2016-02-16 08:01:38 --> Security Class Initialized
DEBUG - 2016-02-16 08:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:01:38 --> Input Class Initialized
INFO - 2016-02-16 08:01:38 --> Language Class Initialized
ERROR - 2016-02-16 08:01:38 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 519
INFO - 2016-02-16 08:02:13 --> Config Class Initialized
INFO - 2016-02-16 08:02:13 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:02:13 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:02:13 --> Utf8 Class Initialized
INFO - 2016-02-16 08:02:13 --> URI Class Initialized
DEBUG - 2016-02-16 08:02:13 --> No URI present. Default controller set.
INFO - 2016-02-16 08:02:13 --> Router Class Initialized
INFO - 2016-02-16 08:02:13 --> Output Class Initialized
INFO - 2016-02-16 08:02:13 --> Security Class Initialized
DEBUG - 2016-02-16 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:02:13 --> Input Class Initialized
INFO - 2016-02-16 08:02:13 --> Language Class Initialized
INFO - 2016-02-16 08:02:13 --> Loader Class Initialized
INFO - 2016-02-16 08:02:13 --> Helper loaded: url_helper
INFO - 2016-02-16 08:02:13 --> Helper loaded: file_helper
INFO - 2016-02-16 08:02:13 --> Helper loaded: date_helper
INFO - 2016-02-16 08:02:13 --> Helper loaded: form_helper
INFO - 2016-02-16 08:02:13 --> Database Driver Class Initialized
INFO - 2016-02-16 08:02:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:02:14 --> Controller Class Initialized
INFO - 2016-02-16 08:02:14 --> Model Class Initialized
INFO - 2016-02-16 08:02:14 --> Model Class Initialized
INFO - 2016-02-16 08:02:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:02:14 --> Pagination Class Initialized
INFO - 2016-02-16 08:02:14 --> Helper loaded: text_helper
INFO - 2016-02-16 08:02:14 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 11:02:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:02:14 --> Final output sent to browser
DEBUG - 2016-02-16 11:02:14 --> Total execution time: 1.2338
INFO - 2016-02-16 08:02:18 --> Config Class Initialized
INFO - 2016-02-16 08:02:18 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:02:18 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:02:18 --> Utf8 Class Initialized
INFO - 2016-02-16 08:02:18 --> URI Class Initialized
INFO - 2016-02-16 08:02:18 --> Router Class Initialized
INFO - 2016-02-16 08:02:18 --> Output Class Initialized
INFO - 2016-02-16 08:02:18 --> Security Class Initialized
DEBUG - 2016-02-16 08:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:02:18 --> Input Class Initialized
INFO - 2016-02-16 08:02:18 --> Language Class Initialized
INFO - 2016-02-16 08:02:18 --> Loader Class Initialized
INFO - 2016-02-16 08:02:18 --> Helper loaded: url_helper
INFO - 2016-02-16 08:02:18 --> Helper loaded: file_helper
INFO - 2016-02-16 08:02:18 --> Helper loaded: date_helper
INFO - 2016-02-16 08:02:18 --> Helper loaded: form_helper
INFO - 2016-02-16 08:02:18 --> Database Driver Class Initialized
INFO - 2016-02-16 08:02:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:02:19 --> Controller Class Initialized
INFO - 2016-02-16 08:02:19 --> Model Class Initialized
INFO - 2016-02-16 08:02:19 --> Model Class Initialized
INFO - 2016-02-16 08:02:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:02:19 --> Pagination Class Initialized
INFO - 2016-02-16 08:02:19 --> Helper loaded: text_helper
INFO - 2016-02-16 08:02:19 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:02:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:02:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:02:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 11:02:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 11:02:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:02:19 --> Final output sent to browser
DEBUG - 2016-02-16 11:02:19 --> Total execution time: 1.2494
INFO - 2016-02-16 08:02:45 --> Config Class Initialized
INFO - 2016-02-16 08:02:45 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:02:45 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:02:45 --> Utf8 Class Initialized
INFO - 2016-02-16 08:02:45 --> URI Class Initialized
INFO - 2016-02-16 08:02:45 --> Router Class Initialized
INFO - 2016-02-16 08:02:45 --> Output Class Initialized
INFO - 2016-02-16 08:02:45 --> Security Class Initialized
DEBUG - 2016-02-16 08:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:02:45 --> Input Class Initialized
INFO - 2016-02-16 08:02:45 --> Language Class Initialized
INFO - 2016-02-16 08:02:45 --> Loader Class Initialized
INFO - 2016-02-16 08:02:45 --> Helper loaded: url_helper
INFO - 2016-02-16 08:02:45 --> Helper loaded: file_helper
INFO - 2016-02-16 08:02:45 --> Helper loaded: date_helper
INFO - 2016-02-16 08:02:45 --> Helper loaded: form_helper
INFO - 2016-02-16 08:02:45 --> Database Driver Class Initialized
INFO - 2016-02-16 08:02:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:02:46 --> Controller Class Initialized
INFO - 2016-02-16 08:02:46 --> Model Class Initialized
INFO - 2016-02-16 08:02:46 --> Model Class Initialized
INFO - 2016-02-16 08:02:46 --> Form Validation Class Initialized
INFO - 2016-02-16 08:02:46 --> Helper loaded: text_helper
INFO - 2016-02-16 08:02:46 --> Config Class Initialized
INFO - 2016-02-16 08:02:46 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:02:46 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:02:46 --> Utf8 Class Initialized
INFO - 2016-02-16 08:02:46 --> URI Class Initialized
INFO - 2016-02-16 08:02:46 --> Router Class Initialized
INFO - 2016-02-16 08:02:46 --> Output Class Initialized
INFO - 2016-02-16 08:02:46 --> Security Class Initialized
DEBUG - 2016-02-16 08:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:02:46 --> Input Class Initialized
INFO - 2016-02-16 08:02:46 --> Language Class Initialized
INFO - 2016-02-16 08:02:46 --> Loader Class Initialized
INFO - 2016-02-16 08:02:46 --> Helper loaded: url_helper
INFO - 2016-02-16 08:02:46 --> Helper loaded: file_helper
INFO - 2016-02-16 08:02:46 --> Helper loaded: date_helper
INFO - 2016-02-16 08:02:46 --> Helper loaded: form_helper
INFO - 2016-02-16 08:02:46 --> Database Driver Class Initialized
INFO - 2016-02-16 08:02:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:02:47 --> Controller Class Initialized
INFO - 2016-02-16 08:02:47 --> Model Class Initialized
INFO - 2016-02-16 08:02:47 --> Model Class Initialized
INFO - 2016-02-16 08:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:02:47 --> Pagination Class Initialized
INFO - 2016-02-16 08:02:47 --> Helper loaded: text_helper
INFO - 2016-02-16 08:02:47 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 11:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 11:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:02:47 --> Final output sent to browser
DEBUG - 2016-02-16 11:02:47 --> Total execution time: 1.1846
INFO - 2016-02-16 08:02:57 --> Config Class Initialized
INFO - 2016-02-16 08:02:57 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:02:57 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:02:57 --> Utf8 Class Initialized
INFO - 2016-02-16 08:02:57 --> URI Class Initialized
INFO - 2016-02-16 08:02:57 --> Router Class Initialized
INFO - 2016-02-16 08:02:57 --> Output Class Initialized
INFO - 2016-02-16 08:02:57 --> Security Class Initialized
DEBUG - 2016-02-16 08:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:02:57 --> Input Class Initialized
INFO - 2016-02-16 08:02:57 --> Language Class Initialized
INFO - 2016-02-16 08:02:57 --> Loader Class Initialized
INFO - 2016-02-16 08:02:57 --> Helper loaded: url_helper
INFO - 2016-02-16 08:02:57 --> Helper loaded: file_helper
INFO - 2016-02-16 08:02:57 --> Helper loaded: date_helper
INFO - 2016-02-16 08:02:57 --> Helper loaded: form_helper
INFO - 2016-02-16 08:02:57 --> Database Driver Class Initialized
INFO - 2016-02-16 08:02:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:02:59 --> Controller Class Initialized
INFO - 2016-02-16 08:02:59 --> Model Class Initialized
INFO - 2016-02-16 08:02:59 --> Model Class Initialized
INFO - 2016-02-16 08:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:02:59 --> Pagination Class Initialized
INFO - 2016-02-16 08:02:59 --> Helper loaded: text_helper
INFO - 2016-02-16 08:02:59 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:02:59 --> Final output sent to browser
DEBUG - 2016-02-16 11:02:59 --> Total execution time: 1.1243
INFO - 2016-02-16 08:03:07 --> Config Class Initialized
INFO - 2016-02-16 08:03:07 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:03:07 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:03:07 --> Utf8 Class Initialized
INFO - 2016-02-16 08:03:07 --> URI Class Initialized
INFO - 2016-02-16 08:03:07 --> Router Class Initialized
INFO - 2016-02-16 08:03:07 --> Output Class Initialized
INFO - 2016-02-16 08:03:07 --> Security Class Initialized
DEBUG - 2016-02-16 08:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:03:07 --> Input Class Initialized
INFO - 2016-02-16 08:03:07 --> Language Class Initialized
INFO - 2016-02-16 08:03:07 --> Loader Class Initialized
INFO - 2016-02-16 08:03:07 --> Helper loaded: url_helper
INFO - 2016-02-16 08:03:07 --> Helper loaded: file_helper
INFO - 2016-02-16 08:03:07 --> Helper loaded: date_helper
INFO - 2016-02-16 08:03:07 --> Helper loaded: form_helper
INFO - 2016-02-16 08:03:07 --> Database Driver Class Initialized
INFO - 2016-02-16 08:03:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:03:08 --> Controller Class Initialized
INFO - 2016-02-16 08:03:08 --> Model Class Initialized
INFO - 2016-02-16 08:03:08 --> Model Class Initialized
INFO - 2016-02-16 08:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:03:08 --> Pagination Class Initialized
INFO - 2016-02-16 08:03:08 --> Helper loaded: text_helper
INFO - 2016-02-16 08:03:08 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:03:08 --> Final output sent to browser
DEBUG - 2016-02-16 11:03:08 --> Total execution time: 1.1767
INFO - 2016-02-16 08:32:07 --> Config Class Initialized
INFO - 2016-02-16 08:32:07 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:32:07 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:32:07 --> Utf8 Class Initialized
INFO - 2016-02-16 08:32:07 --> URI Class Initialized
DEBUG - 2016-02-16 08:32:07 --> No URI present. Default controller set.
INFO - 2016-02-16 08:32:07 --> Router Class Initialized
INFO - 2016-02-16 08:32:07 --> Output Class Initialized
INFO - 2016-02-16 08:32:07 --> Security Class Initialized
DEBUG - 2016-02-16 08:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:32:07 --> Input Class Initialized
INFO - 2016-02-16 08:32:07 --> Language Class Initialized
ERROR - 2016-02-16 08:32:07 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 508
INFO - 2016-02-16 08:32:36 --> Config Class Initialized
INFO - 2016-02-16 08:32:36 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:32:36 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:32:36 --> Utf8 Class Initialized
INFO - 2016-02-16 08:32:36 --> URI Class Initialized
DEBUG - 2016-02-16 08:32:36 --> No URI present. Default controller set.
INFO - 2016-02-16 08:32:36 --> Router Class Initialized
INFO - 2016-02-16 08:32:36 --> Output Class Initialized
INFO - 2016-02-16 08:32:36 --> Security Class Initialized
DEBUG - 2016-02-16 08:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:32:36 --> Input Class Initialized
INFO - 2016-02-16 08:32:36 --> Language Class Initialized
INFO - 2016-02-16 08:32:36 --> Loader Class Initialized
INFO - 2016-02-16 08:32:36 --> Helper loaded: url_helper
INFO - 2016-02-16 08:32:36 --> Helper loaded: file_helper
INFO - 2016-02-16 08:32:36 --> Helper loaded: date_helper
INFO - 2016-02-16 08:32:36 --> Helper loaded: form_helper
INFO - 2016-02-16 08:32:36 --> Database Driver Class Initialized
INFO - 2016-02-16 08:32:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:32:37 --> Controller Class Initialized
INFO - 2016-02-16 08:32:37 --> Model Class Initialized
INFO - 2016-02-16 08:32:37 --> Model Class Initialized
INFO - 2016-02-16 08:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:32:37 --> Pagination Class Initialized
INFO - 2016-02-16 08:32:37 --> Helper loaded: text_helper
INFO - 2016-02-16 08:32:37 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 11:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:32:37 --> Final output sent to browser
DEBUG - 2016-02-16 11:32:37 --> Total execution time: 1.1138
INFO - 2016-02-16 08:32:42 --> Config Class Initialized
INFO - 2016-02-16 08:32:43 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:32:43 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:32:43 --> Utf8 Class Initialized
INFO - 2016-02-16 08:32:43 --> URI Class Initialized
INFO - 2016-02-16 08:32:43 --> Router Class Initialized
INFO - 2016-02-16 08:32:43 --> Output Class Initialized
INFO - 2016-02-16 08:32:43 --> Security Class Initialized
DEBUG - 2016-02-16 08:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:32:43 --> Input Class Initialized
INFO - 2016-02-16 08:32:43 --> Language Class Initialized
INFO - 2016-02-16 08:32:43 --> Loader Class Initialized
INFO - 2016-02-16 08:32:43 --> Helper loaded: url_helper
INFO - 2016-02-16 08:32:43 --> Helper loaded: file_helper
INFO - 2016-02-16 08:32:43 --> Helper loaded: date_helper
INFO - 2016-02-16 08:32:43 --> Helper loaded: form_helper
INFO - 2016-02-16 08:32:43 --> Database Driver Class Initialized
INFO - 2016-02-16 08:32:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:32:44 --> Controller Class Initialized
INFO - 2016-02-16 08:32:44 --> Model Class Initialized
INFO - 2016-02-16 08:32:44 --> Model Class Initialized
INFO - 2016-02-16 08:32:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:32:44 --> Pagination Class Initialized
INFO - 2016-02-16 08:32:44 --> Helper loaded: text_helper
INFO - 2016-02-16 08:32:44 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:32:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:32:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:32:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 11:32:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 11:32:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:32:44 --> Final output sent to browser
DEBUG - 2016-02-16 11:32:44 --> Total execution time: 1.1333
INFO - 2016-02-16 08:32:47 --> Config Class Initialized
INFO - 2016-02-16 08:32:47 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:32:47 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:32:47 --> Utf8 Class Initialized
INFO - 2016-02-16 08:32:47 --> URI Class Initialized
INFO - 2016-02-16 08:32:47 --> Router Class Initialized
INFO - 2016-02-16 08:32:47 --> Output Class Initialized
INFO - 2016-02-16 08:32:47 --> Security Class Initialized
DEBUG - 2016-02-16 08:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:32:47 --> Input Class Initialized
INFO - 2016-02-16 08:32:47 --> Language Class Initialized
INFO - 2016-02-16 08:32:47 --> Loader Class Initialized
INFO - 2016-02-16 08:32:47 --> Helper loaded: url_helper
INFO - 2016-02-16 08:32:47 --> Helper loaded: file_helper
INFO - 2016-02-16 08:32:47 --> Helper loaded: date_helper
INFO - 2016-02-16 08:32:47 --> Helper loaded: form_helper
INFO - 2016-02-16 08:32:47 --> Database Driver Class Initialized
INFO - 2016-02-16 08:32:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:32:48 --> Controller Class Initialized
INFO - 2016-02-16 08:32:48 --> Model Class Initialized
INFO - 2016-02-16 08:32:48 --> Model Class Initialized
INFO - 2016-02-16 08:32:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:32:48 --> Pagination Class Initialized
INFO - 2016-02-16 08:32:48 --> Helper loaded: text_helper
INFO - 2016-02-16 08:32:48 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:32:48 --> Final output sent to browser
DEBUG - 2016-02-16 11:32:48 --> Total execution time: 1.0932
INFO - 2016-02-16 08:34:47 --> Config Class Initialized
INFO - 2016-02-16 08:34:47 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:34:47 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:34:47 --> Utf8 Class Initialized
INFO - 2016-02-16 08:34:47 --> URI Class Initialized
INFO - 2016-02-16 08:34:47 --> Router Class Initialized
INFO - 2016-02-16 08:34:47 --> Output Class Initialized
INFO - 2016-02-16 08:34:47 --> Security Class Initialized
DEBUG - 2016-02-16 08:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:34:47 --> Input Class Initialized
INFO - 2016-02-16 08:34:47 --> Language Class Initialized
INFO - 2016-02-16 08:34:47 --> Loader Class Initialized
INFO - 2016-02-16 08:34:47 --> Helper loaded: url_helper
INFO - 2016-02-16 08:34:47 --> Helper loaded: file_helper
INFO - 2016-02-16 08:34:47 --> Helper loaded: date_helper
INFO - 2016-02-16 08:34:47 --> Helper loaded: form_helper
INFO - 2016-02-16 08:34:47 --> Database Driver Class Initialized
INFO - 2016-02-16 08:34:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:34:48 --> Controller Class Initialized
INFO - 2016-02-16 08:34:48 --> Model Class Initialized
INFO - 2016-02-16 08:34:48 --> Model Class Initialized
INFO - 2016-02-16 08:34:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:34:48 --> Pagination Class Initialized
INFO - 2016-02-16 08:34:48 --> Helper loaded: text_helper
INFO - 2016-02-16 08:34:48 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 11:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 11:34:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:34:48 --> Final output sent to browser
DEBUG - 2016-02-16 11:34:48 --> Total execution time: 1.1372
INFO - 2016-02-16 08:35:05 --> Config Class Initialized
INFO - 2016-02-16 08:35:05 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:35:05 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:35:05 --> Utf8 Class Initialized
INFO - 2016-02-16 08:35:05 --> URI Class Initialized
DEBUG - 2016-02-16 08:35:05 --> No URI present. Default controller set.
INFO - 2016-02-16 08:35:05 --> Router Class Initialized
INFO - 2016-02-16 08:35:05 --> Output Class Initialized
INFO - 2016-02-16 08:35:05 --> Security Class Initialized
DEBUG - 2016-02-16 08:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:35:05 --> Input Class Initialized
INFO - 2016-02-16 08:35:05 --> Language Class Initialized
INFO - 2016-02-16 08:35:05 --> Loader Class Initialized
INFO - 2016-02-16 08:35:05 --> Helper loaded: url_helper
INFO - 2016-02-16 08:35:05 --> Helper loaded: file_helper
INFO - 2016-02-16 08:35:05 --> Helper loaded: date_helper
INFO - 2016-02-16 08:35:05 --> Helper loaded: form_helper
INFO - 2016-02-16 08:35:05 --> Database Driver Class Initialized
INFO - 2016-02-16 08:35:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:35:06 --> Controller Class Initialized
INFO - 2016-02-16 08:35:06 --> Model Class Initialized
INFO - 2016-02-16 08:35:06 --> Model Class Initialized
INFO - 2016-02-16 08:35:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:35:06 --> Pagination Class Initialized
INFO - 2016-02-16 08:35:06 --> Helper loaded: text_helper
INFO - 2016-02-16 08:35:06 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 11:35:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:35:06 --> Final output sent to browser
DEBUG - 2016-02-16 11:35:06 --> Total execution time: 1.1185
INFO - 2016-02-16 08:35:09 --> Config Class Initialized
INFO - 2016-02-16 08:35:09 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:35:09 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:35:09 --> Utf8 Class Initialized
INFO - 2016-02-16 08:35:09 --> URI Class Initialized
INFO - 2016-02-16 08:35:09 --> Router Class Initialized
INFO - 2016-02-16 08:35:09 --> Output Class Initialized
INFO - 2016-02-16 08:35:09 --> Security Class Initialized
DEBUG - 2016-02-16 08:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:35:09 --> Input Class Initialized
INFO - 2016-02-16 08:35:09 --> Language Class Initialized
INFO - 2016-02-16 08:35:09 --> Loader Class Initialized
INFO - 2016-02-16 08:35:09 --> Helper loaded: url_helper
INFO - 2016-02-16 08:35:09 --> Helper loaded: file_helper
INFO - 2016-02-16 08:35:09 --> Helper loaded: date_helper
INFO - 2016-02-16 08:35:09 --> Helper loaded: form_helper
INFO - 2016-02-16 08:35:09 --> Database Driver Class Initialized
INFO - 2016-02-16 08:35:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:35:10 --> Controller Class Initialized
INFO - 2016-02-16 08:35:10 --> Model Class Initialized
INFO - 2016-02-16 08:35:10 --> Model Class Initialized
INFO - 2016-02-16 08:35:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:35:10 --> Pagination Class Initialized
INFO - 2016-02-16 08:35:10 --> Helper loaded: text_helper
INFO - 2016-02-16 08:35:10 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 11:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 11:35:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:35:10 --> Final output sent to browser
DEBUG - 2016-02-16 11:35:10 --> Total execution time: 1.2127
INFO - 2016-02-16 08:35:12 --> Config Class Initialized
INFO - 2016-02-16 08:35:12 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:35:12 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:35:12 --> Utf8 Class Initialized
INFO - 2016-02-16 08:35:12 --> URI Class Initialized
INFO - 2016-02-16 08:35:12 --> Router Class Initialized
INFO - 2016-02-16 08:35:12 --> Output Class Initialized
INFO - 2016-02-16 08:35:12 --> Security Class Initialized
DEBUG - 2016-02-16 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:35:12 --> Input Class Initialized
INFO - 2016-02-16 08:35:12 --> Language Class Initialized
INFO - 2016-02-16 08:35:12 --> Loader Class Initialized
INFO - 2016-02-16 08:35:12 --> Helper loaded: url_helper
INFO - 2016-02-16 08:35:12 --> Helper loaded: file_helper
INFO - 2016-02-16 08:35:12 --> Helper loaded: date_helper
INFO - 2016-02-16 08:35:12 --> Helper loaded: form_helper
INFO - 2016-02-16 08:35:12 --> Database Driver Class Initialized
INFO - 2016-02-16 08:35:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:35:13 --> Controller Class Initialized
INFO - 2016-02-16 08:35:13 --> Model Class Initialized
INFO - 2016-02-16 08:35:13 --> Model Class Initialized
INFO - 2016-02-16 08:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:35:13 --> Pagination Class Initialized
INFO - 2016-02-16 08:35:13 --> Helper loaded: text_helper
INFO - 2016-02-16 08:35:13 --> Helper loaded: cookie_helper
INFO - 2016-02-16 08:37:02 --> Config Class Initialized
INFO - 2016-02-16 08:37:02 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:37:02 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:37:02 --> Utf8 Class Initialized
INFO - 2016-02-16 08:37:02 --> URI Class Initialized
DEBUG - 2016-02-16 08:37:02 --> No URI present. Default controller set.
INFO - 2016-02-16 08:37:02 --> Router Class Initialized
INFO - 2016-02-16 08:37:02 --> Output Class Initialized
INFO - 2016-02-16 08:37:02 --> Security Class Initialized
DEBUG - 2016-02-16 08:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:37:02 --> Input Class Initialized
INFO - 2016-02-16 08:37:02 --> Language Class Initialized
INFO - 2016-02-16 08:37:02 --> Loader Class Initialized
INFO - 2016-02-16 08:37:02 --> Helper loaded: url_helper
INFO - 2016-02-16 08:37:02 --> Helper loaded: file_helper
INFO - 2016-02-16 08:37:02 --> Helper loaded: date_helper
INFO - 2016-02-16 08:37:02 --> Helper loaded: form_helper
INFO - 2016-02-16 08:37:02 --> Database Driver Class Initialized
INFO - 2016-02-16 08:37:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:37:03 --> Controller Class Initialized
INFO - 2016-02-16 08:37:03 --> Model Class Initialized
INFO - 2016-02-16 08:37:03 --> Model Class Initialized
INFO - 2016-02-16 08:37:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:37:03 --> Pagination Class Initialized
INFO - 2016-02-16 08:37:03 --> Helper loaded: text_helper
INFO - 2016-02-16 08:37:03 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:37:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:37:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:37:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 11:37:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:37:03 --> Final output sent to browser
DEBUG - 2016-02-16 11:37:03 --> Total execution time: 1.0989
INFO - 2016-02-16 08:37:06 --> Config Class Initialized
INFO - 2016-02-16 08:37:06 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:37:06 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:37:06 --> Utf8 Class Initialized
INFO - 2016-02-16 08:37:06 --> URI Class Initialized
INFO - 2016-02-16 08:37:06 --> Router Class Initialized
INFO - 2016-02-16 08:37:06 --> Output Class Initialized
INFO - 2016-02-16 08:37:06 --> Security Class Initialized
DEBUG - 2016-02-16 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:37:06 --> Input Class Initialized
INFO - 2016-02-16 08:37:06 --> Language Class Initialized
INFO - 2016-02-16 08:37:06 --> Loader Class Initialized
INFO - 2016-02-16 08:37:06 --> Helper loaded: url_helper
INFO - 2016-02-16 08:37:06 --> Helper loaded: file_helper
INFO - 2016-02-16 08:37:06 --> Helper loaded: date_helper
INFO - 2016-02-16 08:37:06 --> Helper loaded: form_helper
INFO - 2016-02-16 08:37:06 --> Database Driver Class Initialized
INFO - 2016-02-16 08:37:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:37:07 --> Controller Class Initialized
INFO - 2016-02-16 08:37:07 --> Model Class Initialized
INFO - 2016-02-16 08:37:07 --> Model Class Initialized
INFO - 2016-02-16 08:37:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:37:07 --> Pagination Class Initialized
INFO - 2016-02-16 08:37:07 --> Helper loaded: text_helper
INFO - 2016-02-16 08:37:07 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 11:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 11:37:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 11:37:07 --> Final output sent to browser
DEBUG - 2016-02-16 11:37:07 --> Total execution time: 1.1480
INFO - 2016-02-16 08:37:09 --> Config Class Initialized
INFO - 2016-02-16 08:37:09 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:37:09 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:37:09 --> Utf8 Class Initialized
INFO - 2016-02-16 08:37:09 --> URI Class Initialized
INFO - 2016-02-16 08:37:09 --> Router Class Initialized
INFO - 2016-02-16 08:37:09 --> Output Class Initialized
INFO - 2016-02-16 08:37:09 --> Security Class Initialized
DEBUG - 2016-02-16 08:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:37:09 --> Input Class Initialized
INFO - 2016-02-16 08:37:09 --> Language Class Initialized
INFO - 2016-02-16 08:37:09 --> Loader Class Initialized
INFO - 2016-02-16 08:37:09 --> Helper loaded: url_helper
INFO - 2016-02-16 08:37:09 --> Helper loaded: file_helper
INFO - 2016-02-16 08:37:09 --> Helper loaded: date_helper
INFO - 2016-02-16 08:37:09 --> Helper loaded: form_helper
INFO - 2016-02-16 08:37:09 --> Database Driver Class Initialized
INFO - 2016-02-16 08:37:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 08:37:10 --> Controller Class Initialized
INFO - 2016-02-16 08:37:10 --> Model Class Initialized
INFO - 2016-02-16 08:37:10 --> Model Class Initialized
INFO - 2016-02-16 08:37:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 08:37:10 --> Pagination Class Initialized
INFO - 2016-02-16 08:37:10 --> Helper loaded: text_helper
INFO - 2016-02-16 08:37:10 --> Helper loaded: cookie_helper
INFO - 2016-02-16 08:58:24 --> Config Class Initialized
INFO - 2016-02-16 08:58:24 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:58:24 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:58:24 --> Utf8 Class Initialized
INFO - 2016-02-16 08:58:24 --> URI Class Initialized
DEBUG - 2016-02-16 08:58:24 --> No URI present. Default controller set.
INFO - 2016-02-16 08:58:24 --> Router Class Initialized
INFO - 2016-02-16 08:58:24 --> Output Class Initialized
INFO - 2016-02-16 08:58:24 --> Security Class Initialized
DEBUG - 2016-02-16 08:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:58:24 --> Input Class Initialized
INFO - 2016-02-16 08:58:24 --> Language Class Initialized
ERROR - 2016-02-16 08:58:24 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 439
INFO - 2016-02-16 08:59:00 --> Config Class Initialized
INFO - 2016-02-16 08:59:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:59:00 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:59:00 --> Utf8 Class Initialized
INFO - 2016-02-16 08:59:00 --> URI Class Initialized
DEBUG - 2016-02-16 08:59:00 --> No URI present. Default controller set.
INFO - 2016-02-16 08:59:00 --> Router Class Initialized
INFO - 2016-02-16 08:59:00 --> Output Class Initialized
INFO - 2016-02-16 08:59:00 --> Security Class Initialized
DEBUG - 2016-02-16 08:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:59:00 --> Input Class Initialized
INFO - 2016-02-16 08:59:00 --> Language Class Initialized
ERROR - 2016-02-16 08:59:00 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 439
INFO - 2016-02-16 08:59:09 --> Config Class Initialized
INFO - 2016-02-16 08:59:09 --> Hooks Class Initialized
DEBUG - 2016-02-16 08:59:09 --> UTF-8 Support Enabled
INFO - 2016-02-16 08:59:09 --> Utf8 Class Initialized
INFO - 2016-02-16 08:59:09 --> URI Class Initialized
DEBUG - 2016-02-16 08:59:09 --> No URI present. Default controller set.
INFO - 2016-02-16 08:59:09 --> Router Class Initialized
INFO - 2016-02-16 08:59:09 --> Output Class Initialized
INFO - 2016-02-16 08:59:09 --> Security Class Initialized
DEBUG - 2016-02-16 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 08:59:09 --> Input Class Initialized
INFO - 2016-02-16 08:59:09 --> Language Class Initialized
ERROR - 2016-02-16 08:59:09 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 439
INFO - 2016-02-16 09:00:06 --> Config Class Initialized
INFO - 2016-02-16 09:00:06 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:00:06 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:00:06 --> Utf8 Class Initialized
INFO - 2016-02-16 09:00:06 --> URI Class Initialized
DEBUG - 2016-02-16 09:00:06 --> No URI present. Default controller set.
INFO - 2016-02-16 09:00:06 --> Router Class Initialized
INFO - 2016-02-16 09:00:06 --> Output Class Initialized
INFO - 2016-02-16 09:00:06 --> Security Class Initialized
DEBUG - 2016-02-16 09:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:00:06 --> Input Class Initialized
INFO - 2016-02-16 09:00:06 --> Language Class Initialized
ERROR - 2016-02-16 09:00:06 --> Severity: Parsing Error --> syntax error, unexpected '$test' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 438
INFO - 2016-02-16 09:01:27 --> Config Class Initialized
INFO - 2016-02-16 09:01:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:01:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:01:27 --> Utf8 Class Initialized
INFO - 2016-02-16 09:01:27 --> URI Class Initialized
DEBUG - 2016-02-16 09:01:27 --> No URI present. Default controller set.
INFO - 2016-02-16 09:01:27 --> Router Class Initialized
INFO - 2016-02-16 09:01:27 --> Output Class Initialized
INFO - 2016-02-16 09:01:27 --> Security Class Initialized
DEBUG - 2016-02-16 09:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:01:27 --> Input Class Initialized
INFO - 2016-02-16 09:01:27 --> Language Class Initialized
ERROR - 2016-02-16 09:01:27 --> Severity: Parsing Error --> syntax error, unexpected '$test' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 438
INFO - 2016-02-16 09:01:57 --> Config Class Initialized
INFO - 2016-02-16 09:01:57 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:01:57 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:01:57 --> Utf8 Class Initialized
INFO - 2016-02-16 09:01:57 --> URI Class Initialized
DEBUG - 2016-02-16 09:01:57 --> No URI present. Default controller set.
INFO - 2016-02-16 09:01:57 --> Router Class Initialized
INFO - 2016-02-16 09:01:57 --> Output Class Initialized
INFO - 2016-02-16 09:01:57 --> Security Class Initialized
DEBUG - 2016-02-16 09:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:01:57 --> Input Class Initialized
INFO - 2016-02-16 09:01:57 --> Language Class Initialized
ERROR - 2016-02-16 09:01:57 --> Severity: Parsing Error --> syntax error, unexpected '$test' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 438
INFO - 2016-02-16 09:02:14 --> Config Class Initialized
INFO - 2016-02-16 09:02:14 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:02:14 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:02:14 --> Utf8 Class Initialized
INFO - 2016-02-16 09:02:14 --> URI Class Initialized
DEBUG - 2016-02-16 09:02:14 --> No URI present. Default controller set.
INFO - 2016-02-16 09:02:14 --> Router Class Initialized
INFO - 2016-02-16 09:02:14 --> Output Class Initialized
INFO - 2016-02-16 09:02:14 --> Security Class Initialized
DEBUG - 2016-02-16 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:02:14 --> Input Class Initialized
INFO - 2016-02-16 09:02:14 --> Language Class Initialized
ERROR - 2016-02-16 09:02:14 --> Severity: Parsing Error --> syntax error, unexpected '$test' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 438
INFO - 2016-02-16 09:02:27 --> Config Class Initialized
INFO - 2016-02-16 09:02:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:02:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:02:27 --> Utf8 Class Initialized
INFO - 2016-02-16 09:02:27 --> URI Class Initialized
DEBUG - 2016-02-16 09:02:27 --> No URI present. Default controller set.
INFO - 2016-02-16 09:02:27 --> Router Class Initialized
INFO - 2016-02-16 09:02:27 --> Output Class Initialized
INFO - 2016-02-16 09:02:27 --> Security Class Initialized
DEBUG - 2016-02-16 09:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:02:27 --> Input Class Initialized
INFO - 2016-02-16 09:02:27 --> Language Class Initialized
ERROR - 2016-02-16 09:02:27 --> Severity: Parsing Error --> syntax error, unexpected '$test' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 438
INFO - 2016-02-16 09:02:53 --> Config Class Initialized
INFO - 2016-02-16 09:02:53 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:02:53 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:02:53 --> Utf8 Class Initialized
INFO - 2016-02-16 09:02:53 --> URI Class Initialized
DEBUG - 2016-02-16 09:02:53 --> No URI present. Default controller set.
INFO - 2016-02-16 09:02:53 --> Router Class Initialized
INFO - 2016-02-16 09:02:53 --> Output Class Initialized
INFO - 2016-02-16 09:02:53 --> Security Class Initialized
DEBUG - 2016-02-16 09:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:02:53 --> Input Class Initialized
INFO - 2016-02-16 09:02:53 --> Language Class Initialized
INFO - 2016-02-16 09:02:53 --> Loader Class Initialized
INFO - 2016-02-16 09:02:53 --> Helper loaded: url_helper
INFO - 2016-02-16 09:02:53 --> Helper loaded: file_helper
INFO - 2016-02-16 09:02:53 --> Helper loaded: date_helper
INFO - 2016-02-16 09:02:53 --> Helper loaded: form_helper
INFO - 2016-02-16 09:02:53 --> Database Driver Class Initialized
INFO - 2016-02-16 09:02:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:02:54 --> Controller Class Initialized
INFO - 2016-02-16 09:02:54 --> Model Class Initialized
INFO - 2016-02-16 09:02:54 --> Model Class Initialized
INFO - 2016-02-16 09:02:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:02:54 --> Pagination Class Initialized
INFO - 2016-02-16 09:02:54 --> Helper loaded: text_helper
INFO - 2016-02-16 09:02:54 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:02:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:02:54 --> Final output sent to browser
DEBUG - 2016-02-16 12:02:54 --> Total execution time: 1.1330
INFO - 2016-02-16 09:02:57 --> Config Class Initialized
INFO - 2016-02-16 09:02:57 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:02:57 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:02:57 --> Utf8 Class Initialized
INFO - 2016-02-16 09:02:57 --> URI Class Initialized
INFO - 2016-02-16 09:02:57 --> Router Class Initialized
INFO - 2016-02-16 09:02:57 --> Output Class Initialized
INFO - 2016-02-16 09:02:57 --> Security Class Initialized
DEBUG - 2016-02-16 09:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:02:57 --> Input Class Initialized
INFO - 2016-02-16 09:02:57 --> Language Class Initialized
INFO - 2016-02-16 09:02:57 --> Loader Class Initialized
INFO - 2016-02-16 09:02:57 --> Helper loaded: url_helper
INFO - 2016-02-16 09:02:57 --> Helper loaded: file_helper
INFO - 2016-02-16 09:02:57 --> Helper loaded: date_helper
INFO - 2016-02-16 09:02:57 --> Helper loaded: form_helper
INFO - 2016-02-16 09:02:57 --> Database Driver Class Initialized
INFO - 2016-02-16 09:02:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:02:58 --> Controller Class Initialized
INFO - 2016-02-16 09:02:58 --> Model Class Initialized
INFO - 2016-02-16 09:02:58 --> Model Class Initialized
INFO - 2016-02-16 09:02:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:02:58 --> Pagination Class Initialized
INFO - 2016-02-16 09:02:58 --> Helper loaded: text_helper
INFO - 2016-02-16 09:02:58 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:02:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:02:58 --> Final output sent to browser
DEBUG - 2016-02-16 12:02:58 --> Total execution time: 1.1033
INFO - 2016-02-16 09:03:12 --> Config Class Initialized
INFO - 2016-02-16 09:03:12 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:03:12 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:03:12 --> Utf8 Class Initialized
INFO - 2016-02-16 09:03:12 --> URI Class Initialized
INFO - 2016-02-16 09:03:12 --> Router Class Initialized
INFO - 2016-02-16 09:03:12 --> Output Class Initialized
INFO - 2016-02-16 09:03:12 --> Security Class Initialized
DEBUG - 2016-02-16 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:03:12 --> Input Class Initialized
INFO - 2016-02-16 09:03:12 --> Language Class Initialized
INFO - 2016-02-16 09:03:12 --> Loader Class Initialized
INFO - 2016-02-16 09:03:12 --> Helper loaded: url_helper
INFO - 2016-02-16 09:03:12 --> Helper loaded: file_helper
INFO - 2016-02-16 09:03:12 --> Helper loaded: date_helper
INFO - 2016-02-16 09:03:12 --> Helper loaded: form_helper
INFO - 2016-02-16 09:03:12 --> Database Driver Class Initialized
INFO - 2016-02-16 09:03:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:03:13 --> Controller Class Initialized
INFO - 2016-02-16 09:03:13 --> Model Class Initialized
INFO - 2016-02-16 09:03:13 --> Model Class Initialized
INFO - 2016-02-16 09:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:03:13 --> Pagination Class Initialized
INFO - 2016-02-16 09:03:13 --> Helper loaded: text_helper
INFO - 2016-02-16 09:03:13 --> Helper loaded: cookie_helper
ERROR - 2016-02-16 12:03:13 --> Severity: Notice --> Undefined variable: board_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 192
INFO - 2016-02-16 12:03:13 --> Final output sent to browser
DEBUG - 2016-02-16 12:03:13 --> Total execution time: 1.1231
INFO - 2016-02-16 09:03:56 --> Config Class Initialized
INFO - 2016-02-16 09:03:56 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:03:56 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:03:56 --> Utf8 Class Initialized
INFO - 2016-02-16 09:03:56 --> URI Class Initialized
INFO - 2016-02-16 09:03:56 --> Router Class Initialized
INFO - 2016-02-16 09:03:56 --> Output Class Initialized
INFO - 2016-02-16 09:03:56 --> Security Class Initialized
DEBUG - 2016-02-16 09:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:03:56 --> Input Class Initialized
INFO - 2016-02-16 09:03:56 --> Language Class Initialized
INFO - 2016-02-16 09:03:56 --> Loader Class Initialized
INFO - 2016-02-16 09:03:56 --> Helper loaded: url_helper
INFO - 2016-02-16 09:03:56 --> Helper loaded: file_helper
INFO - 2016-02-16 09:03:56 --> Helper loaded: date_helper
INFO - 2016-02-16 09:03:56 --> Helper loaded: form_helper
INFO - 2016-02-16 09:03:56 --> Database Driver Class Initialized
INFO - 2016-02-16 09:03:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:03:57 --> Controller Class Initialized
INFO - 2016-02-16 09:03:57 --> Model Class Initialized
INFO - 2016-02-16 09:03:57 --> Model Class Initialized
INFO - 2016-02-16 09:03:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:03:57 --> Pagination Class Initialized
INFO - 2016-02-16 09:03:57 --> Helper loaded: text_helper
INFO - 2016-02-16 09:03:57 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:03:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:03:57 --> Final output sent to browser
DEBUG - 2016-02-16 12:03:57 --> Total execution time: 1.2018
INFO - 2016-02-16 09:03:58 --> Config Class Initialized
INFO - 2016-02-16 09:03:58 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:03:58 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:03:58 --> Utf8 Class Initialized
INFO - 2016-02-16 09:03:58 --> URI Class Initialized
INFO - 2016-02-16 09:03:58 --> Router Class Initialized
INFO - 2016-02-16 09:03:58 --> Output Class Initialized
INFO - 2016-02-16 09:03:58 --> Security Class Initialized
DEBUG - 2016-02-16 09:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:03:58 --> Input Class Initialized
INFO - 2016-02-16 09:03:58 --> Language Class Initialized
INFO - 2016-02-16 09:03:58 --> Loader Class Initialized
INFO - 2016-02-16 09:03:58 --> Helper loaded: url_helper
INFO - 2016-02-16 09:03:58 --> Helper loaded: file_helper
INFO - 2016-02-16 09:03:58 --> Helper loaded: date_helper
INFO - 2016-02-16 09:03:58 --> Helper loaded: form_helper
INFO - 2016-02-16 09:03:59 --> Database Driver Class Initialized
INFO - 2016-02-16 09:04:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:04:00 --> Controller Class Initialized
INFO - 2016-02-16 09:04:00 --> Model Class Initialized
INFO - 2016-02-16 09:04:00 --> Model Class Initialized
INFO - 2016-02-16 09:04:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:04:00 --> Pagination Class Initialized
INFO - 2016-02-16 09:04:00 --> Helper loaded: text_helper
INFO - 2016-02-16 09:04:00 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:04:00 --> Final output sent to browser
DEBUG - 2016-02-16 12:04:00 --> Total execution time: 1.0806
INFO - 2016-02-16 09:14:20 --> Config Class Initialized
INFO - 2016-02-16 09:14:20 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:14:20 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:14:20 --> Utf8 Class Initialized
INFO - 2016-02-16 09:14:20 --> URI Class Initialized
INFO - 2016-02-16 09:14:20 --> Router Class Initialized
INFO - 2016-02-16 09:14:20 --> Output Class Initialized
INFO - 2016-02-16 09:14:20 --> Security Class Initialized
DEBUG - 2016-02-16 09:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:14:20 --> Input Class Initialized
INFO - 2016-02-16 09:14:20 --> Language Class Initialized
ERROR - 2016-02-16 09:14:20 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 454
INFO - 2016-02-16 09:14:37 --> Config Class Initialized
INFO - 2016-02-16 09:14:37 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:14:37 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:14:37 --> Utf8 Class Initialized
INFO - 2016-02-16 09:14:37 --> URI Class Initialized
INFO - 2016-02-16 09:14:37 --> Router Class Initialized
INFO - 2016-02-16 09:14:37 --> Output Class Initialized
INFO - 2016-02-16 09:14:37 --> Security Class Initialized
DEBUG - 2016-02-16 09:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:14:37 --> Input Class Initialized
INFO - 2016-02-16 09:14:37 --> Language Class Initialized
ERROR - 2016-02-16 09:14:37 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 462
INFO - 2016-02-16 09:15:07 --> Config Class Initialized
INFO - 2016-02-16 09:15:07 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:15:07 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:15:07 --> Utf8 Class Initialized
INFO - 2016-02-16 09:15:07 --> URI Class Initialized
INFO - 2016-02-16 09:15:07 --> Router Class Initialized
INFO - 2016-02-16 09:15:07 --> Output Class Initialized
INFO - 2016-02-16 09:15:07 --> Security Class Initialized
DEBUG - 2016-02-16 09:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:15:07 --> Input Class Initialized
INFO - 2016-02-16 09:15:07 --> Language Class Initialized
INFO - 2016-02-16 09:15:07 --> Loader Class Initialized
INFO - 2016-02-16 09:15:07 --> Helper loaded: url_helper
INFO - 2016-02-16 09:15:07 --> Helper loaded: file_helper
INFO - 2016-02-16 09:15:07 --> Helper loaded: date_helper
INFO - 2016-02-16 09:15:07 --> Helper loaded: form_helper
INFO - 2016-02-16 09:15:07 --> Database Driver Class Initialized
INFO - 2016-02-16 09:15:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:15:08 --> Controller Class Initialized
INFO - 2016-02-16 09:15:08 --> Model Class Initialized
INFO - 2016-02-16 09:15:08 --> Model Class Initialized
INFO - 2016-02-16 09:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:15:08 --> Pagination Class Initialized
INFO - 2016-02-16 09:15:08 --> Helper loaded: text_helper
INFO - 2016-02-16 09:15:08 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:15:08 --> Final output sent to browser
DEBUG - 2016-02-16 12:15:08 --> Total execution time: 1.1683
INFO - 2016-02-16 09:15:15 --> Config Class Initialized
INFO - 2016-02-16 09:15:15 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:15:15 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:15:15 --> Utf8 Class Initialized
INFO - 2016-02-16 09:15:15 --> URI Class Initialized
INFO - 2016-02-16 09:15:15 --> Router Class Initialized
INFO - 2016-02-16 09:15:15 --> Output Class Initialized
INFO - 2016-02-16 09:15:15 --> Security Class Initialized
DEBUG - 2016-02-16 09:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:15:15 --> Input Class Initialized
INFO - 2016-02-16 09:15:15 --> Language Class Initialized
INFO - 2016-02-16 09:15:15 --> Loader Class Initialized
INFO - 2016-02-16 09:15:15 --> Helper loaded: url_helper
INFO - 2016-02-16 09:15:15 --> Helper loaded: file_helper
INFO - 2016-02-16 09:15:15 --> Helper loaded: date_helper
INFO - 2016-02-16 09:15:15 --> Helper loaded: form_helper
INFO - 2016-02-16 09:15:15 --> Database Driver Class Initialized
INFO - 2016-02-16 09:15:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:15:16 --> Controller Class Initialized
INFO - 2016-02-16 09:15:16 --> Model Class Initialized
INFO - 2016-02-16 09:15:16 --> Model Class Initialized
INFO - 2016-02-16 09:15:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:15:16 --> Pagination Class Initialized
INFO - 2016-02-16 09:15:16 --> Helper loaded: text_helper
INFO - 2016-02-16 09:15:16 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:15:16 --> Final output sent to browser
DEBUG - 2016-02-16 12:15:16 --> Total execution time: 1.1278
INFO - 2016-02-16 09:16:29 --> Config Class Initialized
INFO - 2016-02-16 09:16:29 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:16:29 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:16:29 --> Utf8 Class Initialized
INFO - 2016-02-16 09:16:29 --> URI Class Initialized
INFO - 2016-02-16 09:16:29 --> Router Class Initialized
INFO - 2016-02-16 09:16:29 --> Output Class Initialized
INFO - 2016-02-16 09:16:29 --> Security Class Initialized
DEBUG - 2016-02-16 09:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:16:29 --> Input Class Initialized
INFO - 2016-02-16 09:16:29 --> Language Class Initialized
INFO - 2016-02-16 09:16:29 --> Loader Class Initialized
INFO - 2016-02-16 09:16:29 --> Helper loaded: url_helper
INFO - 2016-02-16 09:16:29 --> Helper loaded: file_helper
INFO - 2016-02-16 09:16:29 --> Helper loaded: date_helper
INFO - 2016-02-16 09:16:29 --> Helper loaded: form_helper
INFO - 2016-02-16 09:16:29 --> Database Driver Class Initialized
INFO - 2016-02-16 09:16:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:16:30 --> Controller Class Initialized
INFO - 2016-02-16 09:16:30 --> Model Class Initialized
INFO - 2016-02-16 09:16:30 --> Model Class Initialized
INFO - 2016-02-16 09:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:16:30 --> Pagination Class Initialized
INFO - 2016-02-16 09:16:30 --> Helper loaded: text_helper
INFO - 2016-02-16 09:16:30 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:16:30 --> Final output sent to browser
DEBUG - 2016-02-16 12:16:30 --> Total execution time: 1.1849
INFO - 2016-02-16 09:17:53 --> Config Class Initialized
INFO - 2016-02-16 09:17:53 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:17:53 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:17:53 --> Utf8 Class Initialized
INFO - 2016-02-16 09:17:53 --> URI Class Initialized
DEBUG - 2016-02-16 09:17:53 --> No URI present. Default controller set.
INFO - 2016-02-16 09:17:53 --> Router Class Initialized
INFO - 2016-02-16 09:17:53 --> Output Class Initialized
INFO - 2016-02-16 09:17:53 --> Security Class Initialized
DEBUG - 2016-02-16 09:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:17:53 --> Input Class Initialized
INFO - 2016-02-16 09:17:53 --> Language Class Initialized
INFO - 2016-02-16 09:17:53 --> Loader Class Initialized
INFO - 2016-02-16 09:17:53 --> Helper loaded: url_helper
INFO - 2016-02-16 09:17:53 --> Helper loaded: file_helper
INFO - 2016-02-16 09:17:53 --> Helper loaded: date_helper
INFO - 2016-02-16 09:17:53 --> Helper loaded: form_helper
INFO - 2016-02-16 09:17:53 --> Database Driver Class Initialized
INFO - 2016-02-16 09:17:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:17:54 --> Controller Class Initialized
INFO - 2016-02-16 09:17:54 --> Model Class Initialized
INFO - 2016-02-16 09:17:54 --> Model Class Initialized
INFO - 2016-02-16 09:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:17:54 --> Pagination Class Initialized
INFO - 2016-02-16 09:17:54 --> Helper loaded: text_helper
INFO - 2016-02-16 09:17:54 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:17:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:17:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:17:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:17:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:17:54 --> Final output sent to browser
DEBUG - 2016-02-16 12:17:54 --> Total execution time: 1.1038
INFO - 2016-02-16 09:17:57 --> Config Class Initialized
INFO - 2016-02-16 09:17:57 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:17:57 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:17:57 --> Utf8 Class Initialized
INFO - 2016-02-16 09:17:57 --> URI Class Initialized
INFO - 2016-02-16 09:17:57 --> Router Class Initialized
INFO - 2016-02-16 09:17:57 --> Output Class Initialized
INFO - 2016-02-16 09:17:57 --> Security Class Initialized
DEBUG - 2016-02-16 09:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:17:57 --> Input Class Initialized
INFO - 2016-02-16 09:17:57 --> Language Class Initialized
INFO - 2016-02-16 09:17:57 --> Loader Class Initialized
INFO - 2016-02-16 09:17:57 --> Helper loaded: url_helper
INFO - 2016-02-16 09:17:57 --> Helper loaded: file_helper
INFO - 2016-02-16 09:17:57 --> Helper loaded: date_helper
INFO - 2016-02-16 09:17:57 --> Helper loaded: form_helper
INFO - 2016-02-16 09:17:57 --> Database Driver Class Initialized
INFO - 2016-02-16 09:17:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:17:59 --> Controller Class Initialized
INFO - 2016-02-16 09:17:59 --> Model Class Initialized
INFO - 2016-02-16 09:17:59 --> Model Class Initialized
INFO - 2016-02-16 09:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:17:59 --> Pagination Class Initialized
INFO - 2016-02-16 09:17:59 --> Helper loaded: text_helper
INFO - 2016-02-16 09:17:59 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:17:59 --> Final output sent to browser
DEBUG - 2016-02-16 12:17:59 --> Total execution time: 1.1605
INFO - 2016-02-16 09:18:02 --> Config Class Initialized
INFO - 2016-02-16 09:18:02 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:18:02 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:18:02 --> Utf8 Class Initialized
INFO - 2016-02-16 09:18:02 --> URI Class Initialized
INFO - 2016-02-16 09:18:02 --> Router Class Initialized
INFO - 2016-02-16 09:18:02 --> Output Class Initialized
INFO - 2016-02-16 09:18:02 --> Security Class Initialized
DEBUG - 2016-02-16 09:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:18:02 --> Input Class Initialized
INFO - 2016-02-16 09:18:02 --> Language Class Initialized
INFO - 2016-02-16 09:18:02 --> Loader Class Initialized
INFO - 2016-02-16 09:18:02 --> Helper loaded: url_helper
INFO - 2016-02-16 09:18:02 --> Helper loaded: file_helper
INFO - 2016-02-16 09:18:02 --> Helper loaded: date_helper
INFO - 2016-02-16 09:18:02 --> Helper loaded: form_helper
INFO - 2016-02-16 09:18:02 --> Database Driver Class Initialized
INFO - 2016-02-16 09:18:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:18:03 --> Controller Class Initialized
INFO - 2016-02-16 09:18:03 --> Model Class Initialized
INFO - 2016-02-16 09:18:03 --> Model Class Initialized
INFO - 2016-02-16 09:18:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:18:03 --> Pagination Class Initialized
INFO - 2016-02-16 09:18:03 --> Helper loaded: text_helper
INFO - 2016-02-16 09:18:03 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:18:03 --> Final output sent to browser
DEBUG - 2016-02-16 12:18:03 --> Total execution time: 1.1530
INFO - 2016-02-16 09:19:09 --> Config Class Initialized
INFO - 2016-02-16 09:19:09 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:19:09 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:19:09 --> Utf8 Class Initialized
INFO - 2016-02-16 09:19:09 --> URI Class Initialized
INFO - 2016-02-16 09:19:09 --> Router Class Initialized
INFO - 2016-02-16 09:19:09 --> Output Class Initialized
INFO - 2016-02-16 09:19:09 --> Security Class Initialized
DEBUG - 2016-02-16 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:19:09 --> Input Class Initialized
INFO - 2016-02-16 09:19:09 --> Language Class Initialized
INFO - 2016-02-16 09:19:09 --> Loader Class Initialized
INFO - 2016-02-16 09:19:09 --> Helper loaded: url_helper
INFO - 2016-02-16 09:19:09 --> Helper loaded: file_helper
INFO - 2016-02-16 09:19:09 --> Helper loaded: date_helper
INFO - 2016-02-16 09:19:09 --> Helper loaded: form_helper
INFO - 2016-02-16 09:19:09 --> Database Driver Class Initialized
INFO - 2016-02-16 09:19:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:19:10 --> Controller Class Initialized
INFO - 2016-02-16 09:19:10 --> Model Class Initialized
INFO - 2016-02-16 09:19:10 --> Model Class Initialized
INFO - 2016-02-16 09:19:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:19:10 --> Pagination Class Initialized
INFO - 2016-02-16 09:19:10 --> Helper loaded: text_helper
INFO - 2016-02-16 09:19:10 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:19:10 --> Final output sent to browser
DEBUG - 2016-02-16 12:19:10 --> Total execution time: 1.1608
INFO - 2016-02-16 09:19:56 --> Config Class Initialized
INFO - 2016-02-16 09:19:56 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:19:56 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:19:56 --> Utf8 Class Initialized
INFO - 2016-02-16 09:19:56 --> URI Class Initialized
INFO - 2016-02-16 09:19:56 --> Router Class Initialized
INFO - 2016-02-16 09:19:56 --> Output Class Initialized
INFO - 2016-02-16 09:19:56 --> Security Class Initialized
DEBUG - 2016-02-16 09:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:19:56 --> Input Class Initialized
INFO - 2016-02-16 09:19:56 --> Language Class Initialized
INFO - 2016-02-16 09:19:56 --> Loader Class Initialized
INFO - 2016-02-16 09:19:56 --> Helper loaded: url_helper
INFO - 2016-02-16 09:19:56 --> Helper loaded: file_helper
INFO - 2016-02-16 09:19:56 --> Helper loaded: date_helper
INFO - 2016-02-16 09:19:56 --> Helper loaded: form_helper
INFO - 2016-02-16 09:19:56 --> Database Driver Class Initialized
INFO - 2016-02-16 09:19:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:19:57 --> Controller Class Initialized
INFO - 2016-02-16 09:19:57 --> Model Class Initialized
INFO - 2016-02-16 09:19:57 --> Model Class Initialized
INFO - 2016-02-16 09:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:19:57 --> Pagination Class Initialized
INFO - 2016-02-16 09:19:57 --> Helper loaded: text_helper
INFO - 2016-02-16 09:19:57 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:19:57 --> Final output sent to browser
DEBUG - 2016-02-16 12:19:57 --> Total execution time: 1.1722
INFO - 2016-02-16 09:20:03 --> Config Class Initialized
INFO - 2016-02-16 09:20:03 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:20:03 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:20:03 --> Utf8 Class Initialized
INFO - 2016-02-16 09:20:03 --> URI Class Initialized
INFO - 2016-02-16 09:20:03 --> Router Class Initialized
INFO - 2016-02-16 09:20:03 --> Output Class Initialized
INFO - 2016-02-16 09:20:03 --> Security Class Initialized
DEBUG - 2016-02-16 09:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:20:03 --> Input Class Initialized
INFO - 2016-02-16 09:20:03 --> Language Class Initialized
INFO - 2016-02-16 09:20:03 --> Loader Class Initialized
INFO - 2016-02-16 09:20:03 --> Helper loaded: url_helper
INFO - 2016-02-16 09:20:03 --> Helper loaded: file_helper
INFO - 2016-02-16 09:20:03 --> Helper loaded: date_helper
INFO - 2016-02-16 09:20:03 --> Helper loaded: form_helper
INFO - 2016-02-16 09:20:03 --> Database Driver Class Initialized
INFO - 2016-02-16 09:20:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:20:04 --> Controller Class Initialized
INFO - 2016-02-16 09:20:04 --> Model Class Initialized
INFO - 2016-02-16 09:20:04 --> Model Class Initialized
INFO - 2016-02-16 09:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:20:04 --> Pagination Class Initialized
INFO - 2016-02-16 09:20:04 --> Helper loaded: text_helper
INFO - 2016-02-16 09:20:04 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:20:04 --> Final output sent to browser
DEBUG - 2016-02-16 12:20:04 --> Total execution time: 1.1147
INFO - 2016-02-16 09:20:21 --> Config Class Initialized
INFO - 2016-02-16 09:20:21 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:20:21 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:20:21 --> Utf8 Class Initialized
INFO - 2016-02-16 09:20:21 --> URI Class Initialized
INFO - 2016-02-16 09:20:21 --> Router Class Initialized
INFO - 2016-02-16 09:20:21 --> Output Class Initialized
INFO - 2016-02-16 09:20:21 --> Security Class Initialized
DEBUG - 2016-02-16 09:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:20:21 --> Input Class Initialized
INFO - 2016-02-16 09:20:21 --> Language Class Initialized
INFO - 2016-02-16 09:20:21 --> Loader Class Initialized
INFO - 2016-02-16 09:20:21 --> Helper loaded: url_helper
INFO - 2016-02-16 09:20:21 --> Helper loaded: file_helper
INFO - 2016-02-16 09:20:21 --> Helper loaded: date_helper
INFO - 2016-02-16 09:20:21 --> Helper loaded: form_helper
INFO - 2016-02-16 09:20:21 --> Database Driver Class Initialized
INFO - 2016-02-16 09:20:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:20:22 --> Controller Class Initialized
INFO - 2016-02-16 09:20:22 --> Model Class Initialized
INFO - 2016-02-16 09:20:22 --> Model Class Initialized
INFO - 2016-02-16 09:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:20:22 --> Pagination Class Initialized
INFO - 2016-02-16 09:20:22 --> Helper loaded: text_helper
INFO - 2016-02-16 09:20:22 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:20:22 --> Final output sent to browser
DEBUG - 2016-02-16 12:20:22 --> Total execution time: 1.1184
INFO - 2016-02-16 09:20:59 --> Config Class Initialized
INFO - 2016-02-16 09:20:59 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:20:59 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:20:59 --> Utf8 Class Initialized
INFO - 2016-02-16 09:20:59 --> URI Class Initialized
DEBUG - 2016-02-16 09:20:59 --> No URI present. Default controller set.
INFO - 2016-02-16 09:20:59 --> Router Class Initialized
INFO - 2016-02-16 09:20:59 --> Output Class Initialized
INFO - 2016-02-16 09:20:59 --> Security Class Initialized
DEBUG - 2016-02-16 09:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:20:59 --> Input Class Initialized
INFO - 2016-02-16 09:20:59 --> Language Class Initialized
INFO - 2016-02-16 09:20:59 --> Loader Class Initialized
INFO - 2016-02-16 09:20:59 --> Helper loaded: url_helper
INFO - 2016-02-16 09:20:59 --> Helper loaded: file_helper
INFO - 2016-02-16 09:20:59 --> Helper loaded: date_helper
INFO - 2016-02-16 09:20:59 --> Helper loaded: form_helper
INFO - 2016-02-16 09:20:59 --> Database Driver Class Initialized
INFO - 2016-02-16 09:21:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:21:00 --> Controller Class Initialized
INFO - 2016-02-16 09:21:00 --> Model Class Initialized
INFO - 2016-02-16 09:21:00 --> Model Class Initialized
INFO - 2016-02-16 09:21:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:21:00 --> Pagination Class Initialized
INFO - 2016-02-16 09:21:00 --> Helper loaded: text_helper
INFO - 2016-02-16 09:21:00 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:21:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:21:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:21:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:21:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:21:00 --> Final output sent to browser
DEBUG - 2016-02-16 12:21:00 --> Total execution time: 1.1215
INFO - 2016-02-16 09:22:24 --> Config Class Initialized
INFO - 2016-02-16 09:22:24 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:22:24 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:22:24 --> Utf8 Class Initialized
INFO - 2016-02-16 09:22:24 --> URI Class Initialized
INFO - 2016-02-16 09:22:24 --> Router Class Initialized
INFO - 2016-02-16 09:22:24 --> Output Class Initialized
INFO - 2016-02-16 09:22:24 --> Security Class Initialized
DEBUG - 2016-02-16 09:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:22:24 --> Input Class Initialized
INFO - 2016-02-16 09:22:24 --> Language Class Initialized
INFO - 2016-02-16 09:22:24 --> Loader Class Initialized
INFO - 2016-02-16 09:22:24 --> Helper loaded: url_helper
INFO - 2016-02-16 09:22:24 --> Helper loaded: file_helper
INFO - 2016-02-16 09:22:24 --> Helper loaded: date_helper
INFO - 2016-02-16 09:22:24 --> Helper loaded: form_helper
INFO - 2016-02-16 09:22:24 --> Database Driver Class Initialized
INFO - 2016-02-16 09:22:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:22:25 --> Controller Class Initialized
INFO - 2016-02-16 09:22:25 --> Model Class Initialized
INFO - 2016-02-16 09:22:25 --> Model Class Initialized
INFO - 2016-02-16 09:22:26 --> Form Validation Class Initialized
INFO - 2016-02-16 09:22:26 --> Helper loaded: text_helper
INFO - 2016-02-16 09:22:26 --> Config Class Initialized
INFO - 2016-02-16 09:22:26 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:22:26 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:22:26 --> Utf8 Class Initialized
INFO - 2016-02-16 09:22:26 --> URI Class Initialized
INFO - 2016-02-16 09:22:26 --> Router Class Initialized
INFO - 2016-02-16 09:22:26 --> Output Class Initialized
INFO - 2016-02-16 09:22:26 --> Security Class Initialized
DEBUG - 2016-02-16 09:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:22:26 --> Input Class Initialized
INFO - 2016-02-16 09:22:26 --> Language Class Initialized
INFO - 2016-02-16 09:22:26 --> Loader Class Initialized
INFO - 2016-02-16 09:22:26 --> Helper loaded: url_helper
INFO - 2016-02-16 09:22:26 --> Helper loaded: file_helper
INFO - 2016-02-16 09:22:26 --> Helper loaded: date_helper
INFO - 2016-02-16 09:22:26 --> Helper loaded: form_helper
INFO - 2016-02-16 09:22:26 --> Database Driver Class Initialized
INFO - 2016-02-16 09:22:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:22:27 --> Controller Class Initialized
INFO - 2016-02-16 09:22:27 --> Model Class Initialized
INFO - 2016-02-16 09:22:27 --> Model Class Initialized
INFO - 2016-02-16 09:22:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:22:27 --> Pagination Class Initialized
INFO - 2016-02-16 09:22:27 --> Helper loaded: text_helper
INFO - 2016-02-16 09:22:27 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:22:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:22:27 --> Final output sent to browser
DEBUG - 2016-02-16 12:22:27 --> Total execution time: 1.1163
INFO - 2016-02-16 09:22:28 --> Config Class Initialized
INFO - 2016-02-16 09:22:28 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:22:28 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:22:28 --> Utf8 Class Initialized
INFO - 2016-02-16 09:22:28 --> URI Class Initialized
INFO - 2016-02-16 09:22:28 --> Router Class Initialized
INFO - 2016-02-16 09:22:28 --> Output Class Initialized
INFO - 2016-02-16 09:22:28 --> Security Class Initialized
DEBUG - 2016-02-16 09:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:22:28 --> Input Class Initialized
INFO - 2016-02-16 09:22:28 --> Language Class Initialized
INFO - 2016-02-16 09:22:28 --> Loader Class Initialized
INFO - 2016-02-16 09:22:28 --> Helper loaded: url_helper
INFO - 2016-02-16 09:22:28 --> Helper loaded: file_helper
INFO - 2016-02-16 09:22:28 --> Helper loaded: date_helper
INFO - 2016-02-16 09:22:28 --> Helper loaded: form_helper
INFO - 2016-02-16 09:22:28 --> Database Driver Class Initialized
INFO - 2016-02-16 09:22:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:22:29 --> Controller Class Initialized
INFO - 2016-02-16 09:22:29 --> Model Class Initialized
INFO - 2016-02-16 09:22:29 --> Model Class Initialized
INFO - 2016-02-16 09:22:29 --> Form Validation Class Initialized
INFO - 2016-02-16 09:22:29 --> Helper loaded: text_helper
INFO - 2016-02-16 09:22:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 09:22:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 09:22:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-16 09:22:29 --> Model Class Initialized
INFO - 2016-02-16 09:22:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 09:22:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 09:22:29 --> Final output sent to browser
DEBUG - 2016-02-16 09:22:29 --> Total execution time: 1.1070
INFO - 2016-02-16 09:22:39 --> Config Class Initialized
INFO - 2016-02-16 09:22:39 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:22:39 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:22:39 --> Utf8 Class Initialized
INFO - 2016-02-16 09:22:39 --> URI Class Initialized
INFO - 2016-02-16 09:22:39 --> Router Class Initialized
INFO - 2016-02-16 09:22:39 --> Output Class Initialized
INFO - 2016-02-16 09:22:39 --> Security Class Initialized
DEBUG - 2016-02-16 09:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:22:39 --> Input Class Initialized
INFO - 2016-02-16 09:22:39 --> Language Class Initialized
INFO - 2016-02-16 09:22:39 --> Loader Class Initialized
INFO - 2016-02-16 09:22:39 --> Helper loaded: url_helper
INFO - 2016-02-16 09:22:39 --> Helper loaded: file_helper
INFO - 2016-02-16 09:22:39 --> Helper loaded: date_helper
INFO - 2016-02-16 09:22:39 --> Helper loaded: form_helper
INFO - 2016-02-16 09:22:39 --> Database Driver Class Initialized
INFO - 2016-02-16 09:22:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:22:40 --> Controller Class Initialized
INFO - 2016-02-16 09:22:40 --> Model Class Initialized
INFO - 2016-02-16 09:22:40 --> Model Class Initialized
INFO - 2016-02-16 09:22:40 --> Form Validation Class Initialized
INFO - 2016-02-16 09:22:40 --> Helper loaded: text_helper
INFO - 2016-02-16 09:22:40 --> Config Class Initialized
INFO - 2016-02-16 09:22:40 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:22:40 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:22:40 --> Utf8 Class Initialized
INFO - 2016-02-16 09:22:40 --> URI Class Initialized
INFO - 2016-02-16 09:22:40 --> Router Class Initialized
INFO - 2016-02-16 09:22:40 --> Output Class Initialized
INFO - 2016-02-16 09:22:40 --> Security Class Initialized
DEBUG - 2016-02-16 09:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:22:40 --> Input Class Initialized
INFO - 2016-02-16 09:22:40 --> Language Class Initialized
INFO - 2016-02-16 09:22:40 --> Loader Class Initialized
INFO - 2016-02-16 09:22:40 --> Helper loaded: url_helper
INFO - 2016-02-16 09:22:40 --> Helper loaded: file_helper
INFO - 2016-02-16 09:22:40 --> Helper loaded: date_helper
INFO - 2016-02-16 09:22:40 --> Helper loaded: form_helper
INFO - 2016-02-16 09:22:40 --> Database Driver Class Initialized
INFO - 2016-02-16 09:22:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:22:41 --> Controller Class Initialized
INFO - 2016-02-16 09:22:41 --> Model Class Initialized
INFO - 2016-02-16 09:22:41 --> Model Class Initialized
INFO - 2016-02-16 09:22:41 --> Form Validation Class Initialized
INFO - 2016-02-16 09:22:41 --> Helper loaded: text_helper
INFO - 2016-02-16 09:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 09:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 09:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-16 09:22:41 --> Model Class Initialized
INFO - 2016-02-16 09:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 09:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 09:22:41 --> Final output sent to browser
DEBUG - 2016-02-16 09:22:41 --> Total execution time: 1.1310
INFO - 2016-02-16 09:22:43 --> Config Class Initialized
INFO - 2016-02-16 09:22:43 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:22:43 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:22:43 --> Utf8 Class Initialized
INFO - 2016-02-16 09:22:43 --> URI Class Initialized
DEBUG - 2016-02-16 09:22:43 --> No URI present. Default controller set.
INFO - 2016-02-16 09:22:43 --> Router Class Initialized
INFO - 2016-02-16 09:22:43 --> Output Class Initialized
INFO - 2016-02-16 09:22:43 --> Security Class Initialized
DEBUG - 2016-02-16 09:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:22:43 --> Input Class Initialized
INFO - 2016-02-16 09:22:43 --> Language Class Initialized
INFO - 2016-02-16 09:22:43 --> Loader Class Initialized
INFO - 2016-02-16 09:22:43 --> Helper loaded: url_helper
INFO - 2016-02-16 09:22:43 --> Helper loaded: file_helper
INFO - 2016-02-16 09:22:43 --> Helper loaded: date_helper
INFO - 2016-02-16 09:22:43 --> Helper loaded: form_helper
INFO - 2016-02-16 09:22:43 --> Database Driver Class Initialized
INFO - 2016-02-16 09:22:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:22:44 --> Controller Class Initialized
INFO - 2016-02-16 09:22:44 --> Model Class Initialized
INFO - 2016-02-16 09:22:44 --> Model Class Initialized
INFO - 2016-02-16 09:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:22:44 --> Pagination Class Initialized
INFO - 2016-02-16 09:22:44 --> Helper loaded: text_helper
INFO - 2016-02-16 09:22:44 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:22:44 --> Final output sent to browser
DEBUG - 2016-02-16 12:22:44 --> Total execution time: 1.1280
INFO - 2016-02-16 09:22:47 --> Config Class Initialized
INFO - 2016-02-16 09:22:47 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:22:47 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:22:47 --> Utf8 Class Initialized
INFO - 2016-02-16 09:22:47 --> URI Class Initialized
INFO - 2016-02-16 09:22:47 --> Router Class Initialized
INFO - 2016-02-16 09:22:47 --> Output Class Initialized
INFO - 2016-02-16 09:22:47 --> Security Class Initialized
DEBUG - 2016-02-16 09:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:22:47 --> Input Class Initialized
INFO - 2016-02-16 09:22:47 --> Language Class Initialized
INFO - 2016-02-16 09:22:47 --> Loader Class Initialized
INFO - 2016-02-16 09:22:47 --> Helper loaded: url_helper
INFO - 2016-02-16 09:22:47 --> Helper loaded: file_helper
INFO - 2016-02-16 09:22:47 --> Helper loaded: date_helper
INFO - 2016-02-16 09:22:47 --> Helper loaded: form_helper
INFO - 2016-02-16 09:22:47 --> Database Driver Class Initialized
INFO - 2016-02-16 09:22:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:22:48 --> Controller Class Initialized
INFO - 2016-02-16 09:22:48 --> Model Class Initialized
INFO - 2016-02-16 09:22:48 --> Model Class Initialized
INFO - 2016-02-16 09:22:48 --> Form Validation Class Initialized
INFO - 2016-02-16 09:22:48 --> Helper loaded: text_helper
INFO - 2016-02-16 09:22:48 --> Config Class Initialized
INFO - 2016-02-16 09:22:48 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:22:48 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:22:48 --> Utf8 Class Initialized
INFO - 2016-02-16 09:22:48 --> URI Class Initialized
INFO - 2016-02-16 09:22:48 --> Router Class Initialized
INFO - 2016-02-16 09:22:48 --> Output Class Initialized
INFO - 2016-02-16 09:22:48 --> Security Class Initialized
DEBUG - 2016-02-16 09:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:22:48 --> Input Class Initialized
INFO - 2016-02-16 09:22:48 --> Language Class Initialized
INFO - 2016-02-16 09:22:48 --> Loader Class Initialized
INFO - 2016-02-16 09:22:48 --> Helper loaded: url_helper
INFO - 2016-02-16 09:22:48 --> Helper loaded: file_helper
INFO - 2016-02-16 09:22:48 --> Helper loaded: date_helper
INFO - 2016-02-16 09:22:48 --> Helper loaded: form_helper
INFO - 2016-02-16 09:22:48 --> Database Driver Class Initialized
INFO - 2016-02-16 09:22:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:22:49 --> Controller Class Initialized
INFO - 2016-02-16 09:22:49 --> Model Class Initialized
INFO - 2016-02-16 09:22:49 --> Model Class Initialized
INFO - 2016-02-16 09:22:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:22:49 --> Pagination Class Initialized
INFO - 2016-02-16 09:22:49 --> Helper loaded: text_helper
INFO - 2016-02-16 09:22:49 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:22:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:22:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:22:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:22:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:22:49 --> Final output sent to browser
DEBUG - 2016-02-16 12:22:49 --> Total execution time: 1.0991
INFO - 2016-02-16 09:44:50 --> Config Class Initialized
INFO - 2016-02-16 09:44:50 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:44:50 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:44:50 --> Utf8 Class Initialized
INFO - 2016-02-16 09:44:50 --> URI Class Initialized
DEBUG - 2016-02-16 09:44:50 --> No URI present. Default controller set.
INFO - 2016-02-16 09:44:50 --> Router Class Initialized
INFO - 2016-02-16 09:44:50 --> Output Class Initialized
INFO - 2016-02-16 09:44:50 --> Security Class Initialized
DEBUG - 2016-02-16 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:44:50 --> Input Class Initialized
INFO - 2016-02-16 09:44:50 --> Language Class Initialized
INFO - 2016-02-16 09:44:50 --> Loader Class Initialized
INFO - 2016-02-16 09:44:50 --> Helper loaded: url_helper
INFO - 2016-02-16 09:44:50 --> Helper loaded: file_helper
INFO - 2016-02-16 09:44:50 --> Helper loaded: date_helper
INFO - 2016-02-16 09:44:50 --> Helper loaded: form_helper
INFO - 2016-02-16 09:44:50 --> Database Driver Class Initialized
INFO - 2016-02-16 09:44:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:44:51 --> Controller Class Initialized
INFO - 2016-02-16 09:44:51 --> Model Class Initialized
INFO - 2016-02-16 09:44:51 --> Model Class Initialized
INFO - 2016-02-16 09:44:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:44:51 --> Pagination Class Initialized
INFO - 2016-02-16 09:44:51 --> Helper loaded: text_helper
INFO - 2016-02-16 09:44:51 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:44:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:44:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:44:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:44:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:44:51 --> Final output sent to browser
DEBUG - 2016-02-16 12:44:51 --> Total execution time: 1.1376
INFO - 2016-02-16 09:44:54 --> Config Class Initialized
INFO - 2016-02-16 09:44:54 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:44:54 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:44:54 --> Utf8 Class Initialized
INFO - 2016-02-16 09:44:54 --> URI Class Initialized
INFO - 2016-02-16 09:44:55 --> Router Class Initialized
INFO - 2016-02-16 09:44:55 --> Output Class Initialized
INFO - 2016-02-16 09:44:55 --> Security Class Initialized
DEBUG - 2016-02-16 09:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:44:55 --> Input Class Initialized
INFO - 2016-02-16 09:44:55 --> Language Class Initialized
INFO - 2016-02-16 09:44:55 --> Loader Class Initialized
INFO - 2016-02-16 09:44:55 --> Helper loaded: url_helper
INFO - 2016-02-16 09:44:55 --> Helper loaded: file_helper
INFO - 2016-02-16 09:44:55 --> Helper loaded: date_helper
INFO - 2016-02-16 09:44:55 --> Helper loaded: form_helper
INFO - 2016-02-16 09:44:55 --> Database Driver Class Initialized
INFO - 2016-02-16 09:44:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:44:56 --> Controller Class Initialized
INFO - 2016-02-16 09:44:56 --> Model Class Initialized
INFO - 2016-02-16 09:44:56 --> Model Class Initialized
INFO - 2016-02-16 09:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:44:56 --> Pagination Class Initialized
INFO - 2016-02-16 09:44:56 --> Helper loaded: text_helper
INFO - 2016-02-16 09:44:56 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:44:56 --> Final output sent to browser
DEBUG - 2016-02-16 12:44:56 --> Total execution time: 1.1682
INFO - 2016-02-16 09:44:58 --> Config Class Initialized
INFO - 2016-02-16 09:44:58 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:44:58 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:44:58 --> Utf8 Class Initialized
INFO - 2016-02-16 09:44:58 --> URI Class Initialized
INFO - 2016-02-16 09:44:58 --> Router Class Initialized
INFO - 2016-02-16 09:44:58 --> Output Class Initialized
INFO - 2016-02-16 09:44:58 --> Security Class Initialized
DEBUG - 2016-02-16 09:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:44:58 --> Input Class Initialized
INFO - 2016-02-16 09:44:58 --> Language Class Initialized
INFO - 2016-02-16 09:44:58 --> Loader Class Initialized
INFO - 2016-02-16 09:44:58 --> Helper loaded: url_helper
INFO - 2016-02-16 09:44:58 --> Helper loaded: file_helper
INFO - 2016-02-16 09:44:58 --> Helper loaded: date_helper
INFO - 2016-02-16 09:44:58 --> Helper loaded: form_helper
INFO - 2016-02-16 09:44:58 --> Database Driver Class Initialized
INFO - 2016-02-16 09:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:44:59 --> Controller Class Initialized
INFO - 2016-02-16 09:44:59 --> Model Class Initialized
INFO - 2016-02-16 09:44:59 --> Model Class Initialized
INFO - 2016-02-16 09:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:44:59 --> Pagination Class Initialized
INFO - 2016-02-16 09:44:59 --> Helper loaded: text_helper
INFO - 2016-02-16 09:44:59 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:44:59 --> Final output sent to browser
DEBUG - 2016-02-16 12:44:59 --> Total execution time: 1.1340
INFO - 2016-02-16 09:45:15 --> Config Class Initialized
INFO - 2016-02-16 09:45:15 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:45:16 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:45:16 --> Utf8 Class Initialized
INFO - 2016-02-16 09:45:16 --> URI Class Initialized
INFO - 2016-02-16 09:45:16 --> Router Class Initialized
INFO - 2016-02-16 09:45:16 --> Output Class Initialized
INFO - 2016-02-16 09:45:16 --> Security Class Initialized
DEBUG - 2016-02-16 09:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:45:16 --> Input Class Initialized
INFO - 2016-02-16 09:45:16 --> Language Class Initialized
INFO - 2016-02-16 09:45:16 --> Loader Class Initialized
INFO - 2016-02-16 09:45:16 --> Helper loaded: url_helper
INFO - 2016-02-16 09:45:16 --> Helper loaded: file_helper
INFO - 2016-02-16 09:45:16 --> Helper loaded: date_helper
INFO - 2016-02-16 09:45:16 --> Helper loaded: form_helper
INFO - 2016-02-16 09:45:16 --> Database Driver Class Initialized
INFO - 2016-02-16 09:45:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:45:17 --> Controller Class Initialized
INFO - 2016-02-16 09:45:17 --> Model Class Initialized
INFO - 2016-02-16 09:45:17 --> Model Class Initialized
INFO - 2016-02-16 09:45:17 --> Form Validation Class Initialized
INFO - 2016-02-16 09:45:17 --> Helper loaded: text_helper
INFO - 2016-02-16 09:45:17 --> Config Class Initialized
INFO - 2016-02-16 09:45:17 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:45:17 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:45:17 --> Utf8 Class Initialized
INFO - 2016-02-16 09:45:17 --> URI Class Initialized
INFO - 2016-02-16 09:45:17 --> Router Class Initialized
INFO - 2016-02-16 09:45:17 --> Output Class Initialized
INFO - 2016-02-16 09:45:17 --> Security Class Initialized
DEBUG - 2016-02-16 09:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:45:17 --> Input Class Initialized
INFO - 2016-02-16 09:45:17 --> Language Class Initialized
INFO - 2016-02-16 09:45:17 --> Loader Class Initialized
INFO - 2016-02-16 09:45:17 --> Helper loaded: url_helper
INFO - 2016-02-16 09:45:17 --> Helper loaded: file_helper
INFO - 2016-02-16 09:45:17 --> Helper loaded: date_helper
INFO - 2016-02-16 09:45:17 --> Helper loaded: form_helper
INFO - 2016-02-16 09:45:17 --> Database Driver Class Initialized
INFO - 2016-02-16 09:45:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:45:18 --> Controller Class Initialized
INFO - 2016-02-16 09:45:18 --> Model Class Initialized
INFO - 2016-02-16 09:45:18 --> Model Class Initialized
INFO - 2016-02-16 09:45:18 --> Form Validation Class Initialized
INFO - 2016-02-16 09:45:18 --> Helper loaded: text_helper
INFO - 2016-02-16 09:45:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-16 09:45:18 --> Final output sent to browser
DEBUG - 2016-02-16 09:45:18 --> Total execution time: 1.1295
INFO - 2016-02-16 09:45:26 --> Config Class Initialized
INFO - 2016-02-16 09:45:26 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:45:26 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:45:26 --> Utf8 Class Initialized
INFO - 2016-02-16 09:45:26 --> URI Class Initialized
DEBUG - 2016-02-16 09:45:26 --> No URI present. Default controller set.
INFO - 2016-02-16 09:45:26 --> Router Class Initialized
INFO - 2016-02-16 09:45:26 --> Output Class Initialized
INFO - 2016-02-16 09:45:26 --> Security Class Initialized
DEBUG - 2016-02-16 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:45:26 --> Input Class Initialized
INFO - 2016-02-16 09:45:26 --> Language Class Initialized
INFO - 2016-02-16 09:45:26 --> Loader Class Initialized
INFO - 2016-02-16 09:45:26 --> Helper loaded: url_helper
INFO - 2016-02-16 09:45:26 --> Helper loaded: file_helper
INFO - 2016-02-16 09:45:26 --> Helper loaded: date_helper
INFO - 2016-02-16 09:45:26 --> Helper loaded: form_helper
INFO - 2016-02-16 09:45:26 --> Database Driver Class Initialized
INFO - 2016-02-16 09:45:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:45:27 --> Controller Class Initialized
INFO - 2016-02-16 09:45:27 --> Model Class Initialized
INFO - 2016-02-16 09:45:27 --> Model Class Initialized
INFO - 2016-02-16 09:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:45:27 --> Pagination Class Initialized
INFO - 2016-02-16 09:45:27 --> Helper loaded: text_helper
INFO - 2016-02-16 09:45:27 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:45:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:45:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:45:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:45:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:45:27 --> Final output sent to browser
DEBUG - 2016-02-16 12:45:27 --> Total execution time: 1.1090
INFO - 2016-02-16 09:45:36 --> Config Class Initialized
INFO - 2016-02-16 09:45:36 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:45:37 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:45:37 --> Utf8 Class Initialized
INFO - 2016-02-16 09:45:37 --> URI Class Initialized
INFO - 2016-02-16 09:45:37 --> Router Class Initialized
INFO - 2016-02-16 09:45:37 --> Output Class Initialized
INFO - 2016-02-16 09:45:37 --> Security Class Initialized
DEBUG - 2016-02-16 09:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:45:37 --> Input Class Initialized
INFO - 2016-02-16 09:45:37 --> Language Class Initialized
INFO - 2016-02-16 09:45:37 --> Loader Class Initialized
INFO - 2016-02-16 09:45:37 --> Helper loaded: url_helper
INFO - 2016-02-16 09:45:37 --> Helper loaded: file_helper
INFO - 2016-02-16 09:45:37 --> Helper loaded: date_helper
INFO - 2016-02-16 09:45:37 --> Helper loaded: form_helper
INFO - 2016-02-16 09:45:37 --> Database Driver Class Initialized
INFO - 2016-02-16 09:45:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:45:38 --> Controller Class Initialized
INFO - 2016-02-16 09:45:38 --> Model Class Initialized
INFO - 2016-02-16 09:45:38 --> Model Class Initialized
INFO - 2016-02-16 09:45:38 --> Form Validation Class Initialized
INFO - 2016-02-16 09:45:38 --> Helper loaded: text_helper
INFO - 2016-02-16 09:45:38 --> Config Class Initialized
INFO - 2016-02-16 09:45:38 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:45:38 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:45:38 --> Utf8 Class Initialized
INFO - 2016-02-16 09:45:38 --> URI Class Initialized
INFO - 2016-02-16 09:45:38 --> Router Class Initialized
INFO - 2016-02-16 09:45:38 --> Output Class Initialized
INFO - 2016-02-16 09:45:38 --> Security Class Initialized
DEBUG - 2016-02-16 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:45:38 --> Input Class Initialized
INFO - 2016-02-16 09:45:38 --> Language Class Initialized
INFO - 2016-02-16 09:45:38 --> Loader Class Initialized
INFO - 2016-02-16 09:45:38 --> Helper loaded: url_helper
INFO - 2016-02-16 09:45:38 --> Helper loaded: file_helper
INFO - 2016-02-16 09:45:38 --> Helper loaded: date_helper
INFO - 2016-02-16 09:45:38 --> Helper loaded: form_helper
INFO - 2016-02-16 09:45:38 --> Database Driver Class Initialized
INFO - 2016-02-16 09:45:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:45:39 --> Controller Class Initialized
INFO - 2016-02-16 09:45:39 --> Model Class Initialized
INFO - 2016-02-16 09:45:39 --> Model Class Initialized
INFO - 2016-02-16 09:45:39 --> Form Validation Class Initialized
INFO - 2016-02-16 09:45:39 --> Helper loaded: text_helper
INFO - 2016-02-16 09:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\login.php
INFO - 2016-02-16 09:45:39 --> Final output sent to browser
DEBUG - 2016-02-16 09:45:39 --> Total execution time: 1.1683
INFO - 2016-02-16 09:45:46 --> Config Class Initialized
INFO - 2016-02-16 09:45:46 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:45:46 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:45:46 --> Utf8 Class Initialized
INFO - 2016-02-16 09:45:46 --> URI Class Initialized
DEBUG - 2016-02-16 09:45:46 --> No URI present. Default controller set.
INFO - 2016-02-16 09:45:46 --> Router Class Initialized
INFO - 2016-02-16 09:45:46 --> Output Class Initialized
INFO - 2016-02-16 09:45:46 --> Security Class Initialized
DEBUG - 2016-02-16 09:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:45:46 --> Input Class Initialized
INFO - 2016-02-16 09:45:46 --> Language Class Initialized
INFO - 2016-02-16 09:45:46 --> Loader Class Initialized
INFO - 2016-02-16 09:45:46 --> Helper loaded: url_helper
INFO - 2016-02-16 09:45:46 --> Helper loaded: file_helper
INFO - 2016-02-16 09:45:46 --> Helper loaded: date_helper
INFO - 2016-02-16 09:45:46 --> Helper loaded: form_helper
INFO - 2016-02-16 09:45:46 --> Database Driver Class Initialized
INFO - 2016-02-16 09:45:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:45:47 --> Controller Class Initialized
INFO - 2016-02-16 09:45:47 --> Model Class Initialized
INFO - 2016-02-16 09:45:47 --> Model Class Initialized
INFO - 2016-02-16 09:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:45:47 --> Pagination Class Initialized
INFO - 2016-02-16 09:45:47 --> Helper loaded: text_helper
INFO - 2016-02-16 09:45:47 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:45:47 --> Final output sent to browser
DEBUG - 2016-02-16 12:45:47 --> Total execution time: 1.1407
INFO - 2016-02-16 09:45:58 --> Config Class Initialized
INFO - 2016-02-16 09:45:58 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:45:58 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:45:58 --> Utf8 Class Initialized
INFO - 2016-02-16 09:45:58 --> URI Class Initialized
INFO - 2016-02-16 09:45:58 --> Router Class Initialized
INFO - 2016-02-16 09:45:58 --> Output Class Initialized
INFO - 2016-02-16 09:45:58 --> Security Class Initialized
DEBUG - 2016-02-16 09:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:45:58 --> Input Class Initialized
INFO - 2016-02-16 09:45:58 --> Language Class Initialized
INFO - 2016-02-16 09:45:58 --> Loader Class Initialized
INFO - 2016-02-16 09:45:58 --> Helper loaded: url_helper
INFO - 2016-02-16 09:45:58 --> Helper loaded: file_helper
INFO - 2016-02-16 09:45:58 --> Helper loaded: date_helper
INFO - 2016-02-16 09:45:58 --> Helper loaded: form_helper
INFO - 2016-02-16 09:45:58 --> Database Driver Class Initialized
INFO - 2016-02-16 09:45:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:45:59 --> Controller Class Initialized
INFO - 2016-02-16 09:45:59 --> Model Class Initialized
INFO - 2016-02-16 09:45:59 --> Model Class Initialized
INFO - 2016-02-16 09:45:59 --> Form Validation Class Initialized
INFO - 2016-02-16 09:45:59 --> Helper loaded: text_helper
INFO - 2016-02-16 09:45:59 --> Config Class Initialized
INFO - 2016-02-16 09:45:59 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:45:59 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:45:59 --> Utf8 Class Initialized
INFO - 2016-02-16 09:45:59 --> URI Class Initialized
DEBUG - 2016-02-16 09:45:59 --> No URI present. Default controller set.
INFO - 2016-02-16 09:45:59 --> Router Class Initialized
INFO - 2016-02-16 09:45:59 --> Output Class Initialized
INFO - 2016-02-16 09:45:59 --> Security Class Initialized
DEBUG - 2016-02-16 09:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:45:59 --> Input Class Initialized
INFO - 2016-02-16 09:45:59 --> Language Class Initialized
INFO - 2016-02-16 09:45:59 --> Loader Class Initialized
INFO - 2016-02-16 09:45:59 --> Helper loaded: url_helper
INFO - 2016-02-16 09:45:59 --> Helper loaded: file_helper
INFO - 2016-02-16 09:45:59 --> Helper loaded: date_helper
INFO - 2016-02-16 09:45:59 --> Helper loaded: form_helper
INFO - 2016-02-16 09:45:59 --> Database Driver Class Initialized
INFO - 2016-02-16 09:46:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:46:00 --> Controller Class Initialized
INFO - 2016-02-16 09:46:00 --> Model Class Initialized
INFO - 2016-02-16 09:46:00 --> Model Class Initialized
INFO - 2016-02-16 09:46:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:46:00 --> Pagination Class Initialized
INFO - 2016-02-16 09:46:00 --> Helper loaded: text_helper
INFO - 2016-02-16 09:46:00 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:46:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:46:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:46:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:46:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:46:00 --> Final output sent to browser
DEBUG - 2016-02-16 12:46:00 --> Total execution time: 1.1191
INFO - 2016-02-16 09:46:04 --> Config Class Initialized
INFO - 2016-02-16 09:46:04 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:46:04 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:46:04 --> Utf8 Class Initialized
INFO - 2016-02-16 09:46:04 --> URI Class Initialized
INFO - 2016-02-16 09:46:04 --> Router Class Initialized
INFO - 2016-02-16 09:46:04 --> Output Class Initialized
INFO - 2016-02-16 09:46:04 --> Security Class Initialized
DEBUG - 2016-02-16 09:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:46:04 --> Input Class Initialized
INFO - 2016-02-16 09:46:04 --> Language Class Initialized
INFO - 2016-02-16 09:46:04 --> Loader Class Initialized
INFO - 2016-02-16 09:46:04 --> Helper loaded: url_helper
INFO - 2016-02-16 09:46:04 --> Helper loaded: file_helper
INFO - 2016-02-16 09:46:04 --> Helper loaded: date_helper
INFO - 2016-02-16 09:46:04 --> Helper loaded: form_helper
INFO - 2016-02-16 09:46:04 --> Database Driver Class Initialized
INFO - 2016-02-16 09:46:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:46:05 --> Controller Class Initialized
INFO - 2016-02-16 09:46:05 --> Model Class Initialized
INFO - 2016-02-16 09:46:05 --> Model Class Initialized
INFO - 2016-02-16 09:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:46:05 --> Pagination Class Initialized
INFO - 2016-02-16 09:46:05 --> Helper loaded: text_helper
INFO - 2016-02-16 09:46:05 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:46:05 --> Final output sent to browser
DEBUG - 2016-02-16 12:46:05 --> Total execution time: 1.1703
INFO - 2016-02-16 09:46:08 --> Config Class Initialized
INFO - 2016-02-16 09:46:08 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:46:08 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:46:08 --> Utf8 Class Initialized
INFO - 2016-02-16 09:46:08 --> URI Class Initialized
INFO - 2016-02-16 09:46:08 --> Router Class Initialized
INFO - 2016-02-16 09:46:08 --> Output Class Initialized
INFO - 2016-02-16 09:46:08 --> Security Class Initialized
DEBUG - 2016-02-16 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:46:08 --> Input Class Initialized
INFO - 2016-02-16 09:46:08 --> Language Class Initialized
INFO - 2016-02-16 09:46:08 --> Loader Class Initialized
INFO - 2016-02-16 09:46:08 --> Helper loaded: url_helper
INFO - 2016-02-16 09:46:08 --> Helper loaded: file_helper
INFO - 2016-02-16 09:46:08 --> Helper loaded: date_helper
INFO - 2016-02-16 09:46:08 --> Helper loaded: form_helper
INFO - 2016-02-16 09:46:08 --> Database Driver Class Initialized
INFO - 2016-02-16 09:46:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:46:09 --> Controller Class Initialized
INFO - 2016-02-16 09:46:09 --> Model Class Initialized
INFO - 2016-02-16 09:46:09 --> Model Class Initialized
INFO - 2016-02-16 09:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:46:09 --> Pagination Class Initialized
INFO - 2016-02-16 09:46:09 --> Helper loaded: text_helper
INFO - 2016-02-16 09:46:09 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:46:09 --> Final output sent to browser
DEBUG - 2016-02-16 12:46:09 --> Total execution time: 1.1223
INFO - 2016-02-16 09:54:52 --> Config Class Initialized
INFO - 2016-02-16 09:54:52 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:54:52 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:54:52 --> Utf8 Class Initialized
INFO - 2016-02-16 09:54:52 --> URI Class Initialized
DEBUG - 2016-02-16 09:54:52 --> No URI present. Default controller set.
INFO - 2016-02-16 09:54:52 --> Router Class Initialized
INFO - 2016-02-16 09:54:52 --> Output Class Initialized
INFO - 2016-02-16 09:54:52 --> Security Class Initialized
DEBUG - 2016-02-16 09:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:54:52 --> Input Class Initialized
INFO - 2016-02-16 09:54:52 --> Language Class Initialized
ERROR - 2016-02-16 09:54:52 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 450
INFO - 2016-02-16 09:55:02 --> Config Class Initialized
INFO - 2016-02-16 09:55:02 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:55:02 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:55:02 --> Utf8 Class Initialized
INFO - 2016-02-16 09:55:02 --> URI Class Initialized
DEBUG - 2016-02-16 09:55:02 --> No URI present. Default controller set.
INFO - 2016-02-16 09:55:02 --> Router Class Initialized
INFO - 2016-02-16 09:55:02 --> Output Class Initialized
INFO - 2016-02-16 09:55:02 --> Security Class Initialized
DEBUG - 2016-02-16 09:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:55:02 --> Input Class Initialized
INFO - 2016-02-16 09:55:02 --> Language Class Initialized
INFO - 2016-02-16 09:55:02 --> Loader Class Initialized
INFO - 2016-02-16 09:55:02 --> Helper loaded: url_helper
INFO - 2016-02-16 09:55:02 --> Helper loaded: file_helper
INFO - 2016-02-16 09:55:02 --> Helper loaded: date_helper
INFO - 2016-02-16 09:55:02 --> Helper loaded: form_helper
INFO - 2016-02-16 09:55:02 --> Database Driver Class Initialized
INFO - 2016-02-16 09:55:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:55:03 --> Controller Class Initialized
INFO - 2016-02-16 09:55:03 --> Model Class Initialized
ERROR - 2016-02-16 09:55:03 --> Severity: Parsing Error --> syntax error, unexpected '$user_id' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 197
INFO - 2016-02-16 09:55:17 --> Config Class Initialized
INFO - 2016-02-16 09:55:17 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:55:17 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:55:17 --> Utf8 Class Initialized
INFO - 2016-02-16 09:55:17 --> URI Class Initialized
DEBUG - 2016-02-16 09:55:17 --> No URI present. Default controller set.
INFO - 2016-02-16 09:55:17 --> Router Class Initialized
INFO - 2016-02-16 09:55:17 --> Output Class Initialized
INFO - 2016-02-16 09:55:17 --> Security Class Initialized
DEBUG - 2016-02-16 09:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:55:17 --> Input Class Initialized
INFO - 2016-02-16 09:55:17 --> Language Class Initialized
INFO - 2016-02-16 09:55:17 --> Loader Class Initialized
INFO - 2016-02-16 09:55:17 --> Helper loaded: url_helper
INFO - 2016-02-16 09:55:17 --> Helper loaded: file_helper
INFO - 2016-02-16 09:55:17 --> Helper loaded: date_helper
INFO - 2016-02-16 09:55:17 --> Helper loaded: form_helper
INFO - 2016-02-16 09:55:17 --> Database Driver Class Initialized
INFO - 2016-02-16 09:55:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:55:18 --> Controller Class Initialized
INFO - 2016-02-16 09:55:18 --> Model Class Initialized
ERROR - 2016-02-16 09:55:18 --> Severity: Parsing Error --> syntax error, unexpected '$board_id' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 198
INFO - 2016-02-16 09:55:24 --> Config Class Initialized
INFO - 2016-02-16 09:55:24 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:55:24 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:55:24 --> Utf8 Class Initialized
INFO - 2016-02-16 09:55:24 --> URI Class Initialized
DEBUG - 2016-02-16 09:55:24 --> No URI present. Default controller set.
INFO - 2016-02-16 09:55:24 --> Router Class Initialized
INFO - 2016-02-16 09:55:24 --> Output Class Initialized
INFO - 2016-02-16 09:55:24 --> Security Class Initialized
DEBUG - 2016-02-16 09:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:55:24 --> Input Class Initialized
INFO - 2016-02-16 09:55:24 --> Language Class Initialized
INFO - 2016-02-16 09:55:24 --> Loader Class Initialized
INFO - 2016-02-16 09:55:24 --> Helper loaded: url_helper
INFO - 2016-02-16 09:55:24 --> Helper loaded: file_helper
INFO - 2016-02-16 09:55:24 --> Helper loaded: date_helper
INFO - 2016-02-16 09:55:24 --> Helper loaded: form_helper
INFO - 2016-02-16 09:55:24 --> Database Driver Class Initialized
INFO - 2016-02-16 09:55:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:55:25 --> Controller Class Initialized
INFO - 2016-02-16 09:55:25 --> Model Class Initialized
INFO - 2016-02-16 09:55:25 --> Model Class Initialized
INFO - 2016-02-16 09:55:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:55:25 --> Pagination Class Initialized
INFO - 2016-02-16 09:55:25 --> Helper loaded: text_helper
INFO - 2016-02-16 09:55:25 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 12:55:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:55:25 --> Final output sent to browser
DEBUG - 2016-02-16 12:55:25 --> Total execution time: 1.1441
INFO - 2016-02-16 09:55:29 --> Config Class Initialized
INFO - 2016-02-16 09:55:29 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:55:29 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:55:29 --> Utf8 Class Initialized
INFO - 2016-02-16 09:55:29 --> URI Class Initialized
INFO - 2016-02-16 09:55:29 --> Router Class Initialized
INFO - 2016-02-16 09:55:29 --> Output Class Initialized
INFO - 2016-02-16 09:55:29 --> Security Class Initialized
DEBUG - 2016-02-16 09:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:55:29 --> Input Class Initialized
INFO - 2016-02-16 09:55:29 --> Language Class Initialized
INFO - 2016-02-16 09:55:29 --> Loader Class Initialized
INFO - 2016-02-16 09:55:29 --> Helper loaded: url_helper
INFO - 2016-02-16 09:55:29 --> Helper loaded: file_helper
INFO - 2016-02-16 09:55:29 --> Helper loaded: date_helper
INFO - 2016-02-16 09:55:29 --> Helper loaded: form_helper
INFO - 2016-02-16 09:55:29 --> Database Driver Class Initialized
INFO - 2016-02-16 09:55:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:55:30 --> Controller Class Initialized
INFO - 2016-02-16 09:55:30 --> Model Class Initialized
INFO - 2016-02-16 09:55:30 --> Model Class Initialized
INFO - 2016-02-16 09:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:55:30 --> Pagination Class Initialized
INFO - 2016-02-16 09:55:30 --> Helper loaded: text_helper
INFO - 2016-02-16 09:55:30 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:55:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:55:30 --> Final output sent to browser
DEBUG - 2016-02-16 12:55:30 --> Total execution time: 1.1698
INFO - 2016-02-16 09:55:32 --> Config Class Initialized
INFO - 2016-02-16 09:55:32 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:55:32 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:55:32 --> Utf8 Class Initialized
INFO - 2016-02-16 09:55:32 --> URI Class Initialized
INFO - 2016-02-16 09:55:32 --> Router Class Initialized
INFO - 2016-02-16 09:55:32 --> Output Class Initialized
INFO - 2016-02-16 09:55:32 --> Security Class Initialized
DEBUG - 2016-02-16 09:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:55:32 --> Input Class Initialized
INFO - 2016-02-16 09:55:32 --> Language Class Initialized
INFO - 2016-02-16 09:55:32 --> Loader Class Initialized
INFO - 2016-02-16 09:55:32 --> Helper loaded: url_helper
INFO - 2016-02-16 09:55:32 --> Helper loaded: file_helper
INFO - 2016-02-16 09:55:32 --> Helper loaded: date_helper
INFO - 2016-02-16 09:55:32 --> Helper loaded: form_helper
INFO - 2016-02-16 09:55:32 --> Database Driver Class Initialized
INFO - 2016-02-16 09:55:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:55:33 --> Controller Class Initialized
INFO - 2016-02-16 09:55:33 --> Model Class Initialized
INFO - 2016-02-16 09:55:33 --> Model Class Initialized
INFO - 2016-02-16 09:55:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:55:33 --> Pagination Class Initialized
INFO - 2016-02-16 09:55:33 --> Helper loaded: text_helper
INFO - 2016-02-16 09:55:33 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:55:33 --> Final output sent to browser
DEBUG - 2016-02-16 12:55:33 --> Total execution time: 1.1549
INFO - 2016-02-16 09:58:21 --> Config Class Initialized
INFO - 2016-02-16 09:58:21 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:58:21 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:58:21 --> Utf8 Class Initialized
INFO - 2016-02-16 09:58:21 --> URI Class Initialized
INFO - 2016-02-16 09:58:21 --> Router Class Initialized
INFO - 2016-02-16 09:58:21 --> Output Class Initialized
INFO - 2016-02-16 09:58:21 --> Security Class Initialized
DEBUG - 2016-02-16 09:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:58:22 --> Input Class Initialized
INFO - 2016-02-16 09:58:22 --> Language Class Initialized
INFO - 2016-02-16 09:58:22 --> Loader Class Initialized
INFO - 2016-02-16 09:58:22 --> Helper loaded: url_helper
INFO - 2016-02-16 09:58:22 --> Helper loaded: file_helper
INFO - 2016-02-16 09:58:22 --> Helper loaded: date_helper
INFO - 2016-02-16 09:58:22 --> Helper loaded: form_helper
INFO - 2016-02-16 09:58:22 --> Database Driver Class Initialized
INFO - 2016-02-16 09:58:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:58:23 --> Controller Class Initialized
INFO - 2016-02-16 09:58:23 --> Model Class Initialized
INFO - 2016-02-16 09:58:23 --> Model Class Initialized
INFO - 2016-02-16 09:58:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:58:23 --> Pagination Class Initialized
INFO - 2016-02-16 09:58:23 --> Helper loaded: text_helper
INFO - 2016-02-16 09:58:23 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:58:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:58:23 --> Final output sent to browser
DEBUG - 2016-02-16 12:58:23 --> Total execution time: 1.2195
INFO - 2016-02-16 09:58:25 --> Config Class Initialized
INFO - 2016-02-16 09:58:25 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:58:25 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:58:25 --> Utf8 Class Initialized
INFO - 2016-02-16 09:58:25 --> URI Class Initialized
INFO - 2016-02-16 09:58:25 --> Router Class Initialized
INFO - 2016-02-16 09:58:25 --> Output Class Initialized
INFO - 2016-02-16 09:58:25 --> Security Class Initialized
DEBUG - 2016-02-16 09:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:58:25 --> Input Class Initialized
INFO - 2016-02-16 09:58:25 --> Language Class Initialized
INFO - 2016-02-16 09:58:25 --> Loader Class Initialized
INFO - 2016-02-16 09:58:25 --> Helper loaded: url_helper
INFO - 2016-02-16 09:58:25 --> Helper loaded: file_helper
INFO - 2016-02-16 09:58:25 --> Helper loaded: date_helper
INFO - 2016-02-16 09:58:25 --> Helper loaded: form_helper
INFO - 2016-02-16 09:58:25 --> Database Driver Class Initialized
INFO - 2016-02-16 09:58:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:58:26 --> Controller Class Initialized
INFO - 2016-02-16 09:58:26 --> Model Class Initialized
INFO - 2016-02-16 09:58:26 --> Model Class Initialized
INFO - 2016-02-16 09:58:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:58:26 --> Pagination Class Initialized
INFO - 2016-02-16 09:58:26 --> Helper loaded: text_helper
INFO - 2016-02-16 09:58:26 --> Helper loaded: cookie_helper
ERROR - 2016-02-16 12:58:26 --> Severity: Notice --> Undefined variable: board_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 191
ERROR - 2016-02-16 12:58:26 --> Query error: Column 'board_id' cannot be null - Invalid query: INSERT INTO `vote` (`user_id`, `board_id`) VALUES ('9', NULL)
INFO - 2016-02-16 12:58:26 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-16 09:59:27 --> Config Class Initialized
INFO - 2016-02-16 09:59:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:59:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:59:27 --> Utf8 Class Initialized
INFO - 2016-02-16 09:59:27 --> URI Class Initialized
INFO - 2016-02-16 09:59:27 --> Router Class Initialized
INFO - 2016-02-16 09:59:27 --> Output Class Initialized
INFO - 2016-02-16 09:59:27 --> Security Class Initialized
DEBUG - 2016-02-16 09:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:59:27 --> Input Class Initialized
INFO - 2016-02-16 09:59:27 --> Language Class Initialized
INFO - 2016-02-16 09:59:27 --> Loader Class Initialized
INFO - 2016-02-16 09:59:27 --> Helper loaded: url_helper
INFO - 2016-02-16 09:59:27 --> Helper loaded: file_helper
INFO - 2016-02-16 09:59:27 --> Helper loaded: date_helper
INFO - 2016-02-16 09:59:27 --> Helper loaded: form_helper
INFO - 2016-02-16 09:59:27 --> Database Driver Class Initialized
INFO - 2016-02-16 09:59:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:59:29 --> Controller Class Initialized
INFO - 2016-02-16 09:59:29 --> Model Class Initialized
INFO - 2016-02-16 09:59:29 --> Model Class Initialized
INFO - 2016-02-16 09:59:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:59:29 --> Pagination Class Initialized
INFO - 2016-02-16 09:59:29 --> Helper loaded: text_helper
INFO - 2016-02-16 09:59:29 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 12:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 12:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 12:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 12:59:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 12:59:29 --> Final output sent to browser
DEBUG - 2016-02-16 12:59:29 --> Total execution time: 1.2050
INFO - 2016-02-16 09:59:31 --> Config Class Initialized
INFO - 2016-02-16 09:59:31 --> Hooks Class Initialized
DEBUG - 2016-02-16 09:59:31 --> UTF-8 Support Enabled
INFO - 2016-02-16 09:59:31 --> Utf8 Class Initialized
INFO - 2016-02-16 09:59:31 --> URI Class Initialized
INFO - 2016-02-16 09:59:31 --> Router Class Initialized
INFO - 2016-02-16 09:59:31 --> Output Class Initialized
INFO - 2016-02-16 09:59:31 --> Security Class Initialized
DEBUG - 2016-02-16 09:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 09:59:31 --> Input Class Initialized
INFO - 2016-02-16 09:59:31 --> Language Class Initialized
INFO - 2016-02-16 09:59:31 --> Loader Class Initialized
INFO - 2016-02-16 09:59:31 --> Helper loaded: url_helper
INFO - 2016-02-16 09:59:31 --> Helper loaded: file_helper
INFO - 2016-02-16 09:59:31 --> Helper loaded: date_helper
INFO - 2016-02-16 09:59:31 --> Helper loaded: form_helper
INFO - 2016-02-16 09:59:31 --> Database Driver Class Initialized
INFO - 2016-02-16 09:59:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 09:59:32 --> Controller Class Initialized
INFO - 2016-02-16 09:59:32 --> Model Class Initialized
INFO - 2016-02-16 09:59:32 --> Model Class Initialized
INFO - 2016-02-16 09:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 09:59:32 --> Pagination Class Initialized
INFO - 2016-02-16 09:59:32 --> Helper loaded: text_helper
INFO - 2016-02-16 09:59:32 --> Helper loaded: cookie_helper
ERROR - 2016-02-16 12:59:32 --> Severity: Notice --> Undefined variable: board_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 191
ERROR - 2016-02-16 12:59:32 --> Query error: Column 'board_id' cannot be null - Invalid query: INSERT INTO `vote` (`user_id`, `board_id`) VALUES ('9', NULL)
INFO - 2016-02-16 12:59:32 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-16 10:00:27 --> Config Class Initialized
INFO - 2016-02-16 10:00:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:00:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:00:27 --> Utf8 Class Initialized
INFO - 2016-02-16 10:00:27 --> URI Class Initialized
INFO - 2016-02-16 10:00:27 --> Router Class Initialized
INFO - 2016-02-16 10:00:27 --> Output Class Initialized
INFO - 2016-02-16 10:00:27 --> Security Class Initialized
DEBUG - 2016-02-16 10:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:00:27 --> Input Class Initialized
INFO - 2016-02-16 10:00:27 --> Language Class Initialized
INFO - 2016-02-16 10:00:27 --> Loader Class Initialized
INFO - 2016-02-16 10:00:27 --> Helper loaded: url_helper
INFO - 2016-02-16 10:00:27 --> Helper loaded: file_helper
INFO - 2016-02-16 10:00:27 --> Helper loaded: date_helper
INFO - 2016-02-16 10:00:27 --> Helper loaded: form_helper
INFO - 2016-02-16 10:00:27 --> Database Driver Class Initialized
INFO - 2016-02-16 10:00:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:00:28 --> Controller Class Initialized
INFO - 2016-02-16 10:00:28 --> Model Class Initialized
INFO - 2016-02-16 10:00:28 --> Model Class Initialized
INFO - 2016-02-16 10:00:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:00:28 --> Pagination Class Initialized
INFO - 2016-02-16 10:00:28 --> Helper loaded: text_helper
INFO - 2016-02-16 10:00:28 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:00:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:00:28 --> Final output sent to browser
DEBUG - 2016-02-16 13:00:28 --> Total execution time: 1.2033
INFO - 2016-02-16 10:00:29 --> Config Class Initialized
INFO - 2016-02-16 10:00:29 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:00:29 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:00:29 --> Utf8 Class Initialized
INFO - 2016-02-16 10:00:29 --> URI Class Initialized
INFO - 2016-02-16 10:00:29 --> Router Class Initialized
INFO - 2016-02-16 10:00:29 --> Output Class Initialized
INFO - 2016-02-16 10:00:29 --> Security Class Initialized
DEBUG - 2016-02-16 10:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:00:29 --> Input Class Initialized
INFO - 2016-02-16 10:00:29 --> Language Class Initialized
INFO - 2016-02-16 10:00:29 --> Loader Class Initialized
INFO - 2016-02-16 10:00:29 --> Helper loaded: url_helper
INFO - 2016-02-16 10:00:29 --> Helper loaded: file_helper
INFO - 2016-02-16 10:00:29 --> Helper loaded: date_helper
INFO - 2016-02-16 10:00:29 --> Helper loaded: form_helper
INFO - 2016-02-16 10:00:29 --> Database Driver Class Initialized
INFO - 2016-02-16 10:00:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:00:30 --> Controller Class Initialized
INFO - 2016-02-16 10:00:30 --> Model Class Initialized
INFO - 2016-02-16 10:00:30 --> Model Class Initialized
INFO - 2016-02-16 10:00:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:00:30 --> Pagination Class Initialized
INFO - 2016-02-16 10:00:30 --> Helper loaded: text_helper
INFO - 2016-02-16 10:00:30 --> Helper loaded: cookie_helper
ERROR - 2016-02-16 13:00:30 --> Severity: Notice --> Undefined variable: board_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 191
ERROR - 2016-02-16 13:00:30 --> Query error: Column 'board_id' cannot be null - Invalid query: INSERT INTO `vote` (`user_id`, `board_id`) VALUES ('9', NULL)
INFO - 2016-02-16 13:00:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-16 10:06:37 --> Config Class Initialized
INFO - 2016-02-16 10:06:37 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:06:37 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:06:37 --> Utf8 Class Initialized
INFO - 2016-02-16 10:06:37 --> URI Class Initialized
INFO - 2016-02-16 10:06:37 --> Router Class Initialized
INFO - 2016-02-16 10:06:37 --> Output Class Initialized
INFO - 2016-02-16 10:06:37 --> Security Class Initialized
DEBUG - 2016-02-16 10:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:06:37 --> Input Class Initialized
INFO - 2016-02-16 10:06:37 --> Language Class Initialized
INFO - 2016-02-16 10:06:37 --> Loader Class Initialized
INFO - 2016-02-16 10:06:37 --> Helper loaded: url_helper
INFO - 2016-02-16 10:06:37 --> Helper loaded: file_helper
INFO - 2016-02-16 10:06:37 --> Helper loaded: date_helper
INFO - 2016-02-16 10:06:37 --> Helper loaded: form_helper
INFO - 2016-02-16 10:06:37 --> Database Driver Class Initialized
INFO - 2016-02-16 10:06:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:06:38 --> Controller Class Initialized
INFO - 2016-02-16 10:06:38 --> Model Class Initialized
INFO - 2016-02-16 10:06:38 --> Model Class Initialized
INFO - 2016-02-16 10:06:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:06:38 --> Pagination Class Initialized
INFO - 2016-02-16 10:06:38 --> Helper loaded: text_helper
INFO - 2016-02-16 10:06:38 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:06:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:06:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:06:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:06:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:06:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:06:38 --> Final output sent to browser
DEBUG - 2016-02-16 13:06:38 --> Total execution time: 1.1962
INFO - 2016-02-16 10:06:40 --> Config Class Initialized
INFO - 2016-02-16 10:06:40 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:06:40 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:06:40 --> Utf8 Class Initialized
INFO - 2016-02-16 10:06:40 --> URI Class Initialized
INFO - 2016-02-16 10:06:40 --> Router Class Initialized
INFO - 2016-02-16 10:06:40 --> Output Class Initialized
INFO - 2016-02-16 10:06:40 --> Security Class Initialized
DEBUG - 2016-02-16 10:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:06:40 --> Input Class Initialized
INFO - 2016-02-16 10:06:40 --> Language Class Initialized
INFO - 2016-02-16 10:06:40 --> Loader Class Initialized
INFO - 2016-02-16 10:06:40 --> Helper loaded: url_helper
INFO - 2016-02-16 10:06:40 --> Helper loaded: file_helper
INFO - 2016-02-16 10:06:40 --> Helper loaded: date_helper
INFO - 2016-02-16 10:06:40 --> Helper loaded: form_helper
INFO - 2016-02-16 10:06:40 --> Database Driver Class Initialized
INFO - 2016-02-16 10:06:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:06:41 --> Controller Class Initialized
INFO - 2016-02-16 10:06:41 --> Model Class Initialized
INFO - 2016-02-16 10:06:41 --> Model Class Initialized
INFO - 2016-02-16 10:06:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:06:41 --> Pagination Class Initialized
INFO - 2016-02-16 10:06:41 --> Helper loaded: text_helper
INFO - 2016-02-16 10:06:41 --> Helper loaded: cookie_helper
ERROR - 2016-02-16 13:06:41 --> Severity: Warning --> Missing argument 2 for Jboard_model::is_vote(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 450 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 195
ERROR - 2016-02-16 13:06:41 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-16 13:06:41 --> Severity: Notice --> Undefined variable: board_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 198
ERROR - 2016-02-16 13:06:41 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `vote`
WHERE `user_id` = `Array`
AND `board_id` IS NULL
INFO - 2016-02-16 13:06:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-16 13:06:41 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455646001
WHERE `user_id` = `Array`
AND `board_id` IS NULL
AND `id` = 'dca3f75790b8730713f010b1462224d9b4f260a8'
INFO - 2016-02-16 10:09:37 --> Config Class Initialized
INFO - 2016-02-16 10:09:37 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:09:37 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:09:37 --> Utf8 Class Initialized
INFO - 2016-02-16 10:09:37 --> URI Class Initialized
INFO - 2016-02-16 10:09:37 --> Router Class Initialized
INFO - 2016-02-16 10:09:37 --> Output Class Initialized
INFO - 2016-02-16 10:09:37 --> Security Class Initialized
DEBUG - 2016-02-16 10:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:09:37 --> Input Class Initialized
INFO - 2016-02-16 10:09:37 --> Language Class Initialized
INFO - 2016-02-16 10:09:37 --> Loader Class Initialized
INFO - 2016-02-16 10:09:37 --> Helper loaded: url_helper
INFO - 2016-02-16 10:09:37 --> Helper loaded: file_helper
INFO - 2016-02-16 10:09:37 --> Helper loaded: date_helper
INFO - 2016-02-16 10:09:37 --> Helper loaded: form_helper
INFO - 2016-02-16 10:09:38 --> Database Driver Class Initialized
INFO - 2016-02-16 10:09:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:09:39 --> Controller Class Initialized
INFO - 2016-02-16 10:09:39 --> Model Class Initialized
INFO - 2016-02-16 10:09:39 --> Model Class Initialized
INFO - 2016-02-16 10:09:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:09:39 --> Pagination Class Initialized
INFO - 2016-02-16 10:09:39 --> Helper loaded: text_helper
INFO - 2016-02-16 10:09:39 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:09:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:09:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:09:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:09:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:09:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:09:39 --> Final output sent to browser
DEBUG - 2016-02-16 13:09:39 --> Total execution time: 1.1579
INFO - 2016-02-16 10:09:40 --> Config Class Initialized
INFO - 2016-02-16 10:09:40 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:09:40 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:09:40 --> Utf8 Class Initialized
INFO - 2016-02-16 10:09:40 --> URI Class Initialized
INFO - 2016-02-16 10:09:40 --> Router Class Initialized
INFO - 2016-02-16 10:09:40 --> Output Class Initialized
INFO - 2016-02-16 10:09:40 --> Security Class Initialized
DEBUG - 2016-02-16 10:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:09:40 --> Input Class Initialized
INFO - 2016-02-16 10:09:40 --> Language Class Initialized
INFO - 2016-02-16 10:09:40 --> Loader Class Initialized
INFO - 2016-02-16 10:09:40 --> Helper loaded: url_helper
INFO - 2016-02-16 10:09:40 --> Helper loaded: file_helper
INFO - 2016-02-16 10:09:40 --> Helper loaded: date_helper
INFO - 2016-02-16 10:09:40 --> Helper loaded: form_helper
INFO - 2016-02-16 10:09:40 --> Database Driver Class Initialized
INFO - 2016-02-16 10:09:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:09:41 --> Controller Class Initialized
INFO - 2016-02-16 10:09:41 --> Model Class Initialized
INFO - 2016-02-16 10:09:41 --> Model Class Initialized
INFO - 2016-02-16 10:09:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:09:41 --> Pagination Class Initialized
INFO - 2016-02-16 10:09:41 --> Helper loaded: text_helper
INFO - 2016-02-16 10:09:41 --> Helper loaded: cookie_helper
ERROR - 2016-02-16 13:09:41 --> Severity: Warning --> Illegal string offset 'user_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 191
ERROR - 2016-02-16 13:09:41 --> Severity: Warning --> Illegal string offset 'board_id' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 191
INFO - 2016-02-16 13:09:41 --> Final output sent to browser
DEBUG - 2016-02-16 13:09:41 --> Total execution time: 1.1924
INFO - 2016-02-16 10:09:54 --> Config Class Initialized
INFO - 2016-02-16 10:09:54 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:09:54 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:09:54 --> Utf8 Class Initialized
INFO - 2016-02-16 10:09:54 --> URI Class Initialized
INFO - 2016-02-16 10:09:54 --> Router Class Initialized
INFO - 2016-02-16 10:09:54 --> Output Class Initialized
INFO - 2016-02-16 10:09:54 --> Security Class Initialized
DEBUG - 2016-02-16 10:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:09:54 --> Input Class Initialized
INFO - 2016-02-16 10:09:54 --> Language Class Initialized
INFO - 2016-02-16 10:09:54 --> Loader Class Initialized
INFO - 2016-02-16 10:09:54 --> Helper loaded: url_helper
INFO - 2016-02-16 10:09:54 --> Helper loaded: file_helper
INFO - 2016-02-16 10:09:54 --> Helper loaded: date_helper
INFO - 2016-02-16 10:09:54 --> Helper loaded: form_helper
INFO - 2016-02-16 10:09:54 --> Database Driver Class Initialized
INFO - 2016-02-16 10:09:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:09:55 --> Controller Class Initialized
INFO - 2016-02-16 10:09:55 --> Model Class Initialized
INFO - 2016-02-16 10:09:55 --> Model Class Initialized
INFO - 2016-02-16 10:09:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:09:55 --> Pagination Class Initialized
INFO - 2016-02-16 10:09:55 --> Helper loaded: text_helper
INFO - 2016-02-16 10:09:55 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:09:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:09:55 --> Final output sent to browser
DEBUG - 2016-02-16 13:09:55 --> Total execution time: 1.2498
INFO - 2016-02-16 10:09:56 --> Config Class Initialized
INFO - 2016-02-16 10:09:56 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:09:56 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:09:56 --> Utf8 Class Initialized
INFO - 2016-02-16 10:09:56 --> URI Class Initialized
INFO - 2016-02-16 10:09:56 --> Router Class Initialized
INFO - 2016-02-16 10:09:56 --> Output Class Initialized
INFO - 2016-02-16 10:09:56 --> Security Class Initialized
DEBUG - 2016-02-16 10:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:09:56 --> Input Class Initialized
INFO - 2016-02-16 10:09:56 --> Language Class Initialized
INFO - 2016-02-16 10:09:56 --> Loader Class Initialized
INFO - 2016-02-16 10:09:56 --> Helper loaded: url_helper
INFO - 2016-02-16 10:09:56 --> Helper loaded: file_helper
INFO - 2016-02-16 10:09:57 --> Helper loaded: date_helper
INFO - 2016-02-16 10:09:57 --> Helper loaded: form_helper
INFO - 2016-02-16 10:09:57 --> Database Driver Class Initialized
INFO - 2016-02-16 10:09:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:09:58 --> Controller Class Initialized
INFO - 2016-02-16 10:09:58 --> Model Class Initialized
INFO - 2016-02-16 10:09:58 --> Model Class Initialized
INFO - 2016-02-16 10:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:09:58 --> Pagination Class Initialized
INFO - 2016-02-16 10:09:58 --> Helper loaded: text_helper
INFO - 2016-02-16 10:09:58 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:09:58 --> Final output sent to browser
DEBUG - 2016-02-16 13:09:58 --> Total execution time: 1.1337
INFO - 2016-02-16 10:10:05 --> Config Class Initialized
INFO - 2016-02-16 10:10:05 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:10:05 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:10:05 --> Utf8 Class Initialized
INFO - 2016-02-16 10:10:05 --> URI Class Initialized
INFO - 2016-02-16 10:10:05 --> Router Class Initialized
INFO - 2016-02-16 10:10:05 --> Output Class Initialized
INFO - 2016-02-16 10:10:05 --> Security Class Initialized
DEBUG - 2016-02-16 10:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:10:05 --> Input Class Initialized
INFO - 2016-02-16 10:10:05 --> Language Class Initialized
INFO - 2016-02-16 10:10:05 --> Loader Class Initialized
INFO - 2016-02-16 10:10:05 --> Helper loaded: url_helper
INFO - 2016-02-16 10:10:05 --> Helper loaded: file_helper
INFO - 2016-02-16 10:10:05 --> Helper loaded: date_helper
INFO - 2016-02-16 10:10:05 --> Helper loaded: form_helper
INFO - 2016-02-16 10:10:05 --> Database Driver Class Initialized
INFO - 2016-02-16 10:10:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:10:06 --> Controller Class Initialized
INFO - 2016-02-16 10:10:06 --> Model Class Initialized
INFO - 2016-02-16 10:10:06 --> Model Class Initialized
INFO - 2016-02-16 10:10:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:10:06 --> Pagination Class Initialized
INFO - 2016-02-16 10:10:06 --> Helper loaded: text_helper
INFO - 2016-02-16 10:10:06 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:10:06 --> Final output sent to browser
DEBUG - 2016-02-16 13:10:06 --> Total execution time: 1.1435
INFO - 2016-02-16 10:10:24 --> Config Class Initialized
INFO - 2016-02-16 10:10:24 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:10:24 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:10:24 --> Utf8 Class Initialized
INFO - 2016-02-16 10:10:24 --> URI Class Initialized
DEBUG - 2016-02-16 10:10:24 --> No URI present. Default controller set.
INFO - 2016-02-16 10:10:24 --> Router Class Initialized
INFO - 2016-02-16 10:10:24 --> Output Class Initialized
INFO - 2016-02-16 10:10:24 --> Security Class Initialized
DEBUG - 2016-02-16 10:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:10:24 --> Input Class Initialized
INFO - 2016-02-16 10:10:24 --> Language Class Initialized
INFO - 2016-02-16 10:10:24 --> Loader Class Initialized
INFO - 2016-02-16 10:10:24 --> Helper loaded: url_helper
INFO - 2016-02-16 10:10:24 --> Helper loaded: file_helper
INFO - 2016-02-16 10:10:24 --> Helper loaded: date_helper
INFO - 2016-02-16 10:10:24 --> Helper loaded: form_helper
INFO - 2016-02-16 10:10:24 --> Database Driver Class Initialized
INFO - 2016-02-16 10:10:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:10:25 --> Controller Class Initialized
INFO - 2016-02-16 10:10:25 --> Model Class Initialized
INFO - 2016-02-16 10:10:25 --> Model Class Initialized
INFO - 2016-02-16 10:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:10:25 --> Pagination Class Initialized
INFO - 2016-02-16 10:10:25 --> Helper loaded: text_helper
INFO - 2016-02-16 10:10:25 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:10:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:10:25 --> Final output sent to browser
DEBUG - 2016-02-16 13:10:25 --> Total execution time: 1.1417
INFO - 2016-02-16 10:10:27 --> Config Class Initialized
INFO - 2016-02-16 10:10:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:10:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:10:27 --> Utf8 Class Initialized
INFO - 2016-02-16 10:10:27 --> URI Class Initialized
INFO - 2016-02-16 10:10:27 --> Router Class Initialized
INFO - 2016-02-16 10:10:27 --> Output Class Initialized
INFO - 2016-02-16 10:10:27 --> Security Class Initialized
DEBUG - 2016-02-16 10:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:10:27 --> Input Class Initialized
INFO - 2016-02-16 10:10:27 --> Language Class Initialized
INFO - 2016-02-16 10:10:27 --> Loader Class Initialized
INFO - 2016-02-16 10:10:27 --> Helper loaded: url_helper
INFO - 2016-02-16 10:10:27 --> Helper loaded: file_helper
INFO - 2016-02-16 10:10:27 --> Helper loaded: date_helper
INFO - 2016-02-16 10:10:27 --> Helper loaded: form_helper
INFO - 2016-02-16 10:10:27 --> Database Driver Class Initialized
INFO - 2016-02-16 10:10:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:10:28 --> Controller Class Initialized
INFO - 2016-02-16 10:10:28 --> Model Class Initialized
INFO - 2016-02-16 10:10:28 --> Model Class Initialized
INFO - 2016-02-16 10:10:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:10:28 --> Pagination Class Initialized
INFO - 2016-02-16 10:10:28 --> Helper loaded: text_helper
INFO - 2016-02-16 10:10:28 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:10:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:10:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:10:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:10:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:10:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:10:28 --> Final output sent to browser
DEBUG - 2016-02-16 13:10:28 --> Total execution time: 1.1640
INFO - 2016-02-16 10:10:30 --> Config Class Initialized
INFO - 2016-02-16 10:10:30 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:10:30 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:10:30 --> Utf8 Class Initialized
INFO - 2016-02-16 10:10:30 --> URI Class Initialized
INFO - 2016-02-16 10:10:30 --> Router Class Initialized
INFO - 2016-02-16 10:10:30 --> Output Class Initialized
INFO - 2016-02-16 10:10:30 --> Security Class Initialized
DEBUG - 2016-02-16 10:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:10:30 --> Input Class Initialized
INFO - 2016-02-16 10:10:30 --> Language Class Initialized
INFO - 2016-02-16 10:10:30 --> Loader Class Initialized
INFO - 2016-02-16 10:10:30 --> Helper loaded: url_helper
INFO - 2016-02-16 10:10:30 --> Helper loaded: file_helper
INFO - 2016-02-16 10:10:30 --> Helper loaded: date_helper
INFO - 2016-02-16 10:10:30 --> Helper loaded: form_helper
INFO - 2016-02-16 10:10:30 --> Database Driver Class Initialized
INFO - 2016-02-16 10:10:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:10:31 --> Controller Class Initialized
INFO - 2016-02-16 10:10:31 --> Model Class Initialized
INFO - 2016-02-16 10:10:31 --> Model Class Initialized
INFO - 2016-02-16 10:10:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:10:31 --> Pagination Class Initialized
INFO - 2016-02-16 10:10:31 --> Helper loaded: text_helper
INFO - 2016-02-16 10:10:31 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:10:31 --> Final output sent to browser
DEBUG - 2016-02-16 13:10:31 --> Total execution time: 1.1187
INFO - 2016-02-16 10:15:21 --> Config Class Initialized
INFO - 2016-02-16 10:15:21 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:15:21 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:15:21 --> Utf8 Class Initialized
INFO - 2016-02-16 10:15:21 --> URI Class Initialized
INFO - 2016-02-16 10:15:21 --> Router Class Initialized
INFO - 2016-02-16 10:15:21 --> Output Class Initialized
INFO - 2016-02-16 10:15:21 --> Security Class Initialized
DEBUG - 2016-02-16 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:15:21 --> Input Class Initialized
INFO - 2016-02-16 10:15:21 --> Language Class Initialized
INFO - 2016-02-16 10:15:21 --> Loader Class Initialized
INFO - 2016-02-16 10:15:21 --> Helper loaded: url_helper
INFO - 2016-02-16 10:15:21 --> Helper loaded: file_helper
INFO - 2016-02-16 10:15:21 --> Helper loaded: date_helper
INFO - 2016-02-16 10:15:21 --> Helper loaded: form_helper
INFO - 2016-02-16 10:15:21 --> Database Driver Class Initialized
INFO - 2016-02-16 10:15:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:15:22 --> Controller Class Initialized
INFO - 2016-02-16 10:15:22 --> Model Class Initialized
INFO - 2016-02-16 10:15:22 --> Model Class Initialized
INFO - 2016-02-16 10:15:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:15:22 --> Pagination Class Initialized
INFO - 2016-02-16 10:15:22 --> Helper loaded: text_helper
INFO - 2016-02-16 10:15:22 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:15:22 --> Final output sent to browser
DEBUG - 2016-02-16 13:15:22 --> Total execution time: 1.1359
INFO - 2016-02-16 10:20:23 --> Config Class Initialized
INFO - 2016-02-16 10:20:23 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:20:23 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:20:23 --> Utf8 Class Initialized
INFO - 2016-02-16 10:20:23 --> URI Class Initialized
DEBUG - 2016-02-16 10:20:23 --> No URI present. Default controller set.
INFO - 2016-02-16 10:20:23 --> Router Class Initialized
INFO - 2016-02-16 10:20:23 --> Output Class Initialized
INFO - 2016-02-16 10:20:23 --> Security Class Initialized
DEBUG - 2016-02-16 10:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:20:23 --> Input Class Initialized
INFO - 2016-02-16 10:20:23 --> Language Class Initialized
INFO - 2016-02-16 10:20:23 --> Loader Class Initialized
INFO - 2016-02-16 10:20:23 --> Helper loaded: url_helper
INFO - 2016-02-16 10:20:23 --> Helper loaded: file_helper
INFO - 2016-02-16 10:20:23 --> Helper loaded: date_helper
INFO - 2016-02-16 10:20:23 --> Helper loaded: form_helper
INFO - 2016-02-16 10:20:23 --> Database Driver Class Initialized
INFO - 2016-02-16 10:20:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:20:24 --> Controller Class Initialized
INFO - 2016-02-16 10:20:24 --> Model Class Initialized
INFO - 2016-02-16 10:20:24 --> Model Class Initialized
INFO - 2016-02-16 10:20:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:20:24 --> Pagination Class Initialized
INFO - 2016-02-16 10:20:24 --> Helper loaded: text_helper
INFO - 2016-02-16 10:20:24 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:20:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:20:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:20:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:20:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:20:24 --> Final output sent to browser
DEBUG - 2016-02-16 13:20:24 --> Total execution time: 1.1083
INFO - 2016-02-16 10:20:28 --> Config Class Initialized
INFO - 2016-02-16 10:20:28 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:20:28 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:20:28 --> Utf8 Class Initialized
INFO - 2016-02-16 10:20:28 --> URI Class Initialized
INFO - 2016-02-16 10:20:28 --> Router Class Initialized
INFO - 2016-02-16 10:20:28 --> Output Class Initialized
INFO - 2016-02-16 10:20:28 --> Security Class Initialized
DEBUG - 2016-02-16 10:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:20:28 --> Input Class Initialized
INFO - 2016-02-16 10:20:28 --> Language Class Initialized
INFO - 2016-02-16 10:20:28 --> Loader Class Initialized
INFO - 2016-02-16 10:20:28 --> Helper loaded: url_helper
INFO - 2016-02-16 10:20:28 --> Helper loaded: file_helper
INFO - 2016-02-16 10:20:28 --> Helper loaded: date_helper
INFO - 2016-02-16 10:20:28 --> Helper loaded: form_helper
INFO - 2016-02-16 10:20:28 --> Database Driver Class Initialized
INFO - 2016-02-16 10:20:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:20:29 --> Controller Class Initialized
INFO - 2016-02-16 10:20:29 --> Model Class Initialized
INFO - 2016-02-16 10:20:29 --> Model Class Initialized
INFO - 2016-02-16 10:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:20:29 --> Pagination Class Initialized
INFO - 2016-02-16 10:20:29 --> Helper loaded: text_helper
INFO - 2016-02-16 10:20:29 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:20:29 --> Final output sent to browser
DEBUG - 2016-02-16 13:20:29 --> Total execution time: 1.1799
INFO - 2016-02-16 10:20:32 --> Config Class Initialized
INFO - 2016-02-16 10:20:32 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:20:32 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:20:32 --> Utf8 Class Initialized
INFO - 2016-02-16 10:20:32 --> URI Class Initialized
INFO - 2016-02-16 10:20:32 --> Router Class Initialized
INFO - 2016-02-16 10:20:32 --> Output Class Initialized
INFO - 2016-02-16 10:20:32 --> Security Class Initialized
DEBUG - 2016-02-16 10:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:20:32 --> Input Class Initialized
INFO - 2016-02-16 10:20:32 --> Language Class Initialized
INFO - 2016-02-16 10:20:32 --> Loader Class Initialized
INFO - 2016-02-16 10:20:32 --> Helper loaded: url_helper
INFO - 2016-02-16 10:20:32 --> Helper loaded: file_helper
INFO - 2016-02-16 10:20:32 --> Helper loaded: date_helper
INFO - 2016-02-16 10:20:32 --> Helper loaded: form_helper
INFO - 2016-02-16 10:20:32 --> Database Driver Class Initialized
INFO - 2016-02-16 10:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:20:33 --> Controller Class Initialized
INFO - 2016-02-16 10:20:33 --> Model Class Initialized
INFO - 2016-02-16 10:20:33 --> Model Class Initialized
INFO - 2016-02-16 10:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:20:33 --> Pagination Class Initialized
INFO - 2016-02-16 10:20:33 --> Helper loaded: text_helper
INFO - 2016-02-16 10:20:33 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:20:33 --> Final output sent to browser
DEBUG - 2016-02-16 13:20:33 --> Total execution time: 1.1491
INFO - 2016-02-16 10:20:41 --> Config Class Initialized
INFO - 2016-02-16 10:20:41 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:20:41 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:20:41 --> Utf8 Class Initialized
INFO - 2016-02-16 10:20:41 --> URI Class Initialized
INFO - 2016-02-16 10:20:41 --> Router Class Initialized
INFO - 2016-02-16 10:20:41 --> Output Class Initialized
INFO - 2016-02-16 10:20:41 --> Security Class Initialized
DEBUG - 2016-02-16 10:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:20:41 --> Input Class Initialized
INFO - 2016-02-16 10:20:41 --> Language Class Initialized
INFO - 2016-02-16 10:20:41 --> Loader Class Initialized
INFO - 2016-02-16 10:20:41 --> Helper loaded: url_helper
INFO - 2016-02-16 10:20:41 --> Helper loaded: file_helper
INFO - 2016-02-16 10:20:41 --> Helper loaded: date_helper
INFO - 2016-02-16 10:20:41 --> Helper loaded: form_helper
INFO - 2016-02-16 10:20:41 --> Database Driver Class Initialized
INFO - 2016-02-16 10:20:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:20:42 --> Controller Class Initialized
INFO - 2016-02-16 10:20:42 --> Model Class Initialized
INFO - 2016-02-16 10:20:42 --> Model Class Initialized
INFO - 2016-02-16 10:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:20:42 --> Pagination Class Initialized
INFO - 2016-02-16 10:20:42 --> Helper loaded: text_helper
INFO - 2016-02-16 10:20:42 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:20:42 --> Final output sent to browser
DEBUG - 2016-02-16 13:20:42 --> Total execution time: 1.1895
INFO - 2016-02-16 10:21:46 --> Config Class Initialized
INFO - 2016-02-16 10:21:46 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:21:46 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:21:46 --> Utf8 Class Initialized
INFO - 2016-02-16 10:21:46 --> URI Class Initialized
INFO - 2016-02-16 10:21:46 --> Router Class Initialized
INFO - 2016-02-16 10:21:46 --> Output Class Initialized
INFO - 2016-02-16 10:21:46 --> Security Class Initialized
DEBUG - 2016-02-16 10:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:21:46 --> Input Class Initialized
INFO - 2016-02-16 10:21:46 --> Language Class Initialized
INFO - 2016-02-16 10:21:46 --> Loader Class Initialized
INFO - 2016-02-16 10:21:46 --> Helper loaded: url_helper
INFO - 2016-02-16 10:21:46 --> Helper loaded: file_helper
INFO - 2016-02-16 10:21:46 --> Helper loaded: date_helper
INFO - 2016-02-16 10:21:46 --> Helper loaded: form_helper
INFO - 2016-02-16 10:21:46 --> Database Driver Class Initialized
INFO - 2016-02-16 10:21:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:21:47 --> Controller Class Initialized
INFO - 2016-02-16 10:21:47 --> Model Class Initialized
INFO - 2016-02-16 10:21:47 --> Model Class Initialized
INFO - 2016-02-16 10:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:21:47 --> Pagination Class Initialized
INFO - 2016-02-16 10:21:47 --> Helper loaded: text_helper
INFO - 2016-02-16 10:21:47 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:21:47 --> Final output sent to browser
DEBUG - 2016-02-16 13:21:47 --> Total execution time: 1.2147
INFO - 2016-02-16 10:22:04 --> Config Class Initialized
INFO - 2016-02-16 10:22:04 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:22:04 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:22:04 --> Utf8 Class Initialized
INFO - 2016-02-16 10:22:04 --> URI Class Initialized
INFO - 2016-02-16 10:22:04 --> Router Class Initialized
INFO - 2016-02-16 10:22:04 --> Output Class Initialized
INFO - 2016-02-16 10:22:04 --> Security Class Initialized
DEBUG - 2016-02-16 10:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:22:04 --> Input Class Initialized
INFO - 2016-02-16 10:22:04 --> Language Class Initialized
INFO - 2016-02-16 10:22:04 --> Loader Class Initialized
INFO - 2016-02-16 10:22:04 --> Helper loaded: url_helper
INFO - 2016-02-16 10:22:04 --> Helper loaded: file_helper
INFO - 2016-02-16 10:22:04 --> Helper loaded: date_helper
INFO - 2016-02-16 10:22:04 --> Helper loaded: form_helper
INFO - 2016-02-16 10:22:04 --> Database Driver Class Initialized
INFO - 2016-02-16 10:22:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:22:05 --> Controller Class Initialized
INFO - 2016-02-16 10:22:05 --> Model Class Initialized
INFO - 2016-02-16 10:22:05 --> Model Class Initialized
INFO - 2016-02-16 10:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:22:05 --> Pagination Class Initialized
INFO - 2016-02-16 10:22:05 --> Helper loaded: text_helper
INFO - 2016-02-16 10:22:05 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:22:05 --> Final output sent to browser
DEBUG - 2016-02-16 13:22:05 --> Total execution time: 1.1824
INFO - 2016-02-16 10:22:07 --> Config Class Initialized
INFO - 2016-02-16 10:22:07 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:22:07 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:22:07 --> Utf8 Class Initialized
INFO - 2016-02-16 10:22:07 --> URI Class Initialized
INFO - 2016-02-16 10:22:07 --> Router Class Initialized
INFO - 2016-02-16 10:22:07 --> Output Class Initialized
INFO - 2016-02-16 10:22:07 --> Security Class Initialized
DEBUG - 2016-02-16 10:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:22:07 --> Input Class Initialized
INFO - 2016-02-16 10:22:07 --> Language Class Initialized
INFO - 2016-02-16 10:22:07 --> Loader Class Initialized
INFO - 2016-02-16 10:22:07 --> Helper loaded: url_helper
INFO - 2016-02-16 10:22:07 --> Helper loaded: file_helper
INFO - 2016-02-16 10:22:07 --> Helper loaded: date_helper
INFO - 2016-02-16 10:22:07 --> Helper loaded: form_helper
INFO - 2016-02-16 10:22:07 --> Database Driver Class Initialized
INFO - 2016-02-16 10:22:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:22:08 --> Controller Class Initialized
INFO - 2016-02-16 10:22:08 --> Model Class Initialized
INFO - 2016-02-16 10:22:08 --> Model Class Initialized
INFO - 2016-02-16 10:22:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:22:08 --> Pagination Class Initialized
INFO - 2016-02-16 10:22:08 --> Helper loaded: text_helper
INFO - 2016-02-16 10:22:08 --> Helper loaded: cookie_helper
INFO - 2016-02-16 10:25:15 --> Config Class Initialized
INFO - 2016-02-16 10:25:15 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:25:15 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:25:15 --> Utf8 Class Initialized
INFO - 2016-02-16 10:25:15 --> URI Class Initialized
DEBUG - 2016-02-16 10:25:15 --> No URI present. Default controller set.
INFO - 2016-02-16 10:25:15 --> Router Class Initialized
INFO - 2016-02-16 10:25:15 --> Output Class Initialized
INFO - 2016-02-16 10:25:15 --> Security Class Initialized
DEBUG - 2016-02-16 10:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:25:15 --> Input Class Initialized
INFO - 2016-02-16 10:25:15 --> Language Class Initialized
INFO - 2016-02-16 10:25:15 --> Loader Class Initialized
INFO - 2016-02-16 10:25:15 --> Helper loaded: url_helper
INFO - 2016-02-16 10:25:15 --> Helper loaded: file_helper
INFO - 2016-02-16 10:25:15 --> Helper loaded: date_helper
INFO - 2016-02-16 10:25:15 --> Helper loaded: form_helper
INFO - 2016-02-16 10:25:15 --> Database Driver Class Initialized
INFO - 2016-02-16 10:25:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:25:16 --> Controller Class Initialized
INFO - 2016-02-16 10:25:16 --> Model Class Initialized
INFO - 2016-02-16 10:25:16 --> Model Class Initialized
INFO - 2016-02-16 10:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:25:16 --> Pagination Class Initialized
INFO - 2016-02-16 10:25:16 --> Helper loaded: text_helper
INFO - 2016-02-16 10:25:16 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:25:16 --> Final output sent to browser
DEBUG - 2016-02-16 13:25:16 --> Total execution time: 1.0871
INFO - 2016-02-16 10:25:19 --> Config Class Initialized
INFO - 2016-02-16 10:25:19 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:25:19 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:25:19 --> Utf8 Class Initialized
INFO - 2016-02-16 10:25:19 --> URI Class Initialized
INFO - 2016-02-16 10:25:19 --> Router Class Initialized
INFO - 2016-02-16 10:25:19 --> Output Class Initialized
INFO - 2016-02-16 10:25:19 --> Security Class Initialized
DEBUG - 2016-02-16 10:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:25:19 --> Input Class Initialized
INFO - 2016-02-16 10:25:19 --> Language Class Initialized
INFO - 2016-02-16 10:25:19 --> Loader Class Initialized
INFO - 2016-02-16 10:25:19 --> Helper loaded: url_helper
INFO - 2016-02-16 10:25:19 --> Helper loaded: file_helper
INFO - 2016-02-16 10:25:19 --> Helper loaded: date_helper
INFO - 2016-02-16 10:25:19 --> Helper loaded: form_helper
INFO - 2016-02-16 10:25:19 --> Database Driver Class Initialized
INFO - 2016-02-16 10:25:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:25:20 --> Controller Class Initialized
INFO - 2016-02-16 10:25:20 --> Model Class Initialized
INFO - 2016-02-16 10:25:20 --> Model Class Initialized
INFO - 2016-02-16 10:25:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:25:20 --> Pagination Class Initialized
INFO - 2016-02-16 10:25:20 --> Helper loaded: text_helper
INFO - 2016-02-16 10:25:20 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:25:20 --> Final output sent to browser
DEBUG - 2016-02-16 13:25:20 --> Total execution time: 1.1697
INFO - 2016-02-16 10:25:23 --> Config Class Initialized
INFO - 2016-02-16 10:25:23 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:25:23 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:25:23 --> Utf8 Class Initialized
INFO - 2016-02-16 10:25:23 --> URI Class Initialized
INFO - 2016-02-16 10:25:23 --> Router Class Initialized
INFO - 2016-02-16 10:25:23 --> Output Class Initialized
INFO - 2016-02-16 10:25:23 --> Security Class Initialized
DEBUG - 2016-02-16 10:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:25:23 --> Input Class Initialized
INFO - 2016-02-16 10:25:23 --> Language Class Initialized
INFO - 2016-02-16 10:25:23 --> Loader Class Initialized
INFO - 2016-02-16 10:25:23 --> Helper loaded: url_helper
INFO - 2016-02-16 10:25:23 --> Helper loaded: file_helper
INFO - 2016-02-16 10:25:23 --> Helper loaded: date_helper
INFO - 2016-02-16 10:25:23 --> Helper loaded: form_helper
INFO - 2016-02-16 10:25:23 --> Database Driver Class Initialized
INFO - 2016-02-16 10:25:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:25:24 --> Controller Class Initialized
INFO - 2016-02-16 10:25:24 --> Model Class Initialized
INFO - 2016-02-16 10:25:24 --> Model Class Initialized
INFO - 2016-02-16 10:25:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:25:24 --> Pagination Class Initialized
INFO - 2016-02-16 10:25:24 --> Helper loaded: text_helper
INFO - 2016-02-16 10:25:24 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:25:24 --> Final output sent to browser
DEBUG - 2016-02-16 13:25:24 --> Total execution time: 1.1634
INFO - 2016-02-16 10:25:26 --> Config Class Initialized
INFO - 2016-02-16 10:25:26 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:25:26 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:25:26 --> Utf8 Class Initialized
INFO - 2016-02-16 10:25:26 --> URI Class Initialized
INFO - 2016-02-16 10:25:26 --> Router Class Initialized
INFO - 2016-02-16 10:25:26 --> Output Class Initialized
INFO - 2016-02-16 10:25:26 --> Security Class Initialized
DEBUG - 2016-02-16 10:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:25:26 --> Input Class Initialized
INFO - 2016-02-16 10:25:26 --> Language Class Initialized
INFO - 2016-02-16 10:25:26 --> Loader Class Initialized
INFO - 2016-02-16 10:25:26 --> Helper loaded: url_helper
INFO - 2016-02-16 10:25:26 --> Helper loaded: file_helper
INFO - 2016-02-16 10:25:26 --> Helper loaded: date_helper
INFO - 2016-02-16 10:25:26 --> Helper loaded: form_helper
INFO - 2016-02-16 10:25:26 --> Database Driver Class Initialized
INFO - 2016-02-16 10:25:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:25:27 --> Controller Class Initialized
INFO - 2016-02-16 10:25:27 --> Model Class Initialized
INFO - 2016-02-16 10:25:27 --> Model Class Initialized
INFO - 2016-02-16 10:25:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:25:27 --> Pagination Class Initialized
INFO - 2016-02-16 10:25:27 --> Helper loaded: text_helper
INFO - 2016-02-16 10:25:27 --> Helper loaded: cookie_helper
INFO - 2016-02-16 10:25:29 --> Config Class Initialized
INFO - 2016-02-16 10:25:29 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:25:29 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:25:29 --> Utf8 Class Initialized
INFO - 2016-02-16 10:25:29 --> URI Class Initialized
DEBUG - 2016-02-16 10:25:29 --> No URI present. Default controller set.
INFO - 2016-02-16 10:25:29 --> Router Class Initialized
INFO - 2016-02-16 10:25:29 --> Output Class Initialized
INFO - 2016-02-16 10:25:29 --> Security Class Initialized
DEBUG - 2016-02-16 10:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:25:29 --> Input Class Initialized
INFO - 2016-02-16 10:25:29 --> Language Class Initialized
INFO - 2016-02-16 10:25:29 --> Loader Class Initialized
INFO - 2016-02-16 10:25:29 --> Helper loaded: url_helper
INFO - 2016-02-16 10:25:29 --> Helper loaded: file_helper
INFO - 2016-02-16 10:25:29 --> Helper loaded: date_helper
INFO - 2016-02-16 10:25:29 --> Helper loaded: form_helper
INFO - 2016-02-16 10:25:29 --> Database Driver Class Initialized
INFO - 2016-02-16 10:25:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:25:30 --> Controller Class Initialized
INFO - 2016-02-16 10:25:30 --> Model Class Initialized
INFO - 2016-02-16 10:25:30 --> Model Class Initialized
INFO - 2016-02-16 10:25:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:25:30 --> Pagination Class Initialized
INFO - 2016-02-16 10:25:30 --> Helper loaded: text_helper
INFO - 2016-02-16 10:25:30 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:25:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:25:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:25:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:25:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:25:30 --> Final output sent to browser
DEBUG - 2016-02-16 13:25:30 --> Total execution time: 1.1082
INFO - 2016-02-16 10:41:11 --> Config Class Initialized
INFO - 2016-02-16 10:41:11 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:41:11 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:41:11 --> Utf8 Class Initialized
INFO - 2016-02-16 10:41:11 --> URI Class Initialized
DEBUG - 2016-02-16 10:41:11 --> No URI present. Default controller set.
INFO - 2016-02-16 10:41:11 --> Router Class Initialized
INFO - 2016-02-16 10:41:11 --> Output Class Initialized
INFO - 2016-02-16 10:41:11 --> Security Class Initialized
DEBUG - 2016-02-16 10:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:41:11 --> Input Class Initialized
INFO - 2016-02-16 10:41:11 --> Language Class Initialized
INFO - 2016-02-16 10:41:11 --> Loader Class Initialized
INFO - 2016-02-16 10:41:11 --> Helper loaded: url_helper
INFO - 2016-02-16 10:41:11 --> Helper loaded: file_helper
INFO - 2016-02-16 10:41:11 --> Helper loaded: date_helper
INFO - 2016-02-16 10:41:11 --> Helper loaded: form_helper
INFO - 2016-02-16 10:41:11 --> Database Driver Class Initialized
INFO - 2016-02-16 10:41:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:41:12 --> Controller Class Initialized
INFO - 2016-02-16 10:41:12 --> Model Class Initialized
INFO - 2016-02-16 10:41:12 --> Model Class Initialized
INFO - 2016-02-16 10:41:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:41:12 --> Pagination Class Initialized
INFO - 2016-02-16 10:41:12 --> Helper loaded: text_helper
INFO - 2016-02-16 10:41:12 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:41:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:41:12 --> Final output sent to browser
DEBUG - 2016-02-16 13:41:12 --> Total execution time: 1.1341
INFO - 2016-02-16 10:41:14 --> Config Class Initialized
INFO - 2016-02-16 10:41:14 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:41:14 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:41:14 --> Utf8 Class Initialized
INFO - 2016-02-16 10:41:14 --> URI Class Initialized
INFO - 2016-02-16 10:41:14 --> Router Class Initialized
INFO - 2016-02-16 10:41:14 --> Output Class Initialized
INFO - 2016-02-16 10:41:14 --> Security Class Initialized
DEBUG - 2016-02-16 10:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:41:14 --> Input Class Initialized
INFO - 2016-02-16 10:41:14 --> Language Class Initialized
INFO - 2016-02-16 10:41:14 --> Loader Class Initialized
INFO - 2016-02-16 10:41:14 --> Helper loaded: url_helper
INFO - 2016-02-16 10:41:14 --> Helper loaded: file_helper
INFO - 2016-02-16 10:41:14 --> Helper loaded: date_helper
INFO - 2016-02-16 10:41:14 --> Helper loaded: form_helper
INFO - 2016-02-16 10:41:14 --> Database Driver Class Initialized
INFO - 2016-02-16 10:41:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:41:15 --> Controller Class Initialized
INFO - 2016-02-16 10:41:15 --> Model Class Initialized
INFO - 2016-02-16 10:41:15 --> Model Class Initialized
INFO - 2016-02-16 10:41:15 --> Form Validation Class Initialized
INFO - 2016-02-16 10:41:15 --> Helper loaded: text_helper
INFO - 2016-02-16 10:41:15 --> Config Class Initialized
INFO - 2016-02-16 10:41:15 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:41:15 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:41:15 --> Utf8 Class Initialized
INFO - 2016-02-16 10:41:15 --> URI Class Initialized
INFO - 2016-02-16 10:41:15 --> Router Class Initialized
INFO - 2016-02-16 10:41:15 --> Output Class Initialized
INFO - 2016-02-16 10:41:15 --> Security Class Initialized
DEBUG - 2016-02-16 10:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:41:15 --> Input Class Initialized
INFO - 2016-02-16 10:41:15 --> Language Class Initialized
INFO - 2016-02-16 10:41:15 --> Loader Class Initialized
INFO - 2016-02-16 10:41:15 --> Helper loaded: url_helper
INFO - 2016-02-16 10:41:15 --> Helper loaded: file_helper
INFO - 2016-02-16 10:41:15 --> Helper loaded: date_helper
INFO - 2016-02-16 10:41:15 --> Helper loaded: form_helper
INFO - 2016-02-16 10:41:15 --> Database Driver Class Initialized
INFO - 2016-02-16 10:41:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:41:16 --> Controller Class Initialized
INFO - 2016-02-16 10:41:16 --> Model Class Initialized
INFO - 2016-02-16 10:41:16 --> Model Class Initialized
INFO - 2016-02-16 10:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:41:16 --> Pagination Class Initialized
INFO - 2016-02-16 10:41:16 --> Helper loaded: text_helper
INFO - 2016-02-16 10:41:16 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:41:16 --> Final output sent to browser
DEBUG - 2016-02-16 13:41:16 --> Total execution time: 1.0967
INFO - 2016-02-16 10:41:18 --> Config Class Initialized
INFO - 2016-02-16 10:41:18 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:41:18 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:41:18 --> Utf8 Class Initialized
INFO - 2016-02-16 10:41:18 --> URI Class Initialized
INFO - 2016-02-16 10:41:18 --> Router Class Initialized
INFO - 2016-02-16 10:41:18 --> Output Class Initialized
INFO - 2016-02-16 10:41:18 --> Security Class Initialized
DEBUG - 2016-02-16 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:41:18 --> Input Class Initialized
INFO - 2016-02-16 10:41:18 --> Language Class Initialized
INFO - 2016-02-16 10:41:18 --> Loader Class Initialized
INFO - 2016-02-16 10:41:18 --> Helper loaded: url_helper
INFO - 2016-02-16 10:41:18 --> Helper loaded: file_helper
INFO - 2016-02-16 10:41:18 --> Helper loaded: date_helper
INFO - 2016-02-16 10:41:18 --> Helper loaded: form_helper
INFO - 2016-02-16 10:41:18 --> Database Driver Class Initialized
INFO - 2016-02-16 10:41:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:41:19 --> Controller Class Initialized
INFO - 2016-02-16 10:41:19 --> Model Class Initialized
INFO - 2016-02-16 10:41:19 --> Model Class Initialized
INFO - 2016-02-16 10:41:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:41:19 --> Pagination Class Initialized
INFO - 2016-02-16 10:41:20 --> Helper loaded: text_helper
INFO - 2016-02-16 10:41:20 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:41:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:41:20 --> Final output sent to browser
DEBUG - 2016-02-16 13:41:20 --> Total execution time: 1.1539
INFO - 2016-02-16 10:41:22 --> Config Class Initialized
INFO - 2016-02-16 10:41:22 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:41:22 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:41:22 --> Utf8 Class Initialized
INFO - 2016-02-16 10:41:22 --> URI Class Initialized
INFO - 2016-02-16 10:41:22 --> Router Class Initialized
INFO - 2016-02-16 10:41:22 --> Output Class Initialized
INFO - 2016-02-16 10:41:22 --> Security Class Initialized
DEBUG - 2016-02-16 10:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:41:22 --> Input Class Initialized
INFO - 2016-02-16 10:41:22 --> Language Class Initialized
INFO - 2016-02-16 10:41:22 --> Loader Class Initialized
INFO - 2016-02-16 10:41:22 --> Helper loaded: url_helper
INFO - 2016-02-16 10:41:22 --> Helper loaded: file_helper
INFO - 2016-02-16 10:41:22 --> Helper loaded: date_helper
INFO - 2016-02-16 10:41:22 --> Helper loaded: form_helper
INFO - 2016-02-16 10:41:22 --> Database Driver Class Initialized
INFO - 2016-02-16 10:41:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:41:23 --> Controller Class Initialized
INFO - 2016-02-16 10:41:23 --> Model Class Initialized
INFO - 2016-02-16 10:41:23 --> Model Class Initialized
INFO - 2016-02-16 10:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:41:23 --> Pagination Class Initialized
INFO - 2016-02-16 10:41:23 --> Helper loaded: text_helper
INFO - 2016-02-16 10:41:23 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:41:23 --> Final output sent to browser
DEBUG - 2016-02-16 13:41:23 --> Total execution time: 1.0716
INFO - 2016-02-16 10:41:33 --> Config Class Initialized
INFO - 2016-02-16 10:41:33 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:41:33 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:41:33 --> Utf8 Class Initialized
INFO - 2016-02-16 10:41:33 --> URI Class Initialized
INFO - 2016-02-16 10:41:33 --> Router Class Initialized
INFO - 2016-02-16 10:41:33 --> Output Class Initialized
INFO - 2016-02-16 10:41:33 --> Security Class Initialized
DEBUG - 2016-02-16 10:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:41:33 --> Input Class Initialized
INFO - 2016-02-16 10:41:33 --> Language Class Initialized
INFO - 2016-02-16 10:41:33 --> Loader Class Initialized
INFO - 2016-02-16 10:41:33 --> Helper loaded: url_helper
INFO - 2016-02-16 10:41:33 --> Helper loaded: file_helper
INFO - 2016-02-16 10:41:33 --> Helper loaded: date_helper
INFO - 2016-02-16 10:41:33 --> Helper loaded: form_helper
INFO - 2016-02-16 10:41:33 --> Database Driver Class Initialized
INFO - 2016-02-16 10:41:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:41:34 --> Controller Class Initialized
INFO - 2016-02-16 10:41:34 --> Model Class Initialized
INFO - 2016-02-16 10:41:34 --> Model Class Initialized
INFO - 2016-02-16 10:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:41:34 --> Pagination Class Initialized
INFO - 2016-02-16 10:41:34 --> Helper loaded: text_helper
INFO - 2016-02-16 10:41:34 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:41:34 --> Final output sent to browser
DEBUG - 2016-02-16 13:41:34 --> Total execution time: 1.0975
INFO - 2016-02-16 10:43:00 --> Config Class Initialized
INFO - 2016-02-16 10:43:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:00 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:00 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:00 --> URI Class Initialized
DEBUG - 2016-02-16 10:43:00 --> No URI present. Default controller set.
INFO - 2016-02-16 10:43:00 --> Router Class Initialized
INFO - 2016-02-16 10:43:00 --> Output Class Initialized
INFO - 2016-02-16 10:43:00 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:00 --> Input Class Initialized
INFO - 2016-02-16 10:43:00 --> Language Class Initialized
INFO - 2016-02-16 10:43:00 --> Loader Class Initialized
INFO - 2016-02-16 10:43:00 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:00 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:00 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:00 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:00 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:01 --> Controller Class Initialized
INFO - 2016-02-16 10:43:01 --> Model Class Initialized
INFO - 2016-02-16 10:43:01 --> Model Class Initialized
INFO - 2016-02-16 10:43:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:01 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:01 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:01 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:43:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:43:01 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:01 --> Total execution time: 1.1026
INFO - 2016-02-16 10:43:02 --> Config Class Initialized
INFO - 2016-02-16 10:43:02 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:02 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:02 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:02 --> URI Class Initialized
INFO - 2016-02-16 10:43:02 --> Router Class Initialized
INFO - 2016-02-16 10:43:02 --> Output Class Initialized
INFO - 2016-02-16 10:43:02 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:02 --> Input Class Initialized
INFO - 2016-02-16 10:43:02 --> Language Class Initialized
INFO - 2016-02-16 10:43:02 --> Loader Class Initialized
INFO - 2016-02-16 10:43:02 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:02 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:02 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:02 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:02 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:03 --> Controller Class Initialized
INFO - 2016-02-16 10:43:03 --> Model Class Initialized
INFO - 2016-02-16 10:43:03 --> Model Class Initialized
INFO - 2016-02-16 10:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:03 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:03 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:03 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:43:03 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:04 --> Total execution time: 1.1309
INFO - 2016-02-16 10:43:05 --> Config Class Initialized
INFO - 2016-02-16 10:43:05 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:05 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:05 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:05 --> URI Class Initialized
INFO - 2016-02-16 10:43:05 --> Router Class Initialized
INFO - 2016-02-16 10:43:05 --> Output Class Initialized
INFO - 2016-02-16 10:43:05 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:05 --> Input Class Initialized
INFO - 2016-02-16 10:43:05 --> Language Class Initialized
INFO - 2016-02-16 10:43:05 --> Loader Class Initialized
INFO - 2016-02-16 10:43:05 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:05 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:05 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:05 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:05 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:06 --> Controller Class Initialized
INFO - 2016-02-16 10:43:06 --> Model Class Initialized
INFO - 2016-02-16 10:43:06 --> Model Class Initialized
INFO - 2016-02-16 10:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:06 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:06 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:06 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:06 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:06 --> Total execution time: 1.1122
INFO - 2016-02-16 10:43:23 --> Config Class Initialized
INFO - 2016-02-16 10:43:23 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:24 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:24 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:24 --> URI Class Initialized
INFO - 2016-02-16 10:43:24 --> Router Class Initialized
INFO - 2016-02-16 10:43:24 --> Output Class Initialized
INFO - 2016-02-16 10:43:24 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:24 --> Input Class Initialized
INFO - 2016-02-16 10:43:24 --> Language Class Initialized
INFO - 2016-02-16 10:43:24 --> Loader Class Initialized
INFO - 2016-02-16 10:43:24 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:24 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:24 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:24 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:24 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:25 --> Controller Class Initialized
INFO - 2016-02-16 10:43:25 --> Model Class Initialized
INFO - 2016-02-16 10:43:25 --> Model Class Initialized
INFO - 2016-02-16 10:43:25 --> Form Validation Class Initialized
INFO - 2016-02-16 10:43:25 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:25 --> Config Class Initialized
INFO - 2016-02-16 10:43:25 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:25 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:25 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:25 --> URI Class Initialized
INFO - 2016-02-16 10:43:25 --> Router Class Initialized
INFO - 2016-02-16 10:43:25 --> Output Class Initialized
INFO - 2016-02-16 10:43:25 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:25 --> Input Class Initialized
INFO - 2016-02-16 10:43:25 --> Language Class Initialized
INFO - 2016-02-16 10:43:25 --> Loader Class Initialized
INFO - 2016-02-16 10:43:25 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:25 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:25 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:25 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:25 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:26 --> Controller Class Initialized
INFO - 2016-02-16 10:43:26 --> Model Class Initialized
INFO - 2016-02-16 10:43:26 --> Model Class Initialized
INFO - 2016-02-16 10:43:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:26 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:26 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:26 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:43:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:43:26 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:26 --> Total execution time: 1.1660
INFO - 2016-02-16 10:43:28 --> Config Class Initialized
INFO - 2016-02-16 10:43:28 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:28 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:28 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:28 --> URI Class Initialized
INFO - 2016-02-16 10:43:28 --> Router Class Initialized
INFO - 2016-02-16 10:43:28 --> Output Class Initialized
INFO - 2016-02-16 10:43:28 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:28 --> Input Class Initialized
INFO - 2016-02-16 10:43:28 --> Language Class Initialized
INFO - 2016-02-16 10:43:28 --> Loader Class Initialized
INFO - 2016-02-16 10:43:28 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:28 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:28 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:28 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:28 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:29 --> Controller Class Initialized
INFO - 2016-02-16 10:43:29 --> Model Class Initialized
INFO - 2016-02-16 10:43:29 --> Model Class Initialized
INFO - 2016-02-16 10:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:29 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:29 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:29 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:29 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:29 --> Total execution time: 1.2137
INFO - 2016-02-16 10:43:31 --> Config Class Initialized
INFO - 2016-02-16 10:43:31 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:31 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:31 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:31 --> URI Class Initialized
INFO - 2016-02-16 10:43:31 --> Router Class Initialized
INFO - 2016-02-16 10:43:31 --> Output Class Initialized
INFO - 2016-02-16 10:43:31 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:31 --> Input Class Initialized
INFO - 2016-02-16 10:43:31 --> Language Class Initialized
INFO - 2016-02-16 10:43:31 --> Loader Class Initialized
INFO - 2016-02-16 10:43:31 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:31 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:31 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:31 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:31 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:32 --> Controller Class Initialized
INFO - 2016-02-16 10:43:32 --> Model Class Initialized
INFO - 2016-02-16 10:43:32 --> Model Class Initialized
INFO - 2016-02-16 10:43:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:32 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:32 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:32 --> Helper loaded: cookie_helper
INFO - 2016-02-16 10:43:36 --> Config Class Initialized
INFO - 2016-02-16 10:43:36 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:36 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:36 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:36 --> URI Class Initialized
DEBUG - 2016-02-16 10:43:36 --> No URI present. Default controller set.
INFO - 2016-02-16 10:43:36 --> Router Class Initialized
INFO - 2016-02-16 10:43:36 --> Output Class Initialized
INFO - 2016-02-16 10:43:36 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:36 --> Input Class Initialized
INFO - 2016-02-16 10:43:36 --> Language Class Initialized
INFO - 2016-02-16 10:43:36 --> Loader Class Initialized
INFO - 2016-02-16 10:43:36 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:36 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:36 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:36 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:36 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:37 --> Controller Class Initialized
INFO - 2016-02-16 10:43:37 --> Model Class Initialized
INFO - 2016-02-16 10:43:37 --> Model Class Initialized
INFO - 2016-02-16 10:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:37 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:37 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:37 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:43:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:43:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:43:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:43:37 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:37 --> Total execution time: 1.1172
INFO - 2016-02-16 10:43:39 --> Config Class Initialized
INFO - 2016-02-16 10:43:39 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:39 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:39 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:39 --> URI Class Initialized
INFO - 2016-02-16 10:43:39 --> Router Class Initialized
INFO - 2016-02-16 10:43:39 --> Output Class Initialized
INFO - 2016-02-16 10:43:39 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:39 --> Input Class Initialized
INFO - 2016-02-16 10:43:39 --> Language Class Initialized
INFO - 2016-02-16 10:43:39 --> Loader Class Initialized
INFO - 2016-02-16 10:43:39 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:39 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:39 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:39 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:39 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:40 --> Controller Class Initialized
INFO - 2016-02-16 10:43:40 --> Model Class Initialized
INFO - 2016-02-16 10:43:40 --> Model Class Initialized
INFO - 2016-02-16 10:43:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:40 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:40 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:40 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:43:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:43:40 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:40 --> Total execution time: 1.1780
INFO - 2016-02-16 10:43:43 --> Config Class Initialized
INFO - 2016-02-16 10:43:43 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:43 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:43 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:43 --> URI Class Initialized
INFO - 2016-02-16 10:43:43 --> Router Class Initialized
INFO - 2016-02-16 10:43:43 --> Output Class Initialized
INFO - 2016-02-16 10:43:43 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:43 --> Input Class Initialized
INFO - 2016-02-16 10:43:43 --> Language Class Initialized
INFO - 2016-02-16 10:43:43 --> Loader Class Initialized
INFO - 2016-02-16 10:43:43 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:43 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:43 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:43 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:43 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:44 --> Controller Class Initialized
INFO - 2016-02-16 10:43:44 --> Model Class Initialized
INFO - 2016-02-16 10:43:44 --> Model Class Initialized
INFO - 2016-02-16 10:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:44 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:44 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:44 --> Helper loaded: cookie_helper
INFO - 2016-02-16 10:43:45 --> Config Class Initialized
INFO - 2016-02-16 10:43:45 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:45 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:45 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:45 --> URI Class Initialized
INFO - 2016-02-16 10:43:45 --> Router Class Initialized
INFO - 2016-02-16 10:43:45 --> Output Class Initialized
INFO - 2016-02-16 10:43:45 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:45 --> Input Class Initialized
INFO - 2016-02-16 10:43:45 --> Language Class Initialized
INFO - 2016-02-16 10:43:45 --> Loader Class Initialized
INFO - 2016-02-16 10:43:45 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:45 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:46 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:46 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:46 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:47 --> Controller Class Initialized
INFO - 2016-02-16 10:43:47 --> Model Class Initialized
INFO - 2016-02-16 10:43:47 --> Model Class Initialized
INFO - 2016-02-16 10:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:47 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:47 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:47 --> Helper loaded: cookie_helper
INFO - 2016-02-16 10:43:50 --> Config Class Initialized
INFO - 2016-02-16 10:43:50 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:50 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:50 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:50 --> URI Class Initialized
DEBUG - 2016-02-16 10:43:50 --> No URI present. Default controller set.
INFO - 2016-02-16 10:43:50 --> Router Class Initialized
INFO - 2016-02-16 10:43:50 --> Output Class Initialized
INFO - 2016-02-16 10:43:50 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:50 --> Input Class Initialized
INFO - 2016-02-16 10:43:50 --> Language Class Initialized
INFO - 2016-02-16 10:43:50 --> Loader Class Initialized
INFO - 2016-02-16 10:43:50 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:50 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:50 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:50 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:50 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:51 --> Controller Class Initialized
INFO - 2016-02-16 10:43:51 --> Model Class Initialized
INFO - 2016-02-16 10:43:51 --> Model Class Initialized
INFO - 2016-02-16 10:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:51 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:51 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:51 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:43:51 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:51 --> Total execution time: 1.0876
INFO - 2016-02-16 10:43:54 --> Config Class Initialized
INFO - 2016-02-16 10:43:54 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:54 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:54 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:54 --> URI Class Initialized
INFO - 2016-02-16 10:43:54 --> Router Class Initialized
INFO - 2016-02-16 10:43:54 --> Output Class Initialized
INFO - 2016-02-16 10:43:54 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:54 --> Input Class Initialized
INFO - 2016-02-16 10:43:54 --> Language Class Initialized
INFO - 2016-02-16 10:43:54 --> Loader Class Initialized
INFO - 2016-02-16 10:43:54 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:54 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:54 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:54 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:54 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:55 --> Controller Class Initialized
INFO - 2016-02-16 10:43:55 --> Model Class Initialized
INFO - 2016-02-16 10:43:55 --> Model Class Initialized
INFO - 2016-02-16 10:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:55 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:55 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:55 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:43:55 --> Final output sent to browser
DEBUG - 2016-02-16 13:43:55 --> Total execution time: 1.2815
INFO - 2016-02-16 10:43:58 --> Config Class Initialized
INFO - 2016-02-16 10:43:58 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:43:58 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:43:58 --> Utf8 Class Initialized
INFO - 2016-02-16 10:43:58 --> URI Class Initialized
INFO - 2016-02-16 10:43:58 --> Router Class Initialized
INFO - 2016-02-16 10:43:58 --> Output Class Initialized
INFO - 2016-02-16 10:43:58 --> Security Class Initialized
DEBUG - 2016-02-16 10:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:43:58 --> Input Class Initialized
INFO - 2016-02-16 10:43:58 --> Language Class Initialized
INFO - 2016-02-16 10:43:58 --> Loader Class Initialized
INFO - 2016-02-16 10:43:58 --> Helper loaded: url_helper
INFO - 2016-02-16 10:43:58 --> Helper loaded: file_helper
INFO - 2016-02-16 10:43:58 --> Helper loaded: date_helper
INFO - 2016-02-16 10:43:58 --> Helper loaded: form_helper
INFO - 2016-02-16 10:43:58 --> Database Driver Class Initialized
INFO - 2016-02-16 10:43:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:43:59 --> Controller Class Initialized
INFO - 2016-02-16 10:43:59 --> Model Class Initialized
INFO - 2016-02-16 10:43:59 --> Model Class Initialized
INFO - 2016-02-16 10:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:43:59 --> Pagination Class Initialized
INFO - 2016-02-16 10:43:59 --> Helper loaded: text_helper
INFO - 2016-02-16 10:43:59 --> Helper loaded: cookie_helper
INFO - 2016-02-16 10:44:00 --> Config Class Initialized
INFO - 2016-02-16 10:44:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:44:00 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:44:00 --> Utf8 Class Initialized
INFO - 2016-02-16 10:44:00 --> URI Class Initialized
INFO - 2016-02-16 10:44:00 --> Router Class Initialized
INFO - 2016-02-16 10:44:00 --> Output Class Initialized
INFO - 2016-02-16 10:44:00 --> Security Class Initialized
DEBUG - 2016-02-16 10:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:44:00 --> Input Class Initialized
INFO - 2016-02-16 10:44:00 --> Language Class Initialized
INFO - 2016-02-16 10:44:00 --> Loader Class Initialized
INFO - 2016-02-16 10:44:00 --> Helper loaded: url_helper
INFO - 2016-02-16 10:44:00 --> Helper loaded: file_helper
INFO - 2016-02-16 10:44:00 --> Helper loaded: date_helper
INFO - 2016-02-16 10:44:00 --> Helper loaded: form_helper
INFO - 2016-02-16 10:44:00 --> Database Driver Class Initialized
INFO - 2016-02-16 10:44:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:44:01 --> Controller Class Initialized
INFO - 2016-02-16 10:44:01 --> Model Class Initialized
INFO - 2016-02-16 10:44:01 --> Model Class Initialized
INFO - 2016-02-16 10:44:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:44:01 --> Pagination Class Initialized
INFO - 2016-02-16 10:44:01 --> Helper loaded: text_helper
INFO - 2016-02-16 10:44:01 --> Helper loaded: cookie_helper
INFO - 2016-02-16 10:44:07 --> Config Class Initialized
INFO - 2016-02-16 10:44:07 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:44:07 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:44:07 --> Utf8 Class Initialized
INFO - 2016-02-16 10:44:07 --> URI Class Initialized
DEBUG - 2016-02-16 10:44:07 --> No URI present. Default controller set.
INFO - 2016-02-16 10:44:07 --> Router Class Initialized
INFO - 2016-02-16 10:44:07 --> Output Class Initialized
INFO - 2016-02-16 10:44:07 --> Security Class Initialized
DEBUG - 2016-02-16 10:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:44:07 --> Input Class Initialized
INFO - 2016-02-16 10:44:07 --> Language Class Initialized
INFO - 2016-02-16 10:44:07 --> Loader Class Initialized
INFO - 2016-02-16 10:44:07 --> Helper loaded: url_helper
INFO - 2016-02-16 10:44:07 --> Helper loaded: file_helper
INFO - 2016-02-16 10:44:07 --> Helper loaded: date_helper
INFO - 2016-02-16 10:44:07 --> Helper loaded: form_helper
INFO - 2016-02-16 10:44:07 --> Database Driver Class Initialized
INFO - 2016-02-16 10:44:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:44:08 --> Controller Class Initialized
INFO - 2016-02-16 10:44:08 --> Model Class Initialized
INFO - 2016-02-16 10:44:08 --> Model Class Initialized
INFO - 2016-02-16 10:44:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:44:08 --> Pagination Class Initialized
INFO - 2016-02-16 10:44:08 --> Helper loaded: text_helper
INFO - 2016-02-16 10:44:08 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:44:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:44:08 --> Final output sent to browser
DEBUG - 2016-02-16 13:44:08 --> Total execution time: 1.1620
INFO - 2016-02-16 10:44:27 --> Config Class Initialized
INFO - 2016-02-16 10:44:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:44:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:44:27 --> Utf8 Class Initialized
INFO - 2016-02-16 10:44:27 --> URI Class Initialized
DEBUG - 2016-02-16 10:44:27 --> No URI present. Default controller set.
INFO - 2016-02-16 10:44:27 --> Router Class Initialized
INFO - 2016-02-16 10:44:27 --> Output Class Initialized
INFO - 2016-02-16 10:44:27 --> Security Class Initialized
DEBUG - 2016-02-16 10:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:44:27 --> Input Class Initialized
INFO - 2016-02-16 10:44:27 --> Language Class Initialized
INFO - 2016-02-16 10:44:27 --> Loader Class Initialized
INFO - 2016-02-16 10:44:27 --> Helper loaded: url_helper
INFO - 2016-02-16 10:44:27 --> Helper loaded: file_helper
INFO - 2016-02-16 10:44:27 --> Helper loaded: date_helper
INFO - 2016-02-16 10:44:27 --> Helper loaded: form_helper
INFO - 2016-02-16 10:44:27 --> Database Driver Class Initialized
INFO - 2016-02-16 10:44:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:44:28 --> Controller Class Initialized
INFO - 2016-02-16 10:44:28 --> Model Class Initialized
INFO - 2016-02-16 10:44:28 --> Model Class Initialized
INFO - 2016-02-16 10:44:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:44:28 --> Pagination Class Initialized
INFO - 2016-02-16 10:44:28 --> Helper loaded: text_helper
INFO - 2016-02-16 10:44:28 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:44:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:44:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:44:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:44:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:44:28 --> Final output sent to browser
DEBUG - 2016-02-16 13:44:28 --> Total execution time: 1.1580
INFO - 2016-02-16 10:44:44 --> Config Class Initialized
INFO - 2016-02-16 10:44:44 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:44:44 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:44:44 --> Utf8 Class Initialized
INFO - 2016-02-16 10:44:44 --> URI Class Initialized
INFO - 2016-02-16 10:44:44 --> Router Class Initialized
INFO - 2016-02-16 10:44:44 --> Output Class Initialized
INFO - 2016-02-16 10:44:44 --> Security Class Initialized
DEBUG - 2016-02-16 10:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:44:44 --> Input Class Initialized
INFO - 2016-02-16 10:44:44 --> Language Class Initialized
INFO - 2016-02-16 10:44:45 --> Loader Class Initialized
INFO - 2016-02-16 10:44:45 --> Helper loaded: url_helper
INFO - 2016-02-16 10:44:45 --> Helper loaded: file_helper
INFO - 2016-02-16 10:44:45 --> Helper loaded: date_helper
INFO - 2016-02-16 10:44:45 --> Helper loaded: form_helper
INFO - 2016-02-16 10:44:45 --> Database Driver Class Initialized
INFO - 2016-02-16 10:44:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:44:46 --> Controller Class Initialized
INFO - 2016-02-16 10:44:46 --> Model Class Initialized
INFO - 2016-02-16 10:44:46 --> Model Class Initialized
INFO - 2016-02-16 10:44:46 --> Form Validation Class Initialized
INFO - 2016-02-16 10:44:46 --> Helper loaded: text_helper
INFO - 2016-02-16 10:44:46 --> Config Class Initialized
INFO - 2016-02-16 10:44:46 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:44:46 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:44:46 --> Utf8 Class Initialized
INFO - 2016-02-16 10:44:46 --> URI Class Initialized
INFO - 2016-02-16 10:44:46 --> Router Class Initialized
INFO - 2016-02-16 10:44:46 --> Output Class Initialized
INFO - 2016-02-16 10:44:46 --> Security Class Initialized
DEBUG - 2016-02-16 10:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:44:46 --> Input Class Initialized
INFO - 2016-02-16 10:44:46 --> Language Class Initialized
INFO - 2016-02-16 10:44:46 --> Loader Class Initialized
INFO - 2016-02-16 10:44:46 --> Helper loaded: url_helper
INFO - 2016-02-16 10:44:46 --> Helper loaded: file_helper
INFO - 2016-02-16 10:44:46 --> Helper loaded: date_helper
INFO - 2016-02-16 10:44:46 --> Helper loaded: form_helper
INFO - 2016-02-16 10:44:46 --> Database Driver Class Initialized
INFO - 2016-02-16 10:44:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:44:47 --> Controller Class Initialized
INFO - 2016-02-16 10:44:47 --> Model Class Initialized
INFO - 2016-02-16 10:44:47 --> Model Class Initialized
INFO - 2016-02-16 10:44:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:44:47 --> Pagination Class Initialized
INFO - 2016-02-16 10:44:47 --> Helper loaded: text_helper
INFO - 2016-02-16 10:44:47 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:44:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:44:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:44:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:44:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:44:47 --> Final output sent to browser
DEBUG - 2016-02-16 13:44:47 --> Total execution time: 1.0845
INFO - 2016-02-16 10:45:09 --> Config Class Initialized
INFO - 2016-02-16 10:45:09 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:45:09 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:45:09 --> Utf8 Class Initialized
INFO - 2016-02-16 10:45:09 --> URI Class Initialized
DEBUG - 2016-02-16 10:45:09 --> No URI present. Default controller set.
INFO - 2016-02-16 10:45:09 --> Router Class Initialized
INFO - 2016-02-16 10:45:09 --> Output Class Initialized
INFO - 2016-02-16 10:45:09 --> Security Class Initialized
DEBUG - 2016-02-16 10:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:45:09 --> Input Class Initialized
INFO - 2016-02-16 10:45:09 --> Language Class Initialized
INFO - 2016-02-16 10:45:09 --> Loader Class Initialized
INFO - 2016-02-16 10:45:09 --> Helper loaded: url_helper
INFO - 2016-02-16 10:45:09 --> Helper loaded: file_helper
INFO - 2016-02-16 10:45:09 --> Helper loaded: date_helper
INFO - 2016-02-16 10:45:09 --> Helper loaded: form_helper
INFO - 2016-02-16 10:45:09 --> Database Driver Class Initialized
INFO - 2016-02-16 10:45:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:45:10 --> Controller Class Initialized
INFO - 2016-02-16 10:45:10 --> Model Class Initialized
INFO - 2016-02-16 10:45:10 --> Model Class Initialized
INFO - 2016-02-16 10:45:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:45:10 --> Pagination Class Initialized
INFO - 2016-02-16 10:45:11 --> Helper loaded: text_helper
INFO - 2016-02-16 10:45:11 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:45:11 --> Final output sent to browser
DEBUG - 2016-02-16 13:45:11 --> Total execution time: 1.1004
INFO - 2016-02-16 10:47:11 --> Config Class Initialized
INFO - 2016-02-16 10:47:11 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:47:11 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:47:11 --> Utf8 Class Initialized
INFO - 2016-02-16 10:47:11 --> URI Class Initialized
DEBUG - 2016-02-16 10:47:11 --> No URI present. Default controller set.
INFO - 2016-02-16 10:47:11 --> Router Class Initialized
INFO - 2016-02-16 10:47:11 --> Output Class Initialized
INFO - 2016-02-16 10:47:11 --> Security Class Initialized
DEBUG - 2016-02-16 10:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:47:11 --> Input Class Initialized
INFO - 2016-02-16 10:47:11 --> Language Class Initialized
INFO - 2016-02-16 10:47:11 --> Loader Class Initialized
INFO - 2016-02-16 10:47:11 --> Helper loaded: url_helper
INFO - 2016-02-16 10:47:11 --> Helper loaded: file_helper
INFO - 2016-02-16 10:47:11 --> Helper loaded: date_helper
INFO - 2016-02-16 10:47:11 --> Helper loaded: form_helper
INFO - 2016-02-16 10:47:11 --> Database Driver Class Initialized
INFO - 2016-02-16 10:47:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:47:12 --> Controller Class Initialized
INFO - 2016-02-16 10:47:12 --> Model Class Initialized
INFO - 2016-02-16 10:47:12 --> Model Class Initialized
INFO - 2016-02-16 10:47:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:47:12 --> Pagination Class Initialized
INFO - 2016-02-16 10:47:12 --> Helper loaded: text_helper
INFO - 2016-02-16 10:47:12 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:47:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:47:12 --> Final output sent to browser
DEBUG - 2016-02-16 13:47:12 --> Total execution time: 1.1249
INFO - 2016-02-16 10:53:45 --> Config Class Initialized
INFO - 2016-02-16 10:53:45 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:53:45 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:53:45 --> Utf8 Class Initialized
INFO - 2016-02-16 10:53:45 --> URI Class Initialized
INFO - 2016-02-16 10:53:45 --> Router Class Initialized
INFO - 2016-02-16 10:53:45 --> Output Class Initialized
INFO - 2016-02-16 10:53:45 --> Security Class Initialized
DEBUG - 2016-02-16 10:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:53:45 --> Input Class Initialized
INFO - 2016-02-16 10:53:45 --> Language Class Initialized
INFO - 2016-02-16 10:53:45 --> Loader Class Initialized
INFO - 2016-02-16 10:53:45 --> Helper loaded: url_helper
INFO - 2016-02-16 10:53:45 --> Helper loaded: file_helper
INFO - 2016-02-16 10:53:45 --> Helper loaded: date_helper
INFO - 2016-02-16 10:53:45 --> Helper loaded: form_helper
INFO - 2016-02-16 10:53:45 --> Database Driver Class Initialized
INFO - 2016-02-16 10:53:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:53:46 --> Controller Class Initialized
INFO - 2016-02-16 10:53:46 --> Model Class Initialized
INFO - 2016-02-16 10:53:46 --> Model Class Initialized
INFO - 2016-02-16 10:53:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:53:46 --> Pagination Class Initialized
INFO - 2016-02-16 10:53:46 --> Helper loaded: text_helper
INFO - 2016-02-16 10:53:46 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 13:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 13:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:53:46 --> Final output sent to browser
DEBUG - 2016-02-16 13:53:46 --> Total execution time: 1.1844
INFO - 2016-02-16 10:54:02 --> Config Class Initialized
INFO - 2016-02-16 10:54:02 --> Hooks Class Initialized
DEBUG - 2016-02-16 10:54:02 --> UTF-8 Support Enabled
INFO - 2016-02-16 10:54:02 --> Utf8 Class Initialized
INFO - 2016-02-16 10:54:02 --> URI Class Initialized
DEBUG - 2016-02-16 10:54:02 --> No URI present. Default controller set.
INFO - 2016-02-16 10:54:02 --> Router Class Initialized
INFO - 2016-02-16 10:54:02 --> Output Class Initialized
INFO - 2016-02-16 10:54:02 --> Security Class Initialized
DEBUG - 2016-02-16 10:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 10:54:02 --> Input Class Initialized
INFO - 2016-02-16 10:54:02 --> Language Class Initialized
INFO - 2016-02-16 10:54:02 --> Loader Class Initialized
INFO - 2016-02-16 10:54:02 --> Helper loaded: url_helper
INFO - 2016-02-16 10:54:02 --> Helper loaded: file_helper
INFO - 2016-02-16 10:54:02 --> Helper loaded: date_helper
INFO - 2016-02-16 10:54:02 --> Helper loaded: form_helper
INFO - 2016-02-16 10:54:02 --> Database Driver Class Initialized
INFO - 2016-02-16 10:54:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 10:54:03 --> Controller Class Initialized
INFO - 2016-02-16 10:54:03 --> Model Class Initialized
INFO - 2016-02-16 10:54:03 --> Model Class Initialized
INFO - 2016-02-16 10:54:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 10:54:03 --> Pagination Class Initialized
INFO - 2016-02-16 10:54:03 --> Helper loaded: text_helper
INFO - 2016-02-16 10:54:03 --> Helper loaded: cookie_helper
INFO - 2016-02-16 13:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 13:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 13:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 13:54:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 13:54:03 --> Final output sent to browser
DEBUG - 2016-02-16 13:54:03 --> Total execution time: 1.1270
INFO - 2016-02-16 11:11:02 --> Config Class Initialized
INFO - 2016-02-16 11:11:02 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:11:02 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:11:02 --> Utf8 Class Initialized
INFO - 2016-02-16 11:11:02 --> URI Class Initialized
DEBUG - 2016-02-16 11:11:02 --> No URI present. Default controller set.
INFO - 2016-02-16 11:11:02 --> Router Class Initialized
INFO - 2016-02-16 11:11:02 --> Output Class Initialized
INFO - 2016-02-16 11:11:02 --> Security Class Initialized
DEBUG - 2016-02-16 11:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:11:02 --> Input Class Initialized
INFO - 2016-02-16 11:11:02 --> Language Class Initialized
INFO - 2016-02-16 11:11:02 --> Loader Class Initialized
INFO - 2016-02-16 11:11:02 --> Helper loaded: url_helper
INFO - 2016-02-16 11:11:02 --> Helper loaded: file_helper
INFO - 2016-02-16 11:11:02 --> Helper loaded: date_helper
INFO - 2016-02-16 11:11:02 --> Helper loaded: form_helper
INFO - 2016-02-16 11:11:02 --> Database Driver Class Initialized
INFO - 2016-02-16 11:11:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:11:03 --> Controller Class Initialized
INFO - 2016-02-16 11:11:03 --> Model Class Initialized
INFO - 2016-02-16 11:11:03 --> Model Class Initialized
INFO - 2016-02-16 11:11:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:11:03 --> Pagination Class Initialized
INFO - 2016-02-16 11:11:03 --> Helper loaded: text_helper
INFO - 2016-02-16 11:11:03 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:11:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:11:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:11:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 14:11:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 14:11:03 --> Final output sent to browser
DEBUG - 2016-02-16 14:11:03 --> Total execution time: 1.1038
INFO - 2016-02-16 11:11:56 --> Config Class Initialized
INFO - 2016-02-16 11:11:56 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:11:56 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:11:56 --> Utf8 Class Initialized
INFO - 2016-02-16 11:11:56 --> URI Class Initialized
INFO - 2016-02-16 11:11:56 --> Router Class Initialized
INFO - 2016-02-16 11:11:56 --> Output Class Initialized
INFO - 2016-02-16 11:11:56 --> Security Class Initialized
DEBUG - 2016-02-16 11:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:11:56 --> Input Class Initialized
INFO - 2016-02-16 11:11:56 --> Language Class Initialized
INFO - 2016-02-16 11:11:56 --> Loader Class Initialized
INFO - 2016-02-16 11:11:56 --> Helper loaded: url_helper
INFO - 2016-02-16 11:11:56 --> Helper loaded: file_helper
INFO - 2016-02-16 11:11:56 --> Helper loaded: date_helper
INFO - 2016-02-16 11:11:56 --> Helper loaded: form_helper
INFO - 2016-02-16 11:11:56 --> Database Driver Class Initialized
INFO - 2016-02-16 11:11:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:11:57 --> Controller Class Initialized
INFO - 2016-02-16 11:11:57 --> Model Class Initialized
INFO - 2016-02-16 11:11:57 --> Model Class Initialized
INFO - 2016-02-16 11:11:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:11:57 --> Pagination Class Initialized
INFO - 2016-02-16 11:11:57 --> Helper loaded: text_helper
INFO - 2016-02-16 11:11:57 --> Helper loaded: cookie_helper
INFO - 2016-02-16 11:11:58 --> Config Class Initialized
INFO - 2016-02-16 11:11:58 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:11:58 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:11:58 --> Utf8 Class Initialized
INFO - 2016-02-16 11:11:58 --> URI Class Initialized
INFO - 2016-02-16 11:11:58 --> Router Class Initialized
INFO - 2016-02-16 11:11:58 --> Output Class Initialized
INFO - 2016-02-16 11:11:58 --> Security Class Initialized
DEBUG - 2016-02-16 11:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:11:58 --> Input Class Initialized
INFO - 2016-02-16 11:11:58 --> Language Class Initialized
INFO - 2016-02-16 11:11:58 --> Loader Class Initialized
INFO - 2016-02-16 11:11:58 --> Helper loaded: url_helper
INFO - 2016-02-16 11:11:58 --> Helper loaded: file_helper
INFO - 2016-02-16 11:11:58 --> Helper loaded: date_helper
INFO - 2016-02-16 11:11:58 --> Helper loaded: form_helper
INFO - 2016-02-16 11:11:58 --> Database Driver Class Initialized
INFO - 2016-02-16 11:11:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:11:59 --> Controller Class Initialized
INFO - 2016-02-16 11:11:59 --> Model Class Initialized
INFO - 2016-02-16 11:11:59 --> Model Class Initialized
INFO - 2016-02-16 11:11:59 --> Form Validation Class Initialized
INFO - 2016-02-16 11:11:59 --> Helper loaded: text_helper
INFO - 2016-02-16 11:11:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 11:11:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 11:11:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-16 11:11:59 --> Final output sent to browser
DEBUG - 2016-02-16 11:11:59 --> Total execution time: 1.1119
INFO - 2016-02-16 11:12:06 --> Config Class Initialized
INFO - 2016-02-16 11:12:06 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:12:06 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:12:06 --> Utf8 Class Initialized
INFO - 2016-02-16 11:12:06 --> URI Class Initialized
DEBUG - 2016-02-16 11:12:06 --> No URI present. Default controller set.
INFO - 2016-02-16 11:12:06 --> Router Class Initialized
INFO - 2016-02-16 11:12:06 --> Output Class Initialized
INFO - 2016-02-16 11:12:06 --> Security Class Initialized
DEBUG - 2016-02-16 11:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:12:06 --> Input Class Initialized
INFO - 2016-02-16 11:12:06 --> Language Class Initialized
INFO - 2016-02-16 11:12:06 --> Loader Class Initialized
INFO - 2016-02-16 11:12:06 --> Helper loaded: url_helper
INFO - 2016-02-16 11:12:06 --> Helper loaded: file_helper
INFO - 2016-02-16 11:12:06 --> Helper loaded: date_helper
INFO - 2016-02-16 11:12:06 --> Helper loaded: form_helper
INFO - 2016-02-16 11:12:06 --> Database Driver Class Initialized
INFO - 2016-02-16 11:12:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:12:07 --> Controller Class Initialized
INFO - 2016-02-16 11:12:07 --> Model Class Initialized
INFO - 2016-02-16 11:12:07 --> Model Class Initialized
INFO - 2016-02-16 11:12:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:12:07 --> Pagination Class Initialized
INFO - 2016-02-16 11:12:07 --> Helper loaded: text_helper
INFO - 2016-02-16 11:12:07 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:12:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:12:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:12:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 14:12:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 14:12:07 --> Final output sent to browser
DEBUG - 2016-02-16 14:12:07 --> Total execution time: 1.0883
INFO - 2016-02-16 11:33:14 --> Config Class Initialized
INFO - 2016-02-16 11:33:14 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:33:14 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:33:14 --> Utf8 Class Initialized
INFO - 2016-02-16 11:33:14 --> URI Class Initialized
DEBUG - 2016-02-16 11:33:14 --> No URI present. Default controller set.
INFO - 2016-02-16 11:33:14 --> Router Class Initialized
INFO - 2016-02-16 11:33:14 --> Output Class Initialized
INFO - 2016-02-16 11:33:14 --> Security Class Initialized
DEBUG - 2016-02-16 11:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:33:14 --> Input Class Initialized
INFO - 2016-02-16 11:33:14 --> Language Class Initialized
INFO - 2016-02-16 11:33:14 --> Loader Class Initialized
INFO - 2016-02-16 11:33:14 --> Helper loaded: url_helper
INFO - 2016-02-16 11:33:14 --> Helper loaded: file_helper
INFO - 2016-02-16 11:33:14 --> Helper loaded: date_helper
INFO - 2016-02-16 11:33:14 --> Helper loaded: form_helper
INFO - 2016-02-16 11:33:14 --> Database Driver Class Initialized
INFO - 2016-02-16 11:33:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:33:15 --> Controller Class Initialized
INFO - 2016-02-16 11:33:15 --> Model Class Initialized
INFO - 2016-02-16 11:33:15 --> Model Class Initialized
INFO - 2016-02-16 11:33:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:33:16 --> Pagination Class Initialized
INFO - 2016-02-16 11:33:16 --> Helper loaded: text_helper
INFO - 2016-02-16 11:33:16 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 14:33:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 14:33:16 --> Final output sent to browser
DEBUG - 2016-02-16 14:33:16 --> Total execution time: 1.1854
INFO - 2016-02-16 11:51:04 --> Config Class Initialized
INFO - 2016-02-16 11:51:04 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:51:04 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:51:04 --> Utf8 Class Initialized
INFO - 2016-02-16 11:51:04 --> URI Class Initialized
DEBUG - 2016-02-16 11:51:04 --> No URI present. Default controller set.
INFO - 2016-02-16 11:51:04 --> Router Class Initialized
INFO - 2016-02-16 11:51:04 --> Output Class Initialized
INFO - 2016-02-16 11:51:04 --> Security Class Initialized
DEBUG - 2016-02-16 11:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:51:04 --> Input Class Initialized
INFO - 2016-02-16 11:51:04 --> Language Class Initialized
INFO - 2016-02-16 11:51:04 --> Loader Class Initialized
INFO - 2016-02-16 11:51:04 --> Helper loaded: url_helper
INFO - 2016-02-16 11:51:04 --> Helper loaded: file_helper
INFO - 2016-02-16 11:51:04 --> Helper loaded: date_helper
INFO - 2016-02-16 11:51:04 --> Helper loaded: form_helper
INFO - 2016-02-16 11:51:04 --> Database Driver Class Initialized
INFO - 2016-02-16 11:51:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:51:05 --> Controller Class Initialized
INFO - 2016-02-16 11:51:05 --> Model Class Initialized
INFO - 2016-02-16 11:51:05 --> Model Class Initialized
INFO - 2016-02-16 11:51:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:51:05 --> Pagination Class Initialized
INFO - 2016-02-16 11:51:05 --> Helper loaded: text_helper
INFO - 2016-02-16 11:51:05 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:51:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:51:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:51:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 14:51:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 14:51:05 --> Final output sent to browser
DEBUG - 2016-02-16 14:51:05 --> Total execution time: 1.1461
INFO - 2016-02-16 11:51:06 --> Config Class Initialized
INFO - 2016-02-16 11:51:06 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:51:06 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:51:06 --> Utf8 Class Initialized
INFO - 2016-02-16 11:51:06 --> URI Class Initialized
INFO - 2016-02-16 11:51:06 --> Router Class Initialized
INFO - 2016-02-16 11:51:06 --> Output Class Initialized
INFO - 2016-02-16 11:51:06 --> Security Class Initialized
DEBUG - 2016-02-16 11:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:51:06 --> Input Class Initialized
INFO - 2016-02-16 11:51:06 --> Language Class Initialized
INFO - 2016-02-16 11:51:06 --> Loader Class Initialized
INFO - 2016-02-16 11:51:06 --> Helper loaded: url_helper
INFO - 2016-02-16 11:51:06 --> Helper loaded: file_helper
INFO - 2016-02-16 11:51:06 --> Helper loaded: date_helper
INFO - 2016-02-16 11:51:06 --> Helper loaded: form_helper
INFO - 2016-02-16 11:51:06 --> Database Driver Class Initialized
INFO - 2016-02-16 11:51:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:51:07 --> Controller Class Initialized
INFO - 2016-02-16 11:51:07 --> Model Class Initialized
INFO - 2016-02-16 11:51:08 --> Model Class Initialized
INFO - 2016-02-16 11:51:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:51:08 --> Pagination Class Initialized
INFO - 2016-02-16 11:51:08 --> Helper loaded: text_helper
INFO - 2016-02-16 11:51:08 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:51:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 14:51:08 --> Final output sent to browser
DEBUG - 2016-02-16 14:51:08 --> Total execution time: 1.1637
INFO - 2016-02-16 11:51:09 --> Config Class Initialized
INFO - 2016-02-16 11:51:09 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:51:09 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:51:09 --> Utf8 Class Initialized
INFO - 2016-02-16 11:51:09 --> URI Class Initialized
INFO - 2016-02-16 11:51:09 --> Router Class Initialized
INFO - 2016-02-16 11:51:09 --> Output Class Initialized
INFO - 2016-02-16 11:51:09 --> Security Class Initialized
DEBUG - 2016-02-16 11:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:51:09 --> Input Class Initialized
INFO - 2016-02-16 11:51:09 --> Language Class Initialized
INFO - 2016-02-16 11:51:09 --> Loader Class Initialized
INFO - 2016-02-16 11:51:09 --> Helper loaded: url_helper
INFO - 2016-02-16 11:51:09 --> Helper loaded: file_helper
INFO - 2016-02-16 11:51:09 --> Helper loaded: date_helper
INFO - 2016-02-16 11:51:09 --> Helper loaded: form_helper
INFO - 2016-02-16 11:51:09 --> Database Driver Class Initialized
INFO - 2016-02-16 11:51:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:51:10 --> Controller Class Initialized
INFO - 2016-02-16 11:51:10 --> Model Class Initialized
INFO - 2016-02-16 11:51:10 --> Model Class Initialized
INFO - 2016-02-16 11:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:51:10 --> Pagination Class Initialized
INFO - 2016-02-16 11:51:10 --> Helper loaded: text_helper
INFO - 2016-02-16 11:51:10 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 14:51:10 --> Final output sent to browser
DEBUG - 2016-02-16 14:51:10 --> Total execution time: 1.1348
INFO - 2016-02-16 11:51:12 --> Config Class Initialized
INFO - 2016-02-16 11:51:12 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:51:12 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:51:12 --> Utf8 Class Initialized
INFO - 2016-02-16 11:51:12 --> URI Class Initialized
INFO - 2016-02-16 11:51:12 --> Router Class Initialized
INFO - 2016-02-16 11:51:12 --> Output Class Initialized
INFO - 2016-02-16 11:51:12 --> Security Class Initialized
DEBUG - 2016-02-16 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:51:12 --> Input Class Initialized
INFO - 2016-02-16 11:51:12 --> Language Class Initialized
INFO - 2016-02-16 11:51:12 --> Loader Class Initialized
INFO - 2016-02-16 11:51:12 --> Helper loaded: url_helper
INFO - 2016-02-16 11:51:12 --> Helper loaded: file_helper
INFO - 2016-02-16 11:51:12 --> Helper loaded: date_helper
INFO - 2016-02-16 11:51:12 --> Helper loaded: form_helper
INFO - 2016-02-16 11:51:12 --> Database Driver Class Initialized
INFO - 2016-02-16 11:51:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:51:13 --> Controller Class Initialized
INFO - 2016-02-16 11:51:13 --> Model Class Initialized
INFO - 2016-02-16 11:51:13 --> Model Class Initialized
INFO - 2016-02-16 11:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:51:13 --> Pagination Class Initialized
INFO - 2016-02-16 11:51:13 --> Helper loaded: text_helper
INFO - 2016-02-16 11:51:13 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 14:51:13 --> Final output sent to browser
DEBUG - 2016-02-16 14:51:13 --> Total execution time: 1.1526
INFO - 2016-02-16 11:51:40 --> Config Class Initialized
INFO - 2016-02-16 11:51:40 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:51:40 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:51:40 --> Utf8 Class Initialized
INFO - 2016-02-16 11:51:40 --> URI Class Initialized
INFO - 2016-02-16 11:51:40 --> Router Class Initialized
INFO - 2016-02-16 11:51:40 --> Output Class Initialized
INFO - 2016-02-16 11:51:40 --> Security Class Initialized
DEBUG - 2016-02-16 11:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:51:40 --> Input Class Initialized
INFO - 2016-02-16 11:51:40 --> Language Class Initialized
INFO - 2016-02-16 11:51:40 --> Loader Class Initialized
INFO - 2016-02-16 11:51:40 --> Helper loaded: url_helper
INFO - 2016-02-16 11:51:40 --> Helper loaded: file_helper
INFO - 2016-02-16 11:51:40 --> Helper loaded: date_helper
INFO - 2016-02-16 11:51:40 --> Helper loaded: form_helper
INFO - 2016-02-16 11:51:40 --> Database Driver Class Initialized
INFO - 2016-02-16 11:51:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:51:41 --> Controller Class Initialized
INFO - 2016-02-16 11:51:41 --> Model Class Initialized
INFO - 2016-02-16 11:51:41 --> Model Class Initialized
INFO - 2016-02-16 11:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:51:41 --> Pagination Class Initialized
INFO - 2016-02-16 11:51:41 --> Helper loaded: text_helper
INFO - 2016-02-16 11:51:41 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 14:51:41 --> Final output sent to browser
DEBUG - 2016-02-16 14:51:41 --> Total execution time: 1.1633
INFO - 2016-02-16 11:51:42 --> Config Class Initialized
INFO - 2016-02-16 11:51:42 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:51:42 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:51:42 --> Utf8 Class Initialized
INFO - 2016-02-16 11:51:42 --> URI Class Initialized
DEBUG - 2016-02-16 11:51:42 --> No URI present. Default controller set.
INFO - 2016-02-16 11:51:42 --> Router Class Initialized
INFO - 2016-02-16 11:51:42 --> Output Class Initialized
INFO - 2016-02-16 11:51:42 --> Security Class Initialized
DEBUG - 2016-02-16 11:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:51:42 --> Input Class Initialized
INFO - 2016-02-16 11:51:42 --> Language Class Initialized
INFO - 2016-02-16 11:51:42 --> Loader Class Initialized
INFO - 2016-02-16 11:51:42 --> Helper loaded: url_helper
INFO - 2016-02-16 11:51:42 --> Helper loaded: file_helper
INFO - 2016-02-16 11:51:42 --> Helper loaded: date_helper
INFO - 2016-02-16 11:51:42 --> Helper loaded: form_helper
INFO - 2016-02-16 11:51:42 --> Database Driver Class Initialized
INFO - 2016-02-16 11:51:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:51:43 --> Controller Class Initialized
INFO - 2016-02-16 11:51:43 --> Model Class Initialized
INFO - 2016-02-16 11:51:43 --> Model Class Initialized
INFO - 2016-02-16 11:51:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:51:43 --> Pagination Class Initialized
INFO - 2016-02-16 11:51:43 --> Helper loaded: text_helper
INFO - 2016-02-16 11:51:43 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:51:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:51:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:51:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 14:51:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 14:51:43 --> Final output sent to browser
DEBUG - 2016-02-16 14:51:43 --> Total execution time: 1.1714
INFO - 2016-02-16 11:51:44 --> Config Class Initialized
INFO - 2016-02-16 11:51:44 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:51:44 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:51:44 --> Utf8 Class Initialized
INFO - 2016-02-16 11:51:44 --> URI Class Initialized
INFO - 2016-02-16 11:51:44 --> Router Class Initialized
INFO - 2016-02-16 11:51:44 --> Output Class Initialized
INFO - 2016-02-16 11:51:44 --> Security Class Initialized
DEBUG - 2016-02-16 11:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:51:44 --> Input Class Initialized
INFO - 2016-02-16 11:51:44 --> Language Class Initialized
INFO - 2016-02-16 11:51:44 --> Loader Class Initialized
INFO - 2016-02-16 11:51:44 --> Helper loaded: url_helper
INFO - 2016-02-16 11:51:44 --> Helper loaded: file_helper
INFO - 2016-02-16 11:51:44 --> Helper loaded: date_helper
INFO - 2016-02-16 11:51:44 --> Helper loaded: form_helper
INFO - 2016-02-16 11:51:44 --> Database Driver Class Initialized
INFO - 2016-02-16 11:51:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:51:45 --> Controller Class Initialized
INFO - 2016-02-16 11:51:45 --> Model Class Initialized
INFO - 2016-02-16 11:51:45 --> Model Class Initialized
INFO - 2016-02-16 11:51:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:51:45 --> Pagination Class Initialized
INFO - 2016-02-16 11:51:45 --> Helper loaded: text_helper
INFO - 2016-02-16 11:51:45 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:51:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:51:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:51:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 14:51:45 --> Final output sent to browser
DEBUG - 2016-02-16 14:51:45 --> Total execution time: 1.1582
INFO - 2016-02-16 11:52:02 --> Config Class Initialized
INFO - 2016-02-16 11:52:02 --> Hooks Class Initialized
DEBUG - 2016-02-16 11:52:02 --> UTF-8 Support Enabled
INFO - 2016-02-16 11:52:02 --> Utf8 Class Initialized
INFO - 2016-02-16 11:52:02 --> URI Class Initialized
DEBUG - 2016-02-16 11:52:02 --> No URI present. Default controller set.
INFO - 2016-02-16 11:52:02 --> Router Class Initialized
INFO - 2016-02-16 11:52:02 --> Output Class Initialized
INFO - 2016-02-16 11:52:02 --> Security Class Initialized
DEBUG - 2016-02-16 11:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 11:52:02 --> Input Class Initialized
INFO - 2016-02-16 11:52:02 --> Language Class Initialized
INFO - 2016-02-16 11:52:02 --> Loader Class Initialized
INFO - 2016-02-16 11:52:02 --> Helper loaded: url_helper
INFO - 2016-02-16 11:52:02 --> Helper loaded: file_helper
INFO - 2016-02-16 11:52:02 --> Helper loaded: date_helper
INFO - 2016-02-16 11:52:02 --> Helper loaded: form_helper
INFO - 2016-02-16 11:52:02 --> Database Driver Class Initialized
INFO - 2016-02-16 11:52:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 11:52:03 --> Controller Class Initialized
INFO - 2016-02-16 11:52:03 --> Model Class Initialized
INFO - 2016-02-16 11:52:03 --> Model Class Initialized
INFO - 2016-02-16 11:52:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 11:52:03 --> Pagination Class Initialized
INFO - 2016-02-16 11:52:03 --> Helper loaded: text_helper
INFO - 2016-02-16 11:52:03 --> Helper loaded: cookie_helper
INFO - 2016-02-16 14:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 14:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 14:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 14:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 14:52:03 --> Final output sent to browser
DEBUG - 2016-02-16 14:52:03 --> Total execution time: 1.1243
INFO - 2016-02-16 12:04:11 --> Config Class Initialized
INFO - 2016-02-16 12:04:11 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:04:11 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:04:11 --> Utf8 Class Initialized
INFO - 2016-02-16 12:04:11 --> URI Class Initialized
INFO - 2016-02-16 12:04:11 --> Router Class Initialized
INFO - 2016-02-16 12:04:11 --> Output Class Initialized
INFO - 2016-02-16 12:04:11 --> Security Class Initialized
DEBUG - 2016-02-16 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:04:11 --> Input Class Initialized
INFO - 2016-02-16 12:04:11 --> Language Class Initialized
INFO - 2016-02-16 12:04:11 --> Loader Class Initialized
INFO - 2016-02-16 12:04:11 --> Helper loaded: url_helper
INFO - 2016-02-16 12:04:11 --> Helper loaded: file_helper
INFO - 2016-02-16 12:04:11 --> Helper loaded: date_helper
INFO - 2016-02-16 12:04:11 --> Helper loaded: form_helper
INFO - 2016-02-16 12:04:11 --> Database Driver Class Initialized
INFO - 2016-02-16 12:04:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:04:12 --> Controller Class Initialized
INFO - 2016-02-16 12:04:12 --> Model Class Initialized
INFO - 2016-02-16 12:04:12 --> Model Class Initialized
INFO - 2016-02-16 12:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:04:13 --> Pagination Class Initialized
INFO - 2016-02-16 12:04:13 --> Helper loaded: text_helper
INFO - 2016-02-16 12:04:13 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:04:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:04:13 --> Final output sent to browser
DEBUG - 2016-02-16 15:04:13 --> Total execution time: 1.1820
INFO - 2016-02-16 12:04:24 --> Config Class Initialized
INFO - 2016-02-16 12:04:24 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:04:24 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:04:24 --> Utf8 Class Initialized
INFO - 2016-02-16 12:04:24 --> URI Class Initialized
INFO - 2016-02-16 12:04:24 --> Router Class Initialized
INFO - 2016-02-16 12:04:24 --> Output Class Initialized
INFO - 2016-02-16 12:04:24 --> Security Class Initialized
DEBUG - 2016-02-16 12:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:04:24 --> Input Class Initialized
INFO - 2016-02-16 12:04:24 --> Language Class Initialized
INFO - 2016-02-16 12:04:24 --> Loader Class Initialized
INFO - 2016-02-16 12:04:24 --> Helper loaded: url_helper
INFO - 2016-02-16 12:04:24 --> Helper loaded: file_helper
INFO - 2016-02-16 12:04:24 --> Helper loaded: date_helper
INFO - 2016-02-16 12:04:24 --> Helper loaded: form_helper
INFO - 2016-02-16 12:04:24 --> Database Driver Class Initialized
INFO - 2016-02-16 12:04:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:04:25 --> Controller Class Initialized
INFO - 2016-02-16 12:04:25 --> Model Class Initialized
INFO - 2016-02-16 12:04:25 --> Model Class Initialized
INFO - 2016-02-16 12:04:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:04:25 --> Pagination Class Initialized
INFO - 2016-02-16 12:04:25 --> Helper loaded: text_helper
INFO - 2016-02-16 12:04:25 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:04:25 --> Final output sent to browser
DEBUG - 2016-02-16 15:04:25 --> Total execution time: 1.1101
INFO - 2016-02-16 12:04:41 --> Config Class Initialized
INFO - 2016-02-16 12:04:41 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:04:41 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:04:41 --> Utf8 Class Initialized
INFO - 2016-02-16 12:04:41 --> URI Class Initialized
INFO - 2016-02-16 12:04:41 --> Router Class Initialized
INFO - 2016-02-16 12:04:41 --> Output Class Initialized
INFO - 2016-02-16 12:04:41 --> Security Class Initialized
DEBUG - 2016-02-16 12:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:04:41 --> Input Class Initialized
INFO - 2016-02-16 12:04:41 --> Language Class Initialized
INFO - 2016-02-16 12:04:41 --> Loader Class Initialized
INFO - 2016-02-16 12:04:41 --> Helper loaded: url_helper
INFO - 2016-02-16 12:04:41 --> Helper loaded: file_helper
INFO - 2016-02-16 12:04:41 --> Helper loaded: date_helper
INFO - 2016-02-16 12:04:41 --> Helper loaded: form_helper
INFO - 2016-02-16 12:04:41 --> Database Driver Class Initialized
INFO - 2016-02-16 12:04:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:04:42 --> Controller Class Initialized
INFO - 2016-02-16 12:04:42 --> Model Class Initialized
INFO - 2016-02-16 12:04:42 --> Model Class Initialized
INFO - 2016-02-16 12:04:42 --> Form Validation Class Initialized
INFO - 2016-02-16 12:04:42 --> Helper loaded: text_helper
INFO - 2016-02-16 12:04:42 --> Config Class Initialized
INFO - 2016-02-16 12:04:42 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:04:42 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:04:42 --> Utf8 Class Initialized
INFO - 2016-02-16 12:04:42 --> URI Class Initialized
INFO - 2016-02-16 12:04:42 --> Router Class Initialized
INFO - 2016-02-16 12:04:42 --> Output Class Initialized
INFO - 2016-02-16 12:04:42 --> Security Class Initialized
DEBUG - 2016-02-16 12:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:04:42 --> Input Class Initialized
INFO - 2016-02-16 12:04:42 --> Language Class Initialized
INFO - 2016-02-16 12:04:42 --> Loader Class Initialized
INFO - 2016-02-16 12:04:42 --> Helper loaded: url_helper
INFO - 2016-02-16 12:04:42 --> Helper loaded: file_helper
INFO - 2016-02-16 12:04:42 --> Helper loaded: date_helper
INFO - 2016-02-16 12:04:42 --> Helper loaded: form_helper
INFO - 2016-02-16 12:04:42 --> Database Driver Class Initialized
INFO - 2016-02-16 12:04:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:04:43 --> Controller Class Initialized
INFO - 2016-02-16 12:04:43 --> Model Class Initialized
INFO - 2016-02-16 12:04:43 --> Model Class Initialized
INFO - 2016-02-16 12:04:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:04:43 --> Pagination Class Initialized
INFO - 2016-02-16 12:04:43 --> Helper loaded: text_helper
INFO - 2016-02-16 12:04:43 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:04:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:04:43 --> Final output sent to browser
DEBUG - 2016-02-16 15:04:43 --> Total execution time: 1.1756
INFO - 2016-02-16 12:04:46 --> Config Class Initialized
INFO - 2016-02-16 12:04:46 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:04:46 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:04:46 --> Utf8 Class Initialized
INFO - 2016-02-16 12:04:46 --> URI Class Initialized
INFO - 2016-02-16 12:04:46 --> Router Class Initialized
INFO - 2016-02-16 12:04:46 --> Output Class Initialized
INFO - 2016-02-16 12:04:46 --> Security Class Initialized
DEBUG - 2016-02-16 12:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:04:46 --> Input Class Initialized
INFO - 2016-02-16 12:04:46 --> Language Class Initialized
INFO - 2016-02-16 12:04:46 --> Loader Class Initialized
INFO - 2016-02-16 12:04:46 --> Helper loaded: url_helper
INFO - 2016-02-16 12:04:46 --> Helper loaded: file_helper
INFO - 2016-02-16 12:04:46 --> Helper loaded: date_helper
INFO - 2016-02-16 12:04:46 --> Helper loaded: form_helper
INFO - 2016-02-16 12:04:46 --> Database Driver Class Initialized
INFO - 2016-02-16 12:04:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:04:47 --> Controller Class Initialized
INFO - 2016-02-16 12:04:47 --> Model Class Initialized
INFO - 2016-02-16 12:04:47 --> Model Class Initialized
INFO - 2016-02-16 12:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:04:47 --> Pagination Class Initialized
INFO - 2016-02-16 12:04:47 --> Helper loaded: text_helper
INFO - 2016-02-16 12:04:47 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:05:40 --> Config Class Initialized
INFO - 2016-02-16 12:05:40 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:05:40 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:05:40 --> Utf8 Class Initialized
INFO - 2016-02-16 12:05:40 --> URI Class Initialized
INFO - 2016-02-16 12:05:40 --> Router Class Initialized
INFO - 2016-02-16 12:05:40 --> Output Class Initialized
INFO - 2016-02-16 12:05:40 --> Security Class Initialized
DEBUG - 2016-02-16 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:05:40 --> Input Class Initialized
INFO - 2016-02-16 12:05:40 --> Language Class Initialized
INFO - 2016-02-16 12:05:40 --> Loader Class Initialized
INFO - 2016-02-16 12:05:40 --> Helper loaded: url_helper
INFO - 2016-02-16 12:05:40 --> Helper loaded: file_helper
INFO - 2016-02-16 12:05:40 --> Helper loaded: date_helper
INFO - 2016-02-16 12:05:40 --> Helper loaded: form_helper
INFO - 2016-02-16 12:05:40 --> Database Driver Class Initialized
INFO - 2016-02-16 12:05:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:05:41 --> Controller Class Initialized
INFO - 2016-02-16 12:05:41 --> Model Class Initialized
INFO - 2016-02-16 12:05:41 --> Model Class Initialized
INFO - 2016-02-16 12:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:05:41 --> Pagination Class Initialized
INFO - 2016-02-16 12:05:41 --> Helper loaded: text_helper
INFO - 2016-02-16 12:05:41 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:05:44 --> Config Class Initialized
INFO - 2016-02-16 12:05:44 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:05:44 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:05:44 --> Utf8 Class Initialized
INFO - 2016-02-16 12:05:44 --> URI Class Initialized
INFO - 2016-02-16 12:05:44 --> Router Class Initialized
INFO - 2016-02-16 12:05:44 --> Output Class Initialized
INFO - 2016-02-16 12:05:44 --> Security Class Initialized
DEBUG - 2016-02-16 12:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:05:44 --> Input Class Initialized
INFO - 2016-02-16 12:05:44 --> Language Class Initialized
INFO - 2016-02-16 12:05:44 --> Loader Class Initialized
INFO - 2016-02-16 12:05:44 --> Helper loaded: url_helper
INFO - 2016-02-16 12:05:44 --> Helper loaded: file_helper
INFO - 2016-02-16 12:05:44 --> Helper loaded: date_helper
INFO - 2016-02-16 12:05:44 --> Helper loaded: form_helper
INFO - 2016-02-16 12:05:44 --> Database Driver Class Initialized
INFO - 2016-02-16 12:05:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:05:45 --> Controller Class Initialized
INFO - 2016-02-16 12:05:45 --> Model Class Initialized
INFO - 2016-02-16 12:05:45 --> Model Class Initialized
INFO - 2016-02-16 12:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:05:45 --> Pagination Class Initialized
INFO - 2016-02-16 12:05:45 --> Helper loaded: text_helper
INFO - 2016-02-16 12:05:45 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:05:48 --> Config Class Initialized
INFO - 2016-02-16 12:05:48 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:05:48 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:05:48 --> Utf8 Class Initialized
INFO - 2016-02-16 12:05:48 --> URI Class Initialized
INFO - 2016-02-16 12:05:48 --> Router Class Initialized
INFO - 2016-02-16 12:05:48 --> Output Class Initialized
INFO - 2016-02-16 12:05:48 --> Security Class Initialized
DEBUG - 2016-02-16 12:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:05:48 --> Input Class Initialized
INFO - 2016-02-16 12:05:48 --> Language Class Initialized
INFO - 2016-02-16 12:05:48 --> Loader Class Initialized
INFO - 2016-02-16 12:05:48 --> Helper loaded: url_helper
INFO - 2016-02-16 12:05:48 --> Helper loaded: file_helper
INFO - 2016-02-16 12:05:48 --> Helper loaded: date_helper
INFO - 2016-02-16 12:05:48 --> Helper loaded: form_helper
INFO - 2016-02-16 12:05:48 --> Database Driver Class Initialized
INFO - 2016-02-16 12:05:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:05:49 --> Controller Class Initialized
INFO - 2016-02-16 12:05:49 --> Model Class Initialized
INFO - 2016-02-16 12:05:49 --> Model Class Initialized
INFO - 2016-02-16 12:05:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:05:49 --> Pagination Class Initialized
INFO - 2016-02-16 12:05:49 --> Helper loaded: text_helper
INFO - 2016-02-16 12:05:49 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:05:51 --> Config Class Initialized
INFO - 2016-02-16 12:05:51 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:05:51 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:05:52 --> Utf8 Class Initialized
INFO - 2016-02-16 12:05:52 --> URI Class Initialized
DEBUG - 2016-02-16 12:05:52 --> No URI present. Default controller set.
INFO - 2016-02-16 12:05:52 --> Router Class Initialized
INFO - 2016-02-16 12:05:52 --> Output Class Initialized
INFO - 2016-02-16 12:05:52 --> Security Class Initialized
DEBUG - 2016-02-16 12:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:05:52 --> Input Class Initialized
INFO - 2016-02-16 12:05:52 --> Language Class Initialized
INFO - 2016-02-16 12:05:52 --> Loader Class Initialized
INFO - 2016-02-16 12:05:52 --> Helper loaded: url_helper
INFO - 2016-02-16 12:05:52 --> Helper loaded: file_helper
INFO - 2016-02-16 12:05:52 --> Helper loaded: date_helper
INFO - 2016-02-16 12:05:52 --> Helper loaded: form_helper
INFO - 2016-02-16 12:05:52 --> Database Driver Class Initialized
INFO - 2016-02-16 12:05:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:05:53 --> Controller Class Initialized
INFO - 2016-02-16 12:05:53 --> Model Class Initialized
INFO - 2016-02-16 12:05:53 --> Model Class Initialized
INFO - 2016-02-16 12:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:05:53 --> Pagination Class Initialized
INFO - 2016-02-16 12:05:53 --> Helper loaded: text_helper
INFO - 2016-02-16 12:05:53 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:05:53 --> Final output sent to browser
DEBUG - 2016-02-16 15:05:53 --> Total execution time: 1.1809
INFO - 2016-02-16 12:05:54 --> Config Class Initialized
INFO - 2016-02-16 12:05:54 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:05:54 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:05:54 --> Utf8 Class Initialized
INFO - 2016-02-16 12:05:54 --> URI Class Initialized
INFO - 2016-02-16 12:05:54 --> Router Class Initialized
INFO - 2016-02-16 12:05:54 --> Output Class Initialized
INFO - 2016-02-16 12:05:54 --> Security Class Initialized
DEBUG - 2016-02-16 12:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:05:54 --> Input Class Initialized
INFO - 2016-02-16 12:05:54 --> Language Class Initialized
INFO - 2016-02-16 12:05:54 --> Loader Class Initialized
INFO - 2016-02-16 12:05:54 --> Helper loaded: url_helper
INFO - 2016-02-16 12:05:54 --> Helper loaded: file_helper
INFO - 2016-02-16 12:05:54 --> Helper loaded: date_helper
INFO - 2016-02-16 12:05:54 --> Helper loaded: form_helper
INFO - 2016-02-16 12:05:54 --> Database Driver Class Initialized
INFO - 2016-02-16 12:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:05:55 --> Controller Class Initialized
INFO - 2016-02-16 12:05:55 --> Model Class Initialized
INFO - 2016-02-16 12:05:55 --> Model Class Initialized
INFO - 2016-02-16 12:05:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:05:55 --> Pagination Class Initialized
INFO - 2016-02-16 12:05:55 --> Helper loaded: text_helper
INFO - 2016-02-16 12:05:55 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:05:55 --> Final output sent to browser
DEBUG - 2016-02-16 15:05:55 --> Total execution time: 1.2445
INFO - 2016-02-16 12:06:00 --> Config Class Initialized
INFO - 2016-02-16 12:06:00 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:06:00 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:06:00 --> Utf8 Class Initialized
INFO - 2016-02-16 12:06:00 --> URI Class Initialized
INFO - 2016-02-16 12:06:00 --> Router Class Initialized
INFO - 2016-02-16 12:06:00 --> Output Class Initialized
INFO - 2016-02-16 12:06:00 --> Security Class Initialized
DEBUG - 2016-02-16 12:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:06:00 --> Input Class Initialized
INFO - 2016-02-16 12:06:00 --> Language Class Initialized
INFO - 2016-02-16 12:06:00 --> Loader Class Initialized
INFO - 2016-02-16 12:06:00 --> Helper loaded: url_helper
INFO - 2016-02-16 12:06:00 --> Helper loaded: file_helper
INFO - 2016-02-16 12:06:00 --> Helper loaded: date_helper
INFO - 2016-02-16 12:06:00 --> Helper loaded: form_helper
INFO - 2016-02-16 12:06:00 --> Database Driver Class Initialized
INFO - 2016-02-16 12:06:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:06:01 --> Controller Class Initialized
INFO - 2016-02-16 12:06:01 --> Model Class Initialized
INFO - 2016-02-16 12:06:01 --> Model Class Initialized
INFO - 2016-02-16 12:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:06:01 --> Pagination Class Initialized
INFO - 2016-02-16 12:06:01 --> Helper loaded: text_helper
INFO - 2016-02-16 12:06:01 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:07:04 --> Config Class Initialized
INFO - 2016-02-16 12:07:04 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:07:04 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:07:04 --> Utf8 Class Initialized
INFO - 2016-02-16 12:07:04 --> URI Class Initialized
INFO - 2016-02-16 12:07:04 --> Router Class Initialized
INFO - 2016-02-16 12:07:04 --> Output Class Initialized
INFO - 2016-02-16 12:07:04 --> Security Class Initialized
DEBUG - 2016-02-16 12:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:07:04 --> Input Class Initialized
INFO - 2016-02-16 12:07:04 --> Language Class Initialized
INFO - 2016-02-16 12:07:04 --> Loader Class Initialized
INFO - 2016-02-16 12:07:04 --> Helper loaded: url_helper
INFO - 2016-02-16 12:07:04 --> Helper loaded: file_helper
INFO - 2016-02-16 12:07:04 --> Helper loaded: date_helper
INFO - 2016-02-16 12:07:04 --> Helper loaded: form_helper
INFO - 2016-02-16 12:07:04 --> Database Driver Class Initialized
INFO - 2016-02-16 12:07:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:07:05 --> Controller Class Initialized
INFO - 2016-02-16 12:07:05 --> Model Class Initialized
INFO - 2016-02-16 12:07:05 --> Model Class Initialized
INFO - 2016-02-16 12:07:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:07:05 --> Pagination Class Initialized
INFO - 2016-02-16 12:07:05 --> Helper loaded: text_helper
INFO - 2016-02-16 12:07:05 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:07:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:07:06 --> Final output sent to browser
DEBUG - 2016-02-16 15:07:06 --> Total execution time: 1.2156
INFO - 2016-02-16 12:07:07 --> Config Class Initialized
INFO - 2016-02-16 12:07:07 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:07:07 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:07:07 --> Utf8 Class Initialized
INFO - 2016-02-16 12:07:07 --> URI Class Initialized
INFO - 2016-02-16 12:07:07 --> Router Class Initialized
INFO - 2016-02-16 12:07:07 --> Output Class Initialized
INFO - 2016-02-16 12:07:07 --> Security Class Initialized
DEBUG - 2016-02-16 12:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:07:07 --> Input Class Initialized
INFO - 2016-02-16 12:07:07 --> Language Class Initialized
INFO - 2016-02-16 12:07:07 --> Loader Class Initialized
INFO - 2016-02-16 12:07:07 --> Helper loaded: url_helper
INFO - 2016-02-16 12:07:07 --> Helper loaded: file_helper
INFO - 2016-02-16 12:07:07 --> Helper loaded: date_helper
INFO - 2016-02-16 12:07:07 --> Helper loaded: form_helper
INFO - 2016-02-16 12:07:07 --> Database Driver Class Initialized
INFO - 2016-02-16 12:07:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:07:08 --> Controller Class Initialized
INFO - 2016-02-16 12:07:08 --> Model Class Initialized
INFO - 2016-02-16 12:07:08 --> Model Class Initialized
INFO - 2016-02-16 12:07:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:07:08 --> Pagination Class Initialized
INFO - 2016-02-16 12:07:08 --> Helper loaded: text_helper
INFO - 2016-02-16 12:07:08 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:07:12 --> Config Class Initialized
INFO - 2016-02-16 12:07:12 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:07:12 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:07:12 --> Utf8 Class Initialized
INFO - 2016-02-16 12:07:12 --> URI Class Initialized
INFO - 2016-02-16 12:07:12 --> Router Class Initialized
INFO - 2016-02-16 12:07:12 --> Output Class Initialized
INFO - 2016-02-16 12:07:12 --> Security Class Initialized
DEBUG - 2016-02-16 12:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:07:12 --> Input Class Initialized
INFO - 2016-02-16 12:07:12 --> Language Class Initialized
INFO - 2016-02-16 12:07:12 --> Loader Class Initialized
INFO - 2016-02-16 12:07:12 --> Helper loaded: url_helper
INFO - 2016-02-16 12:07:12 --> Helper loaded: file_helper
INFO - 2016-02-16 12:07:12 --> Helper loaded: date_helper
INFO - 2016-02-16 12:07:12 --> Helper loaded: form_helper
INFO - 2016-02-16 12:07:12 --> Database Driver Class Initialized
INFO - 2016-02-16 12:07:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:07:13 --> Controller Class Initialized
INFO - 2016-02-16 12:07:13 --> Model Class Initialized
INFO - 2016-02-16 12:07:13 --> Model Class Initialized
INFO - 2016-02-16 12:07:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:07:13 --> Pagination Class Initialized
INFO - 2016-02-16 12:07:13 --> Helper loaded: text_helper
INFO - 2016-02-16 12:07:13 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:08:39 --> Config Class Initialized
INFO - 2016-02-16 12:08:39 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:08:39 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:08:39 --> Utf8 Class Initialized
INFO - 2016-02-16 12:08:39 --> URI Class Initialized
INFO - 2016-02-16 12:08:39 --> Router Class Initialized
INFO - 2016-02-16 12:08:39 --> Output Class Initialized
INFO - 2016-02-16 12:08:39 --> Security Class Initialized
DEBUG - 2016-02-16 12:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:08:39 --> Input Class Initialized
INFO - 2016-02-16 12:08:39 --> Language Class Initialized
INFO - 2016-02-16 12:08:39 --> Loader Class Initialized
INFO - 2016-02-16 12:08:39 --> Helper loaded: url_helper
INFO - 2016-02-16 12:08:39 --> Helper loaded: file_helper
INFO - 2016-02-16 12:08:39 --> Helper loaded: date_helper
INFO - 2016-02-16 12:08:39 --> Helper loaded: form_helper
INFO - 2016-02-16 12:08:40 --> Database Driver Class Initialized
INFO - 2016-02-16 12:08:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:08:41 --> Controller Class Initialized
INFO - 2016-02-16 12:08:41 --> Model Class Initialized
INFO - 2016-02-16 12:08:41 --> Model Class Initialized
INFO - 2016-02-16 12:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:08:41 --> Pagination Class Initialized
INFO - 2016-02-16 12:08:41 --> Helper loaded: text_helper
INFO - 2016-02-16 12:08:41 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:08:41 --> Final output sent to browser
DEBUG - 2016-02-16 15:08:41 --> Total execution time: 1.2399
INFO - 2016-02-16 12:08:42 --> Config Class Initialized
INFO - 2016-02-16 12:08:42 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:08:42 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:08:42 --> Utf8 Class Initialized
INFO - 2016-02-16 12:08:42 --> URI Class Initialized
INFO - 2016-02-16 12:08:42 --> Router Class Initialized
INFO - 2016-02-16 12:08:42 --> Output Class Initialized
INFO - 2016-02-16 12:08:42 --> Security Class Initialized
DEBUG - 2016-02-16 12:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:08:42 --> Input Class Initialized
INFO - 2016-02-16 12:08:42 --> Language Class Initialized
INFO - 2016-02-16 12:08:42 --> Loader Class Initialized
INFO - 2016-02-16 12:08:42 --> Helper loaded: url_helper
INFO - 2016-02-16 12:08:42 --> Helper loaded: file_helper
INFO - 2016-02-16 12:08:42 --> Helper loaded: date_helper
INFO - 2016-02-16 12:08:42 --> Helper loaded: form_helper
INFO - 2016-02-16 12:08:42 --> Database Driver Class Initialized
INFO - 2016-02-16 12:08:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:08:43 --> Controller Class Initialized
INFO - 2016-02-16 12:08:43 --> Model Class Initialized
INFO - 2016-02-16 12:08:43 --> Model Class Initialized
INFO - 2016-02-16 12:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:08:43 --> Pagination Class Initialized
INFO - 2016-02-16 12:08:43 --> Helper loaded: text_helper
INFO - 2016-02-16 12:08:43 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:25:35 --> Config Class Initialized
INFO - 2016-02-16 12:25:35 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:25:35 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:25:35 --> Utf8 Class Initialized
INFO - 2016-02-16 12:25:36 --> URI Class Initialized
INFO - 2016-02-16 12:25:36 --> Router Class Initialized
INFO - 2016-02-16 12:25:36 --> Output Class Initialized
INFO - 2016-02-16 12:25:36 --> Security Class Initialized
DEBUG - 2016-02-16 12:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:25:36 --> Input Class Initialized
INFO - 2016-02-16 12:25:36 --> Language Class Initialized
INFO - 2016-02-16 12:25:36 --> Loader Class Initialized
INFO - 2016-02-16 12:25:36 --> Helper loaded: url_helper
INFO - 2016-02-16 12:25:36 --> Helper loaded: file_helper
INFO - 2016-02-16 12:25:36 --> Helper loaded: date_helper
INFO - 2016-02-16 12:25:36 --> Helper loaded: form_helper
INFO - 2016-02-16 12:25:36 --> Database Driver Class Initialized
INFO - 2016-02-16 12:25:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:25:37 --> Controller Class Initialized
INFO - 2016-02-16 12:25:37 --> Model Class Initialized
INFO - 2016-02-16 12:25:37 --> Model Class Initialized
INFO - 2016-02-16 12:25:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:25:37 --> Pagination Class Initialized
INFO - 2016-02-16 12:25:37 --> Helper loaded: text_helper
INFO - 2016-02-16 12:25:37 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:25:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:25:37 --> Final output sent to browser
DEBUG - 2016-02-16 15:25:37 --> Total execution time: 1.2205
INFO - 2016-02-16 12:25:48 --> Config Class Initialized
INFO - 2016-02-16 12:25:48 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:25:48 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:25:48 --> Utf8 Class Initialized
INFO - 2016-02-16 12:25:48 --> URI Class Initialized
INFO - 2016-02-16 12:25:48 --> Router Class Initialized
INFO - 2016-02-16 12:25:48 --> Output Class Initialized
INFO - 2016-02-16 12:25:48 --> Security Class Initialized
DEBUG - 2016-02-16 12:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:25:48 --> Input Class Initialized
INFO - 2016-02-16 12:25:48 --> Language Class Initialized
INFO - 2016-02-16 12:25:48 --> Loader Class Initialized
INFO - 2016-02-16 12:25:48 --> Helper loaded: url_helper
INFO - 2016-02-16 12:25:48 --> Helper loaded: file_helper
INFO - 2016-02-16 12:25:48 --> Helper loaded: date_helper
INFO - 2016-02-16 12:25:48 --> Helper loaded: form_helper
INFO - 2016-02-16 12:25:49 --> Database Driver Class Initialized
INFO - 2016-02-16 12:25:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:25:50 --> Controller Class Initialized
INFO - 2016-02-16 12:25:50 --> Model Class Initialized
INFO - 2016-02-16 12:25:50 --> Model Class Initialized
INFO - 2016-02-16 12:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:25:50 --> Pagination Class Initialized
INFO - 2016-02-16 12:25:50 --> Helper loaded: text_helper
INFO - 2016-02-16 12:25:50 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:25:50 --> Final output sent to browser
DEBUG - 2016-02-16 15:25:50 --> Total execution time: 1.2007
INFO - 2016-02-16 12:27:03 --> Config Class Initialized
INFO - 2016-02-16 12:27:03 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:27:03 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:27:03 --> Utf8 Class Initialized
INFO - 2016-02-16 12:27:03 --> URI Class Initialized
INFO - 2016-02-16 12:27:03 --> Router Class Initialized
INFO - 2016-02-16 12:27:03 --> Output Class Initialized
INFO - 2016-02-16 12:27:03 --> Security Class Initialized
DEBUG - 2016-02-16 12:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:27:03 --> Input Class Initialized
INFO - 2016-02-16 12:27:03 --> Language Class Initialized
INFO - 2016-02-16 12:27:03 --> Loader Class Initialized
INFO - 2016-02-16 12:27:03 --> Helper loaded: url_helper
INFO - 2016-02-16 12:27:03 --> Helper loaded: file_helper
INFO - 2016-02-16 12:27:03 --> Helper loaded: date_helper
INFO - 2016-02-16 12:27:03 --> Helper loaded: form_helper
INFO - 2016-02-16 12:27:03 --> Database Driver Class Initialized
INFO - 2016-02-16 12:27:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:27:04 --> Controller Class Initialized
INFO - 2016-02-16 12:27:04 --> Model Class Initialized
INFO - 2016-02-16 12:27:04 --> Model Class Initialized
INFO - 2016-02-16 12:27:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:27:05 --> Pagination Class Initialized
INFO - 2016-02-16 12:27:05 --> Helper loaded: text_helper
INFO - 2016-02-16 12:27:05 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:27:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:27:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:27:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:27:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:27:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:27:05 --> Final output sent to browser
DEBUG - 2016-02-16 15:27:05 --> Total execution time: 1.2166
INFO - 2016-02-16 12:27:06 --> Config Class Initialized
INFO - 2016-02-16 12:27:06 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:27:06 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:27:06 --> Utf8 Class Initialized
INFO - 2016-02-16 12:27:06 --> URI Class Initialized
INFO - 2016-02-16 12:27:06 --> Router Class Initialized
INFO - 2016-02-16 12:27:06 --> Output Class Initialized
INFO - 2016-02-16 12:27:06 --> Security Class Initialized
DEBUG - 2016-02-16 12:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:27:06 --> Input Class Initialized
INFO - 2016-02-16 12:27:06 --> Language Class Initialized
INFO - 2016-02-16 12:27:06 --> Loader Class Initialized
INFO - 2016-02-16 12:27:06 --> Helper loaded: url_helper
INFO - 2016-02-16 12:27:06 --> Helper loaded: file_helper
INFO - 2016-02-16 12:27:06 --> Helper loaded: date_helper
INFO - 2016-02-16 12:27:06 --> Helper loaded: form_helper
INFO - 2016-02-16 12:27:06 --> Database Driver Class Initialized
INFO - 2016-02-16 12:27:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:27:07 --> Controller Class Initialized
INFO - 2016-02-16 12:27:07 --> Model Class Initialized
INFO - 2016-02-16 12:27:07 --> Model Class Initialized
INFO - 2016-02-16 12:27:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:27:07 --> Pagination Class Initialized
INFO - 2016-02-16 12:27:07 --> Helper loaded: text_helper
INFO - 2016-02-16 12:27:07 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:27:31 --> Config Class Initialized
INFO - 2016-02-16 12:27:31 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:27:31 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:27:31 --> Utf8 Class Initialized
INFO - 2016-02-16 12:27:31 --> URI Class Initialized
INFO - 2016-02-16 12:27:31 --> Router Class Initialized
INFO - 2016-02-16 12:27:31 --> Output Class Initialized
INFO - 2016-02-16 12:27:31 --> Security Class Initialized
DEBUG - 2016-02-16 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:27:31 --> Input Class Initialized
INFO - 2016-02-16 12:27:31 --> Language Class Initialized
INFO - 2016-02-16 12:27:31 --> Loader Class Initialized
INFO - 2016-02-16 12:27:31 --> Helper loaded: url_helper
INFO - 2016-02-16 12:27:31 --> Helper loaded: file_helper
INFO - 2016-02-16 12:27:32 --> Helper loaded: date_helper
INFO - 2016-02-16 12:27:32 --> Helper loaded: form_helper
INFO - 2016-02-16 12:27:32 --> Database Driver Class Initialized
INFO - 2016-02-16 12:27:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:27:33 --> Controller Class Initialized
INFO - 2016-02-16 12:27:33 --> Model Class Initialized
INFO - 2016-02-16 12:27:33 --> Model Class Initialized
INFO - 2016-02-16 12:27:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:27:33 --> Pagination Class Initialized
INFO - 2016-02-16 12:27:33 --> Helper loaded: text_helper
INFO - 2016-02-16 12:27:33 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:27:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:27:33 --> Final output sent to browser
DEBUG - 2016-02-16 15:27:33 --> Total execution time: 1.2273
INFO - 2016-02-16 12:27:34 --> Config Class Initialized
INFO - 2016-02-16 12:27:34 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:27:34 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:27:34 --> Utf8 Class Initialized
INFO - 2016-02-16 12:27:34 --> URI Class Initialized
INFO - 2016-02-16 12:27:34 --> Router Class Initialized
INFO - 2016-02-16 12:27:34 --> Output Class Initialized
INFO - 2016-02-16 12:27:34 --> Security Class Initialized
DEBUG - 2016-02-16 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:27:34 --> Input Class Initialized
INFO - 2016-02-16 12:27:34 --> Language Class Initialized
INFO - 2016-02-16 12:27:34 --> Loader Class Initialized
INFO - 2016-02-16 12:27:34 --> Helper loaded: url_helper
INFO - 2016-02-16 12:27:34 --> Helper loaded: file_helper
INFO - 2016-02-16 12:27:34 --> Helper loaded: date_helper
INFO - 2016-02-16 12:27:34 --> Helper loaded: form_helper
INFO - 2016-02-16 12:27:34 --> Database Driver Class Initialized
INFO - 2016-02-16 12:27:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:27:35 --> Controller Class Initialized
INFO - 2016-02-16 12:27:35 --> Model Class Initialized
INFO - 2016-02-16 12:27:35 --> Model Class Initialized
INFO - 2016-02-16 12:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:27:35 --> Pagination Class Initialized
INFO - 2016-02-16 12:27:35 --> Helper loaded: text_helper
INFO - 2016-02-16 12:27:35 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:28:48 --> Config Class Initialized
INFO - 2016-02-16 12:28:48 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:28:48 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:28:48 --> Utf8 Class Initialized
INFO - 2016-02-16 12:28:48 --> URI Class Initialized
INFO - 2016-02-16 12:28:48 --> Router Class Initialized
INFO - 2016-02-16 12:28:48 --> Output Class Initialized
INFO - 2016-02-16 12:28:48 --> Security Class Initialized
DEBUG - 2016-02-16 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:28:48 --> Input Class Initialized
INFO - 2016-02-16 12:28:48 --> Language Class Initialized
INFO - 2016-02-16 12:28:48 --> Loader Class Initialized
INFO - 2016-02-16 12:28:48 --> Helper loaded: url_helper
INFO - 2016-02-16 12:28:48 --> Helper loaded: file_helper
INFO - 2016-02-16 12:28:48 --> Helper loaded: date_helper
INFO - 2016-02-16 12:28:48 --> Helper loaded: form_helper
INFO - 2016-02-16 12:28:48 --> Database Driver Class Initialized
INFO - 2016-02-16 12:28:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:28:49 --> Controller Class Initialized
INFO - 2016-02-16 12:28:49 --> Model Class Initialized
INFO - 2016-02-16 12:28:49 --> Model Class Initialized
INFO - 2016-02-16 12:28:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:28:49 --> Pagination Class Initialized
INFO - 2016-02-16 12:28:49 --> Helper loaded: text_helper
INFO - 2016-02-16 12:28:49 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-16 15:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-16 15:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:28:49 --> Final output sent to browser
DEBUG - 2016-02-16 15:28:49 --> Total execution time: 1.2098
INFO - 2016-02-16 12:28:50 --> Config Class Initialized
INFO - 2016-02-16 12:28:50 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:28:50 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:28:50 --> Utf8 Class Initialized
INFO - 2016-02-16 12:28:50 --> URI Class Initialized
INFO - 2016-02-16 12:28:50 --> Router Class Initialized
INFO - 2016-02-16 12:28:50 --> Output Class Initialized
INFO - 2016-02-16 12:28:50 --> Security Class Initialized
DEBUG - 2016-02-16 12:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:28:50 --> Input Class Initialized
INFO - 2016-02-16 12:28:50 --> Language Class Initialized
INFO - 2016-02-16 12:28:50 --> Loader Class Initialized
INFO - 2016-02-16 12:28:50 --> Helper loaded: url_helper
INFO - 2016-02-16 12:28:50 --> Helper loaded: file_helper
INFO - 2016-02-16 12:28:50 --> Helper loaded: date_helper
INFO - 2016-02-16 12:28:50 --> Helper loaded: form_helper
INFO - 2016-02-16 12:28:50 --> Database Driver Class Initialized
INFO - 2016-02-16 12:28:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:28:51 --> Controller Class Initialized
INFO - 2016-02-16 12:28:51 --> Model Class Initialized
INFO - 2016-02-16 12:28:51 --> Model Class Initialized
INFO - 2016-02-16 12:28:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:28:51 --> Pagination Class Initialized
INFO - 2016-02-16 12:28:51 --> Helper loaded: text_helper
INFO - 2016-02-16 12:28:51 --> Helper loaded: cookie_helper
INFO - 2016-02-16 12:36:51 --> Config Class Initialized
INFO - 2016-02-16 12:36:51 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:36:51 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:36:51 --> Utf8 Class Initialized
INFO - 2016-02-16 12:36:51 --> URI Class Initialized
DEBUG - 2016-02-16 12:36:51 --> No URI present. Default controller set.
INFO - 2016-02-16 12:36:51 --> Router Class Initialized
INFO - 2016-02-16 12:36:51 --> Output Class Initialized
INFO - 2016-02-16 12:36:51 --> Security Class Initialized
DEBUG - 2016-02-16 12:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:36:51 --> Input Class Initialized
INFO - 2016-02-16 12:36:51 --> Language Class Initialized
INFO - 2016-02-16 12:36:51 --> Loader Class Initialized
INFO - 2016-02-16 12:36:51 --> Helper loaded: url_helper
INFO - 2016-02-16 12:36:51 --> Helper loaded: file_helper
INFO - 2016-02-16 12:36:51 --> Helper loaded: date_helper
INFO - 2016-02-16 12:36:51 --> Helper loaded: form_helper
INFO - 2016-02-16 12:36:51 --> Database Driver Class Initialized
INFO - 2016-02-16 12:36:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:36:53 --> Controller Class Initialized
INFO - 2016-02-16 12:36:53 --> Model Class Initialized
INFO - 2016-02-16 12:36:53 --> Model Class Initialized
INFO - 2016-02-16 12:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:36:53 --> Pagination Class Initialized
INFO - 2016-02-16 12:36:53 --> Helper loaded: text_helper
INFO - 2016-02-16 12:36:53 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:36:53 --> Final output sent to browser
DEBUG - 2016-02-16 15:36:53 --> Total execution time: 1.1789
INFO - 2016-02-16 12:36:54 --> Config Class Initialized
INFO - 2016-02-16 12:36:54 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:36:54 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:36:54 --> Utf8 Class Initialized
INFO - 2016-02-16 12:36:54 --> URI Class Initialized
INFO - 2016-02-16 12:36:54 --> Router Class Initialized
INFO - 2016-02-16 12:36:54 --> Output Class Initialized
INFO - 2016-02-16 12:36:54 --> Security Class Initialized
DEBUG - 2016-02-16 12:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:36:54 --> Input Class Initialized
INFO - 2016-02-16 12:36:54 --> Language Class Initialized
INFO - 2016-02-16 12:36:54 --> Loader Class Initialized
INFO - 2016-02-16 12:36:54 --> Helper loaded: url_helper
INFO - 2016-02-16 12:36:54 --> Helper loaded: file_helper
INFO - 2016-02-16 12:36:54 --> Helper loaded: date_helper
INFO - 2016-02-16 12:36:54 --> Helper loaded: form_helper
INFO - 2016-02-16 12:36:54 --> Database Driver Class Initialized
INFO - 2016-02-16 12:36:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:36:55 --> Controller Class Initialized
INFO - 2016-02-16 12:36:55 --> Model Class Initialized
INFO - 2016-02-16 12:36:55 --> Model Class Initialized
INFO - 2016-02-16 12:36:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:36:55 --> Pagination Class Initialized
INFO - 2016-02-16 12:36:55 --> Helper loaded: text_helper
INFO - 2016-02-16 12:36:55 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:36:55 --> Form Validation Class Initialized
INFO - 2016-02-16 15:36:55 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-16 15:36:55 --> Severity: Error --> Call to undefined function alert() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 339
INFO - 2016-02-16 12:39:34 --> Config Class Initialized
INFO - 2016-02-16 12:39:34 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:39:34 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:39:34 --> Utf8 Class Initialized
INFO - 2016-02-16 12:39:34 --> URI Class Initialized
INFO - 2016-02-16 12:39:34 --> Router Class Initialized
INFO - 2016-02-16 12:39:34 --> Output Class Initialized
INFO - 2016-02-16 12:39:34 --> Security Class Initialized
DEBUG - 2016-02-16 12:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:39:34 --> Input Class Initialized
INFO - 2016-02-16 12:39:34 --> Language Class Initialized
INFO - 2016-02-16 12:39:34 --> Loader Class Initialized
INFO - 2016-02-16 12:39:34 --> Helper loaded: url_helper
INFO - 2016-02-16 12:39:34 --> Helper loaded: file_helper
INFO - 2016-02-16 12:39:34 --> Helper loaded: date_helper
INFO - 2016-02-16 12:39:34 --> Helper loaded: form_helper
INFO - 2016-02-16 12:39:34 --> Database Driver Class Initialized
INFO - 2016-02-16 12:39:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:39:35 --> Controller Class Initialized
INFO - 2016-02-16 12:39:35 --> Model Class Initialized
INFO - 2016-02-16 12:39:35 --> Model Class Initialized
INFO - 2016-02-16 12:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:39:35 --> Pagination Class Initialized
INFO - 2016-02-16 12:39:35 --> Helper loaded: text_helper
INFO - 2016-02-16 12:39:35 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:39:35 --> Form Validation Class Initialized
INFO - 2016-02-16 15:39:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 15:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:39:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:39:35 --> Final output sent to browser
DEBUG - 2016-02-16 15:39:35 --> Total execution time: 1.1682
INFO - 2016-02-16 12:40:54 --> Config Class Initialized
INFO - 2016-02-16 12:40:54 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:40:54 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:40:54 --> Utf8 Class Initialized
INFO - 2016-02-16 12:40:54 --> URI Class Initialized
DEBUG - 2016-02-16 12:40:54 --> No URI present. Default controller set.
INFO - 2016-02-16 12:40:54 --> Router Class Initialized
INFO - 2016-02-16 12:40:54 --> Output Class Initialized
INFO - 2016-02-16 12:40:54 --> Security Class Initialized
DEBUG - 2016-02-16 12:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:40:54 --> Input Class Initialized
INFO - 2016-02-16 12:40:54 --> Language Class Initialized
INFO - 2016-02-16 12:40:54 --> Loader Class Initialized
INFO - 2016-02-16 12:40:54 --> Helper loaded: url_helper
INFO - 2016-02-16 12:40:54 --> Helper loaded: file_helper
INFO - 2016-02-16 12:40:54 --> Helper loaded: date_helper
INFO - 2016-02-16 12:40:54 --> Helper loaded: form_helper
INFO - 2016-02-16 12:40:54 --> Database Driver Class Initialized
INFO - 2016-02-16 12:40:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:40:55 --> Controller Class Initialized
INFO - 2016-02-16 12:40:55 --> Model Class Initialized
INFO - 2016-02-16 12:40:55 --> Model Class Initialized
INFO - 2016-02-16 12:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:40:55 --> Pagination Class Initialized
INFO - 2016-02-16 12:40:55 --> Helper loaded: text_helper
INFO - 2016-02-16 12:40:55 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:40:55 --> Final output sent to browser
DEBUG - 2016-02-16 15:40:55 --> Total execution time: 1.1384
INFO - 2016-02-16 12:40:57 --> Config Class Initialized
INFO - 2016-02-16 12:40:57 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:40:57 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:40:57 --> Utf8 Class Initialized
INFO - 2016-02-16 12:40:57 --> URI Class Initialized
INFO - 2016-02-16 12:40:57 --> Router Class Initialized
INFO - 2016-02-16 12:40:57 --> Output Class Initialized
INFO - 2016-02-16 12:40:57 --> Security Class Initialized
DEBUG - 2016-02-16 12:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:40:57 --> Input Class Initialized
INFO - 2016-02-16 12:40:57 --> Language Class Initialized
INFO - 2016-02-16 12:40:57 --> Loader Class Initialized
INFO - 2016-02-16 12:40:57 --> Helper loaded: url_helper
INFO - 2016-02-16 12:40:57 --> Helper loaded: file_helper
INFO - 2016-02-16 12:40:57 --> Helper loaded: date_helper
INFO - 2016-02-16 12:40:57 --> Helper loaded: form_helper
INFO - 2016-02-16 12:40:57 --> Database Driver Class Initialized
INFO - 2016-02-16 12:40:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:40:58 --> Controller Class Initialized
INFO - 2016-02-16 12:40:58 --> Model Class Initialized
INFO - 2016-02-16 12:40:58 --> Model Class Initialized
INFO - 2016-02-16 12:40:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:40:58 --> Pagination Class Initialized
INFO - 2016-02-16 12:40:58 --> Helper loaded: text_helper
INFO - 2016-02-16 12:40:58 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:40:58 --> Form Validation Class Initialized
INFO - 2016-02-16 15:40:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 12:47:14 --> Config Class Initialized
INFO - 2016-02-16 12:47:14 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:47:14 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:47:14 --> Utf8 Class Initialized
INFO - 2016-02-16 12:47:14 --> URI Class Initialized
INFO - 2016-02-16 12:47:14 --> Router Class Initialized
INFO - 2016-02-16 12:47:14 --> Output Class Initialized
INFO - 2016-02-16 12:47:14 --> Security Class Initialized
DEBUG - 2016-02-16 12:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:47:14 --> Input Class Initialized
INFO - 2016-02-16 12:47:14 --> Language Class Initialized
INFO - 2016-02-16 12:47:14 --> Loader Class Initialized
INFO - 2016-02-16 12:47:14 --> Helper loaded: url_helper
INFO - 2016-02-16 12:47:14 --> Helper loaded: file_helper
INFO - 2016-02-16 12:47:14 --> Helper loaded: date_helper
INFO - 2016-02-16 12:47:14 --> Helper loaded: form_helper
INFO - 2016-02-16 12:47:14 --> Database Driver Class Initialized
INFO - 2016-02-16 12:47:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:47:15 --> Controller Class Initialized
INFO - 2016-02-16 12:47:15 --> Model Class Initialized
INFO - 2016-02-16 12:47:15 --> Model Class Initialized
INFO - 2016-02-16 12:47:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:47:15 --> Pagination Class Initialized
INFO - 2016-02-16 12:47:15 --> Helper loaded: text_helper
INFO - 2016-02-16 12:47:15 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:47:15 --> Form Validation Class Initialized
INFO - 2016-02-16 15:47:15 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-16 15:47:15 --> Severity: Notice --> Undefined variable: data C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 340
INFO - 2016-02-16 15:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:47:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:47:15 --> Final output sent to browser
DEBUG - 2016-02-16 15:47:15 --> Total execution time: 1.1801
INFO - 2016-02-16 12:47:55 --> Config Class Initialized
INFO - 2016-02-16 12:47:55 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:47:55 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:47:55 --> Utf8 Class Initialized
INFO - 2016-02-16 12:47:55 --> URI Class Initialized
DEBUG - 2016-02-16 12:47:55 --> No URI present. Default controller set.
INFO - 2016-02-16 12:47:55 --> Router Class Initialized
INFO - 2016-02-16 12:47:55 --> Output Class Initialized
INFO - 2016-02-16 12:47:55 --> Security Class Initialized
DEBUG - 2016-02-16 12:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:47:55 --> Input Class Initialized
INFO - 2016-02-16 12:47:55 --> Language Class Initialized
INFO - 2016-02-16 12:47:55 --> Loader Class Initialized
INFO - 2016-02-16 12:47:55 --> Helper loaded: url_helper
INFO - 2016-02-16 12:47:55 --> Helper loaded: file_helper
INFO - 2016-02-16 12:47:55 --> Helper loaded: date_helper
INFO - 2016-02-16 12:47:55 --> Helper loaded: form_helper
INFO - 2016-02-16 12:47:55 --> Database Driver Class Initialized
INFO - 2016-02-16 12:47:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:47:56 --> Controller Class Initialized
INFO - 2016-02-16 12:47:56 --> Model Class Initialized
INFO - 2016-02-16 12:47:56 --> Model Class Initialized
INFO - 2016-02-16 12:47:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:47:56 --> Pagination Class Initialized
INFO - 2016-02-16 12:47:56 --> Helper loaded: text_helper
INFO - 2016-02-16 12:47:56 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:47:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:47:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:47:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:47:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:47:56 --> Final output sent to browser
DEBUG - 2016-02-16 15:47:56 --> Total execution time: 1.1245
INFO - 2016-02-16 12:47:58 --> Config Class Initialized
INFO - 2016-02-16 12:47:58 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:47:58 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:47:58 --> Utf8 Class Initialized
INFO - 2016-02-16 12:47:58 --> URI Class Initialized
INFO - 2016-02-16 12:47:58 --> Router Class Initialized
INFO - 2016-02-16 12:47:58 --> Output Class Initialized
INFO - 2016-02-16 12:47:58 --> Security Class Initialized
DEBUG - 2016-02-16 12:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:47:58 --> Input Class Initialized
INFO - 2016-02-16 12:47:58 --> Language Class Initialized
INFO - 2016-02-16 12:47:58 --> Loader Class Initialized
INFO - 2016-02-16 12:47:58 --> Helper loaded: url_helper
INFO - 2016-02-16 12:47:58 --> Helper loaded: file_helper
INFO - 2016-02-16 12:47:58 --> Helper loaded: date_helper
INFO - 2016-02-16 12:47:58 --> Helper loaded: form_helper
INFO - 2016-02-16 12:47:58 --> Database Driver Class Initialized
INFO - 2016-02-16 12:47:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:47:59 --> Controller Class Initialized
INFO - 2016-02-16 12:47:59 --> Model Class Initialized
INFO - 2016-02-16 12:47:59 --> Model Class Initialized
INFO - 2016-02-16 12:47:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:47:59 --> Pagination Class Initialized
INFO - 2016-02-16 12:47:59 --> Helper loaded: text_helper
INFO - 2016-02-16 12:47:59 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:47:59 --> Form Validation Class Initialized
INFO - 2016-02-16 15:47:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 15:47:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:47:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:47:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:47:59 --> Final output sent to browser
DEBUG - 2016-02-16 15:47:59 --> Total execution time: 1.1664
INFO - 2016-02-16 12:48:03 --> Config Class Initialized
INFO - 2016-02-16 12:48:03 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:48:03 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:48:03 --> Utf8 Class Initialized
INFO - 2016-02-16 12:48:03 --> URI Class Initialized
DEBUG - 2016-02-16 12:48:03 --> No URI present. Default controller set.
INFO - 2016-02-16 12:48:03 --> Router Class Initialized
INFO - 2016-02-16 12:48:03 --> Output Class Initialized
INFO - 2016-02-16 12:48:03 --> Security Class Initialized
DEBUG - 2016-02-16 12:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:48:03 --> Input Class Initialized
INFO - 2016-02-16 12:48:03 --> Language Class Initialized
INFO - 2016-02-16 12:48:03 --> Loader Class Initialized
INFO - 2016-02-16 12:48:03 --> Helper loaded: url_helper
INFO - 2016-02-16 12:48:03 --> Helper loaded: file_helper
INFO - 2016-02-16 12:48:03 --> Helper loaded: date_helper
INFO - 2016-02-16 12:48:03 --> Helper loaded: form_helper
INFO - 2016-02-16 12:48:03 --> Database Driver Class Initialized
INFO - 2016-02-16 12:48:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:48:04 --> Controller Class Initialized
INFO - 2016-02-16 12:48:04 --> Model Class Initialized
INFO - 2016-02-16 12:48:04 --> Model Class Initialized
INFO - 2016-02-16 12:48:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:48:04 --> Pagination Class Initialized
INFO - 2016-02-16 12:48:04 --> Helper loaded: text_helper
INFO - 2016-02-16 12:48:04 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:48:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:48:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:48:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:48:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:48:04 --> Final output sent to browser
DEBUG - 2016-02-16 15:48:04 --> Total execution time: 1.1385
INFO - 2016-02-16 12:49:07 --> Config Class Initialized
INFO - 2016-02-16 12:49:07 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:49:07 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:49:07 --> Utf8 Class Initialized
INFO - 2016-02-16 12:49:07 --> URI Class Initialized
DEBUG - 2016-02-16 12:49:07 --> No URI present. Default controller set.
INFO - 2016-02-16 12:49:07 --> Router Class Initialized
INFO - 2016-02-16 12:49:07 --> Output Class Initialized
INFO - 2016-02-16 12:49:07 --> Security Class Initialized
DEBUG - 2016-02-16 12:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:49:07 --> Input Class Initialized
INFO - 2016-02-16 12:49:07 --> Language Class Initialized
INFO - 2016-02-16 12:49:07 --> Loader Class Initialized
INFO - 2016-02-16 12:49:07 --> Helper loaded: url_helper
INFO - 2016-02-16 12:49:07 --> Helper loaded: file_helper
INFO - 2016-02-16 12:49:07 --> Helper loaded: date_helper
INFO - 2016-02-16 12:49:07 --> Helper loaded: form_helper
INFO - 2016-02-16 12:49:07 --> Database Driver Class Initialized
INFO - 2016-02-16 12:49:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:49:08 --> Controller Class Initialized
INFO - 2016-02-16 12:49:08 --> Model Class Initialized
INFO - 2016-02-16 12:49:08 --> Model Class Initialized
INFO - 2016-02-16 12:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:49:08 --> Pagination Class Initialized
INFO - 2016-02-16 12:49:08 --> Helper loaded: text_helper
INFO - 2016-02-16 12:49:08 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:49:08 --> Final output sent to browser
DEBUG - 2016-02-16 15:49:08 --> Total execution time: 1.1492
INFO - 2016-02-16 12:51:27 --> Config Class Initialized
INFO - 2016-02-16 12:51:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:51:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:51:27 --> Utf8 Class Initialized
INFO - 2016-02-16 12:51:27 --> URI Class Initialized
DEBUG - 2016-02-16 12:51:27 --> No URI present. Default controller set.
INFO - 2016-02-16 12:51:27 --> Router Class Initialized
INFO - 2016-02-16 12:51:27 --> Output Class Initialized
INFO - 2016-02-16 12:51:27 --> Security Class Initialized
DEBUG - 2016-02-16 12:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:51:27 --> Input Class Initialized
INFO - 2016-02-16 12:51:27 --> Language Class Initialized
INFO - 2016-02-16 12:51:27 --> Loader Class Initialized
INFO - 2016-02-16 12:51:27 --> Helper loaded: url_helper
INFO - 2016-02-16 12:51:27 --> Helper loaded: file_helper
INFO - 2016-02-16 12:51:27 --> Helper loaded: date_helper
INFO - 2016-02-16 12:51:27 --> Helper loaded: form_helper
INFO - 2016-02-16 12:51:27 --> Database Driver Class Initialized
INFO - 2016-02-16 12:51:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:51:28 --> Controller Class Initialized
INFO - 2016-02-16 12:51:28 --> Model Class Initialized
INFO - 2016-02-16 12:51:28 --> Model Class Initialized
INFO - 2016-02-16 12:51:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:51:28 --> Pagination Class Initialized
INFO - 2016-02-16 12:51:28 --> Helper loaded: text_helper
INFO - 2016-02-16 12:51:28 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:51:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:51:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:51:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:51:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:51:28 --> Final output sent to browser
DEBUG - 2016-02-16 15:51:28 --> Total execution time: 1.1755
INFO - 2016-02-16 12:51:30 --> Config Class Initialized
INFO - 2016-02-16 12:51:30 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:51:30 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:51:30 --> Utf8 Class Initialized
INFO - 2016-02-16 12:51:30 --> URI Class Initialized
INFO - 2016-02-16 12:51:30 --> Router Class Initialized
INFO - 2016-02-16 12:51:30 --> Output Class Initialized
INFO - 2016-02-16 12:51:30 --> Security Class Initialized
DEBUG - 2016-02-16 12:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:51:30 --> Input Class Initialized
INFO - 2016-02-16 12:51:30 --> Language Class Initialized
INFO - 2016-02-16 12:51:30 --> Loader Class Initialized
INFO - 2016-02-16 12:51:30 --> Helper loaded: url_helper
INFO - 2016-02-16 12:51:30 --> Helper loaded: file_helper
INFO - 2016-02-16 12:51:30 --> Helper loaded: date_helper
INFO - 2016-02-16 12:51:30 --> Helper loaded: form_helper
INFO - 2016-02-16 12:51:30 --> Database Driver Class Initialized
INFO - 2016-02-16 12:51:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:51:31 --> Controller Class Initialized
INFO - 2016-02-16 12:51:31 --> Model Class Initialized
INFO - 2016-02-16 12:51:31 --> Model Class Initialized
INFO - 2016-02-16 12:51:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:51:31 --> Pagination Class Initialized
INFO - 2016-02-16 12:51:31 --> Helper loaded: text_helper
INFO - 2016-02-16 12:51:31 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:51:31 --> Form Validation Class Initialized
INFO - 2016-02-16 15:51:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 15:51:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:51:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:51:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:51:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:51:31 --> Final output sent to browser
DEBUG - 2016-02-16 15:51:31 --> Total execution time: 1.1659
INFO - 2016-02-16 12:52:02 --> Config Class Initialized
INFO - 2016-02-16 12:52:02 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:52:02 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:52:02 --> Utf8 Class Initialized
INFO - 2016-02-16 12:52:02 --> URI Class Initialized
DEBUG - 2016-02-16 12:52:02 --> No URI present. Default controller set.
INFO - 2016-02-16 12:52:02 --> Router Class Initialized
INFO - 2016-02-16 12:52:02 --> Output Class Initialized
INFO - 2016-02-16 12:52:02 --> Security Class Initialized
DEBUG - 2016-02-16 12:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:52:02 --> Input Class Initialized
INFO - 2016-02-16 12:52:02 --> Language Class Initialized
INFO - 2016-02-16 12:52:02 --> Loader Class Initialized
INFO - 2016-02-16 12:52:02 --> Helper loaded: url_helper
INFO - 2016-02-16 12:52:02 --> Helper loaded: file_helper
INFO - 2016-02-16 12:52:02 --> Helper loaded: date_helper
INFO - 2016-02-16 12:52:02 --> Helper loaded: form_helper
INFO - 2016-02-16 12:52:02 --> Database Driver Class Initialized
INFO - 2016-02-16 12:52:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:52:03 --> Controller Class Initialized
INFO - 2016-02-16 12:52:03 --> Model Class Initialized
INFO - 2016-02-16 12:52:03 --> Model Class Initialized
INFO - 2016-02-16 12:52:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:52:03 --> Pagination Class Initialized
INFO - 2016-02-16 12:52:03 --> Helper loaded: text_helper
INFO - 2016-02-16 12:52:03 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:52:03 --> Final output sent to browser
DEBUG - 2016-02-16 15:52:03 --> Total execution time: 1.1737
INFO - 2016-02-16 12:52:05 --> Config Class Initialized
INFO - 2016-02-16 12:52:05 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:52:05 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:52:05 --> Utf8 Class Initialized
INFO - 2016-02-16 12:52:05 --> URI Class Initialized
INFO - 2016-02-16 12:52:05 --> Router Class Initialized
INFO - 2016-02-16 12:52:05 --> Output Class Initialized
INFO - 2016-02-16 12:52:05 --> Security Class Initialized
DEBUG - 2016-02-16 12:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:52:05 --> Input Class Initialized
INFO - 2016-02-16 12:52:05 --> Language Class Initialized
INFO - 2016-02-16 12:52:05 --> Loader Class Initialized
INFO - 2016-02-16 12:52:05 --> Helper loaded: url_helper
INFO - 2016-02-16 12:52:05 --> Helper loaded: file_helper
INFO - 2016-02-16 12:52:05 --> Helper loaded: date_helper
INFO - 2016-02-16 12:52:05 --> Helper loaded: form_helper
INFO - 2016-02-16 12:52:05 --> Database Driver Class Initialized
INFO - 2016-02-16 12:52:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:52:06 --> Controller Class Initialized
INFO - 2016-02-16 12:52:06 --> Model Class Initialized
INFO - 2016-02-16 12:52:06 --> Model Class Initialized
INFO - 2016-02-16 12:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:52:06 --> Pagination Class Initialized
INFO - 2016-02-16 12:52:06 --> Helper loaded: text_helper
INFO - 2016-02-16 12:52:06 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:52:06 --> Form Validation Class Initialized
INFO - 2016-02-16 15:52:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 15:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:52:06 --> Final output sent to browser
DEBUG - 2016-02-16 15:52:06 --> Total execution time: 1.1526
INFO - 2016-02-16 12:52:53 --> Config Class Initialized
INFO - 2016-02-16 12:52:53 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:52:53 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:52:53 --> Utf8 Class Initialized
INFO - 2016-02-16 12:52:53 --> URI Class Initialized
DEBUG - 2016-02-16 12:52:53 --> No URI present. Default controller set.
INFO - 2016-02-16 12:52:53 --> Router Class Initialized
INFO - 2016-02-16 12:52:53 --> Output Class Initialized
INFO - 2016-02-16 12:52:53 --> Security Class Initialized
DEBUG - 2016-02-16 12:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:52:53 --> Input Class Initialized
INFO - 2016-02-16 12:52:53 --> Language Class Initialized
INFO - 2016-02-16 12:52:53 --> Loader Class Initialized
INFO - 2016-02-16 12:52:53 --> Helper loaded: url_helper
INFO - 2016-02-16 12:52:53 --> Helper loaded: file_helper
INFO - 2016-02-16 12:52:53 --> Helper loaded: date_helper
INFO - 2016-02-16 12:52:53 --> Helper loaded: form_helper
INFO - 2016-02-16 12:52:53 --> Database Driver Class Initialized
INFO - 2016-02-16 12:52:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:52:54 --> Controller Class Initialized
INFO - 2016-02-16 12:52:54 --> Model Class Initialized
INFO - 2016-02-16 12:52:54 --> Model Class Initialized
INFO - 2016-02-16 12:52:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:52:54 --> Pagination Class Initialized
INFO - 2016-02-16 12:52:54 --> Helper loaded: text_helper
INFO - 2016-02-16 12:52:54 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:52:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:52:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:52:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:52:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:52:54 --> Final output sent to browser
DEBUG - 2016-02-16 15:52:54 --> Total execution time: 1.1245
INFO - 2016-02-16 12:52:55 --> Config Class Initialized
INFO - 2016-02-16 12:52:55 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:52:55 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:52:55 --> Utf8 Class Initialized
INFO - 2016-02-16 12:52:55 --> URI Class Initialized
INFO - 2016-02-16 12:52:55 --> Router Class Initialized
INFO - 2016-02-16 12:52:55 --> Output Class Initialized
INFO - 2016-02-16 12:52:55 --> Security Class Initialized
DEBUG - 2016-02-16 12:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:52:55 --> Input Class Initialized
INFO - 2016-02-16 12:52:55 --> Language Class Initialized
INFO - 2016-02-16 12:52:55 --> Loader Class Initialized
INFO - 2016-02-16 12:52:55 --> Helper loaded: url_helper
INFO - 2016-02-16 12:52:55 --> Helper loaded: file_helper
INFO - 2016-02-16 12:52:55 --> Helper loaded: date_helper
INFO - 2016-02-16 12:52:55 --> Helper loaded: form_helper
INFO - 2016-02-16 12:52:55 --> Database Driver Class Initialized
INFO - 2016-02-16 12:52:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:52:56 --> Controller Class Initialized
INFO - 2016-02-16 12:52:56 --> Model Class Initialized
INFO - 2016-02-16 12:52:56 --> Model Class Initialized
INFO - 2016-02-16 12:52:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:52:56 --> Pagination Class Initialized
INFO - 2016-02-16 12:52:56 --> Helper loaded: text_helper
INFO - 2016-02-16 12:52:56 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:52:56 --> Form Validation Class Initialized
INFO - 2016-02-16 15:52:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 15:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:52:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:52:56 --> Final output sent to browser
DEBUG - 2016-02-16 15:52:56 --> Total execution time: 1.1222
INFO - 2016-02-16 12:53:54 --> Config Class Initialized
INFO - 2016-02-16 12:53:54 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:53:54 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:53:54 --> Utf8 Class Initialized
INFO - 2016-02-16 12:53:54 --> URI Class Initialized
DEBUG - 2016-02-16 12:53:54 --> No URI present. Default controller set.
INFO - 2016-02-16 12:53:54 --> Router Class Initialized
INFO - 2016-02-16 12:53:54 --> Output Class Initialized
INFO - 2016-02-16 12:53:54 --> Security Class Initialized
DEBUG - 2016-02-16 12:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:53:54 --> Input Class Initialized
INFO - 2016-02-16 12:53:54 --> Language Class Initialized
INFO - 2016-02-16 12:53:54 --> Loader Class Initialized
INFO - 2016-02-16 12:53:54 --> Helper loaded: url_helper
INFO - 2016-02-16 12:53:54 --> Helper loaded: file_helper
INFO - 2016-02-16 12:53:54 --> Helper loaded: date_helper
INFO - 2016-02-16 12:53:54 --> Helper loaded: form_helper
INFO - 2016-02-16 12:53:54 --> Database Driver Class Initialized
INFO - 2016-02-16 12:53:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:53:55 --> Controller Class Initialized
INFO - 2016-02-16 12:53:55 --> Model Class Initialized
INFO - 2016-02-16 12:53:55 --> Model Class Initialized
INFO - 2016-02-16 12:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:53:55 --> Pagination Class Initialized
INFO - 2016-02-16 12:53:55 --> Helper loaded: text_helper
INFO - 2016-02-16 12:53:55 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:53:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:53:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:53:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:53:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:53:55 --> Final output sent to browser
DEBUG - 2016-02-16 15:53:55 --> Total execution time: 1.1729
INFO - 2016-02-16 12:53:56 --> Config Class Initialized
INFO - 2016-02-16 12:53:56 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:53:56 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:53:56 --> Utf8 Class Initialized
INFO - 2016-02-16 12:53:56 --> URI Class Initialized
INFO - 2016-02-16 12:53:56 --> Router Class Initialized
INFO - 2016-02-16 12:53:56 --> Output Class Initialized
INFO - 2016-02-16 12:53:56 --> Security Class Initialized
DEBUG - 2016-02-16 12:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:53:56 --> Input Class Initialized
INFO - 2016-02-16 12:53:56 --> Language Class Initialized
INFO - 2016-02-16 12:53:56 --> Loader Class Initialized
INFO - 2016-02-16 12:53:56 --> Helper loaded: url_helper
INFO - 2016-02-16 12:53:56 --> Helper loaded: file_helper
INFO - 2016-02-16 12:53:56 --> Helper loaded: date_helper
INFO - 2016-02-16 12:53:56 --> Helper loaded: form_helper
INFO - 2016-02-16 12:53:56 --> Database Driver Class Initialized
INFO - 2016-02-16 12:53:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:53:57 --> Controller Class Initialized
INFO - 2016-02-16 12:53:57 --> Model Class Initialized
INFO - 2016-02-16 12:53:57 --> Model Class Initialized
INFO - 2016-02-16 12:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:53:57 --> Pagination Class Initialized
INFO - 2016-02-16 12:53:57 --> Helper loaded: text_helper
INFO - 2016-02-16 12:53:57 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:53:57 --> Form Validation Class Initialized
INFO - 2016-02-16 15:53:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 15:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-16 15:53:57 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-16 15:53:57 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-16 15:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
ERROR - 2016-02-16 15:53:57 --> Severity: Warning --> Cannot use a scalar value as an array C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 358
INFO - 2016-02-16 15:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-16 15:53:57 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-16 15:53:57 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-16 15:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:53:57 --> Final output sent to browser
DEBUG - 2016-02-16 15:53:57 --> Total execution time: 1.1474
INFO - 2016-02-16 12:56:24 --> Config Class Initialized
INFO - 2016-02-16 12:56:24 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:56:24 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:56:24 --> Utf8 Class Initialized
INFO - 2016-02-16 12:56:24 --> URI Class Initialized
DEBUG - 2016-02-16 12:56:24 --> No URI present. Default controller set.
INFO - 2016-02-16 12:56:24 --> Router Class Initialized
INFO - 2016-02-16 12:56:24 --> Output Class Initialized
INFO - 2016-02-16 12:56:24 --> Security Class Initialized
DEBUG - 2016-02-16 12:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:56:24 --> Input Class Initialized
INFO - 2016-02-16 12:56:24 --> Language Class Initialized
INFO - 2016-02-16 12:56:24 --> Loader Class Initialized
INFO - 2016-02-16 12:56:24 --> Helper loaded: url_helper
INFO - 2016-02-16 12:56:24 --> Helper loaded: file_helper
INFO - 2016-02-16 12:56:24 --> Helper loaded: date_helper
INFO - 2016-02-16 12:56:24 --> Helper loaded: form_helper
INFO - 2016-02-16 12:56:24 --> Database Driver Class Initialized
INFO - 2016-02-16 12:56:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:56:25 --> Controller Class Initialized
INFO - 2016-02-16 12:56:25 --> Model Class Initialized
INFO - 2016-02-16 12:56:25 --> Model Class Initialized
INFO - 2016-02-16 12:56:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:56:25 --> Pagination Class Initialized
INFO - 2016-02-16 12:56:25 --> Helper loaded: text_helper
INFO - 2016-02-16 12:56:25 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:56:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:56:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:56:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 15:56:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 15:56:25 --> Final output sent to browser
DEBUG - 2016-02-16 15:56:25 --> Total execution time: 1.1759
INFO - 2016-02-16 12:56:27 --> Config Class Initialized
INFO - 2016-02-16 12:56:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 12:56:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 12:56:27 --> Utf8 Class Initialized
INFO - 2016-02-16 12:56:27 --> URI Class Initialized
INFO - 2016-02-16 12:56:27 --> Router Class Initialized
INFO - 2016-02-16 12:56:27 --> Output Class Initialized
INFO - 2016-02-16 12:56:27 --> Security Class Initialized
DEBUG - 2016-02-16 12:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 12:56:27 --> Input Class Initialized
INFO - 2016-02-16 12:56:27 --> Language Class Initialized
INFO - 2016-02-16 12:56:27 --> Loader Class Initialized
INFO - 2016-02-16 12:56:27 --> Helper loaded: url_helper
INFO - 2016-02-16 12:56:27 --> Helper loaded: file_helper
INFO - 2016-02-16 12:56:27 --> Helper loaded: date_helper
INFO - 2016-02-16 12:56:27 --> Helper loaded: form_helper
INFO - 2016-02-16 12:56:27 --> Database Driver Class Initialized
INFO - 2016-02-16 12:56:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 12:56:28 --> Controller Class Initialized
INFO - 2016-02-16 12:56:28 --> Model Class Initialized
INFO - 2016-02-16 12:56:28 --> Model Class Initialized
INFO - 2016-02-16 12:56:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 12:56:28 --> Pagination Class Initialized
INFO - 2016-02-16 12:56:28 --> Helper loaded: text_helper
INFO - 2016-02-16 12:56:28 --> Helper loaded: cookie_helper
INFO - 2016-02-16 15:56:28 --> Form Validation Class Initialized
INFO - 2016-02-16 15:56:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 15:56:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:56:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-16 15:56:28 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-16 15:56:28 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-16 15:56:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:56:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 15:56:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 15:56:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 15:56:28 --> Final output sent to browser
DEBUG - 2016-02-16 15:56:28 --> Total execution time: 1.1844
INFO - 2016-02-16 13:00:47 --> Config Class Initialized
INFO - 2016-02-16 13:00:47 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:00:47 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:00:47 --> Utf8 Class Initialized
INFO - 2016-02-16 13:00:47 --> URI Class Initialized
DEBUG - 2016-02-16 13:00:47 --> No URI present. Default controller set.
INFO - 2016-02-16 13:00:47 --> Router Class Initialized
INFO - 2016-02-16 13:00:47 --> Output Class Initialized
INFO - 2016-02-16 13:00:47 --> Security Class Initialized
DEBUG - 2016-02-16 13:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:00:47 --> Input Class Initialized
INFO - 2016-02-16 13:00:47 --> Language Class Initialized
INFO - 2016-02-16 13:00:47 --> Loader Class Initialized
INFO - 2016-02-16 13:00:47 --> Helper loaded: url_helper
INFO - 2016-02-16 13:00:47 --> Helper loaded: file_helper
INFO - 2016-02-16 13:00:47 --> Helper loaded: date_helper
INFO - 2016-02-16 13:00:47 --> Helper loaded: form_helper
INFO - 2016-02-16 13:00:47 --> Database Driver Class Initialized
INFO - 2016-02-16 13:00:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:00:48 --> Controller Class Initialized
INFO - 2016-02-16 13:00:48 --> Model Class Initialized
INFO - 2016-02-16 13:00:48 --> Model Class Initialized
INFO - 2016-02-16 13:00:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:00:48 --> Pagination Class Initialized
INFO - 2016-02-16 13:00:48 --> Helper loaded: text_helper
INFO - 2016-02-16 13:00:48 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 16:00:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 16:00:48 --> Final output sent to browser
DEBUG - 2016-02-16 16:00:48 --> Total execution time: 1.1259
INFO - 2016-02-16 13:06:35 --> Config Class Initialized
INFO - 2016-02-16 13:06:35 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:06:35 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:06:35 --> Utf8 Class Initialized
INFO - 2016-02-16 13:06:35 --> URI Class Initialized
DEBUG - 2016-02-16 13:06:35 --> No URI present. Default controller set.
INFO - 2016-02-16 13:06:35 --> Router Class Initialized
INFO - 2016-02-16 13:06:35 --> Output Class Initialized
INFO - 2016-02-16 13:06:35 --> Security Class Initialized
DEBUG - 2016-02-16 13:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:06:35 --> Input Class Initialized
INFO - 2016-02-16 13:06:35 --> Language Class Initialized
INFO - 2016-02-16 13:06:35 --> Loader Class Initialized
INFO - 2016-02-16 13:06:35 --> Helper loaded: url_helper
INFO - 2016-02-16 13:06:35 --> Helper loaded: file_helper
INFO - 2016-02-16 13:06:35 --> Helper loaded: date_helper
INFO - 2016-02-16 13:06:35 --> Helper loaded: form_helper
INFO - 2016-02-16 13:06:35 --> Database Driver Class Initialized
INFO - 2016-02-16 13:06:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:06:36 --> Controller Class Initialized
INFO - 2016-02-16 13:06:36 --> Model Class Initialized
INFO - 2016-02-16 13:06:36 --> Model Class Initialized
INFO - 2016-02-16 13:06:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:06:36 --> Pagination Class Initialized
INFO - 2016-02-16 13:06:36 --> Helper loaded: text_helper
INFO - 2016-02-16 13:06:36 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 16:06:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 16:06:36 --> Final output sent to browser
DEBUG - 2016-02-16 16:06:36 --> Total execution time: 1.1097
INFO - 2016-02-16 13:06:38 --> Config Class Initialized
INFO - 2016-02-16 13:06:38 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:06:38 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:06:38 --> Utf8 Class Initialized
INFO - 2016-02-16 13:06:38 --> URI Class Initialized
INFO - 2016-02-16 13:06:38 --> Router Class Initialized
INFO - 2016-02-16 13:06:38 --> Output Class Initialized
INFO - 2016-02-16 13:06:38 --> Security Class Initialized
DEBUG - 2016-02-16 13:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:06:38 --> Input Class Initialized
INFO - 2016-02-16 13:06:38 --> Language Class Initialized
INFO - 2016-02-16 13:06:38 --> Loader Class Initialized
INFO - 2016-02-16 13:06:38 --> Helper loaded: url_helper
INFO - 2016-02-16 13:06:38 --> Helper loaded: file_helper
INFO - 2016-02-16 13:06:38 --> Helper loaded: date_helper
INFO - 2016-02-16 13:06:38 --> Helper loaded: form_helper
INFO - 2016-02-16 13:06:38 --> Database Driver Class Initialized
INFO - 2016-02-16 13:06:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:06:39 --> Controller Class Initialized
INFO - 2016-02-16 13:06:39 --> Model Class Initialized
INFO - 2016-02-16 13:06:39 --> Model Class Initialized
INFO - 2016-02-16 13:06:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:06:39 --> Pagination Class Initialized
INFO - 2016-02-16 13:06:39 --> Helper loaded: text_helper
INFO - 2016-02-16 13:06:39 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:06:39 --> Form Validation Class Initialized
INFO - 2016-02-16 16:06:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 16:06:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:06:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-16 16:06:39 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-16 16:06:39 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-16 16:06:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:06:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:06:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:06:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:06:39 --> Final output sent to browser
DEBUG - 2016-02-16 16:06:39 --> Total execution time: 1.1467
INFO - 2016-02-16 13:07:27 --> Config Class Initialized
INFO - 2016-02-16 13:07:27 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:07:27 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:07:27 --> Utf8 Class Initialized
INFO - 2016-02-16 13:07:27 --> URI Class Initialized
DEBUG - 2016-02-16 13:07:27 --> No URI present. Default controller set.
INFO - 2016-02-16 13:07:27 --> Router Class Initialized
INFO - 2016-02-16 13:07:27 --> Output Class Initialized
INFO - 2016-02-16 13:07:27 --> Security Class Initialized
DEBUG - 2016-02-16 13:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:07:27 --> Input Class Initialized
INFO - 2016-02-16 13:07:27 --> Language Class Initialized
INFO - 2016-02-16 13:07:27 --> Loader Class Initialized
INFO - 2016-02-16 13:07:27 --> Helper loaded: url_helper
INFO - 2016-02-16 13:07:27 --> Helper loaded: file_helper
INFO - 2016-02-16 13:07:27 --> Helper loaded: date_helper
INFO - 2016-02-16 13:07:27 --> Helper loaded: form_helper
INFO - 2016-02-16 13:07:27 --> Database Driver Class Initialized
INFO - 2016-02-16 13:07:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:07:28 --> Controller Class Initialized
INFO - 2016-02-16 13:07:28 --> Model Class Initialized
INFO - 2016-02-16 13:07:28 --> Model Class Initialized
INFO - 2016-02-16 13:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:07:28 --> Pagination Class Initialized
INFO - 2016-02-16 13:07:28 --> Helper loaded: text_helper
INFO - 2016-02-16 13:07:28 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:07:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:07:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:07:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 16:07:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 16:07:28 --> Final output sent to browser
DEBUG - 2016-02-16 16:07:28 --> Total execution time: 1.1164
INFO - 2016-02-16 13:07:29 --> Config Class Initialized
INFO - 2016-02-16 13:07:29 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:07:29 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:07:29 --> Utf8 Class Initialized
INFO - 2016-02-16 13:07:29 --> URI Class Initialized
INFO - 2016-02-16 13:07:29 --> Router Class Initialized
INFO - 2016-02-16 13:07:29 --> Output Class Initialized
INFO - 2016-02-16 13:07:29 --> Security Class Initialized
DEBUG - 2016-02-16 13:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:07:29 --> Input Class Initialized
INFO - 2016-02-16 13:07:29 --> Language Class Initialized
INFO - 2016-02-16 13:07:29 --> Loader Class Initialized
INFO - 2016-02-16 13:07:29 --> Helper loaded: url_helper
INFO - 2016-02-16 13:07:29 --> Helper loaded: file_helper
INFO - 2016-02-16 13:07:29 --> Helper loaded: date_helper
INFO - 2016-02-16 13:07:29 --> Helper loaded: form_helper
INFO - 2016-02-16 13:07:29 --> Database Driver Class Initialized
INFO - 2016-02-16 13:07:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:07:30 --> Controller Class Initialized
INFO - 2016-02-16 13:07:30 --> Model Class Initialized
INFO - 2016-02-16 13:07:30 --> Model Class Initialized
INFO - 2016-02-16 13:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:07:30 --> Pagination Class Initialized
INFO - 2016-02-16 13:07:30 --> Helper loaded: text_helper
INFO - 2016-02-16 13:07:30 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:07:30 --> Form Validation Class Initialized
INFO - 2016-02-16 16:07:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 16:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-16 16:07:30 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-16 16:07:30 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-16 16:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:07:30 --> Final output sent to browser
DEBUG - 2016-02-16 16:07:30 --> Total execution time: 1.1482
INFO - 2016-02-16 13:11:29 --> Config Class Initialized
INFO - 2016-02-16 13:11:29 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:11:29 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:11:29 --> Utf8 Class Initialized
INFO - 2016-02-16 13:11:29 --> URI Class Initialized
DEBUG - 2016-02-16 13:11:29 --> No URI present. Default controller set.
INFO - 2016-02-16 13:11:29 --> Router Class Initialized
INFO - 2016-02-16 13:11:29 --> Output Class Initialized
INFO - 2016-02-16 13:11:29 --> Security Class Initialized
DEBUG - 2016-02-16 13:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:11:29 --> Input Class Initialized
INFO - 2016-02-16 13:11:29 --> Language Class Initialized
INFO - 2016-02-16 13:11:29 --> Loader Class Initialized
INFO - 2016-02-16 13:11:29 --> Helper loaded: url_helper
INFO - 2016-02-16 13:11:29 --> Helper loaded: file_helper
INFO - 2016-02-16 13:11:29 --> Helper loaded: date_helper
INFO - 2016-02-16 13:11:29 --> Helper loaded: form_helper
INFO - 2016-02-16 13:11:29 --> Database Driver Class Initialized
INFO - 2016-02-16 13:11:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:11:30 --> Controller Class Initialized
INFO - 2016-02-16 13:11:30 --> Model Class Initialized
INFO - 2016-02-16 13:11:30 --> Model Class Initialized
INFO - 2016-02-16 13:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:11:30 --> Pagination Class Initialized
INFO - 2016-02-16 13:11:30 --> Helper loaded: text_helper
INFO - 2016-02-16 13:11:30 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:11:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:11:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:11:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 16:11:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 16:11:30 --> Final output sent to browser
DEBUG - 2016-02-16 16:11:30 --> Total execution time: 1.1383
INFO - 2016-02-16 13:11:31 --> Config Class Initialized
INFO - 2016-02-16 13:11:31 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:11:31 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:11:31 --> Utf8 Class Initialized
INFO - 2016-02-16 13:11:31 --> URI Class Initialized
INFO - 2016-02-16 13:11:31 --> Router Class Initialized
INFO - 2016-02-16 13:11:31 --> Output Class Initialized
INFO - 2016-02-16 13:11:31 --> Security Class Initialized
DEBUG - 2016-02-16 13:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:11:31 --> Input Class Initialized
INFO - 2016-02-16 13:11:31 --> Language Class Initialized
INFO - 2016-02-16 13:11:31 --> Loader Class Initialized
INFO - 2016-02-16 13:11:31 --> Helper loaded: url_helper
INFO - 2016-02-16 13:11:31 --> Helper loaded: file_helper
INFO - 2016-02-16 13:11:31 --> Helper loaded: date_helper
INFO - 2016-02-16 13:11:31 --> Helper loaded: form_helper
INFO - 2016-02-16 13:11:31 --> Database Driver Class Initialized
INFO - 2016-02-16 13:11:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:11:32 --> Controller Class Initialized
INFO - 2016-02-16 13:11:32 --> Model Class Initialized
INFO - 2016-02-16 13:11:32 --> Model Class Initialized
INFO - 2016-02-16 13:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:11:32 --> Pagination Class Initialized
INFO - 2016-02-16 13:11:32 --> Helper loaded: text_helper
INFO - 2016-02-16 13:11:32 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:11:32 --> Form Validation Class Initialized
INFO - 2016-02-16 16:11:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 16:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-16 16:11:32 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-16 16:11:32 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-16 16:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:11:32 --> Final output sent to browser
DEBUG - 2016-02-16 16:11:32 --> Total execution time: 1.1826
INFO - 2016-02-16 13:12:18 --> Config Class Initialized
INFO - 2016-02-16 13:12:18 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:12:18 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:12:18 --> Utf8 Class Initialized
INFO - 2016-02-16 13:12:18 --> URI Class Initialized
DEBUG - 2016-02-16 13:12:18 --> No URI present. Default controller set.
INFO - 2016-02-16 13:12:18 --> Router Class Initialized
INFO - 2016-02-16 13:12:18 --> Output Class Initialized
INFO - 2016-02-16 13:12:18 --> Security Class Initialized
DEBUG - 2016-02-16 13:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:12:18 --> Input Class Initialized
INFO - 2016-02-16 13:12:18 --> Language Class Initialized
INFO - 2016-02-16 13:12:18 --> Loader Class Initialized
INFO - 2016-02-16 13:12:18 --> Helper loaded: url_helper
INFO - 2016-02-16 13:12:18 --> Helper loaded: file_helper
INFO - 2016-02-16 13:12:18 --> Helper loaded: date_helper
INFO - 2016-02-16 13:12:18 --> Helper loaded: form_helper
INFO - 2016-02-16 13:12:18 --> Database Driver Class Initialized
INFO - 2016-02-16 13:12:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:12:19 --> Controller Class Initialized
INFO - 2016-02-16 13:12:19 --> Model Class Initialized
INFO - 2016-02-16 13:12:19 --> Model Class Initialized
INFO - 2016-02-16 13:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:12:19 --> Pagination Class Initialized
INFO - 2016-02-16 13:12:19 --> Helper loaded: text_helper
INFO - 2016-02-16 13:12:19 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 16:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 16:12:19 --> Final output sent to browser
DEBUG - 2016-02-16 16:12:19 --> Total execution time: 1.1486
INFO - 2016-02-16 13:12:19 --> Config Class Initialized
INFO - 2016-02-16 13:12:19 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:12:19 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:12:19 --> Utf8 Class Initialized
INFO - 2016-02-16 13:12:19 --> URI Class Initialized
INFO - 2016-02-16 13:12:19 --> Router Class Initialized
INFO - 2016-02-16 13:12:19 --> Output Class Initialized
INFO - 2016-02-16 13:12:19 --> Security Class Initialized
DEBUG - 2016-02-16 13:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:12:19 --> Input Class Initialized
INFO - 2016-02-16 13:12:19 --> Language Class Initialized
INFO - 2016-02-16 13:12:19 --> Loader Class Initialized
INFO - 2016-02-16 13:12:19 --> Helper loaded: url_helper
INFO - 2016-02-16 13:12:19 --> Helper loaded: file_helper
INFO - 2016-02-16 13:12:19 --> Helper loaded: date_helper
INFO - 2016-02-16 13:12:19 --> Helper loaded: form_helper
INFO - 2016-02-16 13:12:19 --> Database Driver Class Initialized
INFO - 2016-02-16 13:12:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:12:20 --> Controller Class Initialized
INFO - 2016-02-16 13:12:20 --> Model Class Initialized
INFO - 2016-02-16 13:12:20 --> Model Class Initialized
INFO - 2016-02-16 13:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:12:20 --> Pagination Class Initialized
INFO - 2016-02-16 13:12:20 --> Helper loaded: text_helper
INFO - 2016-02-16 13:12:20 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:12:20 --> Form Validation Class Initialized
INFO - 2016-02-16 16:12:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-16 16:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-16 16:12:20 --> Severity: Notice --> Undefined variable: keyword C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 3
ERROR - 2016-02-16 16:12:20 --> Severity: Notice --> Undefined variable: search_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php 13
INFO - 2016-02-16 16:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:12:20 --> Final output sent to browser
DEBUG - 2016-02-16 16:12:20 --> Total execution time: 1.1550
INFO - 2016-02-16 13:13:13 --> Config Class Initialized
INFO - 2016-02-16 13:13:13 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:13:13 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:13:13 --> Utf8 Class Initialized
INFO - 2016-02-16 13:13:13 --> URI Class Initialized
DEBUG - 2016-02-16 13:13:13 --> No URI present. Default controller set.
INFO - 2016-02-16 13:13:13 --> Router Class Initialized
INFO - 2016-02-16 13:13:13 --> Output Class Initialized
INFO - 2016-02-16 13:13:13 --> Security Class Initialized
DEBUG - 2016-02-16 13:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:13:13 --> Input Class Initialized
INFO - 2016-02-16 13:13:13 --> Language Class Initialized
INFO - 2016-02-16 13:13:13 --> Loader Class Initialized
INFO - 2016-02-16 13:13:13 --> Helper loaded: url_helper
INFO - 2016-02-16 13:13:13 --> Helper loaded: file_helper
INFO - 2016-02-16 13:13:13 --> Helper loaded: date_helper
INFO - 2016-02-16 13:13:13 --> Helper loaded: form_helper
INFO - 2016-02-16 13:13:13 --> Database Driver Class Initialized
INFO - 2016-02-16 13:13:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:13:14 --> Controller Class Initialized
INFO - 2016-02-16 13:13:14 --> Model Class Initialized
INFO - 2016-02-16 13:13:14 --> Model Class Initialized
INFO - 2016-02-16 13:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:13:14 --> Pagination Class Initialized
INFO - 2016-02-16 13:13:14 --> Helper loaded: text_helper
INFO - 2016-02-16 13:13:14 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 16:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 16:13:14 --> Final output sent to browser
DEBUG - 2016-02-16 16:13:14 --> Total execution time: 1.1615
INFO - 2016-02-16 13:13:17 --> Config Class Initialized
INFO - 2016-02-16 13:13:17 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:13:17 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:13:17 --> Utf8 Class Initialized
INFO - 2016-02-16 13:13:17 --> URI Class Initialized
INFO - 2016-02-16 13:13:17 --> Router Class Initialized
INFO - 2016-02-16 13:13:17 --> Output Class Initialized
INFO - 2016-02-16 13:13:17 --> Security Class Initialized
DEBUG - 2016-02-16 13:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:13:17 --> Input Class Initialized
INFO - 2016-02-16 13:13:17 --> Language Class Initialized
INFO - 2016-02-16 13:13:17 --> Loader Class Initialized
INFO - 2016-02-16 13:13:17 --> Helper loaded: url_helper
INFO - 2016-02-16 13:13:17 --> Helper loaded: file_helper
INFO - 2016-02-16 13:13:17 --> Helper loaded: date_helper
INFO - 2016-02-16 13:13:17 --> Helper loaded: form_helper
INFO - 2016-02-16 13:13:17 --> Database Driver Class Initialized
INFO - 2016-02-16 13:13:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:13:18 --> Controller Class Initialized
INFO - 2016-02-16 13:13:18 --> Model Class Initialized
INFO - 2016-02-16 13:13:18 --> Model Class Initialized
INFO - 2016-02-16 13:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:13:18 --> Pagination Class Initialized
INFO - 2016-02-16 13:13:18 --> Helper loaded: text_helper
INFO - 2016-02-16 13:13:18 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:13:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:13:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:13:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:13:18 --> Final output sent to browser
DEBUG - 2016-02-16 16:13:18 --> Total execution time: 1.1694
INFO - 2016-02-16 13:13:21 --> Config Class Initialized
INFO - 2016-02-16 13:13:21 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:13:21 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:13:21 --> Utf8 Class Initialized
INFO - 2016-02-16 13:13:21 --> URI Class Initialized
INFO - 2016-02-16 13:13:21 --> Router Class Initialized
INFO - 2016-02-16 13:13:21 --> Output Class Initialized
INFO - 2016-02-16 13:13:21 --> Security Class Initialized
DEBUG - 2016-02-16 13:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:13:21 --> Input Class Initialized
INFO - 2016-02-16 13:13:21 --> Language Class Initialized
INFO - 2016-02-16 13:13:21 --> Loader Class Initialized
INFO - 2016-02-16 13:13:21 --> Helper loaded: url_helper
INFO - 2016-02-16 13:13:21 --> Helper loaded: file_helper
INFO - 2016-02-16 13:13:21 --> Helper loaded: date_helper
INFO - 2016-02-16 13:13:21 --> Helper loaded: form_helper
INFO - 2016-02-16 13:13:21 --> Database Driver Class Initialized
INFO - 2016-02-16 13:13:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:13:22 --> Controller Class Initialized
INFO - 2016-02-16 13:13:22 --> Model Class Initialized
INFO - 2016-02-16 13:13:22 --> Model Class Initialized
INFO - 2016-02-16 13:13:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:13:22 --> Pagination Class Initialized
INFO - 2016-02-16 13:13:22 --> Helper loaded: text_helper
INFO - 2016-02-16 13:13:22 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:13:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:13:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:13:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:13:22 --> Final output sent to browser
DEBUG - 2016-02-16 16:13:22 --> Total execution time: 1.1458
INFO - 2016-02-16 13:13:26 --> Config Class Initialized
INFO - 2016-02-16 13:13:26 --> Hooks Class Initialized
DEBUG - 2016-02-16 13:13:26 --> UTF-8 Support Enabled
INFO - 2016-02-16 13:13:26 --> Utf8 Class Initialized
INFO - 2016-02-16 13:13:26 --> URI Class Initialized
INFO - 2016-02-16 13:13:26 --> Router Class Initialized
INFO - 2016-02-16 13:13:26 --> Output Class Initialized
INFO - 2016-02-16 13:13:26 --> Security Class Initialized
DEBUG - 2016-02-16 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 13:13:26 --> Input Class Initialized
INFO - 2016-02-16 13:13:26 --> Language Class Initialized
INFO - 2016-02-16 13:13:26 --> Loader Class Initialized
INFO - 2016-02-16 13:13:26 --> Helper loaded: url_helper
INFO - 2016-02-16 13:13:26 --> Helper loaded: file_helper
INFO - 2016-02-16 13:13:26 --> Helper loaded: date_helper
INFO - 2016-02-16 13:13:26 --> Helper loaded: form_helper
INFO - 2016-02-16 13:13:26 --> Database Driver Class Initialized
INFO - 2016-02-16 13:13:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 13:13:27 --> Controller Class Initialized
INFO - 2016-02-16 13:13:27 --> Model Class Initialized
INFO - 2016-02-16 13:13:27 --> Model Class Initialized
INFO - 2016-02-16 13:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 13:13:27 --> Pagination Class Initialized
INFO - 2016-02-16 13:13:27 --> Helper loaded: text_helper
INFO - 2016-02-16 13:13:27 --> Helper loaded: cookie_helper
INFO - 2016-02-16 16:13:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 16:13:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 16:13:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\search_result.php
INFO - 2016-02-16 16:13:27 --> Final output sent to browser
DEBUG - 2016-02-16 16:13:27 --> Total execution time: 1.1341
INFO - 2016-02-16 14:34:12 --> Config Class Initialized
INFO - 2016-02-16 14:34:12 --> Hooks Class Initialized
DEBUG - 2016-02-16 14:34:12 --> UTF-8 Support Enabled
INFO - 2016-02-16 14:34:12 --> Utf8 Class Initialized
INFO - 2016-02-16 14:34:12 --> URI Class Initialized
DEBUG - 2016-02-16 14:34:12 --> No URI present. Default controller set.
INFO - 2016-02-16 14:34:12 --> Router Class Initialized
INFO - 2016-02-16 14:34:12 --> Output Class Initialized
INFO - 2016-02-16 14:34:12 --> Security Class Initialized
DEBUG - 2016-02-16 14:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-16 14:34:12 --> Input Class Initialized
INFO - 2016-02-16 14:34:12 --> Language Class Initialized
INFO - 2016-02-16 14:34:12 --> Loader Class Initialized
INFO - 2016-02-16 14:34:12 --> Helper loaded: url_helper
INFO - 2016-02-16 14:34:12 --> Helper loaded: file_helper
INFO - 2016-02-16 14:34:12 --> Helper loaded: date_helper
INFO - 2016-02-16 14:34:12 --> Helper loaded: form_helper
INFO - 2016-02-16 14:34:12 --> Database Driver Class Initialized
INFO - 2016-02-16 14:34:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-16 14:34:13 --> Controller Class Initialized
INFO - 2016-02-16 14:34:13 --> Model Class Initialized
INFO - 2016-02-16 14:34:13 --> Model Class Initialized
INFO - 2016-02-16 14:34:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-16 14:34:13 --> Pagination Class Initialized
INFO - 2016-02-16 14:34:13 --> Helper loaded: text_helper
INFO - 2016-02-16 14:34:13 --> Helper loaded: cookie_helper
INFO - 2016-02-16 17:34:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-16 17:34:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-16 17:34:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-16 17:34:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-16 17:34:13 --> Final output sent to browser
DEBUG - 2016-02-16 17:34:13 --> Total execution time: 1.1381
