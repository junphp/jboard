<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-25 05:19:38 --> Config Class Initialized
INFO - 2016-02-25 05:19:38 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:19:38 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:19:38 --> Utf8 Class Initialized
INFO - 2016-02-25 05:19:38 --> URI Class Initialized
DEBUG - 2016-02-25 05:19:38 --> No URI present. Default controller set.
INFO - 2016-02-25 05:19:38 --> Router Class Initialized
INFO - 2016-02-25 05:19:38 --> Output Class Initialized
INFO - 2016-02-25 05:19:38 --> Security Class Initialized
DEBUG - 2016-02-25 05:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:19:38 --> Input Class Initialized
INFO - 2016-02-25 05:19:38 --> Language Class Initialized
INFO - 2016-02-25 05:19:38 --> Loader Class Initialized
INFO - 2016-02-25 05:19:38 --> Helper loaded: url_helper
INFO - 2016-02-25 05:19:38 --> Helper loaded: file_helper
INFO - 2016-02-25 05:19:38 --> Helper loaded: date_helper
INFO - 2016-02-25 05:19:38 --> Helper loaded: form_helper
INFO - 2016-02-25 05:19:38 --> Database Driver Class Initialized
INFO - 2016-02-25 05:19:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:19:39 --> Controller Class Initialized
INFO - 2016-02-25 05:19:39 --> Model Class Initialized
INFO - 2016-02-25 05:19:39 --> Model Class Initialized
INFO - 2016-02-25 05:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:19:39 --> Pagination Class Initialized
INFO - 2016-02-25 05:19:39 --> Helper loaded: text_helper
INFO - 2016-02-25 05:19:39 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-25 08:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:19:39 --> Final output sent to browser
DEBUG - 2016-02-25 08:19:39 --> Total execution time: 1.1388
INFO - 2016-02-25 05:19:42 --> Config Class Initialized
INFO - 2016-02-25 05:19:42 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:19:42 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:19:42 --> Utf8 Class Initialized
INFO - 2016-02-25 05:19:42 --> URI Class Initialized
INFO - 2016-02-25 05:19:42 --> Router Class Initialized
INFO - 2016-02-25 05:19:42 --> Output Class Initialized
INFO - 2016-02-25 05:19:42 --> Security Class Initialized
DEBUG - 2016-02-25 05:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:19:42 --> Input Class Initialized
INFO - 2016-02-25 05:19:42 --> Language Class Initialized
INFO - 2016-02-25 05:19:42 --> Loader Class Initialized
INFO - 2016-02-25 05:19:42 --> Helper loaded: url_helper
INFO - 2016-02-25 05:19:42 --> Helper loaded: file_helper
INFO - 2016-02-25 05:19:42 --> Helper loaded: date_helper
INFO - 2016-02-25 05:19:42 --> Helper loaded: form_helper
INFO - 2016-02-25 05:19:42 --> Database Driver Class Initialized
INFO - 2016-02-25 05:19:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:19:43 --> Controller Class Initialized
INFO - 2016-02-25 05:19:43 --> Model Class Initialized
INFO - 2016-02-25 05:19:43 --> Model Class Initialized
INFO - 2016-02-25 05:19:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:19:43 --> Pagination Class Initialized
INFO - 2016-02-25 05:19:43 --> Helper loaded: text_helper
INFO - 2016-02-25 05:19:43 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:19:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:19:43 --> Final output sent to browser
DEBUG - 2016-02-25 08:19:43 --> Total execution time: 1.1479
INFO - 2016-02-25 05:19:54 --> Config Class Initialized
INFO - 2016-02-25 05:19:54 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:19:54 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:19:54 --> Utf8 Class Initialized
INFO - 2016-02-25 05:19:54 --> URI Class Initialized
INFO - 2016-02-25 05:19:54 --> Router Class Initialized
INFO - 2016-02-25 05:19:54 --> Output Class Initialized
INFO - 2016-02-25 05:19:54 --> Security Class Initialized
DEBUG - 2016-02-25 05:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:19:54 --> Input Class Initialized
INFO - 2016-02-25 05:19:54 --> Language Class Initialized
INFO - 2016-02-25 05:19:54 --> Loader Class Initialized
INFO - 2016-02-25 05:19:54 --> Helper loaded: url_helper
INFO - 2016-02-25 05:19:54 --> Helper loaded: file_helper
INFO - 2016-02-25 05:19:54 --> Helper loaded: date_helper
INFO - 2016-02-25 05:19:54 --> Helper loaded: form_helper
INFO - 2016-02-25 05:19:54 --> Database Driver Class Initialized
INFO - 2016-02-25 05:19:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:19:55 --> Controller Class Initialized
INFO - 2016-02-25 05:19:55 --> Model Class Initialized
INFO - 2016-02-25 05:19:55 --> Model Class Initialized
INFO - 2016-02-25 05:19:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:19:55 --> Pagination Class Initialized
INFO - 2016-02-25 05:19:55 --> Helper loaded: text_helper
INFO - 2016-02-25 05:19:55 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:19:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:19:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:19:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 08:19:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:19:55 --> Final output sent to browser
DEBUG - 2016-02-25 08:19:55 --> Total execution time: 1.1302
INFO - 2016-02-25 05:19:56 --> Config Class Initialized
INFO - 2016-02-25 05:19:56 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:19:56 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:19:56 --> Utf8 Class Initialized
INFO - 2016-02-25 05:19:56 --> URI Class Initialized
INFO - 2016-02-25 05:19:56 --> Router Class Initialized
INFO - 2016-02-25 05:19:56 --> Output Class Initialized
INFO - 2016-02-25 05:19:56 --> Security Class Initialized
DEBUG - 2016-02-25 05:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:19:56 --> Input Class Initialized
INFO - 2016-02-25 05:19:56 --> Language Class Initialized
INFO - 2016-02-25 05:19:56 --> Loader Class Initialized
INFO - 2016-02-25 05:19:56 --> Helper loaded: url_helper
INFO - 2016-02-25 05:19:56 --> Helper loaded: file_helper
INFO - 2016-02-25 05:19:56 --> Helper loaded: date_helper
INFO - 2016-02-25 05:19:56 --> Helper loaded: form_helper
INFO - 2016-02-25 05:19:56 --> Database Driver Class Initialized
INFO - 2016-02-25 05:19:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:19:57 --> Controller Class Initialized
INFO - 2016-02-25 05:19:57 --> Model Class Initialized
INFO - 2016-02-25 05:19:57 --> Model Class Initialized
INFO - 2016-02-25 05:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:19:57 --> Pagination Class Initialized
INFO - 2016-02-25 05:19:57 --> Helper loaded: text_helper
INFO - 2016-02-25 05:19:57 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 08:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-25 08:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:19:57 --> Final output sent to browser
DEBUG - 2016-02-25 08:19:57 --> Total execution time: 1.1219
INFO - 2016-02-25 05:24:54 --> Config Class Initialized
INFO - 2016-02-25 05:24:54 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:24:54 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:24:54 --> Utf8 Class Initialized
INFO - 2016-02-25 05:24:54 --> URI Class Initialized
DEBUG - 2016-02-25 05:24:54 --> No URI present. Default controller set.
INFO - 2016-02-25 05:24:54 --> Router Class Initialized
INFO - 2016-02-25 05:24:54 --> Output Class Initialized
INFO - 2016-02-25 05:24:54 --> Security Class Initialized
DEBUG - 2016-02-25 05:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:24:54 --> Input Class Initialized
INFO - 2016-02-25 05:24:54 --> Language Class Initialized
INFO - 2016-02-25 05:24:54 --> Loader Class Initialized
INFO - 2016-02-25 05:24:54 --> Helper loaded: url_helper
INFO - 2016-02-25 05:24:54 --> Helper loaded: file_helper
INFO - 2016-02-25 05:24:54 --> Helper loaded: date_helper
INFO - 2016-02-25 05:24:54 --> Helper loaded: form_helper
INFO - 2016-02-25 05:24:54 --> Database Driver Class Initialized
INFO - 2016-02-25 05:24:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:24:55 --> Controller Class Initialized
INFO - 2016-02-25 05:24:55 --> Model Class Initialized
INFO - 2016-02-25 05:24:55 --> Model Class Initialized
INFO - 2016-02-25 05:24:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:24:55 --> Pagination Class Initialized
INFO - 2016-02-25 05:24:55 --> Helper loaded: text_helper
INFO - 2016-02-25 05:24:55 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-25 08:24:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:24:55 --> Final output sent to browser
DEBUG - 2016-02-25 08:24:55 --> Total execution time: 1.1384
INFO - 2016-02-25 05:24:55 --> Config Class Initialized
INFO - 2016-02-25 05:24:55 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:24:55 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:24:55 --> Utf8 Class Initialized
INFO - 2016-02-25 05:24:55 --> URI Class Initialized
INFO - 2016-02-25 05:24:55 --> Router Class Initialized
INFO - 2016-02-25 05:24:55 --> Output Class Initialized
INFO - 2016-02-25 05:24:55 --> Security Class Initialized
DEBUG - 2016-02-25 05:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:24:56 --> Input Class Initialized
INFO - 2016-02-25 05:24:56 --> Language Class Initialized
INFO - 2016-02-25 05:24:56 --> Loader Class Initialized
INFO - 2016-02-25 05:24:56 --> Helper loaded: url_helper
INFO - 2016-02-25 05:24:56 --> Helper loaded: file_helper
INFO - 2016-02-25 05:24:56 --> Helper loaded: date_helper
INFO - 2016-02-25 05:24:56 --> Helper loaded: form_helper
INFO - 2016-02-25 05:24:56 --> Database Driver Class Initialized
INFO - 2016-02-25 05:24:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:24:57 --> Controller Class Initialized
INFO - 2016-02-25 05:24:57 --> Model Class Initialized
INFO - 2016-02-25 05:24:57 --> Model Class Initialized
INFO - 2016-02-25 05:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:24:57 --> Pagination Class Initialized
INFO - 2016-02-25 05:24:57 --> Helper loaded: text_helper
INFO - 2016-02-25 05:24:57 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-25 08:24:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-25 08:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:24:57 --> Final output sent to browser
DEBUG - 2016-02-25 08:24:57 --> Total execution time: 1.1543
INFO - 2016-02-25 05:25:10 --> Config Class Initialized
INFO - 2016-02-25 05:25:10 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:25:10 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:25:10 --> Utf8 Class Initialized
INFO - 2016-02-25 05:25:10 --> URI Class Initialized
INFO - 2016-02-25 05:25:10 --> Router Class Initialized
INFO - 2016-02-25 05:25:10 --> Output Class Initialized
INFO - 2016-02-25 05:25:10 --> Security Class Initialized
DEBUG - 2016-02-25 05:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:25:10 --> Input Class Initialized
INFO - 2016-02-25 05:25:10 --> Language Class Initialized
INFO - 2016-02-25 05:25:10 --> Loader Class Initialized
INFO - 2016-02-25 05:25:10 --> Helper loaded: url_helper
INFO - 2016-02-25 05:25:10 --> Helper loaded: file_helper
INFO - 2016-02-25 05:25:10 --> Helper loaded: date_helper
INFO - 2016-02-25 05:25:10 --> Helper loaded: form_helper
INFO - 2016-02-25 05:25:10 --> Database Driver Class Initialized
INFO - 2016-02-25 05:25:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:25:11 --> Controller Class Initialized
INFO - 2016-02-25 05:25:11 --> Model Class Initialized
INFO - 2016-02-25 05:25:11 --> Model Class Initialized
INFO - 2016-02-25 05:25:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:25:11 --> Pagination Class Initialized
INFO - 2016-02-25 05:25:11 --> Helper loaded: text_helper
INFO - 2016-02-25 05:25:11 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:25:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:25:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:25:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 08:25:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:25:11 --> Final output sent to browser
DEBUG - 2016-02-25 08:25:11 --> Total execution time: 1.1642
INFO - 2016-02-25 05:25:13 --> Config Class Initialized
INFO - 2016-02-25 05:25:13 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:25:13 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:25:13 --> Utf8 Class Initialized
INFO - 2016-02-25 05:25:13 --> URI Class Initialized
INFO - 2016-02-25 05:25:13 --> Router Class Initialized
INFO - 2016-02-25 05:25:13 --> Output Class Initialized
INFO - 2016-02-25 05:25:13 --> Security Class Initialized
DEBUG - 2016-02-25 05:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:25:13 --> Input Class Initialized
INFO - 2016-02-25 05:25:13 --> Language Class Initialized
INFO - 2016-02-25 05:25:13 --> Loader Class Initialized
INFO - 2016-02-25 05:25:13 --> Helper loaded: url_helper
INFO - 2016-02-25 05:25:13 --> Helper loaded: file_helper
INFO - 2016-02-25 05:25:13 --> Helper loaded: date_helper
INFO - 2016-02-25 05:25:13 --> Helper loaded: form_helper
INFO - 2016-02-25 05:25:13 --> Database Driver Class Initialized
INFO - 2016-02-25 05:25:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:25:14 --> Controller Class Initialized
INFO - 2016-02-25 05:25:14 --> Model Class Initialized
INFO - 2016-02-25 05:25:14 --> Model Class Initialized
INFO - 2016-02-25 05:25:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:25:14 --> Pagination Class Initialized
INFO - 2016-02-25 05:25:14 --> Helper loaded: text_helper
INFO - 2016-02-25 05:25:14 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:25:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:25:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:25:15 --> Final output sent to browser
DEBUG - 2016-02-25 08:25:15 --> Total execution time: 1.2142
INFO - 2016-02-25 05:25:19 --> Config Class Initialized
INFO - 2016-02-25 05:25:19 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:25:19 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:25:19 --> Utf8 Class Initialized
INFO - 2016-02-25 05:25:19 --> URI Class Initialized
INFO - 2016-02-25 05:25:19 --> Router Class Initialized
INFO - 2016-02-25 05:25:19 --> Output Class Initialized
INFO - 2016-02-25 05:25:19 --> Security Class Initialized
DEBUG - 2016-02-25 05:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:25:19 --> Input Class Initialized
INFO - 2016-02-25 05:25:19 --> Language Class Initialized
INFO - 2016-02-25 05:25:19 --> Loader Class Initialized
INFO - 2016-02-25 05:25:19 --> Helper loaded: url_helper
INFO - 2016-02-25 05:25:19 --> Helper loaded: file_helper
INFO - 2016-02-25 05:25:19 --> Helper loaded: date_helper
INFO - 2016-02-25 05:25:19 --> Helper loaded: form_helper
INFO - 2016-02-25 05:25:19 --> Database Driver Class Initialized
INFO - 2016-02-25 05:25:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:25:20 --> Controller Class Initialized
INFO - 2016-02-25 05:25:20 --> Model Class Initialized
INFO - 2016-02-25 05:25:20 --> Model Class Initialized
INFO - 2016-02-25 05:25:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:25:20 --> Pagination Class Initialized
INFO - 2016-02-25 05:25:20 --> Helper loaded: text_helper
INFO - 2016-02-25 05:25:20 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-25 08:25:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-25 08:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:25:20 --> Final output sent to browser
DEBUG - 2016-02-25 08:25:20 --> Total execution time: 1.1919
INFO - 2016-02-25 05:25:21 --> Config Class Initialized
INFO - 2016-02-25 05:25:21 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:25:21 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:25:21 --> Utf8 Class Initialized
INFO - 2016-02-25 05:25:21 --> URI Class Initialized
INFO - 2016-02-25 05:25:21 --> Router Class Initialized
INFO - 2016-02-25 05:25:21 --> Output Class Initialized
INFO - 2016-02-25 05:25:21 --> Security Class Initialized
DEBUG - 2016-02-25 05:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:25:21 --> Input Class Initialized
INFO - 2016-02-25 05:25:21 --> Language Class Initialized
INFO - 2016-02-25 05:25:21 --> Loader Class Initialized
INFO - 2016-02-25 05:25:21 --> Helper loaded: url_helper
INFO - 2016-02-25 05:25:21 --> Helper loaded: file_helper
INFO - 2016-02-25 05:25:21 --> Helper loaded: date_helper
INFO - 2016-02-25 05:25:21 --> Helper loaded: form_helper
INFO - 2016-02-25 05:25:21 --> Database Driver Class Initialized
INFO - 2016-02-25 05:25:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:25:22 --> Controller Class Initialized
INFO - 2016-02-25 05:25:22 --> Model Class Initialized
INFO - 2016-02-25 05:25:22 --> Model Class Initialized
INFO - 2016-02-25 05:25:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:25:22 --> Pagination Class Initialized
INFO - 2016-02-25 05:25:22 --> Helper loaded: text_helper
INFO - 2016-02-25 05:25:22 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:25:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:25:22 --> Final output sent to browser
DEBUG - 2016-02-25 08:25:22 --> Total execution time: 1.2007
INFO - 2016-02-25 05:25:46 --> Config Class Initialized
INFO - 2016-02-25 05:25:46 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:25:46 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:25:46 --> Utf8 Class Initialized
INFO - 2016-02-25 05:25:46 --> URI Class Initialized
INFO - 2016-02-25 05:25:46 --> Router Class Initialized
INFO - 2016-02-25 05:25:46 --> Output Class Initialized
INFO - 2016-02-25 05:25:46 --> Security Class Initialized
DEBUG - 2016-02-25 05:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:25:46 --> Input Class Initialized
INFO - 2016-02-25 05:25:46 --> Language Class Initialized
INFO - 2016-02-25 05:25:46 --> Loader Class Initialized
INFO - 2016-02-25 05:25:46 --> Helper loaded: url_helper
INFO - 2016-02-25 05:25:46 --> Helper loaded: file_helper
INFO - 2016-02-25 05:25:46 --> Helper loaded: date_helper
INFO - 2016-02-25 05:25:46 --> Helper loaded: form_helper
INFO - 2016-02-25 05:25:46 --> Database Driver Class Initialized
INFO - 2016-02-25 05:25:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:25:47 --> Controller Class Initialized
INFO - 2016-02-25 05:25:47 --> Model Class Initialized
INFO - 2016-02-25 05:25:47 --> Model Class Initialized
INFO - 2016-02-25 05:25:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:25:47 --> Pagination Class Initialized
INFO - 2016-02-25 05:25:47 --> Helper loaded: text_helper
INFO - 2016-02-25 05:25:47 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 08:25:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:25:47 --> Final output sent to browser
DEBUG - 2016-02-25 08:25:47 --> Total execution time: 1.1329
INFO - 2016-02-25 05:25:52 --> Config Class Initialized
INFO - 2016-02-25 05:25:52 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:25:52 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:25:52 --> Utf8 Class Initialized
INFO - 2016-02-25 05:25:52 --> URI Class Initialized
INFO - 2016-02-25 05:25:52 --> Router Class Initialized
INFO - 2016-02-25 05:25:52 --> Output Class Initialized
INFO - 2016-02-25 05:25:52 --> Security Class Initialized
DEBUG - 2016-02-25 05:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:25:52 --> Input Class Initialized
INFO - 2016-02-25 05:25:52 --> Language Class Initialized
INFO - 2016-02-25 05:25:52 --> Loader Class Initialized
INFO - 2016-02-25 05:25:52 --> Helper loaded: url_helper
INFO - 2016-02-25 05:25:52 --> Helper loaded: file_helper
INFO - 2016-02-25 05:25:52 --> Helper loaded: date_helper
INFO - 2016-02-25 05:25:52 --> Helper loaded: form_helper
INFO - 2016-02-25 05:25:52 --> Database Driver Class Initialized
INFO - 2016-02-25 05:25:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:25:53 --> Controller Class Initialized
INFO - 2016-02-25 05:25:53 --> Model Class Initialized
INFO - 2016-02-25 05:25:53 --> Model Class Initialized
INFO - 2016-02-25 05:25:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:25:53 --> Pagination Class Initialized
INFO - 2016-02-25 05:25:53 --> Helper loaded: text_helper
INFO - 2016-02-25 05:25:53 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 08:25:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:25:53 --> Final output sent to browser
DEBUG - 2016-02-25 08:25:53 --> Total execution time: 1.1437
INFO - 2016-02-25 05:25:54 --> Config Class Initialized
INFO - 2016-02-25 05:25:54 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:25:54 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:25:54 --> Utf8 Class Initialized
INFO - 2016-02-25 05:25:54 --> URI Class Initialized
INFO - 2016-02-25 05:25:54 --> Router Class Initialized
INFO - 2016-02-25 05:25:54 --> Output Class Initialized
INFO - 2016-02-25 05:25:54 --> Security Class Initialized
DEBUG - 2016-02-25 05:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:25:54 --> Input Class Initialized
INFO - 2016-02-25 05:25:54 --> Language Class Initialized
INFO - 2016-02-25 05:25:54 --> Loader Class Initialized
INFO - 2016-02-25 05:25:54 --> Helper loaded: url_helper
INFO - 2016-02-25 05:25:54 --> Helper loaded: file_helper
INFO - 2016-02-25 05:25:54 --> Helper loaded: date_helper
INFO - 2016-02-25 05:25:54 --> Helper loaded: form_helper
INFO - 2016-02-25 05:25:54 --> Database Driver Class Initialized
INFO - 2016-02-25 05:25:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:25:55 --> Controller Class Initialized
INFO - 2016-02-25 05:25:55 --> Model Class Initialized
INFO - 2016-02-25 05:25:55 --> Model Class Initialized
INFO - 2016-02-25 05:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:25:55 --> Pagination Class Initialized
INFO - 2016-02-25 05:25:55 --> Helper loaded: text_helper
INFO - 2016-02-25 05:25:55 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:25:55 --> Final output sent to browser
DEBUG - 2016-02-25 08:25:55 --> Total execution time: 1.1501
INFO - 2016-02-25 05:25:57 --> Config Class Initialized
INFO - 2016-02-25 05:25:57 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:25:57 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:25:57 --> Utf8 Class Initialized
INFO - 2016-02-25 05:25:57 --> URI Class Initialized
INFO - 2016-02-25 05:25:57 --> Router Class Initialized
INFO - 2016-02-25 05:25:57 --> Output Class Initialized
INFO - 2016-02-25 05:25:57 --> Security Class Initialized
DEBUG - 2016-02-25 05:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:25:57 --> Input Class Initialized
INFO - 2016-02-25 05:25:57 --> Language Class Initialized
ERROR - 2016-02-25 05:25:57 --> 404 Page Not Found: Wall/69
INFO - 2016-02-25 05:26:40 --> Config Class Initialized
INFO - 2016-02-25 05:26:40 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:26:40 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:26:40 --> Utf8 Class Initialized
INFO - 2016-02-25 05:26:40 --> URI Class Initialized
INFO - 2016-02-25 05:26:40 --> Router Class Initialized
INFO - 2016-02-25 05:26:40 --> Output Class Initialized
INFO - 2016-02-25 05:26:40 --> Security Class Initialized
DEBUG - 2016-02-25 05:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:26:40 --> Input Class Initialized
INFO - 2016-02-25 05:26:40 --> Language Class Initialized
INFO - 2016-02-25 05:26:40 --> Loader Class Initialized
INFO - 2016-02-25 05:26:40 --> Helper loaded: url_helper
INFO - 2016-02-25 05:26:40 --> Helper loaded: file_helper
INFO - 2016-02-25 05:26:40 --> Helper loaded: date_helper
INFO - 2016-02-25 05:26:40 --> Helper loaded: form_helper
INFO - 2016-02-25 05:26:40 --> Database Driver Class Initialized
INFO - 2016-02-25 05:26:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:26:41 --> Controller Class Initialized
INFO - 2016-02-25 05:26:41 --> Model Class Initialized
INFO - 2016-02-25 05:26:41 --> Model Class Initialized
INFO - 2016-02-25 05:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:26:41 --> Pagination Class Initialized
INFO - 2016-02-25 05:26:41 --> Helper loaded: text_helper
INFO - 2016-02-25 05:26:41 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:26:41 --> Final output sent to browser
DEBUG - 2016-02-25 08:26:41 --> Total execution time: 1.2034
INFO - 2016-02-25 05:27:09 --> Config Class Initialized
INFO - 2016-02-25 05:27:09 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:27:09 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:27:09 --> Utf8 Class Initialized
INFO - 2016-02-25 05:27:09 --> URI Class Initialized
INFO - 2016-02-25 05:27:09 --> Router Class Initialized
INFO - 2016-02-25 05:27:09 --> Output Class Initialized
INFO - 2016-02-25 05:27:09 --> Security Class Initialized
DEBUG - 2016-02-25 05:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:27:09 --> Input Class Initialized
INFO - 2016-02-25 05:27:09 --> Language Class Initialized
INFO - 2016-02-25 05:27:09 --> Loader Class Initialized
INFO - 2016-02-25 05:27:09 --> Helper loaded: url_helper
INFO - 2016-02-25 05:27:09 --> Helper loaded: file_helper
INFO - 2016-02-25 05:27:09 --> Helper loaded: date_helper
INFO - 2016-02-25 05:27:09 --> Helper loaded: form_helper
INFO - 2016-02-25 05:27:09 --> Database Driver Class Initialized
INFO - 2016-02-25 05:27:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:27:10 --> Controller Class Initialized
INFO - 2016-02-25 05:27:10 --> Model Class Initialized
INFO - 2016-02-25 05:27:10 --> Model Class Initialized
INFO - 2016-02-25 05:27:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:27:10 --> Pagination Class Initialized
INFO - 2016-02-25 05:27:10 --> Helper loaded: text_helper
INFO - 2016-02-25 05:27:10 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:27:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:27:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:27:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 08:27:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:27:10 --> Final output sent to browser
DEBUG - 2016-02-25 08:27:10 --> Total execution time: 1.1392
INFO - 2016-02-25 05:27:12 --> Config Class Initialized
INFO - 2016-02-25 05:27:12 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:27:12 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:27:12 --> Utf8 Class Initialized
INFO - 2016-02-25 05:27:12 --> URI Class Initialized
INFO - 2016-02-25 05:27:12 --> Router Class Initialized
INFO - 2016-02-25 05:27:12 --> Output Class Initialized
INFO - 2016-02-25 05:27:12 --> Security Class Initialized
DEBUG - 2016-02-25 05:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:27:12 --> Input Class Initialized
INFO - 2016-02-25 05:27:12 --> Language Class Initialized
INFO - 2016-02-25 05:27:12 --> Loader Class Initialized
INFO - 2016-02-25 05:27:12 --> Helper loaded: url_helper
INFO - 2016-02-25 05:27:12 --> Helper loaded: file_helper
INFO - 2016-02-25 05:27:12 --> Helper loaded: date_helper
INFO - 2016-02-25 05:27:12 --> Helper loaded: form_helper
INFO - 2016-02-25 05:27:12 --> Database Driver Class Initialized
INFO - 2016-02-25 05:27:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:27:13 --> Controller Class Initialized
INFO - 2016-02-25 05:27:13 --> Model Class Initialized
INFO - 2016-02-25 05:27:13 --> Model Class Initialized
INFO - 2016-02-25 05:27:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:27:13 --> Pagination Class Initialized
INFO - 2016-02-25 05:27:13 --> Helper loaded: text_helper
INFO - 2016-02-25 05:27:13 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:27:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:27:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:27:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:27:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:27:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:27:13 --> Final output sent to browser
DEBUG - 2016-02-25 08:27:13 --> Total execution time: 1.2156
INFO - 2016-02-25 05:27:16 --> Config Class Initialized
INFO - 2016-02-25 05:27:16 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:27:16 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:27:16 --> Utf8 Class Initialized
INFO - 2016-02-25 05:27:16 --> URI Class Initialized
INFO - 2016-02-25 05:27:16 --> Router Class Initialized
INFO - 2016-02-25 05:27:16 --> Output Class Initialized
INFO - 2016-02-25 05:27:16 --> Security Class Initialized
DEBUG - 2016-02-25 05:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:27:16 --> Input Class Initialized
INFO - 2016-02-25 05:27:16 --> Language Class Initialized
ERROR - 2016-02-25 05:27:16 --> 404 Page Not Found: Wall/69
INFO - 2016-02-25 05:27:18 --> Config Class Initialized
INFO - 2016-02-25 05:27:18 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:27:18 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:27:18 --> Utf8 Class Initialized
INFO - 2016-02-25 05:27:18 --> URI Class Initialized
INFO - 2016-02-25 05:27:18 --> Router Class Initialized
INFO - 2016-02-25 05:27:18 --> Output Class Initialized
INFO - 2016-02-25 05:27:18 --> Security Class Initialized
DEBUG - 2016-02-25 05:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:27:18 --> Input Class Initialized
INFO - 2016-02-25 05:27:18 --> Language Class Initialized
INFO - 2016-02-25 05:27:18 --> Loader Class Initialized
INFO - 2016-02-25 05:27:18 --> Helper loaded: url_helper
INFO - 2016-02-25 05:27:18 --> Helper loaded: file_helper
INFO - 2016-02-25 05:27:18 --> Helper loaded: date_helper
INFO - 2016-02-25 05:27:18 --> Helper loaded: form_helper
INFO - 2016-02-25 05:27:18 --> Database Driver Class Initialized
INFO - 2016-02-25 05:27:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:27:19 --> Controller Class Initialized
INFO - 2016-02-25 05:27:19 --> Model Class Initialized
INFO - 2016-02-25 05:27:19 --> Model Class Initialized
INFO - 2016-02-25 05:27:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:27:19 --> Pagination Class Initialized
INFO - 2016-02-25 05:27:19 --> Helper loaded: text_helper
INFO - 2016-02-25 05:27:19 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 08:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 08:27:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:27:19 --> Final output sent to browser
DEBUG - 2016-02-25 08:27:19 --> Total execution time: 1.1905
INFO - 2016-02-25 05:27:24 --> Config Class Initialized
INFO - 2016-02-25 05:27:24 --> Hooks Class Initialized
DEBUG - 2016-02-25 05:27:24 --> UTF-8 Support Enabled
INFO - 2016-02-25 05:27:24 --> Utf8 Class Initialized
INFO - 2016-02-25 05:27:24 --> URI Class Initialized
DEBUG - 2016-02-25 05:27:24 --> No URI present. Default controller set.
INFO - 2016-02-25 05:27:24 --> Router Class Initialized
INFO - 2016-02-25 05:27:24 --> Output Class Initialized
INFO - 2016-02-25 05:27:24 --> Security Class Initialized
DEBUG - 2016-02-25 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 05:27:24 --> Input Class Initialized
INFO - 2016-02-25 05:27:24 --> Language Class Initialized
INFO - 2016-02-25 05:27:24 --> Loader Class Initialized
INFO - 2016-02-25 05:27:24 --> Helper loaded: url_helper
INFO - 2016-02-25 05:27:24 --> Helper loaded: file_helper
INFO - 2016-02-25 05:27:24 --> Helper loaded: date_helper
INFO - 2016-02-25 05:27:24 --> Helper loaded: form_helper
INFO - 2016-02-25 05:27:24 --> Database Driver Class Initialized
INFO - 2016-02-25 05:27:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 05:27:25 --> Controller Class Initialized
INFO - 2016-02-25 05:27:25 --> Model Class Initialized
INFO - 2016-02-25 05:27:25 --> Model Class Initialized
INFO - 2016-02-25 05:27:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 05:27:25 --> Pagination Class Initialized
INFO - 2016-02-25 05:27:25 --> Helper loaded: text_helper
INFO - 2016-02-25 05:27:25 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 08:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 08:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-25 08:27:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 08:27:25 --> Final output sent to browser
DEBUG - 2016-02-25 08:27:25 --> Total execution time: 1.1144
INFO - 2016-02-25 06:20:30 --> Config Class Initialized
INFO - 2016-02-25 06:20:30 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:20:30 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:20:30 --> Utf8 Class Initialized
INFO - 2016-02-25 06:20:30 --> URI Class Initialized
INFO - 2016-02-25 06:20:30 --> Router Class Initialized
INFO - 2016-02-25 06:20:30 --> Output Class Initialized
INFO - 2016-02-25 06:20:30 --> Security Class Initialized
DEBUG - 2016-02-25 06:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:20:30 --> Input Class Initialized
INFO - 2016-02-25 06:20:30 --> Language Class Initialized
INFO - 2016-02-25 06:20:30 --> Loader Class Initialized
INFO - 2016-02-25 06:20:30 --> Helper loaded: url_helper
INFO - 2016-02-25 06:20:30 --> Helper loaded: file_helper
INFO - 2016-02-25 06:20:30 --> Helper loaded: date_helper
INFO - 2016-02-25 06:20:30 --> Helper loaded: form_helper
INFO - 2016-02-25 06:20:30 --> Database Driver Class Initialized
INFO - 2016-02-25 06:20:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:20:31 --> Controller Class Initialized
INFO - 2016-02-25 06:20:31 --> Model Class Initialized
INFO - 2016-02-25 06:20:31 --> Model Class Initialized
INFO - 2016-02-25 06:20:31 --> Form Validation Class Initialized
INFO - 2016-02-25 06:20:31 --> Helper loaded: text_helper
INFO - 2016-02-25 06:20:32 --> Config Class Initialized
INFO - 2016-02-25 06:20:32 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:20:32 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:20:32 --> Utf8 Class Initialized
INFO - 2016-02-25 06:20:32 --> URI Class Initialized
DEBUG - 2016-02-25 06:20:32 --> No URI present. Default controller set.
INFO - 2016-02-25 06:20:32 --> Router Class Initialized
INFO - 2016-02-25 06:20:32 --> Output Class Initialized
INFO - 2016-02-25 06:20:32 --> Security Class Initialized
DEBUG - 2016-02-25 06:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:20:32 --> Input Class Initialized
INFO - 2016-02-25 06:20:32 --> Language Class Initialized
INFO - 2016-02-25 06:20:32 --> Loader Class Initialized
INFO - 2016-02-25 06:20:32 --> Helper loaded: url_helper
INFO - 2016-02-25 06:20:32 --> Helper loaded: file_helper
INFO - 2016-02-25 06:20:32 --> Helper loaded: date_helper
INFO - 2016-02-25 06:20:32 --> Helper loaded: form_helper
INFO - 2016-02-25 06:20:32 --> Database Driver Class Initialized
INFO - 2016-02-25 06:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:20:33 --> Controller Class Initialized
INFO - 2016-02-25 06:20:33 --> Model Class Initialized
INFO - 2016-02-25 06:20:33 --> Model Class Initialized
INFO - 2016-02-25 06:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:20:33 --> Pagination Class Initialized
INFO - 2016-02-25 06:20:33 --> Helper loaded: text_helper
INFO - 2016-02-25 06:20:33 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-25 09:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:20:33 --> Final output sent to browser
DEBUG - 2016-02-25 09:20:33 --> Total execution time: 1.3090
INFO - 2016-02-25 06:20:41 --> Config Class Initialized
INFO - 2016-02-25 06:20:41 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:20:41 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:20:41 --> Utf8 Class Initialized
INFO - 2016-02-25 06:20:41 --> URI Class Initialized
INFO - 2016-02-25 06:20:41 --> Router Class Initialized
INFO - 2016-02-25 06:20:41 --> Output Class Initialized
INFO - 2016-02-25 06:20:41 --> Security Class Initialized
DEBUG - 2016-02-25 06:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:20:41 --> Input Class Initialized
INFO - 2016-02-25 06:20:41 --> Language Class Initialized
INFO - 2016-02-25 06:20:41 --> Loader Class Initialized
INFO - 2016-02-25 06:20:41 --> Helper loaded: url_helper
INFO - 2016-02-25 06:20:41 --> Helper loaded: file_helper
INFO - 2016-02-25 06:20:41 --> Helper loaded: date_helper
INFO - 2016-02-25 06:20:41 --> Helper loaded: form_helper
INFO - 2016-02-25 06:20:41 --> Database Driver Class Initialized
INFO - 2016-02-25 06:20:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:20:42 --> Controller Class Initialized
INFO - 2016-02-25 06:20:42 --> Model Class Initialized
INFO - 2016-02-25 06:20:42 --> Model Class Initialized
INFO - 2016-02-25 06:20:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:20:42 --> Pagination Class Initialized
INFO - 2016-02-25 06:20:42 --> Helper loaded: text_helper
INFO - 2016-02-25 06:20:42 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 09:20:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:20:42 --> Final output sent to browser
DEBUG - 2016-02-25 09:20:42 --> Total execution time: 1.2243
INFO - 2016-02-25 06:20:44 --> Config Class Initialized
INFO - 2016-02-25 06:20:44 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:20:44 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:20:44 --> Utf8 Class Initialized
INFO - 2016-02-25 06:20:44 --> URI Class Initialized
INFO - 2016-02-25 06:20:44 --> Router Class Initialized
INFO - 2016-02-25 06:20:44 --> Output Class Initialized
INFO - 2016-02-25 06:20:44 --> Security Class Initialized
DEBUG - 2016-02-25 06:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:20:44 --> Input Class Initialized
INFO - 2016-02-25 06:20:44 --> Language Class Initialized
INFO - 2016-02-25 06:20:44 --> Loader Class Initialized
INFO - 2016-02-25 06:20:44 --> Helper loaded: url_helper
INFO - 2016-02-25 06:20:44 --> Helper loaded: file_helper
INFO - 2016-02-25 06:20:44 --> Helper loaded: date_helper
INFO - 2016-02-25 06:20:44 --> Helper loaded: form_helper
INFO - 2016-02-25 06:20:44 --> Database Driver Class Initialized
INFO - 2016-02-25 06:20:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:20:45 --> Controller Class Initialized
INFO - 2016-02-25 06:20:45 --> Model Class Initialized
INFO - 2016-02-25 06:20:45 --> Model Class Initialized
INFO - 2016-02-25 06:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:20:45 --> Pagination Class Initialized
INFO - 2016-02-25 06:20:45 --> Helper loaded: text_helper
INFO - 2016-02-25 06:20:45 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 09:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 09:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:20:45 --> Final output sent to browser
DEBUG - 2016-02-25 09:20:45 --> Total execution time: 1.1740
INFO - 2016-02-25 06:33:37 --> Config Class Initialized
INFO - 2016-02-25 06:33:37 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:33:37 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:33:37 --> Utf8 Class Initialized
INFO - 2016-02-25 06:33:37 --> URI Class Initialized
INFO - 2016-02-25 06:33:37 --> Router Class Initialized
INFO - 2016-02-25 06:33:37 --> Output Class Initialized
INFO - 2016-02-25 06:33:37 --> Security Class Initialized
DEBUG - 2016-02-25 06:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:33:37 --> Input Class Initialized
INFO - 2016-02-25 06:33:37 --> Language Class Initialized
INFO - 2016-02-25 06:33:37 --> Loader Class Initialized
INFO - 2016-02-25 06:33:37 --> Helper loaded: url_helper
INFO - 2016-02-25 06:33:37 --> Helper loaded: file_helper
INFO - 2016-02-25 06:33:37 --> Helper loaded: date_helper
INFO - 2016-02-25 06:33:37 --> Helper loaded: form_helper
INFO - 2016-02-25 06:33:37 --> Database Driver Class Initialized
INFO - 2016-02-25 06:33:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:33:38 --> Controller Class Initialized
INFO - 2016-02-25 06:33:38 --> Model Class Initialized
INFO - 2016-02-25 06:33:38 --> Model Class Initialized
INFO - 2016-02-25 06:33:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:33:38 --> Pagination Class Initialized
INFO - 2016-02-25 06:33:38 --> Helper loaded: text_helper
INFO - 2016-02-25 06:33:38 --> Helper loaded: cookie_helper
INFO - 2016-02-25 06:33:38 --> Image Lib Class Initialized
ERROR - 2016-02-25 09:33:38 --> Severity: Notice --> Undefined variable: filename C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 417
INFO - 2016-02-25 09:33:38 --> Upload Class Initialized
DEBUG - 2016-02-25 09:33:38 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 09:33:38 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2016-02-25 09:33:38 --> The filetype you are attempting to upload is not allowed.
INFO - 2016-02-25 09:33:38 --> Final output sent to browser
DEBUG - 2016-02-25 09:33:38 --> Total execution time: 1.3766
INFO - 2016-02-25 06:35:43 --> Config Class Initialized
INFO - 2016-02-25 06:35:43 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:35:43 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:35:43 --> Utf8 Class Initialized
INFO - 2016-02-25 06:35:43 --> URI Class Initialized
INFO - 2016-02-25 06:35:43 --> Router Class Initialized
INFO - 2016-02-25 06:35:43 --> Output Class Initialized
INFO - 2016-02-25 06:35:43 --> Security Class Initialized
DEBUG - 2016-02-25 06:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:35:43 --> Input Class Initialized
INFO - 2016-02-25 06:35:43 --> Language Class Initialized
INFO - 2016-02-25 06:35:43 --> Loader Class Initialized
INFO - 2016-02-25 06:35:43 --> Helper loaded: url_helper
INFO - 2016-02-25 06:35:43 --> Helper loaded: file_helper
INFO - 2016-02-25 06:35:43 --> Helper loaded: date_helper
INFO - 2016-02-25 06:35:43 --> Helper loaded: form_helper
INFO - 2016-02-25 06:35:43 --> Database Driver Class Initialized
INFO - 2016-02-25 06:35:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:35:44 --> Controller Class Initialized
INFO - 2016-02-25 06:35:44 --> Model Class Initialized
INFO - 2016-02-25 06:35:44 --> Model Class Initialized
INFO - 2016-02-25 06:35:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:35:44 --> Pagination Class Initialized
INFO - 2016-02-25 06:35:44 --> Helper loaded: text_helper
INFO - 2016-02-25 06:35:44 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:35:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:35:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:35:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 09:35:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:35:44 --> Final output sent to browser
DEBUG - 2016-02-25 09:35:44 --> Total execution time: 1.1596
INFO - 2016-02-25 06:35:56 --> Config Class Initialized
INFO - 2016-02-25 06:35:56 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:35:56 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:35:56 --> Utf8 Class Initialized
INFO - 2016-02-25 06:35:56 --> URI Class Initialized
INFO - 2016-02-25 06:35:56 --> Router Class Initialized
INFO - 2016-02-25 06:35:56 --> Output Class Initialized
INFO - 2016-02-25 06:35:56 --> Security Class Initialized
DEBUG - 2016-02-25 06:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:35:56 --> Input Class Initialized
INFO - 2016-02-25 06:35:56 --> Language Class Initialized
INFO - 2016-02-25 06:35:56 --> Loader Class Initialized
INFO - 2016-02-25 06:35:56 --> Helper loaded: url_helper
INFO - 2016-02-25 06:35:57 --> Helper loaded: file_helper
INFO - 2016-02-25 06:35:57 --> Helper loaded: date_helper
INFO - 2016-02-25 06:35:57 --> Helper loaded: form_helper
INFO - 2016-02-25 06:35:57 --> Database Driver Class Initialized
INFO - 2016-02-25 06:35:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:35:58 --> Controller Class Initialized
INFO - 2016-02-25 06:35:58 --> Model Class Initialized
INFO - 2016-02-25 06:35:58 --> Model Class Initialized
INFO - 2016-02-25 06:35:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:35:58 --> Pagination Class Initialized
INFO - 2016-02-25 06:35:58 --> Helper loaded: text_helper
INFO - 2016-02-25 06:35:58 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 09:35:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:35:58 --> Final output sent to browser
DEBUG - 2016-02-25 09:35:58 --> Total execution time: 1.1711
INFO - 2016-02-25 06:36:14 --> Config Class Initialized
INFO - 2016-02-25 06:36:14 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:36:14 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:36:14 --> Utf8 Class Initialized
INFO - 2016-02-25 06:36:14 --> URI Class Initialized
INFO - 2016-02-25 06:36:14 --> Router Class Initialized
INFO - 2016-02-25 06:36:14 --> Output Class Initialized
INFO - 2016-02-25 06:36:14 --> Security Class Initialized
DEBUG - 2016-02-25 06:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:36:14 --> Input Class Initialized
INFO - 2016-02-25 06:36:14 --> Language Class Initialized
INFO - 2016-02-25 06:36:14 --> Loader Class Initialized
INFO - 2016-02-25 06:36:14 --> Helper loaded: url_helper
INFO - 2016-02-25 06:36:14 --> Helper loaded: file_helper
INFO - 2016-02-25 06:36:14 --> Helper loaded: date_helper
INFO - 2016-02-25 06:36:14 --> Helper loaded: form_helper
INFO - 2016-02-25 06:36:14 --> Database Driver Class Initialized
INFO - 2016-02-25 06:36:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:36:15 --> Controller Class Initialized
INFO - 2016-02-25 06:36:15 --> Model Class Initialized
INFO - 2016-02-25 06:36:15 --> Model Class Initialized
INFO - 2016-02-25 06:36:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:36:15 --> Pagination Class Initialized
INFO - 2016-02-25 06:36:15 --> Helper loaded: text_helper
INFO - 2016-02-25 06:36:15 --> Helper loaded: cookie_helper
INFO - 2016-02-25 06:36:15 --> Image Lib Class Initialized
INFO - 2016-02-25 09:36:15 --> Upload Class Initialized
INFO - 2016-02-25 09:36:15 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2016-02-25 09:36:15 --> The filetype you are attempting to upload is not allowed.
INFO - 2016-02-25 09:36:15 --> Final output sent to browser
DEBUG - 2016-02-25 09:36:15 --> Total execution time: 1.1873
INFO - 2016-02-25 06:48:57 --> Config Class Initialized
INFO - 2016-02-25 06:48:57 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:48:57 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:48:57 --> Utf8 Class Initialized
INFO - 2016-02-25 06:48:57 --> URI Class Initialized
INFO - 2016-02-25 06:48:57 --> Router Class Initialized
INFO - 2016-02-25 06:48:57 --> Output Class Initialized
INFO - 2016-02-25 06:48:57 --> Security Class Initialized
DEBUG - 2016-02-25 06:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:48:57 --> Input Class Initialized
INFO - 2016-02-25 06:48:57 --> Language Class Initialized
INFO - 2016-02-25 06:48:57 --> Loader Class Initialized
INFO - 2016-02-25 06:48:57 --> Helper loaded: url_helper
INFO - 2016-02-25 06:48:57 --> Helper loaded: file_helper
INFO - 2016-02-25 06:48:57 --> Helper loaded: date_helper
INFO - 2016-02-25 06:48:57 --> Helper loaded: form_helper
INFO - 2016-02-25 06:48:57 --> Database Driver Class Initialized
INFO - 2016-02-25 06:48:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:48:58 --> Controller Class Initialized
INFO - 2016-02-25 06:48:58 --> Model Class Initialized
INFO - 2016-02-25 06:48:58 --> Model Class Initialized
INFO - 2016-02-25 06:48:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:48:58 --> Pagination Class Initialized
INFO - 2016-02-25 06:48:58 --> Helper loaded: text_helper
INFO - 2016-02-25 06:48:58 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:48:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:48:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:48:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 09:48:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:48:58 --> Final output sent to browser
DEBUG - 2016-02-25 09:48:58 --> Total execution time: 1.1536
INFO - 2016-02-25 06:49:01 --> Config Class Initialized
INFO - 2016-02-25 06:49:01 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:49:01 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:49:01 --> Utf8 Class Initialized
INFO - 2016-02-25 06:49:01 --> URI Class Initialized
INFO - 2016-02-25 06:49:01 --> Router Class Initialized
INFO - 2016-02-25 06:49:01 --> Output Class Initialized
INFO - 2016-02-25 06:49:01 --> Security Class Initialized
DEBUG - 2016-02-25 06:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:49:01 --> Input Class Initialized
INFO - 2016-02-25 06:49:01 --> Language Class Initialized
INFO - 2016-02-25 06:49:01 --> Loader Class Initialized
INFO - 2016-02-25 06:49:01 --> Helper loaded: url_helper
INFO - 2016-02-25 06:49:01 --> Helper loaded: file_helper
INFO - 2016-02-25 06:49:01 --> Helper loaded: date_helper
INFO - 2016-02-25 06:49:01 --> Helper loaded: form_helper
INFO - 2016-02-25 06:49:01 --> Database Driver Class Initialized
INFO - 2016-02-25 06:49:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:49:02 --> Controller Class Initialized
INFO - 2016-02-25 06:49:02 --> Model Class Initialized
INFO - 2016-02-25 06:49:02 --> Model Class Initialized
INFO - 2016-02-25 06:49:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:49:02 --> Pagination Class Initialized
INFO - 2016-02-25 06:49:02 --> Helper loaded: text_helper
INFO - 2016-02-25 06:49:02 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 09:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 09:49:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:49:02 --> Final output sent to browser
DEBUG - 2016-02-25 09:49:02 --> Total execution time: 1.1841
INFO - 2016-02-25 06:49:28 --> Config Class Initialized
INFO - 2016-02-25 06:49:28 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:49:28 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:49:28 --> Utf8 Class Initialized
INFO - 2016-02-25 06:49:28 --> URI Class Initialized
INFO - 2016-02-25 06:49:28 --> Router Class Initialized
INFO - 2016-02-25 06:49:28 --> Output Class Initialized
INFO - 2016-02-25 06:49:28 --> Security Class Initialized
DEBUG - 2016-02-25 06:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:49:28 --> Input Class Initialized
INFO - 2016-02-25 06:49:28 --> Language Class Initialized
INFO - 2016-02-25 06:49:28 --> Loader Class Initialized
INFO - 2016-02-25 06:49:28 --> Helper loaded: url_helper
INFO - 2016-02-25 06:49:28 --> Helper loaded: file_helper
INFO - 2016-02-25 06:49:28 --> Helper loaded: date_helper
INFO - 2016-02-25 06:49:28 --> Helper loaded: form_helper
INFO - 2016-02-25 06:49:28 --> Database Driver Class Initialized
INFO - 2016-02-25 06:49:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:49:29 --> Controller Class Initialized
INFO - 2016-02-25 06:49:29 --> Model Class Initialized
INFO - 2016-02-25 06:49:29 --> Model Class Initialized
INFO - 2016-02-25 06:49:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:49:29 --> Pagination Class Initialized
INFO - 2016-02-25 06:49:29 --> Helper loaded: text_helper
INFO - 2016-02-25 06:49:29 --> Helper loaded: cookie_helper
INFO - 2016-02-25 06:49:29 --> Image Lib Class Initialized
INFO - 2016-02-25 09:49:29 --> Upload Class Initialized
INFO - 2016-02-25 09:49:29 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2016-02-25 09:49:29 --> The filetype you are attempting to upload is not allowed.
INFO - 2016-02-25 09:49:29 --> Final output sent to browser
DEBUG - 2016-02-25 09:49:29 --> Total execution time: 1.1284
INFO - 2016-02-25 06:49:49 --> Config Class Initialized
INFO - 2016-02-25 06:49:49 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:49:49 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:49:49 --> Utf8 Class Initialized
INFO - 2016-02-25 06:49:49 --> URI Class Initialized
INFO - 2016-02-25 06:49:49 --> Router Class Initialized
INFO - 2016-02-25 06:49:49 --> Output Class Initialized
INFO - 2016-02-25 06:49:49 --> Security Class Initialized
DEBUG - 2016-02-25 06:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:49:49 --> Input Class Initialized
INFO - 2016-02-25 06:49:49 --> Language Class Initialized
INFO - 2016-02-25 06:49:49 --> Loader Class Initialized
INFO - 2016-02-25 06:49:49 --> Helper loaded: url_helper
INFO - 2016-02-25 06:49:49 --> Helper loaded: file_helper
INFO - 2016-02-25 06:49:49 --> Helper loaded: date_helper
INFO - 2016-02-25 06:49:49 --> Helper loaded: form_helper
INFO - 2016-02-25 06:49:49 --> Database Driver Class Initialized
INFO - 2016-02-25 06:49:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:49:50 --> Controller Class Initialized
INFO - 2016-02-25 06:49:50 --> Model Class Initialized
INFO - 2016-02-25 06:49:50 --> Model Class Initialized
INFO - 2016-02-25 06:49:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:49:50 --> Pagination Class Initialized
INFO - 2016-02-25 06:49:50 --> Helper loaded: text_helper
INFO - 2016-02-25 06:49:50 --> Helper loaded: cookie_helper
INFO - 2016-02-25 06:49:50 --> Image Lib Class Initialized
INFO - 2016-02-25 09:49:50 --> Upload Class Initialized
DEBUG - 2016-02-25 09:49:50 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 09:49:50 --> Final output sent to browser
DEBUG - 2016-02-25 09:49:50 --> Total execution time: 1.1871
INFO - 2016-02-25 06:49:55 --> Config Class Initialized
INFO - 2016-02-25 06:49:55 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:49:55 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:49:55 --> Utf8 Class Initialized
INFO - 2016-02-25 06:49:55 --> URI Class Initialized
INFO - 2016-02-25 06:49:55 --> Router Class Initialized
INFO - 2016-02-25 06:49:55 --> Output Class Initialized
INFO - 2016-02-25 06:49:55 --> Security Class Initialized
DEBUG - 2016-02-25 06:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:49:55 --> Input Class Initialized
INFO - 2016-02-25 06:49:55 --> Language Class Initialized
INFO - 2016-02-25 06:49:55 --> Loader Class Initialized
INFO - 2016-02-25 06:49:55 --> Helper loaded: url_helper
INFO - 2016-02-25 06:49:55 --> Helper loaded: file_helper
INFO - 2016-02-25 06:49:55 --> Helper loaded: date_helper
INFO - 2016-02-25 06:49:55 --> Helper loaded: form_helper
INFO - 2016-02-25 06:49:55 --> Database Driver Class Initialized
INFO - 2016-02-25 06:49:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:49:56 --> Controller Class Initialized
INFO - 2016-02-25 06:49:56 --> Model Class Initialized
INFO - 2016-02-25 06:49:56 --> Model Class Initialized
INFO - 2016-02-25 06:49:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:49:56 --> Pagination Class Initialized
INFO - 2016-02-25 06:49:56 --> Helper loaded: text_helper
INFO - 2016-02-25 06:49:56 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 09:49:56 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 09:49:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:49:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:49:57 --> Form Validation Class Initialized
INFO - 2016-02-25 09:49:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 06:49:58 --> Config Class Initialized
INFO - 2016-02-25 06:49:58 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:49:58 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:49:58 --> Utf8 Class Initialized
INFO - 2016-02-25 06:49:58 --> URI Class Initialized
INFO - 2016-02-25 06:49:58 --> Router Class Initialized
INFO - 2016-02-25 06:49:58 --> Output Class Initialized
INFO - 2016-02-25 06:49:58 --> Security Class Initialized
DEBUG - 2016-02-25 06:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:49:58 --> Input Class Initialized
INFO - 2016-02-25 06:49:58 --> Language Class Initialized
INFO - 2016-02-25 06:49:58 --> Loader Class Initialized
INFO - 2016-02-25 06:49:58 --> Helper loaded: url_helper
INFO - 2016-02-25 06:49:58 --> Helper loaded: file_helper
INFO - 2016-02-25 06:49:58 --> Helper loaded: date_helper
INFO - 2016-02-25 06:49:58 --> Helper loaded: form_helper
INFO - 2016-02-25 06:49:58 --> Database Driver Class Initialized
INFO - 2016-02-25 06:49:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:49:59 --> Controller Class Initialized
INFO - 2016-02-25 06:49:59 --> Model Class Initialized
INFO - 2016-02-25 06:49:59 --> Model Class Initialized
INFO - 2016-02-25 06:49:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:49:59 --> Pagination Class Initialized
INFO - 2016-02-25 06:49:59 --> Helper loaded: text_helper
INFO - 2016-02-25 06:49:59 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:49:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:49:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:49:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 09:49:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 09:49:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:49:59 --> Final output sent to browser
DEBUG - 2016-02-25 09:49:59 --> Total execution time: 1.2294
INFO - 2016-02-25 06:52:29 --> Config Class Initialized
INFO - 2016-02-25 06:52:29 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:52:29 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:52:29 --> Utf8 Class Initialized
INFO - 2016-02-25 06:52:29 --> URI Class Initialized
INFO - 2016-02-25 06:52:29 --> Router Class Initialized
INFO - 2016-02-25 06:52:29 --> Output Class Initialized
INFO - 2016-02-25 06:52:29 --> Security Class Initialized
DEBUG - 2016-02-25 06:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:52:29 --> Input Class Initialized
INFO - 2016-02-25 06:52:29 --> Language Class Initialized
INFO - 2016-02-25 06:52:29 --> Loader Class Initialized
INFO - 2016-02-25 06:52:29 --> Helper loaded: url_helper
INFO - 2016-02-25 06:52:29 --> Helper loaded: file_helper
INFO - 2016-02-25 06:52:29 --> Helper loaded: date_helper
INFO - 2016-02-25 06:52:29 --> Helper loaded: form_helper
INFO - 2016-02-25 06:52:29 --> Database Driver Class Initialized
INFO - 2016-02-25 06:52:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:52:30 --> Controller Class Initialized
INFO - 2016-02-25 06:52:30 --> Model Class Initialized
INFO - 2016-02-25 06:52:30 --> Model Class Initialized
INFO - 2016-02-25 06:52:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:52:30 --> Pagination Class Initialized
INFO - 2016-02-25 06:52:30 --> Helper loaded: text_helper
INFO - 2016-02-25 06:52:30 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:52:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:52:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:52:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 09:52:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:52:30 --> Final output sent to browser
DEBUG - 2016-02-25 09:52:30 --> Total execution time: 1.2514
INFO - 2016-02-25 06:52:33 --> Config Class Initialized
INFO - 2016-02-25 06:52:33 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:52:33 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:52:33 --> Utf8 Class Initialized
INFO - 2016-02-25 06:52:33 --> URI Class Initialized
INFO - 2016-02-25 06:52:33 --> Router Class Initialized
INFO - 2016-02-25 06:52:33 --> Output Class Initialized
INFO - 2016-02-25 06:52:33 --> Security Class Initialized
DEBUG - 2016-02-25 06:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:52:33 --> Input Class Initialized
INFO - 2016-02-25 06:52:33 --> Language Class Initialized
INFO - 2016-02-25 06:52:33 --> Loader Class Initialized
INFO - 2016-02-25 06:52:33 --> Helper loaded: url_helper
INFO - 2016-02-25 06:52:33 --> Helper loaded: file_helper
INFO - 2016-02-25 06:52:33 --> Helper loaded: date_helper
INFO - 2016-02-25 06:52:33 --> Helper loaded: form_helper
INFO - 2016-02-25 06:52:33 --> Database Driver Class Initialized
INFO - 2016-02-25 06:52:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:52:34 --> Controller Class Initialized
INFO - 2016-02-25 06:52:34 --> Model Class Initialized
INFO - 2016-02-25 06:52:34 --> Model Class Initialized
INFO - 2016-02-25 06:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:52:34 --> Pagination Class Initialized
INFO - 2016-02-25 06:52:34 --> Helper loaded: text_helper
INFO - 2016-02-25 06:52:34 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 09:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 09:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:52:34 --> Final output sent to browser
DEBUG - 2016-02-25 09:52:34 --> Total execution time: 1.1591
INFO - 2016-02-25 06:53:19 --> Config Class Initialized
INFO - 2016-02-25 06:53:19 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:53:19 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:53:19 --> Utf8 Class Initialized
INFO - 2016-02-25 06:53:19 --> URI Class Initialized
INFO - 2016-02-25 06:53:19 --> Router Class Initialized
INFO - 2016-02-25 06:53:19 --> Output Class Initialized
INFO - 2016-02-25 06:53:19 --> Security Class Initialized
DEBUG - 2016-02-25 06:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:53:19 --> Input Class Initialized
INFO - 2016-02-25 06:53:19 --> Language Class Initialized
INFO - 2016-02-25 06:53:19 --> Loader Class Initialized
INFO - 2016-02-25 06:53:19 --> Helper loaded: url_helper
INFO - 2016-02-25 06:53:19 --> Helper loaded: file_helper
INFO - 2016-02-25 06:53:19 --> Helper loaded: date_helper
INFO - 2016-02-25 06:53:19 --> Helper loaded: form_helper
INFO - 2016-02-25 06:53:19 --> Database Driver Class Initialized
INFO - 2016-02-25 06:53:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:53:21 --> Controller Class Initialized
INFO - 2016-02-25 06:53:21 --> Model Class Initialized
INFO - 2016-02-25 06:53:21 --> Model Class Initialized
INFO - 2016-02-25 06:53:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:53:21 --> Pagination Class Initialized
INFO - 2016-02-25 06:53:21 --> Helper loaded: text_helper
INFO - 2016-02-25 06:53:21 --> Helper loaded: cookie_helper
INFO - 2016-02-25 06:53:21 --> Image Lib Class Initialized
INFO - 2016-02-25 09:53:21 --> Upload Class Initialized
DEBUG - 2016-02-25 09:53:21 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 09:53:21 --> Final output sent to browser
DEBUG - 2016-02-25 09:53:21 --> Total execution time: 1.2560
INFO - 2016-02-25 06:53:29 --> Config Class Initialized
INFO - 2016-02-25 06:53:29 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:53:29 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:53:29 --> Utf8 Class Initialized
INFO - 2016-02-25 06:53:29 --> URI Class Initialized
INFO - 2016-02-25 06:53:29 --> Router Class Initialized
INFO - 2016-02-25 06:53:29 --> Output Class Initialized
INFO - 2016-02-25 06:53:29 --> Security Class Initialized
DEBUG - 2016-02-25 06:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:53:29 --> Input Class Initialized
INFO - 2016-02-25 06:53:29 --> Language Class Initialized
INFO - 2016-02-25 06:53:29 --> Loader Class Initialized
INFO - 2016-02-25 06:53:29 --> Helper loaded: url_helper
INFO - 2016-02-25 06:53:29 --> Helper loaded: file_helper
INFO - 2016-02-25 06:53:29 --> Helper loaded: date_helper
INFO - 2016-02-25 06:53:29 --> Helper loaded: form_helper
INFO - 2016-02-25 06:53:29 --> Database Driver Class Initialized
INFO - 2016-02-25 06:53:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:53:30 --> Controller Class Initialized
INFO - 2016-02-25 06:53:30 --> Model Class Initialized
INFO - 2016-02-25 06:53:30 --> Model Class Initialized
INFO - 2016-02-25 06:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:53:30 --> Pagination Class Initialized
INFO - 2016-02-25 06:53:30 --> Helper loaded: text_helper
INFO - 2016-02-25 06:53:30 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 09:53:30 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 09:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:53:30 --> Form Validation Class Initialized
INFO - 2016-02-25 09:53:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 06:53:30 --> Config Class Initialized
INFO - 2016-02-25 06:53:30 --> Hooks Class Initialized
DEBUG - 2016-02-25 06:53:30 --> UTF-8 Support Enabled
INFO - 2016-02-25 06:53:30 --> Utf8 Class Initialized
INFO - 2016-02-25 06:53:30 --> URI Class Initialized
INFO - 2016-02-25 06:53:30 --> Router Class Initialized
INFO - 2016-02-25 06:53:30 --> Output Class Initialized
INFO - 2016-02-25 06:53:30 --> Security Class Initialized
DEBUG - 2016-02-25 06:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 06:53:30 --> Input Class Initialized
INFO - 2016-02-25 06:53:30 --> Language Class Initialized
INFO - 2016-02-25 06:53:30 --> Loader Class Initialized
INFO - 2016-02-25 06:53:30 --> Helper loaded: url_helper
INFO - 2016-02-25 06:53:30 --> Helper loaded: file_helper
INFO - 2016-02-25 06:53:30 --> Helper loaded: date_helper
INFO - 2016-02-25 06:53:30 --> Helper loaded: form_helper
INFO - 2016-02-25 06:53:31 --> Database Driver Class Initialized
INFO - 2016-02-25 06:53:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 06:53:32 --> Controller Class Initialized
INFO - 2016-02-25 06:53:32 --> Model Class Initialized
INFO - 2016-02-25 06:53:32 --> Model Class Initialized
INFO - 2016-02-25 06:53:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 06:53:32 --> Pagination Class Initialized
INFO - 2016-02-25 06:53:32 --> Helper loaded: text_helper
INFO - 2016-02-25 06:53:32 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 09:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 09:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 09:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 09:53:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 09:53:32 --> Final output sent to browser
DEBUG - 2016-02-25 09:53:32 --> Total execution time: 1.2770
INFO - 2016-02-25 07:15:36 --> Config Class Initialized
INFO - 2016-02-25 07:15:36 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:15:37 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:15:37 --> Utf8 Class Initialized
INFO - 2016-02-25 07:15:37 --> URI Class Initialized
DEBUG - 2016-02-25 07:15:37 --> No URI present. Default controller set.
INFO - 2016-02-25 07:15:37 --> Router Class Initialized
INFO - 2016-02-25 07:15:37 --> Output Class Initialized
INFO - 2016-02-25 07:15:37 --> Security Class Initialized
DEBUG - 2016-02-25 07:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:15:37 --> Input Class Initialized
INFO - 2016-02-25 07:15:37 --> Language Class Initialized
INFO - 2016-02-25 07:15:37 --> Loader Class Initialized
INFO - 2016-02-25 07:15:38 --> Helper loaded: url_helper
INFO - 2016-02-25 07:15:38 --> Helper loaded: file_helper
INFO - 2016-02-25 07:15:38 --> Helper loaded: date_helper
INFO - 2016-02-25 07:15:38 --> Helper loaded: form_helper
INFO - 2016-02-25 07:15:38 --> Database Driver Class Initialized
INFO - 2016-02-25 07:15:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:15:40 --> Controller Class Initialized
INFO - 2016-02-25 07:15:40 --> Model Class Initialized
INFO - 2016-02-25 07:15:41 --> Model Class Initialized
INFO - 2016-02-25 07:15:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:15:41 --> Pagination Class Initialized
INFO - 2016-02-25 07:15:41 --> Helper loaded: text_helper
INFO - 2016-02-25 07:15:41 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:15:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:15:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-25 10:15:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:15:43 --> Final output sent to browser
DEBUG - 2016-02-25 10:15:43 --> Total execution time: 6.8819
INFO - 2016-02-25 07:17:39 --> Config Class Initialized
INFO - 2016-02-25 07:17:39 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:17:39 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:17:39 --> Utf8 Class Initialized
INFO - 2016-02-25 07:17:39 --> URI Class Initialized
INFO - 2016-02-25 07:17:39 --> Router Class Initialized
INFO - 2016-02-25 07:17:39 --> Output Class Initialized
INFO - 2016-02-25 07:17:39 --> Security Class Initialized
DEBUG - 2016-02-25 07:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:17:39 --> Input Class Initialized
INFO - 2016-02-25 07:17:39 --> Language Class Initialized
INFO - 2016-02-25 07:17:39 --> Loader Class Initialized
INFO - 2016-02-25 07:17:39 --> Helper loaded: url_helper
INFO - 2016-02-25 07:17:39 --> Helper loaded: file_helper
INFO - 2016-02-25 07:17:39 --> Helper loaded: date_helper
INFO - 2016-02-25 07:17:39 --> Helper loaded: form_helper
INFO - 2016-02-25 07:17:39 --> Database Driver Class Initialized
INFO - 2016-02-25 07:17:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:17:40 --> Controller Class Initialized
INFO - 2016-02-25 07:17:40 --> Model Class Initialized
INFO - 2016-02-25 07:17:40 --> Model Class Initialized
INFO - 2016-02-25 07:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:17:40 --> Pagination Class Initialized
INFO - 2016-02-25 07:17:40 --> Helper loaded: text_helper
INFO - 2016-02-25 07:17:40 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:17:40 --> Final output sent to browser
DEBUG - 2016-02-25 10:17:40 --> Total execution time: 1.9588
INFO - 2016-02-25 07:18:01 --> Config Class Initialized
INFO - 2016-02-25 07:18:01 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:18:01 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:18:01 --> Utf8 Class Initialized
INFO - 2016-02-25 07:18:01 --> URI Class Initialized
INFO - 2016-02-25 07:18:01 --> Router Class Initialized
INFO - 2016-02-25 07:18:01 --> Output Class Initialized
INFO - 2016-02-25 07:18:01 --> Security Class Initialized
DEBUG - 2016-02-25 07:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:18:01 --> Input Class Initialized
INFO - 2016-02-25 07:18:01 --> Language Class Initialized
INFO - 2016-02-25 07:18:01 --> Loader Class Initialized
INFO - 2016-02-25 07:18:01 --> Helper loaded: url_helper
INFO - 2016-02-25 07:18:01 --> Helper loaded: file_helper
INFO - 2016-02-25 07:18:01 --> Helper loaded: date_helper
INFO - 2016-02-25 07:18:01 --> Helper loaded: form_helper
INFO - 2016-02-25 07:18:01 --> Database Driver Class Initialized
INFO - 2016-02-25 07:18:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:18:02 --> Controller Class Initialized
INFO - 2016-02-25 07:18:02 --> Model Class Initialized
INFO - 2016-02-25 07:18:02 --> Model Class Initialized
INFO - 2016-02-25 07:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:18:02 --> Pagination Class Initialized
INFO - 2016-02-25 07:18:02 --> Helper loaded: text_helper
INFO - 2016-02-25 07:18:02 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:18:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:18:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:18:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:18:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:18:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:18:03 --> Final output sent to browser
DEBUG - 2016-02-25 10:18:03 --> Total execution time: 1.2516
INFO - 2016-02-25 07:18:35 --> Config Class Initialized
INFO - 2016-02-25 07:18:35 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:18:35 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:18:35 --> Utf8 Class Initialized
INFO - 2016-02-25 07:18:35 --> URI Class Initialized
INFO - 2016-02-25 07:18:35 --> Router Class Initialized
INFO - 2016-02-25 07:18:35 --> Output Class Initialized
INFO - 2016-02-25 07:18:35 --> Security Class Initialized
DEBUG - 2016-02-25 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:18:35 --> Input Class Initialized
INFO - 2016-02-25 07:18:35 --> Language Class Initialized
INFO - 2016-02-25 07:18:35 --> Loader Class Initialized
INFO - 2016-02-25 07:18:35 --> Helper loaded: url_helper
INFO - 2016-02-25 07:18:35 --> Helper loaded: file_helper
INFO - 2016-02-25 07:18:35 --> Helper loaded: date_helper
INFO - 2016-02-25 07:18:35 --> Helper loaded: form_helper
INFO - 2016-02-25 07:18:35 --> Database Driver Class Initialized
INFO - 2016-02-25 07:18:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:18:36 --> Controller Class Initialized
INFO - 2016-02-25 07:18:36 --> Model Class Initialized
INFO - 2016-02-25 07:18:36 --> Model Class Initialized
INFO - 2016-02-25 07:18:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:18:36 --> Pagination Class Initialized
INFO - 2016-02-25 07:18:36 --> Helper loaded: text_helper
INFO - 2016-02-25 07:18:36 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:18:36 --> Image Lib Class Initialized
INFO - 2016-02-25 10:18:36 --> Upload Class Initialized
DEBUG - 2016-02-25 10:18:36 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 10:18:36 --> Final output sent to browser
DEBUG - 2016-02-25 10:18:36 --> Total execution time: 1.2535
INFO - 2016-02-25 07:18:49 --> Config Class Initialized
INFO - 2016-02-25 07:18:49 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:18:49 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:18:49 --> Utf8 Class Initialized
INFO - 2016-02-25 07:18:49 --> URI Class Initialized
INFO - 2016-02-25 07:18:49 --> Router Class Initialized
INFO - 2016-02-25 07:18:49 --> Output Class Initialized
INFO - 2016-02-25 07:18:49 --> Security Class Initialized
DEBUG - 2016-02-25 07:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:18:49 --> Input Class Initialized
INFO - 2016-02-25 07:18:49 --> Language Class Initialized
INFO - 2016-02-25 07:18:49 --> Loader Class Initialized
INFO - 2016-02-25 07:18:49 --> Helper loaded: url_helper
INFO - 2016-02-25 07:18:49 --> Helper loaded: file_helper
INFO - 2016-02-25 07:18:49 --> Helper loaded: date_helper
INFO - 2016-02-25 07:18:49 --> Helper loaded: form_helper
INFO - 2016-02-25 07:18:49 --> Database Driver Class Initialized
INFO - 2016-02-25 07:18:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:18:50 --> Controller Class Initialized
INFO - 2016-02-25 07:18:50 --> Model Class Initialized
INFO - 2016-02-25 07:18:50 --> Model Class Initialized
INFO - 2016-02-25 07:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:18:50 --> Pagination Class Initialized
INFO - 2016-02-25 07:18:50 --> Helper loaded: text_helper
INFO - 2016-02-25 07:18:50 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:18:50 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:18:50 --> Form Validation Class Initialized
INFO - 2016-02-25 10:18:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:18:51 --> Config Class Initialized
INFO - 2016-02-25 07:18:51 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:18:51 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:18:51 --> Utf8 Class Initialized
INFO - 2016-02-25 07:18:51 --> URI Class Initialized
INFO - 2016-02-25 07:18:51 --> Router Class Initialized
INFO - 2016-02-25 07:18:51 --> Output Class Initialized
INFO - 2016-02-25 07:18:51 --> Security Class Initialized
DEBUG - 2016-02-25 07:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:18:51 --> Input Class Initialized
INFO - 2016-02-25 07:18:51 --> Language Class Initialized
INFO - 2016-02-25 07:18:51 --> Loader Class Initialized
INFO - 2016-02-25 07:18:51 --> Helper loaded: url_helper
INFO - 2016-02-25 07:18:51 --> Helper loaded: file_helper
INFO - 2016-02-25 07:18:51 --> Helper loaded: date_helper
INFO - 2016-02-25 07:18:51 --> Helper loaded: form_helper
INFO - 2016-02-25 07:18:51 --> Database Driver Class Initialized
INFO - 2016-02-25 07:18:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:18:52 --> Controller Class Initialized
INFO - 2016-02-25 07:18:52 --> Model Class Initialized
INFO - 2016-02-25 07:18:52 --> Model Class Initialized
INFO - 2016-02-25 07:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:18:52 --> Pagination Class Initialized
INFO - 2016-02-25 07:18:52 --> Helper loaded: text_helper
INFO - 2016-02-25 07:18:52 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:18:52 --> Final output sent to browser
DEBUG - 2016-02-25 10:18:52 --> Total execution time: 1.2212
INFO - 2016-02-25 07:19:26 --> Config Class Initialized
INFO - 2016-02-25 07:19:26 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:19:26 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:19:26 --> Utf8 Class Initialized
INFO - 2016-02-25 07:19:26 --> URI Class Initialized
INFO - 2016-02-25 07:19:26 --> Router Class Initialized
INFO - 2016-02-25 07:19:26 --> Output Class Initialized
INFO - 2016-02-25 07:19:26 --> Security Class Initialized
DEBUG - 2016-02-25 07:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:19:26 --> Input Class Initialized
INFO - 2016-02-25 07:19:26 --> Language Class Initialized
INFO - 2016-02-25 07:19:26 --> Loader Class Initialized
INFO - 2016-02-25 07:19:26 --> Helper loaded: url_helper
INFO - 2016-02-25 07:19:26 --> Helper loaded: file_helper
INFO - 2016-02-25 07:19:26 --> Helper loaded: date_helper
INFO - 2016-02-25 07:19:26 --> Helper loaded: form_helper
INFO - 2016-02-25 07:19:26 --> Database Driver Class Initialized
INFO - 2016-02-25 07:19:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:19:27 --> Controller Class Initialized
INFO - 2016-02-25 07:19:27 --> Model Class Initialized
INFO - 2016-02-25 07:19:27 --> Model Class Initialized
INFO - 2016-02-25 07:19:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:19:27 --> Pagination Class Initialized
INFO - 2016-02-25 07:19:27 --> Helper loaded: text_helper
INFO - 2016-02-25 07:19:27 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:19:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:19:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:19:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:19:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:19:27 --> Final output sent to browser
DEBUG - 2016-02-25 10:19:27 --> Total execution time: 1.1754
INFO - 2016-02-25 07:19:29 --> Config Class Initialized
INFO - 2016-02-25 07:19:29 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:19:29 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:19:29 --> Utf8 Class Initialized
INFO - 2016-02-25 07:19:29 --> URI Class Initialized
INFO - 2016-02-25 07:19:29 --> Router Class Initialized
INFO - 2016-02-25 07:19:29 --> Output Class Initialized
INFO - 2016-02-25 07:19:29 --> Security Class Initialized
DEBUG - 2016-02-25 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:19:29 --> Input Class Initialized
INFO - 2016-02-25 07:19:29 --> Language Class Initialized
INFO - 2016-02-25 07:19:29 --> Loader Class Initialized
INFO - 2016-02-25 07:19:29 --> Helper loaded: url_helper
INFO - 2016-02-25 07:19:29 --> Helper loaded: file_helper
INFO - 2016-02-25 07:19:29 --> Helper loaded: date_helper
INFO - 2016-02-25 07:19:29 --> Helper loaded: form_helper
INFO - 2016-02-25 07:19:29 --> Database Driver Class Initialized
INFO - 2016-02-25 07:19:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:19:30 --> Controller Class Initialized
INFO - 2016-02-25 07:19:30 --> Model Class Initialized
INFO - 2016-02-25 07:19:30 --> Model Class Initialized
INFO - 2016-02-25 07:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:19:30 --> Pagination Class Initialized
INFO - 2016-02-25 07:19:30 --> Helper loaded: text_helper
INFO - 2016-02-25 07:19:30 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:19:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:19:30 --> Final output sent to browser
DEBUG - 2016-02-25 10:19:30 --> Total execution time: 1.1664
INFO - 2016-02-25 07:19:51 --> Config Class Initialized
INFO - 2016-02-25 07:19:51 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:19:51 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:19:51 --> Utf8 Class Initialized
INFO - 2016-02-25 07:19:51 --> URI Class Initialized
INFO - 2016-02-25 07:19:51 --> Router Class Initialized
INFO - 2016-02-25 07:19:51 --> Output Class Initialized
INFO - 2016-02-25 07:19:51 --> Security Class Initialized
DEBUG - 2016-02-25 07:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:19:51 --> Input Class Initialized
INFO - 2016-02-25 07:19:51 --> Language Class Initialized
INFO - 2016-02-25 07:19:51 --> Loader Class Initialized
INFO - 2016-02-25 07:19:51 --> Helper loaded: url_helper
INFO - 2016-02-25 07:19:51 --> Helper loaded: file_helper
INFO - 2016-02-25 07:19:51 --> Helper loaded: date_helper
INFO - 2016-02-25 07:19:51 --> Helper loaded: form_helper
INFO - 2016-02-25 07:19:51 --> Database Driver Class Initialized
INFO - 2016-02-25 07:19:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:19:52 --> Controller Class Initialized
INFO - 2016-02-25 07:19:52 --> Model Class Initialized
INFO - 2016-02-25 07:19:52 --> Model Class Initialized
INFO - 2016-02-25 07:19:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:19:52 --> Pagination Class Initialized
INFO - 2016-02-25 07:19:52 --> Helper loaded: text_helper
INFO - 2016-02-25 07:19:52 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:19:52 --> Image Lib Class Initialized
INFO - 2016-02-25 10:19:52 --> Upload Class Initialized
DEBUG - 2016-02-25 10:19:52 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 10:19:52 --> Final output sent to browser
DEBUG - 2016-02-25 10:19:53 --> Total execution time: 1.1429
INFO - 2016-02-25 07:19:57 --> Config Class Initialized
INFO - 2016-02-25 07:19:57 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:19:57 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:19:57 --> Utf8 Class Initialized
INFO - 2016-02-25 07:19:57 --> URI Class Initialized
INFO - 2016-02-25 07:19:57 --> Router Class Initialized
INFO - 2016-02-25 07:19:57 --> Output Class Initialized
INFO - 2016-02-25 07:19:57 --> Security Class Initialized
DEBUG - 2016-02-25 07:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:19:57 --> Input Class Initialized
INFO - 2016-02-25 07:19:57 --> Language Class Initialized
INFO - 2016-02-25 07:19:57 --> Loader Class Initialized
INFO - 2016-02-25 07:19:57 --> Helper loaded: url_helper
INFO - 2016-02-25 07:19:57 --> Helper loaded: file_helper
INFO - 2016-02-25 07:19:57 --> Helper loaded: date_helper
INFO - 2016-02-25 07:19:57 --> Helper loaded: form_helper
INFO - 2016-02-25 07:19:57 --> Database Driver Class Initialized
INFO - 2016-02-25 07:19:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:19:58 --> Controller Class Initialized
INFO - 2016-02-25 07:19:58 --> Model Class Initialized
INFO - 2016-02-25 07:19:58 --> Model Class Initialized
INFO - 2016-02-25 07:19:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:19:58 --> Pagination Class Initialized
INFO - 2016-02-25 07:19:58 --> Helper loaded: text_helper
INFO - 2016-02-25 07:19:58 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:19:58 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:19:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:19:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:19:58 --> Form Validation Class Initialized
INFO - 2016-02-25 10:19:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:19:58 --> Config Class Initialized
INFO - 2016-02-25 07:19:58 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:19:58 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:19:58 --> Utf8 Class Initialized
INFO - 2016-02-25 07:19:58 --> URI Class Initialized
INFO - 2016-02-25 07:19:58 --> Router Class Initialized
INFO - 2016-02-25 07:19:58 --> Output Class Initialized
INFO - 2016-02-25 07:19:58 --> Security Class Initialized
DEBUG - 2016-02-25 07:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:19:58 --> Input Class Initialized
INFO - 2016-02-25 07:19:58 --> Language Class Initialized
INFO - 2016-02-25 07:19:58 --> Loader Class Initialized
INFO - 2016-02-25 07:19:58 --> Helper loaded: url_helper
INFO - 2016-02-25 07:19:58 --> Helper loaded: file_helper
INFO - 2016-02-25 07:19:59 --> Helper loaded: date_helper
INFO - 2016-02-25 07:19:59 --> Helper loaded: form_helper
INFO - 2016-02-25 07:19:59 --> Database Driver Class Initialized
INFO - 2016-02-25 07:20:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:20:00 --> Controller Class Initialized
INFO - 2016-02-25 07:20:00 --> Model Class Initialized
INFO - 2016-02-25 07:20:00 --> Model Class Initialized
INFO - 2016-02-25 07:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:20:00 --> Pagination Class Initialized
INFO - 2016-02-25 07:20:00 --> Helper loaded: text_helper
INFO - 2016-02-25 07:20:00 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:20:00 --> Final output sent to browser
DEBUG - 2016-02-25 10:20:00 --> Total execution time: 1.2507
INFO - 2016-02-25 07:20:50 --> Config Class Initialized
INFO - 2016-02-25 07:20:50 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:20:50 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:20:50 --> Utf8 Class Initialized
INFO - 2016-02-25 07:20:50 --> URI Class Initialized
INFO - 2016-02-25 07:20:50 --> Router Class Initialized
INFO - 2016-02-25 07:20:50 --> Output Class Initialized
INFO - 2016-02-25 07:20:50 --> Security Class Initialized
DEBUG - 2016-02-25 07:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:20:50 --> Input Class Initialized
INFO - 2016-02-25 07:20:50 --> Language Class Initialized
INFO - 2016-02-25 07:20:50 --> Loader Class Initialized
INFO - 2016-02-25 07:20:50 --> Helper loaded: url_helper
INFO - 2016-02-25 07:20:50 --> Helper loaded: file_helper
INFO - 2016-02-25 07:20:50 --> Helper loaded: date_helper
INFO - 2016-02-25 07:20:50 --> Helper loaded: form_helper
INFO - 2016-02-25 07:20:50 --> Database Driver Class Initialized
INFO - 2016-02-25 07:20:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:20:51 --> Controller Class Initialized
INFO - 2016-02-25 07:20:51 --> Model Class Initialized
INFO - 2016-02-25 07:20:51 --> Model Class Initialized
INFO - 2016-02-25 07:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:20:51 --> Pagination Class Initialized
INFO - 2016-02-25 07:20:51 --> Helper loaded: text_helper
INFO - 2016-02-25 07:20:51 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:20:51 --> Final output sent to browser
DEBUG - 2016-02-25 10:20:51 --> Total execution time: 1.1450
INFO - 2016-02-25 07:20:53 --> Config Class Initialized
INFO - 2016-02-25 07:20:53 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:20:53 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:20:53 --> Utf8 Class Initialized
INFO - 2016-02-25 07:20:53 --> URI Class Initialized
INFO - 2016-02-25 07:20:53 --> Router Class Initialized
INFO - 2016-02-25 07:20:53 --> Output Class Initialized
INFO - 2016-02-25 07:20:53 --> Security Class Initialized
DEBUG - 2016-02-25 07:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:20:53 --> Input Class Initialized
INFO - 2016-02-25 07:20:53 --> Language Class Initialized
INFO - 2016-02-25 07:20:53 --> Loader Class Initialized
INFO - 2016-02-25 07:20:53 --> Helper loaded: url_helper
INFO - 2016-02-25 07:20:53 --> Helper loaded: file_helper
INFO - 2016-02-25 07:20:53 --> Helper loaded: date_helper
INFO - 2016-02-25 07:20:53 --> Helper loaded: form_helper
INFO - 2016-02-25 07:20:53 --> Database Driver Class Initialized
INFO - 2016-02-25 07:20:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:20:54 --> Controller Class Initialized
INFO - 2016-02-25 07:20:54 --> Model Class Initialized
INFO - 2016-02-25 07:20:54 --> Model Class Initialized
INFO - 2016-02-25 07:20:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:20:54 --> Pagination Class Initialized
INFO - 2016-02-25 07:20:54 --> Helper loaded: text_helper
INFO - 2016-02-25 07:20:54 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:20:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:20:54 --> Final output sent to browser
DEBUG - 2016-02-25 10:20:54 --> Total execution time: 1.2092
INFO - 2016-02-25 07:21:12 --> Config Class Initialized
INFO - 2016-02-25 07:21:12 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:21:12 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:21:12 --> Utf8 Class Initialized
INFO - 2016-02-25 07:21:12 --> URI Class Initialized
INFO - 2016-02-25 07:21:12 --> Router Class Initialized
INFO - 2016-02-25 07:21:12 --> Output Class Initialized
INFO - 2016-02-25 07:21:12 --> Security Class Initialized
DEBUG - 2016-02-25 07:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:21:12 --> Input Class Initialized
INFO - 2016-02-25 07:21:12 --> Language Class Initialized
ERROR - 2016-02-25 07:21:12 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 442
INFO - 2016-02-25 07:21:26 --> Config Class Initialized
INFO - 2016-02-25 07:21:26 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:21:26 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:21:26 --> Utf8 Class Initialized
INFO - 2016-02-25 07:21:26 --> URI Class Initialized
INFO - 2016-02-25 07:21:26 --> Router Class Initialized
INFO - 2016-02-25 07:21:26 --> Output Class Initialized
INFO - 2016-02-25 07:21:26 --> Security Class Initialized
DEBUG - 2016-02-25 07:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:21:26 --> Input Class Initialized
INFO - 2016-02-25 07:21:26 --> Language Class Initialized
ERROR - 2016-02-25 07:21:26 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 442
INFO - 2016-02-25 07:21:42 --> Config Class Initialized
INFO - 2016-02-25 07:21:42 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:21:42 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:21:42 --> Utf8 Class Initialized
INFO - 2016-02-25 07:21:42 --> URI Class Initialized
INFO - 2016-02-25 07:21:42 --> Router Class Initialized
INFO - 2016-02-25 07:21:42 --> Output Class Initialized
INFO - 2016-02-25 07:21:42 --> Security Class Initialized
DEBUG - 2016-02-25 07:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:21:42 --> Input Class Initialized
INFO - 2016-02-25 07:21:42 --> Language Class Initialized
ERROR - 2016-02-25 07:21:42 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 442
INFO - 2016-02-25 07:21:58 --> Config Class Initialized
INFO - 2016-02-25 07:21:58 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:21:58 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:21:58 --> Utf8 Class Initialized
INFO - 2016-02-25 07:21:58 --> URI Class Initialized
INFO - 2016-02-25 07:21:58 --> Router Class Initialized
INFO - 2016-02-25 07:21:58 --> Output Class Initialized
INFO - 2016-02-25 07:21:58 --> Security Class Initialized
DEBUG - 2016-02-25 07:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:21:58 --> Input Class Initialized
INFO - 2016-02-25 07:21:58 --> Language Class Initialized
INFO - 2016-02-25 07:21:58 --> Loader Class Initialized
INFO - 2016-02-25 07:21:58 --> Helper loaded: url_helper
INFO - 2016-02-25 07:21:58 --> Helper loaded: file_helper
INFO - 2016-02-25 07:21:58 --> Helper loaded: date_helper
INFO - 2016-02-25 07:21:58 --> Helper loaded: form_helper
INFO - 2016-02-25 07:21:58 --> Database Driver Class Initialized
INFO - 2016-02-25 07:21:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:21:59 --> Controller Class Initialized
INFO - 2016-02-25 07:21:59 --> Model Class Initialized
INFO - 2016-02-25 07:21:59 --> Model Class Initialized
INFO - 2016-02-25 07:21:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:21:59 --> Pagination Class Initialized
INFO - 2016-02-25 07:21:59 --> Helper loaded: text_helper
INFO - 2016-02-25 07:21:59 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:21:59 --> Image Lib Class Initialized
INFO - 2016-02-25 10:21:59 --> Upload Class Initialized
DEBUG - 2016-02-25 10:21:59 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 10:21:59 --> Final output sent to browser
DEBUG - 2016-02-25 10:21:59 --> Total execution time: 1.1902
INFO - 2016-02-25 07:22:03 --> Config Class Initialized
INFO - 2016-02-25 07:22:03 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:22:03 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:22:03 --> Utf8 Class Initialized
INFO - 2016-02-25 07:22:03 --> URI Class Initialized
INFO - 2016-02-25 07:22:03 --> Router Class Initialized
INFO - 2016-02-25 07:22:03 --> Output Class Initialized
INFO - 2016-02-25 07:22:03 --> Security Class Initialized
DEBUG - 2016-02-25 07:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:22:03 --> Input Class Initialized
INFO - 2016-02-25 07:22:03 --> Language Class Initialized
INFO - 2016-02-25 07:22:03 --> Loader Class Initialized
INFO - 2016-02-25 07:22:03 --> Helper loaded: url_helper
INFO - 2016-02-25 07:22:03 --> Helper loaded: file_helper
INFO - 2016-02-25 07:22:03 --> Helper loaded: date_helper
INFO - 2016-02-25 07:22:03 --> Helper loaded: form_helper
INFO - 2016-02-25 07:22:03 --> Database Driver Class Initialized
INFO - 2016-02-25 07:22:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:22:05 --> Controller Class Initialized
INFO - 2016-02-25 07:22:05 --> Model Class Initialized
INFO - 2016-02-25 07:22:05 --> Model Class Initialized
INFO - 2016-02-25 07:22:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:22:05 --> Pagination Class Initialized
INFO - 2016-02-25 07:22:05 --> Helper loaded: text_helper
INFO - 2016-02-25 07:22:05 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:22:05 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:22:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:22:05 --> Form Validation Class Initialized
INFO - 2016-02-25 10:22:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:22:05 --> Config Class Initialized
INFO - 2016-02-25 07:22:05 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:22:05 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:22:05 --> Utf8 Class Initialized
INFO - 2016-02-25 07:22:05 --> URI Class Initialized
INFO - 2016-02-25 07:22:05 --> Router Class Initialized
INFO - 2016-02-25 07:22:05 --> Output Class Initialized
INFO - 2016-02-25 07:22:05 --> Security Class Initialized
DEBUG - 2016-02-25 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:22:05 --> Input Class Initialized
INFO - 2016-02-25 07:22:05 --> Language Class Initialized
INFO - 2016-02-25 07:22:05 --> Loader Class Initialized
INFO - 2016-02-25 07:22:05 --> Helper loaded: url_helper
INFO - 2016-02-25 07:22:05 --> Helper loaded: file_helper
INFO - 2016-02-25 07:22:05 --> Helper loaded: date_helper
INFO - 2016-02-25 07:22:05 --> Helper loaded: form_helper
INFO - 2016-02-25 07:22:05 --> Database Driver Class Initialized
INFO - 2016-02-25 07:22:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:22:06 --> Controller Class Initialized
INFO - 2016-02-25 07:22:06 --> Model Class Initialized
INFO - 2016-02-25 07:22:06 --> Model Class Initialized
INFO - 2016-02-25 07:22:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:22:06 --> Pagination Class Initialized
INFO - 2016-02-25 07:22:06 --> Helper loaded: text_helper
INFO - 2016-02-25 07:22:06 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:22:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:22:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:22:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:22:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:22:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:22:06 --> Final output sent to browser
DEBUG - 2016-02-25 10:22:06 --> Total execution time: 1.3440
INFO - 2016-02-25 07:24:27 --> Config Class Initialized
INFO - 2016-02-25 07:24:27 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:24:27 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:24:27 --> Utf8 Class Initialized
INFO - 2016-02-25 07:24:27 --> URI Class Initialized
INFO - 2016-02-25 07:24:27 --> Router Class Initialized
INFO - 2016-02-25 07:24:27 --> Output Class Initialized
INFO - 2016-02-25 07:24:27 --> Security Class Initialized
DEBUG - 2016-02-25 07:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:24:27 --> Input Class Initialized
INFO - 2016-02-25 07:24:27 --> Language Class Initialized
INFO - 2016-02-25 07:24:27 --> Loader Class Initialized
INFO - 2016-02-25 07:24:27 --> Helper loaded: url_helper
INFO - 2016-02-25 07:24:27 --> Helper loaded: file_helper
INFO - 2016-02-25 07:24:27 --> Helper loaded: date_helper
INFO - 2016-02-25 07:24:27 --> Helper loaded: form_helper
INFO - 2016-02-25 07:24:27 --> Database Driver Class Initialized
INFO - 2016-02-25 07:24:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:24:28 --> Controller Class Initialized
INFO - 2016-02-25 07:24:28 --> Model Class Initialized
INFO - 2016-02-25 07:24:28 --> Model Class Initialized
INFO - 2016-02-25 07:24:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:24:28 --> Pagination Class Initialized
INFO - 2016-02-25 07:24:28 --> Helper loaded: text_helper
INFO - 2016-02-25 07:24:28 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:24:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:24:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:24:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:24:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:24:28 --> Final output sent to browser
DEBUG - 2016-02-25 10:24:28 --> Total execution time: 1.2143
INFO - 2016-02-25 07:24:30 --> Config Class Initialized
INFO - 2016-02-25 07:24:30 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:24:30 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:24:30 --> Utf8 Class Initialized
INFO - 2016-02-25 07:24:30 --> URI Class Initialized
INFO - 2016-02-25 07:24:30 --> Router Class Initialized
INFO - 2016-02-25 07:24:30 --> Output Class Initialized
INFO - 2016-02-25 07:24:30 --> Security Class Initialized
DEBUG - 2016-02-25 07:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:24:30 --> Input Class Initialized
INFO - 2016-02-25 07:24:30 --> Language Class Initialized
INFO - 2016-02-25 07:24:30 --> Loader Class Initialized
INFO - 2016-02-25 07:24:30 --> Helper loaded: url_helper
INFO - 2016-02-25 07:24:30 --> Helper loaded: file_helper
INFO - 2016-02-25 07:24:30 --> Helper loaded: date_helper
INFO - 2016-02-25 07:24:30 --> Helper loaded: form_helper
INFO - 2016-02-25 07:24:30 --> Database Driver Class Initialized
INFO - 2016-02-25 07:24:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:24:31 --> Controller Class Initialized
INFO - 2016-02-25 07:24:31 --> Model Class Initialized
INFO - 2016-02-25 07:24:31 --> Model Class Initialized
INFO - 2016-02-25 07:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:24:31 --> Pagination Class Initialized
INFO - 2016-02-25 07:24:31 --> Helper loaded: text_helper
INFO - 2016-02-25 07:24:31 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:24:31 --> Final output sent to browser
DEBUG - 2016-02-25 10:24:31 --> Total execution time: 1.1148
INFO - 2016-02-25 07:24:50 --> Config Class Initialized
INFO - 2016-02-25 07:24:50 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:24:50 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:24:50 --> Utf8 Class Initialized
INFO - 2016-02-25 07:24:50 --> URI Class Initialized
INFO - 2016-02-25 07:24:50 --> Router Class Initialized
INFO - 2016-02-25 07:24:50 --> Output Class Initialized
INFO - 2016-02-25 07:24:50 --> Security Class Initialized
DEBUG - 2016-02-25 07:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:24:50 --> Input Class Initialized
INFO - 2016-02-25 07:24:50 --> Language Class Initialized
INFO - 2016-02-25 07:24:50 --> Loader Class Initialized
INFO - 2016-02-25 07:24:50 --> Helper loaded: url_helper
INFO - 2016-02-25 07:24:50 --> Helper loaded: file_helper
INFO - 2016-02-25 07:24:50 --> Helper loaded: date_helper
INFO - 2016-02-25 07:24:50 --> Helper loaded: form_helper
INFO - 2016-02-25 07:24:50 --> Database Driver Class Initialized
INFO - 2016-02-25 07:24:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:24:51 --> Controller Class Initialized
INFO - 2016-02-25 07:24:51 --> Model Class Initialized
INFO - 2016-02-25 07:24:51 --> Model Class Initialized
INFO - 2016-02-25 07:24:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:24:51 --> Pagination Class Initialized
INFO - 2016-02-25 07:24:51 --> Helper loaded: text_helper
INFO - 2016-02-25 07:24:51 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:24:51 --> Image Lib Class Initialized
INFO - 2016-02-25 10:24:51 --> Upload Class Initialized
DEBUG - 2016-02-25 10:24:51 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-02-25 10:24:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\libraries\Image_lib.php 455
INFO - 2016-02-25 10:24:51 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2016-02-25 10:24:51 --> You must specify a source image in your preferences.
INFO - 2016-02-25 10:24:51 --> Final output sent to browser
DEBUG - 2016-02-25 10:24:51 --> Total execution time: 1.2025
INFO - 2016-02-25 07:24:56 --> Config Class Initialized
INFO - 2016-02-25 07:24:56 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:24:56 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:24:56 --> Utf8 Class Initialized
INFO - 2016-02-25 07:24:56 --> URI Class Initialized
INFO - 2016-02-25 07:24:56 --> Router Class Initialized
INFO - 2016-02-25 07:24:56 --> Output Class Initialized
INFO - 2016-02-25 07:24:56 --> Security Class Initialized
DEBUG - 2016-02-25 07:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:24:56 --> Input Class Initialized
INFO - 2016-02-25 07:24:56 --> Language Class Initialized
INFO - 2016-02-25 07:24:56 --> Loader Class Initialized
INFO - 2016-02-25 07:24:56 --> Helper loaded: url_helper
INFO - 2016-02-25 07:24:56 --> Helper loaded: file_helper
INFO - 2016-02-25 07:24:56 --> Helper loaded: date_helper
INFO - 2016-02-25 07:24:56 --> Helper loaded: form_helper
INFO - 2016-02-25 07:24:56 --> Database Driver Class Initialized
INFO - 2016-02-25 07:24:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:24:57 --> Controller Class Initialized
INFO - 2016-02-25 07:24:57 --> Model Class Initialized
INFO - 2016-02-25 07:24:57 --> Model Class Initialized
INFO - 2016-02-25 07:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:24:57 --> Pagination Class Initialized
INFO - 2016-02-25 07:24:57 --> Helper loaded: text_helper
INFO - 2016-02-25 07:24:57 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:24:57 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:24:57 --> Form Validation Class Initialized
INFO - 2016-02-25 10:24:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:24:57 --> Config Class Initialized
INFO - 2016-02-25 07:24:57 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:24:57 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:24:57 --> Utf8 Class Initialized
INFO - 2016-02-25 07:24:57 --> URI Class Initialized
INFO - 2016-02-25 07:24:57 --> Router Class Initialized
INFO - 2016-02-25 07:24:57 --> Output Class Initialized
INFO - 2016-02-25 07:24:57 --> Security Class Initialized
DEBUG - 2016-02-25 07:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:24:57 --> Input Class Initialized
INFO - 2016-02-25 07:24:57 --> Language Class Initialized
INFO - 2016-02-25 07:24:57 --> Loader Class Initialized
INFO - 2016-02-25 07:24:57 --> Helper loaded: url_helper
INFO - 2016-02-25 07:24:57 --> Helper loaded: file_helper
INFO - 2016-02-25 07:24:57 --> Helper loaded: date_helper
INFO - 2016-02-25 07:24:57 --> Helper loaded: form_helper
INFO - 2016-02-25 07:24:57 --> Database Driver Class Initialized
INFO - 2016-02-25 07:24:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:24:58 --> Controller Class Initialized
INFO - 2016-02-25 07:24:58 --> Model Class Initialized
INFO - 2016-02-25 07:24:58 --> Model Class Initialized
INFO - 2016-02-25 07:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:24:58 --> Pagination Class Initialized
INFO - 2016-02-25 07:24:58 --> Helper loaded: text_helper
INFO - 2016-02-25 07:24:58 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:24:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:24:58 --> Final output sent to browser
DEBUG - 2016-02-25 10:24:58 --> Total execution time: 1.2657
INFO - 2016-02-25 07:27:58 --> Config Class Initialized
INFO - 2016-02-25 07:27:58 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:27:58 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:27:58 --> Utf8 Class Initialized
INFO - 2016-02-25 07:27:58 --> URI Class Initialized
INFO - 2016-02-25 07:27:58 --> Router Class Initialized
INFO - 2016-02-25 07:27:58 --> Output Class Initialized
INFO - 2016-02-25 07:27:58 --> Security Class Initialized
DEBUG - 2016-02-25 07:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:27:58 --> Input Class Initialized
INFO - 2016-02-25 07:27:58 --> Language Class Initialized
INFO - 2016-02-25 07:27:58 --> Loader Class Initialized
INFO - 2016-02-25 07:27:58 --> Helper loaded: url_helper
INFO - 2016-02-25 07:27:58 --> Helper loaded: file_helper
INFO - 2016-02-25 07:27:58 --> Helper loaded: date_helper
INFO - 2016-02-25 07:27:58 --> Helper loaded: form_helper
INFO - 2016-02-25 07:27:58 --> Database Driver Class Initialized
INFO - 2016-02-25 07:27:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:27:59 --> Controller Class Initialized
INFO - 2016-02-25 07:27:59 --> Model Class Initialized
INFO - 2016-02-25 07:27:59 --> Model Class Initialized
INFO - 2016-02-25 07:27:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:27:59 --> Pagination Class Initialized
INFO - 2016-02-25 07:27:59 --> Helper loaded: text_helper
INFO - 2016-02-25 07:27:59 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:27:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:27:59 --> Final output sent to browser
DEBUG - 2016-02-25 10:27:59 --> Total execution time: 1.2766
INFO - 2016-02-25 07:28:01 --> Config Class Initialized
INFO - 2016-02-25 07:28:01 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:28:01 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:28:01 --> Utf8 Class Initialized
INFO - 2016-02-25 07:28:01 --> URI Class Initialized
INFO - 2016-02-25 07:28:01 --> Router Class Initialized
INFO - 2016-02-25 07:28:01 --> Output Class Initialized
INFO - 2016-02-25 07:28:01 --> Security Class Initialized
DEBUG - 2016-02-25 07:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:28:01 --> Input Class Initialized
INFO - 2016-02-25 07:28:01 --> Language Class Initialized
INFO - 2016-02-25 07:28:01 --> Loader Class Initialized
INFO - 2016-02-25 07:28:01 --> Helper loaded: url_helper
INFO - 2016-02-25 07:28:01 --> Helper loaded: file_helper
INFO - 2016-02-25 07:28:01 --> Helper loaded: date_helper
INFO - 2016-02-25 07:28:01 --> Helper loaded: form_helper
INFO - 2016-02-25 07:28:01 --> Database Driver Class Initialized
INFO - 2016-02-25 07:28:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:28:02 --> Controller Class Initialized
INFO - 2016-02-25 07:28:02 --> Model Class Initialized
INFO - 2016-02-25 07:28:02 --> Model Class Initialized
INFO - 2016-02-25 07:28:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:28:02 --> Pagination Class Initialized
INFO - 2016-02-25 07:28:02 --> Helper loaded: text_helper
INFO - 2016-02-25 07:28:02 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:28:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:28:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:28:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:28:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:28:02 --> Final output sent to browser
DEBUG - 2016-02-25 10:28:02 --> Total execution time: 1.1703
INFO - 2016-02-25 07:28:04 --> Config Class Initialized
INFO - 2016-02-25 07:28:04 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:28:04 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:28:04 --> Utf8 Class Initialized
INFO - 2016-02-25 07:28:04 --> URI Class Initialized
INFO - 2016-02-25 07:28:04 --> Router Class Initialized
INFO - 2016-02-25 07:28:04 --> Output Class Initialized
INFO - 2016-02-25 07:28:04 --> Security Class Initialized
DEBUG - 2016-02-25 07:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:28:04 --> Input Class Initialized
INFO - 2016-02-25 07:28:04 --> Language Class Initialized
INFO - 2016-02-25 07:28:04 --> Loader Class Initialized
INFO - 2016-02-25 07:28:04 --> Helper loaded: url_helper
INFO - 2016-02-25 07:28:04 --> Helper loaded: file_helper
INFO - 2016-02-25 07:28:04 --> Helper loaded: date_helper
INFO - 2016-02-25 07:28:04 --> Helper loaded: form_helper
INFO - 2016-02-25 07:28:04 --> Database Driver Class Initialized
INFO - 2016-02-25 07:28:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:28:05 --> Controller Class Initialized
INFO - 2016-02-25 07:28:05 --> Model Class Initialized
INFO - 2016-02-25 07:28:05 --> Model Class Initialized
INFO - 2016-02-25 07:28:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:28:05 --> Pagination Class Initialized
INFO - 2016-02-25 07:28:05 --> Helper loaded: text_helper
INFO - 2016-02-25 07:28:05 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:28:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:28:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:28:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:28:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:28:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:28:05 --> Final output sent to browser
DEBUG - 2016-02-25 10:28:05 --> Total execution time: 1.1360
INFO - 2016-02-25 07:28:20 --> Config Class Initialized
INFO - 2016-02-25 07:28:20 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:28:20 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:28:20 --> Utf8 Class Initialized
INFO - 2016-02-25 07:28:20 --> URI Class Initialized
INFO - 2016-02-25 07:28:20 --> Router Class Initialized
INFO - 2016-02-25 07:28:20 --> Output Class Initialized
INFO - 2016-02-25 07:28:20 --> Security Class Initialized
DEBUG - 2016-02-25 07:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:28:20 --> Input Class Initialized
INFO - 2016-02-25 07:28:20 --> Language Class Initialized
INFO - 2016-02-25 07:28:20 --> Loader Class Initialized
INFO - 2016-02-25 07:28:20 --> Helper loaded: url_helper
INFO - 2016-02-25 07:28:20 --> Helper loaded: file_helper
INFO - 2016-02-25 07:28:20 --> Helper loaded: date_helper
INFO - 2016-02-25 07:28:20 --> Helper loaded: form_helper
INFO - 2016-02-25 07:28:20 --> Database Driver Class Initialized
INFO - 2016-02-25 07:28:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:28:21 --> Controller Class Initialized
INFO - 2016-02-25 07:28:21 --> Model Class Initialized
INFO - 2016-02-25 07:28:21 --> Model Class Initialized
INFO - 2016-02-25 07:28:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:28:21 --> Pagination Class Initialized
INFO - 2016-02-25 07:28:21 --> Helper loaded: text_helper
INFO - 2016-02-25 07:28:21 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:28:21 --> Image Lib Class Initialized
INFO - 2016-02-25 10:28:21 --> Upload Class Initialized
DEBUG - 2016-02-25 10:28:21 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-02-25 10:28:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\libraries\Image_lib.php 455
INFO - 2016-02-25 10:28:21 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2016-02-25 10:28:21 --> You must specify a source image in your preferences.
INFO - 2016-02-25 10:28:21 --> Final output sent to browser
DEBUG - 2016-02-25 10:28:21 --> Total execution time: 1.1129
INFO - 2016-02-25 07:28:24 --> Config Class Initialized
INFO - 2016-02-25 07:28:24 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:28:24 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:28:24 --> Utf8 Class Initialized
INFO - 2016-02-25 07:28:24 --> URI Class Initialized
INFO - 2016-02-25 07:28:24 --> Router Class Initialized
INFO - 2016-02-25 07:28:24 --> Output Class Initialized
INFO - 2016-02-25 07:28:24 --> Security Class Initialized
DEBUG - 2016-02-25 07:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:28:24 --> Input Class Initialized
INFO - 2016-02-25 07:28:24 --> Language Class Initialized
INFO - 2016-02-25 07:28:24 --> Loader Class Initialized
INFO - 2016-02-25 07:28:24 --> Helper loaded: url_helper
INFO - 2016-02-25 07:28:24 --> Helper loaded: file_helper
INFO - 2016-02-25 07:28:24 --> Helper loaded: date_helper
INFO - 2016-02-25 07:28:24 --> Helper loaded: form_helper
INFO - 2016-02-25 07:28:24 --> Database Driver Class Initialized
INFO - 2016-02-25 07:28:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:28:25 --> Controller Class Initialized
INFO - 2016-02-25 07:28:25 --> Model Class Initialized
INFO - 2016-02-25 07:28:25 --> Model Class Initialized
INFO - 2016-02-25 07:28:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:28:25 --> Pagination Class Initialized
INFO - 2016-02-25 07:28:25 --> Helper loaded: text_helper
INFO - 2016-02-25 07:28:25 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:28:25 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:28:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:28:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:28:25 --> Form Validation Class Initialized
INFO - 2016-02-25 10:28:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:28:25 --> Config Class Initialized
INFO - 2016-02-25 07:28:25 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:28:25 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:28:25 --> Utf8 Class Initialized
INFO - 2016-02-25 07:28:25 --> URI Class Initialized
INFO - 2016-02-25 07:28:25 --> Router Class Initialized
INFO - 2016-02-25 07:28:25 --> Output Class Initialized
INFO - 2016-02-25 07:28:25 --> Security Class Initialized
DEBUG - 2016-02-25 07:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:28:25 --> Input Class Initialized
INFO - 2016-02-25 07:28:25 --> Language Class Initialized
INFO - 2016-02-25 07:28:26 --> Loader Class Initialized
INFO - 2016-02-25 07:28:26 --> Helper loaded: url_helper
INFO - 2016-02-25 07:28:26 --> Helper loaded: file_helper
INFO - 2016-02-25 07:28:26 --> Helper loaded: date_helper
INFO - 2016-02-25 07:28:26 --> Helper loaded: form_helper
INFO - 2016-02-25 07:28:26 --> Database Driver Class Initialized
INFO - 2016-02-25 07:28:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:28:27 --> Controller Class Initialized
INFO - 2016-02-25 07:28:27 --> Model Class Initialized
INFO - 2016-02-25 07:28:27 --> Model Class Initialized
INFO - 2016-02-25 07:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:28:27 --> Pagination Class Initialized
INFO - 2016-02-25 07:28:27 --> Helper loaded: text_helper
INFO - 2016-02-25 07:28:27 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:28:27 --> Final output sent to browser
DEBUG - 2016-02-25 10:28:27 --> Total execution time: 1.2241
INFO - 2016-02-25 07:28:47 --> Config Class Initialized
INFO - 2016-02-25 07:28:47 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:28:47 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:28:47 --> Utf8 Class Initialized
INFO - 2016-02-25 07:28:47 --> URI Class Initialized
INFO - 2016-02-25 07:28:47 --> Router Class Initialized
INFO - 2016-02-25 07:28:47 --> Output Class Initialized
INFO - 2016-02-25 07:28:47 --> Security Class Initialized
DEBUG - 2016-02-25 07:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:28:48 --> Input Class Initialized
INFO - 2016-02-25 07:28:48 --> Language Class Initialized
INFO - 2016-02-25 07:28:48 --> Loader Class Initialized
INFO - 2016-02-25 07:28:48 --> Helper loaded: url_helper
INFO - 2016-02-25 07:28:48 --> Helper loaded: file_helper
INFO - 2016-02-25 07:28:48 --> Helper loaded: date_helper
INFO - 2016-02-25 07:28:48 --> Helper loaded: form_helper
INFO - 2016-02-25 07:28:48 --> Database Driver Class Initialized
INFO - 2016-02-25 07:28:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:28:49 --> Controller Class Initialized
INFO - 2016-02-25 07:28:49 --> Model Class Initialized
INFO - 2016-02-25 07:28:49 --> Model Class Initialized
INFO - 2016-02-25 07:28:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:28:49 --> Pagination Class Initialized
INFO - 2016-02-25 07:28:49 --> Helper loaded: text_helper
INFO - 2016-02-25 07:28:49 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:28:49 --> Upload Class Initialized
INFO - 2016-02-25 10:28:49 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2016-02-25 10:28:49 --> You did not select a file to upload.
INFO - 2016-02-25 10:28:49 --> Final output sent to browser
DEBUG - 2016-02-25 10:28:49 --> Total execution time: 1.1920
INFO - 2016-02-25 07:28:53 --> Config Class Initialized
INFO - 2016-02-25 07:28:53 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:28:53 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:28:53 --> Utf8 Class Initialized
INFO - 2016-02-25 07:28:53 --> URI Class Initialized
INFO - 2016-02-25 07:28:53 --> Router Class Initialized
INFO - 2016-02-25 07:28:53 --> Output Class Initialized
INFO - 2016-02-25 07:28:53 --> Security Class Initialized
DEBUG - 2016-02-25 07:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:28:53 --> Input Class Initialized
INFO - 2016-02-25 07:28:53 --> Language Class Initialized
INFO - 2016-02-25 07:28:53 --> Loader Class Initialized
INFO - 2016-02-25 07:28:53 --> Helper loaded: url_helper
INFO - 2016-02-25 07:28:53 --> Helper loaded: file_helper
INFO - 2016-02-25 07:28:53 --> Helper loaded: date_helper
INFO - 2016-02-25 07:28:53 --> Helper loaded: form_helper
INFO - 2016-02-25 07:28:53 --> Database Driver Class Initialized
INFO - 2016-02-25 07:28:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:28:54 --> Controller Class Initialized
INFO - 2016-02-25 07:28:54 --> Model Class Initialized
INFO - 2016-02-25 07:28:54 --> Model Class Initialized
INFO - 2016-02-25 07:28:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:28:54 --> Pagination Class Initialized
INFO - 2016-02-25 07:28:54 --> Helper loaded: text_helper
INFO - 2016-02-25 07:28:54 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:28:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:28:54 --> Final output sent to browser
DEBUG - 2016-02-25 10:28:54 --> Total execution time: 1.1817
INFO - 2016-02-25 07:29:15 --> Config Class Initialized
INFO - 2016-02-25 07:29:15 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:29:15 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:29:15 --> Utf8 Class Initialized
INFO - 2016-02-25 07:29:15 --> URI Class Initialized
INFO - 2016-02-25 07:29:15 --> Router Class Initialized
INFO - 2016-02-25 07:29:15 --> Output Class Initialized
INFO - 2016-02-25 07:29:15 --> Security Class Initialized
DEBUG - 2016-02-25 07:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:29:15 --> Input Class Initialized
INFO - 2016-02-25 07:29:15 --> Language Class Initialized
INFO - 2016-02-25 07:29:15 --> Loader Class Initialized
INFO - 2016-02-25 07:29:15 --> Helper loaded: url_helper
INFO - 2016-02-25 07:29:15 --> Helper loaded: file_helper
INFO - 2016-02-25 07:29:15 --> Helper loaded: date_helper
INFO - 2016-02-25 07:29:15 --> Helper loaded: form_helper
INFO - 2016-02-25 07:29:15 --> Database Driver Class Initialized
INFO - 2016-02-25 07:29:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:29:16 --> Controller Class Initialized
INFO - 2016-02-25 07:29:16 --> Model Class Initialized
INFO - 2016-02-25 07:29:16 --> Model Class Initialized
INFO - 2016-02-25 07:29:16 --> Form Validation Class Initialized
INFO - 2016-02-25 07:29:16 --> Helper loaded: text_helper
INFO - 2016-02-25 07:29:16 --> Config Class Initialized
INFO - 2016-02-25 07:29:16 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:29:16 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:29:16 --> Utf8 Class Initialized
INFO - 2016-02-25 07:29:16 --> URI Class Initialized
DEBUG - 2016-02-25 07:29:17 --> No URI present. Default controller set.
INFO - 2016-02-25 07:29:17 --> Router Class Initialized
INFO - 2016-02-25 07:29:17 --> Output Class Initialized
INFO - 2016-02-25 07:29:17 --> Security Class Initialized
DEBUG - 2016-02-25 07:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:29:17 --> Input Class Initialized
INFO - 2016-02-25 07:29:17 --> Language Class Initialized
INFO - 2016-02-25 07:29:17 --> Loader Class Initialized
INFO - 2016-02-25 07:29:17 --> Helper loaded: url_helper
INFO - 2016-02-25 07:29:17 --> Helper loaded: file_helper
INFO - 2016-02-25 07:29:17 --> Helper loaded: date_helper
INFO - 2016-02-25 07:29:17 --> Helper loaded: form_helper
INFO - 2016-02-25 07:29:17 --> Database Driver Class Initialized
INFO - 2016-02-25 07:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:29:18 --> Controller Class Initialized
INFO - 2016-02-25 07:29:18 --> Model Class Initialized
INFO - 2016-02-25 07:29:18 --> Model Class Initialized
INFO - 2016-02-25 07:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:29:18 --> Pagination Class Initialized
INFO - 2016-02-25 07:29:18 --> Helper loaded: text_helper
INFO - 2016-02-25 07:29:18 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-25 10:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:29:18 --> Final output sent to browser
DEBUG - 2016-02-25 10:29:18 --> Total execution time: 1.1502
INFO - 2016-02-25 07:29:21 --> Config Class Initialized
INFO - 2016-02-25 07:29:21 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:29:21 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:29:21 --> Utf8 Class Initialized
INFO - 2016-02-25 07:29:21 --> URI Class Initialized
INFO - 2016-02-25 07:29:21 --> Router Class Initialized
INFO - 2016-02-25 07:29:21 --> Output Class Initialized
INFO - 2016-02-25 07:29:21 --> Security Class Initialized
DEBUG - 2016-02-25 07:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:29:21 --> Input Class Initialized
INFO - 2016-02-25 07:29:21 --> Language Class Initialized
INFO - 2016-02-25 07:29:21 --> Loader Class Initialized
INFO - 2016-02-25 07:29:21 --> Helper loaded: url_helper
INFO - 2016-02-25 07:29:21 --> Helper loaded: file_helper
INFO - 2016-02-25 07:29:21 --> Helper loaded: date_helper
INFO - 2016-02-25 07:29:21 --> Helper loaded: form_helper
INFO - 2016-02-25 07:29:21 --> Database Driver Class Initialized
INFO - 2016-02-25 07:29:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:29:22 --> Controller Class Initialized
INFO - 2016-02-25 07:29:22 --> Model Class Initialized
INFO - 2016-02-25 07:29:22 --> Model Class Initialized
INFO - 2016-02-25 07:29:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:29:22 --> Pagination Class Initialized
INFO - 2016-02-25 07:29:22 --> Helper loaded: text_helper
INFO - 2016-02-25 07:29:22 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:29:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:29:22 --> Final output sent to browser
DEBUG - 2016-02-25 10:29:22 --> Total execution time: 1.1679
INFO - 2016-02-25 07:29:24 --> Config Class Initialized
INFO - 2016-02-25 07:29:24 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:29:24 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:29:24 --> Utf8 Class Initialized
INFO - 2016-02-25 07:29:24 --> URI Class Initialized
INFO - 2016-02-25 07:29:24 --> Router Class Initialized
INFO - 2016-02-25 07:29:24 --> Output Class Initialized
INFO - 2016-02-25 07:29:24 --> Security Class Initialized
DEBUG - 2016-02-25 07:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:29:24 --> Input Class Initialized
INFO - 2016-02-25 07:29:24 --> Language Class Initialized
INFO - 2016-02-25 07:29:24 --> Loader Class Initialized
INFO - 2016-02-25 07:29:24 --> Helper loaded: url_helper
INFO - 2016-02-25 07:29:24 --> Helper loaded: file_helper
INFO - 2016-02-25 07:29:24 --> Helper loaded: date_helper
INFO - 2016-02-25 07:29:24 --> Helper loaded: form_helper
INFO - 2016-02-25 07:29:24 --> Database Driver Class Initialized
INFO - 2016-02-25 07:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:29:25 --> Controller Class Initialized
INFO - 2016-02-25 07:29:25 --> Model Class Initialized
INFO - 2016-02-25 07:29:25 --> Model Class Initialized
INFO - 2016-02-25 07:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:29:25 --> Pagination Class Initialized
INFO - 2016-02-25 07:29:25 --> Helper loaded: text_helper
INFO - 2016-02-25 07:29:25 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:29:25 --> Final output sent to browser
DEBUG - 2016-02-25 10:29:25 --> Total execution time: 1.1519
INFO - 2016-02-25 07:30:20 --> Config Class Initialized
INFO - 2016-02-25 07:30:20 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:30:20 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:30:20 --> Utf8 Class Initialized
INFO - 2016-02-25 07:30:20 --> URI Class Initialized
INFO - 2016-02-25 07:30:20 --> Router Class Initialized
INFO - 2016-02-25 07:30:20 --> Output Class Initialized
INFO - 2016-02-25 07:30:20 --> Security Class Initialized
DEBUG - 2016-02-25 07:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:30:20 --> Input Class Initialized
INFO - 2016-02-25 07:30:20 --> Language Class Initialized
INFO - 2016-02-25 07:30:20 --> Loader Class Initialized
INFO - 2016-02-25 07:30:20 --> Helper loaded: url_helper
INFO - 2016-02-25 07:30:20 --> Helper loaded: file_helper
INFO - 2016-02-25 07:30:20 --> Helper loaded: date_helper
INFO - 2016-02-25 07:30:20 --> Helper loaded: form_helper
INFO - 2016-02-25 07:30:20 --> Database Driver Class Initialized
INFO - 2016-02-25 07:30:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:30:21 --> Controller Class Initialized
INFO - 2016-02-25 07:30:21 --> Model Class Initialized
INFO - 2016-02-25 07:30:21 --> Model Class Initialized
INFO - 2016-02-25 07:30:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:30:21 --> Pagination Class Initialized
INFO - 2016-02-25 07:30:21 --> Helper loaded: text_helper
INFO - 2016-02-25 07:30:21 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:30:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:30:21 --> Final output sent to browser
DEBUG - 2016-02-25 10:30:21 --> Total execution time: 1.1683
INFO - 2016-02-25 07:30:48 --> Config Class Initialized
INFO - 2016-02-25 07:30:48 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:30:48 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:30:48 --> Utf8 Class Initialized
INFO - 2016-02-25 07:30:48 --> URI Class Initialized
INFO - 2016-02-25 07:30:48 --> Router Class Initialized
INFO - 2016-02-25 07:30:48 --> Output Class Initialized
INFO - 2016-02-25 07:30:48 --> Security Class Initialized
DEBUG - 2016-02-25 07:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:30:48 --> Input Class Initialized
INFO - 2016-02-25 07:30:48 --> Language Class Initialized
INFO - 2016-02-25 07:30:48 --> Loader Class Initialized
INFO - 2016-02-25 07:30:48 --> Helper loaded: url_helper
INFO - 2016-02-25 07:30:48 --> Helper loaded: file_helper
INFO - 2016-02-25 07:30:48 --> Helper loaded: date_helper
INFO - 2016-02-25 07:30:48 --> Helper loaded: form_helper
INFO - 2016-02-25 07:30:48 --> Database Driver Class Initialized
INFO - 2016-02-25 07:30:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:30:49 --> Controller Class Initialized
INFO - 2016-02-25 07:30:49 --> Model Class Initialized
INFO - 2016-02-25 07:30:49 --> Model Class Initialized
INFO - 2016-02-25 07:30:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:30:49 --> Pagination Class Initialized
INFO - 2016-02-25 07:30:49 --> Helper loaded: text_helper
INFO - 2016-02-25 07:30:49 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:30:49 --> Image Lib Class Initialized
INFO - 2016-02-25 10:30:49 --> Upload Class Initialized
DEBUG - 2016-02-25 10:30:49 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-02-25 10:30:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\libraries\Image_lib.php 455
INFO - 2016-02-25 10:30:49 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2016-02-25 10:30:49 --> You must specify a source image in your preferences.
INFO - 2016-02-25 10:30:49 --> Final output sent to browser
DEBUG - 2016-02-25 10:30:49 --> Total execution time: 1.1519
INFO - 2016-02-25 07:31:00 --> Config Class Initialized
INFO - 2016-02-25 07:31:00 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:31:00 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:31:00 --> Utf8 Class Initialized
INFO - 2016-02-25 07:31:00 --> URI Class Initialized
INFO - 2016-02-25 07:31:00 --> Router Class Initialized
INFO - 2016-02-25 07:31:00 --> Output Class Initialized
INFO - 2016-02-25 07:31:00 --> Security Class Initialized
DEBUG - 2016-02-25 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:31:00 --> Input Class Initialized
INFO - 2016-02-25 07:31:00 --> Language Class Initialized
INFO - 2016-02-25 07:31:00 --> Loader Class Initialized
INFO - 2016-02-25 07:31:00 --> Helper loaded: url_helper
INFO - 2016-02-25 07:31:00 --> Helper loaded: file_helper
INFO - 2016-02-25 07:31:00 --> Helper loaded: date_helper
INFO - 2016-02-25 07:31:00 --> Helper loaded: form_helper
INFO - 2016-02-25 07:31:00 --> Database Driver Class Initialized
INFO - 2016-02-25 07:31:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:31:01 --> Controller Class Initialized
INFO - 2016-02-25 07:31:01 --> Model Class Initialized
INFO - 2016-02-25 07:31:01 --> Model Class Initialized
INFO - 2016-02-25 07:31:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:31:01 --> Pagination Class Initialized
INFO - 2016-02-25 07:31:01 --> Helper loaded: text_helper
INFO - 2016-02-25 07:31:01 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:31:01 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:31:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:31:01 --> Form Validation Class Initialized
INFO - 2016-02-25 10:31:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:31:01 --> Config Class Initialized
INFO - 2016-02-25 07:31:01 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:31:01 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:31:01 --> Utf8 Class Initialized
INFO - 2016-02-25 07:31:01 --> URI Class Initialized
INFO - 2016-02-25 07:31:01 --> Router Class Initialized
INFO - 2016-02-25 07:31:01 --> Output Class Initialized
INFO - 2016-02-25 07:31:01 --> Security Class Initialized
DEBUG - 2016-02-25 07:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:31:01 --> Input Class Initialized
INFO - 2016-02-25 07:31:01 --> Language Class Initialized
INFO - 2016-02-25 07:31:01 --> Loader Class Initialized
INFO - 2016-02-25 07:31:01 --> Helper loaded: url_helper
INFO - 2016-02-25 07:31:01 --> Helper loaded: file_helper
INFO - 2016-02-25 07:31:01 --> Helper loaded: date_helper
INFO - 2016-02-25 07:31:01 --> Helper loaded: form_helper
INFO - 2016-02-25 07:31:01 --> Database Driver Class Initialized
INFO - 2016-02-25 07:31:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:31:02 --> Controller Class Initialized
INFO - 2016-02-25 07:31:02 --> Model Class Initialized
INFO - 2016-02-25 07:31:02 --> Model Class Initialized
INFO - 2016-02-25 07:31:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:31:02 --> Pagination Class Initialized
INFO - 2016-02-25 07:31:02 --> Helper loaded: text_helper
INFO - 2016-02-25 07:31:02 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:31:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:31:02 --> Final output sent to browser
DEBUG - 2016-02-25 10:31:02 --> Total execution time: 1.1831
INFO - 2016-02-25 07:33:53 --> Config Class Initialized
INFO - 2016-02-25 07:33:53 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:33:53 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:33:53 --> Utf8 Class Initialized
INFO - 2016-02-25 07:33:53 --> URI Class Initialized
INFO - 2016-02-25 07:33:53 --> Router Class Initialized
INFO - 2016-02-25 07:33:53 --> Output Class Initialized
INFO - 2016-02-25 07:33:53 --> Security Class Initialized
DEBUG - 2016-02-25 07:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:33:53 --> Input Class Initialized
INFO - 2016-02-25 07:33:53 --> Language Class Initialized
INFO - 2016-02-25 07:33:53 --> Loader Class Initialized
INFO - 2016-02-25 07:33:53 --> Helper loaded: url_helper
INFO - 2016-02-25 07:33:53 --> Helper loaded: file_helper
INFO - 2016-02-25 07:33:53 --> Helper loaded: date_helper
INFO - 2016-02-25 07:33:53 --> Helper loaded: form_helper
INFO - 2016-02-25 07:33:53 --> Database Driver Class Initialized
INFO - 2016-02-25 07:33:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:33:55 --> Controller Class Initialized
INFO - 2016-02-25 07:33:55 --> Model Class Initialized
INFO - 2016-02-25 07:33:55 --> Model Class Initialized
INFO - 2016-02-25 07:33:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:33:55 --> Pagination Class Initialized
INFO - 2016-02-25 07:33:55 --> Helper loaded: text_helper
INFO - 2016-02-25 07:33:55 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:33:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:33:55 --> Final output sent to browser
DEBUG - 2016-02-25 10:33:55 --> Total execution time: 1.1578
INFO - 2016-02-25 07:33:56 --> Config Class Initialized
INFO - 2016-02-25 07:33:56 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:33:56 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:33:56 --> Utf8 Class Initialized
INFO - 2016-02-25 07:33:56 --> URI Class Initialized
INFO - 2016-02-25 07:33:56 --> Router Class Initialized
INFO - 2016-02-25 07:33:56 --> Output Class Initialized
INFO - 2016-02-25 07:33:56 --> Security Class Initialized
DEBUG - 2016-02-25 07:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:33:56 --> Input Class Initialized
INFO - 2016-02-25 07:33:56 --> Language Class Initialized
INFO - 2016-02-25 07:33:56 --> Loader Class Initialized
INFO - 2016-02-25 07:33:56 --> Helper loaded: url_helper
INFO - 2016-02-25 07:33:56 --> Helper loaded: file_helper
INFO - 2016-02-25 07:33:56 --> Helper loaded: date_helper
INFO - 2016-02-25 07:33:56 --> Helper loaded: form_helper
INFO - 2016-02-25 07:33:56 --> Database Driver Class Initialized
INFO - 2016-02-25 07:33:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:33:58 --> Controller Class Initialized
INFO - 2016-02-25 07:33:58 --> Model Class Initialized
INFO - 2016-02-25 07:33:58 --> Model Class Initialized
INFO - 2016-02-25 07:33:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:33:58 --> Pagination Class Initialized
INFO - 2016-02-25 07:33:58 --> Helper loaded: text_helper
INFO - 2016-02-25 07:33:58 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:33:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:33:58 --> Final output sent to browser
DEBUG - 2016-02-25 10:33:58 --> Total execution time: 1.1328
INFO - 2016-02-25 07:34:20 --> Config Class Initialized
INFO - 2016-02-25 07:34:20 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:34:20 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:34:20 --> Utf8 Class Initialized
INFO - 2016-02-25 07:34:20 --> URI Class Initialized
INFO - 2016-02-25 07:34:20 --> Router Class Initialized
INFO - 2016-02-25 07:34:20 --> Output Class Initialized
INFO - 2016-02-25 07:34:20 --> Security Class Initialized
DEBUG - 2016-02-25 07:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:34:20 --> Input Class Initialized
INFO - 2016-02-25 07:34:20 --> Language Class Initialized
INFO - 2016-02-25 07:34:20 --> Loader Class Initialized
INFO - 2016-02-25 07:34:20 --> Helper loaded: url_helper
INFO - 2016-02-25 07:34:20 --> Helper loaded: file_helper
INFO - 2016-02-25 07:34:20 --> Helper loaded: date_helper
INFO - 2016-02-25 07:34:20 --> Helper loaded: form_helper
INFO - 2016-02-25 07:34:20 --> Database Driver Class Initialized
INFO - 2016-02-25 07:34:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:34:21 --> Controller Class Initialized
INFO - 2016-02-25 07:34:21 --> Model Class Initialized
INFO - 2016-02-25 07:34:21 --> Model Class Initialized
INFO - 2016-02-25 07:34:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:34:21 --> Pagination Class Initialized
INFO - 2016-02-25 07:34:21 --> Helper loaded: text_helper
INFO - 2016-02-25 07:34:21 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:34:21 --> Image Lib Class Initialized
INFO - 2016-02-25 10:34:21 --> Upload Class Initialized
DEBUG - 2016-02-25 10:34:21 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-02-25 10:34:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\libraries\Image_lib.php 455
INFO - 2016-02-25 10:34:21 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2016-02-25 10:34:21 --> You must specify a source image in your preferences.
INFO - 2016-02-25 10:34:21 --> Final output sent to browser
DEBUG - 2016-02-25 10:34:21 --> Total execution time: 1.1400
INFO - 2016-02-25 07:34:24 --> Config Class Initialized
INFO - 2016-02-25 07:34:24 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:34:24 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:34:24 --> Utf8 Class Initialized
INFO - 2016-02-25 07:34:24 --> URI Class Initialized
INFO - 2016-02-25 07:34:24 --> Router Class Initialized
INFO - 2016-02-25 07:34:24 --> Output Class Initialized
INFO - 2016-02-25 07:34:24 --> Security Class Initialized
DEBUG - 2016-02-25 07:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:34:24 --> Input Class Initialized
INFO - 2016-02-25 07:34:24 --> Language Class Initialized
INFO - 2016-02-25 07:34:24 --> Loader Class Initialized
INFO - 2016-02-25 07:34:24 --> Helper loaded: url_helper
INFO - 2016-02-25 07:34:24 --> Helper loaded: file_helper
INFO - 2016-02-25 07:34:24 --> Helper loaded: date_helper
INFO - 2016-02-25 07:34:24 --> Helper loaded: form_helper
INFO - 2016-02-25 07:34:24 --> Database Driver Class Initialized
INFO - 2016-02-25 07:34:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:34:26 --> Controller Class Initialized
INFO - 2016-02-25 07:34:26 --> Model Class Initialized
INFO - 2016-02-25 07:34:26 --> Model Class Initialized
INFO - 2016-02-25 07:34:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:34:26 --> Pagination Class Initialized
INFO - 2016-02-25 07:34:26 --> Helper loaded: text_helper
INFO - 2016-02-25 07:34:26 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:34:26 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:34:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:34:26 --> Form Validation Class Initialized
INFO - 2016-02-25 10:34:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:34:26 --> Config Class Initialized
INFO - 2016-02-25 07:34:26 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:34:26 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:34:26 --> Utf8 Class Initialized
INFO - 2016-02-25 07:34:26 --> URI Class Initialized
INFO - 2016-02-25 07:34:26 --> Router Class Initialized
INFO - 2016-02-25 07:34:26 --> Output Class Initialized
INFO - 2016-02-25 07:34:26 --> Security Class Initialized
DEBUG - 2016-02-25 07:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:34:26 --> Input Class Initialized
INFO - 2016-02-25 07:34:26 --> Language Class Initialized
INFO - 2016-02-25 07:34:26 --> Loader Class Initialized
INFO - 2016-02-25 07:34:26 --> Helper loaded: url_helper
INFO - 2016-02-25 07:34:26 --> Helper loaded: file_helper
INFO - 2016-02-25 07:34:26 --> Helper loaded: date_helper
INFO - 2016-02-25 07:34:26 --> Helper loaded: form_helper
INFO - 2016-02-25 07:34:26 --> Database Driver Class Initialized
INFO - 2016-02-25 07:34:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:34:27 --> Controller Class Initialized
INFO - 2016-02-25 07:34:27 --> Model Class Initialized
INFO - 2016-02-25 07:34:27 --> Model Class Initialized
INFO - 2016-02-25 07:34:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:34:27 --> Pagination Class Initialized
INFO - 2016-02-25 07:34:27 --> Helper loaded: text_helper
INFO - 2016-02-25 07:34:27 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:34:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:34:27 --> Final output sent to browser
DEBUG - 2016-02-25 10:34:27 --> Total execution time: 1.1952
INFO - 2016-02-25 07:37:11 --> Config Class Initialized
INFO - 2016-02-25 07:37:11 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:37:11 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:37:11 --> Utf8 Class Initialized
INFO - 2016-02-25 07:37:11 --> URI Class Initialized
INFO - 2016-02-25 07:37:11 --> Router Class Initialized
INFO - 2016-02-25 07:37:11 --> Output Class Initialized
INFO - 2016-02-25 07:37:11 --> Security Class Initialized
DEBUG - 2016-02-25 07:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:37:11 --> Input Class Initialized
INFO - 2016-02-25 07:37:11 --> Language Class Initialized
INFO - 2016-02-25 07:37:11 --> Loader Class Initialized
INFO - 2016-02-25 07:37:11 --> Helper loaded: url_helper
INFO - 2016-02-25 07:37:11 --> Helper loaded: file_helper
INFO - 2016-02-25 07:37:11 --> Helper loaded: date_helper
INFO - 2016-02-25 07:37:11 --> Helper loaded: form_helper
INFO - 2016-02-25 07:37:11 --> Database Driver Class Initialized
INFO - 2016-02-25 07:37:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:37:12 --> Controller Class Initialized
INFO - 2016-02-25 07:37:12 --> Model Class Initialized
INFO - 2016-02-25 07:37:12 --> Model Class Initialized
INFO - 2016-02-25 07:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:37:12 --> Pagination Class Initialized
INFO - 2016-02-25 07:37:12 --> Helper loaded: text_helper
INFO - 2016-02-25 07:37:12 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:37:12 --> Final output sent to browser
DEBUG - 2016-02-25 10:37:12 --> Total execution time: 1.1589
INFO - 2016-02-25 07:37:14 --> Config Class Initialized
INFO - 2016-02-25 07:37:14 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:37:14 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:37:14 --> Utf8 Class Initialized
INFO - 2016-02-25 07:37:14 --> URI Class Initialized
INFO - 2016-02-25 07:37:14 --> Router Class Initialized
INFO - 2016-02-25 07:37:14 --> Output Class Initialized
INFO - 2016-02-25 07:37:14 --> Security Class Initialized
DEBUG - 2016-02-25 07:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:37:14 --> Input Class Initialized
INFO - 2016-02-25 07:37:14 --> Language Class Initialized
INFO - 2016-02-25 07:37:14 --> Loader Class Initialized
INFO - 2016-02-25 07:37:14 --> Helper loaded: url_helper
INFO - 2016-02-25 07:37:14 --> Helper loaded: file_helper
INFO - 2016-02-25 07:37:14 --> Helper loaded: date_helper
INFO - 2016-02-25 07:37:14 --> Helper loaded: form_helper
INFO - 2016-02-25 07:37:14 --> Database Driver Class Initialized
INFO - 2016-02-25 07:37:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:37:15 --> Controller Class Initialized
INFO - 2016-02-25 07:37:15 --> Model Class Initialized
INFO - 2016-02-25 07:37:15 --> Model Class Initialized
INFO - 2016-02-25 07:37:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:37:15 --> Pagination Class Initialized
INFO - 2016-02-25 07:37:15 --> Helper loaded: text_helper
INFO - 2016-02-25 07:37:15 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:37:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:37:15 --> Final output sent to browser
DEBUG - 2016-02-25 10:37:15 --> Total execution time: 1.0978
INFO - 2016-02-25 07:37:33 --> Config Class Initialized
INFO - 2016-02-25 07:37:33 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:37:33 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:37:33 --> Utf8 Class Initialized
INFO - 2016-02-25 07:37:33 --> URI Class Initialized
INFO - 2016-02-25 07:37:33 --> Router Class Initialized
INFO - 2016-02-25 07:37:33 --> Output Class Initialized
INFO - 2016-02-25 07:37:33 --> Security Class Initialized
DEBUG - 2016-02-25 07:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:37:33 --> Input Class Initialized
INFO - 2016-02-25 07:37:33 --> Language Class Initialized
INFO - 2016-02-25 07:37:33 --> Loader Class Initialized
INFO - 2016-02-25 07:37:33 --> Helper loaded: url_helper
INFO - 2016-02-25 07:37:33 --> Helper loaded: file_helper
INFO - 2016-02-25 07:37:33 --> Helper loaded: date_helper
INFO - 2016-02-25 07:37:33 --> Helper loaded: form_helper
INFO - 2016-02-25 07:37:33 --> Database Driver Class Initialized
INFO - 2016-02-25 07:37:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:37:34 --> Controller Class Initialized
INFO - 2016-02-25 07:37:34 --> Model Class Initialized
INFO - 2016-02-25 07:37:34 --> Model Class Initialized
INFO - 2016-02-25 07:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:37:34 --> Pagination Class Initialized
INFO - 2016-02-25 07:37:34 --> Helper loaded: text_helper
INFO - 2016-02-25 07:37:34 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:37:34 --> Image Lib Class Initialized
INFO - 2016-02-25 10:37:34 --> Upload Class Initialized
DEBUG - 2016-02-25 10:37:34 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 10:37:34 --> Final output sent to browser
DEBUG - 2016-02-25 10:37:34 --> Total execution time: 1.1110
INFO - 2016-02-25 07:37:39 --> Config Class Initialized
INFO - 2016-02-25 07:37:39 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:37:39 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:37:39 --> Utf8 Class Initialized
INFO - 2016-02-25 07:37:39 --> URI Class Initialized
INFO - 2016-02-25 07:37:39 --> Router Class Initialized
INFO - 2016-02-25 07:37:39 --> Output Class Initialized
INFO - 2016-02-25 07:37:39 --> Security Class Initialized
DEBUG - 2016-02-25 07:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:37:39 --> Input Class Initialized
INFO - 2016-02-25 07:37:39 --> Language Class Initialized
INFO - 2016-02-25 07:37:39 --> Loader Class Initialized
INFO - 2016-02-25 07:37:39 --> Helper loaded: url_helper
INFO - 2016-02-25 07:37:39 --> Helper loaded: file_helper
INFO - 2016-02-25 07:37:39 --> Helper loaded: date_helper
INFO - 2016-02-25 07:37:39 --> Helper loaded: form_helper
INFO - 2016-02-25 07:37:39 --> Database Driver Class Initialized
INFO - 2016-02-25 07:37:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:37:40 --> Controller Class Initialized
INFO - 2016-02-25 07:37:40 --> Model Class Initialized
INFO - 2016-02-25 07:37:40 --> Model Class Initialized
INFO - 2016-02-25 07:37:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:37:40 --> Pagination Class Initialized
INFO - 2016-02-25 07:37:40 --> Helper loaded: text_helper
INFO - 2016-02-25 07:37:40 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:37:40 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:37:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:37:40 --> Form Validation Class Initialized
INFO - 2016-02-25 10:37:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:37:40 --> Config Class Initialized
INFO - 2016-02-25 07:37:40 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:37:40 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:37:40 --> Utf8 Class Initialized
INFO - 2016-02-25 07:37:40 --> URI Class Initialized
INFO - 2016-02-25 07:37:40 --> Router Class Initialized
INFO - 2016-02-25 07:37:40 --> Output Class Initialized
INFO - 2016-02-25 07:37:40 --> Security Class Initialized
DEBUG - 2016-02-25 07:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:37:40 --> Input Class Initialized
INFO - 2016-02-25 07:37:40 --> Language Class Initialized
INFO - 2016-02-25 07:37:40 --> Loader Class Initialized
INFO - 2016-02-25 07:37:40 --> Helper loaded: url_helper
INFO - 2016-02-25 07:37:40 --> Helper loaded: file_helper
INFO - 2016-02-25 07:37:40 --> Helper loaded: date_helper
INFO - 2016-02-25 07:37:40 --> Helper loaded: form_helper
INFO - 2016-02-25 07:37:40 --> Database Driver Class Initialized
INFO - 2016-02-25 07:37:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:37:41 --> Controller Class Initialized
INFO - 2016-02-25 07:37:41 --> Model Class Initialized
INFO - 2016-02-25 07:37:41 --> Model Class Initialized
INFO - 2016-02-25 07:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:37:41 --> Pagination Class Initialized
INFO - 2016-02-25 07:37:41 --> Helper loaded: text_helper
INFO - 2016-02-25 07:37:41 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:37:41 --> Final output sent to browser
DEBUG - 2016-02-25 10:37:41 --> Total execution time: 1.1710
INFO - 2016-02-25 07:43:26 --> Config Class Initialized
INFO - 2016-02-25 07:43:26 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:43:26 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:43:26 --> Utf8 Class Initialized
INFO - 2016-02-25 07:43:26 --> URI Class Initialized
INFO - 2016-02-25 07:43:26 --> Router Class Initialized
INFO - 2016-02-25 07:43:26 --> Output Class Initialized
INFO - 2016-02-25 07:43:26 --> Security Class Initialized
DEBUG - 2016-02-25 07:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:43:26 --> Input Class Initialized
INFO - 2016-02-25 07:43:26 --> Language Class Initialized
INFO - 2016-02-25 07:43:26 --> Loader Class Initialized
INFO - 2016-02-25 07:43:26 --> Helper loaded: url_helper
INFO - 2016-02-25 07:43:26 --> Helper loaded: file_helper
INFO - 2016-02-25 07:43:26 --> Helper loaded: date_helper
INFO - 2016-02-25 07:43:26 --> Helper loaded: form_helper
INFO - 2016-02-25 07:43:26 --> Database Driver Class Initialized
INFO - 2016-02-25 07:43:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:43:27 --> Controller Class Initialized
INFO - 2016-02-25 07:43:27 --> Model Class Initialized
INFO - 2016-02-25 07:43:27 --> Model Class Initialized
INFO - 2016-02-25 07:43:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:43:27 --> Pagination Class Initialized
INFO - 2016-02-25 07:43:27 --> Helper loaded: text_helper
INFO - 2016-02-25 07:43:27 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:43:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:43:27 --> Final output sent to browser
DEBUG - 2016-02-25 10:43:27 --> Total execution time: 1.1515
INFO - 2016-02-25 07:43:29 --> Config Class Initialized
INFO - 2016-02-25 07:43:29 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:43:29 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:43:29 --> Utf8 Class Initialized
INFO - 2016-02-25 07:43:29 --> URI Class Initialized
INFO - 2016-02-25 07:43:29 --> Router Class Initialized
INFO - 2016-02-25 07:43:29 --> Output Class Initialized
INFO - 2016-02-25 07:43:29 --> Security Class Initialized
DEBUG - 2016-02-25 07:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:43:29 --> Input Class Initialized
INFO - 2016-02-25 07:43:29 --> Language Class Initialized
INFO - 2016-02-25 07:43:29 --> Loader Class Initialized
INFO - 2016-02-25 07:43:29 --> Helper loaded: url_helper
INFO - 2016-02-25 07:43:29 --> Helper loaded: file_helper
INFO - 2016-02-25 07:43:29 --> Helper loaded: date_helper
INFO - 2016-02-25 07:43:29 --> Helper loaded: form_helper
INFO - 2016-02-25 07:43:29 --> Database Driver Class Initialized
INFO - 2016-02-25 07:43:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:43:30 --> Controller Class Initialized
INFO - 2016-02-25 07:43:30 --> Model Class Initialized
INFO - 2016-02-25 07:43:30 --> Model Class Initialized
INFO - 2016-02-25 07:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:43:30 --> Pagination Class Initialized
INFO - 2016-02-25 07:43:30 --> Helper loaded: text_helper
INFO - 2016-02-25 07:43:30 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:43:30 --> Final output sent to browser
DEBUG - 2016-02-25 10:43:30 --> Total execution time: 1.1286
INFO - 2016-02-25 07:43:55 --> Config Class Initialized
INFO - 2016-02-25 07:43:55 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:43:55 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:43:55 --> Utf8 Class Initialized
INFO - 2016-02-25 07:43:55 --> URI Class Initialized
INFO - 2016-02-25 07:43:55 --> Router Class Initialized
INFO - 2016-02-25 07:43:55 --> Output Class Initialized
INFO - 2016-02-25 07:43:55 --> Security Class Initialized
DEBUG - 2016-02-25 07:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:43:55 --> Input Class Initialized
INFO - 2016-02-25 07:43:55 --> Language Class Initialized
INFO - 2016-02-25 07:43:55 --> Loader Class Initialized
INFO - 2016-02-25 07:43:55 --> Helper loaded: url_helper
INFO - 2016-02-25 07:43:55 --> Helper loaded: file_helper
INFO - 2016-02-25 07:43:55 --> Helper loaded: date_helper
INFO - 2016-02-25 07:43:55 --> Helper loaded: form_helper
INFO - 2016-02-25 07:43:55 --> Database Driver Class Initialized
INFO - 2016-02-25 07:43:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:43:56 --> Controller Class Initialized
INFO - 2016-02-25 07:43:56 --> Model Class Initialized
INFO - 2016-02-25 07:43:56 --> Model Class Initialized
INFO - 2016-02-25 07:43:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:43:56 --> Pagination Class Initialized
INFO - 2016-02-25 07:43:56 --> Helper loaded: text_helper
INFO - 2016-02-25 07:43:56 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:43:56 --> Image Lib Class Initialized
INFO - 2016-02-25 10:43:56 --> Upload Class Initialized
DEBUG - 2016-02-25 10:43:56 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 10:43:56 --> Final output sent to browser
DEBUG - 2016-02-25 10:43:56 --> Total execution time: 1.1746
INFO - 2016-02-25 07:44:03 --> Config Class Initialized
INFO - 2016-02-25 07:44:03 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:44:03 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:44:03 --> Utf8 Class Initialized
INFO - 2016-02-25 07:44:03 --> URI Class Initialized
INFO - 2016-02-25 07:44:03 --> Router Class Initialized
INFO - 2016-02-25 07:44:03 --> Output Class Initialized
INFO - 2016-02-25 07:44:03 --> Security Class Initialized
DEBUG - 2016-02-25 07:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:44:03 --> Input Class Initialized
INFO - 2016-02-25 07:44:03 --> Language Class Initialized
INFO - 2016-02-25 07:44:03 --> Loader Class Initialized
INFO - 2016-02-25 07:44:03 --> Helper loaded: url_helper
INFO - 2016-02-25 07:44:03 --> Helper loaded: file_helper
INFO - 2016-02-25 07:44:03 --> Helper loaded: date_helper
INFO - 2016-02-25 07:44:03 --> Helper loaded: form_helper
INFO - 2016-02-25 07:44:03 --> Database Driver Class Initialized
INFO - 2016-02-25 07:44:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:44:04 --> Controller Class Initialized
INFO - 2016-02-25 07:44:04 --> Model Class Initialized
INFO - 2016-02-25 07:44:04 --> Model Class Initialized
INFO - 2016-02-25 07:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:44:04 --> Pagination Class Initialized
INFO - 2016-02-25 07:44:04 --> Helper loaded: text_helper
INFO - 2016-02-25 07:44:04 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:44:04 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:44:04 --> Form Validation Class Initialized
INFO - 2016-02-25 10:44:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-25 07:44:04 --> Config Class Initialized
INFO - 2016-02-25 07:44:04 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:44:04 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:44:04 --> Utf8 Class Initialized
INFO - 2016-02-25 07:44:04 --> URI Class Initialized
INFO - 2016-02-25 07:44:04 --> Router Class Initialized
INFO - 2016-02-25 07:44:04 --> Output Class Initialized
INFO - 2016-02-25 07:44:04 --> Security Class Initialized
DEBUG - 2016-02-25 07:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:44:04 --> Input Class Initialized
INFO - 2016-02-25 07:44:04 --> Language Class Initialized
INFO - 2016-02-25 07:44:04 --> Loader Class Initialized
INFO - 2016-02-25 07:44:04 --> Helper loaded: url_helper
INFO - 2016-02-25 07:44:04 --> Helper loaded: file_helper
INFO - 2016-02-25 07:44:04 --> Helper loaded: date_helper
INFO - 2016-02-25 07:44:04 --> Helper loaded: form_helper
INFO - 2016-02-25 07:44:04 --> Database Driver Class Initialized
INFO - 2016-02-25 07:44:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:44:05 --> Controller Class Initialized
INFO - 2016-02-25 07:44:05 --> Model Class Initialized
INFO - 2016-02-25 07:44:05 --> Model Class Initialized
INFO - 2016-02-25 07:44:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:44:05 --> Pagination Class Initialized
INFO - 2016-02-25 07:44:05 --> Helper loaded: text_helper
INFO - 2016-02-25 07:44:05 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:44:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:44:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:44:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:44:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:44:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:44:05 --> Final output sent to browser
DEBUG - 2016-02-25 10:44:05 --> Total execution time: 1.2261
INFO - 2016-02-25 07:44:21 --> Config Class Initialized
INFO - 2016-02-25 07:44:21 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:44:21 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:44:21 --> Utf8 Class Initialized
INFO - 2016-02-25 07:44:21 --> URI Class Initialized
INFO - 2016-02-25 07:44:21 --> Router Class Initialized
INFO - 2016-02-25 07:44:21 --> Output Class Initialized
INFO - 2016-02-25 07:44:21 --> Security Class Initialized
DEBUG - 2016-02-25 07:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:44:21 --> Input Class Initialized
INFO - 2016-02-25 07:44:21 --> Language Class Initialized
INFO - 2016-02-25 07:44:21 --> Loader Class Initialized
INFO - 2016-02-25 07:44:21 --> Helper loaded: url_helper
INFO - 2016-02-25 07:44:21 --> Helper loaded: file_helper
INFO - 2016-02-25 07:44:21 --> Helper loaded: date_helper
INFO - 2016-02-25 07:44:21 --> Helper loaded: form_helper
INFO - 2016-02-25 07:44:21 --> Database Driver Class Initialized
INFO - 2016-02-25 07:44:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:44:22 --> Controller Class Initialized
INFO - 2016-02-25 07:44:22 --> Model Class Initialized
INFO - 2016-02-25 07:44:22 --> Model Class Initialized
INFO - 2016-02-25 07:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:44:22 --> Pagination Class Initialized
INFO - 2016-02-25 07:44:22 --> Helper loaded: text_helper
INFO - 2016-02-25 07:44:22 --> Helper loaded: cookie_helper
ERROR - 2016-02-25 10:44:22 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-02-25 10:44:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:44:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:44:22 --> Form Validation Class Initialized
INFO - 2016-02-25 10:44:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:44:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:44:22 --> Final output sent to browser
DEBUG - 2016-02-25 10:44:22 --> Total execution time: 1.1549
INFO - 2016-02-25 07:44:30 --> Config Class Initialized
INFO - 2016-02-25 07:44:30 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:44:30 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:44:30 --> Utf8 Class Initialized
INFO - 2016-02-25 07:44:30 --> URI Class Initialized
INFO - 2016-02-25 07:44:30 --> Router Class Initialized
INFO - 2016-02-25 07:44:30 --> Output Class Initialized
INFO - 2016-02-25 07:44:30 --> Security Class Initialized
DEBUG - 2016-02-25 07:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:44:30 --> Input Class Initialized
INFO - 2016-02-25 07:44:30 --> Language Class Initialized
INFO - 2016-02-25 07:44:30 --> Loader Class Initialized
INFO - 2016-02-25 07:44:30 --> Helper loaded: url_helper
INFO - 2016-02-25 07:44:30 --> Helper loaded: file_helper
INFO - 2016-02-25 07:44:30 --> Helper loaded: date_helper
INFO - 2016-02-25 07:44:30 --> Helper loaded: form_helper
INFO - 2016-02-25 07:44:30 --> Database Driver Class Initialized
INFO - 2016-02-25 07:44:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:44:31 --> Controller Class Initialized
INFO - 2016-02-25 07:44:31 --> Model Class Initialized
INFO - 2016-02-25 07:44:31 --> Model Class Initialized
INFO - 2016-02-25 07:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:44:31 --> Pagination Class Initialized
INFO - 2016-02-25 07:44:31 --> Helper loaded: text_helper
INFO - 2016-02-25 07:44:31 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:44:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:44:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:44:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:44:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:44:31 --> Final output sent to browser
DEBUG - 2016-02-25 10:44:31 --> Total execution time: 1.1157
INFO - 2016-02-25 07:44:34 --> Config Class Initialized
INFO - 2016-02-25 07:44:34 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:44:34 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:44:34 --> Utf8 Class Initialized
INFO - 2016-02-25 07:44:34 --> URI Class Initialized
INFO - 2016-02-25 07:44:34 --> Router Class Initialized
INFO - 2016-02-25 07:44:34 --> Output Class Initialized
INFO - 2016-02-25 07:44:34 --> Security Class Initialized
DEBUG - 2016-02-25 07:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:44:34 --> Input Class Initialized
INFO - 2016-02-25 07:44:34 --> Language Class Initialized
INFO - 2016-02-25 07:44:34 --> Loader Class Initialized
INFO - 2016-02-25 07:44:34 --> Helper loaded: url_helper
INFO - 2016-02-25 07:44:34 --> Helper loaded: file_helper
INFO - 2016-02-25 07:44:34 --> Helper loaded: date_helper
INFO - 2016-02-25 07:44:34 --> Helper loaded: form_helper
INFO - 2016-02-25 07:44:34 --> Database Driver Class Initialized
INFO - 2016-02-25 07:44:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:44:35 --> Controller Class Initialized
INFO - 2016-02-25 07:44:35 --> Model Class Initialized
INFO - 2016-02-25 07:44:35 --> Model Class Initialized
INFO - 2016-02-25 07:44:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:44:35 --> Pagination Class Initialized
INFO - 2016-02-25 07:44:35 --> Helper loaded: text_helper
INFO - 2016-02-25 07:44:35 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 10:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:44:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:44:35 --> Final output sent to browser
DEBUG - 2016-02-25 10:44:35 --> Total execution time: 1.1653
INFO - 2016-02-25 07:44:58 --> Config Class Initialized
INFO - 2016-02-25 07:44:58 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:44:58 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:44:58 --> Utf8 Class Initialized
INFO - 2016-02-25 07:44:58 --> URI Class Initialized
INFO - 2016-02-25 07:44:58 --> Router Class Initialized
INFO - 2016-02-25 07:44:58 --> Output Class Initialized
INFO - 2016-02-25 07:44:58 --> Security Class Initialized
DEBUG - 2016-02-25 07:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:44:58 --> Input Class Initialized
INFO - 2016-02-25 07:44:58 --> Language Class Initialized
INFO - 2016-02-25 07:44:58 --> Loader Class Initialized
INFO - 2016-02-25 07:44:58 --> Helper loaded: url_helper
INFO - 2016-02-25 07:44:58 --> Helper loaded: file_helper
INFO - 2016-02-25 07:44:58 --> Helper loaded: date_helper
INFO - 2016-02-25 07:44:58 --> Helper loaded: form_helper
INFO - 2016-02-25 07:44:58 --> Database Driver Class Initialized
INFO - 2016-02-25 07:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:44:59 --> Controller Class Initialized
INFO - 2016-02-25 07:44:59 --> Model Class Initialized
INFO - 2016-02-25 07:44:59 --> Model Class Initialized
INFO - 2016-02-25 07:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:44:59 --> Pagination Class Initialized
INFO - 2016-02-25 07:44:59 --> Helper loaded: text_helper
INFO - 2016-02-25 07:44:59 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:44:59 --> Image Lib Class Initialized
INFO - 2016-02-25 10:44:59 --> Upload Class Initialized
DEBUG - 2016-02-25 10:44:59 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 10:44:59 --> Final output sent to browser
DEBUG - 2016-02-25 10:44:59 --> Total execution time: 1.1572
INFO - 2016-02-25 07:47:02 --> Config Class Initialized
INFO - 2016-02-25 07:47:02 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:47:02 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:47:02 --> Utf8 Class Initialized
INFO - 2016-02-25 07:47:02 --> URI Class Initialized
INFO - 2016-02-25 07:47:02 --> Router Class Initialized
INFO - 2016-02-25 07:47:02 --> Output Class Initialized
INFO - 2016-02-25 07:47:02 --> Security Class Initialized
DEBUG - 2016-02-25 07:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:47:02 --> Input Class Initialized
INFO - 2016-02-25 07:47:02 --> Language Class Initialized
INFO - 2016-02-25 07:47:02 --> Loader Class Initialized
INFO - 2016-02-25 07:47:02 --> Helper loaded: url_helper
INFO - 2016-02-25 07:47:02 --> Helper loaded: file_helper
INFO - 2016-02-25 07:47:02 --> Helper loaded: date_helper
INFO - 2016-02-25 07:47:02 --> Helper loaded: form_helper
INFO - 2016-02-25 07:47:02 --> Database Driver Class Initialized
INFO - 2016-02-25 07:47:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:47:03 --> Controller Class Initialized
INFO - 2016-02-25 07:47:03 --> Model Class Initialized
INFO - 2016-02-25 07:47:03 --> Model Class Initialized
INFO - 2016-02-25 07:47:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:47:03 --> Pagination Class Initialized
INFO - 2016-02-25 07:47:03 --> Helper loaded: text_helper
INFO - 2016-02-25 07:47:03 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:47:03 --> Image Lib Class Initialized
INFO - 2016-02-25 10:47:03 --> Upload Class Initialized
DEBUG - 2016-02-25 10:47:03 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 10:47:03 --> Final output sent to browser
DEBUG - 2016-02-25 10:47:03 --> Total execution time: 1.1079
INFO - 2016-02-25 07:49:12 --> Config Class Initialized
INFO - 2016-02-25 07:49:12 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:49:12 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:49:12 --> Utf8 Class Initialized
INFO - 2016-02-25 07:49:12 --> URI Class Initialized
INFO - 2016-02-25 07:49:12 --> Router Class Initialized
INFO - 2016-02-25 07:49:12 --> Output Class Initialized
INFO - 2016-02-25 07:49:12 --> Security Class Initialized
DEBUG - 2016-02-25 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:49:12 --> Input Class Initialized
INFO - 2016-02-25 07:49:12 --> Language Class Initialized
INFO - 2016-02-25 07:49:12 --> Loader Class Initialized
INFO - 2016-02-25 07:49:12 --> Helper loaded: url_helper
INFO - 2016-02-25 07:49:12 --> Helper loaded: file_helper
INFO - 2016-02-25 07:49:12 --> Helper loaded: date_helper
INFO - 2016-02-25 07:49:12 --> Helper loaded: form_helper
INFO - 2016-02-25 07:49:12 --> Database Driver Class Initialized
INFO - 2016-02-25 07:49:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:49:13 --> Controller Class Initialized
INFO - 2016-02-25 07:49:13 --> Model Class Initialized
INFO - 2016-02-25 07:49:13 --> Model Class Initialized
INFO - 2016-02-25 07:49:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:49:13 --> Pagination Class Initialized
INFO - 2016-02-25 07:49:13 --> Helper loaded: text_helper
INFO - 2016-02-25 07:49:13 --> Helper loaded: cookie_helper
INFO - 2016-02-25 07:49:13 --> Image Lib Class Initialized
INFO - 2016-02-25 10:49:13 --> Upload Class Initialized
DEBUG - 2016-02-25 10:49:13 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 10:49:13 --> Final output sent to browser
DEBUG - 2016-02-25 10:49:13 --> Total execution time: 1.1378
INFO - 2016-02-25 07:57:17 --> Config Class Initialized
INFO - 2016-02-25 07:57:17 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:57:17 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:57:17 --> Utf8 Class Initialized
INFO - 2016-02-25 07:57:18 --> URI Class Initialized
INFO - 2016-02-25 07:57:18 --> Router Class Initialized
INFO - 2016-02-25 07:57:18 --> Output Class Initialized
INFO - 2016-02-25 07:57:18 --> Security Class Initialized
DEBUG - 2016-02-25 07:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:57:18 --> Input Class Initialized
INFO - 2016-02-25 07:57:18 --> Language Class Initialized
INFO - 2016-02-25 07:57:18 --> Loader Class Initialized
INFO - 2016-02-25 07:57:18 --> Helper loaded: url_helper
INFO - 2016-02-25 07:57:18 --> Helper loaded: file_helper
INFO - 2016-02-25 07:57:18 --> Helper loaded: date_helper
INFO - 2016-02-25 07:57:18 --> Helper loaded: form_helper
INFO - 2016-02-25 07:57:18 --> Database Driver Class Initialized
INFO - 2016-02-25 07:57:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:57:19 --> Controller Class Initialized
INFO - 2016-02-25 07:57:19 --> Model Class Initialized
INFO - 2016-02-25 07:57:19 --> Model Class Initialized
INFO - 2016-02-25 07:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:57:19 --> Pagination Class Initialized
INFO - 2016-02-25 07:57:19 --> Helper loaded: text_helper
INFO - 2016-02-25 07:57:19 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:57:19 --> Final output sent to browser
DEBUG - 2016-02-25 10:57:19 --> Total execution time: 1.1317
INFO - 2016-02-25 07:57:21 --> Config Class Initialized
INFO - 2016-02-25 07:57:21 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:57:21 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:57:21 --> Utf8 Class Initialized
INFO - 2016-02-25 07:57:21 --> URI Class Initialized
INFO - 2016-02-25 07:57:21 --> Router Class Initialized
INFO - 2016-02-25 07:57:21 --> Output Class Initialized
INFO - 2016-02-25 07:57:21 --> Security Class Initialized
DEBUG - 2016-02-25 07:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:57:21 --> Input Class Initialized
INFO - 2016-02-25 07:57:21 --> Language Class Initialized
INFO - 2016-02-25 07:57:21 --> Loader Class Initialized
INFO - 2016-02-25 07:57:21 --> Helper loaded: url_helper
INFO - 2016-02-25 07:57:21 --> Helper loaded: file_helper
INFO - 2016-02-25 07:57:21 --> Helper loaded: date_helper
INFO - 2016-02-25 07:57:21 --> Helper loaded: form_helper
INFO - 2016-02-25 07:57:21 --> Database Driver Class Initialized
INFO - 2016-02-25 07:57:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:57:22 --> Controller Class Initialized
INFO - 2016-02-25 07:57:22 --> Model Class Initialized
INFO - 2016-02-25 07:57:22 --> Model Class Initialized
INFO - 2016-02-25 07:57:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:57:22 --> Pagination Class Initialized
INFO - 2016-02-25 07:57:22 --> Helper loaded: text_helper
INFO - 2016-02-25 07:57:22 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:57:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:57:22 --> Final output sent to browser
DEBUG - 2016-02-25 10:57:22 --> Total execution time: 1.2214
INFO - 2016-02-25 07:57:25 --> Config Class Initialized
INFO - 2016-02-25 07:57:25 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:57:25 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:57:25 --> Utf8 Class Initialized
INFO - 2016-02-25 07:57:25 --> URI Class Initialized
INFO - 2016-02-25 07:57:25 --> Router Class Initialized
INFO - 2016-02-25 07:57:25 --> Output Class Initialized
INFO - 2016-02-25 07:57:25 --> Security Class Initialized
DEBUG - 2016-02-25 07:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:57:25 --> Input Class Initialized
INFO - 2016-02-25 07:57:25 --> Language Class Initialized
INFO - 2016-02-25 07:57:25 --> Loader Class Initialized
INFO - 2016-02-25 07:57:25 --> Helper loaded: url_helper
INFO - 2016-02-25 07:57:25 --> Helper loaded: file_helper
INFO - 2016-02-25 07:57:25 --> Helper loaded: date_helper
INFO - 2016-02-25 07:57:25 --> Helper loaded: form_helper
INFO - 2016-02-25 07:57:25 --> Database Driver Class Initialized
INFO - 2016-02-25 07:57:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:57:27 --> Controller Class Initialized
INFO - 2016-02-25 07:57:27 --> Model Class Initialized
INFO - 2016-02-25 07:57:27 --> Model Class Initialized
INFO - 2016-02-25 07:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:57:27 --> Pagination Class Initialized
INFO - 2016-02-25 07:57:27 --> Helper loaded: text_helper
INFO - 2016-02-25 07:57:27 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:57:27 --> Final output sent to browser
DEBUG - 2016-02-25 10:57:27 --> Total execution time: 1.2179
INFO - 2016-02-25 07:57:28 --> Config Class Initialized
INFO - 2016-02-25 07:57:28 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:57:28 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:57:28 --> Utf8 Class Initialized
INFO - 2016-02-25 07:57:28 --> URI Class Initialized
INFO - 2016-02-25 07:57:28 --> Router Class Initialized
INFO - 2016-02-25 07:57:28 --> Output Class Initialized
INFO - 2016-02-25 07:57:28 --> Security Class Initialized
DEBUG - 2016-02-25 07:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:57:28 --> Input Class Initialized
INFO - 2016-02-25 07:57:28 --> Language Class Initialized
INFO - 2016-02-25 07:57:28 --> Loader Class Initialized
INFO - 2016-02-25 07:57:28 --> Helper loaded: url_helper
INFO - 2016-02-25 07:57:28 --> Helper loaded: file_helper
INFO - 2016-02-25 07:57:28 --> Helper loaded: date_helper
INFO - 2016-02-25 07:57:28 --> Helper loaded: form_helper
INFO - 2016-02-25 07:57:28 --> Database Driver Class Initialized
INFO - 2016-02-25 07:57:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:57:29 --> Controller Class Initialized
INFO - 2016-02-25 07:57:29 --> Model Class Initialized
INFO - 2016-02-25 07:57:29 --> Model Class Initialized
INFO - 2016-02-25 07:57:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:57:29 --> Pagination Class Initialized
INFO - 2016-02-25 07:57:29 --> Helper loaded: text_helper
INFO - 2016-02-25 07:57:29 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:57:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:57:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:57:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:57:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:57:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:57:29 --> Final output sent to browser
DEBUG - 2016-02-25 10:57:29 --> Total execution time: 1.1477
INFO - 2016-02-25 07:57:32 --> Config Class Initialized
INFO - 2016-02-25 07:57:32 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:57:32 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:57:32 --> Utf8 Class Initialized
INFO - 2016-02-25 07:57:32 --> URI Class Initialized
INFO - 2016-02-25 07:57:32 --> Router Class Initialized
INFO - 2016-02-25 07:57:32 --> Output Class Initialized
INFO - 2016-02-25 07:57:32 --> Security Class Initialized
DEBUG - 2016-02-25 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:57:32 --> Input Class Initialized
INFO - 2016-02-25 07:57:32 --> Language Class Initialized
INFO - 2016-02-25 07:57:32 --> Loader Class Initialized
INFO - 2016-02-25 07:57:32 --> Helper loaded: url_helper
INFO - 2016-02-25 07:57:32 --> Helper loaded: file_helper
INFO - 2016-02-25 07:57:32 --> Helper loaded: date_helper
INFO - 2016-02-25 07:57:32 --> Helper loaded: form_helper
INFO - 2016-02-25 07:57:32 --> Database Driver Class Initialized
INFO - 2016-02-25 07:57:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:57:33 --> Controller Class Initialized
INFO - 2016-02-25 07:57:33 --> Model Class Initialized
INFO - 2016-02-25 07:57:33 --> Model Class Initialized
INFO - 2016-02-25 07:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:57:33 --> Pagination Class Initialized
INFO - 2016-02-25 07:57:33 --> Helper loaded: text_helper
INFO - 2016-02-25 07:57:33 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:57:33 --> Final output sent to browser
DEBUG - 2016-02-25 10:57:33 --> Total execution time: 1.1646
INFO - 2016-02-25 07:57:34 --> Config Class Initialized
INFO - 2016-02-25 07:57:34 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:57:34 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:57:34 --> Utf8 Class Initialized
INFO - 2016-02-25 07:57:34 --> URI Class Initialized
INFO - 2016-02-25 07:57:34 --> Router Class Initialized
INFO - 2016-02-25 07:57:34 --> Output Class Initialized
INFO - 2016-02-25 07:57:34 --> Security Class Initialized
DEBUG - 2016-02-25 07:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:57:34 --> Input Class Initialized
INFO - 2016-02-25 07:57:34 --> Language Class Initialized
INFO - 2016-02-25 07:57:34 --> Loader Class Initialized
INFO - 2016-02-25 07:57:34 --> Helper loaded: url_helper
INFO - 2016-02-25 07:57:34 --> Helper loaded: file_helper
INFO - 2016-02-25 07:57:34 --> Helper loaded: date_helper
INFO - 2016-02-25 07:57:34 --> Helper loaded: form_helper
INFO - 2016-02-25 07:57:34 --> Database Driver Class Initialized
INFO - 2016-02-25 07:57:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:57:35 --> Controller Class Initialized
INFO - 2016-02-25 07:57:35 --> Model Class Initialized
INFO - 2016-02-25 07:57:35 --> Model Class Initialized
INFO - 2016-02-25 07:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:57:35 --> Pagination Class Initialized
INFO - 2016-02-25 07:57:35 --> Helper loaded: text_helper
INFO - 2016-02-25 07:57:35 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:57:35 --> Final output sent to browser
DEBUG - 2016-02-25 10:57:35 --> Total execution time: 1.1973
INFO - 2016-02-25 07:57:38 --> Config Class Initialized
INFO - 2016-02-25 07:57:38 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:57:38 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:57:38 --> Utf8 Class Initialized
INFO - 2016-02-25 07:57:38 --> URI Class Initialized
INFO - 2016-02-25 07:57:38 --> Router Class Initialized
INFO - 2016-02-25 07:57:38 --> Output Class Initialized
INFO - 2016-02-25 07:57:38 --> Security Class Initialized
DEBUG - 2016-02-25 07:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:57:38 --> Input Class Initialized
INFO - 2016-02-25 07:57:38 --> Language Class Initialized
INFO - 2016-02-25 07:57:38 --> Loader Class Initialized
INFO - 2016-02-25 07:57:38 --> Helper loaded: url_helper
INFO - 2016-02-25 07:57:38 --> Helper loaded: file_helper
INFO - 2016-02-25 07:57:38 --> Helper loaded: date_helper
INFO - 2016-02-25 07:57:38 --> Helper loaded: form_helper
INFO - 2016-02-25 07:57:38 --> Database Driver Class Initialized
INFO - 2016-02-25 07:57:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:57:39 --> Controller Class Initialized
INFO - 2016-02-25 07:57:39 --> Model Class Initialized
INFO - 2016-02-25 07:57:39 --> Model Class Initialized
INFO - 2016-02-25 07:57:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:57:39 --> Pagination Class Initialized
INFO - 2016-02-25 07:57:39 --> Helper loaded: text_helper
INFO - 2016-02-25 07:57:39 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:57:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:57:39 --> Final output sent to browser
DEBUG - 2016-02-25 10:57:39 --> Total execution time: 1.1340
INFO - 2016-02-25 07:57:40 --> Config Class Initialized
INFO - 2016-02-25 07:57:40 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:57:40 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:57:40 --> Utf8 Class Initialized
INFO - 2016-02-25 07:57:40 --> URI Class Initialized
INFO - 2016-02-25 07:57:40 --> Router Class Initialized
INFO - 2016-02-25 07:57:40 --> Output Class Initialized
INFO - 2016-02-25 07:57:40 --> Security Class Initialized
DEBUG - 2016-02-25 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:57:40 --> Input Class Initialized
INFO - 2016-02-25 07:57:40 --> Language Class Initialized
INFO - 2016-02-25 07:57:40 --> Loader Class Initialized
INFO - 2016-02-25 07:57:40 --> Helper loaded: url_helper
INFO - 2016-02-25 07:57:40 --> Helper loaded: file_helper
INFO - 2016-02-25 07:57:40 --> Helper loaded: date_helper
INFO - 2016-02-25 07:57:40 --> Helper loaded: form_helper
INFO - 2016-02-25 07:57:40 --> Database Driver Class Initialized
INFO - 2016-02-25 07:57:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:57:41 --> Controller Class Initialized
INFO - 2016-02-25 07:57:41 --> Model Class Initialized
INFO - 2016-02-25 07:57:41 --> Model Class Initialized
INFO - 2016-02-25 07:57:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:57:41 --> Pagination Class Initialized
INFO - 2016-02-25 07:57:41 --> Helper loaded: text_helper
INFO - 2016-02-25 07:57:41 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 10:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 10:57:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:57:41 --> Final output sent to browser
DEBUG - 2016-02-25 10:57:41 --> Total execution time: 1.1696
INFO - 2016-02-25 07:58:58 --> Config Class Initialized
INFO - 2016-02-25 07:58:58 --> Hooks Class Initialized
DEBUG - 2016-02-25 07:58:58 --> UTF-8 Support Enabled
INFO - 2016-02-25 07:58:58 --> Utf8 Class Initialized
INFO - 2016-02-25 07:58:58 --> URI Class Initialized
INFO - 2016-02-25 07:58:58 --> Router Class Initialized
INFO - 2016-02-25 07:58:58 --> Output Class Initialized
INFO - 2016-02-25 07:58:58 --> Security Class Initialized
DEBUG - 2016-02-25 07:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 07:58:58 --> Input Class Initialized
INFO - 2016-02-25 07:58:58 --> Language Class Initialized
INFO - 2016-02-25 07:58:58 --> Loader Class Initialized
INFO - 2016-02-25 07:58:58 --> Helper loaded: url_helper
INFO - 2016-02-25 07:58:58 --> Helper loaded: file_helper
INFO - 2016-02-25 07:58:58 --> Helper loaded: date_helper
INFO - 2016-02-25 07:58:58 --> Helper loaded: form_helper
INFO - 2016-02-25 07:58:58 --> Database Driver Class Initialized
INFO - 2016-02-25 07:58:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 07:58:59 --> Controller Class Initialized
INFO - 2016-02-25 07:58:59 --> Model Class Initialized
INFO - 2016-02-25 07:58:59 --> Model Class Initialized
INFO - 2016-02-25 07:58:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 07:58:59 --> Pagination Class Initialized
INFO - 2016-02-25 07:58:59 --> Helper loaded: text_helper
INFO - 2016-02-25 07:58:59 --> Helper loaded: cookie_helper
INFO - 2016-02-25 10:58:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 10:58:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 10:58:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 10:58:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 10:58:59 --> Final output sent to browser
DEBUG - 2016-02-25 10:58:59 --> Total execution time: 1.1543
INFO - 2016-02-25 08:01:06 --> Config Class Initialized
INFO - 2016-02-25 08:01:06 --> Hooks Class Initialized
DEBUG - 2016-02-25 08:01:06 --> UTF-8 Support Enabled
INFO - 2016-02-25 08:01:06 --> Utf8 Class Initialized
INFO - 2016-02-25 08:01:06 --> URI Class Initialized
INFO - 2016-02-25 08:01:06 --> Router Class Initialized
INFO - 2016-02-25 08:01:06 --> Output Class Initialized
INFO - 2016-02-25 08:01:06 --> Security Class Initialized
DEBUG - 2016-02-25 08:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 08:01:06 --> Input Class Initialized
INFO - 2016-02-25 08:01:06 --> Language Class Initialized
INFO - 2016-02-25 08:01:06 --> Loader Class Initialized
INFO - 2016-02-25 08:01:06 --> Helper loaded: url_helper
INFO - 2016-02-25 08:01:06 --> Helper loaded: file_helper
INFO - 2016-02-25 08:01:06 --> Helper loaded: date_helper
INFO - 2016-02-25 08:01:06 --> Helper loaded: form_helper
INFO - 2016-02-25 08:01:06 --> Database Driver Class Initialized
INFO - 2016-02-25 08:01:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 08:01:07 --> Controller Class Initialized
INFO - 2016-02-25 08:01:07 --> Model Class Initialized
INFO - 2016-02-25 08:01:07 --> Model Class Initialized
INFO - 2016-02-25 08:01:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 08:01:07 --> Pagination Class Initialized
INFO - 2016-02-25 08:01:07 --> Helper loaded: text_helper
INFO - 2016-02-25 08:01:07 --> Helper loaded: cookie_helper
INFO - 2016-02-25 11:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 11:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 11:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 11:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 11:01:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 11:01:07 --> Final output sent to browser
DEBUG - 2016-02-25 11:01:07 --> Total execution time: 1.1768
INFO - 2016-02-25 08:01:08 --> Config Class Initialized
INFO - 2016-02-25 08:01:08 --> Hooks Class Initialized
DEBUG - 2016-02-25 08:01:08 --> UTF-8 Support Enabled
INFO - 2016-02-25 08:01:08 --> Utf8 Class Initialized
INFO - 2016-02-25 08:01:08 --> URI Class Initialized
INFO - 2016-02-25 08:01:08 --> Router Class Initialized
INFO - 2016-02-25 08:01:08 --> Output Class Initialized
INFO - 2016-02-25 08:01:08 --> Security Class Initialized
DEBUG - 2016-02-25 08:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 08:01:08 --> Input Class Initialized
INFO - 2016-02-25 08:01:08 --> Language Class Initialized
INFO - 2016-02-25 08:01:08 --> Loader Class Initialized
INFO - 2016-02-25 08:01:08 --> Helper loaded: url_helper
INFO - 2016-02-25 08:01:08 --> Helper loaded: file_helper
INFO - 2016-02-25 08:01:08 --> Helper loaded: date_helper
INFO - 2016-02-25 08:01:08 --> Helper loaded: form_helper
INFO - 2016-02-25 08:01:08 --> Database Driver Class Initialized
INFO - 2016-02-25 08:01:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 08:01:09 --> Controller Class Initialized
INFO - 2016-02-25 08:01:09 --> Model Class Initialized
INFO - 2016-02-25 08:01:09 --> Model Class Initialized
INFO - 2016-02-25 08:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 08:01:09 --> Pagination Class Initialized
INFO - 2016-02-25 08:01:09 --> Helper loaded: text_helper
INFO - 2016-02-25 08:01:09 --> Helper loaded: cookie_helper
INFO - 2016-02-25 11:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 11:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 11:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 11:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 11:01:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 11:01:10 --> Final output sent to browser
DEBUG - 2016-02-25 11:01:10 --> Total execution time: 1.0955
INFO - 2016-02-25 08:01:33 --> Config Class Initialized
INFO - 2016-02-25 08:01:33 --> Hooks Class Initialized
DEBUG - 2016-02-25 08:01:33 --> UTF-8 Support Enabled
INFO - 2016-02-25 08:01:33 --> Utf8 Class Initialized
INFO - 2016-02-25 08:01:33 --> URI Class Initialized
INFO - 2016-02-25 08:01:33 --> Router Class Initialized
INFO - 2016-02-25 08:01:33 --> Output Class Initialized
INFO - 2016-02-25 08:01:33 --> Security Class Initialized
DEBUG - 2016-02-25 08:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 08:01:33 --> Input Class Initialized
INFO - 2016-02-25 08:01:33 --> Language Class Initialized
INFO - 2016-02-25 08:01:33 --> Loader Class Initialized
INFO - 2016-02-25 08:01:33 --> Helper loaded: url_helper
INFO - 2016-02-25 08:01:33 --> Helper loaded: file_helper
INFO - 2016-02-25 08:01:33 --> Helper loaded: date_helper
INFO - 2016-02-25 08:01:33 --> Helper loaded: form_helper
INFO - 2016-02-25 08:01:33 --> Database Driver Class Initialized
INFO - 2016-02-25 08:01:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 08:01:34 --> Controller Class Initialized
INFO - 2016-02-25 08:01:34 --> Model Class Initialized
INFO - 2016-02-25 08:01:34 --> Model Class Initialized
INFO - 2016-02-25 08:01:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 08:01:34 --> Pagination Class Initialized
INFO - 2016-02-25 08:01:34 --> Helper loaded: text_helper
INFO - 2016-02-25 08:01:34 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:01:34 --> Image Lib Class Initialized
INFO - 2016-02-25 11:01:34 --> Upload Class Initialized
DEBUG - 2016-02-25 11:01:34 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 11:01:34 --> Final output sent to browser
DEBUG - 2016-02-25 11:01:34 --> Total execution time: 1.1324
INFO - 2016-02-25 08:08:10 --> Config Class Initialized
INFO - 2016-02-25 08:08:10 --> Hooks Class Initialized
DEBUG - 2016-02-25 08:08:10 --> UTF-8 Support Enabled
INFO - 2016-02-25 08:08:10 --> Utf8 Class Initialized
INFO - 2016-02-25 08:08:10 --> URI Class Initialized
INFO - 2016-02-25 08:08:10 --> Router Class Initialized
INFO - 2016-02-25 08:08:10 --> Output Class Initialized
INFO - 2016-02-25 08:08:10 --> Security Class Initialized
DEBUG - 2016-02-25 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 08:08:10 --> Input Class Initialized
INFO - 2016-02-25 08:08:10 --> Language Class Initialized
INFO - 2016-02-25 08:08:10 --> Loader Class Initialized
INFO - 2016-02-25 08:08:10 --> Helper loaded: url_helper
INFO - 2016-02-25 08:08:10 --> Helper loaded: file_helper
INFO - 2016-02-25 08:08:10 --> Helper loaded: date_helper
INFO - 2016-02-25 08:08:10 --> Helper loaded: form_helper
INFO - 2016-02-25 08:08:10 --> Database Driver Class Initialized
INFO - 2016-02-25 08:08:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 08:08:11 --> Controller Class Initialized
INFO - 2016-02-25 08:08:11 --> Model Class Initialized
INFO - 2016-02-25 08:08:11 --> Model Class Initialized
INFO - 2016-02-25 08:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 08:08:11 --> Pagination Class Initialized
INFO - 2016-02-25 08:08:11 --> Helper loaded: text_helper
INFO - 2016-02-25 08:08:11 --> Helper loaded: cookie_helper
INFO - 2016-02-25 11:08:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 11:08:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 11:08:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 11:08:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 11:08:11 --> Final output sent to browser
DEBUG - 2016-02-25 11:08:11 --> Total execution time: 1.1273
INFO - 2016-02-25 08:08:14 --> Config Class Initialized
INFO - 2016-02-25 08:08:14 --> Hooks Class Initialized
DEBUG - 2016-02-25 08:08:14 --> UTF-8 Support Enabled
INFO - 2016-02-25 08:08:14 --> Utf8 Class Initialized
INFO - 2016-02-25 08:08:14 --> URI Class Initialized
INFO - 2016-02-25 08:08:14 --> Router Class Initialized
INFO - 2016-02-25 08:08:14 --> Output Class Initialized
INFO - 2016-02-25 08:08:14 --> Security Class Initialized
DEBUG - 2016-02-25 08:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 08:08:14 --> Input Class Initialized
INFO - 2016-02-25 08:08:14 --> Language Class Initialized
INFO - 2016-02-25 08:08:14 --> Loader Class Initialized
INFO - 2016-02-25 08:08:14 --> Helper loaded: url_helper
INFO - 2016-02-25 08:08:14 --> Helper loaded: file_helper
INFO - 2016-02-25 08:08:14 --> Helper loaded: date_helper
INFO - 2016-02-25 08:08:14 --> Helper loaded: form_helper
INFO - 2016-02-25 08:08:14 --> Database Driver Class Initialized
INFO - 2016-02-25 08:08:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 08:08:15 --> Controller Class Initialized
INFO - 2016-02-25 08:08:15 --> Model Class Initialized
INFO - 2016-02-25 08:08:15 --> Model Class Initialized
INFO - 2016-02-25 08:08:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 08:08:15 --> Pagination Class Initialized
INFO - 2016-02-25 08:08:15 --> Helper loaded: text_helper
INFO - 2016-02-25 08:08:15 --> Helper loaded: cookie_helper
INFO - 2016-02-25 11:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 11:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 11:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 11:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 11:08:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 11:08:15 --> Final output sent to browser
DEBUG - 2016-02-25 11:08:15 --> Total execution time: 1.1348
INFO - 2016-02-25 08:08:28 --> Config Class Initialized
INFO - 2016-02-25 08:08:28 --> Hooks Class Initialized
DEBUG - 2016-02-25 08:08:28 --> UTF-8 Support Enabled
INFO - 2016-02-25 08:08:28 --> Utf8 Class Initialized
INFO - 2016-02-25 08:08:28 --> URI Class Initialized
INFO - 2016-02-25 08:08:28 --> Router Class Initialized
INFO - 2016-02-25 08:08:28 --> Output Class Initialized
INFO - 2016-02-25 08:08:28 --> Security Class Initialized
DEBUG - 2016-02-25 08:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 08:08:28 --> Input Class Initialized
INFO - 2016-02-25 08:08:28 --> Language Class Initialized
INFO - 2016-02-25 08:08:28 --> Loader Class Initialized
INFO - 2016-02-25 08:08:28 --> Helper loaded: url_helper
INFO - 2016-02-25 08:08:28 --> Helper loaded: file_helper
INFO - 2016-02-25 08:08:28 --> Helper loaded: date_helper
INFO - 2016-02-25 08:08:28 --> Helper loaded: form_helper
INFO - 2016-02-25 08:08:28 --> Database Driver Class Initialized
INFO - 2016-02-25 08:08:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 08:08:29 --> Controller Class Initialized
INFO - 2016-02-25 08:08:29 --> Model Class Initialized
INFO - 2016-02-25 08:08:29 --> Model Class Initialized
INFO - 2016-02-25 08:08:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 08:08:29 --> Pagination Class Initialized
INFO - 2016-02-25 08:08:29 --> Helper loaded: text_helper
INFO - 2016-02-25 08:08:29 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:08:29 --> Image Lib Class Initialized
INFO - 2016-02-25 11:08:29 --> Upload Class Initialized
DEBUG - 2016-02-25 11:08:29 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 11:08:29 --> Final output sent to browser
DEBUG - 2016-02-25 11:08:29 --> Total execution time: 1.0862
INFO - 2016-02-25 08:09:34 --> Config Class Initialized
INFO - 2016-02-25 08:09:34 --> Hooks Class Initialized
DEBUG - 2016-02-25 08:09:34 --> UTF-8 Support Enabled
INFO - 2016-02-25 08:09:34 --> Utf8 Class Initialized
INFO - 2016-02-25 08:09:34 --> URI Class Initialized
INFO - 2016-02-25 08:09:34 --> Router Class Initialized
INFO - 2016-02-25 08:09:34 --> Output Class Initialized
INFO - 2016-02-25 08:09:34 --> Security Class Initialized
DEBUG - 2016-02-25 08:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 08:09:34 --> Input Class Initialized
INFO - 2016-02-25 08:09:34 --> Language Class Initialized
INFO - 2016-02-25 08:09:34 --> Loader Class Initialized
INFO - 2016-02-25 08:09:34 --> Helper loaded: url_helper
INFO - 2016-02-25 08:09:34 --> Helper loaded: file_helper
INFO - 2016-02-25 08:09:34 --> Helper loaded: date_helper
INFO - 2016-02-25 08:09:34 --> Helper loaded: form_helper
INFO - 2016-02-25 08:09:34 --> Database Driver Class Initialized
INFO - 2016-02-25 08:09:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 08:09:35 --> Controller Class Initialized
INFO - 2016-02-25 08:09:35 --> Model Class Initialized
INFO - 2016-02-25 08:09:35 --> Model Class Initialized
INFO - 2016-02-25 08:09:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 08:09:35 --> Pagination Class Initialized
INFO - 2016-02-25 08:09:35 --> Helper loaded: text_helper
INFO - 2016-02-25 08:09:35 --> Helper loaded: cookie_helper
INFO - 2016-02-25 08:09:35 --> Image Lib Class Initialized
INFO - 2016-02-25 11:09:35 --> Upload Class Initialized
DEBUG - 2016-02-25 11:09:35 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 11:09:35 --> Final output sent to browser
DEBUG - 2016-02-25 11:09:35 --> Total execution time: 1.1372
INFO - 2016-02-25 09:11:10 --> Config Class Initialized
INFO - 2016-02-25 09:11:10 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:11:10 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:11:10 --> Utf8 Class Initialized
INFO - 2016-02-25 09:11:10 --> URI Class Initialized
INFO - 2016-02-25 09:11:10 --> Router Class Initialized
INFO - 2016-02-25 09:11:10 --> Output Class Initialized
INFO - 2016-02-25 09:11:10 --> Security Class Initialized
DEBUG - 2016-02-25 09:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:11:10 --> Input Class Initialized
INFO - 2016-02-25 09:11:10 --> Language Class Initialized
INFO - 2016-02-25 09:11:10 --> Loader Class Initialized
INFO - 2016-02-25 09:11:10 --> Helper loaded: url_helper
INFO - 2016-02-25 09:11:10 --> Helper loaded: file_helper
INFO - 2016-02-25 09:11:10 --> Helper loaded: date_helper
INFO - 2016-02-25 09:11:10 --> Helper loaded: form_helper
INFO - 2016-02-25 09:11:10 --> Database Driver Class Initialized
INFO - 2016-02-25 09:11:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:11:11 --> Controller Class Initialized
INFO - 2016-02-25 09:11:11 --> Model Class Initialized
INFO - 2016-02-25 09:11:11 --> Model Class Initialized
INFO - 2016-02-25 09:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:11:11 --> Pagination Class Initialized
INFO - 2016-02-25 09:11:11 --> Helper loaded: text_helper
INFO - 2016-02-25 09:11:11 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:11:11 --> Image Lib Class Initialized
INFO - 2016-02-25 12:11:11 --> Upload Class Initialized
DEBUG - 2016-02-25 12:11:11 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 12:11:11 --> Final output sent to browser
DEBUG - 2016-02-25 12:11:11 --> Total execution time: 1.1364
INFO - 2016-02-25 09:12:32 --> Config Class Initialized
INFO - 2016-02-25 09:12:32 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:12:32 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:12:32 --> Utf8 Class Initialized
INFO - 2016-02-25 09:12:32 --> URI Class Initialized
INFO - 2016-02-25 09:12:32 --> Router Class Initialized
INFO - 2016-02-25 09:12:32 --> Output Class Initialized
INFO - 2016-02-25 09:12:32 --> Security Class Initialized
DEBUG - 2016-02-25 09:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:12:32 --> Input Class Initialized
INFO - 2016-02-25 09:12:32 --> Language Class Initialized
INFO - 2016-02-25 09:12:32 --> Loader Class Initialized
INFO - 2016-02-25 09:12:32 --> Helper loaded: url_helper
INFO - 2016-02-25 09:12:32 --> Helper loaded: file_helper
INFO - 2016-02-25 09:12:32 --> Helper loaded: date_helper
INFO - 2016-02-25 09:12:32 --> Helper loaded: form_helper
INFO - 2016-02-25 09:12:32 --> Database Driver Class Initialized
INFO - 2016-02-25 09:12:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:12:33 --> Controller Class Initialized
INFO - 2016-02-25 09:12:33 --> Model Class Initialized
INFO - 2016-02-25 09:12:33 --> Model Class Initialized
INFO - 2016-02-25 09:12:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:12:33 --> Pagination Class Initialized
INFO - 2016-02-25 09:12:33 --> Helper loaded: text_helper
INFO - 2016-02-25 09:12:33 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:12:33 --> Image Lib Class Initialized
INFO - 2016-02-25 12:12:33 --> Upload Class Initialized
DEBUG - 2016-02-25 12:12:33 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 12:12:33 --> Final output sent to browser
DEBUG - 2016-02-25 12:12:33 --> Total execution time: 1.1121
INFO - 2016-02-25 09:17:15 --> Config Class Initialized
INFO - 2016-02-25 09:17:15 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:17:15 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:17:15 --> Utf8 Class Initialized
INFO - 2016-02-25 09:17:15 --> URI Class Initialized
INFO - 2016-02-25 09:17:15 --> Router Class Initialized
INFO - 2016-02-25 09:17:15 --> Output Class Initialized
INFO - 2016-02-25 09:17:15 --> Security Class Initialized
DEBUG - 2016-02-25 09:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:17:15 --> Input Class Initialized
INFO - 2016-02-25 09:17:15 --> Language Class Initialized
INFO - 2016-02-25 09:17:15 --> Loader Class Initialized
INFO - 2016-02-25 09:17:15 --> Helper loaded: url_helper
INFO - 2016-02-25 09:17:15 --> Helper loaded: file_helper
INFO - 2016-02-25 09:17:15 --> Helper loaded: date_helper
INFO - 2016-02-25 09:17:15 --> Helper loaded: form_helper
INFO - 2016-02-25 09:17:15 --> Database Driver Class Initialized
INFO - 2016-02-25 09:17:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:17:16 --> Controller Class Initialized
INFO - 2016-02-25 09:17:16 --> Model Class Initialized
INFO - 2016-02-25 09:17:16 --> Model Class Initialized
INFO - 2016-02-25 09:17:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:17:16 --> Pagination Class Initialized
INFO - 2016-02-25 09:17:16 --> Helper loaded: text_helper
INFO - 2016-02-25 09:17:16 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:17:16 --> Image Lib Class Initialized
INFO - 2016-02-25 12:17:16 --> Upload Class Initialized
DEBUG - 2016-02-25 12:17:16 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 12:17:16 --> Final output sent to browser
DEBUG - 2016-02-25 12:17:16 --> Total execution time: 1.1213
INFO - 2016-02-25 09:21:35 --> Config Class Initialized
INFO - 2016-02-25 09:21:35 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:21:35 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:21:35 --> Utf8 Class Initialized
INFO - 2016-02-25 09:21:35 --> URI Class Initialized
INFO - 2016-02-25 09:21:35 --> Router Class Initialized
INFO - 2016-02-25 09:21:35 --> Output Class Initialized
INFO - 2016-02-25 09:21:35 --> Security Class Initialized
DEBUG - 2016-02-25 09:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:21:35 --> Input Class Initialized
INFO - 2016-02-25 09:21:35 --> Language Class Initialized
INFO - 2016-02-25 09:21:35 --> Loader Class Initialized
INFO - 2016-02-25 09:21:35 --> Helper loaded: url_helper
INFO - 2016-02-25 09:21:35 --> Helper loaded: file_helper
INFO - 2016-02-25 09:21:35 --> Helper loaded: date_helper
INFO - 2016-02-25 09:21:35 --> Helper loaded: form_helper
INFO - 2016-02-25 09:21:35 --> Database Driver Class Initialized
INFO - 2016-02-25 09:21:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:21:36 --> Controller Class Initialized
INFO - 2016-02-25 09:21:36 --> Model Class Initialized
INFO - 2016-02-25 09:21:36 --> Model Class Initialized
INFO - 2016-02-25 09:21:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:21:37 --> Pagination Class Initialized
INFO - 2016-02-25 09:21:37 --> Helper loaded: text_helper
INFO - 2016-02-25 09:21:37 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 12:21:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:21:37 --> Final output sent to browser
DEBUG - 2016-02-25 12:21:37 --> Total execution time: 1.1356
INFO - 2016-02-25 09:21:38 --> Config Class Initialized
INFO - 2016-02-25 09:21:38 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:21:38 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:21:38 --> Utf8 Class Initialized
INFO - 2016-02-25 09:21:38 --> URI Class Initialized
INFO - 2016-02-25 09:21:38 --> Router Class Initialized
INFO - 2016-02-25 09:21:38 --> Output Class Initialized
INFO - 2016-02-25 09:21:38 --> Security Class Initialized
DEBUG - 2016-02-25 09:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:21:38 --> Input Class Initialized
INFO - 2016-02-25 09:21:38 --> Language Class Initialized
INFO - 2016-02-25 09:21:38 --> Loader Class Initialized
INFO - 2016-02-25 09:21:38 --> Helper loaded: url_helper
INFO - 2016-02-25 09:21:38 --> Helper loaded: file_helper
INFO - 2016-02-25 09:21:38 --> Helper loaded: date_helper
INFO - 2016-02-25 09:21:38 --> Helper loaded: form_helper
INFO - 2016-02-25 09:21:38 --> Database Driver Class Initialized
INFO - 2016-02-25 09:21:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:21:39 --> Controller Class Initialized
INFO - 2016-02-25 09:21:39 --> Model Class Initialized
INFO - 2016-02-25 09:21:39 --> Model Class Initialized
INFO - 2016-02-25 09:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:21:39 --> Pagination Class Initialized
INFO - 2016-02-25 09:21:39 --> Helper loaded: text_helper
INFO - 2016-02-25 09:21:39 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 12:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 12:21:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:21:39 --> Final output sent to browser
DEBUG - 2016-02-25 12:21:39 --> Total execution time: 1.1580
INFO - 2016-02-25 09:21:42 --> Config Class Initialized
INFO - 2016-02-25 09:21:42 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:21:42 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:21:42 --> Utf8 Class Initialized
INFO - 2016-02-25 09:21:42 --> URI Class Initialized
INFO - 2016-02-25 09:21:42 --> Router Class Initialized
INFO - 2016-02-25 09:21:42 --> Output Class Initialized
INFO - 2016-02-25 09:21:42 --> Security Class Initialized
DEBUG - 2016-02-25 09:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:21:42 --> Input Class Initialized
INFO - 2016-02-25 09:21:42 --> Language Class Initialized
INFO - 2016-02-25 09:21:42 --> Loader Class Initialized
INFO - 2016-02-25 09:21:42 --> Helper loaded: url_helper
INFO - 2016-02-25 09:21:42 --> Helper loaded: file_helper
INFO - 2016-02-25 09:21:42 --> Helper loaded: date_helper
INFO - 2016-02-25 09:21:42 --> Helper loaded: form_helper
INFO - 2016-02-25 09:21:42 --> Database Driver Class Initialized
INFO - 2016-02-25 09:21:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:21:43 --> Controller Class Initialized
INFO - 2016-02-25 09:21:43 --> Model Class Initialized
INFO - 2016-02-25 09:21:43 --> Model Class Initialized
INFO - 2016-02-25 09:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:21:43 --> Pagination Class Initialized
INFO - 2016-02-25 09:21:43 --> Helper loaded: text_helper
INFO - 2016-02-25 09:21:43 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 12:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 12:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:21:43 --> Final output sent to browser
DEBUG - 2016-02-25 12:21:43 --> Total execution time: 1.1326
INFO - 2016-02-25 09:21:54 --> Config Class Initialized
INFO - 2016-02-25 09:21:54 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:21:54 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:21:54 --> Utf8 Class Initialized
INFO - 2016-02-25 09:21:54 --> URI Class Initialized
INFO - 2016-02-25 09:21:54 --> Router Class Initialized
INFO - 2016-02-25 09:21:54 --> Output Class Initialized
INFO - 2016-02-25 09:21:54 --> Security Class Initialized
DEBUG - 2016-02-25 09:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:21:54 --> Input Class Initialized
INFO - 2016-02-25 09:21:54 --> Language Class Initialized
INFO - 2016-02-25 09:21:54 --> Loader Class Initialized
INFO - 2016-02-25 09:21:54 --> Helper loaded: url_helper
INFO - 2016-02-25 09:21:54 --> Helper loaded: file_helper
INFO - 2016-02-25 09:21:54 --> Helper loaded: date_helper
INFO - 2016-02-25 09:21:54 --> Helper loaded: form_helper
INFO - 2016-02-25 09:21:54 --> Database Driver Class Initialized
INFO - 2016-02-25 09:21:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:21:55 --> Controller Class Initialized
INFO - 2016-02-25 09:21:55 --> Model Class Initialized
INFO - 2016-02-25 09:21:55 --> Model Class Initialized
INFO - 2016-02-25 09:21:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:21:55 --> Pagination Class Initialized
INFO - 2016-02-25 09:21:55 --> Helper loaded: text_helper
INFO - 2016-02-25 09:21:55 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:21:55 --> Image Lib Class Initialized
INFO - 2016-02-25 12:21:55 --> Upload Class Initialized
DEBUG - 2016-02-25 12:21:55 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 12:21:55 --> Final output sent to browser
DEBUG - 2016-02-25 12:21:55 --> Total execution time: 1.1198
INFO - 2016-02-25 09:32:25 --> Config Class Initialized
INFO - 2016-02-25 09:32:25 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:32:25 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:32:25 --> Utf8 Class Initialized
INFO - 2016-02-25 09:32:25 --> URI Class Initialized
INFO - 2016-02-25 09:32:25 --> Router Class Initialized
INFO - 2016-02-25 09:32:25 --> Output Class Initialized
INFO - 2016-02-25 09:32:25 --> Security Class Initialized
DEBUG - 2016-02-25 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:32:25 --> Input Class Initialized
INFO - 2016-02-25 09:32:25 --> Language Class Initialized
INFO - 2016-02-25 09:32:25 --> Loader Class Initialized
INFO - 2016-02-25 09:32:25 --> Helper loaded: url_helper
INFO - 2016-02-25 09:32:25 --> Helper loaded: file_helper
INFO - 2016-02-25 09:32:25 --> Helper loaded: date_helper
INFO - 2016-02-25 09:32:25 --> Helper loaded: form_helper
INFO - 2016-02-25 09:32:25 --> Database Driver Class Initialized
INFO - 2016-02-25 09:32:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:32:26 --> Controller Class Initialized
INFO - 2016-02-25 09:32:26 --> Model Class Initialized
INFO - 2016-02-25 09:32:26 --> Model Class Initialized
INFO - 2016-02-25 09:32:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:32:26 --> Pagination Class Initialized
INFO - 2016-02-25 09:32:26 --> Helper loaded: text_helper
INFO - 2016-02-25 09:32:26 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 12:32:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:32:26 --> Final output sent to browser
DEBUG - 2016-02-25 12:32:26 --> Total execution time: 1.1739
INFO - 2016-02-25 09:32:30 --> Config Class Initialized
INFO - 2016-02-25 09:32:30 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:32:30 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:32:30 --> Utf8 Class Initialized
INFO - 2016-02-25 09:32:30 --> URI Class Initialized
INFO - 2016-02-25 09:32:30 --> Router Class Initialized
INFO - 2016-02-25 09:32:30 --> Output Class Initialized
INFO - 2016-02-25 09:32:30 --> Security Class Initialized
DEBUG - 2016-02-25 09:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:32:30 --> Input Class Initialized
INFO - 2016-02-25 09:32:30 --> Language Class Initialized
INFO - 2016-02-25 09:32:30 --> Loader Class Initialized
INFO - 2016-02-25 09:32:30 --> Helper loaded: url_helper
INFO - 2016-02-25 09:32:30 --> Helper loaded: file_helper
INFO - 2016-02-25 09:32:30 --> Helper loaded: date_helper
INFO - 2016-02-25 09:32:30 --> Helper loaded: form_helper
INFO - 2016-02-25 09:32:30 --> Database Driver Class Initialized
INFO - 2016-02-25 09:32:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:32:31 --> Controller Class Initialized
INFO - 2016-02-25 09:32:31 --> Model Class Initialized
INFO - 2016-02-25 09:32:31 --> Model Class Initialized
INFO - 2016-02-25 09:32:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:32:31 --> Pagination Class Initialized
INFO - 2016-02-25 09:32:31 --> Helper loaded: text_helper
INFO - 2016-02-25 09:32:31 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 12:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 12:32:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:32:31 --> Final output sent to browser
DEBUG - 2016-02-25 12:32:31 --> Total execution time: 1.1485
INFO - 2016-02-25 09:32:43 --> Config Class Initialized
INFO - 2016-02-25 09:32:43 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:32:43 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:32:43 --> Utf8 Class Initialized
INFO - 2016-02-25 09:32:43 --> URI Class Initialized
INFO - 2016-02-25 09:32:43 --> Router Class Initialized
INFO - 2016-02-25 09:32:43 --> Output Class Initialized
INFO - 2016-02-25 09:32:43 --> Security Class Initialized
DEBUG - 2016-02-25 09:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:32:43 --> Input Class Initialized
INFO - 2016-02-25 09:32:43 --> Language Class Initialized
ERROR - 2016-02-25 09:32:43 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 476
INFO - 2016-02-25 09:33:44 --> Config Class Initialized
INFO - 2016-02-25 09:33:44 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:33:44 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:33:44 --> Utf8 Class Initialized
INFO - 2016-02-25 09:33:44 --> URI Class Initialized
INFO - 2016-02-25 09:33:44 --> Router Class Initialized
INFO - 2016-02-25 09:33:44 --> Output Class Initialized
INFO - 2016-02-25 09:33:44 --> Security Class Initialized
DEBUG - 2016-02-25 09:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:33:44 --> Input Class Initialized
INFO - 2016-02-25 09:33:44 --> Language Class Initialized
INFO - 2016-02-25 09:33:44 --> Loader Class Initialized
INFO - 2016-02-25 09:33:44 --> Helper loaded: url_helper
INFO - 2016-02-25 09:33:44 --> Helper loaded: file_helper
INFO - 2016-02-25 09:33:44 --> Helper loaded: date_helper
INFO - 2016-02-25 09:33:44 --> Helper loaded: form_helper
INFO - 2016-02-25 09:33:44 --> Database Driver Class Initialized
INFO - 2016-02-25 09:33:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:33:45 --> Controller Class Initialized
INFO - 2016-02-25 09:33:45 --> Model Class Initialized
INFO - 2016-02-25 09:33:45 --> Model Class Initialized
INFO - 2016-02-25 09:33:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:33:45 --> Pagination Class Initialized
INFO - 2016-02-25 09:33:45 --> Helper loaded: text_helper
INFO - 2016-02-25 09:33:45 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 12:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 12:33:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:33:45 --> Final output sent to browser
DEBUG - 2016-02-25 12:33:45 --> Total execution time: 1.1513
INFO - 2016-02-25 09:33:53 --> Config Class Initialized
INFO - 2016-02-25 09:33:53 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:33:53 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:33:53 --> Utf8 Class Initialized
INFO - 2016-02-25 09:33:53 --> URI Class Initialized
INFO - 2016-02-25 09:33:53 --> Router Class Initialized
INFO - 2016-02-25 09:33:53 --> Output Class Initialized
INFO - 2016-02-25 09:33:53 --> Security Class Initialized
DEBUG - 2016-02-25 09:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:33:53 --> Input Class Initialized
INFO - 2016-02-25 09:33:53 --> Language Class Initialized
INFO - 2016-02-25 09:33:53 --> Loader Class Initialized
INFO - 2016-02-25 09:33:53 --> Helper loaded: url_helper
INFO - 2016-02-25 09:33:53 --> Helper loaded: file_helper
INFO - 2016-02-25 09:33:53 --> Helper loaded: date_helper
INFO - 2016-02-25 09:33:53 --> Helper loaded: form_helper
INFO - 2016-02-25 09:33:53 --> Database Driver Class Initialized
INFO - 2016-02-25 09:33:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:33:54 --> Controller Class Initialized
INFO - 2016-02-25 09:33:54 --> Model Class Initialized
INFO - 2016-02-25 09:33:54 --> Model Class Initialized
INFO - 2016-02-25 09:33:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:33:54 --> Pagination Class Initialized
INFO - 2016-02-25 09:33:54 --> Helper loaded: text_helper
INFO - 2016-02-25 09:33:54 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:33:54 --> Image Lib Class Initialized
INFO - 2016-02-25 12:33:54 --> Upload Class Initialized
ERROR - 2016-02-25 12:33:54 --> Severity: Error --> Call to undefined method Jboard::_createThumbnail() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 433
INFO - 2016-02-25 09:34:40 --> Config Class Initialized
INFO - 2016-02-25 09:34:40 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:34:40 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:34:40 --> Utf8 Class Initialized
INFO - 2016-02-25 09:34:40 --> URI Class Initialized
INFO - 2016-02-25 09:34:40 --> Router Class Initialized
INFO - 2016-02-25 09:34:40 --> Output Class Initialized
INFO - 2016-02-25 09:34:40 --> Security Class Initialized
DEBUG - 2016-02-25 09:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:34:40 --> Input Class Initialized
INFO - 2016-02-25 09:34:40 --> Language Class Initialized
INFO - 2016-02-25 09:34:40 --> Loader Class Initialized
INFO - 2016-02-25 09:34:40 --> Helper loaded: url_helper
INFO - 2016-02-25 09:34:40 --> Helper loaded: file_helper
INFO - 2016-02-25 09:34:40 --> Helper loaded: date_helper
INFO - 2016-02-25 09:34:40 --> Helper loaded: form_helper
INFO - 2016-02-25 09:34:40 --> Database Driver Class Initialized
INFO - 2016-02-25 09:34:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:34:41 --> Controller Class Initialized
INFO - 2016-02-25 09:34:41 --> Model Class Initialized
INFO - 2016-02-25 09:34:41 --> Model Class Initialized
INFO - 2016-02-25 09:34:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:34:41 --> Pagination Class Initialized
INFO - 2016-02-25 09:34:41 --> Helper loaded: text_helper
INFO - 2016-02-25 09:34:41 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 12:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 12:34:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:34:41 --> Final output sent to browser
DEBUG - 2016-02-25 12:34:41 --> Total execution time: 1.1566
INFO - 2016-02-25 09:34:49 --> Config Class Initialized
INFO - 2016-02-25 09:34:49 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:34:49 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:34:49 --> Utf8 Class Initialized
INFO - 2016-02-25 09:34:49 --> URI Class Initialized
INFO - 2016-02-25 09:34:49 --> Router Class Initialized
INFO - 2016-02-25 09:34:49 --> Output Class Initialized
INFO - 2016-02-25 09:34:49 --> Security Class Initialized
DEBUG - 2016-02-25 09:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:34:49 --> Input Class Initialized
INFO - 2016-02-25 09:34:49 --> Language Class Initialized
INFO - 2016-02-25 09:34:49 --> Loader Class Initialized
INFO - 2016-02-25 09:34:49 --> Helper loaded: url_helper
INFO - 2016-02-25 09:34:49 --> Helper loaded: file_helper
INFO - 2016-02-25 09:34:49 --> Helper loaded: date_helper
INFO - 2016-02-25 09:34:49 --> Helper loaded: form_helper
INFO - 2016-02-25 09:34:49 --> Database Driver Class Initialized
INFO - 2016-02-25 09:34:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:34:50 --> Controller Class Initialized
INFO - 2016-02-25 09:34:50 --> Model Class Initialized
INFO - 2016-02-25 09:34:50 --> Model Class Initialized
INFO - 2016-02-25 09:34:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:34:50 --> Pagination Class Initialized
INFO - 2016-02-25 09:34:50 --> Helper loaded: text_helper
INFO - 2016-02-25 09:34:50 --> Helper loaded: cookie_helper
INFO - 2016-02-25 09:34:50 --> Image Lib Class Initialized
INFO - 2016-02-25 12:34:50 --> Upload Class Initialized
DEBUG - 2016-02-25 12:34:50 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 12:34:50 --> Final output sent to browser
DEBUG - 2016-02-25 12:34:50 --> Total execution time: 1.1592
INFO - 2016-02-25 09:39:14 --> Config Class Initialized
INFO - 2016-02-25 09:39:14 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:39:14 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:39:14 --> Utf8 Class Initialized
INFO - 2016-02-25 09:39:14 --> URI Class Initialized
INFO - 2016-02-25 09:39:14 --> Router Class Initialized
INFO - 2016-02-25 09:39:14 --> Output Class Initialized
INFO - 2016-02-25 09:39:14 --> Security Class Initialized
DEBUG - 2016-02-25 09:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:39:14 --> Input Class Initialized
INFO - 2016-02-25 09:39:14 --> Language Class Initialized
INFO - 2016-02-25 09:39:14 --> Loader Class Initialized
INFO - 2016-02-25 09:39:14 --> Helper loaded: url_helper
INFO - 2016-02-25 09:39:14 --> Helper loaded: file_helper
INFO - 2016-02-25 09:39:14 --> Helper loaded: date_helper
INFO - 2016-02-25 09:39:14 --> Helper loaded: form_helper
INFO - 2016-02-25 09:39:14 --> Database Driver Class Initialized
INFO - 2016-02-25 09:39:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:39:15 --> Controller Class Initialized
INFO - 2016-02-25 09:39:15 --> Model Class Initialized
INFO - 2016-02-25 09:39:15 --> Model Class Initialized
INFO - 2016-02-25 09:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:39:15 --> Pagination Class Initialized
INFO - 2016-02-25 09:39:15 --> Helper loaded: text_helper
INFO - 2016-02-25 09:39:15 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 12:39:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:39:15 --> Final output sent to browser
DEBUG - 2016-02-25 12:39:15 --> Total execution time: 1.0899
INFO - 2016-02-25 09:39:17 --> Config Class Initialized
INFO - 2016-02-25 09:39:17 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:39:17 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:39:17 --> Utf8 Class Initialized
INFO - 2016-02-25 09:39:17 --> URI Class Initialized
INFO - 2016-02-25 09:39:17 --> Router Class Initialized
INFO - 2016-02-25 09:39:17 --> Output Class Initialized
INFO - 2016-02-25 09:39:17 --> Security Class Initialized
DEBUG - 2016-02-25 09:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:39:17 --> Input Class Initialized
INFO - 2016-02-25 09:39:17 --> Language Class Initialized
INFO - 2016-02-25 09:39:17 --> Loader Class Initialized
INFO - 2016-02-25 09:39:17 --> Helper loaded: url_helper
INFO - 2016-02-25 09:39:17 --> Helper loaded: file_helper
INFO - 2016-02-25 09:39:17 --> Helper loaded: date_helper
INFO - 2016-02-25 09:39:17 --> Helper loaded: form_helper
INFO - 2016-02-25 09:39:17 --> Database Driver Class Initialized
INFO - 2016-02-25 09:39:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:39:18 --> Controller Class Initialized
INFO - 2016-02-25 09:39:18 --> Model Class Initialized
INFO - 2016-02-25 09:39:18 --> Model Class Initialized
INFO - 2016-02-25 09:39:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:39:18 --> Pagination Class Initialized
INFO - 2016-02-25 09:39:18 --> Helper loaded: text_helper
INFO - 2016-02-25 09:39:18 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 12:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 12:39:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:39:18 --> Final output sent to browser
DEBUG - 2016-02-25 12:39:18 --> Total execution time: 1.1288
INFO - 2016-02-25 09:39:34 --> Config Class Initialized
INFO - 2016-02-25 09:39:34 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:39:34 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:39:34 --> Utf8 Class Initialized
INFO - 2016-02-25 09:39:34 --> URI Class Initialized
INFO - 2016-02-25 09:39:34 --> Router Class Initialized
INFO - 2016-02-25 09:39:34 --> Output Class Initialized
INFO - 2016-02-25 09:39:34 --> Security Class Initialized
DEBUG - 2016-02-25 09:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:39:34 --> Input Class Initialized
INFO - 2016-02-25 09:39:34 --> Language Class Initialized
INFO - 2016-02-25 09:39:34 --> Loader Class Initialized
INFO - 2016-02-25 09:39:34 --> Helper loaded: url_helper
INFO - 2016-02-25 09:39:34 --> Helper loaded: file_helper
INFO - 2016-02-25 09:39:34 --> Helper loaded: date_helper
INFO - 2016-02-25 09:39:34 --> Helper loaded: form_helper
INFO - 2016-02-25 09:39:34 --> Database Driver Class Initialized
INFO - 2016-02-25 09:39:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:39:35 --> Controller Class Initialized
INFO - 2016-02-25 09:39:35 --> Model Class Initialized
INFO - 2016-02-25 09:39:35 --> Model Class Initialized
INFO - 2016-02-25 09:39:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:39:35 --> Pagination Class Initialized
INFO - 2016-02-25 09:39:35 --> Helper loaded: text_helper
INFO - 2016-02-25 09:39:35 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:39:35 --> Upload Class Initialized
INFO - 2016-02-25 12:39:35 --> Image Lib Class Initialized
DEBUG - 2016-02-25 12:39:35 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 12:39:35 --> Final output sent to browser
DEBUG - 2016-02-25 12:39:35 --> Total execution time: 1.1148
INFO - 2016-02-25 09:45:32 --> Config Class Initialized
INFO - 2016-02-25 09:45:32 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:45:32 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:45:32 --> Utf8 Class Initialized
INFO - 2016-02-25 09:45:32 --> URI Class Initialized
INFO - 2016-02-25 09:45:32 --> Router Class Initialized
INFO - 2016-02-25 09:45:32 --> Output Class Initialized
INFO - 2016-02-25 09:45:32 --> Security Class Initialized
DEBUG - 2016-02-25 09:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:45:32 --> Input Class Initialized
INFO - 2016-02-25 09:45:32 --> Language Class Initialized
ERROR - 2016-02-25 09:45:32 --> 404 Page Not Found: Infophp/index
INFO - 2016-02-25 09:46:06 --> Config Class Initialized
INFO - 2016-02-25 09:46:06 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:46:06 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:46:06 --> Utf8 Class Initialized
INFO - 2016-02-25 09:46:06 --> URI Class Initialized
INFO - 2016-02-25 09:46:06 --> Router Class Initialized
INFO - 2016-02-25 09:46:06 --> Output Class Initialized
INFO - 2016-02-25 09:46:06 --> Security Class Initialized
DEBUG - 2016-02-25 09:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:46:06 --> Input Class Initialized
INFO - 2016-02-25 09:46:06 --> Language Class Initialized
ERROR - 2016-02-25 09:46:06 --> 404 Page Not Found: Infophp/index
INFO - 2016-02-25 09:46:08 --> Config Class Initialized
INFO - 2016-02-25 09:46:08 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:46:08 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:46:08 --> Utf8 Class Initialized
INFO - 2016-02-25 09:46:08 --> URI Class Initialized
INFO - 2016-02-25 09:46:08 --> Router Class Initialized
INFO - 2016-02-25 09:46:08 --> Output Class Initialized
INFO - 2016-02-25 09:46:08 --> Security Class Initialized
DEBUG - 2016-02-25 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:46:08 --> Input Class Initialized
INFO - 2016-02-25 09:46:08 --> Language Class Initialized
ERROR - 2016-02-25 09:46:08 --> 404 Page Not Found: Infophp/index
INFO - 2016-02-25 09:46:20 --> Config Class Initialized
INFO - 2016-02-25 09:46:20 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:46:20 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:46:20 --> Utf8 Class Initialized
INFO - 2016-02-25 09:46:20 --> URI Class Initialized
INFO - 2016-02-25 09:46:20 --> Router Class Initialized
INFO - 2016-02-25 09:46:20 --> Output Class Initialized
INFO - 2016-02-25 09:46:20 --> Security Class Initialized
DEBUG - 2016-02-25 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:46:20 --> Input Class Initialized
INFO - 2016-02-25 09:46:20 --> Language Class Initialized
ERROR - 2016-02-25 09:46:20 --> 404 Page Not Found: Phpinfophp/index
INFO - 2016-02-25 09:47:45 --> Config Class Initialized
INFO - 2016-02-25 09:47:45 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:47:45 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:47:45 --> Utf8 Class Initialized
INFO - 2016-02-25 09:47:45 --> URI Class Initialized
INFO - 2016-02-25 09:47:45 --> Router Class Initialized
INFO - 2016-02-25 09:47:45 --> Output Class Initialized
INFO - 2016-02-25 09:47:45 --> Security Class Initialized
DEBUG - 2016-02-25 09:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:47:45 --> Input Class Initialized
INFO - 2016-02-25 09:47:45 --> Language Class Initialized
ERROR - 2016-02-25 09:47:45 --> 404 Page Not Found: Infophp/index
INFO - 2016-02-25 09:58:02 --> Config Class Initialized
INFO - 2016-02-25 09:58:02 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:58:02 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:58:02 --> Utf8 Class Initialized
INFO - 2016-02-25 09:58:02 --> URI Class Initialized
INFO - 2016-02-25 09:58:02 --> Router Class Initialized
INFO - 2016-02-25 09:58:02 --> Output Class Initialized
INFO - 2016-02-25 09:58:02 --> Security Class Initialized
DEBUG - 2016-02-25 09:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:58:02 --> Input Class Initialized
INFO - 2016-02-25 09:58:02 --> Language Class Initialized
INFO - 2016-02-25 09:58:02 --> Loader Class Initialized
INFO - 2016-02-25 09:58:02 --> Helper loaded: url_helper
INFO - 2016-02-25 09:58:02 --> Helper loaded: file_helper
INFO - 2016-02-25 09:58:02 --> Helper loaded: date_helper
INFO - 2016-02-25 09:58:02 --> Helper loaded: form_helper
INFO - 2016-02-25 09:58:02 --> Database Driver Class Initialized
INFO - 2016-02-25 09:58:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:58:03 --> Controller Class Initialized
INFO - 2016-02-25 09:58:03 --> Model Class Initialized
INFO - 2016-02-25 09:58:03 --> Model Class Initialized
INFO - 2016-02-25 09:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:58:03 --> Pagination Class Initialized
INFO - 2016-02-25 09:58:03 --> Helper loaded: text_helper
INFO - 2016-02-25 09:58:03 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 12:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 12:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:58:03 --> Final output sent to browser
DEBUG - 2016-02-25 12:58:03 --> Total execution time: 1.1238
INFO - 2016-02-25 09:58:17 --> Config Class Initialized
INFO - 2016-02-25 09:58:17 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:58:17 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:58:17 --> Utf8 Class Initialized
INFO - 2016-02-25 09:58:17 --> URI Class Initialized
INFO - 2016-02-25 09:58:17 --> Router Class Initialized
INFO - 2016-02-25 09:58:17 --> Output Class Initialized
INFO - 2016-02-25 09:58:17 --> Security Class Initialized
DEBUG - 2016-02-25 09:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:58:17 --> Input Class Initialized
INFO - 2016-02-25 09:58:17 --> Language Class Initialized
ERROR - 2016-02-25 09:58:17 --> Severity: Parsing Error --> syntax error, unexpected '$config' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 469
INFO - 2016-02-25 09:58:53 --> Config Class Initialized
INFO - 2016-02-25 09:58:53 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:58:53 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:58:53 --> Utf8 Class Initialized
INFO - 2016-02-25 09:58:54 --> URI Class Initialized
INFO - 2016-02-25 09:58:54 --> Router Class Initialized
INFO - 2016-02-25 09:58:54 --> Output Class Initialized
INFO - 2016-02-25 09:58:54 --> Security Class Initialized
DEBUG - 2016-02-25 09:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:58:54 --> Input Class Initialized
INFO - 2016-02-25 09:58:54 --> Language Class Initialized
INFO - 2016-02-25 09:58:54 --> Loader Class Initialized
INFO - 2016-02-25 09:58:54 --> Helper loaded: url_helper
INFO - 2016-02-25 09:58:54 --> Helper loaded: file_helper
INFO - 2016-02-25 09:58:54 --> Helper loaded: date_helper
INFO - 2016-02-25 09:58:54 --> Helper loaded: form_helper
INFO - 2016-02-25 09:58:54 --> Database Driver Class Initialized
INFO - 2016-02-25 09:58:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:58:55 --> Controller Class Initialized
INFO - 2016-02-25 09:58:55 --> Model Class Initialized
INFO - 2016-02-25 09:58:55 --> Model Class Initialized
INFO - 2016-02-25 09:58:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:58:55 --> Pagination Class Initialized
INFO - 2016-02-25 09:58:55 --> Helper loaded: text_helper
INFO - 2016-02-25 09:58:55 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:58:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 12:58:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 12:58:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 12:58:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 12:58:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 12:58:55 --> Final output sent to browser
DEBUG - 2016-02-25 12:58:55 --> Total execution time: 1.1996
INFO - 2016-02-25 09:59:03 --> Config Class Initialized
INFO - 2016-02-25 09:59:03 --> Hooks Class Initialized
DEBUG - 2016-02-25 09:59:03 --> UTF-8 Support Enabled
INFO - 2016-02-25 09:59:03 --> Utf8 Class Initialized
INFO - 2016-02-25 09:59:03 --> URI Class Initialized
INFO - 2016-02-25 09:59:03 --> Router Class Initialized
INFO - 2016-02-25 09:59:03 --> Output Class Initialized
INFO - 2016-02-25 09:59:03 --> Security Class Initialized
DEBUG - 2016-02-25 09:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 09:59:03 --> Input Class Initialized
INFO - 2016-02-25 09:59:03 --> Language Class Initialized
INFO - 2016-02-25 09:59:03 --> Loader Class Initialized
INFO - 2016-02-25 09:59:03 --> Helper loaded: url_helper
INFO - 2016-02-25 09:59:03 --> Helper loaded: file_helper
INFO - 2016-02-25 09:59:03 --> Helper loaded: date_helper
INFO - 2016-02-25 09:59:03 --> Helper loaded: form_helper
INFO - 2016-02-25 09:59:03 --> Database Driver Class Initialized
INFO - 2016-02-25 09:59:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 09:59:04 --> Controller Class Initialized
INFO - 2016-02-25 09:59:04 --> Model Class Initialized
INFO - 2016-02-25 09:59:04 --> Model Class Initialized
INFO - 2016-02-25 09:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 09:59:04 --> Pagination Class Initialized
INFO - 2016-02-25 09:59:04 --> Helper loaded: text_helper
INFO - 2016-02-25 09:59:04 --> Helper loaded: cookie_helper
INFO - 2016-02-25 12:59:04 --> Image Lib Class Initialized
INFO - 2016-02-25 12:59:04 --> Upload Class Initialized
DEBUG - 2016-02-25 12:59:04 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2016-02-25 12:59:04 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 12:59:04 --> Final output sent to browser
DEBUG - 2016-02-25 12:59:04 --> Total execution time: 1.1189
INFO - 2016-02-25 10:06:53 --> Config Class Initialized
INFO - 2016-02-25 10:06:53 --> Hooks Class Initialized
DEBUG - 2016-02-25 10:06:53 --> UTF-8 Support Enabled
INFO - 2016-02-25 10:06:53 --> Utf8 Class Initialized
INFO - 2016-02-25 10:06:53 --> URI Class Initialized
INFO - 2016-02-25 10:06:53 --> Router Class Initialized
INFO - 2016-02-25 10:06:53 --> Output Class Initialized
INFO - 2016-02-25 10:06:53 --> Security Class Initialized
DEBUG - 2016-02-25 10:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 10:06:53 --> Input Class Initialized
INFO - 2016-02-25 10:06:53 --> Language Class Initialized
INFO - 2016-02-25 10:06:53 --> Loader Class Initialized
INFO - 2016-02-25 10:06:53 --> Helper loaded: url_helper
INFO - 2016-02-25 10:06:53 --> Helper loaded: file_helper
INFO - 2016-02-25 10:06:53 --> Helper loaded: date_helper
INFO - 2016-02-25 10:06:53 --> Helper loaded: form_helper
INFO - 2016-02-25 10:06:53 --> Database Driver Class Initialized
INFO - 2016-02-25 10:06:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 10:06:54 --> Controller Class Initialized
INFO - 2016-02-25 10:06:54 --> Model Class Initialized
INFO - 2016-02-25 10:06:54 --> Model Class Initialized
INFO - 2016-02-25 10:06:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 10:06:54 --> Pagination Class Initialized
INFO - 2016-02-25 10:06:54 --> Helper loaded: text_helper
INFO - 2016-02-25 10:06:54 --> Helper loaded: cookie_helper
INFO - 2016-02-25 13:06:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 13:06:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 13:06:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 13:06:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 13:06:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 13:06:54 --> Final output sent to browser
DEBUG - 2016-02-25 13:06:54 --> Total execution time: 1.1653
INFO - 2016-02-25 10:07:17 --> Config Class Initialized
INFO - 2016-02-25 10:07:17 --> Hooks Class Initialized
DEBUG - 2016-02-25 10:07:17 --> UTF-8 Support Enabled
INFO - 2016-02-25 10:07:17 --> Utf8 Class Initialized
INFO - 2016-02-25 10:07:17 --> URI Class Initialized
INFO - 2016-02-25 10:07:17 --> Router Class Initialized
INFO - 2016-02-25 10:07:17 --> Output Class Initialized
INFO - 2016-02-25 10:07:17 --> Security Class Initialized
DEBUG - 2016-02-25 10:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 10:07:17 --> Input Class Initialized
INFO - 2016-02-25 10:07:17 --> Language Class Initialized
INFO - 2016-02-25 10:07:17 --> Loader Class Initialized
INFO - 2016-02-25 10:07:17 --> Helper loaded: url_helper
INFO - 2016-02-25 10:07:17 --> Helper loaded: file_helper
INFO - 2016-02-25 10:07:17 --> Helper loaded: date_helper
INFO - 2016-02-25 10:07:17 --> Helper loaded: form_helper
INFO - 2016-02-25 10:07:17 --> Database Driver Class Initialized
INFO - 2016-02-25 10:07:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 10:07:18 --> Controller Class Initialized
INFO - 2016-02-25 10:07:18 --> Model Class Initialized
INFO - 2016-02-25 10:07:18 --> Model Class Initialized
INFO - 2016-02-25 10:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 10:07:18 --> Pagination Class Initialized
INFO - 2016-02-25 10:07:18 --> Helper loaded: text_helper
INFO - 2016-02-25 10:07:18 --> Helper loaded: cookie_helper
INFO - 2016-02-25 13:07:18 --> Image Lib Class Initialized
ERROR - 2016-02-25 13:07:18 --> Severity: Notice --> Undefined variable: config C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 407
INFO - 2016-02-25 13:07:18 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2016-02-25 13:07:18 --> You must specify a source image in your preferences.
INFO - 2016-02-25 13:07:18 --> Upload Class Initialized
DEBUG - 2016-02-25 13:07:18 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2016-02-25 13:07:18 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 13:07:19 --> Final output sent to browser
DEBUG - 2016-02-25 13:07:19 --> Total execution time: 1.3112
INFO - 2016-02-25 10:08:05 --> Config Class Initialized
INFO - 2016-02-25 10:08:05 --> Hooks Class Initialized
DEBUG - 2016-02-25 10:08:05 --> UTF-8 Support Enabled
INFO - 2016-02-25 10:08:05 --> Utf8 Class Initialized
INFO - 2016-02-25 10:08:05 --> URI Class Initialized
INFO - 2016-02-25 10:08:05 --> Router Class Initialized
INFO - 2016-02-25 10:08:05 --> Output Class Initialized
INFO - 2016-02-25 10:08:05 --> Security Class Initialized
DEBUG - 2016-02-25 10:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 10:08:05 --> Input Class Initialized
INFO - 2016-02-25 10:08:05 --> Language Class Initialized
INFO - 2016-02-25 10:08:05 --> Loader Class Initialized
INFO - 2016-02-25 10:08:05 --> Helper loaded: url_helper
INFO - 2016-02-25 10:08:05 --> Helper loaded: file_helper
INFO - 2016-02-25 10:08:05 --> Helper loaded: date_helper
INFO - 2016-02-25 10:08:05 --> Helper loaded: form_helper
INFO - 2016-02-25 10:08:05 --> Database Driver Class Initialized
INFO - 2016-02-25 10:08:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 10:08:06 --> Controller Class Initialized
INFO - 2016-02-25 10:08:06 --> Model Class Initialized
INFO - 2016-02-25 10:08:06 --> Model Class Initialized
INFO - 2016-02-25 10:08:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 10:08:06 --> Pagination Class Initialized
INFO - 2016-02-25 10:08:06 --> Helper loaded: text_helper
INFO - 2016-02-25 10:08:06 --> Helper loaded: cookie_helper
INFO - 2016-02-25 13:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 13:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 13:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 13:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 13:08:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 13:08:06 --> Final output sent to browser
DEBUG - 2016-02-25 13:08:06 --> Total execution time: 1.1741
INFO - 2016-02-25 10:08:40 --> Config Class Initialized
INFO - 2016-02-25 10:08:40 --> Hooks Class Initialized
DEBUG - 2016-02-25 10:08:40 --> UTF-8 Support Enabled
INFO - 2016-02-25 10:08:40 --> Utf8 Class Initialized
INFO - 2016-02-25 10:08:40 --> URI Class Initialized
INFO - 2016-02-25 10:08:40 --> Router Class Initialized
INFO - 2016-02-25 10:08:40 --> Output Class Initialized
INFO - 2016-02-25 10:08:40 --> Security Class Initialized
DEBUG - 2016-02-25 10:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 10:08:40 --> Input Class Initialized
INFO - 2016-02-25 10:08:40 --> Language Class Initialized
INFO - 2016-02-25 10:08:40 --> Loader Class Initialized
INFO - 2016-02-25 10:08:40 --> Helper loaded: url_helper
INFO - 2016-02-25 10:08:40 --> Helper loaded: file_helper
INFO - 2016-02-25 10:08:40 --> Helper loaded: date_helper
INFO - 2016-02-25 10:08:40 --> Helper loaded: form_helper
INFO - 2016-02-25 10:08:40 --> Database Driver Class Initialized
INFO - 2016-02-25 10:08:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 10:08:41 --> Controller Class Initialized
INFO - 2016-02-25 10:08:41 --> Model Class Initialized
INFO - 2016-02-25 10:08:41 --> Model Class Initialized
INFO - 2016-02-25 10:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 10:08:41 --> Pagination Class Initialized
INFO - 2016-02-25 10:08:41 --> Helper loaded: text_helper
INFO - 2016-02-25 10:08:41 --> Helper loaded: cookie_helper
INFO - 2016-02-25 13:08:41 --> Image Lib Class Initialized
INFO - 2016-02-25 13:08:41 --> Upload Class Initialized
DEBUG - 2016-02-25 13:08:41 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 2016-02-25 13:08:41 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 13:08:42 --> Final output sent to browser
DEBUG - 2016-02-25 13:08:42 --> Total execution time: 1.2215
INFO - 2016-02-25 10:11:07 --> Config Class Initialized
INFO - 2016-02-25 10:11:07 --> Hooks Class Initialized
DEBUG - 2016-02-25 10:11:07 --> UTF-8 Support Enabled
INFO - 2016-02-25 10:11:07 --> Utf8 Class Initialized
INFO - 2016-02-25 10:11:07 --> URI Class Initialized
INFO - 2016-02-25 10:11:07 --> Router Class Initialized
INFO - 2016-02-25 10:11:07 --> Output Class Initialized
INFO - 2016-02-25 10:11:07 --> Security Class Initialized
DEBUG - 2016-02-25 10:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 10:11:07 --> Input Class Initialized
INFO - 2016-02-25 10:11:07 --> Language Class Initialized
INFO - 2016-02-25 10:11:07 --> Loader Class Initialized
INFO - 2016-02-25 10:11:07 --> Helper loaded: url_helper
INFO - 2016-02-25 10:11:07 --> Helper loaded: file_helper
INFO - 2016-02-25 10:11:07 --> Helper loaded: date_helper
INFO - 2016-02-25 10:11:07 --> Helper loaded: form_helper
INFO - 2016-02-25 10:11:07 --> Database Driver Class Initialized
INFO - 2016-02-25 10:11:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 10:11:08 --> Controller Class Initialized
INFO - 2016-02-25 10:11:08 --> Model Class Initialized
INFO - 2016-02-25 10:11:08 --> Model Class Initialized
INFO - 2016-02-25 10:11:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 10:11:08 --> Pagination Class Initialized
INFO - 2016-02-25 10:11:08 --> Helper loaded: text_helper
INFO - 2016-02-25 10:11:08 --> Helper loaded: cookie_helper
INFO - 2016-02-25 13:11:08 --> Upload Class Initialized
INFO - 2016-02-25 13:11:08 --> Image Lib Class Initialized
DEBUG - 2016-02-25 13:11:08 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 13:11:08 --> Final output sent to browser
DEBUG - 2016-02-25 13:11:08 --> Total execution time: 1.4810
INFO - 2016-02-25 10:16:55 --> Config Class Initialized
INFO - 2016-02-25 10:16:55 --> Hooks Class Initialized
DEBUG - 2016-02-25 10:16:55 --> UTF-8 Support Enabled
INFO - 2016-02-25 10:16:55 --> Utf8 Class Initialized
INFO - 2016-02-25 10:16:55 --> URI Class Initialized
INFO - 2016-02-25 10:16:55 --> Router Class Initialized
INFO - 2016-02-25 10:16:55 --> Output Class Initialized
INFO - 2016-02-25 10:16:55 --> Security Class Initialized
DEBUG - 2016-02-25 10:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 10:16:55 --> Input Class Initialized
INFO - 2016-02-25 10:16:55 --> Language Class Initialized
INFO - 2016-02-25 10:16:55 --> Loader Class Initialized
INFO - 2016-02-25 10:16:55 --> Helper loaded: url_helper
INFO - 2016-02-25 10:16:55 --> Helper loaded: file_helper
INFO - 2016-02-25 10:16:55 --> Helper loaded: date_helper
INFO - 2016-02-25 10:16:55 --> Helper loaded: form_helper
INFO - 2016-02-25 10:16:55 --> Database Driver Class Initialized
INFO - 2016-02-25 10:16:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 10:16:56 --> Controller Class Initialized
INFO - 2016-02-25 10:16:56 --> Model Class Initialized
INFO - 2016-02-25 10:16:56 --> Model Class Initialized
INFO - 2016-02-25 10:16:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 10:16:56 --> Pagination Class Initialized
INFO - 2016-02-25 10:16:56 --> Helper loaded: text_helper
INFO - 2016-02-25 10:16:56 --> Helper loaded: cookie_helper
INFO - 2016-02-25 13:16:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 13:16:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 13:16:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 13:16:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 13:16:56 --> Final output sent to browser
DEBUG - 2016-02-25 13:16:56 --> Total execution time: 1.1303
INFO - 2016-02-25 10:17:17 --> Config Class Initialized
INFO - 2016-02-25 10:17:17 --> Hooks Class Initialized
DEBUG - 2016-02-25 10:17:17 --> UTF-8 Support Enabled
INFO - 2016-02-25 10:17:17 --> Utf8 Class Initialized
INFO - 2016-02-25 10:17:17 --> URI Class Initialized
INFO - 2016-02-25 10:17:17 --> Router Class Initialized
INFO - 2016-02-25 10:17:17 --> Output Class Initialized
INFO - 2016-02-25 10:17:17 --> Security Class Initialized
DEBUG - 2016-02-25 10:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 10:17:17 --> Input Class Initialized
INFO - 2016-02-25 10:17:17 --> Language Class Initialized
INFO - 2016-02-25 10:17:17 --> Loader Class Initialized
INFO - 2016-02-25 10:17:17 --> Helper loaded: url_helper
INFO - 2016-02-25 10:17:17 --> Helper loaded: file_helper
INFO - 2016-02-25 10:17:17 --> Helper loaded: date_helper
INFO - 2016-02-25 10:17:17 --> Helper loaded: form_helper
INFO - 2016-02-25 10:17:17 --> Database Driver Class Initialized
INFO - 2016-02-25 10:17:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 10:17:18 --> Controller Class Initialized
INFO - 2016-02-25 10:17:18 --> Model Class Initialized
INFO - 2016-02-25 10:17:18 --> Model Class Initialized
INFO - 2016-02-25 10:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 10:17:18 --> Pagination Class Initialized
INFO - 2016-02-25 10:17:18 --> Helper loaded: text_helper
INFO - 2016-02-25 10:17:18 --> Helper loaded: cookie_helper
INFO - 2016-02-25 13:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 13:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 13:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 13:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-25 13:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 13:17:18 --> Final output sent to browser
DEBUG - 2016-02-25 13:17:18 --> Total execution time: 1.2837
INFO - 2016-02-25 11:28:42 --> Config Class Initialized
INFO - 2016-02-25 11:28:42 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:28:42 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:28:42 --> Utf8 Class Initialized
INFO - 2016-02-25 11:28:42 --> URI Class Initialized
INFO - 2016-02-25 11:28:43 --> Router Class Initialized
INFO - 2016-02-25 11:28:43 --> Output Class Initialized
INFO - 2016-02-25 11:28:43 --> Security Class Initialized
DEBUG - 2016-02-25 11:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:28:43 --> Input Class Initialized
INFO - 2016-02-25 11:28:43 --> Language Class Initialized
INFO - 2016-02-25 11:28:43 --> Loader Class Initialized
INFO - 2016-02-25 11:28:43 --> Helper loaded: url_helper
INFO - 2016-02-25 11:28:43 --> Helper loaded: file_helper
INFO - 2016-02-25 11:28:43 --> Helper loaded: date_helper
INFO - 2016-02-25 11:28:43 --> Helper loaded: form_helper
INFO - 2016-02-25 11:28:43 --> Database Driver Class Initialized
INFO - 2016-02-25 11:28:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:28:44 --> Controller Class Initialized
INFO - 2016-02-25 11:28:44 --> Model Class Initialized
INFO - 2016-02-25 11:28:44 --> Model Class Initialized
INFO - 2016-02-25 11:28:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:28:44 --> Pagination Class Initialized
INFO - 2016-02-25 11:28:44 --> Helper loaded: text_helper
INFO - 2016-02-25 11:28:44 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 14:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 14:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 14:28:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 14:28:44 --> Final output sent to browser
DEBUG - 2016-02-25 14:28:44 --> Total execution time: 1.7013
INFO - 2016-02-25 11:28:47 --> Config Class Initialized
INFO - 2016-02-25 11:28:47 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:28:47 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:28:47 --> Utf8 Class Initialized
INFO - 2016-02-25 11:28:47 --> URI Class Initialized
INFO - 2016-02-25 11:28:47 --> Router Class Initialized
INFO - 2016-02-25 11:28:47 --> Output Class Initialized
INFO - 2016-02-25 11:28:47 --> Security Class Initialized
DEBUG - 2016-02-25 11:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:28:47 --> Input Class Initialized
INFO - 2016-02-25 11:28:47 --> Language Class Initialized
INFO - 2016-02-25 11:28:47 --> Loader Class Initialized
INFO - 2016-02-25 11:28:47 --> Helper loaded: url_helper
INFO - 2016-02-25 11:28:47 --> Helper loaded: file_helper
INFO - 2016-02-25 11:28:47 --> Helper loaded: date_helper
INFO - 2016-02-25 11:28:47 --> Helper loaded: form_helper
INFO - 2016-02-25 11:28:47 --> Database Driver Class Initialized
INFO - 2016-02-25 11:28:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:28:48 --> Controller Class Initialized
INFO - 2016-02-25 11:28:48 --> Model Class Initialized
INFO - 2016-02-25 11:28:48 --> Model Class Initialized
INFO - 2016-02-25 11:28:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:28:48 --> Pagination Class Initialized
INFO - 2016-02-25 11:28:48 --> Helper loaded: text_helper
INFO - 2016-02-25 11:28:48 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:28:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 14:28:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 14:28:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 14:28:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 14:28:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 14:28:48 --> Final output sent to browser
DEBUG - 2016-02-25 14:28:48 --> Total execution time: 1.1847
INFO - 2016-02-25 11:29:22 --> Config Class Initialized
INFO - 2016-02-25 11:29:22 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:29:22 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:29:22 --> Utf8 Class Initialized
INFO - 2016-02-25 11:29:22 --> URI Class Initialized
INFO - 2016-02-25 11:29:22 --> Router Class Initialized
INFO - 2016-02-25 11:29:22 --> Output Class Initialized
INFO - 2016-02-25 11:29:22 --> Security Class Initialized
DEBUG - 2016-02-25 11:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:29:22 --> Input Class Initialized
INFO - 2016-02-25 11:29:22 --> Language Class Initialized
INFO - 2016-02-25 11:29:22 --> Loader Class Initialized
INFO - 2016-02-25 11:29:22 --> Helper loaded: url_helper
INFO - 2016-02-25 11:29:22 --> Helper loaded: file_helper
INFO - 2016-02-25 11:29:22 --> Helper loaded: date_helper
INFO - 2016-02-25 11:29:22 --> Helper loaded: form_helper
INFO - 2016-02-25 11:29:22 --> Database Driver Class Initialized
INFO - 2016-02-25 11:29:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:29:23 --> Controller Class Initialized
INFO - 2016-02-25 11:29:23 --> Model Class Initialized
INFO - 2016-02-25 11:29:23 --> Model Class Initialized
INFO - 2016-02-25 11:29:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:29:23 --> Pagination Class Initialized
INFO - 2016-02-25 11:29:23 --> Helper loaded: text_helper
INFO - 2016-02-25 11:29:23 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 14:29:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 14:29:23 --> Final output sent to browser
DEBUG - 2016-02-25 14:29:23 --> Total execution time: 1.1481
INFO - 2016-02-25 11:32:09 --> Config Class Initialized
INFO - 2016-02-25 11:32:09 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:32:09 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:32:09 --> Utf8 Class Initialized
INFO - 2016-02-25 11:32:09 --> URI Class Initialized
INFO - 2016-02-25 11:32:09 --> Router Class Initialized
INFO - 2016-02-25 11:32:09 --> Output Class Initialized
INFO - 2016-02-25 11:32:09 --> Security Class Initialized
DEBUG - 2016-02-25 11:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:32:09 --> Input Class Initialized
INFO - 2016-02-25 11:32:09 --> Language Class Initialized
INFO - 2016-02-25 11:32:09 --> Loader Class Initialized
INFO - 2016-02-25 11:32:09 --> Helper loaded: url_helper
INFO - 2016-02-25 11:32:09 --> Helper loaded: file_helper
INFO - 2016-02-25 11:32:09 --> Helper loaded: date_helper
INFO - 2016-02-25 11:32:09 --> Helper loaded: form_helper
INFO - 2016-02-25 11:32:09 --> Database Driver Class Initialized
INFO - 2016-02-25 11:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:32:10 --> Controller Class Initialized
INFO - 2016-02-25 11:32:10 --> Model Class Initialized
INFO - 2016-02-25 11:32:10 --> Model Class Initialized
INFO - 2016-02-25 11:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:32:10 --> Pagination Class Initialized
INFO - 2016-02-25 11:32:10 --> Helper loaded: text_helper
INFO - 2016-02-25 11:32:10 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:32:10 --> Upload Class Initialized
ERROR - 2016-02-25 14:32:10 --> Severity: Notice --> Undefined property: Jboard::$image_lib C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 461
ERROR - 2016-02-25 14:32:10 --> Severity: Error --> Call to a member function initialize() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 461
INFO - 2016-02-25 11:33:04 --> Config Class Initialized
INFO - 2016-02-25 11:33:04 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:33:04 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:33:04 --> Utf8 Class Initialized
INFO - 2016-02-25 11:33:04 --> URI Class Initialized
INFO - 2016-02-25 11:33:04 --> Router Class Initialized
INFO - 2016-02-25 11:33:04 --> Output Class Initialized
INFO - 2016-02-25 11:33:04 --> Security Class Initialized
DEBUG - 2016-02-25 11:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:33:04 --> Input Class Initialized
INFO - 2016-02-25 11:33:04 --> Language Class Initialized
INFO - 2016-02-25 11:33:04 --> Loader Class Initialized
INFO - 2016-02-25 11:33:04 --> Helper loaded: url_helper
INFO - 2016-02-25 11:33:04 --> Helper loaded: file_helper
INFO - 2016-02-25 11:33:04 --> Helper loaded: date_helper
INFO - 2016-02-25 11:33:04 --> Helper loaded: form_helper
INFO - 2016-02-25 11:33:04 --> Database Driver Class Initialized
INFO - 2016-02-25 11:33:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:33:05 --> Controller Class Initialized
INFO - 2016-02-25 11:33:05 --> Model Class Initialized
INFO - 2016-02-25 11:33:05 --> Model Class Initialized
INFO - 2016-02-25 11:33:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:33:05 --> Pagination Class Initialized
INFO - 2016-02-25 11:33:05 --> Helper loaded: text_helper
INFO - 2016-02-25 11:33:05 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 14:33:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 14:33:05 --> Final output sent to browser
DEBUG - 2016-02-25 14:33:05 --> Total execution time: 1.1137
INFO - 2016-02-25 11:33:12 --> Config Class Initialized
INFO - 2016-02-25 11:33:12 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:33:12 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:33:12 --> Utf8 Class Initialized
INFO - 2016-02-25 11:33:12 --> URI Class Initialized
INFO - 2016-02-25 11:33:12 --> Router Class Initialized
INFO - 2016-02-25 11:33:12 --> Output Class Initialized
INFO - 2016-02-25 11:33:12 --> Security Class Initialized
DEBUG - 2016-02-25 11:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:33:12 --> Input Class Initialized
INFO - 2016-02-25 11:33:12 --> Language Class Initialized
ERROR - 2016-02-25 11:33:12 --> Severity: Parsing Error --> syntax error, unexpected '$config' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 448
INFO - 2016-02-25 11:33:47 --> Config Class Initialized
INFO - 2016-02-25 11:33:47 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:33:47 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:33:47 --> Utf8 Class Initialized
INFO - 2016-02-25 11:33:47 --> URI Class Initialized
INFO - 2016-02-25 11:33:47 --> Router Class Initialized
INFO - 2016-02-25 11:33:47 --> Output Class Initialized
INFO - 2016-02-25 11:33:47 --> Security Class Initialized
DEBUG - 2016-02-25 11:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:33:47 --> Input Class Initialized
INFO - 2016-02-25 11:33:47 --> Language Class Initialized
INFO - 2016-02-25 11:33:47 --> Loader Class Initialized
INFO - 2016-02-25 11:33:47 --> Helper loaded: url_helper
INFO - 2016-02-25 11:33:47 --> Helper loaded: file_helper
INFO - 2016-02-25 11:33:47 --> Helper loaded: date_helper
INFO - 2016-02-25 11:33:47 --> Helper loaded: form_helper
INFO - 2016-02-25 11:33:47 --> Database Driver Class Initialized
INFO - 2016-02-25 11:33:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:33:48 --> Controller Class Initialized
INFO - 2016-02-25 11:33:48 --> Model Class Initialized
INFO - 2016-02-25 11:33:48 --> Model Class Initialized
INFO - 2016-02-25 11:33:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:33:48 --> Pagination Class Initialized
INFO - 2016-02-25 11:33:48 --> Helper loaded: text_helper
INFO - 2016-02-25 11:33:48 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:33:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 14:33:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 14:33:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 14:33:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 14:33:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 14:33:48 --> Final output sent to browser
DEBUG - 2016-02-25 14:33:48 --> Total execution time: 1.1869
INFO - 2016-02-25 11:33:57 --> Config Class Initialized
INFO - 2016-02-25 11:33:57 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:33:57 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:33:57 --> Utf8 Class Initialized
INFO - 2016-02-25 11:33:57 --> URI Class Initialized
INFO - 2016-02-25 11:33:57 --> Router Class Initialized
INFO - 2016-02-25 11:33:57 --> Output Class Initialized
INFO - 2016-02-25 11:33:57 --> Security Class Initialized
DEBUG - 2016-02-25 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:33:57 --> Input Class Initialized
INFO - 2016-02-25 11:33:57 --> Language Class Initialized
INFO - 2016-02-25 11:33:57 --> Loader Class Initialized
INFO - 2016-02-25 11:33:57 --> Helper loaded: url_helper
INFO - 2016-02-25 11:33:57 --> Helper loaded: file_helper
INFO - 2016-02-25 11:33:57 --> Helper loaded: date_helper
INFO - 2016-02-25 11:33:57 --> Helper loaded: form_helper
INFO - 2016-02-25 11:33:57 --> Database Driver Class Initialized
INFO - 2016-02-25 11:33:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:33:58 --> Controller Class Initialized
INFO - 2016-02-25 11:33:58 --> Model Class Initialized
INFO - 2016-02-25 11:33:58 --> Model Class Initialized
INFO - 2016-02-25 11:33:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:33:58 --> Pagination Class Initialized
INFO - 2016-02-25 11:33:58 --> Helper loaded: text_helper
INFO - 2016-02-25 11:33:58 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:33:58 --> Upload Class Initialized
INFO - 2016-02-25 14:33:58 --> Image Lib Class Initialized
DEBUG - 2016-02-25 14:33:58 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 14:33:58 --> Final output sent to browser
DEBUG - 2016-02-25 14:33:58 --> Total execution time: 1.4659
INFO - 2016-02-25 11:34:19 --> Config Class Initialized
INFO - 2016-02-25 11:34:19 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:34:19 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:34:19 --> Utf8 Class Initialized
INFO - 2016-02-25 11:34:19 --> URI Class Initialized
INFO - 2016-02-25 11:34:19 --> Router Class Initialized
INFO - 2016-02-25 11:34:19 --> Output Class Initialized
INFO - 2016-02-25 11:34:19 --> Security Class Initialized
DEBUG - 2016-02-25 11:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:34:19 --> Input Class Initialized
INFO - 2016-02-25 11:34:19 --> Language Class Initialized
INFO - 2016-02-25 11:34:19 --> Loader Class Initialized
INFO - 2016-02-25 11:34:19 --> Helper loaded: url_helper
INFO - 2016-02-25 11:34:19 --> Helper loaded: file_helper
INFO - 2016-02-25 11:34:19 --> Helper loaded: date_helper
INFO - 2016-02-25 11:34:19 --> Helper loaded: form_helper
INFO - 2016-02-25 11:34:19 --> Database Driver Class Initialized
INFO - 2016-02-25 11:34:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:34:20 --> Controller Class Initialized
INFO - 2016-02-25 11:34:20 --> Model Class Initialized
INFO - 2016-02-25 11:34:20 --> Model Class Initialized
INFO - 2016-02-25 11:34:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:34:20 --> Pagination Class Initialized
INFO - 2016-02-25 11:34:20 --> Helper loaded: text_helper
INFO - 2016-02-25 11:34:20 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:34:20 --> Upload Class Initialized
ERROR - 2016-02-25 14:34:20 --> Severity: Notice --> Undefined property: Jboard::$image_lib C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 461
ERROR - 2016-02-25 14:34:20 --> Severity: Error --> Call to a member function initialize() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 461
INFO - 2016-02-25 11:34:34 --> Config Class Initialized
INFO - 2016-02-25 11:34:34 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:34:34 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:34:34 --> Utf8 Class Initialized
INFO - 2016-02-25 11:34:34 --> URI Class Initialized
INFO - 2016-02-25 11:34:34 --> Router Class Initialized
INFO - 2016-02-25 11:34:34 --> Output Class Initialized
INFO - 2016-02-25 11:34:34 --> Security Class Initialized
DEBUG - 2016-02-25 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:34:34 --> Input Class Initialized
INFO - 2016-02-25 11:34:34 --> Language Class Initialized
INFO - 2016-02-25 11:34:34 --> Loader Class Initialized
INFO - 2016-02-25 11:34:34 --> Helper loaded: url_helper
INFO - 2016-02-25 11:34:34 --> Helper loaded: file_helper
INFO - 2016-02-25 11:34:34 --> Helper loaded: date_helper
INFO - 2016-02-25 11:34:34 --> Helper loaded: form_helper
INFO - 2016-02-25 11:34:34 --> Database Driver Class Initialized
INFO - 2016-02-25 11:34:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:34:35 --> Controller Class Initialized
INFO - 2016-02-25 11:34:35 --> Model Class Initialized
INFO - 2016-02-25 11:34:35 --> Model Class Initialized
INFO - 2016-02-25 11:34:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:34:35 --> Pagination Class Initialized
INFO - 2016-02-25 11:34:35 --> Helper loaded: text_helper
INFO - 2016-02-25 11:34:35 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:34:35 --> Upload Class Initialized
INFO - 2016-02-25 14:34:35 --> Image Lib Class Initialized
INFO - 2016-02-25 14:34:35 --> Final output sent to browser
DEBUG - 2016-02-25 14:34:35 --> Total execution time: 1.2405
INFO - 2016-02-25 11:35:06 --> Config Class Initialized
INFO - 2016-02-25 11:35:06 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:35:06 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:35:06 --> Utf8 Class Initialized
INFO - 2016-02-25 11:35:06 --> URI Class Initialized
INFO - 2016-02-25 11:35:06 --> Router Class Initialized
INFO - 2016-02-25 11:35:06 --> Output Class Initialized
INFO - 2016-02-25 11:35:06 --> Security Class Initialized
DEBUG - 2016-02-25 11:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:35:06 --> Input Class Initialized
INFO - 2016-02-25 11:35:06 --> Language Class Initialized
INFO - 2016-02-25 11:35:06 --> Loader Class Initialized
INFO - 2016-02-25 11:35:06 --> Helper loaded: url_helper
INFO - 2016-02-25 11:35:06 --> Helper loaded: file_helper
INFO - 2016-02-25 11:35:06 --> Helper loaded: date_helper
INFO - 2016-02-25 11:35:06 --> Helper loaded: form_helper
INFO - 2016-02-25 11:35:06 --> Database Driver Class Initialized
INFO - 2016-02-25 11:35:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:35:07 --> Controller Class Initialized
INFO - 2016-02-25 11:35:07 --> Model Class Initialized
INFO - 2016-02-25 11:35:07 --> Model Class Initialized
INFO - 2016-02-25 11:35:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:35:07 --> Pagination Class Initialized
INFO - 2016-02-25 11:35:07 --> Helper loaded: text_helper
INFO - 2016-02-25 11:35:07 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:35:07 --> Upload Class Initialized
INFO - 2016-02-25 14:35:07 --> Image Lib Class Initialized
INFO - 2016-02-25 14:35:07 --> Final output sent to browser
DEBUG - 2016-02-25 14:35:07 --> Total execution time: 1.1556
INFO - 2016-02-25 11:37:15 --> Config Class Initialized
INFO - 2016-02-25 11:37:15 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:37:15 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:37:15 --> Utf8 Class Initialized
INFO - 2016-02-25 11:37:15 --> URI Class Initialized
INFO - 2016-02-25 11:37:15 --> Router Class Initialized
INFO - 2016-02-25 11:37:15 --> Output Class Initialized
INFO - 2016-02-25 11:37:15 --> Security Class Initialized
DEBUG - 2016-02-25 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:37:15 --> Input Class Initialized
INFO - 2016-02-25 11:37:15 --> Language Class Initialized
INFO - 2016-02-25 11:37:15 --> Loader Class Initialized
INFO - 2016-02-25 11:37:15 --> Helper loaded: url_helper
INFO - 2016-02-25 11:37:15 --> Helper loaded: file_helper
INFO - 2016-02-25 11:37:15 --> Helper loaded: date_helper
INFO - 2016-02-25 11:37:15 --> Helper loaded: form_helper
INFO - 2016-02-25 11:37:15 --> Database Driver Class Initialized
INFO - 2016-02-25 11:37:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:37:16 --> Controller Class Initialized
INFO - 2016-02-25 11:37:16 --> Model Class Initialized
INFO - 2016-02-25 11:37:16 --> Model Class Initialized
INFO - 2016-02-25 11:37:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:37:17 --> Pagination Class Initialized
INFO - 2016-02-25 11:37:17 --> Helper loaded: text_helper
INFO - 2016-02-25 11:37:17 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:37:17 --> Upload Class Initialized
INFO - 2016-02-25 14:37:17 --> Image Lib Class Initialized
INFO - 2016-02-25 14:37:17 --> Final output sent to browser
DEBUG - 2016-02-25 14:37:17 --> Total execution time: 1.2406
INFO - 2016-02-25 11:41:07 --> Config Class Initialized
INFO - 2016-02-25 11:41:07 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:41:07 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:41:07 --> Utf8 Class Initialized
INFO - 2016-02-25 11:41:07 --> URI Class Initialized
INFO - 2016-02-25 11:41:07 --> Router Class Initialized
INFO - 2016-02-25 11:41:07 --> Output Class Initialized
INFO - 2016-02-25 11:41:07 --> Security Class Initialized
DEBUG - 2016-02-25 11:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:41:07 --> Input Class Initialized
INFO - 2016-02-25 11:41:07 --> Language Class Initialized
INFO - 2016-02-25 11:41:07 --> Loader Class Initialized
INFO - 2016-02-25 11:41:07 --> Helper loaded: url_helper
INFO - 2016-02-25 11:41:07 --> Helper loaded: file_helper
INFO - 2016-02-25 11:41:07 --> Helper loaded: date_helper
INFO - 2016-02-25 11:41:07 --> Helper loaded: form_helper
INFO - 2016-02-25 11:41:07 --> Database Driver Class Initialized
INFO - 2016-02-25 11:41:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:41:08 --> Controller Class Initialized
INFO - 2016-02-25 11:41:08 --> Model Class Initialized
INFO - 2016-02-25 11:41:08 --> Model Class Initialized
INFO - 2016-02-25 11:41:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:41:08 --> Pagination Class Initialized
INFO - 2016-02-25 11:41:08 --> Helper loaded: text_helper
INFO - 2016-02-25 11:41:08 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:41:08 --> Upload Class Initialized
INFO - 2016-02-25 14:41:08 --> Image Lib Class Initialized
INFO - 2016-02-25 14:41:08 --> Final output sent to browser
DEBUG - 2016-02-25 14:41:08 --> Total execution time: 1.2026
INFO - 2016-02-25 11:41:32 --> Config Class Initialized
INFO - 2016-02-25 11:41:32 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:41:32 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:41:32 --> Utf8 Class Initialized
INFO - 2016-02-25 11:41:32 --> URI Class Initialized
INFO - 2016-02-25 11:41:32 --> Router Class Initialized
INFO - 2016-02-25 11:41:32 --> Output Class Initialized
INFO - 2016-02-25 11:41:32 --> Security Class Initialized
DEBUG - 2016-02-25 11:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:41:32 --> Input Class Initialized
INFO - 2016-02-25 11:41:32 --> Language Class Initialized
INFO - 2016-02-25 11:41:32 --> Loader Class Initialized
INFO - 2016-02-25 11:41:32 --> Helper loaded: url_helper
INFO - 2016-02-25 11:41:32 --> Helper loaded: file_helper
INFO - 2016-02-25 11:41:32 --> Helper loaded: date_helper
INFO - 2016-02-25 11:41:32 --> Helper loaded: form_helper
INFO - 2016-02-25 11:41:32 --> Database Driver Class Initialized
INFO - 2016-02-25 11:41:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:41:33 --> Controller Class Initialized
INFO - 2016-02-25 11:41:33 --> Model Class Initialized
INFO - 2016-02-25 11:41:33 --> Model Class Initialized
INFO - 2016-02-25 11:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:41:33 --> Pagination Class Initialized
INFO - 2016-02-25 11:41:33 --> Helper loaded: text_helper
INFO - 2016-02-25 11:41:33 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:41:33 --> Upload Class Initialized
INFO - 2016-02-25 14:41:33 --> Image Lib Class Initialized
INFO - 2016-02-25 14:41:33 --> Final output sent to browser
DEBUG - 2016-02-25 14:41:33 --> Total execution time: 1.1547
INFO - 2016-02-25 11:44:18 --> Config Class Initialized
INFO - 2016-02-25 11:44:18 --> Hooks Class Initialized
DEBUG - 2016-02-25 11:44:18 --> UTF-8 Support Enabled
INFO - 2016-02-25 11:44:18 --> Utf8 Class Initialized
INFO - 2016-02-25 11:44:18 --> URI Class Initialized
INFO - 2016-02-25 11:44:18 --> Router Class Initialized
INFO - 2016-02-25 11:44:18 --> Output Class Initialized
INFO - 2016-02-25 11:44:18 --> Security Class Initialized
DEBUG - 2016-02-25 11:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 11:44:18 --> Input Class Initialized
INFO - 2016-02-25 11:44:18 --> Language Class Initialized
INFO - 2016-02-25 11:44:18 --> Loader Class Initialized
INFO - 2016-02-25 11:44:18 --> Helper loaded: url_helper
INFO - 2016-02-25 11:44:18 --> Helper loaded: file_helper
INFO - 2016-02-25 11:44:18 --> Helper loaded: date_helper
INFO - 2016-02-25 11:44:18 --> Helper loaded: form_helper
INFO - 2016-02-25 11:44:18 --> Database Driver Class Initialized
INFO - 2016-02-25 11:44:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 11:44:19 --> Controller Class Initialized
INFO - 2016-02-25 11:44:19 --> Model Class Initialized
INFO - 2016-02-25 11:44:19 --> Model Class Initialized
INFO - 2016-02-25 11:44:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 11:44:19 --> Pagination Class Initialized
INFO - 2016-02-25 11:44:19 --> Helper loaded: text_helper
INFO - 2016-02-25 11:44:19 --> Helper loaded: cookie_helper
INFO - 2016-02-25 14:44:19 --> Upload Class Initialized
INFO - 2016-02-25 14:44:19 --> Image Lib Class Initialized
INFO - 2016-02-25 14:44:19 --> Final output sent to browser
DEBUG - 2016-02-25 14:44:19 --> Total execution time: 1.2785
INFO - 2016-02-25 12:15:07 --> Config Class Initialized
INFO - 2016-02-25 12:15:07 --> Hooks Class Initialized
DEBUG - 2016-02-25 12:15:07 --> UTF-8 Support Enabled
INFO - 2016-02-25 12:15:07 --> Utf8 Class Initialized
INFO - 2016-02-25 12:15:07 --> URI Class Initialized
INFO - 2016-02-25 12:15:07 --> Router Class Initialized
INFO - 2016-02-25 12:15:07 --> Output Class Initialized
INFO - 2016-02-25 12:15:07 --> Security Class Initialized
DEBUG - 2016-02-25 12:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 12:15:07 --> Input Class Initialized
INFO - 2016-02-25 12:15:07 --> Language Class Initialized
INFO - 2016-02-25 12:15:07 --> Loader Class Initialized
INFO - 2016-02-25 12:15:07 --> Helper loaded: url_helper
INFO - 2016-02-25 12:15:07 --> Helper loaded: file_helper
INFO - 2016-02-25 12:15:07 --> Helper loaded: date_helper
INFO - 2016-02-25 12:15:07 --> Helper loaded: form_helper
INFO - 2016-02-25 12:15:07 --> Database Driver Class Initialized
INFO - 2016-02-25 12:15:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 12:15:08 --> Controller Class Initialized
INFO - 2016-02-25 12:15:08 --> Model Class Initialized
INFO - 2016-02-25 12:15:08 --> Model Class Initialized
INFO - 2016-02-25 12:15:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 12:15:08 --> Pagination Class Initialized
INFO - 2016-02-25 12:15:08 --> Helper loaded: text_helper
INFO - 2016-02-25 12:15:08 --> Helper loaded: cookie_helper
INFO - 2016-02-25 15:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 15:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 15:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 15:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 15:15:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 15:15:08 --> Final output sent to browser
DEBUG - 2016-02-25 15:15:08 --> Total execution time: 1.1090
INFO - 2016-02-25 12:15:16 --> Config Class Initialized
INFO - 2016-02-25 12:15:16 --> Hooks Class Initialized
DEBUG - 2016-02-25 12:15:16 --> UTF-8 Support Enabled
INFO - 2016-02-25 12:15:16 --> Utf8 Class Initialized
INFO - 2016-02-25 12:15:16 --> URI Class Initialized
INFO - 2016-02-25 12:15:16 --> Router Class Initialized
INFO - 2016-02-25 12:15:16 --> Output Class Initialized
INFO - 2016-02-25 12:15:16 --> Security Class Initialized
DEBUG - 2016-02-25 12:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 12:15:16 --> Input Class Initialized
INFO - 2016-02-25 12:15:16 --> Language Class Initialized
INFO - 2016-02-25 12:15:16 --> Loader Class Initialized
INFO - 2016-02-25 12:15:16 --> Helper loaded: url_helper
INFO - 2016-02-25 12:15:16 --> Helper loaded: file_helper
INFO - 2016-02-25 12:15:16 --> Helper loaded: date_helper
INFO - 2016-02-25 12:15:16 --> Helper loaded: form_helper
INFO - 2016-02-25 12:15:16 --> Database Driver Class Initialized
INFO - 2016-02-25 12:15:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 12:15:17 --> Controller Class Initialized
INFO - 2016-02-25 12:15:17 --> Model Class Initialized
INFO - 2016-02-25 12:15:17 --> Model Class Initialized
INFO - 2016-02-25 12:15:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 12:15:17 --> Pagination Class Initialized
INFO - 2016-02-25 12:15:17 --> Helper loaded: text_helper
INFO - 2016-02-25 12:15:17 --> Helper loaded: cookie_helper
INFO - 2016-02-25 15:15:17 --> Upload Class Initialized
ERROR - 2016-02-25 15:15:17 --> Severity: Notice --> Undefined property: Jboard::$image_lib C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 461
ERROR - 2016-02-25 15:15:17 --> Severity: Error --> Call to a member function initialize() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 461
INFO - 2016-02-25 12:15:44 --> Config Class Initialized
INFO - 2016-02-25 12:15:44 --> Hooks Class Initialized
DEBUG - 2016-02-25 12:15:44 --> UTF-8 Support Enabled
INFO - 2016-02-25 12:15:44 --> Utf8 Class Initialized
INFO - 2016-02-25 12:15:44 --> URI Class Initialized
INFO - 2016-02-25 12:15:44 --> Router Class Initialized
INFO - 2016-02-25 12:15:44 --> Output Class Initialized
INFO - 2016-02-25 12:15:44 --> Security Class Initialized
DEBUG - 2016-02-25 12:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 12:15:44 --> Input Class Initialized
INFO - 2016-02-25 12:15:44 --> Language Class Initialized
INFO - 2016-02-25 12:15:44 --> Loader Class Initialized
INFO - 2016-02-25 12:15:44 --> Helper loaded: url_helper
INFO - 2016-02-25 12:15:44 --> Helper loaded: file_helper
INFO - 2016-02-25 12:15:44 --> Helper loaded: date_helper
INFO - 2016-02-25 12:15:44 --> Helper loaded: form_helper
INFO - 2016-02-25 12:15:44 --> Database Driver Class Initialized
INFO - 2016-02-25 12:15:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 12:15:45 --> Controller Class Initialized
INFO - 2016-02-25 12:15:45 --> Model Class Initialized
INFO - 2016-02-25 12:15:45 --> Model Class Initialized
INFO - 2016-02-25 12:15:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 12:15:45 --> Pagination Class Initialized
INFO - 2016-02-25 12:15:45 --> Helper loaded: text_helper
INFO - 2016-02-25 12:15:45 --> Helper loaded: cookie_helper
INFO - 2016-02-25 15:15:45 --> Upload Class Initialized
INFO - 2016-02-25 15:15:45 --> Image Lib Class Initialized
DEBUG - 2016-02-25 15:15:45 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 15:15:45 --> Final output sent to browser
DEBUG - 2016-02-25 15:15:45 --> Total execution time: 1.1794
INFO - 2016-02-25 12:36:56 --> Config Class Initialized
INFO - 2016-02-25 12:36:56 --> Hooks Class Initialized
DEBUG - 2016-02-25 12:36:56 --> UTF-8 Support Enabled
INFO - 2016-02-25 12:36:56 --> Utf8 Class Initialized
INFO - 2016-02-25 12:36:56 --> URI Class Initialized
INFO - 2016-02-25 12:36:56 --> Router Class Initialized
INFO - 2016-02-25 12:36:56 --> Output Class Initialized
INFO - 2016-02-25 12:36:56 --> Security Class Initialized
DEBUG - 2016-02-25 12:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 12:36:56 --> Input Class Initialized
INFO - 2016-02-25 12:36:56 --> Language Class Initialized
INFO - 2016-02-25 12:36:56 --> Loader Class Initialized
INFO - 2016-02-25 12:36:56 --> Helper loaded: url_helper
INFO - 2016-02-25 12:36:56 --> Helper loaded: file_helper
INFO - 2016-02-25 12:36:56 --> Helper loaded: date_helper
INFO - 2016-02-25 12:36:56 --> Helper loaded: form_helper
INFO - 2016-02-25 12:36:56 --> Database Driver Class Initialized
INFO - 2016-02-25 12:36:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 12:36:57 --> Controller Class Initialized
INFO - 2016-02-25 12:36:57 --> Model Class Initialized
INFO - 2016-02-25 12:36:57 --> Model Class Initialized
INFO - 2016-02-25 12:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 12:36:57 --> Pagination Class Initialized
INFO - 2016-02-25 12:36:57 --> Helper loaded: text_helper
INFO - 2016-02-25 12:36:57 --> Helper loaded: cookie_helper
INFO - 2016-02-25 15:36:57 --> Upload Class Initialized
INFO - 2016-02-25 15:36:57 --> Image Lib Class Initialized
DEBUG - 2016-02-25 15:36:57 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 15:36:57 --> Final output sent to browser
DEBUG - 2016-02-25 15:36:57 --> Total execution time: 1.1449
INFO - 2016-02-25 12:49:54 --> Config Class Initialized
INFO - 2016-02-25 12:49:54 --> Hooks Class Initialized
DEBUG - 2016-02-25 12:49:54 --> UTF-8 Support Enabled
INFO - 2016-02-25 12:49:54 --> Utf8 Class Initialized
INFO - 2016-02-25 12:49:54 --> URI Class Initialized
INFO - 2016-02-25 12:49:54 --> Router Class Initialized
INFO - 2016-02-25 12:49:54 --> Output Class Initialized
INFO - 2016-02-25 12:49:54 --> Security Class Initialized
DEBUG - 2016-02-25 12:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 12:49:54 --> Input Class Initialized
INFO - 2016-02-25 12:49:54 --> Language Class Initialized
INFO - 2016-02-25 12:49:54 --> Loader Class Initialized
INFO - 2016-02-25 12:49:54 --> Helper loaded: url_helper
INFO - 2016-02-25 12:49:54 --> Helper loaded: file_helper
INFO - 2016-02-25 12:49:54 --> Helper loaded: date_helper
INFO - 2016-02-25 12:49:54 --> Helper loaded: form_helper
INFO - 2016-02-25 12:49:54 --> Database Driver Class Initialized
INFO - 2016-02-25 12:49:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 12:49:55 --> Controller Class Initialized
INFO - 2016-02-25 12:49:55 --> Model Class Initialized
INFO - 2016-02-25 12:49:55 --> Model Class Initialized
INFO - 2016-02-25 12:49:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 12:49:55 --> Pagination Class Initialized
INFO - 2016-02-25 12:49:55 --> Helper loaded: text_helper
INFO - 2016-02-25 12:49:55 --> Helper loaded: cookie_helper
INFO - 2016-02-25 15:49:55 --> Upload Class Initialized
INFO - 2016-02-25 15:49:55 --> Image Lib Class Initialized
DEBUG - 2016-02-25 15:49:55 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 15:49:55 --> Final output sent to browser
DEBUG - 2016-02-25 15:49:55 --> Total execution time: 1.1652
INFO - 2016-02-25 13:23:31 --> Config Class Initialized
INFO - 2016-02-25 13:23:31 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:23:31 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:23:31 --> Utf8 Class Initialized
INFO - 2016-02-25 13:23:31 --> URI Class Initialized
INFO - 2016-02-25 13:23:31 --> Router Class Initialized
INFO - 2016-02-25 13:23:31 --> Output Class Initialized
INFO - 2016-02-25 13:23:31 --> Security Class Initialized
DEBUG - 2016-02-25 13:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:23:31 --> Input Class Initialized
INFO - 2016-02-25 13:23:31 --> Language Class Initialized
INFO - 2016-02-25 13:23:31 --> Loader Class Initialized
INFO - 2016-02-25 13:23:31 --> Helper loaded: url_helper
INFO - 2016-02-25 13:23:31 --> Helper loaded: file_helper
INFO - 2016-02-25 13:23:31 --> Helper loaded: date_helper
INFO - 2016-02-25 13:23:31 --> Helper loaded: form_helper
INFO - 2016-02-25 13:23:31 --> Database Driver Class Initialized
INFO - 2016-02-25 13:23:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:23:32 --> Controller Class Initialized
INFO - 2016-02-25 13:23:32 --> Model Class Initialized
INFO - 2016-02-25 13:23:32 --> Model Class Initialized
INFO - 2016-02-25 13:23:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:23:32 --> Pagination Class Initialized
INFO - 2016-02-25 13:23:32 --> Helper loaded: text_helper
INFO - 2016-02-25 13:23:32 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:23:32 --> Upload Class Initialized
INFO - 2016-02-25 16:23:32 --> Image Lib Class Initialized
DEBUG - 2016-02-25 16:23:32 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-02-25 16:23:32 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 435
INFO - 2016-02-25 16:23:32 --> Final output sent to browser
DEBUG - 2016-02-25 16:23:32 --> Total execution time: 1.2385
INFO - 2016-02-25 13:41:48 --> Config Class Initialized
INFO - 2016-02-25 13:41:48 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:41:48 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:41:48 --> Utf8 Class Initialized
INFO - 2016-02-25 13:41:48 --> URI Class Initialized
INFO - 2016-02-25 13:41:48 --> Router Class Initialized
INFO - 2016-02-25 13:41:48 --> Output Class Initialized
INFO - 2016-02-25 13:41:48 --> Security Class Initialized
DEBUG - 2016-02-25 13:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:41:48 --> Input Class Initialized
INFO - 2016-02-25 13:41:48 --> Language Class Initialized
INFO - 2016-02-25 13:41:48 --> Loader Class Initialized
INFO - 2016-02-25 13:41:48 --> Helper loaded: url_helper
INFO - 2016-02-25 13:41:48 --> Helper loaded: file_helper
INFO - 2016-02-25 13:41:48 --> Helper loaded: date_helper
INFO - 2016-02-25 13:41:48 --> Helper loaded: form_helper
INFO - 2016-02-25 13:41:48 --> Database Driver Class Initialized
INFO - 2016-02-25 13:41:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:41:49 --> Controller Class Initialized
INFO - 2016-02-25 13:41:49 --> Model Class Initialized
INFO - 2016-02-25 13:41:49 --> Model Class Initialized
INFO - 2016-02-25 13:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:41:49 --> Pagination Class Initialized
INFO - 2016-02-25 13:41:49 --> Helper loaded: text_helper
INFO - 2016-02-25 13:41:49 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 16:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 16:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 16:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 16:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 16:41:49 --> Final output sent to browser
DEBUG - 2016-02-25 16:41:49 --> Total execution time: 1.2125
INFO - 2016-02-25 13:42:04 --> Config Class Initialized
INFO - 2016-02-25 13:42:04 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:42:04 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:42:04 --> Utf8 Class Initialized
INFO - 2016-02-25 13:42:04 --> URI Class Initialized
INFO - 2016-02-25 13:42:04 --> Router Class Initialized
INFO - 2016-02-25 13:42:04 --> Output Class Initialized
INFO - 2016-02-25 13:42:04 --> Security Class Initialized
DEBUG - 2016-02-25 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:42:04 --> Input Class Initialized
INFO - 2016-02-25 13:42:04 --> Language Class Initialized
INFO - 2016-02-25 13:42:04 --> Loader Class Initialized
INFO - 2016-02-25 13:42:04 --> Helper loaded: url_helper
INFO - 2016-02-25 13:42:04 --> Helper loaded: file_helper
INFO - 2016-02-25 13:42:04 --> Helper loaded: date_helper
INFO - 2016-02-25 13:42:04 --> Helper loaded: form_helper
INFO - 2016-02-25 13:42:04 --> Database Driver Class Initialized
INFO - 2016-02-25 13:42:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:42:05 --> Controller Class Initialized
INFO - 2016-02-25 13:42:05 --> Model Class Initialized
INFO - 2016-02-25 13:42:05 --> Model Class Initialized
INFO - 2016-02-25 13:42:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:42:05 --> Pagination Class Initialized
INFO - 2016-02-25 13:42:05 --> Helper loaded: text_helper
INFO - 2016-02-25 13:42:05 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:42:05 --> Upload Class Initialized
INFO - 2016-02-25 16:42:05 --> Image Lib Class Initialized
DEBUG - 2016-02-25 16:42:05 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-02-25 16:42:05 --> Final output sent to browser
DEBUG - 2016-02-25 16:42:05 --> Total execution time: 1.1582
INFO - 2016-02-25 13:45:23 --> Config Class Initialized
INFO - 2016-02-25 13:45:23 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:45:23 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:45:23 --> Utf8 Class Initialized
INFO - 2016-02-25 13:45:23 --> URI Class Initialized
INFO - 2016-02-25 13:45:23 --> Router Class Initialized
INFO - 2016-02-25 13:45:23 --> Output Class Initialized
INFO - 2016-02-25 13:45:23 --> Security Class Initialized
DEBUG - 2016-02-25 13:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:45:23 --> Input Class Initialized
INFO - 2016-02-25 13:45:23 --> Language Class Initialized
INFO - 2016-02-25 13:45:23 --> Loader Class Initialized
INFO - 2016-02-25 13:45:23 --> Helper loaded: url_helper
INFO - 2016-02-25 13:45:23 --> Helper loaded: file_helper
INFO - 2016-02-25 13:45:23 --> Helper loaded: date_helper
INFO - 2016-02-25 13:45:23 --> Helper loaded: form_helper
INFO - 2016-02-25 13:45:23 --> Database Driver Class Initialized
INFO - 2016-02-25 13:45:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:45:24 --> Controller Class Initialized
INFO - 2016-02-25 13:45:24 --> Model Class Initialized
INFO - 2016-02-25 13:45:24 --> Model Class Initialized
INFO - 2016-02-25 13:45:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:45:24 --> Pagination Class Initialized
INFO - 2016-02-25 13:45:24 --> Helper loaded: text_helper
INFO - 2016-02-25 13:45:24 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:45:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 16:45:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 16:45:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 16:45:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 16:45:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 16:45:24 --> Final output sent to browser
DEBUG - 2016-02-25 16:45:24 --> Total execution time: 1.1475
INFO - 2016-02-25 13:45:28 --> Config Class Initialized
INFO - 2016-02-25 13:45:28 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:45:28 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:45:28 --> Utf8 Class Initialized
INFO - 2016-02-25 13:45:28 --> URI Class Initialized
INFO - 2016-02-25 13:45:28 --> Router Class Initialized
INFO - 2016-02-25 13:45:28 --> Output Class Initialized
INFO - 2016-02-25 13:45:28 --> Security Class Initialized
DEBUG - 2016-02-25 13:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:45:28 --> Input Class Initialized
INFO - 2016-02-25 13:45:28 --> Language Class Initialized
INFO - 2016-02-25 13:45:28 --> Loader Class Initialized
INFO - 2016-02-25 13:45:28 --> Helper loaded: url_helper
INFO - 2016-02-25 13:45:28 --> Helper loaded: file_helper
INFO - 2016-02-25 13:45:28 --> Helper loaded: date_helper
INFO - 2016-02-25 13:45:28 --> Helper loaded: form_helper
INFO - 2016-02-25 13:45:28 --> Database Driver Class Initialized
INFO - 2016-02-25 13:45:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:45:29 --> Controller Class Initialized
INFO - 2016-02-25 13:45:29 --> Model Class Initialized
INFO - 2016-02-25 13:45:29 --> Model Class Initialized
INFO - 2016-02-25 13:45:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:45:29 --> Pagination Class Initialized
INFO - 2016-02-25 13:45:29 --> Helper loaded: text_helper
INFO - 2016-02-25 13:45:29 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 16:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 16:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 16:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 16:45:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 16:45:29 --> Final output sent to browser
DEBUG - 2016-02-25 16:45:29 --> Total execution time: 1.1376
INFO - 2016-02-25 13:45:34 --> Config Class Initialized
INFO - 2016-02-25 13:45:34 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:45:34 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:45:34 --> Utf8 Class Initialized
INFO - 2016-02-25 13:45:34 --> URI Class Initialized
INFO - 2016-02-25 13:45:34 --> Router Class Initialized
INFO - 2016-02-25 13:45:34 --> Output Class Initialized
INFO - 2016-02-25 13:45:34 --> Security Class Initialized
DEBUG - 2016-02-25 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:45:34 --> Input Class Initialized
INFO - 2016-02-25 13:45:34 --> Language Class Initialized
INFO - 2016-02-25 13:45:34 --> Loader Class Initialized
INFO - 2016-02-25 13:45:34 --> Helper loaded: url_helper
INFO - 2016-02-25 13:45:34 --> Helper loaded: file_helper
INFO - 2016-02-25 13:45:34 --> Helper loaded: date_helper
INFO - 2016-02-25 13:45:34 --> Helper loaded: form_helper
INFO - 2016-02-25 13:45:34 --> Database Driver Class Initialized
INFO - 2016-02-25 13:45:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:45:35 --> Controller Class Initialized
INFO - 2016-02-25 13:45:35 --> Model Class Initialized
INFO - 2016-02-25 13:45:35 --> Model Class Initialized
INFO - 2016-02-25 13:45:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:45:35 --> Pagination Class Initialized
INFO - 2016-02-25 13:45:35 --> Helper loaded: text_helper
INFO - 2016-02-25 13:45:36 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 16:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 16:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 16:45:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 16:45:36 --> Final output sent to browser
DEBUG - 2016-02-25 16:45:36 --> Total execution time: 1.1532
INFO - 2016-02-25 13:45:38 --> Config Class Initialized
INFO - 2016-02-25 13:45:38 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:45:38 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:45:38 --> Utf8 Class Initialized
INFO - 2016-02-25 13:45:38 --> URI Class Initialized
INFO - 2016-02-25 13:45:38 --> Router Class Initialized
INFO - 2016-02-25 13:45:38 --> Output Class Initialized
INFO - 2016-02-25 13:45:38 --> Security Class Initialized
DEBUG - 2016-02-25 13:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:45:38 --> Input Class Initialized
INFO - 2016-02-25 13:45:38 --> Language Class Initialized
INFO - 2016-02-25 13:45:38 --> Loader Class Initialized
INFO - 2016-02-25 13:45:38 --> Helper loaded: url_helper
INFO - 2016-02-25 13:45:38 --> Helper loaded: file_helper
INFO - 2016-02-25 13:45:38 --> Helper loaded: date_helper
INFO - 2016-02-25 13:45:38 --> Helper loaded: form_helper
INFO - 2016-02-25 13:45:38 --> Database Driver Class Initialized
INFO - 2016-02-25 13:45:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:45:39 --> Controller Class Initialized
INFO - 2016-02-25 13:45:39 --> Model Class Initialized
INFO - 2016-02-25 13:45:39 --> Model Class Initialized
INFO - 2016-02-25 13:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:45:39 --> Pagination Class Initialized
INFO - 2016-02-25 13:45:39 --> Helper loaded: text_helper
INFO - 2016-02-25 13:45:39 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 16:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 16:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-25 16:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 16:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 16:45:39 --> Final output sent to browser
DEBUG - 2016-02-25 16:45:39 --> Total execution time: 1.1958
INFO - 2016-02-25 13:45:42 --> Config Class Initialized
INFO - 2016-02-25 13:45:42 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:45:42 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:45:42 --> Utf8 Class Initialized
INFO - 2016-02-25 13:45:42 --> URI Class Initialized
INFO - 2016-02-25 13:45:42 --> Router Class Initialized
INFO - 2016-02-25 13:45:42 --> Output Class Initialized
INFO - 2016-02-25 13:45:42 --> Security Class Initialized
DEBUG - 2016-02-25 13:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:45:42 --> Input Class Initialized
INFO - 2016-02-25 13:45:42 --> Language Class Initialized
INFO - 2016-02-25 13:45:42 --> Loader Class Initialized
INFO - 2016-02-25 13:45:42 --> Helper loaded: url_helper
INFO - 2016-02-25 13:45:42 --> Helper loaded: file_helper
INFO - 2016-02-25 13:45:42 --> Helper loaded: date_helper
INFO - 2016-02-25 13:45:42 --> Helper loaded: form_helper
INFO - 2016-02-25 13:45:42 --> Database Driver Class Initialized
INFO - 2016-02-25 13:45:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:45:43 --> Controller Class Initialized
INFO - 2016-02-25 13:45:43 --> Model Class Initialized
INFO - 2016-02-25 13:45:43 --> Model Class Initialized
INFO - 2016-02-25 13:45:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:45:43 --> Pagination Class Initialized
INFO - 2016-02-25 13:45:43 --> Helper loaded: text_helper
INFO - 2016-02-25 13:45:43 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 16:45:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 16:45:43 --> Final output sent to browser
DEBUG - 2016-02-25 16:45:43 --> Total execution time: 1.1405
INFO - 2016-02-25 13:45:44 --> Config Class Initialized
INFO - 2016-02-25 13:45:44 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:45:44 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:45:44 --> Utf8 Class Initialized
INFO - 2016-02-25 13:45:45 --> URI Class Initialized
INFO - 2016-02-25 13:45:45 --> Router Class Initialized
INFO - 2016-02-25 13:45:45 --> Output Class Initialized
INFO - 2016-02-25 13:45:45 --> Security Class Initialized
DEBUG - 2016-02-25 13:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:45:45 --> Input Class Initialized
INFO - 2016-02-25 13:45:45 --> Language Class Initialized
INFO - 2016-02-25 13:45:45 --> Loader Class Initialized
INFO - 2016-02-25 13:45:45 --> Helper loaded: url_helper
INFO - 2016-02-25 13:45:45 --> Helper loaded: file_helper
INFO - 2016-02-25 13:45:45 --> Helper loaded: date_helper
INFO - 2016-02-25 13:45:45 --> Helper loaded: form_helper
INFO - 2016-02-25 13:45:45 --> Database Driver Class Initialized
INFO - 2016-02-25 13:45:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:45:46 --> Controller Class Initialized
INFO - 2016-02-25 13:45:46 --> Model Class Initialized
INFO - 2016-02-25 13:45:46 --> Model Class Initialized
INFO - 2016-02-25 13:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:45:46 --> Pagination Class Initialized
INFO - 2016-02-25 13:45:46 --> Helper loaded: text_helper
INFO - 2016-02-25 13:45:46 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 16:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 16:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-25 16:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-02-25 16:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 16:45:46 --> Final output sent to browser
DEBUG - 2016-02-25 16:45:46 --> Total execution time: 1.2269
INFO - 2016-02-25 13:45:48 --> Config Class Initialized
INFO - 2016-02-25 13:45:48 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:45:48 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:45:48 --> Utf8 Class Initialized
INFO - 2016-02-25 13:45:48 --> URI Class Initialized
INFO - 2016-02-25 13:45:48 --> Router Class Initialized
INFO - 2016-02-25 13:45:48 --> Output Class Initialized
INFO - 2016-02-25 13:45:48 --> Security Class Initialized
DEBUG - 2016-02-25 13:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:45:48 --> Input Class Initialized
INFO - 2016-02-25 13:45:48 --> Language Class Initialized
INFO - 2016-02-25 13:45:48 --> Loader Class Initialized
INFO - 2016-02-25 13:45:48 --> Helper loaded: url_helper
INFO - 2016-02-25 13:45:48 --> Helper loaded: file_helper
INFO - 2016-02-25 13:45:48 --> Helper loaded: date_helper
INFO - 2016-02-25 13:45:48 --> Helper loaded: form_helper
INFO - 2016-02-25 13:45:48 --> Database Driver Class Initialized
INFO - 2016-02-25 13:45:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:45:49 --> Controller Class Initialized
INFO - 2016-02-25 13:45:49 --> Model Class Initialized
INFO - 2016-02-25 13:45:49 --> Model Class Initialized
INFO - 2016-02-25 13:45:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:45:49 --> Pagination Class Initialized
INFO - 2016-02-25 13:45:49 --> Helper loaded: text_helper
INFO - 2016-02-25 13:45:49 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-25 16:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-25 16:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-25 16:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-25 16:45:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-25 16:45:49 --> Final output sent to browser
DEBUG - 2016-02-25 16:45:49 --> Total execution time: 1.1321
INFO - 2016-02-25 13:46:00 --> Config Class Initialized
INFO - 2016-02-25 13:46:00 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:46:00 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:46:00 --> Utf8 Class Initialized
INFO - 2016-02-25 13:46:00 --> URI Class Initialized
INFO - 2016-02-25 13:46:00 --> Router Class Initialized
INFO - 2016-02-25 13:46:00 --> Output Class Initialized
INFO - 2016-02-25 13:46:00 --> Security Class Initialized
DEBUG - 2016-02-25 13:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:46:00 --> Input Class Initialized
INFO - 2016-02-25 13:46:00 --> Language Class Initialized
INFO - 2016-02-25 13:46:00 --> Loader Class Initialized
INFO - 2016-02-25 13:46:00 --> Helper loaded: url_helper
INFO - 2016-02-25 13:46:00 --> Helper loaded: file_helper
INFO - 2016-02-25 13:46:00 --> Helper loaded: date_helper
INFO - 2016-02-25 13:46:00 --> Helper loaded: form_helper
INFO - 2016-02-25 13:46:00 --> Database Driver Class Initialized
INFO - 2016-02-25 13:46:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:46:01 --> Controller Class Initialized
INFO - 2016-02-25 13:46:01 --> Model Class Initialized
INFO - 2016-02-25 13:46:01 --> Model Class Initialized
INFO - 2016-02-25 13:46:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:46:01 --> Pagination Class Initialized
INFO - 2016-02-25 13:46:01 --> Helper loaded: text_helper
INFO - 2016-02-25 13:46:01 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:46:01 --> Upload Class Initialized
INFO - 2016-02-25 16:46:01 --> Image Lib Class Initialized
DEBUG - 2016-02-25 16:46:01 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-02-25 16:46:01 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 435
INFO - 2016-02-25 16:46:01 --> Final output sent to browser
DEBUG - 2016-02-25 16:46:01 --> Total execution time: 1.1027
INFO - 2016-02-25 13:46:17 --> Config Class Initialized
INFO - 2016-02-25 13:46:17 --> Hooks Class Initialized
DEBUG - 2016-02-25 13:46:17 --> UTF-8 Support Enabled
INFO - 2016-02-25 13:46:17 --> Utf8 Class Initialized
INFO - 2016-02-25 13:46:17 --> URI Class Initialized
INFO - 2016-02-25 13:46:17 --> Router Class Initialized
INFO - 2016-02-25 13:46:17 --> Output Class Initialized
INFO - 2016-02-25 13:46:17 --> Security Class Initialized
DEBUG - 2016-02-25 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-25 13:46:17 --> Input Class Initialized
INFO - 2016-02-25 13:46:17 --> Language Class Initialized
INFO - 2016-02-25 13:46:18 --> Loader Class Initialized
INFO - 2016-02-25 13:46:18 --> Helper loaded: url_helper
INFO - 2016-02-25 13:46:18 --> Helper loaded: file_helper
INFO - 2016-02-25 13:46:18 --> Helper loaded: date_helper
INFO - 2016-02-25 13:46:18 --> Helper loaded: form_helper
INFO - 2016-02-25 13:46:18 --> Database Driver Class Initialized
INFO - 2016-02-25 13:46:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-25 13:46:19 --> Controller Class Initialized
INFO - 2016-02-25 13:46:19 --> Model Class Initialized
INFO - 2016-02-25 13:46:19 --> Model Class Initialized
INFO - 2016-02-25 13:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-25 13:46:19 --> Pagination Class Initialized
INFO - 2016-02-25 13:46:19 --> Helper loaded: text_helper
INFO - 2016-02-25 13:46:19 --> Helper loaded: cookie_helper
INFO - 2016-02-25 16:46:19 --> Upload Class Initialized
INFO - 2016-02-25 16:46:19 --> Image Lib Class Initialized
DEBUG - 2016-02-25 16:46:19 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-02-25 16:46:19 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 435
INFO - 2016-02-25 16:46:19 --> Final output sent to browser
DEBUG - 2016-02-25 16:46:19 --> Total execution time: 1.2865
