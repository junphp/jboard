<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-11 00:07:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:07:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:07:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:07:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:07:56 --> Final output sent to browser
DEBUG - 2016-02-11 00:07:56 --> Total execution time: 1.1277
INFO - 2016-02-11 00:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:08:00 --> Helper loaded: text_helper
INFO - 2016-02-11 00:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:08:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:08:00 --> Final output sent to browser
DEBUG - 2016-02-11 00:08:00 --> Total execution time: 1.1371
INFO - 2016-02-11 00:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:08:47 --> Helper loaded: text_helper
INFO - 2016-02-11 00:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:08:47 --> Final output sent to browser
DEBUG - 2016-02-11 00:08:47 --> Total execution time: 1.1486
INFO - 2016-02-11 00:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:08:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:08:54 --> Final output sent to browser
DEBUG - 2016-02-11 00:08:54 --> Total execution time: 1.1052
INFO - 2016-02-11 00:08:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:08:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:08:57 --> Helper loaded: text_helper
INFO - 2016-02-11 00:08:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:08:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:08:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:08:57 --> Final output sent to browser
DEBUG - 2016-02-11 00:08:57 --> Total execution time: 1.1384
INFO - 2016-02-11 00:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:10:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:10:56 --> Final output sent to browser
DEBUG - 2016-02-11 00:10:56 --> Total execution time: 1.1234
INFO - 2016-02-11 00:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:11:00 --> Helper loaded: text_helper
INFO - 2016-02-11 00:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:11:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:11:00 --> Final output sent to browser
DEBUG - 2016-02-11 00:11:00 --> Total execution time: 1.1366
INFO - 2016-02-11 00:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:21:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:21:44 --> Final output sent to browser
DEBUG - 2016-02-11 00:21:44 --> Total execution time: 1.1025
INFO - 2016-02-11 00:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:21:48 --> Helper loaded: text_helper
INFO - 2016-02-11 00:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:21:48 --> Final output sent to browser
DEBUG - 2016-02-11 00:21:48 --> Total execution time: 1.1408
INFO - 2016-02-11 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:22:28 --> Helper loaded: text_helper
INFO - 2016-02-11 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:22:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:22:28 --> Final output sent to browser
DEBUG - 2016-02-11 00:22:28 --> Total execution time: 1.1680
INFO - 2016-02-11 00:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:23:22 --> Helper loaded: text_helper
INFO - 2016-02-11 00:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:23:22 --> Final output sent to browser
DEBUG - 2016-02-11 00:23:22 --> Total execution time: 1.1681
INFO - 2016-02-11 00:23:25 --> Final output sent to browser
DEBUG - 2016-02-11 00:23:25 --> Total execution time: 1.0954
INFO - 2016-02-11 00:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:29:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:29:14 --> Final output sent to browser
DEBUG - 2016-02-11 00:29:14 --> Total execution time: 1.0998
INFO - 2016-02-11 00:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:29:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:29:27 --> Final output sent to browser
DEBUG - 2016-02-11 00:29:27 --> Total execution time: 1.0972
INFO - 2016-02-11 00:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:35:54 --> Helper loaded: text_helper
INFO - 2016-02-11 00:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:35:54 --> Final output sent to browser
DEBUG - 2016-02-11 00:35:54 --> Total execution time: 1.1398
INFO - 2016-02-11 00:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:38:30 --> Helper loaded: text_helper
INFO - 2016-02-11 00:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:38:30 --> Final output sent to browser
DEBUG - 2016-02-11 00:38:30 --> Total execution time: 1.1238
INFO - 2016-02-11 00:39:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:39:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:39:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:39:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:39:52 --> Final output sent to browser
DEBUG - 2016-02-11 00:39:52 --> Total execution time: 1.1190
INFO - 2016-02-11 00:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:39:56 --> Helper loaded: text_helper
INFO - 2016-02-11 00:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:39:56 --> Final output sent to browser
DEBUG - 2016-02-11 00:39:56 --> Total execution time: 1.1522
INFO - 2016-02-11 00:39:59 --> Final output sent to browser
DEBUG - 2016-02-11 00:39:59 --> Total execution time: 1.1364
INFO - 2016-02-11 00:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:40:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:40:49 --> Final output sent to browser
DEBUG - 2016-02-11 00:40:49 --> Total execution time: 1.1189
INFO - 2016-02-11 00:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:45:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:45:59 --> Final output sent to browser
DEBUG - 2016-02-11 00:45:59 --> Total execution time: 1.1133
INFO - 2016-02-11 00:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:46:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:46:26 --> Final output sent to browser
DEBUG - 2016-02-11 00:46:26 --> Total execution time: 1.1044
INFO - 2016-02-11 00:47:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:47:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:47:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:47:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:47:25 --> Final output sent to browser
DEBUG - 2016-02-11 00:47:25 --> Total execution time: 1.1140
INFO - 2016-02-11 00:47:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:47:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:47:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:47:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:47:34 --> Final output sent to browser
DEBUG - 2016-02-11 00:47:34 --> Total execution time: 1.1062
INFO - 2016-02-11 00:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:47:39 --> Helper loaded: text_helper
INFO - 2016-02-11 00:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:47:39 --> Final output sent to browser
DEBUG - 2016-02-11 00:47:39 --> Total execution time: 1.1313
INFO - 2016-02-11 00:47:44 --> Final output sent to browser
DEBUG - 2016-02-11 00:47:44 --> Total execution time: 1.1308
INFO - 2016-02-11 00:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:49:01 --> Helper loaded: text_helper
INFO - 2016-02-11 00:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:49:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:49:01 --> Final output sent to browser
DEBUG - 2016-02-11 00:49:01 --> Total execution time: 1.1536
INFO - 2016-02-11 00:49:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:49:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:49:53 --> Helper loaded: text_helper
INFO - 2016-02-11 00:49:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:49:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:49:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:49:53 --> Final output sent to browser
DEBUG - 2016-02-11 00:49:53 --> Total execution time: 1.1727
INFO - 2016-02-11 00:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:50:01 --> Helper loaded: text_helper
INFO - 2016-02-11 00:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:50:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:50:01 --> Final output sent to browser
DEBUG - 2016-02-11 00:50:01 --> Total execution time: 1.1553
INFO - 2016-02-11 00:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:50:52 --> Helper loaded: text_helper
INFO - 2016-02-11 00:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:50:52 --> Final output sent to browser
DEBUG - 2016-02-11 00:50:52 --> Total execution time: 1.1584
INFO - 2016-02-11 00:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:51:17 --> Helper loaded: text_helper
INFO - 2016-02-11 00:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:51:17 --> Final output sent to browser
DEBUG - 2016-02-11 00:51:17 --> Total execution time: 1.1466
INFO - 2016-02-11 00:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:51:49 --> Helper loaded: text_helper
INFO - 2016-02-11 00:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:51:49 --> Final output sent to browser
DEBUG - 2016-02-11 00:51:49 --> Total execution time: 1.1872
INFO - 2016-02-11 00:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:52:10 --> Helper loaded: text_helper
INFO - 2016-02-11 00:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:52:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:52:10 --> Final output sent to browser
DEBUG - 2016-02-11 00:52:10 --> Total execution time: 1.2041
INFO - 2016-02-11 00:52:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:52:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:52:57 --> Helper loaded: text_helper
INFO - 2016-02-11 00:52:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:52:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:52:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:52:57 --> Final output sent to browser
DEBUG - 2016-02-11 00:52:57 --> Total execution time: 1.2187
INFO - 2016-02-11 00:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:53:53 --> Helper loaded: text_helper
INFO - 2016-02-11 00:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 00:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 00:53:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:53:53 --> Final output sent to browser
DEBUG - 2016-02-11 00:53:53 --> Total execution time: 1.1542
INFO - 2016-02-11 00:54:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 00:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:54:41 --> Final output sent to browser
DEBUG - 2016-02-11 00:54:41 --> Total execution time: 1.1322
INFO - 2016-02-11 00:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 00:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 00:55:04 --> Form Validation Class Initialized
INFO - 2016-02-11 00:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 00:55:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 00:55:04 --> Final output sent to browser
DEBUG - 2016-02-11 00:55:04 --> Total execution time: 1.1196
INFO - 2016-02-11 05:18:01 --> Config Class Initialized
INFO - 2016-02-11 05:18:01 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:18:01 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:18:01 --> Utf8 Class Initialized
INFO - 2016-02-11 05:18:01 --> URI Class Initialized
DEBUG - 2016-02-11 05:18:01 --> No URI present. Default controller set.
INFO - 2016-02-11 05:18:01 --> Router Class Initialized
INFO - 2016-02-11 05:18:01 --> Output Class Initialized
INFO - 2016-02-11 05:18:01 --> Security Class Initialized
DEBUG - 2016-02-11 05:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:18:01 --> Input Class Initialized
INFO - 2016-02-11 05:18:01 --> Language Class Initialized
INFO - 2016-02-11 05:18:01 --> Loader Class Initialized
INFO - 2016-02-11 05:18:01 --> Helper loaded: url_helper
INFO - 2016-02-11 05:18:01 --> Helper loaded: file_helper
INFO - 2016-02-11 05:18:01 --> Helper loaded: date_helper
INFO - 2016-02-11 05:18:01 --> Helper loaded: form_helper
INFO - 2016-02-11 05:18:01 --> Database Driver Class Initialized
INFO - 2016-02-11 05:18:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:18:02 --> Controller Class Initialized
INFO - 2016-02-11 05:18:02 --> Model Class Initialized
INFO - 2016-02-11 05:18:02 --> Model Class Initialized
INFO - 2016-02-11 05:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:18:02 --> Pagination Class Initialized
INFO - 2016-02-11 08:18:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:18:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:18:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 08:18:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:18:02 --> Final output sent to browser
DEBUG - 2016-02-11 08:18:02 --> Total execution time: 1.3351
INFO - 2016-02-11 05:18:34 --> Config Class Initialized
INFO - 2016-02-11 05:18:34 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:18:34 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:18:34 --> Utf8 Class Initialized
INFO - 2016-02-11 05:18:34 --> URI Class Initialized
INFO - 2016-02-11 05:18:34 --> Router Class Initialized
INFO - 2016-02-11 05:18:34 --> Output Class Initialized
INFO - 2016-02-11 05:18:34 --> Security Class Initialized
DEBUG - 2016-02-11 05:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:18:34 --> Input Class Initialized
INFO - 2016-02-11 05:18:34 --> Language Class Initialized
INFO - 2016-02-11 05:18:34 --> Loader Class Initialized
INFO - 2016-02-11 05:18:34 --> Helper loaded: url_helper
INFO - 2016-02-11 05:18:34 --> Helper loaded: file_helper
INFO - 2016-02-11 05:18:34 --> Helper loaded: date_helper
INFO - 2016-02-11 05:18:34 --> Helper loaded: form_helper
INFO - 2016-02-11 05:18:34 --> Database Driver Class Initialized
INFO - 2016-02-11 05:18:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:18:35 --> Controller Class Initialized
INFO - 2016-02-11 05:18:35 --> Model Class Initialized
INFO - 2016-02-11 05:18:35 --> Model Class Initialized
INFO - 2016-02-11 05:18:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:18:35 --> Pagination Class Initialized
INFO - 2016-02-11 08:18:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:18:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:18:35 --> Helper loaded: text_helper
INFO - 2016-02-11 08:18:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 08:18:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 08:18:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:18:35 --> Final output sent to browser
DEBUG - 2016-02-11 08:18:35 --> Total execution time: 1.2592
INFO - 2016-02-11 05:18:59 --> Config Class Initialized
INFO - 2016-02-11 05:18:59 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:18:59 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:18:59 --> Utf8 Class Initialized
INFO - 2016-02-11 05:18:59 --> URI Class Initialized
INFO - 2016-02-11 05:18:59 --> Router Class Initialized
INFO - 2016-02-11 05:18:59 --> Output Class Initialized
INFO - 2016-02-11 05:18:59 --> Security Class Initialized
DEBUG - 2016-02-11 05:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:18:59 --> Input Class Initialized
INFO - 2016-02-11 05:18:59 --> Language Class Initialized
INFO - 2016-02-11 05:18:59 --> Loader Class Initialized
INFO - 2016-02-11 05:18:59 --> Helper loaded: url_helper
INFO - 2016-02-11 05:18:59 --> Helper loaded: file_helper
INFO - 2016-02-11 05:18:59 --> Helper loaded: date_helper
INFO - 2016-02-11 05:18:59 --> Helper loaded: form_helper
INFO - 2016-02-11 05:18:59 --> Database Driver Class Initialized
INFO - 2016-02-11 05:19:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:19:00 --> Controller Class Initialized
INFO - 2016-02-11 05:19:00 --> Model Class Initialized
INFO - 2016-02-11 05:19:00 --> Model Class Initialized
INFO - 2016-02-11 05:19:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:19:00 --> Pagination Class Initialized
INFO - 2016-02-11 08:19:00 --> Final output sent to browser
DEBUG - 2016-02-11 08:19:00 --> Total execution time: 1.0999
INFO - 2016-02-11 05:19:02 --> Config Class Initialized
INFO - 2016-02-11 05:19:02 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:19:02 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:19:02 --> Utf8 Class Initialized
INFO - 2016-02-11 05:19:02 --> URI Class Initialized
INFO - 2016-02-11 05:19:02 --> Router Class Initialized
INFO - 2016-02-11 05:19:02 --> Output Class Initialized
INFO - 2016-02-11 05:19:02 --> Security Class Initialized
DEBUG - 2016-02-11 05:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:19:02 --> Input Class Initialized
INFO - 2016-02-11 05:19:02 --> Language Class Initialized
INFO - 2016-02-11 05:19:02 --> Loader Class Initialized
INFO - 2016-02-11 05:19:02 --> Helper loaded: url_helper
INFO - 2016-02-11 05:19:02 --> Helper loaded: file_helper
INFO - 2016-02-11 05:19:02 --> Helper loaded: date_helper
INFO - 2016-02-11 05:19:02 --> Helper loaded: form_helper
INFO - 2016-02-11 05:19:02 --> Database Driver Class Initialized
INFO - 2016-02-11 05:19:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:19:03 --> Controller Class Initialized
INFO - 2016-02-11 05:19:04 --> Model Class Initialized
INFO - 2016-02-11 05:19:04 --> Model Class Initialized
INFO - 2016-02-11 05:19:04 --> Form Validation Class Initialized
INFO - 2016-02-11 05:19:04 --> Helper loaded: text_helper
INFO - 2016-02-11 05:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 05:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 05:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-11 05:19:04 --> Final output sent to browser
DEBUG - 2016-02-11 05:19:04 --> Total execution time: 1.1600
INFO - 2016-02-11 05:43:43 --> Config Class Initialized
INFO - 2016-02-11 05:43:43 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:43:43 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:43:43 --> Utf8 Class Initialized
INFO - 2016-02-11 05:43:43 --> URI Class Initialized
DEBUG - 2016-02-11 05:43:43 --> No URI present. Default controller set.
INFO - 2016-02-11 05:43:43 --> Router Class Initialized
INFO - 2016-02-11 05:43:43 --> Output Class Initialized
INFO - 2016-02-11 05:43:43 --> Security Class Initialized
DEBUG - 2016-02-11 05:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:43:43 --> Input Class Initialized
INFO - 2016-02-11 05:43:43 --> Language Class Initialized
INFO - 2016-02-11 05:43:43 --> Loader Class Initialized
INFO - 2016-02-11 05:43:43 --> Helper loaded: url_helper
INFO - 2016-02-11 05:43:43 --> Helper loaded: file_helper
INFO - 2016-02-11 05:43:43 --> Helper loaded: date_helper
INFO - 2016-02-11 05:43:43 --> Helper loaded: form_helper
INFO - 2016-02-11 05:43:43 --> Database Driver Class Initialized
INFO - 2016-02-11 05:43:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:43:44 --> Controller Class Initialized
INFO - 2016-02-11 05:43:44 --> Model Class Initialized
INFO - 2016-02-11 05:43:44 --> Model Class Initialized
INFO - 2016-02-11 05:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:43:44 --> Pagination Class Initialized
INFO - 2016-02-11 08:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 08:43:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:43:44 --> Final output sent to browser
DEBUG - 2016-02-11 08:43:44 --> Total execution time: 1.1807
INFO - 2016-02-11 05:43:57 --> Config Class Initialized
INFO - 2016-02-11 05:43:57 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:43:57 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:43:57 --> Utf8 Class Initialized
INFO - 2016-02-11 05:43:57 --> URI Class Initialized
INFO - 2016-02-11 05:43:57 --> Router Class Initialized
INFO - 2016-02-11 05:43:57 --> Output Class Initialized
INFO - 2016-02-11 05:43:57 --> Security Class Initialized
DEBUG - 2016-02-11 05:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:43:57 --> Input Class Initialized
INFO - 2016-02-11 05:43:57 --> Language Class Initialized
INFO - 2016-02-11 05:43:57 --> Loader Class Initialized
INFO - 2016-02-11 05:43:57 --> Helper loaded: url_helper
INFO - 2016-02-11 05:43:57 --> Helper loaded: file_helper
INFO - 2016-02-11 05:43:57 --> Helper loaded: date_helper
INFO - 2016-02-11 05:43:57 --> Helper loaded: form_helper
INFO - 2016-02-11 05:43:57 --> Database Driver Class Initialized
INFO - 2016-02-11 05:43:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:43:58 --> Controller Class Initialized
INFO - 2016-02-11 05:43:58 --> Model Class Initialized
INFO - 2016-02-11 05:43:58 --> Model Class Initialized
INFO - 2016-02-11 05:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:43:58 --> Pagination Class Initialized
INFO - 2016-02-11 08:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:43:58 --> Helper loaded: text_helper
INFO - 2016-02-11 08:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 08:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 08:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:43:58 --> Final output sent to browser
DEBUG - 2016-02-11 08:43:58 --> Total execution time: 1.1896
INFO - 2016-02-11 05:50:15 --> Config Class Initialized
INFO - 2016-02-11 05:50:15 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:50:15 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:50:15 --> Utf8 Class Initialized
INFO - 2016-02-11 05:50:15 --> URI Class Initialized
DEBUG - 2016-02-11 05:50:15 --> No URI present. Default controller set.
INFO - 2016-02-11 05:50:15 --> Router Class Initialized
INFO - 2016-02-11 05:50:15 --> Output Class Initialized
INFO - 2016-02-11 05:50:15 --> Security Class Initialized
DEBUG - 2016-02-11 05:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:50:15 --> Input Class Initialized
INFO - 2016-02-11 05:50:15 --> Language Class Initialized
INFO - 2016-02-11 05:50:15 --> Loader Class Initialized
INFO - 2016-02-11 05:50:15 --> Helper loaded: url_helper
INFO - 2016-02-11 05:50:15 --> Helper loaded: file_helper
INFO - 2016-02-11 05:50:15 --> Helper loaded: date_helper
INFO - 2016-02-11 05:50:15 --> Helper loaded: form_helper
INFO - 2016-02-11 05:50:15 --> Database Driver Class Initialized
INFO - 2016-02-11 05:50:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:50:16 --> Controller Class Initialized
INFO - 2016-02-11 05:50:16 --> Model Class Initialized
INFO - 2016-02-11 05:50:16 --> Model Class Initialized
INFO - 2016-02-11 05:50:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:50:16 --> Pagination Class Initialized
INFO - 2016-02-11 08:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 08:50:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:50:16 --> Final output sent to browser
DEBUG - 2016-02-11 08:50:16 --> Total execution time: 1.1575
INFO - 2016-02-11 05:50:18 --> Config Class Initialized
INFO - 2016-02-11 05:50:18 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:50:18 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:50:18 --> Utf8 Class Initialized
INFO - 2016-02-11 05:50:18 --> URI Class Initialized
INFO - 2016-02-11 05:50:18 --> Router Class Initialized
INFO - 2016-02-11 05:50:18 --> Output Class Initialized
INFO - 2016-02-11 05:50:18 --> Security Class Initialized
DEBUG - 2016-02-11 05:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:50:18 --> Input Class Initialized
INFO - 2016-02-11 05:50:18 --> Language Class Initialized
INFO - 2016-02-11 05:50:18 --> Loader Class Initialized
INFO - 2016-02-11 05:50:18 --> Helper loaded: url_helper
INFO - 2016-02-11 05:50:18 --> Helper loaded: file_helper
INFO - 2016-02-11 05:50:18 --> Helper loaded: date_helper
INFO - 2016-02-11 05:50:18 --> Helper loaded: form_helper
INFO - 2016-02-11 05:50:18 --> Database Driver Class Initialized
INFO - 2016-02-11 05:50:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:50:19 --> Controller Class Initialized
INFO - 2016-02-11 05:50:19 --> Model Class Initialized
INFO - 2016-02-11 05:50:19 --> Model Class Initialized
INFO - 2016-02-11 05:50:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:50:19 --> Pagination Class Initialized
INFO - 2016-02-11 05:50:19 --> Config Class Initialized
INFO - 2016-02-11 05:50:19 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:50:19 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:50:19 --> Utf8 Class Initialized
INFO - 2016-02-11 05:50:19 --> URI Class Initialized
INFO - 2016-02-11 05:50:19 --> Router Class Initialized
INFO - 2016-02-11 05:50:19 --> Output Class Initialized
INFO - 2016-02-11 05:50:19 --> Security Class Initialized
DEBUG - 2016-02-11 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:50:19 --> Input Class Initialized
INFO - 2016-02-11 05:50:19 --> Language Class Initialized
INFO - 2016-02-11 05:50:19 --> Loader Class Initialized
INFO - 2016-02-11 05:50:19 --> Helper loaded: url_helper
INFO - 2016-02-11 05:50:19 --> Helper loaded: file_helper
INFO - 2016-02-11 05:50:19 --> Helper loaded: date_helper
INFO - 2016-02-11 05:50:19 --> Helper loaded: form_helper
INFO - 2016-02-11 05:50:19 --> Database Driver Class Initialized
INFO - 2016-02-11 05:50:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:50:20 --> Controller Class Initialized
INFO - 2016-02-11 05:50:20 --> Model Class Initialized
INFO - 2016-02-11 05:50:20 --> Model Class Initialized
INFO - 2016-02-11 05:50:20 --> Form Validation Class Initialized
INFO - 2016-02-11 05:50:20 --> Helper loaded: text_helper
INFO - 2016-02-11 05:50:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 05:50:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 05:50:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-11 05:50:20 --> Final output sent to browser
DEBUG - 2016-02-11 05:50:20 --> Total execution time: 1.1165
INFO - 2016-02-11 05:50:24 --> Config Class Initialized
INFO - 2016-02-11 05:50:24 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:50:24 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:50:24 --> Utf8 Class Initialized
INFO - 2016-02-11 05:50:24 --> URI Class Initialized
INFO - 2016-02-11 05:50:24 --> Router Class Initialized
INFO - 2016-02-11 05:50:24 --> Output Class Initialized
INFO - 2016-02-11 05:50:24 --> Security Class Initialized
DEBUG - 2016-02-11 05:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:50:24 --> Input Class Initialized
INFO - 2016-02-11 05:50:24 --> Language Class Initialized
INFO - 2016-02-11 05:50:24 --> Loader Class Initialized
INFO - 2016-02-11 05:50:24 --> Helper loaded: url_helper
INFO - 2016-02-11 05:50:24 --> Helper loaded: file_helper
INFO - 2016-02-11 05:50:24 --> Helper loaded: date_helper
INFO - 2016-02-11 05:50:24 --> Helper loaded: form_helper
INFO - 2016-02-11 05:50:24 --> Database Driver Class Initialized
INFO - 2016-02-11 05:50:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:50:25 --> Controller Class Initialized
INFO - 2016-02-11 05:50:25 --> Model Class Initialized
INFO - 2016-02-11 05:50:25 --> Model Class Initialized
INFO - 2016-02-11 05:50:25 --> Form Validation Class Initialized
INFO - 2016-02-11 05:50:25 --> Helper loaded: text_helper
INFO - 2016-02-11 05:50:25 --> Config Class Initialized
INFO - 2016-02-11 05:50:25 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:50:25 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:50:25 --> Utf8 Class Initialized
INFO - 2016-02-11 05:50:25 --> URI Class Initialized
INFO - 2016-02-11 05:50:25 --> Router Class Initialized
INFO - 2016-02-11 05:50:25 --> Output Class Initialized
INFO - 2016-02-11 05:50:25 --> Security Class Initialized
DEBUG - 2016-02-11 05:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:50:25 --> Input Class Initialized
INFO - 2016-02-11 05:50:25 --> Language Class Initialized
INFO - 2016-02-11 05:50:25 --> Loader Class Initialized
INFO - 2016-02-11 05:50:25 --> Helper loaded: url_helper
INFO - 2016-02-11 05:50:25 --> Helper loaded: file_helper
INFO - 2016-02-11 05:50:25 --> Helper loaded: date_helper
INFO - 2016-02-11 05:50:25 --> Helper loaded: form_helper
INFO - 2016-02-11 05:50:25 --> Database Driver Class Initialized
INFO - 2016-02-11 05:50:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:50:26 --> Controller Class Initialized
INFO - 2016-02-11 05:50:26 --> Model Class Initialized
INFO - 2016-02-11 05:50:26 --> Model Class Initialized
INFO - 2016-02-11 05:50:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:50:26 --> Pagination Class Initialized
INFO - 2016-02-11 08:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:50:26 --> Form Validation Class Initialized
INFO - 2016-02-11 08:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 08:50:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:50:26 --> Final output sent to browser
DEBUG - 2016-02-11 08:50:26 --> Total execution time: 1.1618
INFO - 2016-02-11 05:50:35 --> Config Class Initialized
INFO - 2016-02-11 05:50:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:50:35 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:50:35 --> Utf8 Class Initialized
INFO - 2016-02-11 05:50:35 --> URI Class Initialized
INFO - 2016-02-11 05:50:35 --> Router Class Initialized
INFO - 2016-02-11 05:50:35 --> Output Class Initialized
INFO - 2016-02-11 05:50:35 --> Security Class Initialized
DEBUG - 2016-02-11 05:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:50:35 --> Input Class Initialized
INFO - 2016-02-11 05:50:35 --> Language Class Initialized
INFO - 2016-02-11 05:50:35 --> Loader Class Initialized
INFO - 2016-02-11 05:50:35 --> Helper loaded: url_helper
INFO - 2016-02-11 05:50:35 --> Helper loaded: file_helper
INFO - 2016-02-11 05:50:35 --> Helper loaded: date_helper
INFO - 2016-02-11 05:50:35 --> Helper loaded: form_helper
INFO - 2016-02-11 05:50:35 --> Database Driver Class Initialized
INFO - 2016-02-11 05:50:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:50:36 --> Controller Class Initialized
INFO - 2016-02-11 05:50:36 --> Model Class Initialized
INFO - 2016-02-11 05:50:36 --> Model Class Initialized
INFO - 2016-02-11 05:50:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:50:36 --> Pagination Class Initialized
INFO - 2016-02-11 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:50:36 --> Form Validation Class Initialized
INFO - 2016-02-11 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 08:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:50:36 --> Final output sent to browser
DEBUG - 2016-02-11 08:50:36 --> Total execution time: 1.1629
INFO - 2016-02-11 05:51:16 --> Config Class Initialized
INFO - 2016-02-11 05:51:16 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:51:16 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:51:16 --> Utf8 Class Initialized
INFO - 2016-02-11 05:51:16 --> URI Class Initialized
INFO - 2016-02-11 05:51:16 --> Router Class Initialized
INFO - 2016-02-11 05:51:16 --> Output Class Initialized
INFO - 2016-02-11 05:51:16 --> Security Class Initialized
DEBUG - 2016-02-11 05:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:51:16 --> Input Class Initialized
INFO - 2016-02-11 05:51:16 --> Language Class Initialized
INFO - 2016-02-11 05:51:16 --> Loader Class Initialized
INFO - 2016-02-11 05:51:16 --> Helper loaded: url_helper
INFO - 2016-02-11 05:51:16 --> Helper loaded: file_helper
INFO - 2016-02-11 05:51:16 --> Helper loaded: date_helper
INFO - 2016-02-11 05:51:16 --> Helper loaded: form_helper
INFO - 2016-02-11 05:51:16 --> Database Driver Class Initialized
INFO - 2016-02-11 05:51:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:51:17 --> Controller Class Initialized
INFO - 2016-02-11 05:51:17 --> Model Class Initialized
INFO - 2016-02-11 05:51:17 --> Model Class Initialized
INFO - 2016-02-11 05:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:51:17 --> Pagination Class Initialized
INFO - 2016-02-11 08:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:51:17 --> Form Validation Class Initialized
INFO - 2016-02-11 08:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 08:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:51:17 --> Final output sent to browser
DEBUG - 2016-02-11 08:51:17 --> Total execution time: 1.1970
INFO - 2016-02-11 05:51:23 --> Config Class Initialized
INFO - 2016-02-11 05:51:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:51:23 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:51:23 --> Utf8 Class Initialized
INFO - 2016-02-11 05:51:23 --> URI Class Initialized
INFO - 2016-02-11 05:51:23 --> Router Class Initialized
INFO - 2016-02-11 05:51:23 --> Output Class Initialized
INFO - 2016-02-11 05:51:23 --> Security Class Initialized
DEBUG - 2016-02-11 05:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:51:23 --> Input Class Initialized
INFO - 2016-02-11 05:51:23 --> Language Class Initialized
INFO - 2016-02-11 05:51:23 --> Loader Class Initialized
INFO - 2016-02-11 05:51:23 --> Helper loaded: url_helper
INFO - 2016-02-11 05:51:23 --> Helper loaded: file_helper
INFO - 2016-02-11 05:51:23 --> Helper loaded: date_helper
INFO - 2016-02-11 05:51:23 --> Helper loaded: form_helper
INFO - 2016-02-11 05:51:23 --> Database Driver Class Initialized
INFO - 2016-02-11 05:51:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:51:24 --> Controller Class Initialized
INFO - 2016-02-11 05:51:24 --> Model Class Initialized
INFO - 2016-02-11 05:51:24 --> Model Class Initialized
INFO - 2016-02-11 05:51:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:51:24 --> Pagination Class Initialized
INFO - 2016-02-11 08:51:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:51:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:51:24 --> Form Validation Class Initialized
INFO - 2016-02-11 08:51:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 08:51:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:51:24 --> Final output sent to browser
DEBUG - 2016-02-11 08:51:24 --> Total execution time: 1.1690
INFO - 2016-02-11 05:57:48 --> Config Class Initialized
INFO - 2016-02-11 05:57:48 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:57:48 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:57:48 --> Utf8 Class Initialized
INFO - 2016-02-11 05:57:48 --> URI Class Initialized
INFO - 2016-02-11 05:57:48 --> Router Class Initialized
INFO - 2016-02-11 05:57:49 --> Output Class Initialized
INFO - 2016-02-11 05:57:49 --> Security Class Initialized
DEBUG - 2016-02-11 05:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:57:49 --> Input Class Initialized
INFO - 2016-02-11 05:57:49 --> Language Class Initialized
INFO - 2016-02-11 05:57:49 --> Loader Class Initialized
INFO - 2016-02-11 05:57:49 --> Helper loaded: url_helper
INFO - 2016-02-11 05:57:49 --> Helper loaded: file_helper
INFO - 2016-02-11 05:57:49 --> Helper loaded: date_helper
INFO - 2016-02-11 05:57:49 --> Helper loaded: form_helper
INFO - 2016-02-11 05:57:49 --> Database Driver Class Initialized
INFO - 2016-02-11 05:57:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:57:50 --> Controller Class Initialized
INFO - 2016-02-11 05:57:50 --> Model Class Initialized
INFO - 2016-02-11 05:57:50 --> Model Class Initialized
INFO - 2016-02-11 05:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:57:50 --> Pagination Class Initialized
INFO - 2016-02-11 08:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:57:50 --> Form Validation Class Initialized
INFO - 2016-02-11 08:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 08:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:57:50 --> Final output sent to browser
DEBUG - 2016-02-11 08:57:50 --> Total execution time: 1.1721
INFO - 2016-02-11 05:58:36 --> Config Class Initialized
INFO - 2016-02-11 05:58:36 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:58:36 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:58:36 --> Utf8 Class Initialized
INFO - 2016-02-11 05:58:36 --> URI Class Initialized
INFO - 2016-02-11 05:58:36 --> Router Class Initialized
INFO - 2016-02-11 05:58:36 --> Output Class Initialized
INFO - 2016-02-11 05:58:36 --> Security Class Initialized
DEBUG - 2016-02-11 05:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:58:36 --> Input Class Initialized
INFO - 2016-02-11 05:58:36 --> Language Class Initialized
INFO - 2016-02-11 05:58:36 --> Loader Class Initialized
INFO - 2016-02-11 05:58:36 --> Helper loaded: url_helper
INFO - 2016-02-11 05:58:36 --> Helper loaded: file_helper
INFO - 2016-02-11 05:58:36 --> Helper loaded: date_helper
INFO - 2016-02-11 05:58:36 --> Helper loaded: form_helper
INFO - 2016-02-11 05:58:36 --> Database Driver Class Initialized
INFO - 2016-02-11 05:58:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:58:37 --> Controller Class Initialized
INFO - 2016-02-11 05:58:37 --> Model Class Initialized
INFO - 2016-02-11 05:58:37 --> Model Class Initialized
INFO - 2016-02-11 05:58:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:58:37 --> Pagination Class Initialized
INFO - 2016-02-11 08:58:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:58:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:58:37 --> Form Validation Class Initialized
INFO - 2016-02-11 08:58:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 08:58:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:58:37 --> Final output sent to browser
DEBUG - 2016-02-11 08:58:37 --> Total execution time: 1.1806
INFO - 2016-02-11 05:58:46 --> Config Class Initialized
INFO - 2016-02-11 05:58:46 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:58:46 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:58:46 --> Utf8 Class Initialized
INFO - 2016-02-11 05:58:46 --> URI Class Initialized
INFO - 2016-02-11 05:58:46 --> Router Class Initialized
INFO - 2016-02-11 05:58:46 --> Output Class Initialized
INFO - 2016-02-11 05:58:46 --> Security Class Initialized
DEBUG - 2016-02-11 05:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:58:46 --> Input Class Initialized
INFO - 2016-02-11 05:58:46 --> Language Class Initialized
INFO - 2016-02-11 05:58:46 --> Loader Class Initialized
INFO - 2016-02-11 05:58:46 --> Helper loaded: url_helper
INFO - 2016-02-11 05:58:46 --> Helper loaded: file_helper
INFO - 2016-02-11 05:58:46 --> Helper loaded: date_helper
INFO - 2016-02-11 05:58:46 --> Helper loaded: form_helper
INFO - 2016-02-11 05:58:46 --> Database Driver Class Initialized
INFO - 2016-02-11 05:58:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:58:47 --> Controller Class Initialized
INFO - 2016-02-11 05:58:47 --> Model Class Initialized
INFO - 2016-02-11 05:58:47 --> Model Class Initialized
INFO - 2016-02-11 05:58:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:58:47 --> Pagination Class Initialized
INFO - 2016-02-11 08:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:58:47 --> Form Validation Class Initialized
INFO - 2016-02-11 08:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 08:58:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:58:47 --> Final output sent to browser
DEBUG - 2016-02-11 08:58:47 --> Total execution time: 1.1643
INFO - 2016-02-11 05:58:56 --> Config Class Initialized
INFO - 2016-02-11 05:58:56 --> Hooks Class Initialized
DEBUG - 2016-02-11 05:58:56 --> UTF-8 Support Enabled
INFO - 2016-02-11 05:58:56 --> Utf8 Class Initialized
INFO - 2016-02-11 05:58:56 --> URI Class Initialized
INFO - 2016-02-11 05:58:56 --> Router Class Initialized
INFO - 2016-02-11 05:58:56 --> Output Class Initialized
INFO - 2016-02-11 05:58:56 --> Security Class Initialized
DEBUG - 2016-02-11 05:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 05:58:56 --> Input Class Initialized
INFO - 2016-02-11 05:58:56 --> Language Class Initialized
INFO - 2016-02-11 05:58:56 --> Loader Class Initialized
INFO - 2016-02-11 05:58:56 --> Helper loaded: url_helper
INFO - 2016-02-11 05:58:56 --> Helper loaded: file_helper
INFO - 2016-02-11 05:58:56 --> Helper loaded: date_helper
INFO - 2016-02-11 05:58:56 --> Helper loaded: form_helper
INFO - 2016-02-11 05:58:56 --> Database Driver Class Initialized
INFO - 2016-02-11 05:58:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 05:58:57 --> Controller Class Initialized
INFO - 2016-02-11 05:58:57 --> Model Class Initialized
INFO - 2016-02-11 05:58:57 --> Model Class Initialized
INFO - 2016-02-11 05:58:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 05:58:57 --> Pagination Class Initialized
INFO - 2016-02-11 08:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 08:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 08:58:57 --> Form Validation Class Initialized
INFO - 2016-02-11 08:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 08:58:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 08:58:57 --> Final output sent to browser
DEBUG - 2016-02-11 08:58:57 --> Total execution time: 1.2241
INFO - 2016-02-11 06:00:06 --> Config Class Initialized
INFO - 2016-02-11 06:00:06 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:00:06 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:00:06 --> Utf8 Class Initialized
INFO - 2016-02-11 06:00:06 --> URI Class Initialized
INFO - 2016-02-11 06:00:06 --> Router Class Initialized
INFO - 2016-02-11 06:00:07 --> Output Class Initialized
INFO - 2016-02-11 06:00:07 --> Security Class Initialized
DEBUG - 2016-02-11 06:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:00:07 --> Input Class Initialized
INFO - 2016-02-11 06:00:07 --> Language Class Initialized
INFO - 2016-02-11 06:00:07 --> Loader Class Initialized
INFO - 2016-02-11 06:00:07 --> Helper loaded: url_helper
INFO - 2016-02-11 06:00:07 --> Helper loaded: file_helper
INFO - 2016-02-11 06:00:07 --> Helper loaded: date_helper
INFO - 2016-02-11 06:00:07 --> Helper loaded: form_helper
INFO - 2016-02-11 06:00:07 --> Database Driver Class Initialized
INFO - 2016-02-11 06:00:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:00:08 --> Controller Class Initialized
INFO - 2016-02-11 06:00:08 --> Model Class Initialized
INFO - 2016-02-11 06:00:08 --> Model Class Initialized
INFO - 2016-02-11 06:00:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:00:08 --> Pagination Class Initialized
INFO - 2016-02-11 09:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:00:08 --> Form Validation Class Initialized
INFO - 2016-02-11 09:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 09:00:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:00:08 --> Final output sent to browser
DEBUG - 2016-02-11 09:00:08 --> Total execution time: 1.2698
INFO - 2016-02-11 06:00:35 --> Config Class Initialized
INFO - 2016-02-11 06:00:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:00:35 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:00:35 --> Utf8 Class Initialized
INFO - 2016-02-11 06:00:35 --> URI Class Initialized
INFO - 2016-02-11 06:00:35 --> Router Class Initialized
INFO - 2016-02-11 06:00:35 --> Output Class Initialized
INFO - 2016-02-11 06:00:35 --> Security Class Initialized
DEBUG - 2016-02-11 06:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:00:35 --> Input Class Initialized
INFO - 2016-02-11 06:00:35 --> Language Class Initialized
INFO - 2016-02-11 06:00:35 --> Loader Class Initialized
INFO - 2016-02-11 06:00:35 --> Helper loaded: url_helper
INFO - 2016-02-11 06:00:35 --> Helper loaded: file_helper
INFO - 2016-02-11 06:00:35 --> Helper loaded: date_helper
INFO - 2016-02-11 06:00:35 --> Helper loaded: form_helper
INFO - 2016-02-11 06:00:35 --> Database Driver Class Initialized
INFO - 2016-02-11 06:00:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:00:36 --> Controller Class Initialized
INFO - 2016-02-11 06:00:36 --> Model Class Initialized
INFO - 2016-02-11 06:00:36 --> Model Class Initialized
INFO - 2016-02-11 06:00:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:00:36 --> Pagination Class Initialized
INFO - 2016-02-11 09:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:00:36 --> Form Validation Class Initialized
INFO - 2016-02-11 09:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 09:00:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:00:36 --> Final output sent to browser
DEBUG - 2016-02-11 09:00:36 --> Total execution time: 1.1723
INFO - 2016-02-11 06:02:46 --> Config Class Initialized
INFO - 2016-02-11 06:02:46 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:02:46 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:02:46 --> Utf8 Class Initialized
INFO - 2016-02-11 06:02:46 --> URI Class Initialized
INFO - 2016-02-11 06:02:46 --> Router Class Initialized
INFO - 2016-02-11 06:02:46 --> Output Class Initialized
INFO - 2016-02-11 06:02:46 --> Security Class Initialized
DEBUG - 2016-02-11 06:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:02:46 --> Input Class Initialized
INFO - 2016-02-11 06:02:46 --> Language Class Initialized
INFO - 2016-02-11 06:02:46 --> Loader Class Initialized
INFO - 2016-02-11 06:02:46 --> Helper loaded: url_helper
INFO - 2016-02-11 06:02:46 --> Helper loaded: file_helper
INFO - 2016-02-11 06:02:46 --> Helper loaded: date_helper
INFO - 2016-02-11 06:02:46 --> Helper loaded: form_helper
INFO - 2016-02-11 06:02:46 --> Database Driver Class Initialized
INFO - 2016-02-11 06:02:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:02:47 --> Controller Class Initialized
INFO - 2016-02-11 06:02:47 --> Model Class Initialized
INFO - 2016-02-11 06:02:47 --> Model Class Initialized
INFO - 2016-02-11 06:02:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:02:47 --> Pagination Class Initialized
INFO - 2016-02-11 09:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:02:47 --> Form Validation Class Initialized
INFO - 2016-02-11 09:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 09:02:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:02:47 --> Final output sent to browser
DEBUG - 2016-02-11 09:02:47 --> Total execution time: 1.1455
INFO - 2016-02-11 06:03:12 --> Config Class Initialized
INFO - 2016-02-11 06:03:12 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:03:12 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:03:12 --> Utf8 Class Initialized
INFO - 2016-02-11 06:03:12 --> URI Class Initialized
INFO - 2016-02-11 06:03:12 --> Router Class Initialized
INFO - 2016-02-11 06:03:12 --> Output Class Initialized
INFO - 2016-02-11 06:03:12 --> Security Class Initialized
DEBUG - 2016-02-11 06:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:03:12 --> Input Class Initialized
INFO - 2016-02-11 06:03:12 --> Language Class Initialized
INFO - 2016-02-11 06:03:12 --> Loader Class Initialized
INFO - 2016-02-11 06:03:12 --> Helper loaded: url_helper
INFO - 2016-02-11 06:03:12 --> Helper loaded: file_helper
INFO - 2016-02-11 06:03:12 --> Helper loaded: date_helper
INFO - 2016-02-11 06:03:12 --> Helper loaded: form_helper
INFO - 2016-02-11 06:03:12 --> Database Driver Class Initialized
INFO - 2016-02-11 06:03:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:03:13 --> Controller Class Initialized
INFO - 2016-02-11 06:03:13 --> Model Class Initialized
INFO - 2016-02-11 06:03:13 --> Model Class Initialized
INFO - 2016-02-11 06:03:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:03:13 --> Pagination Class Initialized
INFO - 2016-02-11 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:03:13 --> Form Validation Class Initialized
INFO - 2016-02-11 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 09:03:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:03:13 --> Final output sent to browser
DEBUG - 2016-02-11 09:03:13 --> Total execution time: 1.1360
INFO - 2016-02-11 06:03:27 --> Config Class Initialized
INFO - 2016-02-11 06:03:27 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:03:27 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:03:27 --> Utf8 Class Initialized
INFO - 2016-02-11 06:03:27 --> URI Class Initialized
INFO - 2016-02-11 06:03:27 --> Router Class Initialized
INFO - 2016-02-11 06:03:27 --> Output Class Initialized
INFO - 2016-02-11 06:03:27 --> Security Class Initialized
DEBUG - 2016-02-11 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:03:27 --> Input Class Initialized
INFO - 2016-02-11 06:03:27 --> Language Class Initialized
INFO - 2016-02-11 06:03:27 --> Loader Class Initialized
INFO - 2016-02-11 06:03:27 --> Helper loaded: url_helper
INFO - 2016-02-11 06:03:27 --> Helper loaded: file_helper
INFO - 2016-02-11 06:03:27 --> Helper loaded: date_helper
INFO - 2016-02-11 06:03:27 --> Helper loaded: form_helper
INFO - 2016-02-11 06:03:27 --> Database Driver Class Initialized
INFO - 2016-02-11 06:03:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:03:28 --> Controller Class Initialized
INFO - 2016-02-11 06:03:28 --> Model Class Initialized
INFO - 2016-02-11 06:03:28 --> Model Class Initialized
INFO - 2016-02-11 06:03:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:03:28 --> Pagination Class Initialized
INFO - 2016-02-11 09:03:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:03:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:03:28 --> Form Validation Class Initialized
INFO - 2016-02-11 09:03:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 09:03:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:03:28 --> Final output sent to browser
DEBUG - 2016-02-11 09:03:29 --> Total execution time: 1.1297
INFO - 2016-02-11 06:05:06 --> Config Class Initialized
INFO - 2016-02-11 06:05:06 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:05:06 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:05:06 --> Utf8 Class Initialized
INFO - 2016-02-11 06:05:06 --> URI Class Initialized
INFO - 2016-02-11 06:05:06 --> Router Class Initialized
INFO - 2016-02-11 06:05:06 --> Output Class Initialized
INFO - 2016-02-11 06:05:06 --> Security Class Initialized
DEBUG - 2016-02-11 06:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:05:06 --> Input Class Initialized
INFO - 2016-02-11 06:05:06 --> Language Class Initialized
INFO - 2016-02-11 06:05:06 --> Loader Class Initialized
INFO - 2016-02-11 06:05:06 --> Helper loaded: url_helper
INFO - 2016-02-11 06:05:06 --> Helper loaded: file_helper
INFO - 2016-02-11 06:05:06 --> Helper loaded: date_helper
INFO - 2016-02-11 06:05:06 --> Helper loaded: form_helper
INFO - 2016-02-11 06:05:06 --> Database Driver Class Initialized
INFO - 2016-02-11 06:05:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:05:07 --> Controller Class Initialized
INFO - 2016-02-11 06:05:07 --> Model Class Initialized
INFO - 2016-02-11 06:05:07 --> Model Class Initialized
INFO - 2016-02-11 06:05:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:05:07 --> Pagination Class Initialized
INFO - 2016-02-11 09:05:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:05:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:05:07 --> Form Validation Class Initialized
INFO - 2016-02-11 09:05:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 09:05:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:05:07 --> Final output sent to browser
DEBUG - 2016-02-11 09:05:07 --> Total execution time: 1.1924
INFO - 2016-02-11 06:05:19 --> Config Class Initialized
INFO - 2016-02-11 06:05:19 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:05:19 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:05:19 --> Utf8 Class Initialized
INFO - 2016-02-11 06:05:19 --> URI Class Initialized
INFO - 2016-02-11 06:05:19 --> Router Class Initialized
INFO - 2016-02-11 06:05:19 --> Output Class Initialized
INFO - 2016-02-11 06:05:19 --> Security Class Initialized
DEBUG - 2016-02-11 06:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:05:19 --> Input Class Initialized
INFO - 2016-02-11 06:05:19 --> Language Class Initialized
INFO - 2016-02-11 06:05:19 --> Loader Class Initialized
INFO - 2016-02-11 06:05:19 --> Helper loaded: url_helper
INFO - 2016-02-11 06:05:19 --> Helper loaded: file_helper
INFO - 2016-02-11 06:05:19 --> Helper loaded: date_helper
INFO - 2016-02-11 06:05:19 --> Helper loaded: form_helper
INFO - 2016-02-11 06:05:19 --> Database Driver Class Initialized
INFO - 2016-02-11 06:05:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:05:20 --> Controller Class Initialized
INFO - 2016-02-11 06:05:20 --> Model Class Initialized
INFO - 2016-02-11 06:05:20 --> Model Class Initialized
INFO - 2016-02-11 06:05:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:05:20 --> Pagination Class Initialized
INFO - 2016-02-11 09:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:05:20 --> Form Validation Class Initialized
INFO - 2016-02-11 09:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-11 09:05:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:05:20 --> Final output sent to browser
DEBUG - 2016-02-11 09:05:20 --> Total execution time: 1.1643
INFO - 2016-02-11 06:06:16 --> Config Class Initialized
INFO - 2016-02-11 06:06:16 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:06:16 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:06:16 --> Utf8 Class Initialized
INFO - 2016-02-11 06:06:16 --> URI Class Initialized
DEBUG - 2016-02-11 06:06:16 --> No URI present. Default controller set.
INFO - 2016-02-11 06:06:16 --> Router Class Initialized
INFO - 2016-02-11 06:06:16 --> Output Class Initialized
INFO - 2016-02-11 06:06:16 --> Security Class Initialized
DEBUG - 2016-02-11 06:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:06:16 --> Input Class Initialized
INFO - 2016-02-11 06:06:16 --> Language Class Initialized
INFO - 2016-02-11 06:06:16 --> Loader Class Initialized
INFO - 2016-02-11 06:06:16 --> Helper loaded: url_helper
INFO - 2016-02-11 06:06:16 --> Helper loaded: file_helper
INFO - 2016-02-11 06:06:16 --> Helper loaded: date_helper
INFO - 2016-02-11 06:06:16 --> Helper loaded: form_helper
INFO - 2016-02-11 06:06:16 --> Database Driver Class Initialized
INFO - 2016-02-11 06:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:06:17 --> Controller Class Initialized
INFO - 2016-02-11 06:06:17 --> Model Class Initialized
INFO - 2016-02-11 06:06:17 --> Model Class Initialized
INFO - 2016-02-11 06:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:06:17 --> Pagination Class Initialized
INFO - 2016-02-11 09:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:06:17 --> Final output sent to browser
DEBUG - 2016-02-11 09:06:17 --> Total execution time: 1.1091
INFO - 2016-02-11 06:11:58 --> Config Class Initialized
INFO - 2016-02-11 06:11:58 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:11:58 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:11:58 --> Utf8 Class Initialized
INFO - 2016-02-11 06:11:58 --> URI Class Initialized
DEBUG - 2016-02-11 06:11:58 --> No URI present. Default controller set.
INFO - 2016-02-11 06:11:58 --> Router Class Initialized
INFO - 2016-02-11 06:11:58 --> Output Class Initialized
INFO - 2016-02-11 06:11:58 --> Security Class Initialized
DEBUG - 2016-02-11 06:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:11:58 --> Input Class Initialized
INFO - 2016-02-11 06:11:58 --> Language Class Initialized
INFO - 2016-02-11 06:11:58 --> Loader Class Initialized
INFO - 2016-02-11 06:11:58 --> Helper loaded: url_helper
INFO - 2016-02-11 06:11:58 --> Helper loaded: file_helper
INFO - 2016-02-11 06:11:58 --> Helper loaded: date_helper
INFO - 2016-02-11 06:11:58 --> Helper loaded: form_helper
INFO - 2016-02-11 06:11:58 --> Database Driver Class Initialized
INFO - 2016-02-11 06:11:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:11:59 --> Controller Class Initialized
INFO - 2016-02-11 06:11:59 --> Model Class Initialized
INFO - 2016-02-11 06:11:59 --> Model Class Initialized
INFO - 2016-02-11 06:11:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:11:59 --> Pagination Class Initialized
INFO - 2016-02-11 09:11:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:11:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:11:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:11:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:11:59 --> Final output sent to browser
DEBUG - 2016-02-11 09:11:59 --> Total execution time: 1.1568
INFO - 2016-02-11 06:12:13 --> Config Class Initialized
INFO - 2016-02-11 06:12:13 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:12:13 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:12:13 --> Utf8 Class Initialized
INFO - 2016-02-11 06:12:13 --> URI Class Initialized
INFO - 2016-02-11 06:12:13 --> Router Class Initialized
INFO - 2016-02-11 06:12:13 --> Output Class Initialized
INFO - 2016-02-11 06:12:13 --> Security Class Initialized
DEBUG - 2016-02-11 06:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:12:13 --> Input Class Initialized
INFO - 2016-02-11 06:12:13 --> Language Class Initialized
INFO - 2016-02-11 06:12:13 --> Loader Class Initialized
INFO - 2016-02-11 06:12:13 --> Helper loaded: url_helper
INFO - 2016-02-11 06:12:13 --> Helper loaded: file_helper
INFO - 2016-02-11 06:12:13 --> Helper loaded: date_helper
INFO - 2016-02-11 06:12:13 --> Helper loaded: form_helper
INFO - 2016-02-11 06:12:13 --> Database Driver Class Initialized
INFO - 2016-02-11 06:12:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:12:14 --> Controller Class Initialized
INFO - 2016-02-11 06:12:14 --> Model Class Initialized
INFO - 2016-02-11 06:12:14 --> Model Class Initialized
INFO - 2016-02-11 06:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:12:14 --> Pagination Class Initialized
INFO - 2016-02-11 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:12:14 --> Final output sent to browser
DEBUG - 2016-02-11 09:12:14 --> Total execution time: 1.1533
INFO - 2016-02-11 06:12:16 --> Config Class Initialized
INFO - 2016-02-11 06:12:16 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:12:16 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:12:16 --> Utf8 Class Initialized
INFO - 2016-02-11 06:12:16 --> URI Class Initialized
INFO - 2016-02-11 06:12:16 --> Router Class Initialized
INFO - 2016-02-11 06:12:16 --> Output Class Initialized
INFO - 2016-02-11 06:12:16 --> Security Class Initialized
DEBUG - 2016-02-11 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:12:16 --> Input Class Initialized
INFO - 2016-02-11 06:12:16 --> Language Class Initialized
INFO - 2016-02-11 06:12:16 --> Loader Class Initialized
INFO - 2016-02-11 06:12:16 --> Helper loaded: url_helper
INFO - 2016-02-11 06:12:16 --> Helper loaded: file_helper
INFO - 2016-02-11 06:12:16 --> Helper loaded: date_helper
INFO - 2016-02-11 06:12:16 --> Helper loaded: form_helper
INFO - 2016-02-11 06:12:16 --> Database Driver Class Initialized
INFO - 2016-02-11 06:12:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:12:17 --> Controller Class Initialized
INFO - 2016-02-11 06:12:17 --> Model Class Initialized
INFO - 2016-02-11 06:12:17 --> Model Class Initialized
INFO - 2016-02-11 06:12:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:12:17 --> Pagination Class Initialized
INFO - 2016-02-11 09:12:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:12:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:12:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:12:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:12:17 --> Final output sent to browser
DEBUG - 2016-02-11 09:12:17 --> Total execution time: 1.1302
INFO - 2016-02-11 06:12:30 --> Config Class Initialized
INFO - 2016-02-11 06:12:30 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:12:30 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:12:30 --> Utf8 Class Initialized
INFO - 2016-02-11 06:12:30 --> URI Class Initialized
INFO - 2016-02-11 06:12:30 --> Router Class Initialized
INFO - 2016-02-11 06:12:30 --> Output Class Initialized
INFO - 2016-02-11 06:12:30 --> Security Class Initialized
DEBUG - 2016-02-11 06:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:12:30 --> Input Class Initialized
INFO - 2016-02-11 06:12:30 --> Language Class Initialized
INFO - 2016-02-11 06:12:30 --> Loader Class Initialized
INFO - 2016-02-11 06:12:30 --> Helper loaded: url_helper
INFO - 2016-02-11 06:12:30 --> Helper loaded: file_helper
INFO - 2016-02-11 06:12:30 --> Helper loaded: date_helper
INFO - 2016-02-11 06:12:30 --> Helper loaded: form_helper
INFO - 2016-02-11 06:12:30 --> Database Driver Class Initialized
INFO - 2016-02-11 06:12:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:12:31 --> Controller Class Initialized
INFO - 2016-02-11 06:12:31 --> Model Class Initialized
INFO - 2016-02-11 06:12:31 --> Model Class Initialized
INFO - 2016-02-11 06:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:12:31 --> Pagination Class Initialized
INFO - 2016-02-11 09:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:12:31 --> Final output sent to browser
DEBUG - 2016-02-11 09:12:31 --> Total execution time: 1.1375
INFO - 2016-02-11 06:12:40 --> Config Class Initialized
INFO - 2016-02-11 06:12:40 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:12:40 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:12:40 --> Utf8 Class Initialized
INFO - 2016-02-11 06:12:40 --> URI Class Initialized
INFO - 2016-02-11 06:12:40 --> Router Class Initialized
INFO - 2016-02-11 06:12:40 --> Output Class Initialized
INFO - 2016-02-11 06:12:40 --> Security Class Initialized
DEBUG - 2016-02-11 06:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:12:40 --> Input Class Initialized
INFO - 2016-02-11 06:12:40 --> Language Class Initialized
INFO - 2016-02-11 06:12:40 --> Loader Class Initialized
INFO - 2016-02-11 06:12:40 --> Helper loaded: url_helper
INFO - 2016-02-11 06:12:40 --> Helper loaded: file_helper
INFO - 2016-02-11 06:12:40 --> Helper loaded: date_helper
INFO - 2016-02-11 06:12:40 --> Helper loaded: form_helper
INFO - 2016-02-11 06:12:40 --> Database Driver Class Initialized
INFO - 2016-02-11 06:12:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:12:41 --> Controller Class Initialized
INFO - 2016-02-11 06:12:41 --> Model Class Initialized
INFO - 2016-02-11 06:12:41 --> Model Class Initialized
INFO - 2016-02-11 06:12:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:12:41 --> Pagination Class Initialized
INFO - 2016-02-11 09:12:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:12:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:12:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:12:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:12:41 --> Final output sent to browser
DEBUG - 2016-02-11 09:12:41 --> Total execution time: 1.1191
INFO - 2016-02-11 06:12:43 --> Config Class Initialized
INFO - 2016-02-11 06:12:43 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:12:43 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:12:43 --> Utf8 Class Initialized
INFO - 2016-02-11 06:12:43 --> URI Class Initialized
INFO - 2016-02-11 06:12:43 --> Router Class Initialized
INFO - 2016-02-11 06:12:43 --> Output Class Initialized
INFO - 2016-02-11 06:12:43 --> Security Class Initialized
DEBUG - 2016-02-11 06:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:12:43 --> Input Class Initialized
INFO - 2016-02-11 06:12:43 --> Language Class Initialized
INFO - 2016-02-11 06:12:43 --> Loader Class Initialized
INFO - 2016-02-11 06:12:43 --> Helper loaded: url_helper
INFO - 2016-02-11 06:12:43 --> Helper loaded: file_helper
INFO - 2016-02-11 06:12:43 --> Helper loaded: date_helper
INFO - 2016-02-11 06:12:43 --> Helper loaded: form_helper
INFO - 2016-02-11 06:12:43 --> Database Driver Class Initialized
INFO - 2016-02-11 06:12:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:12:44 --> Controller Class Initialized
INFO - 2016-02-11 06:12:44 --> Model Class Initialized
INFO - 2016-02-11 06:12:44 --> Model Class Initialized
INFO - 2016-02-11 06:12:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:12:44 --> Pagination Class Initialized
INFO - 2016-02-11 09:12:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:12:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:12:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:12:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:12:44 --> Final output sent to browser
DEBUG - 2016-02-11 09:12:44 --> Total execution time: 1.1171
INFO - 2016-02-11 06:27:34 --> Config Class Initialized
INFO - 2016-02-11 06:27:34 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:27:34 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:27:34 --> Utf8 Class Initialized
INFO - 2016-02-11 06:27:34 --> URI Class Initialized
DEBUG - 2016-02-11 06:27:34 --> No URI present. Default controller set.
INFO - 2016-02-11 06:27:34 --> Router Class Initialized
INFO - 2016-02-11 06:27:34 --> Output Class Initialized
INFO - 2016-02-11 06:27:34 --> Security Class Initialized
DEBUG - 2016-02-11 06:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:27:34 --> Input Class Initialized
INFO - 2016-02-11 06:27:34 --> Language Class Initialized
INFO - 2016-02-11 06:27:34 --> Loader Class Initialized
INFO - 2016-02-11 06:27:34 --> Helper loaded: url_helper
INFO - 2016-02-11 06:27:34 --> Helper loaded: file_helper
INFO - 2016-02-11 06:27:34 --> Helper loaded: date_helper
INFO - 2016-02-11 06:27:34 --> Helper loaded: form_helper
INFO - 2016-02-11 06:27:34 --> Database Driver Class Initialized
INFO - 2016-02-11 06:27:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:27:35 --> Controller Class Initialized
INFO - 2016-02-11 06:27:35 --> Model Class Initialized
INFO - 2016-02-11 06:27:35 --> Model Class Initialized
INFO - 2016-02-11 06:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:27:35 --> Pagination Class Initialized
INFO - 2016-02-11 09:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:27:35 --> Final output sent to browser
DEBUG - 2016-02-11 09:27:35 --> Total execution time: 1.1444
INFO - 2016-02-11 06:27:40 --> Config Class Initialized
INFO - 2016-02-11 06:27:40 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:27:40 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:27:40 --> Utf8 Class Initialized
INFO - 2016-02-11 06:27:40 --> URI Class Initialized
INFO - 2016-02-11 06:27:40 --> Router Class Initialized
INFO - 2016-02-11 06:27:40 --> Output Class Initialized
INFO - 2016-02-11 06:27:40 --> Security Class Initialized
DEBUG - 2016-02-11 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:27:40 --> Input Class Initialized
INFO - 2016-02-11 06:27:40 --> Language Class Initialized
INFO - 2016-02-11 06:27:40 --> Loader Class Initialized
INFO - 2016-02-11 06:27:40 --> Helper loaded: url_helper
INFO - 2016-02-11 06:27:40 --> Helper loaded: file_helper
INFO - 2016-02-11 06:27:40 --> Helper loaded: date_helper
INFO - 2016-02-11 06:27:40 --> Helper loaded: form_helper
INFO - 2016-02-11 06:27:40 --> Database Driver Class Initialized
INFO - 2016-02-11 06:27:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:27:41 --> Controller Class Initialized
INFO - 2016-02-11 06:27:41 --> Model Class Initialized
INFO - 2016-02-11 06:27:41 --> Model Class Initialized
INFO - 2016-02-11 06:27:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:27:41 --> Pagination Class Initialized
INFO - 2016-02-11 09:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:27:41 --> Helper loaded: text_helper
INFO - 2016-02-11 09:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 09:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 09:27:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:27:41 --> Final output sent to browser
DEBUG - 2016-02-11 09:27:41 --> Total execution time: 1.2138
INFO - 2016-02-11 06:38:39 --> Config Class Initialized
INFO - 2016-02-11 06:38:39 --> Hooks Class Initialized
DEBUG - 2016-02-11 06:38:39 --> UTF-8 Support Enabled
INFO - 2016-02-11 06:38:39 --> Utf8 Class Initialized
INFO - 2016-02-11 06:38:39 --> URI Class Initialized
DEBUG - 2016-02-11 06:38:39 --> No URI present. Default controller set.
INFO - 2016-02-11 06:38:39 --> Router Class Initialized
INFO - 2016-02-11 06:38:39 --> Output Class Initialized
INFO - 2016-02-11 06:38:39 --> Security Class Initialized
DEBUG - 2016-02-11 06:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 06:38:39 --> Input Class Initialized
INFO - 2016-02-11 06:38:39 --> Language Class Initialized
INFO - 2016-02-11 06:38:39 --> Loader Class Initialized
INFO - 2016-02-11 06:38:39 --> Helper loaded: url_helper
INFO - 2016-02-11 06:38:39 --> Helper loaded: file_helper
INFO - 2016-02-11 06:38:39 --> Helper loaded: date_helper
INFO - 2016-02-11 06:38:40 --> Helper loaded: form_helper
INFO - 2016-02-11 06:38:40 --> Database Driver Class Initialized
INFO - 2016-02-11 06:38:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 06:38:41 --> Controller Class Initialized
INFO - 2016-02-11 06:38:41 --> Model Class Initialized
INFO - 2016-02-11 06:38:41 --> Model Class Initialized
INFO - 2016-02-11 06:38:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 06:38:41 --> Pagination Class Initialized
INFO - 2016-02-11 09:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 09:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 09:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 09:38:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 09:38:41 --> Final output sent to browser
DEBUG - 2016-02-11 09:38:41 --> Total execution time: 1.1540
INFO - 2016-02-11 09:35:08 --> Config Class Initialized
INFO - 2016-02-11 09:35:08 --> Hooks Class Initialized
DEBUG - 2016-02-11 09:35:08 --> UTF-8 Support Enabled
INFO - 2016-02-11 09:35:08 --> Utf8 Class Initialized
INFO - 2016-02-11 09:35:08 --> URI Class Initialized
DEBUG - 2016-02-11 09:35:08 --> No URI present. Default controller set.
INFO - 2016-02-11 09:35:08 --> Router Class Initialized
INFO - 2016-02-11 09:35:08 --> Output Class Initialized
INFO - 2016-02-11 09:35:08 --> Security Class Initialized
DEBUG - 2016-02-11 09:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 09:35:08 --> Input Class Initialized
INFO - 2016-02-11 09:35:08 --> Language Class Initialized
INFO - 2016-02-11 09:35:08 --> Loader Class Initialized
INFO - 2016-02-11 09:35:08 --> Helper loaded: url_helper
INFO - 2016-02-11 09:35:08 --> Helper loaded: file_helper
INFO - 2016-02-11 09:35:08 --> Helper loaded: date_helper
INFO - 2016-02-11 09:35:08 --> Helper loaded: form_helper
INFO - 2016-02-11 09:35:08 --> Database Driver Class Initialized
INFO - 2016-02-11 09:35:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 09:35:09 --> Controller Class Initialized
INFO - 2016-02-11 09:35:09 --> Model Class Initialized
INFO - 2016-02-11 09:35:09 --> Model Class Initialized
INFO - 2016-02-11 09:35:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 09:35:09 --> Pagination Class Initialized
INFO - 2016-02-11 12:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 12:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 12:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 12:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 12:35:09 --> Final output sent to browser
DEBUG - 2016-02-11 12:35:09 --> Total execution time: 1.3026
INFO - 2016-02-11 09:35:11 --> Config Class Initialized
INFO - 2016-02-11 09:35:11 --> Hooks Class Initialized
DEBUG - 2016-02-11 09:35:11 --> UTF-8 Support Enabled
INFO - 2016-02-11 09:35:11 --> Utf8 Class Initialized
INFO - 2016-02-11 09:35:11 --> URI Class Initialized
INFO - 2016-02-11 09:35:11 --> Router Class Initialized
INFO - 2016-02-11 09:35:11 --> Output Class Initialized
INFO - 2016-02-11 09:35:11 --> Security Class Initialized
DEBUG - 2016-02-11 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 09:35:11 --> Input Class Initialized
INFO - 2016-02-11 09:35:11 --> Language Class Initialized
INFO - 2016-02-11 09:35:11 --> Loader Class Initialized
INFO - 2016-02-11 09:35:11 --> Helper loaded: url_helper
INFO - 2016-02-11 09:35:11 --> Helper loaded: file_helper
INFO - 2016-02-11 09:35:11 --> Helper loaded: date_helper
INFO - 2016-02-11 09:35:11 --> Helper loaded: form_helper
INFO - 2016-02-11 09:35:11 --> Database Driver Class Initialized
INFO - 2016-02-11 09:35:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 09:35:12 --> Controller Class Initialized
INFO - 2016-02-11 09:35:12 --> Model Class Initialized
INFO - 2016-02-11 09:35:12 --> Model Class Initialized
INFO - 2016-02-11 09:35:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 09:35:12 --> Pagination Class Initialized
INFO - 2016-02-11 12:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 12:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 12:35:12 --> Helper loaded: text_helper
INFO - 2016-02-11 12:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 12:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 12:35:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 12:35:12 --> Final output sent to browser
DEBUG - 2016-02-11 12:35:12 --> Total execution time: 1.1551
INFO - 2016-02-11 09:35:50 --> Config Class Initialized
INFO - 2016-02-11 09:35:50 --> Hooks Class Initialized
DEBUG - 2016-02-11 09:35:50 --> UTF-8 Support Enabled
INFO - 2016-02-11 09:35:50 --> Utf8 Class Initialized
INFO - 2016-02-11 09:35:50 --> URI Class Initialized
INFO - 2016-02-11 09:35:50 --> Router Class Initialized
INFO - 2016-02-11 09:35:50 --> Output Class Initialized
INFO - 2016-02-11 09:35:50 --> Security Class Initialized
DEBUG - 2016-02-11 09:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 09:35:50 --> Input Class Initialized
INFO - 2016-02-11 09:35:50 --> Language Class Initialized
INFO - 2016-02-11 09:35:50 --> Loader Class Initialized
INFO - 2016-02-11 09:35:50 --> Helper loaded: url_helper
INFO - 2016-02-11 09:35:50 --> Helper loaded: file_helper
INFO - 2016-02-11 09:35:50 --> Helper loaded: date_helper
INFO - 2016-02-11 09:35:50 --> Helper loaded: form_helper
INFO - 2016-02-11 09:35:50 --> Database Driver Class Initialized
INFO - 2016-02-11 09:35:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 09:35:51 --> Controller Class Initialized
INFO - 2016-02-11 09:35:51 --> Model Class Initialized
INFO - 2016-02-11 09:35:51 --> Model Class Initialized
INFO - 2016-02-11 09:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 09:35:51 --> Pagination Class Initialized
INFO - 2016-02-11 12:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 12:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 12:35:51 --> Helper loaded: text_helper
INFO - 2016-02-11 12:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 12:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 12:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 12:35:51 --> Final output sent to browser
DEBUG - 2016-02-11 12:35:51 --> Total execution time: 1.2247
INFO - 2016-02-11 10:01:21 --> Config Class Initialized
INFO - 2016-02-11 10:01:21 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:01:21 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:01:21 --> Utf8 Class Initialized
INFO - 2016-02-11 10:01:21 --> URI Class Initialized
INFO - 2016-02-11 10:01:21 --> Router Class Initialized
INFO - 2016-02-11 10:01:21 --> Output Class Initialized
INFO - 2016-02-11 10:01:21 --> Security Class Initialized
DEBUG - 2016-02-11 10:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:01:21 --> Input Class Initialized
INFO - 2016-02-11 10:01:21 --> Language Class Initialized
INFO - 2016-02-11 10:01:21 --> Loader Class Initialized
INFO - 2016-02-11 10:01:21 --> Helper loaded: url_helper
INFO - 2016-02-11 10:01:21 --> Helper loaded: file_helper
INFO - 2016-02-11 10:01:21 --> Helper loaded: date_helper
INFO - 2016-02-11 10:01:21 --> Helper loaded: form_helper
INFO - 2016-02-11 10:01:21 --> Database Driver Class Initialized
INFO - 2016-02-11 10:01:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:01:22 --> Controller Class Initialized
INFO - 2016-02-11 10:01:22 --> Model Class Initialized
INFO - 2016-02-11 10:01:22 --> Model Class Initialized
INFO - 2016-02-11 10:01:22 --> Form Validation Class Initialized
INFO - 2016-02-11 10:01:22 --> Helper loaded: text_helper
INFO - 2016-02-11 10:01:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 10:01:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 10:01:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-11 10:01:22 --> Final output sent to browser
DEBUG - 2016-02-11 10:01:22 --> Total execution time: 1.1112
INFO - 2016-02-11 10:01:26 --> Config Class Initialized
INFO - 2016-02-11 10:01:26 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:01:26 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:01:26 --> Utf8 Class Initialized
INFO - 2016-02-11 10:01:26 --> URI Class Initialized
INFO - 2016-02-11 10:01:26 --> Router Class Initialized
INFO - 2016-02-11 10:01:26 --> Output Class Initialized
INFO - 2016-02-11 10:01:26 --> Security Class Initialized
DEBUG - 2016-02-11 10:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:01:26 --> Input Class Initialized
INFO - 2016-02-11 10:01:26 --> Language Class Initialized
INFO - 2016-02-11 10:01:26 --> Loader Class Initialized
INFO - 2016-02-11 10:01:26 --> Helper loaded: url_helper
INFO - 2016-02-11 10:01:26 --> Helper loaded: file_helper
INFO - 2016-02-11 10:01:26 --> Helper loaded: date_helper
INFO - 2016-02-11 10:01:26 --> Helper loaded: form_helper
INFO - 2016-02-11 10:01:26 --> Database Driver Class Initialized
INFO - 2016-02-11 10:01:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:01:27 --> Controller Class Initialized
INFO - 2016-02-11 10:01:27 --> Model Class Initialized
INFO - 2016-02-11 10:01:27 --> Model Class Initialized
INFO - 2016-02-11 10:01:27 --> Form Validation Class Initialized
INFO - 2016-02-11 10:01:27 --> Helper loaded: text_helper
INFO - 2016-02-11 10:01:27 --> Config Class Initialized
INFO - 2016-02-11 10:01:27 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:01:27 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:01:27 --> Utf8 Class Initialized
INFO - 2016-02-11 10:01:27 --> URI Class Initialized
INFO - 2016-02-11 10:01:27 --> Router Class Initialized
INFO - 2016-02-11 10:01:27 --> Output Class Initialized
INFO - 2016-02-11 10:01:27 --> Security Class Initialized
DEBUG - 2016-02-11 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:01:27 --> Input Class Initialized
INFO - 2016-02-11 10:01:27 --> Language Class Initialized
INFO - 2016-02-11 10:01:27 --> Loader Class Initialized
INFO - 2016-02-11 10:01:27 --> Helper loaded: url_helper
INFO - 2016-02-11 10:01:27 --> Helper loaded: file_helper
INFO - 2016-02-11 10:01:27 --> Helper loaded: date_helper
INFO - 2016-02-11 10:01:27 --> Helper loaded: form_helper
INFO - 2016-02-11 10:01:27 --> Database Driver Class Initialized
INFO - 2016-02-11 10:01:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:01:28 --> Controller Class Initialized
INFO - 2016-02-11 10:01:28 --> Model Class Initialized
ERROR - 2016-02-11 10:01:28 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 98
INFO - 2016-02-11 10:01:55 --> Config Class Initialized
INFO - 2016-02-11 10:01:55 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:01:55 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:01:55 --> Utf8 Class Initialized
INFO - 2016-02-11 10:01:55 --> URI Class Initialized
INFO - 2016-02-11 10:01:55 --> Router Class Initialized
INFO - 2016-02-11 10:01:55 --> Output Class Initialized
INFO - 2016-02-11 10:01:55 --> Security Class Initialized
DEBUG - 2016-02-11 10:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:01:55 --> Input Class Initialized
INFO - 2016-02-11 10:01:55 --> Language Class Initialized
INFO - 2016-02-11 10:01:55 --> Loader Class Initialized
INFO - 2016-02-11 10:01:55 --> Helper loaded: url_helper
INFO - 2016-02-11 10:01:55 --> Helper loaded: file_helper
INFO - 2016-02-11 10:01:55 --> Helper loaded: date_helper
INFO - 2016-02-11 10:01:55 --> Helper loaded: form_helper
INFO - 2016-02-11 10:01:55 --> Database Driver Class Initialized
INFO - 2016-02-11 10:01:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:01:56 --> Controller Class Initialized
INFO - 2016-02-11 10:01:56 --> Model Class Initialized
ERROR - 2016-02-11 10:01:56 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 106
INFO - 2016-02-11 10:02:08 --> Config Class Initialized
INFO - 2016-02-11 10:02:08 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:02:08 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:02:08 --> Utf8 Class Initialized
INFO - 2016-02-11 10:02:08 --> URI Class Initialized
INFO - 2016-02-11 10:02:08 --> Router Class Initialized
INFO - 2016-02-11 10:02:08 --> Output Class Initialized
INFO - 2016-02-11 10:02:08 --> Security Class Initialized
DEBUG - 2016-02-11 10:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:02:08 --> Input Class Initialized
INFO - 2016-02-11 10:02:08 --> Language Class Initialized
INFO - 2016-02-11 10:02:08 --> Loader Class Initialized
INFO - 2016-02-11 10:02:08 --> Helper loaded: url_helper
INFO - 2016-02-11 10:02:08 --> Helper loaded: file_helper
INFO - 2016-02-11 10:02:08 --> Helper loaded: date_helper
INFO - 2016-02-11 10:02:08 --> Helper loaded: form_helper
INFO - 2016-02-11 10:02:08 --> Database Driver Class Initialized
INFO - 2016-02-11 10:02:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:02:09 --> Controller Class Initialized
INFO - 2016-02-11 10:02:09 --> Model Class Initialized
INFO - 2016-02-11 10:02:09 --> Model Class Initialized
INFO - 2016-02-11 10:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:02:09 --> Pagination Class Initialized
INFO - 2016-02-11 13:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 13:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:02:09 --> Final output sent to browser
DEBUG - 2016-02-11 13:02:09 --> Total execution time: 1.1503
INFO - 2016-02-11 10:07:10 --> Config Class Initialized
INFO - 2016-02-11 10:07:10 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:07:10 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:07:10 --> Utf8 Class Initialized
INFO - 2016-02-11 10:07:10 --> URI Class Initialized
INFO - 2016-02-11 10:07:10 --> Router Class Initialized
INFO - 2016-02-11 10:07:10 --> Output Class Initialized
INFO - 2016-02-11 10:07:10 --> Security Class Initialized
DEBUG - 2016-02-11 10:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:07:10 --> Input Class Initialized
INFO - 2016-02-11 10:07:10 --> Language Class Initialized
INFO - 2016-02-11 10:07:10 --> Loader Class Initialized
INFO - 2016-02-11 10:07:10 --> Helper loaded: url_helper
INFO - 2016-02-11 10:07:10 --> Helper loaded: file_helper
INFO - 2016-02-11 10:07:10 --> Helper loaded: date_helper
INFO - 2016-02-11 10:07:10 --> Helper loaded: form_helper
INFO - 2016-02-11 10:07:10 --> Database Driver Class Initialized
INFO - 2016-02-11 10:07:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:07:11 --> Controller Class Initialized
INFO - 2016-02-11 10:07:11 --> Model Class Initialized
INFO - 2016-02-11 10:07:11 --> Model Class Initialized
INFO - 2016-02-11 10:07:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:07:11 --> Pagination Class Initialized
INFO - 2016-02-11 13:07:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:07:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:07:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 13:07:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:07:11 --> Final output sent to browser
DEBUG - 2016-02-11 13:07:11 --> Total execution time: 1.1462
INFO - 2016-02-11 10:07:13 --> Config Class Initialized
INFO - 2016-02-11 10:07:13 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:07:13 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:07:13 --> Utf8 Class Initialized
INFO - 2016-02-11 10:07:13 --> URI Class Initialized
INFO - 2016-02-11 10:07:13 --> Router Class Initialized
INFO - 2016-02-11 10:07:13 --> Output Class Initialized
INFO - 2016-02-11 10:07:13 --> Security Class Initialized
DEBUG - 2016-02-11 10:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:07:13 --> Input Class Initialized
INFO - 2016-02-11 10:07:13 --> Language Class Initialized
INFO - 2016-02-11 10:07:13 --> Loader Class Initialized
INFO - 2016-02-11 10:07:13 --> Helper loaded: url_helper
INFO - 2016-02-11 10:07:13 --> Helper loaded: file_helper
INFO - 2016-02-11 10:07:13 --> Helper loaded: date_helper
INFO - 2016-02-11 10:07:13 --> Helper loaded: form_helper
INFO - 2016-02-11 10:07:13 --> Database Driver Class Initialized
INFO - 2016-02-11 10:07:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:07:14 --> Controller Class Initialized
INFO - 2016-02-11 10:07:14 --> Model Class Initialized
INFO - 2016-02-11 10:07:14 --> Model Class Initialized
INFO - 2016-02-11 10:07:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:07:14 --> Pagination Class Initialized
INFO - 2016-02-11 13:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:07:14 --> Helper loaded: text_helper
INFO - 2016-02-11 13:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:07:14 --> Final output sent to browser
DEBUG - 2016-02-11 13:07:14 --> Total execution time: 1.2190
INFO - 2016-02-11 10:08:12 --> Config Class Initialized
INFO - 2016-02-11 10:08:12 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:08:12 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:08:12 --> Utf8 Class Initialized
INFO - 2016-02-11 10:08:12 --> URI Class Initialized
INFO - 2016-02-11 10:08:12 --> Router Class Initialized
INFO - 2016-02-11 10:08:12 --> Output Class Initialized
INFO - 2016-02-11 10:08:12 --> Security Class Initialized
DEBUG - 2016-02-11 10:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:08:12 --> Input Class Initialized
INFO - 2016-02-11 10:08:12 --> Language Class Initialized
INFO - 2016-02-11 10:08:12 --> Loader Class Initialized
INFO - 2016-02-11 10:08:12 --> Helper loaded: url_helper
INFO - 2016-02-11 10:08:12 --> Helper loaded: file_helper
INFO - 2016-02-11 10:08:12 --> Helper loaded: date_helper
INFO - 2016-02-11 10:08:12 --> Helper loaded: form_helper
INFO - 2016-02-11 10:08:12 --> Database Driver Class Initialized
INFO - 2016-02-11 10:08:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:08:13 --> Controller Class Initialized
INFO - 2016-02-11 10:08:13 --> Model Class Initialized
INFO - 2016-02-11 10:08:13 --> Model Class Initialized
INFO - 2016-02-11 10:08:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:08:13 --> Pagination Class Initialized
INFO - 2016-02-11 13:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:08:13 --> Helper loaded: text_helper
INFO - 2016-02-11 13:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:08:13 --> Final output sent to browser
DEBUG - 2016-02-11 13:08:13 --> Total execution time: 1.1617
INFO - 2016-02-11 10:09:18 --> Config Class Initialized
INFO - 2016-02-11 10:09:18 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:09:18 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:09:18 --> Utf8 Class Initialized
INFO - 2016-02-11 10:09:18 --> URI Class Initialized
INFO - 2016-02-11 10:09:18 --> Router Class Initialized
INFO - 2016-02-11 10:09:18 --> Output Class Initialized
INFO - 2016-02-11 10:09:18 --> Security Class Initialized
DEBUG - 2016-02-11 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:09:18 --> Input Class Initialized
INFO - 2016-02-11 10:09:18 --> Language Class Initialized
INFO - 2016-02-11 10:09:18 --> Loader Class Initialized
INFO - 2016-02-11 10:09:18 --> Helper loaded: url_helper
INFO - 2016-02-11 10:09:18 --> Helper loaded: file_helper
INFO - 2016-02-11 10:09:18 --> Helper loaded: date_helper
INFO - 2016-02-11 10:09:18 --> Helper loaded: form_helper
INFO - 2016-02-11 10:09:18 --> Database Driver Class Initialized
INFO - 2016-02-11 10:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:09:19 --> Controller Class Initialized
INFO - 2016-02-11 10:09:19 --> Model Class Initialized
INFO - 2016-02-11 10:09:19 --> Model Class Initialized
INFO - 2016-02-11 10:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:09:19 --> Pagination Class Initialized
INFO - 2016-02-11 13:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:09:19 --> Helper loaded: text_helper
INFO - 2016-02-11 13:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:09:20 --> Final output sent to browser
DEBUG - 2016-02-11 13:09:20 --> Total execution time: 1.1831
INFO - 2016-02-11 10:14:49 --> Config Class Initialized
INFO - 2016-02-11 10:14:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:14:49 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:14:49 --> Utf8 Class Initialized
INFO - 2016-02-11 10:14:49 --> URI Class Initialized
INFO - 2016-02-11 10:14:49 --> Router Class Initialized
INFO - 2016-02-11 10:14:49 --> Output Class Initialized
INFO - 2016-02-11 10:14:49 --> Security Class Initialized
DEBUG - 2016-02-11 10:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:14:49 --> Input Class Initialized
INFO - 2016-02-11 10:14:49 --> Language Class Initialized
INFO - 2016-02-11 10:14:49 --> Loader Class Initialized
INFO - 2016-02-11 10:14:49 --> Helper loaded: url_helper
INFO - 2016-02-11 10:14:49 --> Helper loaded: file_helper
INFO - 2016-02-11 10:14:49 --> Helper loaded: date_helper
INFO - 2016-02-11 10:14:49 --> Helper loaded: form_helper
INFO - 2016-02-11 10:14:49 --> Database Driver Class Initialized
INFO - 2016-02-11 10:14:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:14:50 --> Controller Class Initialized
INFO - 2016-02-11 10:14:50 --> Model Class Initialized
INFO - 2016-02-11 10:14:50 --> Model Class Initialized
INFO - 2016-02-11 10:14:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:14:50 --> Pagination Class Initialized
INFO - 2016-02-11 13:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:14:50 --> Helper loaded: text_helper
INFO - 2016-02-11 13:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:14:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:14:50 --> Final output sent to browser
DEBUG - 2016-02-11 13:14:50 --> Total execution time: 1.1951
INFO - 2016-02-11 10:17:40 --> Config Class Initialized
INFO - 2016-02-11 10:17:40 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:17:40 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:17:40 --> Utf8 Class Initialized
INFO - 2016-02-11 10:17:40 --> URI Class Initialized
INFO - 2016-02-11 10:17:40 --> Router Class Initialized
INFO - 2016-02-11 10:17:40 --> Output Class Initialized
INFO - 2016-02-11 10:17:40 --> Security Class Initialized
DEBUG - 2016-02-11 10:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:17:40 --> Input Class Initialized
INFO - 2016-02-11 10:17:40 --> Language Class Initialized
INFO - 2016-02-11 10:17:40 --> Loader Class Initialized
INFO - 2016-02-11 10:17:40 --> Helper loaded: url_helper
INFO - 2016-02-11 10:17:40 --> Helper loaded: file_helper
INFO - 2016-02-11 10:17:40 --> Helper loaded: date_helper
INFO - 2016-02-11 10:17:40 --> Helper loaded: form_helper
INFO - 2016-02-11 10:17:40 --> Database Driver Class Initialized
INFO - 2016-02-11 10:17:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:17:41 --> Controller Class Initialized
INFO - 2016-02-11 10:17:41 --> Model Class Initialized
INFO - 2016-02-11 10:17:41 --> Model Class Initialized
INFO - 2016-02-11 10:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:17:41 --> Pagination Class Initialized
INFO - 2016-02-11 13:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:17:41 --> Helper loaded: text_helper
INFO - 2016-02-11 13:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:17:41 --> Final output sent to browser
DEBUG - 2016-02-11 13:17:41 --> Total execution time: 1.2008
INFO - 2016-02-11 10:18:18 --> Config Class Initialized
INFO - 2016-02-11 10:18:18 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:18:18 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:18:18 --> Utf8 Class Initialized
INFO - 2016-02-11 10:18:18 --> URI Class Initialized
INFO - 2016-02-11 10:18:18 --> Router Class Initialized
INFO - 2016-02-11 10:18:18 --> Output Class Initialized
INFO - 2016-02-11 10:18:18 --> Security Class Initialized
DEBUG - 2016-02-11 10:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:18:18 --> Input Class Initialized
INFO - 2016-02-11 10:18:18 --> Language Class Initialized
INFO - 2016-02-11 10:18:18 --> Loader Class Initialized
INFO - 2016-02-11 10:18:18 --> Helper loaded: url_helper
INFO - 2016-02-11 10:18:18 --> Helper loaded: file_helper
INFO - 2016-02-11 10:18:18 --> Helper loaded: date_helper
INFO - 2016-02-11 10:18:18 --> Helper loaded: form_helper
INFO - 2016-02-11 10:18:18 --> Database Driver Class Initialized
INFO - 2016-02-11 10:18:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:18:19 --> Controller Class Initialized
INFO - 2016-02-11 10:18:19 --> Model Class Initialized
INFO - 2016-02-11 10:18:19 --> Model Class Initialized
INFO - 2016-02-11 10:18:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:18:19 --> Pagination Class Initialized
INFO - 2016-02-11 13:18:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:18:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:18:19 --> Helper loaded: text_helper
INFO - 2016-02-11 13:18:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:18:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:18:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:18:19 --> Final output sent to browser
DEBUG - 2016-02-11 13:18:19 --> Total execution time: 1.1711
INFO - 2016-02-11 10:42:31 --> Config Class Initialized
INFO - 2016-02-11 10:42:31 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:42:31 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:42:31 --> Utf8 Class Initialized
INFO - 2016-02-11 10:42:31 --> URI Class Initialized
INFO - 2016-02-11 10:42:31 --> Router Class Initialized
INFO - 2016-02-11 10:42:31 --> Output Class Initialized
INFO - 2016-02-11 10:42:31 --> Security Class Initialized
DEBUG - 2016-02-11 10:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:42:31 --> Input Class Initialized
INFO - 2016-02-11 10:42:31 --> Language Class Initialized
INFO - 2016-02-11 10:42:31 --> Loader Class Initialized
INFO - 2016-02-11 10:42:31 --> Helper loaded: url_helper
INFO - 2016-02-11 10:42:31 --> Helper loaded: file_helper
INFO - 2016-02-11 10:42:31 --> Helper loaded: date_helper
INFO - 2016-02-11 10:42:31 --> Helper loaded: form_helper
INFO - 2016-02-11 10:42:31 --> Database Driver Class Initialized
INFO - 2016-02-11 10:42:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:42:32 --> Controller Class Initialized
INFO - 2016-02-11 10:42:32 --> Model Class Initialized
INFO - 2016-02-11 10:42:32 --> Model Class Initialized
INFO - 2016-02-11 10:42:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:42:32 --> Pagination Class Initialized
INFO - 2016-02-11 13:42:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:42:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:42:32 --> Helper loaded: text_helper
INFO - 2016-02-11 13:42:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:42:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:42:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:42:32 --> Final output sent to browser
DEBUG - 2016-02-11 13:42:32 --> Total execution time: 1.1883
INFO - 2016-02-11 10:42:35 --> Config Class Initialized
INFO - 2016-02-11 10:42:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:42:35 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:42:35 --> Utf8 Class Initialized
INFO - 2016-02-11 10:42:35 --> URI Class Initialized
INFO - 2016-02-11 10:42:35 --> Router Class Initialized
INFO - 2016-02-11 10:42:35 --> Output Class Initialized
INFO - 2016-02-11 10:42:35 --> Security Class Initialized
DEBUG - 2016-02-11 10:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:42:35 --> Input Class Initialized
INFO - 2016-02-11 10:42:35 --> Language Class Initialized
INFO - 2016-02-11 10:42:35 --> Loader Class Initialized
INFO - 2016-02-11 10:42:35 --> Helper loaded: url_helper
INFO - 2016-02-11 10:42:35 --> Helper loaded: file_helper
INFO - 2016-02-11 10:42:35 --> Helper loaded: date_helper
INFO - 2016-02-11 10:42:35 --> Helper loaded: form_helper
INFO - 2016-02-11 10:42:35 --> Database Driver Class Initialized
INFO - 2016-02-11 10:42:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:42:36 --> Controller Class Initialized
INFO - 2016-02-11 10:42:36 --> Model Class Initialized
INFO - 2016-02-11 10:42:36 --> Model Class Initialized
INFO - 2016-02-11 10:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:42:36 --> Pagination Class Initialized
INFO - 2016-02-11 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:42:36 --> Helper loaded: text_helper
INFO - 2016-02-11 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:42:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:42:36 --> Final output sent to browser
DEBUG - 2016-02-11 13:42:36 --> Total execution time: 1.1428
INFO - 2016-02-11 10:48:49 --> Config Class Initialized
INFO - 2016-02-11 10:48:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:48:49 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:48:49 --> Utf8 Class Initialized
INFO - 2016-02-11 10:48:49 --> URI Class Initialized
INFO - 2016-02-11 10:48:49 --> Router Class Initialized
INFO - 2016-02-11 10:48:49 --> Output Class Initialized
INFO - 2016-02-11 10:48:49 --> Security Class Initialized
DEBUG - 2016-02-11 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:48:49 --> Input Class Initialized
INFO - 2016-02-11 10:48:49 --> Language Class Initialized
INFO - 2016-02-11 10:48:49 --> Loader Class Initialized
INFO - 2016-02-11 10:48:49 --> Helper loaded: url_helper
INFO - 2016-02-11 10:48:49 --> Helper loaded: file_helper
INFO - 2016-02-11 10:48:49 --> Helper loaded: date_helper
INFO - 2016-02-11 10:48:49 --> Helper loaded: form_helper
INFO - 2016-02-11 10:48:49 --> Database Driver Class Initialized
INFO - 2016-02-11 10:48:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:48:50 --> Controller Class Initialized
INFO - 2016-02-11 10:48:50 --> Model Class Initialized
INFO - 2016-02-11 10:48:50 --> Model Class Initialized
INFO - 2016-02-11 10:48:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:48:50 --> Pagination Class Initialized
INFO - 2016-02-11 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:48:50 --> Helper loaded: text_helper
INFO - 2016-02-11 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:48:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:48:50 --> Final output sent to browser
DEBUG - 2016-02-11 13:48:50 --> Total execution time: 1.2448
INFO - 2016-02-11 10:48:53 --> Config Class Initialized
INFO - 2016-02-11 10:48:53 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:48:53 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:48:53 --> Utf8 Class Initialized
INFO - 2016-02-11 10:48:53 --> URI Class Initialized
INFO - 2016-02-11 10:48:53 --> Router Class Initialized
INFO - 2016-02-11 10:48:53 --> Output Class Initialized
INFO - 2016-02-11 10:48:53 --> Security Class Initialized
DEBUG - 2016-02-11 10:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:48:53 --> Input Class Initialized
INFO - 2016-02-11 10:48:53 --> Language Class Initialized
INFO - 2016-02-11 10:48:53 --> Loader Class Initialized
INFO - 2016-02-11 10:48:53 --> Helper loaded: url_helper
INFO - 2016-02-11 10:48:53 --> Helper loaded: file_helper
INFO - 2016-02-11 10:48:53 --> Helper loaded: date_helper
INFO - 2016-02-11 10:48:53 --> Helper loaded: form_helper
INFO - 2016-02-11 10:48:53 --> Database Driver Class Initialized
INFO - 2016-02-11 10:48:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:48:54 --> Controller Class Initialized
INFO - 2016-02-11 10:48:54 --> Model Class Initialized
INFO - 2016-02-11 10:48:54 --> Model Class Initialized
INFO - 2016-02-11 10:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:48:54 --> Pagination Class Initialized
INFO - 2016-02-11 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:48:54 --> Helper loaded: text_helper
INFO - 2016-02-11 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:48:54 --> Final output sent to browser
DEBUG - 2016-02-11 13:48:54 --> Total execution time: 1.3029
INFO - 2016-02-11 10:49:26 --> Config Class Initialized
INFO - 2016-02-11 10:49:26 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:49:26 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:49:26 --> Utf8 Class Initialized
INFO - 2016-02-11 10:49:26 --> URI Class Initialized
INFO - 2016-02-11 10:49:26 --> Router Class Initialized
INFO - 2016-02-11 10:49:26 --> Output Class Initialized
INFO - 2016-02-11 10:49:26 --> Security Class Initialized
DEBUG - 2016-02-11 10:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:49:26 --> Input Class Initialized
INFO - 2016-02-11 10:49:26 --> Language Class Initialized
INFO - 2016-02-11 10:49:26 --> Loader Class Initialized
INFO - 2016-02-11 10:49:26 --> Helper loaded: url_helper
INFO - 2016-02-11 10:49:26 --> Helper loaded: file_helper
INFO - 2016-02-11 10:49:26 --> Helper loaded: date_helper
INFO - 2016-02-11 10:49:26 --> Helper loaded: form_helper
INFO - 2016-02-11 10:49:26 --> Database Driver Class Initialized
INFO - 2016-02-11 10:49:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:49:27 --> Controller Class Initialized
INFO - 2016-02-11 10:49:27 --> Model Class Initialized
INFO - 2016-02-11 10:49:27 --> Model Class Initialized
INFO - 2016-02-11 10:49:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:49:27 --> Pagination Class Initialized
INFO - 2016-02-11 13:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:49:27 --> Helper loaded: text_helper
INFO - 2016-02-11 13:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:49:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:49:27 --> Final output sent to browser
DEBUG - 2016-02-11 13:49:27 --> Total execution time: 1.2036
INFO - 2016-02-11 10:50:23 --> Config Class Initialized
INFO - 2016-02-11 10:50:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:50:23 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:50:23 --> Utf8 Class Initialized
INFO - 2016-02-11 10:50:23 --> URI Class Initialized
INFO - 2016-02-11 10:50:23 --> Router Class Initialized
INFO - 2016-02-11 10:50:23 --> Output Class Initialized
INFO - 2016-02-11 10:50:23 --> Security Class Initialized
DEBUG - 2016-02-11 10:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:50:23 --> Input Class Initialized
INFO - 2016-02-11 10:50:23 --> Language Class Initialized
INFO - 2016-02-11 10:50:23 --> Loader Class Initialized
INFO - 2016-02-11 10:50:23 --> Helper loaded: url_helper
INFO - 2016-02-11 10:50:23 --> Helper loaded: file_helper
INFO - 2016-02-11 10:50:23 --> Helper loaded: date_helper
INFO - 2016-02-11 10:50:23 --> Helper loaded: form_helper
INFO - 2016-02-11 10:50:23 --> Database Driver Class Initialized
INFO - 2016-02-11 10:50:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:50:24 --> Controller Class Initialized
INFO - 2016-02-11 10:50:24 --> Model Class Initialized
INFO - 2016-02-11 10:50:24 --> Model Class Initialized
INFO - 2016-02-11 10:50:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:50:24 --> Pagination Class Initialized
INFO - 2016-02-11 13:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:50:24 --> Helper loaded: text_helper
INFO - 2016-02-11 13:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:50:24 --> Final output sent to browser
DEBUG - 2016-02-11 13:50:24 --> Total execution time: 1.1909
INFO - 2016-02-11 10:50:48 --> Config Class Initialized
INFO - 2016-02-11 10:50:48 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:50:48 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:50:48 --> Utf8 Class Initialized
INFO - 2016-02-11 10:50:48 --> URI Class Initialized
INFO - 2016-02-11 10:50:48 --> Router Class Initialized
INFO - 2016-02-11 10:50:48 --> Output Class Initialized
INFO - 2016-02-11 10:50:48 --> Security Class Initialized
DEBUG - 2016-02-11 10:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:50:48 --> Input Class Initialized
INFO - 2016-02-11 10:50:48 --> Language Class Initialized
INFO - 2016-02-11 10:50:48 --> Loader Class Initialized
INFO - 2016-02-11 10:50:48 --> Helper loaded: url_helper
INFO - 2016-02-11 10:50:48 --> Helper loaded: file_helper
INFO - 2016-02-11 10:50:48 --> Helper loaded: date_helper
INFO - 2016-02-11 10:50:48 --> Helper loaded: form_helper
INFO - 2016-02-11 10:50:48 --> Database Driver Class Initialized
INFO - 2016-02-11 10:50:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:50:49 --> Controller Class Initialized
INFO - 2016-02-11 10:50:49 --> Model Class Initialized
INFO - 2016-02-11 10:50:49 --> Model Class Initialized
INFO - 2016-02-11 10:50:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:50:49 --> Pagination Class Initialized
INFO - 2016-02-11 13:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:50:49 --> Helper loaded: text_helper
INFO - 2016-02-11 13:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:50:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:50:49 --> Final output sent to browser
DEBUG - 2016-02-11 13:50:49 --> Total execution time: 1.2034
INFO - 2016-02-11 10:51:33 --> Config Class Initialized
INFO - 2016-02-11 10:51:33 --> Hooks Class Initialized
DEBUG - 2016-02-11 10:51:33 --> UTF-8 Support Enabled
INFO - 2016-02-11 10:51:33 --> Utf8 Class Initialized
INFO - 2016-02-11 10:51:33 --> URI Class Initialized
INFO - 2016-02-11 10:51:33 --> Router Class Initialized
INFO - 2016-02-11 10:51:33 --> Output Class Initialized
INFO - 2016-02-11 10:51:33 --> Security Class Initialized
DEBUG - 2016-02-11 10:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 10:51:33 --> Input Class Initialized
INFO - 2016-02-11 10:51:33 --> Language Class Initialized
INFO - 2016-02-11 10:51:33 --> Loader Class Initialized
INFO - 2016-02-11 10:51:33 --> Helper loaded: url_helper
INFO - 2016-02-11 10:51:33 --> Helper loaded: file_helper
INFO - 2016-02-11 10:51:33 --> Helper loaded: date_helper
INFO - 2016-02-11 10:51:33 --> Helper loaded: form_helper
INFO - 2016-02-11 10:51:33 --> Database Driver Class Initialized
INFO - 2016-02-11 10:51:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 10:51:35 --> Controller Class Initialized
INFO - 2016-02-11 10:51:35 --> Model Class Initialized
INFO - 2016-02-11 10:51:35 --> Model Class Initialized
INFO - 2016-02-11 10:51:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 10:51:35 --> Pagination Class Initialized
INFO - 2016-02-11 13:51:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 13:51:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 13:51:35 --> Helper loaded: text_helper
INFO - 2016-02-11 13:51:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 13:51:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 13:51:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 13:51:35 --> Final output sent to browser
DEBUG - 2016-02-11 13:51:35 --> Total execution time: 1.1868
INFO - 2016-02-11 11:14:49 --> Config Class Initialized
INFO - 2016-02-11 11:14:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:14:49 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:14:49 --> Utf8 Class Initialized
INFO - 2016-02-11 11:14:49 --> URI Class Initialized
INFO - 2016-02-11 11:14:49 --> Router Class Initialized
INFO - 2016-02-11 11:14:49 --> Output Class Initialized
INFO - 2016-02-11 11:14:49 --> Security Class Initialized
DEBUG - 2016-02-11 11:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:14:49 --> Input Class Initialized
INFO - 2016-02-11 11:14:49 --> Language Class Initialized
ERROR - 2016-02-11 11:14:49 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 545
INFO - 2016-02-11 11:15:19 --> Config Class Initialized
INFO - 2016-02-11 11:15:19 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:15:19 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:15:19 --> Utf8 Class Initialized
INFO - 2016-02-11 11:15:19 --> URI Class Initialized
INFO - 2016-02-11 11:15:19 --> Router Class Initialized
INFO - 2016-02-11 11:15:19 --> Output Class Initialized
INFO - 2016-02-11 11:15:19 --> Security Class Initialized
DEBUG - 2016-02-11 11:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:15:19 --> Input Class Initialized
INFO - 2016-02-11 11:15:19 --> Language Class Initialized
INFO - 2016-02-11 11:15:19 --> Loader Class Initialized
INFO - 2016-02-11 11:15:19 --> Helper loaded: url_helper
INFO - 2016-02-11 11:15:19 --> Helper loaded: file_helper
INFO - 2016-02-11 11:15:19 --> Helper loaded: date_helper
INFO - 2016-02-11 11:15:19 --> Helper loaded: form_helper
INFO - 2016-02-11 11:15:19 --> Database Driver Class Initialized
INFO - 2016-02-11 11:15:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:15:20 --> Controller Class Initialized
INFO - 2016-02-11 11:15:20 --> Model Class Initialized
ERROR - 2016-02-11 11:15:20 --> Severity: Parsing Error --> syntax error, unexpected '*', expecting function (T_FUNCTION) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 108
INFO - 2016-02-11 11:15:33 --> Config Class Initialized
INFO - 2016-02-11 11:15:33 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:15:33 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:15:33 --> Utf8 Class Initialized
INFO - 2016-02-11 11:15:33 --> URI Class Initialized
INFO - 2016-02-11 11:15:33 --> Router Class Initialized
INFO - 2016-02-11 11:15:33 --> Output Class Initialized
INFO - 2016-02-11 11:15:33 --> Security Class Initialized
DEBUG - 2016-02-11 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:15:33 --> Input Class Initialized
INFO - 2016-02-11 11:15:33 --> Language Class Initialized
INFO - 2016-02-11 11:15:33 --> Loader Class Initialized
INFO - 2016-02-11 11:15:33 --> Helper loaded: url_helper
INFO - 2016-02-11 11:15:33 --> Helper loaded: file_helper
INFO - 2016-02-11 11:15:33 --> Helper loaded: date_helper
INFO - 2016-02-11 11:15:33 --> Helper loaded: form_helper
INFO - 2016-02-11 11:15:33 --> Database Driver Class Initialized
INFO - 2016-02-11 11:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:15:34 --> Controller Class Initialized
INFO - 2016-02-11 11:15:34 --> Model Class Initialized
INFO - 2016-02-11 11:15:34 --> Model Class Initialized
INFO - 2016-02-11 11:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:15:34 --> Pagination Class Initialized
INFO - 2016-02-11 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 14:15:34 --> Helper loaded: text_helper
ERROR - 2016-02-11 14:15:34 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 64
INFO - 2016-02-11 11:15:50 --> Config Class Initialized
INFO - 2016-02-11 11:15:50 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:15:50 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:15:50 --> Utf8 Class Initialized
INFO - 2016-02-11 11:15:50 --> URI Class Initialized
INFO - 2016-02-11 11:15:50 --> Router Class Initialized
INFO - 2016-02-11 11:15:50 --> Output Class Initialized
INFO - 2016-02-11 11:15:50 --> Security Class Initialized
DEBUG - 2016-02-11 11:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:15:50 --> Input Class Initialized
INFO - 2016-02-11 11:15:50 --> Language Class Initialized
INFO - 2016-02-11 11:15:50 --> Loader Class Initialized
INFO - 2016-02-11 11:15:50 --> Helper loaded: url_helper
INFO - 2016-02-11 11:15:50 --> Helper loaded: file_helper
INFO - 2016-02-11 11:15:50 --> Helper loaded: date_helper
INFO - 2016-02-11 11:15:50 --> Helper loaded: form_helper
INFO - 2016-02-11 11:15:50 --> Database Driver Class Initialized
INFO - 2016-02-11 11:15:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:15:51 --> Controller Class Initialized
INFO - 2016-02-11 11:15:51 --> Model Class Initialized
INFO - 2016-02-11 11:15:51 --> Model Class Initialized
INFO - 2016-02-11 11:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:15:51 --> Pagination Class Initialized
INFO - 2016-02-11 14:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 14:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 14:15:51 --> Helper loaded: text_helper
INFO - 2016-02-11 14:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 14:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 14:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 14:15:51 --> Final output sent to browser
DEBUG - 2016-02-11 14:15:51 --> Total execution time: 1.1836
INFO - 2016-02-11 11:16:05 --> Config Class Initialized
INFO - 2016-02-11 11:16:05 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:16:05 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:16:05 --> Utf8 Class Initialized
INFO - 2016-02-11 11:16:05 --> URI Class Initialized
INFO - 2016-02-11 11:16:05 --> Router Class Initialized
INFO - 2016-02-11 11:16:05 --> Output Class Initialized
INFO - 2016-02-11 11:16:05 --> Security Class Initialized
DEBUG - 2016-02-11 11:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:16:05 --> Input Class Initialized
INFO - 2016-02-11 11:16:05 --> Language Class Initialized
INFO - 2016-02-11 11:16:05 --> Loader Class Initialized
INFO - 2016-02-11 11:16:05 --> Helper loaded: url_helper
INFO - 2016-02-11 11:16:05 --> Helper loaded: file_helper
INFO - 2016-02-11 11:16:05 --> Helper loaded: date_helper
INFO - 2016-02-11 11:16:05 --> Helper loaded: form_helper
INFO - 2016-02-11 11:16:05 --> Database Driver Class Initialized
INFO - 2016-02-11 11:16:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:16:06 --> Controller Class Initialized
INFO - 2016-02-11 11:16:06 --> Model Class Initialized
INFO - 2016-02-11 11:16:06 --> Model Class Initialized
INFO - 2016-02-11 11:16:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:16:06 --> Pagination Class Initialized
INFO - 2016-02-11 14:16:06 --> Form Validation Class Initialized
INFO - 2016-02-11 14:16:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-11 14:16:06 --> Model Class Initialized
ERROR - 2016-02-11 14:16:07 --> Query error: Unknown column 'user_id' in 'field list' - Invalid query: INSERT INTO `child_comment` (created, `board_id`, `user_id`, `user_name`, `article`, `parent_id`) VALUES (NOW(), '221', '12', 'test09095', 'ttl', '221')
INFO - 2016-02-11 14:16:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-11 11:19:28 --> Config Class Initialized
INFO - 2016-02-11 11:19:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:19:28 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:19:28 --> Utf8 Class Initialized
INFO - 2016-02-11 11:19:28 --> URI Class Initialized
INFO - 2016-02-11 11:19:28 --> Router Class Initialized
INFO - 2016-02-11 11:19:28 --> Output Class Initialized
INFO - 2016-02-11 11:19:28 --> Security Class Initialized
DEBUG - 2016-02-11 11:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:19:28 --> Input Class Initialized
INFO - 2016-02-11 11:19:28 --> Language Class Initialized
INFO - 2016-02-11 11:19:28 --> Loader Class Initialized
INFO - 2016-02-11 11:19:29 --> Helper loaded: url_helper
INFO - 2016-02-11 11:19:29 --> Helper loaded: file_helper
INFO - 2016-02-11 11:19:29 --> Helper loaded: date_helper
INFO - 2016-02-11 11:19:29 --> Helper loaded: form_helper
INFO - 2016-02-11 11:19:29 --> Database Driver Class Initialized
INFO - 2016-02-11 11:19:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:19:30 --> Controller Class Initialized
INFO - 2016-02-11 11:19:30 --> Model Class Initialized
INFO - 2016-02-11 11:19:30 --> Model Class Initialized
INFO - 2016-02-11 11:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:19:30 --> Pagination Class Initialized
INFO - 2016-02-11 14:19:30 --> Form Validation Class Initialized
INFO - 2016-02-11 14:19:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-11 14:19:30 --> Model Class Initialized
INFO - 2016-02-11 14:19:30 --> Final output sent to browser
DEBUG - 2016-02-11 14:19:30 --> Total execution time: 1.1806
INFO - 2016-02-11 11:19:35 --> Config Class Initialized
INFO - 2016-02-11 11:19:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:19:35 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:19:35 --> Utf8 Class Initialized
INFO - 2016-02-11 11:19:35 --> URI Class Initialized
DEBUG - 2016-02-11 11:19:35 --> No URI present. Default controller set.
INFO - 2016-02-11 11:19:35 --> Router Class Initialized
INFO - 2016-02-11 11:19:35 --> Output Class Initialized
INFO - 2016-02-11 11:19:35 --> Security Class Initialized
DEBUG - 2016-02-11 11:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:19:35 --> Input Class Initialized
INFO - 2016-02-11 11:19:35 --> Language Class Initialized
INFO - 2016-02-11 11:19:35 --> Loader Class Initialized
INFO - 2016-02-11 11:19:35 --> Helper loaded: url_helper
INFO - 2016-02-11 11:19:35 --> Helper loaded: file_helper
INFO - 2016-02-11 11:19:35 --> Helper loaded: date_helper
INFO - 2016-02-11 11:19:35 --> Helper loaded: form_helper
INFO - 2016-02-11 11:19:35 --> Database Driver Class Initialized
INFO - 2016-02-11 11:19:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:19:36 --> Controller Class Initialized
INFO - 2016-02-11 11:19:36 --> Model Class Initialized
INFO - 2016-02-11 11:19:36 --> Model Class Initialized
INFO - 2016-02-11 11:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:19:36 --> Pagination Class Initialized
INFO - 2016-02-11 14:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 14:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 14:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 14:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 14:19:36 --> Final output sent to browser
DEBUG - 2016-02-11 14:19:36 --> Total execution time: 1.1393
INFO - 2016-02-11 11:19:38 --> Config Class Initialized
INFO - 2016-02-11 11:19:38 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:19:38 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:19:38 --> Utf8 Class Initialized
INFO - 2016-02-11 11:19:38 --> URI Class Initialized
INFO - 2016-02-11 11:19:38 --> Router Class Initialized
INFO - 2016-02-11 11:19:38 --> Output Class Initialized
INFO - 2016-02-11 11:19:38 --> Security Class Initialized
DEBUG - 2016-02-11 11:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:19:38 --> Input Class Initialized
INFO - 2016-02-11 11:19:38 --> Language Class Initialized
INFO - 2016-02-11 11:19:38 --> Loader Class Initialized
INFO - 2016-02-11 11:19:38 --> Helper loaded: url_helper
INFO - 2016-02-11 11:19:38 --> Helper loaded: file_helper
INFO - 2016-02-11 11:19:38 --> Helper loaded: date_helper
INFO - 2016-02-11 11:19:38 --> Helper loaded: form_helper
INFO - 2016-02-11 11:19:38 --> Database Driver Class Initialized
INFO - 2016-02-11 11:19:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:19:39 --> Controller Class Initialized
INFO - 2016-02-11 11:19:39 --> Model Class Initialized
INFO - 2016-02-11 11:19:39 --> Model Class Initialized
INFO - 2016-02-11 11:19:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:19:39 --> Pagination Class Initialized
INFO - 2016-02-11 14:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 14:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 14:19:39 --> Helper loaded: text_helper
INFO - 2016-02-11 14:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 14:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 14:19:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 14:19:39 --> Final output sent to browser
DEBUG - 2016-02-11 14:19:39 --> Total execution time: 1.1986
INFO - 2016-02-11 11:19:52 --> Config Class Initialized
INFO - 2016-02-11 11:19:52 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:19:52 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:19:52 --> Utf8 Class Initialized
INFO - 2016-02-11 11:19:52 --> URI Class Initialized
INFO - 2016-02-11 11:19:52 --> Router Class Initialized
INFO - 2016-02-11 11:19:52 --> Output Class Initialized
INFO - 2016-02-11 11:19:52 --> Security Class Initialized
DEBUG - 2016-02-11 11:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:19:52 --> Input Class Initialized
INFO - 2016-02-11 11:19:52 --> Language Class Initialized
INFO - 2016-02-11 11:19:52 --> Loader Class Initialized
INFO - 2016-02-11 11:19:52 --> Helper loaded: url_helper
INFO - 2016-02-11 11:19:52 --> Helper loaded: file_helper
INFO - 2016-02-11 11:19:52 --> Helper loaded: date_helper
INFO - 2016-02-11 11:19:52 --> Helper loaded: form_helper
INFO - 2016-02-11 11:19:52 --> Database Driver Class Initialized
INFO - 2016-02-11 11:19:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:19:53 --> Controller Class Initialized
INFO - 2016-02-11 11:19:53 --> Model Class Initialized
INFO - 2016-02-11 11:19:53 --> Model Class Initialized
INFO - 2016-02-11 11:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:19:53 --> Pagination Class Initialized
INFO - 2016-02-11 14:19:53 --> Form Validation Class Initialized
INFO - 2016-02-11 14:19:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-11 14:19:53 --> Model Class Initialized
INFO - 2016-02-11 14:19:53 --> Final output sent to browser
DEBUG - 2016-02-11 14:19:53 --> Total execution time: 1.1723
INFO - 2016-02-11 11:29:17 --> Config Class Initialized
INFO - 2016-02-11 11:29:17 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:29:17 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:29:17 --> Utf8 Class Initialized
INFO - 2016-02-11 11:29:17 --> URI Class Initialized
DEBUG - 2016-02-11 11:29:17 --> No URI present. Default controller set.
INFO - 2016-02-11 11:29:17 --> Router Class Initialized
INFO - 2016-02-11 11:29:17 --> Output Class Initialized
INFO - 2016-02-11 11:29:17 --> Security Class Initialized
DEBUG - 2016-02-11 11:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:29:17 --> Input Class Initialized
INFO - 2016-02-11 11:29:17 --> Language Class Initialized
INFO - 2016-02-11 11:29:17 --> Loader Class Initialized
INFO - 2016-02-11 11:29:17 --> Helper loaded: url_helper
INFO - 2016-02-11 11:29:17 --> Helper loaded: file_helper
INFO - 2016-02-11 11:29:17 --> Helper loaded: date_helper
INFO - 2016-02-11 11:29:17 --> Helper loaded: form_helper
INFO - 2016-02-11 11:29:17 --> Database Driver Class Initialized
INFO - 2016-02-11 11:29:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:29:18 --> Controller Class Initialized
INFO - 2016-02-11 11:29:18 --> Model Class Initialized
INFO - 2016-02-11 11:29:18 --> Model Class Initialized
INFO - 2016-02-11 11:29:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:29:18 --> Pagination Class Initialized
INFO - 2016-02-11 14:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 14:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 14:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 14:29:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 14:29:18 --> Final output sent to browser
DEBUG - 2016-02-11 14:29:18 --> Total execution time: 1.1440
INFO - 2016-02-11 11:29:20 --> Config Class Initialized
INFO - 2016-02-11 11:29:20 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:29:20 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:29:20 --> Utf8 Class Initialized
INFO - 2016-02-11 11:29:20 --> URI Class Initialized
INFO - 2016-02-11 11:29:20 --> Router Class Initialized
INFO - 2016-02-11 11:29:20 --> Output Class Initialized
INFO - 2016-02-11 11:29:20 --> Security Class Initialized
DEBUG - 2016-02-11 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:29:20 --> Input Class Initialized
INFO - 2016-02-11 11:29:20 --> Language Class Initialized
INFO - 2016-02-11 11:29:20 --> Loader Class Initialized
INFO - 2016-02-11 11:29:20 --> Helper loaded: url_helper
INFO - 2016-02-11 11:29:20 --> Helper loaded: file_helper
INFO - 2016-02-11 11:29:20 --> Helper loaded: date_helper
INFO - 2016-02-11 11:29:20 --> Helper loaded: form_helper
INFO - 2016-02-11 11:29:20 --> Database Driver Class Initialized
INFO - 2016-02-11 11:29:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:29:21 --> Controller Class Initialized
INFO - 2016-02-11 11:29:21 --> Model Class Initialized
INFO - 2016-02-11 11:29:21 --> Model Class Initialized
INFO - 2016-02-11 11:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:29:21 --> Pagination Class Initialized
INFO - 2016-02-11 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 14:29:21 --> Helper loaded: text_helper
INFO - 2016-02-11 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 14:29:21 --> Final output sent to browser
DEBUG - 2016-02-11 14:29:21 --> Total execution time: 1.1923
INFO - 2016-02-11 11:29:31 --> Config Class Initialized
INFO - 2016-02-11 11:29:31 --> Hooks Class Initialized
DEBUG - 2016-02-11 11:29:31 --> UTF-8 Support Enabled
INFO - 2016-02-11 11:29:31 --> Utf8 Class Initialized
INFO - 2016-02-11 11:29:31 --> URI Class Initialized
INFO - 2016-02-11 11:29:31 --> Router Class Initialized
INFO - 2016-02-11 11:29:31 --> Output Class Initialized
INFO - 2016-02-11 11:29:31 --> Security Class Initialized
DEBUG - 2016-02-11 11:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 11:29:31 --> Input Class Initialized
INFO - 2016-02-11 11:29:31 --> Language Class Initialized
INFO - 2016-02-11 11:29:31 --> Loader Class Initialized
INFO - 2016-02-11 11:29:31 --> Helper loaded: url_helper
INFO - 2016-02-11 11:29:31 --> Helper loaded: file_helper
INFO - 2016-02-11 11:29:31 --> Helper loaded: date_helper
INFO - 2016-02-11 11:29:31 --> Helper loaded: form_helper
INFO - 2016-02-11 11:29:31 --> Database Driver Class Initialized
INFO - 2016-02-11 11:29:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 11:29:32 --> Controller Class Initialized
INFO - 2016-02-11 11:29:32 --> Model Class Initialized
INFO - 2016-02-11 11:29:32 --> Model Class Initialized
INFO - 2016-02-11 11:29:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 11:29:32 --> Pagination Class Initialized
INFO - 2016-02-11 14:29:32 --> Form Validation Class Initialized
INFO - 2016-02-11 14:29:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-11 14:29:32 --> Model Class Initialized
INFO - 2016-02-11 14:29:32 --> Final output sent to browser
DEBUG - 2016-02-11 14:29:32 --> Total execution time: 1.1638
INFO - 2016-02-11 12:20:21 --> Config Class Initialized
INFO - 2016-02-11 12:20:21 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:20:21 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:20:21 --> Utf8 Class Initialized
INFO - 2016-02-11 12:20:21 --> URI Class Initialized
DEBUG - 2016-02-11 12:20:21 --> No URI present. Default controller set.
INFO - 2016-02-11 12:20:21 --> Router Class Initialized
INFO - 2016-02-11 12:20:21 --> Output Class Initialized
INFO - 2016-02-11 12:20:21 --> Security Class Initialized
DEBUG - 2016-02-11 12:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:20:21 --> Input Class Initialized
INFO - 2016-02-11 12:20:21 --> Language Class Initialized
INFO - 2016-02-11 12:20:21 --> Loader Class Initialized
INFO - 2016-02-11 12:20:21 --> Helper loaded: url_helper
INFO - 2016-02-11 12:20:21 --> Helper loaded: file_helper
INFO - 2016-02-11 12:20:21 --> Helper loaded: date_helper
INFO - 2016-02-11 12:20:21 --> Helper loaded: form_helper
INFO - 2016-02-11 12:20:21 --> Database Driver Class Initialized
INFO - 2016-02-11 12:20:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:20:22 --> Controller Class Initialized
INFO - 2016-02-11 12:20:22 --> Model Class Initialized
INFO - 2016-02-11 12:20:22 --> Model Class Initialized
INFO - 2016-02-11 12:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:20:22 --> Pagination Class Initialized
INFO - 2016-02-11 15:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 15:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:20:22 --> Final output sent to browser
DEBUG - 2016-02-11 15:20:22 --> Total execution time: 1.1588
INFO - 2016-02-11 12:20:24 --> Config Class Initialized
INFO - 2016-02-11 12:20:24 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:20:24 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:20:24 --> Utf8 Class Initialized
INFO - 2016-02-11 12:20:24 --> URI Class Initialized
INFO - 2016-02-11 12:20:24 --> Router Class Initialized
INFO - 2016-02-11 12:20:24 --> Output Class Initialized
INFO - 2016-02-11 12:20:24 --> Security Class Initialized
DEBUG - 2016-02-11 12:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:20:24 --> Input Class Initialized
INFO - 2016-02-11 12:20:24 --> Language Class Initialized
INFO - 2016-02-11 12:20:24 --> Loader Class Initialized
INFO - 2016-02-11 12:20:24 --> Helper loaded: url_helper
INFO - 2016-02-11 12:20:24 --> Helper loaded: file_helper
INFO - 2016-02-11 12:20:24 --> Helper loaded: date_helper
INFO - 2016-02-11 12:20:24 --> Helper loaded: form_helper
INFO - 2016-02-11 12:20:24 --> Database Driver Class Initialized
INFO - 2016-02-11 12:20:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:20:25 --> Controller Class Initialized
INFO - 2016-02-11 12:20:25 --> Model Class Initialized
INFO - 2016-02-11 12:20:26 --> Model Class Initialized
INFO - 2016-02-11 12:20:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:20:26 --> Pagination Class Initialized
INFO - 2016-02-11 15:20:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:20:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:20:26 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:20:28 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
INFO - 2016-02-11 15:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:20:28 --> Final output sent to browser
DEBUG - 2016-02-11 15:20:28 --> Total execution time: 3.3601
ERROR - 2016-02-11 15:20:28 --> Query error: Unknown column 'board_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455222028
WHERE `board_id` = '48'
AND `id` = '8828bcf3506367707674636c704d274f71cf9771'
INFO - 2016-02-11 15:20:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-11 15:20:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Output.php:528) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-11 12:22:52 --> Config Class Initialized
INFO - 2016-02-11 12:22:52 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:22:52 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:22:52 --> Utf8 Class Initialized
INFO - 2016-02-11 12:22:52 --> URI Class Initialized
INFO - 2016-02-11 12:22:52 --> Router Class Initialized
INFO - 2016-02-11 12:22:52 --> Output Class Initialized
INFO - 2016-02-11 12:22:52 --> Security Class Initialized
DEBUG - 2016-02-11 12:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:22:52 --> Input Class Initialized
INFO - 2016-02-11 12:22:52 --> Language Class Initialized
INFO - 2016-02-11 12:22:52 --> Loader Class Initialized
INFO - 2016-02-11 12:22:52 --> Helper loaded: url_helper
INFO - 2016-02-11 12:22:52 --> Helper loaded: file_helper
INFO - 2016-02-11 12:22:52 --> Helper loaded: date_helper
INFO - 2016-02-11 12:22:52 --> Helper loaded: form_helper
INFO - 2016-02-11 12:22:52 --> Database Driver Class Initialized
INFO - 2016-02-11 12:22:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:22:53 --> Controller Class Initialized
INFO - 2016-02-11 12:22:53 --> Model Class Initialized
INFO - 2016-02-11 12:22:53 --> Model Class Initialized
INFO - 2016-02-11 12:22:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:22:53 --> Pagination Class Initialized
INFO - 2016-02-11 15:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:22:53 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Undefined property: mysqli_result::$article C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 15:22:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
INFO - 2016-02-11 15:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:22:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:22:53 --> Final output sent to browser
DEBUG - 2016-02-11 15:22:53 --> Total execution time: 1.7612
INFO - 2016-02-11 12:23:39 --> Config Class Initialized
INFO - 2016-02-11 12:23:39 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:23:39 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:23:39 --> Utf8 Class Initialized
INFO - 2016-02-11 12:23:39 --> URI Class Initialized
INFO - 2016-02-11 12:23:39 --> Router Class Initialized
INFO - 2016-02-11 12:23:39 --> Output Class Initialized
INFO - 2016-02-11 12:23:39 --> Security Class Initialized
DEBUG - 2016-02-11 12:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:23:39 --> Input Class Initialized
INFO - 2016-02-11 12:23:39 --> Language Class Initialized
INFO - 2016-02-11 12:23:39 --> Loader Class Initialized
INFO - 2016-02-11 12:23:39 --> Helper loaded: url_helper
INFO - 2016-02-11 12:23:39 --> Helper loaded: file_helper
INFO - 2016-02-11 12:23:39 --> Helper loaded: date_helper
INFO - 2016-02-11 12:23:39 --> Helper loaded: form_helper
INFO - 2016-02-11 12:23:39 --> Database Driver Class Initialized
INFO - 2016-02-11 12:23:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:23:40 --> Controller Class Initialized
INFO - 2016-02-11 12:23:40 --> Model Class Initialized
INFO - 2016-02-11 12:23:40 --> Model Class Initialized
INFO - 2016-02-11 12:23:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:23:40 --> Pagination Class Initialized
INFO - 2016-02-11 15:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:23:40 --> Helper loaded: text_helper
INFO - 2016-02-11 15:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:23:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:23:40 --> Final output sent to browser
DEBUG - 2016-02-11 15:23:40 --> Total execution time: 1.2173
INFO - 2016-02-11 12:30:24 --> Config Class Initialized
INFO - 2016-02-11 12:30:24 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:30:24 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:30:24 --> Utf8 Class Initialized
INFO - 2016-02-11 12:30:24 --> URI Class Initialized
INFO - 2016-02-11 12:30:24 --> Router Class Initialized
INFO - 2016-02-11 12:30:24 --> Output Class Initialized
INFO - 2016-02-11 12:30:24 --> Security Class Initialized
DEBUG - 2016-02-11 12:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:30:24 --> Input Class Initialized
INFO - 2016-02-11 12:30:24 --> Language Class Initialized
INFO - 2016-02-11 12:30:24 --> Loader Class Initialized
INFO - 2016-02-11 12:30:24 --> Helper loaded: url_helper
INFO - 2016-02-11 12:30:24 --> Helper loaded: file_helper
INFO - 2016-02-11 12:30:24 --> Helper loaded: date_helper
INFO - 2016-02-11 12:30:24 --> Helper loaded: form_helper
INFO - 2016-02-11 12:30:24 --> Database Driver Class Initialized
INFO - 2016-02-11 12:30:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:30:25 --> Controller Class Initialized
INFO - 2016-02-11 12:30:25 --> Model Class Initialized
INFO - 2016-02-11 12:30:25 --> Model Class Initialized
INFO - 2016-02-11 12:30:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:30:25 --> Pagination Class Initialized
INFO - 2016-02-11 15:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:30:25 --> Helper loaded: text_helper
INFO - 2016-02-11 15:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:30:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:30:25 --> Final output sent to browser
DEBUG - 2016-02-11 15:30:25 --> Total execution time: 1.2088
INFO - 2016-02-11 12:31:22 --> Config Class Initialized
INFO - 2016-02-11 12:31:22 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:31:22 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:31:22 --> Utf8 Class Initialized
INFO - 2016-02-11 12:31:22 --> URI Class Initialized
INFO - 2016-02-11 12:31:22 --> Router Class Initialized
INFO - 2016-02-11 12:31:22 --> Output Class Initialized
INFO - 2016-02-11 12:31:22 --> Security Class Initialized
DEBUG - 2016-02-11 12:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:31:22 --> Input Class Initialized
INFO - 2016-02-11 12:31:22 --> Language Class Initialized
INFO - 2016-02-11 12:31:22 --> Loader Class Initialized
INFO - 2016-02-11 12:31:22 --> Helper loaded: url_helper
INFO - 2016-02-11 12:31:22 --> Helper loaded: file_helper
INFO - 2016-02-11 12:31:22 --> Helper loaded: date_helper
INFO - 2016-02-11 12:31:22 --> Helper loaded: form_helper
INFO - 2016-02-11 12:31:22 --> Database Driver Class Initialized
INFO - 2016-02-11 12:31:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:31:23 --> Controller Class Initialized
INFO - 2016-02-11 12:31:23 --> Model Class Initialized
INFO - 2016-02-11 12:31:23 --> Model Class Initialized
INFO - 2016-02-11 12:31:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:31:23 --> Pagination Class Initialized
INFO - 2016-02-11 15:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:31:23 --> Helper loaded: text_helper
INFO - 2016-02-11 15:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:31:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:31:23 --> Final output sent to browser
DEBUG - 2016-02-11 15:31:23 --> Total execution time: 1.1637
INFO - 2016-02-11 12:32:17 --> Config Class Initialized
INFO - 2016-02-11 12:32:17 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:32:17 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:32:17 --> Utf8 Class Initialized
INFO - 2016-02-11 12:32:17 --> URI Class Initialized
INFO - 2016-02-11 12:32:17 --> Router Class Initialized
INFO - 2016-02-11 12:32:17 --> Output Class Initialized
INFO - 2016-02-11 12:32:17 --> Security Class Initialized
DEBUG - 2016-02-11 12:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:32:17 --> Input Class Initialized
INFO - 2016-02-11 12:32:17 --> Language Class Initialized
INFO - 2016-02-11 12:32:17 --> Loader Class Initialized
INFO - 2016-02-11 12:32:17 --> Helper loaded: url_helper
INFO - 2016-02-11 12:32:17 --> Helper loaded: file_helper
INFO - 2016-02-11 12:32:17 --> Helper loaded: date_helper
INFO - 2016-02-11 12:32:17 --> Helper loaded: form_helper
INFO - 2016-02-11 12:32:17 --> Database Driver Class Initialized
INFO - 2016-02-11 12:32:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:32:18 --> Controller Class Initialized
INFO - 2016-02-11 12:32:18 --> Model Class Initialized
INFO - 2016-02-11 12:32:18 --> Model Class Initialized
INFO - 2016-02-11 12:32:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:32:18 --> Pagination Class Initialized
INFO - 2016-02-11 15:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:32:18 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:32:18 --> Severity: Notice --> Undefined variable: child C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php 127
INFO - 2016-02-11 15:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:32:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:32:18 --> Final output sent to browser
DEBUG - 2016-02-11 15:32:18 --> Total execution time: 1.2013
INFO - 2016-02-11 12:33:02 --> Config Class Initialized
INFO - 2016-02-11 12:33:02 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:33:02 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:33:02 --> Utf8 Class Initialized
INFO - 2016-02-11 12:33:02 --> URI Class Initialized
INFO - 2016-02-11 12:33:02 --> Router Class Initialized
INFO - 2016-02-11 12:33:02 --> Output Class Initialized
INFO - 2016-02-11 12:33:02 --> Security Class Initialized
DEBUG - 2016-02-11 12:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:33:02 --> Input Class Initialized
INFO - 2016-02-11 12:33:02 --> Language Class Initialized
INFO - 2016-02-11 12:33:02 --> Loader Class Initialized
INFO - 2016-02-11 12:33:02 --> Helper loaded: url_helper
INFO - 2016-02-11 12:33:02 --> Helper loaded: file_helper
INFO - 2016-02-11 12:33:02 --> Helper loaded: date_helper
INFO - 2016-02-11 12:33:02 --> Helper loaded: form_helper
INFO - 2016-02-11 12:33:02 --> Database Driver Class Initialized
INFO - 2016-02-11 12:33:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:33:03 --> Controller Class Initialized
INFO - 2016-02-11 12:33:03 --> Model Class Initialized
INFO - 2016-02-11 12:33:03 --> Model Class Initialized
INFO - 2016-02-11 12:33:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:33:03 --> Pagination Class Initialized
INFO - 2016-02-11 15:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:33:03 --> Helper loaded: text_helper
INFO - 2016-02-11 15:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:33:03 --> Final output sent to browser
DEBUG - 2016-02-11 15:33:03 --> Total execution time: 1.2044
INFO - 2016-02-11 12:34:11 --> Config Class Initialized
INFO - 2016-02-11 12:34:11 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:34:11 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:34:11 --> Utf8 Class Initialized
INFO - 2016-02-11 12:34:11 --> URI Class Initialized
INFO - 2016-02-11 12:34:11 --> Router Class Initialized
INFO - 2016-02-11 12:34:11 --> Output Class Initialized
INFO - 2016-02-11 12:34:11 --> Security Class Initialized
DEBUG - 2016-02-11 12:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:34:11 --> Input Class Initialized
INFO - 2016-02-11 12:34:11 --> Language Class Initialized
INFO - 2016-02-11 12:34:11 --> Loader Class Initialized
INFO - 2016-02-11 12:34:11 --> Helper loaded: url_helper
INFO - 2016-02-11 12:34:11 --> Helper loaded: file_helper
INFO - 2016-02-11 12:34:11 --> Helper loaded: date_helper
INFO - 2016-02-11 12:34:11 --> Helper loaded: form_helper
INFO - 2016-02-11 12:34:11 --> Database Driver Class Initialized
INFO - 2016-02-11 12:34:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:34:12 --> Controller Class Initialized
INFO - 2016-02-11 12:34:12 --> Model Class Initialized
INFO - 2016-02-11 12:34:12 --> Model Class Initialized
INFO - 2016-02-11 12:34:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:34:12 --> Pagination Class Initialized
INFO - 2016-02-11 15:34:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:34:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:34:12 --> Helper loaded: text_helper
INFO - 2016-02-11 15:34:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:34:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:34:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:34:12 --> Final output sent to browser
DEBUG - 2016-02-11 15:34:12 --> Total execution time: 1.2192
INFO - 2016-02-11 12:34:40 --> Config Class Initialized
INFO - 2016-02-11 12:34:40 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:34:40 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:34:40 --> Utf8 Class Initialized
INFO - 2016-02-11 12:34:40 --> URI Class Initialized
INFO - 2016-02-11 12:34:40 --> Router Class Initialized
INFO - 2016-02-11 12:34:40 --> Output Class Initialized
INFO - 2016-02-11 12:34:40 --> Security Class Initialized
DEBUG - 2016-02-11 12:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:34:40 --> Input Class Initialized
INFO - 2016-02-11 12:34:40 --> Language Class Initialized
INFO - 2016-02-11 12:34:40 --> Loader Class Initialized
INFO - 2016-02-11 12:34:40 --> Helper loaded: url_helper
INFO - 2016-02-11 12:34:40 --> Helper loaded: file_helper
INFO - 2016-02-11 12:34:40 --> Helper loaded: date_helper
INFO - 2016-02-11 12:34:40 --> Helper loaded: form_helper
INFO - 2016-02-11 12:34:40 --> Database Driver Class Initialized
INFO - 2016-02-11 12:34:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:34:41 --> Controller Class Initialized
INFO - 2016-02-11 12:34:41 --> Model Class Initialized
INFO - 2016-02-11 12:34:41 --> Model Class Initialized
INFO - 2016-02-11 12:34:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:34:42 --> Pagination Class Initialized
INFO - 2016-02-11 15:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:34:42 --> Helper loaded: text_helper
INFO - 2016-02-11 15:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:34:42 --> Final output sent to browser
DEBUG - 2016-02-11 15:34:42 --> Total execution time: 1.2018
INFO - 2016-02-11 12:35:00 --> Config Class Initialized
INFO - 2016-02-11 12:35:00 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:35:00 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:35:00 --> Utf8 Class Initialized
INFO - 2016-02-11 12:35:00 --> URI Class Initialized
INFO - 2016-02-11 12:35:00 --> Router Class Initialized
INFO - 2016-02-11 12:35:00 --> Output Class Initialized
INFO - 2016-02-11 12:35:00 --> Security Class Initialized
DEBUG - 2016-02-11 12:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:35:00 --> Input Class Initialized
INFO - 2016-02-11 12:35:00 --> Language Class Initialized
INFO - 2016-02-11 12:35:00 --> Loader Class Initialized
INFO - 2016-02-11 12:35:00 --> Helper loaded: url_helper
INFO - 2016-02-11 12:35:00 --> Helper loaded: file_helper
INFO - 2016-02-11 12:35:00 --> Helper loaded: date_helper
INFO - 2016-02-11 12:35:00 --> Helper loaded: form_helper
INFO - 2016-02-11 12:35:00 --> Database Driver Class Initialized
INFO - 2016-02-11 12:35:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:35:01 --> Controller Class Initialized
INFO - 2016-02-11 12:35:01 --> Model Class Initialized
INFO - 2016-02-11 12:35:01 --> Model Class Initialized
INFO - 2016-02-11 12:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:35:01 --> Pagination Class Initialized
INFO - 2016-02-11 15:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:35:01 --> Helper loaded: text_helper
INFO - 2016-02-11 15:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:35:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:35:01 --> Final output sent to browser
DEBUG - 2016-02-11 15:35:01 --> Total execution time: 1.2260
INFO - 2016-02-11 12:35:08 --> Config Class Initialized
INFO - 2016-02-11 12:35:08 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:35:08 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:35:08 --> Utf8 Class Initialized
INFO - 2016-02-11 12:35:08 --> URI Class Initialized
INFO - 2016-02-11 12:35:08 --> Router Class Initialized
INFO - 2016-02-11 12:35:08 --> Output Class Initialized
INFO - 2016-02-11 12:35:08 --> Security Class Initialized
DEBUG - 2016-02-11 12:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:35:08 --> Input Class Initialized
INFO - 2016-02-11 12:35:08 --> Language Class Initialized
INFO - 2016-02-11 12:35:08 --> Loader Class Initialized
INFO - 2016-02-11 12:35:08 --> Helper loaded: url_helper
INFO - 2016-02-11 12:35:08 --> Helper loaded: file_helper
INFO - 2016-02-11 12:35:08 --> Helper loaded: date_helper
INFO - 2016-02-11 12:35:08 --> Helper loaded: form_helper
INFO - 2016-02-11 12:35:08 --> Database Driver Class Initialized
INFO - 2016-02-11 12:35:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:35:09 --> Controller Class Initialized
INFO - 2016-02-11 12:35:09 --> Model Class Initialized
INFO - 2016-02-11 12:35:09 --> Model Class Initialized
INFO - 2016-02-11 12:35:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:35:09 --> Pagination Class Initialized
INFO - 2016-02-11 15:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:35:09 --> Helper loaded: text_helper
INFO - 2016-02-11 15:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:35:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:35:09 --> Final output sent to browser
DEBUG - 2016-02-11 15:35:09 --> Total execution time: 1.1953
INFO - 2016-02-11 12:35:21 --> Config Class Initialized
INFO - 2016-02-11 12:35:21 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:35:21 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:35:21 --> Utf8 Class Initialized
INFO - 2016-02-11 12:35:21 --> URI Class Initialized
INFO - 2016-02-11 12:35:21 --> Router Class Initialized
INFO - 2016-02-11 12:35:21 --> Output Class Initialized
INFO - 2016-02-11 12:35:21 --> Security Class Initialized
DEBUG - 2016-02-11 12:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:35:21 --> Input Class Initialized
INFO - 2016-02-11 12:35:21 --> Language Class Initialized
INFO - 2016-02-11 12:35:21 --> Loader Class Initialized
INFO - 2016-02-11 12:35:21 --> Helper loaded: url_helper
INFO - 2016-02-11 12:35:21 --> Helper loaded: file_helper
INFO - 2016-02-11 12:35:21 --> Helper loaded: date_helper
INFO - 2016-02-11 12:35:21 --> Helper loaded: form_helper
INFO - 2016-02-11 12:35:21 --> Database Driver Class Initialized
INFO - 2016-02-11 12:35:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:35:22 --> Controller Class Initialized
INFO - 2016-02-11 12:35:22 --> Model Class Initialized
INFO - 2016-02-11 12:35:22 --> Model Class Initialized
INFO - 2016-02-11 12:35:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:35:22 --> Pagination Class Initialized
INFO - 2016-02-11 15:35:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:35:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:35:22 --> Helper loaded: text_helper
INFO - 2016-02-11 15:35:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:35:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:35:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:35:22 --> Final output sent to browser
DEBUG - 2016-02-11 15:35:22 --> Total execution time: 1.1928
INFO - 2016-02-11 12:38:52 --> Config Class Initialized
INFO - 2016-02-11 12:38:52 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:38:53 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:38:53 --> Utf8 Class Initialized
INFO - 2016-02-11 12:38:53 --> URI Class Initialized
INFO - 2016-02-11 12:38:53 --> Router Class Initialized
INFO - 2016-02-11 12:38:53 --> Output Class Initialized
INFO - 2016-02-11 12:38:53 --> Security Class Initialized
DEBUG - 2016-02-11 12:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:38:53 --> Input Class Initialized
INFO - 2016-02-11 12:38:53 --> Language Class Initialized
INFO - 2016-02-11 12:38:53 --> Loader Class Initialized
INFO - 2016-02-11 12:38:53 --> Helper loaded: url_helper
INFO - 2016-02-11 12:38:53 --> Helper loaded: file_helper
INFO - 2016-02-11 12:38:53 --> Helper loaded: date_helper
INFO - 2016-02-11 12:38:53 --> Helper loaded: form_helper
INFO - 2016-02-11 12:38:53 --> Database Driver Class Initialized
INFO - 2016-02-11 12:38:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:38:54 --> Controller Class Initialized
INFO - 2016-02-11 12:38:54 --> Model Class Initialized
INFO - 2016-02-11 12:38:54 --> Model Class Initialized
INFO - 2016-02-11 12:38:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:38:54 --> Pagination Class Initialized
INFO - 2016-02-11 15:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:38:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:38:54 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:38:54 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
INFO - 2016-02-11 12:39:02 --> Config Class Initialized
INFO - 2016-02-11 12:39:02 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:39:02 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:39:02 --> Utf8 Class Initialized
INFO - 2016-02-11 12:39:02 --> URI Class Initialized
INFO - 2016-02-11 12:39:02 --> Router Class Initialized
INFO - 2016-02-11 12:39:02 --> Output Class Initialized
INFO - 2016-02-11 12:39:02 --> Security Class Initialized
DEBUG - 2016-02-11 12:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:39:02 --> Input Class Initialized
INFO - 2016-02-11 12:39:02 --> Language Class Initialized
INFO - 2016-02-11 12:39:02 --> Loader Class Initialized
INFO - 2016-02-11 12:39:02 --> Helper loaded: url_helper
INFO - 2016-02-11 12:39:02 --> Helper loaded: file_helper
INFO - 2016-02-11 12:39:02 --> Helper loaded: date_helper
INFO - 2016-02-11 12:39:02 --> Helper loaded: form_helper
INFO - 2016-02-11 12:39:02 --> Database Driver Class Initialized
INFO - 2016-02-11 12:39:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:39:03 --> Controller Class Initialized
INFO - 2016-02-11 12:39:03 --> Model Class Initialized
INFO - 2016-02-11 12:39:03 --> Model Class Initialized
INFO - 2016-02-11 12:39:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:39:03 --> Pagination Class Initialized
INFO - 2016-02-11 15:39:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:39:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:39:03 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:39:03 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
INFO - 2016-02-11 12:45:27 --> Config Class Initialized
INFO - 2016-02-11 12:45:27 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:45:27 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:45:27 --> Utf8 Class Initialized
INFO - 2016-02-11 12:45:27 --> URI Class Initialized
INFO - 2016-02-11 12:45:27 --> Router Class Initialized
INFO - 2016-02-11 12:45:27 --> Output Class Initialized
INFO - 2016-02-11 12:45:27 --> Security Class Initialized
DEBUG - 2016-02-11 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:45:27 --> Input Class Initialized
INFO - 2016-02-11 12:45:27 --> Language Class Initialized
INFO - 2016-02-11 12:45:27 --> Loader Class Initialized
INFO - 2016-02-11 12:45:27 --> Helper loaded: url_helper
INFO - 2016-02-11 12:45:27 --> Helper loaded: file_helper
INFO - 2016-02-11 12:45:27 --> Helper loaded: date_helper
INFO - 2016-02-11 12:45:27 --> Helper loaded: form_helper
INFO - 2016-02-11 12:45:27 --> Database Driver Class Initialized
INFO - 2016-02-11 12:45:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:45:28 --> Controller Class Initialized
INFO - 2016-02-11 12:45:28 --> Model Class Initialized
INFO - 2016-02-11 12:45:28 --> Model Class Initialized
INFO - 2016-02-11 12:45:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:45:28 --> Pagination Class Initialized
INFO - 2016-02-11 15:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:45:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:45:28 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:45:28 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-11 15:45:28 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
INFO - 2016-02-11 12:46:28 --> Config Class Initialized
INFO - 2016-02-11 12:46:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:46:28 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:46:28 --> Utf8 Class Initialized
INFO - 2016-02-11 12:46:28 --> URI Class Initialized
INFO - 2016-02-11 12:46:28 --> Router Class Initialized
INFO - 2016-02-11 12:46:28 --> Output Class Initialized
INFO - 2016-02-11 12:46:28 --> Security Class Initialized
DEBUG - 2016-02-11 12:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:46:29 --> Input Class Initialized
INFO - 2016-02-11 12:46:29 --> Language Class Initialized
INFO - 2016-02-11 12:46:29 --> Loader Class Initialized
INFO - 2016-02-11 12:46:29 --> Helper loaded: url_helper
INFO - 2016-02-11 12:46:29 --> Helper loaded: file_helper
INFO - 2016-02-11 12:46:29 --> Helper loaded: date_helper
INFO - 2016-02-11 12:46:29 --> Helper loaded: form_helper
INFO - 2016-02-11 12:46:29 --> Database Driver Class Initialized
INFO - 2016-02-11 12:46:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:46:30 --> Controller Class Initialized
INFO - 2016-02-11 12:46:30 --> Model Class Initialized
INFO - 2016-02-11 12:46:30 --> Model Class Initialized
INFO - 2016-02-11 12:46:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:46:30 --> Pagination Class Initialized
INFO - 2016-02-11 15:46:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:46:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:46:30 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:46:30 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-11 15:46:30 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
ERROR - 2016-02-11 15:46:30 --> Query error: Unknown column 'child_comment' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455223590
WHERE `child_comment` = `Array`
AND `id` = 'dbf357c73b2f1a4e6c24b75e39599234f843063e'
INFO - 2016-02-11 15:46:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-11 15:46:30 --> Severity: Warning --> Cannot modify header information - headers already sent C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-11 12:48:28 --> Config Class Initialized
INFO - 2016-02-11 12:48:28 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:48:28 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:48:28 --> Utf8 Class Initialized
INFO - 2016-02-11 12:48:28 --> URI Class Initialized
INFO - 2016-02-11 12:48:28 --> Router Class Initialized
INFO - 2016-02-11 12:48:28 --> Output Class Initialized
INFO - 2016-02-11 12:48:28 --> Security Class Initialized
DEBUG - 2016-02-11 12:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:48:28 --> Input Class Initialized
INFO - 2016-02-11 12:48:28 --> Language Class Initialized
INFO - 2016-02-11 12:48:28 --> Loader Class Initialized
INFO - 2016-02-11 12:48:28 --> Helper loaded: url_helper
INFO - 2016-02-11 12:48:28 --> Helper loaded: file_helper
INFO - 2016-02-11 12:48:28 --> Helper loaded: date_helper
INFO - 2016-02-11 12:48:28 --> Helper loaded: form_helper
INFO - 2016-02-11 12:48:28 --> Database Driver Class Initialized
INFO - 2016-02-11 12:48:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:48:29 --> Controller Class Initialized
INFO - 2016-02-11 12:48:29 --> Model Class Initialized
INFO - 2016-02-11 12:48:29 --> Model Class Initialized
INFO - 2016-02-11 12:48:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:48:29 --> Pagination Class Initialized
INFO - 2016-02-11 15:48:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:48:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:48:29 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:48:30 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-11 15:48:30 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::result_array() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 53
ERROR - 2016-02-11 15:48:30 --> Query error: Unknown column 'child_comment' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1455223710
WHERE `child_comment` = `Array`
AND `id` = 'dbf357c73b2f1a4e6c24b75e39599234f843063e'
INFO - 2016-02-11 15:48:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-11 15:48:30 --> Severity: Warning --> Cannot modify header information - headers already sent C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
INFO - 2016-02-11 12:49:02 --> Config Class Initialized
INFO - 2016-02-11 12:49:02 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:49:02 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:49:02 --> Utf8 Class Initialized
INFO - 2016-02-11 12:49:02 --> URI Class Initialized
INFO - 2016-02-11 12:49:02 --> Router Class Initialized
INFO - 2016-02-11 12:49:02 --> Output Class Initialized
INFO - 2016-02-11 12:49:02 --> Security Class Initialized
DEBUG - 2016-02-11 12:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:49:02 --> Input Class Initialized
INFO - 2016-02-11 12:49:02 --> Language Class Initialized
INFO - 2016-02-11 12:49:02 --> Loader Class Initialized
INFO - 2016-02-11 12:49:02 --> Helper loaded: url_helper
INFO - 2016-02-11 12:49:02 --> Helper loaded: file_helper
INFO - 2016-02-11 12:49:02 --> Helper loaded: date_helper
INFO - 2016-02-11 12:49:02 --> Helper loaded: form_helper
INFO - 2016-02-11 12:49:02 --> Database Driver Class Initialized
INFO - 2016-02-11 12:49:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:49:03 --> Controller Class Initialized
INFO - 2016-02-11 12:49:03 --> Model Class Initialized
INFO - 2016-02-11 12:49:03 --> Model Class Initialized
INFO - 2016-02-11 12:49:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:49:03 --> Pagination Class Initialized
INFO - 2016-02-11 15:49:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:49:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:49:03 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:49:03 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 99
INFO - 2016-02-11 12:51:09 --> Config Class Initialized
INFO - 2016-02-11 12:51:09 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:51:09 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:51:09 --> Utf8 Class Initialized
INFO - 2016-02-11 12:51:09 --> URI Class Initialized
INFO - 2016-02-11 12:51:09 --> Router Class Initialized
INFO - 2016-02-11 12:51:09 --> Output Class Initialized
INFO - 2016-02-11 12:51:09 --> Security Class Initialized
DEBUG - 2016-02-11 12:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:51:09 --> Input Class Initialized
INFO - 2016-02-11 12:51:09 --> Language Class Initialized
INFO - 2016-02-11 12:51:09 --> Loader Class Initialized
INFO - 2016-02-11 12:51:09 --> Helper loaded: url_helper
INFO - 2016-02-11 12:51:09 --> Helper loaded: file_helper
INFO - 2016-02-11 12:51:09 --> Helper loaded: date_helper
INFO - 2016-02-11 12:51:09 --> Helper loaded: form_helper
INFO - 2016-02-11 12:51:09 --> Database Driver Class Initialized
INFO - 2016-02-11 12:51:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:51:10 --> Controller Class Initialized
INFO - 2016-02-11 12:51:10 --> Model Class Initialized
INFO - 2016-02-11 12:51:10 --> Model Class Initialized
INFO - 2016-02-11 12:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:51:10 --> Pagination Class Initialized
INFO - 2016-02-11 15:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:51:10 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:51:10 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 100
INFO - 2016-02-11 12:52:05 --> Config Class Initialized
INFO - 2016-02-11 12:52:05 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:52:05 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:52:05 --> Utf8 Class Initialized
INFO - 2016-02-11 12:52:05 --> URI Class Initialized
INFO - 2016-02-11 12:52:05 --> Router Class Initialized
INFO - 2016-02-11 12:52:05 --> Output Class Initialized
INFO - 2016-02-11 12:52:05 --> Security Class Initialized
DEBUG - 2016-02-11 12:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:52:05 --> Input Class Initialized
INFO - 2016-02-11 12:52:05 --> Language Class Initialized
INFO - 2016-02-11 12:52:05 --> Loader Class Initialized
INFO - 2016-02-11 12:52:05 --> Helper loaded: url_helper
INFO - 2016-02-11 12:52:05 --> Helper loaded: file_helper
INFO - 2016-02-11 12:52:05 --> Helper loaded: date_helper
INFO - 2016-02-11 12:52:05 --> Helper loaded: form_helper
INFO - 2016-02-11 12:52:05 --> Database Driver Class Initialized
INFO - 2016-02-11 12:52:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:52:06 --> Controller Class Initialized
INFO - 2016-02-11 12:52:06 --> Model Class Initialized
INFO - 2016-02-11 12:52:06 --> Model Class Initialized
INFO - 2016-02-11 12:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:52:06 --> Pagination Class Initialized
INFO - 2016-02-11 15:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:52:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:52:06 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:52:06 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 99
INFO - 2016-02-11 12:52:35 --> Config Class Initialized
INFO - 2016-02-11 12:52:35 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:52:35 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:52:35 --> Utf8 Class Initialized
INFO - 2016-02-11 12:52:35 --> URI Class Initialized
INFO - 2016-02-11 12:52:35 --> Router Class Initialized
INFO - 2016-02-11 12:52:35 --> Output Class Initialized
INFO - 2016-02-11 12:52:35 --> Security Class Initialized
DEBUG - 2016-02-11 12:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:52:35 --> Input Class Initialized
INFO - 2016-02-11 12:52:35 --> Language Class Initialized
INFO - 2016-02-11 12:52:35 --> Loader Class Initialized
INFO - 2016-02-11 12:52:35 --> Helper loaded: url_helper
INFO - 2016-02-11 12:52:35 --> Helper loaded: file_helper
INFO - 2016-02-11 12:52:35 --> Helper loaded: date_helper
INFO - 2016-02-11 12:52:35 --> Helper loaded: form_helper
INFO - 2016-02-11 12:52:35 --> Database Driver Class Initialized
INFO - 2016-02-11 12:52:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:52:36 --> Controller Class Initialized
INFO - 2016-02-11 12:52:36 --> Model Class Initialized
INFO - 2016-02-11 12:52:36 --> Model Class Initialized
INFO - 2016-02-11 12:52:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:52:36 --> Pagination Class Initialized
INFO - 2016-02-11 15:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:52:36 --> Helper loaded: text_helper
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
ERROR - 2016-02-11 15:52:36 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 67
INFO - 2016-02-11 15:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:52:36 --> Final output sent to browser
DEBUG - 2016-02-11 15:52:36 --> Total execution time: 1.5211
INFO - 2016-02-11 12:52:49 --> Config Class Initialized
INFO - 2016-02-11 12:52:49 --> Hooks Class Initialized
DEBUG - 2016-02-11 12:52:49 --> UTF-8 Support Enabled
INFO - 2016-02-11 12:52:49 --> Utf8 Class Initialized
INFO - 2016-02-11 12:52:49 --> URI Class Initialized
INFO - 2016-02-11 12:52:49 --> Router Class Initialized
INFO - 2016-02-11 12:52:49 --> Output Class Initialized
INFO - 2016-02-11 12:52:49 --> Security Class Initialized
DEBUG - 2016-02-11 12:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 12:52:49 --> Input Class Initialized
INFO - 2016-02-11 12:52:49 --> Language Class Initialized
INFO - 2016-02-11 12:52:49 --> Loader Class Initialized
INFO - 2016-02-11 12:52:49 --> Helper loaded: url_helper
INFO - 2016-02-11 12:52:49 --> Helper loaded: file_helper
INFO - 2016-02-11 12:52:49 --> Helper loaded: date_helper
INFO - 2016-02-11 12:52:49 --> Helper loaded: form_helper
INFO - 2016-02-11 12:52:49 --> Database Driver Class Initialized
INFO - 2016-02-11 12:52:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 12:52:50 --> Controller Class Initialized
INFO - 2016-02-11 12:52:50 --> Model Class Initialized
INFO - 2016-02-11 12:52:50 --> Model Class Initialized
INFO - 2016-02-11 12:52:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 12:52:50 --> Pagination Class Initialized
INFO - 2016-02-11 15:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 15:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 15:52:50 --> Helper loaded: text_helper
INFO - 2016-02-11 15:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 15:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 15:52:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 15:52:50 --> Final output sent to browser
DEBUG - 2016-02-11 15:52:50 --> Total execution time: 1.2386
INFO - 2016-02-11 14:56:51 --> Config Class Initialized
INFO - 2016-02-11 14:56:51 --> Hooks Class Initialized
DEBUG - 2016-02-11 14:56:51 --> UTF-8 Support Enabled
INFO - 2016-02-11 14:56:51 --> Utf8 Class Initialized
INFO - 2016-02-11 14:56:51 --> URI Class Initialized
INFO - 2016-02-11 14:56:51 --> Router Class Initialized
INFO - 2016-02-11 14:56:51 --> Output Class Initialized
INFO - 2016-02-11 14:56:51 --> Security Class Initialized
DEBUG - 2016-02-11 14:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 14:56:51 --> Input Class Initialized
INFO - 2016-02-11 14:56:51 --> Language Class Initialized
INFO - 2016-02-11 14:56:51 --> Loader Class Initialized
INFO - 2016-02-11 14:56:51 --> Helper loaded: url_helper
INFO - 2016-02-11 14:56:51 --> Helper loaded: file_helper
INFO - 2016-02-11 14:56:51 --> Helper loaded: date_helper
INFO - 2016-02-11 14:56:51 --> Helper loaded: form_helper
INFO - 2016-02-11 14:56:51 --> Database Driver Class Initialized
INFO - 2016-02-11 14:56:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 14:56:52 --> Controller Class Initialized
INFO - 2016-02-11 14:56:52 --> Model Class Initialized
INFO - 2016-02-11 14:56:52 --> Model Class Initialized
INFO - 2016-02-11 14:56:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 14:56:52 --> Pagination Class Initialized
INFO - 2016-02-11 17:56:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 17:56:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 17:56:52 --> Helper loaded: text_helper
ERROR - 2016-02-11 17:56:52 --> Severity: Warning --> Missing argument 2 for Jboard_model::child_comment_data(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\jboard.php on line 125 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 51
ERROR - 2016-02-11 17:56:52 --> Severity: Notice --> Undefined variable: board_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 55
ERROR - 2016-02-11 17:56:52 --> Severity: Notice --> Undefined variable: parent_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 56
ERROR - 2016-02-11 17:56:52 --> Severity: Notice --> Undefined variable: query C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 57
ERROR - 2016-02-11 17:56:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 57
ERROR - 2016-02-11 17:56:52 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 57
ERROR - 2016-02-11 17:56:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Exceptions.php:272) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\core\Common.php 573
ERROR - 2016-02-11 17:56:52 --> Severity: Error --> Call to a member function get() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 57
INFO - 2016-02-11 14:58:23 --> Config Class Initialized
INFO - 2016-02-11 14:58:23 --> Hooks Class Initialized
DEBUG - 2016-02-11 14:58:23 --> UTF-8 Support Enabled
INFO - 2016-02-11 14:58:23 --> Utf8 Class Initialized
INFO - 2016-02-11 14:58:23 --> URI Class Initialized
INFO - 2016-02-11 14:58:23 --> Router Class Initialized
INFO - 2016-02-11 14:58:23 --> Output Class Initialized
INFO - 2016-02-11 14:58:23 --> Security Class Initialized
DEBUG - 2016-02-11 14:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 14:58:23 --> Input Class Initialized
INFO - 2016-02-11 14:58:23 --> Language Class Initialized
INFO - 2016-02-11 14:58:23 --> Loader Class Initialized
INFO - 2016-02-11 14:58:23 --> Helper loaded: url_helper
INFO - 2016-02-11 14:58:23 --> Helper loaded: file_helper
INFO - 2016-02-11 14:58:23 --> Helper loaded: date_helper
INFO - 2016-02-11 14:58:23 --> Helper loaded: form_helper
INFO - 2016-02-11 14:58:23 --> Database Driver Class Initialized
INFO - 2016-02-11 14:58:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 14:58:24 --> Controller Class Initialized
INFO - 2016-02-11 14:58:24 --> Model Class Initialized
ERROR - 2016-02-11 14:58:24 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting '&' or variable (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 51
INFO - 2016-02-11 14:58:34 --> Config Class Initialized
INFO - 2016-02-11 14:58:34 --> Hooks Class Initialized
DEBUG - 2016-02-11 14:58:34 --> UTF-8 Support Enabled
INFO - 2016-02-11 14:58:34 --> Utf8 Class Initialized
INFO - 2016-02-11 14:58:34 --> URI Class Initialized
INFO - 2016-02-11 14:58:34 --> Router Class Initialized
INFO - 2016-02-11 14:58:34 --> Output Class Initialized
INFO - 2016-02-11 14:58:34 --> Security Class Initialized
DEBUG - 2016-02-11 14:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 14:58:34 --> Input Class Initialized
INFO - 2016-02-11 14:58:34 --> Language Class Initialized
INFO - 2016-02-11 14:58:34 --> Loader Class Initialized
INFO - 2016-02-11 14:58:34 --> Helper loaded: url_helper
INFO - 2016-02-11 14:58:34 --> Helper loaded: file_helper
INFO - 2016-02-11 14:58:34 --> Helper loaded: date_helper
INFO - 2016-02-11 14:58:34 --> Helper loaded: form_helper
INFO - 2016-02-11 14:58:34 --> Database Driver Class Initialized
INFO - 2016-02-11 14:58:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 14:58:35 --> Controller Class Initialized
INFO - 2016-02-11 14:58:35 --> Model Class Initialized
INFO - 2016-02-11 14:58:35 --> Model Class Initialized
INFO - 2016-02-11 14:58:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 14:58:35 --> Pagination Class Initialized
INFO - 2016-02-11 17:58:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 17:58:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 17:58:35 --> Helper loaded: text_helper
ERROR - 2016-02-11 17:58:35 --> Severity: Error --> Call to a member function result_array() on a non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 65
INFO - 2016-02-11 14:59:25 --> Config Class Initialized
INFO - 2016-02-11 14:59:25 --> Hooks Class Initialized
DEBUG - 2016-02-11 14:59:25 --> UTF-8 Support Enabled
INFO - 2016-02-11 14:59:25 --> Utf8 Class Initialized
INFO - 2016-02-11 14:59:25 --> URI Class Initialized
INFO - 2016-02-11 14:59:25 --> Router Class Initialized
INFO - 2016-02-11 14:59:25 --> Output Class Initialized
INFO - 2016-02-11 14:59:25 --> Security Class Initialized
DEBUG - 2016-02-11 14:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 14:59:25 --> Input Class Initialized
INFO - 2016-02-11 14:59:25 --> Language Class Initialized
INFO - 2016-02-11 14:59:25 --> Loader Class Initialized
INFO - 2016-02-11 14:59:25 --> Helper loaded: url_helper
INFO - 2016-02-11 14:59:25 --> Helper loaded: file_helper
INFO - 2016-02-11 14:59:25 --> Helper loaded: date_helper
INFO - 2016-02-11 14:59:25 --> Helper loaded: form_helper
INFO - 2016-02-11 14:59:25 --> Database Driver Class Initialized
INFO - 2016-02-11 14:59:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 14:59:26 --> Controller Class Initialized
INFO - 2016-02-11 14:59:26 --> Model Class Initialized
INFO - 2016-02-11 14:59:26 --> Model Class Initialized
INFO - 2016-02-11 14:59:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 14:59:26 --> Pagination Class Initialized
INFO - 2016-02-11 17:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 17:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 17:59:26 --> Helper loaded: text_helper
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 17:59:26 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
INFO - 2016-02-11 17:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 17:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 17:59:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 17:59:26 --> Final output sent to browser
DEBUG - 2016-02-11 17:59:26 --> Total execution time: 1.5173
INFO - 2016-02-11 15:01:44 --> Config Class Initialized
INFO - 2016-02-11 15:01:44 --> Hooks Class Initialized
DEBUG - 2016-02-11 15:01:44 --> UTF-8 Support Enabled
INFO - 2016-02-11 15:01:44 --> Utf8 Class Initialized
INFO - 2016-02-11 15:01:44 --> URI Class Initialized
INFO - 2016-02-11 15:01:44 --> Router Class Initialized
INFO - 2016-02-11 15:01:44 --> Output Class Initialized
INFO - 2016-02-11 15:01:44 --> Security Class Initialized
DEBUG - 2016-02-11 15:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 15:01:44 --> Input Class Initialized
INFO - 2016-02-11 15:01:44 --> Language Class Initialized
INFO - 2016-02-11 15:01:44 --> Loader Class Initialized
INFO - 2016-02-11 15:01:44 --> Helper loaded: url_helper
INFO - 2016-02-11 15:01:44 --> Helper loaded: file_helper
INFO - 2016-02-11 15:01:44 --> Helper loaded: date_helper
INFO - 2016-02-11 15:01:44 --> Helper loaded: form_helper
INFO - 2016-02-11 15:01:44 --> Database Driver Class Initialized
INFO - 2016-02-11 15:01:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 15:01:46 --> Controller Class Initialized
INFO - 2016-02-11 15:01:46 --> Model Class Initialized
INFO - 2016-02-11 15:01:46 --> Model Class Initialized
INFO - 2016-02-11 15:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 15:01:46 --> Pagination Class Initialized
INFO - 2016-02-11 18:01:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 18:01:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 18:01:46 --> Helper loaded: text_helper
ERROR - 2016-02-11 18:01:46 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
INFO - 2016-02-11 15:01:52 --> Config Class Initialized
INFO - 2016-02-11 15:01:52 --> Hooks Class Initialized
DEBUG - 2016-02-11 15:01:52 --> UTF-8 Support Enabled
INFO - 2016-02-11 15:01:52 --> Utf8 Class Initialized
INFO - 2016-02-11 15:01:52 --> URI Class Initialized
INFO - 2016-02-11 15:01:52 --> Router Class Initialized
INFO - 2016-02-11 15:01:52 --> Output Class Initialized
INFO - 2016-02-11 15:01:52 --> Security Class Initialized
DEBUG - 2016-02-11 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 15:01:52 --> Input Class Initialized
INFO - 2016-02-11 15:01:52 --> Language Class Initialized
INFO - 2016-02-11 15:01:52 --> Loader Class Initialized
INFO - 2016-02-11 15:01:52 --> Helper loaded: url_helper
INFO - 2016-02-11 15:01:52 --> Helper loaded: file_helper
INFO - 2016-02-11 15:01:52 --> Helper loaded: date_helper
INFO - 2016-02-11 15:01:52 --> Helper loaded: form_helper
INFO - 2016-02-11 15:01:52 --> Database Driver Class Initialized
INFO - 2016-02-11 15:01:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 15:01:53 --> Controller Class Initialized
INFO - 2016-02-11 15:01:53 --> Model Class Initialized
INFO - 2016-02-11 15:01:53 --> Model Class Initialized
INFO - 2016-02-11 15:01:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 15:01:53 --> Pagination Class Initialized
INFO - 2016-02-11 18:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 18:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 18:01:53 --> Helper loaded: text_helper
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
ERROR - 2016-02-11 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 66
INFO - 2016-02-11 18:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-11 18:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-11 18:01:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 18:01:53 --> Final output sent to browser
DEBUG - 2016-02-11 18:01:53 --> Total execution time: 1.5893
INFO - 2016-02-11 15:40:12 --> Config Class Initialized
INFO - 2016-02-11 15:40:12 --> Hooks Class Initialized
DEBUG - 2016-02-11 15:40:12 --> UTF-8 Support Enabled
INFO - 2016-02-11 15:40:12 --> Utf8 Class Initialized
INFO - 2016-02-11 15:40:12 --> URI Class Initialized
DEBUG - 2016-02-11 15:40:12 --> No URI present. Default controller set.
INFO - 2016-02-11 15:40:12 --> Router Class Initialized
INFO - 2016-02-11 15:40:12 --> Output Class Initialized
INFO - 2016-02-11 15:40:12 --> Security Class Initialized
DEBUG - 2016-02-11 15:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-11 15:40:12 --> Input Class Initialized
INFO - 2016-02-11 15:40:12 --> Language Class Initialized
INFO - 2016-02-11 15:40:12 --> Loader Class Initialized
INFO - 2016-02-11 15:40:12 --> Helper loaded: url_helper
INFO - 2016-02-11 15:40:12 --> Helper loaded: file_helper
INFO - 2016-02-11 15:40:12 --> Helper loaded: date_helper
INFO - 2016-02-11 15:40:12 --> Helper loaded: form_helper
INFO - 2016-02-11 15:40:12 --> Database Driver Class Initialized
INFO - 2016-02-11 15:40:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-11 15:40:14 --> Controller Class Initialized
INFO - 2016-02-11 15:40:14 --> Model Class Initialized
INFO - 2016-02-11 15:40:14 --> Model Class Initialized
INFO - 2016-02-11 15:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-11 15:40:14 --> Pagination Class Initialized
INFO - 2016-02-11 18:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-11 18:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-11 18:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-11 18:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-11 18:40:14 --> Final output sent to browser
DEBUG - 2016-02-11 18:40:14 --> Total execution time: 1.1754
