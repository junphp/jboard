<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-04-01 13:55:16 --> Config Class Initialized
INFO - 2016-04-01 13:55:16 --> Hooks Class Initialized
DEBUG - 2016-04-01 13:55:16 --> UTF-8 Support Enabled
INFO - 2016-04-01 13:55:16 --> Utf8 Class Initialized
INFO - 2016-04-01 13:55:16 --> URI Class Initialized
DEBUG - 2016-04-01 13:55:16 --> No URI present. Default controller set.
INFO - 2016-04-01 13:55:16 --> Router Class Initialized
INFO - 2016-04-01 13:55:16 --> Output Class Initialized
INFO - 2016-04-01 13:55:16 --> Security Class Initialized
DEBUG - 2016-04-01 13:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-01 13:55:16 --> Input Class Initialized
INFO - 2016-04-01 13:55:16 --> Language Class Initialized
INFO - 2016-04-01 13:55:16 --> Loader Class Initialized
INFO - 2016-04-01 13:55:16 --> Helper loaded: url_helper
INFO - 2016-04-01 13:55:16 --> Helper loaded: file_helper
INFO - 2016-04-01 13:55:16 --> Helper loaded: date_helper
INFO - 2016-04-01 13:55:16 --> Helper loaded: form_helper
INFO - 2016-04-01 13:55:16 --> Database Driver Class Initialized
INFO - 2016-04-01 13:55:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-01 13:55:18 --> Controller Class Initialized
INFO - 2016-04-01 13:55:18 --> Model Class Initialized
INFO - 2016-04-01 13:55:18 --> Model Class Initialized
INFO - 2016-04-01 13:55:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-01 13:55:18 --> Pagination Class Initialized
INFO - 2016-04-01 13:55:18 --> Helper loaded: text_helper
INFO - 2016-04-01 13:55:18 --> Helper loaded: cookie_helper
INFO - 2016-04-01 16:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-01 16:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-01 16:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-04-01 16:55:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-01 16:55:18 --> Final output sent to browser
DEBUG - 2016-04-01 16:55:18 --> Total execution time: 2.1934
INFO - 2016-04-01 13:55:25 --> Config Class Initialized
INFO - 2016-04-01 13:55:25 --> Hooks Class Initialized
DEBUG - 2016-04-01 13:55:25 --> UTF-8 Support Enabled
INFO - 2016-04-01 13:55:25 --> Utf8 Class Initialized
INFO - 2016-04-01 13:55:25 --> URI Class Initialized
INFO - 2016-04-01 13:55:25 --> Router Class Initialized
INFO - 2016-04-01 13:55:25 --> Output Class Initialized
INFO - 2016-04-01 13:55:25 --> Security Class Initialized
DEBUG - 2016-04-01 13:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-01 13:55:25 --> Input Class Initialized
INFO - 2016-04-01 13:55:25 --> Language Class Initialized
INFO - 2016-04-01 13:55:25 --> Loader Class Initialized
INFO - 2016-04-01 13:55:25 --> Helper loaded: url_helper
INFO - 2016-04-01 13:55:25 --> Helper loaded: file_helper
INFO - 2016-04-01 13:55:25 --> Helper loaded: date_helper
INFO - 2016-04-01 13:55:25 --> Helper loaded: form_helper
INFO - 2016-04-01 13:55:25 --> Database Driver Class Initialized
INFO - 2016-04-01 13:55:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-01 13:55:26 --> Controller Class Initialized
INFO - 2016-04-01 13:55:26 --> Model Class Initialized
INFO - 2016-04-01 13:55:26 --> Model Class Initialized
INFO - 2016-04-01 13:55:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-01 13:55:26 --> Pagination Class Initialized
INFO - 2016-04-01 13:55:26 --> Helper loaded: text_helper
INFO - 2016-04-01 13:55:26 --> Helper loaded: cookie_helper
INFO - 2016-04-01 16:55:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-01 16:55:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-01 16:55:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-04-01 16:55:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-04-01 16:55:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-01 16:55:26 --> Final output sent to browser
DEBUG - 2016-04-01 16:55:26 --> Total execution time: 1.5356
INFO - 2016-04-01 13:56:36 --> Config Class Initialized
INFO - 2016-04-01 13:56:36 --> Hooks Class Initialized
DEBUG - 2016-04-01 13:56:36 --> UTF-8 Support Enabled
INFO - 2016-04-01 13:56:36 --> Utf8 Class Initialized
INFO - 2016-04-01 13:56:36 --> URI Class Initialized
INFO - 2016-04-01 13:56:36 --> Router Class Initialized
INFO - 2016-04-01 13:56:36 --> Output Class Initialized
INFO - 2016-04-01 13:56:36 --> Security Class Initialized
DEBUG - 2016-04-01 13:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-01 13:56:36 --> Input Class Initialized
INFO - 2016-04-01 13:56:36 --> Language Class Initialized
INFO - 2016-04-01 13:56:36 --> Loader Class Initialized
INFO - 2016-04-01 13:56:36 --> Helper loaded: url_helper
INFO - 2016-04-01 13:56:36 --> Helper loaded: file_helper
INFO - 2016-04-01 13:56:36 --> Helper loaded: date_helper
INFO - 2016-04-01 13:56:36 --> Helper loaded: form_helper
INFO - 2016-04-01 13:56:36 --> Database Driver Class Initialized
INFO - 2016-04-01 13:56:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-01 13:56:37 --> Controller Class Initialized
INFO - 2016-04-01 13:56:37 --> Model Class Initialized
INFO - 2016-04-01 13:56:37 --> Model Class Initialized
INFO - 2016-04-01 13:56:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-01 13:56:37 --> Pagination Class Initialized
INFO - 2016-04-01 13:56:37 --> Helper loaded: text_helper
INFO - 2016-04-01 13:56:37 --> Helper loaded: cookie_helper
INFO - 2016-04-01 16:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-01 16:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-01 16:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-04-01 16:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-04-01 16:56:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-01 16:56:37 --> Final output sent to browser
DEBUG - 2016-04-01 16:56:37 --> Total execution time: 1.1486
INFO - 2016-04-01 13:57:01 --> Config Class Initialized
INFO - 2016-04-01 13:57:01 --> Hooks Class Initialized
DEBUG - 2016-04-01 13:57:01 --> UTF-8 Support Enabled
INFO - 2016-04-01 13:57:01 --> Utf8 Class Initialized
INFO - 2016-04-01 13:57:01 --> URI Class Initialized
DEBUG - 2016-04-01 13:57:01 --> No URI present. Default controller set.
INFO - 2016-04-01 13:57:01 --> Router Class Initialized
INFO - 2016-04-01 13:57:01 --> Output Class Initialized
INFO - 2016-04-01 13:57:01 --> Security Class Initialized
DEBUG - 2016-04-01 13:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-01 13:57:01 --> Input Class Initialized
INFO - 2016-04-01 13:57:01 --> Language Class Initialized
INFO - 2016-04-01 13:57:01 --> Loader Class Initialized
INFO - 2016-04-01 13:57:01 --> Helper loaded: url_helper
INFO - 2016-04-01 13:57:01 --> Helper loaded: file_helper
INFO - 2016-04-01 13:57:01 --> Helper loaded: date_helper
INFO - 2016-04-01 13:57:01 --> Helper loaded: form_helper
INFO - 2016-04-01 13:57:01 --> Database Driver Class Initialized
INFO - 2016-04-01 13:57:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-01 13:57:02 --> Controller Class Initialized
INFO - 2016-04-01 13:57:02 --> Model Class Initialized
INFO - 2016-04-01 13:57:02 --> Model Class Initialized
INFO - 2016-04-01 13:57:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-01 13:57:02 --> Pagination Class Initialized
INFO - 2016-04-01 13:57:02 --> Helper loaded: text_helper
INFO - 2016-04-01 13:57:02 --> Helper loaded: cookie_helper
INFO - 2016-04-01 16:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-01 16:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-01 16:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-04-01 16:57:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-01 16:57:02 --> Final output sent to browser
DEBUG - 2016-04-01 16:57:02 --> Total execution time: 1.0711
INFO - 2016-04-01 13:57:18 --> Config Class Initialized
INFO - 2016-04-01 13:57:18 --> Hooks Class Initialized
DEBUG - 2016-04-01 13:57:18 --> UTF-8 Support Enabled
INFO - 2016-04-01 13:57:18 --> Utf8 Class Initialized
INFO - 2016-04-01 13:57:18 --> URI Class Initialized
DEBUG - 2016-04-01 13:57:18 --> No URI present. Default controller set.
INFO - 2016-04-01 13:57:18 --> Router Class Initialized
INFO - 2016-04-01 13:57:18 --> Output Class Initialized
INFO - 2016-04-01 13:57:18 --> Security Class Initialized
DEBUG - 2016-04-01 13:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-04-01 13:57:18 --> Input Class Initialized
INFO - 2016-04-01 13:57:18 --> Language Class Initialized
INFO - 2016-04-01 13:57:18 --> Loader Class Initialized
INFO - 2016-04-01 13:57:18 --> Helper loaded: url_helper
INFO - 2016-04-01 13:57:18 --> Helper loaded: file_helper
INFO - 2016-04-01 13:57:18 --> Helper loaded: date_helper
INFO - 2016-04-01 13:57:18 --> Helper loaded: form_helper
INFO - 2016-04-01 13:57:18 --> Database Driver Class Initialized
INFO - 2016-04-01 13:57:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-04-01 13:57:19 --> Controller Class Initialized
INFO - 2016-04-01 13:57:19 --> Model Class Initialized
INFO - 2016-04-01 13:57:19 --> Model Class Initialized
INFO - 2016-04-01 13:57:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-04-01 13:57:19 --> Pagination Class Initialized
INFO - 2016-04-01 13:57:19 --> Helper loaded: text_helper
INFO - 2016-04-01 13:57:19 --> Helper loaded: cookie_helper
INFO - 2016-04-01 16:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-04-01 16:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-04-01 16:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-04-01 16:57:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-04-01 16:57:19 --> Final output sent to browser
DEBUG - 2016-04-01 16:57:19 --> Total execution time: 1.1916
