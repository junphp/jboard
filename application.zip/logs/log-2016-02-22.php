<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-22 07:19:18 --> Config Class Initialized
INFO - 2016-02-22 07:19:18 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:19:18 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:19:18 --> Utf8 Class Initialized
INFO - 2016-02-22 07:19:18 --> URI Class Initialized
INFO - 2016-02-22 07:19:18 --> Router Class Initialized
INFO - 2016-02-22 07:19:18 --> Output Class Initialized
INFO - 2016-02-22 07:19:18 --> Security Class Initialized
DEBUG - 2016-02-22 07:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:19:18 --> Input Class Initialized
INFO - 2016-02-22 07:19:18 --> Language Class Initialized
INFO - 2016-02-22 07:19:18 --> Loader Class Initialized
INFO - 2016-02-22 07:19:18 --> Helper loaded: url_helper
INFO - 2016-02-22 07:19:18 --> Helper loaded: file_helper
INFO - 2016-02-22 07:19:18 --> Helper loaded: date_helper
INFO - 2016-02-22 07:19:18 --> Helper loaded: form_helper
INFO - 2016-02-22 07:19:18 --> Database Driver Class Initialized
INFO - 2016-02-22 07:19:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:19:19 --> Controller Class Initialized
INFO - 2016-02-22 07:19:19 --> Model Class Initialized
INFO - 2016-02-22 07:19:19 --> Model Class Initialized
INFO - 2016-02-22 07:19:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:19:19 --> Pagination Class Initialized
INFO - 2016-02-22 07:19:19 --> Helper loaded: text_helper
INFO - 2016-02-22 07:19:19 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:19:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:19:19 --> Final output sent to browser
DEBUG - 2016-02-22 10:19:19 --> Total execution time: 1.1583
INFO - 2016-02-22 07:23:25 --> Config Class Initialized
INFO - 2016-02-22 07:23:25 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:23:25 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:23:25 --> Utf8 Class Initialized
INFO - 2016-02-22 07:23:25 --> URI Class Initialized
INFO - 2016-02-22 07:23:25 --> Router Class Initialized
INFO - 2016-02-22 07:23:25 --> Output Class Initialized
INFO - 2016-02-22 07:23:25 --> Security Class Initialized
DEBUG - 2016-02-22 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:23:25 --> Input Class Initialized
INFO - 2016-02-22 07:23:25 --> Language Class Initialized
INFO - 2016-02-22 07:23:25 --> Loader Class Initialized
INFO - 2016-02-22 07:23:25 --> Helper loaded: url_helper
INFO - 2016-02-22 07:23:25 --> Helper loaded: file_helper
INFO - 2016-02-22 07:23:25 --> Helper loaded: date_helper
INFO - 2016-02-22 07:23:25 --> Helper loaded: form_helper
INFO - 2016-02-22 07:23:25 --> Database Driver Class Initialized
INFO - 2016-02-22 07:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:23:26 --> Controller Class Initialized
INFO - 2016-02-22 07:23:26 --> Model Class Initialized
INFO - 2016-02-22 07:23:26 --> Model Class Initialized
INFO - 2016-02-22 07:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:23:26 --> Pagination Class Initialized
INFO - 2016-02-22 07:23:26 --> Helper loaded: text_helper
INFO - 2016-02-22 07:23:26 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:23:26 --> Final output sent to browser
DEBUG - 2016-02-22 10:23:26 --> Total execution time: 1.2031
INFO - 2016-02-22 07:24:11 --> Config Class Initialized
INFO - 2016-02-22 07:24:11 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:24:11 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:24:11 --> Utf8 Class Initialized
INFO - 2016-02-22 07:24:11 --> URI Class Initialized
INFO - 2016-02-22 07:24:11 --> Router Class Initialized
INFO - 2016-02-22 07:24:11 --> Output Class Initialized
INFO - 2016-02-22 07:24:11 --> Security Class Initialized
DEBUG - 2016-02-22 07:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:24:11 --> Input Class Initialized
INFO - 2016-02-22 07:24:11 --> Language Class Initialized
INFO - 2016-02-22 07:24:11 --> Loader Class Initialized
INFO - 2016-02-22 07:24:11 --> Helper loaded: url_helper
INFO - 2016-02-22 07:24:11 --> Helper loaded: file_helper
INFO - 2016-02-22 07:24:11 --> Helper loaded: date_helper
INFO - 2016-02-22 07:24:11 --> Helper loaded: form_helper
INFO - 2016-02-22 07:24:11 --> Database Driver Class Initialized
INFO - 2016-02-22 07:24:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:24:12 --> Controller Class Initialized
INFO - 2016-02-22 07:24:12 --> Model Class Initialized
INFO - 2016-02-22 07:24:12 --> Model Class Initialized
INFO - 2016-02-22 07:24:12 --> Form Validation Class Initialized
INFO - 2016-02-22 07:24:12 --> Helper loaded: text_helper
INFO - 2016-02-22 07:24:12 --> Config Class Initialized
INFO - 2016-02-22 07:24:12 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:24:12 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:24:12 --> Utf8 Class Initialized
INFO - 2016-02-22 07:24:12 --> URI Class Initialized
INFO - 2016-02-22 07:24:12 --> Router Class Initialized
INFO - 2016-02-22 07:24:12 --> Output Class Initialized
INFO - 2016-02-22 07:24:12 --> Security Class Initialized
DEBUG - 2016-02-22 07:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:24:12 --> Input Class Initialized
INFO - 2016-02-22 07:24:12 --> Language Class Initialized
INFO - 2016-02-22 07:24:12 --> Loader Class Initialized
INFO - 2016-02-22 07:24:12 --> Helper loaded: url_helper
INFO - 2016-02-22 07:24:12 --> Helper loaded: file_helper
INFO - 2016-02-22 07:24:12 --> Helper loaded: date_helper
INFO - 2016-02-22 07:24:12 --> Helper loaded: form_helper
INFO - 2016-02-22 07:24:12 --> Database Driver Class Initialized
INFO - 2016-02-22 07:24:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:24:13 --> Controller Class Initialized
INFO - 2016-02-22 07:24:13 --> Model Class Initialized
INFO - 2016-02-22 07:24:13 --> Model Class Initialized
INFO - 2016-02-22 07:24:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:24:13 --> Pagination Class Initialized
INFO - 2016-02-22 07:24:13 --> Helper loaded: text_helper
INFO - 2016-02-22 07:24:13 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:24:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:24:13 --> Final output sent to browser
DEBUG - 2016-02-22 10:24:13 --> Total execution time: 1.1431
INFO - 2016-02-22 07:25:08 --> Config Class Initialized
INFO - 2016-02-22 07:25:08 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:25:08 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:25:08 --> Utf8 Class Initialized
INFO - 2016-02-22 07:25:08 --> URI Class Initialized
INFO - 2016-02-22 07:25:08 --> Router Class Initialized
INFO - 2016-02-22 07:25:08 --> Output Class Initialized
INFO - 2016-02-22 07:25:08 --> Security Class Initialized
DEBUG - 2016-02-22 07:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:25:08 --> Input Class Initialized
INFO - 2016-02-22 07:25:08 --> Language Class Initialized
INFO - 2016-02-22 07:25:08 --> Loader Class Initialized
INFO - 2016-02-22 07:25:08 --> Helper loaded: url_helper
INFO - 2016-02-22 07:25:08 --> Helper loaded: file_helper
INFO - 2016-02-22 07:25:08 --> Helper loaded: date_helper
INFO - 2016-02-22 07:25:08 --> Helper loaded: form_helper
INFO - 2016-02-22 07:25:08 --> Database Driver Class Initialized
INFO - 2016-02-22 07:25:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:25:09 --> Controller Class Initialized
INFO - 2016-02-22 07:25:09 --> Model Class Initialized
INFO - 2016-02-22 07:25:09 --> Model Class Initialized
INFO - 2016-02-22 07:25:09 --> Form Validation Class Initialized
INFO - 2016-02-22 07:25:09 --> Helper loaded: text_helper
INFO - 2016-02-22 07:25:09 --> Config Class Initialized
INFO - 2016-02-22 07:25:09 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:25:09 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:25:09 --> Utf8 Class Initialized
INFO - 2016-02-22 07:25:09 --> URI Class Initialized
DEBUG - 2016-02-22 07:25:09 --> No URI present. Default controller set.
INFO - 2016-02-22 07:25:09 --> Router Class Initialized
INFO - 2016-02-22 07:25:09 --> Output Class Initialized
INFO - 2016-02-22 07:25:09 --> Security Class Initialized
DEBUG - 2016-02-22 07:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:25:09 --> Input Class Initialized
INFO - 2016-02-22 07:25:09 --> Language Class Initialized
INFO - 2016-02-22 07:25:09 --> Loader Class Initialized
INFO - 2016-02-22 07:25:09 --> Helper loaded: url_helper
INFO - 2016-02-22 07:25:09 --> Helper loaded: file_helper
INFO - 2016-02-22 07:25:09 --> Helper loaded: date_helper
INFO - 2016-02-22 07:25:09 --> Helper loaded: form_helper
INFO - 2016-02-22 07:25:09 --> Database Driver Class Initialized
INFO - 2016-02-22 07:25:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:25:10 --> Controller Class Initialized
INFO - 2016-02-22 07:25:10 --> Model Class Initialized
INFO - 2016-02-22 07:25:10 --> Model Class Initialized
INFO - 2016-02-22 07:25:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:25:10 --> Pagination Class Initialized
INFO - 2016-02-22 07:25:10 --> Helper loaded: text_helper
INFO - 2016-02-22 07:25:10 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:25:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 10:25:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-22 10:25:10 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-22 07:25:58 --> Config Class Initialized
INFO - 2016-02-22 07:25:58 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:25:58 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:25:58 --> Utf8 Class Initialized
INFO - 2016-02-22 07:25:58 --> URI Class Initialized
INFO - 2016-02-22 07:25:58 --> Router Class Initialized
INFO - 2016-02-22 07:25:58 --> Output Class Initialized
INFO - 2016-02-22 07:25:58 --> Security Class Initialized
DEBUG - 2016-02-22 07:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:25:58 --> Input Class Initialized
INFO - 2016-02-22 07:25:58 --> Language Class Initialized
INFO - 2016-02-22 07:25:58 --> Loader Class Initialized
INFO - 2016-02-22 07:25:58 --> Helper loaded: url_helper
INFO - 2016-02-22 07:25:58 --> Helper loaded: file_helper
INFO - 2016-02-22 07:25:58 --> Helper loaded: date_helper
INFO - 2016-02-22 07:25:58 --> Helper loaded: form_helper
INFO - 2016-02-22 07:25:58 --> Database Driver Class Initialized
INFO - 2016-02-22 07:25:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:25:59 --> Controller Class Initialized
INFO - 2016-02-22 07:25:59 --> Model Class Initialized
INFO - 2016-02-22 07:25:59 --> Model Class Initialized
INFO - 2016-02-22 07:25:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:25:59 --> Pagination Class Initialized
INFO - 2016-02-22 07:25:59 --> Helper loaded: text_helper
INFO - 2016-02-22 07:25:59 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 10:25:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:25:59 --> Final output sent to browser
DEBUG - 2016-02-22 10:25:59 --> Total execution time: 1.1263
INFO - 2016-02-22 07:26:02 --> Config Class Initialized
INFO - 2016-02-22 07:26:02 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:26:02 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:26:02 --> Utf8 Class Initialized
INFO - 2016-02-22 07:26:02 --> URI Class Initialized
INFO - 2016-02-22 07:26:02 --> Router Class Initialized
INFO - 2016-02-22 07:26:02 --> Output Class Initialized
INFO - 2016-02-22 07:26:02 --> Security Class Initialized
DEBUG - 2016-02-22 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:26:02 --> Input Class Initialized
INFO - 2016-02-22 07:26:02 --> Language Class Initialized
INFO - 2016-02-22 07:26:02 --> Loader Class Initialized
INFO - 2016-02-22 07:26:02 --> Helper loaded: url_helper
INFO - 2016-02-22 07:26:02 --> Helper loaded: file_helper
INFO - 2016-02-22 07:26:02 --> Helper loaded: date_helper
INFO - 2016-02-22 07:26:02 --> Helper loaded: form_helper
INFO - 2016-02-22 07:26:02 --> Database Driver Class Initialized
INFO - 2016-02-22 07:26:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:26:03 --> Controller Class Initialized
INFO - 2016-02-22 07:26:03 --> Model Class Initialized
INFO - 2016-02-22 07:26:03 --> Model Class Initialized
INFO - 2016-02-22 07:26:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:26:03 --> Pagination Class Initialized
INFO - 2016-02-22 07:26:03 --> Helper loaded: text_helper
INFO - 2016-02-22 07:26:03 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:26:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:26:03 --> Final output sent to browser
DEBUG - 2016-02-22 10:26:03 --> Total execution time: 1.1862
INFO - 2016-02-22 07:27:26 --> Config Class Initialized
INFO - 2016-02-22 07:27:26 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:27:26 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:27:26 --> Utf8 Class Initialized
INFO - 2016-02-22 07:27:26 --> URI Class Initialized
INFO - 2016-02-22 07:27:26 --> Router Class Initialized
INFO - 2016-02-22 07:27:26 --> Output Class Initialized
INFO - 2016-02-22 07:27:26 --> Security Class Initialized
DEBUG - 2016-02-22 07:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:27:26 --> Input Class Initialized
INFO - 2016-02-22 07:27:26 --> Language Class Initialized
INFO - 2016-02-22 07:27:26 --> Loader Class Initialized
INFO - 2016-02-22 07:27:26 --> Helper loaded: url_helper
INFO - 2016-02-22 07:27:26 --> Helper loaded: file_helper
INFO - 2016-02-22 07:27:26 --> Helper loaded: date_helper
INFO - 2016-02-22 07:27:26 --> Helper loaded: form_helper
INFO - 2016-02-22 07:27:26 --> Database Driver Class Initialized
INFO - 2016-02-22 07:27:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:27:27 --> Controller Class Initialized
INFO - 2016-02-22 07:27:27 --> Model Class Initialized
INFO - 2016-02-22 07:27:27 --> Model Class Initialized
INFO - 2016-02-22 07:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:27:27 --> Pagination Class Initialized
INFO - 2016-02-22 07:27:27 --> Helper loaded: text_helper
INFO - 2016-02-22 07:27:27 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:27:27 --> Final output sent to browser
DEBUG - 2016-02-22 10:27:27 --> Total execution time: 1.1908
INFO - 2016-02-22 07:43:08 --> Config Class Initialized
INFO - 2016-02-22 07:43:08 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:43:08 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:43:08 --> Utf8 Class Initialized
INFO - 2016-02-22 07:43:08 --> URI Class Initialized
INFO - 2016-02-22 07:43:08 --> Router Class Initialized
INFO - 2016-02-22 07:43:08 --> Output Class Initialized
INFO - 2016-02-22 07:43:08 --> Security Class Initialized
DEBUG - 2016-02-22 07:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:43:08 --> Input Class Initialized
INFO - 2016-02-22 07:43:08 --> Language Class Initialized
INFO - 2016-02-22 07:43:08 --> Loader Class Initialized
INFO - 2016-02-22 07:43:08 --> Helper loaded: url_helper
INFO - 2016-02-22 07:43:08 --> Helper loaded: file_helper
INFO - 2016-02-22 07:43:08 --> Helper loaded: date_helper
INFO - 2016-02-22 07:43:08 --> Helper loaded: form_helper
INFO - 2016-02-22 07:43:08 --> Database Driver Class Initialized
INFO - 2016-02-22 07:43:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:43:09 --> Controller Class Initialized
INFO - 2016-02-22 07:43:09 --> Model Class Initialized
INFO - 2016-02-22 07:43:09 --> Model Class Initialized
INFO - 2016-02-22 07:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:43:09 --> Pagination Class Initialized
INFO - 2016-02-22 07:43:09 --> Helper loaded: text_helper
INFO - 2016-02-22 07:43:09 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 10:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:43:09 --> Final output sent to browser
DEBUG - 2016-02-22 10:43:09 --> Total execution time: 1.0903
INFO - 2016-02-22 07:43:31 --> Config Class Initialized
INFO - 2016-02-22 07:43:31 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:43:31 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:43:31 --> Utf8 Class Initialized
INFO - 2016-02-22 07:43:31 --> URI Class Initialized
INFO - 2016-02-22 07:43:31 --> Router Class Initialized
INFO - 2016-02-22 07:43:31 --> Output Class Initialized
INFO - 2016-02-22 07:43:31 --> Security Class Initialized
DEBUG - 2016-02-22 07:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:43:31 --> Input Class Initialized
INFO - 2016-02-22 07:43:31 --> Language Class Initialized
INFO - 2016-02-22 07:43:31 --> Loader Class Initialized
INFO - 2016-02-22 07:43:31 --> Helper loaded: url_helper
INFO - 2016-02-22 07:43:31 --> Helper loaded: file_helper
INFO - 2016-02-22 07:43:31 --> Helper loaded: date_helper
INFO - 2016-02-22 07:43:31 --> Helper loaded: form_helper
INFO - 2016-02-22 07:43:31 --> Database Driver Class Initialized
INFO - 2016-02-22 07:43:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:43:32 --> Controller Class Initialized
INFO - 2016-02-22 07:43:32 --> Model Class Initialized
INFO - 2016-02-22 07:43:32 --> Model Class Initialized
INFO - 2016-02-22 07:43:32 --> Form Validation Class Initialized
INFO - 2016-02-22 07:43:32 --> Helper loaded: text_helper
INFO - 2016-02-22 07:43:32 --> Final output sent to browser
DEBUG - 2016-02-22 07:43:32 --> Total execution time: 1.1434
INFO - 2016-02-22 07:43:43 --> Config Class Initialized
INFO - 2016-02-22 07:43:43 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:43:43 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:43:43 --> Utf8 Class Initialized
INFO - 2016-02-22 07:43:43 --> URI Class Initialized
INFO - 2016-02-22 07:43:43 --> Router Class Initialized
INFO - 2016-02-22 07:43:43 --> Output Class Initialized
INFO - 2016-02-22 07:43:43 --> Security Class Initialized
DEBUG - 2016-02-22 07:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:43:43 --> Input Class Initialized
INFO - 2016-02-22 07:43:43 --> Language Class Initialized
INFO - 2016-02-22 07:43:44 --> Loader Class Initialized
INFO - 2016-02-22 07:43:44 --> Helper loaded: url_helper
INFO - 2016-02-22 07:43:44 --> Helper loaded: file_helper
INFO - 2016-02-22 07:43:44 --> Helper loaded: date_helper
INFO - 2016-02-22 07:43:44 --> Helper loaded: form_helper
INFO - 2016-02-22 07:43:44 --> Database Driver Class Initialized
INFO - 2016-02-22 07:43:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:43:45 --> Controller Class Initialized
INFO - 2016-02-22 07:43:45 --> Model Class Initialized
INFO - 2016-02-22 07:43:45 --> Model Class Initialized
INFO - 2016-02-22 07:43:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:43:45 --> Pagination Class Initialized
INFO - 2016-02-22 07:43:45 --> Helper loaded: text_helper
INFO - 2016-02-22 07:43:45 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 10:43:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:43:45 --> Final output sent to browser
DEBUG - 2016-02-22 10:43:45 --> Total execution time: 1.1555
INFO - 2016-02-22 07:43:56 --> Config Class Initialized
INFO - 2016-02-22 07:43:56 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:43:56 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:43:56 --> Utf8 Class Initialized
INFO - 2016-02-22 07:43:56 --> URI Class Initialized
INFO - 2016-02-22 07:43:56 --> Router Class Initialized
INFO - 2016-02-22 07:43:56 --> Output Class Initialized
INFO - 2016-02-22 07:43:56 --> Security Class Initialized
DEBUG - 2016-02-22 07:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:43:56 --> Input Class Initialized
INFO - 2016-02-22 07:43:56 --> Language Class Initialized
INFO - 2016-02-22 07:43:56 --> Loader Class Initialized
INFO - 2016-02-22 07:43:56 --> Helper loaded: url_helper
INFO - 2016-02-22 07:43:56 --> Helper loaded: file_helper
INFO - 2016-02-22 07:43:56 --> Helper loaded: date_helper
INFO - 2016-02-22 07:43:56 --> Helper loaded: form_helper
INFO - 2016-02-22 07:43:56 --> Database Driver Class Initialized
INFO - 2016-02-22 07:43:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:43:57 --> Controller Class Initialized
INFO - 2016-02-22 07:43:57 --> Model Class Initialized
INFO - 2016-02-22 07:43:57 --> Model Class Initialized
INFO - 2016-02-22 07:43:57 --> Form Validation Class Initialized
INFO - 2016-02-22 07:43:57 --> Helper loaded: text_helper
INFO - 2016-02-22 07:43:57 --> Config Class Initialized
INFO - 2016-02-22 07:43:57 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:43:57 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:43:57 --> Utf8 Class Initialized
INFO - 2016-02-22 07:43:57 --> URI Class Initialized
INFO - 2016-02-22 07:43:57 --> Router Class Initialized
INFO - 2016-02-22 07:43:57 --> Output Class Initialized
INFO - 2016-02-22 07:43:57 --> Security Class Initialized
DEBUG - 2016-02-22 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:43:57 --> Input Class Initialized
INFO - 2016-02-22 07:43:57 --> Language Class Initialized
INFO - 2016-02-22 07:43:57 --> Loader Class Initialized
INFO - 2016-02-22 07:43:57 --> Helper loaded: url_helper
INFO - 2016-02-22 07:43:57 --> Helper loaded: file_helper
INFO - 2016-02-22 07:43:57 --> Helper loaded: date_helper
INFO - 2016-02-22 07:43:57 --> Helper loaded: form_helper
INFO - 2016-02-22 07:43:57 --> Database Driver Class Initialized
INFO - 2016-02-22 07:43:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:43:58 --> Controller Class Initialized
INFO - 2016-02-22 07:43:58 --> Model Class Initialized
INFO - 2016-02-22 07:43:58 --> Model Class Initialized
INFO - 2016-02-22 07:43:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:43:58 --> Pagination Class Initialized
INFO - 2016-02-22 07:43:58 --> Helper loaded: text_helper
INFO - 2016-02-22 07:43:58 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 10:43:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:43:58 --> Final output sent to browser
DEBUG - 2016-02-22 10:43:58 --> Total execution time: 1.0962
INFO - 2016-02-22 07:44:02 --> Config Class Initialized
INFO - 2016-02-22 07:44:02 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:44:02 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:44:02 --> Utf8 Class Initialized
INFO - 2016-02-22 07:44:02 --> URI Class Initialized
INFO - 2016-02-22 07:44:02 --> Router Class Initialized
INFO - 2016-02-22 07:44:02 --> Output Class Initialized
INFO - 2016-02-22 07:44:02 --> Security Class Initialized
DEBUG - 2016-02-22 07:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:44:02 --> Input Class Initialized
INFO - 2016-02-22 07:44:02 --> Language Class Initialized
INFO - 2016-02-22 07:44:02 --> Loader Class Initialized
INFO - 2016-02-22 07:44:02 --> Helper loaded: url_helper
INFO - 2016-02-22 07:44:02 --> Helper loaded: file_helper
INFO - 2016-02-22 07:44:02 --> Helper loaded: date_helper
INFO - 2016-02-22 07:44:02 --> Helper loaded: form_helper
INFO - 2016-02-22 07:44:02 --> Database Driver Class Initialized
INFO - 2016-02-22 07:44:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:44:03 --> Controller Class Initialized
INFO - 2016-02-22 07:44:03 --> Model Class Initialized
INFO - 2016-02-22 07:44:03 --> Model Class Initialized
INFO - 2016-02-22 07:44:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:44:03 --> Pagination Class Initialized
INFO - 2016-02-22 07:44:03 --> Helper loaded: text_helper
INFO - 2016-02-22 07:44:03 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:44:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:44:03 --> Final output sent to browser
DEBUG - 2016-02-22 10:44:03 --> Total execution time: 1.1865
INFO - 2016-02-22 07:44:06 --> Config Class Initialized
INFO - 2016-02-22 07:44:06 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:44:06 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:44:06 --> Utf8 Class Initialized
INFO - 2016-02-22 07:44:06 --> URI Class Initialized
INFO - 2016-02-22 07:44:06 --> Router Class Initialized
INFO - 2016-02-22 07:44:06 --> Output Class Initialized
INFO - 2016-02-22 07:44:06 --> Security Class Initialized
DEBUG - 2016-02-22 07:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:44:06 --> Input Class Initialized
INFO - 2016-02-22 07:44:06 --> Language Class Initialized
INFO - 2016-02-22 07:44:06 --> Loader Class Initialized
INFO - 2016-02-22 07:44:06 --> Helper loaded: url_helper
INFO - 2016-02-22 07:44:06 --> Helper loaded: file_helper
INFO - 2016-02-22 07:44:06 --> Helper loaded: date_helper
INFO - 2016-02-22 07:44:06 --> Helper loaded: form_helper
INFO - 2016-02-22 07:44:06 --> Database Driver Class Initialized
INFO - 2016-02-22 07:44:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:44:07 --> Controller Class Initialized
INFO - 2016-02-22 07:44:07 --> Model Class Initialized
INFO - 2016-02-22 07:44:07 --> Model Class Initialized
INFO - 2016-02-22 07:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:44:07 --> Pagination Class Initialized
INFO - 2016-02-22 07:44:07 --> Helper loaded: text_helper
INFO - 2016-02-22 07:44:07 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:44:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:44:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:44:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 10:44:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:44:07 --> Final output sent to browser
DEBUG - 2016-02-22 10:44:07 --> Total execution time: 1.1184
INFO - 2016-02-22 07:44:08 --> Config Class Initialized
INFO - 2016-02-22 07:44:08 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:44:08 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:44:08 --> Utf8 Class Initialized
INFO - 2016-02-22 07:44:08 --> URI Class Initialized
INFO - 2016-02-22 07:44:08 --> Router Class Initialized
INFO - 2016-02-22 07:44:08 --> Output Class Initialized
INFO - 2016-02-22 07:44:08 --> Security Class Initialized
DEBUG - 2016-02-22 07:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:44:08 --> Input Class Initialized
INFO - 2016-02-22 07:44:08 --> Language Class Initialized
INFO - 2016-02-22 07:44:08 --> Loader Class Initialized
INFO - 2016-02-22 07:44:08 --> Helper loaded: url_helper
INFO - 2016-02-22 07:44:08 --> Helper loaded: file_helper
INFO - 2016-02-22 07:44:08 --> Helper loaded: date_helper
INFO - 2016-02-22 07:44:08 --> Helper loaded: form_helper
INFO - 2016-02-22 07:44:08 --> Database Driver Class Initialized
INFO - 2016-02-22 07:44:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:44:09 --> Controller Class Initialized
INFO - 2016-02-22 07:44:09 --> Model Class Initialized
INFO - 2016-02-22 07:44:09 --> Model Class Initialized
INFO - 2016-02-22 07:44:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:44:09 --> Pagination Class Initialized
INFO - 2016-02-22 07:44:09 --> Helper loaded: text_helper
INFO - 2016-02-22 07:44:09 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:44:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:44:09 --> Final output sent to browser
DEBUG - 2016-02-22 10:44:09 --> Total execution time: 1.1471
INFO - 2016-02-22 07:56:02 --> Config Class Initialized
INFO - 2016-02-22 07:56:02 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:56:02 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:56:02 --> Utf8 Class Initialized
INFO - 2016-02-22 07:56:02 --> URI Class Initialized
INFO - 2016-02-22 07:56:02 --> Router Class Initialized
INFO - 2016-02-22 07:56:02 --> Output Class Initialized
INFO - 2016-02-22 07:56:02 --> Security Class Initialized
DEBUG - 2016-02-22 07:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:56:02 --> Input Class Initialized
INFO - 2016-02-22 07:56:02 --> Language Class Initialized
INFO - 2016-02-22 07:56:02 --> Loader Class Initialized
INFO - 2016-02-22 07:56:02 --> Helper loaded: url_helper
INFO - 2016-02-22 07:56:02 --> Helper loaded: file_helper
INFO - 2016-02-22 07:56:02 --> Helper loaded: date_helper
INFO - 2016-02-22 07:56:02 --> Helper loaded: form_helper
INFO - 2016-02-22 07:56:02 --> Database Driver Class Initialized
INFO - 2016-02-22 07:56:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:56:03 --> Controller Class Initialized
INFO - 2016-02-22 07:56:03 --> Model Class Initialized
INFO - 2016-02-22 07:56:03 --> Model Class Initialized
INFO - 2016-02-22 07:56:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:56:03 --> Pagination Class Initialized
INFO - 2016-02-22 07:56:03 --> Helper loaded: text_helper
INFO - 2016-02-22 07:56:03 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:56:03 --> User Agent Class Initialized
INFO - 2016-02-22 10:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 10:56:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:56:03 --> Final output sent to browser
DEBUG - 2016-02-22 10:56:04 --> Total execution time: 1.1883
INFO - 2016-02-22 07:56:05 --> Config Class Initialized
INFO - 2016-02-22 07:56:05 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:56:05 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:56:05 --> Utf8 Class Initialized
INFO - 2016-02-22 07:56:05 --> URI Class Initialized
INFO - 2016-02-22 07:56:05 --> Router Class Initialized
INFO - 2016-02-22 07:56:05 --> Output Class Initialized
INFO - 2016-02-22 07:56:05 --> Security Class Initialized
DEBUG - 2016-02-22 07:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:56:05 --> Input Class Initialized
INFO - 2016-02-22 07:56:05 --> Language Class Initialized
INFO - 2016-02-22 07:56:05 --> Loader Class Initialized
INFO - 2016-02-22 07:56:05 --> Helper loaded: url_helper
INFO - 2016-02-22 07:56:05 --> Helper loaded: file_helper
INFO - 2016-02-22 07:56:05 --> Helper loaded: date_helper
INFO - 2016-02-22 07:56:05 --> Helper loaded: form_helper
INFO - 2016-02-22 07:56:05 --> Database Driver Class Initialized
INFO - 2016-02-22 07:56:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:56:06 --> Controller Class Initialized
INFO - 2016-02-22 07:56:06 --> Model Class Initialized
INFO - 2016-02-22 07:56:06 --> Model Class Initialized
INFO - 2016-02-22 07:56:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:56:06 --> Pagination Class Initialized
INFO - 2016-02-22 07:56:06 --> Helper loaded: text_helper
INFO - 2016-02-22 07:56:06 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:56:06 --> User Agent Class Initialized
INFO - 2016-02-22 10:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:56:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:56:06 --> Final output sent to browser
DEBUG - 2016-02-22 10:56:06 --> Total execution time: 1.1958
INFO - 2016-02-22 07:56:11 --> Config Class Initialized
INFO - 2016-02-22 07:56:11 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:56:11 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:56:11 --> Utf8 Class Initialized
INFO - 2016-02-22 07:56:11 --> URI Class Initialized
INFO - 2016-02-22 07:56:11 --> Router Class Initialized
INFO - 2016-02-22 07:56:11 --> Output Class Initialized
INFO - 2016-02-22 07:56:11 --> Security Class Initialized
DEBUG - 2016-02-22 07:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:56:11 --> Input Class Initialized
INFO - 2016-02-22 07:56:11 --> Language Class Initialized
INFO - 2016-02-22 07:56:11 --> Loader Class Initialized
INFO - 2016-02-22 07:56:11 --> Helper loaded: url_helper
INFO - 2016-02-22 07:56:11 --> Helper loaded: file_helper
INFO - 2016-02-22 07:56:11 --> Helper loaded: date_helper
INFO - 2016-02-22 07:56:11 --> Helper loaded: form_helper
INFO - 2016-02-22 07:56:11 --> Database Driver Class Initialized
INFO - 2016-02-22 07:56:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:56:12 --> Controller Class Initialized
INFO - 2016-02-22 07:56:12 --> Model Class Initialized
INFO - 2016-02-22 07:56:12 --> Model Class Initialized
INFO - 2016-02-22 07:56:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:56:12 --> Pagination Class Initialized
INFO - 2016-02-22 07:56:12 --> Helper loaded: text_helper
INFO - 2016-02-22 07:56:12 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:56:12 --> User Agent Class Initialized
INFO - 2016-02-22 10:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 10:56:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:56:12 --> Final output sent to browser
DEBUG - 2016-02-22 10:56:12 --> Total execution time: 1.1270
INFO - 2016-02-22 07:56:14 --> Config Class Initialized
INFO - 2016-02-22 07:56:14 --> Hooks Class Initialized
DEBUG - 2016-02-22 07:56:14 --> UTF-8 Support Enabled
INFO - 2016-02-22 07:56:14 --> Utf8 Class Initialized
INFO - 2016-02-22 07:56:14 --> URI Class Initialized
INFO - 2016-02-22 07:56:14 --> Router Class Initialized
INFO - 2016-02-22 07:56:14 --> Output Class Initialized
INFO - 2016-02-22 07:56:14 --> Security Class Initialized
DEBUG - 2016-02-22 07:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 07:56:14 --> Input Class Initialized
INFO - 2016-02-22 07:56:14 --> Language Class Initialized
INFO - 2016-02-22 07:56:14 --> Loader Class Initialized
INFO - 2016-02-22 07:56:14 --> Helper loaded: url_helper
INFO - 2016-02-22 07:56:14 --> Helper loaded: file_helper
INFO - 2016-02-22 07:56:14 --> Helper loaded: date_helper
INFO - 2016-02-22 07:56:14 --> Helper loaded: form_helper
INFO - 2016-02-22 07:56:14 --> Database Driver Class Initialized
INFO - 2016-02-22 07:56:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 07:56:15 --> Controller Class Initialized
INFO - 2016-02-22 07:56:15 --> Model Class Initialized
INFO - 2016-02-22 07:56:15 --> Model Class Initialized
INFO - 2016-02-22 07:56:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 07:56:15 --> Pagination Class Initialized
INFO - 2016-02-22 07:56:15 --> Helper loaded: text_helper
INFO - 2016-02-22 07:56:15 --> Helper loaded: cookie_helper
INFO - 2016-02-22 10:56:15 --> User Agent Class Initialized
INFO - 2016-02-22 10:56:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 10:56:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 10:56:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 10:56:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 10:56:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 10:56:15 --> Final output sent to browser
DEBUG - 2016-02-22 10:56:15 --> Total execution time: 1.1788
INFO - 2016-02-22 08:17:18 --> Config Class Initialized
INFO - 2016-02-22 08:17:18 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:17:18 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:17:18 --> Utf8 Class Initialized
INFO - 2016-02-22 08:17:18 --> URI Class Initialized
INFO - 2016-02-22 08:17:18 --> Router Class Initialized
INFO - 2016-02-22 08:17:18 --> Output Class Initialized
INFO - 2016-02-22 08:17:18 --> Security Class Initialized
DEBUG - 2016-02-22 08:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:17:18 --> Input Class Initialized
INFO - 2016-02-22 08:17:18 --> Language Class Initialized
INFO - 2016-02-22 08:17:18 --> Loader Class Initialized
INFO - 2016-02-22 08:17:18 --> Helper loaded: url_helper
INFO - 2016-02-22 08:17:18 --> Helper loaded: file_helper
INFO - 2016-02-22 08:17:18 --> Helper loaded: date_helper
INFO - 2016-02-22 08:17:18 --> Helper loaded: form_helper
INFO - 2016-02-22 08:17:18 --> Database Driver Class Initialized
INFO - 2016-02-22 08:17:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:17:19 --> Controller Class Initialized
INFO - 2016-02-22 08:17:19 --> Model Class Initialized
INFO - 2016-02-22 08:17:19 --> Model Class Initialized
INFO - 2016-02-22 08:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:17:19 --> Pagination Class Initialized
INFO - 2016-02-22 08:17:19 --> Helper loaded: text_helper
INFO - 2016-02-22 08:17:19 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 11:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:17:19 --> Final output sent to browser
DEBUG - 2016-02-22 11:17:19 --> Total execution time: 1.7278
INFO - 2016-02-22 08:17:23 --> Config Class Initialized
INFO - 2016-02-22 08:17:23 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:17:23 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:17:23 --> Utf8 Class Initialized
INFO - 2016-02-22 08:17:23 --> URI Class Initialized
INFO - 2016-02-22 08:17:23 --> Router Class Initialized
INFO - 2016-02-22 08:17:23 --> Output Class Initialized
INFO - 2016-02-22 08:17:23 --> Security Class Initialized
DEBUG - 2016-02-22 08:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:17:23 --> Input Class Initialized
INFO - 2016-02-22 08:17:23 --> Language Class Initialized
INFO - 2016-02-22 08:17:23 --> Loader Class Initialized
INFO - 2016-02-22 08:17:23 --> Helper loaded: url_helper
INFO - 2016-02-22 08:17:23 --> Helper loaded: file_helper
INFO - 2016-02-22 08:17:23 --> Helper loaded: date_helper
INFO - 2016-02-22 08:17:23 --> Helper loaded: form_helper
INFO - 2016-02-22 08:17:23 --> Database Driver Class Initialized
INFO - 2016-02-22 08:17:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:17:24 --> Controller Class Initialized
INFO - 2016-02-22 08:17:24 --> Model Class Initialized
INFO - 2016-02-22 08:17:24 --> Model Class Initialized
INFO - 2016-02-22 08:17:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:17:24 --> Pagination Class Initialized
INFO - 2016-02-22 08:17:24 --> Helper loaded: text_helper
INFO - 2016-02-22 08:17:24 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:17:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:17:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:17:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 11:17:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 11:17:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:17:24 --> Final output sent to browser
DEBUG - 2016-02-22 11:17:24 --> Total execution time: 1.4302
INFO - 2016-02-22 08:17:29 --> Config Class Initialized
INFO - 2016-02-22 08:17:29 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:17:30 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:17:30 --> Utf8 Class Initialized
INFO - 2016-02-22 08:17:30 --> URI Class Initialized
INFO - 2016-02-22 08:17:30 --> Router Class Initialized
INFO - 2016-02-22 08:17:30 --> Output Class Initialized
INFO - 2016-02-22 08:17:30 --> Security Class Initialized
DEBUG - 2016-02-22 08:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:17:30 --> Input Class Initialized
INFO - 2016-02-22 08:17:30 --> Language Class Initialized
INFO - 2016-02-22 08:17:30 --> Loader Class Initialized
INFO - 2016-02-22 08:17:30 --> Helper loaded: url_helper
INFO - 2016-02-22 08:17:30 --> Helper loaded: file_helper
INFO - 2016-02-22 08:17:30 --> Helper loaded: date_helper
INFO - 2016-02-22 08:17:30 --> Helper loaded: form_helper
INFO - 2016-02-22 08:17:30 --> Database Driver Class Initialized
INFO - 2016-02-22 08:17:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:17:31 --> Controller Class Initialized
INFO - 2016-02-22 08:17:31 --> Model Class Initialized
INFO - 2016-02-22 08:17:31 --> Model Class Initialized
INFO - 2016-02-22 08:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:17:31 --> Pagination Class Initialized
INFO - 2016-02-22 08:17:31 --> Helper loaded: text_helper
INFO - 2016-02-22 08:17:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-22 11:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:17:31 --> Final output sent to browser
DEBUG - 2016-02-22 11:17:31 --> Total execution time: 1.4068
INFO - 2016-02-22 08:17:50 --> Config Class Initialized
INFO - 2016-02-22 08:17:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:17:50 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:17:50 --> Utf8 Class Initialized
INFO - 2016-02-22 08:17:50 --> URI Class Initialized
INFO - 2016-02-22 08:17:50 --> Router Class Initialized
INFO - 2016-02-22 08:17:50 --> Output Class Initialized
INFO - 2016-02-22 08:17:50 --> Security Class Initialized
DEBUG - 2016-02-22 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:17:50 --> Input Class Initialized
INFO - 2016-02-22 08:17:50 --> Language Class Initialized
INFO - 2016-02-22 08:17:50 --> Loader Class Initialized
INFO - 2016-02-22 08:17:50 --> Helper loaded: url_helper
INFO - 2016-02-22 08:17:50 --> Helper loaded: file_helper
INFO - 2016-02-22 08:17:50 --> Helper loaded: date_helper
INFO - 2016-02-22 08:17:50 --> Helper loaded: form_helper
INFO - 2016-02-22 08:17:50 --> Database Driver Class Initialized
INFO - 2016-02-22 08:17:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:17:51 --> Controller Class Initialized
INFO - 2016-02-22 08:17:51 --> Model Class Initialized
INFO - 2016-02-22 08:17:51 --> Model Class Initialized
INFO - 2016-02-22 08:17:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:17:51 --> Pagination Class Initialized
INFO - 2016-02-22 08:17:51 --> Helper loaded: text_helper
INFO - 2016-02-22 08:17:51 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:17:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:17:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 11:17:51 --> Query error: Table 'jdboard.jboard' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows` FROM `jboard`
INFO - 2016-02-22 11:17:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-22 08:18:12 --> Config Class Initialized
INFO - 2016-02-22 08:18:12 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:18:12 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:18:12 --> Utf8 Class Initialized
INFO - 2016-02-22 08:18:12 --> URI Class Initialized
INFO - 2016-02-22 08:18:12 --> Router Class Initialized
INFO - 2016-02-22 08:18:12 --> Output Class Initialized
INFO - 2016-02-22 08:18:12 --> Security Class Initialized
DEBUG - 2016-02-22 08:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:18:12 --> Input Class Initialized
INFO - 2016-02-22 08:18:12 --> Language Class Initialized
INFO - 2016-02-22 08:18:12 --> Loader Class Initialized
INFO - 2016-02-22 08:18:12 --> Helper loaded: url_helper
INFO - 2016-02-22 08:18:12 --> Helper loaded: file_helper
INFO - 2016-02-22 08:18:12 --> Helper loaded: date_helper
INFO - 2016-02-22 08:18:12 --> Helper loaded: form_helper
INFO - 2016-02-22 08:18:12 --> Database Driver Class Initialized
INFO - 2016-02-22 08:18:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:18:14 --> Controller Class Initialized
INFO - 2016-02-22 08:18:14 --> Model Class Initialized
INFO - 2016-02-22 08:18:14 --> Model Class Initialized
INFO - 2016-02-22 08:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:18:14 --> Pagination Class Initialized
INFO - 2016-02-22 08:18:14 --> Helper loaded: text_helper
INFO - 2016-02-22 08:18:14 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 11:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:18:14 --> Final output sent to browser
DEBUG - 2016-02-22 11:18:14 --> Total execution time: 1.1489
INFO - 2016-02-22 08:18:22 --> Config Class Initialized
INFO - 2016-02-22 08:18:22 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:18:22 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:18:22 --> Utf8 Class Initialized
INFO - 2016-02-22 08:18:22 --> URI Class Initialized
INFO - 2016-02-22 08:18:22 --> Router Class Initialized
INFO - 2016-02-22 08:18:22 --> Output Class Initialized
INFO - 2016-02-22 08:18:22 --> Security Class Initialized
DEBUG - 2016-02-22 08:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:18:22 --> Input Class Initialized
INFO - 2016-02-22 08:18:22 --> Language Class Initialized
INFO - 2016-02-22 08:18:22 --> Loader Class Initialized
INFO - 2016-02-22 08:18:22 --> Helper loaded: url_helper
INFO - 2016-02-22 08:18:22 --> Helper loaded: file_helper
INFO - 2016-02-22 08:18:22 --> Helper loaded: date_helper
INFO - 2016-02-22 08:18:22 --> Helper loaded: form_helper
INFO - 2016-02-22 08:18:22 --> Database Driver Class Initialized
INFO - 2016-02-22 08:18:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:18:23 --> Controller Class Initialized
INFO - 2016-02-22 08:18:23 --> Model Class Initialized
INFO - 2016-02-22 08:18:23 --> Model Class Initialized
INFO - 2016-02-22 08:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:18:23 --> Pagination Class Initialized
INFO - 2016-02-22 08:18:23 --> Helper loaded: text_helper
INFO - 2016-02-22 08:18:23 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:18:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 11:18:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 11:18:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:18:24 --> Final output sent to browser
DEBUG - 2016-02-22 11:18:24 --> Total execution time: 1.6087
INFO - 2016-02-22 08:18:31 --> Config Class Initialized
INFO - 2016-02-22 08:18:31 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:18:31 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:18:31 --> Utf8 Class Initialized
INFO - 2016-02-22 08:18:31 --> URI Class Initialized
INFO - 2016-02-22 08:18:31 --> Router Class Initialized
INFO - 2016-02-22 08:18:31 --> Output Class Initialized
INFO - 2016-02-22 08:18:31 --> Security Class Initialized
DEBUG - 2016-02-22 08:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:18:31 --> Input Class Initialized
INFO - 2016-02-22 08:18:31 --> Language Class Initialized
INFO - 2016-02-22 08:18:31 --> Loader Class Initialized
INFO - 2016-02-22 08:18:31 --> Helper loaded: url_helper
INFO - 2016-02-22 08:18:31 --> Helper loaded: file_helper
INFO - 2016-02-22 08:18:31 --> Helper loaded: date_helper
INFO - 2016-02-22 08:18:31 --> Helper loaded: form_helper
INFO - 2016-02-22 08:18:31 --> Database Driver Class Initialized
INFO - 2016-02-22 08:18:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:18:33 --> Controller Class Initialized
INFO - 2016-02-22 08:18:33 --> Model Class Initialized
INFO - 2016-02-22 08:18:33 --> Model Class Initialized
INFO - 2016-02-22 08:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:18:33 --> Pagination Class Initialized
INFO - 2016-02-22 08:18:33 --> Helper loaded: text_helper
INFO - 2016-02-22 08:18:33 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 11:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:18:33 --> Final output sent to browser
DEBUG - 2016-02-22 11:18:33 --> Total execution time: 1.4638
INFO - 2016-02-22 08:20:01 --> Config Class Initialized
INFO - 2016-02-22 08:20:01 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:20:01 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:20:01 --> Utf8 Class Initialized
INFO - 2016-02-22 08:20:01 --> URI Class Initialized
DEBUG - 2016-02-22 08:20:01 --> No URI present. Default controller set.
INFO - 2016-02-22 08:20:01 --> Router Class Initialized
INFO - 2016-02-22 08:20:01 --> Output Class Initialized
INFO - 2016-02-22 08:20:01 --> Security Class Initialized
DEBUG - 2016-02-22 08:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:20:01 --> Input Class Initialized
INFO - 2016-02-22 08:20:01 --> Language Class Initialized
INFO - 2016-02-22 08:20:02 --> Loader Class Initialized
INFO - 2016-02-22 08:20:02 --> Helper loaded: url_helper
INFO - 2016-02-22 08:20:02 --> Helper loaded: file_helper
INFO - 2016-02-22 08:20:02 --> Helper loaded: date_helper
INFO - 2016-02-22 08:20:02 --> Helper loaded: form_helper
INFO - 2016-02-22 08:20:02 --> Database Driver Class Initialized
INFO - 2016-02-22 08:20:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:20:03 --> Controller Class Initialized
INFO - 2016-02-22 08:20:03 --> Model Class Initialized
INFO - 2016-02-22 08:20:03 --> Model Class Initialized
INFO - 2016-02-22 08:20:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:20:03 --> Pagination Class Initialized
INFO - 2016-02-22 08:20:03 --> Helper loaded: text_helper
INFO - 2016-02-22 08:20:03 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:20:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:20:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 11:20:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-22 11:20:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-22 08:20:16 --> Config Class Initialized
INFO - 2016-02-22 08:20:16 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:20:16 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:20:16 --> Utf8 Class Initialized
INFO - 2016-02-22 08:20:16 --> URI Class Initialized
INFO - 2016-02-22 08:20:16 --> Router Class Initialized
INFO - 2016-02-22 08:20:16 --> Output Class Initialized
INFO - 2016-02-22 08:20:16 --> Security Class Initialized
DEBUG - 2016-02-22 08:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:20:16 --> Input Class Initialized
INFO - 2016-02-22 08:20:16 --> Language Class Initialized
INFO - 2016-02-22 08:20:16 --> Loader Class Initialized
INFO - 2016-02-22 08:20:16 --> Helper loaded: url_helper
INFO - 2016-02-22 08:20:16 --> Helper loaded: file_helper
INFO - 2016-02-22 08:20:16 --> Helper loaded: date_helper
INFO - 2016-02-22 08:20:16 --> Helper loaded: form_helper
INFO - 2016-02-22 08:20:16 --> Database Driver Class Initialized
INFO - 2016-02-22 08:20:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:20:17 --> Controller Class Initialized
INFO - 2016-02-22 08:20:17 --> Model Class Initialized
INFO - 2016-02-22 08:20:17 --> Model Class Initialized
INFO - 2016-02-22 08:20:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:20:17 --> Pagination Class Initialized
INFO - 2016-02-22 08:20:17 --> Helper loaded: text_helper
INFO - 2016-02-22 08:20:17 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 11:20:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:20:17 --> Final output sent to browser
DEBUG - 2016-02-22 11:20:17 --> Total execution time: 1.2040
INFO - 2016-02-22 08:20:21 --> Config Class Initialized
INFO - 2016-02-22 08:20:21 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:20:21 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:20:21 --> Utf8 Class Initialized
INFO - 2016-02-22 08:20:21 --> URI Class Initialized
INFO - 2016-02-22 08:20:21 --> Router Class Initialized
INFO - 2016-02-22 08:20:21 --> Output Class Initialized
INFO - 2016-02-22 08:20:21 --> Security Class Initialized
DEBUG - 2016-02-22 08:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:20:21 --> Input Class Initialized
INFO - 2016-02-22 08:20:21 --> Language Class Initialized
INFO - 2016-02-22 08:20:21 --> Loader Class Initialized
INFO - 2016-02-22 08:20:21 --> Helper loaded: url_helper
INFO - 2016-02-22 08:20:21 --> Helper loaded: file_helper
INFO - 2016-02-22 08:20:21 --> Helper loaded: date_helper
INFO - 2016-02-22 08:20:21 --> Helper loaded: form_helper
INFO - 2016-02-22 08:20:21 --> Database Driver Class Initialized
INFO - 2016-02-22 08:20:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:20:22 --> Controller Class Initialized
INFO - 2016-02-22 08:20:22 --> Model Class Initialized
INFO - 2016-02-22 08:20:22 --> Model Class Initialized
INFO - 2016-02-22 08:20:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:20:22 --> Pagination Class Initialized
INFO - 2016-02-22 08:20:22 --> Helper loaded: text_helper
INFO - 2016-02-22 08:20:22 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 11:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 11:20:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:20:22 --> Final output sent to browser
DEBUG - 2016-02-22 11:20:22 --> Total execution time: 1.1883
INFO - 2016-02-22 08:20:30 --> Config Class Initialized
INFO - 2016-02-22 08:20:30 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:20:30 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:20:30 --> Utf8 Class Initialized
INFO - 2016-02-22 08:20:30 --> URI Class Initialized
INFO - 2016-02-22 08:20:30 --> Router Class Initialized
INFO - 2016-02-22 08:20:30 --> Output Class Initialized
INFO - 2016-02-22 08:20:30 --> Security Class Initialized
DEBUG - 2016-02-22 08:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:20:30 --> Input Class Initialized
INFO - 2016-02-22 08:20:30 --> Language Class Initialized
INFO - 2016-02-22 08:20:30 --> Loader Class Initialized
INFO - 2016-02-22 08:20:30 --> Helper loaded: url_helper
INFO - 2016-02-22 08:20:30 --> Helper loaded: file_helper
INFO - 2016-02-22 08:20:30 --> Helper loaded: date_helper
INFO - 2016-02-22 08:20:30 --> Helper loaded: form_helper
INFO - 2016-02-22 08:20:30 --> Database Driver Class Initialized
INFO - 2016-02-22 08:20:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:20:31 --> Controller Class Initialized
INFO - 2016-02-22 08:20:31 --> Model Class Initialized
INFO - 2016-02-22 08:20:31 --> Model Class Initialized
INFO - 2016-02-22 08:20:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:20:31 --> Pagination Class Initialized
INFO - 2016-02-22 08:20:31 --> Helper loaded: text_helper
INFO - 2016-02-22 08:20:31 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 11:20:31 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 11:20:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:20:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:20:31 --> Form Validation Class Initialized
INFO - 2016-02-22 11:20:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 08:20:32 --> Config Class Initialized
INFO - 2016-02-22 08:20:32 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:20:32 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:20:32 --> Utf8 Class Initialized
INFO - 2016-02-22 08:20:32 --> URI Class Initialized
INFO - 2016-02-22 08:20:32 --> Router Class Initialized
INFO - 2016-02-22 08:20:32 --> Output Class Initialized
INFO - 2016-02-22 08:20:32 --> Security Class Initialized
DEBUG - 2016-02-22 08:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:20:32 --> Input Class Initialized
INFO - 2016-02-22 08:20:32 --> Language Class Initialized
INFO - 2016-02-22 08:20:32 --> Loader Class Initialized
INFO - 2016-02-22 08:20:32 --> Helper loaded: url_helper
INFO - 2016-02-22 08:20:32 --> Helper loaded: file_helper
INFO - 2016-02-22 08:20:32 --> Helper loaded: date_helper
INFO - 2016-02-22 08:20:32 --> Helper loaded: form_helper
INFO - 2016-02-22 08:20:32 --> Database Driver Class Initialized
INFO - 2016-02-22 08:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:20:33 --> Controller Class Initialized
INFO - 2016-02-22 08:20:33 --> Model Class Initialized
INFO - 2016-02-22 08:20:33 --> Model Class Initialized
INFO - 2016-02-22 08:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:20:33 --> Pagination Class Initialized
INFO - 2016-02-22 08:20:33 --> Helper loaded: text_helper
INFO - 2016-02-22 08:20:33 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 11:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 11:20:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:20:33 --> Final output sent to browser
DEBUG - 2016-02-22 11:20:33 --> Total execution time: 1.4454
INFO - 2016-02-22 08:20:37 --> Config Class Initialized
INFO - 2016-02-22 08:20:37 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:20:37 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:20:37 --> Utf8 Class Initialized
INFO - 2016-02-22 08:20:37 --> URI Class Initialized
INFO - 2016-02-22 08:20:37 --> Router Class Initialized
INFO - 2016-02-22 08:20:37 --> Output Class Initialized
INFO - 2016-02-22 08:20:37 --> Security Class Initialized
DEBUG - 2016-02-22 08:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:20:37 --> Input Class Initialized
INFO - 2016-02-22 08:20:37 --> Language Class Initialized
INFO - 2016-02-22 08:20:37 --> Loader Class Initialized
INFO - 2016-02-22 08:20:37 --> Helper loaded: url_helper
INFO - 2016-02-22 08:20:37 --> Helper loaded: file_helper
INFO - 2016-02-22 08:20:37 --> Helper loaded: date_helper
INFO - 2016-02-22 08:20:37 --> Helper loaded: form_helper
INFO - 2016-02-22 08:20:37 --> Database Driver Class Initialized
INFO - 2016-02-22 08:20:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:20:38 --> Controller Class Initialized
INFO - 2016-02-22 08:20:38 --> Model Class Initialized
INFO - 2016-02-22 08:20:38 --> Model Class Initialized
INFO - 2016-02-22 08:20:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:20:38 --> Pagination Class Initialized
INFO - 2016-02-22 08:20:38 --> Helper loaded: text_helper
INFO - 2016-02-22 08:20:38 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-22 11:20:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:20:38 --> Final output sent to browser
DEBUG - 2016-02-22 11:20:38 --> Total execution time: 1.4231
INFO - 2016-02-22 08:21:04 --> Config Class Initialized
INFO - 2016-02-22 08:21:04 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:21:04 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:21:04 --> Utf8 Class Initialized
INFO - 2016-02-22 08:21:04 --> URI Class Initialized
INFO - 2016-02-22 08:21:04 --> Router Class Initialized
INFO - 2016-02-22 08:21:04 --> Output Class Initialized
INFO - 2016-02-22 08:21:04 --> Security Class Initialized
DEBUG - 2016-02-22 08:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:21:04 --> Input Class Initialized
INFO - 2016-02-22 08:21:04 --> Language Class Initialized
INFO - 2016-02-22 08:21:04 --> Loader Class Initialized
INFO - 2016-02-22 08:21:04 --> Helper loaded: url_helper
INFO - 2016-02-22 08:21:04 --> Helper loaded: file_helper
INFO - 2016-02-22 08:21:04 --> Helper loaded: date_helper
INFO - 2016-02-22 08:21:04 --> Helper loaded: form_helper
INFO - 2016-02-22 08:21:04 --> Database Driver Class Initialized
INFO - 2016-02-22 08:21:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:21:05 --> Controller Class Initialized
INFO - 2016-02-22 08:21:05 --> Model Class Initialized
INFO - 2016-02-22 08:21:05 --> Model Class Initialized
INFO - 2016-02-22 08:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:21:05 --> Pagination Class Initialized
INFO - 2016-02-22 08:21:05 --> Helper loaded: text_helper
INFO - 2016-02-22 08:21:05 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:21:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:21:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:21:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 11:21:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:21:05 --> Final output sent to browser
DEBUG - 2016-02-22 11:21:05 --> Total execution time: 1.1703
INFO - 2016-02-22 08:21:06 --> Config Class Initialized
INFO - 2016-02-22 08:21:06 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:21:06 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:21:07 --> Utf8 Class Initialized
INFO - 2016-02-22 08:21:07 --> URI Class Initialized
INFO - 2016-02-22 08:21:07 --> Router Class Initialized
INFO - 2016-02-22 08:21:07 --> Output Class Initialized
INFO - 2016-02-22 08:21:07 --> Security Class Initialized
DEBUG - 2016-02-22 08:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:21:07 --> Input Class Initialized
INFO - 2016-02-22 08:21:07 --> Language Class Initialized
INFO - 2016-02-22 08:21:07 --> Loader Class Initialized
INFO - 2016-02-22 08:21:07 --> Helper loaded: url_helper
INFO - 2016-02-22 08:21:07 --> Helper loaded: file_helper
INFO - 2016-02-22 08:21:07 --> Helper loaded: date_helper
INFO - 2016-02-22 08:21:07 --> Helper loaded: form_helper
INFO - 2016-02-22 08:21:07 --> Database Driver Class Initialized
INFO - 2016-02-22 08:21:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:21:08 --> Controller Class Initialized
INFO - 2016-02-22 08:21:08 --> Model Class Initialized
INFO - 2016-02-22 08:21:08 --> Model Class Initialized
INFO - 2016-02-22 08:21:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:21:08 --> Pagination Class Initialized
INFO - 2016-02-22 08:21:08 --> Helper loaded: text_helper
INFO - 2016-02-22 08:21:08 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:21:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:21:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:21:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 11:21:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 11:21:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:21:08 --> Final output sent to browser
DEBUG - 2016-02-22 11:21:08 --> Total execution time: 1.1244
INFO - 2016-02-22 08:21:13 --> Config Class Initialized
INFO - 2016-02-22 08:21:13 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:21:13 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:21:13 --> Utf8 Class Initialized
INFO - 2016-02-22 08:21:13 --> URI Class Initialized
INFO - 2016-02-22 08:21:13 --> Router Class Initialized
INFO - 2016-02-22 08:21:13 --> Output Class Initialized
INFO - 2016-02-22 08:21:13 --> Security Class Initialized
DEBUG - 2016-02-22 08:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:21:13 --> Input Class Initialized
INFO - 2016-02-22 08:21:13 --> Language Class Initialized
INFO - 2016-02-22 08:21:13 --> Loader Class Initialized
INFO - 2016-02-22 08:21:13 --> Helper loaded: url_helper
INFO - 2016-02-22 08:21:13 --> Helper loaded: file_helper
INFO - 2016-02-22 08:21:13 --> Helper loaded: date_helper
INFO - 2016-02-22 08:21:13 --> Helper loaded: form_helper
INFO - 2016-02-22 08:21:13 --> Database Driver Class Initialized
INFO - 2016-02-22 08:21:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:21:14 --> Controller Class Initialized
INFO - 2016-02-22 08:21:14 --> Model Class Initialized
INFO - 2016-02-22 08:21:14 --> Model Class Initialized
INFO - 2016-02-22 08:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:21:14 --> Pagination Class Initialized
INFO - 2016-02-22 08:21:14 --> Helper loaded: text_helper
INFO - 2016-02-22 08:21:14 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 11:21:14 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 11:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:21:14 --> Form Validation Class Initialized
INFO - 2016-02-22 11:21:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 08:21:14 --> Config Class Initialized
INFO - 2016-02-22 08:21:14 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:21:14 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:21:14 --> Utf8 Class Initialized
INFO - 2016-02-22 08:21:14 --> URI Class Initialized
INFO - 2016-02-22 08:21:14 --> Router Class Initialized
INFO - 2016-02-22 08:21:14 --> Output Class Initialized
INFO - 2016-02-22 08:21:14 --> Security Class Initialized
DEBUG - 2016-02-22 08:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:21:14 --> Input Class Initialized
INFO - 2016-02-22 08:21:14 --> Language Class Initialized
INFO - 2016-02-22 08:21:14 --> Loader Class Initialized
INFO - 2016-02-22 08:21:14 --> Helper loaded: url_helper
INFO - 2016-02-22 08:21:14 --> Helper loaded: file_helper
INFO - 2016-02-22 08:21:14 --> Helper loaded: date_helper
INFO - 2016-02-22 08:21:14 --> Helper loaded: form_helper
INFO - 2016-02-22 08:21:14 --> Database Driver Class Initialized
INFO - 2016-02-22 08:21:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:21:15 --> Controller Class Initialized
INFO - 2016-02-22 08:21:15 --> Model Class Initialized
INFO - 2016-02-22 08:21:15 --> Model Class Initialized
INFO - 2016-02-22 08:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:21:15 --> Pagination Class Initialized
INFO - 2016-02-22 08:21:15 --> Helper loaded: text_helper
INFO - 2016-02-22 08:21:15 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 11:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 11:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:21:15 --> Final output sent to browser
DEBUG - 2016-02-22 11:21:15 --> Total execution time: 1.1847
INFO - 2016-02-22 08:21:17 --> Config Class Initialized
INFO - 2016-02-22 08:21:17 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:21:17 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:21:17 --> Utf8 Class Initialized
INFO - 2016-02-22 08:21:17 --> URI Class Initialized
INFO - 2016-02-22 08:21:17 --> Router Class Initialized
INFO - 2016-02-22 08:21:17 --> Output Class Initialized
INFO - 2016-02-22 08:21:17 --> Security Class Initialized
DEBUG - 2016-02-22 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:21:17 --> Input Class Initialized
INFO - 2016-02-22 08:21:17 --> Language Class Initialized
INFO - 2016-02-22 08:21:17 --> Loader Class Initialized
INFO - 2016-02-22 08:21:17 --> Helper loaded: url_helper
INFO - 2016-02-22 08:21:17 --> Helper loaded: file_helper
INFO - 2016-02-22 08:21:17 --> Helper loaded: date_helper
INFO - 2016-02-22 08:21:17 --> Helper loaded: form_helper
INFO - 2016-02-22 08:21:17 --> Database Driver Class Initialized
INFO - 2016-02-22 08:21:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:21:18 --> Controller Class Initialized
INFO - 2016-02-22 08:21:18 --> Model Class Initialized
INFO - 2016-02-22 08:21:18 --> Model Class Initialized
INFO - 2016-02-22 08:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:21:18 --> Pagination Class Initialized
INFO - 2016-02-22 08:21:18 --> Helper loaded: text_helper
INFO - 2016-02-22 08:21:18 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:21:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:21:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:21:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-22 11:21:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:21:18 --> Final output sent to browser
DEBUG - 2016-02-22 11:21:18 --> Total execution time: 1.1819
INFO - 2016-02-22 08:24:31 --> Config Class Initialized
INFO - 2016-02-22 08:24:31 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:24:31 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:24:31 --> Utf8 Class Initialized
INFO - 2016-02-22 08:24:31 --> URI Class Initialized
INFO - 2016-02-22 08:24:31 --> Router Class Initialized
INFO - 2016-02-22 08:24:31 --> Output Class Initialized
INFO - 2016-02-22 08:24:31 --> Security Class Initialized
DEBUG - 2016-02-22 08:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:24:31 --> Input Class Initialized
INFO - 2016-02-22 08:24:31 --> Language Class Initialized
INFO - 2016-02-22 08:24:31 --> Loader Class Initialized
INFO - 2016-02-22 08:24:31 --> Helper loaded: url_helper
INFO - 2016-02-22 08:24:31 --> Helper loaded: file_helper
INFO - 2016-02-22 08:24:31 --> Helper loaded: date_helper
INFO - 2016-02-22 08:24:31 --> Helper loaded: form_helper
INFO - 2016-02-22 08:24:31 --> Database Driver Class Initialized
INFO - 2016-02-22 08:24:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:24:32 --> Controller Class Initialized
INFO - 2016-02-22 08:24:32 --> Model Class Initialized
INFO - 2016-02-22 08:24:32 --> Model Class Initialized
INFO - 2016-02-22 08:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:24:32 --> Pagination Class Initialized
INFO - 2016-02-22 08:24:32 --> Helper loaded: text_helper
INFO - 2016-02-22 08:24:32 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 11:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:24:32 --> Final output sent to browser
DEBUG - 2016-02-22 11:24:32 --> Total execution time: 1.1567
INFO - 2016-02-22 08:24:35 --> Config Class Initialized
INFO - 2016-02-22 08:24:35 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:24:35 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:24:35 --> Utf8 Class Initialized
INFO - 2016-02-22 08:24:35 --> URI Class Initialized
INFO - 2016-02-22 08:24:35 --> Router Class Initialized
INFO - 2016-02-22 08:24:35 --> Output Class Initialized
INFO - 2016-02-22 08:24:35 --> Security Class Initialized
DEBUG - 2016-02-22 08:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:24:35 --> Input Class Initialized
INFO - 2016-02-22 08:24:35 --> Language Class Initialized
INFO - 2016-02-22 08:24:35 --> Loader Class Initialized
INFO - 2016-02-22 08:24:35 --> Helper loaded: url_helper
INFO - 2016-02-22 08:24:35 --> Helper loaded: file_helper
INFO - 2016-02-22 08:24:35 --> Helper loaded: date_helper
INFO - 2016-02-22 08:24:35 --> Helper loaded: form_helper
INFO - 2016-02-22 08:24:35 --> Database Driver Class Initialized
INFO - 2016-02-22 08:24:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:24:36 --> Controller Class Initialized
INFO - 2016-02-22 08:24:36 --> Model Class Initialized
INFO - 2016-02-22 08:24:36 --> Model Class Initialized
INFO - 2016-02-22 08:24:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:24:36 --> Pagination Class Initialized
INFO - 2016-02-22 08:24:36 --> Helper loaded: text_helper
INFO - 2016-02-22 08:24:36 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 11:24:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:24:36 --> Final output sent to browser
DEBUG - 2016-02-22 11:24:36 --> Total execution time: 1.1097
INFO - 2016-02-22 08:24:41 --> Config Class Initialized
INFO - 2016-02-22 08:24:41 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:24:41 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:24:41 --> Utf8 Class Initialized
INFO - 2016-02-22 08:24:41 --> URI Class Initialized
INFO - 2016-02-22 08:24:41 --> Router Class Initialized
INFO - 2016-02-22 08:24:41 --> Output Class Initialized
INFO - 2016-02-22 08:24:41 --> Security Class Initialized
DEBUG - 2016-02-22 08:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:24:41 --> Input Class Initialized
INFO - 2016-02-22 08:24:42 --> Language Class Initialized
INFO - 2016-02-22 08:24:42 --> Loader Class Initialized
INFO - 2016-02-22 08:24:42 --> Helper loaded: url_helper
INFO - 2016-02-22 08:24:42 --> Helper loaded: file_helper
INFO - 2016-02-22 08:24:42 --> Helper loaded: date_helper
INFO - 2016-02-22 08:24:42 --> Helper loaded: form_helper
INFO - 2016-02-22 08:24:42 --> Database Driver Class Initialized
INFO - 2016-02-22 08:24:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:24:43 --> Controller Class Initialized
INFO - 2016-02-22 08:24:43 --> Model Class Initialized
INFO - 2016-02-22 08:24:43 --> Model Class Initialized
INFO - 2016-02-22 08:24:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:24:43 --> Pagination Class Initialized
INFO - 2016-02-22 08:24:43 --> Helper loaded: text_helper
INFO - 2016-02-22 08:24:43 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 11:24:43 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 11:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:24:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:24:43 --> Form Validation Class Initialized
INFO - 2016-02-22 11:24:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 08:24:43 --> Config Class Initialized
INFO - 2016-02-22 08:24:43 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:24:43 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:24:43 --> Utf8 Class Initialized
INFO - 2016-02-22 08:24:43 --> URI Class Initialized
INFO - 2016-02-22 08:24:43 --> Router Class Initialized
INFO - 2016-02-22 08:24:43 --> Output Class Initialized
INFO - 2016-02-22 08:24:43 --> Security Class Initialized
DEBUG - 2016-02-22 08:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:24:43 --> Input Class Initialized
INFO - 2016-02-22 08:24:43 --> Language Class Initialized
INFO - 2016-02-22 08:24:43 --> Loader Class Initialized
INFO - 2016-02-22 08:24:43 --> Helper loaded: url_helper
INFO - 2016-02-22 08:24:43 --> Helper loaded: file_helper
INFO - 2016-02-22 08:24:43 --> Helper loaded: date_helper
INFO - 2016-02-22 08:24:43 --> Helper loaded: form_helper
INFO - 2016-02-22 08:24:43 --> Database Driver Class Initialized
INFO - 2016-02-22 08:24:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:24:44 --> Controller Class Initialized
INFO - 2016-02-22 08:24:44 --> Model Class Initialized
INFO - 2016-02-22 08:24:44 --> Model Class Initialized
INFO - 2016-02-22 08:24:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:24:44 --> Pagination Class Initialized
INFO - 2016-02-22 08:24:44 --> Helper loaded: text_helper
INFO - 2016-02-22 08:24:44 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 11:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 11:24:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:24:44 --> Final output sent to browser
DEBUG - 2016-02-22 11:24:44 --> Total execution time: 1.1641
INFO - 2016-02-22 08:24:46 --> Config Class Initialized
INFO - 2016-02-22 08:24:46 --> Hooks Class Initialized
DEBUG - 2016-02-22 08:24:46 --> UTF-8 Support Enabled
INFO - 2016-02-22 08:24:46 --> Utf8 Class Initialized
INFO - 2016-02-22 08:24:46 --> URI Class Initialized
INFO - 2016-02-22 08:24:46 --> Router Class Initialized
INFO - 2016-02-22 08:24:46 --> Output Class Initialized
INFO - 2016-02-22 08:24:46 --> Security Class Initialized
DEBUG - 2016-02-22 08:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 08:24:46 --> Input Class Initialized
INFO - 2016-02-22 08:24:46 --> Language Class Initialized
INFO - 2016-02-22 08:24:46 --> Loader Class Initialized
INFO - 2016-02-22 08:24:46 --> Helper loaded: url_helper
INFO - 2016-02-22 08:24:46 --> Helper loaded: file_helper
INFO - 2016-02-22 08:24:46 --> Helper loaded: date_helper
INFO - 2016-02-22 08:24:46 --> Helper loaded: form_helper
INFO - 2016-02-22 08:24:46 --> Database Driver Class Initialized
INFO - 2016-02-22 08:24:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 08:24:47 --> Controller Class Initialized
INFO - 2016-02-22 08:24:47 --> Model Class Initialized
INFO - 2016-02-22 08:24:47 --> Model Class Initialized
INFO - 2016-02-22 08:24:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 08:24:47 --> Pagination Class Initialized
INFO - 2016-02-22 08:24:47 --> Helper loaded: text_helper
INFO - 2016-02-22 08:24:47 --> Helper loaded: cookie_helper
INFO - 2016-02-22 11:24:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 11:24:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:24:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-22 11:24:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 11:24:47 --> Final output sent to browser
DEBUG - 2016-02-22 11:24:47 --> Total execution time: 1.1904
INFO - 2016-02-22 09:45:30 --> Config Class Initialized
INFO - 2016-02-22 09:45:30 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:45:30 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:45:30 --> Utf8 Class Initialized
INFO - 2016-02-22 09:45:30 --> URI Class Initialized
INFO - 2016-02-22 09:45:30 --> Router Class Initialized
INFO - 2016-02-22 09:45:30 --> Output Class Initialized
INFO - 2016-02-22 09:45:30 --> Security Class Initialized
DEBUG - 2016-02-22 09:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:45:30 --> Input Class Initialized
INFO - 2016-02-22 09:45:30 --> Language Class Initialized
INFO - 2016-02-22 09:45:30 --> Loader Class Initialized
INFO - 2016-02-22 09:45:30 --> Helper loaded: url_helper
INFO - 2016-02-22 09:45:30 --> Helper loaded: file_helper
INFO - 2016-02-22 09:45:30 --> Helper loaded: date_helper
INFO - 2016-02-22 09:45:30 --> Helper loaded: form_helper
INFO - 2016-02-22 09:45:30 --> Database Driver Class Initialized
INFO - 2016-02-22 09:45:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:45:31 --> Controller Class Initialized
INFO - 2016-02-22 09:45:31 --> Model Class Initialized
INFO - 2016-02-22 09:45:31 --> Model Class Initialized
INFO - 2016-02-22 09:45:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:45:31 --> Pagination Class Initialized
INFO - 2016-02-22 09:45:31 --> Helper loaded: text_helper
INFO - 2016-02-22 09:45:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 12:45:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:45:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:45:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 12:45:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 12:45:31 --> Final output sent to browser
DEBUG - 2016-02-22 12:45:31 --> Total execution time: 1.1735
INFO - 2016-02-22 09:45:38 --> Config Class Initialized
INFO - 2016-02-22 09:45:38 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:45:38 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:45:38 --> Utf8 Class Initialized
INFO - 2016-02-22 09:45:38 --> URI Class Initialized
INFO - 2016-02-22 09:45:38 --> Router Class Initialized
INFO - 2016-02-22 09:45:38 --> Output Class Initialized
INFO - 2016-02-22 09:45:38 --> Security Class Initialized
DEBUG - 2016-02-22 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:45:38 --> Input Class Initialized
INFO - 2016-02-22 09:45:38 --> Language Class Initialized
INFO - 2016-02-22 09:45:38 --> Loader Class Initialized
INFO - 2016-02-22 09:45:38 --> Helper loaded: url_helper
INFO - 2016-02-22 09:45:38 --> Helper loaded: file_helper
INFO - 2016-02-22 09:45:38 --> Helper loaded: date_helper
INFO - 2016-02-22 09:45:38 --> Helper loaded: form_helper
INFO - 2016-02-22 09:45:38 --> Database Driver Class Initialized
INFO - 2016-02-22 09:45:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:45:39 --> Controller Class Initialized
INFO - 2016-02-22 09:45:39 --> Model Class Initialized
INFO - 2016-02-22 09:45:39 --> Model Class Initialized
INFO - 2016-02-22 09:45:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:45:39 --> Pagination Class Initialized
INFO - 2016-02-22 09:45:39 --> Helper loaded: text_helper
INFO - 2016-02-22 09:45:39 --> Helper loaded: cookie_helper
INFO - 2016-02-22 12:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 12:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 12:45:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 12:45:39 --> Final output sent to browser
DEBUG - 2016-02-22 12:45:39 --> Total execution time: 1.1313
INFO - 2016-02-22 09:45:49 --> Config Class Initialized
INFO - 2016-02-22 09:45:49 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:45:49 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:45:49 --> Utf8 Class Initialized
INFO - 2016-02-22 09:45:49 --> URI Class Initialized
INFO - 2016-02-22 09:45:49 --> Router Class Initialized
INFO - 2016-02-22 09:45:49 --> Output Class Initialized
INFO - 2016-02-22 09:45:49 --> Security Class Initialized
DEBUG - 2016-02-22 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:45:49 --> Input Class Initialized
INFO - 2016-02-22 09:45:49 --> Language Class Initialized
INFO - 2016-02-22 09:45:49 --> Loader Class Initialized
INFO - 2016-02-22 09:45:49 --> Helper loaded: url_helper
INFO - 2016-02-22 09:45:49 --> Helper loaded: file_helper
INFO - 2016-02-22 09:45:49 --> Helper loaded: date_helper
INFO - 2016-02-22 09:45:49 --> Helper loaded: form_helper
INFO - 2016-02-22 09:45:49 --> Database Driver Class Initialized
INFO - 2016-02-22 09:45:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:45:50 --> Controller Class Initialized
INFO - 2016-02-22 09:45:50 --> Model Class Initialized
INFO - 2016-02-22 09:45:50 --> Model Class Initialized
INFO - 2016-02-22 09:45:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:45:50 --> Pagination Class Initialized
INFO - 2016-02-22 09:45:50 --> Helper loaded: text_helper
INFO - 2016-02-22 09:45:50 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 12:45:50 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 12:45:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:45:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:45:50 --> Form Validation Class Initialized
INFO - 2016-02-22 12:45:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 09:45:50 --> Config Class Initialized
INFO - 2016-02-22 09:45:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:45:50 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:45:50 --> Utf8 Class Initialized
INFO - 2016-02-22 09:45:50 --> URI Class Initialized
INFO - 2016-02-22 09:45:50 --> Router Class Initialized
INFO - 2016-02-22 09:45:50 --> Output Class Initialized
INFO - 2016-02-22 09:45:50 --> Security Class Initialized
DEBUG - 2016-02-22 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:45:50 --> Input Class Initialized
INFO - 2016-02-22 09:45:50 --> Language Class Initialized
INFO - 2016-02-22 09:45:50 --> Loader Class Initialized
INFO - 2016-02-22 09:45:50 --> Helper loaded: url_helper
INFO - 2016-02-22 09:45:50 --> Helper loaded: file_helper
INFO - 2016-02-22 09:45:50 --> Helper loaded: date_helper
INFO - 2016-02-22 09:45:50 --> Helper loaded: form_helper
INFO - 2016-02-22 09:45:50 --> Database Driver Class Initialized
INFO - 2016-02-22 09:45:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:45:51 --> Controller Class Initialized
INFO - 2016-02-22 09:45:51 --> Model Class Initialized
INFO - 2016-02-22 09:45:51 --> Model Class Initialized
INFO - 2016-02-22 09:45:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:45:51 --> Pagination Class Initialized
INFO - 2016-02-22 09:45:51 --> Helper loaded: text_helper
INFO - 2016-02-22 09:45:51 --> Helper loaded: cookie_helper
INFO - 2016-02-22 12:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 12:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 12:45:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 12:45:51 --> Final output sent to browser
DEBUG - 2016-02-22 12:45:51 --> Total execution time: 1.1628
INFO - 2016-02-22 09:48:07 --> Config Class Initialized
INFO - 2016-02-22 09:48:07 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:48:07 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:48:07 --> Utf8 Class Initialized
INFO - 2016-02-22 09:48:07 --> URI Class Initialized
INFO - 2016-02-22 09:48:07 --> Router Class Initialized
INFO - 2016-02-22 09:48:07 --> Output Class Initialized
INFO - 2016-02-22 09:48:07 --> Security Class Initialized
DEBUG - 2016-02-22 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:48:07 --> Input Class Initialized
INFO - 2016-02-22 09:48:07 --> Language Class Initialized
INFO - 2016-02-22 09:48:07 --> Loader Class Initialized
INFO - 2016-02-22 09:48:07 --> Helper loaded: url_helper
INFO - 2016-02-22 09:48:07 --> Helper loaded: file_helper
INFO - 2016-02-22 09:48:07 --> Helper loaded: date_helper
INFO - 2016-02-22 09:48:07 --> Helper loaded: form_helper
INFO - 2016-02-22 09:48:07 --> Database Driver Class Initialized
INFO - 2016-02-22 09:48:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:48:08 --> Controller Class Initialized
INFO - 2016-02-22 09:48:08 --> Model Class Initialized
INFO - 2016-02-22 09:48:08 --> Model Class Initialized
INFO - 2016-02-22 09:48:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:48:08 --> Pagination Class Initialized
INFO - 2016-02-22 09:48:08 --> Helper loaded: text_helper
INFO - 2016-02-22 09:48:08 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 12:48:08 --> Severity: Notice --> Undefined variable: single_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 170
ERROR - 2016-02-22 12:48:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 170
INFO - 2016-02-22 12:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 12:48:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 12:48:08 --> Final output sent to browser
DEBUG - 2016-02-22 12:48:08 --> Total execution time: 1.1470
INFO - 2016-02-22 09:48:09 --> Config Class Initialized
INFO - 2016-02-22 09:48:09 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:48:09 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:48:09 --> Utf8 Class Initialized
INFO - 2016-02-22 09:48:09 --> URI Class Initialized
INFO - 2016-02-22 09:48:09 --> Router Class Initialized
INFO - 2016-02-22 09:48:09 --> Output Class Initialized
INFO - 2016-02-22 09:48:09 --> Security Class Initialized
DEBUG - 2016-02-22 09:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:48:09 --> Input Class Initialized
INFO - 2016-02-22 09:48:09 --> Language Class Initialized
INFO - 2016-02-22 09:48:09 --> Loader Class Initialized
INFO - 2016-02-22 09:48:09 --> Helper loaded: url_helper
INFO - 2016-02-22 09:48:09 --> Helper loaded: file_helper
INFO - 2016-02-22 09:48:09 --> Helper loaded: date_helper
INFO - 2016-02-22 09:48:09 --> Helper loaded: form_helper
INFO - 2016-02-22 09:48:09 --> Database Driver Class Initialized
INFO - 2016-02-22 09:48:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:48:10 --> Controller Class Initialized
INFO - 2016-02-22 09:48:10 --> Model Class Initialized
INFO - 2016-02-22 09:48:10 --> Model Class Initialized
INFO - 2016-02-22 09:48:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:48:10 --> Pagination Class Initialized
INFO - 2016-02-22 09:48:10 --> Helper loaded: text_helper
INFO - 2016-02-22 09:48:10 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 12:48:10 --> Severity: Notice --> Undefined variable: single_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 170
ERROR - 2016-02-22 12:48:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 170
INFO - 2016-02-22 12:48:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:48:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:48:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 12:48:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 12:48:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 12:48:10 --> Final output sent to browser
DEBUG - 2016-02-22 12:48:10 --> Total execution time: 1.2074
INFO - 2016-02-22 09:48:31 --> Config Class Initialized
INFO - 2016-02-22 09:48:31 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:48:31 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:48:31 --> Utf8 Class Initialized
INFO - 2016-02-22 09:48:31 --> URI Class Initialized
INFO - 2016-02-22 09:48:31 --> Router Class Initialized
INFO - 2016-02-22 09:48:31 --> Output Class Initialized
INFO - 2016-02-22 09:48:31 --> Security Class Initialized
DEBUG - 2016-02-22 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:48:31 --> Input Class Initialized
INFO - 2016-02-22 09:48:31 --> Language Class Initialized
INFO - 2016-02-22 09:48:31 --> Loader Class Initialized
INFO - 2016-02-22 09:48:31 --> Helper loaded: url_helper
INFO - 2016-02-22 09:48:31 --> Helper loaded: file_helper
INFO - 2016-02-22 09:48:31 --> Helper loaded: date_helper
INFO - 2016-02-22 09:48:31 --> Helper loaded: form_helper
INFO - 2016-02-22 09:48:31 --> Database Driver Class Initialized
INFO - 2016-02-22 09:48:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:48:32 --> Controller Class Initialized
INFO - 2016-02-22 09:48:32 --> Model Class Initialized
INFO - 2016-02-22 09:48:32 --> Model Class Initialized
INFO - 2016-02-22 09:48:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:48:32 --> Pagination Class Initialized
INFO - 2016-02-22 09:48:32 --> Helper loaded: text_helper
INFO - 2016-02-22 09:48:32 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 12:48:32 --> Severity: Notice --> Undefined variable: single_result C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 170
ERROR - 2016-02-22 12:48:32 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 170
INFO - 2016-02-22 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 12:48:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 12:48:32 --> Final output sent to browser
DEBUG - 2016-02-22 12:48:32 --> Total execution time: 1.1656
INFO - 2016-02-22 09:53:29 --> Config Class Initialized
INFO - 2016-02-22 09:53:29 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:53:29 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:53:29 --> Utf8 Class Initialized
INFO - 2016-02-22 09:53:29 --> URI Class Initialized
INFO - 2016-02-22 09:53:29 --> Router Class Initialized
INFO - 2016-02-22 09:53:29 --> Output Class Initialized
INFO - 2016-02-22 09:53:29 --> Security Class Initialized
DEBUG - 2016-02-22 09:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:53:29 --> Input Class Initialized
INFO - 2016-02-22 09:53:29 --> Language Class Initialized
INFO - 2016-02-22 09:53:29 --> Loader Class Initialized
INFO - 2016-02-22 09:53:29 --> Helper loaded: url_helper
INFO - 2016-02-22 09:53:29 --> Helper loaded: file_helper
INFO - 2016-02-22 09:53:29 --> Helper loaded: date_helper
INFO - 2016-02-22 09:53:29 --> Helper loaded: form_helper
INFO - 2016-02-22 09:53:29 --> Database Driver Class Initialized
INFO - 2016-02-22 09:53:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:53:30 --> Controller Class Initialized
INFO - 2016-02-22 09:53:30 --> Model Class Initialized
INFO - 2016-02-22 09:53:30 --> Model Class Initialized
INFO - 2016-02-22 09:53:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:53:30 --> Pagination Class Initialized
INFO - 2016-02-22 09:53:30 --> Helper loaded: text_helper
INFO - 2016-02-22 09:53:30 --> Helper loaded: cookie_helper
INFO - 2016-02-22 12:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 12:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 12:53:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 12:53:30 --> Final output sent to browser
DEBUG - 2016-02-22 12:53:30 --> Total execution time: 1.2191
INFO - 2016-02-22 09:54:57 --> Config Class Initialized
INFO - 2016-02-22 09:54:57 --> Hooks Class Initialized
DEBUG - 2016-02-22 09:54:57 --> UTF-8 Support Enabled
INFO - 2016-02-22 09:54:57 --> Utf8 Class Initialized
INFO - 2016-02-22 09:54:57 --> URI Class Initialized
INFO - 2016-02-22 09:54:57 --> Router Class Initialized
INFO - 2016-02-22 09:54:57 --> Output Class Initialized
INFO - 2016-02-22 09:54:57 --> Security Class Initialized
DEBUG - 2016-02-22 09:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 09:54:57 --> Input Class Initialized
INFO - 2016-02-22 09:54:57 --> Language Class Initialized
INFO - 2016-02-22 09:54:57 --> Loader Class Initialized
INFO - 2016-02-22 09:54:57 --> Helper loaded: url_helper
INFO - 2016-02-22 09:54:57 --> Helper loaded: file_helper
INFO - 2016-02-22 09:54:57 --> Helper loaded: date_helper
INFO - 2016-02-22 09:54:57 --> Helper loaded: form_helper
INFO - 2016-02-22 09:54:57 --> Database Driver Class Initialized
INFO - 2016-02-22 09:54:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 09:54:58 --> Controller Class Initialized
INFO - 2016-02-22 09:54:58 --> Model Class Initialized
INFO - 2016-02-22 09:54:58 --> Model Class Initialized
INFO - 2016-02-22 09:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 09:54:58 --> Pagination Class Initialized
INFO - 2016-02-22 09:54:58 --> Helper loaded: text_helper
INFO - 2016-02-22 09:54:58 --> Helper loaded: cookie_helper
INFO - 2016-02-22 12:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 12:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 12:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 12:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 12:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 12:54:58 --> Final output sent to browser
DEBUG - 2016-02-22 12:54:58 --> Total execution time: 1.2068
INFO - 2016-02-22 10:06:09 --> Config Class Initialized
INFO - 2016-02-22 10:06:09 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:06:09 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:06:09 --> Utf8 Class Initialized
INFO - 2016-02-22 10:06:09 --> URI Class Initialized
INFO - 2016-02-22 10:06:09 --> Router Class Initialized
INFO - 2016-02-22 10:06:09 --> Output Class Initialized
INFO - 2016-02-22 10:06:09 --> Security Class Initialized
DEBUG - 2016-02-22 10:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:06:09 --> Input Class Initialized
INFO - 2016-02-22 10:06:09 --> Language Class Initialized
INFO - 2016-02-22 10:06:09 --> Loader Class Initialized
INFO - 2016-02-22 10:06:09 --> Helper loaded: url_helper
INFO - 2016-02-22 10:06:09 --> Helper loaded: file_helper
INFO - 2016-02-22 10:06:09 --> Helper loaded: date_helper
INFO - 2016-02-22 10:06:09 --> Helper loaded: form_helper
INFO - 2016-02-22 10:06:09 --> Database Driver Class Initialized
INFO - 2016-02-22 10:06:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:06:10 --> Controller Class Initialized
INFO - 2016-02-22 10:06:10 --> Model Class Initialized
INFO - 2016-02-22 10:06:10 --> Model Class Initialized
INFO - 2016-02-22 10:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:06:10 --> Pagination Class Initialized
INFO - 2016-02-22 10:06:10 --> Helper loaded: text_helper
INFO - 2016-02-22 10:06:10 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:06:11 --> Final output sent to browser
DEBUG - 2016-02-22 13:06:11 --> Total execution time: 1.2431
INFO - 2016-02-22 10:06:46 --> Config Class Initialized
INFO - 2016-02-22 10:06:46 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:06:46 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:06:46 --> Utf8 Class Initialized
INFO - 2016-02-22 10:06:46 --> URI Class Initialized
INFO - 2016-02-22 10:06:46 --> Router Class Initialized
INFO - 2016-02-22 10:06:46 --> Output Class Initialized
INFO - 2016-02-22 10:06:46 --> Security Class Initialized
DEBUG - 2016-02-22 10:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:06:46 --> Input Class Initialized
INFO - 2016-02-22 10:06:46 --> Language Class Initialized
INFO - 2016-02-22 10:06:46 --> Loader Class Initialized
INFO - 2016-02-22 10:06:46 --> Helper loaded: url_helper
INFO - 2016-02-22 10:06:46 --> Helper loaded: file_helper
INFO - 2016-02-22 10:06:46 --> Helper loaded: date_helper
INFO - 2016-02-22 10:06:46 --> Helper loaded: form_helper
INFO - 2016-02-22 10:06:46 --> Database Driver Class Initialized
INFO - 2016-02-22 10:06:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:06:47 --> Controller Class Initialized
INFO - 2016-02-22 10:06:47 --> Model Class Initialized
INFO - 2016-02-22 10:06:47 --> Model Class Initialized
INFO - 2016-02-22 10:06:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:06:47 --> Pagination Class Initialized
INFO - 2016-02-22 10:06:47 --> Helper loaded: text_helper
INFO - 2016-02-22 10:06:47 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:06:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:06:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:06:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:06:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:06:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:06:48 --> Final output sent to browser
DEBUG - 2016-02-22 13:06:48 --> Total execution time: 1.2561
INFO - 2016-02-22 10:09:13 --> Config Class Initialized
INFO - 2016-02-22 10:09:13 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:09:13 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:09:13 --> Utf8 Class Initialized
INFO - 2016-02-22 10:09:13 --> URI Class Initialized
INFO - 2016-02-22 10:09:13 --> Router Class Initialized
INFO - 2016-02-22 10:09:13 --> Output Class Initialized
INFO - 2016-02-22 10:09:13 --> Security Class Initialized
DEBUG - 2016-02-22 10:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:09:13 --> Input Class Initialized
INFO - 2016-02-22 10:09:13 --> Language Class Initialized
INFO - 2016-02-22 10:09:13 --> Loader Class Initialized
INFO - 2016-02-22 10:09:13 --> Helper loaded: url_helper
INFO - 2016-02-22 10:09:13 --> Helper loaded: file_helper
INFO - 2016-02-22 10:09:13 --> Helper loaded: date_helper
INFO - 2016-02-22 10:09:13 --> Helper loaded: form_helper
INFO - 2016-02-22 10:09:13 --> Database Driver Class Initialized
INFO - 2016-02-22 10:09:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:09:14 --> Controller Class Initialized
INFO - 2016-02-22 10:09:14 --> Model Class Initialized
INFO - 2016-02-22 10:09:14 --> Model Class Initialized
INFO - 2016-02-22 10:09:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:09:14 --> Pagination Class Initialized
INFO - 2016-02-22 10:09:14 --> Helper loaded: text_helper
INFO - 2016-02-22 10:09:14 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:09:14 --> Final output sent to browser
DEBUG - 2016-02-22 13:09:14 --> Total execution time: 1.2035
INFO - 2016-02-22 10:10:25 --> Config Class Initialized
INFO - 2016-02-22 10:10:25 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:10:25 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:10:25 --> Utf8 Class Initialized
INFO - 2016-02-22 10:10:25 --> URI Class Initialized
INFO - 2016-02-22 10:10:25 --> Router Class Initialized
INFO - 2016-02-22 10:10:25 --> Output Class Initialized
INFO - 2016-02-22 10:10:25 --> Security Class Initialized
DEBUG - 2016-02-22 10:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:10:25 --> Input Class Initialized
INFO - 2016-02-22 10:10:25 --> Language Class Initialized
INFO - 2016-02-22 10:10:25 --> Loader Class Initialized
INFO - 2016-02-22 10:10:25 --> Helper loaded: url_helper
INFO - 2016-02-22 10:10:25 --> Helper loaded: file_helper
INFO - 2016-02-22 10:10:25 --> Helper loaded: date_helper
INFO - 2016-02-22 10:10:25 --> Helper loaded: form_helper
INFO - 2016-02-22 10:10:25 --> Database Driver Class Initialized
INFO - 2016-02-22 10:10:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:10:26 --> Controller Class Initialized
INFO - 2016-02-22 10:10:26 --> Model Class Initialized
INFO - 2016-02-22 10:10:26 --> Model Class Initialized
INFO - 2016-02-22 10:10:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:10:26 --> Pagination Class Initialized
INFO - 2016-02-22 10:10:26 --> Helper loaded: text_helper
INFO - 2016-02-22 10:10:26 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:10:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:10:26 --> Final output sent to browser
DEBUG - 2016-02-22 13:10:26 --> Total execution time: 1.1670
INFO - 2016-02-22 10:10:30 --> Config Class Initialized
INFO - 2016-02-22 10:10:30 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:10:30 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:10:30 --> Utf8 Class Initialized
INFO - 2016-02-22 10:10:30 --> URI Class Initialized
INFO - 2016-02-22 10:10:30 --> Router Class Initialized
INFO - 2016-02-22 10:10:30 --> Output Class Initialized
INFO - 2016-02-22 10:10:30 --> Security Class Initialized
DEBUG - 2016-02-22 10:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:10:30 --> Input Class Initialized
INFO - 2016-02-22 10:10:30 --> Language Class Initialized
INFO - 2016-02-22 10:10:30 --> Loader Class Initialized
INFO - 2016-02-22 10:10:30 --> Helper loaded: url_helper
INFO - 2016-02-22 10:10:30 --> Helper loaded: file_helper
INFO - 2016-02-22 10:10:30 --> Helper loaded: date_helper
INFO - 2016-02-22 10:10:30 --> Helper loaded: form_helper
INFO - 2016-02-22 10:10:30 --> Database Driver Class Initialized
INFO - 2016-02-22 10:10:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:10:31 --> Controller Class Initialized
INFO - 2016-02-22 10:10:31 --> Model Class Initialized
INFO - 2016-02-22 10:10:31 --> Model Class Initialized
INFO - 2016-02-22 10:10:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:10:31 --> Pagination Class Initialized
INFO - 2016-02-22 10:10:31 --> Helper loaded: text_helper
INFO - 2016-02-22 10:10:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:10:31 --> Final output sent to browser
DEBUG - 2016-02-22 13:10:31 --> Total execution time: 1.2174
INFO - 2016-02-22 10:10:38 --> Config Class Initialized
INFO - 2016-02-22 10:10:38 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:10:38 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:10:38 --> Utf8 Class Initialized
INFO - 2016-02-22 10:10:38 --> URI Class Initialized
INFO - 2016-02-22 10:10:38 --> Router Class Initialized
INFO - 2016-02-22 10:10:38 --> Output Class Initialized
INFO - 2016-02-22 10:10:38 --> Security Class Initialized
DEBUG - 2016-02-22 10:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:10:38 --> Input Class Initialized
INFO - 2016-02-22 10:10:38 --> Language Class Initialized
INFO - 2016-02-22 10:10:38 --> Loader Class Initialized
INFO - 2016-02-22 10:10:38 --> Helper loaded: url_helper
INFO - 2016-02-22 10:10:38 --> Helper loaded: file_helper
INFO - 2016-02-22 10:10:38 --> Helper loaded: date_helper
INFO - 2016-02-22 10:10:38 --> Helper loaded: form_helper
INFO - 2016-02-22 10:10:38 --> Database Driver Class Initialized
INFO - 2016-02-22 10:10:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:10:39 --> Controller Class Initialized
INFO - 2016-02-22 10:10:39 --> Model Class Initialized
INFO - 2016-02-22 10:10:39 --> Model Class Initialized
INFO - 2016-02-22 10:10:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:10:39 --> Pagination Class Initialized
INFO - 2016-02-22 10:10:39 --> Helper loaded: text_helper
INFO - 2016-02-22 10:10:39 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:10:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:10:39 --> Final output sent to browser
DEBUG - 2016-02-22 13:10:39 --> Total execution time: 1.2124
INFO - 2016-02-22 10:11:47 --> Config Class Initialized
INFO - 2016-02-22 10:11:47 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:11:47 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:11:47 --> Utf8 Class Initialized
INFO - 2016-02-22 10:11:47 --> URI Class Initialized
INFO - 2016-02-22 10:11:47 --> Router Class Initialized
INFO - 2016-02-22 10:11:47 --> Output Class Initialized
INFO - 2016-02-22 10:11:47 --> Security Class Initialized
DEBUG - 2016-02-22 10:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:11:47 --> Input Class Initialized
INFO - 2016-02-22 10:11:47 --> Language Class Initialized
INFO - 2016-02-22 10:11:47 --> Loader Class Initialized
INFO - 2016-02-22 10:11:47 --> Helper loaded: url_helper
INFO - 2016-02-22 10:11:47 --> Helper loaded: file_helper
INFO - 2016-02-22 10:11:47 --> Helper loaded: date_helper
INFO - 2016-02-22 10:11:47 --> Helper loaded: form_helper
INFO - 2016-02-22 10:11:47 --> Database Driver Class Initialized
INFO - 2016-02-22 10:11:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:11:48 --> Controller Class Initialized
INFO - 2016-02-22 10:11:48 --> Model Class Initialized
INFO - 2016-02-22 10:11:48 --> Model Class Initialized
INFO - 2016-02-22 10:11:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:11:48 --> Pagination Class Initialized
INFO - 2016-02-22 10:11:48 --> Helper loaded: text_helper
INFO - 2016-02-22 10:11:48 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:11:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:11:49 --> Final output sent to browser
DEBUG - 2016-02-22 13:11:49 --> Total execution time: 1.2510
INFO - 2016-02-22 10:11:51 --> Config Class Initialized
INFO - 2016-02-22 10:11:51 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:11:51 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:11:51 --> Utf8 Class Initialized
INFO - 2016-02-22 10:11:51 --> URI Class Initialized
INFO - 2016-02-22 10:11:51 --> Router Class Initialized
INFO - 2016-02-22 10:11:51 --> Output Class Initialized
INFO - 2016-02-22 10:11:51 --> Security Class Initialized
DEBUG - 2016-02-22 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:11:51 --> Input Class Initialized
INFO - 2016-02-22 10:11:51 --> Language Class Initialized
INFO - 2016-02-22 10:11:51 --> Loader Class Initialized
INFO - 2016-02-22 10:11:51 --> Helper loaded: url_helper
INFO - 2016-02-22 10:11:51 --> Helper loaded: file_helper
INFO - 2016-02-22 10:11:51 --> Helper loaded: date_helper
INFO - 2016-02-22 10:11:51 --> Helper loaded: form_helper
INFO - 2016-02-22 10:11:51 --> Database Driver Class Initialized
INFO - 2016-02-22 10:11:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:11:52 --> Controller Class Initialized
INFO - 2016-02-22 10:11:52 --> Model Class Initialized
INFO - 2016-02-22 10:11:52 --> Model Class Initialized
INFO - 2016-02-22 10:11:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:11:52 --> Pagination Class Initialized
INFO - 2016-02-22 10:11:52 --> Helper loaded: text_helper
INFO - 2016-02-22 10:11:52 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:11:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:11:52 --> Final output sent to browser
DEBUG - 2016-02-22 13:11:52 --> Total execution time: 1.1986
INFO - 2016-02-22 10:12:02 --> Config Class Initialized
INFO - 2016-02-22 10:12:02 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:12:02 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:12:02 --> Utf8 Class Initialized
INFO - 2016-02-22 10:12:02 --> URI Class Initialized
INFO - 2016-02-22 10:12:02 --> Router Class Initialized
INFO - 2016-02-22 10:12:02 --> Output Class Initialized
INFO - 2016-02-22 10:12:02 --> Security Class Initialized
DEBUG - 2016-02-22 10:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:12:02 --> Input Class Initialized
INFO - 2016-02-22 10:12:02 --> Language Class Initialized
INFO - 2016-02-22 10:12:02 --> Loader Class Initialized
INFO - 2016-02-22 10:12:02 --> Helper loaded: url_helper
INFO - 2016-02-22 10:12:02 --> Helper loaded: file_helper
INFO - 2016-02-22 10:12:02 --> Helper loaded: date_helper
INFO - 2016-02-22 10:12:02 --> Helper loaded: form_helper
INFO - 2016-02-22 10:12:02 --> Database Driver Class Initialized
INFO - 2016-02-22 10:12:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:12:03 --> Controller Class Initialized
INFO - 2016-02-22 10:12:03 --> Model Class Initialized
INFO - 2016-02-22 10:12:03 --> Model Class Initialized
INFO - 2016-02-22 10:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:12:03 --> Pagination Class Initialized
INFO - 2016-02-22 10:12:03 --> Helper loaded: text_helper
INFO - 2016-02-22 10:12:03 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:12:03 --> Final output sent to browser
DEBUG - 2016-02-22 13:12:03 --> Total execution time: 1.2256
INFO - 2016-02-22 10:12:13 --> Config Class Initialized
INFO - 2016-02-22 10:12:13 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:12:13 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:12:13 --> Utf8 Class Initialized
INFO - 2016-02-22 10:12:13 --> URI Class Initialized
INFO - 2016-02-22 10:12:13 --> Router Class Initialized
INFO - 2016-02-22 10:12:13 --> Output Class Initialized
INFO - 2016-02-22 10:12:13 --> Security Class Initialized
DEBUG - 2016-02-22 10:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:12:13 --> Input Class Initialized
INFO - 2016-02-22 10:12:13 --> Language Class Initialized
INFO - 2016-02-22 10:12:13 --> Loader Class Initialized
INFO - 2016-02-22 10:12:13 --> Helper loaded: url_helper
INFO - 2016-02-22 10:12:13 --> Helper loaded: file_helper
INFO - 2016-02-22 10:12:13 --> Helper loaded: date_helper
INFO - 2016-02-22 10:12:13 --> Helper loaded: form_helper
INFO - 2016-02-22 10:12:13 --> Database Driver Class Initialized
INFO - 2016-02-22 10:12:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:12:14 --> Controller Class Initialized
INFO - 2016-02-22 10:12:14 --> Model Class Initialized
INFO - 2016-02-22 10:12:14 --> Model Class Initialized
INFO - 2016-02-22 10:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:12:14 --> Pagination Class Initialized
INFO - 2016-02-22 10:12:14 --> Helper loaded: text_helper
INFO - 2016-02-22 10:12:14 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:12:14 --> Final output sent to browser
DEBUG - 2016-02-22 13:12:14 --> Total execution time: 1.1214
INFO - 2016-02-22 10:19:39 --> Config Class Initialized
INFO - 2016-02-22 10:19:39 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:19:39 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:19:39 --> Utf8 Class Initialized
INFO - 2016-02-22 10:19:39 --> URI Class Initialized
INFO - 2016-02-22 10:19:39 --> Router Class Initialized
INFO - 2016-02-22 10:19:39 --> Output Class Initialized
INFO - 2016-02-22 10:19:39 --> Security Class Initialized
DEBUG - 2016-02-22 10:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:19:39 --> Input Class Initialized
INFO - 2016-02-22 10:19:39 --> Language Class Initialized
INFO - 2016-02-22 10:19:39 --> Loader Class Initialized
INFO - 2016-02-22 10:19:39 --> Helper loaded: url_helper
INFO - 2016-02-22 10:19:39 --> Helper loaded: file_helper
INFO - 2016-02-22 10:19:39 --> Helper loaded: date_helper
INFO - 2016-02-22 10:19:39 --> Helper loaded: form_helper
INFO - 2016-02-22 10:19:39 --> Database Driver Class Initialized
INFO - 2016-02-22 10:19:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:19:40 --> Controller Class Initialized
INFO - 2016-02-22 10:19:40 --> Model Class Initialized
INFO - 2016-02-22 10:19:40 --> Model Class Initialized
INFO - 2016-02-22 10:19:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:19:40 --> Pagination Class Initialized
INFO - 2016-02-22 10:19:40 --> Helper loaded: text_helper
INFO - 2016-02-22 10:19:40 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:19:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:19:40 --> Final output sent to browser
DEBUG - 2016-02-22 13:19:40 --> Total execution time: 1.1458
INFO - 2016-02-22 10:20:35 --> Config Class Initialized
INFO - 2016-02-22 10:20:35 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:20:35 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:20:35 --> Utf8 Class Initialized
INFO - 2016-02-22 10:20:35 --> URI Class Initialized
INFO - 2016-02-22 10:20:35 --> Router Class Initialized
INFO - 2016-02-22 10:20:35 --> Output Class Initialized
INFO - 2016-02-22 10:20:35 --> Security Class Initialized
DEBUG - 2016-02-22 10:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:20:35 --> Input Class Initialized
INFO - 2016-02-22 10:20:35 --> Language Class Initialized
INFO - 2016-02-22 10:20:35 --> Loader Class Initialized
INFO - 2016-02-22 10:20:35 --> Helper loaded: url_helper
INFO - 2016-02-22 10:20:35 --> Helper loaded: file_helper
INFO - 2016-02-22 10:20:35 --> Helper loaded: date_helper
INFO - 2016-02-22 10:20:35 --> Helper loaded: form_helper
INFO - 2016-02-22 10:20:35 --> Database Driver Class Initialized
INFO - 2016-02-22 10:20:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:20:36 --> Controller Class Initialized
INFO - 2016-02-22 10:20:36 --> Model Class Initialized
INFO - 2016-02-22 10:20:36 --> Model Class Initialized
INFO - 2016-02-22 10:20:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:20:36 --> Pagination Class Initialized
INFO - 2016-02-22 10:20:36 --> Helper loaded: text_helper
INFO - 2016-02-22 10:20:36 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:20:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:20:36 --> Final output sent to browser
DEBUG - 2016-02-22 13:20:36 --> Total execution time: 1.1896
INFO - 2016-02-22 10:20:49 --> Config Class Initialized
INFO - 2016-02-22 10:20:49 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:20:49 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:20:49 --> Utf8 Class Initialized
INFO - 2016-02-22 10:20:49 --> URI Class Initialized
INFO - 2016-02-22 10:20:49 --> Router Class Initialized
INFO - 2016-02-22 10:20:49 --> Output Class Initialized
INFO - 2016-02-22 10:20:49 --> Security Class Initialized
DEBUG - 2016-02-22 10:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:20:49 --> Input Class Initialized
INFO - 2016-02-22 10:20:49 --> Language Class Initialized
INFO - 2016-02-22 10:20:49 --> Loader Class Initialized
INFO - 2016-02-22 10:20:49 --> Helper loaded: url_helper
INFO - 2016-02-22 10:20:49 --> Helper loaded: file_helper
INFO - 2016-02-22 10:20:49 --> Helper loaded: date_helper
INFO - 2016-02-22 10:20:49 --> Helper loaded: form_helper
INFO - 2016-02-22 10:20:49 --> Database Driver Class Initialized
INFO - 2016-02-22 10:20:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:20:50 --> Controller Class Initialized
INFO - 2016-02-22 10:20:50 --> Model Class Initialized
INFO - 2016-02-22 10:20:50 --> Model Class Initialized
INFO - 2016-02-22 10:20:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:20:50 --> Pagination Class Initialized
INFO - 2016-02-22 10:20:50 --> Helper loaded: text_helper
INFO - 2016-02-22 10:20:50 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:20:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:20:50 --> Final output sent to browser
DEBUG - 2016-02-22 13:20:50 --> Total execution time: 1.2001
INFO - 2016-02-22 10:27:26 --> Config Class Initialized
INFO - 2016-02-22 10:27:26 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:27:26 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:27:26 --> Utf8 Class Initialized
INFO - 2016-02-22 10:27:26 --> URI Class Initialized
INFO - 2016-02-22 10:27:26 --> Router Class Initialized
INFO - 2016-02-22 10:27:26 --> Output Class Initialized
INFO - 2016-02-22 10:27:26 --> Security Class Initialized
DEBUG - 2016-02-22 10:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:27:26 --> Input Class Initialized
INFO - 2016-02-22 10:27:26 --> Language Class Initialized
INFO - 2016-02-22 10:27:26 --> Loader Class Initialized
INFO - 2016-02-22 10:27:26 --> Helper loaded: url_helper
INFO - 2016-02-22 10:27:26 --> Helper loaded: file_helper
INFO - 2016-02-22 10:27:26 --> Helper loaded: date_helper
INFO - 2016-02-22 10:27:26 --> Helper loaded: form_helper
INFO - 2016-02-22 10:27:26 --> Database Driver Class Initialized
INFO - 2016-02-22 10:27:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:27:27 --> Controller Class Initialized
INFO - 2016-02-22 10:27:27 --> Model Class Initialized
INFO - 2016-02-22 10:27:27 --> Model Class Initialized
INFO - 2016-02-22 10:27:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:27:27 --> Pagination Class Initialized
INFO - 2016-02-22 10:27:27 --> Helper loaded: text_helper
INFO - 2016-02-22 10:27:27 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:27:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:27:27 --> Final output sent to browser
DEBUG - 2016-02-22 13:27:27 --> Total execution time: 1.2212
INFO - 2016-02-22 10:28:35 --> Config Class Initialized
INFO - 2016-02-22 10:28:35 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:28:35 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:28:35 --> Utf8 Class Initialized
INFO - 2016-02-22 10:28:35 --> URI Class Initialized
INFO - 2016-02-22 10:28:35 --> Router Class Initialized
INFO - 2016-02-22 10:28:35 --> Output Class Initialized
INFO - 2016-02-22 10:28:35 --> Security Class Initialized
DEBUG - 2016-02-22 10:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:28:35 --> Input Class Initialized
INFO - 2016-02-22 10:28:35 --> Language Class Initialized
INFO - 2016-02-22 10:28:35 --> Loader Class Initialized
INFO - 2016-02-22 10:28:35 --> Helper loaded: url_helper
INFO - 2016-02-22 10:28:35 --> Helper loaded: file_helper
INFO - 2016-02-22 10:28:35 --> Helper loaded: date_helper
INFO - 2016-02-22 10:28:35 --> Helper loaded: form_helper
INFO - 2016-02-22 10:28:35 --> Database Driver Class Initialized
INFO - 2016-02-22 10:28:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:28:36 --> Controller Class Initialized
INFO - 2016-02-22 10:28:36 --> Model Class Initialized
INFO - 2016-02-22 10:28:36 --> Model Class Initialized
INFO - 2016-02-22 10:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:28:36 --> Pagination Class Initialized
INFO - 2016-02-22 10:28:36 --> Helper loaded: text_helper
INFO - 2016-02-22 10:28:36 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:28:36 --> Final output sent to browser
DEBUG - 2016-02-22 13:28:36 --> Total execution time: 1.2074
INFO - 2016-02-22 10:30:21 --> Config Class Initialized
INFO - 2016-02-22 10:30:21 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:30:21 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:30:21 --> Utf8 Class Initialized
INFO - 2016-02-22 10:30:21 --> URI Class Initialized
INFO - 2016-02-22 10:30:21 --> Router Class Initialized
INFO - 2016-02-22 10:30:21 --> Output Class Initialized
INFO - 2016-02-22 10:30:21 --> Security Class Initialized
DEBUG - 2016-02-22 10:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:30:21 --> Input Class Initialized
INFO - 2016-02-22 10:30:21 --> Language Class Initialized
INFO - 2016-02-22 10:30:21 --> Loader Class Initialized
INFO - 2016-02-22 10:30:21 --> Helper loaded: url_helper
INFO - 2016-02-22 10:30:21 --> Helper loaded: file_helper
INFO - 2016-02-22 10:30:21 --> Helper loaded: date_helper
INFO - 2016-02-22 10:30:21 --> Helper loaded: form_helper
INFO - 2016-02-22 10:30:21 --> Database Driver Class Initialized
INFO - 2016-02-22 10:30:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:30:22 --> Controller Class Initialized
INFO - 2016-02-22 10:30:22 --> Model Class Initialized
INFO - 2016-02-22 10:30:22 --> Model Class Initialized
INFO - 2016-02-22 10:30:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:30:22 --> Pagination Class Initialized
INFO - 2016-02-22 10:30:22 --> Helper loaded: text_helper
INFO - 2016-02-22 10:30:22 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:30:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:30:22 --> Final output sent to browser
DEBUG - 2016-02-22 13:30:22 --> Total execution time: 1.2553
INFO - 2016-02-22 10:40:15 --> Config Class Initialized
INFO - 2016-02-22 10:40:15 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:40:15 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:40:15 --> Utf8 Class Initialized
INFO - 2016-02-22 10:40:15 --> URI Class Initialized
INFO - 2016-02-22 10:40:15 --> Router Class Initialized
INFO - 2016-02-22 10:40:15 --> Output Class Initialized
INFO - 2016-02-22 10:40:15 --> Security Class Initialized
DEBUG - 2016-02-22 10:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:40:15 --> Input Class Initialized
INFO - 2016-02-22 10:40:15 --> Language Class Initialized
INFO - 2016-02-22 10:40:15 --> Loader Class Initialized
INFO - 2016-02-22 10:40:15 --> Helper loaded: url_helper
INFO - 2016-02-22 10:40:15 --> Helper loaded: file_helper
INFO - 2016-02-22 10:40:15 --> Helper loaded: date_helper
INFO - 2016-02-22 10:40:15 --> Helper loaded: form_helper
INFO - 2016-02-22 10:40:15 --> Database Driver Class Initialized
INFO - 2016-02-22 10:40:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:40:16 --> Controller Class Initialized
INFO - 2016-02-22 10:40:16 --> Model Class Initialized
INFO - 2016-02-22 10:40:16 --> Model Class Initialized
INFO - 2016-02-22 10:40:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:40:16 --> Pagination Class Initialized
INFO - 2016-02-22 10:40:16 --> Helper loaded: text_helper
INFO - 2016-02-22 10:40:16 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:40:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:40:16 --> Final output sent to browser
DEBUG - 2016-02-22 13:40:16 --> Total execution time: 1.1374
INFO - 2016-02-22 10:40:43 --> Config Class Initialized
INFO - 2016-02-22 10:40:43 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:40:43 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:40:43 --> Utf8 Class Initialized
INFO - 2016-02-22 10:40:43 --> URI Class Initialized
INFO - 2016-02-22 10:40:43 --> Router Class Initialized
INFO - 2016-02-22 10:40:43 --> Output Class Initialized
INFO - 2016-02-22 10:40:43 --> Security Class Initialized
DEBUG - 2016-02-22 10:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:40:43 --> Input Class Initialized
INFO - 2016-02-22 10:40:43 --> Language Class Initialized
INFO - 2016-02-22 10:40:43 --> Loader Class Initialized
INFO - 2016-02-22 10:40:43 --> Helper loaded: url_helper
INFO - 2016-02-22 10:40:43 --> Helper loaded: file_helper
INFO - 2016-02-22 10:40:43 --> Helper loaded: date_helper
INFO - 2016-02-22 10:40:43 --> Helper loaded: form_helper
INFO - 2016-02-22 10:40:43 --> Database Driver Class Initialized
INFO - 2016-02-22 10:40:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:40:44 --> Controller Class Initialized
INFO - 2016-02-22 10:40:44 --> Model Class Initialized
INFO - 2016-02-22 10:40:44 --> Model Class Initialized
INFO - 2016-02-22 10:40:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:40:44 --> Pagination Class Initialized
INFO - 2016-02-22 10:40:44 --> Helper loaded: text_helper
INFO - 2016-02-22 10:40:44 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:40:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:40:44 --> Final output sent to browser
DEBUG - 2016-02-22 13:40:44 --> Total execution time: 1.3258
INFO - 2016-02-22 10:41:30 --> Config Class Initialized
INFO - 2016-02-22 10:41:30 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:41:30 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:41:30 --> Utf8 Class Initialized
INFO - 2016-02-22 10:41:30 --> URI Class Initialized
INFO - 2016-02-22 10:41:30 --> Router Class Initialized
INFO - 2016-02-22 10:41:30 --> Output Class Initialized
INFO - 2016-02-22 10:41:30 --> Security Class Initialized
DEBUG - 2016-02-22 10:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:41:30 --> Input Class Initialized
INFO - 2016-02-22 10:41:30 --> Language Class Initialized
INFO - 2016-02-22 10:41:30 --> Loader Class Initialized
INFO - 2016-02-22 10:41:30 --> Helper loaded: url_helper
INFO - 2016-02-22 10:41:30 --> Helper loaded: file_helper
INFO - 2016-02-22 10:41:30 --> Helper loaded: date_helper
INFO - 2016-02-22 10:41:30 --> Helper loaded: form_helper
INFO - 2016-02-22 10:41:30 --> Database Driver Class Initialized
INFO - 2016-02-22 10:41:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:41:31 --> Controller Class Initialized
INFO - 2016-02-22 10:41:31 --> Model Class Initialized
INFO - 2016-02-22 10:41:31 --> Model Class Initialized
INFO - 2016-02-22 10:41:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:41:31 --> Pagination Class Initialized
INFO - 2016-02-22 10:41:31 --> Helper loaded: text_helper
INFO - 2016-02-22 10:41:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:41:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:41:31 --> Final output sent to browser
DEBUG - 2016-02-22 13:41:31 --> Total execution time: 1.1844
INFO - 2016-02-22 10:43:45 --> Config Class Initialized
INFO - 2016-02-22 10:43:45 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:43:45 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:43:45 --> Utf8 Class Initialized
INFO - 2016-02-22 10:43:45 --> URI Class Initialized
INFO - 2016-02-22 10:43:45 --> Router Class Initialized
INFO - 2016-02-22 10:43:45 --> Output Class Initialized
INFO - 2016-02-22 10:43:45 --> Security Class Initialized
DEBUG - 2016-02-22 10:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:43:45 --> Input Class Initialized
INFO - 2016-02-22 10:43:45 --> Language Class Initialized
INFO - 2016-02-22 10:43:45 --> Loader Class Initialized
INFO - 2016-02-22 10:43:45 --> Helper loaded: url_helper
INFO - 2016-02-22 10:43:45 --> Helper loaded: file_helper
INFO - 2016-02-22 10:43:45 --> Helper loaded: date_helper
INFO - 2016-02-22 10:43:45 --> Helper loaded: form_helper
INFO - 2016-02-22 10:43:45 --> Database Driver Class Initialized
INFO - 2016-02-22 10:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:43:46 --> Controller Class Initialized
INFO - 2016-02-22 10:43:46 --> Model Class Initialized
INFO - 2016-02-22 10:43:46 --> Model Class Initialized
INFO - 2016-02-22 10:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:43:46 --> Pagination Class Initialized
INFO - 2016-02-22 10:43:46 --> Helper loaded: text_helper
INFO - 2016-02-22 10:43:46 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:43:47 --> Final output sent to browser
DEBUG - 2016-02-22 13:43:47 --> Total execution time: 1.1608
INFO - 2016-02-22 10:45:06 --> Config Class Initialized
INFO - 2016-02-22 10:45:06 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:45:06 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:45:06 --> Utf8 Class Initialized
INFO - 2016-02-22 10:45:06 --> URI Class Initialized
INFO - 2016-02-22 10:45:06 --> Router Class Initialized
INFO - 2016-02-22 10:45:06 --> Output Class Initialized
INFO - 2016-02-22 10:45:06 --> Security Class Initialized
DEBUG - 2016-02-22 10:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:45:06 --> Input Class Initialized
INFO - 2016-02-22 10:45:06 --> Language Class Initialized
INFO - 2016-02-22 10:45:06 --> Loader Class Initialized
INFO - 2016-02-22 10:45:06 --> Helper loaded: url_helper
INFO - 2016-02-22 10:45:06 --> Helper loaded: file_helper
INFO - 2016-02-22 10:45:06 --> Helper loaded: date_helper
INFO - 2016-02-22 10:45:06 --> Helper loaded: form_helper
INFO - 2016-02-22 10:45:06 --> Database Driver Class Initialized
INFO - 2016-02-22 10:45:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:45:07 --> Controller Class Initialized
INFO - 2016-02-22 10:45:07 --> Model Class Initialized
INFO - 2016-02-22 10:45:07 --> Model Class Initialized
INFO - 2016-02-22 10:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:45:07 --> Pagination Class Initialized
INFO - 2016-02-22 10:45:07 --> Helper loaded: text_helper
INFO - 2016-02-22 10:45:07 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:45:07 --> Final output sent to browser
DEBUG - 2016-02-22 13:45:07 --> Total execution time: 1.1921
INFO - 2016-02-22 10:46:19 --> Config Class Initialized
INFO - 2016-02-22 10:46:19 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:46:19 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:46:19 --> Utf8 Class Initialized
INFO - 2016-02-22 10:46:19 --> URI Class Initialized
INFO - 2016-02-22 10:46:19 --> Router Class Initialized
INFO - 2016-02-22 10:46:19 --> Output Class Initialized
INFO - 2016-02-22 10:46:19 --> Security Class Initialized
DEBUG - 2016-02-22 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:46:19 --> Input Class Initialized
INFO - 2016-02-22 10:46:19 --> Language Class Initialized
INFO - 2016-02-22 10:46:19 --> Loader Class Initialized
INFO - 2016-02-22 10:46:19 --> Helper loaded: url_helper
INFO - 2016-02-22 10:46:19 --> Helper loaded: file_helper
INFO - 2016-02-22 10:46:19 --> Helper loaded: date_helper
INFO - 2016-02-22 10:46:19 --> Helper loaded: form_helper
INFO - 2016-02-22 10:46:19 --> Database Driver Class Initialized
INFO - 2016-02-22 10:46:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:46:20 --> Controller Class Initialized
INFO - 2016-02-22 10:46:20 --> Model Class Initialized
INFO - 2016-02-22 10:46:20 --> Model Class Initialized
INFO - 2016-02-22 10:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:46:20 --> Pagination Class Initialized
INFO - 2016-02-22 10:46:20 --> Helper loaded: text_helper
INFO - 2016-02-22 10:46:20 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:46:20 --> Final output sent to browser
DEBUG - 2016-02-22 13:46:20 --> Total execution time: 1.2684
INFO - 2016-02-22 10:48:53 --> Config Class Initialized
INFO - 2016-02-22 10:48:53 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:48:53 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:48:53 --> Utf8 Class Initialized
INFO - 2016-02-22 10:48:53 --> URI Class Initialized
INFO - 2016-02-22 10:48:53 --> Router Class Initialized
INFO - 2016-02-22 10:48:53 --> Output Class Initialized
INFO - 2016-02-22 10:48:53 --> Security Class Initialized
DEBUG - 2016-02-22 10:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:48:53 --> Input Class Initialized
INFO - 2016-02-22 10:48:53 --> Language Class Initialized
INFO - 2016-02-22 10:48:53 --> Loader Class Initialized
INFO - 2016-02-22 10:48:53 --> Helper loaded: url_helper
INFO - 2016-02-22 10:48:53 --> Helper loaded: file_helper
INFO - 2016-02-22 10:48:53 --> Helper loaded: date_helper
INFO - 2016-02-22 10:48:53 --> Helper loaded: form_helper
INFO - 2016-02-22 10:48:53 --> Database Driver Class Initialized
INFO - 2016-02-22 10:48:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:48:54 --> Controller Class Initialized
INFO - 2016-02-22 10:48:54 --> Model Class Initialized
INFO - 2016-02-22 10:48:54 --> Model Class Initialized
INFO - 2016-02-22 10:48:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:48:54 --> Pagination Class Initialized
INFO - 2016-02-22 10:48:54 --> Helper loaded: text_helper
INFO - 2016-02-22 10:48:54 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:48:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:48:54 --> Final output sent to browser
DEBUG - 2016-02-22 13:48:54 --> Total execution time: 1.2102
INFO - 2016-02-22 10:49:33 --> Config Class Initialized
INFO - 2016-02-22 10:49:33 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:49:33 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:49:33 --> Utf8 Class Initialized
INFO - 2016-02-22 10:49:33 --> URI Class Initialized
INFO - 2016-02-22 10:49:33 --> Router Class Initialized
INFO - 2016-02-22 10:49:33 --> Output Class Initialized
INFO - 2016-02-22 10:49:33 --> Security Class Initialized
DEBUG - 2016-02-22 10:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:49:33 --> Input Class Initialized
INFO - 2016-02-22 10:49:33 --> Language Class Initialized
INFO - 2016-02-22 10:49:33 --> Loader Class Initialized
INFO - 2016-02-22 10:49:33 --> Helper loaded: url_helper
INFO - 2016-02-22 10:49:33 --> Helper loaded: file_helper
INFO - 2016-02-22 10:49:33 --> Helper loaded: date_helper
INFO - 2016-02-22 10:49:33 --> Helper loaded: form_helper
INFO - 2016-02-22 10:49:33 --> Database Driver Class Initialized
INFO - 2016-02-22 10:49:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:49:34 --> Controller Class Initialized
INFO - 2016-02-22 10:49:34 --> Model Class Initialized
INFO - 2016-02-22 10:49:34 --> Model Class Initialized
INFO - 2016-02-22 10:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:49:34 --> Pagination Class Initialized
INFO - 2016-02-22 10:49:34 --> Helper loaded: text_helper
INFO - 2016-02-22 10:49:34 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:49:34 --> Final output sent to browser
DEBUG - 2016-02-22 13:49:34 --> Total execution time: 1.1478
INFO - 2016-02-22 10:54:47 --> Config Class Initialized
INFO - 2016-02-22 10:54:47 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:54:47 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:54:47 --> Utf8 Class Initialized
INFO - 2016-02-22 10:54:47 --> URI Class Initialized
INFO - 2016-02-22 10:54:47 --> Router Class Initialized
INFO - 2016-02-22 10:54:47 --> Output Class Initialized
INFO - 2016-02-22 10:54:47 --> Security Class Initialized
DEBUG - 2016-02-22 10:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:54:47 --> Input Class Initialized
INFO - 2016-02-22 10:54:47 --> Language Class Initialized
INFO - 2016-02-22 10:54:47 --> Loader Class Initialized
INFO - 2016-02-22 10:54:47 --> Helper loaded: url_helper
INFO - 2016-02-22 10:54:47 --> Helper loaded: file_helper
INFO - 2016-02-22 10:54:47 --> Helper loaded: date_helper
INFO - 2016-02-22 10:54:47 --> Helper loaded: form_helper
INFO - 2016-02-22 10:54:47 --> Database Driver Class Initialized
INFO - 2016-02-22 10:54:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:54:48 --> Controller Class Initialized
INFO - 2016-02-22 10:54:48 --> Model Class Initialized
INFO - 2016-02-22 10:54:48 --> Model Class Initialized
INFO - 2016-02-22 10:54:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:54:48 --> Pagination Class Initialized
INFO - 2016-02-22 10:54:48 --> Helper loaded: text_helper
INFO - 2016-02-22 10:54:48 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:54:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:54:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:54:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:54:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:54:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:54:48 --> Final output sent to browser
DEBUG - 2016-02-22 13:54:48 --> Total execution time: 1.1412
INFO - 2016-02-22 10:58:04 --> Config Class Initialized
INFO - 2016-02-22 10:58:04 --> Hooks Class Initialized
DEBUG - 2016-02-22 10:58:04 --> UTF-8 Support Enabled
INFO - 2016-02-22 10:58:04 --> Utf8 Class Initialized
INFO - 2016-02-22 10:58:04 --> URI Class Initialized
INFO - 2016-02-22 10:58:05 --> Router Class Initialized
INFO - 2016-02-22 10:58:05 --> Output Class Initialized
INFO - 2016-02-22 10:58:05 --> Security Class Initialized
DEBUG - 2016-02-22 10:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 10:58:05 --> Input Class Initialized
INFO - 2016-02-22 10:58:05 --> Language Class Initialized
INFO - 2016-02-22 10:58:05 --> Loader Class Initialized
INFO - 2016-02-22 10:58:05 --> Helper loaded: url_helper
INFO - 2016-02-22 10:58:05 --> Helper loaded: file_helper
INFO - 2016-02-22 10:58:05 --> Helper loaded: date_helper
INFO - 2016-02-22 10:58:05 --> Helper loaded: form_helper
INFO - 2016-02-22 10:58:05 --> Database Driver Class Initialized
INFO - 2016-02-22 10:58:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 10:58:06 --> Controller Class Initialized
INFO - 2016-02-22 10:58:06 --> Model Class Initialized
INFO - 2016-02-22 10:58:06 --> Model Class Initialized
INFO - 2016-02-22 10:58:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 10:58:06 --> Pagination Class Initialized
INFO - 2016-02-22 10:58:06 --> Helper loaded: text_helper
INFO - 2016-02-22 10:58:06 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 13:58:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 13:58:06 --> Final output sent to browser
DEBUG - 2016-02-22 13:58:06 --> Total execution time: 1.1695
INFO - 2016-02-22 11:03:33 --> Config Class Initialized
INFO - 2016-02-22 11:03:33 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:03:33 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:03:33 --> Utf8 Class Initialized
INFO - 2016-02-22 11:03:33 --> URI Class Initialized
INFO - 2016-02-22 11:03:33 --> Router Class Initialized
INFO - 2016-02-22 11:03:33 --> Output Class Initialized
INFO - 2016-02-22 11:03:33 --> Security Class Initialized
DEBUG - 2016-02-22 11:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:03:33 --> Input Class Initialized
INFO - 2016-02-22 11:03:33 --> Language Class Initialized
INFO - 2016-02-22 11:03:33 --> Loader Class Initialized
INFO - 2016-02-22 11:03:33 --> Helper loaded: url_helper
INFO - 2016-02-22 11:03:33 --> Helper loaded: file_helper
INFO - 2016-02-22 11:03:33 --> Helper loaded: date_helper
INFO - 2016-02-22 11:03:33 --> Helper loaded: form_helper
INFO - 2016-02-22 11:03:33 --> Database Driver Class Initialized
INFO - 2016-02-22 11:03:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:03:34 --> Controller Class Initialized
INFO - 2016-02-22 11:03:34 --> Model Class Initialized
INFO - 2016-02-22 11:03:34 --> Model Class Initialized
INFO - 2016-02-22 11:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:03:34 --> Pagination Class Initialized
INFO - 2016-02-22 11:03:34 --> Helper loaded: text_helper
INFO - 2016-02-22 11:03:34 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:03:34 --> Final output sent to browser
DEBUG - 2016-02-22 14:03:34 --> Total execution time: 1.1611
INFO - 2016-02-22 11:03:57 --> Config Class Initialized
INFO - 2016-02-22 11:03:57 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:03:57 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:03:57 --> Utf8 Class Initialized
INFO - 2016-02-22 11:03:57 --> URI Class Initialized
INFO - 2016-02-22 11:03:57 --> Router Class Initialized
INFO - 2016-02-22 11:03:57 --> Output Class Initialized
INFO - 2016-02-22 11:03:57 --> Security Class Initialized
DEBUG - 2016-02-22 11:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:03:57 --> Input Class Initialized
INFO - 2016-02-22 11:03:57 --> Language Class Initialized
INFO - 2016-02-22 11:03:57 --> Loader Class Initialized
INFO - 2016-02-22 11:03:57 --> Helper loaded: url_helper
INFO - 2016-02-22 11:03:57 --> Helper loaded: file_helper
INFO - 2016-02-22 11:03:57 --> Helper loaded: date_helper
INFO - 2016-02-22 11:03:57 --> Helper loaded: form_helper
INFO - 2016-02-22 11:03:57 --> Database Driver Class Initialized
INFO - 2016-02-22 11:03:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:03:58 --> Controller Class Initialized
INFO - 2016-02-22 11:03:58 --> Model Class Initialized
INFO - 2016-02-22 11:03:58 --> Model Class Initialized
INFO - 2016-02-22 11:03:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:03:58 --> Pagination Class Initialized
INFO - 2016-02-22 11:03:58 --> Helper loaded: text_helper
INFO - 2016-02-22 11:03:58 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:03:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:03:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:03:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:03:59 --> Final output sent to browser
DEBUG - 2016-02-22 14:03:59 --> Total execution time: 1.2104
INFO - 2016-02-22 11:08:41 --> Config Class Initialized
INFO - 2016-02-22 11:08:41 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:08:41 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:08:41 --> Utf8 Class Initialized
INFO - 2016-02-22 11:08:41 --> URI Class Initialized
INFO - 2016-02-22 11:08:41 --> Router Class Initialized
INFO - 2016-02-22 11:08:41 --> Output Class Initialized
INFO - 2016-02-22 11:08:41 --> Security Class Initialized
DEBUG - 2016-02-22 11:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:08:41 --> Input Class Initialized
INFO - 2016-02-22 11:08:41 --> Language Class Initialized
INFO - 2016-02-22 11:08:41 --> Loader Class Initialized
INFO - 2016-02-22 11:08:41 --> Helper loaded: url_helper
INFO - 2016-02-22 11:08:41 --> Helper loaded: file_helper
INFO - 2016-02-22 11:08:41 --> Helper loaded: date_helper
INFO - 2016-02-22 11:08:41 --> Helper loaded: form_helper
INFO - 2016-02-22 11:08:41 --> Database Driver Class Initialized
INFO - 2016-02-22 11:08:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:08:42 --> Controller Class Initialized
INFO - 2016-02-22 11:08:42 --> Model Class Initialized
INFO - 2016-02-22 11:08:42 --> Model Class Initialized
INFO - 2016-02-22 11:08:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:08:42 --> Pagination Class Initialized
INFO - 2016-02-22 11:08:42 --> Helper loaded: text_helper
INFO - 2016-02-22 11:08:42 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:08:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:08:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:08:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:08:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:08:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:08:42 --> Final output sent to browser
DEBUG - 2016-02-22 14:08:42 --> Total execution time: 1.2193
INFO - 2016-02-22 11:09:05 --> Config Class Initialized
INFO - 2016-02-22 11:09:05 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:09:05 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:09:05 --> Utf8 Class Initialized
INFO - 2016-02-22 11:09:05 --> URI Class Initialized
INFO - 2016-02-22 11:09:05 --> Router Class Initialized
INFO - 2016-02-22 11:09:05 --> Output Class Initialized
INFO - 2016-02-22 11:09:05 --> Security Class Initialized
DEBUG - 2016-02-22 11:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:09:05 --> Input Class Initialized
INFO - 2016-02-22 11:09:05 --> Language Class Initialized
INFO - 2016-02-22 11:09:05 --> Loader Class Initialized
INFO - 2016-02-22 11:09:05 --> Helper loaded: url_helper
INFO - 2016-02-22 11:09:05 --> Helper loaded: file_helper
INFO - 2016-02-22 11:09:05 --> Helper loaded: date_helper
INFO - 2016-02-22 11:09:05 --> Helper loaded: form_helper
INFO - 2016-02-22 11:09:05 --> Database Driver Class Initialized
INFO - 2016-02-22 11:09:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:09:06 --> Controller Class Initialized
INFO - 2016-02-22 11:09:06 --> Model Class Initialized
INFO - 2016-02-22 11:09:06 --> Model Class Initialized
INFO - 2016-02-22 11:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:09:06 --> Pagination Class Initialized
INFO - 2016-02-22 11:09:06 --> Helper loaded: text_helper
INFO - 2016-02-22 11:09:06 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:09:06 --> Final output sent to browser
DEBUG - 2016-02-22 14:09:06 --> Total execution time: 1.1418
INFO - 2016-02-22 11:09:22 --> Config Class Initialized
INFO - 2016-02-22 11:09:22 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:09:22 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:09:22 --> Utf8 Class Initialized
INFO - 2016-02-22 11:09:22 --> URI Class Initialized
INFO - 2016-02-22 11:09:22 --> Router Class Initialized
INFO - 2016-02-22 11:09:22 --> Output Class Initialized
INFO - 2016-02-22 11:09:22 --> Security Class Initialized
DEBUG - 2016-02-22 11:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:09:22 --> Input Class Initialized
INFO - 2016-02-22 11:09:22 --> Language Class Initialized
INFO - 2016-02-22 11:09:22 --> Loader Class Initialized
INFO - 2016-02-22 11:09:22 --> Helper loaded: url_helper
INFO - 2016-02-22 11:09:22 --> Helper loaded: file_helper
INFO - 2016-02-22 11:09:22 --> Helper loaded: date_helper
INFO - 2016-02-22 11:09:22 --> Helper loaded: form_helper
INFO - 2016-02-22 11:09:22 --> Database Driver Class Initialized
INFO - 2016-02-22 11:09:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:09:23 --> Controller Class Initialized
INFO - 2016-02-22 11:09:23 --> Model Class Initialized
INFO - 2016-02-22 11:09:23 --> Model Class Initialized
INFO - 2016-02-22 11:09:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:09:23 --> Pagination Class Initialized
INFO - 2016-02-22 11:09:23 --> Helper loaded: text_helper
INFO - 2016-02-22 11:09:23 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:09:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:09:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:09:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:09:24 --> Final output sent to browser
DEBUG - 2016-02-22 14:09:24 --> Total execution time: 1.2127
INFO - 2016-02-22 11:09:47 --> Config Class Initialized
INFO - 2016-02-22 11:09:47 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:09:47 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:09:47 --> Utf8 Class Initialized
INFO - 2016-02-22 11:09:48 --> URI Class Initialized
INFO - 2016-02-22 11:09:48 --> Router Class Initialized
INFO - 2016-02-22 11:09:48 --> Output Class Initialized
INFO - 2016-02-22 11:09:48 --> Security Class Initialized
DEBUG - 2016-02-22 11:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:09:48 --> Input Class Initialized
INFO - 2016-02-22 11:09:48 --> Language Class Initialized
INFO - 2016-02-22 11:09:48 --> Loader Class Initialized
INFO - 2016-02-22 11:09:48 --> Helper loaded: url_helper
INFO - 2016-02-22 11:09:48 --> Helper loaded: file_helper
INFO - 2016-02-22 11:09:48 --> Helper loaded: date_helper
INFO - 2016-02-22 11:09:48 --> Helper loaded: form_helper
INFO - 2016-02-22 11:09:48 --> Database Driver Class Initialized
INFO - 2016-02-22 11:09:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:09:49 --> Controller Class Initialized
INFO - 2016-02-22 11:09:49 --> Model Class Initialized
INFO - 2016-02-22 11:09:49 --> Model Class Initialized
INFO - 2016-02-22 11:09:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:09:49 --> Pagination Class Initialized
INFO - 2016-02-22 11:09:49 --> Helper loaded: text_helper
INFO - 2016-02-22 11:09:49 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:09:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:09:49 --> Final output sent to browser
DEBUG - 2016-02-22 14:09:49 --> Total execution time: 1.1770
INFO - 2016-02-22 11:14:07 --> Config Class Initialized
INFO - 2016-02-22 11:14:07 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:14:07 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:14:07 --> Utf8 Class Initialized
INFO - 2016-02-22 11:14:07 --> URI Class Initialized
INFO - 2016-02-22 11:14:07 --> Router Class Initialized
INFO - 2016-02-22 11:14:08 --> Output Class Initialized
INFO - 2016-02-22 11:14:08 --> Security Class Initialized
DEBUG - 2016-02-22 11:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:14:08 --> Input Class Initialized
INFO - 2016-02-22 11:14:08 --> Language Class Initialized
INFO - 2016-02-22 11:14:08 --> Loader Class Initialized
INFO - 2016-02-22 11:14:08 --> Helper loaded: url_helper
INFO - 2016-02-22 11:14:08 --> Helper loaded: file_helper
INFO - 2016-02-22 11:14:08 --> Helper loaded: date_helper
INFO - 2016-02-22 11:14:08 --> Helper loaded: form_helper
INFO - 2016-02-22 11:14:08 --> Database Driver Class Initialized
INFO - 2016-02-22 11:14:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:14:09 --> Controller Class Initialized
INFO - 2016-02-22 11:14:09 --> Model Class Initialized
INFO - 2016-02-22 11:14:09 --> Model Class Initialized
INFO - 2016-02-22 11:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:14:09 --> Pagination Class Initialized
INFO - 2016-02-22 11:14:09 --> Helper loaded: text_helper
INFO - 2016-02-22 11:14:09 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:14:09 --> Final output sent to browser
DEBUG - 2016-02-22 14:14:09 --> Total execution time: 1.1966
INFO - 2016-02-22 11:15:00 --> Config Class Initialized
INFO - 2016-02-22 11:15:00 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:15:00 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:15:00 --> Utf8 Class Initialized
INFO - 2016-02-22 11:15:00 --> URI Class Initialized
INFO - 2016-02-22 11:15:00 --> Router Class Initialized
INFO - 2016-02-22 11:15:00 --> Output Class Initialized
INFO - 2016-02-22 11:15:00 --> Security Class Initialized
DEBUG - 2016-02-22 11:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:15:00 --> Input Class Initialized
INFO - 2016-02-22 11:15:00 --> Language Class Initialized
INFO - 2016-02-22 11:15:00 --> Loader Class Initialized
INFO - 2016-02-22 11:15:00 --> Helper loaded: url_helper
INFO - 2016-02-22 11:15:00 --> Helper loaded: file_helper
INFO - 2016-02-22 11:15:00 --> Helper loaded: date_helper
INFO - 2016-02-22 11:15:00 --> Helper loaded: form_helper
INFO - 2016-02-22 11:15:00 --> Database Driver Class Initialized
INFO - 2016-02-22 11:15:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:15:01 --> Controller Class Initialized
INFO - 2016-02-22 11:15:01 --> Model Class Initialized
INFO - 2016-02-22 11:15:01 --> Model Class Initialized
INFO - 2016-02-22 11:15:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:15:01 --> Pagination Class Initialized
INFO - 2016-02-22 11:15:01 --> Helper loaded: text_helper
INFO - 2016-02-22 11:15:01 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:15:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:15:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:15:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:15:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:15:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:15:01 --> Final output sent to browser
DEBUG - 2016-02-22 14:15:01 --> Total execution time: 1.1737
INFO - 2016-02-22 11:15:33 --> Config Class Initialized
INFO - 2016-02-22 11:15:33 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:15:33 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:15:33 --> Utf8 Class Initialized
INFO - 2016-02-22 11:15:33 --> URI Class Initialized
INFO - 2016-02-22 11:15:33 --> Router Class Initialized
INFO - 2016-02-22 11:15:33 --> Output Class Initialized
INFO - 2016-02-22 11:15:33 --> Security Class Initialized
DEBUG - 2016-02-22 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:15:33 --> Input Class Initialized
INFO - 2016-02-22 11:15:33 --> Language Class Initialized
INFO - 2016-02-22 11:15:33 --> Loader Class Initialized
INFO - 2016-02-22 11:15:33 --> Helper loaded: url_helper
INFO - 2016-02-22 11:15:33 --> Helper loaded: file_helper
INFO - 2016-02-22 11:15:33 --> Helper loaded: date_helper
INFO - 2016-02-22 11:15:33 --> Helper loaded: form_helper
INFO - 2016-02-22 11:15:33 --> Database Driver Class Initialized
INFO - 2016-02-22 11:15:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:15:34 --> Controller Class Initialized
INFO - 2016-02-22 11:15:34 --> Model Class Initialized
INFO - 2016-02-22 11:15:34 --> Model Class Initialized
INFO - 2016-02-22 11:15:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:15:34 --> Pagination Class Initialized
INFO - 2016-02-22 11:15:34 --> Helper loaded: text_helper
INFO - 2016-02-22 11:15:34 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:15:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:15:34 --> Final output sent to browser
DEBUG - 2016-02-22 14:15:34 --> Total execution time: 1.2130
INFO - 2016-02-22 11:20:44 --> Config Class Initialized
INFO - 2016-02-22 11:20:44 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:20:44 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:20:44 --> Utf8 Class Initialized
INFO - 2016-02-22 11:20:44 --> URI Class Initialized
INFO - 2016-02-22 11:20:44 --> Router Class Initialized
INFO - 2016-02-22 11:20:44 --> Output Class Initialized
INFO - 2016-02-22 11:20:44 --> Security Class Initialized
DEBUG - 2016-02-22 11:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:20:44 --> Input Class Initialized
INFO - 2016-02-22 11:20:44 --> Language Class Initialized
INFO - 2016-02-22 11:20:44 --> Loader Class Initialized
INFO - 2016-02-22 11:20:44 --> Helper loaded: url_helper
INFO - 2016-02-22 11:20:44 --> Helper loaded: file_helper
INFO - 2016-02-22 11:20:44 --> Helper loaded: date_helper
INFO - 2016-02-22 11:20:44 --> Helper loaded: form_helper
INFO - 2016-02-22 11:20:44 --> Database Driver Class Initialized
INFO - 2016-02-22 11:20:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:20:45 --> Controller Class Initialized
INFO - 2016-02-22 11:20:45 --> Model Class Initialized
INFO - 2016-02-22 11:20:45 --> Model Class Initialized
INFO - 2016-02-22 11:20:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:20:45 --> Pagination Class Initialized
INFO - 2016-02-22 11:20:45 --> Helper loaded: text_helper
INFO - 2016-02-22 11:20:45 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:20:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:20:45 --> Final output sent to browser
DEBUG - 2016-02-22 14:20:45 --> Total execution time: 1.2226
INFO - 2016-02-22 11:25:15 --> Config Class Initialized
INFO - 2016-02-22 11:25:15 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:25:15 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:25:15 --> Utf8 Class Initialized
INFO - 2016-02-22 11:25:15 --> URI Class Initialized
INFO - 2016-02-22 11:25:15 --> Router Class Initialized
INFO - 2016-02-22 11:25:15 --> Output Class Initialized
INFO - 2016-02-22 11:25:15 --> Security Class Initialized
DEBUG - 2016-02-22 11:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:25:15 --> Input Class Initialized
INFO - 2016-02-22 11:25:15 --> Language Class Initialized
INFO - 2016-02-22 11:25:15 --> Loader Class Initialized
INFO - 2016-02-22 11:25:15 --> Helper loaded: url_helper
INFO - 2016-02-22 11:25:15 --> Helper loaded: file_helper
INFO - 2016-02-22 11:25:15 --> Helper loaded: date_helper
INFO - 2016-02-22 11:25:15 --> Helper loaded: form_helper
INFO - 2016-02-22 11:25:15 --> Database Driver Class Initialized
INFO - 2016-02-22 11:25:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:25:16 --> Controller Class Initialized
INFO - 2016-02-22 11:25:16 --> Model Class Initialized
INFO - 2016-02-22 11:25:16 --> Model Class Initialized
INFO - 2016-02-22 11:25:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:25:16 --> Pagination Class Initialized
INFO - 2016-02-22 11:25:16 --> Helper loaded: text_helper
INFO - 2016-02-22 11:25:16 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:25:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:25:16 --> Final output sent to browser
DEBUG - 2016-02-22 14:25:16 --> Total execution time: 1.2378
INFO - 2016-02-22 11:26:37 --> Config Class Initialized
INFO - 2016-02-22 11:26:37 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:26:37 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:26:37 --> Utf8 Class Initialized
INFO - 2016-02-22 11:26:37 --> URI Class Initialized
INFO - 2016-02-22 11:26:37 --> Router Class Initialized
INFO - 2016-02-22 11:26:37 --> Output Class Initialized
INFO - 2016-02-22 11:26:37 --> Security Class Initialized
DEBUG - 2016-02-22 11:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:26:37 --> Input Class Initialized
INFO - 2016-02-22 11:26:37 --> Language Class Initialized
INFO - 2016-02-22 11:26:37 --> Loader Class Initialized
INFO - 2016-02-22 11:26:37 --> Helper loaded: url_helper
INFO - 2016-02-22 11:26:37 --> Helper loaded: file_helper
INFO - 2016-02-22 11:26:37 --> Helper loaded: date_helper
INFO - 2016-02-22 11:26:37 --> Helper loaded: form_helper
INFO - 2016-02-22 11:26:37 --> Database Driver Class Initialized
INFO - 2016-02-22 11:26:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:26:39 --> Controller Class Initialized
INFO - 2016-02-22 11:26:39 --> Model Class Initialized
INFO - 2016-02-22 11:26:39 --> Model Class Initialized
INFO - 2016-02-22 11:26:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:26:39 --> Pagination Class Initialized
INFO - 2016-02-22 11:26:39 --> Helper loaded: text_helper
INFO - 2016-02-22 11:26:39 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:26:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:26:39 --> Final output sent to browser
DEBUG - 2016-02-22 14:26:39 --> Total execution time: 1.2435
INFO - 2016-02-22 11:29:20 --> Config Class Initialized
INFO - 2016-02-22 11:29:20 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:29:20 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:29:20 --> Utf8 Class Initialized
INFO - 2016-02-22 11:29:20 --> URI Class Initialized
INFO - 2016-02-22 11:29:20 --> Router Class Initialized
INFO - 2016-02-22 11:29:20 --> Output Class Initialized
INFO - 2016-02-22 11:29:20 --> Security Class Initialized
DEBUG - 2016-02-22 11:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:29:20 --> Input Class Initialized
INFO - 2016-02-22 11:29:20 --> Language Class Initialized
INFO - 2016-02-22 11:29:20 --> Loader Class Initialized
INFO - 2016-02-22 11:29:20 --> Helper loaded: url_helper
INFO - 2016-02-22 11:29:20 --> Helper loaded: file_helper
INFO - 2016-02-22 11:29:20 --> Helper loaded: date_helper
INFO - 2016-02-22 11:29:20 --> Helper loaded: form_helper
INFO - 2016-02-22 11:29:20 --> Database Driver Class Initialized
INFO - 2016-02-22 11:29:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:29:21 --> Controller Class Initialized
INFO - 2016-02-22 11:29:21 --> Model Class Initialized
INFO - 2016-02-22 11:29:21 --> Model Class Initialized
INFO - 2016-02-22 11:29:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:29:21 --> Pagination Class Initialized
INFO - 2016-02-22 11:29:21 --> Helper loaded: text_helper
INFO - 2016-02-22 11:29:21 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:29:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:29:21 --> Final output sent to browser
DEBUG - 2016-02-22 14:29:21 --> Total execution time: 1.2296
INFO - 2016-02-22 11:29:24 --> Config Class Initialized
INFO - 2016-02-22 11:29:24 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:29:24 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:29:24 --> Utf8 Class Initialized
INFO - 2016-02-22 11:29:24 --> URI Class Initialized
INFO - 2016-02-22 11:29:24 --> Router Class Initialized
INFO - 2016-02-22 11:29:24 --> Output Class Initialized
INFO - 2016-02-22 11:29:24 --> Security Class Initialized
DEBUG - 2016-02-22 11:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:29:24 --> Input Class Initialized
INFO - 2016-02-22 11:29:24 --> Language Class Initialized
INFO - 2016-02-22 11:29:24 --> Loader Class Initialized
INFO - 2016-02-22 11:29:24 --> Helper loaded: url_helper
INFO - 2016-02-22 11:29:24 --> Helper loaded: file_helper
INFO - 2016-02-22 11:29:24 --> Helper loaded: date_helper
INFO - 2016-02-22 11:29:24 --> Helper loaded: form_helper
INFO - 2016-02-22 11:29:24 --> Database Driver Class Initialized
INFO - 2016-02-22 11:29:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:29:25 --> Controller Class Initialized
INFO - 2016-02-22 11:29:25 --> Model Class Initialized
INFO - 2016-02-22 11:29:25 --> Model Class Initialized
INFO - 2016-02-22 11:29:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:29:25 --> Pagination Class Initialized
INFO - 2016-02-22 11:29:25 --> Helper loaded: text_helper
INFO - 2016-02-22 11:29:25 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\dmessage.php
INFO - 2016-02-22 14:29:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:29:25 --> Final output sent to browser
DEBUG - 2016-02-22 14:29:25 --> Total execution time: 1.2238
INFO - 2016-02-22 11:43:58 --> Config Class Initialized
INFO - 2016-02-22 11:43:58 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:43:58 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:43:58 --> Utf8 Class Initialized
INFO - 2016-02-22 11:43:58 --> URI Class Initialized
INFO - 2016-02-22 11:43:58 --> Router Class Initialized
INFO - 2016-02-22 11:43:58 --> Output Class Initialized
INFO - 2016-02-22 11:43:58 --> Security Class Initialized
DEBUG - 2016-02-22 11:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:43:58 --> Input Class Initialized
INFO - 2016-02-22 11:43:58 --> Language Class Initialized
INFO - 2016-02-22 11:43:58 --> Loader Class Initialized
INFO - 2016-02-22 11:43:58 --> Helper loaded: url_helper
INFO - 2016-02-22 11:43:58 --> Helper loaded: file_helper
INFO - 2016-02-22 11:43:58 --> Helper loaded: date_helper
INFO - 2016-02-22 11:43:58 --> Helper loaded: form_helper
INFO - 2016-02-22 11:43:58 --> Database Driver Class Initialized
INFO - 2016-02-22 11:43:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:43:59 --> Controller Class Initialized
INFO - 2016-02-22 11:43:59 --> Model Class Initialized
INFO - 2016-02-22 11:43:59 --> Model Class Initialized
INFO - 2016-02-22 11:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:43:59 --> Pagination Class Initialized
INFO - 2016-02-22 11:43:59 --> Helper loaded: text_helper
INFO - 2016-02-22 11:43:59 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 14:43:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:43:59 --> Final output sent to browser
DEBUG - 2016-02-22 14:43:59 --> Total execution time: 1.1402
INFO - 2016-02-22 11:44:03 --> Config Class Initialized
INFO - 2016-02-22 11:44:03 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:44:03 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:44:03 --> Utf8 Class Initialized
INFO - 2016-02-22 11:44:03 --> URI Class Initialized
INFO - 2016-02-22 11:44:03 --> Router Class Initialized
INFO - 2016-02-22 11:44:03 --> Output Class Initialized
INFO - 2016-02-22 11:44:03 --> Security Class Initialized
DEBUG - 2016-02-22 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:44:03 --> Input Class Initialized
INFO - 2016-02-22 11:44:03 --> Language Class Initialized
INFO - 2016-02-22 11:44:03 --> Loader Class Initialized
INFO - 2016-02-22 11:44:03 --> Helper loaded: url_helper
INFO - 2016-02-22 11:44:03 --> Helper loaded: file_helper
INFO - 2016-02-22 11:44:03 --> Helper loaded: date_helper
INFO - 2016-02-22 11:44:03 --> Helper loaded: form_helper
INFO - 2016-02-22 11:44:03 --> Database Driver Class Initialized
INFO - 2016-02-22 11:44:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:44:04 --> Controller Class Initialized
INFO - 2016-02-22 11:44:04 --> Model Class Initialized
INFO - 2016-02-22 11:44:04 --> Model Class Initialized
INFO - 2016-02-22 11:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:44:04 --> Pagination Class Initialized
INFO - 2016-02-22 11:44:04 --> Helper loaded: text_helper
INFO - 2016-02-22 11:44:04 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 14:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:44:04 --> Final output sent to browser
DEBUG - 2016-02-22 14:44:04 --> Total execution time: 1.1195
INFO - 2016-02-22 11:44:16 --> Config Class Initialized
INFO - 2016-02-22 11:44:16 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:44:16 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:44:16 --> Utf8 Class Initialized
INFO - 2016-02-22 11:44:16 --> URI Class Initialized
INFO - 2016-02-22 11:44:16 --> Router Class Initialized
INFO - 2016-02-22 11:44:16 --> Output Class Initialized
INFO - 2016-02-22 11:44:16 --> Security Class Initialized
DEBUG - 2016-02-22 11:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:44:16 --> Input Class Initialized
INFO - 2016-02-22 11:44:16 --> Language Class Initialized
INFO - 2016-02-22 11:44:16 --> Loader Class Initialized
INFO - 2016-02-22 11:44:16 --> Helper loaded: url_helper
INFO - 2016-02-22 11:44:16 --> Helper loaded: file_helper
INFO - 2016-02-22 11:44:16 --> Helper loaded: date_helper
INFO - 2016-02-22 11:44:16 --> Helper loaded: form_helper
INFO - 2016-02-22 11:44:16 --> Database Driver Class Initialized
INFO - 2016-02-22 11:44:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:44:17 --> Controller Class Initialized
INFO - 2016-02-22 11:44:17 --> Model Class Initialized
INFO - 2016-02-22 11:44:17 --> Model Class Initialized
INFO - 2016-02-22 11:44:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:44:17 --> Pagination Class Initialized
INFO - 2016-02-22 11:44:17 --> Helper loaded: text_helper
INFO - 2016-02-22 11:44:17 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 14:44:17 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 14:44:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:44:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:44:17 --> Form Validation Class Initialized
INFO - 2016-02-22 14:44:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 11:44:17 --> Config Class Initialized
INFO - 2016-02-22 11:44:17 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:44:17 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:44:17 --> Utf8 Class Initialized
INFO - 2016-02-22 11:44:17 --> URI Class Initialized
INFO - 2016-02-22 11:44:17 --> Router Class Initialized
INFO - 2016-02-22 11:44:17 --> Output Class Initialized
INFO - 2016-02-22 11:44:17 --> Security Class Initialized
DEBUG - 2016-02-22 11:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:44:17 --> Input Class Initialized
INFO - 2016-02-22 11:44:17 --> Language Class Initialized
INFO - 2016-02-22 11:44:17 --> Loader Class Initialized
INFO - 2016-02-22 11:44:17 --> Helper loaded: url_helper
INFO - 2016-02-22 11:44:17 --> Helper loaded: file_helper
INFO - 2016-02-22 11:44:17 --> Helper loaded: date_helper
INFO - 2016-02-22 11:44:17 --> Helper loaded: form_helper
INFO - 2016-02-22 11:44:17 --> Database Driver Class Initialized
INFO - 2016-02-22 11:44:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:44:18 --> Controller Class Initialized
INFO - 2016-02-22 11:44:18 --> Model Class Initialized
INFO - 2016-02-22 11:44:18 --> Model Class Initialized
INFO - 2016-02-22 11:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:44:18 --> Pagination Class Initialized
INFO - 2016-02-22 11:44:18 --> Helper loaded: text_helper
INFO - 2016-02-22 11:44:18 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 14:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:44:18 --> Final output sent to browser
DEBUG - 2016-02-22 14:44:18 --> Total execution time: 1.2119
INFO - 2016-02-22 11:44:23 --> Config Class Initialized
INFO - 2016-02-22 11:44:23 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:44:23 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:44:23 --> Utf8 Class Initialized
INFO - 2016-02-22 11:44:23 --> URI Class Initialized
INFO - 2016-02-22 11:44:23 --> Router Class Initialized
INFO - 2016-02-22 11:44:23 --> Output Class Initialized
INFO - 2016-02-22 11:44:23 --> Security Class Initialized
DEBUG - 2016-02-22 11:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:44:23 --> Input Class Initialized
INFO - 2016-02-22 11:44:23 --> Language Class Initialized
INFO - 2016-02-22 11:44:23 --> Loader Class Initialized
INFO - 2016-02-22 11:44:23 --> Helper loaded: url_helper
INFO - 2016-02-22 11:44:23 --> Helper loaded: file_helper
INFO - 2016-02-22 11:44:23 --> Helper loaded: date_helper
INFO - 2016-02-22 11:44:23 --> Helper loaded: form_helper
INFO - 2016-02-22 11:44:23 --> Database Driver Class Initialized
INFO - 2016-02-22 11:44:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:44:24 --> Controller Class Initialized
INFO - 2016-02-22 11:44:24 --> Model Class Initialized
INFO - 2016-02-22 11:44:24 --> Model Class Initialized
INFO - 2016-02-22 11:44:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:44:24 --> Pagination Class Initialized
INFO - 2016-02-22 11:44:24 --> Helper loaded: text_helper
INFO - 2016-02-22 11:44:24 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:44:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:44:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 11:44:24 --> Config Class Initialized
INFO - 2016-02-22 11:44:24 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:44:24 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:44:24 --> Utf8 Class Initialized
INFO - 2016-02-22 11:44:24 --> URI Class Initialized
INFO - 2016-02-22 11:44:24 --> Router Class Initialized
INFO - 2016-02-22 11:44:24 --> Output Class Initialized
INFO - 2016-02-22 11:44:24 --> Security Class Initialized
DEBUG - 2016-02-22 11:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:44:24 --> Input Class Initialized
INFO - 2016-02-22 11:44:24 --> Language Class Initialized
INFO - 2016-02-22 11:44:24 --> Loader Class Initialized
INFO - 2016-02-22 11:44:24 --> Helper loaded: url_helper
INFO - 2016-02-22 11:44:24 --> Helper loaded: file_helper
INFO - 2016-02-22 11:44:24 --> Helper loaded: date_helper
INFO - 2016-02-22 11:44:24 --> Helper loaded: form_helper
INFO - 2016-02-22 11:44:24 --> Database Driver Class Initialized
INFO - 2016-02-22 11:44:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:44:25 --> Controller Class Initialized
INFO - 2016-02-22 11:44:25 --> Model Class Initialized
INFO - 2016-02-22 11:44:25 --> Model Class Initialized
INFO - 2016-02-22 11:44:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:44:25 --> Pagination Class Initialized
INFO - 2016-02-22 11:44:25 --> Helper loaded: text_helper
INFO - 2016-02-22 11:44:25 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 14:44:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:44:25 --> Final output sent to browser
DEBUG - 2016-02-22 14:44:25 --> Total execution time: 1.1676
INFO - 2016-02-22 11:50:19 --> Config Class Initialized
INFO - 2016-02-22 11:50:19 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:50:19 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:50:19 --> Utf8 Class Initialized
INFO - 2016-02-22 11:50:19 --> URI Class Initialized
INFO - 2016-02-22 11:50:19 --> Router Class Initialized
INFO - 2016-02-22 11:50:19 --> Output Class Initialized
INFO - 2016-02-22 11:50:19 --> Security Class Initialized
DEBUG - 2016-02-22 11:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:50:19 --> Input Class Initialized
INFO - 2016-02-22 11:50:19 --> Language Class Initialized
INFO - 2016-02-22 11:50:19 --> Loader Class Initialized
INFO - 2016-02-22 11:50:19 --> Helper loaded: url_helper
INFO - 2016-02-22 11:50:19 --> Helper loaded: file_helper
INFO - 2016-02-22 11:50:19 --> Helper loaded: date_helper
INFO - 2016-02-22 11:50:19 --> Helper loaded: form_helper
INFO - 2016-02-22 11:50:19 --> Database Driver Class Initialized
INFO - 2016-02-22 11:50:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:50:20 --> Controller Class Initialized
INFO - 2016-02-22 11:50:20 --> Model Class Initialized
INFO - 2016-02-22 11:50:20 --> Model Class Initialized
INFO - 2016-02-22 11:50:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:50:20 --> Pagination Class Initialized
INFO - 2016-02-22 11:50:20 --> Helper loaded: text_helper
INFO - 2016-02-22 11:50:20 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:50:20 --> Form Validation Class Initialized
INFO - 2016-02-22 14:50:20 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-22 14:50:20 --> Query error: Column 'title' in where clause is ambiguous - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `jdmain`, `picture`, `video`
WHERE `title` LIKE '%as%' ESCAPE '!'
OR  `description` LIKE '%as%' ESCAPE '!'
INFO - 2016-02-22 14:50:20 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-22 11:51:05 --> Config Class Initialized
INFO - 2016-02-22 11:51:05 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:51:05 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:51:05 --> Utf8 Class Initialized
INFO - 2016-02-22 11:51:05 --> URI Class Initialized
INFO - 2016-02-22 11:51:05 --> Router Class Initialized
INFO - 2016-02-22 11:51:05 --> Output Class Initialized
INFO - 2016-02-22 11:51:05 --> Security Class Initialized
DEBUG - 2016-02-22 11:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:51:05 --> Input Class Initialized
INFO - 2016-02-22 11:51:05 --> Language Class Initialized
INFO - 2016-02-22 11:51:05 --> Loader Class Initialized
INFO - 2016-02-22 11:51:05 --> Helper loaded: url_helper
INFO - 2016-02-22 11:51:05 --> Helper loaded: file_helper
INFO - 2016-02-22 11:51:05 --> Helper loaded: date_helper
INFO - 2016-02-22 11:51:05 --> Helper loaded: form_helper
INFO - 2016-02-22 11:51:05 --> Database Driver Class Initialized
INFO - 2016-02-22 11:51:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:51:06 --> Controller Class Initialized
INFO - 2016-02-22 11:51:06 --> Model Class Initialized
INFO - 2016-02-22 11:51:06 --> Model Class Initialized
INFO - 2016-02-22 11:51:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:51:06 --> Pagination Class Initialized
INFO - 2016-02-22 11:51:06 --> Helper loaded: text_helper
INFO - 2016-02-22 11:51:06 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 14:51:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:51:06 --> Final output sent to browser
DEBUG - 2016-02-22 14:51:06 --> Total execution time: 1.1557
INFO - 2016-02-22 11:51:10 --> Config Class Initialized
INFO - 2016-02-22 11:51:10 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:51:10 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:51:10 --> Utf8 Class Initialized
INFO - 2016-02-22 11:51:10 --> URI Class Initialized
INFO - 2016-02-22 11:51:10 --> Router Class Initialized
INFO - 2016-02-22 11:51:10 --> Output Class Initialized
INFO - 2016-02-22 11:51:10 --> Security Class Initialized
DEBUG - 2016-02-22 11:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:51:10 --> Input Class Initialized
INFO - 2016-02-22 11:51:10 --> Language Class Initialized
INFO - 2016-02-22 11:51:10 --> Loader Class Initialized
INFO - 2016-02-22 11:51:10 --> Helper loaded: url_helper
INFO - 2016-02-22 11:51:10 --> Helper loaded: file_helper
INFO - 2016-02-22 11:51:10 --> Helper loaded: date_helper
INFO - 2016-02-22 11:51:10 --> Helper loaded: form_helper
INFO - 2016-02-22 11:51:10 --> Database Driver Class Initialized
INFO - 2016-02-22 11:51:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:51:11 --> Controller Class Initialized
INFO - 2016-02-22 11:51:11 --> Model Class Initialized
INFO - 2016-02-22 11:51:11 --> Model Class Initialized
INFO - 2016-02-22 11:51:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:51:11 --> Pagination Class Initialized
INFO - 2016-02-22 11:51:11 --> Helper loaded: text_helper
INFO - 2016-02-22 11:51:11 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:51:11 --> Form Validation Class Initialized
INFO - 2016-02-22 14:51:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-22 14:51:11 --> Query error: Column 'title' in where clause is ambiguous - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `jdmain`, `picture`
WHERE `title` LIKE '%as%' ESCAPE '!'
OR  `description` LIKE '%as%' ESCAPE '!'
INFO - 2016-02-22 14:51:11 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-22 14:51:11 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1456170671
WHERE `title` LIKE '%as%' ESCAPE '!'
OR  `description` LIKE '%as%' ESCAPE '!'
AND `id` = 'e95e471b9610ab68d5ff577e6325edc53d14b3f4'
INFO - 2016-02-22 11:52:32 --> Config Class Initialized
INFO - 2016-02-22 11:52:32 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:52:32 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:52:32 --> Utf8 Class Initialized
INFO - 2016-02-22 11:52:33 --> URI Class Initialized
INFO - 2016-02-22 11:52:33 --> Router Class Initialized
INFO - 2016-02-22 11:52:33 --> Output Class Initialized
INFO - 2016-02-22 11:52:33 --> Security Class Initialized
DEBUG - 2016-02-22 11:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:52:33 --> Input Class Initialized
INFO - 2016-02-22 11:52:33 --> Language Class Initialized
INFO - 2016-02-22 11:52:33 --> Loader Class Initialized
INFO - 2016-02-22 11:52:33 --> Helper loaded: url_helper
INFO - 2016-02-22 11:52:33 --> Helper loaded: file_helper
INFO - 2016-02-22 11:52:33 --> Helper loaded: date_helper
INFO - 2016-02-22 11:52:33 --> Helper loaded: form_helper
INFO - 2016-02-22 11:52:33 --> Database Driver Class Initialized
INFO - 2016-02-22 11:52:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:52:34 --> Controller Class Initialized
INFO - 2016-02-22 11:52:34 --> Model Class Initialized
INFO - 2016-02-22 11:52:34 --> Model Class Initialized
INFO - 2016-02-22 11:52:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:52:34 --> Pagination Class Initialized
INFO - 2016-02-22 11:52:34 --> Helper loaded: text_helper
INFO - 2016-02-22 11:52:34 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 14:52:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:52:34 --> Final output sent to browser
DEBUG - 2016-02-22 14:52:34 --> Total execution time: 1.1648
INFO - 2016-02-22 11:52:37 --> Config Class Initialized
INFO - 2016-02-22 11:52:37 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:52:37 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:52:37 --> Utf8 Class Initialized
INFO - 2016-02-22 11:52:37 --> URI Class Initialized
INFO - 2016-02-22 11:52:37 --> Router Class Initialized
INFO - 2016-02-22 11:52:37 --> Output Class Initialized
INFO - 2016-02-22 11:52:37 --> Security Class Initialized
DEBUG - 2016-02-22 11:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:52:37 --> Input Class Initialized
INFO - 2016-02-22 11:52:38 --> Language Class Initialized
INFO - 2016-02-22 11:52:38 --> Loader Class Initialized
INFO - 2016-02-22 11:52:38 --> Helper loaded: url_helper
INFO - 2016-02-22 11:52:38 --> Helper loaded: file_helper
INFO - 2016-02-22 11:52:38 --> Helper loaded: date_helper
INFO - 2016-02-22 11:52:38 --> Helper loaded: form_helper
INFO - 2016-02-22 11:52:38 --> Database Driver Class Initialized
INFO - 2016-02-22 11:52:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:52:39 --> Controller Class Initialized
INFO - 2016-02-22 11:52:39 --> Model Class Initialized
INFO - 2016-02-22 11:52:39 --> Model Class Initialized
INFO - 2016-02-22 11:52:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:52:39 --> Pagination Class Initialized
INFO - 2016-02-22 11:52:39 --> Helper loaded: text_helper
INFO - 2016-02-22 11:52:39 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:52:39 --> Form Validation Class Initialized
INFO - 2016-02-22 14:52:39 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-22 14:52:39 --> Query error: Column 'title' in where clause is ambiguous - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `jdmain`, `picture`
WHERE `title` LIKE '%as%' ESCAPE '!'
OR  `description` LIKE '%as%' ESCAPE '!'
INFO - 2016-02-22 14:52:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-22 14:52:39 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1456170759
WHERE `title` LIKE '%as%' ESCAPE '!'
OR  `description` LIKE '%as%' ESCAPE '!'
AND `id` = 'e95e471b9610ab68d5ff577e6325edc53d14b3f4'
INFO - 2016-02-22 11:55:26 --> Config Class Initialized
INFO - 2016-02-22 11:55:26 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:55:26 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:55:26 --> Utf8 Class Initialized
INFO - 2016-02-22 11:55:26 --> URI Class Initialized
INFO - 2016-02-22 11:55:26 --> Router Class Initialized
INFO - 2016-02-22 11:55:26 --> Output Class Initialized
INFO - 2016-02-22 11:55:26 --> Security Class Initialized
DEBUG - 2016-02-22 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:55:26 --> Input Class Initialized
INFO - 2016-02-22 11:55:26 --> Language Class Initialized
INFO - 2016-02-22 11:55:26 --> Loader Class Initialized
INFO - 2016-02-22 11:55:26 --> Helper loaded: url_helper
INFO - 2016-02-22 11:55:26 --> Helper loaded: file_helper
INFO - 2016-02-22 11:55:26 --> Helper loaded: date_helper
INFO - 2016-02-22 11:55:26 --> Helper loaded: form_helper
INFO - 2016-02-22 11:55:26 --> Database Driver Class Initialized
INFO - 2016-02-22 11:55:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:55:27 --> Controller Class Initialized
INFO - 2016-02-22 11:55:27 --> Model Class Initialized
INFO - 2016-02-22 11:55:27 --> Model Class Initialized
INFO - 2016-02-22 11:55:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:55:27 --> Pagination Class Initialized
INFO - 2016-02-22 11:55:27 --> Helper loaded: text_helper
INFO - 2016-02-22 11:55:27 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:55:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:55:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:55:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 14:55:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:55:27 --> Final output sent to browser
DEBUG - 2016-02-22 14:55:27 --> Total execution time: 1.1829
INFO - 2016-02-22 11:57:34 --> Config Class Initialized
INFO - 2016-02-22 11:57:34 --> Hooks Class Initialized
DEBUG - 2016-02-22 11:57:34 --> UTF-8 Support Enabled
INFO - 2016-02-22 11:57:34 --> Utf8 Class Initialized
INFO - 2016-02-22 11:57:34 --> URI Class Initialized
INFO - 2016-02-22 11:57:34 --> Router Class Initialized
INFO - 2016-02-22 11:57:34 --> Output Class Initialized
INFO - 2016-02-22 11:57:34 --> Security Class Initialized
DEBUG - 2016-02-22 11:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 11:57:34 --> Input Class Initialized
INFO - 2016-02-22 11:57:34 --> Language Class Initialized
INFO - 2016-02-22 11:57:34 --> Loader Class Initialized
INFO - 2016-02-22 11:57:34 --> Helper loaded: url_helper
INFO - 2016-02-22 11:57:34 --> Helper loaded: file_helper
INFO - 2016-02-22 11:57:34 --> Helper loaded: date_helper
INFO - 2016-02-22 11:57:34 --> Helper loaded: form_helper
INFO - 2016-02-22 11:57:34 --> Database Driver Class Initialized
INFO - 2016-02-22 11:57:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 11:57:35 --> Controller Class Initialized
INFO - 2016-02-22 11:57:35 --> Model Class Initialized
INFO - 2016-02-22 11:57:35 --> Model Class Initialized
INFO - 2016-02-22 11:57:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 11:57:35 --> Pagination Class Initialized
INFO - 2016-02-22 11:57:35 --> Helper loaded: text_helper
INFO - 2016-02-22 11:57:35 --> Helper loaded: cookie_helper
INFO - 2016-02-22 14:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 14:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 14:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 14:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 14:57:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 14:57:35 --> Final output sent to browser
DEBUG - 2016-02-22 14:57:35 --> Total execution time: 1.1123
INFO - 2016-02-22 12:05:20 --> Config Class Initialized
INFO - 2016-02-22 12:05:20 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:05:20 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:05:20 --> Utf8 Class Initialized
INFO - 2016-02-22 12:05:20 --> URI Class Initialized
INFO - 2016-02-22 12:05:20 --> Router Class Initialized
INFO - 2016-02-22 12:05:20 --> Output Class Initialized
INFO - 2016-02-22 12:05:20 --> Security Class Initialized
DEBUG - 2016-02-22 12:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:05:20 --> Input Class Initialized
INFO - 2016-02-22 12:05:20 --> Language Class Initialized
INFO - 2016-02-22 12:05:20 --> Loader Class Initialized
INFO - 2016-02-22 12:05:20 --> Helper loaded: url_helper
INFO - 2016-02-22 12:05:20 --> Helper loaded: file_helper
INFO - 2016-02-22 12:05:20 --> Helper loaded: date_helper
INFO - 2016-02-22 12:05:20 --> Helper loaded: form_helper
INFO - 2016-02-22 12:05:20 --> Database Driver Class Initialized
INFO - 2016-02-22 12:05:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:05:21 --> Controller Class Initialized
INFO - 2016-02-22 12:05:21 --> Model Class Initialized
INFO - 2016-02-22 12:05:21 --> Model Class Initialized
INFO - 2016-02-22 12:05:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:05:21 --> Pagination Class Initialized
INFO - 2016-02-22 12:05:21 --> Helper loaded: text_helper
INFO - 2016-02-22 12:05:21 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 15:05:21 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 15:05:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:05:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:05:21 --> Form Validation Class Initialized
INFO - 2016-02-22 15:05:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 12:05:22 --> Config Class Initialized
INFO - 2016-02-22 12:05:22 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:05:22 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:05:22 --> Utf8 Class Initialized
INFO - 2016-02-22 12:05:22 --> URI Class Initialized
INFO - 2016-02-22 12:05:22 --> Router Class Initialized
INFO - 2016-02-22 12:05:22 --> Output Class Initialized
INFO - 2016-02-22 12:05:22 --> Security Class Initialized
DEBUG - 2016-02-22 12:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:05:22 --> Input Class Initialized
INFO - 2016-02-22 12:05:22 --> Language Class Initialized
INFO - 2016-02-22 12:05:22 --> Loader Class Initialized
INFO - 2016-02-22 12:05:22 --> Helper loaded: url_helper
INFO - 2016-02-22 12:05:22 --> Helper loaded: file_helper
INFO - 2016-02-22 12:05:22 --> Helper loaded: date_helper
INFO - 2016-02-22 12:05:22 --> Helper loaded: form_helper
INFO - 2016-02-22 12:05:22 --> Database Driver Class Initialized
INFO - 2016-02-22 12:05:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:05:23 --> Controller Class Initialized
INFO - 2016-02-22 12:05:23 --> Model Class Initialized
INFO - 2016-02-22 12:05:23 --> Model Class Initialized
INFO - 2016-02-22 12:05:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:05:23 --> Pagination Class Initialized
INFO - 2016-02-22 12:05:23 --> Helper loaded: text_helper
INFO - 2016-02-22 12:05:23 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:05:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:05:23 --> Final output sent to browser
DEBUG - 2016-02-22 15:05:23 --> Total execution time: 1.1319
INFO - 2016-02-22 12:05:31 --> Config Class Initialized
INFO - 2016-02-22 12:05:31 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:05:31 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:05:31 --> Utf8 Class Initialized
INFO - 2016-02-22 12:05:31 --> URI Class Initialized
INFO - 2016-02-22 12:05:31 --> Router Class Initialized
INFO - 2016-02-22 12:05:31 --> Output Class Initialized
INFO - 2016-02-22 12:05:32 --> Security Class Initialized
DEBUG - 2016-02-22 12:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:05:32 --> Input Class Initialized
INFO - 2016-02-22 12:05:32 --> Language Class Initialized
INFO - 2016-02-22 12:05:32 --> Loader Class Initialized
INFO - 2016-02-22 12:05:32 --> Helper loaded: url_helper
INFO - 2016-02-22 12:05:32 --> Helper loaded: file_helper
INFO - 2016-02-22 12:05:32 --> Helper loaded: date_helper
INFO - 2016-02-22 12:05:32 --> Helper loaded: form_helper
INFO - 2016-02-22 12:05:32 --> Database Driver Class Initialized
INFO - 2016-02-22 12:05:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:05:33 --> Controller Class Initialized
INFO - 2016-02-22 12:05:33 --> Model Class Initialized
INFO - 2016-02-22 12:05:33 --> Model Class Initialized
INFO - 2016-02-22 12:05:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:05:33 --> Pagination Class Initialized
INFO - 2016-02-22 12:05:33 --> Helper loaded: text_helper
INFO - 2016-02-22 12:05:33 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:05:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:05:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:05:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:05:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:05:33 --> Final output sent to browser
DEBUG - 2016-02-22 15:05:33 --> Total execution time: 1.0896
INFO - 2016-02-22 12:05:39 --> Config Class Initialized
INFO - 2016-02-22 12:05:39 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:05:39 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:05:39 --> Utf8 Class Initialized
INFO - 2016-02-22 12:05:39 --> URI Class Initialized
INFO - 2016-02-22 12:05:39 --> Router Class Initialized
INFO - 2016-02-22 12:05:39 --> Output Class Initialized
INFO - 2016-02-22 12:05:39 --> Security Class Initialized
DEBUG - 2016-02-22 12:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:05:39 --> Input Class Initialized
INFO - 2016-02-22 12:05:39 --> Language Class Initialized
INFO - 2016-02-22 12:05:39 --> Loader Class Initialized
INFO - 2016-02-22 12:05:39 --> Helper loaded: url_helper
INFO - 2016-02-22 12:05:39 --> Helper loaded: file_helper
INFO - 2016-02-22 12:05:39 --> Helper loaded: date_helper
INFO - 2016-02-22 12:05:39 --> Helper loaded: form_helper
INFO - 2016-02-22 12:05:39 --> Database Driver Class Initialized
INFO - 2016-02-22 12:05:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:05:40 --> Controller Class Initialized
INFO - 2016-02-22 12:05:40 --> Model Class Initialized
INFO - 2016-02-22 12:05:40 --> Model Class Initialized
INFO - 2016-02-22 12:05:40 --> Form Validation Class Initialized
INFO - 2016-02-22 12:05:40 --> Helper loaded: text_helper
INFO - 2016-02-22 12:05:40 --> Config Class Initialized
INFO - 2016-02-22 12:05:40 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:05:40 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:05:40 --> Utf8 Class Initialized
INFO - 2016-02-22 12:05:40 --> URI Class Initialized
DEBUG - 2016-02-22 12:05:40 --> No URI present. Default controller set.
INFO - 2016-02-22 12:05:40 --> Router Class Initialized
INFO - 2016-02-22 12:05:40 --> Output Class Initialized
INFO - 2016-02-22 12:05:40 --> Security Class Initialized
DEBUG - 2016-02-22 12:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:05:40 --> Input Class Initialized
INFO - 2016-02-22 12:05:40 --> Language Class Initialized
INFO - 2016-02-22 12:05:40 --> Loader Class Initialized
INFO - 2016-02-22 12:05:40 --> Helper loaded: url_helper
INFO - 2016-02-22 12:05:40 --> Helper loaded: file_helper
INFO - 2016-02-22 12:05:40 --> Helper loaded: date_helper
INFO - 2016-02-22 12:05:40 --> Helper loaded: form_helper
INFO - 2016-02-22 12:05:40 --> Database Driver Class Initialized
INFO - 2016-02-22 12:05:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:05:41 --> Controller Class Initialized
INFO - 2016-02-22 12:05:41 --> Model Class Initialized
INFO - 2016-02-22 12:05:41 --> Model Class Initialized
INFO - 2016-02-22 12:05:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:05:41 --> Pagination Class Initialized
INFO - 2016-02-22 12:05:41 --> Helper loaded: text_helper
INFO - 2016-02-22 12:05:41 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:05:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 15:05:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-22 15:05:41 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-22 12:05:44 --> Config Class Initialized
INFO - 2016-02-22 12:05:44 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:05:44 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:05:44 --> Utf8 Class Initialized
INFO - 2016-02-22 12:05:44 --> URI Class Initialized
INFO - 2016-02-22 12:05:44 --> Router Class Initialized
INFO - 2016-02-22 12:05:44 --> Output Class Initialized
INFO - 2016-02-22 12:05:44 --> Security Class Initialized
DEBUG - 2016-02-22 12:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:05:44 --> Input Class Initialized
INFO - 2016-02-22 12:05:44 --> Language Class Initialized
INFO - 2016-02-22 12:05:44 --> Loader Class Initialized
INFO - 2016-02-22 12:05:44 --> Helper loaded: url_helper
INFO - 2016-02-22 12:05:44 --> Helper loaded: file_helper
INFO - 2016-02-22 12:05:44 --> Helper loaded: date_helper
INFO - 2016-02-22 12:05:44 --> Helper loaded: form_helper
INFO - 2016-02-22 12:05:44 --> Database Driver Class Initialized
INFO - 2016-02-22 12:05:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:05:45 --> Controller Class Initialized
INFO - 2016-02-22 12:05:45 --> Model Class Initialized
INFO - 2016-02-22 12:05:45 --> Model Class Initialized
INFO - 2016-02-22 12:05:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:05:45 --> Pagination Class Initialized
INFO - 2016-02-22 12:05:45 --> Helper loaded: text_helper
INFO - 2016-02-22 12:05:45 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:05:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:05:45 --> Final output sent to browser
DEBUG - 2016-02-22 15:05:45 --> Total execution time: 1.1520
INFO - 2016-02-22 12:05:54 --> Config Class Initialized
INFO - 2016-02-22 12:05:54 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:05:54 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:05:54 --> Utf8 Class Initialized
INFO - 2016-02-22 12:05:54 --> URI Class Initialized
INFO - 2016-02-22 12:05:54 --> Router Class Initialized
INFO - 2016-02-22 12:05:54 --> Output Class Initialized
INFO - 2016-02-22 12:05:54 --> Security Class Initialized
DEBUG - 2016-02-22 12:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:05:54 --> Input Class Initialized
INFO - 2016-02-22 12:05:54 --> Language Class Initialized
INFO - 2016-02-22 12:05:54 --> Loader Class Initialized
INFO - 2016-02-22 12:05:54 --> Helper loaded: url_helper
INFO - 2016-02-22 12:05:54 --> Helper loaded: file_helper
INFO - 2016-02-22 12:05:54 --> Helper loaded: date_helper
INFO - 2016-02-22 12:05:54 --> Helper loaded: form_helper
INFO - 2016-02-22 12:05:54 --> Database Driver Class Initialized
INFO - 2016-02-22 12:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:05:55 --> Controller Class Initialized
INFO - 2016-02-22 12:05:55 --> Model Class Initialized
INFO - 2016-02-22 12:05:55 --> Model Class Initialized
INFO - 2016-02-22 12:05:55 --> Form Validation Class Initialized
INFO - 2016-02-22 12:05:55 --> Helper loaded: text_helper
INFO - 2016-02-22 12:05:55 --> Final output sent to browser
DEBUG - 2016-02-22 12:05:55 --> Total execution time: 1.1794
INFO - 2016-02-22 12:05:57 --> Config Class Initialized
INFO - 2016-02-22 12:05:57 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:05:57 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:05:57 --> Utf8 Class Initialized
INFO - 2016-02-22 12:05:57 --> URI Class Initialized
INFO - 2016-02-22 12:05:57 --> Router Class Initialized
INFO - 2016-02-22 12:05:57 --> Output Class Initialized
INFO - 2016-02-22 12:05:57 --> Security Class Initialized
DEBUG - 2016-02-22 12:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:05:57 --> Input Class Initialized
INFO - 2016-02-22 12:05:57 --> Language Class Initialized
INFO - 2016-02-22 12:05:57 --> Loader Class Initialized
INFO - 2016-02-22 12:05:57 --> Helper loaded: url_helper
INFO - 2016-02-22 12:05:57 --> Helper loaded: file_helper
INFO - 2016-02-22 12:05:57 --> Helper loaded: date_helper
INFO - 2016-02-22 12:05:57 --> Helper loaded: form_helper
INFO - 2016-02-22 12:05:57 --> Database Driver Class Initialized
INFO - 2016-02-22 12:05:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:05:58 --> Controller Class Initialized
INFO - 2016-02-22 12:05:58 --> Model Class Initialized
INFO - 2016-02-22 12:05:58 --> Model Class Initialized
INFO - 2016-02-22 12:05:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:05:58 --> Pagination Class Initialized
INFO - 2016-02-22 12:05:58 --> Helper loaded: text_helper
INFO - 2016-02-22 12:05:58 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:05:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:05:58 --> Final output sent to browser
DEBUG - 2016-02-22 15:05:58 --> Total execution time: 1.1516
INFO - 2016-02-22 12:06:09 --> Config Class Initialized
INFO - 2016-02-22 12:06:09 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:06:09 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:06:09 --> Utf8 Class Initialized
INFO - 2016-02-22 12:06:09 --> URI Class Initialized
INFO - 2016-02-22 12:06:09 --> Router Class Initialized
INFO - 2016-02-22 12:06:09 --> Output Class Initialized
INFO - 2016-02-22 12:06:09 --> Security Class Initialized
DEBUG - 2016-02-22 12:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:06:09 --> Input Class Initialized
INFO - 2016-02-22 12:06:09 --> Language Class Initialized
INFO - 2016-02-22 12:06:09 --> Loader Class Initialized
INFO - 2016-02-22 12:06:09 --> Helper loaded: url_helper
INFO - 2016-02-22 12:06:09 --> Helper loaded: file_helper
INFO - 2016-02-22 12:06:09 --> Helper loaded: date_helper
INFO - 2016-02-22 12:06:09 --> Helper loaded: form_helper
INFO - 2016-02-22 12:06:09 --> Database Driver Class Initialized
INFO - 2016-02-22 12:06:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:06:10 --> Controller Class Initialized
INFO - 2016-02-22 12:06:10 --> Model Class Initialized
INFO - 2016-02-22 12:06:10 --> Model Class Initialized
INFO - 2016-02-22 12:06:10 --> Form Validation Class Initialized
INFO - 2016-02-22 12:06:10 --> Helper loaded: text_helper
INFO - 2016-02-22 12:06:10 --> Config Class Initialized
INFO - 2016-02-22 12:06:10 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:06:10 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:06:10 --> Utf8 Class Initialized
INFO - 2016-02-22 12:06:10 --> URI Class Initialized
INFO - 2016-02-22 12:06:10 --> Router Class Initialized
INFO - 2016-02-22 12:06:10 --> Output Class Initialized
INFO - 2016-02-22 12:06:10 --> Security Class Initialized
DEBUG - 2016-02-22 12:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:06:10 --> Input Class Initialized
INFO - 2016-02-22 12:06:10 --> Language Class Initialized
INFO - 2016-02-22 12:06:10 --> Loader Class Initialized
INFO - 2016-02-22 12:06:10 --> Helper loaded: url_helper
INFO - 2016-02-22 12:06:10 --> Helper loaded: file_helper
INFO - 2016-02-22 12:06:10 --> Helper loaded: date_helper
INFO - 2016-02-22 12:06:10 --> Helper loaded: form_helper
INFO - 2016-02-22 12:06:10 --> Database Driver Class Initialized
INFO - 2016-02-22 12:06:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:06:11 --> Controller Class Initialized
INFO - 2016-02-22 12:06:11 --> Model Class Initialized
INFO - 2016-02-22 12:06:11 --> Model Class Initialized
INFO - 2016-02-22 12:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:06:11 --> Pagination Class Initialized
INFO - 2016-02-22 12:06:11 --> Helper loaded: text_helper
INFO - 2016-02-22 12:06:11 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:06:11 --> Final output sent to browser
DEBUG - 2016-02-22 15:06:11 --> Total execution time: 1.1009
INFO - 2016-02-22 12:06:16 --> Config Class Initialized
INFO - 2016-02-22 12:06:16 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:06:16 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:06:16 --> Utf8 Class Initialized
INFO - 2016-02-22 12:06:16 --> URI Class Initialized
INFO - 2016-02-22 12:06:16 --> Router Class Initialized
INFO - 2016-02-22 12:06:16 --> Output Class Initialized
INFO - 2016-02-22 12:06:16 --> Security Class Initialized
DEBUG - 2016-02-22 12:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:06:16 --> Input Class Initialized
INFO - 2016-02-22 12:06:16 --> Language Class Initialized
INFO - 2016-02-22 12:06:16 --> Loader Class Initialized
INFO - 2016-02-22 12:06:16 --> Helper loaded: url_helper
INFO - 2016-02-22 12:06:16 --> Helper loaded: file_helper
INFO - 2016-02-22 12:06:16 --> Helper loaded: date_helper
INFO - 2016-02-22 12:06:16 --> Helper loaded: form_helper
INFO - 2016-02-22 12:06:16 --> Database Driver Class Initialized
INFO - 2016-02-22 12:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:06:17 --> Controller Class Initialized
INFO - 2016-02-22 12:06:17 --> Model Class Initialized
INFO - 2016-02-22 12:06:17 --> Model Class Initialized
INFO - 2016-02-22 12:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:06:17 --> Pagination Class Initialized
INFO - 2016-02-22 12:06:17 --> Helper loaded: text_helper
INFO - 2016-02-22 12:06:17 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 15:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:06:17 --> Final output sent to browser
DEBUG - 2016-02-22 15:06:17 --> Total execution time: 1.0958
INFO - 2016-02-22 12:07:02 --> Config Class Initialized
INFO - 2016-02-22 12:07:02 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:07:02 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:07:02 --> Utf8 Class Initialized
INFO - 2016-02-22 12:07:02 --> URI Class Initialized
INFO - 2016-02-22 12:07:02 --> Router Class Initialized
INFO - 2016-02-22 12:07:02 --> Output Class Initialized
INFO - 2016-02-22 12:07:02 --> Security Class Initialized
DEBUG - 2016-02-22 12:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:07:02 --> Input Class Initialized
INFO - 2016-02-22 12:07:02 --> Language Class Initialized
INFO - 2016-02-22 12:07:02 --> Loader Class Initialized
INFO - 2016-02-22 12:07:02 --> Helper loaded: url_helper
INFO - 2016-02-22 12:07:02 --> Helper loaded: file_helper
INFO - 2016-02-22 12:07:02 --> Helper loaded: date_helper
INFO - 2016-02-22 12:07:02 --> Helper loaded: form_helper
INFO - 2016-02-22 12:07:02 --> Database Driver Class Initialized
INFO - 2016-02-22 12:07:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:07:03 --> Controller Class Initialized
INFO - 2016-02-22 12:07:03 --> Model Class Initialized
INFO - 2016-02-22 12:07:03 --> Model Class Initialized
INFO - 2016-02-22 12:07:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:07:03 --> Pagination Class Initialized
INFO - 2016-02-22 12:07:03 --> Helper loaded: text_helper
INFO - 2016-02-22 12:07:03 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 15:07:03 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 15:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:07:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:07:03 --> Form Validation Class Initialized
INFO - 2016-02-22 15:07:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 12:07:03 --> Config Class Initialized
INFO - 2016-02-22 12:07:03 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:07:03 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:07:03 --> Utf8 Class Initialized
INFO - 2016-02-22 12:07:03 --> URI Class Initialized
INFO - 2016-02-22 12:07:03 --> Router Class Initialized
INFO - 2016-02-22 12:07:03 --> Output Class Initialized
INFO - 2016-02-22 12:07:03 --> Security Class Initialized
DEBUG - 2016-02-22 12:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:07:03 --> Input Class Initialized
INFO - 2016-02-22 12:07:03 --> Language Class Initialized
INFO - 2016-02-22 12:07:03 --> Loader Class Initialized
INFO - 2016-02-22 12:07:03 --> Helper loaded: url_helper
INFO - 2016-02-22 12:07:03 --> Helper loaded: file_helper
INFO - 2016-02-22 12:07:03 --> Helper loaded: date_helper
INFO - 2016-02-22 12:07:03 --> Helper loaded: form_helper
INFO - 2016-02-22 12:07:03 --> Database Driver Class Initialized
INFO - 2016-02-22 12:07:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:07:04 --> Controller Class Initialized
INFO - 2016-02-22 12:07:04 --> Model Class Initialized
INFO - 2016-02-22 12:07:04 --> Model Class Initialized
INFO - 2016-02-22 12:07:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:07:04 --> Pagination Class Initialized
INFO - 2016-02-22 12:07:04 --> Helper loaded: text_helper
INFO - 2016-02-22 12:07:04 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:07:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:07:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:07:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:07:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:07:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:07:04 --> Final output sent to browser
DEBUG - 2016-02-22 15:07:04 --> Total execution time: 1.1178
INFO - 2016-02-22 12:07:13 --> Config Class Initialized
INFO - 2016-02-22 12:07:13 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:07:13 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:07:13 --> Utf8 Class Initialized
INFO - 2016-02-22 12:07:13 --> URI Class Initialized
INFO - 2016-02-22 12:07:13 --> Router Class Initialized
INFO - 2016-02-22 12:07:13 --> Output Class Initialized
INFO - 2016-02-22 12:07:13 --> Security Class Initialized
DEBUG - 2016-02-22 12:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:07:13 --> Input Class Initialized
INFO - 2016-02-22 12:07:13 --> Language Class Initialized
INFO - 2016-02-22 12:07:13 --> Loader Class Initialized
INFO - 2016-02-22 12:07:13 --> Helper loaded: url_helper
INFO - 2016-02-22 12:07:13 --> Helper loaded: file_helper
INFO - 2016-02-22 12:07:13 --> Helper loaded: date_helper
INFO - 2016-02-22 12:07:13 --> Helper loaded: form_helper
INFO - 2016-02-22 12:07:13 --> Database Driver Class Initialized
INFO - 2016-02-22 12:07:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:07:14 --> Controller Class Initialized
INFO - 2016-02-22 12:07:14 --> Model Class Initialized
INFO - 2016-02-22 12:07:14 --> Model Class Initialized
INFO - 2016-02-22 12:07:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:07:14 --> Pagination Class Initialized
INFO - 2016-02-22 12:07:14 --> Helper loaded: text_helper
INFO - 2016-02-22 12:07:14 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:07:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:07:14 --> Final output sent to browser
DEBUG - 2016-02-22 15:07:14 --> Total execution time: 1.1271
INFO - 2016-02-22 12:08:16 --> Config Class Initialized
INFO - 2016-02-22 12:08:16 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:08:16 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:08:16 --> Utf8 Class Initialized
INFO - 2016-02-22 12:08:16 --> URI Class Initialized
INFO - 2016-02-22 12:08:16 --> Router Class Initialized
INFO - 2016-02-22 12:08:16 --> Output Class Initialized
INFO - 2016-02-22 12:08:16 --> Security Class Initialized
DEBUG - 2016-02-22 12:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:08:16 --> Input Class Initialized
INFO - 2016-02-22 12:08:16 --> Language Class Initialized
INFO - 2016-02-22 12:08:16 --> Loader Class Initialized
INFO - 2016-02-22 12:08:16 --> Helper loaded: url_helper
INFO - 2016-02-22 12:08:16 --> Helper loaded: file_helper
INFO - 2016-02-22 12:08:16 --> Helper loaded: date_helper
INFO - 2016-02-22 12:08:16 --> Helper loaded: form_helper
INFO - 2016-02-22 12:08:16 --> Database Driver Class Initialized
INFO - 2016-02-22 12:08:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:08:18 --> Controller Class Initialized
INFO - 2016-02-22 12:08:18 --> Model Class Initialized
INFO - 2016-02-22 12:08:18 --> Model Class Initialized
INFO - 2016-02-22 12:08:18 --> Form Validation Class Initialized
INFO - 2016-02-22 12:08:18 --> Helper loaded: text_helper
INFO - 2016-02-22 12:08:18 --> Config Class Initialized
INFO - 2016-02-22 12:08:18 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:08:18 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:08:18 --> Utf8 Class Initialized
INFO - 2016-02-22 12:08:18 --> URI Class Initialized
DEBUG - 2016-02-22 12:08:18 --> No URI present. Default controller set.
INFO - 2016-02-22 12:08:18 --> Router Class Initialized
INFO - 2016-02-22 12:08:18 --> Output Class Initialized
INFO - 2016-02-22 12:08:18 --> Security Class Initialized
DEBUG - 2016-02-22 12:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:08:18 --> Input Class Initialized
INFO - 2016-02-22 12:08:18 --> Language Class Initialized
INFO - 2016-02-22 12:08:18 --> Loader Class Initialized
INFO - 2016-02-22 12:08:18 --> Helper loaded: url_helper
INFO - 2016-02-22 12:08:18 --> Helper loaded: file_helper
INFO - 2016-02-22 12:08:18 --> Helper loaded: date_helper
INFO - 2016-02-22 12:08:18 --> Helper loaded: form_helper
INFO - 2016-02-22 12:08:18 --> Database Driver Class Initialized
INFO - 2016-02-22 12:08:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:08:19 --> Controller Class Initialized
INFO - 2016-02-22 12:08:19 --> Model Class Initialized
INFO - 2016-02-22 12:08:19 --> Model Class Initialized
INFO - 2016-02-22 12:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:08:19 --> Pagination Class Initialized
INFO - 2016-02-22 12:08:19 --> Helper loaded: text_helper
INFO - 2016-02-22 12:08:19 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:08:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:08:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 15:08:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-22 15:08:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-22 12:08:22 --> Config Class Initialized
INFO - 2016-02-22 12:08:22 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:08:22 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:08:22 --> Utf8 Class Initialized
INFO - 2016-02-22 12:08:22 --> URI Class Initialized
INFO - 2016-02-22 12:08:22 --> Router Class Initialized
INFO - 2016-02-22 12:08:22 --> Output Class Initialized
INFO - 2016-02-22 12:08:22 --> Security Class Initialized
DEBUG - 2016-02-22 12:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:08:22 --> Input Class Initialized
INFO - 2016-02-22 12:08:22 --> Language Class Initialized
INFO - 2016-02-22 12:08:22 --> Loader Class Initialized
INFO - 2016-02-22 12:08:22 --> Helper loaded: url_helper
INFO - 2016-02-22 12:08:22 --> Helper loaded: file_helper
INFO - 2016-02-22 12:08:22 --> Helper loaded: date_helper
INFO - 2016-02-22 12:08:22 --> Helper loaded: form_helper
INFO - 2016-02-22 12:08:22 --> Database Driver Class Initialized
INFO - 2016-02-22 12:08:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:08:23 --> Controller Class Initialized
INFO - 2016-02-22 12:08:23 --> Model Class Initialized
INFO - 2016-02-22 12:08:23 --> Model Class Initialized
INFO - 2016-02-22 12:08:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:08:23 --> Pagination Class Initialized
INFO - 2016-02-22 12:08:23 --> Helper loaded: text_helper
INFO - 2016-02-22 12:08:23 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:08:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:08:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:08:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:08:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:08:23 --> Final output sent to browser
DEBUG - 2016-02-22 15:08:23 --> Total execution time: 1.1616
INFO - 2016-02-22 12:08:32 --> Config Class Initialized
INFO - 2016-02-22 12:08:32 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:08:32 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:08:32 --> Utf8 Class Initialized
INFO - 2016-02-22 12:08:32 --> URI Class Initialized
INFO - 2016-02-22 12:08:32 --> Router Class Initialized
INFO - 2016-02-22 12:08:32 --> Output Class Initialized
INFO - 2016-02-22 12:08:32 --> Security Class Initialized
DEBUG - 2016-02-22 12:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:08:32 --> Input Class Initialized
INFO - 2016-02-22 12:08:32 --> Language Class Initialized
INFO - 2016-02-22 12:08:32 --> Loader Class Initialized
INFO - 2016-02-22 12:08:32 --> Helper loaded: url_helper
INFO - 2016-02-22 12:08:32 --> Helper loaded: file_helper
INFO - 2016-02-22 12:08:32 --> Helper loaded: date_helper
INFO - 2016-02-22 12:08:32 --> Helper loaded: form_helper
INFO - 2016-02-22 12:08:32 --> Database Driver Class Initialized
INFO - 2016-02-22 12:08:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:08:33 --> Controller Class Initialized
INFO - 2016-02-22 12:08:34 --> Model Class Initialized
INFO - 2016-02-22 12:08:34 --> Model Class Initialized
INFO - 2016-02-22 12:08:34 --> Form Validation Class Initialized
INFO - 2016-02-22 12:08:34 --> Helper loaded: text_helper
INFO - 2016-02-22 12:08:34 --> Config Class Initialized
INFO - 2016-02-22 12:08:34 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:08:34 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:08:34 --> Utf8 Class Initialized
INFO - 2016-02-22 12:08:34 --> URI Class Initialized
INFO - 2016-02-22 12:08:34 --> Router Class Initialized
INFO - 2016-02-22 12:08:34 --> Output Class Initialized
INFO - 2016-02-22 12:08:34 --> Security Class Initialized
DEBUG - 2016-02-22 12:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:08:34 --> Input Class Initialized
INFO - 2016-02-22 12:08:34 --> Language Class Initialized
INFO - 2016-02-22 12:08:34 --> Loader Class Initialized
INFO - 2016-02-22 12:08:34 --> Helper loaded: url_helper
INFO - 2016-02-22 12:08:34 --> Helper loaded: file_helper
INFO - 2016-02-22 12:08:34 --> Helper loaded: date_helper
INFO - 2016-02-22 12:08:34 --> Helper loaded: form_helper
INFO - 2016-02-22 12:08:34 --> Database Driver Class Initialized
INFO - 2016-02-22 12:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:08:35 --> Controller Class Initialized
INFO - 2016-02-22 12:08:35 --> Model Class Initialized
INFO - 2016-02-22 12:08:35 --> Model Class Initialized
INFO - 2016-02-22 12:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:08:35 --> Pagination Class Initialized
INFO - 2016-02-22 12:08:35 --> Helper loaded: text_helper
INFO - 2016-02-22 12:08:35 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:08:35 --> Final output sent to browser
DEBUG - 2016-02-22 15:08:35 --> Total execution time: 1.2037
INFO - 2016-02-22 12:08:39 --> Config Class Initialized
INFO - 2016-02-22 12:08:39 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:08:39 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:08:39 --> Utf8 Class Initialized
INFO - 2016-02-22 12:08:39 --> URI Class Initialized
INFO - 2016-02-22 12:08:39 --> Router Class Initialized
INFO - 2016-02-22 12:08:39 --> Output Class Initialized
INFO - 2016-02-22 12:08:39 --> Security Class Initialized
DEBUG - 2016-02-22 12:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:08:39 --> Input Class Initialized
INFO - 2016-02-22 12:08:39 --> Language Class Initialized
INFO - 2016-02-22 12:08:39 --> Loader Class Initialized
INFO - 2016-02-22 12:08:39 --> Helper loaded: url_helper
INFO - 2016-02-22 12:08:39 --> Helper loaded: file_helper
INFO - 2016-02-22 12:08:39 --> Helper loaded: date_helper
INFO - 2016-02-22 12:08:39 --> Helper loaded: form_helper
INFO - 2016-02-22 12:08:39 --> Database Driver Class Initialized
INFO - 2016-02-22 12:08:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:08:40 --> Controller Class Initialized
INFO - 2016-02-22 12:08:40 --> Model Class Initialized
INFO - 2016-02-22 12:08:40 --> Model Class Initialized
INFO - 2016-02-22 12:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:08:40 --> Pagination Class Initialized
INFO - 2016-02-22 12:08:40 --> Helper loaded: text_helper
INFO - 2016-02-22 12:08:40 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 15:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:08:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:08:40 --> Final output sent to browser
DEBUG - 2016-02-22 15:08:40 --> Total execution time: 1.1652
INFO - 2016-02-22 12:09:11 --> Config Class Initialized
INFO - 2016-02-22 12:09:11 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:09:11 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:09:11 --> Utf8 Class Initialized
INFO - 2016-02-22 12:09:11 --> URI Class Initialized
INFO - 2016-02-22 12:09:11 --> Router Class Initialized
INFO - 2016-02-22 12:09:11 --> Output Class Initialized
INFO - 2016-02-22 12:09:11 --> Security Class Initialized
DEBUG - 2016-02-22 12:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:09:11 --> Input Class Initialized
INFO - 2016-02-22 12:09:11 --> Language Class Initialized
INFO - 2016-02-22 12:09:11 --> Loader Class Initialized
INFO - 2016-02-22 12:09:11 --> Helper loaded: url_helper
INFO - 2016-02-22 12:09:11 --> Helper loaded: file_helper
INFO - 2016-02-22 12:09:11 --> Helper loaded: date_helper
INFO - 2016-02-22 12:09:11 --> Helper loaded: form_helper
INFO - 2016-02-22 12:09:11 --> Database Driver Class Initialized
INFO - 2016-02-22 12:09:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:09:12 --> Controller Class Initialized
INFO - 2016-02-22 12:09:12 --> Model Class Initialized
INFO - 2016-02-22 12:09:12 --> Model Class Initialized
INFO - 2016-02-22 12:09:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:09:12 --> Pagination Class Initialized
INFO - 2016-02-22 12:09:12 --> Helper loaded: text_helper
INFO - 2016-02-22 12:09:12 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 15:09:12 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 15:09:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:09:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:09:12 --> Form Validation Class Initialized
INFO - 2016-02-22 15:09:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 12:09:12 --> Config Class Initialized
INFO - 2016-02-22 12:09:12 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:09:12 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:09:12 --> Utf8 Class Initialized
INFO - 2016-02-22 12:09:12 --> URI Class Initialized
INFO - 2016-02-22 12:09:12 --> Router Class Initialized
INFO - 2016-02-22 12:09:12 --> Output Class Initialized
INFO - 2016-02-22 12:09:12 --> Security Class Initialized
DEBUG - 2016-02-22 12:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:09:12 --> Input Class Initialized
INFO - 2016-02-22 12:09:12 --> Language Class Initialized
INFO - 2016-02-22 12:09:12 --> Loader Class Initialized
INFO - 2016-02-22 12:09:12 --> Helper loaded: url_helper
INFO - 2016-02-22 12:09:12 --> Helper loaded: file_helper
INFO - 2016-02-22 12:09:12 --> Helper loaded: date_helper
INFO - 2016-02-22 12:09:12 --> Helper loaded: form_helper
INFO - 2016-02-22 12:09:12 --> Database Driver Class Initialized
INFO - 2016-02-22 12:09:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:09:13 --> Controller Class Initialized
INFO - 2016-02-22 12:09:13 --> Model Class Initialized
INFO - 2016-02-22 12:09:13 --> Model Class Initialized
INFO - 2016-02-22 12:09:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:09:13 --> Pagination Class Initialized
INFO - 2016-02-22 12:09:13 --> Helper loaded: text_helper
INFO - 2016-02-22 12:09:13 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:09:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:09:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:09:14 --> Final output sent to browser
DEBUG - 2016-02-22 15:09:14 --> Total execution time: 1.2041
INFO - 2016-02-22 12:09:18 --> Config Class Initialized
INFO - 2016-02-22 12:09:18 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:09:18 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:09:18 --> Utf8 Class Initialized
INFO - 2016-02-22 12:09:18 --> URI Class Initialized
INFO - 2016-02-22 12:09:18 --> Router Class Initialized
INFO - 2016-02-22 12:09:18 --> Output Class Initialized
INFO - 2016-02-22 12:09:18 --> Security Class Initialized
DEBUG - 2016-02-22 12:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:09:18 --> Input Class Initialized
INFO - 2016-02-22 12:09:18 --> Language Class Initialized
INFO - 2016-02-22 12:09:18 --> Loader Class Initialized
INFO - 2016-02-22 12:09:18 --> Helper loaded: url_helper
INFO - 2016-02-22 12:09:18 --> Helper loaded: file_helper
INFO - 2016-02-22 12:09:18 --> Helper loaded: date_helper
INFO - 2016-02-22 12:09:18 --> Helper loaded: form_helper
INFO - 2016-02-22 12:09:18 --> Database Driver Class Initialized
INFO - 2016-02-22 12:09:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:09:19 --> Controller Class Initialized
INFO - 2016-02-22 12:09:19 --> Model Class Initialized
INFO - 2016-02-22 12:09:19 --> Model Class Initialized
INFO - 2016-02-22 12:09:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:09:19 --> Pagination Class Initialized
INFO - 2016-02-22 12:09:19 --> Helper loaded: text_helper
INFO - 2016-02-22 12:09:19 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:09:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:09:19 --> Final output sent to browser
DEBUG - 2016-02-22 15:09:19 --> Total execution time: 1.1234
INFO - 2016-02-22 12:09:25 --> Config Class Initialized
INFO - 2016-02-22 12:09:25 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:09:25 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:09:25 --> Utf8 Class Initialized
INFO - 2016-02-22 12:09:25 --> URI Class Initialized
INFO - 2016-02-22 12:09:25 --> Router Class Initialized
INFO - 2016-02-22 12:09:25 --> Output Class Initialized
INFO - 2016-02-22 12:09:25 --> Security Class Initialized
DEBUG - 2016-02-22 12:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:09:25 --> Input Class Initialized
INFO - 2016-02-22 12:09:25 --> Language Class Initialized
INFO - 2016-02-22 12:09:25 --> Loader Class Initialized
INFO - 2016-02-22 12:09:25 --> Helper loaded: url_helper
INFO - 2016-02-22 12:09:25 --> Helper loaded: file_helper
INFO - 2016-02-22 12:09:25 --> Helper loaded: date_helper
INFO - 2016-02-22 12:09:25 --> Helper loaded: form_helper
INFO - 2016-02-22 12:09:25 --> Database Driver Class Initialized
INFO - 2016-02-22 12:09:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:09:26 --> Controller Class Initialized
INFO - 2016-02-22 12:09:26 --> Model Class Initialized
INFO - 2016-02-22 12:09:26 --> Model Class Initialized
INFO - 2016-02-22 12:09:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:09:26 --> Pagination Class Initialized
INFO - 2016-02-22 12:09:26 --> Helper loaded: text_helper
INFO - 2016-02-22 12:09:26 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:09:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:09:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:09:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:09:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:09:26 --> Final output sent to browser
DEBUG - 2016-02-22 15:09:26 --> Total execution time: 1.1453
INFO - 2016-02-22 12:09:58 --> Config Class Initialized
INFO - 2016-02-22 12:09:58 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:09:58 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:09:58 --> Utf8 Class Initialized
INFO - 2016-02-22 12:09:58 --> URI Class Initialized
INFO - 2016-02-22 12:09:58 --> Router Class Initialized
INFO - 2016-02-22 12:09:58 --> Output Class Initialized
INFO - 2016-02-22 12:09:58 --> Security Class Initialized
DEBUG - 2016-02-22 12:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:09:58 --> Input Class Initialized
INFO - 2016-02-22 12:09:58 --> Language Class Initialized
INFO - 2016-02-22 12:09:58 --> Loader Class Initialized
INFO - 2016-02-22 12:09:58 --> Helper loaded: url_helper
INFO - 2016-02-22 12:09:58 --> Helper loaded: file_helper
INFO - 2016-02-22 12:09:58 --> Helper loaded: date_helper
INFO - 2016-02-22 12:09:58 --> Helper loaded: form_helper
INFO - 2016-02-22 12:09:58 --> Database Driver Class Initialized
INFO - 2016-02-22 12:09:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:09:59 --> Controller Class Initialized
INFO - 2016-02-22 12:09:59 --> Model Class Initialized
INFO - 2016-02-22 12:09:59 --> Model Class Initialized
INFO - 2016-02-22 12:09:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:09:59 --> Pagination Class Initialized
INFO - 2016-02-22 12:09:59 --> Helper loaded: text_helper
INFO - 2016-02-22 12:09:59 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:09:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:09:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:09:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:09:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:09:59 --> Final output sent to browser
DEBUG - 2016-02-22 15:09:59 --> Total execution time: 1.0884
INFO - 2016-02-22 12:10:01 --> Config Class Initialized
INFO - 2016-02-22 12:10:01 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:10:01 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:10:01 --> Utf8 Class Initialized
INFO - 2016-02-22 12:10:01 --> URI Class Initialized
INFO - 2016-02-22 12:10:01 --> Router Class Initialized
INFO - 2016-02-22 12:10:01 --> Output Class Initialized
INFO - 2016-02-22 12:10:01 --> Security Class Initialized
DEBUG - 2016-02-22 12:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:10:01 --> Input Class Initialized
INFO - 2016-02-22 12:10:01 --> Language Class Initialized
INFO - 2016-02-22 12:10:01 --> Loader Class Initialized
INFO - 2016-02-22 12:10:01 --> Helper loaded: url_helper
INFO - 2016-02-22 12:10:01 --> Helper loaded: file_helper
INFO - 2016-02-22 12:10:01 --> Helper loaded: date_helper
INFO - 2016-02-22 12:10:01 --> Helper loaded: form_helper
INFO - 2016-02-22 12:10:01 --> Database Driver Class Initialized
INFO - 2016-02-22 12:10:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:10:02 --> Controller Class Initialized
INFO - 2016-02-22 12:10:02 --> Model Class Initialized
INFO - 2016-02-22 12:10:02 --> Model Class Initialized
INFO - 2016-02-22 12:10:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:10:02 --> Pagination Class Initialized
INFO - 2016-02-22 12:10:02 --> Helper loaded: text_helper
INFO - 2016-02-22 12:10:02 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:10:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:10:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:10:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:10:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:10:02 --> Final output sent to browser
DEBUG - 2016-02-22 15:10:02 --> Total execution time: 1.1382
INFO - 2016-02-22 12:10:21 --> Config Class Initialized
INFO - 2016-02-22 12:10:21 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:10:21 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:10:21 --> Utf8 Class Initialized
INFO - 2016-02-22 12:10:21 --> URI Class Initialized
INFO - 2016-02-22 12:10:21 --> Router Class Initialized
INFO - 2016-02-22 12:10:21 --> Output Class Initialized
INFO - 2016-02-22 12:10:21 --> Security Class Initialized
DEBUG - 2016-02-22 12:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:10:21 --> Input Class Initialized
INFO - 2016-02-22 12:10:21 --> Language Class Initialized
INFO - 2016-02-22 12:10:21 --> Loader Class Initialized
INFO - 2016-02-22 12:10:21 --> Helper loaded: url_helper
INFO - 2016-02-22 12:10:21 --> Helper loaded: file_helper
INFO - 2016-02-22 12:10:21 --> Helper loaded: date_helper
INFO - 2016-02-22 12:10:21 --> Helper loaded: form_helper
INFO - 2016-02-22 12:10:21 --> Database Driver Class Initialized
INFO - 2016-02-22 12:10:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:10:22 --> Controller Class Initialized
INFO - 2016-02-22 12:10:22 --> Model Class Initialized
INFO - 2016-02-22 12:10:22 --> Model Class Initialized
INFO - 2016-02-22 12:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:10:22 --> Pagination Class Initialized
INFO - 2016-02-22 12:10:22 --> Helper loaded: text_helper
INFO - 2016-02-22 12:10:22 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:10:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:10:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:10:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-22 15:10:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:10:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:10:22 --> Final output sent to browser
DEBUG - 2016-02-22 15:10:22 --> Total execution time: 1.1308
INFO - 2016-02-22 12:10:48 --> Config Class Initialized
INFO - 2016-02-22 12:10:48 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:10:48 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:10:48 --> Utf8 Class Initialized
INFO - 2016-02-22 12:10:48 --> URI Class Initialized
INFO - 2016-02-22 12:10:48 --> Router Class Initialized
INFO - 2016-02-22 12:10:48 --> Output Class Initialized
INFO - 2016-02-22 12:10:48 --> Security Class Initialized
DEBUG - 2016-02-22 12:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:10:48 --> Input Class Initialized
INFO - 2016-02-22 12:10:48 --> Language Class Initialized
INFO - 2016-02-22 12:10:48 --> Loader Class Initialized
INFO - 2016-02-22 12:10:48 --> Helper loaded: url_helper
INFO - 2016-02-22 12:10:48 --> Helper loaded: file_helper
INFO - 2016-02-22 12:10:48 --> Helper loaded: date_helper
INFO - 2016-02-22 12:10:48 --> Helper loaded: form_helper
INFO - 2016-02-22 12:10:48 --> Database Driver Class Initialized
INFO - 2016-02-22 12:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:10:49 --> Controller Class Initialized
INFO - 2016-02-22 12:10:49 --> Model Class Initialized
INFO - 2016-02-22 12:10:49 --> Model Class Initialized
INFO - 2016-02-22 12:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:10:49 --> Pagination Class Initialized
INFO - 2016-02-22 12:10:49 --> Helper loaded: text_helper
INFO - 2016-02-22 12:10:49 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 15:10:49 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 163
INFO - 2016-02-22 15:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:10:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:10:49 --> Form Validation Class Initialized
INFO - 2016-02-22 15:10:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-22 12:10:49 --> Config Class Initialized
INFO - 2016-02-22 12:10:49 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:10:49 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:10:49 --> Utf8 Class Initialized
INFO - 2016-02-22 12:10:49 --> URI Class Initialized
INFO - 2016-02-22 12:10:49 --> Router Class Initialized
INFO - 2016-02-22 12:10:49 --> Output Class Initialized
INFO - 2016-02-22 12:10:49 --> Security Class Initialized
DEBUG - 2016-02-22 12:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:10:49 --> Input Class Initialized
INFO - 2016-02-22 12:10:49 --> Language Class Initialized
INFO - 2016-02-22 12:10:49 --> Loader Class Initialized
INFO - 2016-02-22 12:10:49 --> Helper loaded: url_helper
INFO - 2016-02-22 12:10:49 --> Helper loaded: file_helper
INFO - 2016-02-22 12:10:49 --> Helper loaded: date_helper
INFO - 2016-02-22 12:10:49 --> Helper loaded: form_helper
INFO - 2016-02-22 12:10:49 --> Database Driver Class Initialized
INFO - 2016-02-22 12:10:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:10:50 --> Controller Class Initialized
INFO - 2016-02-22 12:10:50 --> Model Class Initialized
INFO - 2016-02-22 12:10:50 --> Model Class Initialized
INFO - 2016-02-22 12:10:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:10:50 --> Pagination Class Initialized
INFO - 2016-02-22 12:10:50 --> Helper loaded: text_helper
INFO - 2016-02-22 12:10:50 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:10:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:10:50 --> Final output sent to browser
DEBUG - 2016-02-22 15:10:50 --> Total execution time: 1.1732
INFO - 2016-02-22 12:10:56 --> Config Class Initialized
INFO - 2016-02-22 12:10:56 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:10:56 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:10:56 --> Utf8 Class Initialized
INFO - 2016-02-22 12:10:56 --> URI Class Initialized
INFO - 2016-02-22 12:10:56 --> Router Class Initialized
INFO - 2016-02-22 12:10:56 --> Output Class Initialized
INFO - 2016-02-22 12:10:56 --> Security Class Initialized
DEBUG - 2016-02-22 12:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:10:56 --> Input Class Initialized
INFO - 2016-02-22 12:10:56 --> Language Class Initialized
INFO - 2016-02-22 12:10:56 --> Loader Class Initialized
INFO - 2016-02-22 12:10:56 --> Helper loaded: url_helper
INFO - 2016-02-22 12:10:56 --> Helper loaded: file_helper
INFO - 2016-02-22 12:10:56 --> Helper loaded: date_helper
INFO - 2016-02-22 12:10:56 --> Helper loaded: form_helper
INFO - 2016-02-22 12:10:56 --> Database Driver Class Initialized
INFO - 2016-02-22 12:10:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:10:57 --> Controller Class Initialized
INFO - 2016-02-22 12:10:57 --> Model Class Initialized
INFO - 2016-02-22 12:10:57 --> Model Class Initialized
INFO - 2016-02-22 12:10:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:10:57 --> Pagination Class Initialized
INFO - 2016-02-22 12:10:57 --> Helper loaded: text_helper
INFO - 2016-02-22 12:10:57 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:10:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:10:57 --> Final output sent to browser
DEBUG - 2016-02-22 15:10:57 --> Total execution time: 1.1132
INFO - 2016-02-22 12:11:08 --> Config Class Initialized
INFO - 2016-02-22 12:11:08 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:11:08 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:11:08 --> Utf8 Class Initialized
INFO - 2016-02-22 12:11:08 --> URI Class Initialized
INFO - 2016-02-22 12:11:08 --> Router Class Initialized
INFO - 2016-02-22 12:11:08 --> Output Class Initialized
INFO - 2016-02-22 12:11:08 --> Security Class Initialized
DEBUG - 2016-02-22 12:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:11:08 --> Input Class Initialized
INFO - 2016-02-22 12:11:08 --> Language Class Initialized
INFO - 2016-02-22 12:11:08 --> Loader Class Initialized
INFO - 2016-02-22 12:11:08 --> Helper loaded: url_helper
INFO - 2016-02-22 12:11:08 --> Helper loaded: file_helper
INFO - 2016-02-22 12:11:08 --> Helper loaded: date_helper
INFO - 2016-02-22 12:11:08 --> Helper loaded: form_helper
INFO - 2016-02-22 12:11:08 --> Database Driver Class Initialized
INFO - 2016-02-22 12:11:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:11:09 --> Controller Class Initialized
INFO - 2016-02-22 12:11:09 --> Model Class Initialized
INFO - 2016-02-22 12:11:09 --> Model Class Initialized
INFO - 2016-02-22 12:11:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:11:09 --> Pagination Class Initialized
INFO - 2016-02-22 12:11:09 --> Helper loaded: text_helper
INFO - 2016-02-22 12:11:09 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:11:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:11:09 --> Final output sent to browser
DEBUG - 2016-02-22 15:11:09 --> Total execution time: 1.1430
INFO - 2016-02-22 12:14:29 --> Config Class Initialized
INFO - 2016-02-22 12:14:29 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:14:29 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:14:29 --> Utf8 Class Initialized
INFO - 2016-02-22 12:14:29 --> URI Class Initialized
INFO - 2016-02-22 12:14:29 --> Router Class Initialized
INFO - 2016-02-22 12:14:29 --> Output Class Initialized
INFO - 2016-02-22 12:14:29 --> Security Class Initialized
DEBUG - 2016-02-22 12:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:14:30 --> Input Class Initialized
INFO - 2016-02-22 12:14:30 --> Language Class Initialized
INFO - 2016-02-22 12:14:30 --> Loader Class Initialized
INFO - 2016-02-22 12:14:30 --> Helper loaded: url_helper
INFO - 2016-02-22 12:14:30 --> Helper loaded: file_helper
INFO - 2016-02-22 12:14:30 --> Helper loaded: date_helper
INFO - 2016-02-22 12:14:30 --> Helper loaded: form_helper
INFO - 2016-02-22 12:14:30 --> Database Driver Class Initialized
INFO - 2016-02-22 12:14:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:14:31 --> Controller Class Initialized
INFO - 2016-02-22 12:14:31 --> Model Class Initialized
INFO - 2016-02-22 12:14:31 --> Model Class Initialized
INFO - 2016-02-22 12:14:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:14:31 --> Pagination Class Initialized
INFO - 2016-02-22 12:14:31 --> Helper loaded: text_helper
INFO - 2016-02-22 12:14:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:14:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:14:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:14:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:14:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:14:31 --> Final output sent to browser
DEBUG - 2016-02-22 15:14:31 --> Total execution time: 1.1705
INFO - 2016-02-22 12:14:33 --> Config Class Initialized
INFO - 2016-02-22 12:14:33 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:14:33 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:14:33 --> Utf8 Class Initialized
INFO - 2016-02-22 12:14:33 --> URI Class Initialized
INFO - 2016-02-22 12:14:33 --> Router Class Initialized
INFO - 2016-02-22 12:14:33 --> Output Class Initialized
INFO - 2016-02-22 12:14:33 --> Security Class Initialized
DEBUG - 2016-02-22 12:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:14:33 --> Input Class Initialized
INFO - 2016-02-22 12:14:33 --> Language Class Initialized
INFO - 2016-02-22 12:14:33 --> Loader Class Initialized
INFO - 2016-02-22 12:14:33 --> Helper loaded: url_helper
INFO - 2016-02-22 12:14:33 --> Helper loaded: file_helper
INFO - 2016-02-22 12:14:33 --> Helper loaded: date_helper
INFO - 2016-02-22 12:14:33 --> Helper loaded: form_helper
INFO - 2016-02-22 12:14:33 --> Database Driver Class Initialized
INFO - 2016-02-22 12:14:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:14:34 --> Controller Class Initialized
INFO - 2016-02-22 12:14:34 --> Model Class Initialized
INFO - 2016-02-22 12:14:34 --> Model Class Initialized
INFO - 2016-02-22 12:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:14:34 --> Pagination Class Initialized
INFO - 2016-02-22 12:14:34 --> Helper loaded: text_helper
INFO - 2016-02-22 12:14:34 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:14:34 --> Final output sent to browser
DEBUG - 2016-02-22 15:14:34 --> Total execution time: 1.1642
INFO - 2016-02-22 12:15:57 --> Config Class Initialized
INFO - 2016-02-22 12:15:57 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:15:57 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:15:57 --> Utf8 Class Initialized
INFO - 2016-02-22 12:15:57 --> URI Class Initialized
INFO - 2016-02-22 12:15:57 --> Router Class Initialized
INFO - 2016-02-22 12:15:57 --> Output Class Initialized
INFO - 2016-02-22 12:15:57 --> Security Class Initialized
DEBUG - 2016-02-22 12:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:15:57 --> Input Class Initialized
INFO - 2016-02-22 12:15:57 --> Language Class Initialized
INFO - 2016-02-22 12:15:57 --> Loader Class Initialized
INFO - 2016-02-22 12:15:57 --> Helper loaded: url_helper
INFO - 2016-02-22 12:15:57 --> Helper loaded: file_helper
INFO - 2016-02-22 12:15:57 --> Helper loaded: date_helper
INFO - 2016-02-22 12:15:57 --> Helper loaded: form_helper
INFO - 2016-02-22 12:15:57 --> Database Driver Class Initialized
INFO - 2016-02-22 12:15:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:15:58 --> Controller Class Initialized
INFO - 2016-02-22 12:15:58 --> Model Class Initialized
INFO - 2016-02-22 12:15:58 --> Model Class Initialized
INFO - 2016-02-22 12:15:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:15:58 --> Pagination Class Initialized
INFO - 2016-02-22 12:15:58 --> Helper loaded: text_helper
INFO - 2016-02-22 12:15:58 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:15:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:15:58 --> Final output sent to browser
DEBUG - 2016-02-22 15:15:58 --> Total execution time: 1.1490
INFO - 2016-02-22 12:16:18 --> Config Class Initialized
INFO - 2016-02-22 12:16:18 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:16:18 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:16:18 --> Utf8 Class Initialized
INFO - 2016-02-22 12:16:18 --> URI Class Initialized
INFO - 2016-02-22 12:16:18 --> Router Class Initialized
INFO - 2016-02-22 12:16:18 --> Output Class Initialized
INFO - 2016-02-22 12:16:18 --> Security Class Initialized
DEBUG - 2016-02-22 12:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:16:18 --> Input Class Initialized
INFO - 2016-02-22 12:16:18 --> Language Class Initialized
INFO - 2016-02-22 12:16:18 --> Loader Class Initialized
INFO - 2016-02-22 12:16:18 --> Helper loaded: url_helper
INFO - 2016-02-22 12:16:18 --> Helper loaded: file_helper
INFO - 2016-02-22 12:16:18 --> Helper loaded: date_helper
INFO - 2016-02-22 12:16:18 --> Helper loaded: form_helper
INFO - 2016-02-22 12:16:18 --> Database Driver Class Initialized
INFO - 2016-02-22 12:16:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:16:19 --> Controller Class Initialized
INFO - 2016-02-22 12:16:19 --> Model Class Initialized
INFO - 2016-02-22 12:16:19 --> Model Class Initialized
INFO - 2016-02-22 12:16:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:16:19 --> Pagination Class Initialized
INFO - 2016-02-22 12:16:19 --> Helper loaded: text_helper
INFO - 2016-02-22 12:16:19 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:16:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:16:19 --> Final output sent to browser
DEBUG - 2016-02-22 15:16:19 --> Total execution time: 1.1683
INFO - 2016-02-22 12:16:21 --> Config Class Initialized
INFO - 2016-02-22 12:16:21 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:16:21 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:16:21 --> Utf8 Class Initialized
INFO - 2016-02-22 12:16:21 --> URI Class Initialized
INFO - 2016-02-22 12:16:21 --> Router Class Initialized
INFO - 2016-02-22 12:16:21 --> Output Class Initialized
INFO - 2016-02-22 12:16:21 --> Security Class Initialized
DEBUG - 2016-02-22 12:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:16:21 --> Input Class Initialized
INFO - 2016-02-22 12:16:21 --> Language Class Initialized
INFO - 2016-02-22 12:16:21 --> Loader Class Initialized
INFO - 2016-02-22 12:16:21 --> Helper loaded: url_helper
INFO - 2016-02-22 12:16:21 --> Helper loaded: file_helper
INFO - 2016-02-22 12:16:21 --> Helper loaded: date_helper
INFO - 2016-02-22 12:16:21 --> Helper loaded: form_helper
INFO - 2016-02-22 12:16:21 --> Database Driver Class Initialized
INFO - 2016-02-22 12:16:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:16:22 --> Controller Class Initialized
INFO - 2016-02-22 12:16:22 --> Model Class Initialized
INFO - 2016-02-22 12:16:22 --> Model Class Initialized
INFO - 2016-02-22 12:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:16:22 --> Pagination Class Initialized
INFO - 2016-02-22 12:16:22 --> Helper loaded: text_helper
INFO - 2016-02-22 12:16:22 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:16:22 --> Final output sent to browser
DEBUG - 2016-02-22 15:16:22 --> Total execution time: 1.1366
INFO - 2016-02-22 12:16:25 --> Config Class Initialized
INFO - 2016-02-22 12:16:25 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:16:25 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:16:25 --> Utf8 Class Initialized
INFO - 2016-02-22 12:16:25 --> URI Class Initialized
INFO - 2016-02-22 12:16:25 --> Router Class Initialized
INFO - 2016-02-22 12:16:25 --> Output Class Initialized
INFO - 2016-02-22 12:16:25 --> Security Class Initialized
DEBUG - 2016-02-22 12:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:16:25 --> Input Class Initialized
INFO - 2016-02-22 12:16:25 --> Language Class Initialized
INFO - 2016-02-22 12:16:25 --> Loader Class Initialized
INFO - 2016-02-22 12:16:25 --> Helper loaded: url_helper
INFO - 2016-02-22 12:16:25 --> Helper loaded: file_helper
INFO - 2016-02-22 12:16:25 --> Helper loaded: date_helper
INFO - 2016-02-22 12:16:25 --> Helper loaded: form_helper
INFO - 2016-02-22 12:16:25 --> Database Driver Class Initialized
INFO - 2016-02-22 12:16:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:16:26 --> Controller Class Initialized
INFO - 2016-02-22 12:16:26 --> Model Class Initialized
INFO - 2016-02-22 12:16:26 --> Model Class Initialized
INFO - 2016-02-22 12:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:16:26 --> Pagination Class Initialized
INFO - 2016-02-22 12:16:26 --> Helper loaded: text_helper
INFO - 2016-02-22 12:16:26 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:16:26 --> Final output sent to browser
DEBUG - 2016-02-22 15:16:26 --> Total execution time: 1.1373
INFO - 2016-02-22 12:17:17 --> Config Class Initialized
INFO - 2016-02-22 12:17:17 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:17:17 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:17:17 --> Utf8 Class Initialized
INFO - 2016-02-22 12:17:17 --> URI Class Initialized
INFO - 2016-02-22 12:17:17 --> Router Class Initialized
INFO - 2016-02-22 12:17:17 --> Output Class Initialized
INFO - 2016-02-22 12:17:17 --> Security Class Initialized
DEBUG - 2016-02-22 12:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:17:17 --> Input Class Initialized
INFO - 2016-02-22 12:17:17 --> Language Class Initialized
INFO - 2016-02-22 12:17:17 --> Loader Class Initialized
INFO - 2016-02-22 12:17:17 --> Helper loaded: url_helper
INFO - 2016-02-22 12:17:17 --> Helper loaded: file_helper
INFO - 2016-02-22 12:17:17 --> Helper loaded: date_helper
INFO - 2016-02-22 12:17:17 --> Helper loaded: form_helper
INFO - 2016-02-22 12:17:17 --> Database Driver Class Initialized
INFO - 2016-02-22 12:17:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:17:18 --> Controller Class Initialized
INFO - 2016-02-22 12:17:18 --> Model Class Initialized
INFO - 2016-02-22 12:17:18 --> Model Class Initialized
INFO - 2016-02-22 12:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:17:18 --> Pagination Class Initialized
INFO - 2016-02-22 12:17:18 --> Helper loaded: text_helper
INFO - 2016-02-22 12:17:18 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:17:18 --> Final output sent to browser
DEBUG - 2016-02-22 15:17:18 --> Total execution time: 1.1656
INFO - 2016-02-22 12:17:24 --> Config Class Initialized
INFO - 2016-02-22 12:17:24 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:17:24 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:17:24 --> Utf8 Class Initialized
INFO - 2016-02-22 12:17:24 --> URI Class Initialized
INFO - 2016-02-22 12:17:24 --> Router Class Initialized
INFO - 2016-02-22 12:17:24 --> Output Class Initialized
INFO - 2016-02-22 12:17:24 --> Security Class Initialized
DEBUG - 2016-02-22 12:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:17:24 --> Input Class Initialized
INFO - 2016-02-22 12:17:24 --> Language Class Initialized
INFO - 2016-02-22 12:17:24 --> Loader Class Initialized
INFO - 2016-02-22 12:17:24 --> Helper loaded: url_helper
INFO - 2016-02-22 12:17:24 --> Helper loaded: file_helper
INFO - 2016-02-22 12:17:24 --> Helper loaded: date_helper
INFO - 2016-02-22 12:17:24 --> Helper loaded: form_helper
INFO - 2016-02-22 12:17:24 --> Database Driver Class Initialized
INFO - 2016-02-22 12:17:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:17:25 --> Controller Class Initialized
INFO - 2016-02-22 12:17:25 --> Model Class Initialized
INFO - 2016-02-22 12:17:25 --> Model Class Initialized
INFO - 2016-02-22 12:17:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:17:25 --> Pagination Class Initialized
INFO - 2016-02-22 12:17:25 --> Helper loaded: text_helper
INFO - 2016-02-22 12:17:25 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:17:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:17:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:17:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:17:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:17:25 --> Final output sent to browser
DEBUG - 2016-02-22 15:17:25 --> Total execution time: 1.1517
INFO - 2016-02-22 12:17:31 --> Config Class Initialized
INFO - 2016-02-22 12:17:31 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:17:31 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:17:31 --> Utf8 Class Initialized
INFO - 2016-02-22 12:17:31 --> URI Class Initialized
INFO - 2016-02-22 12:17:31 --> Router Class Initialized
INFO - 2016-02-22 12:17:31 --> Output Class Initialized
INFO - 2016-02-22 12:17:31 --> Security Class Initialized
DEBUG - 2016-02-22 12:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:17:31 --> Input Class Initialized
INFO - 2016-02-22 12:17:31 --> Language Class Initialized
INFO - 2016-02-22 12:17:31 --> Loader Class Initialized
INFO - 2016-02-22 12:17:31 --> Helper loaded: url_helper
INFO - 2016-02-22 12:17:31 --> Helper loaded: file_helper
INFO - 2016-02-22 12:17:31 --> Helper loaded: date_helper
INFO - 2016-02-22 12:17:31 --> Helper loaded: form_helper
INFO - 2016-02-22 12:17:31 --> Database Driver Class Initialized
INFO - 2016-02-22 12:17:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:17:32 --> Controller Class Initialized
INFO - 2016-02-22 12:17:32 --> Model Class Initialized
INFO - 2016-02-22 12:17:32 --> Model Class Initialized
INFO - 2016-02-22 12:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:17:32 --> Pagination Class Initialized
INFO - 2016-02-22 12:17:32 --> Helper loaded: text_helper
INFO - 2016-02-22 12:17:32 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:17:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:17:32 --> Final output sent to browser
DEBUG - 2016-02-22 15:17:32 --> Total execution time: 1.1343
INFO - 2016-02-22 12:18:22 --> Config Class Initialized
INFO - 2016-02-22 12:18:22 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:18:22 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:18:22 --> Utf8 Class Initialized
INFO - 2016-02-22 12:18:22 --> URI Class Initialized
INFO - 2016-02-22 12:18:22 --> Router Class Initialized
INFO - 2016-02-22 12:18:22 --> Output Class Initialized
INFO - 2016-02-22 12:18:22 --> Security Class Initialized
DEBUG - 2016-02-22 12:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:18:22 --> Input Class Initialized
INFO - 2016-02-22 12:18:22 --> Language Class Initialized
INFO - 2016-02-22 12:18:22 --> Loader Class Initialized
INFO - 2016-02-22 12:18:22 --> Helper loaded: url_helper
INFO - 2016-02-22 12:18:22 --> Helper loaded: file_helper
INFO - 2016-02-22 12:18:22 --> Helper loaded: date_helper
INFO - 2016-02-22 12:18:22 --> Helper loaded: form_helper
INFO - 2016-02-22 12:18:22 --> Database Driver Class Initialized
INFO - 2016-02-22 12:18:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:18:23 --> Controller Class Initialized
INFO - 2016-02-22 12:18:23 --> Model Class Initialized
INFO - 2016-02-22 12:18:23 --> Model Class Initialized
INFO - 2016-02-22 12:18:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:18:23 --> Pagination Class Initialized
INFO - 2016-02-22 12:18:23 --> Helper loaded: text_helper
INFO - 2016-02-22 12:18:23 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:18:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:18:23 --> Final output sent to browser
DEBUG - 2016-02-22 15:18:23 --> Total execution time: 1.1405
INFO - 2016-02-22 12:19:06 --> Config Class Initialized
INFO - 2016-02-22 12:19:06 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:19:06 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:19:06 --> Utf8 Class Initialized
INFO - 2016-02-22 12:19:06 --> URI Class Initialized
INFO - 2016-02-22 12:19:06 --> Router Class Initialized
INFO - 2016-02-22 12:19:06 --> Output Class Initialized
INFO - 2016-02-22 12:19:06 --> Security Class Initialized
DEBUG - 2016-02-22 12:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:19:06 --> Input Class Initialized
INFO - 2016-02-22 12:19:06 --> Language Class Initialized
INFO - 2016-02-22 12:19:06 --> Loader Class Initialized
INFO - 2016-02-22 12:19:06 --> Helper loaded: url_helper
INFO - 2016-02-22 12:19:06 --> Helper loaded: file_helper
INFO - 2016-02-22 12:19:06 --> Helper loaded: date_helper
INFO - 2016-02-22 12:19:06 --> Helper loaded: form_helper
INFO - 2016-02-22 12:19:06 --> Database Driver Class Initialized
INFO - 2016-02-22 12:19:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:19:08 --> Controller Class Initialized
INFO - 2016-02-22 12:19:08 --> Model Class Initialized
INFO - 2016-02-22 12:19:08 --> Model Class Initialized
INFO - 2016-02-22 12:19:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:19:08 --> Pagination Class Initialized
INFO - 2016-02-22 12:19:08 --> Helper loaded: text_helper
INFO - 2016-02-22 12:19:08 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:19:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:19:08 --> Final output sent to browser
DEBUG - 2016-02-22 15:19:08 --> Total execution time: 1.1734
INFO - 2016-02-22 12:19:13 --> Config Class Initialized
INFO - 2016-02-22 12:19:13 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:19:13 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:19:13 --> Utf8 Class Initialized
INFO - 2016-02-22 12:19:13 --> URI Class Initialized
INFO - 2016-02-22 12:19:13 --> Router Class Initialized
INFO - 2016-02-22 12:19:13 --> Output Class Initialized
INFO - 2016-02-22 12:19:13 --> Security Class Initialized
DEBUG - 2016-02-22 12:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:19:13 --> Input Class Initialized
INFO - 2016-02-22 12:19:13 --> Language Class Initialized
INFO - 2016-02-22 12:19:13 --> Loader Class Initialized
INFO - 2016-02-22 12:19:13 --> Helper loaded: url_helper
INFO - 2016-02-22 12:19:13 --> Helper loaded: file_helper
INFO - 2016-02-22 12:19:13 --> Helper loaded: date_helper
INFO - 2016-02-22 12:19:13 --> Helper loaded: form_helper
INFO - 2016-02-22 12:19:13 --> Database Driver Class Initialized
INFO - 2016-02-22 12:19:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:19:14 --> Controller Class Initialized
INFO - 2016-02-22 12:19:14 --> Model Class Initialized
INFO - 2016-02-22 12:19:14 --> Model Class Initialized
INFO - 2016-02-22 12:19:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:19:14 --> Pagination Class Initialized
INFO - 2016-02-22 12:19:14 --> Helper loaded: text_helper
INFO - 2016-02-22 12:19:14 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:19:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:19:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:19:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:19:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:19:14 --> Final output sent to browser
DEBUG - 2016-02-22 15:19:14 --> Total execution time: 1.1221
INFO - 2016-02-22 12:19:16 --> Config Class Initialized
INFO - 2016-02-22 12:19:16 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:19:16 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:19:16 --> Utf8 Class Initialized
INFO - 2016-02-22 12:19:16 --> URI Class Initialized
INFO - 2016-02-22 12:19:16 --> Router Class Initialized
INFO - 2016-02-22 12:19:16 --> Output Class Initialized
INFO - 2016-02-22 12:19:16 --> Security Class Initialized
DEBUG - 2016-02-22 12:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:19:16 --> Input Class Initialized
INFO - 2016-02-22 12:19:16 --> Language Class Initialized
INFO - 2016-02-22 12:19:16 --> Loader Class Initialized
INFO - 2016-02-22 12:19:16 --> Helper loaded: url_helper
INFO - 2016-02-22 12:19:16 --> Helper loaded: file_helper
INFO - 2016-02-22 12:19:16 --> Helper loaded: date_helper
INFO - 2016-02-22 12:19:16 --> Helper loaded: form_helper
INFO - 2016-02-22 12:19:16 --> Database Driver Class Initialized
INFO - 2016-02-22 12:19:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:19:17 --> Controller Class Initialized
INFO - 2016-02-22 12:19:17 --> Model Class Initialized
INFO - 2016-02-22 12:19:17 --> Model Class Initialized
INFO - 2016-02-22 12:19:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:19:17 --> Pagination Class Initialized
INFO - 2016-02-22 12:19:17 --> Helper loaded: text_helper
INFO - 2016-02-22 12:19:17 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:19:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:19:17 --> Final output sent to browser
DEBUG - 2016-02-22 15:19:17 --> Total execution time: 1.1221
INFO - 2016-02-22 12:19:28 --> Config Class Initialized
INFO - 2016-02-22 12:19:28 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:19:28 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:19:28 --> Utf8 Class Initialized
INFO - 2016-02-22 12:19:28 --> URI Class Initialized
INFO - 2016-02-22 12:19:28 --> Router Class Initialized
INFO - 2016-02-22 12:19:28 --> Output Class Initialized
INFO - 2016-02-22 12:19:28 --> Security Class Initialized
DEBUG - 2016-02-22 12:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:19:28 --> Input Class Initialized
INFO - 2016-02-22 12:19:28 --> Language Class Initialized
INFO - 2016-02-22 12:19:28 --> Loader Class Initialized
INFO - 2016-02-22 12:19:28 --> Helper loaded: url_helper
INFO - 2016-02-22 12:19:28 --> Helper loaded: file_helper
INFO - 2016-02-22 12:19:28 --> Helper loaded: date_helper
INFO - 2016-02-22 12:19:28 --> Helper loaded: form_helper
INFO - 2016-02-22 12:19:28 --> Database Driver Class Initialized
INFO - 2016-02-22 12:19:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:19:29 --> Controller Class Initialized
INFO - 2016-02-22 12:19:29 --> Model Class Initialized
INFO - 2016-02-22 12:19:29 --> Model Class Initialized
INFO - 2016-02-22 12:19:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:19:29 --> Pagination Class Initialized
INFO - 2016-02-22 12:19:29 --> Helper loaded: text_helper
INFO - 2016-02-22 12:19:29 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:19:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:19:29 --> Final output sent to browser
DEBUG - 2016-02-22 15:19:29 --> Total execution time: 1.1671
INFO - 2016-02-22 12:19:49 --> Config Class Initialized
INFO - 2016-02-22 12:19:49 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:19:49 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:19:49 --> Utf8 Class Initialized
INFO - 2016-02-22 12:19:49 --> URI Class Initialized
INFO - 2016-02-22 12:19:49 --> Router Class Initialized
INFO - 2016-02-22 12:19:49 --> Output Class Initialized
INFO - 2016-02-22 12:19:49 --> Security Class Initialized
DEBUG - 2016-02-22 12:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:19:49 --> Input Class Initialized
INFO - 2016-02-22 12:19:49 --> Language Class Initialized
INFO - 2016-02-22 12:19:49 --> Loader Class Initialized
INFO - 2016-02-22 12:19:49 --> Helper loaded: url_helper
INFO - 2016-02-22 12:19:49 --> Helper loaded: file_helper
INFO - 2016-02-22 12:19:49 --> Helper loaded: date_helper
INFO - 2016-02-22 12:19:49 --> Helper loaded: form_helper
INFO - 2016-02-22 12:19:49 --> Database Driver Class Initialized
INFO - 2016-02-22 12:19:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:19:50 --> Controller Class Initialized
INFO - 2016-02-22 12:19:50 --> Model Class Initialized
INFO - 2016-02-22 12:19:50 --> Model Class Initialized
INFO - 2016-02-22 12:19:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:19:50 --> Pagination Class Initialized
INFO - 2016-02-22 12:19:50 --> Helper loaded: text_helper
INFO - 2016-02-22 12:19:50 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:19:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:19:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:19:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:19:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:19:50 --> Final output sent to browser
DEBUG - 2016-02-22 15:19:50 --> Total execution time: 1.1893
INFO - 2016-02-22 12:19:52 --> Config Class Initialized
INFO - 2016-02-22 12:19:52 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:19:52 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:19:52 --> Utf8 Class Initialized
INFO - 2016-02-22 12:19:52 --> URI Class Initialized
INFO - 2016-02-22 12:19:52 --> Router Class Initialized
INFO - 2016-02-22 12:19:52 --> Output Class Initialized
INFO - 2016-02-22 12:19:52 --> Security Class Initialized
DEBUG - 2016-02-22 12:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:19:52 --> Input Class Initialized
INFO - 2016-02-22 12:19:52 --> Language Class Initialized
INFO - 2016-02-22 12:19:52 --> Loader Class Initialized
INFO - 2016-02-22 12:19:52 --> Helper loaded: url_helper
INFO - 2016-02-22 12:19:52 --> Helper loaded: file_helper
INFO - 2016-02-22 12:19:52 --> Helper loaded: date_helper
INFO - 2016-02-22 12:19:52 --> Helper loaded: form_helper
INFO - 2016-02-22 12:19:52 --> Database Driver Class Initialized
INFO - 2016-02-22 12:19:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:19:53 --> Controller Class Initialized
INFO - 2016-02-22 12:19:53 --> Model Class Initialized
INFO - 2016-02-22 12:19:53 --> Model Class Initialized
INFO - 2016-02-22 12:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:19:53 --> Pagination Class Initialized
INFO - 2016-02-22 12:19:53 --> Helper loaded: text_helper
INFO - 2016-02-22 12:19:53 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:19:53 --> Final output sent to browser
DEBUG - 2016-02-22 15:19:53 --> Total execution time: 1.1640
INFO - 2016-02-22 12:19:55 --> Config Class Initialized
INFO - 2016-02-22 12:19:55 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:19:55 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:19:55 --> Utf8 Class Initialized
INFO - 2016-02-22 12:19:55 --> URI Class Initialized
INFO - 2016-02-22 12:19:55 --> Router Class Initialized
INFO - 2016-02-22 12:19:55 --> Output Class Initialized
INFO - 2016-02-22 12:19:55 --> Security Class Initialized
DEBUG - 2016-02-22 12:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:19:55 --> Input Class Initialized
INFO - 2016-02-22 12:19:55 --> Language Class Initialized
INFO - 2016-02-22 12:19:55 --> Loader Class Initialized
INFO - 2016-02-22 12:19:55 --> Helper loaded: url_helper
INFO - 2016-02-22 12:19:55 --> Helper loaded: file_helper
INFO - 2016-02-22 12:19:55 --> Helper loaded: date_helper
INFO - 2016-02-22 12:19:55 --> Helper loaded: form_helper
INFO - 2016-02-22 12:19:55 --> Database Driver Class Initialized
INFO - 2016-02-22 12:19:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:19:56 --> Controller Class Initialized
INFO - 2016-02-22 12:19:56 --> Model Class Initialized
INFO - 2016-02-22 12:19:56 --> Model Class Initialized
INFO - 2016-02-22 12:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:19:56 --> Pagination Class Initialized
INFO - 2016-02-22 12:19:56 --> Helper loaded: text_helper
INFO - 2016-02-22 12:19:56 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:19:56 --> Final output sent to browser
DEBUG - 2016-02-22 15:19:56 --> Total execution time: 1.1679
INFO - 2016-02-22 12:19:59 --> Config Class Initialized
INFO - 2016-02-22 12:19:59 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:19:59 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:19:59 --> Utf8 Class Initialized
INFO - 2016-02-22 12:19:59 --> URI Class Initialized
INFO - 2016-02-22 12:19:59 --> Router Class Initialized
INFO - 2016-02-22 12:19:59 --> Output Class Initialized
INFO - 2016-02-22 12:19:59 --> Security Class Initialized
DEBUG - 2016-02-22 12:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:19:59 --> Input Class Initialized
INFO - 2016-02-22 12:19:59 --> Language Class Initialized
INFO - 2016-02-22 12:19:59 --> Loader Class Initialized
INFO - 2016-02-22 12:19:59 --> Helper loaded: url_helper
INFO - 2016-02-22 12:19:59 --> Helper loaded: file_helper
INFO - 2016-02-22 12:19:59 --> Helper loaded: date_helper
INFO - 2016-02-22 12:19:59 --> Helper loaded: form_helper
INFO - 2016-02-22 12:19:59 --> Database Driver Class Initialized
INFO - 2016-02-22 12:20:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:20:00 --> Controller Class Initialized
INFO - 2016-02-22 12:20:00 --> Model Class Initialized
INFO - 2016-02-22 12:20:00 --> Model Class Initialized
INFO - 2016-02-22 12:20:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:20:00 --> Pagination Class Initialized
INFO - 2016-02-22 12:20:00 --> Helper loaded: text_helper
INFO - 2016-02-22 12:20:00 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:20:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:20:00 --> Final output sent to browser
DEBUG - 2016-02-22 15:20:00 --> Total execution time: 1.1738
INFO - 2016-02-22 12:20:06 --> Config Class Initialized
INFO - 2016-02-22 12:20:06 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:20:06 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:20:06 --> Utf8 Class Initialized
INFO - 2016-02-22 12:20:06 --> URI Class Initialized
INFO - 2016-02-22 12:20:06 --> Router Class Initialized
INFO - 2016-02-22 12:20:06 --> Output Class Initialized
INFO - 2016-02-22 12:20:06 --> Security Class Initialized
DEBUG - 2016-02-22 12:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:20:06 --> Input Class Initialized
INFO - 2016-02-22 12:20:06 --> Language Class Initialized
INFO - 2016-02-22 12:20:06 --> Loader Class Initialized
INFO - 2016-02-22 12:20:06 --> Helper loaded: url_helper
INFO - 2016-02-22 12:20:06 --> Helper loaded: file_helper
INFO - 2016-02-22 12:20:06 --> Helper loaded: date_helper
INFO - 2016-02-22 12:20:06 --> Helper loaded: form_helper
INFO - 2016-02-22 12:20:06 --> Database Driver Class Initialized
INFO - 2016-02-22 12:20:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:20:07 --> Controller Class Initialized
INFO - 2016-02-22 12:20:07 --> Model Class Initialized
INFO - 2016-02-22 12:20:07 --> Model Class Initialized
INFO - 2016-02-22 12:20:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:20:07 --> Pagination Class Initialized
INFO - 2016-02-22 12:20:07 --> Helper loaded: text_helper
INFO - 2016-02-22 12:20:07 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:20:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:20:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:20:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:20:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:20:07 --> Final output sent to browser
DEBUG - 2016-02-22 15:20:07 --> Total execution time: 1.1250
INFO - 2016-02-22 12:20:08 --> Config Class Initialized
INFO - 2016-02-22 12:20:08 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:20:08 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:20:08 --> Utf8 Class Initialized
INFO - 2016-02-22 12:20:08 --> URI Class Initialized
INFO - 2016-02-22 12:20:08 --> Router Class Initialized
INFO - 2016-02-22 12:20:08 --> Output Class Initialized
INFO - 2016-02-22 12:20:08 --> Security Class Initialized
DEBUG - 2016-02-22 12:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:20:08 --> Input Class Initialized
INFO - 2016-02-22 12:20:08 --> Language Class Initialized
INFO - 2016-02-22 12:20:08 --> Loader Class Initialized
INFO - 2016-02-22 12:20:08 --> Helper loaded: url_helper
INFO - 2016-02-22 12:20:08 --> Helper loaded: file_helper
INFO - 2016-02-22 12:20:08 --> Helper loaded: date_helper
INFO - 2016-02-22 12:20:08 --> Helper loaded: form_helper
INFO - 2016-02-22 12:20:09 --> Database Driver Class Initialized
INFO - 2016-02-22 12:20:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:20:10 --> Controller Class Initialized
INFO - 2016-02-22 12:20:10 --> Model Class Initialized
INFO - 2016-02-22 12:20:10 --> Model Class Initialized
INFO - 2016-02-22 12:20:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:20:10 --> Pagination Class Initialized
INFO - 2016-02-22 12:20:10 --> Helper loaded: text_helper
INFO - 2016-02-22 12:20:10 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:20:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:20:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:20:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:20:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:20:10 --> Final output sent to browser
DEBUG - 2016-02-22 15:20:10 --> Total execution time: 1.1180
INFO - 2016-02-22 12:20:27 --> Config Class Initialized
INFO - 2016-02-22 12:20:27 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:20:27 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:20:27 --> Utf8 Class Initialized
INFO - 2016-02-22 12:20:27 --> URI Class Initialized
INFO - 2016-02-22 12:20:27 --> Router Class Initialized
INFO - 2016-02-22 12:20:27 --> Output Class Initialized
INFO - 2016-02-22 12:20:27 --> Security Class Initialized
DEBUG - 2016-02-22 12:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:20:27 --> Input Class Initialized
INFO - 2016-02-22 12:20:27 --> Language Class Initialized
INFO - 2016-02-22 12:20:27 --> Loader Class Initialized
INFO - 2016-02-22 12:20:27 --> Helper loaded: url_helper
INFO - 2016-02-22 12:20:27 --> Helper loaded: file_helper
INFO - 2016-02-22 12:20:27 --> Helper loaded: date_helper
INFO - 2016-02-22 12:20:27 --> Helper loaded: form_helper
INFO - 2016-02-22 12:20:27 --> Database Driver Class Initialized
INFO - 2016-02-22 12:20:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:20:28 --> Controller Class Initialized
INFO - 2016-02-22 12:20:28 --> Model Class Initialized
INFO - 2016-02-22 12:20:28 --> Model Class Initialized
INFO - 2016-02-22 12:20:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:20:28 --> Pagination Class Initialized
INFO - 2016-02-22 12:20:28 --> Helper loaded: text_helper
INFO - 2016-02-22 12:20:28 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:20:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:20:29 --> Final output sent to browser
DEBUG - 2016-02-22 15:20:29 --> Total execution time: 1.1382
INFO - 2016-02-22 12:20:49 --> Config Class Initialized
INFO - 2016-02-22 12:20:49 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:20:49 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:20:49 --> Utf8 Class Initialized
INFO - 2016-02-22 12:20:49 --> URI Class Initialized
INFO - 2016-02-22 12:20:49 --> Router Class Initialized
INFO - 2016-02-22 12:20:49 --> Output Class Initialized
INFO - 2016-02-22 12:20:49 --> Security Class Initialized
DEBUG - 2016-02-22 12:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:20:49 --> Input Class Initialized
INFO - 2016-02-22 12:20:49 --> Language Class Initialized
INFO - 2016-02-22 12:20:49 --> Loader Class Initialized
INFO - 2016-02-22 12:20:49 --> Helper loaded: url_helper
INFO - 2016-02-22 12:20:49 --> Helper loaded: file_helper
INFO - 2016-02-22 12:20:49 --> Helper loaded: date_helper
INFO - 2016-02-22 12:20:49 --> Helper loaded: form_helper
INFO - 2016-02-22 12:20:49 --> Database Driver Class Initialized
INFO - 2016-02-22 12:20:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:20:51 --> Controller Class Initialized
INFO - 2016-02-22 12:20:51 --> Model Class Initialized
INFO - 2016-02-22 12:20:51 --> Model Class Initialized
INFO - 2016-02-22 12:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:20:51 --> Pagination Class Initialized
INFO - 2016-02-22 12:20:51 --> Helper loaded: text_helper
INFO - 2016-02-22 12:20:51 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:20:51 --> Final output sent to browser
DEBUG - 2016-02-22 15:20:51 --> Total execution time: 1.1851
INFO - 2016-02-22 12:23:50 --> Config Class Initialized
INFO - 2016-02-22 12:23:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:23:50 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:23:50 --> Utf8 Class Initialized
INFO - 2016-02-22 12:23:50 --> URI Class Initialized
INFO - 2016-02-22 12:23:50 --> Router Class Initialized
INFO - 2016-02-22 12:23:50 --> Output Class Initialized
INFO - 2016-02-22 12:23:50 --> Security Class Initialized
DEBUG - 2016-02-22 12:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:23:50 --> Input Class Initialized
INFO - 2016-02-22 12:23:50 --> Language Class Initialized
INFO - 2016-02-22 12:23:50 --> Loader Class Initialized
INFO - 2016-02-22 12:23:50 --> Helper loaded: url_helper
INFO - 2016-02-22 12:23:50 --> Helper loaded: file_helper
INFO - 2016-02-22 12:23:50 --> Helper loaded: date_helper
INFO - 2016-02-22 12:23:50 --> Helper loaded: form_helper
INFO - 2016-02-22 12:23:50 --> Database Driver Class Initialized
INFO - 2016-02-22 12:23:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:23:51 --> Controller Class Initialized
INFO - 2016-02-22 12:23:51 --> Model Class Initialized
INFO - 2016-02-22 12:23:51 --> Model Class Initialized
INFO - 2016-02-22 12:23:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:23:51 --> Pagination Class Initialized
INFO - 2016-02-22 12:23:51 --> Helper loaded: text_helper
INFO - 2016-02-22 12:23:51 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:23:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:23:52 --> Final output sent to browser
DEBUG - 2016-02-22 15:23:52 --> Total execution time: 1.4760
INFO - 2016-02-22 12:43:11 --> Config Class Initialized
INFO - 2016-02-22 12:43:11 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:43:11 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:43:11 --> Utf8 Class Initialized
INFO - 2016-02-22 12:43:11 --> URI Class Initialized
INFO - 2016-02-22 12:43:11 --> Router Class Initialized
INFO - 2016-02-22 12:43:11 --> Output Class Initialized
INFO - 2016-02-22 12:43:11 --> Security Class Initialized
DEBUG - 2016-02-22 12:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:43:11 --> Input Class Initialized
INFO - 2016-02-22 12:43:11 --> Language Class Initialized
ERROR - 2016-02-22 12:43:11 --> Severity: Parsing Error --> syntax error, unexpected '$user_info' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 482
INFO - 2016-02-22 12:43:29 --> Config Class Initialized
INFO - 2016-02-22 12:43:29 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:43:29 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:43:29 --> Utf8 Class Initialized
INFO - 2016-02-22 12:43:29 --> URI Class Initialized
INFO - 2016-02-22 12:43:29 --> Router Class Initialized
INFO - 2016-02-22 12:43:29 --> Output Class Initialized
INFO - 2016-02-22 12:43:29 --> Security Class Initialized
DEBUG - 2016-02-22 12:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:43:29 --> Input Class Initialized
INFO - 2016-02-22 12:43:29 --> Language Class Initialized
INFO - 2016-02-22 12:43:29 --> Loader Class Initialized
INFO - 2016-02-22 12:43:29 --> Helper loaded: url_helper
INFO - 2016-02-22 12:43:29 --> Helper loaded: file_helper
INFO - 2016-02-22 12:43:29 --> Helper loaded: date_helper
INFO - 2016-02-22 12:43:29 --> Helper loaded: form_helper
INFO - 2016-02-22 12:43:29 --> Database Driver Class Initialized
INFO - 2016-02-22 12:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:43:31 --> Controller Class Initialized
INFO - 2016-02-22 12:43:31 --> Model Class Initialized
INFO - 2016-02-22 12:43:31 --> Model Class Initialized
INFO - 2016-02-22 12:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:43:31 --> Pagination Class Initialized
INFO - 2016-02-22 12:43:31 --> Helper loaded: text_helper
INFO - 2016-02-22 12:43:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:43:31 --> Final output sent to browser
DEBUG - 2016-02-22 15:43:31 --> Total execution time: 1.2068
INFO - 2016-02-22 12:43:33 --> Config Class Initialized
INFO - 2016-02-22 12:43:33 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:43:33 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:43:33 --> Utf8 Class Initialized
INFO - 2016-02-22 12:43:33 --> URI Class Initialized
INFO - 2016-02-22 12:43:33 --> Router Class Initialized
INFO - 2016-02-22 12:43:33 --> Output Class Initialized
INFO - 2016-02-22 12:43:33 --> Security Class Initialized
DEBUG - 2016-02-22 12:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:43:33 --> Input Class Initialized
INFO - 2016-02-22 12:43:33 --> Language Class Initialized
INFO - 2016-02-22 12:43:33 --> Loader Class Initialized
INFO - 2016-02-22 12:43:33 --> Helper loaded: url_helper
INFO - 2016-02-22 12:43:33 --> Helper loaded: file_helper
INFO - 2016-02-22 12:43:33 --> Helper loaded: date_helper
INFO - 2016-02-22 12:43:33 --> Helper loaded: form_helper
INFO - 2016-02-22 12:43:33 --> Database Driver Class Initialized
INFO - 2016-02-22 12:43:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:43:34 --> Controller Class Initialized
INFO - 2016-02-22 12:43:34 --> Model Class Initialized
INFO - 2016-02-22 12:43:34 --> Model Class Initialized
INFO - 2016-02-22 12:43:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:43:34 --> Pagination Class Initialized
INFO - 2016-02-22 12:43:34 --> Helper loaded: text_helper
INFO - 2016-02-22 12:43:34 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:43:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:43:34 --> Final output sent to browser
DEBUG - 2016-02-22 15:43:34 --> Total execution time: 1.1494
INFO - 2016-02-22 12:43:37 --> Config Class Initialized
INFO - 2016-02-22 12:43:37 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:43:37 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:43:37 --> Utf8 Class Initialized
INFO - 2016-02-22 12:43:37 --> URI Class Initialized
INFO - 2016-02-22 12:43:37 --> Router Class Initialized
INFO - 2016-02-22 12:43:37 --> Output Class Initialized
INFO - 2016-02-22 12:43:37 --> Security Class Initialized
DEBUG - 2016-02-22 12:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:43:37 --> Input Class Initialized
INFO - 2016-02-22 12:43:37 --> Language Class Initialized
INFO - 2016-02-22 12:43:37 --> Loader Class Initialized
INFO - 2016-02-22 12:43:37 --> Helper loaded: url_helper
INFO - 2016-02-22 12:43:37 --> Helper loaded: file_helper
INFO - 2016-02-22 12:43:37 --> Helper loaded: date_helper
INFO - 2016-02-22 12:43:37 --> Helper loaded: form_helper
INFO - 2016-02-22 12:43:37 --> Database Driver Class Initialized
INFO - 2016-02-22 12:43:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:43:38 --> Controller Class Initialized
INFO - 2016-02-22 12:43:38 --> Model Class Initialized
INFO - 2016-02-22 12:43:38 --> Model Class Initialized
INFO - 2016-02-22 12:43:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:43:38 --> Pagination Class Initialized
INFO - 2016-02-22 12:43:38 --> Helper loaded: text_helper
INFO - 2016-02-22 12:43:38 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:43:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:43:38 --> Final output sent to browser
DEBUG - 2016-02-22 15:43:38 --> Total execution time: 1.2023
INFO - 2016-02-22 12:43:39 --> Config Class Initialized
INFO - 2016-02-22 12:43:39 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:43:39 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:43:39 --> Utf8 Class Initialized
INFO - 2016-02-22 12:43:39 --> URI Class Initialized
INFO - 2016-02-22 12:43:39 --> Router Class Initialized
INFO - 2016-02-22 12:43:39 --> Output Class Initialized
INFO - 2016-02-22 12:43:39 --> Security Class Initialized
DEBUG - 2016-02-22 12:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:43:39 --> Input Class Initialized
INFO - 2016-02-22 12:43:39 --> Language Class Initialized
INFO - 2016-02-22 12:43:39 --> Loader Class Initialized
INFO - 2016-02-22 12:43:39 --> Helper loaded: url_helper
INFO - 2016-02-22 12:43:39 --> Helper loaded: file_helper
INFO - 2016-02-22 12:43:39 --> Helper loaded: date_helper
INFO - 2016-02-22 12:43:39 --> Helper loaded: form_helper
INFO - 2016-02-22 12:43:39 --> Database Driver Class Initialized
INFO - 2016-02-22 12:43:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:43:40 --> Controller Class Initialized
INFO - 2016-02-22 12:43:40 --> Model Class Initialized
INFO - 2016-02-22 12:43:41 --> Model Class Initialized
INFO - 2016-02-22 12:43:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:43:41 --> Pagination Class Initialized
INFO - 2016-02-22 12:43:41 --> Helper loaded: text_helper
INFO - 2016-02-22 12:43:41 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:43:41 --> Final output sent to browser
DEBUG - 2016-02-22 15:43:41 --> Total execution time: 1.2884
INFO - 2016-02-22 12:43:50 --> Config Class Initialized
INFO - 2016-02-22 12:43:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:43:50 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:43:50 --> Utf8 Class Initialized
INFO - 2016-02-22 12:43:50 --> URI Class Initialized
INFO - 2016-02-22 12:43:50 --> Router Class Initialized
INFO - 2016-02-22 12:43:50 --> Output Class Initialized
INFO - 2016-02-22 12:43:50 --> Security Class Initialized
DEBUG - 2016-02-22 12:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:43:50 --> Input Class Initialized
INFO - 2016-02-22 12:43:50 --> Language Class Initialized
INFO - 2016-02-22 12:43:50 --> Loader Class Initialized
INFO - 2016-02-22 12:43:50 --> Helper loaded: url_helper
INFO - 2016-02-22 12:43:50 --> Helper loaded: file_helper
INFO - 2016-02-22 12:43:50 --> Helper loaded: date_helper
INFO - 2016-02-22 12:43:50 --> Helper loaded: form_helper
INFO - 2016-02-22 12:43:50 --> Database Driver Class Initialized
INFO - 2016-02-22 12:43:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:43:51 --> Controller Class Initialized
INFO - 2016-02-22 12:43:51 --> Model Class Initialized
INFO - 2016-02-22 12:43:51 --> Model Class Initialized
INFO - 2016-02-22 12:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:43:51 --> Pagination Class Initialized
INFO - 2016-02-22 12:43:51 --> Helper loaded: text_helper
INFO - 2016-02-22 12:43:51 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:43:51 --> Final output sent to browser
DEBUG - 2016-02-22 15:43:51 --> Total execution time: 1.1098
INFO - 2016-02-22 12:43:54 --> Config Class Initialized
INFO - 2016-02-22 12:43:54 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:43:54 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:43:54 --> Utf8 Class Initialized
INFO - 2016-02-22 12:43:54 --> URI Class Initialized
INFO - 2016-02-22 12:43:54 --> Router Class Initialized
INFO - 2016-02-22 12:43:54 --> Output Class Initialized
INFO - 2016-02-22 12:43:54 --> Security Class Initialized
DEBUG - 2016-02-22 12:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:43:54 --> Input Class Initialized
INFO - 2016-02-22 12:43:54 --> Language Class Initialized
INFO - 2016-02-22 12:43:54 --> Loader Class Initialized
INFO - 2016-02-22 12:43:54 --> Helper loaded: url_helper
INFO - 2016-02-22 12:43:54 --> Helper loaded: file_helper
INFO - 2016-02-22 12:43:54 --> Helper loaded: date_helper
INFO - 2016-02-22 12:43:54 --> Helper loaded: form_helper
INFO - 2016-02-22 12:43:54 --> Database Driver Class Initialized
INFO - 2016-02-22 12:43:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:43:55 --> Controller Class Initialized
INFO - 2016-02-22 12:43:55 --> Model Class Initialized
INFO - 2016-02-22 12:43:55 --> Model Class Initialized
INFO - 2016-02-22 12:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:43:55 --> Pagination Class Initialized
INFO - 2016-02-22 12:43:55 --> Helper loaded: text_helper
INFO - 2016-02-22 12:43:55 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:43:55 --> Final output sent to browser
DEBUG - 2016-02-22 15:43:55 --> Total execution time: 1.1917
INFO - 2016-02-22 12:44:38 --> Config Class Initialized
INFO - 2016-02-22 12:44:38 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:44:38 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:44:38 --> Utf8 Class Initialized
INFO - 2016-02-22 12:44:38 --> URI Class Initialized
INFO - 2016-02-22 12:44:38 --> Router Class Initialized
INFO - 2016-02-22 12:44:38 --> Output Class Initialized
INFO - 2016-02-22 12:44:38 --> Security Class Initialized
DEBUG - 2016-02-22 12:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:44:38 --> Input Class Initialized
INFO - 2016-02-22 12:44:38 --> Language Class Initialized
INFO - 2016-02-22 12:44:38 --> Loader Class Initialized
INFO - 2016-02-22 12:44:38 --> Helper loaded: url_helper
INFO - 2016-02-22 12:44:38 --> Helper loaded: file_helper
INFO - 2016-02-22 12:44:38 --> Helper loaded: date_helper
INFO - 2016-02-22 12:44:38 --> Helper loaded: form_helper
INFO - 2016-02-22 12:44:38 --> Database Driver Class Initialized
INFO - 2016-02-22 12:44:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:44:39 --> Controller Class Initialized
INFO - 2016-02-22 12:44:39 --> Model Class Initialized
INFO - 2016-02-22 12:44:39 --> Model Class Initialized
INFO - 2016-02-22 12:44:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:44:39 --> Pagination Class Initialized
INFO - 2016-02-22 12:44:39 --> Helper loaded: text_helper
INFO - 2016-02-22 12:44:39 --> Helper loaded: cookie_helper
INFO - 2016-02-22 12:47:30 --> Config Class Initialized
INFO - 2016-02-22 12:47:30 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:47:30 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:47:30 --> Utf8 Class Initialized
INFO - 2016-02-22 12:47:30 --> URI Class Initialized
DEBUG - 2016-02-22 12:47:30 --> No URI present. Default controller set.
INFO - 2016-02-22 12:47:30 --> Router Class Initialized
INFO - 2016-02-22 12:47:30 --> Output Class Initialized
INFO - 2016-02-22 12:47:30 --> Security Class Initialized
DEBUG - 2016-02-22 12:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:47:30 --> Input Class Initialized
INFO - 2016-02-22 12:47:30 --> Language Class Initialized
INFO - 2016-02-22 12:47:30 --> Loader Class Initialized
INFO - 2016-02-22 12:47:30 --> Helper loaded: url_helper
INFO - 2016-02-22 12:47:30 --> Helper loaded: file_helper
INFO - 2016-02-22 12:47:30 --> Helper loaded: date_helper
INFO - 2016-02-22 12:47:30 --> Helper loaded: form_helper
INFO - 2016-02-22 12:47:30 --> Database Driver Class Initialized
INFO - 2016-02-22 12:47:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:47:31 --> Controller Class Initialized
INFO - 2016-02-22 12:47:31 --> Model Class Initialized
INFO - 2016-02-22 12:47:31 --> Model Class Initialized
INFO - 2016-02-22 12:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:47:31 --> Pagination Class Initialized
INFO - 2016-02-22 12:47:31 --> Helper loaded: text_helper
INFO - 2016-02-22 12:47:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 15:47:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: SELECT COUNT(*) AS `numrows` FROM 
INFO - 2016-02-22 15:47:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-22 12:47:32 --> Config Class Initialized
INFO - 2016-02-22 12:47:32 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:47:32 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:47:32 --> Utf8 Class Initialized
INFO - 2016-02-22 12:47:32 --> URI Class Initialized
INFO - 2016-02-22 12:47:32 --> Router Class Initialized
INFO - 2016-02-22 12:47:32 --> Output Class Initialized
INFO - 2016-02-22 12:47:32 --> Security Class Initialized
DEBUG - 2016-02-22 12:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:47:32 --> Input Class Initialized
INFO - 2016-02-22 12:47:32 --> Language Class Initialized
INFO - 2016-02-22 12:47:32 --> Loader Class Initialized
INFO - 2016-02-22 12:47:32 --> Helper loaded: url_helper
INFO - 2016-02-22 12:47:32 --> Helper loaded: file_helper
INFO - 2016-02-22 12:47:32 --> Helper loaded: date_helper
INFO - 2016-02-22 12:47:32 --> Helper loaded: form_helper
INFO - 2016-02-22 12:47:32 --> Database Driver Class Initialized
INFO - 2016-02-22 12:47:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:47:33 --> Controller Class Initialized
INFO - 2016-02-22 12:47:33 --> Model Class Initialized
INFO - 2016-02-22 12:47:33 --> Model Class Initialized
INFO - 2016-02-22 12:47:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:47:33 --> Pagination Class Initialized
INFO - 2016-02-22 12:47:33 --> Helper loaded: text_helper
INFO - 2016-02-22 12:47:33 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:47:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:47:33 --> Final output sent to browser
DEBUG - 2016-02-22 15:47:33 --> Total execution time: 1.1689
INFO - 2016-02-22 12:47:35 --> Config Class Initialized
INFO - 2016-02-22 12:47:35 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:47:35 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:47:35 --> Utf8 Class Initialized
INFO - 2016-02-22 12:47:35 --> URI Class Initialized
INFO - 2016-02-22 12:47:35 --> Router Class Initialized
INFO - 2016-02-22 12:47:35 --> Output Class Initialized
INFO - 2016-02-22 12:47:35 --> Security Class Initialized
DEBUG - 2016-02-22 12:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:47:35 --> Input Class Initialized
INFO - 2016-02-22 12:47:35 --> Language Class Initialized
INFO - 2016-02-22 12:47:35 --> Loader Class Initialized
INFO - 2016-02-22 12:47:35 --> Helper loaded: url_helper
INFO - 2016-02-22 12:47:35 --> Helper loaded: file_helper
INFO - 2016-02-22 12:47:35 --> Helper loaded: date_helper
INFO - 2016-02-22 12:47:35 --> Helper loaded: form_helper
INFO - 2016-02-22 12:47:35 --> Database Driver Class Initialized
INFO - 2016-02-22 12:47:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:47:36 --> Controller Class Initialized
INFO - 2016-02-22 12:47:36 --> Model Class Initialized
INFO - 2016-02-22 12:47:36 --> Model Class Initialized
INFO - 2016-02-22 12:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:47:36 --> Pagination Class Initialized
INFO - 2016-02-22 12:47:36 --> Helper loaded: text_helper
INFO - 2016-02-22 12:47:36 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:47:36 --> Final output sent to browser
DEBUG - 2016-02-22 15:47:36 --> Total execution time: 1.1360
INFO - 2016-02-22 12:47:37 --> Config Class Initialized
INFO - 2016-02-22 12:47:37 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:47:37 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:47:37 --> Utf8 Class Initialized
INFO - 2016-02-22 12:47:37 --> URI Class Initialized
INFO - 2016-02-22 12:47:37 --> Router Class Initialized
INFO - 2016-02-22 12:47:37 --> Output Class Initialized
INFO - 2016-02-22 12:47:37 --> Security Class Initialized
DEBUG - 2016-02-22 12:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:47:37 --> Input Class Initialized
INFO - 2016-02-22 12:47:37 --> Language Class Initialized
INFO - 2016-02-22 12:47:37 --> Loader Class Initialized
INFO - 2016-02-22 12:47:37 --> Helper loaded: url_helper
INFO - 2016-02-22 12:47:37 --> Helper loaded: file_helper
INFO - 2016-02-22 12:47:37 --> Helper loaded: date_helper
INFO - 2016-02-22 12:47:37 --> Helper loaded: form_helper
INFO - 2016-02-22 12:47:37 --> Database Driver Class Initialized
INFO - 2016-02-22 12:47:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:47:38 --> Controller Class Initialized
INFO - 2016-02-22 12:47:38 --> Model Class Initialized
INFO - 2016-02-22 12:47:38 --> Model Class Initialized
INFO - 2016-02-22 12:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:47:38 --> Pagination Class Initialized
INFO - 2016-02-22 12:47:38 --> Helper loaded: text_helper
INFO - 2016-02-22 12:47:38 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:47:38 --> Final output sent to browser
DEBUG - 2016-02-22 15:47:38 --> Total execution time: 1.3026
INFO - 2016-02-22 12:47:40 --> Config Class Initialized
INFO - 2016-02-22 12:47:40 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:47:40 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:47:40 --> Utf8 Class Initialized
INFO - 2016-02-22 12:47:40 --> URI Class Initialized
INFO - 2016-02-22 12:47:40 --> Router Class Initialized
INFO - 2016-02-22 12:47:40 --> Output Class Initialized
INFO - 2016-02-22 12:47:40 --> Security Class Initialized
DEBUG - 2016-02-22 12:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:47:40 --> Input Class Initialized
INFO - 2016-02-22 12:47:40 --> Language Class Initialized
INFO - 2016-02-22 12:47:40 --> Loader Class Initialized
INFO - 2016-02-22 12:47:40 --> Helper loaded: url_helper
INFO - 2016-02-22 12:47:40 --> Helper loaded: file_helper
INFO - 2016-02-22 12:47:40 --> Helper loaded: date_helper
INFO - 2016-02-22 12:47:40 --> Helper loaded: form_helper
INFO - 2016-02-22 12:47:40 --> Database Driver Class Initialized
INFO - 2016-02-22 12:47:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:47:41 --> Controller Class Initialized
INFO - 2016-02-22 12:47:41 --> Model Class Initialized
INFO - 2016-02-22 12:47:41 --> Model Class Initialized
INFO - 2016-02-22 12:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:47:41 --> Pagination Class Initialized
INFO - 2016-02-22 12:47:41 --> Helper loaded: text_helper
INFO - 2016-02-22 12:47:41 --> Helper loaded: cookie_helper
ERROR - 2016-02-22 15:47:41 --> Severity: Warning --> Missing argument 3 for Jboard_model::is_vote(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 484 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 203
ERROR - 2016-02-22 15:47:41 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 662
ERROR - 2016-02-22 15:47:41 --> Severity: Notice --> Undefined variable: board_id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 206
ERROR - 2016-02-22 15:47:41 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `wall_vote`
WHERE `user_id` = `Array`
AND `board_id` IS NULL
INFO - 2016-02-22 15:47:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-22 15:47:41 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1456174061
WHERE `user_id` = `Array`
AND `board_id` IS NULL
AND `id` = '4cef9e4e6cc498f44b08462305393193416e5254'
INFO - 2016-02-22 12:51:45 --> Config Class Initialized
INFO - 2016-02-22 12:51:45 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:51:45 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:51:45 --> Utf8 Class Initialized
INFO - 2016-02-22 12:51:45 --> URI Class Initialized
INFO - 2016-02-22 12:51:45 --> Router Class Initialized
INFO - 2016-02-22 12:51:45 --> Output Class Initialized
INFO - 2016-02-22 12:51:45 --> Security Class Initialized
DEBUG - 2016-02-22 12:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:51:45 --> Input Class Initialized
INFO - 2016-02-22 12:51:45 --> Language Class Initialized
INFO - 2016-02-22 12:51:45 --> Loader Class Initialized
INFO - 2016-02-22 12:51:45 --> Helper loaded: url_helper
INFO - 2016-02-22 12:51:45 --> Helper loaded: file_helper
INFO - 2016-02-22 12:51:45 --> Helper loaded: date_helper
INFO - 2016-02-22 12:51:45 --> Helper loaded: form_helper
INFO - 2016-02-22 12:51:45 --> Database Driver Class Initialized
INFO - 2016-02-22 12:51:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:51:46 --> Controller Class Initialized
INFO - 2016-02-22 12:51:46 --> Model Class Initialized
INFO - 2016-02-22 12:51:46 --> Model Class Initialized
INFO - 2016-02-22 12:51:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:51:46 --> Pagination Class Initialized
INFO - 2016-02-22 12:51:46 --> Helper loaded: text_helper
INFO - 2016-02-22 12:51:46 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:51:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:51:46 --> Final output sent to browser
DEBUG - 2016-02-22 15:51:46 --> Total execution time: 1.1514
INFO - 2016-02-22 12:51:48 --> Config Class Initialized
INFO - 2016-02-22 12:51:48 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:51:48 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:51:48 --> Utf8 Class Initialized
INFO - 2016-02-22 12:51:48 --> URI Class Initialized
INFO - 2016-02-22 12:51:48 --> Router Class Initialized
INFO - 2016-02-22 12:51:48 --> Output Class Initialized
INFO - 2016-02-22 12:51:48 --> Security Class Initialized
DEBUG - 2016-02-22 12:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:51:48 --> Input Class Initialized
INFO - 2016-02-22 12:51:48 --> Language Class Initialized
INFO - 2016-02-22 12:51:48 --> Loader Class Initialized
INFO - 2016-02-22 12:51:48 --> Helper loaded: url_helper
INFO - 2016-02-22 12:51:48 --> Helper loaded: file_helper
INFO - 2016-02-22 12:51:48 --> Helper loaded: date_helper
INFO - 2016-02-22 12:51:48 --> Helper loaded: form_helper
INFO - 2016-02-22 12:51:48 --> Database Driver Class Initialized
INFO - 2016-02-22 12:51:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:51:49 --> Controller Class Initialized
INFO - 2016-02-22 12:51:49 --> Model Class Initialized
INFO - 2016-02-22 12:51:49 --> Model Class Initialized
INFO - 2016-02-22 12:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:51:49 --> Pagination Class Initialized
INFO - 2016-02-22 12:51:49 --> Helper loaded: text_helper
INFO - 2016-02-22 12:51:49 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:51:49 --> Final output sent to browser
DEBUG - 2016-02-22 15:51:49 --> Total execution time: 1.1499
INFO - 2016-02-22 12:51:52 --> Config Class Initialized
INFO - 2016-02-22 12:51:52 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:51:52 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:51:52 --> Utf8 Class Initialized
INFO - 2016-02-22 12:51:52 --> URI Class Initialized
INFO - 2016-02-22 12:51:52 --> Router Class Initialized
INFO - 2016-02-22 12:51:52 --> Output Class Initialized
INFO - 2016-02-22 12:51:52 --> Security Class Initialized
DEBUG - 2016-02-22 12:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:51:52 --> Input Class Initialized
INFO - 2016-02-22 12:51:52 --> Language Class Initialized
INFO - 2016-02-22 12:51:52 --> Loader Class Initialized
INFO - 2016-02-22 12:51:52 --> Helper loaded: url_helper
INFO - 2016-02-22 12:51:52 --> Helper loaded: file_helper
INFO - 2016-02-22 12:51:52 --> Helper loaded: date_helper
INFO - 2016-02-22 12:51:52 --> Helper loaded: form_helper
INFO - 2016-02-22 12:51:52 --> Database Driver Class Initialized
INFO - 2016-02-22 12:51:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:51:53 --> Controller Class Initialized
INFO - 2016-02-22 12:51:53 --> Model Class Initialized
INFO - 2016-02-22 12:51:53 --> Model Class Initialized
INFO - 2016-02-22 12:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:51:53 --> Pagination Class Initialized
INFO - 2016-02-22 12:51:53 --> Helper loaded: text_helper
INFO - 2016-02-22 12:51:53 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:51:53 --> Final output sent to browser
DEBUG - 2016-02-22 15:51:53 --> Total execution time: 1.1667
INFO - 2016-02-22 12:51:59 --> Config Class Initialized
INFO - 2016-02-22 12:51:59 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:51:59 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:51:59 --> Utf8 Class Initialized
INFO - 2016-02-22 12:51:59 --> URI Class Initialized
INFO - 2016-02-22 12:51:59 --> Router Class Initialized
INFO - 2016-02-22 12:51:59 --> Output Class Initialized
INFO - 2016-02-22 12:51:59 --> Security Class Initialized
DEBUG - 2016-02-22 12:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:51:59 --> Input Class Initialized
INFO - 2016-02-22 12:51:59 --> Language Class Initialized
INFO - 2016-02-22 12:51:59 --> Loader Class Initialized
INFO - 2016-02-22 12:51:59 --> Helper loaded: url_helper
INFO - 2016-02-22 12:51:59 --> Helper loaded: file_helper
INFO - 2016-02-22 12:51:59 --> Helper loaded: date_helper
INFO - 2016-02-22 12:51:59 --> Helper loaded: form_helper
INFO - 2016-02-22 12:51:59 --> Database Driver Class Initialized
INFO - 2016-02-22 12:52:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:52:00 --> Controller Class Initialized
INFO - 2016-02-22 12:52:00 --> Model Class Initialized
INFO - 2016-02-22 12:52:00 --> Model Class Initialized
INFO - 2016-02-22 12:52:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:52:00 --> Pagination Class Initialized
INFO - 2016-02-22 12:52:00 --> Helper loaded: text_helper
INFO - 2016-02-22 12:52:00 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:52:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:52:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:52:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:52:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:52:00 --> Final output sent to browser
DEBUG - 2016-02-22 15:52:00 --> Total execution time: 1.1430
INFO - 2016-02-22 12:52:02 --> Config Class Initialized
INFO - 2016-02-22 12:52:02 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:52:02 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:52:02 --> Utf8 Class Initialized
INFO - 2016-02-22 12:52:02 --> URI Class Initialized
INFO - 2016-02-22 12:52:02 --> Router Class Initialized
INFO - 2016-02-22 12:52:02 --> Output Class Initialized
INFO - 2016-02-22 12:52:02 --> Security Class Initialized
DEBUG - 2016-02-22 12:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:52:02 --> Input Class Initialized
INFO - 2016-02-22 12:52:02 --> Language Class Initialized
INFO - 2016-02-22 12:52:02 --> Loader Class Initialized
INFO - 2016-02-22 12:52:02 --> Helper loaded: url_helper
INFO - 2016-02-22 12:52:02 --> Helper loaded: file_helper
INFO - 2016-02-22 12:52:02 --> Helper loaded: date_helper
INFO - 2016-02-22 12:52:02 --> Helper loaded: form_helper
INFO - 2016-02-22 12:52:02 --> Database Driver Class Initialized
INFO - 2016-02-22 12:52:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:52:03 --> Controller Class Initialized
INFO - 2016-02-22 12:52:03 --> Model Class Initialized
INFO - 2016-02-22 12:52:03 --> Model Class Initialized
INFO - 2016-02-22 12:52:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:52:03 --> Pagination Class Initialized
INFO - 2016-02-22 12:52:03 --> Helper loaded: text_helper
INFO - 2016-02-22 12:52:03 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:52:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:52:03 --> Final output sent to browser
DEBUG - 2016-02-22 15:52:03 --> Total execution time: 1.2068
INFO - 2016-02-22 12:52:05 --> Config Class Initialized
INFO - 2016-02-22 12:52:05 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:52:05 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:52:05 --> Utf8 Class Initialized
INFO - 2016-02-22 12:52:05 --> URI Class Initialized
INFO - 2016-02-22 12:52:05 --> Router Class Initialized
INFO - 2016-02-22 12:52:05 --> Output Class Initialized
INFO - 2016-02-22 12:52:05 --> Security Class Initialized
DEBUG - 2016-02-22 12:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:52:05 --> Input Class Initialized
INFO - 2016-02-22 12:52:05 --> Language Class Initialized
INFO - 2016-02-22 12:52:05 --> Loader Class Initialized
INFO - 2016-02-22 12:52:05 --> Helper loaded: url_helper
INFO - 2016-02-22 12:52:05 --> Helper loaded: file_helper
INFO - 2016-02-22 12:52:05 --> Helper loaded: date_helper
INFO - 2016-02-22 12:52:05 --> Helper loaded: form_helper
INFO - 2016-02-22 12:52:05 --> Database Driver Class Initialized
INFO - 2016-02-22 12:52:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:52:06 --> Controller Class Initialized
INFO - 2016-02-22 12:52:06 --> Model Class Initialized
INFO - 2016-02-22 12:52:06 --> Model Class Initialized
INFO - 2016-02-22 12:52:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:52:06 --> Pagination Class Initialized
INFO - 2016-02-22 12:52:06 --> Helper loaded: text_helper
INFO - 2016-02-22 12:52:06 --> Helper loaded: cookie_helper
INFO - 2016-02-22 12:54:41 --> Config Class Initialized
INFO - 2016-02-22 12:54:41 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:54:41 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:54:41 --> Utf8 Class Initialized
INFO - 2016-02-22 12:54:41 --> URI Class Initialized
INFO - 2016-02-22 12:54:41 --> Router Class Initialized
INFO - 2016-02-22 12:54:41 --> Output Class Initialized
INFO - 2016-02-22 12:54:41 --> Security Class Initialized
DEBUG - 2016-02-22 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:54:41 --> Input Class Initialized
INFO - 2016-02-22 12:54:41 --> Language Class Initialized
INFO - 2016-02-22 12:54:41 --> Loader Class Initialized
INFO - 2016-02-22 12:54:41 --> Helper loaded: url_helper
INFO - 2016-02-22 12:54:41 --> Helper loaded: file_helper
INFO - 2016-02-22 12:54:41 --> Helper loaded: date_helper
INFO - 2016-02-22 12:54:41 --> Helper loaded: form_helper
INFO - 2016-02-22 12:54:41 --> Database Driver Class Initialized
INFO - 2016-02-22 12:54:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:54:42 --> Controller Class Initialized
INFO - 2016-02-22 12:54:42 --> Model Class Initialized
INFO - 2016-02-22 12:54:42 --> Model Class Initialized
INFO - 2016-02-22 12:54:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:54:42 --> Pagination Class Initialized
INFO - 2016-02-22 12:54:42 --> Helper loaded: text_helper
INFO - 2016-02-22 12:54:42 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:54:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:54:42 --> Final output sent to browser
DEBUG - 2016-02-22 15:54:42 --> Total execution time: 1.1723
INFO - 2016-02-22 12:54:46 --> Config Class Initialized
INFO - 2016-02-22 12:54:46 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:54:46 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:54:46 --> Utf8 Class Initialized
INFO - 2016-02-22 12:54:46 --> URI Class Initialized
INFO - 2016-02-22 12:54:46 --> Router Class Initialized
INFO - 2016-02-22 12:54:46 --> Output Class Initialized
INFO - 2016-02-22 12:54:46 --> Security Class Initialized
DEBUG - 2016-02-22 12:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:54:46 --> Input Class Initialized
INFO - 2016-02-22 12:54:46 --> Language Class Initialized
INFO - 2016-02-22 12:54:46 --> Loader Class Initialized
INFO - 2016-02-22 12:54:46 --> Helper loaded: url_helper
INFO - 2016-02-22 12:54:46 --> Helper loaded: file_helper
INFO - 2016-02-22 12:54:46 --> Helper loaded: date_helper
INFO - 2016-02-22 12:54:46 --> Helper loaded: form_helper
INFO - 2016-02-22 12:54:46 --> Database Driver Class Initialized
INFO - 2016-02-22 12:54:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:54:47 --> Controller Class Initialized
INFO - 2016-02-22 12:54:47 --> Model Class Initialized
INFO - 2016-02-22 12:54:47 --> Model Class Initialized
INFO - 2016-02-22 12:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:54:47 --> Pagination Class Initialized
INFO - 2016-02-22 12:54:47 --> Helper loaded: text_helper
INFO - 2016-02-22 12:54:47 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:54:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:54:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:54:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:54:48 --> Final output sent to browser
DEBUG - 2016-02-22 15:54:48 --> Total execution time: 1.1909
INFO - 2016-02-22 12:54:50 --> Config Class Initialized
INFO - 2016-02-22 12:54:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:54:50 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:54:50 --> Utf8 Class Initialized
INFO - 2016-02-22 12:54:50 --> URI Class Initialized
INFO - 2016-02-22 12:54:50 --> Router Class Initialized
INFO - 2016-02-22 12:54:50 --> Output Class Initialized
INFO - 2016-02-22 12:54:50 --> Security Class Initialized
DEBUG - 2016-02-22 12:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:54:50 --> Input Class Initialized
INFO - 2016-02-22 12:54:50 --> Language Class Initialized
INFO - 2016-02-22 12:54:50 --> Loader Class Initialized
INFO - 2016-02-22 12:54:50 --> Helper loaded: url_helper
INFO - 2016-02-22 12:54:50 --> Helper loaded: file_helper
INFO - 2016-02-22 12:54:50 --> Helper loaded: date_helper
INFO - 2016-02-22 12:54:50 --> Helper loaded: form_helper
INFO - 2016-02-22 12:54:50 --> Database Driver Class Initialized
INFO - 2016-02-22 12:54:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:54:51 --> Controller Class Initialized
INFO - 2016-02-22 12:54:51 --> Model Class Initialized
INFO - 2016-02-22 12:54:51 --> Model Class Initialized
INFO - 2016-02-22 12:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:54:51 --> Pagination Class Initialized
INFO - 2016-02-22 12:54:51 --> Helper loaded: text_helper
INFO - 2016-02-22 12:54:51 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:54:51 --> Final output sent to browser
DEBUG - 2016-02-22 15:54:51 --> Total execution time: 1.1375
INFO - 2016-02-22 12:54:53 --> Config Class Initialized
INFO - 2016-02-22 12:54:53 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:54:53 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:54:53 --> Utf8 Class Initialized
INFO - 2016-02-22 12:54:53 --> URI Class Initialized
INFO - 2016-02-22 12:54:53 --> Router Class Initialized
INFO - 2016-02-22 12:54:53 --> Output Class Initialized
INFO - 2016-02-22 12:54:53 --> Security Class Initialized
DEBUG - 2016-02-22 12:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:54:53 --> Input Class Initialized
INFO - 2016-02-22 12:54:53 --> Language Class Initialized
INFO - 2016-02-22 12:54:53 --> Loader Class Initialized
INFO - 2016-02-22 12:54:53 --> Helper loaded: url_helper
INFO - 2016-02-22 12:54:53 --> Helper loaded: file_helper
INFO - 2016-02-22 12:54:53 --> Helper loaded: date_helper
INFO - 2016-02-22 12:54:53 --> Helper loaded: form_helper
INFO - 2016-02-22 12:54:53 --> Database Driver Class Initialized
INFO - 2016-02-22 12:54:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:54:54 --> Controller Class Initialized
INFO - 2016-02-22 12:54:54 --> Model Class Initialized
INFO - 2016-02-22 12:54:54 --> Model Class Initialized
INFO - 2016-02-22 12:54:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:54:54 --> Pagination Class Initialized
INFO - 2016-02-22 12:54:54 --> Helper loaded: text_helper
INFO - 2016-02-22 12:54:54 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:54:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:54:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 15:54:54 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 15:54:54 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 15:54:54 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 15:54:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 15:54:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:54:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:54:54 --> Final output sent to browser
DEBUG - 2016-02-22 15:54:54 --> Total execution time: 1.1201
INFO - 2016-02-22 12:55:51 --> Config Class Initialized
INFO - 2016-02-22 12:55:51 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:55:51 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:55:51 --> Utf8 Class Initialized
INFO - 2016-02-22 12:55:51 --> URI Class Initialized
INFO - 2016-02-22 12:55:51 --> Router Class Initialized
INFO - 2016-02-22 12:55:51 --> Output Class Initialized
INFO - 2016-02-22 12:55:51 --> Security Class Initialized
DEBUG - 2016-02-22 12:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:55:51 --> Input Class Initialized
INFO - 2016-02-22 12:55:51 --> Language Class Initialized
INFO - 2016-02-22 12:55:51 --> Loader Class Initialized
INFO - 2016-02-22 12:55:51 --> Helper loaded: url_helper
INFO - 2016-02-22 12:55:51 --> Helper loaded: file_helper
INFO - 2016-02-22 12:55:51 --> Helper loaded: date_helper
INFO - 2016-02-22 12:55:51 --> Helper loaded: form_helper
INFO - 2016-02-22 12:55:51 --> Database Driver Class Initialized
INFO - 2016-02-22 12:55:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:55:52 --> Controller Class Initialized
INFO - 2016-02-22 12:55:52 --> Model Class Initialized
INFO - 2016-02-22 12:55:52 --> Model Class Initialized
INFO - 2016-02-22 12:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:55:52 --> Pagination Class Initialized
INFO - 2016-02-22 12:55:52 --> Helper loaded: text_helper
INFO - 2016-02-22 12:55:52 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 15:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:55:52 --> Final output sent to browser
DEBUG - 2016-02-22 15:55:52 --> Total execution time: 1.1881
INFO - 2016-02-22 12:57:24 --> Config Class Initialized
INFO - 2016-02-22 12:57:24 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:57:24 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:57:24 --> Utf8 Class Initialized
INFO - 2016-02-22 12:57:24 --> URI Class Initialized
INFO - 2016-02-22 12:57:24 --> Router Class Initialized
INFO - 2016-02-22 12:57:24 --> Output Class Initialized
INFO - 2016-02-22 12:57:24 --> Security Class Initialized
DEBUG - 2016-02-22 12:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:57:24 --> Input Class Initialized
INFO - 2016-02-22 12:57:24 --> Language Class Initialized
INFO - 2016-02-22 12:57:24 --> Loader Class Initialized
INFO - 2016-02-22 12:57:24 --> Helper loaded: url_helper
INFO - 2016-02-22 12:57:24 --> Helper loaded: file_helper
INFO - 2016-02-22 12:57:24 --> Helper loaded: date_helper
INFO - 2016-02-22 12:57:24 --> Helper loaded: form_helper
INFO - 2016-02-22 12:57:24 --> Database Driver Class Initialized
INFO - 2016-02-22 12:57:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:57:25 --> Controller Class Initialized
INFO - 2016-02-22 12:57:25 --> Model Class Initialized
INFO - 2016-02-22 12:57:25 --> Model Class Initialized
INFO - 2016-02-22 12:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:57:25 --> Pagination Class Initialized
INFO - 2016-02-22 12:57:25 --> Helper loaded: text_helper
INFO - 2016-02-22 12:57:25 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:57:25 --> Final output sent to browser
DEBUG - 2016-02-22 15:57:25 --> Total execution time: 1.1174
INFO - 2016-02-22 12:57:26 --> Config Class Initialized
INFO - 2016-02-22 12:57:26 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:57:26 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:57:26 --> Utf8 Class Initialized
INFO - 2016-02-22 12:57:26 --> URI Class Initialized
INFO - 2016-02-22 12:57:26 --> Router Class Initialized
INFO - 2016-02-22 12:57:26 --> Output Class Initialized
INFO - 2016-02-22 12:57:26 --> Security Class Initialized
DEBUG - 2016-02-22 12:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:57:26 --> Input Class Initialized
INFO - 2016-02-22 12:57:26 --> Language Class Initialized
INFO - 2016-02-22 12:57:26 --> Loader Class Initialized
INFO - 2016-02-22 12:57:26 --> Helper loaded: url_helper
INFO - 2016-02-22 12:57:26 --> Helper loaded: file_helper
INFO - 2016-02-22 12:57:26 --> Helper loaded: date_helper
INFO - 2016-02-22 12:57:26 --> Helper loaded: form_helper
INFO - 2016-02-22 12:57:26 --> Database Driver Class Initialized
INFO - 2016-02-22 12:57:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:57:27 --> Controller Class Initialized
INFO - 2016-02-22 12:57:27 --> Model Class Initialized
INFO - 2016-02-22 12:57:27 --> Model Class Initialized
INFO - 2016-02-22 12:57:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:57:27 --> Pagination Class Initialized
INFO - 2016-02-22 12:57:27 --> Helper loaded: text_helper
INFO - 2016-02-22 12:57:27 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:57:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:57:27 --> Final output sent to browser
DEBUG - 2016-02-22 15:57:27 --> Total execution time: 1.1719
INFO - 2016-02-22 12:57:29 --> Config Class Initialized
INFO - 2016-02-22 12:57:29 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:57:29 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:57:29 --> Utf8 Class Initialized
INFO - 2016-02-22 12:57:29 --> URI Class Initialized
INFO - 2016-02-22 12:57:29 --> Router Class Initialized
INFO - 2016-02-22 12:57:29 --> Output Class Initialized
INFO - 2016-02-22 12:57:29 --> Security Class Initialized
DEBUG - 2016-02-22 12:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:57:29 --> Input Class Initialized
INFO - 2016-02-22 12:57:30 --> Language Class Initialized
INFO - 2016-02-22 12:57:30 --> Loader Class Initialized
INFO - 2016-02-22 12:57:30 --> Helper loaded: url_helper
INFO - 2016-02-22 12:57:30 --> Helper loaded: file_helper
INFO - 2016-02-22 12:57:30 --> Helper loaded: date_helper
INFO - 2016-02-22 12:57:30 --> Helper loaded: form_helper
INFO - 2016-02-22 12:57:30 --> Database Driver Class Initialized
INFO - 2016-02-22 12:57:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:57:31 --> Controller Class Initialized
INFO - 2016-02-22 12:57:31 --> Model Class Initialized
INFO - 2016-02-22 12:57:31 --> Model Class Initialized
INFO - 2016-02-22 12:57:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:57:31 --> Pagination Class Initialized
INFO - 2016-02-22 12:57:31 --> Helper loaded: text_helper
INFO - 2016-02-22 12:57:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:57:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:57:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:57:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 15:57:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:57:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:57:31 --> Final output sent to browser
DEBUG - 2016-02-22 15:57:31 --> Total execution time: 1.1628
INFO - 2016-02-22 12:57:32 --> Config Class Initialized
INFO - 2016-02-22 12:57:32 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:57:32 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:57:32 --> Utf8 Class Initialized
INFO - 2016-02-22 12:57:32 --> URI Class Initialized
INFO - 2016-02-22 12:57:32 --> Router Class Initialized
INFO - 2016-02-22 12:57:32 --> Output Class Initialized
INFO - 2016-02-22 12:57:32 --> Security Class Initialized
DEBUG - 2016-02-22 12:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:57:32 --> Input Class Initialized
INFO - 2016-02-22 12:57:32 --> Language Class Initialized
INFO - 2016-02-22 12:57:32 --> Loader Class Initialized
INFO - 2016-02-22 12:57:32 --> Helper loaded: url_helper
INFO - 2016-02-22 12:57:32 --> Helper loaded: file_helper
INFO - 2016-02-22 12:57:32 --> Helper loaded: date_helper
INFO - 2016-02-22 12:57:32 --> Helper loaded: form_helper
INFO - 2016-02-22 12:57:32 --> Database Driver Class Initialized
INFO - 2016-02-22 12:57:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:57:33 --> Controller Class Initialized
INFO - 2016-02-22 12:57:33 --> Model Class Initialized
INFO - 2016-02-22 12:57:33 --> Model Class Initialized
INFO - 2016-02-22 12:57:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:57:33 --> Pagination Class Initialized
INFO - 2016-02-22 12:57:33 --> Helper loaded: text_helper
INFO - 2016-02-22 12:57:33 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 15:57:33 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 15:57:33 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 15:57:33 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 15:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 15:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:57:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:57:33 --> Final output sent to browser
DEBUG - 2016-02-22 15:57:33 --> Total execution time: 1.1659
INFO - 2016-02-22 12:57:57 --> Config Class Initialized
INFO - 2016-02-22 12:57:57 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:57:57 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:57:57 --> Utf8 Class Initialized
INFO - 2016-02-22 12:57:57 --> URI Class Initialized
INFO - 2016-02-22 12:57:57 --> Router Class Initialized
INFO - 2016-02-22 12:57:57 --> Output Class Initialized
INFO - 2016-02-22 12:57:57 --> Security Class Initialized
DEBUG - 2016-02-22 12:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:57:57 --> Input Class Initialized
INFO - 2016-02-22 12:57:57 --> Language Class Initialized
INFO - 2016-02-22 12:57:57 --> Loader Class Initialized
INFO - 2016-02-22 12:57:57 --> Helper loaded: url_helper
INFO - 2016-02-22 12:57:57 --> Helper loaded: file_helper
INFO - 2016-02-22 12:57:57 --> Helper loaded: date_helper
INFO - 2016-02-22 12:57:57 --> Helper loaded: form_helper
INFO - 2016-02-22 12:57:57 --> Database Driver Class Initialized
INFO - 2016-02-22 12:57:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:57:58 --> Controller Class Initialized
INFO - 2016-02-22 12:57:58 --> Model Class Initialized
INFO - 2016-02-22 12:57:58 --> Model Class Initialized
INFO - 2016-02-22 12:57:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:57:58 --> Pagination Class Initialized
INFO - 2016-02-22 12:57:58 --> Helper loaded: text_helper
INFO - 2016-02-22 12:57:58 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 15:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:57:58 --> Final output sent to browser
DEBUG - 2016-02-22 15:57:58 --> Total execution time: 1.1414
INFO - 2016-02-22 12:57:59 --> Config Class Initialized
INFO - 2016-02-22 12:57:59 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:57:59 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:57:59 --> Utf8 Class Initialized
INFO - 2016-02-22 12:57:59 --> URI Class Initialized
INFO - 2016-02-22 12:57:59 --> Router Class Initialized
INFO - 2016-02-22 12:57:59 --> Output Class Initialized
INFO - 2016-02-22 12:57:59 --> Security Class Initialized
DEBUG - 2016-02-22 12:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:57:59 --> Input Class Initialized
INFO - 2016-02-22 12:57:59 --> Language Class Initialized
INFO - 2016-02-22 12:57:59 --> Loader Class Initialized
INFO - 2016-02-22 12:57:59 --> Helper loaded: url_helper
INFO - 2016-02-22 12:57:59 --> Helper loaded: file_helper
INFO - 2016-02-22 12:57:59 --> Helper loaded: date_helper
INFO - 2016-02-22 12:57:59 --> Helper loaded: form_helper
INFO - 2016-02-22 12:57:59 --> Database Driver Class Initialized
INFO - 2016-02-22 12:58:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:58:00 --> Controller Class Initialized
INFO - 2016-02-22 12:58:00 --> Model Class Initialized
INFO - 2016-02-22 12:58:00 --> Model Class Initialized
INFO - 2016-02-22 12:58:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:58:00 --> Pagination Class Initialized
INFO - 2016-02-22 12:58:00 --> Helper loaded: text_helper
INFO - 2016-02-22 12:58:00 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:58:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:58:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:58:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 15:58:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:58:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:58:00 --> Final output sent to browser
DEBUG - 2016-02-22 15:58:00 --> Total execution time: 1.1894
INFO - 2016-02-22 12:58:02 --> Config Class Initialized
INFO - 2016-02-22 12:58:02 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:58:02 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:58:02 --> Utf8 Class Initialized
INFO - 2016-02-22 12:58:02 --> URI Class Initialized
INFO - 2016-02-22 12:58:02 --> Router Class Initialized
INFO - 2016-02-22 12:58:02 --> Output Class Initialized
INFO - 2016-02-22 12:58:02 --> Security Class Initialized
DEBUG - 2016-02-22 12:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:58:02 --> Input Class Initialized
INFO - 2016-02-22 12:58:02 --> Language Class Initialized
INFO - 2016-02-22 12:58:02 --> Loader Class Initialized
INFO - 2016-02-22 12:58:02 --> Helper loaded: url_helper
INFO - 2016-02-22 12:58:02 --> Helper loaded: file_helper
INFO - 2016-02-22 12:58:02 --> Helper loaded: date_helper
INFO - 2016-02-22 12:58:02 --> Helper loaded: form_helper
INFO - 2016-02-22 12:58:02 --> Database Driver Class Initialized
INFO - 2016-02-22 12:58:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:58:03 --> Controller Class Initialized
INFO - 2016-02-22 12:58:03 --> Model Class Initialized
INFO - 2016-02-22 12:58:03 --> Model Class Initialized
INFO - 2016-02-22 12:58:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:58:03 --> Pagination Class Initialized
INFO - 2016-02-22 12:58:03 --> Helper loaded: text_helper
INFO - 2016-02-22 12:58:03 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 15:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 15:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:58:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:58:03 --> Final output sent to browser
DEBUG - 2016-02-22 15:58:03 --> Total execution time: 1.1438
INFO - 2016-02-22 12:58:07 --> Config Class Initialized
INFO - 2016-02-22 12:58:07 --> Hooks Class Initialized
DEBUG - 2016-02-22 12:58:07 --> UTF-8 Support Enabled
INFO - 2016-02-22 12:58:07 --> Utf8 Class Initialized
INFO - 2016-02-22 12:58:07 --> URI Class Initialized
INFO - 2016-02-22 12:58:07 --> Router Class Initialized
INFO - 2016-02-22 12:58:07 --> Output Class Initialized
INFO - 2016-02-22 12:58:07 --> Security Class Initialized
DEBUG - 2016-02-22 12:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 12:58:07 --> Input Class Initialized
INFO - 2016-02-22 12:58:07 --> Language Class Initialized
INFO - 2016-02-22 12:58:07 --> Loader Class Initialized
INFO - 2016-02-22 12:58:07 --> Helper loaded: url_helper
INFO - 2016-02-22 12:58:07 --> Helper loaded: file_helper
INFO - 2016-02-22 12:58:07 --> Helper loaded: date_helper
INFO - 2016-02-22 12:58:07 --> Helper loaded: form_helper
INFO - 2016-02-22 12:58:07 --> Database Driver Class Initialized
INFO - 2016-02-22 12:58:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 12:58:08 --> Controller Class Initialized
INFO - 2016-02-22 12:58:08 --> Model Class Initialized
INFO - 2016-02-22 12:58:08 --> Model Class Initialized
INFO - 2016-02-22 12:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 12:58:08 --> Pagination Class Initialized
INFO - 2016-02-22 12:58:08 --> Helper loaded: text_helper
INFO - 2016-02-22 12:58:08 --> Helper loaded: cookie_helper
INFO - 2016-02-22 15:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 15:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 15:58:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 15:58:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 15:58:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 15:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 15:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 15:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 15:58:08 --> Final output sent to browser
DEBUG - 2016-02-22 15:58:08 --> Total execution time: 1.1609
INFO - 2016-02-22 13:02:54 --> Config Class Initialized
INFO - 2016-02-22 13:02:54 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:02:54 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:02:54 --> Utf8 Class Initialized
INFO - 2016-02-22 13:02:54 --> URI Class Initialized
INFO - 2016-02-22 13:02:54 --> Router Class Initialized
INFO - 2016-02-22 13:02:54 --> Output Class Initialized
INFO - 2016-02-22 13:02:54 --> Security Class Initialized
DEBUG - 2016-02-22 13:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:02:54 --> Input Class Initialized
INFO - 2016-02-22 13:02:54 --> Language Class Initialized
INFO - 2016-02-22 13:02:54 --> Loader Class Initialized
INFO - 2016-02-22 13:02:54 --> Helper loaded: url_helper
INFO - 2016-02-22 13:02:54 --> Helper loaded: file_helper
INFO - 2016-02-22 13:02:54 --> Helper loaded: date_helper
INFO - 2016-02-22 13:02:54 --> Helper loaded: form_helper
INFO - 2016-02-22 13:02:54 --> Database Driver Class Initialized
INFO - 2016-02-22 13:02:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:02:55 --> Controller Class Initialized
INFO - 2016-02-22 13:02:55 --> Model Class Initialized
INFO - 2016-02-22 13:02:55 --> Model Class Initialized
INFO - 2016-02-22 13:02:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:02:55 --> Pagination Class Initialized
INFO - 2016-02-22 13:02:55 --> Helper loaded: text_helper
INFO - 2016-02-22 13:02:55 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:02:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:02:55 --> Final output sent to browser
DEBUG - 2016-02-22 16:02:55 --> Total execution time: 1.1639
INFO - 2016-02-22 13:03:02 --> Config Class Initialized
INFO - 2016-02-22 13:03:02 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:03:02 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:03:02 --> Utf8 Class Initialized
INFO - 2016-02-22 13:03:02 --> URI Class Initialized
INFO - 2016-02-22 13:03:02 --> Router Class Initialized
INFO - 2016-02-22 13:03:02 --> Output Class Initialized
INFO - 2016-02-22 13:03:02 --> Security Class Initialized
DEBUG - 2016-02-22 13:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:03:02 --> Input Class Initialized
INFO - 2016-02-22 13:03:02 --> Language Class Initialized
INFO - 2016-02-22 13:03:02 --> Loader Class Initialized
INFO - 2016-02-22 13:03:02 --> Helper loaded: url_helper
INFO - 2016-02-22 13:03:02 --> Helper loaded: file_helper
INFO - 2016-02-22 13:03:02 --> Helper loaded: date_helper
INFO - 2016-02-22 13:03:02 --> Helper loaded: form_helper
INFO - 2016-02-22 13:03:02 --> Database Driver Class Initialized
INFO - 2016-02-22 13:03:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:03:03 --> Controller Class Initialized
INFO - 2016-02-22 13:03:03 --> Model Class Initialized
INFO - 2016-02-22 13:03:03 --> Model Class Initialized
INFO - 2016-02-22 13:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:03:03 --> Pagination Class Initialized
INFO - 2016-02-22 13:03:03 --> Helper loaded: text_helper
INFO - 2016-02-22 13:03:03 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 16:03:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 16:03:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 16:03:03 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 16:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:03:03 --> Final output sent to browser
DEBUG - 2016-02-22 16:03:03 --> Total execution time: 1.1041
INFO - 2016-02-22 13:04:27 --> Config Class Initialized
INFO - 2016-02-22 13:04:27 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:04:27 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:04:27 --> Utf8 Class Initialized
INFO - 2016-02-22 13:04:27 --> URI Class Initialized
INFO - 2016-02-22 13:04:27 --> Router Class Initialized
INFO - 2016-02-22 13:04:27 --> Output Class Initialized
INFO - 2016-02-22 13:04:27 --> Security Class Initialized
DEBUG - 2016-02-22 13:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:04:27 --> Input Class Initialized
INFO - 2016-02-22 13:04:27 --> Language Class Initialized
INFO - 2016-02-22 13:04:27 --> Loader Class Initialized
INFO - 2016-02-22 13:04:27 --> Helper loaded: url_helper
INFO - 2016-02-22 13:04:27 --> Helper loaded: file_helper
INFO - 2016-02-22 13:04:27 --> Helper loaded: date_helper
INFO - 2016-02-22 13:04:27 --> Helper loaded: form_helper
INFO - 2016-02-22 13:04:27 --> Database Driver Class Initialized
INFO - 2016-02-22 13:04:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:04:28 --> Controller Class Initialized
INFO - 2016-02-22 13:04:28 --> Model Class Initialized
INFO - 2016-02-22 13:04:28 --> Model Class Initialized
INFO - 2016-02-22 13:04:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:04:28 --> Pagination Class Initialized
INFO - 2016-02-22 13:04:28 --> Helper loaded: text_helper
INFO - 2016-02-22 13:04:28 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:04:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:04:28 --> Final output sent to browser
DEBUG - 2016-02-22 16:04:28 --> Total execution time: 1.1549
INFO - 2016-02-22 13:04:30 --> Config Class Initialized
INFO - 2016-02-22 13:04:30 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:04:30 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:04:30 --> Utf8 Class Initialized
INFO - 2016-02-22 13:04:30 --> URI Class Initialized
INFO - 2016-02-22 13:04:30 --> Router Class Initialized
INFO - 2016-02-22 13:04:30 --> Output Class Initialized
INFO - 2016-02-22 13:04:30 --> Security Class Initialized
DEBUG - 2016-02-22 13:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:04:30 --> Input Class Initialized
INFO - 2016-02-22 13:04:30 --> Language Class Initialized
INFO - 2016-02-22 13:04:30 --> Loader Class Initialized
INFO - 2016-02-22 13:04:30 --> Helper loaded: url_helper
INFO - 2016-02-22 13:04:30 --> Helper loaded: file_helper
INFO - 2016-02-22 13:04:30 --> Helper loaded: date_helper
INFO - 2016-02-22 13:04:30 --> Helper loaded: form_helper
INFO - 2016-02-22 13:04:30 --> Database Driver Class Initialized
INFO - 2016-02-22 13:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:04:31 --> Controller Class Initialized
INFO - 2016-02-22 13:04:31 --> Model Class Initialized
INFO - 2016-02-22 13:04:31 --> Model Class Initialized
INFO - 2016-02-22 13:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:04:31 --> Pagination Class Initialized
INFO - 2016-02-22 13:04:31 --> Helper loaded: text_helper
INFO - 2016-02-22 13:04:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 16:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 16:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 16:04:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 16:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:04:31 --> Final output sent to browser
DEBUG - 2016-02-22 16:04:31 --> Total execution time: 1.1669
INFO - 2016-02-22 13:04:33 --> Config Class Initialized
INFO - 2016-02-22 13:04:33 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:04:33 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:04:33 --> Utf8 Class Initialized
INFO - 2016-02-22 13:04:33 --> URI Class Initialized
INFO - 2016-02-22 13:04:33 --> Router Class Initialized
INFO - 2016-02-22 13:04:33 --> Output Class Initialized
INFO - 2016-02-22 13:04:33 --> Security Class Initialized
DEBUG - 2016-02-22 13:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:04:33 --> Input Class Initialized
INFO - 2016-02-22 13:04:33 --> Language Class Initialized
INFO - 2016-02-22 13:04:33 --> Loader Class Initialized
INFO - 2016-02-22 13:04:33 --> Helper loaded: url_helper
INFO - 2016-02-22 13:04:33 --> Helper loaded: file_helper
INFO - 2016-02-22 13:04:33 --> Helper loaded: date_helper
INFO - 2016-02-22 13:04:33 --> Helper loaded: form_helper
INFO - 2016-02-22 13:04:33 --> Database Driver Class Initialized
INFO - 2016-02-22 13:04:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:04:34 --> Controller Class Initialized
INFO - 2016-02-22 13:04:34 --> Model Class Initialized
INFO - 2016-02-22 13:04:34 --> Model Class Initialized
INFO - 2016-02-22 13:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:04:34 --> Pagination Class Initialized
INFO - 2016-02-22 13:04:34 --> Helper loaded: text_helper
INFO - 2016-02-22 13:04:34 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:04:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:04:34 --> Final output sent to browser
DEBUG - 2016-02-22 16:04:35 --> Total execution time: 1.1120
INFO - 2016-02-22 13:07:41 --> Config Class Initialized
INFO - 2016-02-22 13:07:41 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:07:41 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:07:41 --> Utf8 Class Initialized
INFO - 2016-02-22 13:07:41 --> URI Class Initialized
INFO - 2016-02-22 13:07:41 --> Router Class Initialized
INFO - 2016-02-22 13:07:41 --> Output Class Initialized
INFO - 2016-02-22 13:07:41 --> Security Class Initialized
DEBUG - 2016-02-22 13:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:07:41 --> Input Class Initialized
INFO - 2016-02-22 13:07:41 --> Language Class Initialized
INFO - 2016-02-22 13:07:41 --> Loader Class Initialized
INFO - 2016-02-22 13:07:41 --> Helper loaded: url_helper
INFO - 2016-02-22 13:07:41 --> Helper loaded: file_helper
INFO - 2016-02-22 13:07:41 --> Helper loaded: date_helper
INFO - 2016-02-22 13:07:41 --> Helper loaded: form_helper
INFO - 2016-02-22 13:07:41 --> Database Driver Class Initialized
INFO - 2016-02-22 13:07:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:07:42 --> Controller Class Initialized
INFO - 2016-02-22 13:07:42 --> Model Class Initialized
INFO - 2016-02-22 13:07:42 --> Model Class Initialized
INFO - 2016-02-22 13:07:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:07:42 --> Pagination Class Initialized
INFO - 2016-02-22 13:07:42 --> Helper loaded: text_helper
INFO - 2016-02-22 13:07:42 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:07:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:07:42 --> Final output sent to browser
DEBUG - 2016-02-22 16:07:42 --> Total execution time: 1.1794
INFO - 2016-02-22 13:07:43 --> Config Class Initialized
INFO - 2016-02-22 13:07:43 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:07:44 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:07:44 --> Utf8 Class Initialized
INFO - 2016-02-22 13:07:44 --> URI Class Initialized
INFO - 2016-02-22 13:07:44 --> Router Class Initialized
INFO - 2016-02-22 13:07:44 --> Output Class Initialized
INFO - 2016-02-22 13:07:44 --> Security Class Initialized
DEBUG - 2016-02-22 13:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:07:44 --> Input Class Initialized
INFO - 2016-02-22 13:07:44 --> Language Class Initialized
INFO - 2016-02-22 13:07:44 --> Loader Class Initialized
INFO - 2016-02-22 13:07:44 --> Helper loaded: url_helper
INFO - 2016-02-22 13:07:44 --> Helper loaded: file_helper
INFO - 2016-02-22 13:07:44 --> Helper loaded: date_helper
INFO - 2016-02-22 13:07:44 --> Helper loaded: form_helper
INFO - 2016-02-22 13:07:44 --> Database Driver Class Initialized
INFO - 2016-02-22 13:07:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:07:45 --> Controller Class Initialized
INFO - 2016-02-22 13:07:45 --> Model Class Initialized
INFO - 2016-02-22 13:07:45 --> Model Class Initialized
INFO - 2016-02-22 13:07:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:07:45 --> Pagination Class Initialized
INFO - 2016-02-22 13:07:45 --> Helper loaded: text_helper
INFO - 2016-02-22 13:07:45 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:07:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:07:45 --> Final output sent to browser
DEBUG - 2016-02-22 16:07:45 --> Total execution time: 1.1581
INFO - 2016-02-22 13:07:46 --> Config Class Initialized
INFO - 2016-02-22 13:07:46 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:07:46 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:07:46 --> Utf8 Class Initialized
INFO - 2016-02-22 13:07:46 --> URI Class Initialized
INFO - 2016-02-22 13:07:46 --> Router Class Initialized
INFO - 2016-02-22 13:07:46 --> Output Class Initialized
INFO - 2016-02-22 13:07:46 --> Security Class Initialized
DEBUG - 2016-02-22 13:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:07:46 --> Input Class Initialized
INFO - 2016-02-22 13:07:46 --> Language Class Initialized
INFO - 2016-02-22 13:07:46 --> Loader Class Initialized
INFO - 2016-02-22 13:07:46 --> Helper loaded: url_helper
INFO - 2016-02-22 13:07:46 --> Helper loaded: file_helper
INFO - 2016-02-22 13:07:46 --> Helper loaded: date_helper
INFO - 2016-02-22 13:07:46 --> Helper loaded: form_helper
INFO - 2016-02-22 13:07:46 --> Database Driver Class Initialized
INFO - 2016-02-22 13:07:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:07:47 --> Controller Class Initialized
INFO - 2016-02-22 13:07:47 --> Model Class Initialized
INFO - 2016-02-22 13:07:47 --> Model Class Initialized
INFO - 2016-02-22 13:07:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:07:47 --> Pagination Class Initialized
INFO - 2016-02-22 13:07:47 --> Helper loaded: text_helper
INFO - 2016-02-22 13:07:47 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:07:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:07:47 --> Final output sent to browser
DEBUG - 2016-02-22 16:07:47 --> Total execution time: 1.1213
INFO - 2016-02-22 13:07:50 --> Config Class Initialized
INFO - 2016-02-22 13:07:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:07:50 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:07:50 --> Utf8 Class Initialized
INFO - 2016-02-22 13:07:50 --> URI Class Initialized
INFO - 2016-02-22 13:07:50 --> Router Class Initialized
INFO - 2016-02-22 13:07:50 --> Output Class Initialized
INFO - 2016-02-22 13:07:50 --> Security Class Initialized
DEBUG - 2016-02-22 13:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:07:50 --> Input Class Initialized
INFO - 2016-02-22 13:07:50 --> Language Class Initialized
INFO - 2016-02-22 13:07:50 --> Loader Class Initialized
INFO - 2016-02-22 13:07:50 --> Helper loaded: url_helper
INFO - 2016-02-22 13:07:50 --> Helper loaded: file_helper
INFO - 2016-02-22 13:07:50 --> Helper loaded: date_helper
INFO - 2016-02-22 13:07:50 --> Helper loaded: form_helper
INFO - 2016-02-22 13:07:50 --> Database Driver Class Initialized
INFO - 2016-02-22 13:07:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:07:51 --> Controller Class Initialized
INFO - 2016-02-22 13:07:51 --> Model Class Initialized
INFO - 2016-02-22 13:07:51 --> Model Class Initialized
INFO - 2016-02-22 13:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:07:51 --> Pagination Class Initialized
INFO - 2016-02-22 13:07:51 --> Helper loaded: text_helper
INFO - 2016-02-22 13:07:51 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 16:07:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 16:07:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 16:07:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 16:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:07:51 --> Final output sent to browser
DEBUG - 2016-02-22 16:07:51 --> Total execution time: 1.1773
INFO - 2016-02-22 13:08:25 --> Config Class Initialized
INFO - 2016-02-22 13:08:25 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:08:25 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:08:25 --> Utf8 Class Initialized
INFO - 2016-02-22 13:08:25 --> URI Class Initialized
INFO - 2016-02-22 13:08:25 --> Router Class Initialized
INFO - 2016-02-22 13:08:25 --> Output Class Initialized
INFO - 2016-02-22 13:08:25 --> Security Class Initialized
DEBUG - 2016-02-22 13:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:08:25 --> Input Class Initialized
INFO - 2016-02-22 13:08:25 --> Language Class Initialized
INFO - 2016-02-22 13:08:25 --> Loader Class Initialized
INFO - 2016-02-22 13:08:25 --> Helper loaded: url_helper
INFO - 2016-02-22 13:08:25 --> Helper loaded: file_helper
INFO - 2016-02-22 13:08:25 --> Helper loaded: date_helper
INFO - 2016-02-22 13:08:25 --> Helper loaded: form_helper
INFO - 2016-02-22 13:08:25 --> Database Driver Class Initialized
INFO - 2016-02-22 13:08:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:08:27 --> Controller Class Initialized
INFO - 2016-02-22 13:08:27 --> Model Class Initialized
INFO - 2016-02-22 13:08:27 --> Model Class Initialized
INFO - 2016-02-22 13:08:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:08:27 --> Pagination Class Initialized
INFO - 2016-02-22 13:08:27 --> Helper loaded: text_helper
INFO - 2016-02-22 13:08:27 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:08:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:08:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:08:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:08:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:08:27 --> Final output sent to browser
DEBUG - 2016-02-22 16:08:27 --> Total execution time: 1.1348
INFO - 2016-02-22 13:08:28 --> Config Class Initialized
INFO - 2016-02-22 13:08:28 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:08:28 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:08:28 --> Utf8 Class Initialized
INFO - 2016-02-22 13:08:28 --> URI Class Initialized
INFO - 2016-02-22 13:08:29 --> Router Class Initialized
INFO - 2016-02-22 13:08:29 --> Output Class Initialized
INFO - 2016-02-22 13:08:29 --> Security Class Initialized
DEBUG - 2016-02-22 13:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:08:29 --> Input Class Initialized
INFO - 2016-02-22 13:08:29 --> Language Class Initialized
INFO - 2016-02-22 13:08:29 --> Loader Class Initialized
INFO - 2016-02-22 13:08:29 --> Helper loaded: url_helper
INFO - 2016-02-22 13:08:29 --> Helper loaded: file_helper
INFO - 2016-02-22 13:08:29 --> Helper loaded: date_helper
INFO - 2016-02-22 13:08:29 --> Helper loaded: form_helper
INFO - 2016-02-22 13:08:29 --> Database Driver Class Initialized
INFO - 2016-02-22 13:08:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:08:30 --> Controller Class Initialized
INFO - 2016-02-22 13:08:30 --> Model Class Initialized
INFO - 2016-02-22 13:08:30 --> Model Class Initialized
INFO - 2016-02-22 13:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:08:30 --> Pagination Class Initialized
INFO - 2016-02-22 13:08:30 --> Helper loaded: text_helper
INFO - 2016-02-22 13:08:30 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:08:30 --> Final output sent to browser
DEBUG - 2016-02-22 16:08:30 --> Total execution time: 1.2377
INFO - 2016-02-22 13:08:31 --> Config Class Initialized
INFO - 2016-02-22 13:08:31 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:08:31 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:08:31 --> Utf8 Class Initialized
INFO - 2016-02-22 13:08:31 --> URI Class Initialized
INFO - 2016-02-22 13:08:31 --> Router Class Initialized
INFO - 2016-02-22 13:08:31 --> Output Class Initialized
INFO - 2016-02-22 13:08:31 --> Security Class Initialized
DEBUG - 2016-02-22 13:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:08:31 --> Input Class Initialized
INFO - 2016-02-22 13:08:31 --> Language Class Initialized
INFO - 2016-02-22 13:08:32 --> Loader Class Initialized
INFO - 2016-02-22 13:08:32 --> Helper loaded: url_helper
INFO - 2016-02-22 13:08:32 --> Helper loaded: file_helper
INFO - 2016-02-22 13:08:32 --> Helper loaded: date_helper
INFO - 2016-02-22 13:08:32 --> Helper loaded: form_helper
INFO - 2016-02-22 13:08:32 --> Database Driver Class Initialized
INFO - 2016-02-22 13:08:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:08:33 --> Controller Class Initialized
INFO - 2016-02-22 13:08:33 --> Model Class Initialized
INFO - 2016-02-22 13:08:33 --> Model Class Initialized
INFO - 2016-02-22 13:08:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:08:33 --> Pagination Class Initialized
INFO - 2016-02-22 13:08:33 --> Helper loaded: text_helper
INFO - 2016-02-22 13:08:33 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:08:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:08:33 --> Final output sent to browser
DEBUG - 2016-02-22 16:08:33 --> Total execution time: 1.0994
INFO - 2016-02-22 13:08:34 --> Config Class Initialized
INFO - 2016-02-22 13:08:34 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:08:34 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:08:34 --> Utf8 Class Initialized
INFO - 2016-02-22 13:08:34 --> URI Class Initialized
INFO - 2016-02-22 13:08:34 --> Router Class Initialized
INFO - 2016-02-22 13:08:34 --> Output Class Initialized
INFO - 2016-02-22 13:08:34 --> Security Class Initialized
DEBUG - 2016-02-22 13:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:08:34 --> Input Class Initialized
INFO - 2016-02-22 13:08:34 --> Language Class Initialized
INFO - 2016-02-22 13:08:34 --> Loader Class Initialized
INFO - 2016-02-22 13:08:34 --> Helper loaded: url_helper
INFO - 2016-02-22 13:08:34 --> Helper loaded: file_helper
INFO - 2016-02-22 13:08:34 --> Helper loaded: date_helper
INFO - 2016-02-22 13:08:34 --> Helper loaded: form_helper
INFO - 2016-02-22 13:08:34 --> Database Driver Class Initialized
INFO - 2016-02-22 13:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:08:35 --> Controller Class Initialized
INFO - 2016-02-22 13:08:35 --> Model Class Initialized
INFO - 2016-02-22 13:08:35 --> Model Class Initialized
INFO - 2016-02-22 13:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:08:35 --> Pagination Class Initialized
INFO - 2016-02-22 13:08:35 --> Helper loaded: text_helper
INFO - 2016-02-22 13:08:35 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 16:08:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 16:08:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 16:08:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 16:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:08:35 --> Final output sent to browser
DEBUG - 2016-02-22 16:08:35 --> Total execution time: 1.1558
INFO - 2016-02-22 13:09:39 --> Config Class Initialized
INFO - 2016-02-22 13:09:39 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:09:39 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:09:39 --> Utf8 Class Initialized
INFO - 2016-02-22 13:09:39 --> URI Class Initialized
INFO - 2016-02-22 13:09:39 --> Router Class Initialized
INFO - 2016-02-22 13:09:39 --> Output Class Initialized
INFO - 2016-02-22 13:09:39 --> Security Class Initialized
DEBUG - 2016-02-22 13:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:09:39 --> Input Class Initialized
INFO - 2016-02-22 13:09:39 --> Language Class Initialized
INFO - 2016-02-22 13:09:39 --> Loader Class Initialized
INFO - 2016-02-22 13:09:39 --> Helper loaded: url_helper
INFO - 2016-02-22 13:09:39 --> Helper loaded: file_helper
INFO - 2016-02-22 13:09:39 --> Helper loaded: date_helper
INFO - 2016-02-22 13:09:39 --> Helper loaded: form_helper
INFO - 2016-02-22 13:09:39 --> Database Driver Class Initialized
INFO - 2016-02-22 13:09:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:09:40 --> Controller Class Initialized
INFO - 2016-02-22 13:09:40 --> Model Class Initialized
INFO - 2016-02-22 13:09:40 --> Model Class Initialized
INFO - 2016-02-22 13:09:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:09:40 --> Pagination Class Initialized
INFO - 2016-02-22 13:09:40 --> Helper loaded: text_helper
INFO - 2016-02-22 13:09:40 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:09:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:09:40 --> Final output sent to browser
DEBUG - 2016-02-22 16:09:40 --> Total execution time: 1.1396
INFO - 2016-02-22 13:09:41 --> Config Class Initialized
INFO - 2016-02-22 13:09:41 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:09:41 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:09:41 --> Utf8 Class Initialized
INFO - 2016-02-22 13:09:41 --> URI Class Initialized
INFO - 2016-02-22 13:09:41 --> Router Class Initialized
INFO - 2016-02-22 13:09:41 --> Output Class Initialized
INFO - 2016-02-22 13:09:41 --> Security Class Initialized
DEBUG - 2016-02-22 13:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:09:41 --> Input Class Initialized
INFO - 2016-02-22 13:09:41 --> Language Class Initialized
INFO - 2016-02-22 13:09:41 --> Loader Class Initialized
INFO - 2016-02-22 13:09:41 --> Helper loaded: url_helper
INFO - 2016-02-22 13:09:41 --> Helper loaded: file_helper
INFO - 2016-02-22 13:09:41 --> Helper loaded: date_helper
INFO - 2016-02-22 13:09:41 --> Helper loaded: form_helper
INFO - 2016-02-22 13:09:41 --> Database Driver Class Initialized
INFO - 2016-02-22 13:09:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:09:42 --> Controller Class Initialized
INFO - 2016-02-22 13:09:42 --> Model Class Initialized
INFO - 2016-02-22 13:09:43 --> Model Class Initialized
INFO - 2016-02-22 13:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:09:43 --> Pagination Class Initialized
INFO - 2016-02-22 13:09:43 --> Helper loaded: text_helper
INFO - 2016-02-22 13:09:43 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:09:43 --> Final output sent to browser
DEBUG - 2016-02-22 16:09:43 --> Total execution time: 1.1756
INFO - 2016-02-22 13:09:46 --> Config Class Initialized
INFO - 2016-02-22 13:09:46 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:09:46 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:09:46 --> Utf8 Class Initialized
INFO - 2016-02-22 13:09:46 --> URI Class Initialized
INFO - 2016-02-22 13:09:46 --> Router Class Initialized
INFO - 2016-02-22 13:09:46 --> Output Class Initialized
INFO - 2016-02-22 13:09:46 --> Security Class Initialized
DEBUG - 2016-02-22 13:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:09:46 --> Input Class Initialized
INFO - 2016-02-22 13:09:46 --> Language Class Initialized
INFO - 2016-02-22 13:09:46 --> Loader Class Initialized
INFO - 2016-02-22 13:09:46 --> Helper loaded: url_helper
INFO - 2016-02-22 13:09:46 --> Helper loaded: file_helper
INFO - 2016-02-22 13:09:46 --> Helper loaded: date_helper
INFO - 2016-02-22 13:09:46 --> Helper loaded: form_helper
INFO - 2016-02-22 13:09:46 --> Database Driver Class Initialized
INFO - 2016-02-22 13:09:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:09:47 --> Controller Class Initialized
INFO - 2016-02-22 13:09:47 --> Model Class Initialized
INFO - 2016-02-22 13:09:47 --> Model Class Initialized
INFO - 2016-02-22 13:09:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:09:47 --> Pagination Class Initialized
INFO - 2016-02-22 13:09:47 --> Helper loaded: text_helper
INFO - 2016-02-22 13:09:47 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:09:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:09:47 --> Final output sent to browser
DEBUG - 2016-02-22 16:09:47 --> Total execution time: 1.1260
INFO - 2016-02-22 13:14:26 --> Config Class Initialized
INFO - 2016-02-22 13:14:26 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:14:26 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:14:26 --> Utf8 Class Initialized
INFO - 2016-02-22 13:14:26 --> URI Class Initialized
INFO - 2016-02-22 13:14:26 --> Router Class Initialized
INFO - 2016-02-22 13:14:26 --> Output Class Initialized
INFO - 2016-02-22 13:14:26 --> Security Class Initialized
DEBUG - 2016-02-22 13:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:14:26 --> Input Class Initialized
INFO - 2016-02-22 13:14:26 --> Language Class Initialized
INFO - 2016-02-22 13:14:26 --> Loader Class Initialized
INFO - 2016-02-22 13:14:26 --> Helper loaded: url_helper
INFO - 2016-02-22 13:14:26 --> Helper loaded: file_helper
INFO - 2016-02-22 13:14:26 --> Helper loaded: date_helper
INFO - 2016-02-22 13:14:26 --> Helper loaded: form_helper
INFO - 2016-02-22 13:14:26 --> Database Driver Class Initialized
INFO - 2016-02-22 13:14:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:14:27 --> Controller Class Initialized
INFO - 2016-02-22 13:14:27 --> Model Class Initialized
INFO - 2016-02-22 13:14:27 --> Model Class Initialized
INFO - 2016-02-22 13:14:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:14:27 --> Pagination Class Initialized
INFO - 2016-02-22 13:14:27 --> Helper loaded: text_helper
INFO - 2016-02-22 13:14:27 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:14:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:14:27 --> Final output sent to browser
DEBUG - 2016-02-22 16:14:27 --> Total execution time: 1.2008
INFO - 2016-02-22 13:14:28 --> Config Class Initialized
INFO - 2016-02-22 13:14:28 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:14:28 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:14:28 --> Utf8 Class Initialized
INFO - 2016-02-22 13:14:28 --> URI Class Initialized
INFO - 2016-02-22 13:14:28 --> Router Class Initialized
INFO - 2016-02-22 13:14:28 --> Output Class Initialized
INFO - 2016-02-22 13:14:28 --> Security Class Initialized
DEBUG - 2016-02-22 13:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:14:28 --> Input Class Initialized
INFO - 2016-02-22 13:14:28 --> Language Class Initialized
INFO - 2016-02-22 13:14:28 --> Loader Class Initialized
INFO - 2016-02-22 13:14:28 --> Helper loaded: url_helper
INFO - 2016-02-22 13:14:28 --> Helper loaded: file_helper
INFO - 2016-02-22 13:14:28 --> Helper loaded: date_helper
INFO - 2016-02-22 13:14:28 --> Helper loaded: form_helper
INFO - 2016-02-22 13:14:28 --> Database Driver Class Initialized
INFO - 2016-02-22 13:14:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:14:30 --> Controller Class Initialized
INFO - 2016-02-22 13:14:30 --> Model Class Initialized
INFO - 2016-02-22 13:14:30 --> Model Class Initialized
INFO - 2016-02-22 13:14:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:14:30 --> Pagination Class Initialized
INFO - 2016-02-22 13:14:30 --> Helper loaded: text_helper
INFO - 2016-02-22 13:14:30 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:14:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:14:30 --> Final output sent to browser
DEBUG - 2016-02-22 16:14:30 --> Total execution time: 1.1807
INFO - 2016-02-22 13:14:31 --> Config Class Initialized
INFO - 2016-02-22 13:14:31 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:14:31 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:14:31 --> Utf8 Class Initialized
INFO - 2016-02-22 13:14:31 --> URI Class Initialized
INFO - 2016-02-22 13:14:31 --> Router Class Initialized
INFO - 2016-02-22 13:14:31 --> Output Class Initialized
INFO - 2016-02-22 13:14:31 --> Security Class Initialized
DEBUG - 2016-02-22 13:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:14:31 --> Input Class Initialized
INFO - 2016-02-22 13:14:31 --> Language Class Initialized
INFO - 2016-02-22 13:14:31 --> Loader Class Initialized
INFO - 2016-02-22 13:14:31 --> Helper loaded: url_helper
INFO - 2016-02-22 13:14:31 --> Helper loaded: file_helper
INFO - 2016-02-22 13:14:31 --> Helper loaded: date_helper
INFO - 2016-02-22 13:14:31 --> Helper loaded: form_helper
INFO - 2016-02-22 13:14:31 --> Database Driver Class Initialized
INFO - 2016-02-22 13:14:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:14:32 --> Controller Class Initialized
INFO - 2016-02-22 13:14:32 --> Model Class Initialized
INFO - 2016-02-22 13:14:32 --> Model Class Initialized
INFO - 2016-02-22 13:14:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:14:32 --> Pagination Class Initialized
INFO - 2016-02-22 13:14:32 --> Helper loaded: text_helper
INFO - 2016-02-22 13:14:32 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:14:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:14:32 --> Final output sent to browser
DEBUG - 2016-02-22 16:14:32 --> Total execution time: 1.1180
INFO - 2016-02-22 13:14:34 --> Config Class Initialized
INFO - 2016-02-22 13:14:34 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:14:34 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:14:34 --> Utf8 Class Initialized
INFO - 2016-02-22 13:14:34 --> URI Class Initialized
INFO - 2016-02-22 13:14:34 --> Router Class Initialized
INFO - 2016-02-22 13:14:34 --> Output Class Initialized
INFO - 2016-02-22 13:14:34 --> Security Class Initialized
DEBUG - 2016-02-22 13:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:14:34 --> Input Class Initialized
INFO - 2016-02-22 13:14:34 --> Language Class Initialized
INFO - 2016-02-22 13:14:34 --> Loader Class Initialized
INFO - 2016-02-22 13:14:34 --> Helper loaded: url_helper
INFO - 2016-02-22 13:14:34 --> Helper loaded: file_helper
INFO - 2016-02-22 13:14:34 --> Helper loaded: date_helper
INFO - 2016-02-22 13:14:34 --> Helper loaded: form_helper
INFO - 2016-02-22 13:14:34 --> Database Driver Class Initialized
INFO - 2016-02-22 13:14:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:14:35 --> Controller Class Initialized
INFO - 2016-02-22 13:14:35 --> Model Class Initialized
INFO - 2016-02-22 13:14:35 --> Model Class Initialized
INFO - 2016-02-22 13:14:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:14:35 --> Pagination Class Initialized
INFO - 2016-02-22 13:14:35 --> Helper loaded: text_helper
INFO - 2016-02-22 13:14:35 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:14:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:14:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 16:14:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 16:14:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 16:14:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 16:14:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:14:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:14:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:14:35 --> Final output sent to browser
DEBUG - 2016-02-22 16:14:35 --> Total execution time: 1.1480
INFO - 2016-02-22 13:15:50 --> Config Class Initialized
INFO - 2016-02-22 13:15:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:15:50 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:15:50 --> Utf8 Class Initialized
INFO - 2016-02-22 13:15:50 --> URI Class Initialized
INFO - 2016-02-22 13:15:50 --> Router Class Initialized
INFO - 2016-02-22 13:15:50 --> Output Class Initialized
INFO - 2016-02-22 13:15:50 --> Security Class Initialized
DEBUG - 2016-02-22 13:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:15:50 --> Input Class Initialized
INFO - 2016-02-22 13:15:50 --> Language Class Initialized
INFO - 2016-02-22 13:15:50 --> Loader Class Initialized
INFO - 2016-02-22 13:15:50 --> Helper loaded: url_helper
INFO - 2016-02-22 13:15:50 --> Helper loaded: file_helper
INFO - 2016-02-22 13:15:50 --> Helper loaded: date_helper
INFO - 2016-02-22 13:15:50 --> Helper loaded: form_helper
INFO - 2016-02-22 13:15:50 --> Database Driver Class Initialized
INFO - 2016-02-22 13:15:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:15:51 --> Controller Class Initialized
INFO - 2016-02-22 13:15:51 --> Model Class Initialized
INFO - 2016-02-22 13:15:51 --> Model Class Initialized
INFO - 2016-02-22 13:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:15:51 --> Pagination Class Initialized
INFO - 2016-02-22 13:15:51 --> Helper loaded: text_helper
INFO - 2016-02-22 13:15:51 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:15:51 --> Final output sent to browser
DEBUG - 2016-02-22 16:15:51 --> Total execution time: 1.1343
INFO - 2016-02-22 13:15:53 --> Config Class Initialized
INFO - 2016-02-22 13:15:53 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:15:53 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:15:53 --> Utf8 Class Initialized
INFO - 2016-02-22 13:15:53 --> URI Class Initialized
INFO - 2016-02-22 13:15:53 --> Router Class Initialized
INFO - 2016-02-22 13:15:53 --> Output Class Initialized
INFO - 2016-02-22 13:15:53 --> Security Class Initialized
DEBUG - 2016-02-22 13:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:15:53 --> Input Class Initialized
INFO - 2016-02-22 13:15:53 --> Language Class Initialized
INFO - 2016-02-22 13:15:53 --> Loader Class Initialized
INFO - 2016-02-22 13:15:53 --> Helper loaded: url_helper
INFO - 2016-02-22 13:15:53 --> Helper loaded: file_helper
INFO - 2016-02-22 13:15:53 --> Helper loaded: date_helper
INFO - 2016-02-22 13:15:53 --> Helper loaded: form_helper
INFO - 2016-02-22 13:15:53 --> Database Driver Class Initialized
INFO - 2016-02-22 13:15:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:15:54 --> Controller Class Initialized
INFO - 2016-02-22 13:15:54 --> Model Class Initialized
INFO - 2016-02-22 13:15:54 --> Model Class Initialized
INFO - 2016-02-22 13:15:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:15:54 --> Pagination Class Initialized
INFO - 2016-02-22 13:15:54 --> Helper loaded: text_helper
INFO - 2016-02-22 13:15:54 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:15:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:15:54 --> Final output sent to browser
DEBUG - 2016-02-22 16:15:54 --> Total execution time: 1.1837
INFO - 2016-02-22 13:15:56 --> Config Class Initialized
INFO - 2016-02-22 13:15:56 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:15:56 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:15:56 --> Utf8 Class Initialized
INFO - 2016-02-22 13:15:56 --> URI Class Initialized
INFO - 2016-02-22 13:15:56 --> Router Class Initialized
INFO - 2016-02-22 13:15:56 --> Output Class Initialized
INFO - 2016-02-22 13:15:56 --> Security Class Initialized
DEBUG - 2016-02-22 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:15:56 --> Input Class Initialized
INFO - 2016-02-22 13:15:56 --> Language Class Initialized
INFO - 2016-02-22 13:15:56 --> Loader Class Initialized
INFO - 2016-02-22 13:15:56 --> Helper loaded: url_helper
INFO - 2016-02-22 13:15:56 --> Helper loaded: file_helper
INFO - 2016-02-22 13:15:56 --> Helper loaded: date_helper
INFO - 2016-02-22 13:15:56 --> Helper loaded: form_helper
INFO - 2016-02-22 13:15:56 --> Database Driver Class Initialized
INFO - 2016-02-22 13:15:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:15:57 --> Controller Class Initialized
INFO - 2016-02-22 13:15:57 --> Model Class Initialized
INFO - 2016-02-22 13:15:57 --> Model Class Initialized
INFO - 2016-02-22 13:15:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:15:57 --> Pagination Class Initialized
INFO - 2016-02-22 13:15:57 --> Helper loaded: text_helper
INFO - 2016-02-22 13:15:57 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:15:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:15:57 --> Final output sent to browser
DEBUG - 2016-02-22 16:15:57 --> Total execution time: 1.1640
INFO - 2016-02-22 13:15:58 --> Config Class Initialized
INFO - 2016-02-22 13:15:58 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:15:58 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:15:58 --> Utf8 Class Initialized
INFO - 2016-02-22 13:15:58 --> URI Class Initialized
INFO - 2016-02-22 13:15:58 --> Router Class Initialized
INFO - 2016-02-22 13:15:58 --> Output Class Initialized
INFO - 2016-02-22 13:15:58 --> Security Class Initialized
DEBUG - 2016-02-22 13:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:15:58 --> Input Class Initialized
INFO - 2016-02-22 13:15:58 --> Language Class Initialized
INFO - 2016-02-22 13:15:58 --> Loader Class Initialized
INFO - 2016-02-22 13:15:58 --> Helper loaded: url_helper
INFO - 2016-02-22 13:15:58 --> Helper loaded: file_helper
INFO - 2016-02-22 13:15:58 --> Helper loaded: date_helper
INFO - 2016-02-22 13:15:58 --> Helper loaded: form_helper
INFO - 2016-02-22 13:15:58 --> Database Driver Class Initialized
INFO - 2016-02-22 13:15:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:15:59 --> Controller Class Initialized
INFO - 2016-02-22 13:15:59 --> Model Class Initialized
INFO - 2016-02-22 13:15:59 --> Model Class Initialized
INFO - 2016-02-22 13:15:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:15:59 --> Pagination Class Initialized
INFO - 2016-02-22 13:15:59 --> Helper loaded: text_helper
INFO - 2016-02-22 13:15:59 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:15:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:15:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-22 16:15:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-02-22 16:15:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-02-22 16:15:59 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-02-22 16:15:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:15:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:15:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:15:59 --> Final output sent to browser
DEBUG - 2016-02-22 16:15:59 --> Total execution time: 1.1497
INFO - 2016-02-22 13:16:22 --> Config Class Initialized
INFO - 2016-02-22 13:16:22 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:16:22 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:16:22 --> Utf8 Class Initialized
INFO - 2016-02-22 13:16:22 --> URI Class Initialized
INFO - 2016-02-22 13:16:22 --> Router Class Initialized
INFO - 2016-02-22 13:16:22 --> Output Class Initialized
INFO - 2016-02-22 13:16:22 --> Security Class Initialized
DEBUG - 2016-02-22 13:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:16:22 --> Input Class Initialized
INFO - 2016-02-22 13:16:22 --> Language Class Initialized
INFO - 2016-02-22 13:16:22 --> Loader Class Initialized
INFO - 2016-02-22 13:16:22 --> Helper loaded: url_helper
INFO - 2016-02-22 13:16:22 --> Helper loaded: file_helper
INFO - 2016-02-22 13:16:22 --> Helper loaded: date_helper
INFO - 2016-02-22 13:16:22 --> Helper loaded: form_helper
INFO - 2016-02-22 13:16:22 --> Database Driver Class Initialized
INFO - 2016-02-22 13:16:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:16:23 --> Controller Class Initialized
INFO - 2016-02-22 13:16:23 --> Model Class Initialized
INFO - 2016-02-22 13:16:23 --> Model Class Initialized
INFO - 2016-02-22 13:16:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:16:23 --> Pagination Class Initialized
INFO - 2016-02-22 13:16:23 --> Helper loaded: text_helper
INFO - 2016-02-22 13:16:23 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:16:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:16:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:16:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:16:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:16:23 --> Final output sent to browser
DEBUG - 2016-02-22 16:16:23 --> Total execution time: 1.1520
INFO - 2016-02-22 13:16:25 --> Config Class Initialized
INFO - 2016-02-22 13:16:25 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:16:25 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:16:25 --> Utf8 Class Initialized
INFO - 2016-02-22 13:16:25 --> URI Class Initialized
INFO - 2016-02-22 13:16:25 --> Router Class Initialized
INFO - 2016-02-22 13:16:25 --> Output Class Initialized
INFO - 2016-02-22 13:16:25 --> Security Class Initialized
DEBUG - 2016-02-22 13:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:16:25 --> Input Class Initialized
INFO - 2016-02-22 13:16:25 --> Language Class Initialized
INFO - 2016-02-22 13:16:25 --> Loader Class Initialized
INFO - 2016-02-22 13:16:25 --> Helper loaded: url_helper
INFO - 2016-02-22 13:16:25 --> Helper loaded: file_helper
INFO - 2016-02-22 13:16:25 --> Helper loaded: date_helper
INFO - 2016-02-22 13:16:25 --> Helper loaded: form_helper
INFO - 2016-02-22 13:16:25 --> Database Driver Class Initialized
INFO - 2016-02-22 13:16:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:16:26 --> Controller Class Initialized
INFO - 2016-02-22 13:16:26 --> Model Class Initialized
INFO - 2016-02-22 13:16:26 --> Model Class Initialized
INFO - 2016-02-22 13:16:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:16:26 --> Pagination Class Initialized
INFO - 2016-02-22 13:16:26 --> Helper loaded: text_helper
INFO - 2016-02-22 13:16:26 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:16:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:16:26 --> Final output sent to browser
DEBUG - 2016-02-22 16:16:26 --> Total execution time: 1.1543
INFO - 2016-02-22 13:16:27 --> Config Class Initialized
INFO - 2016-02-22 13:16:27 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:16:27 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:16:27 --> Utf8 Class Initialized
INFO - 2016-02-22 13:16:27 --> URI Class Initialized
INFO - 2016-02-22 13:16:27 --> Router Class Initialized
INFO - 2016-02-22 13:16:27 --> Output Class Initialized
INFO - 2016-02-22 13:16:27 --> Security Class Initialized
DEBUG - 2016-02-22 13:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:16:27 --> Input Class Initialized
INFO - 2016-02-22 13:16:27 --> Language Class Initialized
INFO - 2016-02-22 13:16:27 --> Loader Class Initialized
INFO - 2016-02-22 13:16:27 --> Helper loaded: url_helper
INFO - 2016-02-22 13:16:27 --> Helper loaded: file_helper
INFO - 2016-02-22 13:16:27 --> Helper loaded: date_helper
INFO - 2016-02-22 13:16:27 --> Helper loaded: form_helper
INFO - 2016-02-22 13:16:27 --> Database Driver Class Initialized
INFO - 2016-02-22 13:16:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:16:28 --> Controller Class Initialized
INFO - 2016-02-22 13:16:28 --> Model Class Initialized
INFO - 2016-02-22 13:16:28 --> Model Class Initialized
INFO - 2016-02-22 13:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:16:28 --> Pagination Class Initialized
INFO - 2016-02-22 13:16:28 --> Helper loaded: text_helper
INFO - 2016-02-22 13:16:28 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:16:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:16:28 --> Final output sent to browser
DEBUG - 2016-02-22 16:16:28 --> Total execution time: 1.1467
INFO - 2016-02-22 13:16:29 --> Config Class Initialized
INFO - 2016-02-22 13:16:29 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:16:29 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:16:29 --> Utf8 Class Initialized
INFO - 2016-02-22 13:16:29 --> URI Class Initialized
INFO - 2016-02-22 13:16:29 --> Router Class Initialized
INFO - 2016-02-22 13:16:29 --> Output Class Initialized
INFO - 2016-02-22 13:16:29 --> Security Class Initialized
DEBUG - 2016-02-22 13:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:16:29 --> Input Class Initialized
INFO - 2016-02-22 13:16:29 --> Language Class Initialized
INFO - 2016-02-22 13:16:29 --> Loader Class Initialized
INFO - 2016-02-22 13:16:29 --> Helper loaded: url_helper
INFO - 2016-02-22 13:16:29 --> Helper loaded: file_helper
INFO - 2016-02-22 13:16:29 --> Helper loaded: date_helper
INFO - 2016-02-22 13:16:29 --> Helper loaded: form_helper
INFO - 2016-02-22 13:16:29 --> Database Driver Class Initialized
INFO - 2016-02-22 13:16:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:16:30 --> Controller Class Initialized
INFO - 2016-02-22 13:16:30 --> Model Class Initialized
INFO - 2016-02-22 13:16:30 --> Model Class Initialized
INFO - 2016-02-22 13:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:16:30 --> Pagination Class Initialized
INFO - 2016-02-22 13:16:30 --> Helper loaded: text_helper
INFO - 2016-02-22 13:16:30 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:16:30 --> Final output sent to browser
DEBUG - 2016-02-22 16:16:30 --> Total execution time: 1.1904
INFO - 2016-02-22 13:16:32 --> Config Class Initialized
INFO - 2016-02-22 13:16:32 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:16:32 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:16:32 --> Utf8 Class Initialized
INFO - 2016-02-22 13:16:32 --> URI Class Initialized
INFO - 2016-02-22 13:16:32 --> Router Class Initialized
INFO - 2016-02-22 13:16:32 --> Output Class Initialized
INFO - 2016-02-22 13:16:32 --> Security Class Initialized
DEBUG - 2016-02-22 13:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:16:32 --> Input Class Initialized
INFO - 2016-02-22 13:16:32 --> Language Class Initialized
INFO - 2016-02-22 13:16:32 --> Loader Class Initialized
INFO - 2016-02-22 13:16:32 --> Helper loaded: url_helper
INFO - 2016-02-22 13:16:32 --> Helper loaded: file_helper
INFO - 2016-02-22 13:16:32 --> Helper loaded: date_helper
INFO - 2016-02-22 13:16:32 --> Helper loaded: form_helper
INFO - 2016-02-22 13:16:32 --> Database Driver Class Initialized
INFO - 2016-02-22 13:16:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:16:33 --> Controller Class Initialized
INFO - 2016-02-22 13:16:33 --> Model Class Initialized
INFO - 2016-02-22 13:16:33 --> Model Class Initialized
INFO - 2016-02-22 13:16:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:16:33 --> Pagination Class Initialized
INFO - 2016-02-22 13:16:33 --> Helper loaded: text_helper
INFO - 2016-02-22 13:16:33 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:16:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:16:33 --> Final output sent to browser
DEBUG - 2016-02-22 16:16:33 --> Total execution time: 1.1490
INFO - 2016-02-22 13:16:34 --> Config Class Initialized
INFO - 2016-02-22 13:16:34 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:16:34 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:16:34 --> Utf8 Class Initialized
INFO - 2016-02-22 13:16:34 --> URI Class Initialized
INFO - 2016-02-22 13:16:34 --> Router Class Initialized
INFO - 2016-02-22 13:16:34 --> Output Class Initialized
INFO - 2016-02-22 13:16:34 --> Security Class Initialized
DEBUG - 2016-02-22 13:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:16:34 --> Input Class Initialized
INFO - 2016-02-22 13:16:34 --> Language Class Initialized
ERROR - 2016-02-22 13:16:34 --> 404 Page Not Found: Updatepost/index
INFO - 2016-02-22 13:16:49 --> Config Class Initialized
INFO - 2016-02-22 13:16:49 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:16:49 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:16:49 --> Utf8 Class Initialized
INFO - 2016-02-22 13:16:49 --> URI Class Initialized
INFO - 2016-02-22 13:16:49 --> Router Class Initialized
INFO - 2016-02-22 13:16:49 --> Output Class Initialized
INFO - 2016-02-22 13:16:49 --> Security Class Initialized
DEBUG - 2016-02-22 13:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:16:49 --> Input Class Initialized
INFO - 2016-02-22 13:16:49 --> Language Class Initialized
INFO - 2016-02-22 13:16:49 --> Loader Class Initialized
INFO - 2016-02-22 13:16:49 --> Helper loaded: url_helper
INFO - 2016-02-22 13:16:49 --> Helper loaded: file_helper
INFO - 2016-02-22 13:16:49 --> Helper loaded: date_helper
INFO - 2016-02-22 13:16:49 --> Helper loaded: form_helper
INFO - 2016-02-22 13:16:49 --> Database Driver Class Initialized
INFO - 2016-02-22 13:16:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:16:50 --> Controller Class Initialized
INFO - 2016-02-22 13:16:50 --> Model Class Initialized
INFO - 2016-02-22 13:16:50 --> Model Class Initialized
INFO - 2016-02-22 13:16:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:16:50 --> Pagination Class Initialized
INFO - 2016-02-22 13:16:50 --> Helper loaded: text_helper
INFO - 2016-02-22 13:16:50 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:16:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:16:50 --> Final output sent to browser
DEBUG - 2016-02-22 16:16:50 --> Total execution time: 1.1433
INFO - 2016-02-22 13:16:54 --> Config Class Initialized
INFO - 2016-02-22 13:16:54 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:16:54 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:16:54 --> Utf8 Class Initialized
INFO - 2016-02-22 13:16:54 --> URI Class Initialized
INFO - 2016-02-22 13:16:54 --> Router Class Initialized
INFO - 2016-02-22 13:16:54 --> Output Class Initialized
INFO - 2016-02-22 13:16:54 --> Security Class Initialized
DEBUG - 2016-02-22 13:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:16:54 --> Input Class Initialized
INFO - 2016-02-22 13:16:54 --> Language Class Initialized
ERROR - 2016-02-22 13:16:54 --> 404 Page Not Found: Updatepost/index
INFO - 2016-02-22 13:17:17 --> Config Class Initialized
INFO - 2016-02-22 13:17:17 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:17 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:17 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:17 --> URI Class Initialized
INFO - 2016-02-22 13:17:17 --> Router Class Initialized
INFO - 2016-02-22 13:17:17 --> Output Class Initialized
INFO - 2016-02-22 13:17:17 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:17 --> Input Class Initialized
INFO - 2016-02-22 13:17:17 --> Language Class Initialized
INFO - 2016-02-22 13:17:17 --> Loader Class Initialized
INFO - 2016-02-22 13:17:17 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:17 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:17 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:17 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:17 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:18 --> Controller Class Initialized
INFO - 2016-02-22 13:17:18 --> Model Class Initialized
INFO - 2016-02-22 13:17:18 --> Model Class Initialized
INFO - 2016-02-22 13:17:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:18 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:18 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:18 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:17:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:17:18 --> Final output sent to browser
DEBUG - 2016-02-22 16:17:18 --> Total execution time: 1.1306
INFO - 2016-02-22 13:17:20 --> Config Class Initialized
INFO - 2016-02-22 13:17:20 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:20 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:20 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:20 --> URI Class Initialized
INFO - 2016-02-22 13:17:20 --> Router Class Initialized
INFO - 2016-02-22 13:17:20 --> Output Class Initialized
INFO - 2016-02-22 13:17:20 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:20 --> Input Class Initialized
INFO - 2016-02-22 13:17:20 --> Language Class Initialized
INFO - 2016-02-22 13:17:20 --> Loader Class Initialized
INFO - 2016-02-22 13:17:20 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:20 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:20 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:20 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:20 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:21 --> Controller Class Initialized
INFO - 2016-02-22 13:17:21 --> Model Class Initialized
INFO - 2016-02-22 13:17:21 --> Model Class Initialized
INFO - 2016-02-22 13:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:21 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:21 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:21 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:17:21 --> Final output sent to browser
DEBUG - 2016-02-22 16:17:21 --> Total execution time: 1.2228
INFO - 2016-02-22 13:17:30 --> Config Class Initialized
INFO - 2016-02-22 13:17:30 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:30 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:30 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:30 --> URI Class Initialized
INFO - 2016-02-22 13:17:30 --> Router Class Initialized
INFO - 2016-02-22 13:17:30 --> Output Class Initialized
INFO - 2016-02-22 13:17:30 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:30 --> Input Class Initialized
INFO - 2016-02-22 13:17:30 --> Language Class Initialized
INFO - 2016-02-22 13:17:30 --> Loader Class Initialized
INFO - 2016-02-22 13:17:30 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:30 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:30 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:30 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:30 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:31 --> Controller Class Initialized
INFO - 2016-02-22 13:17:31 --> Model Class Initialized
INFO - 2016-02-22 13:17:31 --> Model Class Initialized
INFO - 2016-02-22 13:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:31 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:31 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:31 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:17:31 --> Final output sent to browser
DEBUG - 2016-02-22 16:17:31 --> Total execution time: 1.1445
INFO - 2016-02-22 13:17:33 --> Config Class Initialized
INFO - 2016-02-22 13:17:33 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:33 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:33 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:33 --> URI Class Initialized
INFO - 2016-02-22 13:17:33 --> Router Class Initialized
INFO - 2016-02-22 13:17:33 --> Output Class Initialized
INFO - 2016-02-22 13:17:33 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:33 --> Input Class Initialized
INFO - 2016-02-22 13:17:33 --> Language Class Initialized
INFO - 2016-02-22 13:17:33 --> Loader Class Initialized
INFO - 2016-02-22 13:17:33 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:33 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:33 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:33 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:33 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:34 --> Controller Class Initialized
INFO - 2016-02-22 13:17:34 --> Model Class Initialized
INFO - 2016-02-22 13:17:34 --> Model Class Initialized
INFO - 2016-02-22 13:17:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:34 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:34 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:34 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:17:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:17:34 --> Final output sent to browser
DEBUG - 2016-02-22 16:17:34 --> Total execution time: 1.1995
INFO - 2016-02-22 13:17:36 --> Config Class Initialized
INFO - 2016-02-22 13:17:36 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:36 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:36 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:36 --> URI Class Initialized
INFO - 2016-02-22 13:17:36 --> Router Class Initialized
INFO - 2016-02-22 13:17:36 --> Output Class Initialized
INFO - 2016-02-22 13:17:36 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:36 --> Input Class Initialized
INFO - 2016-02-22 13:17:36 --> Language Class Initialized
INFO - 2016-02-22 13:17:36 --> Loader Class Initialized
INFO - 2016-02-22 13:17:36 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:36 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:36 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:36 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:36 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:37 --> Controller Class Initialized
INFO - 2016-02-22 13:17:37 --> Model Class Initialized
INFO - 2016-02-22 13:17:37 --> Model Class Initialized
INFO - 2016-02-22 13:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:37 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:37 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:37 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:17:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:17:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:17:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:17:37 --> Final output sent to browser
DEBUG - 2016-02-22 16:17:37 --> Total execution time: 1.1378
INFO - 2016-02-22 13:17:39 --> Config Class Initialized
INFO - 2016-02-22 13:17:39 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:39 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:39 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:39 --> URI Class Initialized
INFO - 2016-02-22 13:17:39 --> Router Class Initialized
INFO - 2016-02-22 13:17:39 --> Output Class Initialized
INFO - 2016-02-22 13:17:39 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:39 --> Input Class Initialized
INFO - 2016-02-22 13:17:39 --> Language Class Initialized
INFO - 2016-02-22 13:17:39 --> Loader Class Initialized
INFO - 2016-02-22 13:17:39 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:39 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:39 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:39 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:39 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:40 --> Controller Class Initialized
INFO - 2016-02-22 13:17:40 --> Model Class Initialized
INFO - 2016-02-22 13:17:40 --> Model Class Initialized
INFO - 2016-02-22 13:17:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:40 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:40 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:40 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:17:40 --> Config Class Initialized
INFO - 2016-02-22 13:17:40 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:40 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:40 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:40 --> URI Class Initialized
INFO - 2016-02-22 13:17:40 --> Router Class Initialized
INFO - 2016-02-22 13:17:40 --> Output Class Initialized
INFO - 2016-02-22 13:17:40 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:40 --> Input Class Initialized
INFO - 2016-02-22 13:17:40 --> Language Class Initialized
INFO - 2016-02-22 13:17:40 --> Loader Class Initialized
INFO - 2016-02-22 13:17:40 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:40 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:40 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:40 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:40 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:41 --> Controller Class Initialized
INFO - 2016-02-22 13:17:41 --> Model Class Initialized
INFO - 2016-02-22 13:17:41 --> Model Class Initialized
INFO - 2016-02-22 13:17:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:41 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:41 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:41 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:17:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:17:41 --> Final output sent to browser
DEBUG - 2016-02-22 16:17:41 --> Total execution time: 1.1743
INFO - 2016-02-22 13:17:47 --> Config Class Initialized
INFO - 2016-02-22 13:17:47 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:47 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:47 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:47 --> URI Class Initialized
INFO - 2016-02-22 13:17:47 --> Router Class Initialized
INFO - 2016-02-22 13:17:47 --> Output Class Initialized
INFO - 2016-02-22 13:17:47 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:47 --> Input Class Initialized
INFO - 2016-02-22 13:17:47 --> Language Class Initialized
INFO - 2016-02-22 13:17:47 --> Loader Class Initialized
INFO - 2016-02-22 13:17:47 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:47 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:47 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:47 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:47 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:48 --> Controller Class Initialized
INFO - 2016-02-22 13:17:48 --> Model Class Initialized
INFO - 2016-02-22 13:17:48 --> Model Class Initialized
INFO - 2016-02-22 13:17:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:48 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:48 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:48 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:17:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:17:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:17:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:17:48 --> Final output sent to browser
DEBUG - 2016-02-22 16:17:48 --> Total execution time: 1.1265
INFO - 2016-02-22 13:17:53 --> Config Class Initialized
INFO - 2016-02-22 13:17:53 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:53 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:53 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:53 --> URI Class Initialized
INFO - 2016-02-22 13:17:53 --> Router Class Initialized
INFO - 2016-02-22 13:17:53 --> Output Class Initialized
INFO - 2016-02-22 13:17:53 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:53 --> Input Class Initialized
INFO - 2016-02-22 13:17:53 --> Language Class Initialized
INFO - 2016-02-22 13:17:53 --> Loader Class Initialized
INFO - 2016-02-22 13:17:53 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:53 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:53 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:53 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:53 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:54 --> Controller Class Initialized
INFO - 2016-02-22 13:17:54 --> Model Class Initialized
INFO - 2016-02-22 13:17:54 --> Model Class Initialized
INFO - 2016-02-22 13:17:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:54 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:54 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:54 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:17:54 --> Config Class Initialized
INFO - 2016-02-22 13:17:54 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:17:54 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:17:54 --> Utf8 Class Initialized
INFO - 2016-02-22 13:17:54 --> URI Class Initialized
INFO - 2016-02-22 13:17:54 --> Router Class Initialized
INFO - 2016-02-22 13:17:54 --> Output Class Initialized
INFO - 2016-02-22 13:17:54 --> Security Class Initialized
DEBUG - 2016-02-22 13:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:17:54 --> Input Class Initialized
INFO - 2016-02-22 13:17:54 --> Language Class Initialized
INFO - 2016-02-22 13:17:54 --> Loader Class Initialized
INFO - 2016-02-22 13:17:54 --> Helper loaded: url_helper
INFO - 2016-02-22 13:17:54 --> Helper loaded: file_helper
INFO - 2016-02-22 13:17:54 --> Helper loaded: date_helper
INFO - 2016-02-22 13:17:54 --> Helper loaded: form_helper
INFO - 2016-02-22 13:17:54 --> Database Driver Class Initialized
INFO - 2016-02-22 13:17:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:17:55 --> Controller Class Initialized
INFO - 2016-02-22 13:17:55 --> Model Class Initialized
INFO - 2016-02-22 13:17:55 --> Model Class Initialized
INFO - 2016-02-22 13:17:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:17:55 --> Pagination Class Initialized
INFO - 2016-02-22 13:17:55 --> Helper loaded: text_helper
INFO - 2016-02-22 13:17:55 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:17:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:17:55 --> Final output sent to browser
DEBUG - 2016-02-22 16:17:55 --> Total execution time: 1.1512
INFO - 2016-02-22 13:18:48 --> Config Class Initialized
INFO - 2016-02-22 13:18:48 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:18:48 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:18:48 --> Utf8 Class Initialized
INFO - 2016-02-22 13:18:48 --> URI Class Initialized
INFO - 2016-02-22 13:18:48 --> Router Class Initialized
INFO - 2016-02-22 13:18:48 --> Output Class Initialized
INFO - 2016-02-22 13:18:48 --> Security Class Initialized
DEBUG - 2016-02-22 13:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:18:48 --> Input Class Initialized
INFO - 2016-02-22 13:18:48 --> Language Class Initialized
INFO - 2016-02-22 13:18:48 --> Loader Class Initialized
INFO - 2016-02-22 13:18:48 --> Helper loaded: url_helper
INFO - 2016-02-22 13:18:48 --> Helper loaded: file_helper
INFO - 2016-02-22 13:18:48 --> Helper loaded: date_helper
INFO - 2016-02-22 13:18:48 --> Helper loaded: form_helper
INFO - 2016-02-22 13:18:48 --> Database Driver Class Initialized
INFO - 2016-02-22 13:18:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:18:49 --> Controller Class Initialized
INFO - 2016-02-22 13:18:49 --> Model Class Initialized
INFO - 2016-02-22 13:18:49 --> Model Class Initialized
INFO - 2016-02-22 13:18:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:18:49 --> Pagination Class Initialized
INFO - 2016-02-22 13:18:49 --> Helper loaded: text_helper
INFO - 2016-02-22 13:18:49 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:18:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:18:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:18:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:18:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:18:49 --> Final output sent to browser
DEBUG - 2016-02-22 16:18:49 --> Total execution time: 1.1046
INFO - 2016-02-22 13:18:50 --> Config Class Initialized
INFO - 2016-02-22 13:18:50 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:18:50 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:18:50 --> Utf8 Class Initialized
INFO - 2016-02-22 13:18:50 --> URI Class Initialized
INFO - 2016-02-22 13:18:50 --> Router Class Initialized
INFO - 2016-02-22 13:18:50 --> Output Class Initialized
INFO - 2016-02-22 13:18:50 --> Security Class Initialized
DEBUG - 2016-02-22 13:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:18:50 --> Input Class Initialized
INFO - 2016-02-22 13:18:50 --> Language Class Initialized
INFO - 2016-02-22 13:18:50 --> Loader Class Initialized
INFO - 2016-02-22 13:18:50 --> Helper loaded: url_helper
INFO - 2016-02-22 13:18:50 --> Helper loaded: file_helper
INFO - 2016-02-22 13:18:50 --> Helper loaded: date_helper
INFO - 2016-02-22 13:18:50 --> Helper loaded: form_helper
INFO - 2016-02-22 13:18:50 --> Database Driver Class Initialized
INFO - 2016-02-22 13:18:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:18:52 --> Controller Class Initialized
INFO - 2016-02-22 13:18:52 --> Model Class Initialized
INFO - 2016-02-22 13:18:52 --> Model Class Initialized
INFO - 2016-02-22 13:18:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:18:52 --> Pagination Class Initialized
INFO - 2016-02-22 13:18:52 --> Helper loaded: text_helper
INFO - 2016-02-22 13:18:52 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:18:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:18:52 --> Final output sent to browser
DEBUG - 2016-02-22 16:18:52 --> Total execution time: 1.1630
INFO - 2016-02-22 13:18:53 --> Config Class Initialized
INFO - 2016-02-22 13:18:53 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:18:53 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:18:53 --> Utf8 Class Initialized
INFO - 2016-02-22 13:18:53 --> URI Class Initialized
INFO - 2016-02-22 13:18:53 --> Router Class Initialized
INFO - 2016-02-22 13:18:53 --> Output Class Initialized
INFO - 2016-02-22 13:18:53 --> Security Class Initialized
DEBUG - 2016-02-22 13:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:18:53 --> Input Class Initialized
INFO - 2016-02-22 13:18:53 --> Language Class Initialized
INFO - 2016-02-22 13:18:53 --> Loader Class Initialized
INFO - 2016-02-22 13:18:53 --> Helper loaded: url_helper
INFO - 2016-02-22 13:18:53 --> Helper loaded: file_helper
INFO - 2016-02-22 13:18:53 --> Helper loaded: date_helper
INFO - 2016-02-22 13:18:53 --> Helper loaded: form_helper
INFO - 2016-02-22 13:18:53 --> Database Driver Class Initialized
INFO - 2016-02-22 13:18:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:18:54 --> Controller Class Initialized
INFO - 2016-02-22 13:18:54 --> Model Class Initialized
INFO - 2016-02-22 13:18:54 --> Model Class Initialized
INFO - 2016-02-22 13:18:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:18:54 --> Pagination Class Initialized
INFO - 2016-02-22 13:18:54 --> Helper loaded: text_helper
INFO - 2016-02-22 13:18:54 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:18:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:18:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:18:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:18:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:18:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:18:54 --> Final output sent to browser
DEBUG - 2016-02-22 16:18:54 --> Total execution time: 1.1342
INFO - 2016-02-22 13:19:00 --> Config Class Initialized
INFO - 2016-02-22 13:19:00 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:19:00 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:19:00 --> Utf8 Class Initialized
INFO - 2016-02-22 13:19:00 --> URI Class Initialized
INFO - 2016-02-22 13:19:00 --> Router Class Initialized
INFO - 2016-02-22 13:19:00 --> Output Class Initialized
INFO - 2016-02-22 13:19:00 --> Security Class Initialized
DEBUG - 2016-02-22 13:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:19:00 --> Input Class Initialized
INFO - 2016-02-22 13:19:00 --> Language Class Initialized
INFO - 2016-02-22 13:19:00 --> Loader Class Initialized
INFO - 2016-02-22 13:19:00 --> Helper loaded: url_helper
INFO - 2016-02-22 13:19:00 --> Helper loaded: file_helper
INFO - 2016-02-22 13:19:00 --> Helper loaded: date_helper
INFO - 2016-02-22 13:19:00 --> Helper loaded: form_helper
INFO - 2016-02-22 13:19:00 --> Database Driver Class Initialized
INFO - 2016-02-22 13:19:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:19:01 --> Controller Class Initialized
INFO - 2016-02-22 13:19:01 --> Model Class Initialized
INFO - 2016-02-22 13:19:01 --> Model Class Initialized
INFO - 2016-02-22 13:19:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:19:01 --> Pagination Class Initialized
INFO - 2016-02-22 13:19:01 --> Helper loaded: text_helper
INFO - 2016-02-22 13:19:01 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:19:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:19:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:19:01 --> Config Class Initialized
INFO - 2016-02-22 13:19:01 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:19:01 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:19:01 --> Utf8 Class Initialized
INFO - 2016-02-22 13:19:01 --> URI Class Initialized
INFO - 2016-02-22 13:19:01 --> Router Class Initialized
INFO - 2016-02-22 13:19:01 --> Output Class Initialized
INFO - 2016-02-22 13:19:01 --> Security Class Initialized
DEBUG - 2016-02-22 13:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:19:01 --> Input Class Initialized
INFO - 2016-02-22 13:19:01 --> Language Class Initialized
INFO - 2016-02-22 13:19:01 --> Loader Class Initialized
INFO - 2016-02-22 13:19:01 --> Helper loaded: url_helper
INFO - 2016-02-22 13:19:01 --> Helper loaded: file_helper
INFO - 2016-02-22 13:19:01 --> Helper loaded: date_helper
INFO - 2016-02-22 13:19:01 --> Helper loaded: form_helper
INFO - 2016-02-22 13:19:01 --> Database Driver Class Initialized
INFO - 2016-02-22 13:19:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:19:02 --> Controller Class Initialized
INFO - 2016-02-22 13:19:02 --> Model Class Initialized
INFO - 2016-02-22 13:19:02 --> Model Class Initialized
INFO - 2016-02-22 13:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:19:02 --> Pagination Class Initialized
INFO - 2016-02-22 13:19:02 --> Helper loaded: text_helper
INFO - 2016-02-22 13:19:02 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:19:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:19:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:19:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:19:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:19:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:19:02 --> Final output sent to browser
DEBUG - 2016-02-22 16:19:02 --> Total execution time: 1.1784
INFO - 2016-02-22 13:19:04 --> Config Class Initialized
INFO - 2016-02-22 13:19:04 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:19:04 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:19:04 --> Utf8 Class Initialized
INFO - 2016-02-22 13:19:04 --> URI Class Initialized
INFO - 2016-02-22 13:19:04 --> Router Class Initialized
INFO - 2016-02-22 13:19:04 --> Output Class Initialized
INFO - 2016-02-22 13:19:04 --> Security Class Initialized
DEBUG - 2016-02-22 13:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:19:04 --> Input Class Initialized
INFO - 2016-02-22 13:19:04 --> Language Class Initialized
INFO - 2016-02-22 13:19:04 --> Loader Class Initialized
INFO - 2016-02-22 13:19:04 --> Helper loaded: url_helper
INFO - 2016-02-22 13:19:04 --> Helper loaded: file_helper
INFO - 2016-02-22 13:19:04 --> Helper loaded: date_helper
INFO - 2016-02-22 13:19:04 --> Helper loaded: form_helper
INFO - 2016-02-22 13:19:04 --> Database Driver Class Initialized
INFO - 2016-02-22 13:19:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:19:05 --> Controller Class Initialized
INFO - 2016-02-22 13:19:05 --> Model Class Initialized
INFO - 2016-02-22 13:19:05 --> Model Class Initialized
INFO - 2016-02-22 13:19:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:19:05 --> Pagination Class Initialized
INFO - 2016-02-22 13:19:05 --> Helper loaded: text_helper
INFO - 2016-02-22 13:19:05 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-02-22 16:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:19:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:19:05 --> Final output sent to browser
DEBUG - 2016-02-22 16:19:05 --> Total execution time: 1.1412
INFO - 2016-02-22 13:19:08 --> Config Class Initialized
INFO - 2016-02-22 13:19:08 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:19:08 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:19:08 --> Utf8 Class Initialized
INFO - 2016-02-22 13:19:08 --> URI Class Initialized
INFO - 2016-02-22 13:19:08 --> Router Class Initialized
INFO - 2016-02-22 13:19:08 --> Output Class Initialized
INFO - 2016-02-22 13:19:08 --> Security Class Initialized
DEBUG - 2016-02-22 13:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:19:08 --> Input Class Initialized
INFO - 2016-02-22 13:19:08 --> Language Class Initialized
INFO - 2016-02-22 13:19:08 --> Loader Class Initialized
INFO - 2016-02-22 13:19:08 --> Helper loaded: url_helper
INFO - 2016-02-22 13:19:08 --> Helper loaded: file_helper
INFO - 2016-02-22 13:19:08 --> Helper loaded: date_helper
INFO - 2016-02-22 13:19:08 --> Helper loaded: form_helper
INFO - 2016-02-22 13:19:08 --> Database Driver Class Initialized
INFO - 2016-02-22 13:19:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:19:09 --> Controller Class Initialized
INFO - 2016-02-22 13:19:09 --> Model Class Initialized
INFO - 2016-02-22 13:19:09 --> Model Class Initialized
INFO - 2016-02-22 13:19:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:19:09 --> Pagination Class Initialized
INFO - 2016-02-22 13:19:09 --> Helper loaded: text_helper
INFO - 2016-02-22 13:19:09 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:19:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:19:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 13:19:10 --> Config Class Initialized
INFO - 2016-02-22 13:19:10 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:19:10 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:19:10 --> Utf8 Class Initialized
INFO - 2016-02-22 13:19:10 --> URI Class Initialized
INFO - 2016-02-22 13:19:10 --> Router Class Initialized
INFO - 2016-02-22 13:19:10 --> Output Class Initialized
INFO - 2016-02-22 13:19:10 --> Security Class Initialized
DEBUG - 2016-02-22 13:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:19:10 --> Input Class Initialized
INFO - 2016-02-22 13:19:10 --> Language Class Initialized
INFO - 2016-02-22 13:19:10 --> Loader Class Initialized
INFO - 2016-02-22 13:19:10 --> Helper loaded: url_helper
INFO - 2016-02-22 13:19:10 --> Helper loaded: file_helper
INFO - 2016-02-22 13:19:10 --> Helper loaded: date_helper
INFO - 2016-02-22 13:19:10 --> Helper loaded: form_helper
INFO - 2016-02-22 13:19:10 --> Database Driver Class Initialized
INFO - 2016-02-22 13:19:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:19:11 --> Controller Class Initialized
INFO - 2016-02-22 13:19:11 --> Model Class Initialized
INFO - 2016-02-22 13:19:11 --> Model Class Initialized
INFO - 2016-02-22 13:19:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:19:11 --> Pagination Class Initialized
INFO - 2016-02-22 13:19:11 --> Helper loaded: text_helper
INFO - 2016-02-22 13:19:11 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:19:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:19:11 --> Final output sent to browser
DEBUG - 2016-02-22 16:19:11 --> Total execution time: 1.1509
INFO - 2016-02-22 13:20:03 --> Config Class Initialized
INFO - 2016-02-22 13:20:03 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:20:03 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:20:03 --> Utf8 Class Initialized
INFO - 2016-02-22 13:20:03 --> URI Class Initialized
INFO - 2016-02-22 13:20:03 --> Router Class Initialized
INFO - 2016-02-22 13:20:03 --> Output Class Initialized
INFO - 2016-02-22 13:20:03 --> Security Class Initialized
DEBUG - 2016-02-22 13:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:20:03 --> Input Class Initialized
INFO - 2016-02-22 13:20:03 --> Language Class Initialized
INFO - 2016-02-22 13:20:03 --> Loader Class Initialized
INFO - 2016-02-22 13:20:03 --> Helper loaded: url_helper
INFO - 2016-02-22 13:20:03 --> Helper loaded: file_helper
INFO - 2016-02-22 13:20:03 --> Helper loaded: date_helper
INFO - 2016-02-22 13:20:03 --> Helper loaded: form_helper
INFO - 2016-02-22 13:20:03 --> Database Driver Class Initialized
INFO - 2016-02-22 13:20:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:20:04 --> Controller Class Initialized
INFO - 2016-02-22 13:20:04 --> Model Class Initialized
INFO - 2016-02-22 13:20:04 --> Model Class Initialized
INFO - 2016-02-22 13:20:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:20:04 --> Pagination Class Initialized
INFO - 2016-02-22 13:20:04 --> Helper loaded: text_helper
INFO - 2016-02-22 13:20:04 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:20:04 --> Final output sent to browser
DEBUG - 2016-02-22 16:20:04 --> Total execution time: 1.2196
INFO - 2016-02-22 13:20:18 --> Config Class Initialized
INFO - 2016-02-22 13:20:18 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:20:18 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:20:18 --> Utf8 Class Initialized
INFO - 2016-02-22 13:20:18 --> URI Class Initialized
INFO - 2016-02-22 13:20:18 --> Router Class Initialized
INFO - 2016-02-22 13:20:18 --> Output Class Initialized
INFO - 2016-02-22 13:20:18 --> Security Class Initialized
DEBUG - 2016-02-22 13:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:20:18 --> Input Class Initialized
INFO - 2016-02-22 13:20:18 --> Language Class Initialized
INFO - 2016-02-22 13:20:18 --> Loader Class Initialized
INFO - 2016-02-22 13:20:18 --> Helper loaded: url_helper
INFO - 2016-02-22 13:20:18 --> Helper loaded: file_helper
INFO - 2016-02-22 13:20:18 --> Helper loaded: date_helper
INFO - 2016-02-22 13:20:18 --> Helper loaded: form_helper
INFO - 2016-02-22 13:20:18 --> Database Driver Class Initialized
INFO - 2016-02-22 13:20:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:20:19 --> Controller Class Initialized
INFO - 2016-02-22 13:20:19 --> Model Class Initialized
INFO - 2016-02-22 13:20:19 --> Model Class Initialized
INFO - 2016-02-22 13:20:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:20:19 --> Pagination Class Initialized
INFO - 2016-02-22 13:20:19 --> Helper loaded: text_helper
INFO - 2016-02-22 13:20:19 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:20:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:20:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:20:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:20:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:20:19 --> Final output sent to browser
DEBUG - 2016-02-22 16:20:19 --> Total execution time: 1.1728
INFO - 2016-02-22 13:20:20 --> Config Class Initialized
INFO - 2016-02-22 13:20:20 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:20:20 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:20:20 --> Utf8 Class Initialized
INFO - 2016-02-22 13:20:20 --> URI Class Initialized
INFO - 2016-02-22 13:20:20 --> Router Class Initialized
INFO - 2016-02-22 13:20:20 --> Output Class Initialized
INFO - 2016-02-22 13:20:20 --> Security Class Initialized
DEBUG - 2016-02-22 13:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:20:20 --> Input Class Initialized
INFO - 2016-02-22 13:20:20 --> Language Class Initialized
INFO - 2016-02-22 13:20:20 --> Loader Class Initialized
INFO - 2016-02-22 13:20:20 --> Helper loaded: url_helper
INFO - 2016-02-22 13:20:20 --> Helper loaded: file_helper
INFO - 2016-02-22 13:20:20 --> Helper loaded: date_helper
INFO - 2016-02-22 13:20:20 --> Helper loaded: form_helper
INFO - 2016-02-22 13:20:20 --> Database Driver Class Initialized
INFO - 2016-02-22 13:20:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:20:21 --> Controller Class Initialized
INFO - 2016-02-22 13:20:21 --> Model Class Initialized
INFO - 2016-02-22 13:20:21 --> Model Class Initialized
INFO - 2016-02-22 13:20:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:20:21 --> Pagination Class Initialized
INFO - 2016-02-22 13:20:21 --> Helper loaded: text_helper
INFO - 2016-02-22 13:20:21 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:20:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:20:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:20:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-22 16:20:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-22 16:20:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:20:21 --> Final output sent to browser
DEBUG - 2016-02-22 16:20:21 --> Total execution time: 1.1759
INFO - 2016-02-22 13:20:24 --> Config Class Initialized
INFO - 2016-02-22 13:20:24 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:20:24 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:20:24 --> Utf8 Class Initialized
INFO - 2016-02-22 13:20:24 --> URI Class Initialized
INFO - 2016-02-22 13:20:24 --> Router Class Initialized
INFO - 2016-02-22 13:20:24 --> Output Class Initialized
INFO - 2016-02-22 13:20:24 --> Security Class Initialized
DEBUG - 2016-02-22 13:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:20:24 --> Input Class Initialized
INFO - 2016-02-22 13:20:24 --> Language Class Initialized
INFO - 2016-02-22 13:20:24 --> Loader Class Initialized
INFO - 2016-02-22 13:20:24 --> Helper loaded: url_helper
INFO - 2016-02-22 13:20:24 --> Helper loaded: file_helper
INFO - 2016-02-22 13:20:24 --> Helper loaded: date_helper
INFO - 2016-02-22 13:20:24 --> Helper loaded: form_helper
INFO - 2016-02-22 13:20:24 --> Database Driver Class Initialized
INFO - 2016-02-22 13:20:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:20:25 --> Controller Class Initialized
INFO - 2016-02-22 13:20:25 --> Model Class Initialized
INFO - 2016-02-22 13:20:25 --> Model Class Initialized
INFO - 2016-02-22 13:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:20:25 --> Pagination Class Initialized
INFO - 2016-02-22 13:20:25 --> Helper loaded: text_helper
INFO - 2016-02-22 13:20:25 --> Helper loaded: cookie_helper
INFO - 2016-02-22 13:20:29 --> Config Class Initialized
INFO - 2016-02-22 13:20:29 --> Hooks Class Initialized
DEBUG - 2016-02-22 13:20:29 --> UTF-8 Support Enabled
INFO - 2016-02-22 13:20:29 --> Utf8 Class Initialized
INFO - 2016-02-22 13:20:29 --> URI Class Initialized
INFO - 2016-02-22 13:20:29 --> Router Class Initialized
INFO - 2016-02-22 13:20:29 --> Output Class Initialized
INFO - 2016-02-22 13:20:29 --> Security Class Initialized
DEBUG - 2016-02-22 13:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 13:20:29 --> Input Class Initialized
INFO - 2016-02-22 13:20:29 --> Language Class Initialized
INFO - 2016-02-22 13:20:29 --> Loader Class Initialized
INFO - 2016-02-22 13:20:29 --> Helper loaded: url_helper
INFO - 2016-02-22 13:20:29 --> Helper loaded: file_helper
INFO - 2016-02-22 13:20:29 --> Helper loaded: date_helper
INFO - 2016-02-22 13:20:29 --> Helper loaded: form_helper
INFO - 2016-02-22 13:20:29 --> Database Driver Class Initialized
INFO - 2016-02-22 13:20:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 13:20:30 --> Controller Class Initialized
INFO - 2016-02-22 13:20:30 --> Model Class Initialized
INFO - 2016-02-22 13:20:30 --> Model Class Initialized
INFO - 2016-02-22 13:20:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 13:20:30 --> Pagination Class Initialized
INFO - 2016-02-22 13:20:30 --> Helper loaded: text_helper
INFO - 2016-02-22 13:20:30 --> Helper loaded: cookie_helper
INFO - 2016-02-22 16:20:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 16:20:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 16:20:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 16:20:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 16:20:30 --> Final output sent to browser
DEBUG - 2016-02-22 16:20:30 --> Total execution time: 1.1305
INFO - 2016-02-22 14:19:27 --> Config Class Initialized
INFO - 2016-02-22 14:19:27 --> Hooks Class Initialized
DEBUG - 2016-02-22 14:19:27 --> UTF-8 Support Enabled
INFO - 2016-02-22 14:19:27 --> Utf8 Class Initialized
INFO - 2016-02-22 14:19:27 --> URI Class Initialized
DEBUG - 2016-02-22 14:19:27 --> No URI present. Default controller set.
INFO - 2016-02-22 14:19:27 --> Router Class Initialized
INFO - 2016-02-22 14:19:27 --> Output Class Initialized
INFO - 2016-02-22 14:19:27 --> Security Class Initialized
DEBUG - 2016-02-22 14:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 14:19:27 --> Input Class Initialized
INFO - 2016-02-22 14:19:27 --> Language Class Initialized
INFO - 2016-02-22 14:19:27 --> Loader Class Initialized
INFO - 2016-02-22 14:19:27 --> Helper loaded: url_helper
INFO - 2016-02-22 14:19:27 --> Helper loaded: file_helper
INFO - 2016-02-22 14:19:27 --> Helper loaded: date_helper
INFO - 2016-02-22 14:19:27 --> Helper loaded: form_helper
INFO - 2016-02-22 14:19:27 --> Database Driver Class Initialized
INFO - 2016-02-22 14:19:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 14:19:28 --> Controller Class Initialized
INFO - 2016-02-22 14:19:28 --> Model Class Initialized
INFO - 2016-02-22 14:19:28 --> Model Class Initialized
INFO - 2016-02-22 14:19:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 14:19:28 --> Pagination Class Initialized
INFO - 2016-02-22 14:19:28 --> Helper loaded: text_helper
INFO - 2016-02-22 14:19:28 --> Helper loaded: cookie_helper
INFO - 2016-02-22 17:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 17:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 17:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-22 17:19:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 17:19:28 --> Final output sent to browser
DEBUG - 2016-02-22 17:19:28 --> Total execution time: 1.1449
INFO - 2016-02-22 14:19:34 --> Config Class Initialized
INFO - 2016-02-22 14:19:34 --> Hooks Class Initialized
DEBUG - 2016-02-22 14:19:34 --> UTF-8 Support Enabled
INFO - 2016-02-22 14:19:34 --> Utf8 Class Initialized
INFO - 2016-02-22 14:19:34 --> URI Class Initialized
INFO - 2016-02-22 14:19:34 --> Router Class Initialized
INFO - 2016-02-22 14:19:34 --> Output Class Initialized
INFO - 2016-02-22 14:19:34 --> Security Class Initialized
DEBUG - 2016-02-22 14:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 14:19:34 --> Input Class Initialized
INFO - 2016-02-22 14:19:34 --> Language Class Initialized
INFO - 2016-02-22 14:19:34 --> Loader Class Initialized
INFO - 2016-02-22 14:19:34 --> Helper loaded: url_helper
INFO - 2016-02-22 14:19:34 --> Helper loaded: file_helper
INFO - 2016-02-22 14:19:34 --> Helper loaded: date_helper
INFO - 2016-02-22 14:19:34 --> Helper loaded: form_helper
INFO - 2016-02-22 14:19:34 --> Database Driver Class Initialized
INFO - 2016-02-22 14:19:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 14:19:36 --> Controller Class Initialized
INFO - 2016-02-22 14:19:36 --> Model Class Initialized
INFO - 2016-02-22 14:19:36 --> Model Class Initialized
INFO - 2016-02-22 14:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 14:19:36 --> Pagination Class Initialized
INFO - 2016-02-22 14:19:36 --> Helper loaded: text_helper
INFO - 2016-02-22 14:19:36 --> Helper loaded: cookie_helper
INFO - 2016-02-22 17:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 17:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 17:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 17:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 17:19:36 --> Final output sent to browser
DEBUG - 2016-02-22 17:19:36 --> Total execution time: 1.1177
INFO - 2016-02-22 14:19:37 --> Config Class Initialized
INFO - 2016-02-22 14:19:37 --> Hooks Class Initialized
DEBUG - 2016-02-22 14:19:37 --> UTF-8 Support Enabled
INFO - 2016-02-22 14:19:37 --> Utf8 Class Initialized
INFO - 2016-02-22 14:19:37 --> URI Class Initialized
INFO - 2016-02-22 14:19:37 --> Router Class Initialized
INFO - 2016-02-22 14:19:37 --> Output Class Initialized
INFO - 2016-02-22 14:19:37 --> Security Class Initialized
DEBUG - 2016-02-22 14:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 14:19:37 --> Input Class Initialized
INFO - 2016-02-22 14:19:37 --> Language Class Initialized
INFO - 2016-02-22 14:19:37 --> Loader Class Initialized
INFO - 2016-02-22 14:19:37 --> Helper loaded: url_helper
INFO - 2016-02-22 14:19:37 --> Helper loaded: file_helper
INFO - 2016-02-22 14:19:37 --> Helper loaded: date_helper
INFO - 2016-02-22 14:19:37 --> Helper loaded: form_helper
INFO - 2016-02-22 14:19:37 --> Database Driver Class Initialized
INFO - 2016-02-22 14:19:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 14:19:38 --> Controller Class Initialized
INFO - 2016-02-22 14:19:38 --> Model Class Initialized
INFO - 2016-02-22 14:19:38 --> Model Class Initialized
INFO - 2016-02-22 14:19:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 14:19:38 --> Pagination Class Initialized
INFO - 2016-02-22 14:19:38 --> Helper loaded: text_helper
INFO - 2016-02-22 14:19:38 --> Helper loaded: cookie_helper
INFO - 2016-02-22 17:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 17:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 17:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 17:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 17:19:38 --> Final output sent to browser
DEBUG - 2016-02-22 17:19:38 --> Total execution time: 1.1091
INFO - 2016-02-22 14:19:41 --> Config Class Initialized
INFO - 2016-02-22 14:19:41 --> Hooks Class Initialized
DEBUG - 2016-02-22 14:19:41 --> UTF-8 Support Enabled
INFO - 2016-02-22 14:19:41 --> Utf8 Class Initialized
INFO - 2016-02-22 14:19:41 --> URI Class Initialized
INFO - 2016-02-22 14:19:41 --> Router Class Initialized
INFO - 2016-02-22 14:19:41 --> Output Class Initialized
INFO - 2016-02-22 14:19:41 --> Security Class Initialized
DEBUG - 2016-02-22 14:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 14:19:41 --> Input Class Initialized
INFO - 2016-02-22 14:19:41 --> Language Class Initialized
INFO - 2016-02-22 14:19:41 --> Loader Class Initialized
INFO - 2016-02-22 14:19:41 --> Helper loaded: url_helper
INFO - 2016-02-22 14:19:41 --> Helper loaded: file_helper
INFO - 2016-02-22 14:19:41 --> Helper loaded: date_helper
INFO - 2016-02-22 14:19:41 --> Helper loaded: form_helper
INFO - 2016-02-22 14:19:41 --> Database Driver Class Initialized
INFO - 2016-02-22 14:19:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 14:19:42 --> Controller Class Initialized
INFO - 2016-02-22 14:19:42 --> Model Class Initialized
INFO - 2016-02-22 14:19:42 --> Model Class Initialized
INFO - 2016-02-22 14:19:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 14:19:42 --> Pagination Class Initialized
INFO - 2016-02-22 14:19:42 --> Helper loaded: text_helper
INFO - 2016-02-22 14:19:42 --> Helper loaded: cookie_helper
INFO - 2016-02-22 17:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 17:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 17:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 17:19:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 17:19:42 --> Final output sent to browser
DEBUG - 2016-02-22 17:19:42 --> Total execution time: 1.1319
INFO - 2016-02-22 14:19:43 --> Config Class Initialized
INFO - 2016-02-22 14:19:43 --> Hooks Class Initialized
DEBUG - 2016-02-22 14:19:43 --> UTF-8 Support Enabled
INFO - 2016-02-22 14:19:43 --> Utf8 Class Initialized
INFO - 2016-02-22 14:19:43 --> URI Class Initialized
DEBUG - 2016-02-22 14:19:43 --> No URI present. Default controller set.
INFO - 2016-02-22 14:19:43 --> Router Class Initialized
INFO - 2016-02-22 14:19:43 --> Output Class Initialized
INFO - 2016-02-22 14:19:43 --> Security Class Initialized
DEBUG - 2016-02-22 14:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 14:19:43 --> Input Class Initialized
INFO - 2016-02-22 14:19:43 --> Language Class Initialized
INFO - 2016-02-22 14:19:43 --> Loader Class Initialized
INFO - 2016-02-22 14:19:43 --> Helper loaded: url_helper
INFO - 2016-02-22 14:19:43 --> Helper loaded: file_helper
INFO - 2016-02-22 14:19:43 --> Helper loaded: date_helper
INFO - 2016-02-22 14:19:43 --> Helper loaded: form_helper
INFO - 2016-02-22 14:19:43 --> Database Driver Class Initialized
INFO - 2016-02-22 14:19:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 14:19:44 --> Controller Class Initialized
INFO - 2016-02-22 14:19:44 --> Model Class Initialized
INFO - 2016-02-22 14:19:44 --> Model Class Initialized
INFO - 2016-02-22 14:19:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 14:19:44 --> Pagination Class Initialized
INFO - 2016-02-22 14:19:44 --> Helper loaded: text_helper
INFO - 2016-02-22 14:19:44 --> Helper loaded: cookie_helper
INFO - 2016-02-22 17:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 17:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 17:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-22 17:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 17:19:44 --> Final output sent to browser
DEBUG - 2016-02-22 17:19:44 --> Total execution time: 1.1640
INFO - 2016-02-22 14:20:05 --> Config Class Initialized
INFO - 2016-02-22 14:20:05 --> Hooks Class Initialized
DEBUG - 2016-02-22 14:20:05 --> UTF-8 Support Enabled
INFO - 2016-02-22 14:20:05 --> Utf8 Class Initialized
INFO - 2016-02-22 14:20:05 --> URI Class Initialized
DEBUG - 2016-02-22 14:20:05 --> No URI present. Default controller set.
INFO - 2016-02-22 14:20:05 --> Router Class Initialized
INFO - 2016-02-22 14:20:05 --> Output Class Initialized
INFO - 2016-02-22 14:20:05 --> Security Class Initialized
DEBUG - 2016-02-22 14:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 14:20:05 --> Input Class Initialized
INFO - 2016-02-22 14:20:05 --> Language Class Initialized
INFO - 2016-02-22 14:20:05 --> Loader Class Initialized
INFO - 2016-02-22 14:20:05 --> Helper loaded: url_helper
INFO - 2016-02-22 14:20:05 --> Helper loaded: file_helper
INFO - 2016-02-22 14:20:05 --> Helper loaded: date_helper
INFO - 2016-02-22 14:20:05 --> Helper loaded: form_helper
INFO - 2016-02-22 14:20:05 --> Database Driver Class Initialized
INFO - 2016-02-22 14:20:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 14:20:06 --> Controller Class Initialized
INFO - 2016-02-22 14:20:06 --> Model Class Initialized
INFO - 2016-02-22 14:20:06 --> Model Class Initialized
INFO - 2016-02-22 14:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 14:20:06 --> Pagination Class Initialized
INFO - 2016-02-22 14:20:06 --> Helper loaded: text_helper
INFO - 2016-02-22 14:20:06 --> Helper loaded: cookie_helper
INFO - 2016-02-22 17:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 17:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 17:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-22 17:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 17:20:06 --> Final output sent to browser
DEBUG - 2016-02-22 17:20:06 --> Total execution time: 1.0958
INFO - 2016-02-22 14:23:01 --> Config Class Initialized
INFO - 2016-02-22 14:23:01 --> Hooks Class Initialized
DEBUG - 2016-02-22 14:23:01 --> UTF-8 Support Enabled
INFO - 2016-02-22 14:23:01 --> Utf8 Class Initialized
INFO - 2016-02-22 14:23:01 --> URI Class Initialized
INFO - 2016-02-22 14:23:01 --> Router Class Initialized
INFO - 2016-02-22 14:23:01 --> Output Class Initialized
INFO - 2016-02-22 14:23:01 --> Security Class Initialized
DEBUG - 2016-02-22 14:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 14:23:01 --> Input Class Initialized
INFO - 2016-02-22 14:23:01 --> Language Class Initialized
INFO - 2016-02-22 14:23:01 --> Loader Class Initialized
INFO - 2016-02-22 14:23:01 --> Helper loaded: url_helper
INFO - 2016-02-22 14:23:01 --> Helper loaded: file_helper
INFO - 2016-02-22 14:23:01 --> Helper loaded: date_helper
INFO - 2016-02-22 14:23:01 --> Helper loaded: form_helper
INFO - 2016-02-22 14:23:01 --> Database Driver Class Initialized
INFO - 2016-02-22 14:23:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 14:23:02 --> Controller Class Initialized
INFO - 2016-02-22 14:23:02 --> Model Class Initialized
INFO - 2016-02-22 14:23:02 --> Model Class Initialized
INFO - 2016-02-22 14:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 14:23:02 --> Pagination Class Initialized
INFO - 2016-02-22 14:23:02 --> Helper loaded: text_helper
INFO - 2016-02-22 14:23:02 --> Helper loaded: cookie_helper
INFO - 2016-02-22 17:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 17:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 17:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-22 17:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 17:23:02 --> Final output sent to browser
DEBUG - 2016-02-22 17:23:02 --> Total execution time: 1.1186
INFO - 2016-02-22 14:23:07 --> Config Class Initialized
INFO - 2016-02-22 14:23:07 --> Hooks Class Initialized
DEBUG - 2016-02-22 14:23:07 --> UTF-8 Support Enabled
INFO - 2016-02-22 14:23:07 --> Utf8 Class Initialized
INFO - 2016-02-22 14:23:07 --> URI Class Initialized
DEBUG - 2016-02-22 14:23:07 --> No URI present. Default controller set.
INFO - 2016-02-22 14:23:07 --> Router Class Initialized
INFO - 2016-02-22 14:23:07 --> Output Class Initialized
INFO - 2016-02-22 14:23:07 --> Security Class Initialized
DEBUG - 2016-02-22 14:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-22 14:23:07 --> Input Class Initialized
INFO - 2016-02-22 14:23:07 --> Language Class Initialized
INFO - 2016-02-22 14:23:07 --> Loader Class Initialized
INFO - 2016-02-22 14:23:07 --> Helper loaded: url_helper
INFO - 2016-02-22 14:23:07 --> Helper loaded: file_helper
INFO - 2016-02-22 14:23:07 --> Helper loaded: date_helper
INFO - 2016-02-22 14:23:07 --> Helper loaded: form_helper
INFO - 2016-02-22 14:23:07 --> Database Driver Class Initialized
INFO - 2016-02-22 14:23:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-22 14:23:08 --> Controller Class Initialized
INFO - 2016-02-22 14:23:08 --> Model Class Initialized
INFO - 2016-02-22 14:23:08 --> Model Class Initialized
INFO - 2016-02-22 14:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-22 14:23:08 --> Pagination Class Initialized
INFO - 2016-02-22 14:23:08 --> Helper loaded: text_helper
INFO - 2016-02-22 14:23:08 --> Helper loaded: cookie_helper
INFO - 2016-02-22 17:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-22 17:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-22 17:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-22 17:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-22 17:23:08 --> Final output sent to browser
DEBUG - 2016-02-22 17:23:08 --> Total execution time: 1.0847
