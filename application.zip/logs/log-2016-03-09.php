<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-09 05:25:55 --> Config Class Initialized
INFO - 2016-03-09 05:25:55 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:25:55 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:25:55 --> Utf8 Class Initialized
INFO - 2016-03-09 05:25:55 --> URI Class Initialized
INFO - 2016-03-09 05:25:55 --> Router Class Initialized
INFO - 2016-03-09 05:25:55 --> Output Class Initialized
INFO - 2016-03-09 05:25:55 --> Security Class Initialized
DEBUG - 2016-03-09 05:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:25:56 --> Input Class Initialized
INFO - 2016-03-09 05:25:56 --> Language Class Initialized
INFO - 2016-03-09 05:25:56 --> Loader Class Initialized
INFO - 2016-03-09 05:25:56 --> Helper loaded: url_helper
INFO - 2016-03-09 05:25:56 --> Helper loaded: file_helper
INFO - 2016-03-09 05:25:56 --> Helper loaded: date_helper
INFO - 2016-03-09 05:25:56 --> Helper loaded: form_helper
INFO - 2016-03-09 05:25:56 --> Database Driver Class Initialized
INFO - 2016-03-09 05:25:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:25:57 --> Controller Class Initialized
INFO - 2016-03-09 05:25:57 --> Model Class Initialized
INFO - 2016-03-09 05:25:57 --> Model Class Initialized
INFO - 2016-03-09 05:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:25:57 --> Pagination Class Initialized
INFO - 2016-03-09 05:25:57 --> Helper loaded: text_helper
INFO - 2016-03-09 05:25:57 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-09 08:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:25:57 --> Final output sent to browser
DEBUG - 2016-03-09 08:25:57 --> Total execution time: 2.1258
INFO - 2016-03-09 05:28:35 --> Config Class Initialized
INFO - 2016-03-09 05:28:35 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:28:35 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:28:35 --> Utf8 Class Initialized
INFO - 2016-03-09 05:28:35 --> URI Class Initialized
INFO - 2016-03-09 05:28:35 --> Router Class Initialized
INFO - 2016-03-09 05:28:35 --> Output Class Initialized
INFO - 2016-03-09 05:28:35 --> Security Class Initialized
DEBUG - 2016-03-09 05:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:28:35 --> Input Class Initialized
INFO - 2016-03-09 05:28:35 --> Language Class Initialized
INFO - 2016-03-09 05:28:35 --> Loader Class Initialized
INFO - 2016-03-09 05:28:35 --> Helper loaded: url_helper
INFO - 2016-03-09 05:28:35 --> Helper loaded: file_helper
INFO - 2016-03-09 05:28:35 --> Helper loaded: date_helper
INFO - 2016-03-09 05:28:35 --> Helper loaded: form_helper
INFO - 2016-03-09 05:28:35 --> Database Driver Class Initialized
INFO - 2016-03-09 05:28:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:28:36 --> Controller Class Initialized
INFO - 2016-03-09 05:28:36 --> Model Class Initialized
INFO - 2016-03-09 05:28:36 --> Model Class Initialized
INFO - 2016-03-09 05:28:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:28:36 --> Pagination Class Initialized
INFO - 2016-03-09 05:28:36 --> Helper loaded: text_helper
INFO - 2016-03-09 05:28:36 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-09 08:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:28:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:28:36 --> Final output sent to browser
DEBUG - 2016-03-09 08:28:36 --> Total execution time: 1.2394
INFO - 2016-03-09 05:29:19 --> Config Class Initialized
INFO - 2016-03-09 05:29:19 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:29:19 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:29:19 --> Utf8 Class Initialized
INFO - 2016-03-09 05:29:19 --> URI Class Initialized
INFO - 2016-03-09 05:29:19 --> Router Class Initialized
INFO - 2016-03-09 05:29:19 --> Output Class Initialized
INFO - 2016-03-09 05:29:19 --> Security Class Initialized
DEBUG - 2016-03-09 05:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:29:19 --> Input Class Initialized
INFO - 2016-03-09 05:29:19 --> Language Class Initialized
INFO - 2016-03-09 05:29:19 --> Loader Class Initialized
INFO - 2016-03-09 05:29:19 --> Helper loaded: url_helper
INFO - 2016-03-09 05:29:19 --> Helper loaded: file_helper
INFO - 2016-03-09 05:29:19 --> Helper loaded: date_helper
INFO - 2016-03-09 05:29:19 --> Helper loaded: form_helper
INFO - 2016-03-09 05:29:19 --> Database Driver Class Initialized
INFO - 2016-03-09 05:29:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:29:20 --> Controller Class Initialized
INFO - 2016-03-09 05:29:20 --> Model Class Initialized
INFO - 2016-03-09 05:29:20 --> Model Class Initialized
INFO - 2016-03-09 05:29:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:29:20 --> Pagination Class Initialized
INFO - 2016-03-09 05:29:20 --> Helper loaded: text_helper
INFO - 2016-03-09 05:29:20 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-09 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:29:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:29:20 --> Final output sent to browser
DEBUG - 2016-03-09 08:29:20 --> Total execution time: 1.1214
INFO - 2016-03-09 05:30:34 --> Config Class Initialized
INFO - 2016-03-09 05:30:34 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:30:34 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:30:34 --> Utf8 Class Initialized
INFO - 2016-03-09 05:30:34 --> URI Class Initialized
INFO - 2016-03-09 05:30:34 --> Router Class Initialized
INFO - 2016-03-09 05:30:34 --> Output Class Initialized
INFO - 2016-03-09 05:30:34 --> Security Class Initialized
DEBUG - 2016-03-09 05:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:30:34 --> Input Class Initialized
INFO - 2016-03-09 05:30:34 --> Language Class Initialized
INFO - 2016-03-09 05:30:34 --> Loader Class Initialized
INFO - 2016-03-09 05:30:34 --> Helper loaded: url_helper
INFO - 2016-03-09 05:30:34 --> Helper loaded: file_helper
INFO - 2016-03-09 05:30:34 --> Helper loaded: date_helper
INFO - 2016-03-09 05:30:34 --> Helper loaded: form_helper
INFO - 2016-03-09 05:30:34 --> Database Driver Class Initialized
INFO - 2016-03-09 05:30:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:30:35 --> Controller Class Initialized
INFO - 2016-03-09 05:30:35 --> Model Class Initialized
INFO - 2016-03-09 05:30:35 --> Model Class Initialized
INFO - 2016-03-09 05:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:30:35 --> Pagination Class Initialized
INFO - 2016-03-09 05:30:35 --> Helper loaded: text_helper
INFO - 2016-03-09 05:30:35 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-09 08:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:30:35 --> Final output sent to browser
DEBUG - 2016-03-09 08:30:35 --> Total execution time: 1.1509
INFO - 2016-03-09 05:35:27 --> Config Class Initialized
INFO - 2016-03-09 05:35:27 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:35:27 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:35:27 --> Utf8 Class Initialized
INFO - 2016-03-09 05:35:27 --> URI Class Initialized
INFO - 2016-03-09 05:35:27 --> Router Class Initialized
INFO - 2016-03-09 05:35:27 --> Output Class Initialized
INFO - 2016-03-09 05:35:27 --> Security Class Initialized
DEBUG - 2016-03-09 05:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:35:27 --> Input Class Initialized
INFO - 2016-03-09 05:35:27 --> Language Class Initialized
INFO - 2016-03-09 05:35:27 --> Loader Class Initialized
INFO - 2016-03-09 05:35:27 --> Helper loaded: url_helper
INFO - 2016-03-09 05:35:27 --> Helper loaded: file_helper
INFO - 2016-03-09 05:35:27 --> Helper loaded: date_helper
INFO - 2016-03-09 05:35:27 --> Helper loaded: form_helper
INFO - 2016-03-09 05:35:27 --> Database Driver Class Initialized
INFO - 2016-03-09 05:35:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:35:28 --> Controller Class Initialized
INFO - 2016-03-09 05:35:28 --> Model Class Initialized
INFO - 2016-03-09 05:35:28 --> Model Class Initialized
INFO - 2016-03-09 05:35:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:35:28 --> Pagination Class Initialized
INFO - 2016-03-09 05:35:28 --> Helper loaded: text_helper
INFO - 2016-03-09 05:35:28 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:35:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:35:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:35:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:35:29 --> Final output sent to browser
DEBUG - 2016-03-09 08:35:29 --> Total execution time: 1.3317
INFO - 2016-03-09 05:35:32 --> Config Class Initialized
INFO - 2016-03-09 05:35:32 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:35:32 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:35:32 --> Utf8 Class Initialized
INFO - 2016-03-09 05:35:32 --> URI Class Initialized
INFO - 2016-03-09 05:35:32 --> Router Class Initialized
INFO - 2016-03-09 05:35:32 --> Output Class Initialized
INFO - 2016-03-09 05:35:32 --> Security Class Initialized
DEBUG - 2016-03-09 05:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:35:32 --> Input Class Initialized
INFO - 2016-03-09 05:35:32 --> Language Class Initialized
INFO - 2016-03-09 05:35:32 --> Loader Class Initialized
INFO - 2016-03-09 05:35:32 --> Helper loaded: url_helper
INFO - 2016-03-09 05:35:32 --> Helper loaded: file_helper
INFO - 2016-03-09 05:35:32 --> Helper loaded: date_helper
INFO - 2016-03-09 05:35:32 --> Helper loaded: form_helper
INFO - 2016-03-09 05:35:32 --> Database Driver Class Initialized
INFO - 2016-03-09 05:35:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:35:33 --> Controller Class Initialized
INFO - 2016-03-09 05:35:33 --> Model Class Initialized
INFO - 2016-03-09 05:35:33 --> Model Class Initialized
INFO - 2016-03-09 05:35:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:35:33 --> Pagination Class Initialized
INFO - 2016-03-09 05:35:33 --> Helper loaded: text_helper
INFO - 2016-03-09 05:35:33 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:35:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:35:33 --> Final output sent to browser
DEBUG - 2016-03-09 08:35:33 --> Total execution time: 1.1483
INFO - 2016-03-09 05:35:35 --> Config Class Initialized
INFO - 2016-03-09 05:35:35 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:35:35 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:35:35 --> Utf8 Class Initialized
INFO - 2016-03-09 05:35:35 --> URI Class Initialized
INFO - 2016-03-09 05:35:35 --> Router Class Initialized
INFO - 2016-03-09 05:35:35 --> Output Class Initialized
INFO - 2016-03-09 05:35:35 --> Security Class Initialized
DEBUG - 2016-03-09 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:35:35 --> Input Class Initialized
INFO - 2016-03-09 05:35:35 --> Language Class Initialized
INFO - 2016-03-09 05:35:35 --> Loader Class Initialized
INFO - 2016-03-09 05:35:35 --> Helper loaded: url_helper
INFO - 2016-03-09 05:35:35 --> Helper loaded: file_helper
INFO - 2016-03-09 05:35:35 --> Helper loaded: date_helper
INFO - 2016-03-09 05:35:35 --> Helper loaded: form_helper
INFO - 2016-03-09 05:35:35 --> Database Driver Class Initialized
INFO - 2016-03-09 05:35:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:35:36 --> Controller Class Initialized
INFO - 2016-03-09 05:35:36 --> Model Class Initialized
INFO - 2016-03-09 05:35:36 --> Model Class Initialized
INFO - 2016-03-09 05:35:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:35:36 --> Pagination Class Initialized
INFO - 2016-03-09 05:35:36 --> Helper loaded: text_helper
INFO - 2016-03-09 05:35:36 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:35:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:35:36 --> Final output sent to browser
DEBUG - 2016-03-09 08:35:36 --> Total execution time: 1.1271
INFO - 2016-03-09 05:35:39 --> Config Class Initialized
INFO - 2016-03-09 05:35:39 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:35:39 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:35:39 --> Utf8 Class Initialized
INFO - 2016-03-09 05:35:39 --> URI Class Initialized
INFO - 2016-03-09 05:35:39 --> Router Class Initialized
INFO - 2016-03-09 05:35:39 --> Output Class Initialized
INFO - 2016-03-09 05:35:39 --> Security Class Initialized
DEBUG - 2016-03-09 05:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:35:39 --> Input Class Initialized
INFO - 2016-03-09 05:35:39 --> Language Class Initialized
INFO - 2016-03-09 05:35:39 --> Loader Class Initialized
INFO - 2016-03-09 05:35:39 --> Helper loaded: url_helper
INFO - 2016-03-09 05:35:39 --> Helper loaded: file_helper
INFO - 2016-03-09 05:35:39 --> Helper loaded: date_helper
INFO - 2016-03-09 05:35:39 --> Helper loaded: form_helper
INFO - 2016-03-09 05:35:39 --> Database Driver Class Initialized
INFO - 2016-03-09 05:35:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:35:40 --> Controller Class Initialized
INFO - 2016-03-09 05:35:40 --> Model Class Initialized
INFO - 2016-03-09 05:35:40 --> Model Class Initialized
INFO - 2016-03-09 05:35:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:35:40 --> Pagination Class Initialized
INFO - 2016-03-09 05:35:40 --> Helper loaded: text_helper
INFO - 2016-03-09 05:35:40 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:35:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:35:40 --> Final output sent to browser
DEBUG - 2016-03-09 08:35:40 --> Total execution time: 1.1287
INFO - 2016-03-09 05:35:42 --> Config Class Initialized
INFO - 2016-03-09 05:35:42 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:35:42 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:35:42 --> Utf8 Class Initialized
INFO - 2016-03-09 05:35:42 --> URI Class Initialized
INFO - 2016-03-09 05:35:42 --> Router Class Initialized
INFO - 2016-03-09 05:35:42 --> Output Class Initialized
INFO - 2016-03-09 05:35:42 --> Security Class Initialized
DEBUG - 2016-03-09 05:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:35:42 --> Input Class Initialized
INFO - 2016-03-09 05:35:42 --> Language Class Initialized
INFO - 2016-03-09 05:35:42 --> Loader Class Initialized
INFO - 2016-03-09 05:35:42 --> Helper loaded: url_helper
INFO - 2016-03-09 05:35:42 --> Helper loaded: file_helper
INFO - 2016-03-09 05:35:42 --> Helper loaded: date_helper
INFO - 2016-03-09 05:35:42 --> Helper loaded: form_helper
INFO - 2016-03-09 05:35:42 --> Database Driver Class Initialized
INFO - 2016-03-09 05:35:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:35:43 --> Controller Class Initialized
INFO - 2016-03-09 05:35:43 --> Model Class Initialized
INFO - 2016-03-09 05:35:43 --> Model Class Initialized
INFO - 2016-03-09 05:35:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:35:43 --> Pagination Class Initialized
INFO - 2016-03-09 05:35:43 --> Helper loaded: text_helper
INFO - 2016-03-09 05:35:43 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:35:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:35:44 --> Final output sent to browser
DEBUG - 2016-03-09 08:35:44 --> Total execution time: 1.2491
INFO - 2016-03-09 05:37:38 --> Config Class Initialized
INFO - 2016-03-09 05:37:38 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:37:38 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:37:38 --> Utf8 Class Initialized
INFO - 2016-03-09 05:37:38 --> URI Class Initialized
INFO - 2016-03-09 05:37:38 --> Router Class Initialized
INFO - 2016-03-09 05:37:38 --> Output Class Initialized
INFO - 2016-03-09 05:37:38 --> Security Class Initialized
DEBUG - 2016-03-09 05:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:37:38 --> Input Class Initialized
INFO - 2016-03-09 05:37:38 --> Language Class Initialized
ERROR - 2016-03-09 05:37:38 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 180
INFO - 2016-03-09 05:37:44 --> Config Class Initialized
INFO - 2016-03-09 05:37:44 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:37:44 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:37:44 --> Utf8 Class Initialized
INFO - 2016-03-09 05:37:44 --> URI Class Initialized
INFO - 2016-03-09 05:37:44 --> Router Class Initialized
INFO - 2016-03-09 05:37:44 --> Output Class Initialized
INFO - 2016-03-09 05:37:44 --> Security Class Initialized
DEBUG - 2016-03-09 05:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:37:44 --> Input Class Initialized
INFO - 2016-03-09 05:37:44 --> Language Class Initialized
INFO - 2016-03-09 05:37:44 --> Loader Class Initialized
INFO - 2016-03-09 05:37:44 --> Helper loaded: url_helper
INFO - 2016-03-09 05:37:44 --> Helper loaded: file_helper
INFO - 2016-03-09 05:37:44 --> Helper loaded: date_helper
INFO - 2016-03-09 05:37:44 --> Helper loaded: form_helper
INFO - 2016-03-09 05:37:44 --> Database Driver Class Initialized
INFO - 2016-03-09 05:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:37:45 --> Controller Class Initialized
INFO - 2016-03-09 05:37:45 --> Model Class Initialized
INFO - 2016-03-09 05:37:45 --> Model Class Initialized
INFO - 2016-03-09 05:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:37:45 --> Pagination Class Initialized
INFO - 2016-03-09 05:37:45 --> Helper loaded: text_helper
INFO - 2016-03-09 05:37:45 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 08:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:37:45 --> Final output sent to browser
DEBUG - 2016-03-09 08:37:45 --> Total execution time: 1.1874
INFO - 2016-03-09 05:38:16 --> Config Class Initialized
INFO - 2016-03-09 05:38:16 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:38:16 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:38:16 --> Utf8 Class Initialized
INFO - 2016-03-09 05:38:16 --> URI Class Initialized
INFO - 2016-03-09 05:38:16 --> Router Class Initialized
INFO - 2016-03-09 05:38:16 --> Output Class Initialized
INFO - 2016-03-09 05:38:16 --> Security Class Initialized
DEBUG - 2016-03-09 05:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:38:16 --> Input Class Initialized
INFO - 2016-03-09 05:38:16 --> Language Class Initialized
INFO - 2016-03-09 05:38:16 --> Loader Class Initialized
INFO - 2016-03-09 05:38:16 --> Helper loaded: url_helper
INFO - 2016-03-09 05:38:16 --> Helper loaded: file_helper
INFO - 2016-03-09 05:38:16 --> Helper loaded: date_helper
INFO - 2016-03-09 05:38:16 --> Helper loaded: form_helper
INFO - 2016-03-09 05:38:16 --> Database Driver Class Initialized
INFO - 2016-03-09 05:38:17 --> Config Class Initialized
INFO - 2016-03-09 05:38:17 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:38:17 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:38:17 --> Utf8 Class Initialized
INFO - 2016-03-09 05:38:17 --> URI Class Initialized
INFO - 2016-03-09 05:38:17 --> Router Class Initialized
INFO - 2016-03-09 05:38:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:38:17 --> Output Class Initialized
INFO - 2016-03-09 05:38:17 --> Controller Class Initialized
INFO - 2016-03-09 05:38:17 --> Model Class Initialized
INFO - 2016-03-09 05:38:17 --> Security Class Initialized
INFO - 2016-03-09 05:38:17 --> Model Class Initialized
DEBUG - 2016-03-09 05:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:38:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:38:17 --> Input Class Initialized
INFO - 2016-03-09 05:38:17 --> Pagination Class Initialized
INFO - 2016-03-09 05:38:17 --> Language Class Initialized
INFO - 2016-03-09 05:38:17 --> Helper loaded: text_helper
INFO - 2016-03-09 05:38:17 --> Helper loaded: cookie_helper
INFO - 2016-03-09 05:38:17 --> Loader Class Initialized
INFO - 2016-03-09 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 05:38:17 --> Helper loaded: url_helper
INFO - 2016-03-09 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 05:38:17 --> Helper loaded: file_helper
INFO - 2016-03-09 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 05:38:17 --> Helper loaded: date_helper
INFO - 2016-03-09 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 05:38:17 --> Helper loaded: form_helper
INFO - 2016-03-09 08:38:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:38:17 --> Final output sent to browser
DEBUG - 2016-03-09 08:38:17 --> Total execution time: 1.0970
INFO - 2016-03-09 05:38:17 --> Database Driver Class Initialized
INFO - 2016-03-09 05:38:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:38:18 --> Controller Class Initialized
INFO - 2016-03-09 05:38:18 --> Model Class Initialized
INFO - 2016-03-09 05:38:18 --> Model Class Initialized
INFO - 2016-03-09 05:38:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:38:18 --> Pagination Class Initialized
INFO - 2016-03-09 05:38:18 --> Helper loaded: text_helper
INFO - 2016-03-09 05:38:18 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:38:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:38:18 --> Final output sent to browser
DEBUG - 2016-03-09 08:38:18 --> Total execution time: 1.1211
INFO - 2016-03-09 05:38:23 --> Config Class Initialized
INFO - 2016-03-09 05:38:23 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:38:23 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:38:23 --> Utf8 Class Initialized
INFO - 2016-03-09 05:38:23 --> URI Class Initialized
INFO - 2016-03-09 05:38:23 --> Router Class Initialized
INFO - 2016-03-09 05:38:23 --> Output Class Initialized
INFO - 2016-03-09 05:38:23 --> Security Class Initialized
DEBUG - 2016-03-09 05:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:38:23 --> Input Class Initialized
INFO - 2016-03-09 05:38:23 --> Language Class Initialized
INFO - 2016-03-09 05:38:23 --> Loader Class Initialized
INFO - 2016-03-09 05:38:23 --> Helper loaded: url_helper
INFO - 2016-03-09 05:38:23 --> Helper loaded: file_helper
INFO - 2016-03-09 05:38:23 --> Helper loaded: date_helper
INFO - 2016-03-09 05:38:23 --> Helper loaded: form_helper
INFO - 2016-03-09 05:38:23 --> Database Driver Class Initialized
INFO - 2016-03-09 05:38:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:38:24 --> Controller Class Initialized
INFO - 2016-03-09 05:38:24 --> Model Class Initialized
INFO - 2016-03-09 05:38:24 --> Model Class Initialized
INFO - 2016-03-09 05:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:38:24 --> Pagination Class Initialized
INFO - 2016-03-09 05:38:24 --> Helper loaded: text_helper
INFO - 2016-03-09 05:38:24 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:38:24 --> Final output sent to browser
DEBUG - 2016-03-09 08:38:24 --> Total execution time: 1.1174
INFO - 2016-03-09 05:38:26 --> Config Class Initialized
INFO - 2016-03-09 05:38:26 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:38:26 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:38:26 --> Utf8 Class Initialized
INFO - 2016-03-09 05:38:26 --> URI Class Initialized
INFO - 2016-03-09 05:38:26 --> Router Class Initialized
INFO - 2016-03-09 05:38:26 --> Output Class Initialized
INFO - 2016-03-09 05:38:26 --> Security Class Initialized
DEBUG - 2016-03-09 05:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:38:26 --> Input Class Initialized
INFO - 2016-03-09 05:38:26 --> Language Class Initialized
INFO - 2016-03-09 05:38:26 --> Loader Class Initialized
INFO - 2016-03-09 05:38:26 --> Helper loaded: url_helper
INFO - 2016-03-09 05:38:26 --> Helper loaded: file_helper
INFO - 2016-03-09 05:38:26 --> Helper loaded: date_helper
INFO - 2016-03-09 05:38:26 --> Helper loaded: form_helper
INFO - 2016-03-09 05:38:26 --> Database Driver Class Initialized
INFO - 2016-03-09 05:38:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:38:27 --> Controller Class Initialized
INFO - 2016-03-09 05:38:27 --> User Agent Class Initialized
INFO - 2016-03-09 05:38:27 --> Final output sent to browser
DEBUG - 2016-03-09 05:38:27 --> Total execution time: 1.1082
INFO - 2016-03-09 05:38:31 --> Config Class Initialized
INFO - 2016-03-09 05:38:31 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:38:31 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:38:31 --> Utf8 Class Initialized
INFO - 2016-03-09 05:38:31 --> URI Class Initialized
INFO - 2016-03-09 05:38:31 --> Router Class Initialized
INFO - 2016-03-09 05:38:31 --> Output Class Initialized
INFO - 2016-03-09 05:38:31 --> Security Class Initialized
DEBUG - 2016-03-09 05:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:38:31 --> Input Class Initialized
INFO - 2016-03-09 05:38:31 --> Language Class Initialized
INFO - 2016-03-09 05:38:31 --> Loader Class Initialized
INFO - 2016-03-09 05:38:31 --> Helper loaded: url_helper
INFO - 2016-03-09 05:38:31 --> Helper loaded: file_helper
INFO - 2016-03-09 05:38:31 --> Helper loaded: date_helper
INFO - 2016-03-09 05:38:31 --> Helper loaded: form_helper
INFO - 2016-03-09 05:38:31 --> Database Driver Class Initialized
INFO - 2016-03-09 05:38:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:38:32 --> Controller Class Initialized
INFO - 2016-03-09 05:38:32 --> Model Class Initialized
INFO - 2016-03-09 05:38:32 --> Model Class Initialized
INFO - 2016-03-09 05:38:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:38:32 --> Pagination Class Initialized
INFO - 2016-03-09 05:38:32 --> Helper loaded: text_helper
INFO - 2016-03-09 05:38:32 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:38:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:38:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:38:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:38:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:38:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:38:32 --> Final output sent to browser
DEBUG - 2016-03-09 08:38:32 --> Total execution time: 1.1631
INFO - 2016-03-09 05:40:58 --> Config Class Initialized
INFO - 2016-03-09 05:40:58 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:40:58 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:40:58 --> Utf8 Class Initialized
INFO - 2016-03-09 05:40:58 --> URI Class Initialized
INFO - 2016-03-09 05:40:59 --> Router Class Initialized
INFO - 2016-03-09 05:40:59 --> Output Class Initialized
INFO - 2016-03-09 05:40:59 --> Security Class Initialized
DEBUG - 2016-03-09 05:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:40:59 --> Input Class Initialized
INFO - 2016-03-09 05:40:59 --> Language Class Initialized
INFO - 2016-03-09 05:40:59 --> Loader Class Initialized
INFO - 2016-03-09 05:40:59 --> Helper loaded: url_helper
INFO - 2016-03-09 05:40:59 --> Helper loaded: file_helper
INFO - 2016-03-09 05:40:59 --> Helper loaded: date_helper
INFO - 2016-03-09 05:40:59 --> Helper loaded: form_helper
INFO - 2016-03-09 05:40:59 --> Database Driver Class Initialized
INFO - 2016-03-09 05:41:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:41:00 --> Controller Class Initialized
INFO - 2016-03-09 05:41:00 --> Model Class Initialized
INFO - 2016-03-09 05:41:00 --> Model Class Initialized
INFO - 2016-03-09 05:41:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:41:00 --> Pagination Class Initialized
INFO - 2016-03-09 05:41:00 --> Helper loaded: text_helper
INFO - 2016-03-09 05:41:00 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-09 08:41:00 --> Severity: Notice --> Undefined variable: per_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 178
INFO - 2016-03-09 08:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 08:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:41:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:41:00 --> Final output sent to browser
DEBUG - 2016-03-09 08:41:00 --> Total execution time: 1.1992
INFO - 2016-03-09 05:41:12 --> Config Class Initialized
INFO - 2016-03-09 05:41:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:41:12 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:41:12 --> Utf8 Class Initialized
INFO - 2016-03-09 05:41:12 --> URI Class Initialized
INFO - 2016-03-09 05:41:12 --> Router Class Initialized
INFO - 2016-03-09 05:41:12 --> Output Class Initialized
INFO - 2016-03-09 05:41:12 --> Security Class Initialized
DEBUG - 2016-03-09 05:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:41:12 --> Input Class Initialized
INFO - 2016-03-09 05:41:12 --> Language Class Initialized
INFO - 2016-03-09 05:41:12 --> Loader Class Initialized
INFO - 2016-03-09 05:41:12 --> Helper loaded: url_helper
INFO - 2016-03-09 05:41:12 --> Helper loaded: file_helper
INFO - 2016-03-09 05:41:12 --> Helper loaded: date_helper
INFO - 2016-03-09 05:41:12 --> Helper loaded: form_helper
INFO - 2016-03-09 05:41:12 --> Database Driver Class Initialized
INFO - 2016-03-09 05:41:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:41:13 --> Controller Class Initialized
INFO - 2016-03-09 05:41:13 --> Model Class Initialized
INFO - 2016-03-09 05:41:13 --> Model Class Initialized
INFO - 2016-03-09 05:41:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:41:13 --> Pagination Class Initialized
INFO - 2016-03-09 05:41:13 --> Helper loaded: text_helper
INFO - 2016-03-09 05:41:13 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 08:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:41:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:41:13 --> Final output sent to browser
DEBUG - 2016-03-09 08:41:13 --> Total execution time: 1.1641
INFO - 2016-03-09 05:42:49 --> Config Class Initialized
INFO - 2016-03-09 05:42:49 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:42:49 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:42:49 --> Utf8 Class Initialized
INFO - 2016-03-09 05:42:49 --> URI Class Initialized
INFO - 2016-03-09 05:42:49 --> Router Class Initialized
INFO - 2016-03-09 05:42:49 --> Output Class Initialized
INFO - 2016-03-09 05:42:49 --> Security Class Initialized
DEBUG - 2016-03-09 05:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:42:49 --> Input Class Initialized
INFO - 2016-03-09 05:42:49 --> Language Class Initialized
INFO - 2016-03-09 05:42:49 --> Loader Class Initialized
INFO - 2016-03-09 05:42:49 --> Helper loaded: url_helper
INFO - 2016-03-09 05:42:49 --> Helper loaded: file_helper
INFO - 2016-03-09 05:42:49 --> Helper loaded: date_helper
INFO - 2016-03-09 05:42:49 --> Helper loaded: form_helper
INFO - 2016-03-09 05:42:49 --> Database Driver Class Initialized
INFO - 2016-03-09 05:42:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:42:50 --> Controller Class Initialized
INFO - 2016-03-09 05:42:50 --> Model Class Initialized
INFO - 2016-03-09 05:42:50 --> Model Class Initialized
INFO - 2016-03-09 05:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:42:50 --> Pagination Class Initialized
INFO - 2016-03-09 05:42:50 --> Helper loaded: text_helper
INFO - 2016-03-09 05:42:50 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:42:50 --> Final output sent to browser
DEBUG - 2016-03-09 08:42:50 --> Total execution time: 1.1522
INFO - 2016-03-09 05:42:52 --> Config Class Initialized
INFO - 2016-03-09 05:42:52 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:42:52 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:42:52 --> Utf8 Class Initialized
INFO - 2016-03-09 05:42:52 --> URI Class Initialized
INFO - 2016-03-09 05:42:52 --> Router Class Initialized
INFO - 2016-03-09 05:42:52 --> Output Class Initialized
INFO - 2016-03-09 05:42:52 --> Security Class Initialized
DEBUG - 2016-03-09 05:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:42:52 --> Input Class Initialized
INFO - 2016-03-09 05:42:52 --> Language Class Initialized
INFO - 2016-03-09 05:42:52 --> Loader Class Initialized
INFO - 2016-03-09 05:42:52 --> Helper loaded: url_helper
INFO - 2016-03-09 05:42:52 --> Helper loaded: file_helper
INFO - 2016-03-09 05:42:52 --> Helper loaded: date_helper
INFO - 2016-03-09 05:42:52 --> Helper loaded: form_helper
INFO - 2016-03-09 05:42:52 --> Database Driver Class Initialized
INFO - 2016-03-09 05:42:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:42:53 --> Controller Class Initialized
INFO - 2016-03-09 05:42:53 --> Model Class Initialized
INFO - 2016-03-09 05:42:53 --> Model Class Initialized
INFO - 2016-03-09 05:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:42:53 --> Pagination Class Initialized
INFO - 2016-03-09 05:42:53 --> Helper loaded: text_helper
INFO - 2016-03-09 05:42:53 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:42:53 --> Final output sent to browser
DEBUG - 2016-03-09 08:42:53 --> Total execution time: 1.0970
INFO - 2016-03-09 05:42:57 --> Config Class Initialized
INFO - 2016-03-09 05:42:57 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:42:57 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:42:57 --> Utf8 Class Initialized
INFO - 2016-03-09 05:42:57 --> URI Class Initialized
INFO - 2016-03-09 05:42:57 --> Router Class Initialized
INFO - 2016-03-09 05:42:57 --> Output Class Initialized
INFO - 2016-03-09 05:42:57 --> Security Class Initialized
DEBUG - 2016-03-09 05:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:42:57 --> Input Class Initialized
INFO - 2016-03-09 05:42:57 --> Language Class Initialized
INFO - 2016-03-09 05:42:57 --> Loader Class Initialized
INFO - 2016-03-09 05:42:57 --> Helper loaded: url_helper
INFO - 2016-03-09 05:42:57 --> Helper loaded: file_helper
INFO - 2016-03-09 05:42:57 --> Helper loaded: date_helper
INFO - 2016-03-09 05:42:57 --> Helper loaded: form_helper
INFO - 2016-03-09 05:42:57 --> Database Driver Class Initialized
INFO - 2016-03-09 05:42:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:42:58 --> Controller Class Initialized
INFO - 2016-03-09 05:42:58 --> Model Class Initialized
INFO - 2016-03-09 05:42:58 --> Model Class Initialized
INFO - 2016-03-09 05:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:42:58 --> Pagination Class Initialized
INFO - 2016-03-09 05:42:58 --> Helper loaded: text_helper
INFO - 2016-03-09 05:42:58 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 08:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:42:58 --> Final output sent to browser
DEBUG - 2016-03-09 08:42:58 --> Total execution time: 1.1572
INFO - 2016-03-09 05:43:30 --> Config Class Initialized
INFO - 2016-03-09 05:43:30 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:43:30 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:43:30 --> Utf8 Class Initialized
INFO - 2016-03-09 05:43:30 --> URI Class Initialized
INFO - 2016-03-09 05:43:30 --> Router Class Initialized
INFO - 2016-03-09 05:43:30 --> Output Class Initialized
INFO - 2016-03-09 05:43:30 --> Security Class Initialized
DEBUG - 2016-03-09 05:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:43:30 --> Input Class Initialized
INFO - 2016-03-09 05:43:30 --> Language Class Initialized
INFO - 2016-03-09 05:43:30 --> Loader Class Initialized
INFO - 2016-03-09 05:43:30 --> Helper loaded: url_helper
INFO - 2016-03-09 05:43:30 --> Helper loaded: file_helper
INFO - 2016-03-09 05:43:30 --> Helper loaded: date_helper
INFO - 2016-03-09 05:43:30 --> Helper loaded: form_helper
INFO - 2016-03-09 05:43:30 --> Database Driver Class Initialized
INFO - 2016-03-09 05:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:43:31 --> Controller Class Initialized
INFO - 2016-03-09 05:43:31 --> Model Class Initialized
INFO - 2016-03-09 05:43:31 --> Model Class Initialized
INFO - 2016-03-09 05:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:43:31 --> Pagination Class Initialized
INFO - 2016-03-09 05:43:31 --> Helper loaded: text_helper
INFO - 2016-03-09 05:43:31 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 08:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:43:31 --> Final output sent to browser
DEBUG - 2016-03-09 08:43:31 --> Total execution time: 1.2127
INFO - 2016-03-09 05:43:45 --> Config Class Initialized
INFO - 2016-03-09 05:43:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:43:45 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:43:45 --> Utf8 Class Initialized
INFO - 2016-03-09 05:43:45 --> URI Class Initialized
INFO - 2016-03-09 05:43:45 --> Router Class Initialized
INFO - 2016-03-09 05:43:45 --> Output Class Initialized
INFO - 2016-03-09 05:43:45 --> Security Class Initialized
DEBUG - 2016-03-09 05:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:43:45 --> Input Class Initialized
INFO - 2016-03-09 05:43:45 --> Language Class Initialized
INFO - 2016-03-09 05:43:45 --> Loader Class Initialized
INFO - 2016-03-09 05:43:45 --> Helper loaded: url_helper
INFO - 2016-03-09 05:43:45 --> Helper loaded: file_helper
INFO - 2016-03-09 05:43:45 --> Helper loaded: date_helper
INFO - 2016-03-09 05:43:45 --> Helper loaded: form_helper
INFO - 2016-03-09 05:43:45 --> Database Driver Class Initialized
INFO - 2016-03-09 05:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:43:46 --> Controller Class Initialized
INFO - 2016-03-09 05:43:46 --> Model Class Initialized
INFO - 2016-03-09 05:43:46 --> Model Class Initialized
INFO - 2016-03-09 05:43:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:43:47 --> Pagination Class Initialized
INFO - 2016-03-09 05:43:47 --> Helper loaded: text_helper
INFO - 2016-03-09 05:43:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:43:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:43:47 --> Final output sent to browser
DEBUG - 2016-03-09 08:43:47 --> Total execution time: 1.0990
INFO - 2016-03-09 05:43:50 --> Config Class Initialized
INFO - 2016-03-09 05:43:50 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:43:50 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:43:50 --> Utf8 Class Initialized
INFO - 2016-03-09 05:43:50 --> URI Class Initialized
INFO - 2016-03-09 05:43:50 --> Router Class Initialized
INFO - 2016-03-09 05:43:50 --> Output Class Initialized
INFO - 2016-03-09 05:43:50 --> Security Class Initialized
DEBUG - 2016-03-09 05:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:43:50 --> Input Class Initialized
INFO - 2016-03-09 05:43:50 --> Language Class Initialized
INFO - 2016-03-09 05:43:50 --> Loader Class Initialized
INFO - 2016-03-09 05:43:50 --> Helper loaded: url_helper
INFO - 2016-03-09 05:43:50 --> Helper loaded: file_helper
INFO - 2016-03-09 05:43:50 --> Helper loaded: date_helper
INFO - 2016-03-09 05:43:50 --> Helper loaded: form_helper
INFO - 2016-03-09 05:43:50 --> Database Driver Class Initialized
INFO - 2016-03-09 05:43:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:43:51 --> Controller Class Initialized
INFO - 2016-03-09 05:43:51 --> Model Class Initialized
INFO - 2016-03-09 05:43:51 --> Model Class Initialized
INFO - 2016-03-09 05:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:43:51 --> Pagination Class Initialized
INFO - 2016-03-09 05:43:51 --> Helper loaded: text_helper
INFO - 2016-03-09 05:43:51 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:43:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:43:51 --> Final output sent to browser
DEBUG - 2016-03-09 08:43:51 --> Total execution time: 1.1402
INFO - 2016-03-09 05:43:54 --> Config Class Initialized
INFO - 2016-03-09 05:43:54 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:43:54 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:43:54 --> Utf8 Class Initialized
INFO - 2016-03-09 05:43:54 --> URI Class Initialized
INFO - 2016-03-09 05:43:54 --> Router Class Initialized
INFO - 2016-03-09 05:43:54 --> Output Class Initialized
INFO - 2016-03-09 05:43:54 --> Security Class Initialized
DEBUG - 2016-03-09 05:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:43:54 --> Input Class Initialized
INFO - 2016-03-09 05:43:54 --> Language Class Initialized
INFO - 2016-03-09 05:43:54 --> Loader Class Initialized
INFO - 2016-03-09 05:43:54 --> Helper loaded: url_helper
INFO - 2016-03-09 05:43:54 --> Helper loaded: file_helper
INFO - 2016-03-09 05:43:54 --> Helper loaded: date_helper
INFO - 2016-03-09 05:43:54 --> Helper loaded: form_helper
INFO - 2016-03-09 05:43:54 --> Database Driver Class Initialized
INFO - 2016-03-09 05:43:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:43:55 --> Controller Class Initialized
INFO - 2016-03-09 05:43:55 --> Model Class Initialized
INFO - 2016-03-09 05:43:55 --> Model Class Initialized
INFO - 2016-03-09 05:43:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:43:55 --> Pagination Class Initialized
INFO - 2016-03-09 05:43:55 --> Helper loaded: text_helper
INFO - 2016-03-09 05:43:55 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 08:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:43:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:43:55 --> Final output sent to browser
DEBUG - 2016-03-09 08:43:55 --> Total execution time: 1.2077
INFO - 2016-03-09 05:45:02 --> Config Class Initialized
INFO - 2016-03-09 05:45:02 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:45:02 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:45:02 --> Utf8 Class Initialized
INFO - 2016-03-09 05:45:02 --> URI Class Initialized
INFO - 2016-03-09 05:45:02 --> Router Class Initialized
INFO - 2016-03-09 05:45:02 --> Output Class Initialized
INFO - 2016-03-09 05:45:02 --> Security Class Initialized
DEBUG - 2016-03-09 05:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:45:02 --> Input Class Initialized
INFO - 2016-03-09 05:45:02 --> Language Class Initialized
INFO - 2016-03-09 05:45:02 --> Loader Class Initialized
INFO - 2016-03-09 05:45:02 --> Helper loaded: url_helper
INFO - 2016-03-09 05:45:02 --> Helper loaded: file_helper
INFO - 2016-03-09 05:45:02 --> Helper loaded: date_helper
INFO - 2016-03-09 05:45:02 --> Helper loaded: form_helper
INFO - 2016-03-09 05:45:02 --> Database Driver Class Initialized
INFO - 2016-03-09 05:45:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:45:03 --> Controller Class Initialized
INFO - 2016-03-09 05:45:03 --> Model Class Initialized
INFO - 2016-03-09 05:45:03 --> Model Class Initialized
INFO - 2016-03-09 05:45:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:45:03 --> Pagination Class Initialized
INFO - 2016-03-09 05:45:03 --> Helper loaded: text_helper
INFO - 2016-03-09 05:45:03 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:45:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:45:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:45:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 08:45:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 08:45:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:45:03 --> Final output sent to browser
DEBUG - 2016-03-09 08:45:03 --> Total execution time: 1.2791
INFO - 2016-03-09 05:45:07 --> Config Class Initialized
INFO - 2016-03-09 05:45:07 --> Hooks Class Initialized
DEBUG - 2016-03-09 05:45:07 --> UTF-8 Support Enabled
INFO - 2016-03-09 05:45:07 --> Utf8 Class Initialized
INFO - 2016-03-09 05:45:07 --> URI Class Initialized
INFO - 2016-03-09 05:45:07 --> Router Class Initialized
INFO - 2016-03-09 05:45:07 --> Output Class Initialized
INFO - 2016-03-09 05:45:07 --> Security Class Initialized
DEBUG - 2016-03-09 05:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 05:45:07 --> Input Class Initialized
INFO - 2016-03-09 05:45:07 --> Language Class Initialized
INFO - 2016-03-09 05:45:07 --> Loader Class Initialized
INFO - 2016-03-09 05:45:07 --> Helper loaded: url_helper
INFO - 2016-03-09 05:45:07 --> Helper loaded: file_helper
INFO - 2016-03-09 05:45:07 --> Helper loaded: date_helper
INFO - 2016-03-09 05:45:07 --> Helper loaded: form_helper
INFO - 2016-03-09 05:45:07 --> Database Driver Class Initialized
INFO - 2016-03-09 05:45:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 05:45:08 --> Controller Class Initialized
INFO - 2016-03-09 05:45:08 --> Model Class Initialized
INFO - 2016-03-09 05:45:08 --> Model Class Initialized
INFO - 2016-03-09 05:45:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 05:45:08 --> Pagination Class Initialized
INFO - 2016-03-09 05:45:08 --> Helper loaded: text_helper
INFO - 2016-03-09 05:45:08 --> Helper loaded: cookie_helper
INFO - 2016-03-09 08:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 08:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 08:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 08:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 08:45:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 08:45:08 --> Final output sent to browser
DEBUG - 2016-03-09 08:45:08 --> Total execution time: 1.1449
INFO - 2016-03-09 07:19:55 --> Config Class Initialized
INFO - 2016-03-09 07:19:55 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:19:55 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:19:55 --> Utf8 Class Initialized
INFO - 2016-03-09 07:19:55 --> URI Class Initialized
INFO - 2016-03-09 07:19:55 --> Router Class Initialized
INFO - 2016-03-09 07:19:55 --> Output Class Initialized
INFO - 2016-03-09 07:19:55 --> Security Class Initialized
DEBUG - 2016-03-09 07:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:19:55 --> Input Class Initialized
INFO - 2016-03-09 07:19:55 --> Language Class Initialized
INFO - 2016-03-09 07:19:55 --> Loader Class Initialized
INFO - 2016-03-09 07:19:55 --> Helper loaded: url_helper
INFO - 2016-03-09 07:19:55 --> Helper loaded: file_helper
INFO - 2016-03-09 07:19:55 --> Helper loaded: date_helper
INFO - 2016-03-09 07:19:55 --> Helper loaded: form_helper
INFO - 2016-03-09 07:19:55 --> Database Driver Class Initialized
INFO - 2016-03-09 07:19:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:19:56 --> Controller Class Initialized
INFO - 2016-03-09 07:19:56 --> Model Class Initialized
INFO - 2016-03-09 07:19:56 --> Model Class Initialized
INFO - 2016-03-09 07:19:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:19:56 --> Pagination Class Initialized
INFO - 2016-03-09 07:19:56 --> Helper loaded: text_helper
INFO - 2016-03-09 07:19:56 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:19:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:19:57 --> Final output sent to browser
DEBUG - 2016-03-09 10:19:57 --> Total execution time: 1.1846
INFO - 2016-03-09 07:20:24 --> Config Class Initialized
INFO - 2016-03-09 07:20:24 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:20:24 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:20:24 --> Utf8 Class Initialized
INFO - 2016-03-09 07:20:24 --> URI Class Initialized
INFO - 2016-03-09 07:20:24 --> Router Class Initialized
INFO - 2016-03-09 07:20:24 --> Output Class Initialized
INFO - 2016-03-09 07:20:24 --> Security Class Initialized
DEBUG - 2016-03-09 07:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:20:24 --> Input Class Initialized
INFO - 2016-03-09 07:20:24 --> Language Class Initialized
INFO - 2016-03-09 07:20:24 --> Loader Class Initialized
INFO - 2016-03-09 07:20:24 --> Helper loaded: url_helper
INFO - 2016-03-09 07:20:24 --> Helper loaded: file_helper
INFO - 2016-03-09 07:20:24 --> Helper loaded: date_helper
INFO - 2016-03-09 07:20:24 --> Helper loaded: form_helper
INFO - 2016-03-09 07:20:24 --> Database Driver Class Initialized
INFO - 2016-03-09 07:20:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:20:25 --> Controller Class Initialized
INFO - 2016-03-09 07:20:25 --> Model Class Initialized
INFO - 2016-03-09 07:20:25 --> Model Class Initialized
INFO - 2016-03-09 07:20:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:20:25 --> Pagination Class Initialized
INFO - 2016-03-09 07:20:25 --> Helper loaded: text_helper
INFO - 2016-03-09 07:20:25 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:20:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:20:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:20:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:20:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:20:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:20:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:20:25 --> Final output sent to browser
DEBUG - 2016-03-09 10:20:25 --> Total execution time: 1.2105
INFO - 2016-03-09 07:25:19 --> Config Class Initialized
INFO - 2016-03-09 07:25:19 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:25:19 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:25:19 --> Utf8 Class Initialized
INFO - 2016-03-09 07:25:19 --> URI Class Initialized
INFO - 2016-03-09 07:25:19 --> Router Class Initialized
INFO - 2016-03-09 07:25:19 --> Output Class Initialized
INFO - 2016-03-09 07:25:19 --> Security Class Initialized
DEBUG - 2016-03-09 07:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:25:19 --> Input Class Initialized
INFO - 2016-03-09 07:25:19 --> Language Class Initialized
INFO - 2016-03-09 07:25:19 --> Loader Class Initialized
INFO - 2016-03-09 07:25:19 --> Helper loaded: url_helper
INFO - 2016-03-09 07:25:19 --> Helper loaded: file_helper
INFO - 2016-03-09 07:25:19 --> Helper loaded: date_helper
INFO - 2016-03-09 07:25:19 --> Helper loaded: form_helper
INFO - 2016-03-09 07:25:19 --> Database Driver Class Initialized
INFO - 2016-03-09 07:25:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:25:20 --> Controller Class Initialized
INFO - 2016-03-09 07:25:20 --> Model Class Initialized
INFO - 2016-03-09 07:25:20 --> Model Class Initialized
INFO - 2016-03-09 07:25:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:25:20 --> Pagination Class Initialized
INFO - 2016-03-09 07:25:20 --> Helper loaded: text_helper
INFO - 2016-03-09 07:25:20 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:25:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-09 10:25:20 --> Severity: Error --> Call to undefined method Wall::pagination() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 194
INFO - 2016-03-09 07:31:55 --> Config Class Initialized
INFO - 2016-03-09 07:31:55 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:31:55 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:31:55 --> Utf8 Class Initialized
INFO - 2016-03-09 07:31:55 --> URI Class Initialized
INFO - 2016-03-09 07:31:55 --> Router Class Initialized
INFO - 2016-03-09 07:31:55 --> Output Class Initialized
INFO - 2016-03-09 07:31:55 --> Security Class Initialized
DEBUG - 2016-03-09 07:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:31:55 --> Input Class Initialized
INFO - 2016-03-09 07:31:55 --> Language Class Initialized
INFO - 2016-03-09 07:31:55 --> Loader Class Initialized
INFO - 2016-03-09 07:31:55 --> Helper loaded: url_helper
INFO - 2016-03-09 07:31:55 --> Helper loaded: file_helper
INFO - 2016-03-09 07:31:55 --> Helper loaded: date_helper
INFO - 2016-03-09 07:31:55 --> Helper loaded: form_helper
INFO - 2016-03-09 07:31:55 --> Database Driver Class Initialized
INFO - 2016-03-09 07:31:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:31:56 --> Controller Class Initialized
INFO - 2016-03-09 07:31:56 --> Model Class Initialized
INFO - 2016-03-09 07:31:56 --> Model Class Initialized
INFO - 2016-03-09 07:31:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:31:56 --> Pagination Class Initialized
INFO - 2016-03-09 07:31:56 --> Helper loaded: text_helper
INFO - 2016-03-09 07:31:56 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 196
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-09 10:31:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined variable: idx_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 84
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:31:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:56 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:31:57 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
INFO - 2016-03-09 10:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:31:57 --> Final output sent to browser
DEBUG - 2016-03-09 10:31:57 --> Total execution time: 1.3925
INFO - 2016-03-09 07:34:05 --> Config Class Initialized
INFO - 2016-03-09 07:34:05 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:34:05 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:34:05 --> Utf8 Class Initialized
INFO - 2016-03-09 07:34:05 --> URI Class Initialized
INFO - 2016-03-09 07:34:05 --> Router Class Initialized
INFO - 2016-03-09 07:34:05 --> Output Class Initialized
INFO - 2016-03-09 07:34:05 --> Security Class Initialized
DEBUG - 2016-03-09 07:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:34:05 --> Input Class Initialized
INFO - 2016-03-09 07:34:05 --> Language Class Initialized
INFO - 2016-03-09 07:34:05 --> Loader Class Initialized
INFO - 2016-03-09 07:34:05 --> Helper loaded: url_helper
INFO - 2016-03-09 07:34:05 --> Helper loaded: file_helper
INFO - 2016-03-09 07:34:05 --> Helper loaded: date_helper
INFO - 2016-03-09 07:34:05 --> Helper loaded: form_helper
INFO - 2016-03-09 07:34:05 --> Database Driver Class Initialized
INFO - 2016-03-09 07:34:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:34:06 --> Controller Class Initialized
INFO - 2016-03-09 07:34:06 --> Model Class Initialized
INFO - 2016-03-09 07:34:06 --> Model Class Initialized
INFO - 2016-03-09 07:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:34:06 --> Pagination Class Initialized
INFO - 2016-03-09 07:34:06 --> Helper loaded: text_helper
INFO - 2016-03-09 07:34:06 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined variable: idx_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 84
INFO - 2016-03-09 10:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli_result::$id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli_result::$title C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli_result::$user_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli_result::$created C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli_result::$view C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined property: mysqli_result::$vote C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 19
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 20
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 21
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 22
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 23
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 24
ERROR - 2016-03-09 10:34:06 --> Severity: Notice --> Undefined variable: page_link C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 32
INFO - 2016-03-09 10:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:34:06 --> Final output sent to browser
DEBUG - 2016-03-09 10:34:06 --> Total execution time: 1.3064
INFO - 2016-03-09 07:34:55 --> Config Class Initialized
INFO - 2016-03-09 07:34:55 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:34:55 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:34:55 --> Utf8 Class Initialized
INFO - 2016-03-09 07:34:55 --> URI Class Initialized
INFO - 2016-03-09 07:34:55 --> Router Class Initialized
INFO - 2016-03-09 07:34:55 --> Output Class Initialized
INFO - 2016-03-09 07:34:55 --> Security Class Initialized
DEBUG - 2016-03-09 07:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:34:55 --> Input Class Initialized
INFO - 2016-03-09 07:34:55 --> Language Class Initialized
INFO - 2016-03-09 07:34:55 --> Loader Class Initialized
INFO - 2016-03-09 07:34:55 --> Helper loaded: url_helper
INFO - 2016-03-09 07:34:55 --> Helper loaded: file_helper
INFO - 2016-03-09 07:34:55 --> Helper loaded: date_helper
INFO - 2016-03-09 07:34:55 --> Helper loaded: form_helper
INFO - 2016-03-09 07:34:55 --> Database Driver Class Initialized
INFO - 2016-03-09 07:34:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:34:56 --> Controller Class Initialized
INFO - 2016-03-09 07:34:56 --> Model Class Initialized
INFO - 2016-03-09 07:34:56 --> Model Class Initialized
INFO - 2016-03-09 07:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:34:56 --> Pagination Class Initialized
INFO - 2016-03-09 07:34:56 --> Helper loaded: text_helper
INFO - 2016-03-09 07:34:56 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:34:56 --> Final output sent to browser
DEBUG - 2016-03-09 10:34:56 --> Total execution time: 1.2627
INFO - 2016-03-09 07:35:10 --> Config Class Initialized
INFO - 2016-03-09 07:35:10 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:35:10 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:35:10 --> Utf8 Class Initialized
INFO - 2016-03-09 07:35:10 --> URI Class Initialized
INFO - 2016-03-09 07:35:10 --> Router Class Initialized
INFO - 2016-03-09 07:35:10 --> Output Class Initialized
INFO - 2016-03-09 07:35:10 --> Security Class Initialized
DEBUG - 2016-03-09 07:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:35:10 --> Input Class Initialized
INFO - 2016-03-09 07:35:10 --> Language Class Initialized
INFO - 2016-03-09 07:35:10 --> Loader Class Initialized
INFO - 2016-03-09 07:35:10 --> Helper loaded: url_helper
INFO - 2016-03-09 07:35:10 --> Helper loaded: file_helper
INFO - 2016-03-09 07:35:10 --> Helper loaded: date_helper
INFO - 2016-03-09 07:35:10 --> Helper loaded: form_helper
INFO - 2016-03-09 07:35:10 --> Database Driver Class Initialized
INFO - 2016-03-09 07:35:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:35:11 --> Controller Class Initialized
INFO - 2016-03-09 07:35:11 --> Model Class Initialized
INFO - 2016-03-09 07:35:11 --> Model Class Initialized
INFO - 2016-03-09 07:35:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:35:11 --> Pagination Class Initialized
INFO - 2016-03-09 07:35:11 --> Helper loaded: text_helper
INFO - 2016-03-09 07:35:11 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:35:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:35:11 --> Final output sent to browser
DEBUG - 2016-03-09 10:35:11 --> Total execution time: 1.0947
INFO - 2016-03-09 07:35:13 --> Config Class Initialized
INFO - 2016-03-09 07:35:13 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:35:13 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:35:13 --> Utf8 Class Initialized
INFO - 2016-03-09 07:35:13 --> URI Class Initialized
INFO - 2016-03-09 07:35:13 --> Router Class Initialized
INFO - 2016-03-09 07:35:14 --> Output Class Initialized
INFO - 2016-03-09 07:35:14 --> Security Class Initialized
DEBUG - 2016-03-09 07:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:35:14 --> Input Class Initialized
INFO - 2016-03-09 07:35:14 --> Language Class Initialized
INFO - 2016-03-09 07:35:14 --> Loader Class Initialized
INFO - 2016-03-09 07:35:14 --> Helper loaded: url_helper
INFO - 2016-03-09 07:35:14 --> Helper loaded: file_helper
INFO - 2016-03-09 07:35:14 --> Helper loaded: date_helper
INFO - 2016-03-09 07:35:14 --> Helper loaded: form_helper
INFO - 2016-03-09 07:35:14 --> Database Driver Class Initialized
INFO - 2016-03-09 07:35:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:35:15 --> Controller Class Initialized
INFO - 2016-03-09 07:35:15 --> Model Class Initialized
INFO - 2016-03-09 07:35:15 --> Model Class Initialized
INFO - 2016-03-09 07:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:35:15 --> Pagination Class Initialized
INFO - 2016-03-09 07:35:15 --> Helper loaded: text_helper
INFO - 2016-03-09 07:35:15 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:35:15 --> Final output sent to browser
DEBUG - 2016-03-09 10:35:15 --> Total execution time: 1.1371
INFO - 2016-03-09 07:35:16 --> Config Class Initialized
INFO - 2016-03-09 07:35:16 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:35:16 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:35:16 --> Utf8 Class Initialized
INFO - 2016-03-09 07:35:16 --> URI Class Initialized
INFO - 2016-03-09 07:35:16 --> Router Class Initialized
INFO - 2016-03-09 07:35:16 --> Output Class Initialized
INFO - 2016-03-09 07:35:16 --> Security Class Initialized
DEBUG - 2016-03-09 07:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:35:16 --> Input Class Initialized
INFO - 2016-03-09 07:35:16 --> Language Class Initialized
INFO - 2016-03-09 07:35:16 --> Loader Class Initialized
INFO - 2016-03-09 07:35:16 --> Helper loaded: url_helper
INFO - 2016-03-09 07:35:16 --> Helper loaded: file_helper
INFO - 2016-03-09 07:35:16 --> Helper loaded: date_helper
INFO - 2016-03-09 07:35:16 --> Helper loaded: form_helper
INFO - 2016-03-09 07:35:16 --> Database Driver Class Initialized
INFO - 2016-03-09 07:35:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:35:17 --> Controller Class Initialized
INFO - 2016-03-09 07:35:17 --> Model Class Initialized
INFO - 2016-03-09 07:35:17 --> Model Class Initialized
INFO - 2016-03-09 07:35:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:35:17 --> Pagination Class Initialized
INFO - 2016-03-09 07:35:17 --> Helper loaded: text_helper
INFO - 2016-03-09 07:35:17 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:35:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:35:17 --> Final output sent to browser
DEBUG - 2016-03-09 10:35:17 --> Total execution time: 1.2269
INFO - 2016-03-09 07:35:36 --> Config Class Initialized
INFO - 2016-03-09 07:35:36 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:35:36 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:35:36 --> Utf8 Class Initialized
INFO - 2016-03-09 07:35:36 --> URI Class Initialized
INFO - 2016-03-09 07:35:36 --> Router Class Initialized
INFO - 2016-03-09 07:35:36 --> Output Class Initialized
INFO - 2016-03-09 07:35:36 --> Security Class Initialized
DEBUG - 2016-03-09 07:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:35:36 --> Input Class Initialized
INFO - 2016-03-09 07:35:36 --> Language Class Initialized
INFO - 2016-03-09 07:35:36 --> Loader Class Initialized
INFO - 2016-03-09 07:35:36 --> Helper loaded: url_helper
INFO - 2016-03-09 07:35:36 --> Helper loaded: file_helper
INFO - 2016-03-09 07:35:36 --> Helper loaded: date_helper
INFO - 2016-03-09 07:35:36 --> Helper loaded: form_helper
INFO - 2016-03-09 07:35:36 --> Database Driver Class Initialized
INFO - 2016-03-09 07:35:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:35:37 --> Controller Class Initialized
INFO - 2016-03-09 07:35:37 --> Model Class Initialized
INFO - 2016-03-09 07:35:37 --> Model Class Initialized
INFO - 2016-03-09 07:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:35:37 --> Pagination Class Initialized
INFO - 2016-03-09 07:35:37 --> Helper loaded: text_helper
INFO - 2016-03-09 07:35:37 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:35:37 --> Final output sent to browser
DEBUG - 2016-03-09 10:35:37 --> Total execution time: 1.1131
INFO - 2016-03-09 07:36:50 --> Config Class Initialized
INFO - 2016-03-09 07:36:50 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:36:50 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:36:50 --> Utf8 Class Initialized
INFO - 2016-03-09 07:36:50 --> URI Class Initialized
INFO - 2016-03-09 07:36:50 --> Router Class Initialized
INFO - 2016-03-09 07:36:50 --> Output Class Initialized
INFO - 2016-03-09 07:36:50 --> Security Class Initialized
DEBUG - 2016-03-09 07:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:36:50 --> Input Class Initialized
INFO - 2016-03-09 07:36:50 --> Language Class Initialized
INFO - 2016-03-09 07:36:50 --> Loader Class Initialized
INFO - 2016-03-09 07:36:50 --> Helper loaded: url_helper
INFO - 2016-03-09 07:36:50 --> Helper loaded: file_helper
INFO - 2016-03-09 07:36:50 --> Helper loaded: date_helper
INFO - 2016-03-09 07:36:50 --> Helper loaded: form_helper
INFO - 2016-03-09 07:36:50 --> Database Driver Class Initialized
INFO - 2016-03-09 07:36:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:36:51 --> Controller Class Initialized
INFO - 2016-03-09 07:36:51 --> Model Class Initialized
INFO - 2016-03-09 07:36:51 --> Model Class Initialized
INFO - 2016-03-09 07:36:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:36:51 --> Pagination Class Initialized
INFO - 2016-03-09 07:36:51 --> Helper loaded: text_helper
INFO - 2016-03-09 07:36:51 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:36:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:36:51 --> Final output sent to browser
DEBUG - 2016-03-09 10:36:51 --> Total execution time: 1.1819
INFO - 2016-03-09 07:36:56 --> Config Class Initialized
INFO - 2016-03-09 07:36:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:36:56 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:36:56 --> Utf8 Class Initialized
INFO - 2016-03-09 07:36:56 --> URI Class Initialized
INFO - 2016-03-09 07:36:56 --> Router Class Initialized
INFO - 2016-03-09 07:36:56 --> Output Class Initialized
INFO - 2016-03-09 07:36:56 --> Security Class Initialized
DEBUG - 2016-03-09 07:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:36:56 --> Input Class Initialized
INFO - 2016-03-09 07:36:56 --> Language Class Initialized
INFO - 2016-03-09 07:36:56 --> Loader Class Initialized
INFO - 2016-03-09 07:36:56 --> Helper loaded: url_helper
INFO - 2016-03-09 07:36:56 --> Helper loaded: file_helper
INFO - 2016-03-09 07:36:56 --> Helper loaded: date_helper
INFO - 2016-03-09 07:36:56 --> Helper loaded: form_helper
INFO - 2016-03-09 07:36:56 --> Database Driver Class Initialized
INFO - 2016-03-09 07:36:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:36:57 --> Controller Class Initialized
INFO - 2016-03-09 07:36:57 --> Model Class Initialized
INFO - 2016-03-09 07:36:57 --> Model Class Initialized
INFO - 2016-03-09 07:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:36:57 --> Pagination Class Initialized
INFO - 2016-03-09 07:36:57 --> Helper loaded: text_helper
INFO - 2016-03-09 07:36:57 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:36:57 --> Final output sent to browser
DEBUG - 2016-03-09 10:36:57 --> Total execution time: 1.1469
INFO - 2016-03-09 07:37:27 --> Config Class Initialized
INFO - 2016-03-09 07:37:27 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:37:27 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:37:27 --> Utf8 Class Initialized
INFO - 2016-03-09 07:37:27 --> URI Class Initialized
INFO - 2016-03-09 07:37:27 --> Router Class Initialized
INFO - 2016-03-09 07:37:27 --> Output Class Initialized
INFO - 2016-03-09 07:37:27 --> Security Class Initialized
DEBUG - 2016-03-09 07:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:37:27 --> Input Class Initialized
INFO - 2016-03-09 07:37:27 --> Language Class Initialized
ERROR - 2016-03-09 07:37:27 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 141
INFO - 2016-03-09 07:37:40 --> Config Class Initialized
INFO - 2016-03-09 07:37:40 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:37:40 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:37:40 --> Utf8 Class Initialized
INFO - 2016-03-09 07:37:40 --> URI Class Initialized
INFO - 2016-03-09 07:37:40 --> Router Class Initialized
INFO - 2016-03-09 07:37:40 --> Output Class Initialized
INFO - 2016-03-09 07:37:40 --> Security Class Initialized
DEBUG - 2016-03-09 07:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:37:40 --> Input Class Initialized
INFO - 2016-03-09 07:37:40 --> Language Class Initialized
INFO - 2016-03-09 07:37:40 --> Loader Class Initialized
INFO - 2016-03-09 07:37:40 --> Helper loaded: url_helper
INFO - 2016-03-09 07:37:40 --> Helper loaded: file_helper
INFO - 2016-03-09 07:37:40 --> Helper loaded: date_helper
INFO - 2016-03-09 07:37:40 --> Helper loaded: form_helper
INFO - 2016-03-09 07:37:40 --> Database Driver Class Initialized
INFO - 2016-03-09 07:37:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:37:41 --> Controller Class Initialized
INFO - 2016-03-09 07:37:41 --> Model Class Initialized
INFO - 2016-03-09 07:37:41 --> Model Class Initialized
INFO - 2016-03-09 07:37:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:37:41 --> Pagination Class Initialized
INFO - 2016-03-09 07:37:41 --> Helper loaded: text_helper
INFO - 2016-03-09 07:37:41 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:37:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:37:42 --> Final output sent to browser
DEBUG - 2016-03-09 10:37:42 --> Total execution time: 1.1864
INFO - 2016-03-09 07:37:44 --> Config Class Initialized
INFO - 2016-03-09 07:37:44 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:37:44 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:37:44 --> Utf8 Class Initialized
INFO - 2016-03-09 07:37:44 --> URI Class Initialized
INFO - 2016-03-09 07:37:44 --> Router Class Initialized
INFO - 2016-03-09 07:37:44 --> Output Class Initialized
INFO - 2016-03-09 07:37:44 --> Security Class Initialized
DEBUG - 2016-03-09 07:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:37:44 --> Input Class Initialized
INFO - 2016-03-09 07:37:44 --> Language Class Initialized
INFO - 2016-03-09 07:37:44 --> Loader Class Initialized
INFO - 2016-03-09 07:37:44 --> Helper loaded: url_helper
INFO - 2016-03-09 07:37:44 --> Helper loaded: file_helper
INFO - 2016-03-09 07:37:44 --> Helper loaded: date_helper
INFO - 2016-03-09 07:37:44 --> Helper loaded: form_helper
INFO - 2016-03-09 07:37:44 --> Database Driver Class Initialized
INFO - 2016-03-09 07:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:37:45 --> Controller Class Initialized
INFO - 2016-03-09 07:37:45 --> Model Class Initialized
INFO - 2016-03-09 07:37:45 --> Model Class Initialized
INFO - 2016-03-09 07:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:37:45 --> Pagination Class Initialized
INFO - 2016-03-09 07:37:45 --> Helper loaded: text_helper
INFO - 2016-03-09 07:37:45 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 10:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-09 10:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:37:45 --> Final output sent to browser
DEBUG - 2016-03-09 10:37:45 --> Total execution time: 1.1456
INFO - 2016-03-09 07:40:04 --> Config Class Initialized
INFO - 2016-03-09 07:40:04 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:40:04 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:40:04 --> Utf8 Class Initialized
INFO - 2016-03-09 07:40:04 --> URI Class Initialized
INFO - 2016-03-09 07:40:04 --> Router Class Initialized
INFO - 2016-03-09 07:40:04 --> Output Class Initialized
INFO - 2016-03-09 07:40:04 --> Security Class Initialized
DEBUG - 2016-03-09 07:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:40:04 --> Input Class Initialized
INFO - 2016-03-09 07:40:04 --> Language Class Initialized
INFO - 2016-03-09 07:40:04 --> Loader Class Initialized
INFO - 2016-03-09 07:40:04 --> Helper loaded: url_helper
INFO - 2016-03-09 07:40:04 --> Helper loaded: file_helper
INFO - 2016-03-09 07:40:04 --> Helper loaded: date_helper
INFO - 2016-03-09 07:40:04 --> Helper loaded: form_helper
INFO - 2016-03-09 07:40:04 --> Database Driver Class Initialized
INFO - 2016-03-09 07:40:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:40:05 --> Controller Class Initialized
INFO - 2016-03-09 07:40:05 --> Model Class Initialized
INFO - 2016-03-09 07:40:05 --> Model Class Initialized
INFO - 2016-03-09 07:40:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:40:05 --> Pagination Class Initialized
INFO - 2016-03-09 07:40:05 --> Helper loaded: text_helper
INFO - 2016-03-09 07:40:05 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:40:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:40:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:40:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:40:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 10:40:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-09 10:40:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:40:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:40:05 --> Final output sent to browser
DEBUG - 2016-03-09 10:40:05 --> Total execution time: 1.1964
INFO - 2016-03-09 07:40:12 --> Config Class Initialized
INFO - 2016-03-09 07:40:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:40:12 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:40:12 --> Utf8 Class Initialized
INFO - 2016-03-09 07:40:12 --> URI Class Initialized
INFO - 2016-03-09 07:40:12 --> Router Class Initialized
INFO - 2016-03-09 07:40:12 --> Output Class Initialized
INFO - 2016-03-09 07:40:12 --> Security Class Initialized
DEBUG - 2016-03-09 07:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:40:12 --> Input Class Initialized
INFO - 2016-03-09 07:40:12 --> Language Class Initialized
INFO - 2016-03-09 07:40:12 --> Loader Class Initialized
INFO - 2016-03-09 07:40:12 --> Helper loaded: url_helper
INFO - 2016-03-09 07:40:12 --> Helper loaded: file_helper
INFO - 2016-03-09 07:40:12 --> Helper loaded: date_helper
INFO - 2016-03-09 07:40:12 --> Helper loaded: form_helper
INFO - 2016-03-09 07:40:12 --> Database Driver Class Initialized
INFO - 2016-03-09 07:40:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:40:13 --> Controller Class Initialized
INFO - 2016-03-09 07:40:13 --> Model Class Initialized
INFO - 2016-03-09 07:40:13 --> Model Class Initialized
INFO - 2016-03-09 07:40:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:40:13 --> Pagination Class Initialized
INFO - 2016-03-09 07:40:13 --> Helper loaded: text_helper
INFO - 2016-03-09 07:40:13 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:40:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:40:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:40:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:40:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:40:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:40:13 --> Final output sent to browser
DEBUG - 2016-03-09 10:40:13 --> Total execution time: 1.1375
INFO - 2016-03-09 07:40:22 --> Config Class Initialized
INFO - 2016-03-09 07:40:22 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:40:22 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:40:22 --> Utf8 Class Initialized
INFO - 2016-03-09 07:40:22 --> URI Class Initialized
INFO - 2016-03-09 07:40:22 --> Router Class Initialized
INFO - 2016-03-09 07:40:22 --> Output Class Initialized
INFO - 2016-03-09 07:40:22 --> Security Class Initialized
DEBUG - 2016-03-09 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:40:22 --> Input Class Initialized
INFO - 2016-03-09 07:40:22 --> Language Class Initialized
INFO - 2016-03-09 07:40:22 --> Loader Class Initialized
INFO - 2016-03-09 07:40:22 --> Helper loaded: url_helper
INFO - 2016-03-09 07:40:22 --> Helper loaded: file_helper
INFO - 2016-03-09 07:40:22 --> Helper loaded: date_helper
INFO - 2016-03-09 07:40:22 --> Helper loaded: form_helper
INFO - 2016-03-09 07:40:22 --> Database Driver Class Initialized
INFO - 2016-03-09 07:40:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:40:23 --> Controller Class Initialized
INFO - 2016-03-09 07:40:23 --> Model Class Initialized
INFO - 2016-03-09 07:40:23 --> Model Class Initialized
INFO - 2016-03-09 07:40:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:40:23 --> Pagination Class Initialized
INFO - 2016-03-09 07:40:23 --> Helper loaded: text_helper
INFO - 2016-03-09 07:40:23 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:40:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:40:23 --> Final output sent to browser
DEBUG - 2016-03-09 10:40:23 --> Total execution time: 1.1440
INFO - 2016-03-09 07:41:25 --> Config Class Initialized
INFO - 2016-03-09 07:41:25 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:41:25 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:41:25 --> Utf8 Class Initialized
INFO - 2016-03-09 07:41:25 --> URI Class Initialized
INFO - 2016-03-09 07:41:25 --> Router Class Initialized
INFO - 2016-03-09 07:41:25 --> Output Class Initialized
INFO - 2016-03-09 07:41:25 --> Security Class Initialized
DEBUG - 2016-03-09 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:41:25 --> Input Class Initialized
INFO - 2016-03-09 07:41:25 --> Language Class Initialized
INFO - 2016-03-09 07:41:25 --> Loader Class Initialized
INFO - 2016-03-09 07:41:25 --> Helper loaded: url_helper
INFO - 2016-03-09 07:41:25 --> Helper loaded: file_helper
INFO - 2016-03-09 07:41:25 --> Helper loaded: date_helper
INFO - 2016-03-09 07:41:25 --> Helper loaded: form_helper
INFO - 2016-03-09 07:41:25 --> Database Driver Class Initialized
INFO - 2016-03-09 07:41:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:41:26 --> Controller Class Initialized
INFO - 2016-03-09 07:41:26 --> Model Class Initialized
INFO - 2016-03-09 07:41:26 --> Model Class Initialized
INFO - 2016-03-09 07:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:41:26 --> Pagination Class Initialized
INFO - 2016-03-09 07:41:26 --> Helper loaded: text_helper
INFO - 2016-03-09 07:41:26 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:41:26 --> Final output sent to browser
DEBUG - 2016-03-09 10:41:26 --> Total execution time: 1.1539
INFO - 2016-03-09 07:41:29 --> Config Class Initialized
INFO - 2016-03-09 07:41:29 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:41:29 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:41:29 --> Utf8 Class Initialized
INFO - 2016-03-09 07:41:29 --> URI Class Initialized
INFO - 2016-03-09 07:41:29 --> Router Class Initialized
INFO - 2016-03-09 07:41:29 --> Output Class Initialized
INFO - 2016-03-09 07:41:29 --> Security Class Initialized
DEBUG - 2016-03-09 07:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:41:29 --> Input Class Initialized
INFO - 2016-03-09 07:41:29 --> Language Class Initialized
INFO - 2016-03-09 07:41:29 --> Loader Class Initialized
INFO - 2016-03-09 07:41:29 --> Helper loaded: url_helper
INFO - 2016-03-09 07:41:29 --> Helper loaded: file_helper
INFO - 2016-03-09 07:41:29 --> Helper loaded: date_helper
INFO - 2016-03-09 07:41:29 --> Helper loaded: form_helper
INFO - 2016-03-09 07:41:29 --> Database Driver Class Initialized
INFO - 2016-03-09 07:41:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:41:30 --> Controller Class Initialized
INFO - 2016-03-09 07:41:30 --> Model Class Initialized
INFO - 2016-03-09 07:41:30 --> Model Class Initialized
INFO - 2016-03-09 07:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:41:30 --> Pagination Class Initialized
INFO - 2016-03-09 07:41:30 --> Helper loaded: text_helper
INFO - 2016-03-09 07:41:30 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:41:30 --> Final output sent to browser
DEBUG - 2016-03-09 10:41:30 --> Total execution time: 1.1344
INFO - 2016-03-09 07:41:32 --> Config Class Initialized
INFO - 2016-03-09 07:41:32 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:41:32 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:41:32 --> Utf8 Class Initialized
INFO - 2016-03-09 07:41:32 --> URI Class Initialized
INFO - 2016-03-09 07:41:32 --> Router Class Initialized
INFO - 2016-03-09 07:41:32 --> Output Class Initialized
INFO - 2016-03-09 07:41:32 --> Security Class Initialized
DEBUG - 2016-03-09 07:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:41:32 --> Input Class Initialized
INFO - 2016-03-09 07:41:32 --> Language Class Initialized
INFO - 2016-03-09 07:41:32 --> Loader Class Initialized
INFO - 2016-03-09 07:41:32 --> Helper loaded: url_helper
INFO - 2016-03-09 07:41:32 --> Helper loaded: file_helper
INFO - 2016-03-09 07:41:32 --> Helper loaded: date_helper
INFO - 2016-03-09 07:41:32 --> Helper loaded: form_helper
INFO - 2016-03-09 07:41:32 --> Database Driver Class Initialized
INFO - 2016-03-09 07:41:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:41:33 --> Controller Class Initialized
INFO - 2016-03-09 07:41:33 --> Model Class Initialized
INFO - 2016-03-09 07:41:33 --> Model Class Initialized
INFO - 2016-03-09 07:41:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:41:33 --> Pagination Class Initialized
INFO - 2016-03-09 07:41:33 --> Helper loaded: text_helper
INFO - 2016-03-09 07:41:33 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:41:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:41:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:41:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:41:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:41:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:41:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:41:33 --> Final output sent to browser
DEBUG - 2016-03-09 10:41:33 --> Total execution time: 1.2417
INFO - 2016-03-09 07:42:00 --> Config Class Initialized
INFO - 2016-03-09 07:42:00 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:42:00 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:42:00 --> Utf8 Class Initialized
INFO - 2016-03-09 07:42:00 --> URI Class Initialized
INFO - 2016-03-09 07:42:00 --> Router Class Initialized
INFO - 2016-03-09 07:42:00 --> Output Class Initialized
INFO - 2016-03-09 07:42:00 --> Security Class Initialized
DEBUG - 2016-03-09 07:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:42:00 --> Input Class Initialized
INFO - 2016-03-09 07:42:00 --> Language Class Initialized
INFO - 2016-03-09 07:42:00 --> Loader Class Initialized
INFO - 2016-03-09 07:42:00 --> Helper loaded: url_helper
INFO - 2016-03-09 07:42:00 --> Helper loaded: file_helper
INFO - 2016-03-09 07:42:00 --> Helper loaded: date_helper
INFO - 2016-03-09 07:42:00 --> Helper loaded: form_helper
INFO - 2016-03-09 07:42:00 --> Database Driver Class Initialized
INFO - 2016-03-09 07:42:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:42:01 --> Controller Class Initialized
INFO - 2016-03-09 07:42:01 --> Model Class Initialized
INFO - 2016-03-09 07:42:01 --> Model Class Initialized
INFO - 2016-03-09 07:42:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:42:01 --> Pagination Class Initialized
INFO - 2016-03-09 07:42:01 --> Helper loaded: text_helper
INFO - 2016-03-09 07:42:01 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:42:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:42:01 --> Final output sent to browser
DEBUG - 2016-03-09 10:42:01 --> Total execution time: 1.2574
INFO - 2016-03-09 07:42:07 --> Config Class Initialized
INFO - 2016-03-09 07:42:07 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:42:08 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:42:08 --> Utf8 Class Initialized
INFO - 2016-03-09 07:42:08 --> URI Class Initialized
INFO - 2016-03-09 07:42:08 --> Router Class Initialized
INFO - 2016-03-09 07:42:08 --> Output Class Initialized
INFO - 2016-03-09 07:42:08 --> Security Class Initialized
DEBUG - 2016-03-09 07:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:42:08 --> Input Class Initialized
INFO - 2016-03-09 07:42:08 --> Language Class Initialized
INFO - 2016-03-09 07:42:08 --> Loader Class Initialized
INFO - 2016-03-09 07:42:08 --> Helper loaded: url_helper
INFO - 2016-03-09 07:42:08 --> Helper loaded: file_helper
INFO - 2016-03-09 07:42:08 --> Helper loaded: date_helper
INFO - 2016-03-09 07:42:08 --> Helper loaded: form_helper
INFO - 2016-03-09 07:42:08 --> Database Driver Class Initialized
INFO - 2016-03-09 07:42:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:42:09 --> Controller Class Initialized
INFO - 2016-03-09 07:42:09 --> Model Class Initialized
INFO - 2016-03-09 07:42:09 --> Model Class Initialized
INFO - 2016-03-09 07:42:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:42:09 --> Pagination Class Initialized
INFO - 2016-03-09 07:42:09 --> Helper loaded: text_helper
INFO - 2016-03-09 07:42:09 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:42:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:42:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:42:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:42:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:42:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:42:09 --> Final output sent to browser
DEBUG - 2016-03-09 10:42:09 --> Total execution time: 1.1369
INFO - 2016-03-09 07:42:10 --> Config Class Initialized
INFO - 2016-03-09 07:42:10 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:42:10 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:42:10 --> Utf8 Class Initialized
INFO - 2016-03-09 07:42:10 --> URI Class Initialized
INFO - 2016-03-09 07:42:10 --> Router Class Initialized
INFO - 2016-03-09 07:42:10 --> Output Class Initialized
INFO - 2016-03-09 07:42:10 --> Security Class Initialized
DEBUG - 2016-03-09 07:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:42:10 --> Input Class Initialized
INFO - 2016-03-09 07:42:10 --> Language Class Initialized
INFO - 2016-03-09 07:42:10 --> Loader Class Initialized
INFO - 2016-03-09 07:42:10 --> Helper loaded: url_helper
INFO - 2016-03-09 07:42:10 --> Helper loaded: file_helper
INFO - 2016-03-09 07:42:10 --> Helper loaded: date_helper
INFO - 2016-03-09 07:42:10 --> Helper loaded: form_helper
INFO - 2016-03-09 07:42:10 --> Database Driver Class Initialized
INFO - 2016-03-09 07:42:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:42:11 --> Controller Class Initialized
INFO - 2016-03-09 07:42:11 --> Model Class Initialized
INFO - 2016-03-09 07:42:11 --> Model Class Initialized
INFO - 2016-03-09 07:42:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:42:11 --> Pagination Class Initialized
INFO - 2016-03-09 07:42:11 --> Helper loaded: text_helper
INFO - 2016-03-09 07:42:11 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:42:11 --> Final output sent to browser
DEBUG - 2016-03-09 10:42:11 --> Total execution time: 1.1681
INFO - 2016-03-09 07:42:23 --> Config Class Initialized
INFO - 2016-03-09 07:42:23 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:42:23 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:42:23 --> Utf8 Class Initialized
INFO - 2016-03-09 07:42:23 --> URI Class Initialized
INFO - 2016-03-09 07:42:23 --> Router Class Initialized
INFO - 2016-03-09 07:42:23 --> Output Class Initialized
INFO - 2016-03-09 07:42:23 --> Security Class Initialized
DEBUG - 2016-03-09 07:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:42:23 --> Input Class Initialized
INFO - 2016-03-09 07:42:23 --> Language Class Initialized
INFO - 2016-03-09 07:42:23 --> Loader Class Initialized
INFO - 2016-03-09 07:42:23 --> Helper loaded: url_helper
INFO - 2016-03-09 07:42:23 --> Helper loaded: file_helper
INFO - 2016-03-09 07:42:23 --> Helper loaded: date_helper
INFO - 2016-03-09 07:42:23 --> Helper loaded: form_helper
INFO - 2016-03-09 07:42:23 --> Database Driver Class Initialized
INFO - 2016-03-09 07:42:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:42:24 --> Controller Class Initialized
INFO - 2016-03-09 07:42:24 --> Model Class Initialized
INFO - 2016-03-09 07:42:24 --> Model Class Initialized
INFO - 2016-03-09 07:42:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:42:24 --> Pagination Class Initialized
INFO - 2016-03-09 07:42:24 --> Helper loaded: text_helper
INFO - 2016-03-09 07:42:24 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:42:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:42:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:42:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:42:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:42:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:42:24 --> Final output sent to browser
DEBUG - 2016-03-09 10:42:24 --> Total execution time: 1.1340
INFO - 2016-03-09 07:43:09 --> Config Class Initialized
INFO - 2016-03-09 07:43:09 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:43:09 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:43:09 --> Utf8 Class Initialized
INFO - 2016-03-09 07:43:09 --> URI Class Initialized
INFO - 2016-03-09 07:43:09 --> Router Class Initialized
INFO - 2016-03-09 07:43:09 --> Output Class Initialized
INFO - 2016-03-09 07:43:09 --> Security Class Initialized
DEBUG - 2016-03-09 07:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:43:09 --> Input Class Initialized
INFO - 2016-03-09 07:43:09 --> Language Class Initialized
INFO - 2016-03-09 07:43:09 --> Loader Class Initialized
INFO - 2016-03-09 07:43:09 --> Helper loaded: url_helper
INFO - 2016-03-09 07:43:09 --> Helper loaded: file_helper
INFO - 2016-03-09 07:43:09 --> Helper loaded: date_helper
INFO - 2016-03-09 07:43:09 --> Helper loaded: form_helper
INFO - 2016-03-09 07:43:09 --> Database Driver Class Initialized
INFO - 2016-03-09 07:43:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:43:10 --> Controller Class Initialized
INFO - 2016-03-09 07:43:10 --> Model Class Initialized
INFO - 2016-03-09 07:43:10 --> Model Class Initialized
INFO - 2016-03-09 07:43:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:43:10 --> Pagination Class Initialized
INFO - 2016-03-09 07:43:10 --> Helper loaded: text_helper
INFO - 2016-03-09 07:43:10 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:43:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:43:10 --> Final output sent to browser
DEBUG - 2016-03-09 10:43:10 --> Total execution time: 1.1697
INFO - 2016-03-09 07:44:17 --> Config Class Initialized
INFO - 2016-03-09 07:44:17 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:44:17 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:44:17 --> Utf8 Class Initialized
INFO - 2016-03-09 07:44:17 --> URI Class Initialized
INFO - 2016-03-09 07:44:17 --> Router Class Initialized
INFO - 2016-03-09 07:44:17 --> Output Class Initialized
INFO - 2016-03-09 07:44:17 --> Security Class Initialized
DEBUG - 2016-03-09 07:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:44:17 --> Input Class Initialized
INFO - 2016-03-09 07:44:17 --> Language Class Initialized
INFO - 2016-03-09 07:44:17 --> Loader Class Initialized
INFO - 2016-03-09 07:44:17 --> Helper loaded: url_helper
INFO - 2016-03-09 07:44:17 --> Helper loaded: file_helper
INFO - 2016-03-09 07:44:17 --> Helper loaded: date_helper
INFO - 2016-03-09 07:44:17 --> Helper loaded: form_helper
INFO - 2016-03-09 07:44:17 --> Database Driver Class Initialized
INFO - 2016-03-09 07:44:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:44:18 --> Controller Class Initialized
INFO - 2016-03-09 07:44:18 --> Model Class Initialized
INFO - 2016-03-09 07:44:18 --> Model Class Initialized
INFO - 2016-03-09 07:44:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:44:18 --> Pagination Class Initialized
INFO - 2016-03-09 07:44:18 --> Helper loaded: text_helper
INFO - 2016-03-09 07:44:18 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:44:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:44:18 --> Final output sent to browser
DEBUG - 2016-03-09 10:44:18 --> Total execution time: 1.3377
INFO - 2016-03-09 07:44:41 --> Config Class Initialized
INFO - 2016-03-09 07:44:41 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:44:41 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:44:41 --> Utf8 Class Initialized
INFO - 2016-03-09 07:44:41 --> URI Class Initialized
INFO - 2016-03-09 07:44:41 --> Router Class Initialized
INFO - 2016-03-09 07:44:41 --> Output Class Initialized
INFO - 2016-03-09 07:44:41 --> Security Class Initialized
DEBUG - 2016-03-09 07:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:44:41 --> Input Class Initialized
INFO - 2016-03-09 07:44:41 --> Language Class Initialized
INFO - 2016-03-09 07:44:41 --> Loader Class Initialized
INFO - 2016-03-09 07:44:41 --> Helper loaded: url_helper
INFO - 2016-03-09 07:44:41 --> Helper loaded: file_helper
INFO - 2016-03-09 07:44:41 --> Helper loaded: date_helper
INFO - 2016-03-09 07:44:41 --> Helper loaded: form_helper
INFO - 2016-03-09 07:44:41 --> Database Driver Class Initialized
INFO - 2016-03-09 07:44:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:44:42 --> Controller Class Initialized
INFO - 2016-03-09 07:44:42 --> Model Class Initialized
INFO - 2016-03-09 07:44:42 --> Model Class Initialized
INFO - 2016-03-09 07:44:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:44:42 --> Pagination Class Initialized
INFO - 2016-03-09 07:44:42 --> Helper loaded: text_helper
INFO - 2016-03-09 07:44:42 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:44:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:44:42 --> Final output sent to browser
DEBUG - 2016-03-09 10:44:42 --> Total execution time: 1.1373
INFO - 2016-03-09 07:45:46 --> Config Class Initialized
INFO - 2016-03-09 07:45:46 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:45:46 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:45:46 --> Utf8 Class Initialized
INFO - 2016-03-09 07:45:46 --> URI Class Initialized
INFO - 2016-03-09 07:45:46 --> Router Class Initialized
INFO - 2016-03-09 07:45:46 --> Output Class Initialized
INFO - 2016-03-09 07:45:46 --> Security Class Initialized
DEBUG - 2016-03-09 07:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:45:46 --> Input Class Initialized
INFO - 2016-03-09 07:45:46 --> Language Class Initialized
INFO - 2016-03-09 07:45:46 --> Loader Class Initialized
INFO - 2016-03-09 07:45:46 --> Helper loaded: url_helper
INFO - 2016-03-09 07:45:46 --> Helper loaded: file_helper
INFO - 2016-03-09 07:45:46 --> Helper loaded: date_helper
INFO - 2016-03-09 07:45:46 --> Helper loaded: form_helper
INFO - 2016-03-09 07:45:46 --> Database Driver Class Initialized
INFO - 2016-03-09 07:45:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:45:47 --> Controller Class Initialized
INFO - 2016-03-09 07:45:47 --> Model Class Initialized
INFO - 2016-03-09 07:45:47 --> Model Class Initialized
INFO - 2016-03-09 07:45:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:45:47 --> Pagination Class Initialized
INFO - 2016-03-09 07:45:47 --> Helper loaded: text_helper
INFO - 2016-03-09 07:45:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:45:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:45:47 --> Final output sent to browser
DEBUG - 2016-03-09 10:45:47 --> Total execution time: 1.1966
INFO - 2016-03-09 07:45:51 --> Config Class Initialized
INFO - 2016-03-09 07:45:51 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:45:51 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:45:51 --> Utf8 Class Initialized
INFO - 2016-03-09 07:45:51 --> URI Class Initialized
INFO - 2016-03-09 07:45:51 --> Router Class Initialized
INFO - 2016-03-09 07:45:51 --> Output Class Initialized
INFO - 2016-03-09 07:45:51 --> Security Class Initialized
DEBUG - 2016-03-09 07:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:45:51 --> Input Class Initialized
INFO - 2016-03-09 07:45:51 --> Language Class Initialized
INFO - 2016-03-09 07:45:51 --> Loader Class Initialized
INFO - 2016-03-09 07:45:51 --> Helper loaded: url_helper
INFO - 2016-03-09 07:45:51 --> Helper loaded: file_helper
INFO - 2016-03-09 07:45:51 --> Helper loaded: date_helper
INFO - 2016-03-09 07:45:51 --> Helper loaded: form_helper
INFO - 2016-03-09 07:45:51 --> Database Driver Class Initialized
INFO - 2016-03-09 07:45:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:45:52 --> Controller Class Initialized
INFO - 2016-03-09 07:45:52 --> Model Class Initialized
INFO - 2016-03-09 07:45:52 --> Model Class Initialized
INFO - 2016-03-09 07:45:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:45:52 --> Pagination Class Initialized
INFO - 2016-03-09 07:45:52 --> Helper loaded: text_helper
INFO - 2016-03-09 07:45:52 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:45:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:45:52 --> Final output sent to browser
DEBUG - 2016-03-09 10:45:52 --> Total execution time: 1.1051
INFO - 2016-03-09 07:45:57 --> Config Class Initialized
INFO - 2016-03-09 07:45:57 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:45:57 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:45:57 --> Utf8 Class Initialized
INFO - 2016-03-09 07:45:57 --> URI Class Initialized
INFO - 2016-03-09 07:45:57 --> Router Class Initialized
INFO - 2016-03-09 07:45:57 --> Output Class Initialized
INFO - 2016-03-09 07:45:57 --> Security Class Initialized
DEBUG - 2016-03-09 07:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:45:57 --> Input Class Initialized
INFO - 2016-03-09 07:45:57 --> Language Class Initialized
INFO - 2016-03-09 07:45:57 --> Loader Class Initialized
INFO - 2016-03-09 07:45:57 --> Helper loaded: url_helper
INFO - 2016-03-09 07:45:57 --> Helper loaded: file_helper
INFO - 2016-03-09 07:45:57 --> Helper loaded: date_helper
INFO - 2016-03-09 07:45:57 --> Helper loaded: form_helper
INFO - 2016-03-09 07:45:57 --> Database Driver Class Initialized
INFO - 2016-03-09 07:45:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:45:58 --> Controller Class Initialized
INFO - 2016-03-09 07:45:58 --> Model Class Initialized
INFO - 2016-03-09 07:45:58 --> Model Class Initialized
INFO - 2016-03-09 07:45:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:45:58 --> Pagination Class Initialized
INFO - 2016-03-09 07:45:58 --> Helper loaded: text_helper
INFO - 2016-03-09 07:45:58 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:45:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:45:58 --> Final output sent to browser
DEBUG - 2016-03-09 10:45:58 --> Total execution time: 1.1481
INFO - 2016-03-09 07:46:30 --> Config Class Initialized
INFO - 2016-03-09 07:46:30 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:46:30 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:46:30 --> Utf8 Class Initialized
INFO - 2016-03-09 07:46:30 --> URI Class Initialized
INFO - 2016-03-09 07:46:30 --> Router Class Initialized
INFO - 2016-03-09 07:46:30 --> Output Class Initialized
INFO - 2016-03-09 07:46:30 --> Security Class Initialized
DEBUG - 2016-03-09 07:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:46:30 --> Input Class Initialized
INFO - 2016-03-09 07:46:30 --> Language Class Initialized
INFO - 2016-03-09 07:46:30 --> Loader Class Initialized
INFO - 2016-03-09 07:46:30 --> Helper loaded: url_helper
INFO - 2016-03-09 07:46:30 --> Helper loaded: file_helper
INFO - 2016-03-09 07:46:30 --> Helper loaded: date_helper
INFO - 2016-03-09 07:46:30 --> Helper loaded: form_helper
INFO - 2016-03-09 07:46:30 --> Database Driver Class Initialized
INFO - 2016-03-09 07:46:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:46:31 --> Controller Class Initialized
INFO - 2016-03-09 07:46:31 --> Model Class Initialized
INFO - 2016-03-09 07:46:31 --> Model Class Initialized
INFO - 2016-03-09 07:46:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:46:31 --> Pagination Class Initialized
INFO - 2016-03-09 07:46:31 --> Helper loaded: text_helper
INFO - 2016-03-09 07:46:31 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:46:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:46:31 --> Final output sent to browser
DEBUG - 2016-03-09 10:46:31 --> Total execution time: 1.1033
INFO - 2016-03-09 07:46:33 --> Config Class Initialized
INFO - 2016-03-09 07:46:33 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:46:33 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:46:33 --> Utf8 Class Initialized
INFO - 2016-03-09 07:46:33 --> URI Class Initialized
INFO - 2016-03-09 07:46:33 --> Router Class Initialized
INFO - 2016-03-09 07:46:33 --> Output Class Initialized
INFO - 2016-03-09 07:46:33 --> Security Class Initialized
DEBUG - 2016-03-09 07:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:46:33 --> Input Class Initialized
INFO - 2016-03-09 07:46:33 --> Language Class Initialized
INFO - 2016-03-09 07:46:33 --> Loader Class Initialized
INFO - 2016-03-09 07:46:33 --> Helper loaded: url_helper
INFO - 2016-03-09 07:46:33 --> Helper loaded: file_helper
INFO - 2016-03-09 07:46:33 --> Helper loaded: date_helper
INFO - 2016-03-09 07:46:33 --> Helper loaded: form_helper
INFO - 2016-03-09 07:46:33 --> Database Driver Class Initialized
INFO - 2016-03-09 07:46:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:46:34 --> Controller Class Initialized
INFO - 2016-03-09 07:46:34 --> Model Class Initialized
INFO - 2016-03-09 07:46:34 --> Model Class Initialized
INFO - 2016-03-09 07:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:46:34 --> Pagination Class Initialized
INFO - 2016-03-09 07:46:34 --> Helper loaded: text_helper
INFO - 2016-03-09 07:46:34 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:46:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:46:34 --> Final output sent to browser
DEBUG - 2016-03-09 10:46:34 --> Total execution time: 1.1401
INFO - 2016-03-09 07:46:36 --> Config Class Initialized
INFO - 2016-03-09 07:46:36 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:46:36 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:46:36 --> Utf8 Class Initialized
INFO - 2016-03-09 07:46:36 --> URI Class Initialized
INFO - 2016-03-09 07:46:36 --> Router Class Initialized
INFO - 2016-03-09 07:46:36 --> Output Class Initialized
INFO - 2016-03-09 07:46:36 --> Security Class Initialized
DEBUG - 2016-03-09 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:46:36 --> Input Class Initialized
INFO - 2016-03-09 07:46:36 --> Language Class Initialized
INFO - 2016-03-09 07:46:36 --> Loader Class Initialized
INFO - 2016-03-09 07:46:36 --> Helper loaded: url_helper
INFO - 2016-03-09 07:46:36 --> Helper loaded: file_helper
INFO - 2016-03-09 07:46:36 --> Helper loaded: date_helper
INFO - 2016-03-09 07:46:36 --> Helper loaded: form_helper
INFO - 2016-03-09 07:46:36 --> Database Driver Class Initialized
INFO - 2016-03-09 07:46:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:46:37 --> Controller Class Initialized
INFO - 2016-03-09 07:46:37 --> Model Class Initialized
INFO - 2016-03-09 07:46:37 --> Model Class Initialized
INFO - 2016-03-09 07:46:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:46:37 --> Pagination Class Initialized
INFO - 2016-03-09 07:46:37 --> Helper loaded: text_helper
INFO - 2016-03-09 07:46:37 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:46:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:46:37 --> Final output sent to browser
DEBUG - 2016-03-09 10:46:37 --> Total execution time: 1.1260
INFO - 2016-03-09 07:46:39 --> Config Class Initialized
INFO - 2016-03-09 07:46:39 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:46:39 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:46:39 --> Utf8 Class Initialized
INFO - 2016-03-09 07:46:39 --> URI Class Initialized
INFO - 2016-03-09 07:46:39 --> Router Class Initialized
INFO - 2016-03-09 07:46:39 --> Output Class Initialized
INFO - 2016-03-09 07:46:39 --> Security Class Initialized
DEBUG - 2016-03-09 07:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:46:39 --> Input Class Initialized
INFO - 2016-03-09 07:46:39 --> Language Class Initialized
INFO - 2016-03-09 07:46:39 --> Loader Class Initialized
INFO - 2016-03-09 07:46:39 --> Helper loaded: url_helper
INFO - 2016-03-09 07:46:39 --> Helper loaded: file_helper
INFO - 2016-03-09 07:46:39 --> Helper loaded: date_helper
INFO - 2016-03-09 07:46:39 --> Helper loaded: form_helper
INFO - 2016-03-09 07:46:39 --> Database Driver Class Initialized
INFO - 2016-03-09 07:46:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:46:40 --> Controller Class Initialized
INFO - 2016-03-09 07:46:40 --> Model Class Initialized
INFO - 2016-03-09 07:46:40 --> Model Class Initialized
INFO - 2016-03-09 07:46:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:46:40 --> Pagination Class Initialized
INFO - 2016-03-09 07:46:40 --> Helper loaded: text_helper
INFO - 2016-03-09 07:46:40 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:46:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:46:40 --> Final output sent to browser
DEBUG - 2016-03-09 10:46:40 --> Total execution time: 1.0967
INFO - 2016-03-09 07:46:45 --> Config Class Initialized
INFO - 2016-03-09 07:46:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:46:45 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:46:45 --> Utf8 Class Initialized
INFO - 2016-03-09 07:46:45 --> URI Class Initialized
INFO - 2016-03-09 07:46:45 --> Router Class Initialized
INFO - 2016-03-09 07:46:45 --> Output Class Initialized
INFO - 2016-03-09 07:46:45 --> Security Class Initialized
DEBUG - 2016-03-09 07:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:46:45 --> Input Class Initialized
INFO - 2016-03-09 07:46:45 --> Language Class Initialized
INFO - 2016-03-09 07:46:45 --> Loader Class Initialized
INFO - 2016-03-09 07:46:45 --> Helper loaded: url_helper
INFO - 2016-03-09 07:46:45 --> Helper loaded: file_helper
INFO - 2016-03-09 07:46:45 --> Helper loaded: date_helper
INFO - 2016-03-09 07:46:45 --> Helper loaded: form_helper
INFO - 2016-03-09 07:46:45 --> Database Driver Class Initialized
INFO - 2016-03-09 07:46:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:46:46 --> Controller Class Initialized
INFO - 2016-03-09 07:46:46 --> Model Class Initialized
INFO - 2016-03-09 07:46:46 --> Model Class Initialized
INFO - 2016-03-09 07:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:46:46 --> Pagination Class Initialized
INFO - 2016-03-09 07:46:46 --> Helper loaded: text_helper
INFO - 2016-03-09 07:46:46 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:46:46 --> Final output sent to browser
DEBUG - 2016-03-09 10:46:46 --> Total execution time: 1.2039
INFO - 2016-03-09 07:50:34 --> Config Class Initialized
INFO - 2016-03-09 07:50:34 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:50:34 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:50:34 --> Utf8 Class Initialized
INFO - 2016-03-09 07:50:34 --> URI Class Initialized
INFO - 2016-03-09 07:50:34 --> Router Class Initialized
INFO - 2016-03-09 07:50:34 --> Output Class Initialized
INFO - 2016-03-09 07:50:34 --> Security Class Initialized
DEBUG - 2016-03-09 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:50:34 --> Input Class Initialized
INFO - 2016-03-09 07:50:34 --> Language Class Initialized
INFO - 2016-03-09 07:50:34 --> Loader Class Initialized
INFO - 2016-03-09 07:50:34 --> Helper loaded: url_helper
INFO - 2016-03-09 07:50:34 --> Helper loaded: file_helper
INFO - 2016-03-09 07:50:34 --> Helper loaded: date_helper
INFO - 2016-03-09 07:50:34 --> Helper loaded: form_helper
INFO - 2016-03-09 07:50:34 --> Database Driver Class Initialized
INFO - 2016-03-09 07:50:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:50:35 --> Controller Class Initialized
INFO - 2016-03-09 07:50:35 --> Model Class Initialized
INFO - 2016-03-09 07:50:35 --> Model Class Initialized
INFO - 2016-03-09 07:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:50:35 --> Pagination Class Initialized
INFO - 2016-03-09 07:50:35 --> Helper loaded: text_helper
INFO - 2016-03-09 07:50:35 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 10:50:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-09 10:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:50:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:50:36 --> Final output sent to browser
DEBUG - 2016-03-09 10:50:36 --> Total execution time: 1.2755
INFO - 2016-03-09 07:50:54 --> Config Class Initialized
INFO - 2016-03-09 07:50:54 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:50:54 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:50:54 --> Utf8 Class Initialized
INFO - 2016-03-09 07:50:54 --> URI Class Initialized
INFO - 2016-03-09 07:50:54 --> Router Class Initialized
INFO - 2016-03-09 07:50:54 --> Output Class Initialized
INFO - 2016-03-09 07:50:54 --> Security Class Initialized
DEBUG - 2016-03-09 07:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:50:54 --> Input Class Initialized
INFO - 2016-03-09 07:50:54 --> Language Class Initialized
INFO - 2016-03-09 07:50:54 --> Loader Class Initialized
INFO - 2016-03-09 07:50:54 --> Helper loaded: url_helper
INFO - 2016-03-09 07:50:54 --> Helper loaded: file_helper
INFO - 2016-03-09 07:50:54 --> Helper loaded: date_helper
INFO - 2016-03-09 07:50:54 --> Helper loaded: form_helper
INFO - 2016-03-09 07:50:54 --> Database Driver Class Initialized
INFO - 2016-03-09 07:50:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:50:55 --> Controller Class Initialized
INFO - 2016-03-09 07:50:55 --> Model Class Initialized
INFO - 2016-03-09 07:50:55 --> Model Class Initialized
INFO - 2016-03-09 07:50:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:50:55 --> Pagination Class Initialized
INFO - 2016-03-09 07:50:55 --> Helper loaded: text_helper
INFO - 2016-03-09 07:50:55 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 10:50:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-09 10:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:50:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:50:55 --> Final output sent to browser
DEBUG - 2016-03-09 10:50:55 --> Total execution time: 1.2031
INFO - 2016-03-09 07:51:40 --> Config Class Initialized
INFO - 2016-03-09 07:51:40 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:51:40 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:51:40 --> Utf8 Class Initialized
INFO - 2016-03-09 07:51:40 --> URI Class Initialized
INFO - 2016-03-09 07:51:40 --> Router Class Initialized
INFO - 2016-03-09 07:51:40 --> Output Class Initialized
INFO - 2016-03-09 07:51:40 --> Security Class Initialized
DEBUG - 2016-03-09 07:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:51:40 --> Input Class Initialized
INFO - 2016-03-09 07:51:40 --> Language Class Initialized
INFO - 2016-03-09 07:51:40 --> Loader Class Initialized
INFO - 2016-03-09 07:51:40 --> Helper loaded: url_helper
INFO - 2016-03-09 07:51:40 --> Helper loaded: file_helper
INFO - 2016-03-09 07:51:40 --> Helper loaded: date_helper
INFO - 2016-03-09 07:51:40 --> Helper loaded: form_helper
INFO - 2016-03-09 07:51:40 --> Database Driver Class Initialized
INFO - 2016-03-09 07:51:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:51:41 --> Controller Class Initialized
INFO - 2016-03-09 07:51:41 --> Model Class Initialized
INFO - 2016-03-09 07:51:41 --> Model Class Initialized
INFO - 2016-03-09 07:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:51:41 --> Pagination Class Initialized
INFO - 2016-03-09 07:51:41 --> Helper loaded: text_helper
INFO - 2016-03-09 07:51:41 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 10:51:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-09 10:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:51:41 --> Final output sent to browser
DEBUG - 2016-03-09 10:51:41 --> Total execution time: 1.1874
INFO - 2016-03-09 07:52:12 --> Config Class Initialized
INFO - 2016-03-09 07:52:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:52:12 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:52:12 --> Utf8 Class Initialized
INFO - 2016-03-09 07:52:12 --> URI Class Initialized
INFO - 2016-03-09 07:52:12 --> Router Class Initialized
INFO - 2016-03-09 07:52:12 --> Output Class Initialized
INFO - 2016-03-09 07:52:12 --> Security Class Initialized
DEBUG - 2016-03-09 07:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:52:12 --> Input Class Initialized
INFO - 2016-03-09 07:52:12 --> Language Class Initialized
INFO - 2016-03-09 07:52:12 --> Loader Class Initialized
INFO - 2016-03-09 07:52:12 --> Helper loaded: url_helper
INFO - 2016-03-09 07:52:12 --> Helper loaded: file_helper
INFO - 2016-03-09 07:52:12 --> Helper loaded: date_helper
INFO - 2016-03-09 07:52:12 --> Helper loaded: form_helper
INFO - 2016-03-09 07:52:12 --> Database Driver Class Initialized
INFO - 2016-03-09 07:52:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:52:13 --> Controller Class Initialized
INFO - 2016-03-09 07:52:13 --> Model Class Initialized
INFO - 2016-03-09 07:52:13 --> Model Class Initialized
INFO - 2016-03-09 07:52:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:52:13 --> Pagination Class Initialized
INFO - 2016-03-09 07:52:13 --> Helper loaded: text_helper
INFO - 2016-03-09 07:52:13 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:52:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:52:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:52:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:52:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:52:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:52:13 --> Final output sent to browser
DEBUG - 2016-03-09 10:52:13 --> Total execution time: 1.1488
INFO - 2016-03-09 07:52:17 --> Config Class Initialized
INFO - 2016-03-09 07:52:17 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:52:17 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:52:17 --> Utf8 Class Initialized
INFO - 2016-03-09 07:52:17 --> URI Class Initialized
INFO - 2016-03-09 07:52:17 --> Router Class Initialized
INFO - 2016-03-09 07:52:17 --> Output Class Initialized
INFO - 2016-03-09 07:52:17 --> Security Class Initialized
DEBUG - 2016-03-09 07:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:52:17 --> Input Class Initialized
INFO - 2016-03-09 07:52:17 --> Language Class Initialized
INFO - 2016-03-09 07:52:17 --> Loader Class Initialized
INFO - 2016-03-09 07:52:17 --> Helper loaded: url_helper
INFO - 2016-03-09 07:52:17 --> Helper loaded: file_helper
INFO - 2016-03-09 07:52:17 --> Helper loaded: date_helper
INFO - 2016-03-09 07:52:17 --> Helper loaded: form_helper
INFO - 2016-03-09 07:52:17 --> Database Driver Class Initialized
INFO - 2016-03-09 07:52:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:52:18 --> Controller Class Initialized
INFO - 2016-03-09 07:52:18 --> Model Class Initialized
INFO - 2016-03-09 07:52:18 --> Model Class Initialized
INFO - 2016-03-09 07:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:52:18 --> Pagination Class Initialized
INFO - 2016-03-09 07:52:18 --> Helper loaded: text_helper
INFO - 2016-03-09 07:52:18 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:52:18 --> Final output sent to browser
DEBUG - 2016-03-09 10:52:18 --> Total execution time: 1.1280
INFO - 2016-03-09 07:52:19 --> Config Class Initialized
INFO - 2016-03-09 07:52:19 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:52:19 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:52:19 --> Utf8 Class Initialized
INFO - 2016-03-09 07:52:19 --> URI Class Initialized
INFO - 2016-03-09 07:52:19 --> Router Class Initialized
INFO - 2016-03-09 07:52:19 --> Output Class Initialized
INFO - 2016-03-09 07:52:19 --> Security Class Initialized
DEBUG - 2016-03-09 07:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:52:19 --> Input Class Initialized
INFO - 2016-03-09 07:52:19 --> Language Class Initialized
INFO - 2016-03-09 07:52:19 --> Loader Class Initialized
INFO - 2016-03-09 07:52:19 --> Helper loaded: url_helper
INFO - 2016-03-09 07:52:19 --> Helper loaded: file_helper
INFO - 2016-03-09 07:52:19 --> Helper loaded: date_helper
INFO - 2016-03-09 07:52:19 --> Helper loaded: form_helper
INFO - 2016-03-09 07:52:19 --> Database Driver Class Initialized
INFO - 2016-03-09 07:52:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:52:20 --> Controller Class Initialized
INFO - 2016-03-09 07:52:20 --> Model Class Initialized
INFO - 2016-03-09 07:52:20 --> Model Class Initialized
INFO - 2016-03-09 07:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:52:20 --> Pagination Class Initialized
INFO - 2016-03-09 07:52:20 --> Helper loaded: text_helper
INFO - 2016-03-09 07:52:20 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 10:52:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-09 10:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:52:20 --> Final output sent to browser
DEBUG - 2016-03-09 10:52:20 --> Total execution time: 1.1667
INFO - 2016-03-09 07:53:16 --> Config Class Initialized
INFO - 2016-03-09 07:53:16 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:53:16 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:53:16 --> Utf8 Class Initialized
INFO - 2016-03-09 07:53:16 --> URI Class Initialized
INFO - 2016-03-09 07:53:16 --> Router Class Initialized
INFO - 2016-03-09 07:53:16 --> Output Class Initialized
INFO - 2016-03-09 07:53:16 --> Security Class Initialized
DEBUG - 2016-03-09 07:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:53:16 --> Input Class Initialized
INFO - 2016-03-09 07:53:16 --> Language Class Initialized
INFO - 2016-03-09 07:53:16 --> Loader Class Initialized
INFO - 2016-03-09 07:53:16 --> Helper loaded: url_helper
INFO - 2016-03-09 07:53:16 --> Helper loaded: file_helper
INFO - 2016-03-09 07:53:16 --> Helper loaded: date_helper
INFO - 2016-03-09 07:53:16 --> Helper loaded: form_helper
INFO - 2016-03-09 07:53:16 --> Database Driver Class Initialized
INFO - 2016-03-09 07:53:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:53:17 --> Controller Class Initialized
INFO - 2016-03-09 07:53:17 --> Model Class Initialized
INFO - 2016-03-09 07:53:17 --> Model Class Initialized
INFO - 2016-03-09 07:53:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:53:17 --> Pagination Class Initialized
INFO - 2016-03-09 07:53:17 --> Helper loaded: text_helper
INFO - 2016-03-09 07:53:17 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:53:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:53:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:53:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:53:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:53:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:53:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:53:17 --> Final output sent to browser
DEBUG - 2016-03-09 10:53:17 --> Total execution time: 1.1641
INFO - 2016-03-09 07:53:56 --> Config Class Initialized
INFO - 2016-03-09 07:53:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:53:56 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:53:56 --> Utf8 Class Initialized
INFO - 2016-03-09 07:53:56 --> URI Class Initialized
INFO - 2016-03-09 07:53:56 --> Router Class Initialized
INFO - 2016-03-09 07:53:56 --> Output Class Initialized
INFO - 2016-03-09 07:53:56 --> Security Class Initialized
DEBUG - 2016-03-09 07:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:53:56 --> Input Class Initialized
INFO - 2016-03-09 07:53:56 --> Language Class Initialized
INFO - 2016-03-09 07:53:56 --> Loader Class Initialized
INFO - 2016-03-09 07:53:56 --> Helper loaded: url_helper
INFO - 2016-03-09 07:53:56 --> Helper loaded: file_helper
INFO - 2016-03-09 07:53:56 --> Helper loaded: date_helper
INFO - 2016-03-09 07:53:56 --> Helper loaded: form_helper
INFO - 2016-03-09 07:53:56 --> Database Driver Class Initialized
INFO - 2016-03-09 07:53:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:53:57 --> Controller Class Initialized
INFO - 2016-03-09 07:53:57 --> Model Class Initialized
INFO - 2016-03-09 07:53:57 --> Model Class Initialized
INFO - 2016-03-09 07:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:53:57 --> Pagination Class Initialized
INFO - 2016-03-09 07:53:57 --> Helper loaded: text_helper
INFO - 2016-03-09 07:53:57 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:53:57 --> Final output sent to browser
DEBUG - 2016-03-09 10:53:57 --> Total execution time: 1.1592
INFO - 2016-03-09 07:54:03 --> Config Class Initialized
INFO - 2016-03-09 07:54:03 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:54:03 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:54:03 --> Utf8 Class Initialized
INFO - 2016-03-09 07:54:03 --> URI Class Initialized
INFO - 2016-03-09 07:54:03 --> Router Class Initialized
INFO - 2016-03-09 07:54:03 --> Output Class Initialized
INFO - 2016-03-09 07:54:03 --> Security Class Initialized
DEBUG - 2016-03-09 07:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:54:03 --> Input Class Initialized
INFO - 2016-03-09 07:54:03 --> Language Class Initialized
INFO - 2016-03-09 07:54:03 --> Loader Class Initialized
INFO - 2016-03-09 07:54:03 --> Helper loaded: url_helper
INFO - 2016-03-09 07:54:03 --> Helper loaded: file_helper
INFO - 2016-03-09 07:54:03 --> Helper loaded: date_helper
INFO - 2016-03-09 07:54:03 --> Helper loaded: form_helper
INFO - 2016-03-09 07:54:03 --> Database Driver Class Initialized
INFO - 2016-03-09 07:54:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:54:04 --> Controller Class Initialized
INFO - 2016-03-09 07:54:04 --> Model Class Initialized
INFO - 2016-03-09 07:54:04 --> Model Class Initialized
INFO - 2016-03-09 07:54:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:54:04 --> Pagination Class Initialized
INFO - 2016-03-09 07:54:04 --> Helper loaded: text_helper
INFO - 2016-03-09 07:54:04 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:54:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:54:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:54:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:54:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:54:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:54:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:54:04 --> Final output sent to browser
DEBUG - 2016-03-09 10:54:04 --> Total execution time: 1.1852
INFO - 2016-03-09 07:54:56 --> Config Class Initialized
INFO - 2016-03-09 07:54:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:54:56 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:54:56 --> Utf8 Class Initialized
INFO - 2016-03-09 07:54:56 --> URI Class Initialized
INFO - 2016-03-09 07:54:56 --> Router Class Initialized
INFO - 2016-03-09 07:54:56 --> Output Class Initialized
INFO - 2016-03-09 07:54:56 --> Security Class Initialized
DEBUG - 2016-03-09 07:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:54:56 --> Input Class Initialized
INFO - 2016-03-09 07:54:56 --> Language Class Initialized
INFO - 2016-03-09 07:54:56 --> Loader Class Initialized
INFO - 2016-03-09 07:54:56 --> Helper loaded: url_helper
INFO - 2016-03-09 07:54:56 --> Helper loaded: file_helper
INFO - 2016-03-09 07:54:56 --> Helper loaded: date_helper
INFO - 2016-03-09 07:54:56 --> Helper loaded: form_helper
INFO - 2016-03-09 07:54:56 --> Database Driver Class Initialized
INFO - 2016-03-09 07:54:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:54:57 --> Controller Class Initialized
INFO - 2016-03-09 07:54:57 --> Model Class Initialized
INFO - 2016-03-09 07:54:57 --> Model Class Initialized
INFO - 2016-03-09 07:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:54:57 --> Pagination Class Initialized
INFO - 2016-03-09 07:54:57 --> Helper loaded: text_helper
INFO - 2016-03-09 07:54:57 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-09 10:54:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-09 10:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:54:57 --> Final output sent to browser
DEBUG - 2016-03-09 10:54:57 --> Total execution time: 1.1349
INFO - 2016-03-09 07:55:00 --> Config Class Initialized
INFO - 2016-03-09 07:55:00 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:55:00 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:55:00 --> Utf8 Class Initialized
INFO - 2016-03-09 07:55:00 --> URI Class Initialized
INFO - 2016-03-09 07:55:00 --> Router Class Initialized
INFO - 2016-03-09 07:55:00 --> Output Class Initialized
INFO - 2016-03-09 07:55:00 --> Security Class Initialized
DEBUG - 2016-03-09 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:55:00 --> Input Class Initialized
INFO - 2016-03-09 07:55:00 --> Language Class Initialized
INFO - 2016-03-09 07:55:00 --> Loader Class Initialized
INFO - 2016-03-09 07:55:00 --> Helper loaded: url_helper
INFO - 2016-03-09 07:55:00 --> Helper loaded: file_helper
INFO - 2016-03-09 07:55:00 --> Helper loaded: date_helper
INFO - 2016-03-09 07:55:00 --> Helper loaded: form_helper
INFO - 2016-03-09 07:55:00 --> Database Driver Class Initialized
INFO - 2016-03-09 07:55:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:55:01 --> Controller Class Initialized
INFO - 2016-03-09 07:55:01 --> Model Class Initialized
INFO - 2016-03-09 07:55:01 --> Model Class Initialized
INFO - 2016-03-09 07:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:55:01 --> Pagination Class Initialized
INFO - 2016-03-09 07:55:01 --> Helper loaded: text_helper
INFO - 2016-03-09 07:55:01 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:55:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:55:01 --> Final output sent to browser
DEBUG - 2016-03-09 10:55:01 --> Total execution time: 1.1547
INFO - 2016-03-09 07:55:08 --> Config Class Initialized
INFO - 2016-03-09 07:55:08 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:55:08 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:55:08 --> Utf8 Class Initialized
INFO - 2016-03-09 07:55:08 --> URI Class Initialized
INFO - 2016-03-09 07:55:08 --> Router Class Initialized
INFO - 2016-03-09 07:55:08 --> Output Class Initialized
INFO - 2016-03-09 07:55:08 --> Security Class Initialized
DEBUG - 2016-03-09 07:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:55:08 --> Input Class Initialized
INFO - 2016-03-09 07:55:08 --> Language Class Initialized
INFO - 2016-03-09 07:55:08 --> Loader Class Initialized
INFO - 2016-03-09 07:55:08 --> Helper loaded: url_helper
INFO - 2016-03-09 07:55:08 --> Helper loaded: file_helper
INFO - 2016-03-09 07:55:08 --> Helper loaded: date_helper
INFO - 2016-03-09 07:55:08 --> Helper loaded: form_helper
INFO - 2016-03-09 07:55:08 --> Database Driver Class Initialized
INFO - 2016-03-09 07:55:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:55:09 --> Controller Class Initialized
INFO - 2016-03-09 07:55:09 --> Model Class Initialized
INFO - 2016-03-09 07:55:09 --> Model Class Initialized
INFO - 2016-03-09 07:55:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:55:09 --> Pagination Class Initialized
INFO - 2016-03-09 07:55:09 --> Helper loaded: text_helper
INFO - 2016-03-09 07:55:09 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:55:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:55:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:55:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:55:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:55:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:55:09 --> Final output sent to browser
DEBUG - 2016-03-09 10:55:09 --> Total execution time: 1.1285
INFO - 2016-03-09 07:55:12 --> Config Class Initialized
INFO - 2016-03-09 07:55:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:55:12 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:55:12 --> Utf8 Class Initialized
INFO - 2016-03-09 07:55:12 --> URI Class Initialized
INFO - 2016-03-09 07:55:12 --> Router Class Initialized
INFO - 2016-03-09 07:55:12 --> Output Class Initialized
INFO - 2016-03-09 07:55:12 --> Security Class Initialized
DEBUG - 2016-03-09 07:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:55:12 --> Input Class Initialized
INFO - 2016-03-09 07:55:12 --> Language Class Initialized
INFO - 2016-03-09 07:55:12 --> Loader Class Initialized
INFO - 2016-03-09 07:55:12 --> Helper loaded: url_helper
INFO - 2016-03-09 07:55:12 --> Helper loaded: file_helper
INFO - 2016-03-09 07:55:12 --> Helper loaded: date_helper
INFO - 2016-03-09 07:55:12 --> Helper loaded: form_helper
INFO - 2016-03-09 07:55:12 --> Database Driver Class Initialized
INFO - 2016-03-09 07:55:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:55:13 --> Controller Class Initialized
INFO - 2016-03-09 07:55:13 --> Model Class Initialized
INFO - 2016-03-09 07:55:13 --> Model Class Initialized
INFO - 2016-03-09 07:55:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:55:13 --> Pagination Class Initialized
INFO - 2016-03-09 07:55:13 --> Helper loaded: text_helper
INFO - 2016-03-09 07:55:13 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:55:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:55:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:55:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:55:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:55:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:55:13 --> Final output sent to browser
DEBUG - 2016-03-09 10:55:13 --> Total execution time: 1.1418
INFO - 2016-03-09 07:55:15 --> Config Class Initialized
INFO - 2016-03-09 07:55:15 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:55:15 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:55:15 --> Utf8 Class Initialized
INFO - 2016-03-09 07:55:15 --> URI Class Initialized
INFO - 2016-03-09 07:55:15 --> Router Class Initialized
INFO - 2016-03-09 07:55:15 --> Output Class Initialized
INFO - 2016-03-09 07:55:15 --> Security Class Initialized
DEBUG - 2016-03-09 07:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:55:15 --> Input Class Initialized
INFO - 2016-03-09 07:55:15 --> Language Class Initialized
INFO - 2016-03-09 07:55:15 --> Loader Class Initialized
INFO - 2016-03-09 07:55:15 --> Helper loaded: url_helper
INFO - 2016-03-09 07:55:15 --> Helper loaded: file_helper
INFO - 2016-03-09 07:55:15 --> Helper loaded: date_helper
INFO - 2016-03-09 07:55:15 --> Helper loaded: form_helper
INFO - 2016-03-09 07:55:15 --> Database Driver Class Initialized
INFO - 2016-03-09 07:55:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:55:16 --> Controller Class Initialized
INFO - 2016-03-09 07:55:16 --> Model Class Initialized
INFO - 2016-03-09 07:55:16 --> Model Class Initialized
INFO - 2016-03-09 07:55:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:55:16 --> Pagination Class Initialized
INFO - 2016-03-09 07:55:16 --> Helper loaded: text_helper
INFO - 2016-03-09 07:55:16 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:55:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:55:16 --> Final output sent to browser
DEBUG - 2016-03-09 10:55:16 --> Total execution time: 1.1871
INFO - 2016-03-09 07:55:40 --> Config Class Initialized
INFO - 2016-03-09 07:55:40 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:55:40 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:55:40 --> Utf8 Class Initialized
INFO - 2016-03-09 07:55:40 --> URI Class Initialized
INFO - 2016-03-09 07:55:40 --> Router Class Initialized
INFO - 2016-03-09 07:55:40 --> Output Class Initialized
INFO - 2016-03-09 07:55:40 --> Security Class Initialized
DEBUG - 2016-03-09 07:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:55:40 --> Input Class Initialized
INFO - 2016-03-09 07:55:40 --> Language Class Initialized
INFO - 2016-03-09 07:55:40 --> Loader Class Initialized
INFO - 2016-03-09 07:55:40 --> Helper loaded: url_helper
INFO - 2016-03-09 07:55:40 --> Helper loaded: file_helper
INFO - 2016-03-09 07:55:40 --> Helper loaded: date_helper
INFO - 2016-03-09 07:55:40 --> Helper loaded: form_helper
INFO - 2016-03-09 07:55:40 --> Database Driver Class Initialized
INFO - 2016-03-09 07:55:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:55:41 --> Controller Class Initialized
INFO - 2016-03-09 07:55:41 --> Model Class Initialized
INFO - 2016-03-09 07:55:41 --> Model Class Initialized
INFO - 2016-03-09 07:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:55:41 --> Pagination Class Initialized
INFO - 2016-03-09 07:55:41 --> Helper loaded: text_helper
INFO - 2016-03-09 07:55:41 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:55:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:55:41 --> Final output sent to browser
DEBUG - 2016-03-09 10:55:41 --> Total execution time: 1.2924
INFO - 2016-03-09 07:55:45 --> Config Class Initialized
INFO - 2016-03-09 07:55:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:55:45 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:55:45 --> Utf8 Class Initialized
INFO - 2016-03-09 07:55:45 --> URI Class Initialized
INFO - 2016-03-09 07:55:45 --> Router Class Initialized
INFO - 2016-03-09 07:55:45 --> Output Class Initialized
INFO - 2016-03-09 07:55:45 --> Security Class Initialized
DEBUG - 2016-03-09 07:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:55:45 --> Input Class Initialized
INFO - 2016-03-09 07:55:45 --> Language Class Initialized
INFO - 2016-03-09 07:55:45 --> Loader Class Initialized
INFO - 2016-03-09 07:55:45 --> Helper loaded: url_helper
INFO - 2016-03-09 07:55:45 --> Helper loaded: file_helper
INFO - 2016-03-09 07:55:45 --> Helper loaded: date_helper
INFO - 2016-03-09 07:55:45 --> Helper loaded: form_helper
INFO - 2016-03-09 07:55:45 --> Database Driver Class Initialized
INFO - 2016-03-09 07:55:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:55:46 --> Controller Class Initialized
INFO - 2016-03-09 07:55:46 --> Model Class Initialized
INFO - 2016-03-09 07:55:46 --> Model Class Initialized
INFO - 2016-03-09 07:55:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:55:46 --> Pagination Class Initialized
INFO - 2016-03-09 07:55:46 --> Helper loaded: text_helper
INFO - 2016-03-09 07:55:46 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:55:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:55:46 --> Final output sent to browser
DEBUG - 2016-03-09 10:55:46 --> Total execution time: 1.1631
INFO - 2016-03-09 07:55:51 --> Config Class Initialized
INFO - 2016-03-09 07:55:51 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:55:51 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:55:51 --> Utf8 Class Initialized
INFO - 2016-03-09 07:55:51 --> URI Class Initialized
INFO - 2016-03-09 07:55:51 --> Router Class Initialized
INFO - 2016-03-09 07:55:51 --> Output Class Initialized
INFO - 2016-03-09 07:55:51 --> Security Class Initialized
DEBUG - 2016-03-09 07:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:55:51 --> Input Class Initialized
INFO - 2016-03-09 07:55:51 --> Language Class Initialized
INFO - 2016-03-09 07:55:51 --> Loader Class Initialized
INFO - 2016-03-09 07:55:51 --> Helper loaded: url_helper
INFO - 2016-03-09 07:55:51 --> Helper loaded: file_helper
INFO - 2016-03-09 07:55:51 --> Helper loaded: date_helper
INFO - 2016-03-09 07:55:51 --> Helper loaded: form_helper
INFO - 2016-03-09 07:55:51 --> Database Driver Class Initialized
INFO - 2016-03-09 07:55:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:55:52 --> Controller Class Initialized
INFO - 2016-03-09 07:55:52 --> Model Class Initialized
INFO - 2016-03-09 07:55:52 --> Model Class Initialized
INFO - 2016-03-09 07:55:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:55:52 --> Pagination Class Initialized
INFO - 2016-03-09 07:55:52 --> Helper loaded: text_helper
INFO - 2016-03-09 07:55:52 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:55:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:55:52 --> Final output sent to browser
DEBUG - 2016-03-09 10:55:52 --> Total execution time: 1.1760
INFO - 2016-03-09 07:56:10 --> Config Class Initialized
INFO - 2016-03-09 07:56:10 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:56:10 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:56:10 --> Utf8 Class Initialized
INFO - 2016-03-09 07:56:10 --> URI Class Initialized
INFO - 2016-03-09 07:56:10 --> Router Class Initialized
INFO - 2016-03-09 07:56:10 --> Output Class Initialized
INFO - 2016-03-09 07:56:10 --> Security Class Initialized
DEBUG - 2016-03-09 07:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:56:10 --> Input Class Initialized
INFO - 2016-03-09 07:56:10 --> Language Class Initialized
INFO - 2016-03-09 07:56:10 --> Loader Class Initialized
INFO - 2016-03-09 07:56:10 --> Helper loaded: url_helper
INFO - 2016-03-09 07:56:10 --> Helper loaded: file_helper
INFO - 2016-03-09 07:56:10 --> Helper loaded: date_helper
INFO - 2016-03-09 07:56:10 --> Helper loaded: form_helper
INFO - 2016-03-09 07:56:10 --> Database Driver Class Initialized
INFO - 2016-03-09 07:56:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:56:11 --> Controller Class Initialized
INFO - 2016-03-09 07:56:11 --> Model Class Initialized
INFO - 2016-03-09 07:56:11 --> Model Class Initialized
INFO - 2016-03-09 07:56:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:56:11 --> Pagination Class Initialized
INFO - 2016-03-09 07:56:11 --> Helper loaded: text_helper
INFO - 2016-03-09 07:56:11 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:56:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:56:11 --> Final output sent to browser
DEBUG - 2016-03-09 10:56:11 --> Total execution time: 1.1070
INFO - 2016-03-09 07:57:03 --> Config Class Initialized
INFO - 2016-03-09 07:57:03 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:57:03 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:57:03 --> Utf8 Class Initialized
INFO - 2016-03-09 07:57:03 --> URI Class Initialized
INFO - 2016-03-09 07:57:03 --> Router Class Initialized
INFO - 2016-03-09 07:57:03 --> Output Class Initialized
INFO - 2016-03-09 07:57:03 --> Security Class Initialized
DEBUG - 2016-03-09 07:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:57:03 --> Input Class Initialized
INFO - 2016-03-09 07:57:03 --> Language Class Initialized
INFO - 2016-03-09 07:57:03 --> Loader Class Initialized
INFO - 2016-03-09 07:57:03 --> Helper loaded: url_helper
INFO - 2016-03-09 07:57:03 --> Helper loaded: file_helper
INFO - 2016-03-09 07:57:03 --> Helper loaded: date_helper
INFO - 2016-03-09 07:57:03 --> Helper loaded: form_helper
INFO - 2016-03-09 07:57:03 --> Database Driver Class Initialized
INFO - 2016-03-09 07:57:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:57:04 --> Controller Class Initialized
INFO - 2016-03-09 07:57:04 --> Model Class Initialized
INFO - 2016-03-09 07:57:04 --> Model Class Initialized
INFO - 2016-03-09 07:57:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:57:04 --> Pagination Class Initialized
INFO - 2016-03-09 07:57:04 --> Helper loaded: text_helper
INFO - 2016-03-09 07:57:04 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:57:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:57:04 --> Final output sent to browser
DEBUG - 2016-03-09 10:57:04 --> Total execution time: 1.1452
INFO - 2016-03-09 07:57:06 --> Config Class Initialized
INFO - 2016-03-09 07:57:06 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:57:06 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:57:06 --> Utf8 Class Initialized
INFO - 2016-03-09 07:57:06 --> URI Class Initialized
INFO - 2016-03-09 07:57:06 --> Router Class Initialized
INFO - 2016-03-09 07:57:06 --> Output Class Initialized
INFO - 2016-03-09 07:57:06 --> Security Class Initialized
DEBUG - 2016-03-09 07:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:57:06 --> Input Class Initialized
INFO - 2016-03-09 07:57:06 --> Language Class Initialized
INFO - 2016-03-09 07:57:06 --> Loader Class Initialized
INFO - 2016-03-09 07:57:06 --> Helper loaded: url_helper
INFO - 2016-03-09 07:57:06 --> Helper loaded: file_helper
INFO - 2016-03-09 07:57:06 --> Helper loaded: date_helper
INFO - 2016-03-09 07:57:06 --> Helper loaded: form_helper
INFO - 2016-03-09 07:57:06 --> Database Driver Class Initialized
INFO - 2016-03-09 07:57:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:57:07 --> Controller Class Initialized
INFO - 2016-03-09 07:57:07 --> Model Class Initialized
INFO - 2016-03-09 07:57:07 --> Model Class Initialized
INFO - 2016-03-09 07:57:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:57:07 --> Pagination Class Initialized
INFO - 2016-03-09 07:57:07 --> Helper loaded: text_helper
INFO - 2016-03-09 07:57:07 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:57:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:57:07 --> Final output sent to browser
DEBUG - 2016-03-09 10:57:07 --> Total execution time: 1.1123
INFO - 2016-03-09 07:57:24 --> Config Class Initialized
INFO - 2016-03-09 07:57:24 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:57:24 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:57:24 --> Utf8 Class Initialized
INFO - 2016-03-09 07:57:24 --> URI Class Initialized
INFO - 2016-03-09 07:57:24 --> Router Class Initialized
INFO - 2016-03-09 07:57:24 --> Output Class Initialized
INFO - 2016-03-09 07:57:24 --> Security Class Initialized
DEBUG - 2016-03-09 07:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:57:24 --> Input Class Initialized
INFO - 2016-03-09 07:57:24 --> Language Class Initialized
INFO - 2016-03-09 07:57:24 --> Loader Class Initialized
INFO - 2016-03-09 07:57:24 --> Helper loaded: url_helper
INFO - 2016-03-09 07:57:24 --> Helper loaded: file_helper
INFO - 2016-03-09 07:57:24 --> Helper loaded: date_helper
INFO - 2016-03-09 07:57:24 --> Helper loaded: form_helper
INFO - 2016-03-09 07:57:24 --> Database Driver Class Initialized
INFO - 2016-03-09 07:57:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:57:25 --> Controller Class Initialized
INFO - 2016-03-09 07:57:25 --> Model Class Initialized
INFO - 2016-03-09 07:57:25 --> Model Class Initialized
INFO - 2016-03-09 07:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:57:25 --> Pagination Class Initialized
INFO - 2016-03-09 07:57:25 --> Helper loaded: text_helper
INFO - 2016-03-09 07:57:25 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:57:25 --> Final output sent to browser
DEBUG - 2016-03-09 10:57:25 --> Total execution time: 1.1977
INFO - 2016-03-09 07:57:32 --> Config Class Initialized
INFO - 2016-03-09 07:57:32 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:57:32 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:57:32 --> Utf8 Class Initialized
INFO - 2016-03-09 07:57:32 --> URI Class Initialized
INFO - 2016-03-09 07:57:32 --> Router Class Initialized
INFO - 2016-03-09 07:57:32 --> Output Class Initialized
INFO - 2016-03-09 07:57:32 --> Security Class Initialized
DEBUG - 2016-03-09 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:57:32 --> Input Class Initialized
INFO - 2016-03-09 07:57:32 --> Language Class Initialized
INFO - 2016-03-09 07:57:32 --> Loader Class Initialized
INFO - 2016-03-09 07:57:32 --> Helper loaded: url_helper
INFO - 2016-03-09 07:57:32 --> Helper loaded: file_helper
INFO - 2016-03-09 07:57:32 --> Helper loaded: date_helper
INFO - 2016-03-09 07:57:32 --> Helper loaded: form_helper
INFO - 2016-03-09 07:57:32 --> Database Driver Class Initialized
INFO - 2016-03-09 07:57:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:57:34 --> Controller Class Initialized
INFO - 2016-03-09 07:57:34 --> Model Class Initialized
INFO - 2016-03-09 07:57:34 --> Model Class Initialized
INFO - 2016-03-09 07:57:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:57:34 --> Pagination Class Initialized
INFO - 2016-03-09 07:57:34 --> Helper loaded: text_helper
INFO - 2016-03-09 07:57:34 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:57:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:57:34 --> Final output sent to browser
DEBUG - 2016-03-09 10:57:34 --> Total execution time: 1.1728
INFO - 2016-03-09 07:57:49 --> Config Class Initialized
INFO - 2016-03-09 07:57:49 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:57:49 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:57:49 --> Utf8 Class Initialized
INFO - 2016-03-09 07:57:49 --> URI Class Initialized
INFO - 2016-03-09 07:57:49 --> Router Class Initialized
INFO - 2016-03-09 07:57:49 --> Output Class Initialized
INFO - 2016-03-09 07:57:49 --> Security Class Initialized
DEBUG - 2016-03-09 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:57:49 --> Input Class Initialized
INFO - 2016-03-09 07:57:49 --> Language Class Initialized
INFO - 2016-03-09 07:57:49 --> Loader Class Initialized
INFO - 2016-03-09 07:57:49 --> Helper loaded: url_helper
INFO - 2016-03-09 07:57:49 --> Helper loaded: file_helper
INFO - 2016-03-09 07:57:49 --> Helper loaded: date_helper
INFO - 2016-03-09 07:57:49 --> Helper loaded: form_helper
INFO - 2016-03-09 07:57:49 --> Database Driver Class Initialized
INFO - 2016-03-09 07:57:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:57:50 --> Controller Class Initialized
INFO - 2016-03-09 07:57:50 --> Model Class Initialized
INFO - 2016-03-09 07:57:50 --> Model Class Initialized
INFO - 2016-03-09 07:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:57:50 --> Pagination Class Initialized
INFO - 2016-03-09 07:57:50 --> Helper loaded: text_helper
INFO - 2016-03-09 07:57:50 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:57:50 --> Final output sent to browser
DEBUG - 2016-03-09 10:57:50 --> Total execution time: 1.1443
INFO - 2016-03-09 07:57:53 --> Config Class Initialized
INFO - 2016-03-09 07:57:53 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:57:53 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:57:53 --> Utf8 Class Initialized
INFO - 2016-03-09 07:57:53 --> URI Class Initialized
INFO - 2016-03-09 07:57:53 --> Router Class Initialized
INFO - 2016-03-09 07:57:53 --> Output Class Initialized
INFO - 2016-03-09 07:57:53 --> Security Class Initialized
DEBUG - 2016-03-09 07:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:57:53 --> Input Class Initialized
INFO - 2016-03-09 07:57:53 --> Language Class Initialized
INFO - 2016-03-09 07:57:53 --> Loader Class Initialized
INFO - 2016-03-09 07:57:53 --> Helper loaded: url_helper
INFO - 2016-03-09 07:57:53 --> Helper loaded: file_helper
INFO - 2016-03-09 07:57:53 --> Helper loaded: date_helper
INFO - 2016-03-09 07:57:53 --> Helper loaded: form_helper
INFO - 2016-03-09 07:57:53 --> Database Driver Class Initialized
INFO - 2016-03-09 07:57:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:57:54 --> Controller Class Initialized
INFO - 2016-03-09 07:57:54 --> Model Class Initialized
INFO - 2016-03-09 07:57:54 --> Model Class Initialized
INFO - 2016-03-09 07:57:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:57:54 --> Pagination Class Initialized
INFO - 2016-03-09 07:57:54 --> Helper loaded: text_helper
INFO - 2016-03-09 07:57:54 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:57:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:57:54 --> Final output sent to browser
DEBUG - 2016-03-09 10:57:54 --> Total execution time: 1.1446
INFO - 2016-03-09 07:57:57 --> Config Class Initialized
INFO - 2016-03-09 07:57:57 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:57:57 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:57:57 --> Utf8 Class Initialized
INFO - 2016-03-09 07:57:57 --> URI Class Initialized
INFO - 2016-03-09 07:57:57 --> Router Class Initialized
INFO - 2016-03-09 07:57:57 --> Output Class Initialized
INFO - 2016-03-09 07:57:57 --> Security Class Initialized
DEBUG - 2016-03-09 07:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:57:57 --> Input Class Initialized
INFO - 2016-03-09 07:57:57 --> Language Class Initialized
INFO - 2016-03-09 07:57:57 --> Loader Class Initialized
INFO - 2016-03-09 07:57:57 --> Helper loaded: url_helper
INFO - 2016-03-09 07:57:57 --> Helper loaded: file_helper
INFO - 2016-03-09 07:57:57 --> Helper loaded: date_helper
INFO - 2016-03-09 07:57:57 --> Helper loaded: form_helper
INFO - 2016-03-09 07:57:57 --> Database Driver Class Initialized
INFO - 2016-03-09 07:57:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:57:58 --> Controller Class Initialized
INFO - 2016-03-09 07:57:58 --> Model Class Initialized
INFO - 2016-03-09 07:57:58 --> Model Class Initialized
INFO - 2016-03-09 07:57:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:57:58 --> Pagination Class Initialized
INFO - 2016-03-09 07:57:58 --> Helper loaded: text_helper
INFO - 2016-03-09 07:57:58 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 10:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 10:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 10:57:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:57:58 --> Final output sent to browser
DEBUG - 2016-03-09 10:57:58 --> Total execution time: 1.2086
INFO - 2016-03-09 07:58:29 --> Config Class Initialized
INFO - 2016-03-09 07:58:29 --> Hooks Class Initialized
DEBUG - 2016-03-09 07:58:29 --> UTF-8 Support Enabled
INFO - 2016-03-09 07:58:29 --> Utf8 Class Initialized
INFO - 2016-03-09 07:58:29 --> URI Class Initialized
INFO - 2016-03-09 07:58:29 --> Router Class Initialized
INFO - 2016-03-09 07:58:29 --> Output Class Initialized
INFO - 2016-03-09 07:58:29 --> Security Class Initialized
DEBUG - 2016-03-09 07:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 07:58:29 --> Input Class Initialized
INFO - 2016-03-09 07:58:29 --> Language Class Initialized
INFO - 2016-03-09 07:58:29 --> Loader Class Initialized
INFO - 2016-03-09 07:58:29 --> Helper loaded: url_helper
INFO - 2016-03-09 07:58:29 --> Helper loaded: file_helper
INFO - 2016-03-09 07:58:29 --> Helper loaded: date_helper
INFO - 2016-03-09 07:58:29 --> Helper loaded: form_helper
INFO - 2016-03-09 07:58:29 --> Database Driver Class Initialized
INFO - 2016-03-09 07:58:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 07:58:30 --> Controller Class Initialized
INFO - 2016-03-09 07:58:30 --> Model Class Initialized
INFO - 2016-03-09 07:58:30 --> Model Class Initialized
INFO - 2016-03-09 07:58:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 07:58:30 --> Pagination Class Initialized
INFO - 2016-03-09 07:58:30 --> Helper loaded: text_helper
INFO - 2016-03-09 07:58:30 --> Helper loaded: cookie_helper
INFO - 2016-03-09 10:58:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 10:58:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 10:58:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 10:58:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 10:58:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 10:58:30 --> Final output sent to browser
DEBUG - 2016-03-09 10:58:30 --> Total execution time: 1.1339
INFO - 2016-03-09 08:02:07 --> Config Class Initialized
INFO - 2016-03-09 08:02:07 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:02:07 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:02:07 --> Utf8 Class Initialized
INFO - 2016-03-09 08:02:07 --> URI Class Initialized
INFO - 2016-03-09 08:02:07 --> Router Class Initialized
INFO - 2016-03-09 08:02:07 --> Output Class Initialized
INFO - 2016-03-09 08:02:07 --> Security Class Initialized
DEBUG - 2016-03-09 08:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:02:07 --> Input Class Initialized
INFO - 2016-03-09 08:02:07 --> Language Class Initialized
INFO - 2016-03-09 08:02:07 --> Loader Class Initialized
INFO - 2016-03-09 08:02:07 --> Helper loaded: url_helper
INFO - 2016-03-09 08:02:07 --> Helper loaded: file_helper
INFO - 2016-03-09 08:02:07 --> Helper loaded: date_helper
INFO - 2016-03-09 08:02:07 --> Helper loaded: form_helper
INFO - 2016-03-09 08:02:07 --> Database Driver Class Initialized
INFO - 2016-03-09 08:02:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:02:09 --> Controller Class Initialized
INFO - 2016-03-09 08:02:09 --> Model Class Initialized
INFO - 2016-03-09 08:02:09 --> Model Class Initialized
INFO - 2016-03-09 08:02:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:02:09 --> Pagination Class Initialized
INFO - 2016-03-09 08:02:09 --> Helper loaded: text_helper
INFO - 2016-03-09 08:02:09 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:02:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:02:09 --> Final output sent to browser
DEBUG - 2016-03-09 11:02:09 --> Total execution time: 1.1449
INFO - 2016-03-09 08:02:14 --> Config Class Initialized
INFO - 2016-03-09 08:02:14 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:02:14 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:02:14 --> Utf8 Class Initialized
INFO - 2016-03-09 08:02:14 --> URI Class Initialized
INFO - 2016-03-09 08:02:14 --> Router Class Initialized
INFO - 2016-03-09 08:02:14 --> Output Class Initialized
INFO - 2016-03-09 08:02:14 --> Security Class Initialized
DEBUG - 2016-03-09 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:02:14 --> Input Class Initialized
INFO - 2016-03-09 08:02:14 --> Language Class Initialized
INFO - 2016-03-09 08:02:14 --> Loader Class Initialized
INFO - 2016-03-09 08:02:14 --> Helper loaded: url_helper
INFO - 2016-03-09 08:02:14 --> Helper loaded: file_helper
INFO - 2016-03-09 08:02:14 --> Helper loaded: date_helper
INFO - 2016-03-09 08:02:14 --> Helper loaded: form_helper
INFO - 2016-03-09 08:02:14 --> Database Driver Class Initialized
INFO - 2016-03-09 08:02:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:02:15 --> Controller Class Initialized
INFO - 2016-03-09 08:02:15 --> Model Class Initialized
INFO - 2016-03-09 08:02:15 --> Model Class Initialized
INFO - 2016-03-09 08:02:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:02:15 --> Pagination Class Initialized
INFO - 2016-03-09 08:02:15 --> Helper loaded: text_helper
INFO - 2016-03-09 08:02:15 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:02:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:02:15 --> Final output sent to browser
DEBUG - 2016-03-09 11:02:15 --> Total execution time: 1.2055
INFO - 2016-03-09 08:02:51 --> Config Class Initialized
INFO - 2016-03-09 08:02:51 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:02:51 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:02:51 --> Utf8 Class Initialized
INFO - 2016-03-09 08:02:51 --> URI Class Initialized
INFO - 2016-03-09 08:02:51 --> Router Class Initialized
INFO - 2016-03-09 08:02:51 --> Output Class Initialized
INFO - 2016-03-09 08:02:51 --> Security Class Initialized
DEBUG - 2016-03-09 08:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:02:51 --> Input Class Initialized
INFO - 2016-03-09 08:02:51 --> Language Class Initialized
INFO - 2016-03-09 08:02:51 --> Loader Class Initialized
INFO - 2016-03-09 08:02:51 --> Helper loaded: url_helper
INFO - 2016-03-09 08:02:51 --> Helper loaded: file_helper
INFO - 2016-03-09 08:02:51 --> Helper loaded: date_helper
INFO - 2016-03-09 08:02:51 --> Helper loaded: form_helper
INFO - 2016-03-09 08:02:51 --> Database Driver Class Initialized
INFO - 2016-03-09 08:02:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:02:52 --> Controller Class Initialized
INFO - 2016-03-09 08:02:52 --> Model Class Initialized
INFO - 2016-03-09 08:02:52 --> Model Class Initialized
INFO - 2016-03-09 08:02:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:02:52 --> Pagination Class Initialized
INFO - 2016-03-09 08:02:52 --> Helper loaded: text_helper
INFO - 2016-03-09 08:02:52 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:02:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:02:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:02:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:02:53 --> Final output sent to browser
DEBUG - 2016-03-09 11:02:53 --> Total execution time: 1.3743
INFO - 2016-03-09 08:02:58 --> Config Class Initialized
INFO - 2016-03-09 08:02:58 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:02:58 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:02:58 --> Utf8 Class Initialized
INFO - 2016-03-09 08:02:58 --> URI Class Initialized
INFO - 2016-03-09 08:02:58 --> Router Class Initialized
INFO - 2016-03-09 08:02:58 --> Output Class Initialized
INFO - 2016-03-09 08:02:58 --> Security Class Initialized
DEBUG - 2016-03-09 08:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:02:58 --> Input Class Initialized
INFO - 2016-03-09 08:02:58 --> Language Class Initialized
INFO - 2016-03-09 08:02:58 --> Loader Class Initialized
INFO - 2016-03-09 08:02:58 --> Helper loaded: url_helper
INFO - 2016-03-09 08:02:58 --> Helper loaded: file_helper
INFO - 2016-03-09 08:02:58 --> Helper loaded: date_helper
INFO - 2016-03-09 08:02:58 --> Helper loaded: form_helper
INFO - 2016-03-09 08:02:58 --> Database Driver Class Initialized
INFO - 2016-03-09 08:02:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:02:59 --> Controller Class Initialized
INFO - 2016-03-09 08:02:59 --> Model Class Initialized
INFO - 2016-03-09 08:02:59 --> Model Class Initialized
INFO - 2016-03-09 08:02:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:02:59 --> Pagination Class Initialized
INFO - 2016-03-09 08:02:59 --> Helper loaded: text_helper
INFO - 2016-03-09 08:02:59 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:02:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:02:59 --> Final output sent to browser
DEBUG - 2016-03-09 11:02:59 --> Total execution time: 1.1457
INFO - 2016-03-09 08:03:02 --> Config Class Initialized
INFO - 2016-03-09 08:03:02 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:03:02 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:03:02 --> Utf8 Class Initialized
INFO - 2016-03-09 08:03:02 --> URI Class Initialized
INFO - 2016-03-09 08:03:02 --> Router Class Initialized
INFO - 2016-03-09 08:03:02 --> Output Class Initialized
INFO - 2016-03-09 08:03:02 --> Security Class Initialized
DEBUG - 2016-03-09 08:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:03:02 --> Input Class Initialized
INFO - 2016-03-09 08:03:02 --> Language Class Initialized
INFO - 2016-03-09 08:03:02 --> Loader Class Initialized
INFO - 2016-03-09 08:03:02 --> Helper loaded: url_helper
INFO - 2016-03-09 08:03:02 --> Helper loaded: file_helper
INFO - 2016-03-09 08:03:02 --> Helper loaded: date_helper
INFO - 2016-03-09 08:03:02 --> Helper loaded: form_helper
INFO - 2016-03-09 08:03:02 --> Database Driver Class Initialized
INFO - 2016-03-09 08:03:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:03:03 --> Controller Class Initialized
INFO - 2016-03-09 08:03:03 --> Model Class Initialized
INFO - 2016-03-09 08:03:03 --> Model Class Initialized
INFO - 2016-03-09 08:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:03:03 --> Pagination Class Initialized
INFO - 2016-03-09 08:03:03 --> Helper loaded: text_helper
INFO - 2016-03-09 08:03:03 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:03:03 --> Final output sent to browser
DEBUG - 2016-03-09 11:03:03 --> Total execution time: 1.1502
INFO - 2016-03-09 08:03:04 --> Config Class Initialized
INFO - 2016-03-09 08:03:04 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:03:04 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:03:04 --> Utf8 Class Initialized
INFO - 2016-03-09 08:03:04 --> URI Class Initialized
INFO - 2016-03-09 08:03:04 --> Router Class Initialized
INFO - 2016-03-09 08:03:04 --> Output Class Initialized
INFO - 2016-03-09 08:03:04 --> Security Class Initialized
DEBUG - 2016-03-09 08:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:03:04 --> Input Class Initialized
INFO - 2016-03-09 08:03:04 --> Language Class Initialized
INFO - 2016-03-09 08:03:04 --> Loader Class Initialized
INFO - 2016-03-09 08:03:04 --> Helper loaded: url_helper
INFO - 2016-03-09 08:03:04 --> Helper loaded: file_helper
INFO - 2016-03-09 08:03:04 --> Helper loaded: date_helper
INFO - 2016-03-09 08:03:04 --> Helper loaded: form_helper
INFO - 2016-03-09 08:03:04 --> Database Driver Class Initialized
INFO - 2016-03-09 08:03:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:03:05 --> Controller Class Initialized
INFO - 2016-03-09 08:03:05 --> Model Class Initialized
INFO - 2016-03-09 08:03:05 --> Model Class Initialized
INFO - 2016-03-09 08:03:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:03:05 --> Pagination Class Initialized
INFO - 2016-03-09 08:03:05 --> Helper loaded: text_helper
INFO - 2016-03-09 08:03:05 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:03:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:03:05 --> Final output sent to browser
DEBUG - 2016-03-09 11:03:05 --> Total execution time: 1.1726
INFO - 2016-03-09 08:04:01 --> Config Class Initialized
INFO - 2016-03-09 08:04:01 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:04:01 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:04:01 --> Utf8 Class Initialized
INFO - 2016-03-09 08:04:01 --> URI Class Initialized
INFO - 2016-03-09 08:04:01 --> Router Class Initialized
INFO - 2016-03-09 08:04:01 --> Output Class Initialized
INFO - 2016-03-09 08:04:01 --> Security Class Initialized
DEBUG - 2016-03-09 08:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:04:01 --> Input Class Initialized
INFO - 2016-03-09 08:04:01 --> Language Class Initialized
INFO - 2016-03-09 08:04:01 --> Loader Class Initialized
INFO - 2016-03-09 08:04:01 --> Helper loaded: url_helper
INFO - 2016-03-09 08:04:01 --> Helper loaded: file_helper
INFO - 2016-03-09 08:04:01 --> Helper loaded: date_helper
INFO - 2016-03-09 08:04:01 --> Helper loaded: form_helper
INFO - 2016-03-09 08:04:01 --> Database Driver Class Initialized
INFO - 2016-03-09 08:04:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:04:02 --> Controller Class Initialized
INFO - 2016-03-09 08:04:02 --> Model Class Initialized
INFO - 2016-03-09 08:04:02 --> Model Class Initialized
INFO - 2016-03-09 08:04:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:04:02 --> Pagination Class Initialized
INFO - 2016-03-09 08:04:02 --> Helper loaded: text_helper
INFO - 2016-03-09 08:04:02 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:04:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:04:02 --> Final output sent to browser
DEBUG - 2016-03-09 11:04:02 --> Total execution time: 1.1256
INFO - 2016-03-09 08:04:03 --> Config Class Initialized
INFO - 2016-03-09 08:04:03 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:04:03 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:04:03 --> Utf8 Class Initialized
INFO - 2016-03-09 08:04:03 --> URI Class Initialized
INFO - 2016-03-09 08:04:03 --> Router Class Initialized
INFO - 2016-03-09 08:04:03 --> Output Class Initialized
INFO - 2016-03-09 08:04:03 --> Security Class Initialized
DEBUG - 2016-03-09 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:04:03 --> Input Class Initialized
INFO - 2016-03-09 08:04:03 --> Language Class Initialized
INFO - 2016-03-09 08:04:03 --> Loader Class Initialized
INFO - 2016-03-09 08:04:03 --> Helper loaded: url_helper
INFO - 2016-03-09 08:04:03 --> Helper loaded: file_helper
INFO - 2016-03-09 08:04:03 --> Helper loaded: date_helper
INFO - 2016-03-09 08:04:03 --> Helper loaded: form_helper
INFO - 2016-03-09 08:04:03 --> Database Driver Class Initialized
INFO - 2016-03-09 08:04:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:04:04 --> Controller Class Initialized
INFO - 2016-03-09 08:04:04 --> Model Class Initialized
INFO - 2016-03-09 08:04:04 --> Model Class Initialized
INFO - 2016-03-09 08:04:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:04:04 --> Pagination Class Initialized
INFO - 2016-03-09 08:04:04 --> Helper loaded: text_helper
INFO - 2016-03-09 08:04:04 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:04:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:04:04 --> Final output sent to browser
DEBUG - 2016-03-09 11:04:04 --> Total execution time: 1.1492
INFO - 2016-03-09 08:04:06 --> Config Class Initialized
INFO - 2016-03-09 08:04:06 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:04:06 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:04:06 --> Utf8 Class Initialized
INFO - 2016-03-09 08:04:06 --> URI Class Initialized
INFO - 2016-03-09 08:04:06 --> Router Class Initialized
INFO - 2016-03-09 08:04:06 --> Output Class Initialized
INFO - 2016-03-09 08:04:06 --> Security Class Initialized
DEBUG - 2016-03-09 08:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:04:06 --> Input Class Initialized
INFO - 2016-03-09 08:04:06 --> Language Class Initialized
INFO - 2016-03-09 08:04:06 --> Loader Class Initialized
INFO - 2016-03-09 08:04:06 --> Helper loaded: url_helper
INFO - 2016-03-09 08:04:06 --> Helper loaded: file_helper
INFO - 2016-03-09 08:04:06 --> Helper loaded: date_helper
INFO - 2016-03-09 08:04:06 --> Helper loaded: form_helper
INFO - 2016-03-09 08:04:06 --> Database Driver Class Initialized
INFO - 2016-03-09 08:04:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:04:07 --> Controller Class Initialized
INFO - 2016-03-09 08:04:07 --> Model Class Initialized
INFO - 2016-03-09 08:04:07 --> Model Class Initialized
INFO - 2016-03-09 08:04:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:04:07 --> Pagination Class Initialized
INFO - 2016-03-09 08:04:07 --> Helper loaded: text_helper
INFO - 2016-03-09 08:04:07 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:04:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:04:07 --> Final output sent to browser
DEBUG - 2016-03-09 11:04:07 --> Total execution time: 1.1900
INFO - 2016-03-09 08:04:20 --> Config Class Initialized
INFO - 2016-03-09 08:04:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:04:20 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:04:20 --> Utf8 Class Initialized
INFO - 2016-03-09 08:04:20 --> URI Class Initialized
INFO - 2016-03-09 08:04:20 --> Router Class Initialized
INFO - 2016-03-09 08:04:20 --> Output Class Initialized
INFO - 2016-03-09 08:04:20 --> Security Class Initialized
DEBUG - 2016-03-09 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:04:20 --> Input Class Initialized
INFO - 2016-03-09 08:04:20 --> Language Class Initialized
INFO - 2016-03-09 08:04:20 --> Loader Class Initialized
INFO - 2016-03-09 08:04:20 --> Helper loaded: url_helper
INFO - 2016-03-09 08:04:20 --> Helper loaded: file_helper
INFO - 2016-03-09 08:04:20 --> Helper loaded: date_helper
INFO - 2016-03-09 08:04:20 --> Helper loaded: form_helper
INFO - 2016-03-09 08:04:20 --> Database Driver Class Initialized
INFO - 2016-03-09 08:04:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:04:21 --> Controller Class Initialized
INFO - 2016-03-09 08:04:21 --> Model Class Initialized
INFO - 2016-03-09 08:04:21 --> Model Class Initialized
INFO - 2016-03-09 08:04:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:04:21 --> Pagination Class Initialized
INFO - 2016-03-09 08:04:21 --> Helper loaded: text_helper
INFO - 2016-03-09 08:04:21 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:04:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:04:21 --> Final output sent to browser
DEBUG - 2016-03-09 11:04:21 --> Total execution time: 1.1112
INFO - 2016-03-09 08:04:55 --> Config Class Initialized
INFO - 2016-03-09 08:04:55 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:04:55 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:04:55 --> Utf8 Class Initialized
INFO - 2016-03-09 08:04:55 --> URI Class Initialized
INFO - 2016-03-09 08:04:55 --> Router Class Initialized
INFO - 2016-03-09 08:04:55 --> Output Class Initialized
INFO - 2016-03-09 08:04:55 --> Security Class Initialized
DEBUG - 2016-03-09 08:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:04:55 --> Input Class Initialized
INFO - 2016-03-09 08:04:55 --> Language Class Initialized
INFO - 2016-03-09 08:04:55 --> Loader Class Initialized
INFO - 2016-03-09 08:04:55 --> Helper loaded: url_helper
INFO - 2016-03-09 08:04:55 --> Helper loaded: file_helper
INFO - 2016-03-09 08:04:55 --> Helper loaded: date_helper
INFO - 2016-03-09 08:04:55 --> Helper loaded: form_helper
INFO - 2016-03-09 08:04:55 --> Database Driver Class Initialized
INFO - 2016-03-09 08:04:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:04:56 --> Controller Class Initialized
INFO - 2016-03-09 08:04:56 --> Model Class Initialized
INFO - 2016-03-09 08:04:56 --> Model Class Initialized
INFO - 2016-03-09 08:04:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:04:56 --> Pagination Class Initialized
INFO - 2016-03-09 08:04:56 --> Helper loaded: text_helper
INFO - 2016-03-09 08:04:56 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:04:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:04:56 --> Final output sent to browser
DEBUG - 2016-03-09 11:04:56 --> Total execution time: 1.2117
INFO - 2016-03-09 08:07:25 --> Config Class Initialized
INFO - 2016-03-09 08:07:25 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:07:25 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:07:25 --> Utf8 Class Initialized
INFO - 2016-03-09 08:07:25 --> URI Class Initialized
INFO - 2016-03-09 08:07:25 --> Router Class Initialized
INFO - 2016-03-09 08:07:25 --> Output Class Initialized
INFO - 2016-03-09 08:07:25 --> Security Class Initialized
DEBUG - 2016-03-09 08:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:07:25 --> Input Class Initialized
INFO - 2016-03-09 08:07:25 --> Language Class Initialized
INFO - 2016-03-09 08:07:25 --> Loader Class Initialized
INFO - 2016-03-09 08:07:25 --> Helper loaded: url_helper
INFO - 2016-03-09 08:07:25 --> Helper loaded: file_helper
INFO - 2016-03-09 08:07:25 --> Helper loaded: date_helper
INFO - 2016-03-09 08:07:25 --> Helper loaded: form_helper
INFO - 2016-03-09 08:07:25 --> Database Driver Class Initialized
INFO - 2016-03-09 08:07:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:07:26 --> Controller Class Initialized
INFO - 2016-03-09 08:07:26 --> Model Class Initialized
INFO - 2016-03-09 08:07:26 --> Model Class Initialized
INFO - 2016-03-09 08:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:07:26 --> Pagination Class Initialized
INFO - 2016-03-09 08:07:26 --> Helper loaded: text_helper
INFO - 2016-03-09 08:07:26 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:07:26 --> Final output sent to browser
DEBUG - 2016-03-09 11:07:26 --> Total execution time: 1.2211
INFO - 2016-03-09 08:07:49 --> Config Class Initialized
INFO - 2016-03-09 08:07:49 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:07:49 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:07:49 --> Utf8 Class Initialized
INFO - 2016-03-09 08:07:49 --> URI Class Initialized
INFO - 2016-03-09 08:07:49 --> Router Class Initialized
INFO - 2016-03-09 08:07:49 --> Output Class Initialized
INFO - 2016-03-09 08:07:49 --> Security Class Initialized
DEBUG - 2016-03-09 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:07:49 --> Input Class Initialized
INFO - 2016-03-09 08:07:49 --> Language Class Initialized
INFO - 2016-03-09 08:07:49 --> Loader Class Initialized
INFO - 2016-03-09 08:07:49 --> Helper loaded: url_helper
INFO - 2016-03-09 08:07:49 --> Helper loaded: file_helper
INFO - 2016-03-09 08:07:49 --> Helper loaded: date_helper
INFO - 2016-03-09 08:07:49 --> Helper loaded: form_helper
INFO - 2016-03-09 08:07:49 --> Database Driver Class Initialized
INFO - 2016-03-09 08:07:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:07:51 --> Controller Class Initialized
INFO - 2016-03-09 08:07:51 --> Model Class Initialized
INFO - 2016-03-09 08:07:51 --> Model Class Initialized
INFO - 2016-03-09 08:07:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:07:51 --> Pagination Class Initialized
INFO - 2016-03-09 08:07:51 --> Helper loaded: text_helper
INFO - 2016-03-09 08:07:51 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:07:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:07:51 --> Final output sent to browser
DEBUG - 2016-03-09 11:07:51 --> Total execution time: 1.1573
INFO - 2016-03-09 08:07:53 --> Config Class Initialized
INFO - 2016-03-09 08:07:53 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:07:53 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:07:53 --> Utf8 Class Initialized
INFO - 2016-03-09 08:07:53 --> URI Class Initialized
INFO - 2016-03-09 08:07:53 --> Router Class Initialized
INFO - 2016-03-09 08:07:53 --> Output Class Initialized
INFO - 2016-03-09 08:07:53 --> Security Class Initialized
DEBUG - 2016-03-09 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:07:53 --> Input Class Initialized
INFO - 2016-03-09 08:07:53 --> Language Class Initialized
INFO - 2016-03-09 08:07:53 --> Loader Class Initialized
INFO - 2016-03-09 08:07:53 --> Helper loaded: url_helper
INFO - 2016-03-09 08:07:53 --> Helper loaded: file_helper
INFO - 2016-03-09 08:07:53 --> Helper loaded: date_helper
INFO - 2016-03-09 08:07:53 --> Helper loaded: form_helper
INFO - 2016-03-09 08:07:53 --> Database Driver Class Initialized
INFO - 2016-03-09 08:07:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:07:54 --> Controller Class Initialized
INFO - 2016-03-09 08:07:54 --> Model Class Initialized
INFO - 2016-03-09 08:07:54 --> Model Class Initialized
INFO - 2016-03-09 08:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:07:54 --> Pagination Class Initialized
INFO - 2016-03-09 08:07:54 --> Helper loaded: text_helper
INFO - 2016-03-09 08:07:54 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:07:54 --> Final output sent to browser
DEBUG - 2016-03-09 11:07:54 --> Total execution time: 1.1532
INFO - 2016-03-09 08:07:57 --> Config Class Initialized
INFO - 2016-03-09 08:07:57 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:07:57 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:07:57 --> Utf8 Class Initialized
INFO - 2016-03-09 08:07:57 --> URI Class Initialized
INFO - 2016-03-09 08:07:57 --> Router Class Initialized
INFO - 2016-03-09 08:07:57 --> Output Class Initialized
INFO - 2016-03-09 08:07:57 --> Security Class Initialized
DEBUG - 2016-03-09 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:07:57 --> Input Class Initialized
INFO - 2016-03-09 08:07:57 --> Language Class Initialized
INFO - 2016-03-09 08:07:57 --> Loader Class Initialized
INFO - 2016-03-09 08:07:57 --> Helper loaded: url_helper
INFO - 2016-03-09 08:07:57 --> Helper loaded: file_helper
INFO - 2016-03-09 08:07:57 --> Helper loaded: date_helper
INFO - 2016-03-09 08:07:57 --> Helper loaded: form_helper
INFO - 2016-03-09 08:07:57 --> Database Driver Class Initialized
INFO - 2016-03-09 08:07:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:07:58 --> Controller Class Initialized
INFO - 2016-03-09 08:07:58 --> Model Class Initialized
INFO - 2016-03-09 08:07:58 --> Model Class Initialized
INFO - 2016-03-09 08:07:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:07:58 --> Pagination Class Initialized
INFO - 2016-03-09 08:07:58 --> Helper loaded: text_helper
INFO - 2016-03-09 08:07:58 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:07:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:07:58 --> Final output sent to browser
DEBUG - 2016-03-09 11:07:58 --> Total execution time: 1.1654
INFO - 2016-03-09 08:08:07 --> Config Class Initialized
INFO - 2016-03-09 08:08:07 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:08:07 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:08:07 --> Utf8 Class Initialized
INFO - 2016-03-09 08:08:07 --> URI Class Initialized
INFO - 2016-03-09 08:08:07 --> Router Class Initialized
INFO - 2016-03-09 08:08:07 --> Output Class Initialized
INFO - 2016-03-09 08:08:07 --> Security Class Initialized
DEBUG - 2016-03-09 08:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:08:07 --> Input Class Initialized
INFO - 2016-03-09 08:08:07 --> Language Class Initialized
INFO - 2016-03-09 08:08:07 --> Loader Class Initialized
INFO - 2016-03-09 08:08:07 --> Helper loaded: url_helper
INFO - 2016-03-09 08:08:07 --> Helper loaded: file_helper
INFO - 2016-03-09 08:08:07 --> Helper loaded: date_helper
INFO - 2016-03-09 08:08:07 --> Helper loaded: form_helper
INFO - 2016-03-09 08:08:07 --> Database Driver Class Initialized
INFO - 2016-03-09 08:08:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:08:08 --> Controller Class Initialized
INFO - 2016-03-09 08:08:08 --> Model Class Initialized
INFO - 2016-03-09 08:08:08 --> Model Class Initialized
INFO - 2016-03-09 08:08:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:08:08 --> Pagination Class Initialized
INFO - 2016-03-09 08:08:08 --> Helper loaded: text_helper
INFO - 2016-03-09 08:08:08 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:08:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:08:08 --> Final output sent to browser
DEBUG - 2016-03-09 11:08:08 --> Total execution time: 1.1271
INFO - 2016-03-09 08:08:10 --> Config Class Initialized
INFO - 2016-03-09 08:08:10 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:08:10 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:08:10 --> Utf8 Class Initialized
INFO - 2016-03-09 08:08:10 --> URI Class Initialized
INFO - 2016-03-09 08:08:10 --> Router Class Initialized
INFO - 2016-03-09 08:08:10 --> Output Class Initialized
INFO - 2016-03-09 08:08:10 --> Security Class Initialized
DEBUG - 2016-03-09 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:08:10 --> Input Class Initialized
INFO - 2016-03-09 08:08:10 --> Language Class Initialized
INFO - 2016-03-09 08:08:10 --> Loader Class Initialized
INFO - 2016-03-09 08:08:10 --> Helper loaded: url_helper
INFO - 2016-03-09 08:08:10 --> Helper loaded: file_helper
INFO - 2016-03-09 08:08:10 --> Helper loaded: date_helper
INFO - 2016-03-09 08:08:10 --> Helper loaded: form_helper
INFO - 2016-03-09 08:08:10 --> Database Driver Class Initialized
INFO - 2016-03-09 08:08:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:08:11 --> Controller Class Initialized
INFO - 2016-03-09 08:08:11 --> Model Class Initialized
INFO - 2016-03-09 08:08:11 --> Model Class Initialized
INFO - 2016-03-09 08:08:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:08:11 --> Pagination Class Initialized
INFO - 2016-03-09 08:08:11 --> Helper loaded: text_helper
INFO - 2016-03-09 08:08:11 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:08:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:08:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:08:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:08:12 --> Final output sent to browser
DEBUG - 2016-03-09 11:08:12 --> Total execution time: 1.1958
INFO - 2016-03-09 08:08:29 --> Config Class Initialized
INFO - 2016-03-09 08:08:29 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:08:29 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:08:29 --> Utf8 Class Initialized
INFO - 2016-03-09 08:08:29 --> URI Class Initialized
INFO - 2016-03-09 08:08:29 --> Router Class Initialized
INFO - 2016-03-09 08:08:29 --> Output Class Initialized
INFO - 2016-03-09 08:08:29 --> Security Class Initialized
DEBUG - 2016-03-09 08:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:08:29 --> Input Class Initialized
INFO - 2016-03-09 08:08:29 --> Language Class Initialized
INFO - 2016-03-09 08:08:29 --> Loader Class Initialized
INFO - 2016-03-09 08:08:29 --> Helper loaded: url_helper
INFO - 2016-03-09 08:08:29 --> Helper loaded: file_helper
INFO - 2016-03-09 08:08:29 --> Helper loaded: date_helper
INFO - 2016-03-09 08:08:29 --> Helper loaded: form_helper
INFO - 2016-03-09 08:08:29 --> Database Driver Class Initialized
INFO - 2016-03-09 08:08:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:08:30 --> Controller Class Initialized
INFO - 2016-03-09 08:08:30 --> Model Class Initialized
INFO - 2016-03-09 08:08:30 --> Model Class Initialized
INFO - 2016-03-09 08:08:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:08:30 --> Pagination Class Initialized
INFO - 2016-03-09 08:08:30 --> Helper loaded: text_helper
INFO - 2016-03-09 08:08:30 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:08:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:08:30 --> Final output sent to browser
DEBUG - 2016-03-09 11:08:30 --> Total execution time: 1.1528
INFO - 2016-03-09 08:08:45 --> Config Class Initialized
INFO - 2016-03-09 08:08:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:08:45 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:08:45 --> Utf8 Class Initialized
INFO - 2016-03-09 08:08:45 --> URI Class Initialized
INFO - 2016-03-09 08:08:45 --> Router Class Initialized
INFO - 2016-03-09 08:08:45 --> Output Class Initialized
INFO - 2016-03-09 08:08:45 --> Security Class Initialized
DEBUG - 2016-03-09 08:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:08:45 --> Input Class Initialized
INFO - 2016-03-09 08:08:45 --> Language Class Initialized
INFO - 2016-03-09 08:08:45 --> Loader Class Initialized
INFO - 2016-03-09 08:08:45 --> Helper loaded: url_helper
INFO - 2016-03-09 08:08:45 --> Helper loaded: file_helper
INFO - 2016-03-09 08:08:45 --> Helper loaded: date_helper
INFO - 2016-03-09 08:08:45 --> Helper loaded: form_helper
INFO - 2016-03-09 08:08:45 --> Database Driver Class Initialized
INFO - 2016-03-09 08:08:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:08:46 --> Controller Class Initialized
INFO - 2016-03-09 08:08:46 --> Model Class Initialized
INFO - 2016-03-09 08:08:46 --> Model Class Initialized
INFO - 2016-03-09 08:08:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:08:46 --> Pagination Class Initialized
INFO - 2016-03-09 08:08:46 --> Helper loaded: text_helper
INFO - 2016-03-09 08:08:46 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:08:46 --> Final output sent to browser
DEBUG - 2016-03-09 11:08:46 --> Total execution time: 1.1645
INFO - 2016-03-09 08:08:54 --> Config Class Initialized
INFO - 2016-03-09 08:08:54 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:08:54 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:08:54 --> Utf8 Class Initialized
INFO - 2016-03-09 08:08:54 --> URI Class Initialized
INFO - 2016-03-09 08:08:54 --> Router Class Initialized
INFO - 2016-03-09 08:08:54 --> Output Class Initialized
INFO - 2016-03-09 08:08:54 --> Security Class Initialized
DEBUG - 2016-03-09 08:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:08:54 --> Input Class Initialized
INFO - 2016-03-09 08:08:54 --> Language Class Initialized
INFO - 2016-03-09 08:08:54 --> Loader Class Initialized
INFO - 2016-03-09 08:08:54 --> Helper loaded: url_helper
INFO - 2016-03-09 08:08:54 --> Helper loaded: file_helper
INFO - 2016-03-09 08:08:54 --> Helper loaded: date_helper
INFO - 2016-03-09 08:08:54 --> Helper loaded: form_helper
INFO - 2016-03-09 08:08:54 --> Database Driver Class Initialized
INFO - 2016-03-09 08:08:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:08:55 --> Controller Class Initialized
INFO - 2016-03-09 08:08:55 --> Model Class Initialized
INFO - 2016-03-09 08:08:55 --> Model Class Initialized
INFO - 2016-03-09 08:08:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:08:55 --> Pagination Class Initialized
INFO - 2016-03-09 08:08:55 --> Helper loaded: text_helper
INFO - 2016-03-09 08:08:55 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:08:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:08:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:08:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:08:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:08:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:08:55 --> Final output sent to browser
DEBUG - 2016-03-09 11:08:55 --> Total execution time: 1.1632
INFO - 2016-03-09 08:09:43 --> Config Class Initialized
INFO - 2016-03-09 08:09:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:09:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:09:43 --> Utf8 Class Initialized
INFO - 2016-03-09 08:09:43 --> URI Class Initialized
INFO - 2016-03-09 08:09:43 --> Router Class Initialized
INFO - 2016-03-09 08:09:43 --> Output Class Initialized
INFO - 2016-03-09 08:09:43 --> Security Class Initialized
DEBUG - 2016-03-09 08:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:09:43 --> Input Class Initialized
INFO - 2016-03-09 08:09:43 --> Language Class Initialized
INFO - 2016-03-09 08:09:43 --> Loader Class Initialized
INFO - 2016-03-09 08:09:43 --> Helper loaded: url_helper
INFO - 2016-03-09 08:09:43 --> Helper loaded: file_helper
INFO - 2016-03-09 08:09:43 --> Helper loaded: date_helper
INFO - 2016-03-09 08:09:43 --> Helper loaded: form_helper
INFO - 2016-03-09 08:09:43 --> Database Driver Class Initialized
INFO - 2016-03-09 08:09:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:09:44 --> Controller Class Initialized
INFO - 2016-03-09 08:09:44 --> Model Class Initialized
INFO - 2016-03-09 08:09:44 --> Model Class Initialized
INFO - 2016-03-09 08:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:09:44 --> Pagination Class Initialized
INFO - 2016-03-09 08:09:44 --> Helper loaded: text_helper
INFO - 2016-03-09 08:09:44 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:09:44 --> Final output sent to browser
DEBUG - 2016-03-09 11:09:44 --> Total execution time: 1.2098
INFO - 2016-03-09 08:09:52 --> Config Class Initialized
INFO - 2016-03-09 08:09:52 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:09:52 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:09:52 --> Utf8 Class Initialized
INFO - 2016-03-09 08:09:52 --> URI Class Initialized
INFO - 2016-03-09 08:09:52 --> Router Class Initialized
INFO - 2016-03-09 08:09:52 --> Output Class Initialized
INFO - 2016-03-09 08:09:52 --> Security Class Initialized
DEBUG - 2016-03-09 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:09:52 --> Input Class Initialized
INFO - 2016-03-09 08:09:52 --> Language Class Initialized
INFO - 2016-03-09 08:09:52 --> Loader Class Initialized
INFO - 2016-03-09 08:09:52 --> Helper loaded: url_helper
INFO - 2016-03-09 08:09:52 --> Helper loaded: file_helper
INFO - 2016-03-09 08:09:52 --> Helper loaded: date_helper
INFO - 2016-03-09 08:09:52 --> Helper loaded: form_helper
INFO - 2016-03-09 08:09:52 --> Database Driver Class Initialized
INFO - 2016-03-09 08:09:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:09:53 --> Controller Class Initialized
INFO - 2016-03-09 08:09:53 --> Model Class Initialized
INFO - 2016-03-09 08:09:53 --> Model Class Initialized
INFO - 2016-03-09 08:09:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:09:53 --> Pagination Class Initialized
INFO - 2016-03-09 08:09:53 --> Helper loaded: text_helper
INFO - 2016-03-09 08:09:53 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:09:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:09:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:09:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:09:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:09:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:09:54 --> Final output sent to browser
DEBUG - 2016-03-09 11:09:54 --> Total execution time: 1.2130
INFO - 2016-03-09 08:10:04 --> Config Class Initialized
INFO - 2016-03-09 08:10:04 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:10:04 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:10:04 --> Utf8 Class Initialized
INFO - 2016-03-09 08:10:04 --> URI Class Initialized
INFO - 2016-03-09 08:10:04 --> Router Class Initialized
INFO - 2016-03-09 08:10:04 --> Output Class Initialized
INFO - 2016-03-09 08:10:04 --> Security Class Initialized
DEBUG - 2016-03-09 08:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:10:04 --> Input Class Initialized
INFO - 2016-03-09 08:10:04 --> Language Class Initialized
INFO - 2016-03-09 08:10:04 --> Loader Class Initialized
INFO - 2016-03-09 08:10:04 --> Helper loaded: url_helper
INFO - 2016-03-09 08:10:04 --> Helper loaded: file_helper
INFO - 2016-03-09 08:10:04 --> Helper loaded: date_helper
INFO - 2016-03-09 08:10:04 --> Helper loaded: form_helper
INFO - 2016-03-09 08:10:04 --> Database Driver Class Initialized
INFO - 2016-03-09 08:10:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:10:05 --> Controller Class Initialized
INFO - 2016-03-09 08:10:05 --> Model Class Initialized
INFO - 2016-03-09 08:10:05 --> Model Class Initialized
INFO - 2016-03-09 08:10:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:10:05 --> Pagination Class Initialized
INFO - 2016-03-09 08:10:05 --> Helper loaded: text_helper
INFO - 2016-03-09 08:10:05 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:10:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:10:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:10:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:10:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:10:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:10:05 --> Final output sent to browser
DEBUG - 2016-03-09 11:10:05 --> Total execution time: 1.1080
INFO - 2016-03-09 08:10:15 --> Config Class Initialized
INFO - 2016-03-09 08:10:15 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:10:15 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:10:15 --> Utf8 Class Initialized
INFO - 2016-03-09 08:10:15 --> URI Class Initialized
INFO - 2016-03-09 08:10:15 --> Router Class Initialized
INFO - 2016-03-09 08:10:15 --> Output Class Initialized
INFO - 2016-03-09 08:10:15 --> Security Class Initialized
DEBUG - 2016-03-09 08:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:10:15 --> Input Class Initialized
INFO - 2016-03-09 08:10:15 --> Language Class Initialized
INFO - 2016-03-09 08:10:15 --> Loader Class Initialized
INFO - 2016-03-09 08:10:15 --> Helper loaded: url_helper
INFO - 2016-03-09 08:10:15 --> Helper loaded: file_helper
INFO - 2016-03-09 08:10:15 --> Helper loaded: date_helper
INFO - 2016-03-09 08:10:15 --> Helper loaded: form_helper
INFO - 2016-03-09 08:10:15 --> Database Driver Class Initialized
INFO - 2016-03-09 08:10:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:10:16 --> Controller Class Initialized
INFO - 2016-03-09 08:10:16 --> Model Class Initialized
INFO - 2016-03-09 08:10:16 --> Model Class Initialized
INFO - 2016-03-09 08:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:10:16 --> Pagination Class Initialized
INFO - 2016-03-09 08:10:16 --> Helper loaded: text_helper
INFO - 2016-03-09 08:10:16 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:10:16 --> Final output sent to browser
DEBUG - 2016-03-09 11:10:16 --> Total execution time: 1.1487
INFO - 2016-03-09 08:10:34 --> Config Class Initialized
INFO - 2016-03-09 08:10:34 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:10:34 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:10:34 --> Utf8 Class Initialized
INFO - 2016-03-09 08:10:34 --> URI Class Initialized
INFO - 2016-03-09 08:10:34 --> Router Class Initialized
INFO - 2016-03-09 08:10:34 --> Output Class Initialized
INFO - 2016-03-09 08:10:34 --> Security Class Initialized
DEBUG - 2016-03-09 08:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:10:34 --> Input Class Initialized
INFO - 2016-03-09 08:10:34 --> Language Class Initialized
INFO - 2016-03-09 08:10:34 --> Loader Class Initialized
INFO - 2016-03-09 08:10:34 --> Helper loaded: url_helper
INFO - 2016-03-09 08:10:34 --> Helper loaded: file_helper
INFO - 2016-03-09 08:10:34 --> Helper loaded: date_helper
INFO - 2016-03-09 08:10:34 --> Helper loaded: form_helper
INFO - 2016-03-09 08:10:34 --> Database Driver Class Initialized
INFO - 2016-03-09 08:10:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:10:35 --> Controller Class Initialized
INFO - 2016-03-09 08:10:35 --> Model Class Initialized
INFO - 2016-03-09 08:10:35 --> Model Class Initialized
INFO - 2016-03-09 08:10:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:10:35 --> Pagination Class Initialized
INFO - 2016-03-09 08:10:35 --> Helper loaded: text_helper
INFO - 2016-03-09 08:10:35 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:10:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:10:35 --> Final output sent to browser
DEBUG - 2016-03-09 11:10:35 --> Total execution time: 1.1429
INFO - 2016-03-09 08:11:16 --> Config Class Initialized
INFO - 2016-03-09 08:11:16 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:11:16 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:11:16 --> Utf8 Class Initialized
INFO - 2016-03-09 08:11:16 --> URI Class Initialized
INFO - 2016-03-09 08:11:16 --> Router Class Initialized
INFO - 2016-03-09 08:11:16 --> Output Class Initialized
INFO - 2016-03-09 08:11:16 --> Security Class Initialized
DEBUG - 2016-03-09 08:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:11:16 --> Input Class Initialized
INFO - 2016-03-09 08:11:16 --> Language Class Initialized
INFO - 2016-03-09 08:11:16 --> Loader Class Initialized
INFO - 2016-03-09 08:11:16 --> Helper loaded: url_helper
INFO - 2016-03-09 08:11:16 --> Helper loaded: file_helper
INFO - 2016-03-09 08:11:16 --> Helper loaded: date_helper
INFO - 2016-03-09 08:11:16 --> Helper loaded: form_helper
INFO - 2016-03-09 08:11:16 --> Database Driver Class Initialized
INFO - 2016-03-09 08:11:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:11:17 --> Controller Class Initialized
INFO - 2016-03-09 08:11:17 --> Model Class Initialized
INFO - 2016-03-09 08:11:17 --> Model Class Initialized
INFO - 2016-03-09 08:11:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:11:17 --> Pagination Class Initialized
INFO - 2016-03-09 08:11:17 --> Helper loaded: text_helper
INFO - 2016-03-09 08:11:17 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:11:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:11:17 --> Final output sent to browser
DEBUG - 2016-03-09 11:11:17 --> Total execution time: 1.2259
INFO - 2016-03-09 08:11:35 --> Config Class Initialized
INFO - 2016-03-09 08:11:35 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:11:35 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:11:35 --> Utf8 Class Initialized
INFO - 2016-03-09 08:11:35 --> URI Class Initialized
INFO - 2016-03-09 08:11:35 --> Router Class Initialized
INFO - 2016-03-09 08:11:35 --> Output Class Initialized
INFO - 2016-03-09 08:11:35 --> Security Class Initialized
DEBUG - 2016-03-09 08:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:11:35 --> Input Class Initialized
INFO - 2016-03-09 08:11:35 --> Language Class Initialized
INFO - 2016-03-09 08:11:35 --> Loader Class Initialized
INFO - 2016-03-09 08:11:35 --> Helper loaded: url_helper
INFO - 2016-03-09 08:11:35 --> Helper loaded: file_helper
INFO - 2016-03-09 08:11:35 --> Helper loaded: date_helper
INFO - 2016-03-09 08:11:35 --> Helper loaded: form_helper
INFO - 2016-03-09 08:11:35 --> Database Driver Class Initialized
INFO - 2016-03-09 08:11:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:11:36 --> Controller Class Initialized
INFO - 2016-03-09 08:11:36 --> Model Class Initialized
INFO - 2016-03-09 08:11:36 --> Model Class Initialized
INFO - 2016-03-09 08:11:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:11:36 --> Pagination Class Initialized
INFO - 2016-03-09 08:11:36 --> Helper loaded: text_helper
INFO - 2016-03-09 08:11:36 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:11:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:11:36 --> Final output sent to browser
DEBUG - 2016-03-09 11:11:36 --> Total execution time: 1.1567
INFO - 2016-03-09 08:12:14 --> Config Class Initialized
INFO - 2016-03-09 08:12:14 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:12:14 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:12:14 --> Utf8 Class Initialized
INFO - 2016-03-09 08:12:14 --> URI Class Initialized
INFO - 2016-03-09 08:12:14 --> Router Class Initialized
INFO - 2016-03-09 08:12:14 --> Output Class Initialized
INFO - 2016-03-09 08:12:14 --> Security Class Initialized
DEBUG - 2016-03-09 08:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:12:14 --> Input Class Initialized
INFO - 2016-03-09 08:12:14 --> Language Class Initialized
INFO - 2016-03-09 08:12:14 --> Loader Class Initialized
INFO - 2016-03-09 08:12:14 --> Helper loaded: url_helper
INFO - 2016-03-09 08:12:14 --> Helper loaded: file_helper
INFO - 2016-03-09 08:12:14 --> Helper loaded: date_helper
INFO - 2016-03-09 08:12:14 --> Helper loaded: form_helper
INFO - 2016-03-09 08:12:14 --> Database Driver Class Initialized
INFO - 2016-03-09 08:12:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:12:15 --> Controller Class Initialized
INFO - 2016-03-09 08:12:15 --> Model Class Initialized
INFO - 2016-03-09 08:12:15 --> Model Class Initialized
INFO - 2016-03-09 08:12:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:12:15 --> Pagination Class Initialized
INFO - 2016-03-09 08:12:15 --> Helper loaded: text_helper
INFO - 2016-03-09 08:12:15 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:12:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:12:15 --> Final output sent to browser
DEBUG - 2016-03-09 11:12:15 --> Total execution time: 1.1527
INFO - 2016-03-09 08:12:18 --> Config Class Initialized
INFO - 2016-03-09 08:12:18 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:12:18 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:12:18 --> Utf8 Class Initialized
INFO - 2016-03-09 08:12:18 --> URI Class Initialized
INFO - 2016-03-09 08:12:18 --> Router Class Initialized
INFO - 2016-03-09 08:12:18 --> Output Class Initialized
INFO - 2016-03-09 08:12:18 --> Security Class Initialized
DEBUG - 2016-03-09 08:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:12:18 --> Input Class Initialized
INFO - 2016-03-09 08:12:18 --> Language Class Initialized
INFO - 2016-03-09 08:12:18 --> Loader Class Initialized
INFO - 2016-03-09 08:12:18 --> Helper loaded: url_helper
INFO - 2016-03-09 08:12:18 --> Helper loaded: file_helper
INFO - 2016-03-09 08:12:18 --> Helper loaded: date_helper
INFO - 2016-03-09 08:12:18 --> Helper loaded: form_helper
INFO - 2016-03-09 08:12:18 --> Database Driver Class Initialized
INFO - 2016-03-09 08:12:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:12:19 --> Controller Class Initialized
INFO - 2016-03-09 08:12:19 --> Model Class Initialized
INFO - 2016-03-09 08:12:19 --> Model Class Initialized
INFO - 2016-03-09 08:12:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:12:19 --> Pagination Class Initialized
INFO - 2016-03-09 08:12:19 --> Helper loaded: text_helper
INFO - 2016-03-09 08:12:19 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:12:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:12:19 --> Final output sent to browser
DEBUG - 2016-03-09 11:12:19 --> Total execution time: 1.1676
INFO - 2016-03-09 08:12:31 --> Config Class Initialized
INFO - 2016-03-09 08:12:31 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:12:31 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:12:31 --> Utf8 Class Initialized
INFO - 2016-03-09 08:12:31 --> URI Class Initialized
INFO - 2016-03-09 08:12:31 --> Router Class Initialized
INFO - 2016-03-09 08:12:31 --> Output Class Initialized
INFO - 2016-03-09 08:12:31 --> Security Class Initialized
DEBUG - 2016-03-09 08:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:12:31 --> Input Class Initialized
INFO - 2016-03-09 08:12:31 --> Language Class Initialized
INFO - 2016-03-09 08:12:31 --> Loader Class Initialized
INFO - 2016-03-09 08:12:31 --> Helper loaded: url_helper
INFO - 2016-03-09 08:12:31 --> Helper loaded: file_helper
INFO - 2016-03-09 08:12:31 --> Helper loaded: date_helper
INFO - 2016-03-09 08:12:31 --> Helper loaded: form_helper
INFO - 2016-03-09 08:12:31 --> Database Driver Class Initialized
INFO - 2016-03-09 08:12:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:12:32 --> Controller Class Initialized
INFO - 2016-03-09 08:12:32 --> Model Class Initialized
INFO - 2016-03-09 08:12:32 --> Model Class Initialized
INFO - 2016-03-09 08:12:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:12:32 --> Pagination Class Initialized
INFO - 2016-03-09 08:12:32 --> Helper loaded: text_helper
INFO - 2016-03-09 08:12:32 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:12:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:12:32 --> Final output sent to browser
DEBUG - 2016-03-09 11:12:32 --> Total execution time: 1.1143
INFO - 2016-03-09 08:13:13 --> Config Class Initialized
INFO - 2016-03-09 08:13:13 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:13:13 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:13:13 --> Utf8 Class Initialized
INFO - 2016-03-09 08:13:13 --> URI Class Initialized
INFO - 2016-03-09 08:13:13 --> Router Class Initialized
INFO - 2016-03-09 08:13:13 --> Output Class Initialized
INFO - 2016-03-09 08:13:13 --> Security Class Initialized
DEBUG - 2016-03-09 08:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:13:13 --> Input Class Initialized
INFO - 2016-03-09 08:13:13 --> Language Class Initialized
INFO - 2016-03-09 08:13:13 --> Loader Class Initialized
INFO - 2016-03-09 08:13:13 --> Helper loaded: url_helper
INFO - 2016-03-09 08:13:13 --> Helper loaded: file_helper
INFO - 2016-03-09 08:13:13 --> Helper loaded: date_helper
INFO - 2016-03-09 08:13:13 --> Helper loaded: form_helper
INFO - 2016-03-09 08:13:13 --> Database Driver Class Initialized
INFO - 2016-03-09 08:13:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:13:14 --> Controller Class Initialized
INFO - 2016-03-09 08:13:14 --> Model Class Initialized
INFO - 2016-03-09 08:13:14 --> Model Class Initialized
INFO - 2016-03-09 08:13:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:13:14 --> Pagination Class Initialized
INFO - 2016-03-09 08:13:14 --> Helper loaded: text_helper
INFO - 2016-03-09 08:13:14 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:13:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:13:14 --> Final output sent to browser
DEBUG - 2016-03-09 11:13:14 --> Total execution time: 1.1631
INFO - 2016-03-09 08:13:17 --> Config Class Initialized
INFO - 2016-03-09 08:13:17 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:13:17 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:13:17 --> Utf8 Class Initialized
INFO - 2016-03-09 08:13:17 --> URI Class Initialized
INFO - 2016-03-09 08:13:17 --> Router Class Initialized
INFO - 2016-03-09 08:13:17 --> Output Class Initialized
INFO - 2016-03-09 08:13:17 --> Security Class Initialized
DEBUG - 2016-03-09 08:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:13:17 --> Input Class Initialized
INFO - 2016-03-09 08:13:17 --> Language Class Initialized
INFO - 2016-03-09 08:13:17 --> Loader Class Initialized
INFO - 2016-03-09 08:13:17 --> Helper loaded: url_helper
INFO - 2016-03-09 08:13:17 --> Helper loaded: file_helper
INFO - 2016-03-09 08:13:17 --> Helper loaded: date_helper
INFO - 2016-03-09 08:13:17 --> Helper loaded: form_helper
INFO - 2016-03-09 08:13:17 --> Database Driver Class Initialized
INFO - 2016-03-09 08:13:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:13:18 --> Controller Class Initialized
INFO - 2016-03-09 08:13:18 --> Model Class Initialized
INFO - 2016-03-09 08:13:18 --> Model Class Initialized
INFO - 2016-03-09 08:13:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:13:18 --> Pagination Class Initialized
INFO - 2016-03-09 08:13:18 --> Helper loaded: text_helper
INFO - 2016-03-09 08:13:18 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:13:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:13:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:13:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:13:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:13:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:13:18 --> Final output sent to browser
DEBUG - 2016-03-09 11:13:18 --> Total execution time: 1.1116
INFO - 2016-03-09 08:13:20 --> Config Class Initialized
INFO - 2016-03-09 08:13:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:13:20 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:13:20 --> Utf8 Class Initialized
INFO - 2016-03-09 08:13:20 --> URI Class Initialized
INFO - 2016-03-09 08:13:20 --> Router Class Initialized
INFO - 2016-03-09 08:13:20 --> Output Class Initialized
INFO - 2016-03-09 08:13:20 --> Security Class Initialized
DEBUG - 2016-03-09 08:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:13:20 --> Input Class Initialized
INFO - 2016-03-09 08:13:20 --> Language Class Initialized
INFO - 2016-03-09 08:13:20 --> Loader Class Initialized
INFO - 2016-03-09 08:13:20 --> Helper loaded: url_helper
INFO - 2016-03-09 08:13:20 --> Helper loaded: file_helper
INFO - 2016-03-09 08:13:20 --> Helper loaded: date_helper
INFO - 2016-03-09 08:13:20 --> Helper loaded: form_helper
INFO - 2016-03-09 08:13:20 --> Database Driver Class Initialized
INFO - 2016-03-09 08:13:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:13:21 --> Controller Class Initialized
INFO - 2016-03-09 08:13:21 --> Model Class Initialized
INFO - 2016-03-09 08:13:21 --> Model Class Initialized
INFO - 2016-03-09 08:13:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:13:21 --> Pagination Class Initialized
INFO - 2016-03-09 08:13:21 --> Helper loaded: text_helper
INFO - 2016-03-09 08:13:21 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:13:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:13:21 --> Final output sent to browser
DEBUG - 2016-03-09 11:13:21 --> Total execution time: 1.1456
INFO - 2016-03-09 08:13:22 --> Config Class Initialized
INFO - 2016-03-09 08:13:22 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:13:22 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:13:22 --> Utf8 Class Initialized
INFO - 2016-03-09 08:13:22 --> URI Class Initialized
INFO - 2016-03-09 08:13:22 --> Router Class Initialized
INFO - 2016-03-09 08:13:22 --> Output Class Initialized
INFO - 2016-03-09 08:13:22 --> Security Class Initialized
DEBUG - 2016-03-09 08:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:13:22 --> Input Class Initialized
INFO - 2016-03-09 08:13:22 --> Language Class Initialized
INFO - 2016-03-09 08:13:22 --> Loader Class Initialized
INFO - 2016-03-09 08:13:22 --> Helper loaded: url_helper
INFO - 2016-03-09 08:13:22 --> Helper loaded: file_helper
INFO - 2016-03-09 08:13:22 --> Helper loaded: date_helper
INFO - 2016-03-09 08:13:22 --> Helper loaded: form_helper
INFO - 2016-03-09 08:13:22 --> Database Driver Class Initialized
INFO - 2016-03-09 08:13:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:13:23 --> Controller Class Initialized
INFO - 2016-03-09 08:13:23 --> Model Class Initialized
INFO - 2016-03-09 08:13:23 --> Model Class Initialized
INFO - 2016-03-09 08:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:13:23 --> Pagination Class Initialized
INFO - 2016-03-09 08:13:23 --> Helper loaded: text_helper
INFO - 2016-03-09 08:13:23 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:13:23 --> Final output sent to browser
DEBUG - 2016-03-09 11:13:23 --> Total execution time: 1.1948
INFO - 2016-03-09 08:13:24 --> Config Class Initialized
INFO - 2016-03-09 08:13:24 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:13:24 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:13:24 --> Utf8 Class Initialized
INFO - 2016-03-09 08:13:24 --> URI Class Initialized
INFO - 2016-03-09 08:13:24 --> Router Class Initialized
INFO - 2016-03-09 08:13:24 --> Output Class Initialized
INFO - 2016-03-09 08:13:24 --> Security Class Initialized
DEBUG - 2016-03-09 08:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:13:24 --> Input Class Initialized
INFO - 2016-03-09 08:13:24 --> Language Class Initialized
INFO - 2016-03-09 08:13:24 --> Loader Class Initialized
INFO - 2016-03-09 08:13:24 --> Helper loaded: url_helper
INFO - 2016-03-09 08:13:24 --> Helper loaded: file_helper
INFO - 2016-03-09 08:13:24 --> Helper loaded: date_helper
INFO - 2016-03-09 08:13:24 --> Helper loaded: form_helper
INFO - 2016-03-09 08:13:24 --> Database Driver Class Initialized
INFO - 2016-03-09 08:13:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:13:25 --> Controller Class Initialized
INFO - 2016-03-09 08:13:25 --> Model Class Initialized
INFO - 2016-03-09 08:13:25 --> Model Class Initialized
INFO - 2016-03-09 08:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:13:25 --> Pagination Class Initialized
INFO - 2016-03-09 08:13:25 --> Helper loaded: text_helper
INFO - 2016-03-09 08:13:25 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:13:25 --> Final output sent to browser
DEBUG - 2016-03-09 11:13:25 --> Total execution time: 1.1840
INFO - 2016-03-09 08:13:33 --> Config Class Initialized
INFO - 2016-03-09 08:13:33 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:13:33 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:13:33 --> Utf8 Class Initialized
INFO - 2016-03-09 08:13:33 --> URI Class Initialized
INFO - 2016-03-09 08:13:33 --> Router Class Initialized
INFO - 2016-03-09 08:13:33 --> Output Class Initialized
INFO - 2016-03-09 08:13:33 --> Security Class Initialized
DEBUG - 2016-03-09 08:13:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:13:33 --> Input Class Initialized
INFO - 2016-03-09 08:13:33 --> Language Class Initialized
INFO - 2016-03-09 08:13:33 --> Loader Class Initialized
INFO - 2016-03-09 08:13:33 --> Helper loaded: url_helper
INFO - 2016-03-09 08:13:33 --> Helper loaded: file_helper
INFO - 2016-03-09 08:13:33 --> Helper loaded: date_helper
INFO - 2016-03-09 08:13:33 --> Helper loaded: form_helper
INFO - 2016-03-09 08:13:33 --> Database Driver Class Initialized
INFO - 2016-03-09 08:13:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:13:34 --> Controller Class Initialized
INFO - 2016-03-09 08:13:34 --> Model Class Initialized
INFO - 2016-03-09 08:13:34 --> Model Class Initialized
INFO - 2016-03-09 08:13:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:13:34 --> Pagination Class Initialized
INFO - 2016-03-09 08:13:34 --> Helper loaded: text_helper
INFO - 2016-03-09 08:13:34 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:13:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:13:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:13:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:13:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:13:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:13:34 --> Final output sent to browser
DEBUG - 2016-03-09 11:13:34 --> Total execution time: 1.1332
INFO - 2016-03-09 08:13:51 --> Config Class Initialized
INFO - 2016-03-09 08:13:51 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:13:51 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:13:51 --> Utf8 Class Initialized
INFO - 2016-03-09 08:13:51 --> URI Class Initialized
INFO - 2016-03-09 08:13:51 --> Router Class Initialized
INFO - 2016-03-09 08:13:51 --> Output Class Initialized
INFO - 2016-03-09 08:13:51 --> Security Class Initialized
DEBUG - 2016-03-09 08:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:13:51 --> Input Class Initialized
INFO - 2016-03-09 08:13:51 --> Language Class Initialized
INFO - 2016-03-09 08:13:51 --> Loader Class Initialized
INFO - 2016-03-09 08:13:51 --> Helper loaded: url_helper
INFO - 2016-03-09 08:13:51 --> Helper loaded: file_helper
INFO - 2016-03-09 08:13:51 --> Helper loaded: date_helper
INFO - 2016-03-09 08:13:51 --> Helper loaded: form_helper
INFO - 2016-03-09 08:13:51 --> Database Driver Class Initialized
INFO - 2016-03-09 08:13:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:13:52 --> Controller Class Initialized
INFO - 2016-03-09 08:13:52 --> Model Class Initialized
INFO - 2016-03-09 08:13:52 --> Model Class Initialized
INFO - 2016-03-09 08:13:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:13:52 --> Pagination Class Initialized
INFO - 2016-03-09 08:13:52 --> Helper loaded: text_helper
INFO - 2016-03-09 08:13:52 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:13:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:13:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:13:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:13:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:13:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:13:52 --> Final output sent to browser
DEBUG - 2016-03-09 11:13:52 --> Total execution time: 1.1315
INFO - 2016-03-09 08:13:59 --> Config Class Initialized
INFO - 2016-03-09 08:13:59 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:13:59 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:13:59 --> Utf8 Class Initialized
INFO - 2016-03-09 08:13:59 --> URI Class Initialized
INFO - 2016-03-09 08:13:59 --> Router Class Initialized
INFO - 2016-03-09 08:13:59 --> Output Class Initialized
INFO - 2016-03-09 08:13:59 --> Security Class Initialized
DEBUG - 2016-03-09 08:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:13:59 --> Input Class Initialized
INFO - 2016-03-09 08:13:59 --> Language Class Initialized
INFO - 2016-03-09 08:13:59 --> Loader Class Initialized
INFO - 2016-03-09 08:13:59 --> Helper loaded: url_helper
INFO - 2016-03-09 08:13:59 --> Helper loaded: file_helper
INFO - 2016-03-09 08:13:59 --> Helper loaded: date_helper
INFO - 2016-03-09 08:13:59 --> Helper loaded: form_helper
INFO - 2016-03-09 08:13:59 --> Database Driver Class Initialized
INFO - 2016-03-09 08:14:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:14:00 --> Controller Class Initialized
INFO - 2016-03-09 08:14:00 --> Model Class Initialized
INFO - 2016-03-09 08:14:00 --> Model Class Initialized
INFO - 2016-03-09 08:14:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:14:00 --> Pagination Class Initialized
INFO - 2016-03-09 08:14:00 --> Helper loaded: text_helper
INFO - 2016-03-09 08:14:00 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:14:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:14:00 --> Final output sent to browser
DEBUG - 2016-03-09 11:14:00 --> Total execution time: 1.1224
INFO - 2016-03-09 08:14:02 --> Config Class Initialized
INFO - 2016-03-09 08:14:02 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:14:02 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:14:02 --> Utf8 Class Initialized
INFO - 2016-03-09 08:14:02 --> URI Class Initialized
INFO - 2016-03-09 08:14:02 --> Router Class Initialized
INFO - 2016-03-09 08:14:02 --> Output Class Initialized
INFO - 2016-03-09 08:14:02 --> Security Class Initialized
DEBUG - 2016-03-09 08:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:14:02 --> Input Class Initialized
INFO - 2016-03-09 08:14:02 --> Language Class Initialized
INFO - 2016-03-09 08:14:02 --> Loader Class Initialized
INFO - 2016-03-09 08:14:02 --> Helper loaded: url_helper
INFO - 2016-03-09 08:14:02 --> Helper loaded: file_helper
INFO - 2016-03-09 08:14:02 --> Helper loaded: date_helper
INFO - 2016-03-09 08:14:02 --> Helper loaded: form_helper
INFO - 2016-03-09 08:14:02 --> Database Driver Class Initialized
INFO - 2016-03-09 08:14:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:14:03 --> Controller Class Initialized
INFO - 2016-03-09 08:14:03 --> Model Class Initialized
INFO - 2016-03-09 08:14:03 --> Model Class Initialized
INFO - 2016-03-09 08:14:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:14:03 --> Pagination Class Initialized
INFO - 2016-03-09 08:14:03 --> Helper loaded: text_helper
INFO - 2016-03-09 08:14:03 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:14:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:14:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:14:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:14:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:14:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:14:03 --> Final output sent to browser
DEBUG - 2016-03-09 11:14:03 --> Total execution time: 1.1252
INFO - 2016-03-09 08:14:13 --> Config Class Initialized
INFO - 2016-03-09 08:14:13 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:14:13 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:14:13 --> Utf8 Class Initialized
INFO - 2016-03-09 08:14:13 --> URI Class Initialized
INFO - 2016-03-09 08:14:13 --> Router Class Initialized
INFO - 2016-03-09 08:14:13 --> Output Class Initialized
INFO - 2016-03-09 08:14:13 --> Security Class Initialized
DEBUG - 2016-03-09 08:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:14:13 --> Input Class Initialized
INFO - 2016-03-09 08:14:13 --> Language Class Initialized
INFO - 2016-03-09 08:14:13 --> Loader Class Initialized
INFO - 2016-03-09 08:14:13 --> Helper loaded: url_helper
INFO - 2016-03-09 08:14:13 --> Helper loaded: file_helper
INFO - 2016-03-09 08:14:13 --> Helper loaded: date_helper
INFO - 2016-03-09 08:14:13 --> Helper loaded: form_helper
INFO - 2016-03-09 08:14:13 --> Database Driver Class Initialized
INFO - 2016-03-09 08:14:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:14:14 --> Controller Class Initialized
INFO - 2016-03-09 08:14:14 --> Model Class Initialized
INFO - 2016-03-09 08:14:14 --> Model Class Initialized
INFO - 2016-03-09 08:14:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:14:14 --> Pagination Class Initialized
INFO - 2016-03-09 08:14:14 --> Helper loaded: text_helper
INFO - 2016-03-09 08:14:14 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:14:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:14:14 --> Final output sent to browser
DEBUG - 2016-03-09 11:14:15 --> Total execution time: 1.0946
INFO - 2016-03-09 08:14:28 --> Config Class Initialized
INFO - 2016-03-09 08:14:28 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:14:28 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:14:28 --> Utf8 Class Initialized
INFO - 2016-03-09 08:14:28 --> URI Class Initialized
INFO - 2016-03-09 08:14:28 --> Router Class Initialized
INFO - 2016-03-09 08:14:28 --> Output Class Initialized
INFO - 2016-03-09 08:14:28 --> Security Class Initialized
DEBUG - 2016-03-09 08:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:14:28 --> Input Class Initialized
INFO - 2016-03-09 08:14:28 --> Language Class Initialized
INFO - 2016-03-09 08:14:28 --> Loader Class Initialized
INFO - 2016-03-09 08:14:28 --> Helper loaded: url_helper
INFO - 2016-03-09 08:14:28 --> Helper loaded: file_helper
INFO - 2016-03-09 08:14:28 --> Helper loaded: date_helper
INFO - 2016-03-09 08:14:28 --> Helper loaded: form_helper
INFO - 2016-03-09 08:14:28 --> Database Driver Class Initialized
INFO - 2016-03-09 08:14:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:14:29 --> Controller Class Initialized
INFO - 2016-03-09 08:14:29 --> Model Class Initialized
INFO - 2016-03-09 08:14:29 --> Model Class Initialized
INFO - 2016-03-09 08:14:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:14:29 --> Pagination Class Initialized
INFO - 2016-03-09 08:14:29 --> Helper loaded: text_helper
INFO - 2016-03-09 08:14:29 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:14:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:14:29 --> Final output sent to browser
DEBUG - 2016-03-09 11:14:29 --> Total execution time: 1.1504
INFO - 2016-03-09 08:14:40 --> Config Class Initialized
INFO - 2016-03-09 08:14:40 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:14:41 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:14:41 --> Utf8 Class Initialized
INFO - 2016-03-09 08:14:41 --> URI Class Initialized
INFO - 2016-03-09 08:14:41 --> Router Class Initialized
INFO - 2016-03-09 08:14:41 --> Output Class Initialized
INFO - 2016-03-09 08:14:41 --> Security Class Initialized
DEBUG - 2016-03-09 08:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:14:41 --> Input Class Initialized
INFO - 2016-03-09 08:14:41 --> Language Class Initialized
INFO - 2016-03-09 08:14:41 --> Loader Class Initialized
INFO - 2016-03-09 08:14:41 --> Helper loaded: url_helper
INFO - 2016-03-09 08:14:41 --> Helper loaded: file_helper
INFO - 2016-03-09 08:14:41 --> Helper loaded: date_helper
INFO - 2016-03-09 08:14:41 --> Helper loaded: form_helper
INFO - 2016-03-09 08:14:41 --> Database Driver Class Initialized
INFO - 2016-03-09 08:14:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:14:42 --> Controller Class Initialized
INFO - 2016-03-09 08:14:42 --> Model Class Initialized
INFO - 2016-03-09 08:14:42 --> Model Class Initialized
INFO - 2016-03-09 08:14:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:14:42 --> Pagination Class Initialized
INFO - 2016-03-09 08:14:42 --> Helper loaded: text_helper
INFO - 2016-03-09 08:14:42 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:14:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:14:42 --> Final output sent to browser
DEBUG - 2016-03-09 11:14:42 --> Total execution time: 1.1357
INFO - 2016-03-09 08:14:52 --> Config Class Initialized
INFO - 2016-03-09 08:14:52 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:14:52 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:14:52 --> Utf8 Class Initialized
INFO - 2016-03-09 08:14:52 --> URI Class Initialized
INFO - 2016-03-09 08:14:52 --> Router Class Initialized
INFO - 2016-03-09 08:14:52 --> Output Class Initialized
INFO - 2016-03-09 08:14:52 --> Security Class Initialized
DEBUG - 2016-03-09 08:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:14:52 --> Input Class Initialized
INFO - 2016-03-09 08:14:52 --> Language Class Initialized
INFO - 2016-03-09 08:14:52 --> Loader Class Initialized
INFO - 2016-03-09 08:14:52 --> Helper loaded: url_helper
INFO - 2016-03-09 08:14:52 --> Helper loaded: file_helper
INFO - 2016-03-09 08:14:52 --> Helper loaded: date_helper
INFO - 2016-03-09 08:14:52 --> Helper loaded: form_helper
INFO - 2016-03-09 08:14:52 --> Database Driver Class Initialized
INFO - 2016-03-09 08:14:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:14:53 --> Controller Class Initialized
INFO - 2016-03-09 08:14:53 --> Model Class Initialized
INFO - 2016-03-09 08:14:53 --> Model Class Initialized
INFO - 2016-03-09 08:14:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:14:53 --> Pagination Class Initialized
INFO - 2016-03-09 08:14:53 --> Helper loaded: text_helper
INFO - 2016-03-09 08:14:53 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:14:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:14:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:14:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:14:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:14:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:14:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:14:53 --> Final output sent to browser
DEBUG - 2016-03-09 11:14:53 --> Total execution time: 1.1580
INFO - 2016-03-09 08:15:03 --> Config Class Initialized
INFO - 2016-03-09 08:15:03 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:15:03 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:15:03 --> Utf8 Class Initialized
INFO - 2016-03-09 08:15:03 --> URI Class Initialized
INFO - 2016-03-09 08:15:03 --> Router Class Initialized
INFO - 2016-03-09 08:15:03 --> Output Class Initialized
INFO - 2016-03-09 08:15:03 --> Security Class Initialized
DEBUG - 2016-03-09 08:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:15:03 --> Input Class Initialized
INFO - 2016-03-09 08:15:03 --> Language Class Initialized
INFO - 2016-03-09 08:15:03 --> Loader Class Initialized
INFO - 2016-03-09 08:15:03 --> Helper loaded: url_helper
INFO - 2016-03-09 08:15:03 --> Helper loaded: file_helper
INFO - 2016-03-09 08:15:03 --> Helper loaded: date_helper
INFO - 2016-03-09 08:15:03 --> Helper loaded: form_helper
INFO - 2016-03-09 08:15:03 --> Database Driver Class Initialized
INFO - 2016-03-09 08:15:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:15:04 --> Controller Class Initialized
INFO - 2016-03-09 08:15:04 --> Model Class Initialized
INFO - 2016-03-09 08:15:04 --> Model Class Initialized
INFO - 2016-03-09 08:15:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:15:04 --> Pagination Class Initialized
INFO - 2016-03-09 08:15:04 --> Helper loaded: text_helper
INFO - 2016-03-09 08:15:04 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:15:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:15:04 --> Final output sent to browser
DEBUG - 2016-03-09 11:15:04 --> Total execution time: 1.1452
INFO - 2016-03-09 08:19:17 --> Config Class Initialized
INFO - 2016-03-09 08:19:17 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:17 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:17 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:17 --> URI Class Initialized
INFO - 2016-03-09 08:19:17 --> Router Class Initialized
INFO - 2016-03-09 08:19:17 --> Output Class Initialized
INFO - 2016-03-09 08:19:17 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:17 --> Input Class Initialized
INFO - 2016-03-09 08:19:17 --> Language Class Initialized
INFO - 2016-03-09 08:19:17 --> Loader Class Initialized
INFO - 2016-03-09 08:19:17 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:17 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:17 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:17 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:17 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:18 --> Controller Class Initialized
INFO - 2016-03-09 08:19:18 --> Model Class Initialized
INFO - 2016-03-09 08:19:18 --> Model Class Initialized
INFO - 2016-03-09 08:19:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:18 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:18 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:18 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:19:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:18 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:18 --> Total execution time: 1.1877
INFO - 2016-03-09 08:19:20 --> Config Class Initialized
INFO - 2016-03-09 08:19:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:20 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:20 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:20 --> URI Class Initialized
INFO - 2016-03-09 08:19:20 --> Router Class Initialized
INFO - 2016-03-09 08:19:20 --> Output Class Initialized
INFO - 2016-03-09 08:19:20 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:20 --> Input Class Initialized
INFO - 2016-03-09 08:19:20 --> Language Class Initialized
INFO - 2016-03-09 08:19:20 --> Loader Class Initialized
INFO - 2016-03-09 08:19:20 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:20 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:20 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:20 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:20 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:21 --> Controller Class Initialized
INFO - 2016-03-09 08:19:21 --> Model Class Initialized
INFO - 2016-03-09 08:19:21 --> Model Class Initialized
INFO - 2016-03-09 08:19:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:21 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:21 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:21 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:19:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:19:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:19:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:21 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:21 --> Total execution time: 1.2902
INFO - 2016-03-09 08:19:33 --> Config Class Initialized
INFO - 2016-03-09 08:19:33 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:33 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:33 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:33 --> URI Class Initialized
INFO - 2016-03-09 08:19:33 --> Router Class Initialized
INFO - 2016-03-09 08:19:33 --> Output Class Initialized
INFO - 2016-03-09 08:19:33 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:33 --> Input Class Initialized
INFO - 2016-03-09 08:19:33 --> Language Class Initialized
INFO - 2016-03-09 08:19:33 --> Loader Class Initialized
INFO - 2016-03-09 08:19:33 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:33 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:33 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:33 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:33 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:34 --> Controller Class Initialized
INFO - 2016-03-09 08:19:34 --> Model Class Initialized
INFO - 2016-03-09 08:19:34 --> Model Class Initialized
INFO - 2016-03-09 08:19:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:34 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:34 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:34 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:19:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:35 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:35 --> Total execution time: 1.2083
INFO - 2016-03-09 08:19:37 --> Config Class Initialized
INFO - 2016-03-09 08:19:37 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:37 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:37 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:37 --> URI Class Initialized
INFO - 2016-03-09 08:19:37 --> Router Class Initialized
INFO - 2016-03-09 08:19:37 --> Output Class Initialized
INFO - 2016-03-09 08:19:37 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:37 --> Input Class Initialized
INFO - 2016-03-09 08:19:37 --> Language Class Initialized
INFO - 2016-03-09 08:19:37 --> Loader Class Initialized
INFO - 2016-03-09 08:19:37 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:37 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:37 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:37 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:37 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:38 --> Controller Class Initialized
INFO - 2016-03-09 08:19:38 --> Model Class Initialized
INFO - 2016-03-09 08:19:38 --> Model Class Initialized
INFO - 2016-03-09 08:19:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:38 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:38 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:38 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:38 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:38 --> Total execution time: 1.1759
INFO - 2016-03-09 08:19:40 --> Config Class Initialized
INFO - 2016-03-09 08:19:40 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:40 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:40 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:40 --> URI Class Initialized
INFO - 2016-03-09 08:19:40 --> Router Class Initialized
INFO - 2016-03-09 08:19:40 --> Output Class Initialized
INFO - 2016-03-09 08:19:40 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:40 --> Input Class Initialized
INFO - 2016-03-09 08:19:40 --> Language Class Initialized
INFO - 2016-03-09 08:19:40 --> Loader Class Initialized
INFO - 2016-03-09 08:19:40 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:40 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:40 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:40 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:40 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:41 --> Controller Class Initialized
INFO - 2016-03-09 08:19:41 --> Model Class Initialized
INFO - 2016-03-09 08:19:41 --> Model Class Initialized
INFO - 2016-03-09 08:19:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:41 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:41 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:41 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:19:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:19:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:19:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:41 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:41 --> Total execution time: 1.2257
INFO - 2016-03-09 08:19:43 --> Config Class Initialized
INFO - 2016-03-09 08:19:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:43 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:43 --> URI Class Initialized
INFO - 2016-03-09 08:19:43 --> Router Class Initialized
INFO - 2016-03-09 08:19:43 --> Output Class Initialized
INFO - 2016-03-09 08:19:43 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:43 --> Input Class Initialized
INFO - 2016-03-09 08:19:43 --> Language Class Initialized
INFO - 2016-03-09 08:19:43 --> Loader Class Initialized
INFO - 2016-03-09 08:19:43 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:43 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:43 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:43 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:43 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:44 --> Controller Class Initialized
INFO - 2016-03-09 08:19:44 --> Model Class Initialized
INFO - 2016-03-09 08:19:44 --> Model Class Initialized
INFO - 2016-03-09 08:19:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:44 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:44 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:44 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:44 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:44 --> Total execution time: 1.1706
INFO - 2016-03-09 08:19:46 --> Config Class Initialized
INFO - 2016-03-09 08:19:46 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:46 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:46 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:46 --> URI Class Initialized
INFO - 2016-03-09 08:19:46 --> Router Class Initialized
INFO - 2016-03-09 08:19:46 --> Output Class Initialized
INFO - 2016-03-09 08:19:46 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:46 --> Input Class Initialized
INFO - 2016-03-09 08:19:46 --> Language Class Initialized
INFO - 2016-03-09 08:19:46 --> Loader Class Initialized
INFO - 2016-03-09 08:19:46 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:46 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:46 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:46 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:46 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:47 --> Controller Class Initialized
INFO - 2016-03-09 08:19:47 --> Model Class Initialized
INFO - 2016-03-09 08:19:47 --> Model Class Initialized
INFO - 2016-03-09 08:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:47 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:47 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:19:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:47 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:47 --> Total execution time: 1.1453
INFO - 2016-03-09 08:19:52 --> Config Class Initialized
INFO - 2016-03-09 08:19:52 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:52 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:52 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:52 --> URI Class Initialized
INFO - 2016-03-09 08:19:52 --> Router Class Initialized
INFO - 2016-03-09 08:19:52 --> Output Class Initialized
INFO - 2016-03-09 08:19:52 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:52 --> Input Class Initialized
INFO - 2016-03-09 08:19:52 --> Language Class Initialized
INFO - 2016-03-09 08:19:52 --> Loader Class Initialized
INFO - 2016-03-09 08:19:52 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:52 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:52 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:52 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:52 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:53 --> Controller Class Initialized
INFO - 2016-03-09 08:19:53 --> Model Class Initialized
INFO - 2016-03-09 08:19:53 --> Model Class Initialized
INFO - 2016-03-09 08:19:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:53 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:53 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:53 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:19:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:53 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:53 --> Total execution time: 1.1093
INFO - 2016-03-09 08:19:56 --> Config Class Initialized
INFO - 2016-03-09 08:19:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:19:56 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:19:56 --> Utf8 Class Initialized
INFO - 2016-03-09 08:19:56 --> URI Class Initialized
INFO - 2016-03-09 08:19:56 --> Router Class Initialized
INFO - 2016-03-09 08:19:56 --> Output Class Initialized
INFO - 2016-03-09 08:19:56 --> Security Class Initialized
DEBUG - 2016-03-09 08:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:19:56 --> Input Class Initialized
INFO - 2016-03-09 08:19:56 --> Language Class Initialized
INFO - 2016-03-09 08:19:56 --> Loader Class Initialized
INFO - 2016-03-09 08:19:56 --> Helper loaded: url_helper
INFO - 2016-03-09 08:19:56 --> Helper loaded: file_helper
INFO - 2016-03-09 08:19:56 --> Helper loaded: date_helper
INFO - 2016-03-09 08:19:56 --> Helper loaded: form_helper
INFO - 2016-03-09 08:19:56 --> Database Driver Class Initialized
INFO - 2016-03-09 08:19:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:19:57 --> Controller Class Initialized
INFO - 2016-03-09 08:19:57 --> Model Class Initialized
INFO - 2016-03-09 08:19:57 --> Model Class Initialized
INFO - 2016-03-09 08:19:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:19:57 --> Pagination Class Initialized
INFO - 2016-03-09 08:19:57 --> Helper loaded: text_helper
INFO - 2016-03-09 08:19:57 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:19:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:19:57 --> Final output sent to browser
DEBUG - 2016-03-09 11:19:57 --> Total execution time: 1.1980
INFO - 2016-03-09 08:21:45 --> Config Class Initialized
INFO - 2016-03-09 08:21:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:21:45 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:21:45 --> Utf8 Class Initialized
INFO - 2016-03-09 08:21:45 --> URI Class Initialized
INFO - 2016-03-09 08:21:45 --> Router Class Initialized
INFO - 2016-03-09 08:21:45 --> Output Class Initialized
INFO - 2016-03-09 08:21:45 --> Security Class Initialized
DEBUG - 2016-03-09 08:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:21:45 --> Input Class Initialized
INFO - 2016-03-09 08:21:45 --> Language Class Initialized
INFO - 2016-03-09 08:21:45 --> Loader Class Initialized
INFO - 2016-03-09 08:21:45 --> Helper loaded: url_helper
INFO - 2016-03-09 08:21:45 --> Helper loaded: file_helper
INFO - 2016-03-09 08:21:45 --> Helper loaded: date_helper
INFO - 2016-03-09 08:21:45 --> Helper loaded: form_helper
INFO - 2016-03-09 08:21:45 --> Database Driver Class Initialized
INFO - 2016-03-09 08:21:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:21:47 --> Controller Class Initialized
INFO - 2016-03-09 08:21:47 --> Model Class Initialized
INFO - 2016-03-09 08:21:47 --> Model Class Initialized
INFO - 2016-03-09 08:21:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:21:47 --> Pagination Class Initialized
INFO - 2016-03-09 08:21:47 --> Helper loaded: text_helper
INFO - 2016-03-09 08:21:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:21:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:21:47 --> Final output sent to browser
DEBUG - 2016-03-09 11:21:47 --> Total execution time: 1.1235
INFO - 2016-03-09 08:21:52 --> Config Class Initialized
INFO - 2016-03-09 08:21:52 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:21:52 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:21:52 --> Utf8 Class Initialized
INFO - 2016-03-09 08:21:52 --> URI Class Initialized
INFO - 2016-03-09 08:21:52 --> Router Class Initialized
INFO - 2016-03-09 08:21:52 --> Output Class Initialized
INFO - 2016-03-09 08:21:52 --> Security Class Initialized
DEBUG - 2016-03-09 08:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:21:52 --> Input Class Initialized
INFO - 2016-03-09 08:21:52 --> Language Class Initialized
INFO - 2016-03-09 08:21:52 --> Loader Class Initialized
INFO - 2016-03-09 08:21:52 --> Helper loaded: url_helper
INFO - 2016-03-09 08:21:52 --> Helper loaded: file_helper
INFO - 2016-03-09 08:21:52 --> Helper loaded: date_helper
INFO - 2016-03-09 08:21:52 --> Helper loaded: form_helper
INFO - 2016-03-09 08:21:52 --> Database Driver Class Initialized
INFO - 2016-03-09 08:21:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:21:53 --> Controller Class Initialized
INFO - 2016-03-09 08:21:53 --> Model Class Initialized
INFO - 2016-03-09 08:21:53 --> Model Class Initialized
INFO - 2016-03-09 08:21:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:21:53 --> Pagination Class Initialized
INFO - 2016-03-09 08:21:53 --> Helper loaded: text_helper
INFO - 2016-03-09 08:21:53 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:21:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:21:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:21:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:21:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:21:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:21:53 --> Final output sent to browser
DEBUG - 2016-03-09 11:21:53 --> Total execution time: 1.1506
INFO - 2016-03-09 08:22:00 --> Config Class Initialized
INFO - 2016-03-09 08:22:00 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:22:00 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:22:00 --> Utf8 Class Initialized
INFO - 2016-03-09 08:22:00 --> URI Class Initialized
INFO - 2016-03-09 08:22:00 --> Router Class Initialized
INFO - 2016-03-09 08:22:00 --> Output Class Initialized
INFO - 2016-03-09 08:22:00 --> Security Class Initialized
DEBUG - 2016-03-09 08:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:22:00 --> Input Class Initialized
INFO - 2016-03-09 08:22:00 --> Language Class Initialized
INFO - 2016-03-09 08:22:00 --> Loader Class Initialized
INFO - 2016-03-09 08:22:00 --> Helper loaded: url_helper
INFO - 2016-03-09 08:22:00 --> Helper loaded: file_helper
INFO - 2016-03-09 08:22:00 --> Helper loaded: date_helper
INFO - 2016-03-09 08:22:00 --> Helper loaded: form_helper
INFO - 2016-03-09 08:22:00 --> Database Driver Class Initialized
INFO - 2016-03-09 08:22:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:22:01 --> Controller Class Initialized
INFO - 2016-03-09 08:22:01 --> Model Class Initialized
INFO - 2016-03-09 08:22:01 --> Model Class Initialized
INFO - 2016-03-09 08:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:22:01 --> Pagination Class Initialized
INFO - 2016-03-09 08:22:01 --> Helper loaded: text_helper
INFO - 2016-03-09 08:22:01 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:22:01 --> Final output sent to browser
DEBUG - 2016-03-09 11:22:01 --> Total execution time: 1.1529
INFO - 2016-03-09 08:22:16 --> Config Class Initialized
INFO - 2016-03-09 08:22:16 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:22:16 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:22:16 --> Utf8 Class Initialized
INFO - 2016-03-09 08:22:16 --> URI Class Initialized
INFO - 2016-03-09 08:22:16 --> Router Class Initialized
INFO - 2016-03-09 08:22:16 --> Output Class Initialized
INFO - 2016-03-09 08:22:16 --> Security Class Initialized
DEBUG - 2016-03-09 08:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:22:16 --> Input Class Initialized
INFO - 2016-03-09 08:22:16 --> Language Class Initialized
INFO - 2016-03-09 08:22:16 --> Loader Class Initialized
INFO - 2016-03-09 08:22:16 --> Helper loaded: url_helper
INFO - 2016-03-09 08:22:16 --> Helper loaded: file_helper
INFO - 2016-03-09 08:22:16 --> Helper loaded: date_helper
INFO - 2016-03-09 08:22:16 --> Helper loaded: form_helper
INFO - 2016-03-09 08:22:16 --> Database Driver Class Initialized
INFO - 2016-03-09 08:22:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:22:17 --> Controller Class Initialized
INFO - 2016-03-09 08:22:17 --> Model Class Initialized
INFO - 2016-03-09 08:22:17 --> Model Class Initialized
INFO - 2016-03-09 08:22:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:22:17 --> Pagination Class Initialized
INFO - 2016-03-09 08:22:17 --> Helper loaded: text_helper
INFO - 2016-03-09 08:22:17 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:22:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:22:17 --> Final output sent to browser
DEBUG - 2016-03-09 11:22:17 --> Total execution time: 1.2204
INFO - 2016-03-09 08:22:19 --> Config Class Initialized
INFO - 2016-03-09 08:22:19 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:22:19 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:22:19 --> Utf8 Class Initialized
INFO - 2016-03-09 08:22:19 --> URI Class Initialized
INFO - 2016-03-09 08:22:19 --> Router Class Initialized
INFO - 2016-03-09 08:22:19 --> Output Class Initialized
INFO - 2016-03-09 08:22:19 --> Security Class Initialized
DEBUG - 2016-03-09 08:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:22:19 --> Input Class Initialized
INFO - 2016-03-09 08:22:19 --> Language Class Initialized
INFO - 2016-03-09 08:22:19 --> Loader Class Initialized
INFO - 2016-03-09 08:22:19 --> Helper loaded: url_helper
INFO - 2016-03-09 08:22:19 --> Helper loaded: file_helper
INFO - 2016-03-09 08:22:19 --> Helper loaded: date_helper
INFO - 2016-03-09 08:22:19 --> Helper loaded: form_helper
INFO - 2016-03-09 08:22:19 --> Database Driver Class Initialized
INFO - 2016-03-09 08:22:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:22:20 --> Controller Class Initialized
INFO - 2016-03-09 08:22:20 --> Model Class Initialized
INFO - 2016-03-09 08:22:20 --> Model Class Initialized
INFO - 2016-03-09 08:22:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:22:20 --> Pagination Class Initialized
INFO - 2016-03-09 08:22:20 --> Helper loaded: text_helper
INFO - 2016-03-09 08:22:20 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:22:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:22:20 --> Final output sent to browser
DEBUG - 2016-03-09 11:22:20 --> Total execution time: 1.1468
INFO - 2016-03-09 08:22:23 --> Config Class Initialized
INFO - 2016-03-09 08:22:23 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:22:23 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:22:23 --> Utf8 Class Initialized
INFO - 2016-03-09 08:22:23 --> URI Class Initialized
INFO - 2016-03-09 08:22:23 --> Router Class Initialized
INFO - 2016-03-09 08:22:23 --> Output Class Initialized
INFO - 2016-03-09 08:22:23 --> Security Class Initialized
DEBUG - 2016-03-09 08:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:22:23 --> Input Class Initialized
INFO - 2016-03-09 08:22:23 --> Language Class Initialized
INFO - 2016-03-09 08:22:23 --> Loader Class Initialized
INFO - 2016-03-09 08:22:23 --> Helper loaded: url_helper
INFO - 2016-03-09 08:22:23 --> Helper loaded: file_helper
INFO - 2016-03-09 08:22:23 --> Helper loaded: date_helper
INFO - 2016-03-09 08:22:23 --> Helper loaded: form_helper
INFO - 2016-03-09 08:22:23 --> Database Driver Class Initialized
INFO - 2016-03-09 08:22:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:22:24 --> Controller Class Initialized
INFO - 2016-03-09 08:22:24 --> Model Class Initialized
INFO - 2016-03-09 08:22:24 --> Model Class Initialized
INFO - 2016-03-09 08:22:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:22:24 --> Pagination Class Initialized
INFO - 2016-03-09 08:22:24 --> Helper loaded: text_helper
INFO - 2016-03-09 08:22:24 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:22:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:22:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:22:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:22:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:22:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:22:24 --> Final output sent to browser
DEBUG - 2016-03-09 11:22:24 --> Total execution time: 1.1347
INFO - 2016-03-09 08:22:43 --> Config Class Initialized
INFO - 2016-03-09 08:22:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:22:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:22:43 --> Utf8 Class Initialized
INFO - 2016-03-09 08:22:43 --> URI Class Initialized
INFO - 2016-03-09 08:22:43 --> Router Class Initialized
INFO - 2016-03-09 08:22:43 --> Output Class Initialized
INFO - 2016-03-09 08:22:43 --> Security Class Initialized
DEBUG - 2016-03-09 08:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:22:43 --> Input Class Initialized
INFO - 2016-03-09 08:22:43 --> Language Class Initialized
INFO - 2016-03-09 08:22:43 --> Loader Class Initialized
INFO - 2016-03-09 08:22:43 --> Helper loaded: url_helper
INFO - 2016-03-09 08:22:43 --> Helper loaded: file_helper
INFO - 2016-03-09 08:22:43 --> Helper loaded: date_helper
INFO - 2016-03-09 08:22:43 --> Helper loaded: form_helper
INFO - 2016-03-09 08:22:43 --> Database Driver Class Initialized
INFO - 2016-03-09 08:22:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:22:44 --> Controller Class Initialized
INFO - 2016-03-09 08:22:44 --> Model Class Initialized
INFO - 2016-03-09 08:22:44 --> Model Class Initialized
INFO - 2016-03-09 08:22:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:22:44 --> Pagination Class Initialized
INFO - 2016-03-09 08:22:44 --> Helper loaded: text_helper
INFO - 2016-03-09 08:22:44 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:22:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:22:44 --> Final output sent to browser
DEBUG - 2016-03-09 11:22:44 --> Total execution time: 1.1454
INFO - 2016-03-09 08:23:46 --> Config Class Initialized
INFO - 2016-03-09 08:23:46 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:23:46 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:23:46 --> Utf8 Class Initialized
INFO - 2016-03-09 08:23:46 --> URI Class Initialized
INFO - 2016-03-09 08:23:46 --> Router Class Initialized
INFO - 2016-03-09 08:23:46 --> Output Class Initialized
INFO - 2016-03-09 08:23:46 --> Security Class Initialized
DEBUG - 2016-03-09 08:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:23:46 --> Input Class Initialized
INFO - 2016-03-09 08:23:46 --> Language Class Initialized
INFO - 2016-03-09 08:23:46 --> Loader Class Initialized
INFO - 2016-03-09 08:23:46 --> Helper loaded: url_helper
INFO - 2016-03-09 08:23:46 --> Helper loaded: file_helper
INFO - 2016-03-09 08:23:46 --> Helper loaded: date_helper
INFO - 2016-03-09 08:23:46 --> Helper loaded: form_helper
INFO - 2016-03-09 08:23:46 --> Database Driver Class Initialized
INFO - 2016-03-09 08:23:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:23:47 --> Controller Class Initialized
INFO - 2016-03-09 08:23:47 --> Model Class Initialized
INFO - 2016-03-09 08:23:47 --> Model Class Initialized
INFO - 2016-03-09 08:23:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:23:47 --> Pagination Class Initialized
INFO - 2016-03-09 08:23:47 --> Helper loaded: text_helper
INFO - 2016-03-09 08:23:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:23:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:23:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-09 11:23:47 --> Severity: Warning --> Missing argument 3 for Jboard_model::mydata(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 192 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 14
ERROR - 2016-03-09 11:23:47 --> Severity: Notice --> Undefined variable: offset C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 18
INFO - 2016-03-09 11:23:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:23:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:23:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:23:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:23:47 --> Final output sent to browser
DEBUG - 2016-03-09 11:23:47 --> Total execution time: 1.2332
INFO - 2016-03-09 08:24:36 --> Config Class Initialized
INFO - 2016-03-09 08:24:36 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:24:36 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:24:36 --> Utf8 Class Initialized
INFO - 2016-03-09 08:24:36 --> URI Class Initialized
INFO - 2016-03-09 08:24:36 --> Router Class Initialized
INFO - 2016-03-09 08:24:36 --> Output Class Initialized
INFO - 2016-03-09 08:24:36 --> Security Class Initialized
DEBUG - 2016-03-09 08:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:24:36 --> Input Class Initialized
INFO - 2016-03-09 08:24:36 --> Language Class Initialized
INFO - 2016-03-09 08:24:36 --> Loader Class Initialized
INFO - 2016-03-09 08:24:36 --> Helper loaded: url_helper
INFO - 2016-03-09 08:24:36 --> Helper loaded: file_helper
INFO - 2016-03-09 08:24:36 --> Helper loaded: date_helper
INFO - 2016-03-09 08:24:36 --> Helper loaded: form_helper
INFO - 2016-03-09 08:24:36 --> Database Driver Class Initialized
INFO - 2016-03-09 08:24:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:24:37 --> Controller Class Initialized
INFO - 2016-03-09 08:24:37 --> Model Class Initialized
INFO - 2016-03-09 08:24:37 --> Model Class Initialized
INFO - 2016-03-09 08:24:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:24:37 --> Pagination Class Initialized
INFO - 2016-03-09 08:24:37 --> Helper loaded: text_helper
INFO - 2016-03-09 08:24:37 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:24:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:24:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:24:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:24:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:24:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:24:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:24:37 --> Final output sent to browser
DEBUG - 2016-03-09 11:24:37 --> Total execution time: 1.3339
INFO - 2016-03-09 08:25:39 --> Config Class Initialized
INFO - 2016-03-09 08:25:39 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:25:39 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:25:39 --> Utf8 Class Initialized
INFO - 2016-03-09 08:25:39 --> URI Class Initialized
INFO - 2016-03-09 08:25:39 --> Router Class Initialized
INFO - 2016-03-09 08:25:39 --> Output Class Initialized
INFO - 2016-03-09 08:25:39 --> Security Class Initialized
DEBUG - 2016-03-09 08:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:25:39 --> Input Class Initialized
INFO - 2016-03-09 08:25:39 --> Language Class Initialized
INFO - 2016-03-09 08:25:39 --> Loader Class Initialized
INFO - 2016-03-09 08:25:39 --> Helper loaded: url_helper
INFO - 2016-03-09 08:25:39 --> Helper loaded: file_helper
INFO - 2016-03-09 08:25:39 --> Helper loaded: date_helper
INFO - 2016-03-09 08:25:39 --> Helper loaded: form_helper
INFO - 2016-03-09 08:25:39 --> Database Driver Class Initialized
INFO - 2016-03-09 08:25:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:25:40 --> Controller Class Initialized
INFO - 2016-03-09 08:25:40 --> Model Class Initialized
INFO - 2016-03-09 08:25:40 --> Model Class Initialized
INFO - 2016-03-09 08:25:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:25:40 --> Pagination Class Initialized
INFO - 2016-03-09 08:25:40 --> Helper loaded: text_helper
INFO - 2016-03-09 08:25:40 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:25:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:25:40 --> Final output sent to browser
DEBUG - 2016-03-09 11:25:40 --> Total execution time: 1.2460
INFO - 2016-03-09 08:26:40 --> Config Class Initialized
INFO - 2016-03-09 08:26:40 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:26:40 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:26:40 --> Utf8 Class Initialized
INFO - 2016-03-09 08:26:40 --> URI Class Initialized
INFO - 2016-03-09 08:26:40 --> Router Class Initialized
INFO - 2016-03-09 08:26:40 --> Output Class Initialized
INFO - 2016-03-09 08:26:40 --> Security Class Initialized
DEBUG - 2016-03-09 08:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:26:40 --> Input Class Initialized
INFO - 2016-03-09 08:26:40 --> Language Class Initialized
INFO - 2016-03-09 08:26:40 --> Loader Class Initialized
INFO - 2016-03-09 08:26:40 --> Helper loaded: url_helper
INFO - 2016-03-09 08:26:40 --> Helper loaded: file_helper
INFO - 2016-03-09 08:26:40 --> Helper loaded: date_helper
INFO - 2016-03-09 08:26:40 --> Helper loaded: form_helper
INFO - 2016-03-09 08:26:40 --> Database Driver Class Initialized
INFO - 2016-03-09 08:26:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:26:41 --> Controller Class Initialized
INFO - 2016-03-09 08:26:41 --> Model Class Initialized
INFO - 2016-03-09 08:26:41 --> Model Class Initialized
INFO - 2016-03-09 08:26:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:26:41 --> Pagination Class Initialized
INFO - 2016-03-09 08:26:41 --> Helper loaded: text_helper
INFO - 2016-03-09 08:26:41 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:26:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:26:41 --> Final output sent to browser
DEBUG - 2016-03-09 11:26:41 --> Total execution time: 1.2842
INFO - 2016-03-09 08:27:59 --> Config Class Initialized
INFO - 2016-03-09 08:27:59 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:27:59 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:27:59 --> Utf8 Class Initialized
INFO - 2016-03-09 08:27:59 --> URI Class Initialized
INFO - 2016-03-09 08:27:59 --> Router Class Initialized
INFO - 2016-03-09 08:27:59 --> Output Class Initialized
INFO - 2016-03-09 08:27:59 --> Security Class Initialized
DEBUG - 2016-03-09 08:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:27:59 --> Input Class Initialized
INFO - 2016-03-09 08:27:59 --> Language Class Initialized
INFO - 2016-03-09 08:27:59 --> Loader Class Initialized
INFO - 2016-03-09 08:27:59 --> Helper loaded: url_helper
INFO - 2016-03-09 08:27:59 --> Helper loaded: file_helper
INFO - 2016-03-09 08:27:59 --> Helper loaded: date_helper
INFO - 2016-03-09 08:27:59 --> Helper loaded: form_helper
INFO - 2016-03-09 08:27:59 --> Database Driver Class Initialized
INFO - 2016-03-09 08:28:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:28:00 --> Controller Class Initialized
INFO - 2016-03-09 08:28:00 --> Model Class Initialized
INFO - 2016-03-09 08:28:00 --> Model Class Initialized
INFO - 2016-03-09 08:28:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:28:00 --> Pagination Class Initialized
INFO - 2016-03-09 08:28:00 --> Helper loaded: text_helper
INFO - 2016-03-09 08:28:00 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:28:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:28:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:28:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:28:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:28:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:28:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:28:00 --> Final output sent to browser
DEBUG - 2016-03-09 11:28:00 --> Total execution time: 1.2227
INFO - 2016-03-09 08:28:48 --> Config Class Initialized
INFO - 2016-03-09 08:28:48 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:28:48 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:28:48 --> Utf8 Class Initialized
INFO - 2016-03-09 08:28:48 --> URI Class Initialized
INFO - 2016-03-09 08:28:48 --> Router Class Initialized
INFO - 2016-03-09 08:28:48 --> Output Class Initialized
INFO - 2016-03-09 08:28:48 --> Security Class Initialized
DEBUG - 2016-03-09 08:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:28:48 --> Input Class Initialized
INFO - 2016-03-09 08:28:48 --> Language Class Initialized
INFO - 2016-03-09 08:28:48 --> Loader Class Initialized
INFO - 2016-03-09 08:28:48 --> Helper loaded: url_helper
INFO - 2016-03-09 08:28:48 --> Helper loaded: file_helper
INFO - 2016-03-09 08:28:48 --> Helper loaded: date_helper
INFO - 2016-03-09 08:28:48 --> Helper loaded: form_helper
INFO - 2016-03-09 08:28:48 --> Database Driver Class Initialized
INFO - 2016-03-09 08:28:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:28:49 --> Controller Class Initialized
INFO - 2016-03-09 08:28:49 --> Model Class Initialized
INFO - 2016-03-09 08:28:49 --> Model Class Initialized
INFO - 2016-03-09 08:28:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:28:49 --> Pagination Class Initialized
INFO - 2016-03-09 08:28:49 --> Helper loaded: text_helper
INFO - 2016-03-09 08:28:49 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:28:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:28:49 --> Final output sent to browser
DEBUG - 2016-03-09 11:28:49 --> Total execution time: 1.1926
INFO - 2016-03-09 08:29:28 --> Config Class Initialized
INFO - 2016-03-09 08:29:28 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:29:28 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:29:28 --> Utf8 Class Initialized
INFO - 2016-03-09 08:29:28 --> URI Class Initialized
INFO - 2016-03-09 08:29:28 --> Router Class Initialized
INFO - 2016-03-09 08:29:28 --> Output Class Initialized
INFO - 2016-03-09 08:29:28 --> Security Class Initialized
DEBUG - 2016-03-09 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:29:28 --> Input Class Initialized
INFO - 2016-03-09 08:29:28 --> Language Class Initialized
INFO - 2016-03-09 08:29:28 --> Loader Class Initialized
INFO - 2016-03-09 08:29:28 --> Helper loaded: url_helper
INFO - 2016-03-09 08:29:28 --> Helper loaded: file_helper
INFO - 2016-03-09 08:29:28 --> Helper loaded: date_helper
INFO - 2016-03-09 08:29:28 --> Helper loaded: form_helper
INFO - 2016-03-09 08:29:28 --> Database Driver Class Initialized
INFO - 2016-03-09 08:29:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:29:29 --> Controller Class Initialized
INFO - 2016-03-09 08:29:29 --> Model Class Initialized
INFO - 2016-03-09 08:29:29 --> Model Class Initialized
INFO - 2016-03-09 08:29:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:29:29 --> Pagination Class Initialized
INFO - 2016-03-09 08:29:29 --> Helper loaded: text_helper
INFO - 2016-03-09 08:29:29 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:29:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:29:29 --> Final output sent to browser
DEBUG - 2016-03-09 11:29:29 --> Total execution time: 1.2079
INFO - 2016-03-09 08:29:55 --> Config Class Initialized
INFO - 2016-03-09 08:29:55 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:29:55 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:29:55 --> Utf8 Class Initialized
INFO - 2016-03-09 08:29:55 --> URI Class Initialized
INFO - 2016-03-09 08:29:55 --> Router Class Initialized
INFO - 2016-03-09 08:29:55 --> Output Class Initialized
INFO - 2016-03-09 08:29:55 --> Security Class Initialized
DEBUG - 2016-03-09 08:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:29:55 --> Input Class Initialized
INFO - 2016-03-09 08:29:55 --> Language Class Initialized
INFO - 2016-03-09 08:29:55 --> Loader Class Initialized
INFO - 2016-03-09 08:29:55 --> Helper loaded: url_helper
INFO - 2016-03-09 08:29:55 --> Helper loaded: file_helper
INFO - 2016-03-09 08:29:55 --> Helper loaded: date_helper
INFO - 2016-03-09 08:29:55 --> Helper loaded: form_helper
INFO - 2016-03-09 08:29:55 --> Database Driver Class Initialized
INFO - 2016-03-09 08:29:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:29:56 --> Controller Class Initialized
INFO - 2016-03-09 08:29:56 --> Model Class Initialized
INFO - 2016-03-09 08:29:56 --> Model Class Initialized
INFO - 2016-03-09 08:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:29:56 --> Pagination Class Initialized
INFO - 2016-03-09 08:29:56 --> Helper loaded: text_helper
INFO - 2016-03-09 08:29:56 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:29:56 --> Final output sent to browser
DEBUG - 2016-03-09 11:29:56 --> Total execution time: 1.2309
INFO - 2016-03-09 08:30:02 --> Config Class Initialized
INFO - 2016-03-09 08:30:02 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:30:02 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:30:02 --> Utf8 Class Initialized
INFO - 2016-03-09 08:30:02 --> URI Class Initialized
INFO - 2016-03-09 08:30:02 --> Router Class Initialized
INFO - 2016-03-09 08:30:02 --> Output Class Initialized
INFO - 2016-03-09 08:30:02 --> Security Class Initialized
DEBUG - 2016-03-09 08:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:30:02 --> Input Class Initialized
INFO - 2016-03-09 08:30:02 --> Language Class Initialized
INFO - 2016-03-09 08:30:02 --> Loader Class Initialized
INFO - 2016-03-09 08:30:02 --> Helper loaded: url_helper
INFO - 2016-03-09 08:30:02 --> Helper loaded: file_helper
INFO - 2016-03-09 08:30:02 --> Helper loaded: date_helper
INFO - 2016-03-09 08:30:02 --> Helper loaded: form_helper
INFO - 2016-03-09 08:30:02 --> Database Driver Class Initialized
INFO - 2016-03-09 08:30:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:30:03 --> Controller Class Initialized
INFO - 2016-03-09 08:30:03 --> Model Class Initialized
INFO - 2016-03-09 08:30:03 --> Model Class Initialized
INFO - 2016-03-09 08:30:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:30:03 --> Pagination Class Initialized
INFO - 2016-03-09 08:30:03 --> Helper loaded: text_helper
INFO - 2016-03-09 08:30:03 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:30:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:30:03 --> Final output sent to browser
DEBUG - 2016-03-09 11:30:03 --> Total execution time: 1.1344
INFO - 2016-03-09 08:30:05 --> Config Class Initialized
INFO - 2016-03-09 08:30:05 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:30:05 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:30:05 --> Utf8 Class Initialized
INFO - 2016-03-09 08:30:05 --> URI Class Initialized
INFO - 2016-03-09 08:30:05 --> Router Class Initialized
INFO - 2016-03-09 08:30:05 --> Output Class Initialized
INFO - 2016-03-09 08:30:05 --> Security Class Initialized
DEBUG - 2016-03-09 08:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:30:05 --> Input Class Initialized
INFO - 2016-03-09 08:30:05 --> Language Class Initialized
INFO - 2016-03-09 08:30:05 --> Loader Class Initialized
INFO - 2016-03-09 08:30:05 --> Helper loaded: url_helper
INFO - 2016-03-09 08:30:05 --> Helper loaded: file_helper
INFO - 2016-03-09 08:30:05 --> Helper loaded: date_helper
INFO - 2016-03-09 08:30:05 --> Helper loaded: form_helper
INFO - 2016-03-09 08:30:05 --> Database Driver Class Initialized
INFO - 2016-03-09 08:30:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:30:06 --> Controller Class Initialized
INFO - 2016-03-09 08:30:06 --> Model Class Initialized
INFO - 2016-03-09 08:30:06 --> Model Class Initialized
INFO - 2016-03-09 08:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:30:06 --> Pagination Class Initialized
INFO - 2016-03-09 08:30:06 --> Helper loaded: text_helper
INFO - 2016-03-09 08:30:06 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:30:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:30:06 --> Final output sent to browser
DEBUG - 2016-03-09 11:30:06 --> Total execution time: 1.1726
INFO - 2016-03-09 08:30:12 --> Config Class Initialized
INFO - 2016-03-09 08:30:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:30:12 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:30:12 --> Utf8 Class Initialized
INFO - 2016-03-09 08:30:12 --> URI Class Initialized
INFO - 2016-03-09 08:30:12 --> Router Class Initialized
INFO - 2016-03-09 08:30:12 --> Output Class Initialized
INFO - 2016-03-09 08:30:12 --> Security Class Initialized
DEBUG - 2016-03-09 08:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:30:12 --> Input Class Initialized
INFO - 2016-03-09 08:30:12 --> Language Class Initialized
INFO - 2016-03-09 08:30:12 --> Loader Class Initialized
INFO - 2016-03-09 08:30:12 --> Helper loaded: url_helper
INFO - 2016-03-09 08:30:12 --> Helper loaded: file_helper
INFO - 2016-03-09 08:30:12 --> Helper loaded: date_helper
INFO - 2016-03-09 08:30:12 --> Helper loaded: form_helper
INFO - 2016-03-09 08:30:12 --> Database Driver Class Initialized
INFO - 2016-03-09 08:30:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:30:13 --> Controller Class Initialized
INFO - 2016-03-09 08:30:13 --> Model Class Initialized
INFO - 2016-03-09 08:30:13 --> Model Class Initialized
INFO - 2016-03-09 08:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:30:13 --> Pagination Class Initialized
INFO - 2016-03-09 08:30:13 --> Helper loaded: text_helper
INFO - 2016-03-09 08:30:13 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:30:13 --> Final output sent to browser
DEBUG - 2016-03-09 11:30:13 --> Total execution time: 1.2025
INFO - 2016-03-09 08:31:54 --> Config Class Initialized
INFO - 2016-03-09 08:31:54 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:31:54 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:31:54 --> Utf8 Class Initialized
INFO - 2016-03-09 08:31:54 --> URI Class Initialized
INFO - 2016-03-09 08:31:54 --> Router Class Initialized
INFO - 2016-03-09 08:31:54 --> Output Class Initialized
INFO - 2016-03-09 08:31:54 --> Security Class Initialized
DEBUG - 2016-03-09 08:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:31:54 --> Input Class Initialized
INFO - 2016-03-09 08:31:54 --> Language Class Initialized
INFO - 2016-03-09 08:31:54 --> Loader Class Initialized
INFO - 2016-03-09 08:31:54 --> Helper loaded: url_helper
INFO - 2016-03-09 08:31:54 --> Helper loaded: file_helper
INFO - 2016-03-09 08:31:54 --> Helper loaded: date_helper
INFO - 2016-03-09 08:31:54 --> Helper loaded: form_helper
INFO - 2016-03-09 08:31:54 --> Database Driver Class Initialized
INFO - 2016-03-09 08:31:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:31:55 --> Controller Class Initialized
INFO - 2016-03-09 08:31:55 --> Model Class Initialized
INFO - 2016-03-09 08:31:55 --> Model Class Initialized
INFO - 2016-03-09 08:31:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:31:55 --> Pagination Class Initialized
INFO - 2016-03-09 08:31:55 --> Helper loaded: text_helper
INFO - 2016-03-09 08:31:55 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:31:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:31:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:31:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:31:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:31:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:31:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:31:55 --> Final output sent to browser
DEBUG - 2016-03-09 11:31:55 --> Total execution time: 1.1943
INFO - 2016-03-09 08:32:02 --> Config Class Initialized
INFO - 2016-03-09 08:32:02 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:32:02 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:32:02 --> Utf8 Class Initialized
INFO - 2016-03-09 08:32:02 --> URI Class Initialized
INFO - 2016-03-09 08:32:02 --> Router Class Initialized
INFO - 2016-03-09 08:32:02 --> Output Class Initialized
INFO - 2016-03-09 08:32:02 --> Security Class Initialized
DEBUG - 2016-03-09 08:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:32:02 --> Input Class Initialized
INFO - 2016-03-09 08:32:02 --> Language Class Initialized
INFO - 2016-03-09 08:32:02 --> Loader Class Initialized
INFO - 2016-03-09 08:32:02 --> Helper loaded: url_helper
INFO - 2016-03-09 08:32:02 --> Helper loaded: file_helper
INFO - 2016-03-09 08:32:02 --> Helper loaded: date_helper
INFO - 2016-03-09 08:32:02 --> Helper loaded: form_helper
INFO - 2016-03-09 08:32:02 --> Database Driver Class Initialized
INFO - 2016-03-09 08:32:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:32:03 --> Controller Class Initialized
INFO - 2016-03-09 08:32:03 --> Model Class Initialized
INFO - 2016-03-09 08:32:03 --> Model Class Initialized
INFO - 2016-03-09 08:32:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:32:03 --> Pagination Class Initialized
INFO - 2016-03-09 08:32:03 --> Helper loaded: text_helper
INFO - 2016-03-09 08:32:03 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:32:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:32:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:32:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:32:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:32:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:32:03 --> Final output sent to browser
DEBUG - 2016-03-09 11:32:03 --> Total execution time: 1.1446
INFO - 2016-03-09 08:32:05 --> Config Class Initialized
INFO - 2016-03-09 08:32:05 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:32:05 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:32:05 --> Utf8 Class Initialized
INFO - 2016-03-09 08:32:05 --> URI Class Initialized
INFO - 2016-03-09 08:32:05 --> Router Class Initialized
INFO - 2016-03-09 08:32:05 --> Output Class Initialized
INFO - 2016-03-09 08:32:05 --> Security Class Initialized
DEBUG - 2016-03-09 08:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:32:05 --> Input Class Initialized
INFO - 2016-03-09 08:32:05 --> Language Class Initialized
INFO - 2016-03-09 08:32:05 --> Loader Class Initialized
INFO - 2016-03-09 08:32:05 --> Helper loaded: url_helper
INFO - 2016-03-09 08:32:05 --> Helper loaded: file_helper
INFO - 2016-03-09 08:32:05 --> Helper loaded: date_helper
INFO - 2016-03-09 08:32:05 --> Helper loaded: form_helper
INFO - 2016-03-09 08:32:05 --> Database Driver Class Initialized
INFO - 2016-03-09 08:32:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:32:06 --> Controller Class Initialized
INFO - 2016-03-09 08:32:06 --> Model Class Initialized
INFO - 2016-03-09 08:32:06 --> Model Class Initialized
INFO - 2016-03-09 08:32:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:32:06 --> Pagination Class Initialized
INFO - 2016-03-09 08:32:06 --> Helper loaded: text_helper
INFO - 2016-03-09 08:32:06 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:32:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:32:06 --> Final output sent to browser
DEBUG - 2016-03-09 11:32:06 --> Total execution time: 1.1735
INFO - 2016-03-09 08:32:08 --> Config Class Initialized
INFO - 2016-03-09 08:32:08 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:32:08 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:32:08 --> Utf8 Class Initialized
INFO - 2016-03-09 08:32:08 --> URI Class Initialized
INFO - 2016-03-09 08:32:08 --> Router Class Initialized
INFO - 2016-03-09 08:32:08 --> Output Class Initialized
INFO - 2016-03-09 08:32:08 --> Security Class Initialized
DEBUG - 2016-03-09 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:32:08 --> Input Class Initialized
INFO - 2016-03-09 08:32:08 --> Language Class Initialized
INFO - 2016-03-09 08:32:08 --> Loader Class Initialized
INFO - 2016-03-09 08:32:08 --> Helper loaded: url_helper
INFO - 2016-03-09 08:32:08 --> Helper loaded: file_helper
INFO - 2016-03-09 08:32:08 --> Helper loaded: date_helper
INFO - 2016-03-09 08:32:08 --> Helper loaded: form_helper
INFO - 2016-03-09 08:32:08 --> Database Driver Class Initialized
INFO - 2016-03-09 08:32:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:32:10 --> Controller Class Initialized
INFO - 2016-03-09 08:32:10 --> Model Class Initialized
INFO - 2016-03-09 08:32:10 --> Model Class Initialized
INFO - 2016-03-09 08:32:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:32:10 --> Pagination Class Initialized
INFO - 2016-03-09 08:32:10 --> Helper loaded: text_helper
INFO - 2016-03-09 08:32:10 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:32:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:32:10 --> Final output sent to browser
DEBUG - 2016-03-09 11:32:10 --> Total execution time: 1.1666
INFO - 2016-03-09 08:32:11 --> Config Class Initialized
INFO - 2016-03-09 08:32:11 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:32:11 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:32:11 --> Utf8 Class Initialized
INFO - 2016-03-09 08:32:11 --> URI Class Initialized
INFO - 2016-03-09 08:32:11 --> Router Class Initialized
INFO - 2016-03-09 08:32:11 --> Output Class Initialized
INFO - 2016-03-09 08:32:11 --> Security Class Initialized
DEBUG - 2016-03-09 08:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:32:11 --> Input Class Initialized
INFO - 2016-03-09 08:32:11 --> Language Class Initialized
INFO - 2016-03-09 08:32:11 --> Loader Class Initialized
INFO - 2016-03-09 08:32:11 --> Helper loaded: url_helper
INFO - 2016-03-09 08:32:11 --> Helper loaded: file_helper
INFO - 2016-03-09 08:32:11 --> Helper loaded: date_helper
INFO - 2016-03-09 08:32:11 --> Helper loaded: form_helper
INFO - 2016-03-09 08:32:11 --> Database Driver Class Initialized
INFO - 2016-03-09 08:32:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:32:12 --> Controller Class Initialized
INFO - 2016-03-09 08:32:12 --> Model Class Initialized
INFO - 2016-03-09 08:32:12 --> Model Class Initialized
INFO - 2016-03-09 08:32:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:32:12 --> Pagination Class Initialized
INFO - 2016-03-09 08:32:12 --> Helper loaded: text_helper
INFO - 2016-03-09 08:32:12 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:32:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:32:12 --> Final output sent to browser
DEBUG - 2016-03-09 11:32:12 --> Total execution time: 1.2061
INFO - 2016-03-09 08:32:44 --> Config Class Initialized
INFO - 2016-03-09 08:32:44 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:32:44 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:32:44 --> Utf8 Class Initialized
INFO - 2016-03-09 08:32:44 --> URI Class Initialized
INFO - 2016-03-09 08:32:44 --> Router Class Initialized
INFO - 2016-03-09 08:32:44 --> Output Class Initialized
INFO - 2016-03-09 08:32:44 --> Security Class Initialized
DEBUG - 2016-03-09 08:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:32:44 --> Input Class Initialized
INFO - 2016-03-09 08:32:44 --> Language Class Initialized
INFO - 2016-03-09 08:32:44 --> Loader Class Initialized
INFO - 2016-03-09 08:32:44 --> Helper loaded: url_helper
INFO - 2016-03-09 08:32:44 --> Helper loaded: file_helper
INFO - 2016-03-09 08:32:44 --> Helper loaded: date_helper
INFO - 2016-03-09 08:32:44 --> Helper loaded: form_helper
INFO - 2016-03-09 08:32:44 --> Database Driver Class Initialized
INFO - 2016-03-09 08:32:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:32:45 --> Controller Class Initialized
INFO - 2016-03-09 08:32:45 --> Model Class Initialized
INFO - 2016-03-09 08:32:45 --> Model Class Initialized
INFO - 2016-03-09 08:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:32:45 --> Pagination Class Initialized
INFO - 2016-03-09 08:32:45 --> Helper loaded: text_helper
INFO - 2016-03-09 08:32:45 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:32:45 --> Final output sent to browser
DEBUG - 2016-03-09 11:32:45 --> Total execution time: 1.2318
INFO - 2016-03-09 08:32:50 --> Config Class Initialized
INFO - 2016-03-09 08:32:50 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:32:50 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:32:50 --> Utf8 Class Initialized
INFO - 2016-03-09 08:32:50 --> URI Class Initialized
INFO - 2016-03-09 08:32:50 --> Router Class Initialized
INFO - 2016-03-09 08:32:50 --> Output Class Initialized
INFO - 2016-03-09 08:32:50 --> Security Class Initialized
DEBUG - 2016-03-09 08:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:32:50 --> Input Class Initialized
INFO - 2016-03-09 08:32:50 --> Language Class Initialized
INFO - 2016-03-09 08:32:50 --> Loader Class Initialized
INFO - 2016-03-09 08:32:50 --> Helper loaded: url_helper
INFO - 2016-03-09 08:32:50 --> Helper loaded: file_helper
INFO - 2016-03-09 08:32:50 --> Helper loaded: date_helper
INFO - 2016-03-09 08:32:50 --> Helper loaded: form_helper
INFO - 2016-03-09 08:32:50 --> Database Driver Class Initialized
INFO - 2016-03-09 08:32:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:32:51 --> Controller Class Initialized
INFO - 2016-03-09 08:32:51 --> Model Class Initialized
INFO - 2016-03-09 08:32:51 --> Model Class Initialized
INFO - 2016-03-09 08:32:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:32:51 --> Pagination Class Initialized
INFO - 2016-03-09 08:32:51 --> Helper loaded: text_helper
INFO - 2016-03-09 08:32:51 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:32:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:32:51 --> Final output sent to browser
DEBUG - 2016-03-09 11:32:51 --> Total execution time: 1.1332
INFO - 2016-03-09 08:32:53 --> Config Class Initialized
INFO - 2016-03-09 08:32:53 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:32:53 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:32:53 --> Utf8 Class Initialized
INFO - 2016-03-09 08:32:53 --> URI Class Initialized
INFO - 2016-03-09 08:32:53 --> Router Class Initialized
INFO - 2016-03-09 08:32:53 --> Output Class Initialized
INFO - 2016-03-09 08:32:53 --> Security Class Initialized
DEBUG - 2016-03-09 08:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:32:53 --> Input Class Initialized
INFO - 2016-03-09 08:32:53 --> Language Class Initialized
INFO - 2016-03-09 08:32:53 --> Loader Class Initialized
INFO - 2016-03-09 08:32:53 --> Helper loaded: url_helper
INFO - 2016-03-09 08:32:53 --> Helper loaded: file_helper
INFO - 2016-03-09 08:32:53 --> Helper loaded: date_helper
INFO - 2016-03-09 08:32:53 --> Helper loaded: form_helper
INFO - 2016-03-09 08:32:53 --> Database Driver Class Initialized
INFO - 2016-03-09 08:32:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:32:54 --> Controller Class Initialized
INFO - 2016-03-09 08:32:54 --> Model Class Initialized
INFO - 2016-03-09 08:32:54 --> Model Class Initialized
INFO - 2016-03-09 08:32:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:32:54 --> Pagination Class Initialized
INFO - 2016-03-09 08:32:54 --> Helper loaded: text_helper
INFO - 2016-03-09 08:32:54 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:32:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:32:54 --> Final output sent to browser
DEBUG - 2016-03-09 11:32:54 --> Total execution time: 1.1723
INFO - 2016-03-09 08:32:56 --> Config Class Initialized
INFO - 2016-03-09 08:32:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:32:56 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:32:56 --> Utf8 Class Initialized
INFO - 2016-03-09 08:32:56 --> URI Class Initialized
INFO - 2016-03-09 08:32:56 --> Router Class Initialized
INFO - 2016-03-09 08:32:56 --> Output Class Initialized
INFO - 2016-03-09 08:32:56 --> Security Class Initialized
DEBUG - 2016-03-09 08:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:32:56 --> Input Class Initialized
INFO - 2016-03-09 08:32:56 --> Language Class Initialized
INFO - 2016-03-09 08:32:56 --> Loader Class Initialized
INFO - 2016-03-09 08:32:56 --> Helper loaded: url_helper
INFO - 2016-03-09 08:32:56 --> Helper loaded: file_helper
INFO - 2016-03-09 08:32:56 --> Helper loaded: date_helper
INFO - 2016-03-09 08:32:56 --> Helper loaded: form_helper
INFO - 2016-03-09 08:32:56 --> Database Driver Class Initialized
INFO - 2016-03-09 08:32:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:32:57 --> Controller Class Initialized
INFO - 2016-03-09 08:32:57 --> Model Class Initialized
INFO - 2016-03-09 08:32:57 --> Model Class Initialized
INFO - 2016-03-09 08:32:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:32:57 --> Pagination Class Initialized
INFO - 2016-03-09 08:32:57 --> Helper loaded: text_helper
INFO - 2016-03-09 08:32:57 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:32:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:32:57 --> Final output sent to browser
DEBUG - 2016-03-09 11:32:57 --> Total execution time: 1.2774
INFO - 2016-03-09 08:33:20 --> Config Class Initialized
INFO - 2016-03-09 08:33:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:33:20 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:33:20 --> Utf8 Class Initialized
INFO - 2016-03-09 08:33:20 --> URI Class Initialized
INFO - 2016-03-09 08:33:20 --> Router Class Initialized
INFO - 2016-03-09 08:33:20 --> Output Class Initialized
INFO - 2016-03-09 08:33:20 --> Security Class Initialized
DEBUG - 2016-03-09 08:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:33:20 --> Input Class Initialized
INFO - 2016-03-09 08:33:20 --> Language Class Initialized
INFO - 2016-03-09 08:33:20 --> Loader Class Initialized
INFO - 2016-03-09 08:33:20 --> Helper loaded: url_helper
INFO - 2016-03-09 08:33:20 --> Helper loaded: file_helper
INFO - 2016-03-09 08:33:20 --> Helper loaded: date_helper
INFO - 2016-03-09 08:33:20 --> Helper loaded: form_helper
INFO - 2016-03-09 08:33:20 --> Database Driver Class Initialized
INFO - 2016-03-09 08:33:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:33:21 --> Controller Class Initialized
INFO - 2016-03-09 08:33:21 --> Model Class Initialized
INFO - 2016-03-09 08:33:21 --> Model Class Initialized
INFO - 2016-03-09 08:33:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:33:21 --> Pagination Class Initialized
INFO - 2016-03-09 08:33:21 --> Helper loaded: text_helper
INFO - 2016-03-09 08:33:21 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:33:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:33:21 --> Final output sent to browser
DEBUG - 2016-03-09 11:33:21 --> Total execution time: 1.2567
INFO - 2016-03-09 08:33:25 --> Config Class Initialized
INFO - 2016-03-09 08:33:25 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:33:25 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:33:25 --> Utf8 Class Initialized
INFO - 2016-03-09 08:33:25 --> URI Class Initialized
INFO - 2016-03-09 08:33:25 --> Router Class Initialized
INFO - 2016-03-09 08:33:25 --> Output Class Initialized
INFO - 2016-03-09 08:33:25 --> Security Class Initialized
DEBUG - 2016-03-09 08:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:33:25 --> Input Class Initialized
INFO - 2016-03-09 08:33:25 --> Language Class Initialized
INFO - 2016-03-09 08:33:25 --> Loader Class Initialized
INFO - 2016-03-09 08:33:25 --> Helper loaded: url_helper
INFO - 2016-03-09 08:33:25 --> Helper loaded: file_helper
INFO - 2016-03-09 08:33:25 --> Helper loaded: date_helper
INFO - 2016-03-09 08:33:25 --> Helper loaded: form_helper
INFO - 2016-03-09 08:33:25 --> Database Driver Class Initialized
INFO - 2016-03-09 08:33:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:33:26 --> Controller Class Initialized
INFO - 2016-03-09 08:33:26 --> Model Class Initialized
INFO - 2016-03-09 08:33:26 --> Model Class Initialized
INFO - 2016-03-09 08:33:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:33:26 --> Pagination Class Initialized
INFO - 2016-03-09 08:33:26 --> Helper loaded: text_helper
INFO - 2016-03-09 08:33:26 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:33:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:33:26 --> Final output sent to browser
DEBUG - 2016-03-09 11:33:26 --> Total execution time: 1.1333
INFO - 2016-03-09 08:33:28 --> Config Class Initialized
INFO - 2016-03-09 08:33:28 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:33:28 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:33:28 --> Utf8 Class Initialized
INFO - 2016-03-09 08:33:28 --> URI Class Initialized
INFO - 2016-03-09 08:33:28 --> Router Class Initialized
INFO - 2016-03-09 08:33:28 --> Output Class Initialized
INFO - 2016-03-09 08:33:28 --> Security Class Initialized
DEBUG - 2016-03-09 08:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:33:28 --> Input Class Initialized
INFO - 2016-03-09 08:33:28 --> Language Class Initialized
INFO - 2016-03-09 08:33:28 --> Loader Class Initialized
INFO - 2016-03-09 08:33:28 --> Helper loaded: url_helper
INFO - 2016-03-09 08:33:28 --> Helper loaded: file_helper
INFO - 2016-03-09 08:33:28 --> Helper loaded: date_helper
INFO - 2016-03-09 08:33:28 --> Helper loaded: form_helper
INFO - 2016-03-09 08:33:28 --> Database Driver Class Initialized
INFO - 2016-03-09 08:33:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:33:29 --> Controller Class Initialized
INFO - 2016-03-09 08:33:29 --> Model Class Initialized
INFO - 2016-03-09 08:33:29 --> Model Class Initialized
INFO - 2016-03-09 08:33:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:33:29 --> Pagination Class Initialized
INFO - 2016-03-09 08:33:29 --> Helper loaded: text_helper
INFO - 2016-03-09 08:33:29 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:33:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:33:29 --> Final output sent to browser
DEBUG - 2016-03-09 11:33:29 --> Total execution time: 1.1779
INFO - 2016-03-09 08:34:04 --> Config Class Initialized
INFO - 2016-03-09 08:34:04 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:34:04 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:34:04 --> Utf8 Class Initialized
INFO - 2016-03-09 08:34:04 --> URI Class Initialized
INFO - 2016-03-09 08:34:04 --> Router Class Initialized
INFO - 2016-03-09 08:34:04 --> Output Class Initialized
INFO - 2016-03-09 08:34:04 --> Security Class Initialized
DEBUG - 2016-03-09 08:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:34:04 --> Input Class Initialized
INFO - 2016-03-09 08:34:04 --> Language Class Initialized
INFO - 2016-03-09 08:34:04 --> Loader Class Initialized
INFO - 2016-03-09 08:34:04 --> Helper loaded: url_helper
INFO - 2016-03-09 08:34:04 --> Helper loaded: file_helper
INFO - 2016-03-09 08:34:04 --> Helper loaded: date_helper
INFO - 2016-03-09 08:34:04 --> Helper loaded: form_helper
INFO - 2016-03-09 08:34:04 --> Database Driver Class Initialized
INFO - 2016-03-09 08:34:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:34:05 --> Controller Class Initialized
INFO - 2016-03-09 08:34:05 --> Model Class Initialized
INFO - 2016-03-09 08:34:05 --> Model Class Initialized
INFO - 2016-03-09 08:34:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:34:05 --> Pagination Class Initialized
INFO - 2016-03-09 08:34:05 --> Helper loaded: text_helper
INFO - 2016-03-09 08:34:05 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:34:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:34:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:34:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:34:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:34:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:34:05 --> Final output sent to browser
DEBUG - 2016-03-09 11:34:05 --> Total execution time: 1.1712
INFO - 2016-03-09 08:34:09 --> Config Class Initialized
INFO - 2016-03-09 08:34:09 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:34:09 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:34:09 --> Utf8 Class Initialized
INFO - 2016-03-09 08:34:09 --> URI Class Initialized
INFO - 2016-03-09 08:34:09 --> Router Class Initialized
INFO - 2016-03-09 08:34:09 --> Output Class Initialized
INFO - 2016-03-09 08:34:09 --> Security Class Initialized
DEBUG - 2016-03-09 08:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:34:09 --> Input Class Initialized
INFO - 2016-03-09 08:34:09 --> Language Class Initialized
INFO - 2016-03-09 08:34:09 --> Loader Class Initialized
INFO - 2016-03-09 08:34:09 --> Helper loaded: url_helper
INFO - 2016-03-09 08:34:09 --> Helper loaded: file_helper
INFO - 2016-03-09 08:34:09 --> Helper loaded: date_helper
INFO - 2016-03-09 08:34:09 --> Helper loaded: form_helper
INFO - 2016-03-09 08:34:09 --> Database Driver Class Initialized
INFO - 2016-03-09 08:34:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:34:10 --> Controller Class Initialized
INFO - 2016-03-09 08:34:10 --> Model Class Initialized
INFO - 2016-03-09 08:34:10 --> Model Class Initialized
INFO - 2016-03-09 08:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:34:10 --> Pagination Class Initialized
INFO - 2016-03-09 08:34:10 --> Helper loaded: text_helper
INFO - 2016-03-09 08:34:10 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:34:10 --> Final output sent to browser
DEBUG - 2016-03-09 11:34:10 --> Total execution time: 1.2498
INFO - 2016-03-09 08:34:24 --> Config Class Initialized
INFO - 2016-03-09 08:34:24 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:34:24 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:34:24 --> Utf8 Class Initialized
INFO - 2016-03-09 08:34:24 --> URI Class Initialized
INFO - 2016-03-09 08:34:24 --> Router Class Initialized
INFO - 2016-03-09 08:34:24 --> Output Class Initialized
INFO - 2016-03-09 08:34:24 --> Security Class Initialized
DEBUG - 2016-03-09 08:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:34:24 --> Input Class Initialized
INFO - 2016-03-09 08:34:24 --> Language Class Initialized
INFO - 2016-03-09 08:34:24 --> Loader Class Initialized
INFO - 2016-03-09 08:34:24 --> Helper loaded: url_helper
INFO - 2016-03-09 08:34:24 --> Helper loaded: file_helper
INFO - 2016-03-09 08:34:24 --> Helper loaded: date_helper
INFO - 2016-03-09 08:34:24 --> Helper loaded: form_helper
INFO - 2016-03-09 08:34:24 --> Database Driver Class Initialized
INFO - 2016-03-09 08:34:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:34:25 --> Controller Class Initialized
INFO - 2016-03-09 08:34:25 --> Model Class Initialized
INFO - 2016-03-09 08:34:25 --> Model Class Initialized
INFO - 2016-03-09 08:34:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:34:25 --> Pagination Class Initialized
INFO - 2016-03-09 08:34:25 --> Helper loaded: text_helper
INFO - 2016-03-09 08:34:25 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:34:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:34:25 --> Final output sent to browser
DEBUG - 2016-03-09 11:34:25 --> Total execution time: 1.2416
INFO - 2016-03-09 08:34:54 --> Config Class Initialized
INFO - 2016-03-09 08:34:54 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:34:54 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:34:54 --> Utf8 Class Initialized
INFO - 2016-03-09 08:34:54 --> URI Class Initialized
INFO - 2016-03-09 08:34:54 --> Router Class Initialized
INFO - 2016-03-09 08:34:54 --> Output Class Initialized
INFO - 2016-03-09 08:34:54 --> Security Class Initialized
DEBUG - 2016-03-09 08:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:34:54 --> Input Class Initialized
INFO - 2016-03-09 08:34:54 --> Language Class Initialized
INFO - 2016-03-09 08:34:54 --> Loader Class Initialized
INFO - 2016-03-09 08:34:54 --> Helper loaded: url_helper
INFO - 2016-03-09 08:34:54 --> Helper loaded: file_helper
INFO - 2016-03-09 08:34:54 --> Helper loaded: date_helper
INFO - 2016-03-09 08:34:54 --> Helper loaded: form_helper
INFO - 2016-03-09 08:34:54 --> Database Driver Class Initialized
INFO - 2016-03-09 08:34:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:34:56 --> Controller Class Initialized
INFO - 2016-03-09 08:34:56 --> Model Class Initialized
INFO - 2016-03-09 08:34:56 --> Model Class Initialized
INFO - 2016-03-09 08:34:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:34:56 --> Pagination Class Initialized
INFO - 2016-03-09 08:34:56 --> Helper loaded: text_helper
INFO - 2016-03-09 08:34:56 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:34:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:34:56 --> Final output sent to browser
DEBUG - 2016-03-09 11:34:56 --> Total execution time: 1.1775
INFO - 2016-03-09 08:35:43 --> Config Class Initialized
INFO - 2016-03-09 08:35:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:35:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:35:43 --> Utf8 Class Initialized
INFO - 2016-03-09 08:35:43 --> URI Class Initialized
INFO - 2016-03-09 08:35:43 --> Router Class Initialized
INFO - 2016-03-09 08:35:43 --> Output Class Initialized
INFO - 2016-03-09 08:35:43 --> Security Class Initialized
DEBUG - 2016-03-09 08:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:35:43 --> Input Class Initialized
INFO - 2016-03-09 08:35:43 --> Language Class Initialized
INFO - 2016-03-09 08:35:43 --> Loader Class Initialized
INFO - 2016-03-09 08:35:43 --> Helper loaded: url_helper
INFO - 2016-03-09 08:35:43 --> Helper loaded: file_helper
INFO - 2016-03-09 08:35:43 --> Helper loaded: date_helper
INFO - 2016-03-09 08:35:43 --> Helper loaded: form_helper
INFO - 2016-03-09 08:35:43 --> Database Driver Class Initialized
INFO - 2016-03-09 08:35:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:35:45 --> Controller Class Initialized
INFO - 2016-03-09 08:35:45 --> Model Class Initialized
INFO - 2016-03-09 08:35:45 --> Model Class Initialized
INFO - 2016-03-09 08:35:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:35:45 --> Pagination Class Initialized
INFO - 2016-03-09 08:35:45 --> Helper loaded: text_helper
INFO - 2016-03-09 08:35:45 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:35:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:35:45 --> Final output sent to browser
DEBUG - 2016-03-09 11:35:45 --> Total execution time: 1.2425
INFO - 2016-03-09 08:36:12 --> Config Class Initialized
INFO - 2016-03-09 08:36:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:36:12 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:36:12 --> Utf8 Class Initialized
INFO - 2016-03-09 08:36:12 --> URI Class Initialized
INFO - 2016-03-09 08:36:12 --> Router Class Initialized
INFO - 2016-03-09 08:36:12 --> Output Class Initialized
INFO - 2016-03-09 08:36:12 --> Security Class Initialized
DEBUG - 2016-03-09 08:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:36:12 --> Input Class Initialized
INFO - 2016-03-09 08:36:12 --> Language Class Initialized
INFO - 2016-03-09 08:36:12 --> Loader Class Initialized
INFO - 2016-03-09 08:36:12 --> Helper loaded: url_helper
INFO - 2016-03-09 08:36:12 --> Helper loaded: file_helper
INFO - 2016-03-09 08:36:12 --> Helper loaded: date_helper
INFO - 2016-03-09 08:36:12 --> Helper loaded: form_helper
INFO - 2016-03-09 08:36:12 --> Database Driver Class Initialized
INFO - 2016-03-09 08:36:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:36:13 --> Controller Class Initialized
INFO - 2016-03-09 08:36:13 --> Model Class Initialized
INFO - 2016-03-09 08:36:13 --> Model Class Initialized
INFO - 2016-03-09 08:36:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:36:13 --> Pagination Class Initialized
INFO - 2016-03-09 08:36:13 --> Helper loaded: text_helper
INFO - 2016-03-09 08:36:13 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:36:13 --> Final output sent to browser
DEBUG - 2016-03-09 11:36:13 --> Total execution time: 1.2210
INFO - 2016-03-09 08:36:22 --> Config Class Initialized
INFO - 2016-03-09 08:36:22 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:36:22 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:36:22 --> Utf8 Class Initialized
INFO - 2016-03-09 08:36:22 --> URI Class Initialized
INFO - 2016-03-09 08:36:22 --> Router Class Initialized
INFO - 2016-03-09 08:36:22 --> Output Class Initialized
INFO - 2016-03-09 08:36:22 --> Security Class Initialized
DEBUG - 2016-03-09 08:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:36:22 --> Input Class Initialized
INFO - 2016-03-09 08:36:22 --> Language Class Initialized
INFO - 2016-03-09 08:36:22 --> Loader Class Initialized
INFO - 2016-03-09 08:36:22 --> Helper loaded: url_helper
INFO - 2016-03-09 08:36:22 --> Helper loaded: file_helper
INFO - 2016-03-09 08:36:22 --> Helper loaded: date_helper
INFO - 2016-03-09 08:36:22 --> Helper loaded: form_helper
INFO - 2016-03-09 08:36:22 --> Database Driver Class Initialized
INFO - 2016-03-09 08:36:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:36:23 --> Controller Class Initialized
INFO - 2016-03-09 08:36:23 --> Model Class Initialized
INFO - 2016-03-09 08:36:23 --> Model Class Initialized
INFO - 2016-03-09 08:36:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:36:23 --> Pagination Class Initialized
INFO - 2016-03-09 08:36:23 --> Helper loaded: text_helper
INFO - 2016-03-09 08:36:23 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:36:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:36:23 --> Final output sent to browser
DEBUG - 2016-03-09 11:36:23 --> Total execution time: 1.1195
INFO - 2016-03-09 08:36:25 --> Config Class Initialized
INFO - 2016-03-09 08:36:25 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:36:25 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:36:25 --> Utf8 Class Initialized
INFO - 2016-03-09 08:36:25 --> URI Class Initialized
INFO - 2016-03-09 08:36:25 --> Router Class Initialized
INFO - 2016-03-09 08:36:25 --> Output Class Initialized
INFO - 2016-03-09 08:36:25 --> Security Class Initialized
DEBUG - 2016-03-09 08:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:36:25 --> Input Class Initialized
INFO - 2016-03-09 08:36:25 --> Language Class Initialized
INFO - 2016-03-09 08:36:25 --> Loader Class Initialized
INFO - 2016-03-09 08:36:25 --> Helper loaded: url_helper
INFO - 2016-03-09 08:36:25 --> Helper loaded: file_helper
INFO - 2016-03-09 08:36:25 --> Helper loaded: date_helper
INFO - 2016-03-09 08:36:25 --> Helper loaded: form_helper
INFO - 2016-03-09 08:36:25 --> Database Driver Class Initialized
INFO - 2016-03-09 08:36:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:36:26 --> Controller Class Initialized
INFO - 2016-03-09 08:36:26 --> Model Class Initialized
INFO - 2016-03-09 08:36:26 --> Model Class Initialized
INFO - 2016-03-09 08:36:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:36:26 --> Pagination Class Initialized
INFO - 2016-03-09 08:36:26 --> Helper loaded: text_helper
INFO - 2016-03-09 08:36:26 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:36:26 --> Final output sent to browser
DEBUG - 2016-03-09 11:36:26 --> Total execution time: 1.1743
INFO - 2016-03-09 08:36:31 --> Config Class Initialized
INFO - 2016-03-09 08:36:31 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:36:31 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:36:31 --> Utf8 Class Initialized
INFO - 2016-03-09 08:36:31 --> URI Class Initialized
INFO - 2016-03-09 08:36:31 --> Router Class Initialized
INFO - 2016-03-09 08:36:31 --> Output Class Initialized
INFO - 2016-03-09 08:36:31 --> Security Class Initialized
DEBUG - 2016-03-09 08:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:36:31 --> Input Class Initialized
INFO - 2016-03-09 08:36:31 --> Language Class Initialized
INFO - 2016-03-09 08:36:31 --> Loader Class Initialized
INFO - 2016-03-09 08:36:31 --> Helper loaded: url_helper
INFO - 2016-03-09 08:36:31 --> Helper loaded: file_helper
INFO - 2016-03-09 08:36:31 --> Helper loaded: date_helper
INFO - 2016-03-09 08:36:31 --> Helper loaded: form_helper
INFO - 2016-03-09 08:36:32 --> Database Driver Class Initialized
INFO - 2016-03-09 08:36:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:36:33 --> Controller Class Initialized
INFO - 2016-03-09 08:36:33 --> Model Class Initialized
INFO - 2016-03-09 08:36:33 --> Model Class Initialized
INFO - 2016-03-09 08:36:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:36:33 --> Pagination Class Initialized
INFO - 2016-03-09 08:36:33 --> Helper loaded: text_helper
INFO - 2016-03-09 08:36:33 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:36:33 --> Final output sent to browser
DEBUG - 2016-03-09 11:36:33 --> Total execution time: 1.1510
INFO - 2016-03-09 08:36:35 --> Config Class Initialized
INFO - 2016-03-09 08:36:35 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:36:35 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:36:35 --> Utf8 Class Initialized
INFO - 2016-03-09 08:36:35 --> URI Class Initialized
INFO - 2016-03-09 08:36:35 --> Router Class Initialized
INFO - 2016-03-09 08:36:35 --> Output Class Initialized
INFO - 2016-03-09 08:36:35 --> Security Class Initialized
DEBUG - 2016-03-09 08:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:36:35 --> Input Class Initialized
INFO - 2016-03-09 08:36:35 --> Language Class Initialized
INFO - 2016-03-09 08:36:35 --> Loader Class Initialized
INFO - 2016-03-09 08:36:35 --> Helper loaded: url_helper
INFO - 2016-03-09 08:36:35 --> Helper loaded: file_helper
INFO - 2016-03-09 08:36:35 --> Helper loaded: date_helper
INFO - 2016-03-09 08:36:35 --> Helper loaded: form_helper
INFO - 2016-03-09 08:36:35 --> Database Driver Class Initialized
INFO - 2016-03-09 08:36:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:36:36 --> Controller Class Initialized
INFO - 2016-03-09 08:36:36 --> Model Class Initialized
INFO - 2016-03-09 08:36:36 --> Model Class Initialized
INFO - 2016-03-09 08:36:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:36:36 --> Pagination Class Initialized
INFO - 2016-03-09 08:36:36 --> Helper loaded: text_helper
INFO - 2016-03-09 08:36:36 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:36:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:36:36 --> Final output sent to browser
DEBUG - 2016-03-09 11:36:36 --> Total execution time: 1.1234
INFO - 2016-03-09 08:36:39 --> Config Class Initialized
INFO - 2016-03-09 08:36:39 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:36:39 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:36:39 --> Utf8 Class Initialized
INFO - 2016-03-09 08:36:39 --> URI Class Initialized
INFO - 2016-03-09 08:36:39 --> Router Class Initialized
INFO - 2016-03-09 08:36:39 --> Output Class Initialized
INFO - 2016-03-09 08:36:39 --> Security Class Initialized
DEBUG - 2016-03-09 08:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:36:39 --> Input Class Initialized
INFO - 2016-03-09 08:36:39 --> Language Class Initialized
INFO - 2016-03-09 08:36:39 --> Loader Class Initialized
INFO - 2016-03-09 08:36:39 --> Helper loaded: url_helper
INFO - 2016-03-09 08:36:39 --> Helper loaded: file_helper
INFO - 2016-03-09 08:36:39 --> Helper loaded: date_helper
INFO - 2016-03-09 08:36:39 --> Helper loaded: form_helper
INFO - 2016-03-09 08:36:39 --> Database Driver Class Initialized
INFO - 2016-03-09 08:36:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:36:40 --> Controller Class Initialized
INFO - 2016-03-09 08:36:40 --> Model Class Initialized
INFO - 2016-03-09 08:36:40 --> Model Class Initialized
INFO - 2016-03-09 08:36:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:36:40 --> Pagination Class Initialized
INFO - 2016-03-09 08:36:40 --> Helper loaded: text_helper
INFO - 2016-03-09 08:36:40 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:36:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:36:40 --> Final output sent to browser
DEBUG - 2016-03-09 11:36:40 --> Total execution time: 1.1502
INFO - 2016-03-09 08:37:33 --> Config Class Initialized
INFO - 2016-03-09 08:37:33 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:37:33 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:37:33 --> Utf8 Class Initialized
INFO - 2016-03-09 08:37:33 --> URI Class Initialized
INFO - 2016-03-09 08:37:33 --> Router Class Initialized
INFO - 2016-03-09 08:37:33 --> Output Class Initialized
INFO - 2016-03-09 08:37:33 --> Security Class Initialized
DEBUG - 2016-03-09 08:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:37:33 --> Input Class Initialized
INFO - 2016-03-09 08:37:33 --> Language Class Initialized
INFO - 2016-03-09 08:37:33 --> Loader Class Initialized
INFO - 2016-03-09 08:37:33 --> Helper loaded: url_helper
INFO - 2016-03-09 08:37:33 --> Helper loaded: file_helper
INFO - 2016-03-09 08:37:33 --> Helper loaded: date_helper
INFO - 2016-03-09 08:37:33 --> Helper loaded: form_helper
INFO - 2016-03-09 08:37:33 --> Database Driver Class Initialized
INFO - 2016-03-09 08:37:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:37:34 --> Controller Class Initialized
INFO - 2016-03-09 08:37:34 --> Model Class Initialized
INFO - 2016-03-09 08:37:35 --> Model Class Initialized
INFO - 2016-03-09 08:37:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:37:35 --> Pagination Class Initialized
INFO - 2016-03-09 08:37:35 --> Helper loaded: text_helper
INFO - 2016-03-09 08:37:35 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:37:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:37:35 --> Final output sent to browser
DEBUG - 2016-03-09 11:37:35 --> Total execution time: 1.1592
INFO - 2016-03-09 08:37:41 --> Config Class Initialized
INFO - 2016-03-09 08:37:41 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:37:41 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:37:41 --> Utf8 Class Initialized
INFO - 2016-03-09 08:37:41 --> URI Class Initialized
INFO - 2016-03-09 08:37:41 --> Router Class Initialized
INFO - 2016-03-09 08:37:41 --> Output Class Initialized
INFO - 2016-03-09 08:37:41 --> Security Class Initialized
DEBUG - 2016-03-09 08:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:37:41 --> Input Class Initialized
INFO - 2016-03-09 08:37:41 --> Language Class Initialized
INFO - 2016-03-09 08:37:41 --> Loader Class Initialized
INFO - 2016-03-09 08:37:41 --> Helper loaded: url_helper
INFO - 2016-03-09 08:37:41 --> Helper loaded: file_helper
INFO - 2016-03-09 08:37:41 --> Helper loaded: date_helper
INFO - 2016-03-09 08:37:41 --> Helper loaded: form_helper
INFO - 2016-03-09 08:37:41 --> Database Driver Class Initialized
INFO - 2016-03-09 08:37:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:37:42 --> Controller Class Initialized
INFO - 2016-03-09 08:37:42 --> Model Class Initialized
INFO - 2016-03-09 08:37:42 --> Model Class Initialized
INFO - 2016-03-09 08:37:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:37:42 --> Pagination Class Initialized
INFO - 2016-03-09 08:37:42 --> Helper loaded: text_helper
INFO - 2016-03-09 08:37:42 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:37:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:37:42 --> Final output sent to browser
DEBUG - 2016-03-09 11:37:42 --> Total execution time: 1.1487
INFO - 2016-03-09 08:37:43 --> Config Class Initialized
INFO - 2016-03-09 08:37:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:37:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:37:43 --> Utf8 Class Initialized
INFO - 2016-03-09 08:37:43 --> URI Class Initialized
INFO - 2016-03-09 08:37:43 --> Router Class Initialized
INFO - 2016-03-09 08:37:43 --> Output Class Initialized
INFO - 2016-03-09 08:37:43 --> Security Class Initialized
DEBUG - 2016-03-09 08:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:37:43 --> Input Class Initialized
INFO - 2016-03-09 08:37:43 --> Language Class Initialized
INFO - 2016-03-09 08:37:44 --> Loader Class Initialized
INFO - 2016-03-09 08:37:44 --> Helper loaded: url_helper
INFO - 2016-03-09 08:37:44 --> Helper loaded: file_helper
INFO - 2016-03-09 08:37:44 --> Helper loaded: date_helper
INFO - 2016-03-09 08:37:44 --> Helper loaded: form_helper
INFO - 2016-03-09 08:37:44 --> Database Driver Class Initialized
INFO - 2016-03-09 08:37:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:37:45 --> Controller Class Initialized
INFO - 2016-03-09 08:37:45 --> Model Class Initialized
INFO - 2016-03-09 08:37:45 --> Model Class Initialized
INFO - 2016-03-09 08:37:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:37:45 --> Pagination Class Initialized
INFO - 2016-03-09 08:37:45 --> Helper loaded: text_helper
INFO - 2016-03-09 08:37:45 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 11:37:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-09 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:37:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:37:45 --> Final output sent to browser
DEBUG - 2016-03-09 11:37:45 --> Total execution time: 1.3364
INFO - 2016-03-09 08:38:02 --> Config Class Initialized
INFO - 2016-03-09 08:38:02 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:38:02 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:38:02 --> Utf8 Class Initialized
INFO - 2016-03-09 08:38:02 --> URI Class Initialized
INFO - 2016-03-09 08:38:02 --> Router Class Initialized
INFO - 2016-03-09 08:38:02 --> Output Class Initialized
INFO - 2016-03-09 08:38:02 --> Security Class Initialized
DEBUG - 2016-03-09 08:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:38:02 --> Input Class Initialized
INFO - 2016-03-09 08:38:02 --> Language Class Initialized
INFO - 2016-03-09 08:38:02 --> Loader Class Initialized
INFO - 2016-03-09 08:38:02 --> Helper loaded: url_helper
INFO - 2016-03-09 08:38:02 --> Helper loaded: file_helper
INFO - 2016-03-09 08:38:02 --> Helper loaded: date_helper
INFO - 2016-03-09 08:38:02 --> Helper loaded: form_helper
INFO - 2016-03-09 08:38:02 --> Database Driver Class Initialized
INFO - 2016-03-09 08:38:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:38:03 --> Controller Class Initialized
INFO - 2016-03-09 08:38:03 --> Model Class Initialized
INFO - 2016-03-09 08:38:03 --> Model Class Initialized
INFO - 2016-03-09 08:38:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:38:03 --> Pagination Class Initialized
INFO - 2016-03-09 08:38:03 --> Helper loaded: text_helper
INFO - 2016-03-09 08:38:03 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
ERROR - 2016-03-09 11:38:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php 15
INFO - 2016-03-09 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:38:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:38:03 --> Final output sent to browser
DEBUG - 2016-03-09 11:38:03 --> Total execution time: 1.2858
INFO - 2016-03-09 08:38:07 --> Config Class Initialized
INFO - 2016-03-09 08:38:07 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:38:07 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:38:07 --> Utf8 Class Initialized
INFO - 2016-03-09 08:38:07 --> URI Class Initialized
INFO - 2016-03-09 08:38:07 --> Router Class Initialized
INFO - 2016-03-09 08:38:07 --> Output Class Initialized
INFO - 2016-03-09 08:38:07 --> Security Class Initialized
DEBUG - 2016-03-09 08:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:38:07 --> Input Class Initialized
INFO - 2016-03-09 08:38:07 --> Language Class Initialized
INFO - 2016-03-09 08:38:07 --> Loader Class Initialized
INFO - 2016-03-09 08:38:07 --> Helper loaded: url_helper
INFO - 2016-03-09 08:38:07 --> Helper loaded: file_helper
INFO - 2016-03-09 08:38:07 --> Helper loaded: date_helper
INFO - 2016-03-09 08:38:07 --> Helper loaded: form_helper
INFO - 2016-03-09 08:38:07 --> Database Driver Class Initialized
INFO - 2016-03-09 08:38:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:38:08 --> Controller Class Initialized
INFO - 2016-03-09 08:38:08 --> Model Class Initialized
INFO - 2016-03-09 08:38:08 --> Model Class Initialized
INFO - 2016-03-09 08:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:38:08 --> Pagination Class Initialized
INFO - 2016-03-09 08:38:08 --> Helper loaded: text_helper
INFO - 2016-03-09 08:38:08 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:38:08 --> Final output sent to browser
DEBUG - 2016-03-09 11:38:08 --> Total execution time: 1.1613
INFO - 2016-03-09 08:39:28 --> Config Class Initialized
INFO - 2016-03-09 08:39:28 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:39:28 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:39:28 --> Utf8 Class Initialized
INFO - 2016-03-09 08:39:28 --> URI Class Initialized
INFO - 2016-03-09 08:39:28 --> Router Class Initialized
INFO - 2016-03-09 08:39:28 --> Output Class Initialized
INFO - 2016-03-09 08:39:28 --> Security Class Initialized
DEBUG - 2016-03-09 08:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:39:28 --> Input Class Initialized
INFO - 2016-03-09 08:39:28 --> Language Class Initialized
INFO - 2016-03-09 08:39:28 --> Loader Class Initialized
INFO - 2016-03-09 08:39:28 --> Helper loaded: url_helper
INFO - 2016-03-09 08:39:28 --> Helper loaded: file_helper
INFO - 2016-03-09 08:39:28 --> Helper loaded: date_helper
INFO - 2016-03-09 08:39:28 --> Helper loaded: form_helper
INFO - 2016-03-09 08:39:28 --> Database Driver Class Initialized
INFO - 2016-03-09 08:39:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:39:29 --> Controller Class Initialized
INFO - 2016-03-09 08:39:29 --> Model Class Initialized
INFO - 2016-03-09 08:39:29 --> Model Class Initialized
INFO - 2016-03-09 08:39:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:39:29 --> Pagination Class Initialized
INFO - 2016-03-09 08:39:29 --> Helper loaded: text_helper
INFO - 2016-03-09 08:39:29 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:39:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:39:29 --> Final output sent to browser
DEBUG - 2016-03-09 11:39:29 --> Total execution time: 1.1448
INFO - 2016-03-09 08:39:43 --> Config Class Initialized
INFO - 2016-03-09 08:39:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:39:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:39:43 --> Utf8 Class Initialized
INFO - 2016-03-09 08:39:43 --> URI Class Initialized
INFO - 2016-03-09 08:39:43 --> Router Class Initialized
INFO - 2016-03-09 08:39:43 --> Output Class Initialized
INFO - 2016-03-09 08:39:43 --> Security Class Initialized
DEBUG - 2016-03-09 08:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:39:43 --> Input Class Initialized
INFO - 2016-03-09 08:39:43 --> Language Class Initialized
INFO - 2016-03-09 08:39:43 --> Loader Class Initialized
INFO - 2016-03-09 08:39:43 --> Helper loaded: url_helper
INFO - 2016-03-09 08:39:43 --> Helper loaded: file_helper
INFO - 2016-03-09 08:39:43 --> Helper loaded: date_helper
INFO - 2016-03-09 08:39:43 --> Helper loaded: form_helper
INFO - 2016-03-09 08:39:43 --> Database Driver Class Initialized
INFO - 2016-03-09 08:39:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:39:44 --> Controller Class Initialized
INFO - 2016-03-09 08:39:44 --> Model Class Initialized
INFO - 2016-03-09 08:39:44 --> Model Class Initialized
INFO - 2016-03-09 08:39:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:39:44 --> Pagination Class Initialized
INFO - 2016-03-09 08:39:44 --> Helper loaded: text_helper
INFO - 2016-03-09 08:39:44 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:39:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:39:44 --> Final output sent to browser
DEBUG - 2016-03-09 11:39:44 --> Total execution time: 1.1566
INFO - 2016-03-09 08:42:06 --> Config Class Initialized
INFO - 2016-03-09 08:42:06 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:06 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:06 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:06 --> URI Class Initialized
INFO - 2016-03-09 08:42:06 --> Router Class Initialized
INFO - 2016-03-09 08:42:06 --> Output Class Initialized
INFO - 2016-03-09 08:42:06 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:06 --> Input Class Initialized
INFO - 2016-03-09 08:42:06 --> Language Class Initialized
INFO - 2016-03-09 08:42:06 --> Loader Class Initialized
INFO - 2016-03-09 08:42:06 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:06 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:06 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:06 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:06 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:07 --> Controller Class Initialized
INFO - 2016-03-09 08:42:07 --> Model Class Initialized
INFO - 2016-03-09 08:42:07 --> Model Class Initialized
INFO - 2016-03-09 08:42:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:07 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:07 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:07 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:42:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:42:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:07 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:07 --> Total execution time: 1.1322
INFO - 2016-03-09 08:42:10 --> Config Class Initialized
INFO - 2016-03-09 08:42:10 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:10 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:10 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:10 --> URI Class Initialized
INFO - 2016-03-09 08:42:10 --> Router Class Initialized
INFO - 2016-03-09 08:42:10 --> Output Class Initialized
INFO - 2016-03-09 08:42:10 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:10 --> Input Class Initialized
INFO - 2016-03-09 08:42:10 --> Language Class Initialized
INFO - 2016-03-09 08:42:10 --> Loader Class Initialized
INFO - 2016-03-09 08:42:10 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:10 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:10 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:10 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:10 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:11 --> Controller Class Initialized
INFO - 2016-03-09 08:42:11 --> Model Class Initialized
INFO - 2016-03-09 08:42:11 --> Model Class Initialized
INFO - 2016-03-09 08:42:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:11 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:11 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:11 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:42:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:11 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:11 --> Total execution time: 1.1399
INFO - 2016-03-09 08:42:13 --> Config Class Initialized
INFO - 2016-03-09 08:42:13 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:13 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:13 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:13 --> URI Class Initialized
INFO - 2016-03-09 08:42:13 --> Router Class Initialized
INFO - 2016-03-09 08:42:13 --> Output Class Initialized
INFO - 2016-03-09 08:42:13 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:13 --> Input Class Initialized
INFO - 2016-03-09 08:42:13 --> Language Class Initialized
INFO - 2016-03-09 08:42:13 --> Loader Class Initialized
INFO - 2016-03-09 08:42:13 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:13 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:13 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:13 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:13 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:14 --> Controller Class Initialized
INFO - 2016-03-09 08:42:14 --> Model Class Initialized
INFO - 2016-03-09 08:42:14 --> Model Class Initialized
INFO - 2016-03-09 08:42:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:14 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:14 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:14 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:42:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:14 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:14 --> Total execution time: 1.1490
INFO - 2016-03-09 08:42:20 --> Config Class Initialized
INFO - 2016-03-09 08:42:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:20 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:20 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:20 --> URI Class Initialized
INFO - 2016-03-09 08:42:20 --> Router Class Initialized
INFO - 2016-03-09 08:42:20 --> Output Class Initialized
INFO - 2016-03-09 08:42:20 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:20 --> Input Class Initialized
INFO - 2016-03-09 08:42:20 --> Language Class Initialized
INFO - 2016-03-09 08:42:20 --> Loader Class Initialized
INFO - 2016-03-09 08:42:20 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:20 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:20 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:20 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:20 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:21 --> Controller Class Initialized
INFO - 2016-03-09 08:42:21 --> Model Class Initialized
INFO - 2016-03-09 08:42:21 --> Model Class Initialized
INFO - 2016-03-09 08:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:21 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:21 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:21 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:21 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:21 --> Total execution time: 1.1726
INFO - 2016-03-09 08:42:33 --> Config Class Initialized
INFO - 2016-03-09 08:42:33 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:33 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:33 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:33 --> URI Class Initialized
INFO - 2016-03-09 08:42:33 --> Router Class Initialized
INFO - 2016-03-09 08:42:33 --> Output Class Initialized
INFO - 2016-03-09 08:42:33 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:33 --> Input Class Initialized
INFO - 2016-03-09 08:42:33 --> Language Class Initialized
INFO - 2016-03-09 08:42:33 --> Loader Class Initialized
INFO - 2016-03-09 08:42:33 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:33 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:33 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:33 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:33 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:34 --> Controller Class Initialized
INFO - 2016-03-09 08:42:34 --> Model Class Initialized
INFO - 2016-03-09 08:42:34 --> Model Class Initialized
INFO - 2016-03-09 08:42:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:34 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:34 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:34 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:42:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:42:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:34 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:34 --> Total execution time: 1.1604
INFO - 2016-03-09 08:42:39 --> Config Class Initialized
INFO - 2016-03-09 08:42:39 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:39 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:39 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:39 --> URI Class Initialized
INFO - 2016-03-09 08:42:39 --> Router Class Initialized
INFO - 2016-03-09 08:42:39 --> Output Class Initialized
INFO - 2016-03-09 08:42:39 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:39 --> Input Class Initialized
INFO - 2016-03-09 08:42:39 --> Language Class Initialized
INFO - 2016-03-09 08:42:39 --> Loader Class Initialized
INFO - 2016-03-09 08:42:39 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:39 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:39 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:39 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:39 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:40 --> Controller Class Initialized
INFO - 2016-03-09 08:42:40 --> Model Class Initialized
INFO - 2016-03-09 08:42:40 --> Model Class Initialized
INFO - 2016-03-09 08:42:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:41 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:41 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:41 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:42:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:41 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:41 --> Total execution time: 1.1531
INFO - 2016-03-09 08:42:43 --> Config Class Initialized
INFO - 2016-03-09 08:42:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:43 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:43 --> URI Class Initialized
INFO - 2016-03-09 08:42:43 --> Router Class Initialized
INFO - 2016-03-09 08:42:43 --> Output Class Initialized
INFO - 2016-03-09 08:42:43 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:43 --> Input Class Initialized
INFO - 2016-03-09 08:42:43 --> Language Class Initialized
INFO - 2016-03-09 08:42:43 --> Loader Class Initialized
INFO - 2016-03-09 08:42:43 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:43 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:43 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:43 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:43 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:44 --> Controller Class Initialized
INFO - 2016-03-09 08:42:44 --> Model Class Initialized
INFO - 2016-03-09 08:42:44 --> Model Class Initialized
INFO - 2016-03-09 08:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:44 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:44 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:44 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:44 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:44 --> Total execution time: 1.1817
INFO - 2016-03-09 08:42:54 --> Config Class Initialized
INFO - 2016-03-09 08:42:54 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:54 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:54 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:54 --> URI Class Initialized
INFO - 2016-03-09 08:42:54 --> Router Class Initialized
INFO - 2016-03-09 08:42:54 --> Output Class Initialized
INFO - 2016-03-09 08:42:54 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:54 --> Input Class Initialized
INFO - 2016-03-09 08:42:54 --> Language Class Initialized
INFO - 2016-03-09 08:42:54 --> Loader Class Initialized
INFO - 2016-03-09 08:42:54 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:54 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:54 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:54 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:54 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:55 --> Controller Class Initialized
INFO - 2016-03-09 08:42:55 --> Model Class Initialized
INFO - 2016-03-09 08:42:55 --> Model Class Initialized
INFO - 2016-03-09 08:42:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:55 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:55 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:55 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 11:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 11:42:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:55 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:55 --> Total execution time: 1.1257
INFO - 2016-03-09 08:42:57 --> Config Class Initialized
INFO - 2016-03-09 08:42:57 --> Hooks Class Initialized
DEBUG - 2016-03-09 08:42:57 --> UTF-8 Support Enabled
INFO - 2016-03-09 08:42:57 --> Utf8 Class Initialized
INFO - 2016-03-09 08:42:57 --> URI Class Initialized
INFO - 2016-03-09 08:42:57 --> Router Class Initialized
INFO - 2016-03-09 08:42:57 --> Output Class Initialized
INFO - 2016-03-09 08:42:57 --> Security Class Initialized
DEBUG - 2016-03-09 08:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 08:42:57 --> Input Class Initialized
INFO - 2016-03-09 08:42:57 --> Language Class Initialized
INFO - 2016-03-09 08:42:57 --> Loader Class Initialized
INFO - 2016-03-09 08:42:57 --> Helper loaded: url_helper
INFO - 2016-03-09 08:42:57 --> Helper loaded: file_helper
INFO - 2016-03-09 08:42:57 --> Helper loaded: date_helper
INFO - 2016-03-09 08:42:57 --> Helper loaded: form_helper
INFO - 2016-03-09 08:42:57 --> Database Driver Class Initialized
INFO - 2016-03-09 08:42:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 08:42:58 --> Controller Class Initialized
INFO - 2016-03-09 08:42:58 --> Model Class Initialized
INFO - 2016-03-09 08:42:58 --> Model Class Initialized
INFO - 2016-03-09 08:42:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 08:42:58 --> Pagination Class Initialized
INFO - 2016-03-09 08:42:58 --> Helper loaded: text_helper
INFO - 2016-03-09 08:42:58 --> Helper loaded: cookie_helper
INFO - 2016-03-09 11:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 11:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 11:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 11:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 11:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 11:42:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 11:42:58 --> Final output sent to browser
DEBUG - 2016-03-09 11:42:58 --> Total execution time: 1.2420
INFO - 2016-03-09 10:09:05 --> Config Class Initialized
INFO - 2016-03-09 10:09:05 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:09:05 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:09:05 --> Utf8 Class Initialized
INFO - 2016-03-09 10:09:05 --> URI Class Initialized
INFO - 2016-03-09 10:09:05 --> Router Class Initialized
INFO - 2016-03-09 10:09:05 --> Output Class Initialized
INFO - 2016-03-09 10:09:05 --> Security Class Initialized
DEBUG - 2016-03-09 10:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:09:05 --> Input Class Initialized
INFO - 2016-03-09 10:09:05 --> Language Class Initialized
INFO - 2016-03-09 10:09:05 --> Loader Class Initialized
INFO - 2016-03-09 10:09:05 --> Helper loaded: url_helper
INFO - 2016-03-09 10:09:05 --> Helper loaded: file_helper
INFO - 2016-03-09 10:09:05 --> Helper loaded: date_helper
INFO - 2016-03-09 10:09:05 --> Helper loaded: form_helper
INFO - 2016-03-09 10:09:05 --> Database Driver Class Initialized
INFO - 2016-03-09 10:09:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:09:06 --> Controller Class Initialized
INFO - 2016-03-09 10:09:06 --> Model Class Initialized
INFO - 2016-03-09 10:09:06 --> Model Class Initialized
INFO - 2016-03-09 10:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:09:06 --> Pagination Class Initialized
INFO - 2016-03-09 10:09:06 --> Helper loaded: text_helper
INFO - 2016-03-09 10:09:06 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:09:06 --> Final output sent to browser
DEBUG - 2016-03-09 13:09:06 --> Total execution time: 1.1793
INFO - 2016-03-09 10:09:20 --> Config Class Initialized
INFO - 2016-03-09 10:09:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:09:20 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:09:20 --> Utf8 Class Initialized
INFO - 2016-03-09 10:09:20 --> URI Class Initialized
INFO - 2016-03-09 10:09:20 --> Router Class Initialized
INFO - 2016-03-09 10:09:20 --> Output Class Initialized
INFO - 2016-03-09 10:09:20 --> Security Class Initialized
DEBUG - 2016-03-09 10:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:09:20 --> Input Class Initialized
INFO - 2016-03-09 10:09:20 --> Language Class Initialized
ERROR - 2016-03-09 10:09:21 --> Severity: Parsing Error --> syntax error, unexpected '$config' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 143
INFO - 2016-03-09 10:09:30 --> Config Class Initialized
INFO - 2016-03-09 10:09:30 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:09:30 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:09:30 --> Utf8 Class Initialized
INFO - 2016-03-09 10:09:30 --> URI Class Initialized
INFO - 2016-03-09 10:09:30 --> Router Class Initialized
INFO - 2016-03-09 10:09:30 --> Output Class Initialized
INFO - 2016-03-09 10:09:30 --> Security Class Initialized
DEBUG - 2016-03-09 10:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:09:30 --> Input Class Initialized
INFO - 2016-03-09 10:09:30 --> Language Class Initialized
INFO - 2016-03-09 10:09:30 --> Loader Class Initialized
INFO - 2016-03-09 10:09:30 --> Helper loaded: url_helper
INFO - 2016-03-09 10:09:30 --> Helper loaded: file_helper
INFO - 2016-03-09 10:09:30 --> Helper loaded: date_helper
INFO - 2016-03-09 10:09:30 --> Helper loaded: form_helper
INFO - 2016-03-09 10:09:30 --> Database Driver Class Initialized
INFO - 2016-03-09 10:09:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:09:31 --> Controller Class Initialized
INFO - 2016-03-09 10:09:31 --> Model Class Initialized
INFO - 2016-03-09 10:09:31 --> Model Class Initialized
INFO - 2016-03-09 10:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:09:31 --> Pagination Class Initialized
INFO - 2016-03-09 10:09:31 --> Helper loaded: text_helper
INFO - 2016-03-09 10:09:31 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:09:31 --> Final output sent to browser
DEBUG - 2016-03-09 13:09:31 --> Total execution time: 1.1159
INFO - 2016-03-09 10:09:33 --> Config Class Initialized
INFO - 2016-03-09 10:09:33 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:09:33 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:09:33 --> Utf8 Class Initialized
INFO - 2016-03-09 10:09:33 --> URI Class Initialized
INFO - 2016-03-09 10:09:33 --> Router Class Initialized
INFO - 2016-03-09 10:09:33 --> Output Class Initialized
INFO - 2016-03-09 10:09:33 --> Security Class Initialized
DEBUG - 2016-03-09 10:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:09:33 --> Input Class Initialized
INFO - 2016-03-09 10:09:33 --> Language Class Initialized
INFO - 2016-03-09 10:09:33 --> Loader Class Initialized
INFO - 2016-03-09 10:09:33 --> Helper loaded: url_helper
INFO - 2016-03-09 10:09:33 --> Helper loaded: file_helper
INFO - 2016-03-09 10:09:33 --> Helper loaded: date_helper
INFO - 2016-03-09 10:09:33 --> Helper loaded: form_helper
INFO - 2016-03-09 10:09:33 --> Database Driver Class Initialized
INFO - 2016-03-09 10:09:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:09:34 --> Controller Class Initialized
INFO - 2016-03-09 10:09:34 --> Model Class Initialized
INFO - 2016-03-09 10:09:34 --> Model Class Initialized
INFO - 2016-03-09 10:09:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:09:34 --> Pagination Class Initialized
INFO - 2016-03-09 10:09:34 --> Helper loaded: text_helper
INFO - 2016-03-09 10:09:34 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:09:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:09:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:09:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:09:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:09:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:09:34 --> Final output sent to browser
DEBUG - 2016-03-09 13:09:34 --> Total execution time: 1.1212
INFO - 2016-03-09 10:11:10 --> Config Class Initialized
INFO - 2016-03-09 10:11:10 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:11:10 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:11:10 --> Utf8 Class Initialized
INFO - 2016-03-09 10:11:10 --> URI Class Initialized
INFO - 2016-03-09 10:11:10 --> Router Class Initialized
INFO - 2016-03-09 10:11:10 --> Output Class Initialized
INFO - 2016-03-09 10:11:10 --> Security Class Initialized
DEBUG - 2016-03-09 10:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:11:10 --> Input Class Initialized
INFO - 2016-03-09 10:11:10 --> Language Class Initialized
INFO - 2016-03-09 10:11:10 --> Loader Class Initialized
INFO - 2016-03-09 10:11:10 --> Helper loaded: url_helper
INFO - 2016-03-09 10:11:10 --> Helper loaded: file_helper
INFO - 2016-03-09 10:11:10 --> Helper loaded: date_helper
INFO - 2016-03-09 10:11:10 --> Helper loaded: form_helper
INFO - 2016-03-09 10:11:10 --> Database Driver Class Initialized
INFO - 2016-03-09 10:11:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:11:11 --> Controller Class Initialized
INFO - 2016-03-09 10:11:11 --> Model Class Initialized
INFO - 2016-03-09 10:11:11 --> Model Class Initialized
INFO - 2016-03-09 10:11:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:11:11 --> Pagination Class Initialized
INFO - 2016-03-09 10:11:11 --> Helper loaded: text_helper
INFO - 2016-03-09 10:11:11 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:11:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 13:11:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:11:12 --> Final output sent to browser
DEBUG - 2016-03-09 13:11:12 --> Total execution time: 1.1443
INFO - 2016-03-09 10:11:25 --> Config Class Initialized
INFO - 2016-03-09 10:11:25 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:11:25 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:11:25 --> Utf8 Class Initialized
INFO - 2016-03-09 10:11:25 --> URI Class Initialized
INFO - 2016-03-09 10:11:25 --> Router Class Initialized
INFO - 2016-03-09 10:11:25 --> Output Class Initialized
INFO - 2016-03-09 10:11:25 --> Security Class Initialized
DEBUG - 2016-03-09 10:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:11:25 --> Input Class Initialized
INFO - 2016-03-09 10:11:25 --> Language Class Initialized
INFO - 2016-03-09 10:11:25 --> Loader Class Initialized
INFO - 2016-03-09 10:11:25 --> Helper loaded: url_helper
INFO - 2016-03-09 10:11:25 --> Helper loaded: file_helper
INFO - 2016-03-09 10:11:25 --> Helper loaded: date_helper
INFO - 2016-03-09 10:11:25 --> Helper loaded: form_helper
INFO - 2016-03-09 10:11:25 --> Database Driver Class Initialized
INFO - 2016-03-09 10:11:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:11:26 --> Controller Class Initialized
INFO - 2016-03-09 10:11:26 --> Model Class Initialized
INFO - 2016-03-09 10:11:26 --> Model Class Initialized
INFO - 2016-03-09 10:11:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:11:26 --> Pagination Class Initialized
INFO - 2016-03-09 10:11:26 --> Helper loaded: text_helper
INFO - 2016-03-09 10:11:26 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:11:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:11:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:11:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:11:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:11:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:11:26 --> Final output sent to browser
DEBUG - 2016-03-09 13:11:26 --> Total execution time: 1.1698
INFO - 2016-03-09 10:11:31 --> Config Class Initialized
INFO - 2016-03-09 10:11:31 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:11:31 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:11:31 --> Utf8 Class Initialized
INFO - 2016-03-09 10:11:31 --> URI Class Initialized
INFO - 2016-03-09 10:11:31 --> Router Class Initialized
INFO - 2016-03-09 10:11:31 --> Output Class Initialized
INFO - 2016-03-09 10:11:31 --> Security Class Initialized
DEBUG - 2016-03-09 10:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:11:31 --> Input Class Initialized
INFO - 2016-03-09 10:11:31 --> Language Class Initialized
INFO - 2016-03-09 10:11:31 --> Loader Class Initialized
INFO - 2016-03-09 10:11:31 --> Helper loaded: url_helper
INFO - 2016-03-09 10:11:31 --> Helper loaded: file_helper
INFO - 2016-03-09 10:11:31 --> Helper loaded: date_helper
INFO - 2016-03-09 10:11:31 --> Helper loaded: form_helper
INFO - 2016-03-09 10:11:31 --> Database Driver Class Initialized
INFO - 2016-03-09 10:11:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:11:32 --> Controller Class Initialized
INFO - 2016-03-09 10:11:32 --> Model Class Initialized
INFO - 2016-03-09 10:11:32 --> Model Class Initialized
INFO - 2016-03-09 10:11:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:11:32 --> Pagination Class Initialized
INFO - 2016-03-09 10:11:32 --> Helper loaded: text_helper
INFO - 2016-03-09 10:11:32 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:11:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:11:32 --> Final output sent to browser
DEBUG - 2016-03-09 13:11:32 --> Total execution time: 1.1256
INFO - 2016-03-09 10:11:40 --> Config Class Initialized
INFO - 2016-03-09 10:11:40 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:11:40 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:11:40 --> Utf8 Class Initialized
INFO - 2016-03-09 10:11:40 --> URI Class Initialized
INFO - 2016-03-09 10:11:40 --> Router Class Initialized
INFO - 2016-03-09 10:11:40 --> Output Class Initialized
INFO - 2016-03-09 10:11:40 --> Security Class Initialized
DEBUG - 2016-03-09 10:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:11:40 --> Input Class Initialized
INFO - 2016-03-09 10:11:40 --> Language Class Initialized
INFO - 2016-03-09 10:11:40 --> Loader Class Initialized
INFO - 2016-03-09 10:11:40 --> Helper loaded: url_helper
INFO - 2016-03-09 10:11:40 --> Helper loaded: file_helper
INFO - 2016-03-09 10:11:40 --> Helper loaded: date_helper
INFO - 2016-03-09 10:11:40 --> Helper loaded: form_helper
INFO - 2016-03-09 10:11:40 --> Database Driver Class Initialized
INFO - 2016-03-09 10:11:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:11:41 --> Controller Class Initialized
INFO - 2016-03-09 10:11:41 --> Model Class Initialized
INFO - 2016-03-09 10:11:41 --> Model Class Initialized
INFO - 2016-03-09 10:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:11:41 --> Pagination Class Initialized
INFO - 2016-03-09 10:11:41 --> Helper loaded: text_helper
INFO - 2016-03-09 10:11:41 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 13:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:11:41 --> Final output sent to browser
DEBUG - 2016-03-09 13:11:41 --> Total execution time: 1.1587
INFO - 2016-03-09 10:12:30 --> Config Class Initialized
INFO - 2016-03-09 10:12:30 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:12:30 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:12:30 --> Utf8 Class Initialized
INFO - 2016-03-09 10:12:30 --> URI Class Initialized
INFO - 2016-03-09 10:12:30 --> Router Class Initialized
INFO - 2016-03-09 10:12:30 --> Output Class Initialized
INFO - 2016-03-09 10:12:30 --> Security Class Initialized
DEBUG - 2016-03-09 10:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:12:30 --> Input Class Initialized
INFO - 2016-03-09 10:12:30 --> Language Class Initialized
INFO - 2016-03-09 10:12:30 --> Loader Class Initialized
INFO - 2016-03-09 10:12:30 --> Helper loaded: url_helper
INFO - 2016-03-09 10:12:30 --> Helper loaded: file_helper
INFO - 2016-03-09 10:12:30 --> Helper loaded: date_helper
INFO - 2016-03-09 10:12:30 --> Helper loaded: form_helper
INFO - 2016-03-09 10:12:30 --> Database Driver Class Initialized
INFO - 2016-03-09 10:12:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:12:31 --> Controller Class Initialized
INFO - 2016-03-09 10:12:31 --> Model Class Initialized
INFO - 2016-03-09 10:12:31 --> Model Class Initialized
INFO - 2016-03-09 10:12:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:12:31 --> Pagination Class Initialized
INFO - 2016-03-09 10:12:31 --> Helper loaded: text_helper
INFO - 2016-03-09 10:12:31 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 13:12:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:12:31 --> Final output sent to browser
DEBUG - 2016-03-09 13:12:31 --> Total execution time: 1.2014
INFO - 2016-03-09 10:17:30 --> Config Class Initialized
INFO - 2016-03-09 10:17:30 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:17:30 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:17:30 --> Utf8 Class Initialized
INFO - 2016-03-09 10:17:30 --> URI Class Initialized
INFO - 2016-03-09 10:17:30 --> Router Class Initialized
INFO - 2016-03-09 10:17:30 --> Output Class Initialized
INFO - 2016-03-09 10:17:30 --> Security Class Initialized
DEBUG - 2016-03-09 10:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:17:30 --> Input Class Initialized
INFO - 2016-03-09 10:17:30 --> Language Class Initialized
INFO - 2016-03-09 10:17:30 --> Loader Class Initialized
INFO - 2016-03-09 10:17:30 --> Helper loaded: url_helper
INFO - 2016-03-09 10:17:30 --> Helper loaded: file_helper
INFO - 2016-03-09 10:17:30 --> Helper loaded: date_helper
INFO - 2016-03-09 10:17:30 --> Helper loaded: form_helper
INFO - 2016-03-09 10:17:30 --> Database Driver Class Initialized
INFO - 2016-03-09 10:17:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:17:31 --> Controller Class Initialized
INFO - 2016-03-09 10:17:31 --> Model Class Initialized
INFO - 2016-03-09 10:17:31 --> Model Class Initialized
INFO - 2016-03-09 10:17:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:17:31 --> Pagination Class Initialized
INFO - 2016-03-09 10:17:31 --> Helper loaded: text_helper
INFO - 2016-03-09 10:17:31 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:17:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:17:31 --> Final output sent to browser
DEBUG - 2016-03-09 13:17:31 --> Total execution time: 1.1325
INFO - 2016-03-09 10:18:49 --> Config Class Initialized
INFO - 2016-03-09 10:18:49 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:18:49 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:18:49 --> Utf8 Class Initialized
INFO - 2016-03-09 10:18:49 --> URI Class Initialized
INFO - 2016-03-09 10:18:49 --> Router Class Initialized
INFO - 2016-03-09 10:18:49 --> Output Class Initialized
INFO - 2016-03-09 10:18:49 --> Security Class Initialized
DEBUG - 2016-03-09 10:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:18:49 --> Input Class Initialized
INFO - 2016-03-09 10:18:49 --> Language Class Initialized
INFO - 2016-03-09 10:18:49 --> Loader Class Initialized
INFO - 2016-03-09 10:18:49 --> Helper loaded: url_helper
INFO - 2016-03-09 10:18:49 --> Helper loaded: file_helper
INFO - 2016-03-09 10:18:49 --> Helper loaded: date_helper
INFO - 2016-03-09 10:18:49 --> Helper loaded: form_helper
INFO - 2016-03-09 10:18:49 --> Database Driver Class Initialized
INFO - 2016-03-09 10:18:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:18:50 --> Controller Class Initialized
INFO - 2016-03-09 10:18:50 --> Model Class Initialized
INFO - 2016-03-09 10:18:50 --> Model Class Initialized
INFO - 2016-03-09 10:18:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:18:50 --> Pagination Class Initialized
INFO - 2016-03-09 10:18:50 --> Helper loaded: text_helper
INFO - 2016-03-09 10:18:50 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:18:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:18:50 --> Final output sent to browser
DEBUG - 2016-03-09 13:18:50 --> Total execution time: 1.1687
INFO - 2016-03-09 10:18:57 --> Config Class Initialized
INFO - 2016-03-09 10:18:57 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:18:57 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:18:57 --> Utf8 Class Initialized
INFO - 2016-03-09 10:18:57 --> URI Class Initialized
INFO - 2016-03-09 10:18:57 --> Router Class Initialized
INFO - 2016-03-09 10:18:57 --> Output Class Initialized
INFO - 2016-03-09 10:18:57 --> Security Class Initialized
DEBUG - 2016-03-09 10:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:18:57 --> Input Class Initialized
INFO - 2016-03-09 10:18:57 --> Language Class Initialized
INFO - 2016-03-09 10:18:57 --> Loader Class Initialized
INFO - 2016-03-09 10:18:57 --> Helper loaded: url_helper
INFO - 2016-03-09 10:18:57 --> Helper loaded: file_helper
INFO - 2016-03-09 10:18:57 --> Helper loaded: date_helper
INFO - 2016-03-09 10:18:57 --> Helper loaded: form_helper
INFO - 2016-03-09 10:18:57 --> Database Driver Class Initialized
INFO - 2016-03-09 10:18:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:18:58 --> Controller Class Initialized
INFO - 2016-03-09 10:18:58 --> Model Class Initialized
INFO - 2016-03-09 10:18:58 --> Model Class Initialized
INFO - 2016-03-09 10:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:18:58 --> Pagination Class Initialized
INFO - 2016-03-09 10:18:58 --> Helper loaded: text_helper
INFO - 2016-03-09 10:18:58 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:18:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:18:58 --> Final output sent to browser
DEBUG - 2016-03-09 13:18:58 --> Total execution time: 1.1239
INFO - 2016-03-09 10:19:03 --> Config Class Initialized
INFO - 2016-03-09 10:19:03 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:19:03 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:19:03 --> Utf8 Class Initialized
INFO - 2016-03-09 10:19:03 --> URI Class Initialized
INFO - 2016-03-09 10:19:03 --> Router Class Initialized
INFO - 2016-03-09 10:19:03 --> Output Class Initialized
INFO - 2016-03-09 10:19:03 --> Security Class Initialized
DEBUG - 2016-03-09 10:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:19:03 --> Input Class Initialized
INFO - 2016-03-09 10:19:03 --> Language Class Initialized
INFO - 2016-03-09 10:19:03 --> Loader Class Initialized
INFO - 2016-03-09 10:19:03 --> Helper loaded: url_helper
INFO - 2016-03-09 10:19:03 --> Helper loaded: file_helper
INFO - 2016-03-09 10:19:03 --> Helper loaded: date_helper
INFO - 2016-03-09 10:19:03 --> Helper loaded: form_helper
INFO - 2016-03-09 10:19:03 --> Database Driver Class Initialized
INFO - 2016-03-09 10:19:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:19:04 --> Controller Class Initialized
INFO - 2016-03-09 10:19:04 --> Model Class Initialized
INFO - 2016-03-09 10:19:04 --> Model Class Initialized
INFO - 2016-03-09 10:19:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:19:04 --> Pagination Class Initialized
INFO - 2016-03-09 10:19:04 --> Helper loaded: text_helper
INFO - 2016-03-09 10:19:04 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 13:19:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:19:04 --> Final output sent to browser
DEBUG - 2016-03-09 13:19:04 --> Total execution time: 1.1438
INFO - 2016-03-09 10:20:16 --> Config Class Initialized
INFO - 2016-03-09 10:20:16 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:20:16 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:20:16 --> Utf8 Class Initialized
INFO - 2016-03-09 10:20:16 --> URI Class Initialized
INFO - 2016-03-09 10:20:16 --> Router Class Initialized
INFO - 2016-03-09 10:20:16 --> Output Class Initialized
INFO - 2016-03-09 10:20:16 --> Security Class Initialized
DEBUG - 2016-03-09 10:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:20:16 --> Input Class Initialized
INFO - 2016-03-09 10:20:16 --> Language Class Initialized
INFO - 2016-03-09 10:20:16 --> Loader Class Initialized
INFO - 2016-03-09 10:20:16 --> Helper loaded: url_helper
INFO - 2016-03-09 10:20:16 --> Helper loaded: file_helper
INFO - 2016-03-09 10:20:16 --> Helper loaded: date_helper
INFO - 2016-03-09 10:20:16 --> Helper loaded: form_helper
INFO - 2016-03-09 10:20:16 --> Database Driver Class Initialized
INFO - 2016-03-09 10:20:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:20:17 --> Controller Class Initialized
INFO - 2016-03-09 10:20:18 --> Model Class Initialized
INFO - 2016-03-09 10:20:18 --> Model Class Initialized
INFO - 2016-03-09 10:20:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:20:18 --> Pagination Class Initialized
INFO - 2016-03-09 10:20:18 --> Helper loaded: text_helper
INFO - 2016-03-09 10:20:18 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:20:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:20:18 --> Final output sent to browser
DEBUG - 2016-03-09 13:20:18 --> Total execution time: 1.1281
INFO - 2016-03-09 10:21:14 --> Config Class Initialized
INFO - 2016-03-09 10:21:14 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:21:14 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:21:14 --> Utf8 Class Initialized
INFO - 2016-03-09 10:21:14 --> URI Class Initialized
INFO - 2016-03-09 10:21:14 --> Router Class Initialized
INFO - 2016-03-09 10:21:14 --> Output Class Initialized
INFO - 2016-03-09 10:21:14 --> Security Class Initialized
DEBUG - 2016-03-09 10:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:21:14 --> Input Class Initialized
INFO - 2016-03-09 10:21:14 --> Language Class Initialized
INFO - 2016-03-09 10:21:14 --> Loader Class Initialized
INFO - 2016-03-09 10:21:14 --> Helper loaded: url_helper
INFO - 2016-03-09 10:21:14 --> Helper loaded: file_helper
INFO - 2016-03-09 10:21:14 --> Helper loaded: date_helper
INFO - 2016-03-09 10:21:14 --> Helper loaded: form_helper
INFO - 2016-03-09 10:21:14 --> Database Driver Class Initialized
INFO - 2016-03-09 10:21:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:21:15 --> Controller Class Initialized
INFO - 2016-03-09 10:21:15 --> Model Class Initialized
INFO - 2016-03-09 10:21:15 --> Model Class Initialized
INFO - 2016-03-09 10:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:21:15 --> Pagination Class Initialized
INFO - 2016-03-09 10:21:15 --> Helper loaded: text_helper
INFO - 2016-03-09 10:21:15 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:21:15 --> Final output sent to browser
DEBUG - 2016-03-09 13:21:15 --> Total execution time: 1.1498
INFO - 2016-03-09 10:22:13 --> Config Class Initialized
INFO - 2016-03-09 10:22:13 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:22:13 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:22:13 --> Utf8 Class Initialized
INFO - 2016-03-09 10:22:13 --> URI Class Initialized
INFO - 2016-03-09 10:22:13 --> Router Class Initialized
INFO - 2016-03-09 10:22:13 --> Output Class Initialized
INFO - 2016-03-09 10:22:13 --> Security Class Initialized
DEBUG - 2016-03-09 10:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:22:13 --> Input Class Initialized
INFO - 2016-03-09 10:22:13 --> Language Class Initialized
INFO - 2016-03-09 10:22:13 --> Loader Class Initialized
INFO - 2016-03-09 10:22:13 --> Helper loaded: url_helper
INFO - 2016-03-09 10:22:13 --> Helper loaded: file_helper
INFO - 2016-03-09 10:22:13 --> Helper loaded: date_helper
INFO - 2016-03-09 10:22:13 --> Helper loaded: form_helper
INFO - 2016-03-09 10:22:13 --> Database Driver Class Initialized
INFO - 2016-03-09 10:22:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:22:14 --> Controller Class Initialized
INFO - 2016-03-09 10:22:14 --> Model Class Initialized
INFO - 2016-03-09 10:22:14 --> Model Class Initialized
INFO - 2016-03-09 10:22:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:22:14 --> Pagination Class Initialized
INFO - 2016-03-09 10:22:14 --> Helper loaded: text_helper
INFO - 2016-03-09 10:22:14 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:22:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:22:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:22:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:22:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:22:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:22:14 --> Final output sent to browser
DEBUG - 2016-03-09 13:22:14 --> Total execution time: 1.1462
INFO - 2016-03-09 10:22:58 --> Config Class Initialized
INFO - 2016-03-09 10:22:58 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:22:58 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:22:58 --> Utf8 Class Initialized
INFO - 2016-03-09 10:22:58 --> URI Class Initialized
INFO - 2016-03-09 10:22:58 --> Router Class Initialized
INFO - 2016-03-09 10:22:58 --> Output Class Initialized
INFO - 2016-03-09 10:22:58 --> Security Class Initialized
DEBUG - 2016-03-09 10:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:22:58 --> Input Class Initialized
INFO - 2016-03-09 10:22:58 --> Language Class Initialized
INFO - 2016-03-09 10:22:58 --> Loader Class Initialized
INFO - 2016-03-09 10:22:58 --> Helper loaded: url_helper
INFO - 2016-03-09 10:22:58 --> Helper loaded: file_helper
INFO - 2016-03-09 10:22:58 --> Helper loaded: date_helper
INFO - 2016-03-09 10:22:58 --> Helper loaded: form_helper
INFO - 2016-03-09 10:22:58 --> Database Driver Class Initialized
INFO - 2016-03-09 10:22:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:22:59 --> Controller Class Initialized
INFO - 2016-03-09 10:22:59 --> Model Class Initialized
INFO - 2016-03-09 10:22:59 --> Model Class Initialized
INFO - 2016-03-09 10:22:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:22:59 --> Pagination Class Initialized
INFO - 2016-03-09 10:22:59 --> Helper loaded: text_helper
INFO - 2016-03-09 10:23:00 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 13:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:23:00 --> Final output sent to browser
DEBUG - 2016-03-09 13:23:00 --> Total execution time: 1.1701
INFO - 2016-03-09 10:23:22 --> Config Class Initialized
INFO - 2016-03-09 10:23:22 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:23:22 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:23:22 --> Utf8 Class Initialized
INFO - 2016-03-09 10:23:22 --> URI Class Initialized
INFO - 2016-03-09 10:23:22 --> Router Class Initialized
INFO - 2016-03-09 10:23:22 --> Output Class Initialized
INFO - 2016-03-09 10:23:22 --> Security Class Initialized
DEBUG - 2016-03-09 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:23:22 --> Input Class Initialized
INFO - 2016-03-09 10:23:22 --> Language Class Initialized
INFO - 2016-03-09 10:23:22 --> Loader Class Initialized
INFO - 2016-03-09 10:23:22 --> Helper loaded: url_helper
INFO - 2016-03-09 10:23:22 --> Helper loaded: file_helper
INFO - 2016-03-09 10:23:22 --> Helper loaded: date_helper
INFO - 2016-03-09 10:23:22 --> Helper loaded: form_helper
INFO - 2016-03-09 10:23:22 --> Database Driver Class Initialized
INFO - 2016-03-09 10:23:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:23:23 --> Controller Class Initialized
INFO - 2016-03-09 10:23:23 --> Model Class Initialized
INFO - 2016-03-09 10:23:23 --> Model Class Initialized
INFO - 2016-03-09 10:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:23:23 --> Pagination Class Initialized
INFO - 2016-03-09 10:23:23 --> Helper loaded: text_helper
INFO - 2016-03-09 10:23:23 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:23:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:23:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:23:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:23:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:23:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:23:23 --> Final output sent to browser
DEBUG - 2016-03-09 13:23:23 --> Total execution time: 1.1221
INFO - 2016-03-09 10:24:56 --> Config Class Initialized
INFO - 2016-03-09 10:24:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:24:56 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:24:56 --> Utf8 Class Initialized
INFO - 2016-03-09 10:24:56 --> URI Class Initialized
INFO - 2016-03-09 10:24:56 --> Router Class Initialized
INFO - 2016-03-09 10:24:56 --> Output Class Initialized
INFO - 2016-03-09 10:24:56 --> Security Class Initialized
DEBUG - 2016-03-09 10:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:24:56 --> Input Class Initialized
INFO - 2016-03-09 10:24:56 --> Language Class Initialized
INFO - 2016-03-09 10:24:56 --> Loader Class Initialized
INFO - 2016-03-09 10:24:56 --> Helper loaded: url_helper
INFO - 2016-03-09 10:24:56 --> Helper loaded: file_helper
INFO - 2016-03-09 10:24:56 --> Helper loaded: date_helper
INFO - 2016-03-09 10:24:56 --> Helper loaded: form_helper
INFO - 2016-03-09 10:24:56 --> Database Driver Class Initialized
INFO - 2016-03-09 10:24:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:24:57 --> Controller Class Initialized
INFO - 2016-03-09 10:24:57 --> Model Class Initialized
INFO - 2016-03-09 10:24:57 --> Model Class Initialized
INFO - 2016-03-09 10:24:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:24:57 --> Pagination Class Initialized
INFO - 2016-03-09 10:24:57 --> Helper loaded: text_helper
INFO - 2016-03-09 10:24:57 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:24:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:24:57 --> Final output sent to browser
DEBUG - 2016-03-09 13:24:57 --> Total execution time: 1.1101
INFO - 2016-03-09 10:25:22 --> Config Class Initialized
INFO - 2016-03-09 10:25:22 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:25:22 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:25:22 --> Utf8 Class Initialized
INFO - 2016-03-09 10:25:22 --> URI Class Initialized
INFO - 2016-03-09 10:25:22 --> Router Class Initialized
INFO - 2016-03-09 10:25:22 --> Output Class Initialized
INFO - 2016-03-09 10:25:22 --> Security Class Initialized
DEBUG - 2016-03-09 10:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:25:22 --> Input Class Initialized
INFO - 2016-03-09 10:25:22 --> Language Class Initialized
INFO - 2016-03-09 10:25:22 --> Loader Class Initialized
INFO - 2016-03-09 10:25:22 --> Helper loaded: url_helper
INFO - 2016-03-09 10:25:22 --> Helper loaded: file_helper
INFO - 2016-03-09 10:25:22 --> Helper loaded: date_helper
INFO - 2016-03-09 10:25:22 --> Helper loaded: form_helper
INFO - 2016-03-09 10:25:22 --> Database Driver Class Initialized
INFO - 2016-03-09 10:25:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:25:23 --> Controller Class Initialized
INFO - 2016-03-09 10:25:23 --> Model Class Initialized
INFO - 2016-03-09 10:25:23 --> Model Class Initialized
INFO - 2016-03-09 10:25:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:25:23 --> Pagination Class Initialized
INFO - 2016-03-09 10:25:23 --> Helper loaded: text_helper
INFO - 2016-03-09 10:25:23 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 13:25:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:25:23 --> Final output sent to browser
DEBUG - 2016-03-09 13:25:23 --> Total execution time: 1.1321
INFO - 2016-03-09 10:29:46 --> Config Class Initialized
INFO - 2016-03-09 10:29:46 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:29:46 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:29:46 --> Utf8 Class Initialized
INFO - 2016-03-09 10:29:46 --> URI Class Initialized
INFO - 2016-03-09 10:29:46 --> Router Class Initialized
INFO - 2016-03-09 10:29:46 --> Output Class Initialized
INFO - 2016-03-09 10:29:46 --> Security Class Initialized
DEBUG - 2016-03-09 10:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:29:46 --> Input Class Initialized
INFO - 2016-03-09 10:29:46 --> Language Class Initialized
INFO - 2016-03-09 10:29:46 --> Loader Class Initialized
INFO - 2016-03-09 10:29:46 --> Helper loaded: url_helper
INFO - 2016-03-09 10:29:46 --> Helper loaded: file_helper
INFO - 2016-03-09 10:29:46 --> Helper loaded: date_helper
INFO - 2016-03-09 10:29:46 --> Helper loaded: form_helper
INFO - 2016-03-09 10:29:46 --> Database Driver Class Initialized
INFO - 2016-03-09 10:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:29:47 --> Controller Class Initialized
INFO - 2016-03-09 10:29:47 --> Model Class Initialized
INFO - 2016-03-09 10:29:47 --> Model Class Initialized
INFO - 2016-03-09 10:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:29:47 --> Pagination Class Initialized
INFO - 2016-03-09 10:29:47 --> Helper loaded: text_helper
INFO - 2016-03-09 10:29:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:29:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:29:47 --> Final output sent to browser
DEBUG - 2016-03-09 13:29:47 --> Total execution time: 1.0954
INFO - 2016-03-09 10:29:50 --> Config Class Initialized
INFO - 2016-03-09 10:29:50 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:29:50 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:29:50 --> Utf8 Class Initialized
INFO - 2016-03-09 10:29:50 --> URI Class Initialized
INFO - 2016-03-09 10:29:50 --> Router Class Initialized
INFO - 2016-03-09 10:29:50 --> Output Class Initialized
INFO - 2016-03-09 10:29:50 --> Security Class Initialized
DEBUG - 2016-03-09 10:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:29:50 --> Input Class Initialized
INFO - 2016-03-09 10:29:50 --> Language Class Initialized
INFO - 2016-03-09 10:29:50 --> Loader Class Initialized
INFO - 2016-03-09 10:29:50 --> Helper loaded: url_helper
INFO - 2016-03-09 10:29:50 --> Helper loaded: file_helper
INFO - 2016-03-09 10:29:50 --> Helper loaded: date_helper
INFO - 2016-03-09 10:29:50 --> Helper loaded: form_helper
INFO - 2016-03-09 10:29:50 --> Database Driver Class Initialized
INFO - 2016-03-09 10:29:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:29:51 --> Controller Class Initialized
INFO - 2016-03-09 10:29:51 --> Model Class Initialized
INFO - 2016-03-09 10:29:51 --> Model Class Initialized
INFO - 2016-03-09 10:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:29:51 --> Pagination Class Initialized
INFO - 2016-03-09 10:29:51 --> Helper loaded: text_helper
INFO - 2016-03-09 10:29:51 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:29:51 --> Final output sent to browser
DEBUG - 2016-03-09 13:29:51 --> Total execution time: 1.1621
INFO - 2016-03-09 10:29:53 --> Config Class Initialized
INFO - 2016-03-09 10:29:53 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:29:53 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:29:53 --> Utf8 Class Initialized
INFO - 2016-03-09 10:29:53 --> URI Class Initialized
INFO - 2016-03-09 10:29:53 --> Router Class Initialized
INFO - 2016-03-09 10:29:53 --> Output Class Initialized
INFO - 2016-03-09 10:29:53 --> Security Class Initialized
DEBUG - 2016-03-09 10:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:29:53 --> Input Class Initialized
INFO - 2016-03-09 10:29:53 --> Language Class Initialized
INFO - 2016-03-09 10:29:53 --> Loader Class Initialized
INFO - 2016-03-09 10:29:53 --> Helper loaded: url_helper
INFO - 2016-03-09 10:29:53 --> Helper loaded: file_helper
INFO - 2016-03-09 10:29:53 --> Helper loaded: date_helper
INFO - 2016-03-09 10:29:53 --> Helper loaded: form_helper
INFO - 2016-03-09 10:29:53 --> Database Driver Class Initialized
INFO - 2016-03-09 10:29:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:29:54 --> Controller Class Initialized
INFO - 2016-03-09 10:29:54 --> Model Class Initialized
INFO - 2016-03-09 10:29:54 --> Model Class Initialized
INFO - 2016-03-09 10:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:29:54 --> Pagination Class Initialized
INFO - 2016-03-09 10:29:54 --> Helper loaded: text_helper
INFO - 2016-03-09 10:29:54 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 13:29:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:29:54 --> Final output sent to browser
DEBUG - 2016-03-09 13:29:54 --> Total execution time: 1.2217
INFO - 2016-03-09 10:31:59 --> Config Class Initialized
INFO - 2016-03-09 10:31:59 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:31:59 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:31:59 --> Utf8 Class Initialized
INFO - 2016-03-09 10:31:59 --> URI Class Initialized
INFO - 2016-03-09 10:31:59 --> Router Class Initialized
INFO - 2016-03-09 10:31:59 --> Output Class Initialized
INFO - 2016-03-09 10:31:59 --> Security Class Initialized
DEBUG - 2016-03-09 10:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:31:59 --> Input Class Initialized
INFO - 2016-03-09 10:31:59 --> Language Class Initialized
INFO - 2016-03-09 10:31:59 --> Loader Class Initialized
INFO - 2016-03-09 10:31:59 --> Helper loaded: url_helper
INFO - 2016-03-09 10:31:59 --> Helper loaded: file_helper
INFO - 2016-03-09 10:31:59 --> Helper loaded: date_helper
INFO - 2016-03-09 10:31:59 --> Helper loaded: form_helper
INFO - 2016-03-09 10:31:59 --> Database Driver Class Initialized
INFO - 2016-03-09 10:32:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:32:01 --> Controller Class Initialized
INFO - 2016-03-09 10:32:01 --> Model Class Initialized
INFO - 2016-03-09 10:32:01 --> Model Class Initialized
INFO - 2016-03-09 10:32:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:32:01 --> Pagination Class Initialized
INFO - 2016-03-09 10:32:01 --> Helper loaded: text_helper
INFO - 2016-03-09 10:32:01 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:32:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:32:01 --> Final output sent to browser
DEBUG - 2016-03-09 13:32:01 --> Total execution time: 1.1393
INFO - 2016-03-09 10:32:13 --> Config Class Initialized
INFO - 2016-03-09 10:32:13 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:32:13 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:32:13 --> Utf8 Class Initialized
INFO - 2016-03-09 10:32:13 --> URI Class Initialized
INFO - 2016-03-09 10:32:13 --> Router Class Initialized
INFO - 2016-03-09 10:32:13 --> Output Class Initialized
INFO - 2016-03-09 10:32:13 --> Security Class Initialized
DEBUG - 2016-03-09 10:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:32:13 --> Input Class Initialized
INFO - 2016-03-09 10:32:13 --> Language Class Initialized
INFO - 2016-03-09 10:32:13 --> Loader Class Initialized
INFO - 2016-03-09 10:32:13 --> Helper loaded: url_helper
INFO - 2016-03-09 10:32:13 --> Helper loaded: file_helper
INFO - 2016-03-09 10:32:13 --> Helper loaded: date_helper
INFO - 2016-03-09 10:32:13 --> Helper loaded: form_helper
INFO - 2016-03-09 10:32:13 --> Database Driver Class Initialized
INFO - 2016-03-09 10:32:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:32:14 --> Controller Class Initialized
INFO - 2016-03-09 10:32:14 --> Model Class Initialized
INFO - 2016-03-09 10:32:14 --> Model Class Initialized
INFO - 2016-03-09 10:32:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:32:14 --> Pagination Class Initialized
INFO - 2016-03-09 10:32:14 --> Helper loaded: text_helper
INFO - 2016-03-09 10:32:14 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:32:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:32:14 --> Final output sent to browser
DEBUG - 2016-03-09 13:32:14 --> Total execution time: 1.1074
INFO - 2016-03-09 10:37:32 --> Config Class Initialized
INFO - 2016-03-09 10:37:32 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:37:32 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:37:32 --> Utf8 Class Initialized
INFO - 2016-03-09 10:37:32 --> URI Class Initialized
DEBUG - 2016-03-09 10:37:32 --> No URI present. Default controller set.
INFO - 2016-03-09 10:37:32 --> Router Class Initialized
INFO - 2016-03-09 10:37:32 --> Output Class Initialized
INFO - 2016-03-09 10:37:32 --> Security Class Initialized
DEBUG - 2016-03-09 10:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:37:32 --> Input Class Initialized
INFO - 2016-03-09 10:37:32 --> Language Class Initialized
INFO - 2016-03-09 10:37:32 --> Loader Class Initialized
INFO - 2016-03-09 10:37:32 --> Helper loaded: url_helper
INFO - 2016-03-09 10:37:32 --> Helper loaded: file_helper
INFO - 2016-03-09 10:37:32 --> Helper loaded: date_helper
INFO - 2016-03-09 10:37:32 --> Helper loaded: form_helper
INFO - 2016-03-09 10:37:32 --> Database Driver Class Initialized
INFO - 2016-03-09 10:37:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:37:33 --> Controller Class Initialized
INFO - 2016-03-09 10:37:33 --> Model Class Initialized
INFO - 2016-03-09 10:37:33 --> Model Class Initialized
INFO - 2016-03-09 10:37:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:37:33 --> Pagination Class Initialized
INFO - 2016-03-09 10:37:33 --> Helper loaded: text_helper
INFO - 2016-03-09 10:37:33 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-09 13:37:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:37:33 --> Final output sent to browser
DEBUG - 2016-03-09 13:37:33 --> Total execution time: 1.1199
INFO - 2016-03-09 10:54:24 --> Config Class Initialized
INFO - 2016-03-09 10:54:24 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:54:24 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:54:24 --> Utf8 Class Initialized
INFO - 2016-03-09 10:54:24 --> URI Class Initialized
DEBUG - 2016-03-09 10:54:24 --> No URI present. Default controller set.
INFO - 2016-03-09 10:54:24 --> Router Class Initialized
INFO - 2016-03-09 10:54:24 --> Output Class Initialized
INFO - 2016-03-09 10:54:24 --> Security Class Initialized
DEBUG - 2016-03-09 10:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:54:24 --> Input Class Initialized
INFO - 2016-03-09 10:54:24 --> Language Class Initialized
INFO - 2016-03-09 10:54:24 --> Loader Class Initialized
INFO - 2016-03-09 10:54:24 --> Helper loaded: url_helper
INFO - 2016-03-09 10:54:24 --> Helper loaded: file_helper
INFO - 2016-03-09 10:54:24 --> Helper loaded: date_helper
INFO - 2016-03-09 10:54:24 --> Helper loaded: form_helper
INFO - 2016-03-09 10:54:24 --> Database Driver Class Initialized
INFO - 2016-03-09 10:54:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:54:26 --> Controller Class Initialized
INFO - 2016-03-09 10:54:26 --> Model Class Initialized
INFO - 2016-03-09 10:54:26 --> Model Class Initialized
INFO - 2016-03-09 10:54:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:54:26 --> Pagination Class Initialized
INFO - 2016-03-09 10:54:26 --> Helper loaded: text_helper
INFO - 2016-03-09 10:54:26 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-09 13:54:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:54:26 --> Final output sent to browser
DEBUG - 2016-03-09 13:54:26 --> Total execution time: 2.0066
INFO - 2016-03-09 10:54:42 --> Config Class Initialized
INFO - 2016-03-09 10:54:42 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:54:42 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:54:42 --> Utf8 Class Initialized
INFO - 2016-03-09 10:54:42 --> URI Class Initialized
INFO - 2016-03-09 10:54:42 --> Router Class Initialized
INFO - 2016-03-09 10:54:42 --> Output Class Initialized
INFO - 2016-03-09 10:54:42 --> Security Class Initialized
DEBUG - 2016-03-09 10:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:54:42 --> Input Class Initialized
INFO - 2016-03-09 10:54:42 --> Language Class Initialized
ERROR - 2016-03-09 10:54:42 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 307
INFO - 2016-03-09 10:54:59 --> Config Class Initialized
INFO - 2016-03-09 10:54:59 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:54:59 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:54:59 --> Utf8 Class Initialized
INFO - 2016-03-09 10:54:59 --> URI Class Initialized
INFO - 2016-03-09 10:54:59 --> Router Class Initialized
INFO - 2016-03-09 10:54:59 --> Output Class Initialized
INFO - 2016-03-09 10:54:59 --> Security Class Initialized
DEBUG - 2016-03-09 10:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:54:59 --> Input Class Initialized
INFO - 2016-03-09 10:54:59 --> Language Class Initialized
INFO - 2016-03-09 10:54:59 --> Loader Class Initialized
INFO - 2016-03-09 10:54:59 --> Helper loaded: url_helper
INFO - 2016-03-09 10:54:59 --> Helper loaded: file_helper
INFO - 2016-03-09 10:54:59 --> Helper loaded: date_helper
INFO - 2016-03-09 10:54:59 --> Helper loaded: form_helper
INFO - 2016-03-09 10:54:59 --> Database Driver Class Initialized
INFO - 2016-03-09 10:55:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:55:00 --> Controller Class Initialized
INFO - 2016-03-09 10:55:00 --> Model Class Initialized
INFO - 2016-03-09 10:55:00 --> Model Class Initialized
INFO - 2016-03-09 10:55:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:55:00 --> Pagination Class Initialized
INFO - 2016-03-09 10:55:00 --> Helper loaded: text_helper
INFO - 2016-03-09 10:55:00 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:55:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:55:00 --> Final output sent to browser
DEBUG - 2016-03-09 13:55:00 --> Total execution time: 1.1647
INFO - 2016-03-09 10:55:02 --> Config Class Initialized
INFO - 2016-03-09 10:55:02 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:55:02 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:55:02 --> Utf8 Class Initialized
INFO - 2016-03-09 10:55:02 --> URI Class Initialized
INFO - 2016-03-09 10:55:02 --> Router Class Initialized
INFO - 2016-03-09 10:55:02 --> Output Class Initialized
INFO - 2016-03-09 10:55:02 --> Security Class Initialized
DEBUG - 2016-03-09 10:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:55:02 --> Input Class Initialized
INFO - 2016-03-09 10:55:02 --> Language Class Initialized
INFO - 2016-03-09 10:55:02 --> Loader Class Initialized
INFO - 2016-03-09 10:55:02 --> Helper loaded: url_helper
INFO - 2016-03-09 10:55:02 --> Helper loaded: file_helper
INFO - 2016-03-09 10:55:02 --> Helper loaded: date_helper
INFO - 2016-03-09 10:55:02 --> Helper loaded: form_helper
INFO - 2016-03-09 10:55:02 --> Database Driver Class Initialized
INFO - 2016-03-09 10:55:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:55:03 --> Controller Class Initialized
INFO - 2016-03-09 10:55:03 --> Model Class Initialized
INFO - 2016-03-09 10:55:03 --> Model Class Initialized
INFO - 2016-03-09 10:55:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:55:03 --> Pagination Class Initialized
INFO - 2016-03-09 10:55:03 --> Helper loaded: text_helper
INFO - 2016-03-09 10:55:03 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 13:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 13:55:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:55:03 --> Final output sent to browser
DEBUG - 2016-03-09 13:55:03 --> Total execution time: 1.1147
INFO - 2016-03-09 10:55:05 --> Config Class Initialized
INFO - 2016-03-09 10:55:05 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:55:05 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:55:05 --> Utf8 Class Initialized
INFO - 2016-03-09 10:55:05 --> URI Class Initialized
INFO - 2016-03-09 10:55:05 --> Router Class Initialized
INFO - 2016-03-09 10:55:05 --> Output Class Initialized
INFO - 2016-03-09 10:55:05 --> Security Class Initialized
DEBUG - 2016-03-09 10:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:55:05 --> Input Class Initialized
INFO - 2016-03-09 10:55:05 --> Language Class Initialized
INFO - 2016-03-09 10:55:05 --> Loader Class Initialized
INFO - 2016-03-09 10:55:05 --> Helper loaded: url_helper
INFO - 2016-03-09 10:55:05 --> Helper loaded: file_helper
INFO - 2016-03-09 10:55:05 --> Helper loaded: date_helper
INFO - 2016-03-09 10:55:05 --> Helper loaded: form_helper
INFO - 2016-03-09 10:55:05 --> Database Driver Class Initialized
INFO - 2016-03-09 10:55:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:55:06 --> Controller Class Initialized
INFO - 2016-03-09 10:55:06 --> Model Class Initialized
INFO - 2016-03-09 10:55:06 --> Model Class Initialized
INFO - 2016-03-09 10:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:55:06 --> Pagination Class Initialized
INFO - 2016-03-09 10:55:06 --> Helper loaded: text_helper
INFO - 2016-03-09 10:55:06 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-09 13:55:06 --> Severity: Notice --> Undefined variable: idx_page C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 84
INFO - 2016-03-09 13:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:55:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:55:06 --> Final output sent to browser
DEBUG - 2016-03-09 13:55:06 --> Total execution time: 1.2053
INFO - 2016-03-09 10:57:46 --> Config Class Initialized
INFO - 2016-03-09 10:57:46 --> Hooks Class Initialized
DEBUG - 2016-03-09 10:57:46 --> UTF-8 Support Enabled
INFO - 2016-03-09 10:57:46 --> Utf8 Class Initialized
INFO - 2016-03-09 10:57:46 --> URI Class Initialized
INFO - 2016-03-09 10:57:46 --> Router Class Initialized
INFO - 2016-03-09 10:57:46 --> Output Class Initialized
INFO - 2016-03-09 10:57:46 --> Security Class Initialized
DEBUG - 2016-03-09 10:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 10:57:46 --> Input Class Initialized
INFO - 2016-03-09 10:57:46 --> Language Class Initialized
INFO - 2016-03-09 10:57:46 --> Loader Class Initialized
INFO - 2016-03-09 10:57:46 --> Helper loaded: url_helper
INFO - 2016-03-09 10:57:46 --> Helper loaded: file_helper
INFO - 2016-03-09 10:57:46 --> Helper loaded: date_helper
INFO - 2016-03-09 10:57:46 --> Helper loaded: form_helper
INFO - 2016-03-09 10:57:46 --> Database Driver Class Initialized
INFO - 2016-03-09 10:57:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 10:57:47 --> Controller Class Initialized
INFO - 2016-03-09 10:57:47 --> Model Class Initialized
INFO - 2016-03-09 10:57:47 --> Model Class Initialized
INFO - 2016-03-09 10:57:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 10:57:47 --> Pagination Class Initialized
INFO - 2016-03-09 10:57:47 --> Helper loaded: text_helper
INFO - 2016-03-09 10:57:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 13:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 13:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 13:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 13:57:48 --> Final output sent to browser
DEBUG - 2016-03-09 13:57:48 --> Total execution time: 1.6475
INFO - 2016-03-09 11:00:04 --> Config Class Initialized
INFO - 2016-03-09 11:00:04 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:00:04 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:00:04 --> Utf8 Class Initialized
INFO - 2016-03-09 11:00:04 --> URI Class Initialized
INFO - 2016-03-09 11:00:04 --> Router Class Initialized
INFO - 2016-03-09 11:00:04 --> Output Class Initialized
INFO - 2016-03-09 11:00:04 --> Security Class Initialized
DEBUG - 2016-03-09 11:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:00:04 --> Input Class Initialized
INFO - 2016-03-09 11:00:04 --> Language Class Initialized
INFO - 2016-03-09 11:00:04 --> Loader Class Initialized
INFO - 2016-03-09 11:00:04 --> Helper loaded: url_helper
INFO - 2016-03-09 11:00:04 --> Helper loaded: file_helper
INFO - 2016-03-09 11:00:04 --> Helper loaded: date_helper
INFO - 2016-03-09 11:00:04 --> Helper loaded: form_helper
INFO - 2016-03-09 11:00:04 --> Database Driver Class Initialized
INFO - 2016-03-09 11:00:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:00:05 --> Controller Class Initialized
INFO - 2016-03-09 11:00:05 --> Model Class Initialized
INFO - 2016-03-09 11:00:05 --> Model Class Initialized
INFO - 2016-03-09 11:00:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:00:05 --> Pagination Class Initialized
INFO - 2016-03-09 11:00:05 --> Helper loaded: text_helper
INFO - 2016-03-09 11:00:05 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 14:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 14:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 14:00:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:00:05 --> Final output sent to browser
DEBUG - 2016-03-09 14:00:05 --> Total execution time: 1.2052
INFO - 2016-03-09 11:05:02 --> Config Class Initialized
INFO - 2016-03-09 11:05:02 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:05:02 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:05:02 --> Utf8 Class Initialized
INFO - 2016-03-09 11:05:02 --> URI Class Initialized
DEBUG - 2016-03-09 11:05:02 --> No URI present. Default controller set.
INFO - 2016-03-09 11:05:02 --> Router Class Initialized
INFO - 2016-03-09 11:05:02 --> Output Class Initialized
INFO - 2016-03-09 11:05:02 --> Security Class Initialized
DEBUG - 2016-03-09 11:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:05:02 --> Input Class Initialized
INFO - 2016-03-09 11:05:02 --> Language Class Initialized
INFO - 2016-03-09 11:05:02 --> Loader Class Initialized
INFO - 2016-03-09 11:05:02 --> Helper loaded: url_helper
INFO - 2016-03-09 11:05:02 --> Helper loaded: file_helper
INFO - 2016-03-09 11:05:02 --> Helper loaded: date_helper
INFO - 2016-03-09 11:05:02 --> Helper loaded: form_helper
INFO - 2016-03-09 11:05:02 --> Database Driver Class Initialized
INFO - 2016-03-09 11:05:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:05:03 --> Controller Class Initialized
INFO - 2016-03-09 11:05:03 --> Model Class Initialized
INFO - 2016-03-09 11:05:03 --> Model Class Initialized
INFO - 2016-03-09 11:05:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:05:03 --> Pagination Class Initialized
INFO - 2016-03-09 11:05:03 --> Helper loaded: text_helper
INFO - 2016-03-09 11:05:03 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:05:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:05:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:05:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-09 14:05:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:05:03 --> Final output sent to browser
DEBUG - 2016-03-09 14:05:03 --> Total execution time: 1.1406
INFO - 2016-03-09 11:08:43 --> Config Class Initialized
INFO - 2016-03-09 11:08:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:08:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:08:43 --> Utf8 Class Initialized
INFO - 2016-03-09 11:08:43 --> URI Class Initialized
INFO - 2016-03-09 11:08:43 --> Router Class Initialized
INFO - 2016-03-09 11:08:43 --> Output Class Initialized
INFO - 2016-03-09 11:08:43 --> Security Class Initialized
DEBUG - 2016-03-09 11:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:08:43 --> Input Class Initialized
INFO - 2016-03-09 11:08:43 --> Language Class Initialized
INFO - 2016-03-09 11:08:43 --> Loader Class Initialized
INFO - 2016-03-09 11:08:43 --> Helper loaded: url_helper
INFO - 2016-03-09 11:08:43 --> Helper loaded: file_helper
INFO - 2016-03-09 11:08:43 --> Helper loaded: date_helper
INFO - 2016-03-09 11:08:43 --> Helper loaded: form_helper
INFO - 2016-03-09 11:08:43 --> Database Driver Class Initialized
INFO - 2016-03-09 11:08:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:08:44 --> Controller Class Initialized
INFO - 2016-03-09 11:08:44 --> Model Class Initialized
INFO - 2016-03-09 11:08:44 --> Model Class Initialized
INFO - 2016-03-09 11:08:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:08:44 --> Pagination Class Initialized
INFO - 2016-03-09 11:08:44 --> Helper loaded: text_helper
INFO - 2016-03-09 11:08:44 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:08:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:08:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:08:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:08:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:08:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:08:44 --> Final output sent to browser
DEBUG - 2016-03-09 14:08:44 --> Total execution time: 1.1208
INFO - 2016-03-09 11:08:45 --> Config Class Initialized
INFO - 2016-03-09 11:08:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:08:45 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:08:45 --> Utf8 Class Initialized
INFO - 2016-03-09 11:08:45 --> URI Class Initialized
INFO - 2016-03-09 11:08:45 --> Router Class Initialized
INFO - 2016-03-09 11:08:45 --> Output Class Initialized
INFO - 2016-03-09 11:08:45 --> Security Class Initialized
DEBUG - 2016-03-09 11:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:08:45 --> Input Class Initialized
INFO - 2016-03-09 11:08:45 --> Language Class Initialized
INFO - 2016-03-09 11:08:45 --> Loader Class Initialized
INFO - 2016-03-09 11:08:45 --> Helper loaded: url_helper
INFO - 2016-03-09 11:08:45 --> Helper loaded: file_helper
INFO - 2016-03-09 11:08:45 --> Helper loaded: date_helper
INFO - 2016-03-09 11:08:45 --> Helper loaded: form_helper
INFO - 2016-03-09 11:08:45 --> Database Driver Class Initialized
INFO - 2016-03-09 11:08:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:08:47 --> Controller Class Initialized
INFO - 2016-03-09 11:08:47 --> Model Class Initialized
INFO - 2016-03-09 11:08:47 --> Model Class Initialized
INFO - 2016-03-09 11:08:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:08:47 --> Pagination Class Initialized
INFO - 2016-03-09 11:08:47 --> Helper loaded: text_helper
INFO - 2016-03-09 11:08:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:08:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:08:47 --> Final output sent to browser
DEBUG - 2016-03-09 14:08:47 --> Total execution time: 1.1322
INFO - 2016-03-09 11:09:51 --> Config Class Initialized
INFO - 2016-03-09 11:09:51 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:09:51 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:09:51 --> Utf8 Class Initialized
INFO - 2016-03-09 11:09:51 --> URI Class Initialized
INFO - 2016-03-09 11:09:51 --> Router Class Initialized
INFO - 2016-03-09 11:09:51 --> Output Class Initialized
INFO - 2016-03-09 11:09:51 --> Security Class Initialized
DEBUG - 2016-03-09 11:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:09:51 --> Input Class Initialized
INFO - 2016-03-09 11:09:51 --> Language Class Initialized
INFO - 2016-03-09 11:09:51 --> Loader Class Initialized
INFO - 2016-03-09 11:09:51 --> Helper loaded: url_helper
INFO - 2016-03-09 11:09:51 --> Helper loaded: file_helper
INFO - 2016-03-09 11:09:51 --> Helper loaded: date_helper
INFO - 2016-03-09 11:09:51 --> Helper loaded: form_helper
INFO - 2016-03-09 11:09:51 --> Database Driver Class Initialized
INFO - 2016-03-09 11:09:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:09:52 --> Controller Class Initialized
INFO - 2016-03-09 11:09:52 --> Model Class Initialized
INFO - 2016-03-09 11:09:52 --> Model Class Initialized
INFO - 2016-03-09 11:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:09:52 --> Pagination Class Initialized
INFO - 2016-03-09 11:09:52 --> Helper loaded: text_helper
INFO - 2016-03-09 11:09:52 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:09:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:09:52 --> Final output sent to browser
DEBUG - 2016-03-09 14:09:52 --> Total execution time: 1.1424
INFO - 2016-03-09 11:09:55 --> Config Class Initialized
INFO - 2016-03-09 11:09:55 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:09:55 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:09:55 --> Utf8 Class Initialized
INFO - 2016-03-09 11:09:55 --> URI Class Initialized
INFO - 2016-03-09 11:09:55 --> Router Class Initialized
INFO - 2016-03-09 11:09:55 --> Output Class Initialized
INFO - 2016-03-09 11:09:55 --> Security Class Initialized
DEBUG - 2016-03-09 11:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:09:55 --> Input Class Initialized
INFO - 2016-03-09 11:09:55 --> Language Class Initialized
INFO - 2016-03-09 11:09:55 --> Loader Class Initialized
INFO - 2016-03-09 11:09:55 --> Helper loaded: url_helper
INFO - 2016-03-09 11:09:55 --> Helper loaded: file_helper
INFO - 2016-03-09 11:09:55 --> Helper loaded: date_helper
INFO - 2016-03-09 11:09:55 --> Helper loaded: form_helper
INFO - 2016-03-09 11:09:55 --> Database Driver Class Initialized
INFO - 2016-03-09 11:09:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:09:56 --> Controller Class Initialized
INFO - 2016-03-09 11:09:56 --> Model Class Initialized
INFO - 2016-03-09 11:09:56 --> Model Class Initialized
INFO - 2016-03-09 11:09:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:09:56 --> Pagination Class Initialized
INFO - 2016-03-09 11:09:56 --> Helper loaded: text_helper
INFO - 2016-03-09 11:09:56 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:09:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:09:56 --> Final output sent to browser
DEBUG - 2016-03-09 14:09:56 --> Total execution time: 1.1069
INFO - 2016-03-09 11:09:57 --> Config Class Initialized
INFO - 2016-03-09 11:09:57 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:09:57 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:09:57 --> Utf8 Class Initialized
INFO - 2016-03-09 11:09:57 --> URI Class Initialized
INFO - 2016-03-09 11:09:57 --> Router Class Initialized
INFO - 2016-03-09 11:09:57 --> Output Class Initialized
INFO - 2016-03-09 11:09:57 --> Security Class Initialized
DEBUG - 2016-03-09 11:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:09:57 --> Input Class Initialized
INFO - 2016-03-09 11:09:57 --> Language Class Initialized
INFO - 2016-03-09 11:09:57 --> Loader Class Initialized
INFO - 2016-03-09 11:09:57 --> Helper loaded: url_helper
INFO - 2016-03-09 11:09:57 --> Helper loaded: file_helper
INFO - 2016-03-09 11:09:57 --> Helper loaded: date_helper
INFO - 2016-03-09 11:09:57 --> Helper loaded: form_helper
INFO - 2016-03-09 11:09:57 --> Database Driver Class Initialized
INFO - 2016-03-09 11:09:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:09:58 --> Controller Class Initialized
INFO - 2016-03-09 11:09:58 --> Model Class Initialized
INFO - 2016-03-09 11:09:58 --> Model Class Initialized
INFO - 2016-03-09 11:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:09:58 --> Pagination Class Initialized
INFO - 2016-03-09 11:09:58 --> Helper loaded: text_helper
INFO - 2016-03-09 11:09:58 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 14:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 14:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 14:09:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:09:58 --> Final output sent to browser
DEBUG - 2016-03-09 14:09:58 --> Total execution time: 1.2889
INFO - 2016-03-09 11:12:19 --> Config Class Initialized
INFO - 2016-03-09 11:12:19 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:12:19 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:12:19 --> Utf8 Class Initialized
INFO - 2016-03-09 11:12:19 --> URI Class Initialized
INFO - 2016-03-09 11:12:19 --> Router Class Initialized
INFO - 2016-03-09 11:12:19 --> Output Class Initialized
INFO - 2016-03-09 11:12:19 --> Security Class Initialized
DEBUG - 2016-03-09 11:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:12:19 --> Input Class Initialized
INFO - 2016-03-09 11:12:19 --> Language Class Initialized
INFO - 2016-03-09 11:12:19 --> Loader Class Initialized
INFO - 2016-03-09 11:12:19 --> Helper loaded: url_helper
INFO - 2016-03-09 11:12:19 --> Helper loaded: file_helper
INFO - 2016-03-09 11:12:19 --> Helper loaded: date_helper
INFO - 2016-03-09 11:12:19 --> Helper loaded: form_helper
INFO - 2016-03-09 11:12:19 --> Database Driver Class Initialized
INFO - 2016-03-09 11:12:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:12:20 --> Controller Class Initialized
INFO - 2016-03-09 11:12:20 --> Model Class Initialized
INFO - 2016-03-09 11:12:20 --> Model Class Initialized
INFO - 2016-03-09 11:12:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:12:20 --> Pagination Class Initialized
INFO - 2016-03-09 11:12:20 --> Helper loaded: text_helper
INFO - 2016-03-09 11:12:20 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:12:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:12:20 --> Final output sent to browser
DEBUG - 2016-03-09 14:12:20 --> Total execution time: 1.1203
INFO - 2016-03-09 11:12:22 --> Config Class Initialized
INFO - 2016-03-09 11:12:22 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:12:22 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:12:22 --> Utf8 Class Initialized
INFO - 2016-03-09 11:12:22 --> URI Class Initialized
INFO - 2016-03-09 11:12:22 --> Router Class Initialized
INFO - 2016-03-09 11:12:22 --> Output Class Initialized
INFO - 2016-03-09 11:12:22 --> Security Class Initialized
DEBUG - 2016-03-09 11:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:12:22 --> Input Class Initialized
INFO - 2016-03-09 11:12:22 --> Language Class Initialized
INFO - 2016-03-09 11:12:22 --> Loader Class Initialized
INFO - 2016-03-09 11:12:22 --> Helper loaded: url_helper
INFO - 2016-03-09 11:12:22 --> Helper loaded: file_helper
INFO - 2016-03-09 11:12:22 --> Helper loaded: date_helper
INFO - 2016-03-09 11:12:22 --> Helper loaded: form_helper
INFO - 2016-03-09 11:12:22 --> Database Driver Class Initialized
INFO - 2016-03-09 11:12:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:12:23 --> Controller Class Initialized
INFO - 2016-03-09 11:12:23 --> Model Class Initialized
INFO - 2016-03-09 11:12:23 --> Model Class Initialized
INFO - 2016-03-09 11:12:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:12:23 --> Pagination Class Initialized
INFO - 2016-03-09 11:12:23 --> Helper loaded: text_helper
INFO - 2016-03-09 11:12:23 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:12:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:12:23 --> Final output sent to browser
DEBUG - 2016-03-09 14:12:23 --> Total execution time: 1.1068
INFO - 2016-03-09 11:12:26 --> Config Class Initialized
INFO - 2016-03-09 11:12:26 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:12:26 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:12:26 --> Utf8 Class Initialized
INFO - 2016-03-09 11:12:26 --> URI Class Initialized
INFO - 2016-03-09 11:12:26 --> Router Class Initialized
INFO - 2016-03-09 11:12:26 --> Output Class Initialized
INFO - 2016-03-09 11:12:26 --> Security Class Initialized
DEBUG - 2016-03-09 11:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:12:26 --> Input Class Initialized
INFO - 2016-03-09 11:12:26 --> Language Class Initialized
INFO - 2016-03-09 11:12:26 --> Loader Class Initialized
INFO - 2016-03-09 11:12:26 --> Helper loaded: url_helper
INFO - 2016-03-09 11:12:26 --> Helper loaded: file_helper
INFO - 2016-03-09 11:12:26 --> Helper loaded: date_helper
INFO - 2016-03-09 11:12:26 --> Helper loaded: form_helper
INFO - 2016-03-09 11:12:26 --> Database Driver Class Initialized
INFO - 2016-03-09 11:12:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:12:27 --> Controller Class Initialized
INFO - 2016-03-09 11:12:27 --> Model Class Initialized
INFO - 2016-03-09 11:12:27 --> Model Class Initialized
INFO - 2016-03-09 11:12:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:12:27 --> Pagination Class Initialized
INFO - 2016-03-09 11:12:27 --> Helper loaded: text_helper
INFO - 2016-03-09 11:12:27 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 14:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 14:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 14:12:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:12:27 --> Final output sent to browser
DEBUG - 2016-03-09 14:12:27 --> Total execution time: 1.1502
INFO - 2016-03-09 11:13:26 --> Config Class Initialized
INFO - 2016-03-09 11:13:26 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:13:26 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:13:26 --> Utf8 Class Initialized
INFO - 2016-03-09 11:13:26 --> URI Class Initialized
INFO - 2016-03-09 11:13:26 --> Router Class Initialized
INFO - 2016-03-09 11:13:26 --> Output Class Initialized
INFO - 2016-03-09 11:13:26 --> Security Class Initialized
DEBUG - 2016-03-09 11:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:13:26 --> Input Class Initialized
INFO - 2016-03-09 11:13:26 --> Language Class Initialized
INFO - 2016-03-09 11:13:26 --> Loader Class Initialized
INFO - 2016-03-09 11:13:26 --> Helper loaded: url_helper
INFO - 2016-03-09 11:13:26 --> Helper loaded: file_helper
INFO - 2016-03-09 11:13:26 --> Helper loaded: date_helper
INFO - 2016-03-09 11:13:26 --> Helper loaded: form_helper
INFO - 2016-03-09 11:13:26 --> Database Driver Class Initialized
INFO - 2016-03-09 11:13:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:13:27 --> Controller Class Initialized
INFO - 2016-03-09 11:13:27 --> Model Class Initialized
INFO - 2016-03-09 11:13:27 --> Model Class Initialized
INFO - 2016-03-09 11:13:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:13:27 --> Pagination Class Initialized
INFO - 2016-03-09 11:13:27 --> Helper loaded: text_helper
INFO - 2016-03-09 11:13:27 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:13:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:13:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:13:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:13:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:13:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:13:27 --> Final output sent to browser
DEBUG - 2016-03-09 14:13:27 --> Total execution time: 1.1208
INFO - 2016-03-09 11:13:30 --> Config Class Initialized
INFO - 2016-03-09 11:13:30 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:13:30 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:13:30 --> Utf8 Class Initialized
INFO - 2016-03-09 11:13:30 --> URI Class Initialized
INFO - 2016-03-09 11:13:30 --> Router Class Initialized
INFO - 2016-03-09 11:13:30 --> Output Class Initialized
INFO - 2016-03-09 11:13:30 --> Security Class Initialized
DEBUG - 2016-03-09 11:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:13:30 --> Input Class Initialized
INFO - 2016-03-09 11:13:30 --> Language Class Initialized
INFO - 2016-03-09 11:13:30 --> Loader Class Initialized
INFO - 2016-03-09 11:13:30 --> Helper loaded: url_helper
INFO - 2016-03-09 11:13:30 --> Helper loaded: file_helper
INFO - 2016-03-09 11:13:30 --> Helper loaded: date_helper
INFO - 2016-03-09 11:13:30 --> Helper loaded: form_helper
INFO - 2016-03-09 11:13:30 --> Database Driver Class Initialized
INFO - 2016-03-09 11:13:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:13:31 --> Controller Class Initialized
INFO - 2016-03-09 11:13:31 --> Model Class Initialized
INFO - 2016-03-09 11:13:31 --> Model Class Initialized
INFO - 2016-03-09 11:13:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:13:31 --> Pagination Class Initialized
INFO - 2016-03-09 11:13:31 --> Helper loaded: text_helper
INFO - 2016-03-09 11:13:31 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:13:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:13:31 --> Final output sent to browser
DEBUG - 2016-03-09 14:13:31 --> Total execution time: 1.1245
INFO - 2016-03-09 11:13:32 --> Config Class Initialized
INFO - 2016-03-09 11:13:32 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:13:32 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:13:32 --> Utf8 Class Initialized
INFO - 2016-03-09 11:13:32 --> URI Class Initialized
INFO - 2016-03-09 11:13:32 --> Router Class Initialized
INFO - 2016-03-09 11:13:32 --> Output Class Initialized
INFO - 2016-03-09 11:13:32 --> Security Class Initialized
DEBUG - 2016-03-09 11:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:13:32 --> Input Class Initialized
INFO - 2016-03-09 11:13:32 --> Language Class Initialized
INFO - 2016-03-09 11:13:32 --> Loader Class Initialized
INFO - 2016-03-09 11:13:32 --> Helper loaded: url_helper
INFO - 2016-03-09 11:13:32 --> Helper loaded: file_helper
INFO - 2016-03-09 11:13:32 --> Helper loaded: date_helper
INFO - 2016-03-09 11:13:32 --> Helper loaded: form_helper
INFO - 2016-03-09 11:13:32 --> Database Driver Class Initialized
INFO - 2016-03-09 11:13:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:13:33 --> Controller Class Initialized
INFO - 2016-03-09 11:13:33 --> Model Class Initialized
INFO - 2016-03-09 11:13:33 --> Model Class Initialized
INFO - 2016-03-09 11:13:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:13:33 --> Pagination Class Initialized
INFO - 2016-03-09 11:13:33 --> Helper loaded: text_helper
INFO - 2016-03-09 11:13:33 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 14:13:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:13:33 --> Final output sent to browser
DEBUG - 2016-03-09 14:13:33 --> Total execution time: 1.1620
INFO - 2016-03-09 11:16:20 --> Config Class Initialized
INFO - 2016-03-09 11:16:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:16:20 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:16:20 --> Utf8 Class Initialized
INFO - 2016-03-09 11:16:20 --> URI Class Initialized
INFO - 2016-03-09 11:16:20 --> Router Class Initialized
INFO - 2016-03-09 11:16:20 --> Output Class Initialized
INFO - 2016-03-09 11:16:20 --> Security Class Initialized
DEBUG - 2016-03-09 11:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:16:20 --> Input Class Initialized
INFO - 2016-03-09 11:16:20 --> Language Class Initialized
INFO - 2016-03-09 11:16:20 --> Loader Class Initialized
INFO - 2016-03-09 11:16:20 --> Helper loaded: url_helper
INFO - 2016-03-09 11:16:20 --> Helper loaded: file_helper
INFO - 2016-03-09 11:16:20 --> Helper loaded: date_helper
INFO - 2016-03-09 11:16:20 --> Helper loaded: form_helper
INFO - 2016-03-09 11:16:20 --> Database Driver Class Initialized
INFO - 2016-03-09 11:16:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:16:21 --> Controller Class Initialized
INFO - 2016-03-09 11:16:21 --> Model Class Initialized
INFO - 2016-03-09 11:16:21 --> Model Class Initialized
INFO - 2016-03-09 11:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:16:21 --> Pagination Class Initialized
INFO - 2016-03-09 11:16:21 --> Helper loaded: text_helper
INFO - 2016-03-09 11:16:21 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:16:21 --> Final output sent to browser
DEBUG - 2016-03-09 14:16:21 --> Total execution time: 1.0986
INFO - 2016-03-09 11:26:33 --> Config Class Initialized
INFO - 2016-03-09 11:26:33 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:26:33 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:26:33 --> Utf8 Class Initialized
INFO - 2016-03-09 11:26:33 --> URI Class Initialized
INFO - 2016-03-09 11:26:33 --> Router Class Initialized
INFO - 2016-03-09 11:26:33 --> Output Class Initialized
INFO - 2016-03-09 11:26:33 --> Security Class Initialized
DEBUG - 2016-03-09 11:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:26:33 --> Input Class Initialized
INFO - 2016-03-09 11:26:33 --> Language Class Initialized
INFO - 2016-03-09 11:26:33 --> Loader Class Initialized
INFO - 2016-03-09 11:26:33 --> Helper loaded: url_helper
INFO - 2016-03-09 11:26:33 --> Helper loaded: file_helper
INFO - 2016-03-09 11:26:33 --> Helper loaded: date_helper
INFO - 2016-03-09 11:26:33 --> Helper loaded: form_helper
INFO - 2016-03-09 11:26:33 --> Database Driver Class Initialized
INFO - 2016-03-09 11:26:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:26:34 --> Controller Class Initialized
INFO - 2016-03-09 11:26:34 --> Model Class Initialized
INFO - 2016-03-09 11:26:34 --> Model Class Initialized
INFO - 2016-03-09 11:26:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:26:34 --> Pagination Class Initialized
INFO - 2016-03-09 11:26:34 --> Helper loaded: text_helper
INFO - 2016-03-09 11:26:34 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 14:26:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:26:34 --> Final output sent to browser
DEBUG - 2016-03-09 14:26:34 --> Total execution time: 1.1970
INFO - 2016-03-09 11:30:31 --> Config Class Initialized
INFO - 2016-03-09 11:30:31 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:30:31 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:30:31 --> Utf8 Class Initialized
INFO - 2016-03-09 11:30:31 --> URI Class Initialized
INFO - 2016-03-09 11:30:31 --> Router Class Initialized
INFO - 2016-03-09 11:30:31 --> Output Class Initialized
INFO - 2016-03-09 11:30:31 --> Security Class Initialized
DEBUG - 2016-03-09 11:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:30:31 --> Input Class Initialized
INFO - 2016-03-09 11:30:31 --> Language Class Initialized
INFO - 2016-03-09 11:30:31 --> Loader Class Initialized
INFO - 2016-03-09 11:30:31 --> Helper loaded: url_helper
INFO - 2016-03-09 11:30:31 --> Helper loaded: file_helper
INFO - 2016-03-09 11:30:31 --> Helper loaded: date_helper
INFO - 2016-03-09 11:30:31 --> Helper loaded: form_helper
INFO - 2016-03-09 11:30:31 --> Database Driver Class Initialized
INFO - 2016-03-09 11:30:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:30:32 --> Controller Class Initialized
INFO - 2016-03-09 11:30:32 --> Model Class Initialized
INFO - 2016-03-09 11:30:32 --> Model Class Initialized
INFO - 2016-03-09 11:30:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:30:32 --> Pagination Class Initialized
INFO - 2016-03-09 11:30:32 --> Helper loaded: text_helper
INFO - 2016-03-09 11:30:32 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:30:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:30:32 --> Final output sent to browser
DEBUG - 2016-03-09 14:30:32 --> Total execution time: 1.1293
INFO - 2016-03-09 11:30:34 --> Config Class Initialized
INFO - 2016-03-09 11:30:34 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:30:34 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:30:34 --> Utf8 Class Initialized
INFO - 2016-03-09 11:30:34 --> URI Class Initialized
INFO - 2016-03-09 11:30:34 --> Router Class Initialized
INFO - 2016-03-09 11:30:34 --> Output Class Initialized
INFO - 2016-03-09 11:30:34 --> Security Class Initialized
DEBUG - 2016-03-09 11:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:30:34 --> Input Class Initialized
INFO - 2016-03-09 11:30:34 --> Language Class Initialized
INFO - 2016-03-09 11:30:34 --> Loader Class Initialized
INFO - 2016-03-09 11:30:34 --> Helper loaded: url_helper
INFO - 2016-03-09 11:30:34 --> Helper loaded: file_helper
INFO - 2016-03-09 11:30:34 --> Helper loaded: date_helper
INFO - 2016-03-09 11:30:34 --> Helper loaded: form_helper
INFO - 2016-03-09 11:30:34 --> Database Driver Class Initialized
INFO - 2016-03-09 11:30:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:30:35 --> Controller Class Initialized
INFO - 2016-03-09 11:30:35 --> Model Class Initialized
INFO - 2016-03-09 11:30:35 --> Model Class Initialized
INFO - 2016-03-09 11:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:30:35 --> Pagination Class Initialized
INFO - 2016-03-09 11:30:35 --> Helper loaded: text_helper
INFO - 2016-03-09 11:30:35 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:30:35 --> Final output sent to browser
DEBUG - 2016-03-09 14:30:35 --> Total execution time: 1.1101
INFO - 2016-03-09 11:30:37 --> Config Class Initialized
INFO - 2016-03-09 11:30:37 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:30:37 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:30:37 --> Utf8 Class Initialized
INFO - 2016-03-09 11:30:37 --> URI Class Initialized
INFO - 2016-03-09 11:30:37 --> Router Class Initialized
INFO - 2016-03-09 11:30:37 --> Output Class Initialized
INFO - 2016-03-09 11:30:37 --> Security Class Initialized
DEBUG - 2016-03-09 11:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:30:37 --> Input Class Initialized
INFO - 2016-03-09 11:30:37 --> Language Class Initialized
INFO - 2016-03-09 11:30:37 --> Loader Class Initialized
INFO - 2016-03-09 11:30:37 --> Helper loaded: url_helper
INFO - 2016-03-09 11:30:37 --> Helper loaded: file_helper
INFO - 2016-03-09 11:30:37 --> Helper loaded: date_helper
INFO - 2016-03-09 11:30:37 --> Helper loaded: form_helper
INFO - 2016-03-09 11:30:37 --> Database Driver Class Initialized
INFO - 2016-03-09 11:30:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:30:38 --> Controller Class Initialized
INFO - 2016-03-09 11:30:38 --> Model Class Initialized
INFO - 2016-03-09 11:30:38 --> Model Class Initialized
INFO - 2016-03-09 11:30:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:30:38 --> Pagination Class Initialized
INFO - 2016-03-09 11:30:38 --> Helper loaded: text_helper
INFO - 2016-03-09 11:30:38 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 14:30:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:30:38 --> Final output sent to browser
DEBUG - 2016-03-09 14:30:38 --> Total execution time: 1.1220
INFO - 2016-03-09 11:33:43 --> Config Class Initialized
INFO - 2016-03-09 11:33:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:33:43 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:33:43 --> Utf8 Class Initialized
INFO - 2016-03-09 11:33:43 --> URI Class Initialized
INFO - 2016-03-09 11:33:43 --> Router Class Initialized
INFO - 2016-03-09 11:33:43 --> Output Class Initialized
INFO - 2016-03-09 11:33:43 --> Security Class Initialized
DEBUG - 2016-03-09 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:33:43 --> Input Class Initialized
INFO - 2016-03-09 11:33:43 --> Language Class Initialized
INFO - 2016-03-09 11:33:43 --> Loader Class Initialized
INFO - 2016-03-09 11:33:43 --> Helper loaded: url_helper
INFO - 2016-03-09 11:33:43 --> Helper loaded: file_helper
INFO - 2016-03-09 11:33:43 --> Helper loaded: date_helper
INFO - 2016-03-09 11:33:43 --> Helper loaded: form_helper
INFO - 2016-03-09 11:33:43 --> Database Driver Class Initialized
INFO - 2016-03-09 11:33:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:33:44 --> Controller Class Initialized
INFO - 2016-03-09 11:33:44 --> Model Class Initialized
INFO - 2016-03-09 11:33:44 --> Model Class Initialized
INFO - 2016-03-09 11:33:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:33:44 --> Pagination Class Initialized
INFO - 2016-03-09 11:33:44 --> Helper loaded: text_helper
INFO - 2016-03-09 11:33:44 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:33:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:33:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:33:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:33:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:33:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:33:44 --> Final output sent to browser
DEBUG - 2016-03-09 14:33:44 --> Total execution time: 1.1010
INFO - 2016-03-09 11:33:46 --> Config Class Initialized
INFO - 2016-03-09 11:33:46 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:33:46 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:33:46 --> Utf8 Class Initialized
INFO - 2016-03-09 11:33:46 --> URI Class Initialized
INFO - 2016-03-09 11:33:46 --> Router Class Initialized
INFO - 2016-03-09 11:33:46 --> Output Class Initialized
INFO - 2016-03-09 11:33:46 --> Security Class Initialized
DEBUG - 2016-03-09 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:33:46 --> Input Class Initialized
INFO - 2016-03-09 11:33:46 --> Language Class Initialized
INFO - 2016-03-09 11:33:46 --> Loader Class Initialized
INFO - 2016-03-09 11:33:46 --> Helper loaded: url_helper
INFO - 2016-03-09 11:33:46 --> Helper loaded: file_helper
INFO - 2016-03-09 11:33:46 --> Helper loaded: date_helper
INFO - 2016-03-09 11:33:46 --> Helper loaded: form_helper
INFO - 2016-03-09 11:33:46 --> Database Driver Class Initialized
INFO - 2016-03-09 11:33:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:33:47 --> Controller Class Initialized
INFO - 2016-03-09 11:33:47 --> Model Class Initialized
INFO - 2016-03-09 11:33:47 --> Model Class Initialized
INFO - 2016-03-09 11:33:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:33:47 --> Pagination Class Initialized
INFO - 2016-03-09 11:33:47 --> Helper loaded: text_helper
INFO - 2016-03-09 11:33:47 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:33:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:33:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:33:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:33:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:33:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:33:47 --> Final output sent to browser
DEBUG - 2016-03-09 14:33:47 --> Total execution time: 1.1222
INFO - 2016-03-09 11:33:50 --> Config Class Initialized
INFO - 2016-03-09 11:33:50 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:33:50 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:33:50 --> Utf8 Class Initialized
INFO - 2016-03-09 11:33:50 --> URI Class Initialized
INFO - 2016-03-09 11:33:50 --> Router Class Initialized
INFO - 2016-03-09 11:33:50 --> Output Class Initialized
INFO - 2016-03-09 11:33:50 --> Security Class Initialized
DEBUG - 2016-03-09 11:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:33:50 --> Input Class Initialized
INFO - 2016-03-09 11:33:50 --> Language Class Initialized
INFO - 2016-03-09 11:33:50 --> Loader Class Initialized
INFO - 2016-03-09 11:33:50 --> Helper loaded: url_helper
INFO - 2016-03-09 11:33:50 --> Helper loaded: file_helper
INFO - 2016-03-09 11:33:50 --> Helper loaded: date_helper
INFO - 2016-03-09 11:33:50 --> Helper loaded: form_helper
INFO - 2016-03-09 11:33:50 --> Database Driver Class Initialized
INFO - 2016-03-09 11:33:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:33:51 --> Controller Class Initialized
INFO - 2016-03-09 11:33:51 --> Model Class Initialized
INFO - 2016-03-09 11:33:51 --> Model Class Initialized
INFO - 2016-03-09 11:33:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:33:51 --> Pagination Class Initialized
INFO - 2016-03-09 11:33:51 --> Helper loaded: text_helper
INFO - 2016-03-09 11:33:51 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 14:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 14:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 14:33:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:33:51 --> Final output sent to browser
DEBUG - 2016-03-09 14:33:51 --> Total execution time: 1.1799
INFO - 2016-03-09 11:47:37 --> Config Class Initialized
INFO - 2016-03-09 11:47:37 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:47:37 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:47:37 --> Utf8 Class Initialized
INFO - 2016-03-09 11:47:37 --> URI Class Initialized
INFO - 2016-03-09 11:47:37 --> Router Class Initialized
INFO - 2016-03-09 11:47:37 --> Output Class Initialized
INFO - 2016-03-09 11:47:37 --> Security Class Initialized
DEBUG - 2016-03-09 11:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:47:37 --> Input Class Initialized
INFO - 2016-03-09 11:47:37 --> Language Class Initialized
INFO - 2016-03-09 11:47:37 --> Loader Class Initialized
INFO - 2016-03-09 11:47:37 --> Helper loaded: url_helper
INFO - 2016-03-09 11:47:37 --> Helper loaded: file_helper
INFO - 2016-03-09 11:47:37 --> Helper loaded: date_helper
INFO - 2016-03-09 11:47:37 --> Helper loaded: form_helper
INFO - 2016-03-09 11:47:37 --> Database Driver Class Initialized
INFO - 2016-03-09 11:47:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:47:38 --> Controller Class Initialized
INFO - 2016-03-09 11:47:38 --> Model Class Initialized
INFO - 2016-03-09 11:47:38 --> Model Class Initialized
INFO - 2016-03-09 11:47:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:47:38 --> Pagination Class Initialized
INFO - 2016-03-09 11:47:38 --> Helper loaded: text_helper
INFO - 2016-03-09 11:47:38 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 14:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 14:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 14:47:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:47:38 --> Final output sent to browser
DEBUG - 2016-03-09 14:47:38 --> Total execution time: 1.1847
INFO - 2016-03-09 11:50:50 --> Config Class Initialized
INFO - 2016-03-09 11:50:50 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:50:50 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:50:50 --> Utf8 Class Initialized
INFO - 2016-03-09 11:50:50 --> URI Class Initialized
INFO - 2016-03-09 11:50:50 --> Router Class Initialized
INFO - 2016-03-09 11:50:50 --> Output Class Initialized
INFO - 2016-03-09 11:50:50 --> Security Class Initialized
DEBUG - 2016-03-09 11:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:50:50 --> Input Class Initialized
INFO - 2016-03-09 11:50:50 --> Language Class Initialized
INFO - 2016-03-09 11:50:50 --> Loader Class Initialized
INFO - 2016-03-09 11:50:50 --> Helper loaded: url_helper
INFO - 2016-03-09 11:50:50 --> Helper loaded: file_helper
INFO - 2016-03-09 11:50:50 --> Helper loaded: date_helper
INFO - 2016-03-09 11:50:50 --> Helper loaded: form_helper
INFO - 2016-03-09 11:50:50 --> Database Driver Class Initialized
INFO - 2016-03-09 11:50:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:50:51 --> Controller Class Initialized
INFO - 2016-03-09 11:50:51 --> Model Class Initialized
INFO - 2016-03-09 11:50:51 --> Model Class Initialized
INFO - 2016-03-09 11:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:50:51 --> Pagination Class Initialized
INFO - 2016-03-09 11:50:51 --> Helper loaded: text_helper
INFO - 2016-03-09 11:50:51 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:50:51 --> Final output sent to browser
DEBUG - 2016-03-09 14:50:51 --> Total execution time: 1.0990
INFO - 2016-03-09 11:50:52 --> Config Class Initialized
INFO - 2016-03-09 11:50:52 --> Hooks Class Initialized
DEBUG - 2016-03-09 11:50:52 --> UTF-8 Support Enabled
INFO - 2016-03-09 11:50:52 --> Utf8 Class Initialized
INFO - 2016-03-09 11:50:52 --> URI Class Initialized
INFO - 2016-03-09 11:50:52 --> Router Class Initialized
INFO - 2016-03-09 11:50:52 --> Output Class Initialized
INFO - 2016-03-09 11:50:52 --> Security Class Initialized
DEBUG - 2016-03-09 11:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 11:50:53 --> Input Class Initialized
INFO - 2016-03-09 11:50:53 --> Language Class Initialized
INFO - 2016-03-09 11:50:53 --> Loader Class Initialized
INFO - 2016-03-09 11:50:53 --> Helper loaded: url_helper
INFO - 2016-03-09 11:50:53 --> Helper loaded: file_helper
INFO - 2016-03-09 11:50:53 --> Helper loaded: date_helper
INFO - 2016-03-09 11:50:53 --> Helper loaded: form_helper
INFO - 2016-03-09 11:50:53 --> Database Driver Class Initialized
INFO - 2016-03-09 11:50:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 11:50:54 --> Controller Class Initialized
INFO - 2016-03-09 11:50:54 --> Model Class Initialized
INFO - 2016-03-09 11:50:54 --> Model Class Initialized
INFO - 2016-03-09 11:50:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 11:50:54 --> Pagination Class Initialized
INFO - 2016-03-09 11:50:54 --> Helper loaded: text_helper
INFO - 2016-03-09 11:50:54 --> Helper loaded: cookie_helper
INFO - 2016-03-09 14:50:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 14:50:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 14:50:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 14:50:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 14:50:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 14:50:54 --> Final output sent to browser
DEBUG - 2016-03-09 14:50:54 --> Total execution time: 1.1010
INFO - 2016-03-09 12:01:42 --> Config Class Initialized
INFO - 2016-03-09 12:01:42 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:01:42 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:01:42 --> Utf8 Class Initialized
INFO - 2016-03-09 12:01:42 --> URI Class Initialized
INFO - 2016-03-09 12:01:42 --> Router Class Initialized
INFO - 2016-03-09 12:01:42 --> Output Class Initialized
INFO - 2016-03-09 12:01:42 --> Security Class Initialized
DEBUG - 2016-03-09 12:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:01:42 --> Input Class Initialized
INFO - 2016-03-09 12:01:42 --> Language Class Initialized
ERROR - 2016-03-09 12:01:42 --> Severity: Parsing Error --> syntax error, unexpected '';' (T_CONSTANT_ENCAPSED_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 267
INFO - 2016-03-09 12:01:53 --> Config Class Initialized
INFO - 2016-03-09 12:01:53 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:01:53 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:01:53 --> Utf8 Class Initialized
INFO - 2016-03-09 12:01:53 --> URI Class Initialized
INFO - 2016-03-09 12:01:53 --> Router Class Initialized
INFO - 2016-03-09 12:01:53 --> Output Class Initialized
INFO - 2016-03-09 12:01:53 --> Security Class Initialized
DEBUG - 2016-03-09 12:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:01:53 --> Input Class Initialized
INFO - 2016-03-09 12:01:53 --> Language Class Initialized
INFO - 2016-03-09 12:01:53 --> Loader Class Initialized
INFO - 2016-03-09 12:01:53 --> Helper loaded: url_helper
INFO - 2016-03-09 12:01:53 --> Helper loaded: file_helper
INFO - 2016-03-09 12:01:53 --> Helper loaded: date_helper
INFO - 2016-03-09 12:01:53 --> Helper loaded: form_helper
INFO - 2016-03-09 12:01:53 --> Database Driver Class Initialized
INFO - 2016-03-09 12:01:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:01:54 --> Controller Class Initialized
INFO - 2016-03-09 12:01:54 --> Model Class Initialized
INFO - 2016-03-09 12:01:54 --> Model Class Initialized
INFO - 2016-03-09 12:01:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:01:54 --> Pagination Class Initialized
INFO - 2016-03-09 12:01:54 --> Helper loaded: text_helper
INFO - 2016-03-09 12:01:54 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:01:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:01:54 --> Final output sent to browser
DEBUG - 2016-03-09 15:01:54 --> Total execution time: 1.1870
INFO - 2016-03-09 12:01:56 --> Config Class Initialized
INFO - 2016-03-09 12:01:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:01:56 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:01:56 --> Utf8 Class Initialized
INFO - 2016-03-09 12:01:56 --> URI Class Initialized
INFO - 2016-03-09 12:01:56 --> Router Class Initialized
INFO - 2016-03-09 12:01:56 --> Output Class Initialized
INFO - 2016-03-09 12:01:56 --> Security Class Initialized
DEBUG - 2016-03-09 12:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:01:56 --> Input Class Initialized
INFO - 2016-03-09 12:01:56 --> Language Class Initialized
INFO - 2016-03-09 12:01:56 --> Loader Class Initialized
INFO - 2016-03-09 12:01:56 --> Helper loaded: url_helper
INFO - 2016-03-09 12:01:56 --> Helper loaded: file_helper
INFO - 2016-03-09 12:01:56 --> Helper loaded: date_helper
INFO - 2016-03-09 12:01:56 --> Helper loaded: form_helper
INFO - 2016-03-09 12:01:56 --> Database Driver Class Initialized
INFO - 2016-03-09 12:01:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:01:57 --> Controller Class Initialized
INFO - 2016-03-09 12:01:57 --> Model Class Initialized
INFO - 2016-03-09 12:01:57 --> Model Class Initialized
INFO - 2016-03-09 12:01:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:01:57 --> Pagination Class Initialized
INFO - 2016-03-09 12:01:57 --> Helper loaded: text_helper
INFO - 2016-03-09 12:01:57 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:01:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:01:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:01:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:01:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:01:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:01:57 --> Final output sent to browser
DEBUG - 2016-03-09 15:01:57 --> Total execution time: 1.1035
INFO - 2016-03-09 12:02:00 --> Config Class Initialized
INFO - 2016-03-09 12:02:00 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:02:00 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:02:00 --> Utf8 Class Initialized
INFO - 2016-03-09 12:02:00 --> URI Class Initialized
INFO - 2016-03-09 12:02:00 --> Router Class Initialized
INFO - 2016-03-09 12:02:00 --> Output Class Initialized
INFO - 2016-03-09 12:02:00 --> Security Class Initialized
DEBUG - 2016-03-09 12:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:02:00 --> Input Class Initialized
INFO - 2016-03-09 12:02:00 --> Language Class Initialized
INFO - 2016-03-09 12:02:00 --> Loader Class Initialized
INFO - 2016-03-09 12:02:00 --> Helper loaded: url_helper
INFO - 2016-03-09 12:02:00 --> Helper loaded: file_helper
INFO - 2016-03-09 12:02:00 --> Helper loaded: date_helper
INFO - 2016-03-09 12:02:00 --> Helper loaded: form_helper
INFO - 2016-03-09 12:02:00 --> Database Driver Class Initialized
INFO - 2016-03-09 12:02:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:02:01 --> Controller Class Initialized
INFO - 2016-03-09 12:02:01 --> Model Class Initialized
INFO - 2016-03-09 12:02:01 --> Model Class Initialized
INFO - 2016-03-09 12:02:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:02:01 --> Pagination Class Initialized
INFO - 2016-03-09 12:02:01 --> Helper loaded: text_helper
INFO - 2016-03-09 12:02:01 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 15:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 15:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 15:02:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:02:01 --> Final output sent to browser
DEBUG - 2016-03-09 15:02:01 --> Total execution time: 1.1324
INFO - 2016-03-09 12:02:12 --> Config Class Initialized
INFO - 2016-03-09 12:02:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:02:12 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:02:12 --> Utf8 Class Initialized
INFO - 2016-03-09 12:02:12 --> URI Class Initialized
INFO - 2016-03-09 12:02:12 --> Router Class Initialized
INFO - 2016-03-09 12:02:12 --> Output Class Initialized
INFO - 2016-03-09 12:02:12 --> Security Class Initialized
DEBUG - 2016-03-09 12:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:02:12 --> Input Class Initialized
INFO - 2016-03-09 12:02:12 --> Language Class Initialized
INFO - 2016-03-09 12:02:12 --> Loader Class Initialized
INFO - 2016-03-09 12:02:12 --> Helper loaded: url_helper
INFO - 2016-03-09 12:02:12 --> Helper loaded: file_helper
INFO - 2016-03-09 12:02:12 --> Helper loaded: date_helper
INFO - 2016-03-09 12:02:12 --> Helper loaded: form_helper
INFO - 2016-03-09 12:02:12 --> Database Driver Class Initialized
INFO - 2016-03-09 12:02:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:02:13 --> Controller Class Initialized
INFO - 2016-03-09 12:02:13 --> Model Class Initialized
INFO - 2016-03-09 12:02:13 --> Model Class Initialized
INFO - 2016-03-09 12:02:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:02:13 --> Pagination Class Initialized
INFO - 2016-03-09 12:02:13 --> Helper loaded: text_helper
INFO - 2016-03-09 12:02:13 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:02:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:02:13 --> Final output sent to browser
DEBUG - 2016-03-09 15:02:13 --> Total execution time: 1.1073
INFO - 2016-03-09 12:02:25 --> Config Class Initialized
INFO - 2016-03-09 12:02:25 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:02:25 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:02:25 --> Utf8 Class Initialized
INFO - 2016-03-09 12:02:25 --> URI Class Initialized
INFO - 2016-03-09 12:02:25 --> Router Class Initialized
INFO - 2016-03-09 12:02:25 --> Output Class Initialized
INFO - 2016-03-09 12:02:25 --> Security Class Initialized
DEBUG - 2016-03-09 12:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:02:25 --> Input Class Initialized
INFO - 2016-03-09 12:02:25 --> Language Class Initialized
INFO - 2016-03-09 12:02:25 --> Loader Class Initialized
INFO - 2016-03-09 12:02:25 --> Helper loaded: url_helper
INFO - 2016-03-09 12:02:25 --> Helper loaded: file_helper
INFO - 2016-03-09 12:02:25 --> Helper loaded: date_helper
INFO - 2016-03-09 12:02:25 --> Helper loaded: form_helper
INFO - 2016-03-09 12:02:25 --> Database Driver Class Initialized
INFO - 2016-03-09 12:02:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:02:26 --> Controller Class Initialized
INFO - 2016-03-09 12:02:26 --> Model Class Initialized
INFO - 2016-03-09 12:02:26 --> Model Class Initialized
INFO - 2016-03-09 12:02:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:02:26 --> Pagination Class Initialized
INFO - 2016-03-09 12:02:26 --> Helper loaded: text_helper
INFO - 2016-03-09 12:02:26 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-09 15:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-09 15:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list_bottom.php
INFO - 2016-03-09 15:02:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:02:26 --> Final output sent to browser
DEBUG - 2016-03-09 15:02:26 --> Total execution time: 1.1315
INFO - 2016-03-09 12:33:08 --> Config Class Initialized
INFO - 2016-03-09 12:33:08 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:33:08 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:33:08 --> Utf8 Class Initialized
INFO - 2016-03-09 12:33:08 --> URI Class Initialized
INFO - 2016-03-09 12:33:08 --> Router Class Initialized
INFO - 2016-03-09 12:33:08 --> Output Class Initialized
INFO - 2016-03-09 12:33:08 --> Security Class Initialized
DEBUG - 2016-03-09 12:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:33:08 --> Input Class Initialized
INFO - 2016-03-09 12:33:08 --> Language Class Initialized
INFO - 2016-03-09 12:33:08 --> Loader Class Initialized
INFO - 2016-03-09 12:33:08 --> Helper loaded: url_helper
INFO - 2016-03-09 12:33:08 --> Helper loaded: file_helper
INFO - 2016-03-09 12:33:08 --> Helper loaded: date_helper
INFO - 2016-03-09 12:33:08 --> Helper loaded: form_helper
INFO - 2016-03-09 12:33:08 --> Database Driver Class Initialized
INFO - 2016-03-09 12:33:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:33:09 --> Controller Class Initialized
INFO - 2016-03-09 12:33:09 --> Model Class Initialized
INFO - 2016-03-09 12:33:09 --> Model Class Initialized
INFO - 2016-03-09 12:33:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:33:09 --> Pagination Class Initialized
INFO - 2016-03-09 12:33:09 --> Helper loaded: text_helper
INFO - 2016-03-09 12:33:09 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:33:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:33:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:33:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:33:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:33:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:33:09 --> Final output sent to browser
DEBUG - 2016-03-09 15:33:09 --> Total execution time: 1.1282
INFO - 2016-03-09 12:38:54 --> Config Class Initialized
INFO - 2016-03-09 12:38:54 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:38:54 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:38:54 --> Utf8 Class Initialized
INFO - 2016-03-09 12:38:54 --> URI Class Initialized
INFO - 2016-03-09 12:38:54 --> Router Class Initialized
INFO - 2016-03-09 12:38:54 --> Output Class Initialized
INFO - 2016-03-09 12:38:54 --> Security Class Initialized
DEBUG - 2016-03-09 12:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:38:54 --> Input Class Initialized
INFO - 2016-03-09 12:38:54 --> Language Class Initialized
INFO - 2016-03-09 12:38:54 --> Loader Class Initialized
INFO - 2016-03-09 12:38:54 --> Helper loaded: url_helper
INFO - 2016-03-09 12:38:54 --> Helper loaded: file_helper
INFO - 2016-03-09 12:38:54 --> Helper loaded: date_helper
INFO - 2016-03-09 12:38:54 --> Helper loaded: form_helper
INFO - 2016-03-09 12:38:54 --> Database Driver Class Initialized
INFO - 2016-03-09 12:38:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:38:55 --> Controller Class Initialized
INFO - 2016-03-09 12:38:55 --> Model Class Initialized
INFO - 2016-03-09 12:38:55 --> Model Class Initialized
INFO - 2016-03-09 12:38:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:38:55 --> Pagination Class Initialized
INFO - 2016-03-09 12:38:55 --> Helper loaded: text_helper
INFO - 2016-03-09 12:38:55 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:38:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:38:55 --> Final output sent to browser
DEBUG - 2016-03-09 15:38:55 --> Total execution time: 1.1737
INFO - 2016-03-09 12:41:33 --> Config Class Initialized
INFO - 2016-03-09 12:41:33 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:41:33 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:41:33 --> Utf8 Class Initialized
INFO - 2016-03-09 12:41:33 --> URI Class Initialized
INFO - 2016-03-09 12:41:33 --> Router Class Initialized
INFO - 2016-03-09 12:41:33 --> Output Class Initialized
INFO - 2016-03-09 12:41:33 --> Security Class Initialized
DEBUG - 2016-03-09 12:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:41:33 --> Input Class Initialized
INFO - 2016-03-09 12:41:33 --> Language Class Initialized
INFO - 2016-03-09 12:41:33 --> Loader Class Initialized
INFO - 2016-03-09 12:41:33 --> Helper loaded: url_helper
INFO - 2016-03-09 12:41:33 --> Helper loaded: file_helper
INFO - 2016-03-09 12:41:33 --> Helper loaded: date_helper
INFO - 2016-03-09 12:41:33 --> Helper loaded: form_helper
INFO - 2016-03-09 12:41:33 --> Database Driver Class Initialized
INFO - 2016-03-09 12:41:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:41:34 --> Controller Class Initialized
INFO - 2016-03-09 12:41:34 --> Model Class Initialized
INFO - 2016-03-09 12:41:34 --> Model Class Initialized
INFO - 2016-03-09 12:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:41:34 --> Pagination Class Initialized
INFO - 2016-03-09 12:41:34 --> Helper loaded: text_helper
INFO - 2016-03-09 12:41:34 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:41:34 --> Final output sent to browser
DEBUG - 2016-03-09 15:41:34 --> Total execution time: 1.1319
INFO - 2016-03-09 12:42:15 --> Config Class Initialized
INFO - 2016-03-09 12:42:15 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:42:15 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:42:15 --> Utf8 Class Initialized
INFO - 2016-03-09 12:42:15 --> URI Class Initialized
INFO - 2016-03-09 12:42:15 --> Router Class Initialized
INFO - 2016-03-09 12:42:15 --> Output Class Initialized
INFO - 2016-03-09 12:42:15 --> Security Class Initialized
DEBUG - 2016-03-09 12:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:42:15 --> Input Class Initialized
INFO - 2016-03-09 12:42:15 --> Language Class Initialized
INFO - 2016-03-09 12:42:15 --> Loader Class Initialized
INFO - 2016-03-09 12:42:15 --> Helper loaded: url_helper
INFO - 2016-03-09 12:42:15 --> Helper loaded: file_helper
INFO - 2016-03-09 12:42:15 --> Helper loaded: date_helper
INFO - 2016-03-09 12:42:15 --> Helper loaded: form_helper
INFO - 2016-03-09 12:42:15 --> Database Driver Class Initialized
INFO - 2016-03-09 12:42:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:42:16 --> Controller Class Initialized
INFO - 2016-03-09 12:42:16 --> Model Class Initialized
INFO - 2016-03-09 12:42:16 --> Model Class Initialized
INFO - 2016-03-09 12:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:42:16 --> Pagination Class Initialized
INFO - 2016-03-09 12:42:16 --> Helper loaded: text_helper
INFO - 2016-03-09 12:42:16 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:42:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:42:16 --> Final output sent to browser
DEBUG - 2016-03-09 15:42:16 --> Total execution time: 1.1076
INFO - 2016-03-09 12:42:27 --> Config Class Initialized
INFO - 2016-03-09 12:42:27 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:42:27 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:42:27 --> Utf8 Class Initialized
INFO - 2016-03-09 12:42:27 --> URI Class Initialized
INFO - 2016-03-09 12:42:27 --> Router Class Initialized
INFO - 2016-03-09 12:42:27 --> Output Class Initialized
INFO - 2016-03-09 12:42:27 --> Security Class Initialized
DEBUG - 2016-03-09 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:42:27 --> Input Class Initialized
INFO - 2016-03-09 12:42:27 --> Language Class Initialized
INFO - 2016-03-09 12:42:27 --> Loader Class Initialized
INFO - 2016-03-09 12:42:27 --> Helper loaded: url_helper
INFO - 2016-03-09 12:42:27 --> Helper loaded: file_helper
INFO - 2016-03-09 12:42:27 --> Helper loaded: date_helper
INFO - 2016-03-09 12:42:27 --> Helper loaded: form_helper
INFO - 2016-03-09 12:42:27 --> Database Driver Class Initialized
INFO - 2016-03-09 12:42:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:42:28 --> Controller Class Initialized
INFO - 2016-03-09 12:42:28 --> Model Class Initialized
INFO - 2016-03-09 12:42:28 --> Model Class Initialized
INFO - 2016-03-09 12:42:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:42:28 --> Pagination Class Initialized
INFO - 2016-03-09 12:42:28 --> Helper loaded: text_helper
INFO - 2016-03-09 12:42:28 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:42:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:42:28 --> Final output sent to browser
DEBUG - 2016-03-09 15:42:28 --> Total execution time: 1.1496
INFO - 2016-03-09 12:42:51 --> Config Class Initialized
INFO - 2016-03-09 12:42:51 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:42:51 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:42:51 --> Utf8 Class Initialized
INFO - 2016-03-09 12:42:51 --> URI Class Initialized
INFO - 2016-03-09 12:42:51 --> Router Class Initialized
INFO - 2016-03-09 12:42:51 --> Output Class Initialized
INFO - 2016-03-09 12:42:51 --> Security Class Initialized
DEBUG - 2016-03-09 12:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:42:51 --> Input Class Initialized
INFO - 2016-03-09 12:42:51 --> Language Class Initialized
INFO - 2016-03-09 12:42:51 --> Loader Class Initialized
INFO - 2016-03-09 12:42:51 --> Helper loaded: url_helper
INFO - 2016-03-09 12:42:51 --> Helper loaded: file_helper
INFO - 2016-03-09 12:42:51 --> Helper loaded: date_helper
INFO - 2016-03-09 12:42:51 --> Helper loaded: form_helper
INFO - 2016-03-09 12:42:51 --> Database Driver Class Initialized
INFO - 2016-03-09 12:42:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:42:52 --> Controller Class Initialized
INFO - 2016-03-09 12:42:52 --> Model Class Initialized
INFO - 2016-03-09 12:42:52 --> Model Class Initialized
INFO - 2016-03-09 12:42:52 --> Form Validation Class Initialized
INFO - 2016-03-09 12:42:52 --> Helper loaded: text_helper
INFO - 2016-03-09 12:42:52 --> Final output sent to browser
DEBUG - 2016-03-09 12:42:52 --> Total execution time: 1.1115
INFO - 2016-03-09 12:43:30 --> Config Class Initialized
INFO - 2016-03-09 12:43:30 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:43:30 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:43:30 --> Utf8 Class Initialized
INFO - 2016-03-09 12:43:30 --> URI Class Initialized
INFO - 2016-03-09 12:43:30 --> Router Class Initialized
INFO - 2016-03-09 12:43:30 --> Output Class Initialized
INFO - 2016-03-09 12:43:30 --> Security Class Initialized
DEBUG - 2016-03-09 12:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:43:30 --> Input Class Initialized
INFO - 2016-03-09 12:43:30 --> Language Class Initialized
INFO - 2016-03-09 12:43:30 --> Loader Class Initialized
INFO - 2016-03-09 12:43:30 --> Helper loaded: url_helper
INFO - 2016-03-09 12:43:30 --> Helper loaded: file_helper
INFO - 2016-03-09 12:43:30 --> Helper loaded: date_helper
INFO - 2016-03-09 12:43:30 --> Helper loaded: form_helper
INFO - 2016-03-09 12:43:30 --> Database Driver Class Initialized
INFO - 2016-03-09 12:43:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:43:31 --> Controller Class Initialized
INFO - 2016-03-09 12:43:31 --> Model Class Initialized
INFO - 2016-03-09 12:43:31 --> Model Class Initialized
INFO - 2016-03-09 12:43:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:43:31 --> Pagination Class Initialized
INFO - 2016-03-09 12:43:31 --> Helper loaded: text_helper
INFO - 2016-03-09 12:43:31 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:43:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:43:31 --> Final output sent to browser
DEBUG - 2016-03-09 15:43:31 --> Total execution time: 1.1029
INFO - 2016-03-09 12:53:36 --> Config Class Initialized
INFO - 2016-03-09 12:53:36 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:53:36 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:53:36 --> Utf8 Class Initialized
INFO - 2016-03-09 12:53:36 --> URI Class Initialized
INFO - 2016-03-09 12:53:36 --> Router Class Initialized
INFO - 2016-03-09 12:53:36 --> Output Class Initialized
INFO - 2016-03-09 12:53:36 --> Security Class Initialized
DEBUG - 2016-03-09 12:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:53:36 --> Input Class Initialized
INFO - 2016-03-09 12:53:36 --> Language Class Initialized
INFO - 2016-03-09 12:53:36 --> Loader Class Initialized
INFO - 2016-03-09 12:53:36 --> Helper loaded: url_helper
INFO - 2016-03-09 12:53:36 --> Helper loaded: file_helper
INFO - 2016-03-09 12:53:36 --> Helper loaded: date_helper
INFO - 2016-03-09 12:53:36 --> Helper loaded: form_helper
INFO - 2016-03-09 12:53:36 --> Database Driver Class Initialized
INFO - 2016-03-09 12:53:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:53:37 --> Controller Class Initialized
INFO - 2016-03-09 12:53:37 --> Model Class Initialized
INFO - 2016-03-09 12:53:37 --> Model Class Initialized
INFO - 2016-03-09 12:53:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:53:37 --> Pagination Class Initialized
INFO - 2016-03-09 12:53:37 --> Helper loaded: text_helper
INFO - 2016-03-09 12:53:37 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:53:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:53:37 --> Final output sent to browser
DEBUG - 2016-03-09 15:53:37 --> Total execution time: 1.1057
INFO - 2016-03-09 12:54:22 --> Config Class Initialized
INFO - 2016-03-09 12:54:22 --> Hooks Class Initialized
DEBUG - 2016-03-09 12:54:22 --> UTF-8 Support Enabled
INFO - 2016-03-09 12:54:22 --> Utf8 Class Initialized
INFO - 2016-03-09 12:54:23 --> URI Class Initialized
INFO - 2016-03-09 12:54:23 --> Router Class Initialized
INFO - 2016-03-09 12:54:23 --> Output Class Initialized
INFO - 2016-03-09 12:54:23 --> Security Class Initialized
DEBUG - 2016-03-09 12:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 12:54:23 --> Input Class Initialized
INFO - 2016-03-09 12:54:23 --> Language Class Initialized
INFO - 2016-03-09 12:54:23 --> Loader Class Initialized
INFO - 2016-03-09 12:54:23 --> Helper loaded: url_helper
INFO - 2016-03-09 12:54:23 --> Helper loaded: file_helper
INFO - 2016-03-09 12:54:23 --> Helper loaded: date_helper
INFO - 2016-03-09 12:54:23 --> Helper loaded: form_helper
INFO - 2016-03-09 12:54:23 --> Database Driver Class Initialized
INFO - 2016-03-09 12:54:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 12:54:24 --> Controller Class Initialized
INFO - 2016-03-09 12:54:24 --> Model Class Initialized
INFO - 2016-03-09 12:54:24 --> Model Class Initialized
INFO - 2016-03-09 12:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 12:54:24 --> Pagination Class Initialized
INFO - 2016-03-09 12:54:24 --> Helper loaded: text_helper
INFO - 2016-03-09 12:54:24 --> Helper loaded: cookie_helper
INFO - 2016-03-09 15:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 15:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 15:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-09 15:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-09 15:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 15:54:24 --> Final output sent to browser
DEBUG - 2016-03-09 15:54:24 --> Total execution time: 1.1079
INFO - 2016-03-09 14:01:54 --> Config Class Initialized
INFO - 2016-03-09 14:01:54 --> Hooks Class Initialized
DEBUG - 2016-03-09 14:01:54 --> UTF-8 Support Enabled
INFO - 2016-03-09 14:01:54 --> Utf8 Class Initialized
INFO - 2016-03-09 14:01:54 --> URI Class Initialized
DEBUG - 2016-03-09 14:01:54 --> No URI present. Default controller set.
INFO - 2016-03-09 14:01:54 --> Router Class Initialized
INFO - 2016-03-09 14:01:54 --> Output Class Initialized
INFO - 2016-03-09 14:01:54 --> Security Class Initialized
DEBUG - 2016-03-09 14:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-09 14:01:54 --> Input Class Initialized
INFO - 2016-03-09 14:01:54 --> Language Class Initialized
INFO - 2016-03-09 14:01:54 --> Loader Class Initialized
INFO - 2016-03-09 14:01:54 --> Helper loaded: url_helper
INFO - 2016-03-09 14:01:54 --> Helper loaded: file_helper
INFO - 2016-03-09 14:01:54 --> Helper loaded: date_helper
INFO - 2016-03-09 14:01:54 --> Helper loaded: form_helper
INFO - 2016-03-09 14:01:54 --> Database Driver Class Initialized
INFO - 2016-03-09 14:01:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-09 14:01:55 --> Controller Class Initialized
INFO - 2016-03-09 14:01:55 --> Model Class Initialized
INFO - 2016-03-09 14:01:55 --> Model Class Initialized
INFO - 2016-03-09 14:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-09 14:01:55 --> Pagination Class Initialized
INFO - 2016-03-09 14:01:55 --> Helper loaded: text_helper
INFO - 2016-03-09 14:01:55 --> Helper loaded: cookie_helper
INFO - 2016-03-09 17:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-09 17:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-09 17:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-09 17:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-09 17:01:55 --> Final output sent to browser
DEBUG - 2016-03-09 17:01:55 --> Total execution time: 1.1350
