<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-02-23 05:22:58 --> Config Class Initialized
INFO - 2016-02-23 05:22:58 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:22:58 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:22:58 --> Utf8 Class Initialized
INFO - 2016-02-23 05:22:59 --> URI Class Initialized
DEBUG - 2016-02-23 05:22:59 --> No URI present. Default controller set.
INFO - 2016-02-23 05:22:59 --> Router Class Initialized
INFO - 2016-02-23 05:22:59 --> Output Class Initialized
INFO - 2016-02-23 05:22:59 --> Security Class Initialized
DEBUG - 2016-02-23 05:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:22:59 --> Input Class Initialized
INFO - 2016-02-23 05:22:59 --> Language Class Initialized
INFO - 2016-02-23 05:22:59 --> Loader Class Initialized
INFO - 2016-02-23 05:22:59 --> Helper loaded: url_helper
INFO - 2016-02-23 05:22:59 --> Helper loaded: file_helper
INFO - 2016-02-23 05:22:59 --> Helper loaded: date_helper
INFO - 2016-02-23 05:22:59 --> Helper loaded: form_helper
INFO - 2016-02-23 05:22:59 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:00 --> Controller Class Initialized
INFO - 2016-02-23 05:23:00 --> Model Class Initialized
INFO - 2016-02-23 05:23:00 --> Model Class Initialized
INFO - 2016-02-23 05:23:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:00 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:00 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:00 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 08:23:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:00 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:00 --> Total execution time: 1.1538
INFO - 2016-02-23 05:23:03 --> Config Class Initialized
INFO - 2016-02-23 05:23:03 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:23:03 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:23:03 --> Utf8 Class Initialized
INFO - 2016-02-23 05:23:03 --> URI Class Initialized
INFO - 2016-02-23 05:23:03 --> Router Class Initialized
INFO - 2016-02-23 05:23:03 --> Output Class Initialized
INFO - 2016-02-23 05:23:03 --> Security Class Initialized
DEBUG - 2016-02-23 05:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:23:03 --> Input Class Initialized
INFO - 2016-02-23 05:23:03 --> Language Class Initialized
INFO - 2016-02-23 05:23:03 --> Loader Class Initialized
INFO - 2016-02-23 05:23:03 --> Helper loaded: url_helper
INFO - 2016-02-23 05:23:03 --> Helper loaded: file_helper
INFO - 2016-02-23 05:23:03 --> Helper loaded: date_helper
INFO - 2016-02-23 05:23:03 --> Helper loaded: form_helper
INFO - 2016-02-23 05:23:03 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:04 --> Controller Class Initialized
INFO - 2016-02-23 05:23:04 --> Model Class Initialized
INFO - 2016-02-23 05:23:04 --> Model Class Initialized
INFO - 2016-02-23 05:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:04 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:04 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:04 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 08:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:04 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:04 --> Total execution time: 1.0999
INFO - 2016-02-23 05:23:05 --> Config Class Initialized
INFO - 2016-02-23 05:23:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:23:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:23:05 --> Utf8 Class Initialized
INFO - 2016-02-23 05:23:05 --> URI Class Initialized
INFO - 2016-02-23 05:23:05 --> Router Class Initialized
INFO - 2016-02-23 05:23:05 --> Output Class Initialized
INFO - 2016-02-23 05:23:05 --> Security Class Initialized
DEBUG - 2016-02-23 05:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:23:05 --> Input Class Initialized
INFO - 2016-02-23 05:23:05 --> Language Class Initialized
INFO - 2016-02-23 05:23:05 --> Loader Class Initialized
INFO - 2016-02-23 05:23:05 --> Helper loaded: url_helper
INFO - 2016-02-23 05:23:05 --> Helper loaded: file_helper
INFO - 2016-02-23 05:23:05 --> Helper loaded: date_helper
INFO - 2016-02-23 05:23:05 --> Helper loaded: form_helper
INFO - 2016-02-23 05:23:05 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:06 --> Controller Class Initialized
INFO - 2016-02-23 05:23:06 --> Model Class Initialized
INFO - 2016-02-23 05:23:06 --> Model Class Initialized
INFO - 2016-02-23 05:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:06 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:06 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:06 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 08:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:06 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:06 --> Total execution time: 1.1466
INFO - 2016-02-23 05:23:07 --> Config Class Initialized
INFO - 2016-02-23 05:23:07 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:23:07 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:23:07 --> Utf8 Class Initialized
INFO - 2016-02-23 05:23:07 --> URI Class Initialized
INFO - 2016-02-23 05:23:07 --> Router Class Initialized
INFO - 2016-02-23 05:23:07 --> Output Class Initialized
INFO - 2016-02-23 05:23:07 --> Security Class Initialized
DEBUG - 2016-02-23 05:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:23:07 --> Input Class Initialized
INFO - 2016-02-23 05:23:07 --> Language Class Initialized
INFO - 2016-02-23 05:23:07 --> Loader Class Initialized
INFO - 2016-02-23 05:23:07 --> Helper loaded: url_helper
INFO - 2016-02-23 05:23:07 --> Helper loaded: file_helper
INFO - 2016-02-23 05:23:07 --> Helper loaded: date_helper
INFO - 2016-02-23 05:23:07 --> Helper loaded: form_helper
INFO - 2016-02-23 05:23:07 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:08 --> Controller Class Initialized
INFO - 2016-02-23 05:23:08 --> Model Class Initialized
INFO - 2016-02-23 05:23:08 --> Model Class Initialized
INFO - 2016-02-23 05:23:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:08 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:08 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:08 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 08:23:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:08 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:08 --> Total execution time: 1.1084
INFO - 2016-02-23 05:23:18 --> Config Class Initialized
INFO - 2016-02-23 05:23:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:23:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:23:18 --> Utf8 Class Initialized
INFO - 2016-02-23 05:23:18 --> URI Class Initialized
INFO - 2016-02-23 05:23:18 --> Router Class Initialized
INFO - 2016-02-23 05:23:18 --> Output Class Initialized
INFO - 2016-02-23 05:23:18 --> Security Class Initialized
DEBUG - 2016-02-23 05:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:23:18 --> Input Class Initialized
INFO - 2016-02-23 05:23:18 --> Language Class Initialized
INFO - 2016-02-23 05:23:18 --> Loader Class Initialized
INFO - 2016-02-23 05:23:18 --> Helper loaded: url_helper
INFO - 2016-02-23 05:23:18 --> Helper loaded: file_helper
INFO - 2016-02-23 05:23:18 --> Helper loaded: date_helper
INFO - 2016-02-23 05:23:18 --> Helper loaded: form_helper
INFO - 2016-02-23 05:23:18 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:19 --> Controller Class Initialized
INFO - 2016-02-23 05:23:19 --> Model Class Initialized
INFO - 2016-02-23 05:23:19 --> Model Class Initialized
INFO - 2016-02-23 05:23:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:19 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:19 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:19 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 08:23:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:19 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:19 --> Total execution time: 1.1190
INFO - 2016-02-23 05:23:21 --> Config Class Initialized
INFO - 2016-02-23 05:23:21 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:23:21 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:23:21 --> Utf8 Class Initialized
INFO - 2016-02-23 05:23:21 --> URI Class Initialized
INFO - 2016-02-23 05:23:21 --> Router Class Initialized
INFO - 2016-02-23 05:23:21 --> Output Class Initialized
INFO - 2016-02-23 05:23:21 --> Security Class Initialized
DEBUG - 2016-02-23 05:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:23:21 --> Input Class Initialized
INFO - 2016-02-23 05:23:21 --> Language Class Initialized
INFO - 2016-02-23 05:23:21 --> Loader Class Initialized
INFO - 2016-02-23 05:23:21 --> Helper loaded: url_helper
INFO - 2016-02-23 05:23:21 --> Helper loaded: file_helper
INFO - 2016-02-23 05:23:21 --> Helper loaded: date_helper
INFO - 2016-02-23 05:23:21 --> Helper loaded: form_helper
INFO - 2016-02-23 05:23:21 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:22 --> Controller Class Initialized
INFO - 2016-02-23 05:23:22 --> Model Class Initialized
INFO - 2016-02-23 05:23:22 --> Model Class Initialized
INFO - 2016-02-23 05:23:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:22 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:22 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:22 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 08:23:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:22 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:22 --> Total execution time: 1.1101
INFO - 2016-02-23 05:23:25 --> Config Class Initialized
INFO - 2016-02-23 05:23:25 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:23:25 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:23:25 --> Utf8 Class Initialized
INFO - 2016-02-23 05:23:25 --> URI Class Initialized
INFO - 2016-02-23 05:23:25 --> Router Class Initialized
INFO - 2016-02-23 05:23:25 --> Output Class Initialized
INFO - 2016-02-23 05:23:25 --> Security Class Initialized
DEBUG - 2016-02-23 05:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:23:25 --> Input Class Initialized
INFO - 2016-02-23 05:23:25 --> Language Class Initialized
INFO - 2016-02-23 05:23:25 --> Loader Class Initialized
INFO - 2016-02-23 05:23:25 --> Helper loaded: url_helper
INFO - 2016-02-23 05:23:25 --> Helper loaded: file_helper
INFO - 2016-02-23 05:23:25 --> Helper loaded: date_helper
INFO - 2016-02-23 05:23:25 --> Helper loaded: form_helper
INFO - 2016-02-23 05:23:25 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:26 --> Controller Class Initialized
INFO - 2016-02-23 05:23:26 --> Model Class Initialized
INFO - 2016-02-23 05:23:26 --> Model Class Initialized
INFO - 2016-02-23 05:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:26 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:26 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:26 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 08:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 08:23:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:26 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:26 --> Total execution time: 1.1831
INFO - 2016-02-23 05:23:43 --> Config Class Initialized
INFO - 2016-02-23 05:23:43 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:23:43 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:23:43 --> Utf8 Class Initialized
INFO - 2016-02-23 05:23:43 --> URI Class Initialized
DEBUG - 2016-02-23 05:23:43 --> No URI present. Default controller set.
INFO - 2016-02-23 05:23:43 --> Router Class Initialized
INFO - 2016-02-23 05:23:43 --> Output Class Initialized
INFO - 2016-02-23 05:23:43 --> Security Class Initialized
DEBUG - 2016-02-23 05:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:23:43 --> Input Class Initialized
INFO - 2016-02-23 05:23:43 --> Language Class Initialized
INFO - 2016-02-23 05:23:43 --> Loader Class Initialized
INFO - 2016-02-23 05:23:43 --> Helper loaded: url_helper
INFO - 2016-02-23 05:23:43 --> Helper loaded: file_helper
INFO - 2016-02-23 05:23:43 --> Helper loaded: date_helper
INFO - 2016-02-23 05:23:43 --> Helper loaded: form_helper
INFO - 2016-02-23 05:23:43 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:44 --> Controller Class Initialized
INFO - 2016-02-23 05:23:44 --> Model Class Initialized
INFO - 2016-02-23 05:23:44 --> Model Class Initialized
INFO - 2016-02-23 05:23:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:44 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:44 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:44 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 08:23:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:44 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:44 --> Total execution time: 1.1087
INFO - 2016-02-23 05:23:58 --> Config Class Initialized
INFO - 2016-02-23 05:23:58 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:23:58 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:23:58 --> Utf8 Class Initialized
INFO - 2016-02-23 05:23:58 --> URI Class Initialized
INFO - 2016-02-23 05:23:58 --> Router Class Initialized
INFO - 2016-02-23 05:23:58 --> Output Class Initialized
INFO - 2016-02-23 05:23:58 --> Security Class Initialized
DEBUG - 2016-02-23 05:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:23:58 --> Input Class Initialized
INFO - 2016-02-23 05:23:58 --> Language Class Initialized
INFO - 2016-02-23 05:23:58 --> Loader Class Initialized
INFO - 2016-02-23 05:23:58 --> Helper loaded: url_helper
INFO - 2016-02-23 05:23:58 --> Helper loaded: file_helper
INFO - 2016-02-23 05:23:58 --> Helper loaded: date_helper
INFO - 2016-02-23 05:23:58 --> Helper loaded: form_helper
INFO - 2016-02-23 05:23:58 --> Database Driver Class Initialized
INFO - 2016-02-23 05:23:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:23:59 --> Controller Class Initialized
INFO - 2016-02-23 05:23:59 --> Model Class Initialized
INFO - 2016-02-23 05:23:59 --> Model Class Initialized
INFO - 2016-02-23 05:23:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:23:59 --> Pagination Class Initialized
INFO - 2016-02-23 05:23:59 --> Helper loaded: text_helper
INFO - 2016-02-23 05:23:59 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 08:23:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:23:59 --> Final output sent to browser
DEBUG - 2016-02-23 08:23:59 --> Total execution time: 1.0897
INFO - 2016-02-23 05:24:14 --> Config Class Initialized
INFO - 2016-02-23 05:24:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:24:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:24:14 --> Utf8 Class Initialized
INFO - 2016-02-23 05:24:14 --> URI Class Initialized
INFO - 2016-02-23 05:24:14 --> Router Class Initialized
INFO - 2016-02-23 05:24:14 --> Output Class Initialized
INFO - 2016-02-23 05:24:14 --> Security Class Initialized
DEBUG - 2016-02-23 05:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:24:14 --> Input Class Initialized
INFO - 2016-02-23 05:24:14 --> Language Class Initialized
INFO - 2016-02-23 05:24:14 --> Loader Class Initialized
INFO - 2016-02-23 05:24:14 --> Helper loaded: url_helper
INFO - 2016-02-23 05:24:14 --> Helper loaded: file_helper
INFO - 2016-02-23 05:24:14 --> Helper loaded: date_helper
INFO - 2016-02-23 05:24:14 --> Helper loaded: form_helper
INFO - 2016-02-23 05:24:14 --> Database Driver Class Initialized
INFO - 2016-02-23 05:24:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:24:15 --> Controller Class Initialized
INFO - 2016-02-23 05:24:15 --> Model Class Initialized
INFO - 2016-02-23 05:24:15 --> Model Class Initialized
INFO - 2016-02-23 05:24:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:24:15 --> Pagination Class Initialized
INFO - 2016-02-23 05:24:15 --> Helper loaded: text_helper
INFO - 2016-02-23 05:24:15 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 08:24:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:24:15 --> Final output sent to browser
DEBUG - 2016-02-23 08:24:15 --> Total execution time: 1.1015
INFO - 2016-02-23 05:31:47 --> Config Class Initialized
INFO - 2016-02-23 05:31:47 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:31:47 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:31:47 --> Utf8 Class Initialized
INFO - 2016-02-23 05:31:47 --> URI Class Initialized
INFO - 2016-02-23 05:31:47 --> Router Class Initialized
INFO - 2016-02-23 05:31:47 --> Output Class Initialized
INFO - 2016-02-23 05:31:47 --> Security Class Initialized
DEBUG - 2016-02-23 05:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:31:47 --> Input Class Initialized
INFO - 2016-02-23 05:31:47 --> Language Class Initialized
INFO - 2016-02-23 05:31:47 --> Loader Class Initialized
INFO - 2016-02-23 05:31:47 --> Helper loaded: url_helper
INFO - 2016-02-23 05:31:47 --> Helper loaded: file_helper
INFO - 2016-02-23 05:31:47 --> Helper loaded: date_helper
INFO - 2016-02-23 05:31:47 --> Helper loaded: form_helper
INFO - 2016-02-23 05:31:47 --> Database Driver Class Initialized
INFO - 2016-02-23 05:31:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:31:48 --> Controller Class Initialized
INFO - 2016-02-23 05:31:48 --> Model Class Initialized
INFO - 2016-02-23 05:31:48 --> Model Class Initialized
INFO - 2016-02-23 05:31:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:31:48 --> Pagination Class Initialized
INFO - 2016-02-23 05:31:48 --> Helper loaded: text_helper
INFO - 2016-02-23 05:31:48 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 08:31:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:31:48 --> Final output sent to browser
DEBUG - 2016-02-23 08:31:48 --> Total execution time: 1.1208
INFO - 2016-02-23 05:48:07 --> Config Class Initialized
INFO - 2016-02-23 05:48:07 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:48:07 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:48:07 --> Utf8 Class Initialized
INFO - 2016-02-23 05:48:07 --> URI Class Initialized
INFO - 2016-02-23 05:48:07 --> Router Class Initialized
INFO - 2016-02-23 05:48:07 --> Output Class Initialized
INFO - 2016-02-23 05:48:07 --> Security Class Initialized
DEBUG - 2016-02-23 05:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:48:07 --> Input Class Initialized
INFO - 2016-02-23 05:48:07 --> Language Class Initialized
ERROR - 2016-02-23 05:48:07 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 44
INFO - 2016-02-23 05:48:48 --> Config Class Initialized
INFO - 2016-02-23 05:48:48 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:48:48 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:48:48 --> Utf8 Class Initialized
INFO - 2016-02-23 05:48:48 --> URI Class Initialized
DEBUG - 2016-02-23 05:48:48 --> No URI present. Default controller set.
INFO - 2016-02-23 05:48:48 --> Router Class Initialized
INFO - 2016-02-23 05:48:48 --> Output Class Initialized
INFO - 2016-02-23 05:48:48 --> Security Class Initialized
DEBUG - 2016-02-23 05:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:48:48 --> Input Class Initialized
INFO - 2016-02-23 05:48:48 --> Language Class Initialized
INFO - 2016-02-23 05:48:48 --> Loader Class Initialized
INFO - 2016-02-23 05:48:48 --> Helper loaded: url_helper
INFO - 2016-02-23 05:48:48 --> Helper loaded: file_helper
INFO - 2016-02-23 05:48:48 --> Helper loaded: date_helper
INFO - 2016-02-23 05:48:48 --> Helper loaded: form_helper
INFO - 2016-02-23 05:48:48 --> Database Driver Class Initialized
INFO - 2016-02-23 05:48:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:48:49 --> Controller Class Initialized
INFO - 2016-02-23 05:48:49 --> Model Class Initialized
INFO - 2016-02-23 05:48:49 --> Model Class Initialized
INFO - 2016-02-23 05:48:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:48:49 --> Pagination Class Initialized
INFO - 2016-02-23 05:48:49 --> Helper loaded: text_helper
INFO - 2016-02-23 05:48:49 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:48:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 08:48:49 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 4
INFO - 2016-02-23 05:49:11 --> Config Class Initialized
INFO - 2016-02-23 05:49:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:49:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:49:11 --> Utf8 Class Initialized
INFO - 2016-02-23 05:49:11 --> URI Class Initialized
DEBUG - 2016-02-23 05:49:11 --> No URI present. Default controller set.
INFO - 2016-02-23 05:49:11 --> Router Class Initialized
INFO - 2016-02-23 05:49:11 --> Output Class Initialized
INFO - 2016-02-23 05:49:11 --> Security Class Initialized
DEBUG - 2016-02-23 05:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:49:11 --> Input Class Initialized
INFO - 2016-02-23 05:49:11 --> Language Class Initialized
INFO - 2016-02-23 05:49:11 --> Loader Class Initialized
INFO - 2016-02-23 05:49:11 --> Helper loaded: url_helper
INFO - 2016-02-23 05:49:11 --> Helper loaded: file_helper
INFO - 2016-02-23 05:49:11 --> Helper loaded: date_helper
INFO - 2016-02-23 05:49:11 --> Helper loaded: form_helper
INFO - 2016-02-23 05:49:11 --> Database Driver Class Initialized
INFO - 2016-02-23 05:49:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:49:12 --> Controller Class Initialized
INFO - 2016-02-23 05:49:12 --> Model Class Initialized
INFO - 2016-02-23 05:49:12 --> Model Class Initialized
INFO - 2016-02-23 05:49:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:49:12 --> Pagination Class Initialized
INFO - 2016-02-23 05:49:12 --> Helper loaded: text_helper
INFO - 2016-02-23 05:49:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:49:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 08:49:12 --> Severity: Parsing Error --> syntax error, unexpected 'printf' (T_STRING) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 4
INFO - 2016-02-23 05:49:32 --> Config Class Initialized
INFO - 2016-02-23 05:49:32 --> Hooks Class Initialized
DEBUG - 2016-02-23 05:49:32 --> UTF-8 Support Enabled
INFO - 2016-02-23 05:49:32 --> Utf8 Class Initialized
INFO - 2016-02-23 05:49:32 --> URI Class Initialized
DEBUG - 2016-02-23 05:49:32 --> No URI present. Default controller set.
INFO - 2016-02-23 05:49:32 --> Router Class Initialized
INFO - 2016-02-23 05:49:32 --> Output Class Initialized
INFO - 2016-02-23 05:49:32 --> Security Class Initialized
DEBUG - 2016-02-23 05:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 05:49:32 --> Input Class Initialized
INFO - 2016-02-23 05:49:32 --> Language Class Initialized
INFO - 2016-02-23 05:49:32 --> Loader Class Initialized
INFO - 2016-02-23 05:49:32 --> Helper loaded: url_helper
INFO - 2016-02-23 05:49:32 --> Helper loaded: file_helper
INFO - 2016-02-23 05:49:32 --> Helper loaded: date_helper
INFO - 2016-02-23 05:49:32 --> Helper loaded: form_helper
INFO - 2016-02-23 05:49:32 --> Database Driver Class Initialized
INFO - 2016-02-23 05:49:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 05:49:33 --> Controller Class Initialized
INFO - 2016-02-23 05:49:33 --> Model Class Initialized
INFO - 2016-02-23 05:49:34 --> Model Class Initialized
INFO - 2016-02-23 05:49:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 05:49:34 --> Pagination Class Initialized
INFO - 2016-02-23 05:49:34 --> Helper loaded: text_helper
INFO - 2016-02-23 05:49:34 --> Helper loaded: cookie_helper
INFO - 2016-02-23 08:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 08:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 08:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 08:49:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 08:49:34 --> Final output sent to browser
DEBUG - 2016-02-23 08:49:34 --> Total execution time: 1.1714
INFO - 2016-02-23 06:13:24 --> Config Class Initialized
INFO - 2016-02-23 06:13:24 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:13:24 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:13:24 --> Utf8 Class Initialized
INFO - 2016-02-23 06:13:24 --> URI Class Initialized
DEBUG - 2016-02-23 06:13:24 --> No URI present. Default controller set.
INFO - 2016-02-23 06:13:24 --> Router Class Initialized
INFO - 2016-02-23 06:13:24 --> Output Class Initialized
INFO - 2016-02-23 06:13:24 --> Security Class Initialized
DEBUG - 2016-02-23 06:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:13:24 --> Input Class Initialized
INFO - 2016-02-23 06:13:24 --> Language Class Initialized
INFO - 2016-02-23 06:13:24 --> Loader Class Initialized
INFO - 2016-02-23 06:13:24 --> Helper loaded: url_helper
INFO - 2016-02-23 06:13:24 --> Helper loaded: file_helper
INFO - 2016-02-23 06:13:24 --> Helper loaded: date_helper
INFO - 2016-02-23 06:13:24 --> Helper loaded: form_helper
INFO - 2016-02-23 06:13:24 --> Database Driver Class Initialized
INFO - 2016-02-23 06:13:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:13:25 --> Controller Class Initialized
INFO - 2016-02-23 06:13:25 --> Model Class Initialized
INFO - 2016-02-23 06:13:25 --> Model Class Initialized
INFO - 2016-02-23 06:13:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:13:25 --> Pagination Class Initialized
INFO - 2016-02-23 06:13:25 --> Helper loaded: text_helper
INFO - 2016-02-23 06:13:25 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 09:13:25 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 4
INFO - 2016-02-23 09:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 09:13:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:13:25 --> Final output sent to browser
DEBUG - 2016-02-23 09:13:25 --> Total execution time: 1.1867
INFO - 2016-02-23 06:13:39 --> Config Class Initialized
INFO - 2016-02-23 06:13:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:13:39 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:13:39 --> Utf8 Class Initialized
INFO - 2016-02-23 06:13:39 --> URI Class Initialized
DEBUG - 2016-02-23 06:13:39 --> No URI present. Default controller set.
INFO - 2016-02-23 06:13:39 --> Router Class Initialized
INFO - 2016-02-23 06:13:39 --> Output Class Initialized
INFO - 2016-02-23 06:13:39 --> Security Class Initialized
DEBUG - 2016-02-23 06:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:13:39 --> Input Class Initialized
INFO - 2016-02-23 06:13:39 --> Language Class Initialized
INFO - 2016-02-23 06:13:39 --> Loader Class Initialized
INFO - 2016-02-23 06:13:39 --> Helper loaded: url_helper
INFO - 2016-02-23 06:13:39 --> Helper loaded: file_helper
INFO - 2016-02-23 06:13:39 --> Helper loaded: date_helper
INFO - 2016-02-23 06:13:39 --> Helper loaded: form_helper
INFO - 2016-02-23 06:13:39 --> Database Driver Class Initialized
INFO - 2016-02-23 06:13:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:13:40 --> Controller Class Initialized
INFO - 2016-02-23 06:13:40 --> Model Class Initialized
INFO - 2016-02-23 06:13:40 --> Model Class Initialized
INFO - 2016-02-23 06:13:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:13:40 --> Pagination Class Initialized
INFO - 2016-02-23 06:13:40 --> Helper loaded: text_helper
INFO - 2016-02-23 06:13:40 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 09:13:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:13:40 --> Final output sent to browser
DEBUG - 2016-02-23 09:13:40 --> Total execution time: 1.1778
INFO - 2016-02-23 06:15:48 --> Config Class Initialized
INFO - 2016-02-23 06:15:48 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:15:48 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:15:48 --> Utf8 Class Initialized
INFO - 2016-02-23 06:15:48 --> URI Class Initialized
INFO - 2016-02-23 06:15:48 --> Router Class Initialized
INFO - 2016-02-23 06:15:48 --> Output Class Initialized
INFO - 2016-02-23 06:15:48 --> Security Class Initialized
DEBUG - 2016-02-23 06:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:15:48 --> Input Class Initialized
INFO - 2016-02-23 06:15:48 --> Language Class Initialized
INFO - 2016-02-23 06:15:48 --> Loader Class Initialized
INFO - 2016-02-23 06:15:48 --> Helper loaded: url_helper
INFO - 2016-02-23 06:15:48 --> Helper loaded: file_helper
INFO - 2016-02-23 06:15:48 --> Helper loaded: date_helper
INFO - 2016-02-23 06:15:48 --> Helper loaded: form_helper
INFO - 2016-02-23 06:15:48 --> Database Driver Class Initialized
INFO - 2016-02-23 06:15:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:15:49 --> Controller Class Initialized
INFO - 2016-02-23 06:15:49 --> Model Class Initialized
INFO - 2016-02-23 06:15:49 --> Model Class Initialized
INFO - 2016-02-23 06:15:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:15:49 --> Pagination Class Initialized
INFO - 2016-02-23 06:15:49 --> Helper loaded: text_helper
INFO - 2016-02-23 06:15:49 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:15:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:15:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 09:15:49 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-23 06:16:13 --> Config Class Initialized
INFO - 2016-02-23 06:16:13 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:16:13 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:16:13 --> Utf8 Class Initialized
INFO - 2016-02-23 06:16:13 --> URI Class Initialized
INFO - 2016-02-23 06:16:13 --> Router Class Initialized
INFO - 2016-02-23 06:16:13 --> Output Class Initialized
INFO - 2016-02-23 06:16:13 --> Security Class Initialized
DEBUG - 2016-02-23 06:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:16:13 --> Input Class Initialized
INFO - 2016-02-23 06:16:13 --> Language Class Initialized
INFO - 2016-02-23 06:16:13 --> Loader Class Initialized
INFO - 2016-02-23 06:16:13 --> Helper loaded: url_helper
INFO - 2016-02-23 06:16:13 --> Helper loaded: file_helper
INFO - 2016-02-23 06:16:13 --> Helper loaded: date_helper
INFO - 2016-02-23 06:16:13 --> Helper loaded: form_helper
INFO - 2016-02-23 06:16:13 --> Database Driver Class Initialized
INFO - 2016-02-23 06:16:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:16:14 --> Controller Class Initialized
INFO - 2016-02-23 06:16:14 --> Model Class Initialized
INFO - 2016-02-23 06:16:14 --> Model Class Initialized
INFO - 2016-02-23 06:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:16:14 --> Pagination Class Initialized
INFO - 2016-02-23 06:16:14 --> Helper loaded: text_helper
INFO - 2016-02-23 06:16:14 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:16:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:16:14 --> Final output sent to browser
DEBUG - 2016-02-23 09:16:14 --> Total execution time: 1.3072
INFO - 2016-02-23 06:16:20 --> Config Class Initialized
INFO - 2016-02-23 06:16:20 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:16:20 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:16:20 --> Utf8 Class Initialized
INFO - 2016-02-23 06:16:20 --> URI Class Initialized
INFO - 2016-02-23 06:16:20 --> Router Class Initialized
INFO - 2016-02-23 06:16:20 --> Output Class Initialized
INFO - 2016-02-23 06:16:20 --> Security Class Initialized
DEBUG - 2016-02-23 06:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:16:20 --> Input Class Initialized
INFO - 2016-02-23 06:16:20 --> Language Class Initialized
INFO - 2016-02-23 06:16:20 --> Loader Class Initialized
INFO - 2016-02-23 06:16:20 --> Helper loaded: url_helper
INFO - 2016-02-23 06:16:20 --> Helper loaded: file_helper
INFO - 2016-02-23 06:16:20 --> Helper loaded: date_helper
INFO - 2016-02-23 06:16:20 --> Helper loaded: form_helper
INFO - 2016-02-23 06:16:20 --> Database Driver Class Initialized
INFO - 2016-02-23 06:16:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:16:21 --> Controller Class Initialized
INFO - 2016-02-23 06:16:21 --> Model Class Initialized
INFO - 2016-02-23 06:16:21 --> Model Class Initialized
INFO - 2016-02-23 06:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:16:21 --> Pagination Class Initialized
INFO - 2016-02-23 06:16:21 --> Helper loaded: text_helper
INFO - 2016-02-23 06:16:21 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 09:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:16:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:16:21 --> Final output sent to browser
DEBUG - 2016-02-23 09:16:21 --> Total execution time: 1.2101
INFO - 2016-02-23 06:16:33 --> Config Class Initialized
INFO - 2016-02-23 06:16:33 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:16:33 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:16:33 --> Utf8 Class Initialized
INFO - 2016-02-23 06:16:33 --> URI Class Initialized
INFO - 2016-02-23 06:16:33 --> Router Class Initialized
INFO - 2016-02-23 06:16:33 --> Output Class Initialized
INFO - 2016-02-23 06:16:33 --> Security Class Initialized
DEBUG - 2016-02-23 06:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:16:33 --> Input Class Initialized
INFO - 2016-02-23 06:16:33 --> Language Class Initialized
INFO - 2016-02-23 06:16:33 --> Loader Class Initialized
INFO - 2016-02-23 06:16:33 --> Helper loaded: url_helper
INFO - 2016-02-23 06:16:33 --> Helper loaded: file_helper
INFO - 2016-02-23 06:16:33 --> Helper loaded: date_helper
INFO - 2016-02-23 06:16:33 --> Helper loaded: form_helper
INFO - 2016-02-23 06:16:33 --> Database Driver Class Initialized
INFO - 2016-02-23 06:16:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:16:34 --> Controller Class Initialized
INFO - 2016-02-23 06:16:34 --> Model Class Initialized
INFO - 2016-02-23 06:16:34 --> Model Class Initialized
INFO - 2016-02-23 06:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:16:34 --> Pagination Class Initialized
INFO - 2016-02-23 06:16:34 --> Helper loaded: text_helper
INFO - 2016-02-23 06:16:34 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 09:16:34 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 164
INFO - 2016-02-23 06:16:34 --> Config Class Initialized
INFO - 2016-02-23 06:16:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:16:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:16:34 --> Utf8 Class Initialized
INFO - 2016-02-23 06:16:34 --> URI Class Initialized
INFO - 2016-02-23 06:16:34 --> Router Class Initialized
INFO - 2016-02-23 06:16:34 --> Output Class Initialized
INFO - 2016-02-23 06:16:34 --> Security Class Initialized
DEBUG - 2016-02-23 06:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:16:34 --> Input Class Initialized
INFO - 2016-02-23 06:16:34 --> Language Class Initialized
INFO - 2016-02-23 06:16:34 --> Loader Class Initialized
INFO - 2016-02-23 06:16:34 --> Helper loaded: url_helper
INFO - 2016-02-23 06:16:34 --> Helper loaded: file_helper
INFO - 2016-02-23 06:16:34 --> Helper loaded: date_helper
INFO - 2016-02-23 06:16:34 --> Helper loaded: form_helper
INFO - 2016-02-23 06:16:34 --> Database Driver Class Initialized
INFO - 2016-02-23 06:16:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:16:35 --> Controller Class Initialized
INFO - 2016-02-23 06:16:35 --> Model Class Initialized
INFO - 2016-02-23 06:16:35 --> Model Class Initialized
INFO - 2016-02-23 06:16:35 --> Form Validation Class Initialized
INFO - 2016-02-23 06:16:35 --> Helper loaded: text_helper
INFO - 2016-02-23 06:16:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 06:16:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 06:16:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-02-23 06:16:35 --> Final output sent to browser
DEBUG - 2016-02-23 06:16:35 --> Total execution time: 1.2691
INFO - 2016-02-23 06:16:41 --> Config Class Initialized
INFO - 2016-02-23 06:16:41 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:16:41 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:16:41 --> Utf8 Class Initialized
INFO - 2016-02-23 06:16:41 --> URI Class Initialized
DEBUG - 2016-02-23 06:16:41 --> No URI present. Default controller set.
INFO - 2016-02-23 06:16:41 --> Router Class Initialized
INFO - 2016-02-23 06:16:41 --> Output Class Initialized
INFO - 2016-02-23 06:16:41 --> Security Class Initialized
DEBUG - 2016-02-23 06:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:16:41 --> Input Class Initialized
INFO - 2016-02-23 06:16:41 --> Language Class Initialized
INFO - 2016-02-23 06:16:41 --> Loader Class Initialized
INFO - 2016-02-23 06:16:41 --> Helper loaded: url_helper
INFO - 2016-02-23 06:16:41 --> Helper loaded: file_helper
INFO - 2016-02-23 06:16:41 --> Helper loaded: date_helper
INFO - 2016-02-23 06:16:41 --> Helper loaded: form_helper
INFO - 2016-02-23 06:16:41 --> Database Driver Class Initialized
INFO - 2016-02-23 06:16:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:16:42 --> Controller Class Initialized
INFO - 2016-02-23 06:16:42 --> Model Class Initialized
INFO - 2016-02-23 06:16:42 --> Model Class Initialized
INFO - 2016-02-23 06:16:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:16:42 --> Pagination Class Initialized
INFO - 2016-02-23 06:16:42 --> Helper loaded: text_helper
INFO - 2016-02-23 06:16:42 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 09:16:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:16:42 --> Final output sent to browser
DEBUG - 2016-02-23 09:16:42 --> Total execution time: 1.1305
INFO - 2016-02-23 06:16:53 --> Config Class Initialized
INFO - 2016-02-23 06:16:53 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:16:53 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:16:53 --> Utf8 Class Initialized
INFO - 2016-02-23 06:16:53 --> URI Class Initialized
INFO - 2016-02-23 06:16:53 --> Router Class Initialized
INFO - 2016-02-23 06:16:53 --> Output Class Initialized
INFO - 2016-02-23 06:16:53 --> Security Class Initialized
DEBUG - 2016-02-23 06:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:16:53 --> Input Class Initialized
INFO - 2016-02-23 06:16:53 --> Language Class Initialized
INFO - 2016-02-23 06:16:53 --> Loader Class Initialized
INFO - 2016-02-23 06:16:53 --> Helper loaded: url_helper
INFO - 2016-02-23 06:16:53 --> Helper loaded: file_helper
INFO - 2016-02-23 06:16:53 --> Helper loaded: date_helper
INFO - 2016-02-23 06:16:53 --> Helper loaded: form_helper
INFO - 2016-02-23 06:16:53 --> Database Driver Class Initialized
INFO - 2016-02-23 06:16:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:16:54 --> Controller Class Initialized
INFO - 2016-02-23 06:16:54 --> Model Class Initialized
INFO - 2016-02-23 06:16:54 --> Model Class Initialized
INFO - 2016-02-23 06:16:54 --> Form Validation Class Initialized
INFO - 2016-02-23 06:16:54 --> Helper loaded: text_helper
INFO - 2016-02-23 06:16:54 --> Config Class Initialized
INFO - 2016-02-23 06:16:54 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:16:54 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:16:54 --> Utf8 Class Initialized
INFO - 2016-02-23 06:16:54 --> URI Class Initialized
DEBUG - 2016-02-23 06:16:54 --> No URI present. Default controller set.
INFO - 2016-02-23 06:16:54 --> Router Class Initialized
INFO - 2016-02-23 06:16:54 --> Output Class Initialized
INFO - 2016-02-23 06:16:54 --> Security Class Initialized
DEBUG - 2016-02-23 06:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:16:54 --> Input Class Initialized
INFO - 2016-02-23 06:16:54 --> Language Class Initialized
INFO - 2016-02-23 06:16:54 --> Loader Class Initialized
INFO - 2016-02-23 06:16:54 --> Helper loaded: url_helper
INFO - 2016-02-23 06:16:54 --> Helper loaded: file_helper
INFO - 2016-02-23 06:16:54 --> Helper loaded: date_helper
INFO - 2016-02-23 06:16:54 --> Helper loaded: form_helper
INFO - 2016-02-23 06:16:54 --> Database Driver Class Initialized
INFO - 2016-02-23 06:16:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:16:55 --> Controller Class Initialized
INFO - 2016-02-23 06:16:55 --> Model Class Initialized
INFO - 2016-02-23 06:16:55 --> Model Class Initialized
INFO - 2016-02-23 06:16:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:16:55 --> Pagination Class Initialized
INFO - 2016-02-23 06:16:55 --> Helper loaded: text_helper
INFO - 2016-02-23 06:16:55 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:16:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 09:16:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:16:56 --> Final output sent to browser
DEBUG - 2016-02-23 09:16:56 --> Total execution time: 1.1623
INFO - 2016-02-23 06:16:58 --> Config Class Initialized
INFO - 2016-02-23 06:16:58 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:16:58 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:16:58 --> Utf8 Class Initialized
INFO - 2016-02-23 06:16:58 --> URI Class Initialized
INFO - 2016-02-23 06:16:58 --> Router Class Initialized
INFO - 2016-02-23 06:16:58 --> Output Class Initialized
INFO - 2016-02-23 06:16:58 --> Security Class Initialized
DEBUG - 2016-02-23 06:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:16:58 --> Input Class Initialized
INFO - 2016-02-23 06:16:58 --> Language Class Initialized
INFO - 2016-02-23 06:16:58 --> Loader Class Initialized
INFO - 2016-02-23 06:16:58 --> Helper loaded: url_helper
INFO - 2016-02-23 06:16:58 --> Helper loaded: file_helper
INFO - 2016-02-23 06:16:58 --> Helper loaded: date_helper
INFO - 2016-02-23 06:16:58 --> Helper loaded: form_helper
INFO - 2016-02-23 06:16:58 --> Database Driver Class Initialized
INFO - 2016-02-23 06:16:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:16:59 --> Controller Class Initialized
INFO - 2016-02-23 06:16:59 --> Model Class Initialized
INFO - 2016-02-23 06:16:59 --> Model Class Initialized
INFO - 2016-02-23 06:16:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:16:59 --> Pagination Class Initialized
INFO - 2016-02-23 06:16:59 --> Helper loaded: text_helper
INFO - 2016-02-23 06:16:59 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:16:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:16:59 --> Final output sent to browser
DEBUG - 2016-02-23 09:16:59 --> Total execution time: 1.1324
INFO - 2016-02-23 06:17:02 --> Config Class Initialized
INFO - 2016-02-23 06:17:02 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:17:02 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:17:02 --> Utf8 Class Initialized
INFO - 2016-02-23 06:17:02 --> URI Class Initialized
INFO - 2016-02-23 06:17:02 --> Router Class Initialized
INFO - 2016-02-23 06:17:02 --> Output Class Initialized
INFO - 2016-02-23 06:17:02 --> Security Class Initialized
DEBUG - 2016-02-23 06:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:17:02 --> Input Class Initialized
INFO - 2016-02-23 06:17:02 --> Language Class Initialized
INFO - 2016-02-23 06:17:02 --> Loader Class Initialized
INFO - 2016-02-23 06:17:02 --> Helper loaded: url_helper
INFO - 2016-02-23 06:17:02 --> Helper loaded: file_helper
INFO - 2016-02-23 06:17:02 --> Helper loaded: date_helper
INFO - 2016-02-23 06:17:02 --> Helper loaded: form_helper
INFO - 2016-02-23 06:17:02 --> Database Driver Class Initialized
INFO - 2016-02-23 06:17:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:17:03 --> Controller Class Initialized
INFO - 2016-02-23 06:17:03 --> Model Class Initialized
INFO - 2016-02-23 06:17:03 --> Model Class Initialized
INFO - 2016-02-23 06:17:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:17:03 --> Pagination Class Initialized
INFO - 2016-02-23 06:17:03 --> Helper loaded: text_helper
INFO - 2016-02-23 06:17:03 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:17:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:17:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:17:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 09:17:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:17:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:17:03 --> Final output sent to browser
DEBUG - 2016-02-23 09:17:03 --> Total execution time: 1.1610
INFO - 2016-02-23 06:17:12 --> Config Class Initialized
INFO - 2016-02-23 06:17:12 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:17:12 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:17:13 --> Utf8 Class Initialized
INFO - 2016-02-23 06:17:13 --> URI Class Initialized
INFO - 2016-02-23 06:17:13 --> Router Class Initialized
INFO - 2016-02-23 06:17:13 --> Output Class Initialized
INFO - 2016-02-23 06:17:13 --> Security Class Initialized
DEBUG - 2016-02-23 06:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:17:13 --> Input Class Initialized
INFO - 2016-02-23 06:17:13 --> Language Class Initialized
INFO - 2016-02-23 06:17:13 --> Loader Class Initialized
INFO - 2016-02-23 06:17:13 --> Helper loaded: url_helper
INFO - 2016-02-23 06:17:13 --> Helper loaded: file_helper
INFO - 2016-02-23 06:17:13 --> Helper loaded: date_helper
INFO - 2016-02-23 06:17:13 --> Helper loaded: form_helper
INFO - 2016-02-23 06:17:13 --> Database Driver Class Initialized
INFO - 2016-02-23 06:17:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:17:14 --> Controller Class Initialized
INFO - 2016-02-23 06:17:14 --> Model Class Initialized
INFO - 2016-02-23 06:17:14 --> Model Class Initialized
INFO - 2016-02-23 06:17:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:17:14 --> Pagination Class Initialized
INFO - 2016-02-23 06:17:14 --> Helper loaded: text_helper
INFO - 2016-02-23 06:17:14 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 09:17:14 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 164
INFO - 2016-02-23 09:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:17:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:17:14 --> Form Validation Class Initialized
INFO - 2016-02-23 09:17:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-23 06:17:14 --> Config Class Initialized
INFO - 2016-02-23 06:17:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:17:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:17:14 --> Utf8 Class Initialized
INFO - 2016-02-23 06:17:14 --> URI Class Initialized
INFO - 2016-02-23 06:17:14 --> Router Class Initialized
INFO - 2016-02-23 06:17:14 --> Output Class Initialized
INFO - 2016-02-23 06:17:14 --> Security Class Initialized
DEBUG - 2016-02-23 06:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:17:14 --> Input Class Initialized
INFO - 2016-02-23 06:17:14 --> Language Class Initialized
INFO - 2016-02-23 06:17:14 --> Loader Class Initialized
INFO - 2016-02-23 06:17:14 --> Helper loaded: url_helper
INFO - 2016-02-23 06:17:14 --> Helper loaded: file_helper
INFO - 2016-02-23 06:17:14 --> Helper loaded: date_helper
INFO - 2016-02-23 06:17:14 --> Helper loaded: form_helper
INFO - 2016-02-23 06:17:14 --> Database Driver Class Initialized
INFO - 2016-02-23 06:17:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:17:15 --> Controller Class Initialized
INFO - 2016-02-23 06:17:15 --> Model Class Initialized
INFO - 2016-02-23 06:17:15 --> Model Class Initialized
INFO - 2016-02-23 06:17:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:17:15 --> Pagination Class Initialized
INFO - 2016-02-23 06:17:15 --> Helper loaded: text_helper
INFO - 2016-02-23 06:17:15 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:17:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:17:15 --> Final output sent to browser
DEBUG - 2016-02-23 09:17:15 --> Total execution time: 1.1908
INFO - 2016-02-23 06:17:18 --> Config Class Initialized
INFO - 2016-02-23 06:17:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:17:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:17:18 --> Utf8 Class Initialized
INFO - 2016-02-23 06:17:18 --> URI Class Initialized
INFO - 2016-02-23 06:17:18 --> Router Class Initialized
INFO - 2016-02-23 06:17:18 --> Output Class Initialized
INFO - 2016-02-23 06:17:18 --> Security Class Initialized
DEBUG - 2016-02-23 06:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:17:18 --> Input Class Initialized
INFO - 2016-02-23 06:17:18 --> Language Class Initialized
INFO - 2016-02-23 06:17:18 --> Loader Class Initialized
INFO - 2016-02-23 06:17:18 --> Helper loaded: url_helper
INFO - 2016-02-23 06:17:18 --> Helper loaded: file_helper
INFO - 2016-02-23 06:17:18 --> Helper loaded: date_helper
INFO - 2016-02-23 06:17:18 --> Helper loaded: form_helper
INFO - 2016-02-23 06:17:18 --> Database Driver Class Initialized
INFO - 2016-02-23 06:17:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:17:19 --> Controller Class Initialized
INFO - 2016-02-23 06:17:19 --> Model Class Initialized
INFO - 2016-02-23 06:17:19 --> Model Class Initialized
INFO - 2016-02-23 06:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:17:19 --> Pagination Class Initialized
INFO - 2016-02-23 06:17:19 --> Helper loaded: text_helper
INFO - 2016-02-23 06:17:19 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:17:19 --> Final output sent to browser
DEBUG - 2016-02-23 09:17:19 --> Total execution time: 1.1420
INFO - 2016-02-23 06:18:13 --> Config Class Initialized
INFO - 2016-02-23 06:18:13 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:18:13 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:18:13 --> Utf8 Class Initialized
INFO - 2016-02-23 06:18:13 --> URI Class Initialized
INFO - 2016-02-23 06:18:13 --> Router Class Initialized
INFO - 2016-02-23 06:18:13 --> Output Class Initialized
INFO - 2016-02-23 06:18:13 --> Security Class Initialized
DEBUG - 2016-02-23 06:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:18:13 --> Input Class Initialized
INFO - 2016-02-23 06:18:13 --> Language Class Initialized
INFO - 2016-02-23 06:18:13 --> Loader Class Initialized
INFO - 2016-02-23 06:18:13 --> Helper loaded: url_helper
INFO - 2016-02-23 06:18:13 --> Helper loaded: file_helper
INFO - 2016-02-23 06:18:13 --> Helper loaded: date_helper
INFO - 2016-02-23 06:18:13 --> Helper loaded: form_helper
INFO - 2016-02-23 06:18:13 --> Database Driver Class Initialized
INFO - 2016-02-23 06:18:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:18:14 --> Controller Class Initialized
INFO - 2016-02-23 06:18:14 --> Model Class Initialized
INFO - 2016-02-23 06:18:14 --> Model Class Initialized
INFO - 2016-02-23 06:18:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:18:14 --> Pagination Class Initialized
INFO - 2016-02-23 06:18:14 --> Helper loaded: text_helper
INFO - 2016-02-23 06:18:14 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 09:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:18:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:18:14 --> Final output sent to browser
DEBUG - 2016-02-23 09:18:14 --> Total execution time: 1.1532
INFO - 2016-02-23 06:18:23 --> Config Class Initialized
INFO - 2016-02-23 06:18:23 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:18:23 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:18:23 --> Utf8 Class Initialized
INFO - 2016-02-23 06:18:23 --> URI Class Initialized
INFO - 2016-02-23 06:18:23 --> Router Class Initialized
INFO - 2016-02-23 06:18:23 --> Output Class Initialized
INFO - 2016-02-23 06:18:23 --> Security Class Initialized
DEBUG - 2016-02-23 06:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:18:23 --> Input Class Initialized
INFO - 2016-02-23 06:18:23 --> Language Class Initialized
INFO - 2016-02-23 06:18:23 --> Loader Class Initialized
INFO - 2016-02-23 06:18:23 --> Helper loaded: url_helper
INFO - 2016-02-23 06:18:23 --> Helper loaded: file_helper
INFO - 2016-02-23 06:18:23 --> Helper loaded: date_helper
INFO - 2016-02-23 06:18:23 --> Helper loaded: form_helper
INFO - 2016-02-23 06:18:23 --> Database Driver Class Initialized
INFO - 2016-02-23 06:18:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:18:24 --> Controller Class Initialized
INFO - 2016-02-23 06:18:24 --> Model Class Initialized
INFO - 2016-02-23 06:18:24 --> Model Class Initialized
INFO - 2016-02-23 06:18:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:18:24 --> Pagination Class Initialized
INFO - 2016-02-23 06:18:24 --> Helper loaded: text_helper
INFO - 2016-02-23 06:18:24 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 09:18:24 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 164
INFO - 2016-02-23 09:18:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:18:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:18:24 --> Form Validation Class Initialized
INFO - 2016-02-23 09:18:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-23 06:18:24 --> Config Class Initialized
INFO - 2016-02-23 06:18:24 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:18:24 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:18:24 --> Utf8 Class Initialized
INFO - 2016-02-23 06:18:24 --> URI Class Initialized
INFO - 2016-02-23 06:18:24 --> Router Class Initialized
INFO - 2016-02-23 06:18:24 --> Output Class Initialized
INFO - 2016-02-23 06:18:24 --> Security Class Initialized
DEBUG - 2016-02-23 06:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:18:24 --> Input Class Initialized
INFO - 2016-02-23 06:18:24 --> Language Class Initialized
INFO - 2016-02-23 06:18:24 --> Loader Class Initialized
INFO - 2016-02-23 06:18:24 --> Helper loaded: url_helper
INFO - 2016-02-23 06:18:24 --> Helper loaded: file_helper
INFO - 2016-02-23 06:18:24 --> Helper loaded: date_helper
INFO - 2016-02-23 06:18:24 --> Helper loaded: form_helper
INFO - 2016-02-23 06:18:24 --> Database Driver Class Initialized
INFO - 2016-02-23 06:18:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:18:25 --> Controller Class Initialized
INFO - 2016-02-23 06:18:25 --> Model Class Initialized
INFO - 2016-02-23 06:18:25 --> Model Class Initialized
INFO - 2016-02-23 06:18:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:18:25 --> Pagination Class Initialized
INFO - 2016-02-23 06:18:25 --> Helper loaded: text_helper
INFO - 2016-02-23 06:18:25 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:18:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:18:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:18:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:18:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:18:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:18:26 --> Final output sent to browser
DEBUG - 2016-02-23 09:18:26 --> Total execution time: 1.2054
INFO - 2016-02-23 06:18:28 --> Config Class Initialized
INFO - 2016-02-23 06:18:28 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:18:28 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:18:28 --> Utf8 Class Initialized
INFO - 2016-02-23 06:18:28 --> URI Class Initialized
INFO - 2016-02-23 06:18:28 --> Router Class Initialized
INFO - 2016-02-23 06:18:28 --> Output Class Initialized
INFO - 2016-02-23 06:18:28 --> Security Class Initialized
DEBUG - 2016-02-23 06:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:18:28 --> Input Class Initialized
INFO - 2016-02-23 06:18:28 --> Language Class Initialized
INFO - 2016-02-23 06:18:28 --> Loader Class Initialized
INFO - 2016-02-23 06:18:28 --> Helper loaded: url_helper
INFO - 2016-02-23 06:18:28 --> Helper loaded: file_helper
INFO - 2016-02-23 06:18:28 --> Helper loaded: date_helper
INFO - 2016-02-23 06:18:28 --> Helper loaded: form_helper
INFO - 2016-02-23 06:18:28 --> Database Driver Class Initialized
INFO - 2016-02-23 06:18:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:18:29 --> Controller Class Initialized
INFO - 2016-02-23 06:18:29 --> Model Class Initialized
INFO - 2016-02-23 06:18:29 --> Model Class Initialized
INFO - 2016-02-23 06:18:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:18:29 --> Pagination Class Initialized
INFO - 2016-02-23 06:18:29 --> Helper loaded: text_helper
INFO - 2016-02-23 06:18:29 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:18:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:18:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 09:18:29 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-23 06:22:47 --> Config Class Initialized
INFO - 2016-02-23 06:22:47 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:22:47 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:22:47 --> Utf8 Class Initialized
INFO - 2016-02-23 06:22:47 --> URI Class Initialized
DEBUG - 2016-02-23 06:22:47 --> No URI present. Default controller set.
INFO - 2016-02-23 06:22:47 --> Router Class Initialized
INFO - 2016-02-23 06:22:47 --> Output Class Initialized
INFO - 2016-02-23 06:22:47 --> Security Class Initialized
DEBUG - 2016-02-23 06:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:22:47 --> Input Class Initialized
INFO - 2016-02-23 06:22:47 --> Language Class Initialized
INFO - 2016-02-23 06:22:47 --> Loader Class Initialized
INFO - 2016-02-23 06:22:47 --> Helper loaded: url_helper
INFO - 2016-02-23 06:22:47 --> Helper loaded: file_helper
INFO - 2016-02-23 06:22:47 --> Helper loaded: date_helper
INFO - 2016-02-23 06:22:47 --> Helper loaded: form_helper
INFO - 2016-02-23 06:22:47 --> Database Driver Class Initialized
INFO - 2016-02-23 06:22:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:22:48 --> Controller Class Initialized
INFO - 2016-02-23 06:22:48 --> Model Class Initialized
INFO - 2016-02-23 06:22:48 --> Model Class Initialized
INFO - 2016-02-23 06:22:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:22:48 --> Pagination Class Initialized
INFO - 2016-02-23 06:22:48 --> Helper loaded: text_helper
INFO - 2016-02-23 06:22:48 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:22:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:22:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 09:22:48 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 3
INFO - 2016-02-23 09:22:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 09:22:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:22:48 --> Final output sent to browser
DEBUG - 2016-02-23 09:22:48 --> Total execution time: 1.1936
INFO - 2016-02-23 06:24:32 --> Config Class Initialized
INFO - 2016-02-23 06:24:32 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:24:32 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:24:32 --> Utf8 Class Initialized
INFO - 2016-02-23 06:24:32 --> URI Class Initialized
INFO - 2016-02-23 06:24:32 --> Router Class Initialized
INFO - 2016-02-23 06:24:32 --> Output Class Initialized
INFO - 2016-02-23 06:24:32 --> Security Class Initialized
DEBUG - 2016-02-23 06:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:24:32 --> Input Class Initialized
INFO - 2016-02-23 06:24:32 --> Language Class Initialized
INFO - 2016-02-23 06:24:32 --> Loader Class Initialized
INFO - 2016-02-23 06:24:32 --> Helper loaded: url_helper
INFO - 2016-02-23 06:24:32 --> Helper loaded: file_helper
INFO - 2016-02-23 06:24:32 --> Helper loaded: date_helper
INFO - 2016-02-23 06:24:32 --> Helper loaded: form_helper
INFO - 2016-02-23 06:24:32 --> Database Driver Class Initialized
INFO - 2016-02-23 06:24:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:24:33 --> Controller Class Initialized
INFO - 2016-02-23 06:24:33 --> Model Class Initialized
INFO - 2016-02-23 06:24:33 --> Model Class Initialized
INFO - 2016-02-23 06:24:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:24:33 --> Pagination Class Initialized
INFO - 2016-02-23 06:24:33 --> Helper loaded: text_helper
INFO - 2016-02-23 06:24:33 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:24:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 09:24:33 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-23 06:25:33 --> Config Class Initialized
INFO - 2016-02-23 06:25:33 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:25:33 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:25:33 --> Utf8 Class Initialized
INFO - 2016-02-23 06:25:33 --> URI Class Initialized
INFO - 2016-02-23 06:25:33 --> Router Class Initialized
INFO - 2016-02-23 06:25:33 --> Output Class Initialized
INFO - 2016-02-23 06:25:33 --> Security Class Initialized
DEBUG - 2016-02-23 06:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:25:33 --> Input Class Initialized
INFO - 2016-02-23 06:25:33 --> Language Class Initialized
INFO - 2016-02-23 06:25:33 --> Loader Class Initialized
INFO - 2016-02-23 06:25:33 --> Helper loaded: url_helper
INFO - 2016-02-23 06:25:33 --> Helper loaded: file_helper
INFO - 2016-02-23 06:25:33 --> Helper loaded: date_helper
INFO - 2016-02-23 06:25:33 --> Helper loaded: form_helper
INFO - 2016-02-23 06:25:33 --> Database Driver Class Initialized
INFO - 2016-02-23 06:25:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:25:34 --> Controller Class Initialized
INFO - 2016-02-23 06:25:34 --> Model Class Initialized
INFO - 2016-02-23 06:25:34 --> Model Class Initialized
INFO - 2016-02-23 06:25:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:25:34 --> Pagination Class Initialized
INFO - 2016-02-23 06:25:34 --> Helper loaded: text_helper
INFO - 2016-02-23 06:25:34 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:25:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:25:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 09:25:34 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-23 06:26:17 --> Config Class Initialized
INFO - 2016-02-23 06:26:17 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:26:17 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:26:17 --> Utf8 Class Initialized
INFO - 2016-02-23 06:26:17 --> URI Class Initialized
INFO - 2016-02-23 06:26:17 --> Router Class Initialized
INFO - 2016-02-23 06:26:17 --> Output Class Initialized
INFO - 2016-02-23 06:26:17 --> Security Class Initialized
DEBUG - 2016-02-23 06:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:26:17 --> Input Class Initialized
INFO - 2016-02-23 06:26:17 --> Language Class Initialized
INFO - 2016-02-23 06:26:17 --> Loader Class Initialized
INFO - 2016-02-23 06:26:17 --> Helper loaded: url_helper
INFO - 2016-02-23 06:26:17 --> Helper loaded: file_helper
INFO - 2016-02-23 06:26:17 --> Helper loaded: date_helper
INFO - 2016-02-23 06:26:17 --> Helper loaded: form_helper
INFO - 2016-02-23 06:26:17 --> Database Driver Class Initialized
INFO - 2016-02-23 06:26:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:26:18 --> Controller Class Initialized
INFO - 2016-02-23 06:26:18 --> Model Class Initialized
INFO - 2016-02-23 06:26:18 --> Model Class Initialized
INFO - 2016-02-23 06:26:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:26:18 --> Pagination Class Initialized
INFO - 2016-02-23 06:26:18 --> Helper loaded: text_helper
INFO - 2016-02-23 06:26:18 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:26:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:26:18 --> Final output sent to browser
DEBUG - 2016-02-23 09:26:18 --> Total execution time: 1.1422
INFO - 2016-02-23 06:26:43 --> Config Class Initialized
INFO - 2016-02-23 06:26:43 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:26:43 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:26:43 --> Utf8 Class Initialized
INFO - 2016-02-23 06:26:43 --> URI Class Initialized
INFO - 2016-02-23 06:26:43 --> Router Class Initialized
INFO - 2016-02-23 06:26:43 --> Output Class Initialized
INFO - 2016-02-23 06:26:43 --> Security Class Initialized
DEBUG - 2016-02-23 06:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:26:43 --> Input Class Initialized
INFO - 2016-02-23 06:26:43 --> Language Class Initialized
INFO - 2016-02-23 06:26:43 --> Loader Class Initialized
INFO - 2016-02-23 06:26:43 --> Helper loaded: url_helper
INFO - 2016-02-23 06:26:43 --> Helper loaded: file_helper
INFO - 2016-02-23 06:26:43 --> Helper loaded: date_helper
INFO - 2016-02-23 06:26:43 --> Helper loaded: form_helper
INFO - 2016-02-23 06:26:43 --> Database Driver Class Initialized
INFO - 2016-02-23 06:26:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:26:44 --> Controller Class Initialized
INFO - 2016-02-23 06:26:44 --> Model Class Initialized
INFO - 2016-02-23 06:26:44 --> Model Class Initialized
INFO - 2016-02-23 06:26:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:26:44 --> Pagination Class Initialized
INFO - 2016-02-23 06:26:44 --> Helper loaded: text_helper
INFO - 2016-02-23 06:26:44 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:26:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:26:44 --> Final output sent to browser
DEBUG - 2016-02-23 09:26:44 --> Total execution time: 1.1630
INFO - 2016-02-23 06:28:26 --> Config Class Initialized
INFO - 2016-02-23 06:28:26 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:28:26 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:28:26 --> Utf8 Class Initialized
INFO - 2016-02-23 06:28:26 --> URI Class Initialized
INFO - 2016-02-23 06:28:26 --> Router Class Initialized
INFO - 2016-02-23 06:28:26 --> Output Class Initialized
INFO - 2016-02-23 06:28:26 --> Security Class Initialized
DEBUG - 2016-02-23 06:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:28:26 --> Input Class Initialized
INFO - 2016-02-23 06:28:26 --> Language Class Initialized
INFO - 2016-02-23 06:28:26 --> Loader Class Initialized
INFO - 2016-02-23 06:28:26 --> Helper loaded: url_helper
INFO - 2016-02-23 06:28:26 --> Helper loaded: file_helper
INFO - 2016-02-23 06:28:26 --> Helper loaded: date_helper
INFO - 2016-02-23 06:28:26 --> Helper loaded: form_helper
INFO - 2016-02-23 06:28:26 --> Database Driver Class Initialized
INFO - 2016-02-23 06:28:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:28:27 --> Controller Class Initialized
INFO - 2016-02-23 06:28:27 --> Model Class Initialized
INFO - 2016-02-23 06:28:27 --> Model Class Initialized
INFO - 2016-02-23 06:28:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:28:27 --> Pagination Class Initialized
INFO - 2016-02-23 06:28:27 --> Helper loaded: text_helper
INFO - 2016-02-23 06:28:27 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:28:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:28:27 --> Final output sent to browser
DEBUG - 2016-02-23 09:28:27 --> Total execution time: 1.1406
INFO - 2016-02-23 06:29:14 --> Config Class Initialized
INFO - 2016-02-23 06:29:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:29:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:29:14 --> Utf8 Class Initialized
INFO - 2016-02-23 06:29:14 --> URI Class Initialized
INFO - 2016-02-23 06:29:14 --> Router Class Initialized
INFO - 2016-02-23 06:29:14 --> Output Class Initialized
INFO - 2016-02-23 06:29:14 --> Security Class Initialized
DEBUG - 2016-02-23 06:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:29:14 --> Input Class Initialized
INFO - 2016-02-23 06:29:14 --> Language Class Initialized
INFO - 2016-02-23 06:29:14 --> Loader Class Initialized
INFO - 2016-02-23 06:29:14 --> Helper loaded: url_helper
INFO - 2016-02-23 06:29:14 --> Helper loaded: file_helper
INFO - 2016-02-23 06:29:14 --> Helper loaded: date_helper
INFO - 2016-02-23 06:29:14 --> Helper loaded: form_helper
INFO - 2016-02-23 06:29:14 --> Database Driver Class Initialized
INFO - 2016-02-23 06:29:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:29:15 --> Controller Class Initialized
INFO - 2016-02-23 06:29:15 --> Model Class Initialized
INFO - 2016-02-23 06:29:15 --> Model Class Initialized
INFO - 2016-02-23 06:29:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:29:15 --> Pagination Class Initialized
INFO - 2016-02-23 06:29:15 --> Helper loaded: text_helper
INFO - 2016-02-23 06:29:15 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:29:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 09:29:15 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-23 06:29:37 --> Config Class Initialized
INFO - 2016-02-23 06:29:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:29:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:29:37 --> Utf8 Class Initialized
INFO - 2016-02-23 06:29:37 --> URI Class Initialized
INFO - 2016-02-23 06:29:37 --> Router Class Initialized
INFO - 2016-02-23 06:29:37 --> Output Class Initialized
INFO - 2016-02-23 06:29:37 --> Security Class Initialized
DEBUG - 2016-02-23 06:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:29:37 --> Input Class Initialized
INFO - 2016-02-23 06:29:37 --> Language Class Initialized
INFO - 2016-02-23 06:29:37 --> Loader Class Initialized
INFO - 2016-02-23 06:29:37 --> Helper loaded: url_helper
INFO - 2016-02-23 06:29:37 --> Helper loaded: file_helper
INFO - 2016-02-23 06:29:37 --> Helper loaded: date_helper
INFO - 2016-02-23 06:29:37 --> Helper loaded: form_helper
INFO - 2016-02-23 06:29:37 --> Database Driver Class Initialized
INFO - 2016-02-23 06:29:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:29:38 --> Controller Class Initialized
INFO - 2016-02-23 06:29:38 --> Model Class Initialized
INFO - 2016-02-23 06:29:38 --> Model Class Initialized
INFO - 2016-02-23 06:29:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:29:38 --> Pagination Class Initialized
INFO - 2016-02-23 06:29:38 --> Helper loaded: text_helper
INFO - 2016-02-23 06:29:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:29:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:29:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 09:29:38 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-23 06:32:23 --> Config Class Initialized
INFO - 2016-02-23 06:32:23 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:32:23 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:32:23 --> Utf8 Class Initialized
INFO - 2016-02-23 06:32:23 --> URI Class Initialized
INFO - 2016-02-23 06:32:23 --> Router Class Initialized
INFO - 2016-02-23 06:32:23 --> Output Class Initialized
INFO - 2016-02-23 06:32:23 --> Security Class Initialized
DEBUG - 2016-02-23 06:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:32:23 --> Input Class Initialized
INFO - 2016-02-23 06:32:23 --> Language Class Initialized
INFO - 2016-02-23 06:32:23 --> Loader Class Initialized
INFO - 2016-02-23 06:32:23 --> Helper loaded: url_helper
INFO - 2016-02-23 06:32:23 --> Helper loaded: file_helper
INFO - 2016-02-23 06:32:23 --> Helper loaded: date_helper
INFO - 2016-02-23 06:32:23 --> Helper loaded: form_helper
INFO - 2016-02-23 06:32:23 --> Database Driver Class Initialized
INFO - 2016-02-23 06:32:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:32:24 --> Controller Class Initialized
INFO - 2016-02-23 06:32:24 --> Model Class Initialized
INFO - 2016-02-23 06:32:24 --> Model Class Initialized
INFO - 2016-02-23 06:32:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:32:24 --> Pagination Class Initialized
INFO - 2016-02-23 06:32:24 --> Helper loaded: text_helper
INFO - 2016-02-23 06:32:24 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:32:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:32:24 --> Final output sent to browser
DEBUG - 2016-02-23 09:32:24 --> Total execution time: 1.1603
INFO - 2016-02-23 06:35:18 --> Config Class Initialized
INFO - 2016-02-23 06:35:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:35:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:35:18 --> Utf8 Class Initialized
INFO - 2016-02-23 06:35:18 --> URI Class Initialized
INFO - 2016-02-23 06:35:18 --> Router Class Initialized
INFO - 2016-02-23 06:35:18 --> Output Class Initialized
INFO - 2016-02-23 06:35:18 --> Security Class Initialized
DEBUG - 2016-02-23 06:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:35:18 --> Input Class Initialized
INFO - 2016-02-23 06:35:18 --> Language Class Initialized
INFO - 2016-02-23 06:35:18 --> Loader Class Initialized
INFO - 2016-02-23 06:35:18 --> Helper loaded: url_helper
INFO - 2016-02-23 06:35:18 --> Helper loaded: file_helper
INFO - 2016-02-23 06:35:18 --> Helper loaded: date_helper
INFO - 2016-02-23 06:35:18 --> Helper loaded: form_helper
INFO - 2016-02-23 06:35:18 --> Database Driver Class Initialized
INFO - 2016-02-23 06:35:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:35:19 --> Controller Class Initialized
INFO - 2016-02-23 06:35:19 --> Model Class Initialized
INFO - 2016-02-23 06:35:19 --> Model Class Initialized
INFO - 2016-02-23 06:35:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:35:19 --> Pagination Class Initialized
INFO - 2016-02-23 06:35:19 --> Helper loaded: text_helper
INFO - 2016-02-23 06:35:19 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:35:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:35:19 --> Final output sent to browser
DEBUG - 2016-02-23 09:35:19 --> Total execution time: 1.1671
INFO - 2016-02-23 06:35:36 --> Config Class Initialized
INFO - 2016-02-23 06:35:36 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:35:36 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:35:36 --> Utf8 Class Initialized
INFO - 2016-02-23 06:35:36 --> URI Class Initialized
INFO - 2016-02-23 06:35:36 --> Router Class Initialized
INFO - 2016-02-23 06:35:36 --> Output Class Initialized
INFO - 2016-02-23 06:35:36 --> Security Class Initialized
DEBUG - 2016-02-23 06:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:35:36 --> Input Class Initialized
INFO - 2016-02-23 06:35:36 --> Language Class Initialized
INFO - 2016-02-23 06:35:36 --> Loader Class Initialized
INFO - 2016-02-23 06:35:36 --> Helper loaded: url_helper
INFO - 2016-02-23 06:35:36 --> Helper loaded: file_helper
INFO - 2016-02-23 06:35:36 --> Helper loaded: date_helper
INFO - 2016-02-23 06:35:36 --> Helper loaded: form_helper
INFO - 2016-02-23 06:35:36 --> Database Driver Class Initialized
INFO - 2016-02-23 06:35:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:35:37 --> Controller Class Initialized
INFO - 2016-02-23 06:35:37 --> Model Class Initialized
INFO - 2016-02-23 06:35:37 --> Model Class Initialized
INFO - 2016-02-23 06:35:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:35:37 --> Pagination Class Initialized
INFO - 2016-02-23 06:35:37 --> Helper loaded: text_helper
INFO - 2016-02-23 06:35:37 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:35:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:35:37 --> Final output sent to browser
DEBUG - 2016-02-23 09:35:37 --> Total execution time: 1.1744
INFO - 2016-02-23 06:35:51 --> Config Class Initialized
INFO - 2016-02-23 06:35:51 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:35:51 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:35:51 --> Utf8 Class Initialized
INFO - 2016-02-23 06:35:51 --> URI Class Initialized
INFO - 2016-02-23 06:35:51 --> Router Class Initialized
INFO - 2016-02-23 06:35:51 --> Output Class Initialized
INFO - 2016-02-23 06:35:51 --> Security Class Initialized
DEBUG - 2016-02-23 06:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:35:51 --> Input Class Initialized
INFO - 2016-02-23 06:35:51 --> Language Class Initialized
INFO - 2016-02-23 06:35:51 --> Loader Class Initialized
INFO - 2016-02-23 06:35:51 --> Helper loaded: url_helper
INFO - 2016-02-23 06:35:51 --> Helper loaded: file_helper
INFO - 2016-02-23 06:35:51 --> Helper loaded: date_helper
INFO - 2016-02-23 06:35:51 --> Helper loaded: form_helper
INFO - 2016-02-23 06:35:51 --> Database Driver Class Initialized
INFO - 2016-02-23 06:35:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:35:52 --> Controller Class Initialized
INFO - 2016-02-23 06:35:52 --> Model Class Initialized
INFO - 2016-02-23 06:35:52 --> Model Class Initialized
INFO - 2016-02-23 06:35:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:35:52 --> Pagination Class Initialized
INFO - 2016-02-23 06:35:52 --> Helper loaded: text_helper
INFO - 2016-02-23 06:35:52 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:35:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:35:52 --> Final output sent to browser
DEBUG - 2016-02-23 09:35:52 --> Total execution time: 1.2167
INFO - 2016-02-23 06:36:01 --> Config Class Initialized
INFO - 2016-02-23 06:36:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:36:01 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:36:01 --> Utf8 Class Initialized
INFO - 2016-02-23 06:36:01 --> URI Class Initialized
INFO - 2016-02-23 06:36:01 --> Router Class Initialized
INFO - 2016-02-23 06:36:01 --> Output Class Initialized
INFO - 2016-02-23 06:36:01 --> Security Class Initialized
DEBUG - 2016-02-23 06:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:36:01 --> Input Class Initialized
INFO - 2016-02-23 06:36:01 --> Language Class Initialized
INFO - 2016-02-23 06:36:01 --> Loader Class Initialized
INFO - 2016-02-23 06:36:01 --> Helper loaded: url_helper
INFO - 2016-02-23 06:36:01 --> Helper loaded: file_helper
INFO - 2016-02-23 06:36:01 --> Helper loaded: date_helper
INFO - 2016-02-23 06:36:01 --> Helper loaded: form_helper
INFO - 2016-02-23 06:36:01 --> Database Driver Class Initialized
INFO - 2016-02-23 06:36:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:36:02 --> Controller Class Initialized
INFO - 2016-02-23 06:36:02 --> Model Class Initialized
INFO - 2016-02-23 06:36:02 --> Model Class Initialized
INFO - 2016-02-23 06:36:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:36:02 --> Pagination Class Initialized
INFO - 2016-02-23 06:36:02 --> Helper loaded: text_helper
INFO - 2016-02-23 06:36:02 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:36:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:36:02 --> Final output sent to browser
DEBUG - 2016-02-23 09:36:02 --> Total execution time: 1.1658
INFO - 2016-02-23 06:36:31 --> Config Class Initialized
INFO - 2016-02-23 06:36:31 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:36:31 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:36:31 --> Utf8 Class Initialized
INFO - 2016-02-23 06:36:31 --> URI Class Initialized
INFO - 2016-02-23 06:36:31 --> Router Class Initialized
INFO - 2016-02-23 06:36:31 --> Output Class Initialized
INFO - 2016-02-23 06:36:31 --> Security Class Initialized
DEBUG - 2016-02-23 06:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:36:31 --> Input Class Initialized
INFO - 2016-02-23 06:36:31 --> Language Class Initialized
INFO - 2016-02-23 06:36:31 --> Loader Class Initialized
INFO - 2016-02-23 06:36:31 --> Helper loaded: url_helper
INFO - 2016-02-23 06:36:31 --> Helper loaded: file_helper
INFO - 2016-02-23 06:36:31 --> Helper loaded: date_helper
INFO - 2016-02-23 06:36:31 --> Helper loaded: form_helper
INFO - 2016-02-23 06:36:31 --> Database Driver Class Initialized
INFO - 2016-02-23 06:36:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:36:32 --> Controller Class Initialized
INFO - 2016-02-23 06:36:32 --> Model Class Initialized
INFO - 2016-02-23 06:36:32 --> Model Class Initialized
INFO - 2016-02-23 06:36:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:36:32 --> Pagination Class Initialized
INFO - 2016-02-23 06:36:32 --> Helper loaded: text_helper
INFO - 2016-02-23 06:36:32 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:36:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:36:32 --> Final output sent to browser
DEBUG - 2016-02-23 09:36:32 --> Total execution time: 1.1901
INFO - 2016-02-23 06:37:01 --> Config Class Initialized
INFO - 2016-02-23 06:37:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:37:01 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:37:01 --> Utf8 Class Initialized
INFO - 2016-02-23 06:37:01 --> URI Class Initialized
INFO - 2016-02-23 06:37:01 --> Router Class Initialized
INFO - 2016-02-23 06:37:01 --> Output Class Initialized
INFO - 2016-02-23 06:37:01 --> Security Class Initialized
DEBUG - 2016-02-23 06:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:37:01 --> Input Class Initialized
INFO - 2016-02-23 06:37:01 --> Language Class Initialized
INFO - 2016-02-23 06:37:01 --> Loader Class Initialized
INFO - 2016-02-23 06:37:01 --> Helper loaded: url_helper
INFO - 2016-02-23 06:37:01 --> Helper loaded: file_helper
INFO - 2016-02-23 06:37:01 --> Helper loaded: date_helper
INFO - 2016-02-23 06:37:01 --> Helper loaded: form_helper
INFO - 2016-02-23 06:37:01 --> Database Driver Class Initialized
INFO - 2016-02-23 06:37:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:37:02 --> Controller Class Initialized
INFO - 2016-02-23 06:37:02 --> Model Class Initialized
INFO - 2016-02-23 06:37:02 --> Model Class Initialized
INFO - 2016-02-23 06:37:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:37:02 --> Pagination Class Initialized
INFO - 2016-02-23 06:37:02 --> Helper loaded: text_helper
INFO - 2016-02-23 06:37:02 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:37:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:37:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:37:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:37:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:37:02 --> Final output sent to browser
DEBUG - 2016-02-23 09:37:02 --> Total execution time: 1.1370
INFO - 2016-02-23 06:37:19 --> Config Class Initialized
INFO - 2016-02-23 06:37:19 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:37:19 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:37:19 --> Utf8 Class Initialized
INFO - 2016-02-23 06:37:19 --> URI Class Initialized
INFO - 2016-02-23 06:37:19 --> Router Class Initialized
INFO - 2016-02-23 06:37:19 --> Output Class Initialized
INFO - 2016-02-23 06:37:19 --> Security Class Initialized
DEBUG - 2016-02-23 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:37:19 --> Input Class Initialized
INFO - 2016-02-23 06:37:19 --> Language Class Initialized
INFO - 2016-02-23 06:37:19 --> Loader Class Initialized
INFO - 2016-02-23 06:37:19 --> Helper loaded: url_helper
INFO - 2016-02-23 06:37:19 --> Helper loaded: file_helper
INFO - 2016-02-23 06:37:19 --> Helper loaded: date_helper
INFO - 2016-02-23 06:37:19 --> Helper loaded: form_helper
INFO - 2016-02-23 06:37:19 --> Database Driver Class Initialized
INFO - 2016-02-23 06:37:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:37:20 --> Controller Class Initialized
INFO - 2016-02-23 06:37:20 --> Model Class Initialized
INFO - 2016-02-23 06:37:20 --> Model Class Initialized
INFO - 2016-02-23 06:37:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:37:20 --> Pagination Class Initialized
INFO - 2016-02-23 06:37:20 --> Helper loaded: text_helper
INFO - 2016-02-23 06:37:20 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:37:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:37:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:37:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:37:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:37:20 --> Final output sent to browser
DEBUG - 2016-02-23 09:37:20 --> Total execution time: 1.1374
INFO - 2016-02-23 06:37:33 --> Config Class Initialized
INFO - 2016-02-23 06:37:33 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:37:33 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:37:33 --> Utf8 Class Initialized
INFO - 2016-02-23 06:37:33 --> URI Class Initialized
INFO - 2016-02-23 06:37:33 --> Router Class Initialized
INFO - 2016-02-23 06:37:33 --> Output Class Initialized
INFO - 2016-02-23 06:37:33 --> Security Class Initialized
DEBUG - 2016-02-23 06:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:37:33 --> Input Class Initialized
INFO - 2016-02-23 06:37:33 --> Language Class Initialized
INFO - 2016-02-23 06:37:33 --> Loader Class Initialized
INFO - 2016-02-23 06:37:33 --> Helper loaded: url_helper
INFO - 2016-02-23 06:37:33 --> Helper loaded: file_helper
INFO - 2016-02-23 06:37:33 --> Helper loaded: date_helper
INFO - 2016-02-23 06:37:33 --> Helper loaded: form_helper
INFO - 2016-02-23 06:37:33 --> Database Driver Class Initialized
INFO - 2016-02-23 06:37:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:37:34 --> Controller Class Initialized
INFO - 2016-02-23 06:37:34 --> Model Class Initialized
INFO - 2016-02-23 06:37:34 --> Model Class Initialized
INFO - 2016-02-23 06:37:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:37:34 --> Pagination Class Initialized
INFO - 2016-02-23 06:37:34 --> Helper loaded: text_helper
INFO - 2016-02-23 06:37:34 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:37:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:37:34 --> Final output sent to browser
DEBUG - 2016-02-23 09:37:34 --> Total execution time: 1.1627
INFO - 2016-02-23 06:38:28 --> Config Class Initialized
INFO - 2016-02-23 06:38:28 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:38:28 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:38:28 --> Utf8 Class Initialized
INFO - 2016-02-23 06:38:28 --> URI Class Initialized
INFO - 2016-02-23 06:38:28 --> Router Class Initialized
INFO - 2016-02-23 06:38:28 --> Output Class Initialized
INFO - 2016-02-23 06:38:28 --> Security Class Initialized
DEBUG - 2016-02-23 06:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:38:28 --> Input Class Initialized
INFO - 2016-02-23 06:38:28 --> Language Class Initialized
INFO - 2016-02-23 06:38:28 --> Loader Class Initialized
INFO - 2016-02-23 06:38:28 --> Helper loaded: url_helper
INFO - 2016-02-23 06:38:28 --> Helper loaded: file_helper
INFO - 2016-02-23 06:38:28 --> Helper loaded: date_helper
INFO - 2016-02-23 06:38:28 --> Helper loaded: form_helper
INFO - 2016-02-23 06:38:28 --> Database Driver Class Initialized
INFO - 2016-02-23 06:38:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:38:29 --> Controller Class Initialized
INFO - 2016-02-23 06:38:29 --> Model Class Initialized
INFO - 2016-02-23 06:38:29 --> Model Class Initialized
INFO - 2016-02-23 06:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:38:29 --> Pagination Class Initialized
INFO - 2016-02-23 06:38:29 --> Helper loaded: text_helper
INFO - 2016-02-23 06:38:29 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:38:29 --> Final output sent to browser
DEBUG - 2016-02-23 09:38:29 --> Total execution time: 1.1405
INFO - 2016-02-23 06:40:02 --> Config Class Initialized
INFO - 2016-02-23 06:40:02 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:40:02 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:40:02 --> Utf8 Class Initialized
INFO - 2016-02-23 06:40:02 --> URI Class Initialized
INFO - 2016-02-23 06:40:02 --> Router Class Initialized
INFO - 2016-02-23 06:40:02 --> Output Class Initialized
INFO - 2016-02-23 06:40:02 --> Security Class Initialized
DEBUG - 2016-02-23 06:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:40:02 --> Input Class Initialized
INFO - 2016-02-23 06:40:02 --> Language Class Initialized
INFO - 2016-02-23 06:40:02 --> Loader Class Initialized
INFO - 2016-02-23 06:40:02 --> Helper loaded: url_helper
INFO - 2016-02-23 06:40:02 --> Helper loaded: file_helper
INFO - 2016-02-23 06:40:02 --> Helper loaded: date_helper
INFO - 2016-02-23 06:40:02 --> Helper loaded: form_helper
INFO - 2016-02-23 06:40:02 --> Database Driver Class Initialized
INFO - 2016-02-23 06:40:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:40:03 --> Controller Class Initialized
INFO - 2016-02-23 06:40:03 --> Model Class Initialized
INFO - 2016-02-23 06:40:03 --> Model Class Initialized
INFO - 2016-02-23 06:40:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:40:03 --> Pagination Class Initialized
INFO - 2016-02-23 06:40:03 --> Helper loaded: text_helper
INFO - 2016-02-23 06:40:03 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:40:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:40:03 --> Final output sent to browser
DEBUG - 2016-02-23 09:40:03 --> Total execution time: 1.1822
INFO - 2016-02-23 06:40:05 --> Config Class Initialized
INFO - 2016-02-23 06:40:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:40:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:40:05 --> Utf8 Class Initialized
INFO - 2016-02-23 06:40:05 --> URI Class Initialized
INFO - 2016-02-23 06:40:05 --> Router Class Initialized
INFO - 2016-02-23 06:40:05 --> Output Class Initialized
INFO - 2016-02-23 06:40:05 --> Security Class Initialized
DEBUG - 2016-02-23 06:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:40:05 --> Input Class Initialized
INFO - 2016-02-23 06:40:05 --> Language Class Initialized
INFO - 2016-02-23 06:40:05 --> Loader Class Initialized
INFO - 2016-02-23 06:40:05 --> Helper loaded: url_helper
INFO - 2016-02-23 06:40:05 --> Helper loaded: file_helper
INFO - 2016-02-23 06:40:05 --> Helper loaded: date_helper
INFO - 2016-02-23 06:40:05 --> Helper loaded: form_helper
INFO - 2016-02-23 06:40:05 --> Database Driver Class Initialized
INFO - 2016-02-23 06:40:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:40:06 --> Controller Class Initialized
INFO - 2016-02-23 06:40:06 --> Model Class Initialized
INFO - 2016-02-23 06:40:06 --> Model Class Initialized
INFO - 2016-02-23 06:40:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:40:06 --> Pagination Class Initialized
INFO - 2016-02-23 06:40:06 --> Helper loaded: text_helper
INFO - 2016-02-23 06:40:06 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:40:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:40:06 --> Final output sent to browser
DEBUG - 2016-02-23 09:40:06 --> Total execution time: 1.1385
INFO - 2016-02-23 06:40:09 --> Config Class Initialized
INFO - 2016-02-23 06:40:09 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:40:09 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:40:09 --> Utf8 Class Initialized
INFO - 2016-02-23 06:40:09 --> URI Class Initialized
INFO - 2016-02-23 06:40:09 --> Router Class Initialized
INFO - 2016-02-23 06:40:09 --> Output Class Initialized
INFO - 2016-02-23 06:40:09 --> Security Class Initialized
DEBUG - 2016-02-23 06:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:40:09 --> Input Class Initialized
INFO - 2016-02-23 06:40:09 --> Language Class Initialized
INFO - 2016-02-23 06:40:09 --> Loader Class Initialized
INFO - 2016-02-23 06:40:09 --> Helper loaded: url_helper
INFO - 2016-02-23 06:40:09 --> Helper loaded: file_helper
INFO - 2016-02-23 06:40:09 --> Helper loaded: date_helper
INFO - 2016-02-23 06:40:09 --> Helper loaded: form_helper
INFO - 2016-02-23 06:40:09 --> Database Driver Class Initialized
INFO - 2016-02-23 06:40:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:40:10 --> Controller Class Initialized
INFO - 2016-02-23 06:40:10 --> Model Class Initialized
INFO - 2016-02-23 06:40:10 --> Model Class Initialized
INFO - 2016-02-23 06:40:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:40:10 --> Pagination Class Initialized
INFO - 2016-02-23 06:40:10 --> Helper loaded: text_helper
INFO - 2016-02-23 06:40:10 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:40:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:40:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:40:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:40:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:40:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:40:10 --> Final output sent to browser
DEBUG - 2016-02-23 09:40:10 --> Total execution time: 1.2010
INFO - 2016-02-23 06:40:13 --> Config Class Initialized
INFO - 2016-02-23 06:40:13 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:40:13 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:40:13 --> Utf8 Class Initialized
INFO - 2016-02-23 06:40:13 --> URI Class Initialized
INFO - 2016-02-23 06:40:13 --> Router Class Initialized
INFO - 2016-02-23 06:40:13 --> Output Class Initialized
INFO - 2016-02-23 06:40:13 --> Security Class Initialized
DEBUG - 2016-02-23 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:40:13 --> Input Class Initialized
INFO - 2016-02-23 06:40:13 --> Language Class Initialized
INFO - 2016-02-23 06:40:13 --> Loader Class Initialized
INFO - 2016-02-23 06:40:13 --> Helper loaded: url_helper
INFO - 2016-02-23 06:40:13 --> Helper loaded: file_helper
INFO - 2016-02-23 06:40:13 --> Helper loaded: date_helper
INFO - 2016-02-23 06:40:13 --> Helper loaded: form_helper
INFO - 2016-02-23 06:40:13 --> Database Driver Class Initialized
INFO - 2016-02-23 06:40:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:40:14 --> Controller Class Initialized
INFO - 2016-02-23 06:40:14 --> Model Class Initialized
INFO - 2016-02-23 06:40:14 --> Model Class Initialized
INFO - 2016-02-23 06:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:40:14 --> Pagination Class Initialized
INFO - 2016-02-23 06:40:14 --> Helper loaded: text_helper
INFO - 2016-02-23 06:40:14 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:40:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:40:14 --> Final output sent to browser
DEBUG - 2016-02-23 09:40:14 --> Total execution time: 1.1406
INFO - 2016-02-23 06:42:46 --> Config Class Initialized
INFO - 2016-02-23 06:42:46 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:42:46 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:42:46 --> Utf8 Class Initialized
INFO - 2016-02-23 06:42:46 --> URI Class Initialized
DEBUG - 2016-02-23 06:42:46 --> No URI present. Default controller set.
INFO - 2016-02-23 06:42:46 --> Router Class Initialized
INFO - 2016-02-23 06:42:46 --> Output Class Initialized
INFO - 2016-02-23 06:42:46 --> Security Class Initialized
DEBUG - 2016-02-23 06:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:42:46 --> Input Class Initialized
INFO - 2016-02-23 06:42:46 --> Language Class Initialized
INFO - 2016-02-23 06:42:46 --> Loader Class Initialized
INFO - 2016-02-23 06:42:46 --> Helper loaded: url_helper
INFO - 2016-02-23 06:42:46 --> Helper loaded: file_helper
INFO - 2016-02-23 06:42:46 --> Helper loaded: date_helper
INFO - 2016-02-23 06:42:46 --> Helper loaded: form_helper
INFO - 2016-02-23 06:42:46 --> Database Driver Class Initialized
INFO - 2016-02-23 06:42:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:42:47 --> Controller Class Initialized
INFO - 2016-02-23 06:42:47 --> Model Class Initialized
INFO - 2016-02-23 06:42:47 --> Model Class Initialized
INFO - 2016-02-23 06:42:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:42:47 --> Pagination Class Initialized
INFO - 2016-02-23 06:42:47 --> Helper loaded: text_helper
INFO - 2016-02-23 06:42:47 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 09:42:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:42:47 --> Final output sent to browser
DEBUG - 2016-02-23 09:42:47 --> Total execution time: 1.1165
INFO - 2016-02-23 06:42:48 --> Config Class Initialized
INFO - 2016-02-23 06:42:48 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:42:48 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:42:48 --> Utf8 Class Initialized
INFO - 2016-02-23 06:42:48 --> URI Class Initialized
INFO - 2016-02-23 06:42:48 --> Router Class Initialized
INFO - 2016-02-23 06:42:48 --> Output Class Initialized
INFO - 2016-02-23 06:42:48 --> Security Class Initialized
DEBUG - 2016-02-23 06:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:42:48 --> Input Class Initialized
INFO - 2016-02-23 06:42:48 --> Language Class Initialized
INFO - 2016-02-23 06:42:48 --> Loader Class Initialized
INFO - 2016-02-23 06:42:48 --> Helper loaded: url_helper
INFO - 2016-02-23 06:42:48 --> Helper loaded: file_helper
INFO - 2016-02-23 06:42:48 --> Helper loaded: date_helper
INFO - 2016-02-23 06:42:48 --> Helper loaded: form_helper
INFO - 2016-02-23 06:42:48 --> Database Driver Class Initialized
INFO - 2016-02-23 06:42:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:42:49 --> Controller Class Initialized
INFO - 2016-02-23 06:42:49 --> Model Class Initialized
INFO - 2016-02-23 06:42:49 --> Model Class Initialized
INFO - 2016-02-23 06:42:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:42:49 --> Pagination Class Initialized
INFO - 2016-02-23 06:42:49 --> Helper loaded: text_helper
INFO - 2016-02-23 06:42:49 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:42:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:42:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:42:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:42:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:42:49 --> Final output sent to browser
DEBUG - 2016-02-23 09:42:49 --> Total execution time: 1.1137
INFO - 2016-02-23 06:42:50 --> Config Class Initialized
INFO - 2016-02-23 06:42:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:42:50 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:42:50 --> Utf8 Class Initialized
INFO - 2016-02-23 06:42:50 --> URI Class Initialized
INFO - 2016-02-23 06:42:50 --> Router Class Initialized
INFO - 2016-02-23 06:42:50 --> Output Class Initialized
INFO - 2016-02-23 06:42:50 --> Security Class Initialized
DEBUG - 2016-02-23 06:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:42:50 --> Input Class Initialized
INFO - 2016-02-23 06:42:50 --> Language Class Initialized
INFO - 2016-02-23 06:42:50 --> Loader Class Initialized
INFO - 2016-02-23 06:42:50 --> Helper loaded: url_helper
INFO - 2016-02-23 06:42:50 --> Helper loaded: file_helper
INFO - 2016-02-23 06:42:50 --> Helper loaded: date_helper
INFO - 2016-02-23 06:42:50 --> Helper loaded: form_helper
INFO - 2016-02-23 06:42:50 --> Database Driver Class Initialized
INFO - 2016-02-23 06:42:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:42:51 --> Controller Class Initialized
INFO - 2016-02-23 06:42:51 --> Model Class Initialized
INFO - 2016-02-23 06:42:51 --> Model Class Initialized
INFO - 2016-02-23 06:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:42:51 --> Pagination Class Initialized
INFO - 2016-02-23 06:42:51 --> Helper loaded: text_helper
INFO - 2016-02-23 06:42:51 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:42:51 --> Final output sent to browser
DEBUG - 2016-02-23 09:42:51 --> Total execution time: 1.1782
INFO - 2016-02-23 06:42:59 --> Config Class Initialized
INFO - 2016-02-23 06:42:59 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:42:59 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:42:59 --> Utf8 Class Initialized
INFO - 2016-02-23 06:42:59 --> URI Class Initialized
INFO - 2016-02-23 06:42:59 --> Router Class Initialized
INFO - 2016-02-23 06:42:59 --> Output Class Initialized
INFO - 2016-02-23 06:42:59 --> Security Class Initialized
DEBUG - 2016-02-23 06:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:42:59 --> Input Class Initialized
INFO - 2016-02-23 06:42:59 --> Language Class Initialized
INFO - 2016-02-23 06:42:59 --> Loader Class Initialized
INFO - 2016-02-23 06:42:59 --> Helper loaded: url_helper
INFO - 2016-02-23 06:42:59 --> Helper loaded: file_helper
INFO - 2016-02-23 06:42:59 --> Helper loaded: date_helper
INFO - 2016-02-23 06:42:59 --> Helper loaded: form_helper
INFO - 2016-02-23 06:42:59 --> Database Driver Class Initialized
INFO - 2016-02-23 06:43:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:43:00 --> Controller Class Initialized
INFO - 2016-02-23 06:43:00 --> Model Class Initialized
INFO - 2016-02-23 06:43:00 --> Model Class Initialized
INFO - 2016-02-23 06:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:43:00 --> Pagination Class Initialized
INFO - 2016-02-23 06:43:00 --> Helper loaded: text_helper
INFO - 2016-02-23 06:43:00 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:43:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:43:00 --> Final output sent to browser
DEBUG - 2016-02-23 09:43:00 --> Total execution time: 1.0998
INFO - 2016-02-23 06:44:25 --> Config Class Initialized
INFO - 2016-02-23 06:44:25 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:44:25 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:44:25 --> Utf8 Class Initialized
INFO - 2016-02-23 06:44:25 --> URI Class Initialized
INFO - 2016-02-23 06:44:25 --> Router Class Initialized
INFO - 2016-02-23 06:44:25 --> Output Class Initialized
INFO - 2016-02-23 06:44:25 --> Security Class Initialized
DEBUG - 2016-02-23 06:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:44:25 --> Input Class Initialized
INFO - 2016-02-23 06:44:25 --> Language Class Initialized
INFO - 2016-02-23 06:44:25 --> Loader Class Initialized
INFO - 2016-02-23 06:44:25 --> Helper loaded: url_helper
INFO - 2016-02-23 06:44:25 --> Helper loaded: file_helper
INFO - 2016-02-23 06:44:25 --> Helper loaded: date_helper
INFO - 2016-02-23 06:44:25 --> Helper loaded: form_helper
INFO - 2016-02-23 06:44:25 --> Database Driver Class Initialized
INFO - 2016-02-23 06:44:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:44:26 --> Controller Class Initialized
INFO - 2016-02-23 06:44:27 --> Model Class Initialized
INFO - 2016-02-23 06:44:27 --> Model Class Initialized
INFO - 2016-02-23 06:44:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:44:27 --> Pagination Class Initialized
INFO - 2016-02-23 06:44:27 --> Helper loaded: text_helper
INFO - 2016-02-23 06:44:27 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:44:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:44:27 --> Final output sent to browser
DEBUG - 2016-02-23 09:44:27 --> Total execution time: 1.1733
INFO - 2016-02-23 06:44:28 --> Config Class Initialized
INFO - 2016-02-23 06:44:28 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:44:28 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:44:28 --> Utf8 Class Initialized
INFO - 2016-02-23 06:44:28 --> URI Class Initialized
INFO - 2016-02-23 06:44:28 --> Router Class Initialized
INFO - 2016-02-23 06:44:28 --> Output Class Initialized
INFO - 2016-02-23 06:44:28 --> Security Class Initialized
DEBUG - 2016-02-23 06:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:44:28 --> Input Class Initialized
INFO - 2016-02-23 06:44:28 --> Language Class Initialized
INFO - 2016-02-23 06:44:28 --> Loader Class Initialized
INFO - 2016-02-23 06:44:28 --> Helper loaded: url_helper
INFO - 2016-02-23 06:44:28 --> Helper loaded: file_helper
INFO - 2016-02-23 06:44:28 --> Helper loaded: date_helper
INFO - 2016-02-23 06:44:28 --> Helper loaded: form_helper
INFO - 2016-02-23 06:44:28 --> Database Driver Class Initialized
INFO - 2016-02-23 06:44:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:44:29 --> Controller Class Initialized
INFO - 2016-02-23 06:44:29 --> Model Class Initialized
INFO - 2016-02-23 06:44:29 --> Model Class Initialized
INFO - 2016-02-23 06:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:44:29 --> Pagination Class Initialized
INFO - 2016-02-23 06:44:29 --> Helper loaded: text_helper
INFO - 2016-02-23 06:44:29 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:44:29 --> Final output sent to browser
DEBUG - 2016-02-23 09:44:29 --> Total execution time: 1.1412
INFO - 2016-02-23 06:44:32 --> Config Class Initialized
INFO - 2016-02-23 06:44:32 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:44:32 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:44:32 --> Utf8 Class Initialized
INFO - 2016-02-23 06:44:32 --> URI Class Initialized
INFO - 2016-02-23 06:44:32 --> Router Class Initialized
INFO - 2016-02-23 06:44:32 --> Output Class Initialized
INFO - 2016-02-23 06:44:32 --> Security Class Initialized
DEBUG - 2016-02-23 06:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:44:32 --> Input Class Initialized
INFO - 2016-02-23 06:44:32 --> Language Class Initialized
INFO - 2016-02-23 06:44:32 --> Loader Class Initialized
INFO - 2016-02-23 06:44:32 --> Helper loaded: url_helper
INFO - 2016-02-23 06:44:32 --> Helper loaded: file_helper
INFO - 2016-02-23 06:44:32 --> Helper loaded: date_helper
INFO - 2016-02-23 06:44:32 --> Helper loaded: form_helper
INFO - 2016-02-23 06:44:32 --> Database Driver Class Initialized
INFO - 2016-02-23 06:44:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:44:33 --> Controller Class Initialized
INFO - 2016-02-23 06:44:33 --> Model Class Initialized
INFO - 2016-02-23 06:44:33 --> Model Class Initialized
INFO - 2016-02-23 06:44:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:44:33 --> Pagination Class Initialized
INFO - 2016-02-23 06:44:33 --> Helper loaded: text_helper
INFO - 2016-02-23 06:44:33 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:44:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:44:33 --> Final output sent to browser
DEBUG - 2016-02-23 09:44:33 --> Total execution time: 1.1555
INFO - 2016-02-23 06:44:34 --> Config Class Initialized
INFO - 2016-02-23 06:44:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:44:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:44:34 --> Utf8 Class Initialized
INFO - 2016-02-23 06:44:34 --> URI Class Initialized
INFO - 2016-02-23 06:44:34 --> Router Class Initialized
INFO - 2016-02-23 06:44:34 --> Output Class Initialized
INFO - 2016-02-23 06:44:34 --> Security Class Initialized
DEBUG - 2016-02-23 06:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:44:34 --> Input Class Initialized
INFO - 2016-02-23 06:44:34 --> Language Class Initialized
INFO - 2016-02-23 06:44:34 --> Loader Class Initialized
INFO - 2016-02-23 06:44:34 --> Helper loaded: url_helper
INFO - 2016-02-23 06:44:34 --> Helper loaded: file_helper
INFO - 2016-02-23 06:44:34 --> Helper loaded: date_helper
INFO - 2016-02-23 06:44:34 --> Helper loaded: form_helper
INFO - 2016-02-23 06:44:35 --> Database Driver Class Initialized
INFO - 2016-02-23 06:44:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:44:36 --> Controller Class Initialized
INFO - 2016-02-23 06:44:36 --> Model Class Initialized
INFO - 2016-02-23 06:44:36 --> Model Class Initialized
INFO - 2016-02-23 06:44:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:44:36 --> Pagination Class Initialized
INFO - 2016-02-23 06:44:36 --> Helper loaded: text_helper
INFO - 2016-02-23 06:44:36 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:44:36 --> Final output sent to browser
DEBUG - 2016-02-23 09:44:36 --> Total execution time: 1.1134
INFO - 2016-02-23 06:44:37 --> Config Class Initialized
INFO - 2016-02-23 06:44:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:44:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:44:37 --> Utf8 Class Initialized
INFO - 2016-02-23 06:44:37 --> URI Class Initialized
INFO - 2016-02-23 06:44:37 --> Router Class Initialized
INFO - 2016-02-23 06:44:37 --> Output Class Initialized
INFO - 2016-02-23 06:44:37 --> Security Class Initialized
DEBUG - 2016-02-23 06:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:44:37 --> Input Class Initialized
INFO - 2016-02-23 06:44:37 --> Language Class Initialized
INFO - 2016-02-23 06:44:37 --> Loader Class Initialized
INFO - 2016-02-23 06:44:37 --> Helper loaded: url_helper
INFO - 2016-02-23 06:44:37 --> Helper loaded: file_helper
INFO - 2016-02-23 06:44:37 --> Helper loaded: date_helper
INFO - 2016-02-23 06:44:37 --> Helper loaded: form_helper
INFO - 2016-02-23 06:44:37 --> Database Driver Class Initialized
INFO - 2016-02-23 06:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:44:38 --> Controller Class Initialized
INFO - 2016-02-23 06:44:38 --> Model Class Initialized
INFO - 2016-02-23 06:44:38 --> Model Class Initialized
INFO - 2016-02-23 06:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:44:38 --> Pagination Class Initialized
INFO - 2016-02-23 06:44:38 --> Helper loaded: text_helper
INFO - 2016-02-23 06:44:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:44:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:44:38 --> Final output sent to browser
DEBUG - 2016-02-23 09:44:38 --> Total execution time: 1.2226
INFO - 2016-02-23 06:44:39 --> Config Class Initialized
INFO - 2016-02-23 06:44:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:44:39 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:44:39 --> Utf8 Class Initialized
INFO - 2016-02-23 06:44:39 --> URI Class Initialized
INFO - 2016-02-23 06:44:39 --> Router Class Initialized
INFO - 2016-02-23 06:44:39 --> Output Class Initialized
INFO - 2016-02-23 06:44:39 --> Security Class Initialized
DEBUG - 2016-02-23 06:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:44:39 --> Input Class Initialized
INFO - 2016-02-23 06:44:39 --> Language Class Initialized
INFO - 2016-02-23 06:44:39 --> Loader Class Initialized
INFO - 2016-02-23 06:44:39 --> Helper loaded: url_helper
INFO - 2016-02-23 06:44:39 --> Helper loaded: file_helper
INFO - 2016-02-23 06:44:39 --> Helper loaded: date_helper
INFO - 2016-02-23 06:44:39 --> Helper loaded: form_helper
INFO - 2016-02-23 06:44:39 --> Database Driver Class Initialized
INFO - 2016-02-23 06:44:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:44:40 --> Controller Class Initialized
INFO - 2016-02-23 06:44:40 --> Model Class Initialized
INFO - 2016-02-23 06:44:40 --> Model Class Initialized
INFO - 2016-02-23 06:44:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:44:40 --> Pagination Class Initialized
INFO - 2016-02-23 06:44:40 --> Helper loaded: text_helper
INFO - 2016-02-23 06:44:40 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:44:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:44:40 --> Final output sent to browser
DEBUG - 2016-02-23 09:44:40 --> Total execution time: 1.1501
INFO - 2016-02-23 06:45:55 --> Config Class Initialized
INFO - 2016-02-23 06:45:55 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:45:55 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:45:55 --> Utf8 Class Initialized
INFO - 2016-02-23 06:45:55 --> URI Class Initialized
INFO - 2016-02-23 06:45:55 --> Router Class Initialized
INFO - 2016-02-23 06:45:55 --> Output Class Initialized
INFO - 2016-02-23 06:45:55 --> Security Class Initialized
DEBUG - 2016-02-23 06:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:45:55 --> Input Class Initialized
INFO - 2016-02-23 06:45:55 --> Language Class Initialized
INFO - 2016-02-23 06:45:55 --> Loader Class Initialized
INFO - 2016-02-23 06:45:55 --> Helper loaded: url_helper
INFO - 2016-02-23 06:45:55 --> Helper loaded: file_helper
INFO - 2016-02-23 06:45:55 --> Helper loaded: date_helper
INFO - 2016-02-23 06:45:55 --> Helper loaded: form_helper
INFO - 2016-02-23 06:45:55 --> Database Driver Class Initialized
INFO - 2016-02-23 06:45:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:45:56 --> Controller Class Initialized
INFO - 2016-02-23 06:45:56 --> Model Class Initialized
INFO - 2016-02-23 06:45:56 --> Model Class Initialized
INFO - 2016-02-23 06:45:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:45:56 --> Pagination Class Initialized
INFO - 2016-02-23 06:45:56 --> Helper loaded: text_helper
INFO - 2016-02-23 06:45:56 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:45:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:45:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:45:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:45:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:45:56 --> Final output sent to browser
DEBUG - 2016-02-23 09:45:56 --> Total execution time: 1.1524
INFO - 2016-02-23 06:46:02 --> Config Class Initialized
INFO - 2016-02-23 06:46:02 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:46:02 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:46:02 --> Utf8 Class Initialized
INFO - 2016-02-23 06:46:02 --> URI Class Initialized
INFO - 2016-02-23 06:46:02 --> Router Class Initialized
INFO - 2016-02-23 06:46:02 --> Output Class Initialized
INFO - 2016-02-23 06:46:02 --> Security Class Initialized
DEBUG - 2016-02-23 06:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:46:02 --> Input Class Initialized
INFO - 2016-02-23 06:46:02 --> Language Class Initialized
INFO - 2016-02-23 06:46:02 --> Loader Class Initialized
INFO - 2016-02-23 06:46:02 --> Helper loaded: url_helper
INFO - 2016-02-23 06:46:02 --> Helper loaded: file_helper
INFO - 2016-02-23 06:46:02 --> Helper loaded: date_helper
INFO - 2016-02-23 06:46:02 --> Helper loaded: form_helper
INFO - 2016-02-23 06:46:02 --> Database Driver Class Initialized
INFO - 2016-02-23 06:46:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:46:03 --> Controller Class Initialized
INFO - 2016-02-23 06:46:03 --> Model Class Initialized
INFO - 2016-02-23 06:46:03 --> Model Class Initialized
INFO - 2016-02-23 06:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:46:03 --> Pagination Class Initialized
INFO - 2016-02-23 06:46:03 --> Helper loaded: text_helper
INFO - 2016-02-23 06:46:03 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:46:03 --> Final output sent to browser
DEBUG - 2016-02-23 09:46:03 --> Total execution time: 1.1338
INFO - 2016-02-23 06:46:05 --> Config Class Initialized
INFO - 2016-02-23 06:46:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:46:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:46:05 --> Utf8 Class Initialized
INFO - 2016-02-23 06:46:05 --> URI Class Initialized
INFO - 2016-02-23 06:46:05 --> Router Class Initialized
INFO - 2016-02-23 06:46:05 --> Output Class Initialized
INFO - 2016-02-23 06:46:05 --> Security Class Initialized
DEBUG - 2016-02-23 06:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:46:05 --> Input Class Initialized
INFO - 2016-02-23 06:46:05 --> Language Class Initialized
INFO - 2016-02-23 06:46:05 --> Loader Class Initialized
INFO - 2016-02-23 06:46:05 --> Helper loaded: url_helper
INFO - 2016-02-23 06:46:05 --> Helper loaded: file_helper
INFO - 2016-02-23 06:46:05 --> Helper loaded: date_helper
INFO - 2016-02-23 06:46:05 --> Helper loaded: form_helper
INFO - 2016-02-23 06:46:05 --> Database Driver Class Initialized
INFO - 2016-02-23 06:46:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:46:06 --> Controller Class Initialized
INFO - 2016-02-23 06:46:06 --> Model Class Initialized
INFO - 2016-02-23 06:46:06 --> Model Class Initialized
INFO - 2016-02-23 06:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:46:06 --> Pagination Class Initialized
INFO - 2016-02-23 06:46:06 --> Helper loaded: text_helper
INFO - 2016-02-23 06:46:06 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:46:06 --> Final output sent to browser
DEBUG - 2016-02-23 09:46:06 --> Total execution time: 1.1096
INFO - 2016-02-23 06:46:07 --> Config Class Initialized
INFO - 2016-02-23 06:46:07 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:46:07 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:46:07 --> Utf8 Class Initialized
INFO - 2016-02-23 06:46:07 --> URI Class Initialized
INFO - 2016-02-23 06:46:07 --> Router Class Initialized
INFO - 2016-02-23 06:46:07 --> Output Class Initialized
INFO - 2016-02-23 06:46:07 --> Security Class Initialized
DEBUG - 2016-02-23 06:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:46:07 --> Input Class Initialized
INFO - 2016-02-23 06:46:07 --> Language Class Initialized
INFO - 2016-02-23 06:46:07 --> Loader Class Initialized
INFO - 2016-02-23 06:46:07 --> Helper loaded: url_helper
INFO - 2016-02-23 06:46:07 --> Helper loaded: file_helper
INFO - 2016-02-23 06:46:07 --> Helper loaded: date_helper
INFO - 2016-02-23 06:46:07 --> Helper loaded: form_helper
INFO - 2016-02-23 06:46:07 --> Database Driver Class Initialized
INFO - 2016-02-23 06:46:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:46:08 --> Controller Class Initialized
INFO - 2016-02-23 06:46:08 --> Model Class Initialized
INFO - 2016-02-23 06:46:08 --> Model Class Initialized
INFO - 2016-02-23 06:46:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:46:08 --> Pagination Class Initialized
INFO - 2016-02-23 06:46:08 --> Helper loaded: text_helper
INFO - 2016-02-23 06:46:08 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:46:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:46:08 --> Final output sent to browser
DEBUG - 2016-02-23 09:46:08 --> Total execution time: 1.1131
INFO - 2016-02-23 06:46:10 --> Config Class Initialized
INFO - 2016-02-23 06:46:10 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:46:10 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:46:10 --> Utf8 Class Initialized
INFO - 2016-02-23 06:46:10 --> URI Class Initialized
INFO - 2016-02-23 06:46:10 --> Router Class Initialized
INFO - 2016-02-23 06:46:10 --> Output Class Initialized
INFO - 2016-02-23 06:46:10 --> Security Class Initialized
DEBUG - 2016-02-23 06:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:46:10 --> Input Class Initialized
INFO - 2016-02-23 06:46:10 --> Language Class Initialized
INFO - 2016-02-23 06:46:10 --> Loader Class Initialized
INFO - 2016-02-23 06:46:10 --> Helper loaded: url_helper
INFO - 2016-02-23 06:46:10 --> Helper loaded: file_helper
INFO - 2016-02-23 06:46:10 --> Helper loaded: date_helper
INFO - 2016-02-23 06:46:10 --> Helper loaded: form_helper
INFO - 2016-02-23 06:46:10 --> Database Driver Class Initialized
INFO - 2016-02-23 06:46:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:46:11 --> Controller Class Initialized
INFO - 2016-02-23 06:46:11 --> Model Class Initialized
INFO - 2016-02-23 06:46:11 --> Model Class Initialized
INFO - 2016-02-23 06:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:46:11 --> Pagination Class Initialized
INFO - 2016-02-23 06:46:11 --> Helper loaded: text_helper
INFO - 2016-02-23 06:46:11 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:46:11 --> Final output sent to browser
DEBUG - 2016-02-23 09:46:11 --> Total execution time: 1.1212
INFO - 2016-02-23 06:46:13 --> Config Class Initialized
INFO - 2016-02-23 06:46:13 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:46:13 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:46:13 --> Utf8 Class Initialized
INFO - 2016-02-23 06:46:13 --> URI Class Initialized
INFO - 2016-02-23 06:46:13 --> Router Class Initialized
INFO - 2016-02-23 06:46:13 --> Output Class Initialized
INFO - 2016-02-23 06:46:13 --> Security Class Initialized
DEBUG - 2016-02-23 06:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:46:13 --> Input Class Initialized
INFO - 2016-02-23 06:46:13 --> Language Class Initialized
INFO - 2016-02-23 06:46:13 --> Loader Class Initialized
INFO - 2016-02-23 06:46:13 --> Helper loaded: url_helper
INFO - 2016-02-23 06:46:13 --> Helper loaded: file_helper
INFO - 2016-02-23 06:46:13 --> Helper loaded: date_helper
INFO - 2016-02-23 06:46:13 --> Helper loaded: form_helper
INFO - 2016-02-23 06:46:13 --> Database Driver Class Initialized
INFO - 2016-02-23 06:46:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:46:14 --> Controller Class Initialized
INFO - 2016-02-23 06:46:14 --> Model Class Initialized
INFO - 2016-02-23 06:46:14 --> Model Class Initialized
INFO - 2016-02-23 06:46:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:46:14 --> Pagination Class Initialized
INFO - 2016-02-23 06:46:14 --> Helper loaded: text_helper
INFO - 2016-02-23 06:46:14 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:46:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:46:14 --> Final output sent to browser
DEBUG - 2016-02-23 09:46:14 --> Total execution time: 1.1047
INFO - 2016-02-23 06:46:18 --> Config Class Initialized
INFO - 2016-02-23 06:46:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:46:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:46:18 --> Utf8 Class Initialized
INFO - 2016-02-23 06:46:18 --> URI Class Initialized
INFO - 2016-02-23 06:46:18 --> Router Class Initialized
INFO - 2016-02-23 06:46:18 --> Output Class Initialized
INFO - 2016-02-23 06:46:18 --> Security Class Initialized
DEBUG - 2016-02-23 06:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:46:18 --> Input Class Initialized
INFO - 2016-02-23 06:46:18 --> Language Class Initialized
INFO - 2016-02-23 06:46:18 --> Loader Class Initialized
INFO - 2016-02-23 06:46:18 --> Helper loaded: url_helper
INFO - 2016-02-23 06:46:18 --> Helper loaded: file_helper
INFO - 2016-02-23 06:46:18 --> Helper loaded: date_helper
INFO - 2016-02-23 06:46:18 --> Helper loaded: form_helper
INFO - 2016-02-23 06:46:18 --> Database Driver Class Initialized
INFO - 2016-02-23 06:46:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:46:19 --> Controller Class Initialized
INFO - 2016-02-23 06:46:19 --> Model Class Initialized
INFO - 2016-02-23 06:46:19 --> Model Class Initialized
INFO - 2016-02-23 06:46:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:46:19 --> Pagination Class Initialized
INFO - 2016-02-23 06:46:19 --> Helper loaded: text_helper
INFO - 2016-02-23 06:46:19 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 09:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 09:46:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:46:19 --> Final output sent to browser
DEBUG - 2016-02-23 09:46:19 --> Total execution time: 1.2265
INFO - 2016-02-23 06:46:21 --> Config Class Initialized
INFO - 2016-02-23 06:46:21 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:46:21 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:46:21 --> Utf8 Class Initialized
INFO - 2016-02-23 06:46:21 --> URI Class Initialized
INFO - 2016-02-23 06:46:21 --> Router Class Initialized
INFO - 2016-02-23 06:46:21 --> Output Class Initialized
INFO - 2016-02-23 06:46:21 --> Security Class Initialized
DEBUG - 2016-02-23 06:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:46:21 --> Input Class Initialized
INFO - 2016-02-23 06:46:21 --> Language Class Initialized
INFO - 2016-02-23 06:46:21 --> Loader Class Initialized
INFO - 2016-02-23 06:46:21 --> Helper loaded: url_helper
INFO - 2016-02-23 06:46:21 --> Helper loaded: file_helper
INFO - 2016-02-23 06:46:21 --> Helper loaded: date_helper
INFO - 2016-02-23 06:46:21 --> Helper loaded: form_helper
INFO - 2016-02-23 06:46:21 --> Database Driver Class Initialized
INFO - 2016-02-23 06:46:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:46:22 --> Controller Class Initialized
INFO - 2016-02-23 06:46:22 --> Model Class Initialized
INFO - 2016-02-23 06:46:22 --> Model Class Initialized
INFO - 2016-02-23 06:46:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:46:22 --> Pagination Class Initialized
INFO - 2016-02-23 06:46:22 --> Helper loaded: text_helper
INFO - 2016-02-23 06:46:22 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:46:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:46:22 --> Final output sent to browser
DEBUG - 2016-02-23 09:46:22 --> Total execution time: 1.1038
INFO - 2016-02-23 06:47:00 --> Config Class Initialized
INFO - 2016-02-23 06:47:00 --> Hooks Class Initialized
DEBUG - 2016-02-23 06:47:00 --> UTF-8 Support Enabled
INFO - 2016-02-23 06:47:00 --> Utf8 Class Initialized
INFO - 2016-02-23 06:47:00 --> URI Class Initialized
INFO - 2016-02-23 06:47:00 --> Router Class Initialized
INFO - 2016-02-23 06:47:00 --> Output Class Initialized
INFO - 2016-02-23 06:47:00 --> Security Class Initialized
DEBUG - 2016-02-23 06:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 06:47:00 --> Input Class Initialized
INFO - 2016-02-23 06:47:00 --> Language Class Initialized
INFO - 2016-02-23 06:47:00 --> Loader Class Initialized
INFO - 2016-02-23 06:47:00 --> Helper loaded: url_helper
INFO - 2016-02-23 06:47:00 --> Helper loaded: file_helper
INFO - 2016-02-23 06:47:00 --> Helper loaded: date_helper
INFO - 2016-02-23 06:47:00 --> Helper loaded: form_helper
INFO - 2016-02-23 06:47:00 --> Database Driver Class Initialized
INFO - 2016-02-23 06:47:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 06:47:01 --> Controller Class Initialized
INFO - 2016-02-23 06:47:01 --> Model Class Initialized
INFO - 2016-02-23 06:47:01 --> Model Class Initialized
INFO - 2016-02-23 06:47:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 06:47:01 --> Pagination Class Initialized
INFO - 2016-02-23 06:47:01 --> Helper loaded: text_helper
INFO - 2016-02-23 06:47:01 --> Helper loaded: cookie_helper
INFO - 2016-02-23 09:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 09:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 09:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 09:47:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 09:47:01 --> Final output sent to browser
DEBUG - 2016-02-23 09:47:01 --> Total execution time: 1.1291
INFO - 2016-02-23 07:03:32 --> Config Class Initialized
INFO - 2016-02-23 07:03:32 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:03:32 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:03:32 --> Utf8 Class Initialized
INFO - 2016-02-23 07:03:32 --> URI Class Initialized
INFO - 2016-02-23 07:03:32 --> Router Class Initialized
INFO - 2016-02-23 07:03:32 --> Output Class Initialized
INFO - 2016-02-23 07:03:32 --> Security Class Initialized
DEBUG - 2016-02-23 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:03:32 --> Input Class Initialized
INFO - 2016-02-23 07:03:32 --> Language Class Initialized
INFO - 2016-02-23 07:03:32 --> Loader Class Initialized
INFO - 2016-02-23 07:03:32 --> Helper loaded: url_helper
INFO - 2016-02-23 07:03:32 --> Helper loaded: file_helper
INFO - 2016-02-23 07:03:32 --> Helper loaded: date_helper
INFO - 2016-02-23 07:03:32 --> Helper loaded: form_helper
INFO - 2016-02-23 07:03:32 --> Database Driver Class Initialized
INFO - 2016-02-23 07:03:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:03:33 --> Controller Class Initialized
INFO - 2016-02-23 07:03:33 --> Model Class Initialized
INFO - 2016-02-23 07:03:33 --> Model Class Initialized
INFO - 2016-02-23 07:03:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:03:33 --> Pagination Class Initialized
INFO - 2016-02-23 07:03:33 --> Helper loaded: text_helper
INFO - 2016-02-23 07:03:33 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 07:03:33 --> Config Class Initialized
INFO - 2016-02-23 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 07:03:33 --> Hooks Class Initialized
INFO - 2016-02-23 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
DEBUG - 2016-02-23 07:03:33 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:03:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 07:03:33 --> Utf8 Class Initialized
INFO - 2016-02-23 10:03:33 --> Final output sent to browser
INFO - 2016-02-23 07:03:33 --> URI Class Initialized
DEBUG - 2016-02-23 10:03:33 --> Total execution time: 1.1604
DEBUG - 2016-02-23 07:03:33 --> No URI present. Default controller set.
INFO - 2016-02-23 07:03:33 --> Router Class Initialized
INFO - 2016-02-23 07:03:33 --> Output Class Initialized
INFO - 2016-02-23 07:03:33 --> Security Class Initialized
DEBUG - 2016-02-23 07:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:03:33 --> Input Class Initialized
INFO - 2016-02-23 07:03:33 --> Language Class Initialized
INFO - 2016-02-23 07:03:33 --> Loader Class Initialized
INFO - 2016-02-23 07:03:33 --> Helper loaded: url_helper
INFO - 2016-02-23 07:03:33 --> Helper loaded: file_helper
INFO - 2016-02-23 07:03:33 --> Helper loaded: date_helper
INFO - 2016-02-23 07:03:33 --> Helper loaded: form_helper
INFO - 2016-02-23 07:03:33 --> Database Driver Class Initialized
INFO - 2016-02-23 07:03:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:03:34 --> Controller Class Initialized
INFO - 2016-02-23 07:03:34 --> Model Class Initialized
INFO - 2016-02-23 07:03:34 --> Model Class Initialized
INFO - 2016-02-23 07:03:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:03:34 --> Pagination Class Initialized
INFO - 2016-02-23 07:03:34 --> Helper loaded: text_helper
INFO - 2016-02-23 07:03:34 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:03:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:03:34 --> Final output sent to browser
DEBUG - 2016-02-23 10:03:34 --> Total execution time: 1.1224
INFO - 2016-02-23 07:04:46 --> Config Class Initialized
INFO - 2016-02-23 07:04:46 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:04:46 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:04:46 --> Utf8 Class Initialized
INFO - 2016-02-23 07:04:46 --> URI Class Initialized
INFO - 2016-02-23 07:04:46 --> Router Class Initialized
INFO - 2016-02-23 07:04:46 --> Output Class Initialized
INFO - 2016-02-23 07:04:46 --> Security Class Initialized
DEBUG - 2016-02-23 07:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:04:46 --> Input Class Initialized
INFO - 2016-02-23 07:04:46 --> Language Class Initialized
INFO - 2016-02-23 07:04:46 --> Loader Class Initialized
INFO - 2016-02-23 07:04:46 --> Helper loaded: url_helper
INFO - 2016-02-23 07:04:46 --> Helper loaded: file_helper
INFO - 2016-02-23 07:04:46 --> Helper loaded: date_helper
INFO - 2016-02-23 07:04:46 --> Helper loaded: form_helper
INFO - 2016-02-23 07:04:46 --> Database Driver Class Initialized
INFO - 2016-02-23 07:04:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:04:47 --> Controller Class Initialized
INFO - 2016-02-23 07:04:47 --> Model Class Initialized
INFO - 2016-02-23 07:04:47 --> Model Class Initialized
INFO - 2016-02-23 07:04:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:04:47 --> Pagination Class Initialized
INFO - 2016-02-23 07:04:47 --> Helper loaded: text_helper
INFO - 2016-02-23 07:04:47 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 10:04:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:04:47 --> Final output sent to browser
DEBUG - 2016-02-23 10:04:47 --> Total execution time: 1.1115
INFO - 2016-02-23 07:04:50 --> Config Class Initialized
INFO - 2016-02-23 07:04:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:04:50 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:04:50 --> Utf8 Class Initialized
INFO - 2016-02-23 07:04:50 --> URI Class Initialized
INFO - 2016-02-23 07:04:50 --> Router Class Initialized
INFO - 2016-02-23 07:04:50 --> Output Class Initialized
INFO - 2016-02-23 07:04:50 --> Security Class Initialized
DEBUG - 2016-02-23 07:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:04:50 --> Input Class Initialized
INFO - 2016-02-23 07:04:50 --> Language Class Initialized
INFO - 2016-02-23 07:04:50 --> Loader Class Initialized
INFO - 2016-02-23 07:04:50 --> Helper loaded: url_helper
INFO - 2016-02-23 07:04:50 --> Helper loaded: file_helper
INFO - 2016-02-23 07:04:50 --> Helper loaded: date_helper
INFO - 2016-02-23 07:04:50 --> Helper loaded: form_helper
INFO - 2016-02-23 07:04:50 --> Database Driver Class Initialized
INFO - 2016-02-23 07:04:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:04:51 --> Controller Class Initialized
INFO - 2016-02-23 07:04:51 --> Model Class Initialized
INFO - 2016-02-23 07:04:51 --> Model Class Initialized
INFO - 2016-02-23 07:04:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:04:51 --> Pagination Class Initialized
INFO - 2016-02-23 07:04:51 --> Helper loaded: text_helper
INFO - 2016-02-23 07:04:51 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:04:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:04:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:04:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 10:04:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:04:51 --> Final output sent to browser
DEBUG - 2016-02-23 10:04:51 --> Total execution time: 1.1218
INFO - 2016-02-23 07:04:54 --> Config Class Initialized
INFO - 2016-02-23 07:04:54 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:04:54 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:04:54 --> Utf8 Class Initialized
INFO - 2016-02-23 07:04:54 --> URI Class Initialized
INFO - 2016-02-23 07:04:54 --> Router Class Initialized
INFO - 2016-02-23 07:04:54 --> Output Class Initialized
INFO - 2016-02-23 07:04:54 --> Security Class Initialized
DEBUG - 2016-02-23 07:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:04:54 --> Input Class Initialized
INFO - 2016-02-23 07:04:54 --> Language Class Initialized
INFO - 2016-02-23 07:04:54 --> Loader Class Initialized
INFO - 2016-02-23 07:04:54 --> Helper loaded: url_helper
INFO - 2016-02-23 07:04:54 --> Helper loaded: file_helper
INFO - 2016-02-23 07:04:54 --> Helper loaded: date_helper
INFO - 2016-02-23 07:04:54 --> Helper loaded: form_helper
INFO - 2016-02-23 07:04:54 --> Database Driver Class Initialized
INFO - 2016-02-23 07:04:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:04:55 --> Controller Class Initialized
INFO - 2016-02-23 07:04:55 --> Model Class Initialized
INFO - 2016-02-23 07:04:55 --> Model Class Initialized
INFO - 2016-02-23 07:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:04:55 --> Pagination Class Initialized
INFO - 2016-02-23 07:04:55 --> Helper loaded: text_helper
INFO - 2016-02-23 07:04:55 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 10:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 10:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:04:55 --> Final output sent to browser
DEBUG - 2016-02-23 10:04:55 --> Total execution time: 1.1809
INFO - 2016-02-23 07:06:06 --> Config Class Initialized
INFO - 2016-02-23 07:06:06 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:06:06 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:06:06 --> Utf8 Class Initialized
INFO - 2016-02-23 07:06:06 --> URI Class Initialized
DEBUG - 2016-02-23 07:06:06 --> No URI present. Default controller set.
INFO - 2016-02-23 07:06:06 --> Router Class Initialized
INFO - 2016-02-23 07:06:06 --> Output Class Initialized
INFO - 2016-02-23 07:06:06 --> Security Class Initialized
DEBUG - 2016-02-23 07:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:06:06 --> Input Class Initialized
INFO - 2016-02-23 07:06:06 --> Language Class Initialized
INFO - 2016-02-23 07:06:06 --> Loader Class Initialized
INFO - 2016-02-23 07:06:06 --> Helper loaded: url_helper
INFO - 2016-02-23 07:06:06 --> Helper loaded: file_helper
INFO - 2016-02-23 07:06:06 --> Helper loaded: date_helper
INFO - 2016-02-23 07:06:06 --> Helper loaded: form_helper
INFO - 2016-02-23 07:06:06 --> Database Driver Class Initialized
INFO - 2016-02-23 07:06:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:06:08 --> Controller Class Initialized
INFO - 2016-02-23 07:06:08 --> Model Class Initialized
INFO - 2016-02-23 07:06:08 --> Model Class Initialized
INFO - 2016-02-23 07:06:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:06:08 --> Pagination Class Initialized
INFO - 2016-02-23 07:06:08 --> Helper loaded: text_helper
INFO - 2016-02-23 07:06:08 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:06:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:06:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:06:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:06:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:06:08 --> Final output sent to browser
DEBUG - 2016-02-23 10:06:08 --> Total execution time: 1.1509
INFO - 2016-02-23 07:06:47 --> Config Class Initialized
INFO - 2016-02-23 07:06:47 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:06:47 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:06:47 --> Utf8 Class Initialized
INFO - 2016-02-23 07:06:47 --> URI Class Initialized
INFO - 2016-02-23 07:06:47 --> Router Class Initialized
INFO - 2016-02-23 07:06:47 --> Output Class Initialized
INFO - 2016-02-23 07:06:47 --> Security Class Initialized
DEBUG - 2016-02-23 07:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:06:47 --> Input Class Initialized
INFO - 2016-02-23 07:06:47 --> Language Class Initialized
INFO - 2016-02-23 07:06:47 --> Loader Class Initialized
INFO - 2016-02-23 07:06:47 --> Helper loaded: url_helper
INFO - 2016-02-23 07:06:47 --> Helper loaded: file_helper
INFO - 2016-02-23 07:06:47 --> Helper loaded: date_helper
INFO - 2016-02-23 07:06:47 --> Helper loaded: form_helper
INFO - 2016-02-23 07:06:47 --> Database Driver Class Initialized
INFO - 2016-02-23 07:06:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:06:48 --> Controller Class Initialized
INFO - 2016-02-23 07:06:48 --> Model Class Initialized
INFO - 2016-02-23 07:06:48 --> Model Class Initialized
INFO - 2016-02-23 07:06:48 --> Form Validation Class Initialized
INFO - 2016-02-23 07:06:48 --> Helper loaded: text_helper
INFO - 2016-02-23 07:06:48 --> Config Class Initialized
INFO - 2016-02-23 07:06:48 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:06:48 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:06:48 --> Utf8 Class Initialized
INFO - 2016-02-23 07:06:48 --> URI Class Initialized
DEBUG - 2016-02-23 07:06:48 --> No URI present. Default controller set.
INFO - 2016-02-23 07:06:48 --> Router Class Initialized
INFO - 2016-02-23 07:06:48 --> Output Class Initialized
INFO - 2016-02-23 07:06:48 --> Security Class Initialized
DEBUG - 2016-02-23 07:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:06:48 --> Input Class Initialized
INFO - 2016-02-23 07:06:48 --> Language Class Initialized
INFO - 2016-02-23 07:06:48 --> Loader Class Initialized
INFO - 2016-02-23 07:06:48 --> Helper loaded: url_helper
INFO - 2016-02-23 07:06:48 --> Helper loaded: file_helper
INFO - 2016-02-23 07:06:48 --> Helper loaded: date_helper
INFO - 2016-02-23 07:06:48 --> Helper loaded: form_helper
INFO - 2016-02-23 07:06:48 --> Database Driver Class Initialized
INFO - 2016-02-23 07:06:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:06:49 --> Controller Class Initialized
INFO - 2016-02-23 07:06:49 --> Model Class Initialized
INFO - 2016-02-23 07:06:49 --> Model Class Initialized
INFO - 2016-02-23 07:06:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:06:49 --> Pagination Class Initialized
INFO - 2016-02-23 07:06:49 --> Helper loaded: text_helper
INFO - 2016-02-23 07:06:49 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:06:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:06:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:06:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:06:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:06:49 --> Final output sent to browser
DEBUG - 2016-02-23 10:06:49 --> Total execution time: 1.2028
INFO - 2016-02-23 07:06:52 --> Config Class Initialized
INFO - 2016-02-23 07:06:52 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:06:52 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:06:52 --> Utf8 Class Initialized
INFO - 2016-02-23 07:06:52 --> URI Class Initialized
INFO - 2016-02-23 07:06:52 --> Router Class Initialized
INFO - 2016-02-23 07:06:52 --> Output Class Initialized
INFO - 2016-02-23 07:06:52 --> Security Class Initialized
DEBUG - 2016-02-23 07:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:06:52 --> Input Class Initialized
INFO - 2016-02-23 07:06:52 --> Language Class Initialized
INFO - 2016-02-23 07:06:52 --> Loader Class Initialized
INFO - 2016-02-23 07:06:52 --> Helper loaded: url_helper
INFO - 2016-02-23 07:06:52 --> Helper loaded: file_helper
INFO - 2016-02-23 07:06:52 --> Helper loaded: date_helper
INFO - 2016-02-23 07:06:52 --> Helper loaded: form_helper
INFO - 2016-02-23 07:06:52 --> Database Driver Class Initialized
INFO - 2016-02-23 07:06:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:06:53 --> Controller Class Initialized
INFO - 2016-02-23 07:06:53 --> Model Class Initialized
INFO - 2016-02-23 07:06:53 --> Model Class Initialized
INFO - 2016-02-23 07:06:53 --> Form Validation Class Initialized
INFO - 2016-02-23 07:06:53 --> Helper loaded: text_helper
INFO - 2016-02-23 07:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 07:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 07:06:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-02-23 07:06:53 --> Model Class Initialized
ERROR - 2016-02-23 07:06:53 --> Severity: Warning --> Missing argument 1 for Jboard_model::get_latest(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php on line 37 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 72
ERROR - 2016-02-23 07:06:53 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 76
ERROR - 2016-02-23 07:06:53 --> Query error: No tables used - Invalid query: SELECT *
ORDER BY `id` DESC
 LIMIT 5
INFO - 2016-02-23 07:06:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-23 07:06:55 --> Config Class Initialized
INFO - 2016-02-23 07:06:55 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:06:55 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:06:55 --> Utf8 Class Initialized
INFO - 2016-02-23 07:06:55 --> URI Class Initialized
DEBUG - 2016-02-23 07:06:55 --> No URI present. Default controller set.
INFO - 2016-02-23 07:06:55 --> Router Class Initialized
INFO - 2016-02-23 07:06:55 --> Output Class Initialized
INFO - 2016-02-23 07:06:55 --> Security Class Initialized
DEBUG - 2016-02-23 07:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:06:55 --> Input Class Initialized
INFO - 2016-02-23 07:06:55 --> Language Class Initialized
INFO - 2016-02-23 07:06:55 --> Loader Class Initialized
INFO - 2016-02-23 07:06:55 --> Helper loaded: url_helper
INFO - 2016-02-23 07:06:55 --> Helper loaded: file_helper
INFO - 2016-02-23 07:06:55 --> Helper loaded: date_helper
INFO - 2016-02-23 07:06:55 --> Helper loaded: form_helper
INFO - 2016-02-23 07:06:55 --> Database Driver Class Initialized
INFO - 2016-02-23 07:06:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:06:56 --> Controller Class Initialized
INFO - 2016-02-23 07:06:56 --> Model Class Initialized
INFO - 2016-02-23 07:06:56 --> Model Class Initialized
INFO - 2016-02-23 07:06:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:06:56 --> Pagination Class Initialized
INFO - 2016-02-23 07:06:56 --> Helper loaded: text_helper
INFO - 2016-02-23 07:06:56 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:06:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:06:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:06:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:06:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:06:56 --> Final output sent to browser
DEBUG - 2016-02-23 10:06:56 --> Total execution time: 1.1863
INFO - 2016-02-23 07:07:03 --> Config Class Initialized
INFO - 2016-02-23 07:07:03 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:07:03 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:07:03 --> Utf8 Class Initialized
INFO - 2016-02-23 07:07:03 --> URI Class Initialized
INFO - 2016-02-23 07:07:03 --> Router Class Initialized
INFO - 2016-02-23 07:07:03 --> Output Class Initialized
INFO - 2016-02-23 07:07:03 --> Security Class Initialized
DEBUG - 2016-02-23 07:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:07:03 --> Input Class Initialized
INFO - 2016-02-23 07:07:03 --> Language Class Initialized
INFO - 2016-02-23 07:07:03 --> Loader Class Initialized
INFO - 2016-02-23 07:07:03 --> Helper loaded: url_helper
INFO - 2016-02-23 07:07:03 --> Helper loaded: file_helper
INFO - 2016-02-23 07:07:03 --> Helper loaded: date_helper
INFO - 2016-02-23 07:07:03 --> Helper loaded: form_helper
INFO - 2016-02-23 07:07:03 --> Database Driver Class Initialized
INFO - 2016-02-23 07:07:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:07:04 --> Controller Class Initialized
INFO - 2016-02-23 07:07:04 --> Model Class Initialized
INFO - 2016-02-23 07:07:04 --> Model Class Initialized
INFO - 2016-02-23 07:07:04 --> Form Validation Class Initialized
INFO - 2016-02-23 07:07:04 --> Helper loaded: text_helper
INFO - 2016-02-23 07:07:04 --> Final output sent to browser
DEBUG - 2016-02-23 07:07:04 --> Total execution time: 1.1351
INFO - 2016-02-23 07:07:06 --> Config Class Initialized
INFO - 2016-02-23 07:07:06 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:07:06 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:07:06 --> Utf8 Class Initialized
INFO - 2016-02-23 07:07:06 --> URI Class Initialized
DEBUG - 2016-02-23 07:07:06 --> No URI present. Default controller set.
INFO - 2016-02-23 07:07:06 --> Router Class Initialized
INFO - 2016-02-23 07:07:06 --> Output Class Initialized
INFO - 2016-02-23 07:07:06 --> Security Class Initialized
DEBUG - 2016-02-23 07:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:07:06 --> Input Class Initialized
INFO - 2016-02-23 07:07:06 --> Language Class Initialized
INFO - 2016-02-23 07:07:06 --> Loader Class Initialized
INFO - 2016-02-23 07:07:06 --> Helper loaded: url_helper
INFO - 2016-02-23 07:07:06 --> Helper loaded: file_helper
INFO - 2016-02-23 07:07:06 --> Helper loaded: date_helper
INFO - 2016-02-23 07:07:06 --> Helper loaded: form_helper
INFO - 2016-02-23 07:07:06 --> Database Driver Class Initialized
INFO - 2016-02-23 07:07:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:07:07 --> Controller Class Initialized
INFO - 2016-02-23 07:07:07 --> Model Class Initialized
INFO - 2016-02-23 07:07:07 --> Model Class Initialized
INFO - 2016-02-23 07:07:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:07:07 --> Pagination Class Initialized
INFO - 2016-02-23 07:07:07 --> Helper loaded: text_helper
INFO - 2016-02-23 07:07:07 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:07:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:07:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:07:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:07:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:07:07 --> Final output sent to browser
DEBUG - 2016-02-23 10:07:07 --> Total execution time: 1.1680
INFO - 2016-02-23 07:07:29 --> Config Class Initialized
INFO - 2016-02-23 07:07:29 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:07:29 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:07:29 --> Utf8 Class Initialized
INFO - 2016-02-23 07:07:29 --> URI Class Initialized
DEBUG - 2016-02-23 07:07:29 --> No URI present. Default controller set.
INFO - 2016-02-23 07:07:29 --> Router Class Initialized
INFO - 2016-02-23 07:07:29 --> Output Class Initialized
INFO - 2016-02-23 07:07:29 --> Security Class Initialized
DEBUG - 2016-02-23 07:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:07:29 --> Input Class Initialized
INFO - 2016-02-23 07:07:29 --> Language Class Initialized
INFO - 2016-02-23 07:07:29 --> Loader Class Initialized
INFO - 2016-02-23 07:07:29 --> Helper loaded: url_helper
INFO - 2016-02-23 07:07:29 --> Helper loaded: file_helper
INFO - 2016-02-23 07:07:29 --> Helper loaded: date_helper
INFO - 2016-02-23 07:07:29 --> Helper loaded: form_helper
INFO - 2016-02-23 07:07:29 --> Database Driver Class Initialized
INFO - 2016-02-23 07:07:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:07:30 --> Controller Class Initialized
INFO - 2016-02-23 07:07:30 --> Model Class Initialized
INFO - 2016-02-23 07:07:30 --> Model Class Initialized
INFO - 2016-02-23 07:07:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:07:30 --> Pagination Class Initialized
INFO - 2016-02-23 07:07:30 --> Helper loaded: text_helper
INFO - 2016-02-23 07:07:30 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:07:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:07:30 --> Final output sent to browser
DEBUG - 2016-02-23 10:07:30 --> Total execution time: 1.1551
INFO - 2016-02-23 07:08:42 --> Config Class Initialized
INFO - 2016-02-23 07:08:42 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:08:42 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:08:42 --> Utf8 Class Initialized
INFO - 2016-02-23 07:08:42 --> URI Class Initialized
INFO - 2016-02-23 07:08:42 --> Router Class Initialized
INFO - 2016-02-23 07:08:42 --> Output Class Initialized
INFO - 2016-02-23 07:08:42 --> Security Class Initialized
DEBUG - 2016-02-23 07:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:08:42 --> Input Class Initialized
INFO - 2016-02-23 07:08:42 --> Language Class Initialized
INFO - 2016-02-23 07:08:42 --> Loader Class Initialized
INFO - 2016-02-23 07:08:42 --> Helper loaded: url_helper
INFO - 2016-02-23 07:08:42 --> Helper loaded: file_helper
INFO - 2016-02-23 07:08:42 --> Helper loaded: date_helper
INFO - 2016-02-23 07:08:42 --> Helper loaded: form_helper
INFO - 2016-02-23 07:08:42 --> Database Driver Class Initialized
INFO - 2016-02-23 07:08:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:08:43 --> Controller Class Initialized
INFO - 2016-02-23 07:08:43 --> Model Class Initialized
INFO - 2016-02-23 07:08:43 --> Model Class Initialized
INFO - 2016-02-23 07:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:08:43 --> Pagination Class Initialized
INFO - 2016-02-23 07:08:43 --> Helper loaded: text_helper
INFO - 2016-02-23 07:08:43 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 10:08:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:08:43 --> Final output sent to browser
DEBUG - 2016-02-23 10:08:43 --> Total execution time: 1.1401
INFO - 2016-02-23 07:08:45 --> Config Class Initialized
INFO - 2016-02-23 07:08:45 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:08:45 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:08:45 --> Utf8 Class Initialized
INFO - 2016-02-23 07:08:45 --> URI Class Initialized
INFO - 2016-02-23 07:08:45 --> Router Class Initialized
INFO - 2016-02-23 07:08:45 --> Output Class Initialized
INFO - 2016-02-23 07:08:45 --> Security Class Initialized
DEBUG - 2016-02-23 07:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:08:45 --> Input Class Initialized
INFO - 2016-02-23 07:08:45 --> Language Class Initialized
INFO - 2016-02-23 07:08:45 --> Loader Class Initialized
INFO - 2016-02-23 07:08:45 --> Helper loaded: url_helper
INFO - 2016-02-23 07:08:45 --> Helper loaded: file_helper
INFO - 2016-02-23 07:08:45 --> Helper loaded: date_helper
INFO - 2016-02-23 07:08:45 --> Helper loaded: form_helper
INFO - 2016-02-23 07:08:45 --> Database Driver Class Initialized
INFO - 2016-02-23 07:08:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:08:46 --> Controller Class Initialized
INFO - 2016-02-23 07:08:46 --> Model Class Initialized
INFO - 2016-02-23 07:08:46 --> Model Class Initialized
INFO - 2016-02-23 07:08:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:08:46 --> Pagination Class Initialized
INFO - 2016-02-23 07:08:46 --> Helper loaded: text_helper
INFO - 2016-02-23 07:08:46 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 10:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 10:08:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:08:46 --> Final output sent to browser
DEBUG - 2016-02-23 10:08:46 --> Total execution time: 1.1629
INFO - 2016-02-23 07:55:16 --> Config Class Initialized
INFO - 2016-02-23 07:55:16 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:55:16 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:55:16 --> Utf8 Class Initialized
INFO - 2016-02-23 07:55:16 --> URI Class Initialized
DEBUG - 2016-02-23 07:55:16 --> No URI present. Default controller set.
INFO - 2016-02-23 07:55:16 --> Router Class Initialized
INFO - 2016-02-23 07:55:16 --> Output Class Initialized
INFO - 2016-02-23 07:55:16 --> Security Class Initialized
DEBUG - 2016-02-23 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:55:16 --> Input Class Initialized
INFO - 2016-02-23 07:55:16 --> Language Class Initialized
INFO - 2016-02-23 07:55:16 --> Loader Class Initialized
INFO - 2016-02-23 07:55:16 --> Helper loaded: url_helper
INFO - 2016-02-23 07:55:16 --> Helper loaded: file_helper
INFO - 2016-02-23 07:55:16 --> Helper loaded: date_helper
INFO - 2016-02-23 07:55:16 --> Helper loaded: form_helper
INFO - 2016-02-23 07:55:16 --> Database Driver Class Initialized
INFO - 2016-02-23 07:55:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:55:17 --> Controller Class Initialized
INFO - 2016-02-23 07:55:17 --> Model Class Initialized
ERROR - 2016-02-23 07:55:17 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\models\jboard_model.php 249
INFO - 2016-02-23 07:56:20 --> Config Class Initialized
INFO - 2016-02-23 07:56:20 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:56:20 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:56:20 --> Utf8 Class Initialized
INFO - 2016-02-23 07:56:20 --> URI Class Initialized
DEBUG - 2016-02-23 07:56:20 --> No URI present. Default controller set.
INFO - 2016-02-23 07:56:20 --> Router Class Initialized
INFO - 2016-02-23 07:56:20 --> Output Class Initialized
INFO - 2016-02-23 07:56:20 --> Security Class Initialized
DEBUG - 2016-02-23 07:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:56:20 --> Input Class Initialized
INFO - 2016-02-23 07:56:20 --> Language Class Initialized
INFO - 2016-02-23 07:56:20 --> Loader Class Initialized
INFO - 2016-02-23 07:56:20 --> Helper loaded: url_helper
INFO - 2016-02-23 07:56:20 --> Helper loaded: file_helper
INFO - 2016-02-23 07:56:20 --> Helper loaded: date_helper
INFO - 2016-02-23 07:56:20 --> Helper loaded: form_helper
INFO - 2016-02-23 07:56:20 --> Database Driver Class Initialized
INFO - 2016-02-23 07:56:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:56:21 --> Controller Class Initialized
INFO - 2016-02-23 07:56:21 --> Model Class Initialized
INFO - 2016-02-23 07:56:21 --> Model Class Initialized
INFO - 2016-02-23 07:56:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:56:21 --> Pagination Class Initialized
INFO - 2016-02-23 07:56:21 --> Helper loaded: text_helper
INFO - 2016-02-23 07:56:21 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:56:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 10:56:21 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 9
INFO - 2016-02-23 07:56:34 --> Config Class Initialized
INFO - 2016-02-23 07:56:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:56:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:56:34 --> Utf8 Class Initialized
INFO - 2016-02-23 07:56:34 --> URI Class Initialized
DEBUG - 2016-02-23 07:56:34 --> No URI present. Default controller set.
INFO - 2016-02-23 07:56:34 --> Router Class Initialized
INFO - 2016-02-23 07:56:34 --> Output Class Initialized
INFO - 2016-02-23 07:56:34 --> Security Class Initialized
DEBUG - 2016-02-23 07:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:56:34 --> Input Class Initialized
INFO - 2016-02-23 07:56:34 --> Language Class Initialized
INFO - 2016-02-23 07:56:34 --> Loader Class Initialized
INFO - 2016-02-23 07:56:34 --> Helper loaded: url_helper
INFO - 2016-02-23 07:56:34 --> Helper loaded: file_helper
INFO - 2016-02-23 07:56:34 --> Helper loaded: date_helper
INFO - 2016-02-23 07:56:34 --> Helper loaded: form_helper
INFO - 2016-02-23 07:56:34 --> Database Driver Class Initialized
INFO - 2016-02-23 07:56:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:56:35 --> Controller Class Initialized
INFO - 2016-02-23 07:56:35 --> Model Class Initialized
INFO - 2016-02-23 07:56:35 --> Model Class Initialized
INFO - 2016-02-23 07:56:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:56:35 --> Pagination Class Initialized
INFO - 2016-02-23 07:56:35 --> Helper loaded: text_helper
INFO - 2016-02-23 07:56:35 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:56:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:56:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 10:56:35 --> Severity: Notice --> Undefined variable: wall C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 2
ERROR - 2016-02-23 10:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 2
ERROR - 2016-02-23 10:56:35 --> Severity: Notice --> Undefined variable: picture C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 8
ERROR - 2016-02-23 10:56:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 8
INFO - 2016-02-23 10:56:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:56:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:56:35 --> Final output sent to browser
DEBUG - 2016-02-23 10:56:35 --> Total execution time: 1.1911
INFO - 2016-02-23 07:56:56 --> Config Class Initialized
INFO - 2016-02-23 07:56:56 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:56:56 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:56:56 --> Utf8 Class Initialized
INFO - 2016-02-23 07:56:56 --> URI Class Initialized
DEBUG - 2016-02-23 07:56:56 --> No URI present. Default controller set.
INFO - 2016-02-23 07:56:56 --> Router Class Initialized
INFO - 2016-02-23 07:56:56 --> Output Class Initialized
INFO - 2016-02-23 07:56:56 --> Security Class Initialized
DEBUG - 2016-02-23 07:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:56:56 --> Input Class Initialized
INFO - 2016-02-23 07:56:56 --> Language Class Initialized
INFO - 2016-02-23 07:56:56 --> Loader Class Initialized
INFO - 2016-02-23 07:56:56 --> Helper loaded: url_helper
INFO - 2016-02-23 07:56:56 --> Helper loaded: file_helper
INFO - 2016-02-23 07:56:56 --> Helper loaded: date_helper
INFO - 2016-02-23 07:56:56 --> Helper loaded: form_helper
INFO - 2016-02-23 07:56:56 --> Database Driver Class Initialized
INFO - 2016-02-23 07:56:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:56:57 --> Controller Class Initialized
INFO - 2016-02-23 07:56:57 --> Model Class Initialized
INFO - 2016-02-23 07:56:57 --> Model Class Initialized
INFO - 2016-02-23 07:56:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:56:57 --> Pagination Class Initialized
INFO - 2016-02-23 07:56:57 --> Helper loaded: text_helper
INFO - 2016-02-23 07:56:57 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:56:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:56:57 --> Final output sent to browser
DEBUG - 2016-02-23 10:56:57 --> Total execution time: 1.1669
INFO - 2016-02-23 07:57:47 --> Config Class Initialized
INFO - 2016-02-23 07:57:47 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:57:47 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:57:47 --> Utf8 Class Initialized
INFO - 2016-02-23 07:57:47 --> URI Class Initialized
DEBUG - 2016-02-23 07:57:47 --> No URI present. Default controller set.
INFO - 2016-02-23 07:57:47 --> Router Class Initialized
INFO - 2016-02-23 07:57:47 --> Output Class Initialized
INFO - 2016-02-23 07:57:47 --> Security Class Initialized
DEBUG - 2016-02-23 07:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:57:47 --> Input Class Initialized
INFO - 2016-02-23 07:57:47 --> Language Class Initialized
INFO - 2016-02-23 07:57:47 --> Loader Class Initialized
INFO - 2016-02-23 07:57:47 --> Helper loaded: url_helper
INFO - 2016-02-23 07:57:47 --> Helper loaded: file_helper
INFO - 2016-02-23 07:57:47 --> Helper loaded: date_helper
INFO - 2016-02-23 07:57:47 --> Helper loaded: form_helper
INFO - 2016-02-23 07:57:47 --> Database Driver Class Initialized
INFO - 2016-02-23 07:57:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:57:48 --> Controller Class Initialized
INFO - 2016-02-23 07:57:48 --> Model Class Initialized
INFO - 2016-02-23 07:57:48 --> Model Class Initialized
INFO - 2016-02-23 07:57:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:57:48 --> Pagination Class Initialized
INFO - 2016-02-23 07:57:48 --> Helper loaded: text_helper
INFO - 2016-02-23 07:57:48 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:57:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:57:48 --> Final output sent to browser
DEBUG - 2016-02-23 10:57:48 --> Total execution time: 1.1517
INFO - 2016-02-23 07:59:11 --> Config Class Initialized
INFO - 2016-02-23 07:59:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 07:59:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 07:59:11 --> Utf8 Class Initialized
INFO - 2016-02-23 07:59:11 --> URI Class Initialized
DEBUG - 2016-02-23 07:59:11 --> No URI present. Default controller set.
INFO - 2016-02-23 07:59:11 --> Router Class Initialized
INFO - 2016-02-23 07:59:11 --> Output Class Initialized
INFO - 2016-02-23 07:59:11 --> Security Class Initialized
DEBUG - 2016-02-23 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 07:59:11 --> Input Class Initialized
INFO - 2016-02-23 07:59:11 --> Language Class Initialized
INFO - 2016-02-23 07:59:11 --> Loader Class Initialized
INFO - 2016-02-23 07:59:11 --> Helper loaded: url_helper
INFO - 2016-02-23 07:59:11 --> Helper loaded: file_helper
INFO - 2016-02-23 07:59:11 --> Helper loaded: date_helper
INFO - 2016-02-23 07:59:11 --> Helper loaded: form_helper
INFO - 2016-02-23 07:59:11 --> Database Driver Class Initialized
INFO - 2016-02-23 07:59:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 07:59:12 --> Controller Class Initialized
INFO - 2016-02-23 07:59:12 --> Model Class Initialized
INFO - 2016-02-23 07:59:13 --> Model Class Initialized
INFO - 2016-02-23 07:59:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 07:59:13 --> Pagination Class Initialized
INFO - 2016-02-23 07:59:13 --> Helper loaded: text_helper
INFO - 2016-02-23 07:59:13 --> Helper loaded: cookie_helper
INFO - 2016-02-23 10:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 10:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 10:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 10:59:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 10:59:13 --> Final output sent to browser
DEBUG - 2016-02-23 10:59:13 --> Total execution time: 1.1564
INFO - 2016-02-23 08:01:37 --> Config Class Initialized
INFO - 2016-02-23 08:01:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:01:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:01:37 --> Utf8 Class Initialized
INFO - 2016-02-23 08:01:37 --> URI Class Initialized
DEBUG - 2016-02-23 08:01:37 --> No URI present. Default controller set.
INFO - 2016-02-23 08:01:37 --> Router Class Initialized
INFO - 2016-02-23 08:01:37 --> Output Class Initialized
INFO - 2016-02-23 08:01:37 --> Security Class Initialized
DEBUG - 2016-02-23 08:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:01:37 --> Input Class Initialized
INFO - 2016-02-23 08:01:37 --> Language Class Initialized
INFO - 2016-02-23 08:01:37 --> Loader Class Initialized
INFO - 2016-02-23 08:01:37 --> Helper loaded: url_helper
INFO - 2016-02-23 08:01:37 --> Helper loaded: file_helper
INFO - 2016-02-23 08:01:37 --> Helper loaded: date_helper
INFO - 2016-02-23 08:01:37 --> Helper loaded: form_helper
INFO - 2016-02-23 08:01:37 --> Database Driver Class Initialized
INFO - 2016-02-23 08:01:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:01:38 --> Controller Class Initialized
INFO - 2016-02-23 08:01:38 --> Model Class Initialized
INFO - 2016-02-23 08:01:38 --> Model Class Initialized
INFO - 2016-02-23 08:01:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:01:38 --> Pagination Class Initialized
INFO - 2016-02-23 08:01:38 --> Helper loaded: text_helper
INFO - 2016-02-23 08:01:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:01:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:01:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:01:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:01:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:01:38 --> Final output sent to browser
DEBUG - 2016-02-23 11:01:38 --> Total execution time: 1.1271
INFO - 2016-02-23 08:02:09 --> Config Class Initialized
INFO - 2016-02-23 08:02:09 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:02:09 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:02:09 --> Utf8 Class Initialized
INFO - 2016-02-23 08:02:09 --> URI Class Initialized
DEBUG - 2016-02-23 08:02:09 --> No URI present. Default controller set.
INFO - 2016-02-23 08:02:09 --> Router Class Initialized
INFO - 2016-02-23 08:02:09 --> Output Class Initialized
INFO - 2016-02-23 08:02:09 --> Security Class Initialized
DEBUG - 2016-02-23 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:02:09 --> Input Class Initialized
INFO - 2016-02-23 08:02:09 --> Language Class Initialized
INFO - 2016-02-23 08:02:09 --> Loader Class Initialized
INFO - 2016-02-23 08:02:09 --> Helper loaded: url_helper
INFO - 2016-02-23 08:02:09 --> Helper loaded: file_helper
INFO - 2016-02-23 08:02:09 --> Helper loaded: date_helper
INFO - 2016-02-23 08:02:09 --> Helper loaded: form_helper
INFO - 2016-02-23 08:02:09 --> Database Driver Class Initialized
INFO - 2016-02-23 08:02:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:02:10 --> Controller Class Initialized
INFO - 2016-02-23 08:02:10 --> Model Class Initialized
INFO - 2016-02-23 08:02:10 --> Model Class Initialized
INFO - 2016-02-23 08:02:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:02:10 --> Pagination Class Initialized
INFO - 2016-02-23 08:02:10 --> Helper loaded: text_helper
INFO - 2016-02-23 08:02:10 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:02:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:02:10 --> Final output sent to browser
DEBUG - 2016-02-23 11:02:10 --> Total execution time: 1.1241
INFO - 2016-02-23 08:02:30 --> Config Class Initialized
INFO - 2016-02-23 08:02:30 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:02:30 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:02:30 --> Utf8 Class Initialized
INFO - 2016-02-23 08:02:30 --> URI Class Initialized
DEBUG - 2016-02-23 08:02:30 --> No URI present. Default controller set.
INFO - 2016-02-23 08:02:30 --> Router Class Initialized
INFO - 2016-02-23 08:02:30 --> Output Class Initialized
INFO - 2016-02-23 08:02:30 --> Security Class Initialized
DEBUG - 2016-02-23 08:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:02:30 --> Input Class Initialized
INFO - 2016-02-23 08:02:30 --> Language Class Initialized
INFO - 2016-02-23 08:02:30 --> Loader Class Initialized
INFO - 2016-02-23 08:02:30 --> Helper loaded: url_helper
INFO - 2016-02-23 08:02:30 --> Helper loaded: file_helper
INFO - 2016-02-23 08:02:30 --> Helper loaded: date_helper
INFO - 2016-02-23 08:02:30 --> Helper loaded: form_helper
INFO - 2016-02-23 08:02:30 --> Database Driver Class Initialized
INFO - 2016-02-23 08:02:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:02:31 --> Controller Class Initialized
INFO - 2016-02-23 08:02:31 --> Model Class Initialized
INFO - 2016-02-23 08:02:31 --> Model Class Initialized
INFO - 2016-02-23 08:02:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:02:31 --> Pagination Class Initialized
INFO - 2016-02-23 08:02:31 --> Helper loaded: text_helper
INFO - 2016-02-23 08:02:31 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:02:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:02:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:02:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:02:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:02:31 --> Final output sent to browser
DEBUG - 2016-02-23 11:02:31 --> Total execution time: 1.1083
INFO - 2016-02-23 08:04:11 --> Config Class Initialized
INFO - 2016-02-23 08:04:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:04:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:04:11 --> Utf8 Class Initialized
INFO - 2016-02-23 08:04:11 --> URI Class Initialized
DEBUG - 2016-02-23 08:04:11 --> No URI present. Default controller set.
INFO - 2016-02-23 08:04:11 --> Router Class Initialized
INFO - 2016-02-23 08:04:11 --> Output Class Initialized
INFO - 2016-02-23 08:04:11 --> Security Class Initialized
DEBUG - 2016-02-23 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:04:11 --> Input Class Initialized
INFO - 2016-02-23 08:04:11 --> Language Class Initialized
INFO - 2016-02-23 08:04:11 --> Loader Class Initialized
INFO - 2016-02-23 08:04:11 --> Helper loaded: url_helper
INFO - 2016-02-23 08:04:11 --> Helper loaded: file_helper
INFO - 2016-02-23 08:04:11 --> Helper loaded: date_helper
INFO - 2016-02-23 08:04:11 --> Helper loaded: form_helper
INFO - 2016-02-23 08:04:11 --> Database Driver Class Initialized
INFO - 2016-02-23 08:04:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:04:12 --> Controller Class Initialized
INFO - 2016-02-23 08:04:12 --> Model Class Initialized
INFO - 2016-02-23 08:04:12 --> Model Class Initialized
INFO - 2016-02-23 08:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:04:12 --> Pagination Class Initialized
INFO - 2016-02-23 08:04:12 --> Helper loaded: text_helper
INFO - 2016-02-23 08:04:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:04:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:04:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 11:04:12 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 2
INFO - 2016-02-23 08:04:33 --> Config Class Initialized
INFO - 2016-02-23 08:04:33 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:04:33 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:04:33 --> Utf8 Class Initialized
INFO - 2016-02-23 08:04:33 --> URI Class Initialized
DEBUG - 2016-02-23 08:04:33 --> No URI present. Default controller set.
INFO - 2016-02-23 08:04:33 --> Router Class Initialized
INFO - 2016-02-23 08:04:33 --> Output Class Initialized
INFO - 2016-02-23 08:04:33 --> Security Class Initialized
DEBUG - 2016-02-23 08:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:04:33 --> Input Class Initialized
INFO - 2016-02-23 08:04:33 --> Language Class Initialized
INFO - 2016-02-23 08:04:33 --> Loader Class Initialized
INFO - 2016-02-23 08:04:33 --> Helper loaded: url_helper
INFO - 2016-02-23 08:04:33 --> Helper loaded: file_helper
INFO - 2016-02-23 08:04:33 --> Helper loaded: date_helper
INFO - 2016-02-23 08:04:33 --> Helper loaded: form_helper
INFO - 2016-02-23 08:04:33 --> Database Driver Class Initialized
INFO - 2016-02-23 08:04:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:04:34 --> Controller Class Initialized
INFO - 2016-02-23 08:04:34 --> Model Class Initialized
INFO - 2016-02-23 08:04:34 --> Model Class Initialized
INFO - 2016-02-23 08:04:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:04:35 --> Pagination Class Initialized
INFO - 2016-02-23 08:04:35 --> Helper loaded: text_helper
INFO - 2016-02-23 08:04:35 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 11:04:35 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 2
INFO - 2016-02-23 08:05:30 --> Config Class Initialized
INFO - 2016-02-23 08:05:30 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:05:30 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:05:30 --> Utf8 Class Initialized
INFO - 2016-02-23 08:05:30 --> URI Class Initialized
DEBUG - 2016-02-23 08:05:30 --> No URI present. Default controller set.
INFO - 2016-02-23 08:05:30 --> Router Class Initialized
INFO - 2016-02-23 08:05:30 --> Output Class Initialized
INFO - 2016-02-23 08:05:30 --> Security Class Initialized
DEBUG - 2016-02-23 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:05:30 --> Input Class Initialized
INFO - 2016-02-23 08:05:30 --> Language Class Initialized
INFO - 2016-02-23 08:05:30 --> Loader Class Initialized
INFO - 2016-02-23 08:05:30 --> Helper loaded: url_helper
INFO - 2016-02-23 08:05:30 --> Helper loaded: file_helper
INFO - 2016-02-23 08:05:30 --> Helper loaded: date_helper
INFO - 2016-02-23 08:05:30 --> Helper loaded: form_helper
INFO - 2016-02-23 08:05:30 --> Database Driver Class Initialized
INFO - 2016-02-23 08:05:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:05:31 --> Controller Class Initialized
INFO - 2016-02-23 08:05:31 --> Model Class Initialized
INFO - 2016-02-23 08:05:31 --> Model Class Initialized
INFO - 2016-02-23 08:05:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:05:31 --> Pagination Class Initialized
INFO - 2016-02-23 08:05:31 --> Helper loaded: text_helper
INFO - 2016-02-23 08:05:31 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:05:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:05:31 --> Final output sent to browser
DEBUG - 2016-02-23 11:05:31 --> Total execution time: 1.1402
INFO - 2016-02-23 08:05:53 --> Config Class Initialized
INFO - 2016-02-23 08:05:53 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:05:53 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:05:53 --> Utf8 Class Initialized
INFO - 2016-02-23 08:05:53 --> URI Class Initialized
DEBUG - 2016-02-23 08:05:53 --> No URI present. Default controller set.
INFO - 2016-02-23 08:05:53 --> Router Class Initialized
INFO - 2016-02-23 08:05:53 --> Output Class Initialized
INFO - 2016-02-23 08:05:53 --> Security Class Initialized
DEBUG - 2016-02-23 08:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:05:53 --> Input Class Initialized
INFO - 2016-02-23 08:05:53 --> Language Class Initialized
INFO - 2016-02-23 08:05:53 --> Loader Class Initialized
INFO - 2016-02-23 08:05:53 --> Helper loaded: url_helper
INFO - 2016-02-23 08:05:53 --> Helper loaded: file_helper
INFO - 2016-02-23 08:05:53 --> Helper loaded: date_helper
INFO - 2016-02-23 08:05:53 --> Helper loaded: form_helper
INFO - 2016-02-23 08:05:53 --> Database Driver Class Initialized
INFO - 2016-02-23 08:05:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:05:54 --> Controller Class Initialized
INFO - 2016-02-23 08:05:54 --> Model Class Initialized
INFO - 2016-02-23 08:05:54 --> Model Class Initialized
INFO - 2016-02-23 08:05:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:05:54 --> Pagination Class Initialized
INFO - 2016-02-23 08:05:54 --> Helper loaded: text_helper
INFO - 2016-02-23 08:05:54 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:05:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:05:54 --> Final output sent to browser
DEBUG - 2016-02-23 11:05:54 --> Total execution time: 1.1169
INFO - 2016-02-23 08:06:01 --> Config Class Initialized
INFO - 2016-02-23 08:06:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:06:01 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:06:01 --> Utf8 Class Initialized
INFO - 2016-02-23 08:06:01 --> URI Class Initialized
DEBUG - 2016-02-23 08:06:01 --> No URI present. Default controller set.
INFO - 2016-02-23 08:06:01 --> Router Class Initialized
INFO - 2016-02-23 08:06:01 --> Output Class Initialized
INFO - 2016-02-23 08:06:01 --> Security Class Initialized
DEBUG - 2016-02-23 08:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:06:01 --> Input Class Initialized
INFO - 2016-02-23 08:06:01 --> Language Class Initialized
INFO - 2016-02-23 08:06:01 --> Loader Class Initialized
INFO - 2016-02-23 08:06:01 --> Helper loaded: url_helper
INFO - 2016-02-23 08:06:01 --> Helper loaded: file_helper
INFO - 2016-02-23 08:06:01 --> Helper loaded: date_helper
INFO - 2016-02-23 08:06:01 --> Helper loaded: form_helper
INFO - 2016-02-23 08:06:01 --> Database Driver Class Initialized
INFO - 2016-02-23 08:06:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:06:02 --> Controller Class Initialized
INFO - 2016-02-23 08:06:02 --> Model Class Initialized
INFO - 2016-02-23 08:06:02 --> Model Class Initialized
INFO - 2016-02-23 08:06:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:06:02 --> Pagination Class Initialized
INFO - 2016-02-23 08:06:02 --> Helper loaded: text_helper
INFO - 2016-02-23 08:06:02 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:06:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:06:02 --> Final output sent to browser
DEBUG - 2016-02-23 11:06:02 --> Total execution time: 1.1287
INFO - 2016-02-23 08:06:16 --> Config Class Initialized
INFO - 2016-02-23 08:06:16 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:06:16 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:06:16 --> Utf8 Class Initialized
INFO - 2016-02-23 08:06:16 --> URI Class Initialized
DEBUG - 2016-02-23 08:06:16 --> No URI present. Default controller set.
INFO - 2016-02-23 08:06:16 --> Router Class Initialized
INFO - 2016-02-23 08:06:16 --> Output Class Initialized
INFO - 2016-02-23 08:06:16 --> Security Class Initialized
DEBUG - 2016-02-23 08:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:06:16 --> Input Class Initialized
INFO - 2016-02-23 08:06:16 --> Language Class Initialized
INFO - 2016-02-23 08:06:16 --> Loader Class Initialized
INFO - 2016-02-23 08:06:16 --> Helper loaded: url_helper
INFO - 2016-02-23 08:06:16 --> Helper loaded: file_helper
INFO - 2016-02-23 08:06:16 --> Helper loaded: date_helper
INFO - 2016-02-23 08:06:16 --> Helper loaded: form_helper
INFO - 2016-02-23 08:06:16 --> Database Driver Class Initialized
INFO - 2016-02-23 08:06:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:06:17 --> Controller Class Initialized
INFO - 2016-02-23 08:06:17 --> Model Class Initialized
INFO - 2016-02-23 08:06:17 --> Model Class Initialized
INFO - 2016-02-23 08:06:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:06:17 --> Pagination Class Initialized
INFO - 2016-02-23 08:06:17 --> Helper loaded: text_helper
INFO - 2016-02-23 08:06:17 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:06:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:06:17 --> Final output sent to browser
DEBUG - 2016-02-23 11:06:17 --> Total execution time: 1.1225
INFO - 2016-02-23 08:06:18 --> Config Class Initialized
INFO - 2016-02-23 08:06:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:06:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:06:18 --> Utf8 Class Initialized
INFO - 2016-02-23 08:06:18 --> URI Class Initialized
DEBUG - 2016-02-23 08:06:18 --> No URI present. Default controller set.
INFO - 2016-02-23 08:06:18 --> Router Class Initialized
INFO - 2016-02-23 08:06:18 --> Output Class Initialized
INFO - 2016-02-23 08:06:18 --> Security Class Initialized
DEBUG - 2016-02-23 08:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:06:18 --> Input Class Initialized
INFO - 2016-02-23 08:06:18 --> Language Class Initialized
INFO - 2016-02-23 08:06:18 --> Loader Class Initialized
INFO - 2016-02-23 08:06:18 --> Helper loaded: url_helper
INFO - 2016-02-23 08:06:18 --> Helper loaded: file_helper
INFO - 2016-02-23 08:06:18 --> Helper loaded: date_helper
INFO - 2016-02-23 08:06:18 --> Helper loaded: form_helper
INFO - 2016-02-23 08:06:18 --> Database Driver Class Initialized
INFO - 2016-02-23 08:06:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:06:19 --> Controller Class Initialized
INFO - 2016-02-23 08:06:19 --> Model Class Initialized
INFO - 2016-02-23 08:06:19 --> Model Class Initialized
INFO - 2016-02-23 08:06:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:06:19 --> Pagination Class Initialized
INFO - 2016-02-23 08:06:19 --> Helper loaded: text_helper
INFO - 2016-02-23 08:06:19 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:06:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:06:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:06:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:06:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:06:19 --> Final output sent to browser
DEBUG - 2016-02-23 11:06:19 --> Total execution time: 1.1259
INFO - 2016-02-23 08:10:15 --> Config Class Initialized
INFO - 2016-02-23 08:10:15 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:10:15 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:10:15 --> Utf8 Class Initialized
INFO - 2016-02-23 08:10:15 --> URI Class Initialized
DEBUG - 2016-02-23 08:10:15 --> No URI present. Default controller set.
INFO - 2016-02-23 08:10:15 --> Router Class Initialized
INFO - 2016-02-23 08:10:15 --> Output Class Initialized
INFO - 2016-02-23 08:10:15 --> Security Class Initialized
DEBUG - 2016-02-23 08:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:10:15 --> Input Class Initialized
INFO - 2016-02-23 08:10:15 --> Language Class Initialized
INFO - 2016-02-23 08:10:15 --> Loader Class Initialized
INFO - 2016-02-23 08:10:15 --> Helper loaded: url_helper
INFO - 2016-02-23 08:10:15 --> Helper loaded: file_helper
INFO - 2016-02-23 08:10:15 --> Helper loaded: date_helper
INFO - 2016-02-23 08:10:15 --> Helper loaded: form_helper
INFO - 2016-02-23 08:10:15 --> Database Driver Class Initialized
INFO - 2016-02-23 08:10:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:10:16 --> Controller Class Initialized
INFO - 2016-02-23 08:10:16 --> Model Class Initialized
INFO - 2016-02-23 08:10:16 --> Model Class Initialized
INFO - 2016-02-23 08:10:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:10:16 --> Pagination Class Initialized
INFO - 2016-02-23 08:10:16 --> Helper loaded: text_helper
INFO - 2016-02-23 08:10:16 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:10:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:10:16 --> Final output sent to browser
DEBUG - 2016-02-23 11:10:16 --> Total execution time: 1.2236
INFO - 2016-02-23 08:11:01 --> Config Class Initialized
INFO - 2016-02-23 08:11:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:11:01 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:11:01 --> Utf8 Class Initialized
INFO - 2016-02-23 08:11:01 --> URI Class Initialized
DEBUG - 2016-02-23 08:11:01 --> No URI present. Default controller set.
INFO - 2016-02-23 08:11:01 --> Router Class Initialized
INFO - 2016-02-23 08:11:01 --> Output Class Initialized
INFO - 2016-02-23 08:11:01 --> Security Class Initialized
DEBUG - 2016-02-23 08:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:11:01 --> Input Class Initialized
INFO - 2016-02-23 08:11:01 --> Language Class Initialized
INFO - 2016-02-23 08:11:01 --> Loader Class Initialized
INFO - 2016-02-23 08:11:01 --> Helper loaded: url_helper
INFO - 2016-02-23 08:11:01 --> Helper loaded: file_helper
INFO - 2016-02-23 08:11:01 --> Helper loaded: date_helper
INFO - 2016-02-23 08:11:01 --> Helper loaded: form_helper
INFO - 2016-02-23 08:11:01 --> Database Driver Class Initialized
INFO - 2016-02-23 08:11:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:11:02 --> Controller Class Initialized
INFO - 2016-02-23 08:11:02 --> Model Class Initialized
INFO - 2016-02-23 08:11:02 --> Model Class Initialized
INFO - 2016-02-23 08:11:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:11:02 --> Pagination Class Initialized
INFO - 2016-02-23 08:11:02 --> Helper loaded: text_helper
INFO - 2016-02-23 08:11:02 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:11:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:11:02 --> Final output sent to browser
DEBUG - 2016-02-23 11:11:02 --> Total execution time: 1.1342
INFO - 2016-02-23 08:33:33 --> Config Class Initialized
INFO - 2016-02-23 08:33:33 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:33:33 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:33:33 --> Utf8 Class Initialized
INFO - 2016-02-23 08:33:33 --> URI Class Initialized
DEBUG - 2016-02-23 08:33:33 --> No URI present. Default controller set.
INFO - 2016-02-23 08:33:33 --> Router Class Initialized
INFO - 2016-02-23 08:33:33 --> Output Class Initialized
INFO - 2016-02-23 08:33:33 --> Security Class Initialized
DEBUG - 2016-02-23 08:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:33:33 --> Input Class Initialized
INFO - 2016-02-23 08:33:33 --> Language Class Initialized
INFO - 2016-02-23 08:33:33 --> Loader Class Initialized
INFO - 2016-02-23 08:33:33 --> Helper loaded: url_helper
INFO - 2016-02-23 08:33:33 --> Helper loaded: file_helper
INFO - 2016-02-23 08:33:33 --> Helper loaded: date_helper
INFO - 2016-02-23 08:33:33 --> Helper loaded: form_helper
INFO - 2016-02-23 08:33:33 --> Database Driver Class Initialized
INFO - 2016-02-23 08:33:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:33:34 --> Controller Class Initialized
INFO - 2016-02-23 08:33:34 --> Model Class Initialized
INFO - 2016-02-23 08:33:34 --> Model Class Initialized
INFO - 2016-02-23 08:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:33:34 --> Pagination Class Initialized
INFO - 2016-02-23 08:33:34 --> Helper loaded: text_helper
INFO - 2016-02-23 08:33:34 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:33:34 --> Final output sent to browser
DEBUG - 2016-02-23 11:33:34 --> Total execution time: 1.1503
INFO - 2016-02-23 08:33:52 --> Config Class Initialized
INFO - 2016-02-23 08:33:52 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:33:52 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:33:52 --> Utf8 Class Initialized
INFO - 2016-02-23 08:33:52 --> URI Class Initialized
INFO - 2016-02-23 08:33:52 --> Router Class Initialized
INFO - 2016-02-23 08:33:52 --> Output Class Initialized
INFO - 2016-02-23 08:33:52 --> Security Class Initialized
DEBUG - 2016-02-23 08:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:33:52 --> Input Class Initialized
INFO - 2016-02-23 08:33:52 --> Language Class Initialized
INFO - 2016-02-23 08:33:52 --> Loader Class Initialized
INFO - 2016-02-23 08:33:52 --> Helper loaded: url_helper
INFO - 2016-02-23 08:33:52 --> Helper loaded: file_helper
INFO - 2016-02-23 08:33:52 --> Helper loaded: date_helper
INFO - 2016-02-23 08:33:52 --> Helper loaded: form_helper
INFO - 2016-02-23 08:33:52 --> Database Driver Class Initialized
INFO - 2016-02-23 08:33:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:33:53 --> Controller Class Initialized
INFO - 2016-02-23 08:33:53 --> Model Class Initialized
INFO - 2016-02-23 08:33:53 --> Model Class Initialized
INFO - 2016-02-23 08:33:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:33:53 --> Pagination Class Initialized
INFO - 2016-02-23 08:33:53 --> Helper loaded: text_helper
INFO - 2016-02-23 08:33:53 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 11:33:53 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-23 11:33:53 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-23 11:33:53 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-23 11:33:53 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-23 11:33:53 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-23 11:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:33:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:33:53 --> Final output sent to browser
DEBUG - 2016-02-23 11:33:53 --> Total execution time: 1.1975
INFO - 2016-02-23 08:34:01 --> Config Class Initialized
INFO - 2016-02-23 08:34:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:34:01 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:34:01 --> Utf8 Class Initialized
INFO - 2016-02-23 08:34:01 --> URI Class Initialized
INFO - 2016-02-23 08:34:01 --> Router Class Initialized
INFO - 2016-02-23 08:34:01 --> Output Class Initialized
INFO - 2016-02-23 08:34:01 --> Security Class Initialized
DEBUG - 2016-02-23 08:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:34:01 --> Input Class Initialized
INFO - 2016-02-23 08:34:01 --> Language Class Initialized
INFO - 2016-02-23 08:34:01 --> Loader Class Initialized
INFO - 2016-02-23 08:34:01 --> Helper loaded: url_helper
INFO - 2016-02-23 08:34:01 --> Helper loaded: file_helper
INFO - 2016-02-23 08:34:01 --> Helper loaded: date_helper
INFO - 2016-02-23 08:34:01 --> Helper loaded: form_helper
INFO - 2016-02-23 08:34:01 --> Database Driver Class Initialized
INFO - 2016-02-23 08:34:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:34:02 --> Controller Class Initialized
INFO - 2016-02-23 08:34:02 --> Model Class Initialized
INFO - 2016-02-23 08:34:02 --> Model Class Initialized
INFO - 2016-02-23 08:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:34:02 --> Pagination Class Initialized
INFO - 2016-02-23 08:34:02 --> Helper loaded: text_helper
INFO - 2016-02-23 08:34:02 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:34:02 --> Final output sent to browser
DEBUG - 2016-02-23 11:34:02 --> Total execution time: 1.1705
INFO - 2016-02-23 08:34:05 --> Config Class Initialized
INFO - 2016-02-23 08:34:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:34:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:34:05 --> Utf8 Class Initialized
INFO - 2016-02-23 08:34:05 --> URI Class Initialized
INFO - 2016-02-23 08:34:05 --> Router Class Initialized
INFO - 2016-02-23 08:34:05 --> Output Class Initialized
INFO - 2016-02-23 08:34:05 --> Security Class Initialized
DEBUG - 2016-02-23 08:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:34:05 --> Input Class Initialized
INFO - 2016-02-23 08:34:05 --> Language Class Initialized
INFO - 2016-02-23 08:34:05 --> Loader Class Initialized
INFO - 2016-02-23 08:34:05 --> Helper loaded: url_helper
INFO - 2016-02-23 08:34:05 --> Helper loaded: file_helper
INFO - 2016-02-23 08:34:05 --> Helper loaded: date_helper
INFO - 2016-02-23 08:34:05 --> Helper loaded: form_helper
INFO - 2016-02-23 08:34:05 --> Database Driver Class Initialized
INFO - 2016-02-23 08:34:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:34:06 --> Controller Class Initialized
INFO - 2016-02-23 08:34:06 --> Model Class Initialized
INFO - 2016-02-23 08:34:06 --> Model Class Initialized
INFO - 2016-02-23 08:34:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:34:06 --> Pagination Class Initialized
INFO - 2016-02-23 08:34:06 --> Helper loaded: text_helper
INFO - 2016-02-23 08:34:06 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 11:34:06 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-23 11:34:06 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-23 11:34:06 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-23 11:34:06 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
ERROR - 2016-02-23 11:34:06 --> Severity: Notice --> Undefined variable: today C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 20
INFO - 2016-02-23 11:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:34:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:34:06 --> Final output sent to browser
DEBUG - 2016-02-23 11:34:06 --> Total execution time: 1.1610
INFO - 2016-02-23 08:35:22 --> Config Class Initialized
INFO - 2016-02-23 08:35:22 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:35:22 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:35:22 --> Utf8 Class Initialized
INFO - 2016-02-23 08:35:22 --> URI Class Initialized
INFO - 2016-02-23 08:35:22 --> Router Class Initialized
INFO - 2016-02-23 08:35:22 --> Output Class Initialized
INFO - 2016-02-23 08:35:22 --> Security Class Initialized
DEBUG - 2016-02-23 08:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:35:22 --> Input Class Initialized
INFO - 2016-02-23 08:35:22 --> Language Class Initialized
INFO - 2016-02-23 08:35:22 --> Loader Class Initialized
INFO - 2016-02-23 08:35:22 --> Helper loaded: url_helper
INFO - 2016-02-23 08:35:22 --> Helper loaded: file_helper
INFO - 2016-02-23 08:35:22 --> Helper loaded: date_helper
INFO - 2016-02-23 08:35:22 --> Helper loaded: form_helper
INFO - 2016-02-23 08:35:22 --> Database Driver Class Initialized
INFO - 2016-02-23 08:35:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:35:23 --> Controller Class Initialized
INFO - 2016-02-23 08:35:23 --> Model Class Initialized
INFO - 2016-02-23 08:35:23 --> Model Class Initialized
INFO - 2016-02-23 08:35:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:35:23 --> Pagination Class Initialized
INFO - 2016-02-23 08:35:23 --> Helper loaded: text_helper
INFO - 2016-02-23 08:35:23 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:35:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:35:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:35:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:35:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:35:23 --> Final output sent to browser
DEBUG - 2016-02-23 11:35:23 --> Total execution time: 1.1172
INFO - 2016-02-23 08:35:49 --> Config Class Initialized
INFO - 2016-02-23 08:35:49 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:35:49 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:35:49 --> Utf8 Class Initialized
INFO - 2016-02-23 08:35:49 --> URI Class Initialized
INFO - 2016-02-23 08:35:49 --> Router Class Initialized
INFO - 2016-02-23 08:35:49 --> Output Class Initialized
INFO - 2016-02-23 08:35:49 --> Security Class Initialized
DEBUG - 2016-02-23 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:35:49 --> Input Class Initialized
INFO - 2016-02-23 08:35:49 --> Language Class Initialized
INFO - 2016-02-23 08:35:49 --> Loader Class Initialized
INFO - 2016-02-23 08:35:49 --> Helper loaded: url_helper
INFO - 2016-02-23 08:35:49 --> Helper loaded: file_helper
INFO - 2016-02-23 08:35:49 --> Helper loaded: date_helper
INFO - 2016-02-23 08:35:49 --> Helper loaded: form_helper
INFO - 2016-02-23 08:35:49 --> Database Driver Class Initialized
INFO - 2016-02-23 08:35:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:35:50 --> Controller Class Initialized
INFO - 2016-02-23 08:35:50 --> Model Class Initialized
INFO - 2016-02-23 08:35:50 --> Model Class Initialized
INFO - 2016-02-23 08:35:50 --> Form Validation Class Initialized
INFO - 2016-02-23 08:35:50 --> Helper loaded: text_helper
INFO - 2016-02-23 08:35:50 --> Config Class Initialized
INFO - 2016-02-23 08:35:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:35:50 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:35:50 --> Utf8 Class Initialized
INFO - 2016-02-23 08:35:50 --> URI Class Initialized
INFO - 2016-02-23 08:35:50 --> Router Class Initialized
INFO - 2016-02-23 08:35:50 --> Output Class Initialized
INFO - 2016-02-23 08:35:50 --> Security Class Initialized
DEBUG - 2016-02-23 08:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:35:50 --> Input Class Initialized
INFO - 2016-02-23 08:35:50 --> Language Class Initialized
INFO - 2016-02-23 08:35:50 --> Loader Class Initialized
INFO - 2016-02-23 08:35:50 --> Helper loaded: url_helper
INFO - 2016-02-23 08:35:50 --> Helper loaded: file_helper
INFO - 2016-02-23 08:35:50 --> Helper loaded: date_helper
INFO - 2016-02-23 08:35:50 --> Helper loaded: form_helper
INFO - 2016-02-23 08:35:50 --> Database Driver Class Initialized
INFO - 2016-02-23 08:35:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:35:51 --> Controller Class Initialized
INFO - 2016-02-23 08:35:51 --> Model Class Initialized
INFO - 2016-02-23 08:35:51 --> Model Class Initialized
INFO - 2016-02-23 08:35:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:35:51 --> Pagination Class Initialized
INFO - 2016-02-23 08:35:51 --> Helper loaded: text_helper
INFO - 2016-02-23 08:35:51 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:35:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:35:51 --> Final output sent to browser
DEBUG - 2016-02-23 11:35:51 --> Total execution time: 1.1753
INFO - 2016-02-23 08:35:53 --> Config Class Initialized
INFO - 2016-02-23 08:35:53 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:35:53 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:35:53 --> Utf8 Class Initialized
INFO - 2016-02-23 08:35:53 --> URI Class Initialized
INFO - 2016-02-23 08:35:53 --> Router Class Initialized
INFO - 2016-02-23 08:35:53 --> Output Class Initialized
INFO - 2016-02-23 08:35:53 --> Security Class Initialized
DEBUG - 2016-02-23 08:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:35:53 --> Input Class Initialized
INFO - 2016-02-23 08:35:53 --> Language Class Initialized
INFO - 2016-02-23 08:35:53 --> Loader Class Initialized
INFO - 2016-02-23 08:35:53 --> Helper loaded: url_helper
INFO - 2016-02-23 08:35:53 --> Helper loaded: file_helper
INFO - 2016-02-23 08:35:53 --> Helper loaded: date_helper
INFO - 2016-02-23 08:35:53 --> Helper loaded: form_helper
INFO - 2016-02-23 08:35:53 --> Database Driver Class Initialized
INFO - 2016-02-23 08:35:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:35:54 --> Controller Class Initialized
INFO - 2016-02-23 08:35:54 --> Model Class Initialized
INFO - 2016-02-23 08:35:54 --> Model Class Initialized
INFO - 2016-02-23 08:35:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:35:54 --> Pagination Class Initialized
INFO - 2016-02-23 08:35:54 --> Helper loaded: text_helper
INFO - 2016-02-23 08:35:54 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 11:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:35:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:35:54 --> Final output sent to browser
DEBUG - 2016-02-23 11:35:54 --> Total execution time: 1.1269
INFO - 2016-02-23 08:37:12 --> Config Class Initialized
INFO - 2016-02-23 08:37:12 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:37:12 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:37:12 --> Utf8 Class Initialized
INFO - 2016-02-23 08:37:12 --> URI Class Initialized
INFO - 2016-02-23 08:37:12 --> Router Class Initialized
INFO - 2016-02-23 08:37:12 --> Output Class Initialized
INFO - 2016-02-23 08:37:12 --> Security Class Initialized
DEBUG - 2016-02-23 08:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:37:12 --> Input Class Initialized
INFO - 2016-02-23 08:37:12 --> Language Class Initialized
INFO - 2016-02-23 08:37:12 --> Loader Class Initialized
INFO - 2016-02-23 08:37:12 --> Helper loaded: url_helper
INFO - 2016-02-23 08:37:12 --> Helper loaded: file_helper
INFO - 2016-02-23 08:37:12 --> Helper loaded: date_helper
INFO - 2016-02-23 08:37:12 --> Helper loaded: form_helper
INFO - 2016-02-23 08:37:12 --> Database Driver Class Initialized
INFO - 2016-02-23 08:37:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:37:13 --> Controller Class Initialized
INFO - 2016-02-23 08:37:13 --> Model Class Initialized
INFO - 2016-02-23 08:37:13 --> Model Class Initialized
INFO - 2016-02-23 08:37:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:37:13 --> Pagination Class Initialized
INFO - 2016-02-23 08:37:13 --> Helper loaded: text_helper
INFO - 2016-02-23 08:37:13 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 11:37:13 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 161
INFO - 2016-02-23 11:37:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:37:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:37:14 --> Form Validation Class Initialized
INFO - 2016-02-23 11:37:14 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-02-23 11:37:14 --> Severity: Notice --> Undefined variable: table_name C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 188
ERROR - 2016-02-23 11:37:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '(created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), '\'X-Fi' at line 1 - Invalid query: INSERT INTO  (created, `title`, `user_id`, `user_name`, `description`) VALUES (NOW(), '\'X-Files\' Creator Chris Carter Says Fox Wants More Episodes — It\'s Just a Matter of When', '9', 'oda', '<aside class=\"blog-post-deck\">\r\n<div class=\"blog-post-summary\">&quot;The last negotiations took about five months, so it could be a while before we figure out how to do this.&quot;</div>\r\n</aside>\r\n\r\n<article class=\"blog-post-body js-fitvids-content\">\r\n<p>New and longtime <em>X-Files</em> enthusiasts, however satisfied they might be with Fox&#39;s six-episode revival, are likely wondering what comes next for the famous franchise in the wake of Monday&#39;s open-ended finale.</p>\r\n\r\n<p><em><strong>Spoilers ahead for anyone who&#39;s yet to see the Feb. 22 episode of </strong></em><strong>The X-Files</strong><em><strong>.</strong></em></p>\r\n\r\n<p>An almost direct continuation of the Jan. 24 opener, &quot;My Struggle II&quot; revisited the series&#39; developing mythology and quickly careened toward a bigger cliffhanger than many likely expected. Mulder (David Duchovny) and Scully (Gillian Anderson), who barely shared a frame in the hour-long episode, were tasked with stopping a Syndicate-sponsored pandemic. And it looked like they were going to be successful until a rather conspicuous UFO appeared over a panicked Washington, D.C., engulfing the pair in a bright light before the episode cut to black. It made the opening titles tagline, &quot;This is the end,&quot; that much more confusing.</p>\r\n\r\n<p>Given the lack of closure, network and studio interest in keeping the property alive, and relatively strong ratings, it&#39;s natural to assume that this is not actually the end. Even going into the revival, the best case scenario was that some version of the show live on &mdash; be it more event series with the original stars or a spinoff around junior agents played by Lauren Ambrose and Robbie Amell. The latter, at least, seemed a little more feasible given Anderson and Duchovny&#39;s other obligations. (&quot;Trying to find a time for all of them to pick up and move for a period of time back to Vancouver was just really challenging,&quot; Fox TV Group CEO and chairman Dana Walden told <em>The Hollywood Reporter</em> ahead of the premiere.)</p>\r\n</article>\r\n')
INFO - 2016-02-23 11:37:14 --> Language file loaded: language/english/db_lang.php
INFO - 2016-02-23 08:37:50 --> Config Class Initialized
INFO - 2016-02-23 08:37:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:37:50 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:37:50 --> Utf8 Class Initialized
INFO - 2016-02-23 08:37:50 --> URI Class Initialized
INFO - 2016-02-23 08:37:50 --> Router Class Initialized
INFO - 2016-02-23 08:37:50 --> Output Class Initialized
INFO - 2016-02-23 08:37:50 --> Security Class Initialized
DEBUG - 2016-02-23 08:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:37:50 --> Input Class Initialized
INFO - 2016-02-23 08:37:50 --> Language Class Initialized
INFO - 2016-02-23 08:37:50 --> Loader Class Initialized
INFO - 2016-02-23 08:37:50 --> Helper loaded: url_helper
INFO - 2016-02-23 08:37:50 --> Helper loaded: file_helper
INFO - 2016-02-23 08:37:50 --> Helper loaded: date_helper
INFO - 2016-02-23 08:37:50 --> Helper loaded: form_helper
INFO - 2016-02-23 08:37:50 --> Database Driver Class Initialized
INFO - 2016-02-23 08:37:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:37:51 --> Controller Class Initialized
INFO - 2016-02-23 08:37:51 --> Model Class Initialized
INFO - 2016-02-23 08:37:51 --> Model Class Initialized
INFO - 2016-02-23 08:37:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:37:51 --> Pagination Class Initialized
INFO - 2016-02-23 08:37:51 --> Helper loaded: text_helper
INFO - 2016-02-23 08:37:51 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 11:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:37:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:37:51 --> Final output sent to browser
DEBUG - 2016-02-23 11:37:51 --> Total execution time: 1.1208
INFO - 2016-02-23 08:38:09 --> Config Class Initialized
INFO - 2016-02-23 08:38:09 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:38:09 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:38:09 --> Utf8 Class Initialized
INFO - 2016-02-23 08:38:09 --> URI Class Initialized
INFO - 2016-02-23 08:38:09 --> Router Class Initialized
INFO - 2016-02-23 08:38:09 --> Output Class Initialized
INFO - 2016-02-23 08:38:09 --> Security Class Initialized
DEBUG - 2016-02-23 08:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:38:09 --> Input Class Initialized
INFO - 2016-02-23 08:38:09 --> Language Class Initialized
INFO - 2016-02-23 08:38:09 --> Loader Class Initialized
INFO - 2016-02-23 08:38:09 --> Helper loaded: url_helper
INFO - 2016-02-23 08:38:09 --> Helper loaded: file_helper
INFO - 2016-02-23 08:38:09 --> Helper loaded: date_helper
INFO - 2016-02-23 08:38:09 --> Helper loaded: form_helper
INFO - 2016-02-23 08:38:09 --> Database Driver Class Initialized
INFO - 2016-02-23 08:38:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:38:11 --> Controller Class Initialized
INFO - 2016-02-23 08:38:11 --> Model Class Initialized
INFO - 2016-02-23 08:38:11 --> Model Class Initialized
INFO - 2016-02-23 08:38:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:38:11 --> Pagination Class Initialized
INFO - 2016-02-23 08:38:11 --> Helper loaded: text_helper
INFO - 2016-02-23 08:38:11 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 11:38:11 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 161
INFO - 2016-02-23 11:38:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:38:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:38:11 --> Form Validation Class Initialized
INFO - 2016-02-23 11:38:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-23 08:38:11 --> Config Class Initialized
INFO - 2016-02-23 08:38:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:38:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:38:11 --> Utf8 Class Initialized
INFO - 2016-02-23 08:38:11 --> URI Class Initialized
INFO - 2016-02-23 08:38:11 --> Router Class Initialized
INFO - 2016-02-23 08:38:11 --> Output Class Initialized
INFO - 2016-02-23 08:38:11 --> Security Class Initialized
DEBUG - 2016-02-23 08:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:38:11 --> Input Class Initialized
INFO - 2016-02-23 08:38:11 --> Language Class Initialized
INFO - 2016-02-23 08:38:11 --> Loader Class Initialized
INFO - 2016-02-23 08:38:11 --> Helper loaded: url_helper
INFO - 2016-02-23 08:38:11 --> Helper loaded: file_helper
INFO - 2016-02-23 08:38:11 --> Helper loaded: date_helper
INFO - 2016-02-23 08:38:11 --> Helper loaded: form_helper
INFO - 2016-02-23 08:38:11 --> Database Driver Class Initialized
INFO - 2016-02-23 08:38:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:38:12 --> Controller Class Initialized
INFO - 2016-02-23 08:38:12 --> Model Class Initialized
INFO - 2016-02-23 08:38:12 --> Model Class Initialized
INFO - 2016-02-23 08:38:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:38:12 --> Pagination Class Initialized
INFO - 2016-02-23 08:38:12 --> Helper loaded: text_helper
INFO - 2016-02-23 08:38:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 11:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:38:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:38:12 --> Final output sent to browser
DEBUG - 2016-02-23 11:38:12 --> Total execution time: 1.1522
INFO - 2016-02-23 08:38:18 --> Config Class Initialized
INFO - 2016-02-23 08:38:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:38:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:38:18 --> Utf8 Class Initialized
INFO - 2016-02-23 08:38:18 --> URI Class Initialized
INFO - 2016-02-23 08:38:18 --> Router Class Initialized
INFO - 2016-02-23 08:38:18 --> Output Class Initialized
INFO - 2016-02-23 08:38:18 --> Security Class Initialized
DEBUG - 2016-02-23 08:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:38:18 --> Input Class Initialized
INFO - 2016-02-23 08:38:18 --> Language Class Initialized
INFO - 2016-02-23 08:38:18 --> Loader Class Initialized
INFO - 2016-02-23 08:38:18 --> Helper loaded: url_helper
INFO - 2016-02-23 08:38:18 --> Helper loaded: file_helper
INFO - 2016-02-23 08:38:18 --> Helper loaded: date_helper
INFO - 2016-02-23 08:38:18 --> Helper loaded: form_helper
INFO - 2016-02-23 08:38:18 --> Database Driver Class Initialized
INFO - 2016-02-23 08:38:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:38:19 --> Controller Class Initialized
INFO - 2016-02-23 08:38:19 --> Model Class Initialized
INFO - 2016-02-23 08:38:19 --> Model Class Initialized
INFO - 2016-02-23 08:38:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:38:19 --> Pagination Class Initialized
INFO - 2016-02-23 08:38:19 --> Helper loaded: text_helper
INFO - 2016-02-23 08:38:19 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:38:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:38:19 --> Final output sent to browser
DEBUG - 2016-02-23 11:38:19 --> Total execution time: 1.1179
INFO - 2016-02-23 08:39:49 --> Config Class Initialized
INFO - 2016-02-23 08:39:49 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:39:49 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:39:49 --> Utf8 Class Initialized
INFO - 2016-02-23 08:39:49 --> URI Class Initialized
INFO - 2016-02-23 08:39:49 --> Router Class Initialized
INFO - 2016-02-23 08:39:49 --> Output Class Initialized
INFO - 2016-02-23 08:39:49 --> Security Class Initialized
DEBUG - 2016-02-23 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:39:49 --> Input Class Initialized
INFO - 2016-02-23 08:39:49 --> Language Class Initialized
INFO - 2016-02-23 08:39:49 --> Loader Class Initialized
INFO - 2016-02-23 08:39:49 --> Helper loaded: url_helper
INFO - 2016-02-23 08:39:49 --> Helper loaded: file_helper
INFO - 2016-02-23 08:39:49 --> Helper loaded: date_helper
INFO - 2016-02-23 08:39:49 --> Helper loaded: form_helper
INFO - 2016-02-23 08:39:49 --> Database Driver Class Initialized
INFO - 2016-02-23 08:39:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:39:50 --> Controller Class Initialized
INFO - 2016-02-23 08:39:50 --> Model Class Initialized
INFO - 2016-02-23 08:39:50 --> Model Class Initialized
INFO - 2016-02-23 08:39:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:39:50 --> Pagination Class Initialized
INFO - 2016-02-23 08:39:50 --> Helper loaded: text_helper
INFO - 2016-02-23 08:39:50 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:39:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:39:50 --> Final output sent to browser
DEBUG - 2016-02-23 11:39:50 --> Total execution time: 1.1156
INFO - 2016-02-23 08:42:09 --> Config Class Initialized
INFO - 2016-02-23 08:42:09 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:42:09 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:42:09 --> Utf8 Class Initialized
INFO - 2016-02-23 08:42:09 --> URI Class Initialized
INFO - 2016-02-23 08:42:09 --> Router Class Initialized
INFO - 2016-02-23 08:42:09 --> Output Class Initialized
INFO - 2016-02-23 08:42:09 --> Security Class Initialized
DEBUG - 2016-02-23 08:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:42:09 --> Input Class Initialized
INFO - 2016-02-23 08:42:09 --> Language Class Initialized
INFO - 2016-02-23 08:42:09 --> Loader Class Initialized
INFO - 2016-02-23 08:42:09 --> Helper loaded: url_helper
INFO - 2016-02-23 08:42:09 --> Helper loaded: file_helper
INFO - 2016-02-23 08:42:09 --> Helper loaded: date_helper
INFO - 2016-02-23 08:42:09 --> Helper loaded: form_helper
INFO - 2016-02-23 08:42:09 --> Database Driver Class Initialized
INFO - 2016-02-23 08:42:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:42:10 --> Controller Class Initialized
INFO - 2016-02-23 08:42:10 --> Model Class Initialized
INFO - 2016-02-23 08:42:10 --> Model Class Initialized
INFO - 2016-02-23 08:42:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:42:10 --> Pagination Class Initialized
INFO - 2016-02-23 08:42:10 --> Helper loaded: text_helper
INFO - 2016-02-23 08:42:10 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:42:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:42:10 --> Final output sent to browser
DEBUG - 2016-02-23 11:42:10 --> Total execution time: 1.1083
INFO - 2016-02-23 08:42:19 --> Config Class Initialized
INFO - 2016-02-23 08:42:19 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:42:20 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:42:20 --> Utf8 Class Initialized
INFO - 2016-02-23 08:42:20 --> URI Class Initialized
INFO - 2016-02-23 08:42:20 --> Router Class Initialized
INFO - 2016-02-23 08:42:20 --> Output Class Initialized
INFO - 2016-02-23 08:42:20 --> Security Class Initialized
DEBUG - 2016-02-23 08:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:42:20 --> Input Class Initialized
INFO - 2016-02-23 08:42:20 --> Language Class Initialized
INFO - 2016-02-23 08:42:20 --> Loader Class Initialized
INFO - 2016-02-23 08:42:20 --> Helper loaded: url_helper
INFO - 2016-02-23 08:42:20 --> Helper loaded: file_helper
INFO - 2016-02-23 08:42:20 --> Helper loaded: date_helper
INFO - 2016-02-23 08:42:20 --> Helper loaded: form_helper
INFO - 2016-02-23 08:42:20 --> Database Driver Class Initialized
INFO - 2016-02-23 08:42:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:42:21 --> Controller Class Initialized
INFO - 2016-02-23 08:42:21 --> Model Class Initialized
INFO - 2016-02-23 08:42:21 --> Model Class Initialized
INFO - 2016-02-23 08:42:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:42:21 --> Pagination Class Initialized
INFO - 2016-02-23 08:42:21 --> Helper loaded: text_helper
INFO - 2016-02-23 08:42:21 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:42:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:42:21 --> Final output sent to browser
DEBUG - 2016-02-23 11:42:21 --> Total execution time: 1.1304
INFO - 2016-02-23 08:42:37 --> Config Class Initialized
INFO - 2016-02-23 08:42:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:42:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:42:37 --> Utf8 Class Initialized
INFO - 2016-02-23 08:42:37 --> URI Class Initialized
INFO - 2016-02-23 08:42:37 --> Router Class Initialized
INFO - 2016-02-23 08:42:37 --> Output Class Initialized
INFO - 2016-02-23 08:42:37 --> Security Class Initialized
DEBUG - 2016-02-23 08:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:42:37 --> Input Class Initialized
INFO - 2016-02-23 08:42:37 --> Language Class Initialized
INFO - 2016-02-23 08:42:37 --> Loader Class Initialized
INFO - 2016-02-23 08:42:37 --> Helper loaded: url_helper
INFO - 2016-02-23 08:42:37 --> Helper loaded: file_helper
INFO - 2016-02-23 08:42:37 --> Helper loaded: date_helper
INFO - 2016-02-23 08:42:37 --> Helper loaded: form_helper
INFO - 2016-02-23 08:42:37 --> Database Driver Class Initialized
INFO - 2016-02-23 08:42:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:42:38 --> Controller Class Initialized
INFO - 2016-02-23 08:42:38 --> Model Class Initialized
INFO - 2016-02-23 08:42:38 --> Model Class Initialized
INFO - 2016-02-23 08:42:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:42:38 --> Pagination Class Initialized
INFO - 2016-02-23 08:42:38 --> Helper loaded: text_helper
INFO - 2016-02-23 08:42:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:42:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:42:38 --> Final output sent to browser
DEBUG - 2016-02-23 11:42:38 --> Total execution time: 1.1122
INFO - 2016-02-23 08:42:42 --> Config Class Initialized
INFO - 2016-02-23 08:42:42 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:42:42 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:42:42 --> Utf8 Class Initialized
INFO - 2016-02-23 08:42:42 --> URI Class Initialized
INFO - 2016-02-23 08:42:42 --> Router Class Initialized
INFO - 2016-02-23 08:42:42 --> Output Class Initialized
INFO - 2016-02-23 08:42:42 --> Security Class Initialized
DEBUG - 2016-02-23 08:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:42:42 --> Input Class Initialized
INFO - 2016-02-23 08:42:42 --> Language Class Initialized
INFO - 2016-02-23 08:42:42 --> Loader Class Initialized
INFO - 2016-02-23 08:42:42 --> Helper loaded: url_helper
INFO - 2016-02-23 08:42:42 --> Helper loaded: file_helper
INFO - 2016-02-23 08:42:42 --> Helper loaded: date_helper
INFO - 2016-02-23 08:42:42 --> Helper loaded: form_helper
INFO - 2016-02-23 08:42:42 --> Database Driver Class Initialized
INFO - 2016-02-23 08:42:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:42:43 --> Controller Class Initialized
INFO - 2016-02-23 08:42:43 --> Model Class Initialized
INFO - 2016-02-23 08:42:43 --> Model Class Initialized
INFO - 2016-02-23 08:42:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:42:43 --> Pagination Class Initialized
INFO - 2016-02-23 08:42:43 --> Helper loaded: text_helper
INFO - 2016-02-23 08:42:43 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:42:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:42:43 --> Final output sent to browser
DEBUG - 2016-02-23 11:42:43 --> Total execution time: 1.0952
INFO - 2016-02-23 08:42:45 --> Config Class Initialized
INFO - 2016-02-23 08:42:45 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:42:45 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:42:45 --> Utf8 Class Initialized
INFO - 2016-02-23 08:42:45 --> URI Class Initialized
INFO - 2016-02-23 08:42:45 --> Router Class Initialized
INFO - 2016-02-23 08:42:45 --> Output Class Initialized
INFO - 2016-02-23 08:42:45 --> Security Class Initialized
DEBUG - 2016-02-23 08:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:42:45 --> Input Class Initialized
INFO - 2016-02-23 08:42:45 --> Language Class Initialized
INFO - 2016-02-23 08:42:45 --> Loader Class Initialized
INFO - 2016-02-23 08:42:45 --> Helper loaded: url_helper
INFO - 2016-02-23 08:42:45 --> Helper loaded: file_helper
INFO - 2016-02-23 08:42:45 --> Helper loaded: date_helper
INFO - 2016-02-23 08:42:45 --> Helper loaded: form_helper
INFO - 2016-02-23 08:42:45 --> Database Driver Class Initialized
INFO - 2016-02-23 08:42:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:42:46 --> Controller Class Initialized
INFO - 2016-02-23 08:42:46 --> Model Class Initialized
INFO - 2016-02-23 08:42:46 --> Model Class Initialized
INFO - 2016-02-23 08:42:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:42:46 --> Pagination Class Initialized
INFO - 2016-02-23 08:42:46 --> Helper loaded: text_helper
INFO - 2016-02-23 08:42:46 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:42:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:42:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:42:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:42:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:42:46 --> Final output sent to browser
DEBUG - 2016-02-23 11:42:46 --> Total execution time: 1.1044
INFO - 2016-02-23 08:42:49 --> Config Class Initialized
INFO - 2016-02-23 08:42:49 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:42:49 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:42:49 --> Utf8 Class Initialized
INFO - 2016-02-23 08:42:49 --> URI Class Initialized
INFO - 2016-02-23 08:42:49 --> Router Class Initialized
INFO - 2016-02-23 08:42:49 --> Output Class Initialized
INFO - 2016-02-23 08:42:49 --> Security Class Initialized
DEBUG - 2016-02-23 08:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:42:49 --> Input Class Initialized
INFO - 2016-02-23 08:42:49 --> Language Class Initialized
INFO - 2016-02-23 08:42:49 --> Loader Class Initialized
INFO - 2016-02-23 08:42:49 --> Helper loaded: url_helper
INFO - 2016-02-23 08:42:49 --> Helper loaded: file_helper
INFO - 2016-02-23 08:42:49 --> Helper loaded: date_helper
INFO - 2016-02-23 08:42:49 --> Helper loaded: form_helper
INFO - 2016-02-23 08:42:49 --> Database Driver Class Initialized
INFO - 2016-02-23 08:42:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:42:50 --> Controller Class Initialized
INFO - 2016-02-23 08:42:50 --> Model Class Initialized
INFO - 2016-02-23 08:42:50 --> Model Class Initialized
INFO - 2016-02-23 08:42:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:42:50 --> Pagination Class Initialized
INFO - 2016-02-23 08:42:50 --> Helper loaded: text_helper
INFO - 2016-02-23 08:42:50 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:42:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:42:50 --> Final output sent to browser
DEBUG - 2016-02-23 11:42:50 --> Total execution time: 1.1254
INFO - 2016-02-23 08:42:52 --> Config Class Initialized
INFO - 2016-02-23 08:42:52 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:42:52 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:42:52 --> Utf8 Class Initialized
INFO - 2016-02-23 08:42:52 --> URI Class Initialized
INFO - 2016-02-23 08:42:52 --> Router Class Initialized
INFO - 2016-02-23 08:42:52 --> Output Class Initialized
INFO - 2016-02-23 08:42:52 --> Security Class Initialized
DEBUG - 2016-02-23 08:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:42:52 --> Input Class Initialized
INFO - 2016-02-23 08:42:52 --> Language Class Initialized
INFO - 2016-02-23 08:42:52 --> Loader Class Initialized
INFO - 2016-02-23 08:42:52 --> Helper loaded: url_helper
INFO - 2016-02-23 08:42:52 --> Helper loaded: file_helper
INFO - 2016-02-23 08:42:52 --> Helper loaded: date_helper
INFO - 2016-02-23 08:42:52 --> Helper loaded: form_helper
INFO - 2016-02-23 08:42:52 --> Database Driver Class Initialized
INFO - 2016-02-23 08:42:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:42:53 --> Controller Class Initialized
INFO - 2016-02-23 08:42:53 --> Model Class Initialized
INFO - 2016-02-23 08:42:53 --> Model Class Initialized
INFO - 2016-02-23 08:42:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:42:53 --> Pagination Class Initialized
INFO - 2016-02-23 08:42:53 --> Helper loaded: text_helper
INFO - 2016-02-23 08:42:53 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:42:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:42:53 --> Final output sent to browser
DEBUG - 2016-02-23 11:42:53 --> Total execution time: 1.1533
INFO - 2016-02-23 08:42:55 --> Config Class Initialized
INFO - 2016-02-23 08:42:55 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:42:55 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:42:55 --> Utf8 Class Initialized
INFO - 2016-02-23 08:42:55 --> URI Class Initialized
INFO - 2016-02-23 08:42:55 --> Router Class Initialized
INFO - 2016-02-23 08:42:55 --> Output Class Initialized
INFO - 2016-02-23 08:42:55 --> Security Class Initialized
DEBUG - 2016-02-23 08:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:42:55 --> Input Class Initialized
INFO - 2016-02-23 08:42:55 --> Language Class Initialized
INFO - 2016-02-23 08:42:55 --> Loader Class Initialized
INFO - 2016-02-23 08:42:55 --> Helper loaded: url_helper
INFO - 2016-02-23 08:42:55 --> Helper loaded: file_helper
INFO - 2016-02-23 08:42:55 --> Helper loaded: date_helper
INFO - 2016-02-23 08:42:55 --> Helper loaded: form_helper
INFO - 2016-02-23 08:42:55 --> Database Driver Class Initialized
INFO - 2016-02-23 08:42:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:42:56 --> Controller Class Initialized
INFO - 2016-02-23 08:42:56 --> Model Class Initialized
INFO - 2016-02-23 08:42:56 --> Model Class Initialized
INFO - 2016-02-23 08:42:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:42:56 --> Pagination Class Initialized
INFO - 2016-02-23 08:42:56 --> Helper loaded: text_helper
INFO - 2016-02-23 08:42:56 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:42:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:42:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:42:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:42:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:42:57 --> Final output sent to browser
DEBUG - 2016-02-23 11:42:57 --> Total execution time: 1.1456
INFO - 2016-02-23 08:45:09 --> Config Class Initialized
INFO - 2016-02-23 08:45:09 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:09 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:09 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:09 --> URI Class Initialized
INFO - 2016-02-23 08:45:09 --> Router Class Initialized
INFO - 2016-02-23 08:45:09 --> Output Class Initialized
INFO - 2016-02-23 08:45:09 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:09 --> Input Class Initialized
INFO - 2016-02-23 08:45:09 --> Language Class Initialized
INFO - 2016-02-23 08:45:09 --> Loader Class Initialized
INFO - 2016-02-23 08:45:09 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:09 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:09 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:09 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:09 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:10 --> Controller Class Initialized
INFO - 2016-02-23 08:45:10 --> Model Class Initialized
INFO - 2016-02-23 08:45:10 --> Model Class Initialized
INFO - 2016-02-23 08:45:10 --> Form Validation Class Initialized
INFO - 2016-02-23 08:45:10 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:10 --> Config Class Initialized
INFO - 2016-02-23 08:45:10 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:10 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:10 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:10 --> URI Class Initialized
DEBUG - 2016-02-23 08:45:10 --> No URI present. Default controller set.
INFO - 2016-02-23 08:45:10 --> Router Class Initialized
INFO - 2016-02-23 08:45:10 --> Output Class Initialized
INFO - 2016-02-23 08:45:10 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:10 --> Input Class Initialized
INFO - 2016-02-23 08:45:10 --> Language Class Initialized
INFO - 2016-02-23 08:45:10 --> Loader Class Initialized
INFO - 2016-02-23 08:45:10 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:10 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:10 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:10 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:10 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:11 --> Controller Class Initialized
INFO - 2016-02-23 08:45:11 --> Model Class Initialized
INFO - 2016-02-23 08:45:11 --> Model Class Initialized
INFO - 2016-02-23 08:45:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:45:11 --> Pagination Class Initialized
INFO - 2016-02-23 08:45:11 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:11 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:45:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:45:11 --> Final output sent to browser
DEBUG - 2016-02-23 11:45:11 --> Total execution time: 1.1316
INFO - 2016-02-23 08:45:21 --> Config Class Initialized
INFO - 2016-02-23 08:45:21 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:21 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:21 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:21 --> URI Class Initialized
INFO - 2016-02-23 08:45:21 --> Router Class Initialized
INFO - 2016-02-23 08:45:21 --> Output Class Initialized
INFO - 2016-02-23 08:45:21 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:21 --> Input Class Initialized
INFO - 2016-02-23 08:45:21 --> Language Class Initialized
INFO - 2016-02-23 08:45:21 --> Loader Class Initialized
INFO - 2016-02-23 08:45:21 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:21 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:21 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:21 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:21 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:22 --> Controller Class Initialized
INFO - 2016-02-23 08:45:22 --> Model Class Initialized
INFO - 2016-02-23 08:45:22 --> Model Class Initialized
INFO - 2016-02-23 08:45:22 --> Form Validation Class Initialized
INFO - 2016-02-23 08:45:22 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:22 --> Config Class Initialized
INFO - 2016-02-23 08:45:22 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:22 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:22 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:22 --> URI Class Initialized
DEBUG - 2016-02-23 08:45:22 --> No URI present. Default controller set.
INFO - 2016-02-23 08:45:22 --> Router Class Initialized
INFO - 2016-02-23 08:45:22 --> Output Class Initialized
INFO - 2016-02-23 08:45:22 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:22 --> Input Class Initialized
INFO - 2016-02-23 08:45:22 --> Language Class Initialized
INFO - 2016-02-23 08:45:22 --> Loader Class Initialized
INFO - 2016-02-23 08:45:22 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:22 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:22 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:22 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:22 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:23 --> Controller Class Initialized
INFO - 2016-02-23 08:45:23 --> Model Class Initialized
INFO - 2016-02-23 08:45:23 --> Model Class Initialized
INFO - 2016-02-23 08:45:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:45:23 --> Pagination Class Initialized
INFO - 2016-02-23 08:45:23 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:23 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:45:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:45:23 --> Final output sent to browser
DEBUG - 2016-02-23 11:45:23 --> Total execution time: 1.1114
INFO - 2016-02-23 08:45:25 --> Config Class Initialized
INFO - 2016-02-23 08:45:26 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:26 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:26 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:26 --> URI Class Initialized
INFO - 2016-02-23 08:45:26 --> Router Class Initialized
INFO - 2016-02-23 08:45:26 --> Output Class Initialized
INFO - 2016-02-23 08:45:26 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:26 --> Input Class Initialized
INFO - 2016-02-23 08:45:26 --> Language Class Initialized
INFO - 2016-02-23 08:45:26 --> Loader Class Initialized
INFO - 2016-02-23 08:45:26 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:26 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:26 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:26 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:26 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:27 --> Controller Class Initialized
INFO - 2016-02-23 08:45:27 --> Model Class Initialized
INFO - 2016-02-23 08:45:27 --> Model Class Initialized
INFO - 2016-02-23 08:45:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:45:27 --> Pagination Class Initialized
INFO - 2016-02-23 08:45:27 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:27 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:45:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:45:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:45:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:45:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:45:27 --> Final output sent to browser
DEBUG - 2016-02-23 11:45:27 --> Total execution time: 1.1177
INFO - 2016-02-23 08:45:28 --> Config Class Initialized
INFO - 2016-02-23 08:45:28 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:28 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:28 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:28 --> URI Class Initialized
INFO - 2016-02-23 08:45:28 --> Router Class Initialized
INFO - 2016-02-23 08:45:28 --> Output Class Initialized
INFO - 2016-02-23 08:45:28 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:28 --> Input Class Initialized
INFO - 2016-02-23 08:45:28 --> Language Class Initialized
INFO - 2016-02-23 08:45:28 --> Loader Class Initialized
INFO - 2016-02-23 08:45:28 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:28 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:28 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:28 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:28 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:29 --> Controller Class Initialized
INFO - 2016-02-23 08:45:29 --> Model Class Initialized
INFO - 2016-02-23 08:45:30 --> Model Class Initialized
INFO - 2016-02-23 08:45:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:45:30 --> Pagination Class Initialized
INFO - 2016-02-23 08:45:30 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:30 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:45:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:45:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:45:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 11:45:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:45:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:45:30 --> Final output sent to browser
DEBUG - 2016-02-23 11:45:30 --> Total execution time: 1.1080
INFO - 2016-02-23 08:45:44 --> Config Class Initialized
INFO - 2016-02-23 08:45:44 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:44 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:44 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:44 --> URI Class Initialized
INFO - 2016-02-23 08:45:44 --> Router Class Initialized
INFO - 2016-02-23 08:45:44 --> Output Class Initialized
INFO - 2016-02-23 08:45:44 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:44 --> Input Class Initialized
INFO - 2016-02-23 08:45:44 --> Language Class Initialized
INFO - 2016-02-23 08:45:44 --> Loader Class Initialized
INFO - 2016-02-23 08:45:44 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:44 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:44 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:44 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:44 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:45 --> Controller Class Initialized
INFO - 2016-02-23 08:45:45 --> Model Class Initialized
INFO - 2016-02-23 08:45:45 --> Model Class Initialized
INFO - 2016-02-23 08:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:45:45 --> Pagination Class Initialized
INFO - 2016-02-23 08:45:45 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:45 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 11:45:45 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 161
INFO - 2016-02-23 11:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:45:45 --> Form Validation Class Initialized
INFO - 2016-02-23 11:45:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-23 08:45:45 --> Config Class Initialized
INFO - 2016-02-23 08:45:45 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:45 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:45 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:45 --> URI Class Initialized
INFO - 2016-02-23 08:45:45 --> Router Class Initialized
INFO - 2016-02-23 08:45:45 --> Output Class Initialized
INFO - 2016-02-23 08:45:45 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:45 --> Input Class Initialized
INFO - 2016-02-23 08:45:45 --> Language Class Initialized
INFO - 2016-02-23 08:45:45 --> Loader Class Initialized
INFO - 2016-02-23 08:45:45 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:45 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:45 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:45 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:45 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:46 --> Controller Class Initialized
INFO - 2016-02-23 08:45:46 --> Model Class Initialized
INFO - 2016-02-23 08:45:46 --> Model Class Initialized
INFO - 2016-02-23 08:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:45:46 --> Pagination Class Initialized
INFO - 2016-02-23 08:45:46 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:46 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 11:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:45:46 --> Final output sent to browser
DEBUG - 2016-02-23 11:45:46 --> Total execution time: 1.1827
INFO - 2016-02-23 08:45:56 --> Config Class Initialized
INFO - 2016-02-23 08:45:56 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:45:56 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:45:56 --> Utf8 Class Initialized
INFO - 2016-02-23 08:45:56 --> URI Class Initialized
INFO - 2016-02-23 08:45:56 --> Router Class Initialized
INFO - 2016-02-23 08:45:56 --> Output Class Initialized
INFO - 2016-02-23 08:45:56 --> Security Class Initialized
DEBUG - 2016-02-23 08:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:45:56 --> Input Class Initialized
INFO - 2016-02-23 08:45:56 --> Language Class Initialized
INFO - 2016-02-23 08:45:56 --> Loader Class Initialized
INFO - 2016-02-23 08:45:56 --> Helper loaded: url_helper
INFO - 2016-02-23 08:45:56 --> Helper loaded: file_helper
INFO - 2016-02-23 08:45:56 --> Helper loaded: date_helper
INFO - 2016-02-23 08:45:56 --> Helper loaded: form_helper
INFO - 2016-02-23 08:45:56 --> Database Driver Class Initialized
INFO - 2016-02-23 08:45:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:45:57 --> Controller Class Initialized
INFO - 2016-02-23 08:45:57 --> Model Class Initialized
INFO - 2016-02-23 08:45:57 --> Model Class Initialized
INFO - 2016-02-23 08:45:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:45:57 --> Pagination Class Initialized
INFO - 2016-02-23 08:45:57 --> Helper loaded: text_helper
INFO - 2016-02-23 08:45:57 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:45:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:45:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:45:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:45:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:45:57 --> Final output sent to browser
DEBUG - 2016-02-23 11:45:57 --> Total execution time: 1.1335
INFO - 2016-02-23 08:46:01 --> Config Class Initialized
INFO - 2016-02-23 08:46:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:46:01 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:46:01 --> Utf8 Class Initialized
INFO - 2016-02-23 08:46:01 --> URI Class Initialized
INFO - 2016-02-23 08:46:01 --> Router Class Initialized
INFO - 2016-02-23 08:46:01 --> Output Class Initialized
INFO - 2016-02-23 08:46:01 --> Security Class Initialized
DEBUG - 2016-02-23 08:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:46:01 --> Input Class Initialized
INFO - 2016-02-23 08:46:01 --> Language Class Initialized
INFO - 2016-02-23 08:46:01 --> Loader Class Initialized
INFO - 2016-02-23 08:46:01 --> Helper loaded: url_helper
INFO - 2016-02-23 08:46:01 --> Helper loaded: file_helper
INFO - 2016-02-23 08:46:01 --> Helper loaded: date_helper
INFO - 2016-02-23 08:46:01 --> Helper loaded: form_helper
INFO - 2016-02-23 08:46:01 --> Database Driver Class Initialized
INFO - 2016-02-23 08:46:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:46:02 --> Controller Class Initialized
INFO - 2016-02-23 08:46:02 --> Model Class Initialized
INFO - 2016-02-23 08:46:02 --> Model Class Initialized
INFO - 2016-02-23 08:46:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:46:02 --> Pagination Class Initialized
INFO - 2016-02-23 08:46:02 --> Helper loaded: text_helper
INFO - 2016-02-23 08:46:02 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:46:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:46:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:46:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 11:46:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:46:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:46:02 --> Final output sent to browser
DEBUG - 2016-02-23 11:46:02 --> Total execution time: 1.1615
INFO - 2016-02-23 08:46:10 --> Config Class Initialized
INFO - 2016-02-23 08:46:10 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:46:10 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:46:10 --> Utf8 Class Initialized
INFO - 2016-02-23 08:46:10 --> URI Class Initialized
INFO - 2016-02-23 08:46:10 --> Router Class Initialized
INFO - 2016-02-23 08:46:10 --> Output Class Initialized
INFO - 2016-02-23 08:46:10 --> Security Class Initialized
DEBUG - 2016-02-23 08:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:46:10 --> Input Class Initialized
INFO - 2016-02-23 08:46:10 --> Language Class Initialized
INFO - 2016-02-23 08:46:10 --> Loader Class Initialized
INFO - 2016-02-23 08:46:10 --> Helper loaded: url_helper
INFO - 2016-02-23 08:46:10 --> Helper loaded: file_helper
INFO - 2016-02-23 08:46:10 --> Helper loaded: date_helper
INFO - 2016-02-23 08:46:10 --> Helper loaded: form_helper
INFO - 2016-02-23 08:46:10 --> Database Driver Class Initialized
INFO - 2016-02-23 08:46:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:46:11 --> Controller Class Initialized
INFO - 2016-02-23 08:46:11 --> Model Class Initialized
INFO - 2016-02-23 08:46:11 --> Model Class Initialized
INFO - 2016-02-23 08:46:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:46:11 --> Pagination Class Initialized
INFO - 2016-02-23 08:46:11 --> Helper loaded: text_helper
INFO - 2016-02-23 08:46:11 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:46:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:46:11 --> Final output sent to browser
DEBUG - 2016-02-23 11:46:11 --> Total execution time: 1.1121
INFO - 2016-02-23 08:46:34 --> Config Class Initialized
INFO - 2016-02-23 08:46:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:46:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:46:34 --> Utf8 Class Initialized
INFO - 2016-02-23 08:46:34 --> URI Class Initialized
INFO - 2016-02-23 08:46:34 --> Router Class Initialized
INFO - 2016-02-23 08:46:34 --> Output Class Initialized
INFO - 2016-02-23 08:46:34 --> Security Class Initialized
DEBUG - 2016-02-23 08:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:46:34 --> Input Class Initialized
INFO - 2016-02-23 08:46:34 --> Language Class Initialized
INFO - 2016-02-23 08:46:34 --> Loader Class Initialized
INFO - 2016-02-23 08:46:34 --> Helper loaded: url_helper
INFO - 2016-02-23 08:46:34 --> Helper loaded: file_helper
INFO - 2016-02-23 08:46:34 --> Helper loaded: date_helper
INFO - 2016-02-23 08:46:34 --> Helper loaded: form_helper
INFO - 2016-02-23 08:46:34 --> Database Driver Class Initialized
INFO - 2016-02-23 08:46:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:46:35 --> Controller Class Initialized
INFO - 2016-02-23 08:46:35 --> Model Class Initialized
INFO - 2016-02-23 08:46:35 --> Model Class Initialized
INFO - 2016-02-23 08:46:35 --> Form Validation Class Initialized
INFO - 2016-02-23 08:46:35 --> Helper loaded: text_helper
INFO - 2016-02-23 08:46:35 --> Config Class Initialized
INFO - 2016-02-23 08:46:35 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:46:35 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:46:35 --> Utf8 Class Initialized
INFO - 2016-02-23 08:46:35 --> URI Class Initialized
DEBUG - 2016-02-23 08:46:35 --> No URI present. Default controller set.
INFO - 2016-02-23 08:46:35 --> Router Class Initialized
INFO - 2016-02-23 08:46:35 --> Output Class Initialized
INFO - 2016-02-23 08:46:35 --> Security Class Initialized
DEBUG - 2016-02-23 08:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:46:35 --> Input Class Initialized
INFO - 2016-02-23 08:46:35 --> Language Class Initialized
INFO - 2016-02-23 08:46:35 --> Loader Class Initialized
INFO - 2016-02-23 08:46:35 --> Helper loaded: url_helper
INFO - 2016-02-23 08:46:35 --> Helper loaded: file_helper
INFO - 2016-02-23 08:46:35 --> Helper loaded: date_helper
INFO - 2016-02-23 08:46:35 --> Helper loaded: form_helper
INFO - 2016-02-23 08:46:35 --> Database Driver Class Initialized
INFO - 2016-02-23 08:46:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:46:36 --> Controller Class Initialized
INFO - 2016-02-23 08:46:36 --> Model Class Initialized
INFO - 2016-02-23 08:46:36 --> Model Class Initialized
INFO - 2016-02-23 08:46:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:46:36 --> Pagination Class Initialized
INFO - 2016-02-23 08:46:36 --> Helper loaded: text_helper
INFO - 2016-02-23 08:46:36 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:46:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:46:36 --> Final output sent to browser
DEBUG - 2016-02-23 11:46:36 --> Total execution time: 1.1955
INFO - 2016-02-23 08:46:46 --> Config Class Initialized
INFO - 2016-02-23 08:46:46 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:46:46 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:46:46 --> Utf8 Class Initialized
INFO - 2016-02-23 08:46:46 --> URI Class Initialized
INFO - 2016-02-23 08:46:46 --> Router Class Initialized
INFO - 2016-02-23 08:46:46 --> Output Class Initialized
INFO - 2016-02-23 08:46:46 --> Security Class Initialized
DEBUG - 2016-02-23 08:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:46:46 --> Input Class Initialized
INFO - 2016-02-23 08:46:46 --> Language Class Initialized
INFO - 2016-02-23 08:46:46 --> Loader Class Initialized
INFO - 2016-02-23 08:46:46 --> Helper loaded: url_helper
INFO - 2016-02-23 08:46:46 --> Helper loaded: file_helper
INFO - 2016-02-23 08:46:46 --> Helper loaded: date_helper
INFO - 2016-02-23 08:46:46 --> Helper loaded: form_helper
INFO - 2016-02-23 08:46:46 --> Database Driver Class Initialized
INFO - 2016-02-23 08:46:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:46:47 --> Controller Class Initialized
INFO - 2016-02-23 08:46:47 --> Model Class Initialized
INFO - 2016-02-23 08:46:47 --> Model Class Initialized
INFO - 2016-02-23 08:46:47 --> Form Validation Class Initialized
INFO - 2016-02-23 08:46:47 --> Helper loaded: text_helper
INFO - 2016-02-23 08:46:47 --> Config Class Initialized
INFO - 2016-02-23 08:46:47 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:46:47 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:46:47 --> Utf8 Class Initialized
INFO - 2016-02-23 08:46:47 --> URI Class Initialized
DEBUG - 2016-02-23 08:46:47 --> No URI present. Default controller set.
INFO - 2016-02-23 08:46:47 --> Router Class Initialized
INFO - 2016-02-23 08:46:47 --> Output Class Initialized
INFO - 2016-02-23 08:46:47 --> Security Class Initialized
DEBUG - 2016-02-23 08:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:46:47 --> Input Class Initialized
INFO - 2016-02-23 08:46:47 --> Language Class Initialized
INFO - 2016-02-23 08:46:47 --> Loader Class Initialized
INFO - 2016-02-23 08:46:47 --> Helper loaded: url_helper
INFO - 2016-02-23 08:46:47 --> Helper loaded: file_helper
INFO - 2016-02-23 08:46:47 --> Helper loaded: date_helper
INFO - 2016-02-23 08:46:47 --> Helper loaded: form_helper
INFO - 2016-02-23 08:46:47 --> Database Driver Class Initialized
INFO - 2016-02-23 08:46:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:46:48 --> Controller Class Initialized
INFO - 2016-02-23 08:46:48 --> Model Class Initialized
INFO - 2016-02-23 08:46:48 --> Model Class Initialized
INFO - 2016-02-23 08:46:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:46:48 --> Pagination Class Initialized
INFO - 2016-02-23 08:46:48 --> Helper loaded: text_helper
INFO - 2016-02-23 08:46:48 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:46:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:46:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:46:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:46:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:46:48 --> Final output sent to browser
DEBUG - 2016-02-23 11:46:48 --> Total execution time: 1.1321
INFO - 2016-02-23 08:46:51 --> Config Class Initialized
INFO - 2016-02-23 08:46:51 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:46:51 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:46:51 --> Utf8 Class Initialized
INFO - 2016-02-23 08:46:51 --> URI Class Initialized
INFO - 2016-02-23 08:46:51 --> Router Class Initialized
INFO - 2016-02-23 08:46:51 --> Output Class Initialized
INFO - 2016-02-23 08:46:51 --> Security Class Initialized
DEBUG - 2016-02-23 08:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:46:51 --> Input Class Initialized
INFO - 2016-02-23 08:46:51 --> Language Class Initialized
INFO - 2016-02-23 08:46:51 --> Loader Class Initialized
INFO - 2016-02-23 08:46:51 --> Helper loaded: url_helper
INFO - 2016-02-23 08:46:51 --> Helper loaded: file_helper
INFO - 2016-02-23 08:46:51 --> Helper loaded: date_helper
INFO - 2016-02-23 08:46:51 --> Helper loaded: form_helper
INFO - 2016-02-23 08:46:51 --> Database Driver Class Initialized
INFO - 2016-02-23 08:46:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:46:52 --> Controller Class Initialized
INFO - 2016-02-23 08:46:52 --> Model Class Initialized
INFO - 2016-02-23 08:46:52 --> Model Class Initialized
INFO - 2016-02-23 08:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:46:52 --> Pagination Class Initialized
INFO - 2016-02-23 08:46:52 --> Helper loaded: text_helper
INFO - 2016-02-23 08:46:52 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:46:52 --> Final output sent to browser
DEBUG - 2016-02-23 11:46:52 --> Total execution time: 1.1188
INFO - 2016-02-23 08:46:54 --> Config Class Initialized
INFO - 2016-02-23 08:46:54 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:46:54 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:46:54 --> Utf8 Class Initialized
INFO - 2016-02-23 08:46:54 --> URI Class Initialized
INFO - 2016-02-23 08:46:54 --> Router Class Initialized
INFO - 2016-02-23 08:46:54 --> Output Class Initialized
INFO - 2016-02-23 08:46:54 --> Security Class Initialized
DEBUG - 2016-02-23 08:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:46:54 --> Input Class Initialized
INFO - 2016-02-23 08:46:54 --> Language Class Initialized
INFO - 2016-02-23 08:46:54 --> Loader Class Initialized
INFO - 2016-02-23 08:46:54 --> Helper loaded: url_helper
INFO - 2016-02-23 08:46:54 --> Helper loaded: file_helper
INFO - 2016-02-23 08:46:54 --> Helper loaded: date_helper
INFO - 2016-02-23 08:46:54 --> Helper loaded: form_helper
INFO - 2016-02-23 08:46:54 --> Database Driver Class Initialized
INFO - 2016-02-23 08:46:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:46:55 --> Controller Class Initialized
INFO - 2016-02-23 08:46:55 --> Model Class Initialized
INFO - 2016-02-23 08:46:55 --> Model Class Initialized
INFO - 2016-02-23 08:46:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:46:55 --> Pagination Class Initialized
INFO - 2016-02-23 08:46:55 --> Helper loaded: text_helper
INFO - 2016-02-23 08:46:55 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 11:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:46:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:46:55 --> Final output sent to browser
DEBUG - 2016-02-23 11:46:55 --> Total execution time: 1.1146
INFO - 2016-02-23 08:48:44 --> Config Class Initialized
INFO - 2016-02-23 08:48:44 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:48:44 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:48:44 --> Utf8 Class Initialized
INFO - 2016-02-23 08:48:44 --> URI Class Initialized
INFO - 2016-02-23 08:48:44 --> Router Class Initialized
INFO - 2016-02-23 08:48:44 --> Output Class Initialized
INFO - 2016-02-23 08:48:44 --> Security Class Initialized
DEBUG - 2016-02-23 08:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:48:44 --> Input Class Initialized
INFO - 2016-02-23 08:48:44 --> Language Class Initialized
INFO - 2016-02-23 08:48:44 --> Loader Class Initialized
INFO - 2016-02-23 08:48:44 --> Helper loaded: url_helper
INFO - 2016-02-23 08:48:44 --> Helper loaded: file_helper
INFO - 2016-02-23 08:48:44 --> Helper loaded: date_helper
INFO - 2016-02-23 08:48:44 --> Helper loaded: form_helper
INFO - 2016-02-23 08:48:44 --> Database Driver Class Initialized
INFO - 2016-02-23 08:48:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:48:45 --> Controller Class Initialized
INFO - 2016-02-23 08:48:45 --> Model Class Initialized
INFO - 2016-02-23 08:48:45 --> Model Class Initialized
INFO - 2016-02-23 08:48:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:48:45 --> Pagination Class Initialized
INFO - 2016-02-23 08:48:45 --> Helper loaded: text_helper
INFO - 2016-02-23 08:48:45 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 11:48:45 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 161
INFO - 2016-02-23 11:48:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:48:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:48:45 --> Form Validation Class Initialized
INFO - 2016-02-23 11:48:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-23 08:48:45 --> Config Class Initialized
INFO - 2016-02-23 08:48:45 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:48:45 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:48:45 --> Utf8 Class Initialized
INFO - 2016-02-23 08:48:45 --> URI Class Initialized
INFO - 2016-02-23 08:48:45 --> Router Class Initialized
INFO - 2016-02-23 08:48:45 --> Output Class Initialized
INFO - 2016-02-23 08:48:45 --> Security Class Initialized
DEBUG - 2016-02-23 08:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:48:45 --> Input Class Initialized
INFO - 2016-02-23 08:48:45 --> Language Class Initialized
INFO - 2016-02-23 08:48:45 --> Loader Class Initialized
INFO - 2016-02-23 08:48:45 --> Helper loaded: url_helper
INFO - 2016-02-23 08:48:45 --> Helper loaded: file_helper
INFO - 2016-02-23 08:48:45 --> Helper loaded: date_helper
INFO - 2016-02-23 08:48:45 --> Helper loaded: form_helper
INFO - 2016-02-23 08:48:45 --> Database Driver Class Initialized
INFO - 2016-02-23 08:48:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:48:46 --> Controller Class Initialized
INFO - 2016-02-23 08:48:46 --> Model Class Initialized
INFO - 2016-02-23 08:48:46 --> Model Class Initialized
INFO - 2016-02-23 08:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:48:46 --> Pagination Class Initialized
INFO - 2016-02-23 08:48:46 --> Helper loaded: text_helper
INFO - 2016-02-23 08:48:46 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 11:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:48:46 --> Final output sent to browser
DEBUG - 2016-02-23 11:48:46 --> Total execution time: 1.2483
INFO - 2016-02-23 08:48:54 --> Config Class Initialized
INFO - 2016-02-23 08:48:54 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:48:54 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:48:54 --> Utf8 Class Initialized
INFO - 2016-02-23 08:48:54 --> URI Class Initialized
INFO - 2016-02-23 08:48:54 --> Router Class Initialized
INFO - 2016-02-23 08:48:54 --> Output Class Initialized
INFO - 2016-02-23 08:48:54 --> Security Class Initialized
DEBUG - 2016-02-23 08:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:48:54 --> Input Class Initialized
INFO - 2016-02-23 08:48:54 --> Language Class Initialized
INFO - 2016-02-23 08:48:54 --> Loader Class Initialized
INFO - 2016-02-23 08:48:54 --> Helper loaded: url_helper
INFO - 2016-02-23 08:48:54 --> Helper loaded: file_helper
INFO - 2016-02-23 08:48:54 --> Helper loaded: date_helper
INFO - 2016-02-23 08:48:54 --> Helper loaded: form_helper
INFO - 2016-02-23 08:48:54 --> Database Driver Class Initialized
INFO - 2016-02-23 08:48:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:48:55 --> Controller Class Initialized
INFO - 2016-02-23 08:48:55 --> Model Class Initialized
INFO - 2016-02-23 08:48:55 --> Model Class Initialized
INFO - 2016-02-23 08:48:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:48:55 --> Pagination Class Initialized
INFO - 2016-02-23 08:48:55 --> Helper loaded: text_helper
INFO - 2016-02-23 08:48:55 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:48:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:48:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:48:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 11:48:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:48:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:48:55 --> Final output sent to browser
DEBUG - 2016-02-23 11:48:55 --> Total execution time: 1.1404
INFO - 2016-02-23 08:49:06 --> Config Class Initialized
INFO - 2016-02-23 08:49:06 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:49:06 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:49:06 --> Utf8 Class Initialized
INFO - 2016-02-23 08:49:06 --> URI Class Initialized
INFO - 2016-02-23 08:49:06 --> Router Class Initialized
INFO - 2016-02-23 08:49:06 --> Output Class Initialized
INFO - 2016-02-23 08:49:06 --> Security Class Initialized
DEBUG - 2016-02-23 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:49:06 --> Input Class Initialized
INFO - 2016-02-23 08:49:06 --> Language Class Initialized
INFO - 2016-02-23 08:49:06 --> Loader Class Initialized
INFO - 2016-02-23 08:49:06 --> Helper loaded: url_helper
INFO - 2016-02-23 08:49:06 --> Helper loaded: file_helper
INFO - 2016-02-23 08:49:06 --> Helper loaded: date_helper
INFO - 2016-02-23 08:49:06 --> Helper loaded: form_helper
INFO - 2016-02-23 08:49:06 --> Database Driver Class Initialized
INFO - 2016-02-23 08:49:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:49:07 --> Controller Class Initialized
INFO - 2016-02-23 08:49:07 --> Model Class Initialized
INFO - 2016-02-23 08:49:07 --> Model Class Initialized
INFO - 2016-02-23 08:49:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:49:07 --> Pagination Class Initialized
INFO - 2016-02-23 08:49:07 --> Helper loaded: text_helper
INFO - 2016-02-23 08:49:07 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:49:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:49:07 --> Final output sent to browser
DEBUG - 2016-02-23 11:49:07 --> Total execution time: 1.0954
INFO - 2016-02-23 08:49:14 --> Config Class Initialized
INFO - 2016-02-23 08:49:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:49:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:49:14 --> Utf8 Class Initialized
INFO - 2016-02-23 08:49:14 --> URI Class Initialized
INFO - 2016-02-23 08:49:14 --> Router Class Initialized
INFO - 2016-02-23 08:49:14 --> Output Class Initialized
INFO - 2016-02-23 08:49:14 --> Security Class Initialized
DEBUG - 2016-02-23 08:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:49:14 --> Input Class Initialized
INFO - 2016-02-23 08:49:14 --> Language Class Initialized
INFO - 2016-02-23 08:49:14 --> Loader Class Initialized
INFO - 2016-02-23 08:49:14 --> Helper loaded: url_helper
INFO - 2016-02-23 08:49:14 --> Helper loaded: file_helper
INFO - 2016-02-23 08:49:14 --> Helper loaded: date_helper
INFO - 2016-02-23 08:49:14 --> Helper loaded: form_helper
INFO - 2016-02-23 08:49:14 --> Database Driver Class Initialized
INFO - 2016-02-23 08:49:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:49:15 --> Controller Class Initialized
INFO - 2016-02-23 08:49:15 --> Model Class Initialized
INFO - 2016-02-23 08:49:15 --> Model Class Initialized
INFO - 2016-02-23 08:49:15 --> Form Validation Class Initialized
INFO - 2016-02-23 08:49:15 --> Helper loaded: text_helper
INFO - 2016-02-23 08:49:15 --> Config Class Initialized
INFO - 2016-02-23 08:49:15 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:49:15 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:49:15 --> Utf8 Class Initialized
INFO - 2016-02-23 08:49:15 --> URI Class Initialized
DEBUG - 2016-02-23 08:49:15 --> No URI present. Default controller set.
INFO - 2016-02-23 08:49:15 --> Router Class Initialized
INFO - 2016-02-23 08:49:15 --> Output Class Initialized
INFO - 2016-02-23 08:49:15 --> Security Class Initialized
DEBUG - 2016-02-23 08:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:49:15 --> Input Class Initialized
INFO - 2016-02-23 08:49:15 --> Language Class Initialized
INFO - 2016-02-23 08:49:15 --> Loader Class Initialized
INFO - 2016-02-23 08:49:15 --> Helper loaded: url_helper
INFO - 2016-02-23 08:49:15 --> Helper loaded: file_helper
INFO - 2016-02-23 08:49:15 --> Helper loaded: date_helper
INFO - 2016-02-23 08:49:15 --> Helper loaded: form_helper
INFO - 2016-02-23 08:49:15 --> Database Driver Class Initialized
INFO - 2016-02-23 08:49:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:49:16 --> Controller Class Initialized
INFO - 2016-02-23 08:49:16 --> Model Class Initialized
INFO - 2016-02-23 08:49:16 --> Model Class Initialized
INFO - 2016-02-23 08:49:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:49:16 --> Pagination Class Initialized
INFO - 2016-02-23 08:49:16 --> Helper loaded: text_helper
INFO - 2016-02-23 08:49:16 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:49:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:49:16 --> Final output sent to browser
DEBUG - 2016-02-23 11:49:16 --> Total execution time: 1.1646
INFO - 2016-02-23 08:49:26 --> Config Class Initialized
INFO - 2016-02-23 08:49:26 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:49:26 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:49:26 --> Utf8 Class Initialized
INFO - 2016-02-23 08:49:26 --> URI Class Initialized
INFO - 2016-02-23 08:49:26 --> Router Class Initialized
INFO - 2016-02-23 08:49:26 --> Output Class Initialized
INFO - 2016-02-23 08:49:26 --> Security Class Initialized
DEBUG - 2016-02-23 08:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:49:26 --> Input Class Initialized
INFO - 2016-02-23 08:49:26 --> Language Class Initialized
INFO - 2016-02-23 08:49:26 --> Loader Class Initialized
INFO - 2016-02-23 08:49:26 --> Helper loaded: url_helper
INFO - 2016-02-23 08:49:26 --> Helper loaded: file_helper
INFO - 2016-02-23 08:49:26 --> Helper loaded: date_helper
INFO - 2016-02-23 08:49:26 --> Helper loaded: form_helper
INFO - 2016-02-23 08:49:26 --> Database Driver Class Initialized
INFO - 2016-02-23 08:49:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:49:27 --> Controller Class Initialized
INFO - 2016-02-23 08:49:27 --> Model Class Initialized
INFO - 2016-02-23 08:49:27 --> Model Class Initialized
INFO - 2016-02-23 08:49:27 --> Form Validation Class Initialized
INFO - 2016-02-23 08:49:27 --> Helper loaded: text_helper
ERROR - 2016-02-23 08:49:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 96
INFO - 2016-02-23 08:49:27 --> Final output sent to browser
DEBUG - 2016-02-23 08:49:27 --> Total execution time: 1.0959
INFO - 2016-02-23 08:49:31 --> Config Class Initialized
INFO - 2016-02-23 08:49:31 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:49:31 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:49:31 --> Utf8 Class Initialized
INFO - 2016-02-23 08:49:31 --> URI Class Initialized
DEBUG - 2016-02-23 08:49:31 --> No URI present. Default controller set.
INFO - 2016-02-23 08:49:31 --> Router Class Initialized
INFO - 2016-02-23 08:49:31 --> Output Class Initialized
INFO - 2016-02-23 08:49:31 --> Security Class Initialized
DEBUG - 2016-02-23 08:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:49:31 --> Input Class Initialized
INFO - 2016-02-23 08:49:31 --> Language Class Initialized
INFO - 2016-02-23 08:49:31 --> Loader Class Initialized
INFO - 2016-02-23 08:49:31 --> Helper loaded: url_helper
INFO - 2016-02-23 08:49:31 --> Helper loaded: file_helper
INFO - 2016-02-23 08:49:31 --> Helper loaded: date_helper
INFO - 2016-02-23 08:49:31 --> Helper loaded: form_helper
INFO - 2016-02-23 08:49:31 --> Database Driver Class Initialized
INFO - 2016-02-23 08:49:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:49:32 --> Controller Class Initialized
INFO - 2016-02-23 08:49:32 --> Model Class Initialized
INFO - 2016-02-23 08:49:32 --> Model Class Initialized
INFO - 2016-02-23 08:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:49:32 --> Pagination Class Initialized
INFO - 2016-02-23 08:49:32 --> Helper loaded: text_helper
INFO - 2016-02-23 08:49:32 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:49:32 --> Final output sent to browser
DEBUG - 2016-02-23 11:49:32 --> Total execution time: 1.1349
INFO - 2016-02-23 08:49:41 --> Config Class Initialized
INFO - 2016-02-23 08:49:41 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:49:41 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:49:41 --> Utf8 Class Initialized
INFO - 2016-02-23 08:49:41 --> URI Class Initialized
INFO - 2016-02-23 08:49:41 --> Router Class Initialized
INFO - 2016-02-23 08:49:41 --> Output Class Initialized
INFO - 2016-02-23 08:49:41 --> Security Class Initialized
DEBUG - 2016-02-23 08:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:49:41 --> Input Class Initialized
INFO - 2016-02-23 08:49:41 --> Language Class Initialized
INFO - 2016-02-23 08:49:41 --> Loader Class Initialized
INFO - 2016-02-23 08:49:41 --> Helper loaded: url_helper
INFO - 2016-02-23 08:49:41 --> Helper loaded: file_helper
INFO - 2016-02-23 08:49:41 --> Helper loaded: date_helper
INFO - 2016-02-23 08:49:41 --> Helper loaded: form_helper
INFO - 2016-02-23 08:49:41 --> Database Driver Class Initialized
INFO - 2016-02-23 08:49:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:49:42 --> Controller Class Initialized
INFO - 2016-02-23 08:49:42 --> Model Class Initialized
INFO - 2016-02-23 08:49:42 --> Model Class Initialized
INFO - 2016-02-23 08:49:42 --> Form Validation Class Initialized
INFO - 2016-02-23 08:49:42 --> Helper loaded: text_helper
ERROR - 2016-02-23 08:49:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 96
INFO - 2016-02-23 08:49:42 --> Final output sent to browser
DEBUG - 2016-02-23 08:49:42 --> Total execution time: 1.1001
INFO - 2016-02-23 08:51:56 --> Config Class Initialized
INFO - 2016-02-23 08:51:56 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:51:56 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:51:56 --> Utf8 Class Initialized
INFO - 2016-02-23 08:51:56 --> URI Class Initialized
DEBUG - 2016-02-23 08:51:56 --> No URI present. Default controller set.
INFO - 2016-02-23 08:51:56 --> Router Class Initialized
INFO - 2016-02-23 08:51:56 --> Output Class Initialized
INFO - 2016-02-23 08:51:56 --> Security Class Initialized
DEBUG - 2016-02-23 08:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:51:56 --> Input Class Initialized
INFO - 2016-02-23 08:51:56 --> Language Class Initialized
INFO - 2016-02-23 08:51:56 --> Loader Class Initialized
INFO - 2016-02-23 08:51:56 --> Helper loaded: url_helper
INFO - 2016-02-23 08:51:56 --> Helper loaded: file_helper
INFO - 2016-02-23 08:51:56 --> Helper loaded: date_helper
INFO - 2016-02-23 08:51:56 --> Helper loaded: form_helper
INFO - 2016-02-23 08:51:56 --> Database Driver Class Initialized
INFO - 2016-02-23 08:51:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:51:57 --> Controller Class Initialized
INFO - 2016-02-23 08:51:57 --> Model Class Initialized
INFO - 2016-02-23 08:51:57 --> Model Class Initialized
INFO - 2016-02-23 08:51:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:51:57 --> Pagination Class Initialized
INFO - 2016-02-23 08:51:57 --> Helper loaded: text_helper
INFO - 2016-02-23 08:51:57 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:51:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:51:57 --> Final output sent to browser
DEBUG - 2016-02-23 11:51:57 --> Total execution time: 1.1265
INFO - 2016-02-23 08:52:05 --> Config Class Initialized
INFO - 2016-02-23 08:52:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:52:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:52:05 --> Utf8 Class Initialized
INFO - 2016-02-23 08:52:05 --> URI Class Initialized
INFO - 2016-02-23 08:52:05 --> Router Class Initialized
INFO - 2016-02-23 08:52:05 --> Output Class Initialized
INFO - 2016-02-23 08:52:05 --> Security Class Initialized
DEBUG - 2016-02-23 08:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:52:05 --> Input Class Initialized
INFO - 2016-02-23 08:52:05 --> Language Class Initialized
INFO - 2016-02-23 08:52:05 --> Loader Class Initialized
INFO - 2016-02-23 08:52:05 --> Helper loaded: url_helper
INFO - 2016-02-23 08:52:05 --> Helper loaded: file_helper
INFO - 2016-02-23 08:52:05 --> Helper loaded: date_helper
INFO - 2016-02-23 08:52:05 --> Helper loaded: form_helper
INFO - 2016-02-23 08:52:05 --> Database Driver Class Initialized
INFO - 2016-02-23 08:52:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:52:06 --> Controller Class Initialized
INFO - 2016-02-23 08:52:06 --> Model Class Initialized
INFO - 2016-02-23 08:52:06 --> Model Class Initialized
INFO - 2016-02-23 08:52:06 --> Form Validation Class Initialized
INFO - 2016-02-23 08:52:06 --> Helper loaded: text_helper
INFO - 2016-02-23 08:52:07 --> Config Class Initialized
INFO - 2016-02-23 08:52:07 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:52:07 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:52:07 --> Utf8 Class Initialized
INFO - 2016-02-23 08:52:07 --> URI Class Initialized
DEBUG - 2016-02-23 08:52:07 --> No URI present. Default controller set.
INFO - 2016-02-23 08:52:07 --> Router Class Initialized
INFO - 2016-02-23 08:52:07 --> Output Class Initialized
INFO - 2016-02-23 08:52:07 --> Security Class Initialized
DEBUG - 2016-02-23 08:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:52:07 --> Input Class Initialized
INFO - 2016-02-23 08:52:07 --> Language Class Initialized
INFO - 2016-02-23 08:52:07 --> Loader Class Initialized
INFO - 2016-02-23 08:52:07 --> Helper loaded: url_helper
INFO - 2016-02-23 08:52:07 --> Helper loaded: file_helper
INFO - 2016-02-23 08:52:07 --> Helper loaded: date_helper
INFO - 2016-02-23 08:52:07 --> Helper loaded: form_helper
INFO - 2016-02-23 08:52:07 --> Database Driver Class Initialized
INFO - 2016-02-23 08:52:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:52:08 --> Controller Class Initialized
INFO - 2016-02-23 08:52:08 --> Model Class Initialized
INFO - 2016-02-23 08:52:08 --> Model Class Initialized
INFO - 2016-02-23 08:52:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:52:08 --> Pagination Class Initialized
INFO - 2016-02-23 08:52:08 --> Helper loaded: text_helper
INFO - 2016-02-23 08:52:08 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 11:52:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:52:08 --> Final output sent to browser
DEBUG - 2016-02-23 11:52:08 --> Total execution time: 1.1043
INFO - 2016-02-23 08:52:11 --> Config Class Initialized
INFO - 2016-02-23 08:52:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:52:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:52:11 --> Utf8 Class Initialized
INFO - 2016-02-23 08:52:11 --> URI Class Initialized
INFO - 2016-02-23 08:52:11 --> Router Class Initialized
INFO - 2016-02-23 08:52:11 --> Output Class Initialized
INFO - 2016-02-23 08:52:11 --> Security Class Initialized
DEBUG - 2016-02-23 08:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:52:11 --> Input Class Initialized
INFO - 2016-02-23 08:52:11 --> Language Class Initialized
INFO - 2016-02-23 08:52:11 --> Loader Class Initialized
INFO - 2016-02-23 08:52:11 --> Helper loaded: url_helper
INFO - 2016-02-23 08:52:11 --> Helper loaded: file_helper
INFO - 2016-02-23 08:52:11 --> Helper loaded: date_helper
INFO - 2016-02-23 08:52:11 --> Helper loaded: form_helper
INFO - 2016-02-23 08:52:11 --> Database Driver Class Initialized
INFO - 2016-02-23 08:52:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:52:12 --> Controller Class Initialized
INFO - 2016-02-23 08:52:12 --> Model Class Initialized
INFO - 2016-02-23 08:52:12 --> Model Class Initialized
INFO - 2016-02-23 08:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:52:12 --> Pagination Class Initialized
INFO - 2016-02-23 08:52:12 --> Helper loaded: text_helper
INFO - 2016-02-23 08:52:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:52:12 --> Final output sent to browser
DEBUG - 2016-02-23 11:52:12 --> Total execution time: 1.1226
INFO - 2016-02-23 08:52:14 --> Config Class Initialized
INFO - 2016-02-23 08:52:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:52:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:52:14 --> Utf8 Class Initialized
INFO - 2016-02-23 08:52:14 --> URI Class Initialized
INFO - 2016-02-23 08:52:14 --> Router Class Initialized
INFO - 2016-02-23 08:52:14 --> Output Class Initialized
INFO - 2016-02-23 08:52:14 --> Security Class Initialized
DEBUG - 2016-02-23 08:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:52:14 --> Input Class Initialized
INFO - 2016-02-23 08:52:14 --> Language Class Initialized
INFO - 2016-02-23 08:52:14 --> Loader Class Initialized
INFO - 2016-02-23 08:52:14 --> Helper loaded: url_helper
INFO - 2016-02-23 08:52:14 --> Helper loaded: file_helper
INFO - 2016-02-23 08:52:14 --> Helper loaded: date_helper
INFO - 2016-02-23 08:52:14 --> Helper loaded: form_helper
INFO - 2016-02-23 08:52:14 --> Database Driver Class Initialized
INFO - 2016-02-23 08:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:52:15 --> Controller Class Initialized
INFO - 2016-02-23 08:52:15 --> Model Class Initialized
INFO - 2016-02-23 08:52:15 --> Model Class Initialized
INFO - 2016-02-23 08:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:52:15 --> Pagination Class Initialized
INFO - 2016-02-23 08:52:15 --> Helper loaded: text_helper
INFO - 2016-02-23 08:52:15 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 11:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:52:15 --> Final output sent to browser
DEBUG - 2016-02-23 11:52:15 --> Total execution time: 1.1180
INFO - 2016-02-23 08:54:21 --> Config Class Initialized
INFO - 2016-02-23 08:54:21 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:54:21 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:54:21 --> Utf8 Class Initialized
INFO - 2016-02-23 08:54:21 --> URI Class Initialized
INFO - 2016-02-23 08:54:21 --> Router Class Initialized
INFO - 2016-02-23 08:54:21 --> Output Class Initialized
INFO - 2016-02-23 08:54:21 --> Security Class Initialized
DEBUG - 2016-02-23 08:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:54:21 --> Input Class Initialized
INFO - 2016-02-23 08:54:21 --> Language Class Initialized
INFO - 2016-02-23 08:54:21 --> Loader Class Initialized
INFO - 2016-02-23 08:54:21 --> Helper loaded: url_helper
INFO - 2016-02-23 08:54:21 --> Helper loaded: file_helper
INFO - 2016-02-23 08:54:21 --> Helper loaded: date_helper
INFO - 2016-02-23 08:54:21 --> Helper loaded: form_helper
INFO - 2016-02-23 08:54:21 --> Database Driver Class Initialized
INFO - 2016-02-23 08:54:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:54:22 --> Controller Class Initialized
INFO - 2016-02-23 08:54:22 --> Model Class Initialized
INFO - 2016-02-23 08:54:22 --> Model Class Initialized
INFO - 2016-02-23 08:54:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:54:22 --> Pagination Class Initialized
INFO - 2016-02-23 08:54:22 --> Helper loaded: text_helper
INFO - 2016-02-23 08:54:22 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 11:54:22 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 161
INFO - 2016-02-23 11:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:54:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:54:22 --> Form Validation Class Initialized
INFO - 2016-02-23 11:54:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-23 08:54:22 --> Config Class Initialized
INFO - 2016-02-23 08:54:22 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:54:22 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:54:22 --> Utf8 Class Initialized
INFO - 2016-02-23 08:54:22 --> URI Class Initialized
INFO - 2016-02-23 08:54:22 --> Router Class Initialized
INFO - 2016-02-23 08:54:22 --> Output Class Initialized
INFO - 2016-02-23 08:54:22 --> Security Class Initialized
DEBUG - 2016-02-23 08:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:54:22 --> Input Class Initialized
INFO - 2016-02-23 08:54:22 --> Language Class Initialized
INFO - 2016-02-23 08:54:22 --> Loader Class Initialized
INFO - 2016-02-23 08:54:22 --> Helper loaded: url_helper
INFO - 2016-02-23 08:54:22 --> Helper loaded: file_helper
INFO - 2016-02-23 08:54:22 --> Helper loaded: date_helper
INFO - 2016-02-23 08:54:22 --> Helper loaded: form_helper
INFO - 2016-02-23 08:54:22 --> Database Driver Class Initialized
INFO - 2016-02-23 08:54:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:54:23 --> Controller Class Initialized
INFO - 2016-02-23 08:54:23 --> Model Class Initialized
INFO - 2016-02-23 08:54:23 --> Model Class Initialized
INFO - 2016-02-23 08:54:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:54:23 --> Pagination Class Initialized
INFO - 2016-02-23 08:54:23 --> Helper loaded: text_helper
INFO - 2016-02-23 08:54:23 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 11:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 11:54:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:54:23 --> Final output sent to browser
DEBUG - 2016-02-23 11:54:23 --> Total execution time: 1.1934
INFO - 2016-02-23 08:54:27 --> Config Class Initialized
INFO - 2016-02-23 08:54:27 --> Hooks Class Initialized
DEBUG - 2016-02-23 08:54:27 --> UTF-8 Support Enabled
INFO - 2016-02-23 08:54:27 --> Utf8 Class Initialized
INFO - 2016-02-23 08:54:27 --> URI Class Initialized
INFO - 2016-02-23 08:54:27 --> Router Class Initialized
INFO - 2016-02-23 08:54:27 --> Output Class Initialized
INFO - 2016-02-23 08:54:27 --> Security Class Initialized
DEBUG - 2016-02-23 08:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 08:54:27 --> Input Class Initialized
INFO - 2016-02-23 08:54:27 --> Language Class Initialized
INFO - 2016-02-23 08:54:27 --> Loader Class Initialized
INFO - 2016-02-23 08:54:27 --> Helper loaded: url_helper
INFO - 2016-02-23 08:54:27 --> Helper loaded: file_helper
INFO - 2016-02-23 08:54:27 --> Helper loaded: date_helper
INFO - 2016-02-23 08:54:27 --> Helper loaded: form_helper
INFO - 2016-02-23 08:54:27 --> Database Driver Class Initialized
INFO - 2016-02-23 08:54:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 08:54:28 --> Controller Class Initialized
INFO - 2016-02-23 08:54:28 --> Model Class Initialized
INFO - 2016-02-23 08:54:28 --> Model Class Initialized
INFO - 2016-02-23 08:54:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 08:54:28 --> Pagination Class Initialized
INFO - 2016-02-23 08:54:28 --> Helper loaded: text_helper
INFO - 2016-02-23 08:54:28 --> Helper loaded: cookie_helper
INFO - 2016-02-23 11:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 11:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 11:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 11:54:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 11:54:28 --> Final output sent to browser
DEBUG - 2016-02-23 11:54:28 --> Total execution time: 1.0941
INFO - 2016-02-23 09:58:41 --> Config Class Initialized
INFO - 2016-02-23 09:58:41 --> Hooks Class Initialized
DEBUG - 2016-02-23 09:58:41 --> UTF-8 Support Enabled
INFO - 2016-02-23 09:58:41 --> Utf8 Class Initialized
INFO - 2016-02-23 09:58:41 --> URI Class Initialized
INFO - 2016-02-23 09:58:41 --> Router Class Initialized
INFO - 2016-02-23 09:58:41 --> Output Class Initialized
INFO - 2016-02-23 09:58:41 --> Security Class Initialized
DEBUG - 2016-02-23 09:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 09:58:41 --> Input Class Initialized
INFO - 2016-02-23 09:58:41 --> Language Class Initialized
INFO - 2016-02-23 09:58:41 --> Loader Class Initialized
INFO - 2016-02-23 09:58:41 --> Helper loaded: url_helper
INFO - 2016-02-23 09:58:41 --> Helper loaded: file_helper
INFO - 2016-02-23 09:58:41 --> Helper loaded: date_helper
INFO - 2016-02-23 09:58:41 --> Helper loaded: form_helper
INFO - 2016-02-23 09:58:41 --> Database Driver Class Initialized
INFO - 2016-02-23 09:58:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 09:58:42 --> Controller Class Initialized
INFO - 2016-02-23 09:58:42 --> Model Class Initialized
INFO - 2016-02-23 09:58:42 --> Model Class Initialized
INFO - 2016-02-23 09:58:42 --> Form Validation Class Initialized
INFO - 2016-02-23 09:58:42 --> Helper loaded: text_helper
INFO - 2016-02-23 09:58:42 --> Config Class Initialized
INFO - 2016-02-23 09:58:42 --> Hooks Class Initialized
DEBUG - 2016-02-23 09:58:42 --> UTF-8 Support Enabled
INFO - 2016-02-23 09:58:42 --> Utf8 Class Initialized
INFO - 2016-02-23 09:58:42 --> URI Class Initialized
DEBUG - 2016-02-23 09:58:42 --> No URI present. Default controller set.
INFO - 2016-02-23 09:58:42 --> Router Class Initialized
INFO - 2016-02-23 09:58:42 --> Output Class Initialized
INFO - 2016-02-23 09:58:42 --> Security Class Initialized
DEBUG - 2016-02-23 09:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 09:58:42 --> Input Class Initialized
INFO - 2016-02-23 09:58:42 --> Language Class Initialized
INFO - 2016-02-23 09:58:42 --> Loader Class Initialized
INFO - 2016-02-23 09:58:42 --> Helper loaded: url_helper
INFO - 2016-02-23 09:58:42 --> Helper loaded: file_helper
INFO - 2016-02-23 09:58:42 --> Helper loaded: date_helper
INFO - 2016-02-23 09:58:42 --> Helper loaded: form_helper
INFO - 2016-02-23 09:58:42 --> Database Driver Class Initialized
INFO - 2016-02-23 09:58:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 09:58:43 --> Controller Class Initialized
INFO - 2016-02-23 09:58:43 --> Model Class Initialized
INFO - 2016-02-23 09:58:43 --> Model Class Initialized
INFO - 2016-02-23 09:58:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 09:58:43 --> Pagination Class Initialized
INFO - 2016-02-23 09:58:43 --> Helper loaded: text_helper
INFO - 2016-02-23 09:58:43 --> Helper loaded: cookie_helper
INFO - 2016-02-23 12:58:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 12:58:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 12:58:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 12:58:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 12:58:43 --> Final output sent to browser
DEBUG - 2016-02-23 12:58:43 --> Total execution time: 1.1448
INFO - 2016-02-23 09:59:08 --> Config Class Initialized
INFO - 2016-02-23 09:59:08 --> Hooks Class Initialized
DEBUG - 2016-02-23 09:59:08 --> UTF-8 Support Enabled
INFO - 2016-02-23 09:59:08 --> Utf8 Class Initialized
INFO - 2016-02-23 09:59:08 --> URI Class Initialized
INFO - 2016-02-23 09:59:08 --> Router Class Initialized
INFO - 2016-02-23 09:59:08 --> Output Class Initialized
INFO - 2016-02-23 09:59:08 --> Security Class Initialized
DEBUG - 2016-02-23 09:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 09:59:08 --> Input Class Initialized
INFO - 2016-02-23 09:59:08 --> Language Class Initialized
INFO - 2016-02-23 09:59:08 --> Loader Class Initialized
INFO - 2016-02-23 09:59:08 --> Helper loaded: url_helper
INFO - 2016-02-23 09:59:08 --> Helper loaded: file_helper
INFO - 2016-02-23 09:59:08 --> Helper loaded: date_helper
INFO - 2016-02-23 09:59:08 --> Helper loaded: form_helper
INFO - 2016-02-23 09:59:08 --> Database Driver Class Initialized
INFO - 2016-02-23 09:59:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 09:59:09 --> Controller Class Initialized
INFO - 2016-02-23 09:59:09 --> Model Class Initialized
INFO - 2016-02-23 09:59:09 --> Model Class Initialized
INFO - 2016-02-23 09:59:09 --> Form Validation Class Initialized
INFO - 2016-02-23 09:59:09 --> Helper loaded: text_helper
INFO - 2016-02-23 09:59:09 --> Config Class Initialized
INFO - 2016-02-23 09:59:09 --> Hooks Class Initialized
DEBUG - 2016-02-23 09:59:09 --> UTF-8 Support Enabled
INFO - 2016-02-23 09:59:09 --> Utf8 Class Initialized
INFO - 2016-02-23 09:59:09 --> URI Class Initialized
DEBUG - 2016-02-23 09:59:09 --> No URI present. Default controller set.
INFO - 2016-02-23 09:59:09 --> Router Class Initialized
INFO - 2016-02-23 09:59:09 --> Output Class Initialized
INFO - 2016-02-23 09:59:09 --> Security Class Initialized
DEBUG - 2016-02-23 09:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 09:59:09 --> Input Class Initialized
INFO - 2016-02-23 09:59:09 --> Language Class Initialized
INFO - 2016-02-23 09:59:09 --> Loader Class Initialized
INFO - 2016-02-23 09:59:09 --> Helper loaded: url_helper
INFO - 2016-02-23 09:59:09 --> Helper loaded: file_helper
INFO - 2016-02-23 09:59:09 --> Helper loaded: date_helper
INFO - 2016-02-23 09:59:09 --> Helper loaded: form_helper
INFO - 2016-02-23 09:59:09 --> Database Driver Class Initialized
INFO - 2016-02-23 09:59:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 09:59:10 --> Controller Class Initialized
INFO - 2016-02-23 09:59:10 --> Model Class Initialized
INFO - 2016-02-23 09:59:10 --> Model Class Initialized
INFO - 2016-02-23 09:59:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 09:59:10 --> Pagination Class Initialized
INFO - 2016-02-23 09:59:10 --> Helper loaded: text_helper
INFO - 2016-02-23 09:59:10 --> Helper loaded: cookie_helper
INFO - 2016-02-23 12:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 12:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 12:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 12:59:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 12:59:11 --> Final output sent to browser
DEBUG - 2016-02-23 12:59:11 --> Total execution time: 1.1217
INFO - 2016-02-23 09:59:21 --> Config Class Initialized
INFO - 2016-02-23 09:59:21 --> Hooks Class Initialized
DEBUG - 2016-02-23 09:59:21 --> UTF-8 Support Enabled
INFO - 2016-02-23 09:59:21 --> Utf8 Class Initialized
INFO - 2016-02-23 09:59:21 --> URI Class Initialized
INFO - 2016-02-23 09:59:21 --> Router Class Initialized
INFO - 2016-02-23 09:59:21 --> Output Class Initialized
INFO - 2016-02-23 09:59:21 --> Security Class Initialized
DEBUG - 2016-02-23 09:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 09:59:21 --> Input Class Initialized
INFO - 2016-02-23 09:59:21 --> Language Class Initialized
INFO - 2016-02-23 09:59:21 --> Loader Class Initialized
INFO - 2016-02-23 09:59:21 --> Helper loaded: url_helper
INFO - 2016-02-23 09:59:21 --> Helper loaded: file_helper
INFO - 2016-02-23 09:59:21 --> Helper loaded: date_helper
INFO - 2016-02-23 09:59:21 --> Helper loaded: form_helper
INFO - 2016-02-23 09:59:21 --> Database Driver Class Initialized
INFO - 2016-02-23 09:59:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 09:59:22 --> Controller Class Initialized
INFO - 2016-02-23 09:59:22 --> Model Class Initialized
INFO - 2016-02-23 09:59:22 --> Model Class Initialized
INFO - 2016-02-23 09:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 09:59:22 --> Pagination Class Initialized
INFO - 2016-02-23 09:59:22 --> Helper loaded: text_helper
INFO - 2016-02-23 09:59:22 --> Helper loaded: cookie_helper
INFO - 2016-02-23 12:59:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 12:59:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 12:59:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 12:59:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 12:59:22 --> Final output sent to browser
DEBUG - 2016-02-23 12:59:22 --> Total execution time: 1.0910
INFO - 2016-02-23 09:59:24 --> Config Class Initialized
INFO - 2016-02-23 09:59:24 --> Hooks Class Initialized
DEBUG - 2016-02-23 09:59:24 --> UTF-8 Support Enabled
INFO - 2016-02-23 09:59:24 --> Utf8 Class Initialized
INFO - 2016-02-23 09:59:24 --> URI Class Initialized
INFO - 2016-02-23 09:59:24 --> Router Class Initialized
INFO - 2016-02-23 09:59:24 --> Output Class Initialized
INFO - 2016-02-23 09:59:24 --> Security Class Initialized
DEBUG - 2016-02-23 09:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 09:59:24 --> Input Class Initialized
INFO - 2016-02-23 09:59:24 --> Language Class Initialized
INFO - 2016-02-23 09:59:24 --> Loader Class Initialized
INFO - 2016-02-23 09:59:24 --> Helper loaded: url_helper
INFO - 2016-02-23 09:59:24 --> Helper loaded: file_helper
INFO - 2016-02-23 09:59:24 --> Helper loaded: date_helper
INFO - 2016-02-23 09:59:24 --> Helper loaded: form_helper
INFO - 2016-02-23 09:59:24 --> Database Driver Class Initialized
INFO - 2016-02-23 09:59:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 09:59:25 --> Controller Class Initialized
INFO - 2016-02-23 09:59:25 --> Model Class Initialized
INFO - 2016-02-23 09:59:25 --> Model Class Initialized
INFO - 2016-02-23 09:59:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 09:59:25 --> Pagination Class Initialized
INFO - 2016-02-23 09:59:25 --> Helper loaded: text_helper
INFO - 2016-02-23 09:59:25 --> Helper loaded: cookie_helper
INFO - 2016-02-23 12:59:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 12:59:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 12:59:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-02-23 12:59:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 12:59:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 12:59:25 --> Final output sent to browser
DEBUG - 2016-02-23 12:59:25 --> Total execution time: 1.1114
INFO - 2016-02-23 10:03:35 --> Config Class Initialized
INFO - 2016-02-23 10:03:35 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:03:35 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:03:35 --> Utf8 Class Initialized
INFO - 2016-02-23 10:03:35 --> URI Class Initialized
INFO - 2016-02-23 10:03:35 --> Router Class Initialized
INFO - 2016-02-23 10:03:35 --> Output Class Initialized
INFO - 2016-02-23 10:03:35 --> Security Class Initialized
DEBUG - 2016-02-23 10:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:03:35 --> Input Class Initialized
INFO - 2016-02-23 10:03:35 --> Language Class Initialized
INFO - 2016-02-23 10:03:35 --> Loader Class Initialized
INFO - 2016-02-23 10:03:35 --> Helper loaded: url_helper
INFO - 2016-02-23 10:03:35 --> Helper loaded: file_helper
INFO - 2016-02-23 10:03:35 --> Helper loaded: date_helper
INFO - 2016-02-23 10:03:35 --> Helper loaded: form_helper
INFO - 2016-02-23 10:03:35 --> Database Driver Class Initialized
INFO - 2016-02-23 10:03:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:03:36 --> Controller Class Initialized
INFO - 2016-02-23 10:03:36 --> Model Class Initialized
INFO - 2016-02-23 10:03:36 --> Model Class Initialized
INFO - 2016-02-23 10:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:03:36 --> Pagination Class Initialized
INFO - 2016-02-23 10:03:36 --> Helper loaded: text_helper
INFO - 2016-02-23 10:03:36 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 13:03:36 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 161
INFO - 2016-02-23 13:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:03:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:03:36 --> Form Validation Class Initialized
INFO - 2016-02-23 13:03:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-02-23 10:03:36 --> Config Class Initialized
INFO - 2016-02-23 10:03:36 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:03:36 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:03:36 --> Utf8 Class Initialized
INFO - 2016-02-23 10:03:36 --> URI Class Initialized
INFO - 2016-02-23 10:03:36 --> Router Class Initialized
INFO - 2016-02-23 10:03:36 --> Output Class Initialized
INFO - 2016-02-23 10:03:36 --> Security Class Initialized
DEBUG - 2016-02-23 10:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:03:36 --> Input Class Initialized
INFO - 2016-02-23 10:03:36 --> Language Class Initialized
INFO - 2016-02-23 10:03:36 --> Loader Class Initialized
INFO - 2016-02-23 10:03:36 --> Helper loaded: url_helper
INFO - 2016-02-23 10:03:36 --> Helper loaded: file_helper
INFO - 2016-02-23 10:03:36 --> Helper loaded: date_helper
INFO - 2016-02-23 10:03:36 --> Helper loaded: form_helper
INFO - 2016-02-23 10:03:36 --> Database Driver Class Initialized
INFO - 2016-02-23 10:03:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:03:37 --> Controller Class Initialized
INFO - 2016-02-23 10:03:37 --> Model Class Initialized
INFO - 2016-02-23 10:03:37 --> Model Class Initialized
INFO - 2016-02-23 10:03:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:03:37 --> Pagination Class Initialized
INFO - 2016-02-23 10:03:37 --> Helper loaded: text_helper
INFO - 2016-02-23 10:03:37 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 13:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 13:03:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:03:37 --> Final output sent to browser
DEBUG - 2016-02-23 13:03:37 --> Total execution time: 1.1307
INFO - 2016-02-23 10:03:40 --> Config Class Initialized
INFO - 2016-02-23 10:03:40 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:03:40 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:03:40 --> Utf8 Class Initialized
INFO - 2016-02-23 10:03:40 --> URI Class Initialized
INFO - 2016-02-23 10:03:40 --> Router Class Initialized
INFO - 2016-02-23 10:03:40 --> Output Class Initialized
INFO - 2016-02-23 10:03:40 --> Security Class Initialized
DEBUG - 2016-02-23 10:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:03:40 --> Input Class Initialized
INFO - 2016-02-23 10:03:40 --> Language Class Initialized
INFO - 2016-02-23 10:03:40 --> Loader Class Initialized
INFO - 2016-02-23 10:03:40 --> Helper loaded: url_helper
INFO - 2016-02-23 10:03:40 --> Helper loaded: file_helper
INFO - 2016-02-23 10:03:40 --> Helper loaded: date_helper
INFO - 2016-02-23 10:03:40 --> Helper loaded: form_helper
INFO - 2016-02-23 10:03:40 --> Database Driver Class Initialized
INFO - 2016-02-23 10:03:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:03:41 --> Controller Class Initialized
INFO - 2016-02-23 10:03:42 --> Model Class Initialized
INFO - 2016-02-23 10:03:42 --> Model Class Initialized
INFO - 2016-02-23 10:03:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:03:42 --> Pagination Class Initialized
INFO - 2016-02-23 10:03:42 --> Helper loaded: text_helper
INFO - 2016-02-23 10:03:42 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 13:03:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:03:42 --> Final output sent to browser
DEBUG - 2016-02-23 13:03:42 --> Total execution time: 1.1004
INFO - 2016-02-23 10:04:32 --> Config Class Initialized
INFO - 2016-02-23 10:04:32 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:04:32 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:04:32 --> Utf8 Class Initialized
INFO - 2016-02-23 10:04:32 --> URI Class Initialized
INFO - 2016-02-23 10:04:32 --> Router Class Initialized
INFO - 2016-02-23 10:04:32 --> Output Class Initialized
INFO - 2016-02-23 10:04:32 --> Security Class Initialized
DEBUG - 2016-02-23 10:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:04:32 --> Input Class Initialized
INFO - 2016-02-23 10:04:32 --> Language Class Initialized
INFO - 2016-02-23 10:04:32 --> Loader Class Initialized
INFO - 2016-02-23 10:04:32 --> Helper loaded: url_helper
INFO - 2016-02-23 10:04:32 --> Helper loaded: file_helper
INFO - 2016-02-23 10:04:32 --> Helper loaded: date_helper
INFO - 2016-02-23 10:04:32 --> Helper loaded: form_helper
INFO - 2016-02-23 10:04:32 --> Database Driver Class Initialized
INFO - 2016-02-23 10:04:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:04:33 --> Controller Class Initialized
INFO - 2016-02-23 10:04:33 --> Model Class Initialized
INFO - 2016-02-23 10:04:33 --> Model Class Initialized
INFO - 2016-02-23 10:04:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:04:33 --> Pagination Class Initialized
INFO - 2016-02-23 10:04:33 --> Helper loaded: text_helper
INFO - 2016-02-23 10:04:33 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 13:04:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:04:33 --> Final output sent to browser
DEBUG - 2016-02-23 13:04:33 --> Total execution time: 1.1402
INFO - 2016-02-23 10:04:34 --> Config Class Initialized
INFO - 2016-02-23 10:04:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:04:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:04:34 --> Utf8 Class Initialized
INFO - 2016-02-23 10:04:34 --> URI Class Initialized
DEBUG - 2016-02-23 10:04:34 --> No URI present. Default controller set.
INFO - 2016-02-23 10:04:34 --> Router Class Initialized
INFO - 2016-02-23 10:04:34 --> Output Class Initialized
INFO - 2016-02-23 10:04:34 --> Security Class Initialized
DEBUG - 2016-02-23 10:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:04:34 --> Input Class Initialized
INFO - 2016-02-23 10:04:34 --> Language Class Initialized
INFO - 2016-02-23 10:04:34 --> Loader Class Initialized
INFO - 2016-02-23 10:04:34 --> Helper loaded: url_helper
INFO - 2016-02-23 10:04:34 --> Helper loaded: file_helper
INFO - 2016-02-23 10:04:34 --> Helper loaded: date_helper
INFO - 2016-02-23 10:04:34 --> Helper loaded: form_helper
INFO - 2016-02-23 10:04:34 --> Database Driver Class Initialized
INFO - 2016-02-23 10:04:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:04:35 --> Controller Class Initialized
INFO - 2016-02-23 10:04:35 --> Model Class Initialized
INFO - 2016-02-23 10:04:35 --> Model Class Initialized
INFO - 2016-02-23 10:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:04:35 --> Pagination Class Initialized
INFO - 2016-02-23 10:04:35 --> Helper loaded: text_helper
INFO - 2016-02-23 10:04:35 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 13:04:35 --> Severity: Notice --> Use of undefined constant picture - assumed 'picture' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 7
ERROR - 2016-02-23 13:04:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php 7
INFO - 2016-02-23 13:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:04:35 --> Final output sent to browser
DEBUG - 2016-02-23 13:04:35 --> Total execution time: 1.2308
INFO - 2016-02-23 10:04:46 --> Config Class Initialized
INFO - 2016-02-23 10:04:47 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:04:47 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:04:47 --> Utf8 Class Initialized
INFO - 2016-02-23 10:04:47 --> URI Class Initialized
DEBUG - 2016-02-23 10:04:47 --> No URI present. Default controller set.
INFO - 2016-02-23 10:04:47 --> Router Class Initialized
INFO - 2016-02-23 10:04:47 --> Output Class Initialized
INFO - 2016-02-23 10:04:47 --> Security Class Initialized
DEBUG - 2016-02-23 10:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:04:47 --> Input Class Initialized
INFO - 2016-02-23 10:04:47 --> Language Class Initialized
INFO - 2016-02-23 10:04:47 --> Loader Class Initialized
INFO - 2016-02-23 10:04:47 --> Helper loaded: url_helper
INFO - 2016-02-23 10:04:47 --> Helper loaded: file_helper
INFO - 2016-02-23 10:04:47 --> Helper loaded: date_helper
INFO - 2016-02-23 10:04:47 --> Helper loaded: form_helper
INFO - 2016-02-23 10:04:47 --> Database Driver Class Initialized
INFO - 2016-02-23 10:04:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:04:48 --> Controller Class Initialized
INFO - 2016-02-23 10:04:48 --> Model Class Initialized
INFO - 2016-02-23 10:04:48 --> Model Class Initialized
INFO - 2016-02-23 10:04:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:04:48 --> Pagination Class Initialized
INFO - 2016-02-23 10:04:48 --> Helper loaded: text_helper
INFO - 2016-02-23 10:04:48 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:04:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:04:48 --> Final output sent to browser
DEBUG - 2016-02-23 13:04:48 --> Total execution time: 1.3144
INFO - 2016-02-23 10:05:14 --> Config Class Initialized
INFO - 2016-02-23 10:05:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:05:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:05:14 --> Utf8 Class Initialized
INFO - 2016-02-23 10:05:14 --> URI Class Initialized
DEBUG - 2016-02-23 10:05:14 --> No URI present. Default controller set.
INFO - 2016-02-23 10:05:14 --> Router Class Initialized
INFO - 2016-02-23 10:05:14 --> Output Class Initialized
INFO - 2016-02-23 10:05:14 --> Security Class Initialized
DEBUG - 2016-02-23 10:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:05:14 --> Input Class Initialized
INFO - 2016-02-23 10:05:14 --> Language Class Initialized
INFO - 2016-02-23 10:05:14 --> Loader Class Initialized
INFO - 2016-02-23 10:05:14 --> Helper loaded: url_helper
INFO - 2016-02-23 10:05:14 --> Helper loaded: file_helper
INFO - 2016-02-23 10:05:14 --> Helper loaded: date_helper
INFO - 2016-02-23 10:05:14 --> Helper loaded: form_helper
INFO - 2016-02-23 10:05:14 --> Database Driver Class Initialized
INFO - 2016-02-23 10:05:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:05:15 --> Controller Class Initialized
INFO - 2016-02-23 10:05:15 --> Model Class Initialized
INFO - 2016-02-23 10:05:15 --> Model Class Initialized
INFO - 2016-02-23 10:05:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:05:15 --> Pagination Class Initialized
INFO - 2016-02-23 10:05:15 --> Helper loaded: text_helper
INFO - 2016-02-23 10:05:15 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:05:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:05:15 --> Final output sent to browser
DEBUG - 2016-02-23 13:05:15 --> Total execution time: 1.1397
INFO - 2016-02-23 10:05:24 --> Config Class Initialized
INFO - 2016-02-23 10:05:24 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:05:24 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:05:24 --> Utf8 Class Initialized
INFO - 2016-02-23 10:05:24 --> URI Class Initialized
DEBUG - 2016-02-23 10:05:24 --> No URI present. Default controller set.
INFO - 2016-02-23 10:05:24 --> Router Class Initialized
INFO - 2016-02-23 10:05:24 --> Output Class Initialized
INFO - 2016-02-23 10:05:24 --> Security Class Initialized
DEBUG - 2016-02-23 10:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:05:24 --> Input Class Initialized
INFO - 2016-02-23 10:05:24 --> Language Class Initialized
INFO - 2016-02-23 10:05:24 --> Loader Class Initialized
INFO - 2016-02-23 10:05:24 --> Helper loaded: url_helper
INFO - 2016-02-23 10:05:24 --> Helper loaded: file_helper
INFO - 2016-02-23 10:05:24 --> Helper loaded: date_helper
INFO - 2016-02-23 10:05:24 --> Helper loaded: form_helper
INFO - 2016-02-23 10:05:24 --> Database Driver Class Initialized
INFO - 2016-02-23 10:05:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:05:25 --> Controller Class Initialized
INFO - 2016-02-23 10:05:25 --> Model Class Initialized
INFO - 2016-02-23 10:05:25 --> Model Class Initialized
INFO - 2016-02-23 10:05:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:05:25 --> Pagination Class Initialized
INFO - 2016-02-23 10:05:25 --> Helper loaded: text_helper
INFO - 2016-02-23 10:05:25 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:05:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:05:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:05:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:05:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:05:25 --> Final output sent to browser
DEBUG - 2016-02-23 13:05:25 --> Total execution time: 1.1112
INFO - 2016-02-23 10:05:37 --> Config Class Initialized
INFO - 2016-02-23 10:05:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:05:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:05:37 --> Utf8 Class Initialized
INFO - 2016-02-23 10:05:37 --> URI Class Initialized
DEBUG - 2016-02-23 10:05:37 --> No URI present. Default controller set.
INFO - 2016-02-23 10:05:37 --> Router Class Initialized
INFO - 2016-02-23 10:05:37 --> Output Class Initialized
INFO - 2016-02-23 10:05:37 --> Security Class Initialized
DEBUG - 2016-02-23 10:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:05:37 --> Input Class Initialized
INFO - 2016-02-23 10:05:37 --> Language Class Initialized
INFO - 2016-02-23 10:05:37 --> Loader Class Initialized
INFO - 2016-02-23 10:05:37 --> Helper loaded: url_helper
INFO - 2016-02-23 10:05:37 --> Helper loaded: file_helper
INFO - 2016-02-23 10:05:37 --> Helper loaded: date_helper
INFO - 2016-02-23 10:05:37 --> Helper loaded: form_helper
INFO - 2016-02-23 10:05:37 --> Database Driver Class Initialized
INFO - 2016-02-23 10:05:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:05:38 --> Controller Class Initialized
INFO - 2016-02-23 10:05:38 --> Model Class Initialized
INFO - 2016-02-23 10:05:38 --> Model Class Initialized
INFO - 2016-02-23 10:05:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:05:38 --> Pagination Class Initialized
INFO - 2016-02-23 10:05:38 --> Helper loaded: text_helper
INFO - 2016-02-23 10:05:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:05:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:05:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:05:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:05:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:05:38 --> Final output sent to browser
DEBUG - 2016-02-23 13:05:38 --> Total execution time: 1.1199
INFO - 2016-02-23 10:06:13 --> Config Class Initialized
INFO - 2016-02-23 10:06:13 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:06:13 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:06:13 --> Utf8 Class Initialized
INFO - 2016-02-23 10:06:13 --> URI Class Initialized
DEBUG - 2016-02-23 10:06:13 --> No URI present. Default controller set.
INFO - 2016-02-23 10:06:13 --> Router Class Initialized
INFO - 2016-02-23 10:06:13 --> Output Class Initialized
INFO - 2016-02-23 10:06:13 --> Security Class Initialized
DEBUG - 2016-02-23 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:06:13 --> Input Class Initialized
INFO - 2016-02-23 10:06:13 --> Language Class Initialized
INFO - 2016-02-23 10:06:13 --> Loader Class Initialized
INFO - 2016-02-23 10:06:13 --> Helper loaded: url_helper
INFO - 2016-02-23 10:06:13 --> Helper loaded: file_helper
INFO - 2016-02-23 10:06:13 --> Helper loaded: date_helper
INFO - 2016-02-23 10:06:13 --> Helper loaded: form_helper
INFO - 2016-02-23 10:06:13 --> Database Driver Class Initialized
INFO - 2016-02-23 10:06:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:06:14 --> Controller Class Initialized
INFO - 2016-02-23 10:06:14 --> Model Class Initialized
INFO - 2016-02-23 10:06:14 --> Model Class Initialized
INFO - 2016-02-23 10:06:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:06:14 --> Pagination Class Initialized
INFO - 2016-02-23 10:06:14 --> Helper loaded: text_helper
INFO - 2016-02-23 10:06:14 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:06:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:06:14 --> Final output sent to browser
DEBUG - 2016-02-23 13:06:14 --> Total execution time: 1.1761
INFO - 2016-02-23 10:08:21 --> Config Class Initialized
INFO - 2016-02-23 10:08:21 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:08:21 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:08:21 --> Utf8 Class Initialized
INFO - 2016-02-23 10:08:21 --> URI Class Initialized
DEBUG - 2016-02-23 10:08:21 --> No URI present. Default controller set.
INFO - 2016-02-23 10:08:21 --> Router Class Initialized
INFO - 2016-02-23 10:08:21 --> Output Class Initialized
INFO - 2016-02-23 10:08:21 --> Security Class Initialized
DEBUG - 2016-02-23 10:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:08:21 --> Input Class Initialized
INFO - 2016-02-23 10:08:21 --> Language Class Initialized
INFO - 2016-02-23 10:08:21 --> Loader Class Initialized
INFO - 2016-02-23 10:08:21 --> Helper loaded: url_helper
INFO - 2016-02-23 10:08:21 --> Helper loaded: file_helper
INFO - 2016-02-23 10:08:21 --> Helper loaded: date_helper
INFO - 2016-02-23 10:08:21 --> Helper loaded: form_helper
INFO - 2016-02-23 10:08:21 --> Database Driver Class Initialized
INFO - 2016-02-23 10:08:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:08:22 --> Controller Class Initialized
INFO - 2016-02-23 10:08:22 --> Model Class Initialized
INFO - 2016-02-23 10:08:22 --> Model Class Initialized
INFO - 2016-02-23 10:08:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:08:22 --> Pagination Class Initialized
INFO - 2016-02-23 10:08:22 --> Helper loaded: text_helper
INFO - 2016-02-23 10:08:22 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:08:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:08:22 --> Final output sent to browser
DEBUG - 2016-02-23 13:08:22 --> Total execution time: 1.0995
INFO - 2016-02-23 10:08:31 --> Config Class Initialized
INFO - 2016-02-23 10:08:31 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:08:31 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:08:31 --> Utf8 Class Initialized
INFO - 2016-02-23 10:08:31 --> URI Class Initialized
DEBUG - 2016-02-23 10:08:31 --> No URI present. Default controller set.
INFO - 2016-02-23 10:08:31 --> Router Class Initialized
INFO - 2016-02-23 10:08:31 --> Output Class Initialized
INFO - 2016-02-23 10:08:31 --> Security Class Initialized
DEBUG - 2016-02-23 10:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:08:31 --> Input Class Initialized
INFO - 2016-02-23 10:08:31 --> Language Class Initialized
INFO - 2016-02-23 10:08:31 --> Loader Class Initialized
INFO - 2016-02-23 10:08:31 --> Helper loaded: url_helper
INFO - 2016-02-23 10:08:31 --> Helper loaded: file_helper
INFO - 2016-02-23 10:08:31 --> Helper loaded: date_helper
INFO - 2016-02-23 10:08:31 --> Helper loaded: form_helper
INFO - 2016-02-23 10:08:31 --> Database Driver Class Initialized
INFO - 2016-02-23 10:08:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:08:32 --> Controller Class Initialized
INFO - 2016-02-23 10:08:32 --> Model Class Initialized
INFO - 2016-02-23 10:08:32 --> Model Class Initialized
INFO - 2016-02-23 10:08:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:08:32 --> Pagination Class Initialized
INFO - 2016-02-23 10:08:32 --> Helper loaded: text_helper
INFO - 2016-02-23 10:08:32 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:08:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:08:32 --> Final output sent to browser
DEBUG - 2016-02-23 13:08:32 --> Total execution time: 1.1403
INFO - 2016-02-23 10:09:19 --> Config Class Initialized
INFO - 2016-02-23 10:09:19 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:09:19 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:09:19 --> Utf8 Class Initialized
INFO - 2016-02-23 10:09:19 --> URI Class Initialized
DEBUG - 2016-02-23 10:09:19 --> No URI present. Default controller set.
INFO - 2016-02-23 10:09:19 --> Router Class Initialized
INFO - 2016-02-23 10:09:19 --> Output Class Initialized
INFO - 2016-02-23 10:09:19 --> Security Class Initialized
DEBUG - 2016-02-23 10:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:09:19 --> Input Class Initialized
INFO - 2016-02-23 10:09:19 --> Language Class Initialized
INFO - 2016-02-23 10:09:19 --> Loader Class Initialized
INFO - 2016-02-23 10:09:19 --> Helper loaded: url_helper
INFO - 2016-02-23 10:09:19 --> Helper loaded: file_helper
INFO - 2016-02-23 10:09:19 --> Helper loaded: date_helper
INFO - 2016-02-23 10:09:19 --> Helper loaded: form_helper
INFO - 2016-02-23 10:09:19 --> Database Driver Class Initialized
INFO - 2016-02-23 10:09:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:09:20 --> Controller Class Initialized
INFO - 2016-02-23 10:09:20 --> Model Class Initialized
INFO - 2016-02-23 10:09:20 --> Model Class Initialized
INFO - 2016-02-23 10:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:09:20 --> Pagination Class Initialized
INFO - 2016-02-23 10:09:20 --> Helper loaded: text_helper
INFO - 2016-02-23 10:09:20 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:09:20 --> Final output sent to browser
DEBUG - 2016-02-23 13:09:20 --> Total execution time: 1.1095
INFO - 2016-02-23 10:09:42 --> Config Class Initialized
INFO - 2016-02-23 10:09:42 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:09:42 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:09:42 --> Utf8 Class Initialized
INFO - 2016-02-23 10:09:42 --> URI Class Initialized
DEBUG - 2016-02-23 10:09:42 --> No URI present. Default controller set.
INFO - 2016-02-23 10:09:42 --> Router Class Initialized
INFO - 2016-02-23 10:09:42 --> Output Class Initialized
INFO - 2016-02-23 10:09:42 --> Security Class Initialized
DEBUG - 2016-02-23 10:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:09:42 --> Input Class Initialized
INFO - 2016-02-23 10:09:42 --> Language Class Initialized
INFO - 2016-02-23 10:09:42 --> Loader Class Initialized
INFO - 2016-02-23 10:09:42 --> Helper loaded: url_helper
INFO - 2016-02-23 10:09:42 --> Helper loaded: file_helper
INFO - 2016-02-23 10:09:42 --> Helper loaded: date_helper
INFO - 2016-02-23 10:09:42 --> Helper loaded: form_helper
INFO - 2016-02-23 10:09:42 --> Database Driver Class Initialized
INFO - 2016-02-23 10:09:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:09:43 --> Controller Class Initialized
INFO - 2016-02-23 10:09:43 --> Model Class Initialized
INFO - 2016-02-23 10:09:43 --> Model Class Initialized
INFO - 2016-02-23 10:09:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:09:43 --> Pagination Class Initialized
INFO - 2016-02-23 10:09:43 --> Helper loaded: text_helper
INFO - 2016-02-23 10:09:43 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:09:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:09:43 --> Final output sent to browser
DEBUG - 2016-02-23 13:09:43 --> Total execution time: 1.1089
INFO - 2016-02-23 10:10:50 --> Config Class Initialized
INFO - 2016-02-23 10:10:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:10:50 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:10:50 --> Utf8 Class Initialized
INFO - 2016-02-23 10:10:50 --> URI Class Initialized
DEBUG - 2016-02-23 10:10:50 --> No URI present. Default controller set.
INFO - 2016-02-23 10:10:50 --> Router Class Initialized
INFO - 2016-02-23 10:10:50 --> Output Class Initialized
INFO - 2016-02-23 10:10:50 --> Security Class Initialized
DEBUG - 2016-02-23 10:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:10:50 --> Input Class Initialized
INFO - 2016-02-23 10:10:50 --> Language Class Initialized
INFO - 2016-02-23 10:10:50 --> Loader Class Initialized
INFO - 2016-02-23 10:10:50 --> Helper loaded: url_helper
INFO - 2016-02-23 10:10:50 --> Helper loaded: file_helper
INFO - 2016-02-23 10:10:50 --> Helper loaded: date_helper
INFO - 2016-02-23 10:10:50 --> Helper loaded: form_helper
INFO - 2016-02-23 10:10:50 --> Database Driver Class Initialized
INFO - 2016-02-23 10:10:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:10:51 --> Controller Class Initialized
INFO - 2016-02-23 10:10:51 --> Model Class Initialized
INFO - 2016-02-23 10:10:51 --> Model Class Initialized
INFO - 2016-02-23 10:10:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:10:51 --> Pagination Class Initialized
INFO - 2016-02-23 10:10:51 --> Helper loaded: text_helper
INFO - 2016-02-23 10:10:51 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:10:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:10:51 --> Final output sent to browser
DEBUG - 2016-02-23 13:10:51 --> Total execution time: 1.1240
INFO - 2016-02-23 10:11:34 --> Config Class Initialized
INFO - 2016-02-23 10:11:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:11:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:11:34 --> Utf8 Class Initialized
INFO - 2016-02-23 10:11:34 --> URI Class Initialized
DEBUG - 2016-02-23 10:11:34 --> No URI present. Default controller set.
INFO - 2016-02-23 10:11:34 --> Router Class Initialized
INFO - 2016-02-23 10:11:34 --> Output Class Initialized
INFO - 2016-02-23 10:11:34 --> Security Class Initialized
DEBUG - 2016-02-23 10:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:11:34 --> Input Class Initialized
INFO - 2016-02-23 10:11:34 --> Language Class Initialized
INFO - 2016-02-23 10:11:34 --> Loader Class Initialized
INFO - 2016-02-23 10:11:34 --> Helper loaded: url_helper
INFO - 2016-02-23 10:11:34 --> Helper loaded: file_helper
INFO - 2016-02-23 10:11:34 --> Helper loaded: date_helper
INFO - 2016-02-23 10:11:34 --> Helper loaded: form_helper
INFO - 2016-02-23 10:11:34 --> Database Driver Class Initialized
INFO - 2016-02-23 10:11:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:11:35 --> Controller Class Initialized
INFO - 2016-02-23 10:11:35 --> Model Class Initialized
INFO - 2016-02-23 10:11:35 --> Model Class Initialized
INFO - 2016-02-23 10:11:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:11:35 --> Pagination Class Initialized
INFO - 2016-02-23 10:11:35 --> Helper loaded: text_helper
INFO - 2016-02-23 10:11:35 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:11:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:11:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:11:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:11:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:11:35 --> Final output sent to browser
DEBUG - 2016-02-23 13:11:35 --> Total execution time: 1.1436
INFO - 2016-02-23 10:12:10 --> Config Class Initialized
INFO - 2016-02-23 10:12:10 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:12:10 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:12:10 --> Utf8 Class Initialized
INFO - 2016-02-23 10:12:10 --> URI Class Initialized
DEBUG - 2016-02-23 10:12:10 --> No URI present. Default controller set.
INFO - 2016-02-23 10:12:10 --> Router Class Initialized
INFO - 2016-02-23 10:12:11 --> Output Class Initialized
INFO - 2016-02-23 10:12:11 --> Security Class Initialized
DEBUG - 2016-02-23 10:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:12:11 --> Input Class Initialized
INFO - 2016-02-23 10:12:11 --> Language Class Initialized
INFO - 2016-02-23 10:12:11 --> Loader Class Initialized
INFO - 2016-02-23 10:12:11 --> Helper loaded: url_helper
INFO - 2016-02-23 10:12:11 --> Helper loaded: file_helper
INFO - 2016-02-23 10:12:11 --> Helper loaded: date_helper
INFO - 2016-02-23 10:12:11 --> Helper loaded: form_helper
INFO - 2016-02-23 10:12:11 --> Database Driver Class Initialized
INFO - 2016-02-23 10:12:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:12:12 --> Controller Class Initialized
INFO - 2016-02-23 10:12:12 --> Model Class Initialized
INFO - 2016-02-23 10:12:12 --> Model Class Initialized
INFO - 2016-02-23 10:12:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:12:12 --> Pagination Class Initialized
INFO - 2016-02-23 10:12:12 --> Helper loaded: text_helper
INFO - 2016-02-23 10:12:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:12:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:12:12 --> Final output sent to browser
DEBUG - 2016-02-23 13:12:12 --> Total execution time: 1.1502
INFO - 2016-02-23 10:13:16 --> Config Class Initialized
INFO - 2016-02-23 10:13:16 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:13:16 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:13:16 --> Utf8 Class Initialized
INFO - 2016-02-23 10:13:16 --> URI Class Initialized
DEBUG - 2016-02-23 10:13:16 --> No URI present. Default controller set.
INFO - 2016-02-23 10:13:16 --> Router Class Initialized
INFO - 2016-02-23 10:13:16 --> Output Class Initialized
INFO - 2016-02-23 10:13:16 --> Security Class Initialized
DEBUG - 2016-02-23 10:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:13:16 --> Input Class Initialized
INFO - 2016-02-23 10:13:16 --> Language Class Initialized
INFO - 2016-02-23 10:13:16 --> Loader Class Initialized
INFO - 2016-02-23 10:13:16 --> Helper loaded: url_helper
INFO - 2016-02-23 10:13:16 --> Helper loaded: file_helper
INFO - 2016-02-23 10:13:16 --> Helper loaded: date_helper
INFO - 2016-02-23 10:13:16 --> Helper loaded: form_helper
INFO - 2016-02-23 10:13:16 --> Database Driver Class Initialized
INFO - 2016-02-23 10:13:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:13:17 --> Controller Class Initialized
INFO - 2016-02-23 10:13:17 --> Model Class Initialized
INFO - 2016-02-23 10:13:17 --> Model Class Initialized
INFO - 2016-02-23 10:13:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:13:17 --> Pagination Class Initialized
INFO - 2016-02-23 10:13:17 --> Helper loaded: text_helper
INFO - 2016-02-23 10:13:17 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:13:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:13:17 --> Final output sent to browser
DEBUG - 2016-02-23 13:13:17 --> Total execution time: 1.1621
INFO - 2016-02-23 10:13:26 --> Config Class Initialized
INFO - 2016-02-23 10:13:26 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:13:26 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:13:26 --> Utf8 Class Initialized
INFO - 2016-02-23 10:13:26 --> URI Class Initialized
DEBUG - 2016-02-23 10:13:26 --> No URI present. Default controller set.
INFO - 2016-02-23 10:13:26 --> Router Class Initialized
INFO - 2016-02-23 10:13:27 --> Output Class Initialized
INFO - 2016-02-23 10:13:27 --> Security Class Initialized
DEBUG - 2016-02-23 10:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:13:27 --> Input Class Initialized
INFO - 2016-02-23 10:13:27 --> Language Class Initialized
INFO - 2016-02-23 10:13:27 --> Loader Class Initialized
INFO - 2016-02-23 10:13:27 --> Helper loaded: url_helper
INFO - 2016-02-23 10:13:27 --> Helper loaded: file_helper
INFO - 2016-02-23 10:13:27 --> Helper loaded: date_helper
INFO - 2016-02-23 10:13:27 --> Helper loaded: form_helper
INFO - 2016-02-23 10:13:27 --> Database Driver Class Initialized
INFO - 2016-02-23 10:13:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:13:28 --> Controller Class Initialized
INFO - 2016-02-23 10:13:28 --> Model Class Initialized
INFO - 2016-02-23 10:13:28 --> Model Class Initialized
INFO - 2016-02-23 10:13:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:13:28 --> Pagination Class Initialized
INFO - 2016-02-23 10:13:28 --> Helper loaded: text_helper
INFO - 2016-02-23 10:13:28 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:13:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:13:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:13:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:13:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:13:28 --> Final output sent to browser
DEBUG - 2016-02-23 13:13:28 --> Total execution time: 1.0900
INFO - 2016-02-23 10:13:54 --> Config Class Initialized
INFO - 2016-02-23 10:13:54 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:13:54 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:13:54 --> Utf8 Class Initialized
INFO - 2016-02-23 10:13:54 --> URI Class Initialized
DEBUG - 2016-02-23 10:13:54 --> No URI present. Default controller set.
INFO - 2016-02-23 10:13:54 --> Router Class Initialized
INFO - 2016-02-23 10:13:54 --> Output Class Initialized
INFO - 2016-02-23 10:13:54 --> Security Class Initialized
DEBUG - 2016-02-23 10:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:13:54 --> Input Class Initialized
INFO - 2016-02-23 10:13:54 --> Language Class Initialized
INFO - 2016-02-23 10:13:54 --> Loader Class Initialized
INFO - 2016-02-23 10:13:54 --> Helper loaded: url_helper
INFO - 2016-02-23 10:13:54 --> Helper loaded: file_helper
INFO - 2016-02-23 10:13:54 --> Helper loaded: date_helper
INFO - 2016-02-23 10:13:54 --> Helper loaded: form_helper
INFO - 2016-02-23 10:13:54 --> Database Driver Class Initialized
INFO - 2016-02-23 10:13:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:13:55 --> Controller Class Initialized
INFO - 2016-02-23 10:13:55 --> Model Class Initialized
INFO - 2016-02-23 10:13:55 --> Model Class Initialized
INFO - 2016-02-23 10:13:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:13:55 --> Pagination Class Initialized
INFO - 2016-02-23 10:13:55 --> Helper loaded: text_helper
INFO - 2016-02-23 10:13:55 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:13:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:13:55 --> Final output sent to browser
DEBUG - 2016-02-23 13:13:55 --> Total execution time: 1.1282
INFO - 2016-02-23 10:14:14 --> Config Class Initialized
INFO - 2016-02-23 10:14:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:14:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:14:14 --> Utf8 Class Initialized
INFO - 2016-02-23 10:14:14 --> URI Class Initialized
DEBUG - 2016-02-23 10:14:14 --> No URI present. Default controller set.
INFO - 2016-02-23 10:14:14 --> Router Class Initialized
INFO - 2016-02-23 10:14:14 --> Output Class Initialized
INFO - 2016-02-23 10:14:14 --> Security Class Initialized
DEBUG - 2016-02-23 10:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:14:14 --> Input Class Initialized
INFO - 2016-02-23 10:14:14 --> Language Class Initialized
INFO - 2016-02-23 10:14:14 --> Loader Class Initialized
INFO - 2016-02-23 10:14:14 --> Helper loaded: url_helper
INFO - 2016-02-23 10:14:14 --> Helper loaded: file_helper
INFO - 2016-02-23 10:14:14 --> Helper loaded: date_helper
INFO - 2016-02-23 10:14:14 --> Helper loaded: form_helper
INFO - 2016-02-23 10:14:14 --> Database Driver Class Initialized
INFO - 2016-02-23 10:14:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:14:15 --> Controller Class Initialized
INFO - 2016-02-23 10:14:15 --> Model Class Initialized
INFO - 2016-02-23 10:14:15 --> Model Class Initialized
INFO - 2016-02-23 10:14:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:14:15 --> Pagination Class Initialized
INFO - 2016-02-23 10:14:15 --> Helper loaded: text_helper
INFO - 2016-02-23 10:14:15 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:14:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:14:15 --> Final output sent to browser
DEBUG - 2016-02-23 13:14:15 --> Total execution time: 1.0991
INFO - 2016-02-23 10:46:37 --> Config Class Initialized
INFO - 2016-02-23 10:46:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:46:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:46:37 --> Utf8 Class Initialized
INFO - 2016-02-23 10:46:37 --> URI Class Initialized
DEBUG - 2016-02-23 10:46:37 --> No URI present. Default controller set.
INFO - 2016-02-23 10:46:37 --> Router Class Initialized
INFO - 2016-02-23 10:46:37 --> Output Class Initialized
INFO - 2016-02-23 10:46:37 --> Security Class Initialized
DEBUG - 2016-02-23 10:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:46:37 --> Input Class Initialized
INFO - 2016-02-23 10:46:37 --> Language Class Initialized
INFO - 2016-02-23 10:46:37 --> Loader Class Initialized
INFO - 2016-02-23 10:46:37 --> Helper loaded: url_helper
INFO - 2016-02-23 10:46:37 --> Helper loaded: file_helper
INFO - 2016-02-23 10:46:37 --> Helper loaded: date_helper
INFO - 2016-02-23 10:46:37 --> Helper loaded: form_helper
INFO - 2016-02-23 10:46:37 --> Database Driver Class Initialized
INFO - 2016-02-23 10:46:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:46:38 --> Controller Class Initialized
INFO - 2016-02-23 10:46:38 --> Model Class Initialized
INFO - 2016-02-23 10:46:38 --> Model Class Initialized
INFO - 2016-02-23 10:46:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:46:38 --> Pagination Class Initialized
INFO - 2016-02-23 10:46:38 --> Helper loaded: text_helper
INFO - 2016-02-23 10:46:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:46:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:46:38 --> Final output sent to browser
DEBUG - 2016-02-23 13:46:38 --> Total execution time: 1.1354
INFO - 2016-02-23 10:47:17 --> Config Class Initialized
INFO - 2016-02-23 10:47:17 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:47:17 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:47:17 --> Utf8 Class Initialized
INFO - 2016-02-23 10:47:17 --> URI Class Initialized
DEBUG - 2016-02-23 10:47:17 --> No URI present. Default controller set.
INFO - 2016-02-23 10:47:17 --> Router Class Initialized
INFO - 2016-02-23 10:47:17 --> Output Class Initialized
INFO - 2016-02-23 10:47:17 --> Security Class Initialized
DEBUG - 2016-02-23 10:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:47:17 --> Input Class Initialized
INFO - 2016-02-23 10:47:17 --> Language Class Initialized
INFO - 2016-02-23 10:47:17 --> Loader Class Initialized
INFO - 2016-02-23 10:47:17 --> Helper loaded: url_helper
INFO - 2016-02-23 10:47:17 --> Helper loaded: file_helper
INFO - 2016-02-23 10:47:17 --> Helper loaded: date_helper
INFO - 2016-02-23 10:47:17 --> Helper loaded: form_helper
INFO - 2016-02-23 10:47:17 --> Database Driver Class Initialized
INFO - 2016-02-23 10:47:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:47:18 --> Controller Class Initialized
INFO - 2016-02-23 10:47:18 --> Model Class Initialized
INFO - 2016-02-23 10:47:18 --> Model Class Initialized
INFO - 2016-02-23 10:47:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:47:18 --> Pagination Class Initialized
INFO - 2016-02-23 10:47:18 --> Helper loaded: text_helper
INFO - 2016-02-23 10:47:18 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:47:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:47:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:47:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:47:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:47:18 --> Final output sent to browser
DEBUG - 2016-02-23 13:47:18 --> Total execution time: 1.1300
INFO - 2016-02-23 10:47:40 --> Config Class Initialized
INFO - 2016-02-23 10:47:40 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:47:40 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:47:40 --> Utf8 Class Initialized
INFO - 2016-02-23 10:47:40 --> URI Class Initialized
DEBUG - 2016-02-23 10:47:40 --> No URI present. Default controller set.
INFO - 2016-02-23 10:47:40 --> Router Class Initialized
INFO - 2016-02-23 10:47:40 --> Output Class Initialized
INFO - 2016-02-23 10:47:40 --> Security Class Initialized
DEBUG - 2016-02-23 10:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:47:40 --> Input Class Initialized
INFO - 2016-02-23 10:47:40 --> Language Class Initialized
INFO - 2016-02-23 10:47:40 --> Loader Class Initialized
INFO - 2016-02-23 10:47:40 --> Helper loaded: url_helper
INFO - 2016-02-23 10:47:40 --> Helper loaded: file_helper
INFO - 2016-02-23 10:47:40 --> Helper loaded: date_helper
INFO - 2016-02-23 10:47:40 --> Helper loaded: form_helper
INFO - 2016-02-23 10:47:40 --> Database Driver Class Initialized
INFO - 2016-02-23 10:47:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:47:41 --> Controller Class Initialized
INFO - 2016-02-23 10:47:41 --> Model Class Initialized
INFO - 2016-02-23 10:47:41 --> Model Class Initialized
INFO - 2016-02-23 10:47:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:47:41 --> Pagination Class Initialized
INFO - 2016-02-23 10:47:41 --> Helper loaded: text_helper
INFO - 2016-02-23 10:47:41 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:47:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:47:41 --> Final output sent to browser
DEBUG - 2016-02-23 13:47:41 --> Total execution time: 1.1202
INFO - 2016-02-23 10:47:56 --> Config Class Initialized
INFO - 2016-02-23 10:47:56 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:47:56 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:47:56 --> Utf8 Class Initialized
INFO - 2016-02-23 10:47:56 --> URI Class Initialized
DEBUG - 2016-02-23 10:47:56 --> No URI present. Default controller set.
INFO - 2016-02-23 10:47:56 --> Router Class Initialized
INFO - 2016-02-23 10:47:56 --> Output Class Initialized
INFO - 2016-02-23 10:47:56 --> Security Class Initialized
DEBUG - 2016-02-23 10:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:47:56 --> Input Class Initialized
INFO - 2016-02-23 10:47:56 --> Language Class Initialized
INFO - 2016-02-23 10:47:56 --> Loader Class Initialized
INFO - 2016-02-23 10:47:56 --> Helper loaded: url_helper
INFO - 2016-02-23 10:47:56 --> Helper loaded: file_helper
INFO - 2016-02-23 10:47:56 --> Helper loaded: date_helper
INFO - 2016-02-23 10:47:56 --> Helper loaded: form_helper
INFO - 2016-02-23 10:47:56 --> Database Driver Class Initialized
INFO - 2016-02-23 10:47:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:47:57 --> Controller Class Initialized
INFO - 2016-02-23 10:47:57 --> Model Class Initialized
INFO - 2016-02-23 10:47:57 --> Model Class Initialized
INFO - 2016-02-23 10:47:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:47:57 --> Pagination Class Initialized
INFO - 2016-02-23 10:47:57 --> Helper loaded: text_helper
INFO - 2016-02-23 10:47:57 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:47:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:47:57 --> Final output sent to browser
DEBUG - 2016-02-23 13:47:57 --> Total execution time: 1.1296
INFO - 2016-02-23 10:48:29 --> Config Class Initialized
INFO - 2016-02-23 10:48:29 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:48:29 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:48:29 --> Utf8 Class Initialized
INFO - 2016-02-23 10:48:29 --> URI Class Initialized
DEBUG - 2016-02-23 10:48:29 --> No URI present. Default controller set.
INFO - 2016-02-23 10:48:29 --> Router Class Initialized
INFO - 2016-02-23 10:48:29 --> Output Class Initialized
INFO - 2016-02-23 10:48:29 --> Security Class Initialized
DEBUG - 2016-02-23 10:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:48:29 --> Input Class Initialized
INFO - 2016-02-23 10:48:29 --> Language Class Initialized
INFO - 2016-02-23 10:48:29 --> Loader Class Initialized
INFO - 2016-02-23 10:48:29 --> Helper loaded: url_helper
INFO - 2016-02-23 10:48:29 --> Helper loaded: file_helper
INFO - 2016-02-23 10:48:29 --> Helper loaded: date_helper
INFO - 2016-02-23 10:48:29 --> Helper loaded: form_helper
INFO - 2016-02-23 10:48:29 --> Database Driver Class Initialized
INFO - 2016-02-23 10:48:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:48:30 --> Controller Class Initialized
INFO - 2016-02-23 10:48:30 --> Model Class Initialized
INFO - 2016-02-23 10:48:30 --> Model Class Initialized
INFO - 2016-02-23 10:48:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:48:30 --> Pagination Class Initialized
INFO - 2016-02-23 10:48:30 --> Helper loaded: text_helper
INFO - 2016-02-23 10:48:30 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:48:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:48:30 --> Final output sent to browser
DEBUG - 2016-02-23 13:48:30 --> Total execution time: 1.1468
INFO - 2016-02-23 10:49:24 --> Config Class Initialized
INFO - 2016-02-23 10:49:24 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:49:24 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:49:24 --> Utf8 Class Initialized
INFO - 2016-02-23 10:49:24 --> URI Class Initialized
DEBUG - 2016-02-23 10:49:24 --> No URI present. Default controller set.
INFO - 2016-02-23 10:49:24 --> Router Class Initialized
INFO - 2016-02-23 10:49:24 --> Output Class Initialized
INFO - 2016-02-23 10:49:24 --> Security Class Initialized
DEBUG - 2016-02-23 10:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:49:24 --> Input Class Initialized
INFO - 2016-02-23 10:49:24 --> Language Class Initialized
INFO - 2016-02-23 10:49:24 --> Loader Class Initialized
INFO - 2016-02-23 10:49:24 --> Helper loaded: url_helper
INFO - 2016-02-23 10:49:24 --> Helper loaded: file_helper
INFO - 2016-02-23 10:49:24 --> Helper loaded: date_helper
INFO - 2016-02-23 10:49:24 --> Helper loaded: form_helper
INFO - 2016-02-23 10:49:24 --> Database Driver Class Initialized
INFO - 2016-02-23 10:49:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:49:25 --> Controller Class Initialized
INFO - 2016-02-23 10:49:25 --> Model Class Initialized
INFO - 2016-02-23 10:49:25 --> Model Class Initialized
INFO - 2016-02-23 10:49:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:49:25 --> Pagination Class Initialized
INFO - 2016-02-23 10:49:25 --> Helper loaded: text_helper
INFO - 2016-02-23 10:49:25 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:49:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:49:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:49:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:49:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:49:25 --> Final output sent to browser
DEBUG - 2016-02-23 13:49:25 --> Total execution time: 1.1186
INFO - 2016-02-23 10:50:18 --> Config Class Initialized
INFO - 2016-02-23 10:50:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:50:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:50:18 --> Utf8 Class Initialized
INFO - 2016-02-23 10:50:18 --> URI Class Initialized
INFO - 2016-02-23 10:50:18 --> Router Class Initialized
INFO - 2016-02-23 10:50:18 --> Output Class Initialized
INFO - 2016-02-23 10:50:18 --> Security Class Initialized
DEBUG - 2016-02-23 10:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:50:18 --> Input Class Initialized
INFO - 2016-02-23 10:50:18 --> Language Class Initialized
INFO - 2016-02-23 10:50:18 --> Loader Class Initialized
INFO - 2016-02-23 10:50:18 --> Helper loaded: url_helper
INFO - 2016-02-23 10:50:18 --> Helper loaded: file_helper
INFO - 2016-02-23 10:50:18 --> Helper loaded: date_helper
INFO - 2016-02-23 10:50:18 --> Helper loaded: form_helper
INFO - 2016-02-23 10:50:18 --> Database Driver Class Initialized
INFO - 2016-02-23 10:50:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:50:19 --> Controller Class Initialized
INFO - 2016-02-23 10:50:19 --> Model Class Initialized
INFO - 2016-02-23 10:50:19 --> Model Class Initialized
INFO - 2016-02-23 10:50:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:50:19 --> Pagination Class Initialized
INFO - 2016-02-23 10:50:19 --> Helper loaded: text_helper
INFO - 2016-02-23 10:50:19 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:50:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:50:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:50:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 13:50:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:50:19 --> Final output sent to browser
DEBUG - 2016-02-23 13:50:19 --> Total execution time: 1.1359
INFO - 2016-02-23 10:50:20 --> Config Class Initialized
INFO - 2016-02-23 10:50:20 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:50:20 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:50:20 --> Utf8 Class Initialized
INFO - 2016-02-23 10:50:20 --> URI Class Initialized
INFO - 2016-02-23 10:50:20 --> Router Class Initialized
INFO - 2016-02-23 10:50:20 --> Output Class Initialized
INFO - 2016-02-23 10:50:20 --> Security Class Initialized
DEBUG - 2016-02-23 10:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:50:20 --> Input Class Initialized
INFO - 2016-02-23 10:50:20 --> Language Class Initialized
INFO - 2016-02-23 10:50:20 --> Loader Class Initialized
INFO - 2016-02-23 10:50:20 --> Helper loaded: url_helper
INFO - 2016-02-23 10:50:20 --> Helper loaded: file_helper
INFO - 2016-02-23 10:50:20 --> Helper loaded: date_helper
INFO - 2016-02-23 10:50:20 --> Helper loaded: form_helper
INFO - 2016-02-23 10:50:20 --> Database Driver Class Initialized
INFO - 2016-02-23 10:50:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:50:21 --> Controller Class Initialized
INFO - 2016-02-23 10:50:21 --> Model Class Initialized
INFO - 2016-02-23 10:50:21 --> Model Class Initialized
INFO - 2016-02-23 10:50:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:50:21 --> Pagination Class Initialized
INFO - 2016-02-23 10:50:21 --> Helper loaded: text_helper
INFO - 2016-02-23 10:50:21 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 13:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 13:50:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:50:21 --> Final output sent to browser
DEBUG - 2016-02-23 13:50:21 --> Total execution time: 1.1506
INFO - 2016-02-23 10:50:31 --> Config Class Initialized
INFO - 2016-02-23 10:50:31 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:50:31 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:50:31 --> Utf8 Class Initialized
INFO - 2016-02-23 10:50:31 --> URI Class Initialized
DEBUG - 2016-02-23 10:50:31 --> No URI present. Default controller set.
INFO - 2016-02-23 10:50:31 --> Router Class Initialized
INFO - 2016-02-23 10:50:31 --> Output Class Initialized
INFO - 2016-02-23 10:50:31 --> Security Class Initialized
DEBUG - 2016-02-23 10:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:50:31 --> Input Class Initialized
INFO - 2016-02-23 10:50:31 --> Language Class Initialized
INFO - 2016-02-23 10:50:31 --> Loader Class Initialized
INFO - 2016-02-23 10:50:31 --> Helper loaded: url_helper
INFO - 2016-02-23 10:50:31 --> Helper loaded: file_helper
INFO - 2016-02-23 10:50:31 --> Helper loaded: date_helper
INFO - 2016-02-23 10:50:31 --> Helper loaded: form_helper
INFO - 2016-02-23 10:50:31 --> Database Driver Class Initialized
INFO - 2016-02-23 10:50:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:50:32 --> Controller Class Initialized
INFO - 2016-02-23 10:50:32 --> Model Class Initialized
INFO - 2016-02-23 10:50:32 --> Model Class Initialized
INFO - 2016-02-23 10:50:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:50:32 --> Pagination Class Initialized
INFO - 2016-02-23 10:50:32 --> Helper loaded: text_helper
INFO - 2016-02-23 10:50:32 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:50:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:50:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:50:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:50:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:50:32 --> Final output sent to browser
DEBUG - 2016-02-23 13:50:32 --> Total execution time: 1.1046
INFO - 2016-02-23 10:50:38 --> Config Class Initialized
INFO - 2016-02-23 10:50:38 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:50:38 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:50:38 --> Utf8 Class Initialized
INFO - 2016-02-23 10:50:38 --> URI Class Initialized
DEBUG - 2016-02-23 10:50:38 --> No URI present. Default controller set.
INFO - 2016-02-23 10:50:38 --> Router Class Initialized
INFO - 2016-02-23 10:50:38 --> Output Class Initialized
INFO - 2016-02-23 10:50:38 --> Security Class Initialized
DEBUG - 2016-02-23 10:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:50:38 --> Input Class Initialized
INFO - 2016-02-23 10:50:38 --> Language Class Initialized
INFO - 2016-02-23 10:50:38 --> Loader Class Initialized
INFO - 2016-02-23 10:50:38 --> Helper loaded: url_helper
INFO - 2016-02-23 10:50:38 --> Helper loaded: file_helper
INFO - 2016-02-23 10:50:38 --> Helper loaded: date_helper
INFO - 2016-02-23 10:50:38 --> Helper loaded: form_helper
INFO - 2016-02-23 10:50:38 --> Database Driver Class Initialized
INFO - 2016-02-23 10:50:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:50:39 --> Controller Class Initialized
INFO - 2016-02-23 10:50:39 --> Model Class Initialized
INFO - 2016-02-23 10:50:39 --> Model Class Initialized
INFO - 2016-02-23 10:50:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:50:39 --> Pagination Class Initialized
INFO - 2016-02-23 10:50:39 --> Helper loaded: text_helper
INFO - 2016-02-23 10:50:39 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:50:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:50:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:50:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:50:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:50:39 --> Final output sent to browser
DEBUG - 2016-02-23 13:50:39 --> Total execution time: 1.1330
INFO - 2016-02-23 10:51:03 --> Config Class Initialized
INFO - 2016-02-23 10:51:03 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:51:03 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:51:03 --> Utf8 Class Initialized
INFO - 2016-02-23 10:51:03 --> URI Class Initialized
DEBUG - 2016-02-23 10:51:03 --> No URI present. Default controller set.
INFO - 2016-02-23 10:51:03 --> Router Class Initialized
INFO - 2016-02-23 10:51:03 --> Output Class Initialized
INFO - 2016-02-23 10:51:03 --> Security Class Initialized
DEBUG - 2016-02-23 10:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:51:03 --> Input Class Initialized
INFO - 2016-02-23 10:51:03 --> Language Class Initialized
INFO - 2016-02-23 10:51:03 --> Loader Class Initialized
INFO - 2016-02-23 10:51:03 --> Helper loaded: url_helper
INFO - 2016-02-23 10:51:03 --> Helper loaded: file_helper
INFO - 2016-02-23 10:51:03 --> Helper loaded: date_helper
INFO - 2016-02-23 10:51:03 --> Helper loaded: form_helper
INFO - 2016-02-23 10:51:03 --> Database Driver Class Initialized
INFO - 2016-02-23 10:51:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:51:04 --> Controller Class Initialized
INFO - 2016-02-23 10:51:04 --> Model Class Initialized
INFO - 2016-02-23 10:51:04 --> Model Class Initialized
INFO - 2016-02-23 10:51:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:51:04 --> Pagination Class Initialized
INFO - 2016-02-23 10:51:04 --> Helper loaded: text_helper
INFO - 2016-02-23 10:51:04 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:51:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:51:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:51:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:51:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:51:04 --> Final output sent to browser
DEBUG - 2016-02-23 13:51:04 --> Total execution time: 1.1247
INFO - 2016-02-23 10:51:25 --> Config Class Initialized
INFO - 2016-02-23 10:51:25 --> Hooks Class Initialized
DEBUG - 2016-02-23 10:51:25 --> UTF-8 Support Enabled
INFO - 2016-02-23 10:51:25 --> Utf8 Class Initialized
INFO - 2016-02-23 10:51:25 --> URI Class Initialized
DEBUG - 2016-02-23 10:51:25 --> No URI present. Default controller set.
INFO - 2016-02-23 10:51:25 --> Router Class Initialized
INFO - 2016-02-23 10:51:25 --> Output Class Initialized
INFO - 2016-02-23 10:51:25 --> Security Class Initialized
DEBUG - 2016-02-23 10:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 10:51:25 --> Input Class Initialized
INFO - 2016-02-23 10:51:25 --> Language Class Initialized
INFO - 2016-02-23 10:51:25 --> Loader Class Initialized
INFO - 2016-02-23 10:51:25 --> Helper loaded: url_helper
INFO - 2016-02-23 10:51:26 --> Helper loaded: file_helper
INFO - 2016-02-23 10:51:26 --> Helper loaded: date_helper
INFO - 2016-02-23 10:51:26 --> Helper loaded: form_helper
INFO - 2016-02-23 10:51:26 --> Database Driver Class Initialized
INFO - 2016-02-23 10:51:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 10:51:27 --> Controller Class Initialized
INFO - 2016-02-23 10:51:27 --> Model Class Initialized
INFO - 2016-02-23 10:51:27 --> Model Class Initialized
INFO - 2016-02-23 10:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 10:51:27 --> Pagination Class Initialized
INFO - 2016-02-23 10:51:27 --> Helper loaded: text_helper
INFO - 2016-02-23 10:51:27 --> Helper loaded: cookie_helper
INFO - 2016-02-23 13:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 13:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 13:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 13:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 13:51:27 --> Final output sent to browser
DEBUG - 2016-02-23 13:51:27 --> Total execution time: 1.1358
INFO - 2016-02-23 11:07:12 --> Config Class Initialized
INFO - 2016-02-23 11:07:12 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:07:12 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:07:12 --> Utf8 Class Initialized
INFO - 2016-02-23 11:07:12 --> URI Class Initialized
DEBUG - 2016-02-23 11:07:12 --> No URI present. Default controller set.
INFO - 2016-02-23 11:07:12 --> Router Class Initialized
INFO - 2016-02-23 11:07:12 --> Output Class Initialized
INFO - 2016-02-23 11:07:12 --> Security Class Initialized
DEBUG - 2016-02-23 11:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:07:12 --> Input Class Initialized
INFO - 2016-02-23 11:07:12 --> Language Class Initialized
INFO - 2016-02-23 11:07:12 --> Loader Class Initialized
INFO - 2016-02-23 11:07:12 --> Helper loaded: url_helper
INFO - 2016-02-23 11:07:12 --> Helper loaded: file_helper
INFO - 2016-02-23 11:07:12 --> Helper loaded: date_helper
INFO - 2016-02-23 11:07:12 --> Helper loaded: form_helper
INFO - 2016-02-23 11:07:12 --> Database Driver Class Initialized
INFO - 2016-02-23 11:07:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:07:13 --> Controller Class Initialized
INFO - 2016-02-23 11:07:13 --> Model Class Initialized
INFO - 2016-02-23 11:07:13 --> Model Class Initialized
INFO - 2016-02-23 11:07:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:07:13 --> Pagination Class Initialized
INFO - 2016-02-23 11:07:13 --> Helper loaded: text_helper
INFO - 2016-02-23 11:07:13 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:07:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:07:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:07:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:07:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:07:13 --> Final output sent to browser
DEBUG - 2016-02-23 14:07:13 --> Total execution time: 1.1147
INFO - 2016-02-23 11:07:14 --> Config Class Initialized
INFO - 2016-02-23 11:07:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:07:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:07:14 --> Utf8 Class Initialized
INFO - 2016-02-23 11:07:14 --> URI Class Initialized
INFO - 2016-02-23 11:07:14 --> Router Class Initialized
INFO - 2016-02-23 11:07:14 --> Output Class Initialized
INFO - 2016-02-23 11:07:14 --> Security Class Initialized
DEBUG - 2016-02-23 11:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:07:14 --> Input Class Initialized
INFO - 2016-02-23 11:07:14 --> Language Class Initialized
INFO - 2016-02-23 11:07:14 --> Loader Class Initialized
INFO - 2016-02-23 11:07:14 --> Helper loaded: url_helper
INFO - 2016-02-23 11:07:14 --> Helper loaded: file_helper
INFO - 2016-02-23 11:07:14 --> Helper loaded: date_helper
INFO - 2016-02-23 11:07:14 --> Helper loaded: form_helper
INFO - 2016-02-23 11:07:14 --> Database Driver Class Initialized
INFO - 2016-02-23 11:07:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:07:15 --> Controller Class Initialized
INFO - 2016-02-23 11:07:15 --> Model Class Initialized
INFO - 2016-02-23 11:07:15 --> Model Class Initialized
INFO - 2016-02-23 11:07:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:07:15 --> Pagination Class Initialized
INFO - 2016-02-23 11:07:15 --> Helper loaded: text_helper
INFO - 2016-02-23 11:07:15 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 14:07:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:07:15 --> Final output sent to browser
DEBUG - 2016-02-23 14:07:15 --> Total execution time: 1.1199
INFO - 2016-02-23 11:09:05 --> Config Class Initialized
INFO - 2016-02-23 11:09:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:09:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:09:05 --> Utf8 Class Initialized
INFO - 2016-02-23 11:09:05 --> URI Class Initialized
DEBUG - 2016-02-23 11:09:05 --> No URI present. Default controller set.
INFO - 2016-02-23 11:09:05 --> Router Class Initialized
INFO - 2016-02-23 11:09:05 --> Output Class Initialized
INFO - 2016-02-23 11:09:05 --> Security Class Initialized
DEBUG - 2016-02-23 11:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:09:05 --> Input Class Initialized
INFO - 2016-02-23 11:09:05 --> Language Class Initialized
INFO - 2016-02-23 11:09:05 --> Loader Class Initialized
INFO - 2016-02-23 11:09:05 --> Helper loaded: url_helper
INFO - 2016-02-23 11:09:05 --> Helper loaded: file_helper
INFO - 2016-02-23 11:09:05 --> Helper loaded: date_helper
INFO - 2016-02-23 11:09:05 --> Helper loaded: form_helper
INFO - 2016-02-23 11:09:05 --> Database Driver Class Initialized
INFO - 2016-02-23 11:09:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:09:06 --> Controller Class Initialized
INFO - 2016-02-23 11:09:06 --> Model Class Initialized
INFO - 2016-02-23 11:09:06 --> Model Class Initialized
INFO - 2016-02-23 11:09:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:09:06 --> Pagination Class Initialized
INFO - 2016-02-23 11:09:06 --> Helper loaded: text_helper
INFO - 2016-02-23 11:09:06 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:09:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:09:06 --> Final output sent to browser
DEBUG - 2016-02-23 14:09:06 --> Total execution time: 1.1488
INFO - 2016-02-23 11:09:19 --> Config Class Initialized
INFO - 2016-02-23 11:09:19 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:09:19 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:09:19 --> Utf8 Class Initialized
INFO - 2016-02-23 11:09:19 --> URI Class Initialized
DEBUG - 2016-02-23 11:09:19 --> No URI present. Default controller set.
INFO - 2016-02-23 11:09:19 --> Router Class Initialized
INFO - 2016-02-23 11:09:19 --> Output Class Initialized
INFO - 2016-02-23 11:09:19 --> Security Class Initialized
DEBUG - 2016-02-23 11:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:09:19 --> Input Class Initialized
INFO - 2016-02-23 11:09:19 --> Language Class Initialized
INFO - 2016-02-23 11:09:19 --> Loader Class Initialized
INFO - 2016-02-23 11:09:19 --> Helper loaded: url_helper
INFO - 2016-02-23 11:09:19 --> Helper loaded: file_helper
INFO - 2016-02-23 11:09:19 --> Helper loaded: date_helper
INFO - 2016-02-23 11:09:19 --> Helper loaded: form_helper
INFO - 2016-02-23 11:09:19 --> Database Driver Class Initialized
INFO - 2016-02-23 11:09:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:09:20 --> Controller Class Initialized
INFO - 2016-02-23 11:09:20 --> Model Class Initialized
INFO - 2016-02-23 11:09:20 --> Model Class Initialized
INFO - 2016-02-23 11:09:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:09:20 --> Pagination Class Initialized
INFO - 2016-02-23 11:09:20 --> Helper loaded: text_helper
INFO - 2016-02-23 11:09:20 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:09:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:09:20 --> Final output sent to browser
DEBUG - 2016-02-23 14:09:20 --> Total execution time: 1.1180
INFO - 2016-02-23 11:09:32 --> Config Class Initialized
INFO - 2016-02-23 11:09:32 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:09:32 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:09:32 --> Utf8 Class Initialized
INFO - 2016-02-23 11:09:32 --> URI Class Initialized
DEBUG - 2016-02-23 11:09:32 --> No URI present. Default controller set.
INFO - 2016-02-23 11:09:32 --> Router Class Initialized
INFO - 2016-02-23 11:09:32 --> Output Class Initialized
INFO - 2016-02-23 11:09:32 --> Security Class Initialized
DEBUG - 2016-02-23 11:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:09:32 --> Input Class Initialized
INFO - 2016-02-23 11:09:32 --> Language Class Initialized
INFO - 2016-02-23 11:09:32 --> Loader Class Initialized
INFO - 2016-02-23 11:09:32 --> Helper loaded: url_helper
INFO - 2016-02-23 11:09:32 --> Helper loaded: file_helper
INFO - 2016-02-23 11:09:32 --> Helper loaded: date_helper
INFO - 2016-02-23 11:09:32 --> Helper loaded: form_helper
INFO - 2016-02-23 11:09:32 --> Database Driver Class Initialized
INFO - 2016-02-23 11:09:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:09:33 --> Controller Class Initialized
INFO - 2016-02-23 11:09:33 --> Model Class Initialized
INFO - 2016-02-23 11:09:33 --> Model Class Initialized
INFO - 2016-02-23 11:09:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:09:33 --> Pagination Class Initialized
INFO - 2016-02-23 11:09:33 --> Helper loaded: text_helper
INFO - 2016-02-23 11:09:33 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:09:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:09:33 --> Final output sent to browser
DEBUG - 2016-02-23 14:09:33 --> Total execution time: 1.1218
INFO - 2016-02-23 11:21:27 --> Config Class Initialized
INFO - 2016-02-23 11:21:27 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:21:27 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:21:27 --> Utf8 Class Initialized
INFO - 2016-02-23 11:21:27 --> URI Class Initialized
INFO - 2016-02-23 11:21:27 --> Router Class Initialized
INFO - 2016-02-23 11:21:27 --> Output Class Initialized
INFO - 2016-02-23 11:21:27 --> Security Class Initialized
DEBUG - 2016-02-23 11:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:21:27 --> Input Class Initialized
INFO - 2016-02-23 11:21:27 --> Language Class Initialized
INFO - 2016-02-23 11:21:27 --> Loader Class Initialized
INFO - 2016-02-23 11:21:27 --> Helper loaded: url_helper
INFO - 2016-02-23 11:21:27 --> Helper loaded: file_helper
INFO - 2016-02-23 11:21:27 --> Helper loaded: date_helper
INFO - 2016-02-23 11:21:27 --> Helper loaded: form_helper
INFO - 2016-02-23 11:21:27 --> Database Driver Class Initialized
INFO - 2016-02-23 11:21:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:21:29 --> Controller Class Initialized
INFO - 2016-02-23 11:21:29 --> Model Class Initialized
INFO - 2016-02-23 11:21:29 --> Model Class Initialized
INFO - 2016-02-23 11:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:21:29 --> Pagination Class Initialized
INFO - 2016-02-23 11:21:29 --> Helper loaded: text_helper
INFO - 2016-02-23 11:21:29 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 14:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:21:29 --> Final output sent to browser
DEBUG - 2016-02-23 14:21:29 --> Total execution time: 1.2465
INFO - 2016-02-23 11:21:31 --> Config Class Initialized
INFO - 2016-02-23 11:21:31 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:21:31 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:21:31 --> Utf8 Class Initialized
INFO - 2016-02-23 11:21:31 --> URI Class Initialized
INFO - 2016-02-23 11:21:31 --> Router Class Initialized
INFO - 2016-02-23 11:21:31 --> Output Class Initialized
INFO - 2016-02-23 11:21:31 --> Security Class Initialized
DEBUG - 2016-02-23 11:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:21:31 --> Input Class Initialized
INFO - 2016-02-23 11:21:31 --> Language Class Initialized
INFO - 2016-02-23 11:21:31 --> Loader Class Initialized
INFO - 2016-02-23 11:21:31 --> Helper loaded: url_helper
INFO - 2016-02-23 11:21:31 --> Helper loaded: file_helper
INFO - 2016-02-23 11:21:31 --> Helper loaded: date_helper
INFO - 2016-02-23 11:21:31 --> Helper loaded: form_helper
INFO - 2016-02-23 11:21:31 --> Database Driver Class Initialized
INFO - 2016-02-23 11:21:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:21:32 --> Controller Class Initialized
INFO - 2016-02-23 11:21:32 --> Model Class Initialized
INFO - 2016-02-23 11:21:32 --> Model Class Initialized
INFO - 2016-02-23 11:21:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:21:32 --> Pagination Class Initialized
INFO - 2016-02-23 11:21:32 --> Helper loaded: text_helper
INFO - 2016-02-23 11:21:32 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 14:21:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:21:32 --> Final output sent to browser
DEBUG - 2016-02-23 14:21:32 --> Total execution time: 1.1435
INFO - 2016-02-23 11:23:01 --> Config Class Initialized
INFO - 2016-02-23 11:23:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:23:01 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:23:01 --> Utf8 Class Initialized
INFO - 2016-02-23 11:23:01 --> URI Class Initialized
INFO - 2016-02-23 11:23:01 --> Router Class Initialized
INFO - 2016-02-23 11:23:01 --> Output Class Initialized
INFO - 2016-02-23 11:23:01 --> Security Class Initialized
DEBUG - 2016-02-23 11:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:23:01 --> Input Class Initialized
INFO - 2016-02-23 11:23:01 --> Language Class Initialized
INFO - 2016-02-23 11:23:01 --> Loader Class Initialized
INFO - 2016-02-23 11:23:01 --> Helper loaded: url_helper
INFO - 2016-02-23 11:23:01 --> Helper loaded: file_helper
INFO - 2016-02-23 11:23:01 --> Helper loaded: date_helper
INFO - 2016-02-23 11:23:01 --> Helper loaded: form_helper
INFO - 2016-02-23 11:23:01 --> Database Driver Class Initialized
INFO - 2016-02-23 11:23:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:23:02 --> Controller Class Initialized
INFO - 2016-02-23 11:23:02 --> Model Class Initialized
INFO - 2016-02-23 11:23:02 --> Model Class Initialized
INFO - 2016-02-23 11:23:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:23:02 --> Pagination Class Initialized
INFO - 2016-02-23 11:23:02 --> Helper loaded: text_helper
INFO - 2016-02-23 11:23:02 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 14:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 14:23:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:23:02 --> Final output sent to browser
DEBUG - 2016-02-23 14:23:02 --> Total execution time: 1.2259
INFO - 2016-02-23 11:23:05 --> Config Class Initialized
INFO - 2016-02-23 11:23:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:23:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:23:05 --> Utf8 Class Initialized
INFO - 2016-02-23 11:23:05 --> URI Class Initialized
INFO - 2016-02-23 11:23:05 --> Router Class Initialized
INFO - 2016-02-23 11:23:05 --> Output Class Initialized
INFO - 2016-02-23 11:23:05 --> Security Class Initialized
DEBUG - 2016-02-23 11:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:23:05 --> Input Class Initialized
INFO - 2016-02-23 11:23:05 --> Language Class Initialized
INFO - 2016-02-23 11:23:05 --> Loader Class Initialized
INFO - 2016-02-23 11:23:05 --> Helper loaded: url_helper
INFO - 2016-02-23 11:23:05 --> Helper loaded: file_helper
INFO - 2016-02-23 11:23:05 --> Helper loaded: date_helper
INFO - 2016-02-23 11:23:05 --> Helper loaded: form_helper
INFO - 2016-02-23 11:23:05 --> Database Driver Class Initialized
INFO - 2016-02-23 11:23:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:23:06 --> Controller Class Initialized
INFO - 2016-02-23 11:23:06 --> Model Class Initialized
INFO - 2016-02-23 11:23:06 --> Model Class Initialized
INFO - 2016-02-23 11:23:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:23:06 --> Pagination Class Initialized
INFO - 2016-02-23 11:23:06 --> Helper loaded: text_helper
INFO - 2016-02-23 11:23:06 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 14:23:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:23:06 --> Final output sent to browser
DEBUG - 2016-02-23 14:23:06 --> Total execution time: 1.1090
INFO - 2016-02-23 11:23:08 --> Config Class Initialized
INFO - 2016-02-23 11:23:08 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:23:08 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:23:08 --> Utf8 Class Initialized
INFO - 2016-02-23 11:23:08 --> URI Class Initialized
INFO - 2016-02-23 11:23:08 --> Router Class Initialized
INFO - 2016-02-23 11:23:08 --> Output Class Initialized
INFO - 2016-02-23 11:23:08 --> Security Class Initialized
DEBUG - 2016-02-23 11:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:23:08 --> Input Class Initialized
INFO - 2016-02-23 11:23:08 --> Language Class Initialized
INFO - 2016-02-23 11:23:08 --> Loader Class Initialized
INFO - 2016-02-23 11:23:08 --> Helper loaded: url_helper
INFO - 2016-02-23 11:23:08 --> Helper loaded: file_helper
INFO - 2016-02-23 11:23:08 --> Helper loaded: date_helper
INFO - 2016-02-23 11:23:08 --> Helper loaded: form_helper
INFO - 2016-02-23 11:23:08 --> Database Driver Class Initialized
INFO - 2016-02-23 11:23:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:23:09 --> Controller Class Initialized
INFO - 2016-02-23 11:23:09 --> Model Class Initialized
INFO - 2016-02-23 11:23:09 --> Model Class Initialized
INFO - 2016-02-23 11:23:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:23:09 --> Pagination Class Initialized
INFO - 2016-02-23 11:23:09 --> Helper loaded: text_helper
INFO - 2016-02-23 11:23:09 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 14:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 14:23:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:23:09 --> Final output sent to browser
DEBUG - 2016-02-23 14:23:09 --> Total execution time: 1.1258
INFO - 2016-02-23 11:36:52 --> Config Class Initialized
INFO - 2016-02-23 11:36:52 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:36:52 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:36:52 --> Utf8 Class Initialized
INFO - 2016-02-23 11:36:52 --> URI Class Initialized
INFO - 2016-02-23 11:36:52 --> Router Class Initialized
INFO - 2016-02-23 11:36:52 --> Output Class Initialized
INFO - 2016-02-23 11:36:52 --> Security Class Initialized
DEBUG - 2016-02-23 11:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:36:52 --> Input Class Initialized
INFO - 2016-02-23 11:36:52 --> Language Class Initialized
INFO - 2016-02-23 11:36:52 --> Loader Class Initialized
INFO - 2016-02-23 11:36:52 --> Helper loaded: url_helper
INFO - 2016-02-23 11:36:52 --> Helper loaded: file_helper
INFO - 2016-02-23 11:36:52 --> Helper loaded: date_helper
INFO - 2016-02-23 11:36:52 --> Helper loaded: form_helper
INFO - 2016-02-23 11:36:52 --> Database Driver Class Initialized
INFO - 2016-02-23 11:36:52 --> Config Class Initialized
INFO - 2016-02-23 11:36:52 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:36:52 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:36:52 --> Utf8 Class Initialized
INFO - 2016-02-23 11:36:52 --> URI Class Initialized
INFO - 2016-02-23 11:36:52 --> Router Class Initialized
INFO - 2016-02-23 11:36:53 --> Output Class Initialized
INFO - 2016-02-23 11:36:53 --> Security Class Initialized
DEBUG - 2016-02-23 11:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:36:53 --> Input Class Initialized
INFO - 2016-02-23 11:36:53 --> Language Class Initialized
INFO - 2016-02-23 11:36:53 --> Loader Class Initialized
INFO - 2016-02-23 11:36:53 --> Helper loaded: url_helper
INFO - 2016-02-23 11:36:53 --> Helper loaded: file_helper
INFO - 2016-02-23 11:36:53 --> Helper loaded: date_helper
INFO - 2016-02-23 11:36:53 --> Helper loaded: form_helper
INFO - 2016-02-23 11:36:53 --> Database Driver Class Initialized
INFO - 2016-02-23 11:36:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:36:53 --> Controller Class Initialized
INFO - 2016-02-23 11:36:53 --> Model Class Initialized
INFO - 2016-02-23 11:36:53 --> Model Class Initialized
INFO - 2016-02-23 11:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:36:53 --> Pagination Class Initialized
INFO - 2016-02-23 11:36:53 --> Helper loaded: text_helper
INFO - 2016-02-23 11:36:53 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 14:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:36:53 --> Final output sent to browser
DEBUG - 2016-02-23 14:36:53 --> Total execution time: 1.1192
INFO - 2016-02-23 11:36:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:36:54 --> Controller Class Initialized
INFO - 2016-02-23 11:36:54 --> Model Class Initialized
INFO - 2016-02-23 11:36:54 --> Model Class Initialized
INFO - 2016-02-23 11:36:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:36:54 --> Pagination Class Initialized
INFO - 2016-02-23 11:36:54 --> Helper loaded: text_helper
INFO - 2016-02-23 11:36:54 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 14:36:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:36:54 --> Final output sent to browser
DEBUG - 2016-02-23 14:36:54 --> Total execution time: 1.1230
INFO - 2016-02-23 11:36:56 --> Config Class Initialized
INFO - 2016-02-23 11:36:56 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:36:56 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:36:56 --> Utf8 Class Initialized
INFO - 2016-02-23 11:36:56 --> URI Class Initialized
DEBUG - 2016-02-23 11:36:56 --> No URI present. Default controller set.
INFO - 2016-02-23 11:36:56 --> Router Class Initialized
INFO - 2016-02-23 11:36:56 --> Output Class Initialized
INFO - 2016-02-23 11:36:56 --> Security Class Initialized
DEBUG - 2016-02-23 11:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:36:56 --> Input Class Initialized
INFO - 2016-02-23 11:36:56 --> Language Class Initialized
INFO - 2016-02-23 11:36:56 --> Loader Class Initialized
INFO - 2016-02-23 11:36:56 --> Helper loaded: url_helper
INFO - 2016-02-23 11:36:56 --> Helper loaded: file_helper
INFO - 2016-02-23 11:36:56 --> Helper loaded: date_helper
INFO - 2016-02-23 11:36:56 --> Helper loaded: form_helper
INFO - 2016-02-23 11:36:56 --> Database Driver Class Initialized
INFO - 2016-02-23 11:36:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:36:57 --> Controller Class Initialized
INFO - 2016-02-23 11:36:57 --> Model Class Initialized
INFO - 2016-02-23 11:36:57 --> Model Class Initialized
INFO - 2016-02-23 11:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:36:57 --> Pagination Class Initialized
INFO - 2016-02-23 11:36:57 --> Helper loaded: text_helper
INFO - 2016-02-23 11:36:57 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:36:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:36:57 --> Final output sent to browser
DEBUG - 2016-02-23 14:36:57 --> Total execution time: 1.1164
INFO - 2016-02-23 11:41:53 --> Config Class Initialized
INFO - 2016-02-23 11:41:53 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:41:53 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:41:53 --> Utf8 Class Initialized
INFO - 2016-02-23 11:41:53 --> URI Class Initialized
DEBUG - 2016-02-23 11:41:53 --> No URI present. Default controller set.
INFO - 2016-02-23 11:41:53 --> Router Class Initialized
INFO - 2016-02-23 11:41:53 --> Output Class Initialized
INFO - 2016-02-23 11:41:53 --> Security Class Initialized
DEBUG - 2016-02-23 11:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:41:53 --> Input Class Initialized
INFO - 2016-02-23 11:41:53 --> Language Class Initialized
INFO - 2016-02-23 11:41:53 --> Loader Class Initialized
INFO - 2016-02-23 11:41:53 --> Helper loaded: url_helper
INFO - 2016-02-23 11:41:53 --> Helper loaded: file_helper
INFO - 2016-02-23 11:41:53 --> Helper loaded: date_helper
INFO - 2016-02-23 11:41:53 --> Helper loaded: form_helper
INFO - 2016-02-23 11:41:53 --> Database Driver Class Initialized
INFO - 2016-02-23 11:41:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:41:54 --> Controller Class Initialized
INFO - 2016-02-23 11:41:54 --> Model Class Initialized
INFO - 2016-02-23 11:41:54 --> Model Class Initialized
INFO - 2016-02-23 11:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:41:54 --> Pagination Class Initialized
INFO - 2016-02-23 11:41:54 --> Helper loaded: text_helper
INFO - 2016-02-23 11:41:54 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:41:54 --> Final output sent to browser
DEBUG - 2016-02-23 14:41:54 --> Total execution time: 1.1280
INFO - 2016-02-23 11:42:43 --> Config Class Initialized
INFO - 2016-02-23 11:42:43 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:42:43 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:42:43 --> Utf8 Class Initialized
INFO - 2016-02-23 11:42:43 --> URI Class Initialized
DEBUG - 2016-02-23 11:42:43 --> No URI present. Default controller set.
INFO - 2016-02-23 11:42:43 --> Router Class Initialized
INFO - 2016-02-23 11:42:43 --> Output Class Initialized
INFO - 2016-02-23 11:42:43 --> Security Class Initialized
DEBUG - 2016-02-23 11:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:42:43 --> Input Class Initialized
INFO - 2016-02-23 11:42:43 --> Language Class Initialized
INFO - 2016-02-23 11:42:43 --> Loader Class Initialized
INFO - 2016-02-23 11:42:43 --> Helper loaded: url_helper
INFO - 2016-02-23 11:42:43 --> Helper loaded: file_helper
INFO - 2016-02-23 11:42:43 --> Helper loaded: date_helper
INFO - 2016-02-23 11:42:43 --> Helper loaded: form_helper
INFO - 2016-02-23 11:42:43 --> Database Driver Class Initialized
INFO - 2016-02-23 11:42:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:42:44 --> Controller Class Initialized
INFO - 2016-02-23 11:42:44 --> Model Class Initialized
INFO - 2016-02-23 11:42:44 --> Model Class Initialized
INFO - 2016-02-23 11:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:42:44 --> Pagination Class Initialized
INFO - 2016-02-23 11:42:44 --> Helper loaded: text_helper
INFO - 2016-02-23 11:42:44 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:42:44 --> Final output sent to browser
DEBUG - 2016-02-23 14:42:44 --> Total execution time: 1.1250
INFO - 2016-02-23 11:44:06 --> Config Class Initialized
INFO - 2016-02-23 11:44:06 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:44:06 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:44:06 --> Utf8 Class Initialized
INFO - 2016-02-23 11:44:06 --> URI Class Initialized
DEBUG - 2016-02-23 11:44:06 --> No URI present. Default controller set.
INFO - 2016-02-23 11:44:06 --> Router Class Initialized
INFO - 2016-02-23 11:44:06 --> Output Class Initialized
INFO - 2016-02-23 11:44:06 --> Security Class Initialized
DEBUG - 2016-02-23 11:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:44:06 --> Input Class Initialized
INFO - 2016-02-23 11:44:06 --> Language Class Initialized
INFO - 2016-02-23 11:44:06 --> Loader Class Initialized
INFO - 2016-02-23 11:44:06 --> Helper loaded: url_helper
INFO - 2016-02-23 11:44:06 --> Helper loaded: file_helper
INFO - 2016-02-23 11:44:06 --> Helper loaded: date_helper
INFO - 2016-02-23 11:44:06 --> Helper loaded: form_helper
INFO - 2016-02-23 11:44:06 --> Database Driver Class Initialized
INFO - 2016-02-23 11:44:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:44:07 --> Controller Class Initialized
INFO - 2016-02-23 11:44:07 --> Model Class Initialized
INFO - 2016-02-23 11:44:07 --> Model Class Initialized
INFO - 2016-02-23 11:44:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:44:07 --> Pagination Class Initialized
INFO - 2016-02-23 11:44:07 --> Helper loaded: text_helper
INFO - 2016-02-23 11:44:07 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:44:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:44:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:44:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:44:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:44:07 --> Final output sent to browser
DEBUG - 2016-02-23 14:44:07 --> Total execution time: 1.1643
INFO - 2016-02-23 11:44:54 --> Config Class Initialized
INFO - 2016-02-23 11:44:54 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:44:54 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:44:54 --> Utf8 Class Initialized
INFO - 2016-02-23 11:44:54 --> URI Class Initialized
DEBUG - 2016-02-23 11:44:54 --> No URI present. Default controller set.
INFO - 2016-02-23 11:44:54 --> Router Class Initialized
INFO - 2016-02-23 11:44:54 --> Output Class Initialized
INFO - 2016-02-23 11:44:54 --> Security Class Initialized
DEBUG - 2016-02-23 11:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:44:54 --> Input Class Initialized
INFO - 2016-02-23 11:44:54 --> Language Class Initialized
INFO - 2016-02-23 11:44:54 --> Loader Class Initialized
INFO - 2016-02-23 11:44:54 --> Helper loaded: url_helper
INFO - 2016-02-23 11:44:54 --> Helper loaded: file_helper
INFO - 2016-02-23 11:44:54 --> Helper loaded: date_helper
INFO - 2016-02-23 11:44:54 --> Helper loaded: form_helper
INFO - 2016-02-23 11:44:54 --> Database Driver Class Initialized
INFO - 2016-02-23 11:44:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:44:55 --> Controller Class Initialized
INFO - 2016-02-23 11:44:55 --> Model Class Initialized
INFO - 2016-02-23 11:44:55 --> Model Class Initialized
INFO - 2016-02-23 11:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:44:55 --> Pagination Class Initialized
INFO - 2016-02-23 11:44:55 --> Helper loaded: text_helper
INFO - 2016-02-23 11:44:55 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:44:55 --> Final output sent to browser
DEBUG - 2016-02-23 14:44:55 --> Total execution time: 1.1586
INFO - 2016-02-23 11:47:19 --> Config Class Initialized
INFO - 2016-02-23 11:47:19 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:47:19 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:47:19 --> Utf8 Class Initialized
INFO - 2016-02-23 11:47:19 --> URI Class Initialized
DEBUG - 2016-02-23 11:47:19 --> No URI present. Default controller set.
INFO - 2016-02-23 11:47:19 --> Router Class Initialized
INFO - 2016-02-23 11:47:19 --> Output Class Initialized
INFO - 2016-02-23 11:47:19 --> Security Class Initialized
DEBUG - 2016-02-23 11:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:47:19 --> Input Class Initialized
INFO - 2016-02-23 11:47:19 --> Language Class Initialized
INFO - 2016-02-23 11:47:19 --> Loader Class Initialized
INFO - 2016-02-23 11:47:19 --> Helper loaded: url_helper
INFO - 2016-02-23 11:47:19 --> Helper loaded: file_helper
INFO - 2016-02-23 11:47:19 --> Helper loaded: date_helper
INFO - 2016-02-23 11:47:19 --> Helper loaded: form_helper
INFO - 2016-02-23 11:47:19 --> Database Driver Class Initialized
INFO - 2016-02-23 11:47:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:47:20 --> Controller Class Initialized
INFO - 2016-02-23 11:47:20 --> Model Class Initialized
INFO - 2016-02-23 11:47:20 --> Model Class Initialized
INFO - 2016-02-23 11:47:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:47:20 --> Pagination Class Initialized
INFO - 2016-02-23 11:47:20 --> Helper loaded: text_helper
INFO - 2016-02-23 11:47:20 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:47:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:47:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:47:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:47:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:47:20 --> Final output sent to browser
DEBUG - 2016-02-23 14:47:20 --> Total execution time: 1.1176
INFO - 2016-02-23 11:55:53 --> Config Class Initialized
INFO - 2016-02-23 11:55:53 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:55:53 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:55:53 --> Utf8 Class Initialized
INFO - 2016-02-23 11:55:53 --> URI Class Initialized
INFO - 2016-02-23 11:55:53 --> Router Class Initialized
INFO - 2016-02-23 11:55:53 --> Output Class Initialized
INFO - 2016-02-23 11:55:53 --> Security Class Initialized
DEBUG - 2016-02-23 11:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:55:53 --> Input Class Initialized
INFO - 2016-02-23 11:55:53 --> Language Class Initialized
INFO - 2016-02-23 11:55:53 --> Loader Class Initialized
INFO - 2016-02-23 11:55:53 --> Helper loaded: url_helper
INFO - 2016-02-23 11:55:53 --> Helper loaded: file_helper
INFO - 2016-02-23 11:55:53 --> Helper loaded: date_helper
INFO - 2016-02-23 11:55:53 --> Helper loaded: form_helper
INFO - 2016-02-23 11:55:53 --> Database Driver Class Initialized
INFO - 2016-02-23 11:55:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:55:54 --> Controller Class Initialized
INFO - 2016-02-23 11:55:54 --> Model Class Initialized
INFO - 2016-02-23 11:55:54 --> Model Class Initialized
INFO - 2016-02-23 11:55:54 --> Form Validation Class Initialized
INFO - 2016-02-23 11:55:54 --> Helper loaded: text_helper
INFO - 2016-02-23 11:55:54 --> Config Class Initialized
INFO - 2016-02-23 11:55:54 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:55:54 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:55:54 --> Utf8 Class Initialized
INFO - 2016-02-23 11:55:54 --> URI Class Initialized
DEBUG - 2016-02-23 11:55:54 --> No URI present. Default controller set.
INFO - 2016-02-23 11:55:54 --> Router Class Initialized
INFO - 2016-02-23 11:55:54 --> Output Class Initialized
INFO - 2016-02-23 11:55:54 --> Security Class Initialized
DEBUG - 2016-02-23 11:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:55:54 --> Input Class Initialized
INFO - 2016-02-23 11:55:54 --> Language Class Initialized
INFO - 2016-02-23 11:55:54 --> Loader Class Initialized
INFO - 2016-02-23 11:55:54 --> Helper loaded: url_helper
INFO - 2016-02-23 11:55:54 --> Helper loaded: file_helper
INFO - 2016-02-23 11:55:54 --> Helper loaded: date_helper
INFO - 2016-02-23 11:55:54 --> Helper loaded: form_helper
INFO - 2016-02-23 11:55:54 --> Database Driver Class Initialized
INFO - 2016-02-23 11:55:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:55:55 --> Controller Class Initialized
INFO - 2016-02-23 11:55:55 --> Model Class Initialized
INFO - 2016-02-23 11:55:55 --> Model Class Initialized
INFO - 2016-02-23 11:55:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:55:55 --> Pagination Class Initialized
INFO - 2016-02-23 11:55:55 --> Helper loaded: text_helper
INFO - 2016-02-23 11:55:55 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 14:55:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:55:55 --> Final output sent to browser
DEBUG - 2016-02-23 14:55:55 --> Total execution time: 1.0883
INFO - 2016-02-23 11:59:05 --> Config Class Initialized
INFO - 2016-02-23 11:59:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 11:59:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 11:59:05 --> Utf8 Class Initialized
INFO - 2016-02-23 11:59:05 --> URI Class Initialized
INFO - 2016-02-23 11:59:05 --> Router Class Initialized
INFO - 2016-02-23 11:59:05 --> Output Class Initialized
INFO - 2016-02-23 11:59:05 --> Security Class Initialized
DEBUG - 2016-02-23 11:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 11:59:05 --> Input Class Initialized
INFO - 2016-02-23 11:59:05 --> Language Class Initialized
INFO - 2016-02-23 11:59:05 --> Loader Class Initialized
INFO - 2016-02-23 11:59:05 --> Helper loaded: url_helper
INFO - 2016-02-23 11:59:05 --> Helper loaded: file_helper
INFO - 2016-02-23 11:59:05 --> Helper loaded: date_helper
INFO - 2016-02-23 11:59:05 --> Helper loaded: form_helper
INFO - 2016-02-23 11:59:05 --> Database Driver Class Initialized
INFO - 2016-02-23 11:59:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 11:59:06 --> Controller Class Initialized
INFO - 2016-02-23 11:59:06 --> Model Class Initialized
INFO - 2016-02-23 11:59:06 --> Model Class Initialized
INFO - 2016-02-23 11:59:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 11:59:06 --> Pagination Class Initialized
INFO - 2016-02-23 11:59:06 --> Helper loaded: text_helper
INFO - 2016-02-23 11:59:06 --> Helper loaded: cookie_helper
INFO - 2016-02-23 14:59:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 14:59:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 14:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 14:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 14:59:07 --> Final output sent to browser
DEBUG - 2016-02-23 14:59:07 --> Total execution time: 1.1185
INFO - 2016-02-23 12:02:02 --> Config Class Initialized
INFO - 2016-02-23 12:02:02 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:02:02 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:02:02 --> Utf8 Class Initialized
INFO - 2016-02-23 12:02:02 --> URI Class Initialized
DEBUG - 2016-02-23 12:02:02 --> No URI present. Default controller set.
INFO - 2016-02-23 12:02:02 --> Router Class Initialized
INFO - 2016-02-23 12:02:02 --> Output Class Initialized
INFO - 2016-02-23 12:02:02 --> Security Class Initialized
DEBUG - 2016-02-23 12:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:02:02 --> Input Class Initialized
INFO - 2016-02-23 12:02:02 --> Language Class Initialized
INFO - 2016-02-23 12:02:02 --> Loader Class Initialized
INFO - 2016-02-23 12:02:02 --> Helper loaded: url_helper
INFO - 2016-02-23 12:02:02 --> Helper loaded: file_helper
INFO - 2016-02-23 12:02:02 --> Helper loaded: date_helper
INFO - 2016-02-23 12:02:02 --> Helper loaded: form_helper
INFO - 2016-02-23 12:02:02 --> Database Driver Class Initialized
INFO - 2016-02-23 12:02:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:02:03 --> Controller Class Initialized
INFO - 2016-02-23 12:02:03 --> Model Class Initialized
INFO - 2016-02-23 12:02:03 --> Model Class Initialized
INFO - 2016-02-23 12:02:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:02:03 --> Pagination Class Initialized
INFO - 2016-02-23 12:02:03 --> Helper loaded: text_helper
INFO - 2016-02-23 12:02:03 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:02:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:02:03 --> Final output sent to browser
DEBUG - 2016-02-23 15:02:03 --> Total execution time: 1.1187
INFO - 2016-02-23 12:05:35 --> Config Class Initialized
INFO - 2016-02-23 12:05:35 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:05:35 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:05:35 --> Utf8 Class Initialized
INFO - 2016-02-23 12:05:35 --> URI Class Initialized
DEBUG - 2016-02-23 12:05:35 --> No URI present. Default controller set.
INFO - 2016-02-23 12:05:35 --> Router Class Initialized
INFO - 2016-02-23 12:05:35 --> Output Class Initialized
INFO - 2016-02-23 12:05:35 --> Security Class Initialized
DEBUG - 2016-02-23 12:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:05:35 --> Input Class Initialized
INFO - 2016-02-23 12:05:35 --> Language Class Initialized
INFO - 2016-02-23 12:05:35 --> Loader Class Initialized
INFO - 2016-02-23 12:05:35 --> Helper loaded: url_helper
INFO - 2016-02-23 12:05:35 --> Helper loaded: file_helper
INFO - 2016-02-23 12:05:35 --> Helper loaded: date_helper
INFO - 2016-02-23 12:05:35 --> Helper loaded: form_helper
INFO - 2016-02-23 12:05:35 --> Database Driver Class Initialized
INFO - 2016-02-23 12:05:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:05:36 --> Controller Class Initialized
INFO - 2016-02-23 12:05:36 --> Model Class Initialized
INFO - 2016-02-23 12:05:36 --> Model Class Initialized
INFO - 2016-02-23 12:05:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:05:36 --> Pagination Class Initialized
INFO - 2016-02-23 12:05:36 --> Helper loaded: text_helper
INFO - 2016-02-23 12:05:36 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:05:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:05:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:05:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:05:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:05:36 --> Final output sent to browser
DEBUG - 2016-02-23 15:05:36 --> Total execution time: 1.1120
INFO - 2016-02-23 12:07:25 --> Config Class Initialized
INFO - 2016-02-23 12:07:25 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:07:25 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:07:25 --> Utf8 Class Initialized
INFO - 2016-02-23 12:07:25 --> URI Class Initialized
DEBUG - 2016-02-23 12:07:25 --> No URI present. Default controller set.
INFO - 2016-02-23 12:07:25 --> Router Class Initialized
INFO - 2016-02-23 12:07:25 --> Output Class Initialized
INFO - 2016-02-23 12:07:25 --> Security Class Initialized
DEBUG - 2016-02-23 12:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:07:25 --> Input Class Initialized
INFO - 2016-02-23 12:07:25 --> Language Class Initialized
INFO - 2016-02-23 12:07:25 --> Loader Class Initialized
INFO - 2016-02-23 12:07:25 --> Helper loaded: url_helper
INFO - 2016-02-23 12:07:25 --> Helper loaded: file_helper
INFO - 2016-02-23 12:07:25 --> Helper loaded: date_helper
INFO - 2016-02-23 12:07:25 --> Helper loaded: form_helper
INFO - 2016-02-23 12:07:25 --> Database Driver Class Initialized
INFO - 2016-02-23 12:07:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:07:26 --> Controller Class Initialized
INFO - 2016-02-23 12:07:26 --> Model Class Initialized
INFO - 2016-02-23 12:07:26 --> Model Class Initialized
INFO - 2016-02-23 12:07:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:07:26 --> Pagination Class Initialized
INFO - 2016-02-23 12:07:26 --> Helper loaded: text_helper
INFO - 2016-02-23 12:07:26 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:07:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:07:26 --> Final output sent to browser
DEBUG - 2016-02-23 15:07:26 --> Total execution time: 1.1254
INFO - 2016-02-23 12:08:17 --> Config Class Initialized
INFO - 2016-02-23 12:08:17 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:08:17 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:08:17 --> Utf8 Class Initialized
INFO - 2016-02-23 12:08:17 --> URI Class Initialized
DEBUG - 2016-02-23 12:08:17 --> No URI present. Default controller set.
INFO - 2016-02-23 12:08:17 --> Router Class Initialized
INFO - 2016-02-23 12:08:17 --> Output Class Initialized
INFO - 2016-02-23 12:08:17 --> Security Class Initialized
DEBUG - 2016-02-23 12:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:08:17 --> Input Class Initialized
INFO - 2016-02-23 12:08:17 --> Language Class Initialized
INFO - 2016-02-23 12:08:17 --> Loader Class Initialized
INFO - 2016-02-23 12:08:17 --> Helper loaded: url_helper
INFO - 2016-02-23 12:08:17 --> Helper loaded: file_helper
INFO - 2016-02-23 12:08:17 --> Helper loaded: date_helper
INFO - 2016-02-23 12:08:17 --> Helper loaded: form_helper
INFO - 2016-02-23 12:08:17 --> Database Driver Class Initialized
INFO - 2016-02-23 12:08:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:08:18 --> Controller Class Initialized
INFO - 2016-02-23 12:08:18 --> Model Class Initialized
INFO - 2016-02-23 12:08:18 --> Model Class Initialized
INFO - 2016-02-23 12:08:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:08:18 --> Pagination Class Initialized
INFO - 2016-02-23 12:08:18 --> Helper loaded: text_helper
INFO - 2016-02-23 12:08:18 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:08:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:08:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:08:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:08:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:08:18 --> Final output sent to browser
DEBUG - 2016-02-23 15:08:18 --> Total execution time: 1.1281
INFO - 2016-02-23 12:09:47 --> Config Class Initialized
INFO - 2016-02-23 12:09:47 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:09:47 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:09:47 --> Utf8 Class Initialized
INFO - 2016-02-23 12:09:47 --> URI Class Initialized
DEBUG - 2016-02-23 12:09:47 --> No URI present. Default controller set.
INFO - 2016-02-23 12:09:47 --> Router Class Initialized
INFO - 2016-02-23 12:09:47 --> Output Class Initialized
INFO - 2016-02-23 12:09:47 --> Security Class Initialized
DEBUG - 2016-02-23 12:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:09:47 --> Input Class Initialized
INFO - 2016-02-23 12:09:47 --> Language Class Initialized
INFO - 2016-02-23 12:09:47 --> Loader Class Initialized
INFO - 2016-02-23 12:09:47 --> Helper loaded: url_helper
INFO - 2016-02-23 12:09:47 --> Helper loaded: file_helper
INFO - 2016-02-23 12:09:47 --> Helper loaded: date_helper
INFO - 2016-02-23 12:09:47 --> Helper loaded: form_helper
INFO - 2016-02-23 12:09:47 --> Database Driver Class Initialized
INFO - 2016-02-23 12:09:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:09:48 --> Controller Class Initialized
INFO - 2016-02-23 12:09:48 --> Model Class Initialized
INFO - 2016-02-23 12:09:48 --> Model Class Initialized
INFO - 2016-02-23 12:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:09:48 --> Pagination Class Initialized
INFO - 2016-02-23 12:09:48 --> Helper loaded: text_helper
INFO - 2016-02-23 12:09:48 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:09:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:09:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:09:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:09:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:09:48 --> Final output sent to browser
DEBUG - 2016-02-23 15:09:48 --> Total execution time: 1.1396
INFO - 2016-02-23 12:10:11 --> Config Class Initialized
INFO - 2016-02-23 12:10:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:10:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:10:11 --> Utf8 Class Initialized
INFO - 2016-02-23 12:10:11 --> URI Class Initialized
DEBUG - 2016-02-23 12:10:11 --> No URI present. Default controller set.
INFO - 2016-02-23 12:10:11 --> Router Class Initialized
INFO - 2016-02-23 12:10:11 --> Output Class Initialized
INFO - 2016-02-23 12:10:11 --> Security Class Initialized
DEBUG - 2016-02-23 12:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:10:11 --> Input Class Initialized
INFO - 2016-02-23 12:10:11 --> Language Class Initialized
INFO - 2016-02-23 12:10:11 --> Loader Class Initialized
INFO - 2016-02-23 12:10:11 --> Helper loaded: url_helper
INFO - 2016-02-23 12:10:11 --> Helper loaded: file_helper
INFO - 2016-02-23 12:10:11 --> Helper loaded: date_helper
INFO - 2016-02-23 12:10:11 --> Helper loaded: form_helper
INFO - 2016-02-23 12:10:11 --> Database Driver Class Initialized
INFO - 2016-02-23 12:10:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:10:12 --> Controller Class Initialized
INFO - 2016-02-23 12:10:12 --> Model Class Initialized
INFO - 2016-02-23 12:10:12 --> Model Class Initialized
INFO - 2016-02-23 12:10:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:10:12 --> Pagination Class Initialized
INFO - 2016-02-23 12:10:12 --> Helper loaded: text_helper
INFO - 2016-02-23 12:10:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:10:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:10:12 --> Final output sent to browser
DEBUG - 2016-02-23 15:10:12 --> Total execution time: 1.1222
INFO - 2016-02-23 12:13:45 --> Config Class Initialized
INFO - 2016-02-23 12:13:45 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:13:45 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:13:45 --> Utf8 Class Initialized
INFO - 2016-02-23 12:13:45 --> URI Class Initialized
DEBUG - 2016-02-23 12:13:45 --> No URI present. Default controller set.
INFO - 2016-02-23 12:13:45 --> Router Class Initialized
INFO - 2016-02-23 12:13:45 --> Output Class Initialized
INFO - 2016-02-23 12:13:45 --> Security Class Initialized
DEBUG - 2016-02-23 12:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:13:45 --> Input Class Initialized
INFO - 2016-02-23 12:13:45 --> Language Class Initialized
INFO - 2016-02-23 12:13:45 --> Loader Class Initialized
INFO - 2016-02-23 12:13:45 --> Helper loaded: url_helper
INFO - 2016-02-23 12:13:45 --> Helper loaded: file_helper
INFO - 2016-02-23 12:13:45 --> Helper loaded: date_helper
INFO - 2016-02-23 12:13:45 --> Helper loaded: form_helper
INFO - 2016-02-23 12:13:45 --> Database Driver Class Initialized
INFO - 2016-02-23 12:13:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:13:46 --> Controller Class Initialized
INFO - 2016-02-23 12:13:46 --> Model Class Initialized
INFO - 2016-02-23 12:13:46 --> Model Class Initialized
INFO - 2016-02-23 12:13:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:13:46 --> Pagination Class Initialized
INFO - 2016-02-23 12:13:46 --> Helper loaded: text_helper
INFO - 2016-02-23 12:13:46 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:13:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:13:46 --> Final output sent to browser
DEBUG - 2016-02-23 15:13:46 --> Total execution time: 1.1540
INFO - 2016-02-23 12:15:50 --> Config Class Initialized
INFO - 2016-02-23 12:15:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:15:50 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:15:50 --> Utf8 Class Initialized
INFO - 2016-02-23 12:15:50 --> URI Class Initialized
DEBUG - 2016-02-23 12:15:50 --> No URI present. Default controller set.
INFO - 2016-02-23 12:15:50 --> Router Class Initialized
INFO - 2016-02-23 12:15:50 --> Output Class Initialized
INFO - 2016-02-23 12:15:50 --> Security Class Initialized
DEBUG - 2016-02-23 12:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:15:50 --> Input Class Initialized
INFO - 2016-02-23 12:15:50 --> Language Class Initialized
INFO - 2016-02-23 12:15:50 --> Loader Class Initialized
INFO - 2016-02-23 12:15:50 --> Helper loaded: url_helper
INFO - 2016-02-23 12:15:50 --> Helper loaded: file_helper
INFO - 2016-02-23 12:15:50 --> Helper loaded: date_helper
INFO - 2016-02-23 12:15:50 --> Helper loaded: form_helper
INFO - 2016-02-23 12:15:50 --> Database Driver Class Initialized
INFO - 2016-02-23 12:15:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:15:51 --> Controller Class Initialized
INFO - 2016-02-23 12:15:51 --> Model Class Initialized
INFO - 2016-02-23 12:15:51 --> Model Class Initialized
INFO - 2016-02-23 12:15:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:15:51 --> Pagination Class Initialized
INFO - 2016-02-23 12:15:51 --> Helper loaded: text_helper
INFO - 2016-02-23 12:15:51 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:15:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:15:51 --> Final output sent to browser
DEBUG - 2016-02-23 15:15:51 --> Total execution time: 1.1238
INFO - 2016-02-23 12:16:03 --> Config Class Initialized
INFO - 2016-02-23 12:16:03 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:16:03 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:16:03 --> Utf8 Class Initialized
INFO - 2016-02-23 12:16:03 --> URI Class Initialized
DEBUG - 2016-02-23 12:16:03 --> No URI present. Default controller set.
INFO - 2016-02-23 12:16:03 --> Router Class Initialized
INFO - 2016-02-23 12:16:03 --> Output Class Initialized
INFO - 2016-02-23 12:16:03 --> Security Class Initialized
DEBUG - 2016-02-23 12:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:16:03 --> Input Class Initialized
INFO - 2016-02-23 12:16:03 --> Language Class Initialized
INFO - 2016-02-23 12:16:03 --> Loader Class Initialized
INFO - 2016-02-23 12:16:03 --> Helper loaded: url_helper
INFO - 2016-02-23 12:16:03 --> Helper loaded: file_helper
INFO - 2016-02-23 12:16:03 --> Helper loaded: date_helper
INFO - 2016-02-23 12:16:03 --> Helper loaded: form_helper
INFO - 2016-02-23 12:16:03 --> Database Driver Class Initialized
INFO - 2016-02-23 12:16:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:16:04 --> Controller Class Initialized
INFO - 2016-02-23 12:16:04 --> Model Class Initialized
INFO - 2016-02-23 12:16:04 --> Model Class Initialized
INFO - 2016-02-23 12:16:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:16:04 --> Pagination Class Initialized
INFO - 2016-02-23 12:16:04 --> Helper loaded: text_helper
INFO - 2016-02-23 12:16:04 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:16:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:16:04 --> Final output sent to browser
DEBUG - 2016-02-23 15:16:04 --> Total execution time: 1.1188
INFO - 2016-02-23 12:17:18 --> Config Class Initialized
INFO - 2016-02-23 12:17:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:17:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:17:18 --> Utf8 Class Initialized
INFO - 2016-02-23 12:17:18 --> URI Class Initialized
DEBUG - 2016-02-23 12:17:18 --> No URI present. Default controller set.
INFO - 2016-02-23 12:17:18 --> Router Class Initialized
INFO - 2016-02-23 12:17:18 --> Output Class Initialized
INFO - 2016-02-23 12:17:18 --> Security Class Initialized
DEBUG - 2016-02-23 12:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:17:18 --> Input Class Initialized
INFO - 2016-02-23 12:17:18 --> Language Class Initialized
INFO - 2016-02-23 12:17:18 --> Loader Class Initialized
INFO - 2016-02-23 12:17:18 --> Helper loaded: url_helper
INFO - 2016-02-23 12:17:18 --> Helper loaded: file_helper
INFO - 2016-02-23 12:17:18 --> Helper loaded: date_helper
INFO - 2016-02-23 12:17:18 --> Helper loaded: form_helper
INFO - 2016-02-23 12:17:18 --> Database Driver Class Initialized
INFO - 2016-02-23 12:17:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:17:19 --> Controller Class Initialized
INFO - 2016-02-23 12:17:19 --> Model Class Initialized
INFO - 2016-02-23 12:17:19 --> Model Class Initialized
INFO - 2016-02-23 12:17:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:17:19 --> Pagination Class Initialized
INFO - 2016-02-23 12:17:19 --> Helper loaded: text_helper
INFO - 2016-02-23 12:17:19 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:17:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:17:19 --> Final output sent to browser
DEBUG - 2016-02-23 15:17:19 --> Total execution time: 1.1103
INFO - 2016-02-23 12:23:03 --> Config Class Initialized
INFO - 2016-02-23 12:23:03 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:23:03 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:23:03 --> Utf8 Class Initialized
INFO - 2016-02-23 12:23:03 --> URI Class Initialized
DEBUG - 2016-02-23 12:23:03 --> No URI present. Default controller set.
INFO - 2016-02-23 12:23:03 --> Router Class Initialized
INFO - 2016-02-23 12:23:03 --> Output Class Initialized
INFO - 2016-02-23 12:23:03 --> Security Class Initialized
DEBUG - 2016-02-23 12:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:23:03 --> Input Class Initialized
INFO - 2016-02-23 12:23:03 --> Language Class Initialized
INFO - 2016-02-23 12:23:03 --> Loader Class Initialized
INFO - 2016-02-23 12:23:03 --> Helper loaded: url_helper
INFO - 2016-02-23 12:23:03 --> Helper loaded: file_helper
INFO - 2016-02-23 12:23:03 --> Helper loaded: date_helper
INFO - 2016-02-23 12:23:03 --> Helper loaded: form_helper
INFO - 2016-02-23 12:23:03 --> Database Driver Class Initialized
INFO - 2016-02-23 12:23:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:23:04 --> Controller Class Initialized
INFO - 2016-02-23 12:23:04 --> Model Class Initialized
INFO - 2016-02-23 12:23:04 --> Model Class Initialized
INFO - 2016-02-23 12:23:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:23:04 --> Pagination Class Initialized
INFO - 2016-02-23 12:23:04 --> Helper loaded: text_helper
INFO - 2016-02-23 12:23:04 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:23:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:23:04 --> Final output sent to browser
DEBUG - 2016-02-23 15:23:04 --> Total execution time: 1.0921
INFO - 2016-02-23 12:24:23 --> Config Class Initialized
INFO - 2016-02-23 12:24:23 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:24:23 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:24:23 --> Utf8 Class Initialized
INFO - 2016-02-23 12:24:23 --> URI Class Initialized
DEBUG - 2016-02-23 12:24:23 --> No URI present. Default controller set.
INFO - 2016-02-23 12:24:23 --> Router Class Initialized
INFO - 2016-02-23 12:24:23 --> Output Class Initialized
INFO - 2016-02-23 12:24:23 --> Security Class Initialized
DEBUG - 2016-02-23 12:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:24:23 --> Input Class Initialized
INFO - 2016-02-23 12:24:23 --> Language Class Initialized
INFO - 2016-02-23 12:24:23 --> Loader Class Initialized
INFO - 2016-02-23 12:24:23 --> Helper loaded: url_helper
INFO - 2016-02-23 12:24:23 --> Helper loaded: file_helper
INFO - 2016-02-23 12:24:23 --> Helper loaded: date_helper
INFO - 2016-02-23 12:24:23 --> Helper loaded: form_helper
INFO - 2016-02-23 12:24:23 --> Database Driver Class Initialized
INFO - 2016-02-23 12:24:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:24:24 --> Controller Class Initialized
INFO - 2016-02-23 12:24:24 --> Model Class Initialized
INFO - 2016-02-23 12:24:24 --> Model Class Initialized
INFO - 2016-02-23 12:24:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:24:24 --> Pagination Class Initialized
INFO - 2016-02-23 12:24:24 --> Helper loaded: text_helper
INFO - 2016-02-23 12:24:24 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:24:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:24:24 --> Final output sent to browser
DEBUG - 2016-02-23 15:24:24 --> Total execution time: 1.1514
INFO - 2016-02-23 12:39:55 --> Config Class Initialized
INFO - 2016-02-23 12:39:55 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:39:55 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:39:55 --> Utf8 Class Initialized
INFO - 2016-02-23 12:39:55 --> URI Class Initialized
DEBUG - 2016-02-23 12:39:55 --> No URI present. Default controller set.
INFO - 2016-02-23 12:39:55 --> Router Class Initialized
INFO - 2016-02-23 12:39:55 --> Output Class Initialized
INFO - 2016-02-23 12:39:55 --> Security Class Initialized
DEBUG - 2016-02-23 12:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:39:55 --> Input Class Initialized
INFO - 2016-02-23 12:39:55 --> Language Class Initialized
INFO - 2016-02-23 12:39:55 --> Loader Class Initialized
INFO - 2016-02-23 12:39:55 --> Helper loaded: url_helper
INFO - 2016-02-23 12:39:55 --> Helper loaded: file_helper
INFO - 2016-02-23 12:39:55 --> Helper loaded: date_helper
INFO - 2016-02-23 12:39:55 --> Helper loaded: form_helper
INFO - 2016-02-23 12:39:55 --> Database Driver Class Initialized
INFO - 2016-02-23 12:39:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:39:56 --> Controller Class Initialized
INFO - 2016-02-23 12:39:56 --> Model Class Initialized
INFO - 2016-02-23 12:39:56 --> Model Class Initialized
INFO - 2016-02-23 12:39:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:39:56 --> Pagination Class Initialized
INFO - 2016-02-23 12:39:56 --> Helper loaded: text_helper
INFO - 2016-02-23 12:39:56 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:39:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:39:56 --> Final output sent to browser
DEBUG - 2016-02-23 15:39:56 --> Total execution time: 1.1048
INFO - 2016-02-23 12:54:16 --> Config Class Initialized
INFO - 2016-02-23 12:54:16 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:54:16 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:54:16 --> Utf8 Class Initialized
INFO - 2016-02-23 12:54:16 --> URI Class Initialized
INFO - 2016-02-23 12:54:16 --> Router Class Initialized
INFO - 2016-02-23 12:54:16 --> Output Class Initialized
INFO - 2016-02-23 12:54:16 --> Security Class Initialized
DEBUG - 2016-02-23 12:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:54:16 --> Input Class Initialized
INFO - 2016-02-23 12:54:16 --> Language Class Initialized
INFO - 2016-02-23 12:54:16 --> Loader Class Initialized
INFO - 2016-02-23 12:54:16 --> Helper loaded: url_helper
INFO - 2016-02-23 12:54:16 --> Helper loaded: file_helper
INFO - 2016-02-23 12:54:16 --> Helper loaded: date_helper
INFO - 2016-02-23 12:54:16 --> Helper loaded: form_helper
INFO - 2016-02-23 12:54:16 --> Database Driver Class Initialized
INFO - 2016-02-23 12:54:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:54:17 --> Controller Class Initialized
INFO - 2016-02-23 12:54:17 --> Model Class Initialized
INFO - 2016-02-23 12:54:17 --> Model Class Initialized
INFO - 2016-02-23 12:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:54:17 --> Pagination Class Initialized
INFO - 2016-02-23 12:54:17 --> Helper loaded: text_helper
INFO - 2016-02-23 12:54:17 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 15:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:54:17 --> Final output sent to browser
DEBUG - 2016-02-23 15:54:17 --> Total execution time: 1.1444
INFO - 2016-02-23 12:54:50 --> Config Class Initialized
INFO - 2016-02-23 12:54:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 12:54:50 --> UTF-8 Support Enabled
INFO - 2016-02-23 12:54:50 --> Utf8 Class Initialized
INFO - 2016-02-23 12:54:50 --> URI Class Initialized
DEBUG - 2016-02-23 12:54:50 --> No URI present. Default controller set.
INFO - 2016-02-23 12:54:50 --> Router Class Initialized
INFO - 2016-02-23 12:54:50 --> Output Class Initialized
INFO - 2016-02-23 12:54:50 --> Security Class Initialized
DEBUG - 2016-02-23 12:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 12:54:50 --> Input Class Initialized
INFO - 2016-02-23 12:54:50 --> Language Class Initialized
INFO - 2016-02-23 12:54:50 --> Loader Class Initialized
INFO - 2016-02-23 12:54:50 --> Helper loaded: url_helper
INFO - 2016-02-23 12:54:50 --> Helper loaded: file_helper
INFO - 2016-02-23 12:54:50 --> Helper loaded: date_helper
INFO - 2016-02-23 12:54:50 --> Helper loaded: form_helper
INFO - 2016-02-23 12:54:50 --> Database Driver Class Initialized
INFO - 2016-02-23 12:54:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 12:54:51 --> Controller Class Initialized
INFO - 2016-02-23 12:54:51 --> Model Class Initialized
INFO - 2016-02-23 12:54:51 --> Model Class Initialized
INFO - 2016-02-23 12:54:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 12:54:51 --> Pagination Class Initialized
INFO - 2016-02-23 12:54:51 --> Helper loaded: text_helper
INFO - 2016-02-23 12:54:51 --> Helper loaded: cookie_helper
INFO - 2016-02-23 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 15:54:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 15:54:51 --> Final output sent to browser
DEBUG - 2016-02-23 15:54:51 --> Total execution time: 1.1071
INFO - 2016-02-23 13:02:41 --> Config Class Initialized
INFO - 2016-02-23 13:02:41 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:02:41 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:02:41 --> Utf8 Class Initialized
INFO - 2016-02-23 13:02:41 --> URI Class Initialized
INFO - 2016-02-23 13:02:41 --> Router Class Initialized
INFO - 2016-02-23 13:02:41 --> Output Class Initialized
INFO - 2016-02-23 13:02:41 --> Security Class Initialized
DEBUG - 2016-02-23 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:02:41 --> Input Class Initialized
INFO - 2016-02-23 13:02:41 --> Language Class Initialized
INFO - 2016-02-23 13:02:41 --> Loader Class Initialized
INFO - 2016-02-23 13:02:41 --> Helper loaded: url_helper
INFO - 2016-02-23 13:02:41 --> Helper loaded: file_helper
INFO - 2016-02-23 13:02:41 --> Helper loaded: date_helper
INFO - 2016-02-23 13:02:41 --> Helper loaded: form_helper
INFO - 2016-02-23 13:02:41 --> Database Driver Class Initialized
INFO - 2016-02-23 13:02:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:02:42 --> Controller Class Initialized
INFO - 2016-02-23 13:02:42 --> Model Class Initialized
INFO - 2016-02-23 13:02:42 --> Model Class Initialized
INFO - 2016-02-23 13:02:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:02:42 --> Pagination Class Initialized
INFO - 2016-02-23 13:02:42 --> Helper loaded: text_helper
INFO - 2016-02-23 13:02:42 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:02:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:02:42 --> Final output sent to browser
DEBUG - 2016-02-23 16:02:42 --> Total execution time: 1.0925
INFO - 2016-02-23 13:02:43 --> Config Class Initialized
INFO - 2016-02-23 13:02:43 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:02:43 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:02:43 --> Utf8 Class Initialized
INFO - 2016-02-23 13:02:43 --> URI Class Initialized
INFO - 2016-02-23 13:02:43 --> Router Class Initialized
INFO - 2016-02-23 13:02:43 --> Output Class Initialized
INFO - 2016-02-23 13:02:43 --> Security Class Initialized
DEBUG - 2016-02-23 13:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:02:43 --> Input Class Initialized
INFO - 2016-02-23 13:02:43 --> Language Class Initialized
INFO - 2016-02-23 13:02:43 --> Loader Class Initialized
INFO - 2016-02-23 13:02:43 --> Helper loaded: url_helper
INFO - 2016-02-23 13:02:43 --> Helper loaded: file_helper
INFO - 2016-02-23 13:02:43 --> Helper loaded: date_helper
INFO - 2016-02-23 13:02:43 --> Helper loaded: form_helper
INFO - 2016-02-23 13:02:43 --> Database Driver Class Initialized
INFO - 2016-02-23 13:02:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:02:44 --> Controller Class Initialized
INFO - 2016-02-23 13:02:44 --> Model Class Initialized
INFO - 2016-02-23 13:02:44 --> Model Class Initialized
INFO - 2016-02-23 13:02:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:02:44 --> Pagination Class Initialized
INFO - 2016-02-23 13:02:44 --> Helper loaded: text_helper
INFO - 2016-02-23 13:02:44 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:02:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:02:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:02:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:02:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:02:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:02:45 --> Final output sent to browser
DEBUG - 2016-02-23 16:02:45 --> Total execution time: 1.3070
INFO - 2016-02-23 13:05:29 --> Config Class Initialized
INFO - 2016-02-23 13:05:29 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:05:29 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:05:29 --> Utf8 Class Initialized
INFO - 2016-02-23 13:05:29 --> URI Class Initialized
DEBUG - 2016-02-23 13:05:29 --> No URI present. Default controller set.
INFO - 2016-02-23 13:05:29 --> Router Class Initialized
INFO - 2016-02-23 13:05:29 --> Output Class Initialized
INFO - 2016-02-23 13:05:29 --> Security Class Initialized
DEBUG - 2016-02-23 13:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:05:29 --> Input Class Initialized
INFO - 2016-02-23 13:05:29 --> Language Class Initialized
INFO - 2016-02-23 13:05:29 --> Loader Class Initialized
INFO - 2016-02-23 13:05:29 --> Helper loaded: url_helper
INFO - 2016-02-23 13:05:29 --> Helper loaded: file_helper
INFO - 2016-02-23 13:05:29 --> Helper loaded: date_helper
INFO - 2016-02-23 13:05:29 --> Helper loaded: form_helper
INFO - 2016-02-23 13:05:29 --> Database Driver Class Initialized
INFO - 2016-02-23 13:05:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:05:30 --> Controller Class Initialized
INFO - 2016-02-23 13:05:30 --> Model Class Initialized
INFO - 2016-02-23 13:05:30 --> Model Class Initialized
INFO - 2016-02-23 13:05:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:05:30 --> Pagination Class Initialized
INFO - 2016-02-23 13:05:30 --> Helper loaded: text_helper
INFO - 2016-02-23 13:05:30 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:05:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:05:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:05:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:05:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:05:30 --> Final output sent to browser
DEBUG - 2016-02-23 16:05:30 --> Total execution time: 1.1251
INFO - 2016-02-23 13:15:10 --> Config Class Initialized
INFO - 2016-02-23 13:15:10 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:15:10 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:15:10 --> Utf8 Class Initialized
INFO - 2016-02-23 13:15:10 --> URI Class Initialized
INFO - 2016-02-23 13:15:10 --> Router Class Initialized
INFO - 2016-02-23 13:15:10 --> Output Class Initialized
INFO - 2016-02-23 13:15:10 --> Security Class Initialized
DEBUG - 2016-02-23 13:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:15:10 --> Input Class Initialized
INFO - 2016-02-23 13:15:10 --> Language Class Initialized
INFO - 2016-02-23 13:15:10 --> Loader Class Initialized
INFO - 2016-02-23 13:15:10 --> Helper loaded: url_helper
INFO - 2016-02-23 13:15:10 --> Helper loaded: file_helper
INFO - 2016-02-23 13:15:10 --> Helper loaded: date_helper
INFO - 2016-02-23 13:15:10 --> Helper loaded: form_helper
INFO - 2016-02-23 13:15:10 --> Database Driver Class Initialized
INFO - 2016-02-23 13:15:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:15:11 --> Controller Class Initialized
INFO - 2016-02-23 13:15:11 --> Model Class Initialized
INFO - 2016-02-23 13:15:11 --> Model Class Initialized
INFO - 2016-02-23 13:15:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:15:11 --> Pagination Class Initialized
INFO - 2016-02-23 13:15:11 --> Helper loaded: text_helper
INFO - 2016-02-23 13:15:11 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 16:15:11 --> 404 Page Not Found: 
INFO - 2016-02-23 13:19:34 --> Config Class Initialized
INFO - 2016-02-23 13:19:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:19:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:19:34 --> Utf8 Class Initialized
INFO - 2016-02-23 13:19:34 --> URI Class Initialized
DEBUG - 2016-02-23 13:19:34 --> No URI present. Default controller set.
INFO - 2016-02-23 13:19:34 --> Router Class Initialized
INFO - 2016-02-23 13:19:34 --> Output Class Initialized
INFO - 2016-02-23 13:19:34 --> Security Class Initialized
DEBUG - 2016-02-23 13:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:19:34 --> Input Class Initialized
INFO - 2016-02-23 13:19:34 --> Language Class Initialized
INFO - 2016-02-23 13:19:34 --> Loader Class Initialized
INFO - 2016-02-23 13:19:34 --> Helper loaded: url_helper
INFO - 2016-02-23 13:19:34 --> Helper loaded: file_helper
INFO - 2016-02-23 13:19:34 --> Helper loaded: date_helper
INFO - 2016-02-23 13:19:34 --> Helper loaded: form_helper
INFO - 2016-02-23 13:19:34 --> Database Driver Class Initialized
INFO - 2016-02-23 13:19:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:19:36 --> Controller Class Initialized
INFO - 2016-02-23 13:19:36 --> Model Class Initialized
INFO - 2016-02-23 13:19:36 --> Model Class Initialized
INFO - 2016-02-23 13:19:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:19:36 --> Pagination Class Initialized
INFO - 2016-02-23 13:19:36 --> Helper loaded: text_helper
INFO - 2016-02-23 13:19:36 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:19:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:19:36 --> Final output sent to browser
DEBUG - 2016-02-23 16:19:36 --> Total execution time: 1.1650
INFO - 2016-02-23 13:19:37 --> Config Class Initialized
INFO - 2016-02-23 13:19:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:19:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:19:37 --> Utf8 Class Initialized
INFO - 2016-02-23 13:19:37 --> URI Class Initialized
INFO - 2016-02-23 13:19:37 --> Router Class Initialized
INFO - 2016-02-23 13:19:37 --> Output Class Initialized
INFO - 2016-02-23 13:19:37 --> Security Class Initialized
DEBUG - 2016-02-23 13:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:19:37 --> Input Class Initialized
INFO - 2016-02-23 13:19:37 --> Language Class Initialized
INFO - 2016-02-23 13:19:37 --> Loader Class Initialized
INFO - 2016-02-23 13:19:37 --> Helper loaded: url_helper
INFO - 2016-02-23 13:19:37 --> Helper loaded: file_helper
INFO - 2016-02-23 13:19:37 --> Helper loaded: date_helper
INFO - 2016-02-23 13:19:37 --> Helper loaded: form_helper
INFO - 2016-02-23 13:19:37 --> Database Driver Class Initialized
INFO - 2016-02-23 13:19:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:19:38 --> Controller Class Initialized
INFO - 2016-02-23 13:19:38 --> Model Class Initialized
INFO - 2016-02-23 13:19:38 --> Model Class Initialized
INFO - 2016-02-23 13:19:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:19:38 --> Pagination Class Initialized
INFO - 2016-02-23 13:19:38 --> Helper loaded: text_helper
INFO - 2016-02-23 13:19:38 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 16:19:38 --> Severity: Warning --> Missing argument 1 for Wall::get(), called in C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php on line 29 and defined C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 118
INFO - 2016-02-23 16:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 146
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-23 16:19:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-23 16:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:19:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:19:38 --> Final output sent to browser
DEBUG - 2016-02-23 16:19:38 --> Total execution time: 1.1801
INFO - 2016-02-23 13:21:16 --> Config Class Initialized
INFO - 2016-02-23 13:21:16 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:21:16 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:21:16 --> Utf8 Class Initialized
INFO - 2016-02-23 13:21:16 --> URI Class Initialized
DEBUG - 2016-02-23 13:21:16 --> No URI present. Default controller set.
INFO - 2016-02-23 13:21:16 --> Router Class Initialized
INFO - 2016-02-23 13:21:16 --> Output Class Initialized
INFO - 2016-02-23 13:21:16 --> Security Class Initialized
DEBUG - 2016-02-23 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:21:16 --> Input Class Initialized
INFO - 2016-02-23 13:21:16 --> Language Class Initialized
INFO - 2016-02-23 13:21:16 --> Loader Class Initialized
INFO - 2016-02-23 13:21:16 --> Helper loaded: url_helper
INFO - 2016-02-23 13:21:16 --> Helper loaded: file_helper
INFO - 2016-02-23 13:21:16 --> Helper loaded: date_helper
INFO - 2016-02-23 13:21:16 --> Helper loaded: form_helper
INFO - 2016-02-23 13:21:16 --> Database Driver Class Initialized
INFO - 2016-02-23 13:21:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:21:17 --> Controller Class Initialized
INFO - 2016-02-23 13:21:17 --> Model Class Initialized
INFO - 2016-02-23 13:21:17 --> Model Class Initialized
INFO - 2016-02-23 13:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:21:17 --> Pagination Class Initialized
INFO - 2016-02-23 13:21:17 --> Helper loaded: text_helper
INFO - 2016-02-23 13:21:17 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:21:17 --> Final output sent to browser
DEBUG - 2016-02-23 16:21:17 --> Total execution time: 1.1359
INFO - 2016-02-23 13:21:18 --> Config Class Initialized
INFO - 2016-02-23 13:21:18 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:21:18 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:21:18 --> Utf8 Class Initialized
INFO - 2016-02-23 13:21:18 --> URI Class Initialized
INFO - 2016-02-23 13:21:18 --> Router Class Initialized
INFO - 2016-02-23 13:21:18 --> Output Class Initialized
INFO - 2016-02-23 13:21:18 --> Security Class Initialized
DEBUG - 2016-02-23 13:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:21:18 --> Input Class Initialized
INFO - 2016-02-23 13:21:18 --> Language Class Initialized
ERROR - 2016-02-23 13:21:18 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 116
INFO - 2016-02-23 13:21:35 --> Config Class Initialized
INFO - 2016-02-23 13:21:35 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:21:35 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:21:35 --> Utf8 Class Initialized
INFO - 2016-02-23 13:21:35 --> URI Class Initialized
DEBUG - 2016-02-23 13:21:35 --> No URI present. Default controller set.
INFO - 2016-02-23 13:21:35 --> Router Class Initialized
INFO - 2016-02-23 13:21:35 --> Output Class Initialized
INFO - 2016-02-23 13:21:35 --> Security Class Initialized
DEBUG - 2016-02-23 13:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:21:35 --> Input Class Initialized
INFO - 2016-02-23 13:21:35 --> Language Class Initialized
INFO - 2016-02-23 13:21:35 --> Loader Class Initialized
INFO - 2016-02-23 13:21:35 --> Helper loaded: url_helper
INFO - 2016-02-23 13:21:35 --> Helper loaded: file_helper
INFO - 2016-02-23 13:21:35 --> Helper loaded: date_helper
INFO - 2016-02-23 13:21:35 --> Helper loaded: form_helper
INFO - 2016-02-23 13:21:35 --> Database Driver Class Initialized
INFO - 2016-02-23 13:21:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:21:36 --> Controller Class Initialized
INFO - 2016-02-23 13:21:36 --> Model Class Initialized
INFO - 2016-02-23 13:21:36 --> Model Class Initialized
INFO - 2016-02-23 13:21:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:21:36 --> Pagination Class Initialized
INFO - 2016-02-23 13:21:36 --> Helper loaded: text_helper
INFO - 2016-02-23 13:21:36 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:21:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:21:36 --> Final output sent to browser
DEBUG - 2016-02-23 16:21:36 --> Total execution time: 1.1134
INFO - 2016-02-23 13:21:37 --> Config Class Initialized
INFO - 2016-02-23 13:21:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:21:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:21:37 --> Utf8 Class Initialized
INFO - 2016-02-23 13:21:37 --> URI Class Initialized
INFO - 2016-02-23 13:21:37 --> Router Class Initialized
INFO - 2016-02-23 13:21:37 --> Output Class Initialized
INFO - 2016-02-23 13:21:37 --> Security Class Initialized
DEBUG - 2016-02-23 13:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:21:37 --> Input Class Initialized
INFO - 2016-02-23 13:21:37 --> Language Class Initialized
INFO - 2016-02-23 13:21:37 --> Loader Class Initialized
INFO - 2016-02-23 13:21:37 --> Helper loaded: url_helper
INFO - 2016-02-23 13:21:37 --> Helper loaded: file_helper
INFO - 2016-02-23 13:21:37 --> Helper loaded: date_helper
INFO - 2016-02-23 13:21:37 --> Helper loaded: form_helper
INFO - 2016-02-23 13:21:37 --> Database Driver Class Initialized
INFO - 2016-02-23 13:21:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:21:39 --> Controller Class Initialized
INFO - 2016-02-23 13:21:39 --> Model Class Initialized
INFO - 2016-02-23 13:21:39 --> Model Class Initialized
INFO - 2016-02-23 13:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:21:39 --> Pagination Class Initialized
INFO - 2016-02-23 13:21:39 --> Helper loaded: text_helper
INFO - 2016-02-23 13:21:39 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:21:39 --> Final output sent to browser
DEBUG - 2016-02-23 16:21:39 --> Total execution time: 1.1086
INFO - 2016-02-23 13:21:42 --> Config Class Initialized
INFO - 2016-02-23 13:21:42 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:21:42 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:21:42 --> Utf8 Class Initialized
INFO - 2016-02-23 13:21:42 --> URI Class Initialized
DEBUG - 2016-02-23 13:21:42 --> No URI present. Default controller set.
INFO - 2016-02-23 13:21:42 --> Router Class Initialized
INFO - 2016-02-23 13:21:42 --> Output Class Initialized
INFO - 2016-02-23 13:21:42 --> Security Class Initialized
DEBUG - 2016-02-23 13:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:21:42 --> Input Class Initialized
INFO - 2016-02-23 13:21:42 --> Language Class Initialized
INFO - 2016-02-23 13:21:42 --> Loader Class Initialized
INFO - 2016-02-23 13:21:42 --> Helper loaded: url_helper
INFO - 2016-02-23 13:21:42 --> Helper loaded: file_helper
INFO - 2016-02-23 13:21:42 --> Helper loaded: date_helper
INFO - 2016-02-23 13:21:42 --> Helper loaded: form_helper
INFO - 2016-02-23 13:21:42 --> Database Driver Class Initialized
INFO - 2016-02-23 13:21:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:21:43 --> Controller Class Initialized
INFO - 2016-02-23 13:21:43 --> Model Class Initialized
INFO - 2016-02-23 13:21:43 --> Model Class Initialized
INFO - 2016-02-23 13:21:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:21:43 --> Pagination Class Initialized
INFO - 2016-02-23 13:21:43 --> Helper loaded: text_helper
INFO - 2016-02-23 13:21:43 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:21:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:21:43 --> Final output sent to browser
DEBUG - 2016-02-23 16:21:43 --> Total execution time: 1.1040
INFO - 2016-02-23 13:21:49 --> Config Class Initialized
INFO - 2016-02-23 13:21:49 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:21:49 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:21:49 --> Utf8 Class Initialized
INFO - 2016-02-23 13:21:49 --> URI Class Initialized
INFO - 2016-02-23 13:21:49 --> Router Class Initialized
INFO - 2016-02-23 13:21:49 --> Output Class Initialized
INFO - 2016-02-23 13:21:49 --> Security Class Initialized
DEBUG - 2016-02-23 13:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:21:49 --> Input Class Initialized
INFO - 2016-02-23 13:21:49 --> Language Class Initialized
INFO - 2016-02-23 13:21:49 --> Loader Class Initialized
INFO - 2016-02-23 13:21:49 --> Helper loaded: url_helper
INFO - 2016-02-23 13:21:49 --> Helper loaded: file_helper
INFO - 2016-02-23 13:21:49 --> Helper loaded: date_helper
INFO - 2016-02-23 13:21:49 --> Helper loaded: form_helper
INFO - 2016-02-23 13:21:49 --> Database Driver Class Initialized
INFO - 2016-02-23 13:21:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:21:50 --> Controller Class Initialized
INFO - 2016-02-23 13:21:50 --> Model Class Initialized
INFO - 2016-02-23 13:21:50 --> Model Class Initialized
INFO - 2016-02-23 13:21:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:21:50 --> Pagination Class Initialized
INFO - 2016-02-23 13:21:50 --> Helper loaded: text_helper
INFO - 2016-02-23 13:21:50 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:21:50 --> Final output sent to browser
DEBUG - 2016-02-23 16:21:50 --> Total execution time: 1.1201
INFO - 2016-02-23 13:21:53 --> Config Class Initialized
INFO - 2016-02-23 13:21:53 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:21:53 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:21:53 --> Utf8 Class Initialized
INFO - 2016-02-23 13:21:53 --> URI Class Initialized
DEBUG - 2016-02-23 13:21:53 --> No URI present. Default controller set.
INFO - 2016-02-23 13:21:53 --> Router Class Initialized
INFO - 2016-02-23 13:21:53 --> Output Class Initialized
INFO - 2016-02-23 13:21:53 --> Security Class Initialized
DEBUG - 2016-02-23 13:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:21:53 --> Input Class Initialized
INFO - 2016-02-23 13:21:53 --> Language Class Initialized
INFO - 2016-02-23 13:21:53 --> Loader Class Initialized
INFO - 2016-02-23 13:21:53 --> Helper loaded: url_helper
INFO - 2016-02-23 13:21:53 --> Helper loaded: file_helper
INFO - 2016-02-23 13:21:53 --> Helper loaded: date_helper
INFO - 2016-02-23 13:21:53 --> Helper loaded: form_helper
INFO - 2016-02-23 13:21:53 --> Database Driver Class Initialized
INFO - 2016-02-23 13:21:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:21:54 --> Controller Class Initialized
INFO - 2016-02-23 13:21:54 --> Model Class Initialized
INFO - 2016-02-23 13:21:54 --> Model Class Initialized
INFO - 2016-02-23 13:21:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:21:54 --> Pagination Class Initialized
INFO - 2016-02-23 13:21:54 --> Helper loaded: text_helper
INFO - 2016-02-23 13:21:54 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:21:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:21:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:21:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:21:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:21:54 --> Final output sent to browser
DEBUG - 2016-02-23 16:21:54 --> Total execution time: 1.1353
INFO - 2016-02-23 13:22:00 --> Config Class Initialized
INFO - 2016-02-23 13:22:00 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:22:00 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:22:00 --> Utf8 Class Initialized
INFO - 2016-02-23 13:22:00 --> URI Class Initialized
DEBUG - 2016-02-23 13:22:00 --> No URI present. Default controller set.
INFO - 2016-02-23 13:22:00 --> Router Class Initialized
INFO - 2016-02-23 13:22:00 --> Output Class Initialized
INFO - 2016-02-23 13:22:00 --> Security Class Initialized
DEBUG - 2016-02-23 13:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:22:00 --> Input Class Initialized
INFO - 2016-02-23 13:22:00 --> Language Class Initialized
INFO - 2016-02-23 13:22:00 --> Loader Class Initialized
INFO - 2016-02-23 13:22:00 --> Helper loaded: url_helper
INFO - 2016-02-23 13:22:00 --> Helper loaded: file_helper
INFO - 2016-02-23 13:22:00 --> Helper loaded: date_helper
INFO - 2016-02-23 13:22:00 --> Helper loaded: form_helper
INFO - 2016-02-23 13:22:00 --> Database Driver Class Initialized
INFO - 2016-02-23 13:22:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:22:01 --> Controller Class Initialized
INFO - 2016-02-23 13:22:01 --> Model Class Initialized
INFO - 2016-02-23 13:22:01 --> Model Class Initialized
INFO - 2016-02-23 13:22:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:22:01 --> Pagination Class Initialized
INFO - 2016-02-23 13:22:01 --> Helper loaded: text_helper
INFO - 2016-02-23 13:22:01 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:22:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:22:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:22:02 --> Final output sent to browser
DEBUG - 2016-02-23 16:22:02 --> Total execution time: 1.1344
INFO - 2016-02-23 13:22:20 --> Config Class Initialized
INFO - 2016-02-23 13:22:20 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:22:20 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:22:20 --> Utf8 Class Initialized
INFO - 2016-02-23 13:22:20 --> URI Class Initialized
INFO - 2016-02-23 13:22:20 --> Router Class Initialized
INFO - 2016-02-23 13:22:20 --> Output Class Initialized
INFO - 2016-02-23 13:22:20 --> Security Class Initialized
DEBUG - 2016-02-23 13:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:22:20 --> Input Class Initialized
INFO - 2016-02-23 13:22:20 --> Language Class Initialized
INFO - 2016-02-23 13:22:20 --> Loader Class Initialized
INFO - 2016-02-23 13:22:20 --> Helper loaded: url_helper
INFO - 2016-02-23 13:22:20 --> Helper loaded: file_helper
INFO - 2016-02-23 13:22:20 --> Helper loaded: date_helper
INFO - 2016-02-23 13:22:20 --> Helper loaded: form_helper
INFO - 2016-02-23 13:22:20 --> Database Driver Class Initialized
INFO - 2016-02-23 13:22:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:22:21 --> Controller Class Initialized
INFO - 2016-02-23 13:22:21 --> Model Class Initialized
INFO - 2016-02-23 13:22:21 --> Model Class Initialized
INFO - 2016-02-23 13:22:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:22:21 --> Pagination Class Initialized
INFO - 2016-02-23 13:22:21 --> Helper loaded: text_helper
INFO - 2016-02-23 13:22:21 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:22:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:22:21 --> Final output sent to browser
DEBUG - 2016-02-23 16:22:21 --> Total execution time: 1.1613
INFO - 2016-02-23 13:22:22 --> Config Class Initialized
INFO - 2016-02-23 13:22:22 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:22:22 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:22:22 --> Utf8 Class Initialized
INFO - 2016-02-23 13:22:22 --> URI Class Initialized
DEBUG - 2016-02-23 13:22:22 --> No URI present. Default controller set.
INFO - 2016-02-23 13:22:22 --> Router Class Initialized
INFO - 2016-02-23 13:22:22 --> Output Class Initialized
INFO - 2016-02-23 13:22:22 --> Security Class Initialized
DEBUG - 2016-02-23 13:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:22:22 --> Input Class Initialized
INFO - 2016-02-23 13:22:22 --> Language Class Initialized
INFO - 2016-02-23 13:22:22 --> Loader Class Initialized
INFO - 2016-02-23 13:22:22 --> Helper loaded: url_helper
INFO - 2016-02-23 13:22:22 --> Helper loaded: file_helper
INFO - 2016-02-23 13:22:22 --> Helper loaded: date_helper
INFO - 2016-02-23 13:22:22 --> Helper loaded: form_helper
INFO - 2016-02-23 13:22:22 --> Database Driver Class Initialized
INFO - 2016-02-23 13:22:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:22:23 --> Controller Class Initialized
INFO - 2016-02-23 13:22:23 --> Model Class Initialized
INFO - 2016-02-23 13:22:23 --> Model Class Initialized
INFO - 2016-02-23 13:22:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:22:23 --> Pagination Class Initialized
INFO - 2016-02-23 13:22:23 --> Helper loaded: text_helper
INFO - 2016-02-23 13:22:23 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:22:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:22:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:22:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:22:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:22:23 --> Final output sent to browser
DEBUG - 2016-02-23 16:22:23 --> Total execution time: 1.1289
INFO - 2016-02-23 13:22:34 --> Config Class Initialized
INFO - 2016-02-23 13:22:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:22:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:22:34 --> Utf8 Class Initialized
INFO - 2016-02-23 13:22:34 --> URI Class Initialized
INFO - 2016-02-23 13:22:34 --> Router Class Initialized
INFO - 2016-02-23 13:22:34 --> Output Class Initialized
INFO - 2016-02-23 13:22:34 --> Security Class Initialized
DEBUG - 2016-02-23 13:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:22:34 --> Input Class Initialized
INFO - 2016-02-23 13:22:34 --> Language Class Initialized
INFO - 2016-02-23 13:22:34 --> Loader Class Initialized
INFO - 2016-02-23 13:22:34 --> Helper loaded: url_helper
INFO - 2016-02-23 13:22:34 --> Helper loaded: file_helper
INFO - 2016-02-23 13:22:34 --> Helper loaded: date_helper
INFO - 2016-02-23 13:22:34 --> Helper loaded: form_helper
INFO - 2016-02-23 13:22:34 --> Database Driver Class Initialized
INFO - 2016-02-23 13:22:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:22:35 --> Controller Class Initialized
INFO - 2016-02-23 13:22:35 --> Model Class Initialized
INFO - 2016-02-23 13:22:35 --> Model Class Initialized
INFO - 2016-02-23 13:22:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:22:35 --> Pagination Class Initialized
INFO - 2016-02-23 13:22:35 --> Helper loaded: text_helper
INFO - 2016-02-23 13:22:35 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:22:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:22:35 --> Final output sent to browser
DEBUG - 2016-02-23 16:22:35 --> Total execution time: 1.1328
INFO - 2016-02-23 13:29:46 --> Config Class Initialized
INFO - 2016-02-23 13:29:46 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:29:46 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:29:46 --> Utf8 Class Initialized
INFO - 2016-02-23 13:29:46 --> URI Class Initialized
INFO - 2016-02-23 13:29:46 --> Router Class Initialized
INFO - 2016-02-23 13:29:46 --> Output Class Initialized
INFO - 2016-02-23 13:29:46 --> Security Class Initialized
DEBUG - 2016-02-23 13:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:29:46 --> Input Class Initialized
INFO - 2016-02-23 13:29:46 --> Language Class Initialized
INFO - 2016-02-23 13:29:46 --> Loader Class Initialized
INFO - 2016-02-23 13:29:46 --> Helper loaded: url_helper
INFO - 2016-02-23 13:29:46 --> Helper loaded: file_helper
INFO - 2016-02-23 13:29:46 --> Helper loaded: date_helper
INFO - 2016-02-23 13:29:46 --> Helper loaded: form_helper
INFO - 2016-02-23 13:29:46 --> Database Driver Class Initialized
INFO - 2016-02-23 13:29:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:29:47 --> Controller Class Initialized
INFO - 2016-02-23 13:29:47 --> Model Class Initialized
INFO - 2016-02-23 13:29:47 --> Model Class Initialized
INFO - 2016-02-23 13:29:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:29:47 --> Pagination Class Initialized
INFO - 2016-02-23 13:29:47 --> Helper loaded: text_helper
INFO - 2016-02-23 13:29:48 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:29:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:29:48 --> Final output sent to browser
DEBUG - 2016-02-23 16:29:48 --> Total execution time: 1.1676
INFO - 2016-02-23 13:29:51 --> Config Class Initialized
INFO - 2016-02-23 13:29:51 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:29:51 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:29:51 --> Utf8 Class Initialized
INFO - 2016-02-23 13:29:51 --> URI Class Initialized
INFO - 2016-02-23 13:29:51 --> Router Class Initialized
INFO - 2016-02-23 13:29:51 --> Output Class Initialized
INFO - 2016-02-23 13:29:51 --> Security Class Initialized
DEBUG - 2016-02-23 13:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:29:51 --> Input Class Initialized
INFO - 2016-02-23 13:29:51 --> Language Class Initialized
INFO - 2016-02-23 13:29:51 --> Loader Class Initialized
INFO - 2016-02-23 13:29:51 --> Helper loaded: url_helper
INFO - 2016-02-23 13:29:51 --> Helper loaded: file_helper
INFO - 2016-02-23 13:29:51 --> Helper loaded: date_helper
INFO - 2016-02-23 13:29:51 --> Helper loaded: form_helper
INFO - 2016-02-23 13:29:51 --> Database Driver Class Initialized
INFO - 2016-02-23 13:29:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:29:52 --> Controller Class Initialized
INFO - 2016-02-23 13:29:52 --> Model Class Initialized
INFO - 2016-02-23 13:29:52 --> Model Class Initialized
INFO - 2016-02-23 13:29:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:29:52 --> Pagination Class Initialized
INFO - 2016-02-23 13:29:52 --> Helper loaded: text_helper
INFO - 2016-02-23 13:29:52 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:29:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:29:52 --> Final output sent to browser
DEBUG - 2016-02-23 16:29:52 --> Total execution time: 1.1858
INFO - 2016-02-23 13:32:22 --> Config Class Initialized
INFO - 2016-02-23 13:32:22 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:32:22 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:32:22 --> Utf8 Class Initialized
INFO - 2016-02-23 13:32:22 --> URI Class Initialized
DEBUG - 2016-02-23 13:32:22 --> No URI present. Default controller set.
INFO - 2016-02-23 13:32:22 --> Router Class Initialized
INFO - 2016-02-23 13:32:22 --> Output Class Initialized
INFO - 2016-02-23 13:32:22 --> Security Class Initialized
DEBUG - 2016-02-23 13:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:32:22 --> Input Class Initialized
INFO - 2016-02-23 13:32:22 --> Language Class Initialized
INFO - 2016-02-23 13:32:22 --> Loader Class Initialized
INFO - 2016-02-23 13:32:22 --> Helper loaded: url_helper
INFO - 2016-02-23 13:32:22 --> Helper loaded: file_helper
INFO - 2016-02-23 13:32:22 --> Helper loaded: date_helper
INFO - 2016-02-23 13:32:22 --> Helper loaded: form_helper
INFO - 2016-02-23 13:32:22 --> Database Driver Class Initialized
INFO - 2016-02-23 13:32:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:32:23 --> Controller Class Initialized
INFO - 2016-02-23 13:32:23 --> Model Class Initialized
INFO - 2016-02-23 13:32:23 --> Model Class Initialized
INFO - 2016-02-23 13:32:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:32:23 --> Pagination Class Initialized
INFO - 2016-02-23 13:32:23 --> Helper loaded: text_helper
INFO - 2016-02-23 13:32:23 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:32:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:32:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:32:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:32:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:32:23 --> Final output sent to browser
DEBUG - 2016-02-23 16:32:23 --> Total execution time: 1.1763
INFO - 2016-02-23 13:32:24 --> Config Class Initialized
INFO - 2016-02-23 13:32:24 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:32:24 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:32:24 --> Utf8 Class Initialized
INFO - 2016-02-23 13:32:24 --> URI Class Initialized
INFO - 2016-02-23 13:32:24 --> Router Class Initialized
INFO - 2016-02-23 13:32:24 --> Output Class Initialized
INFO - 2016-02-23 13:32:24 --> Security Class Initialized
DEBUG - 2016-02-23 13:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:32:24 --> Input Class Initialized
INFO - 2016-02-23 13:32:24 --> Language Class Initialized
INFO - 2016-02-23 13:32:24 --> Loader Class Initialized
INFO - 2016-02-23 13:32:24 --> Helper loaded: url_helper
INFO - 2016-02-23 13:32:24 --> Helper loaded: file_helper
INFO - 2016-02-23 13:32:24 --> Helper loaded: date_helper
INFO - 2016-02-23 13:32:24 --> Helper loaded: form_helper
INFO - 2016-02-23 13:32:24 --> Database Driver Class Initialized
INFO - 2016-02-23 13:32:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:32:25 --> Controller Class Initialized
INFO - 2016-02-23 13:32:25 --> Model Class Initialized
INFO - 2016-02-23 13:32:25 --> Model Class Initialized
INFO - 2016-02-23 13:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:32:25 --> Pagination Class Initialized
INFO - 2016-02-23 13:32:25 --> Helper loaded: text_helper
INFO - 2016-02-23 13:32:25 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:32:25 --> Final output sent to browser
DEBUG - 2016-02-23 16:32:25 --> Total execution time: 1.1170
INFO - 2016-02-23 13:32:27 --> Config Class Initialized
INFO - 2016-02-23 13:32:27 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:32:27 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:32:27 --> Utf8 Class Initialized
INFO - 2016-02-23 13:32:27 --> URI Class Initialized
INFO - 2016-02-23 13:32:27 --> Router Class Initialized
INFO - 2016-02-23 13:32:27 --> Output Class Initialized
INFO - 2016-02-23 13:32:27 --> Security Class Initialized
DEBUG - 2016-02-23 13:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:32:27 --> Input Class Initialized
INFO - 2016-02-23 13:32:27 --> Language Class Initialized
INFO - 2016-02-23 13:32:27 --> Loader Class Initialized
INFO - 2016-02-23 13:32:27 --> Helper loaded: url_helper
INFO - 2016-02-23 13:32:27 --> Helper loaded: file_helper
INFO - 2016-02-23 13:32:27 --> Helper loaded: date_helper
INFO - 2016-02-23 13:32:27 --> Helper loaded: form_helper
INFO - 2016-02-23 13:32:27 --> Database Driver Class Initialized
INFO - 2016-02-23 13:32:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:32:28 --> Controller Class Initialized
INFO - 2016-02-23 13:32:28 --> Model Class Initialized
INFO - 2016-02-23 13:32:28 --> Model Class Initialized
INFO - 2016-02-23 13:32:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:32:28 --> Pagination Class Initialized
INFO - 2016-02-23 13:32:28 --> Helper loaded: text_helper
INFO - 2016-02-23 13:32:28 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:32:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:32:28 --> Final output sent to browser
DEBUG - 2016-02-23 16:32:28 --> Total execution time: 1.2766
INFO - 2016-02-23 13:32:34 --> Config Class Initialized
INFO - 2016-02-23 13:32:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:32:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:32:34 --> Utf8 Class Initialized
INFO - 2016-02-23 13:32:34 --> URI Class Initialized
INFO - 2016-02-23 13:32:34 --> Router Class Initialized
INFO - 2016-02-23 13:32:34 --> Output Class Initialized
INFO - 2016-02-23 13:32:34 --> Security Class Initialized
DEBUG - 2016-02-23 13:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:32:34 --> Input Class Initialized
INFO - 2016-02-23 13:32:34 --> Language Class Initialized
INFO - 2016-02-23 13:32:34 --> Loader Class Initialized
INFO - 2016-02-23 13:32:34 --> Helper loaded: url_helper
INFO - 2016-02-23 13:32:34 --> Helper loaded: file_helper
INFO - 2016-02-23 13:32:34 --> Helper loaded: date_helper
INFO - 2016-02-23 13:32:34 --> Helper loaded: form_helper
INFO - 2016-02-23 13:32:34 --> Database Driver Class Initialized
INFO - 2016-02-23 13:32:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:32:35 --> Controller Class Initialized
INFO - 2016-02-23 13:32:35 --> Model Class Initialized
INFO - 2016-02-23 13:32:35 --> Model Class Initialized
INFO - 2016-02-23 13:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:32:35 --> Pagination Class Initialized
INFO - 2016-02-23 13:32:35 --> Helper loaded: text_helper
INFO - 2016-02-23 13:32:35 --> Helper loaded: cookie_helper
ERROR - 2016-02-23 16:32:35 --> Severity: Warning --> Missing argument 1 for Wall::get() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 108
INFO - 2016-02-23 16:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Undefined variable: id C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 136
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 46
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 48
ERROR - 2016-02-23 16:32:35 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 107
INFO - 2016-02-23 16:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:32:35 --> Final output sent to browser
DEBUG - 2016-02-23 16:32:35 --> Total execution time: 1.1912
INFO - 2016-02-23 13:32:38 --> Config Class Initialized
INFO - 2016-02-23 13:32:38 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:32:38 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:32:38 --> Utf8 Class Initialized
INFO - 2016-02-23 13:32:38 --> URI Class Initialized
INFO - 2016-02-23 13:32:38 --> Router Class Initialized
INFO - 2016-02-23 13:32:38 --> Output Class Initialized
INFO - 2016-02-23 13:32:38 --> Security Class Initialized
DEBUG - 2016-02-23 13:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:32:38 --> Input Class Initialized
INFO - 2016-02-23 13:32:38 --> Language Class Initialized
INFO - 2016-02-23 13:32:38 --> Loader Class Initialized
INFO - 2016-02-23 13:32:38 --> Helper loaded: url_helper
INFO - 2016-02-23 13:32:38 --> Helper loaded: file_helper
INFO - 2016-02-23 13:32:38 --> Helper loaded: date_helper
INFO - 2016-02-23 13:32:38 --> Helper loaded: form_helper
INFO - 2016-02-23 13:32:38 --> Database Driver Class Initialized
INFO - 2016-02-23 13:32:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:32:39 --> Controller Class Initialized
INFO - 2016-02-23 13:32:39 --> Model Class Initialized
INFO - 2016-02-23 13:32:39 --> Model Class Initialized
INFO - 2016-02-23 13:32:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:32:39 --> Pagination Class Initialized
INFO - 2016-02-23 13:32:39 --> Helper loaded: text_helper
INFO - 2016-02-23 13:32:39 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:32:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:32:39 --> Final output sent to browser
DEBUG - 2016-02-23 16:32:39 --> Total execution time: 1.2111
INFO - 2016-02-23 13:33:23 --> Config Class Initialized
INFO - 2016-02-23 13:33:23 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:33:23 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:33:23 --> Utf8 Class Initialized
INFO - 2016-02-23 13:33:23 --> URI Class Initialized
DEBUG - 2016-02-23 13:33:23 --> No URI present. Default controller set.
INFO - 2016-02-23 13:33:23 --> Router Class Initialized
INFO - 2016-02-23 13:33:23 --> Output Class Initialized
INFO - 2016-02-23 13:33:23 --> Security Class Initialized
DEBUG - 2016-02-23 13:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:33:23 --> Input Class Initialized
INFO - 2016-02-23 13:33:23 --> Language Class Initialized
INFO - 2016-02-23 13:33:23 --> Loader Class Initialized
INFO - 2016-02-23 13:33:23 --> Helper loaded: url_helper
INFO - 2016-02-23 13:33:23 --> Helper loaded: file_helper
INFO - 2016-02-23 13:33:23 --> Helper loaded: date_helper
INFO - 2016-02-23 13:33:23 --> Helper loaded: form_helper
INFO - 2016-02-23 13:33:23 --> Database Driver Class Initialized
INFO - 2016-02-23 13:33:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:33:24 --> Controller Class Initialized
INFO - 2016-02-23 13:33:24 --> Model Class Initialized
INFO - 2016-02-23 13:33:24 --> Model Class Initialized
INFO - 2016-02-23 13:33:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:33:24 --> Pagination Class Initialized
INFO - 2016-02-23 13:33:24 --> Helper loaded: text_helper
INFO - 2016-02-23 13:33:24 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:33:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:33:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:33:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:33:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:33:24 --> Final output sent to browser
DEBUG - 2016-02-23 16:33:24 --> Total execution time: 1.3096
INFO - 2016-02-23 13:33:26 --> Config Class Initialized
INFO - 2016-02-23 13:33:26 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:33:26 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:33:26 --> Utf8 Class Initialized
INFO - 2016-02-23 13:33:26 --> URI Class Initialized
INFO - 2016-02-23 13:33:26 --> Router Class Initialized
INFO - 2016-02-23 13:33:26 --> Output Class Initialized
INFO - 2016-02-23 13:33:26 --> Security Class Initialized
DEBUG - 2016-02-23 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:33:26 --> Input Class Initialized
INFO - 2016-02-23 13:33:26 --> Language Class Initialized
INFO - 2016-02-23 13:33:26 --> Loader Class Initialized
INFO - 2016-02-23 13:33:26 --> Helper loaded: url_helper
INFO - 2016-02-23 13:33:26 --> Helper loaded: file_helper
INFO - 2016-02-23 13:33:26 --> Helper loaded: date_helper
INFO - 2016-02-23 13:33:26 --> Helper loaded: form_helper
INFO - 2016-02-23 13:33:26 --> Database Driver Class Initialized
INFO - 2016-02-23 13:33:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:33:27 --> Controller Class Initialized
INFO - 2016-02-23 13:33:27 --> Model Class Initialized
INFO - 2016-02-23 13:33:27 --> Model Class Initialized
INFO - 2016-02-23 13:33:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:33:27 --> Pagination Class Initialized
INFO - 2016-02-23 13:33:27 --> Helper loaded: text_helper
INFO - 2016-02-23 13:33:27 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:33:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:33:27 --> Final output sent to browser
DEBUG - 2016-02-23 16:33:27 --> Total execution time: 1.1465
INFO - 2016-02-23 13:33:29 --> Config Class Initialized
INFO - 2016-02-23 13:33:29 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:33:29 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:33:29 --> Utf8 Class Initialized
INFO - 2016-02-23 13:33:29 --> URI Class Initialized
INFO - 2016-02-23 13:33:29 --> Router Class Initialized
INFO - 2016-02-23 13:33:29 --> Output Class Initialized
INFO - 2016-02-23 13:33:29 --> Security Class Initialized
DEBUG - 2016-02-23 13:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:33:29 --> Input Class Initialized
INFO - 2016-02-23 13:33:29 --> Language Class Initialized
INFO - 2016-02-23 13:33:29 --> Loader Class Initialized
INFO - 2016-02-23 13:33:29 --> Helper loaded: url_helper
INFO - 2016-02-23 13:33:29 --> Helper loaded: file_helper
INFO - 2016-02-23 13:33:29 --> Helper loaded: date_helper
INFO - 2016-02-23 13:33:29 --> Helper loaded: form_helper
INFO - 2016-02-23 13:33:29 --> Database Driver Class Initialized
INFO - 2016-02-23 13:33:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:33:30 --> Controller Class Initialized
INFO - 2016-02-23 13:33:30 --> Model Class Initialized
INFO - 2016-02-23 13:33:30 --> Model Class Initialized
INFO - 2016-02-23 13:33:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:33:30 --> Pagination Class Initialized
INFO - 2016-02-23 13:33:30 --> Helper loaded: text_helper
INFO - 2016-02-23 13:33:30 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:33:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:33:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:33:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:33:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:33:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:33:31 --> Final output sent to browser
DEBUG - 2016-02-23 16:33:31 --> Total execution time: 1.1776
INFO - 2016-02-23 13:42:50 --> Config Class Initialized
INFO - 2016-02-23 13:42:50 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:42:50 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:42:50 --> Utf8 Class Initialized
INFO - 2016-02-23 13:42:50 --> URI Class Initialized
DEBUG - 2016-02-23 13:42:50 --> No URI present. Default controller set.
INFO - 2016-02-23 13:42:50 --> Router Class Initialized
INFO - 2016-02-23 13:42:50 --> Output Class Initialized
INFO - 2016-02-23 13:42:50 --> Security Class Initialized
DEBUG - 2016-02-23 13:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:42:50 --> Input Class Initialized
INFO - 2016-02-23 13:42:50 --> Language Class Initialized
INFO - 2016-02-23 13:42:50 --> Loader Class Initialized
INFO - 2016-02-23 13:42:50 --> Helper loaded: url_helper
INFO - 2016-02-23 13:42:50 --> Helper loaded: file_helper
INFO - 2016-02-23 13:42:50 --> Helper loaded: date_helper
INFO - 2016-02-23 13:42:50 --> Helper loaded: form_helper
INFO - 2016-02-23 13:42:50 --> Database Driver Class Initialized
INFO - 2016-02-23 13:42:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:42:51 --> Controller Class Initialized
INFO - 2016-02-23 13:42:51 --> Model Class Initialized
INFO - 2016-02-23 13:42:51 --> Model Class Initialized
INFO - 2016-02-23 13:42:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:42:51 --> Pagination Class Initialized
INFO - 2016-02-23 13:42:51 --> Helper loaded: text_helper
INFO - 2016-02-23 13:42:51 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:42:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:42:51 --> Final output sent to browser
DEBUG - 2016-02-23 16:42:51 --> Total execution time: 1.1478
INFO - 2016-02-23 13:42:53 --> Config Class Initialized
INFO - 2016-02-23 13:42:53 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:42:53 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:42:53 --> Utf8 Class Initialized
INFO - 2016-02-23 13:42:53 --> URI Class Initialized
INFO - 2016-02-23 13:42:53 --> Router Class Initialized
INFO - 2016-02-23 13:42:53 --> Output Class Initialized
INFO - 2016-02-23 13:42:53 --> Security Class Initialized
DEBUG - 2016-02-23 13:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:42:53 --> Input Class Initialized
INFO - 2016-02-23 13:42:53 --> Language Class Initialized
INFO - 2016-02-23 13:42:53 --> Loader Class Initialized
INFO - 2016-02-23 13:42:53 --> Helper loaded: url_helper
INFO - 2016-02-23 13:42:53 --> Helper loaded: file_helper
INFO - 2016-02-23 13:42:53 --> Helper loaded: date_helper
INFO - 2016-02-23 13:42:53 --> Helper loaded: form_helper
INFO - 2016-02-23 13:42:53 --> Database Driver Class Initialized
INFO - 2016-02-23 13:42:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:42:54 --> Controller Class Initialized
INFO - 2016-02-23 13:42:54 --> Model Class Initialized
INFO - 2016-02-23 13:42:54 --> Model Class Initialized
INFO - 2016-02-23 13:42:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:42:54 --> Pagination Class Initialized
INFO - 2016-02-23 13:42:54 --> Helper loaded: text_helper
INFO - 2016-02-23 13:42:54 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:42:54 --> Final output sent to browser
DEBUG - 2016-02-23 16:42:54 --> Total execution time: 1.1285
INFO - 2016-02-23 13:43:11 --> Config Class Initialized
INFO - 2016-02-23 13:43:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:43:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:43:11 --> Utf8 Class Initialized
INFO - 2016-02-23 13:43:11 --> URI Class Initialized
INFO - 2016-02-23 13:43:11 --> Router Class Initialized
INFO - 2016-02-23 13:43:11 --> Output Class Initialized
INFO - 2016-02-23 13:43:11 --> Security Class Initialized
DEBUG - 2016-02-23 13:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:43:11 --> Input Class Initialized
INFO - 2016-02-23 13:43:11 --> Language Class Initialized
INFO - 2016-02-23 13:43:11 --> Loader Class Initialized
INFO - 2016-02-23 13:43:11 --> Helper loaded: url_helper
INFO - 2016-02-23 13:43:11 --> Helper loaded: file_helper
INFO - 2016-02-23 13:43:11 --> Helper loaded: date_helper
INFO - 2016-02-23 13:43:11 --> Helper loaded: form_helper
INFO - 2016-02-23 13:43:11 --> Database Driver Class Initialized
INFO - 2016-02-23 13:43:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:43:12 --> Controller Class Initialized
INFO - 2016-02-23 13:43:12 --> Model Class Initialized
INFO - 2016-02-23 13:43:12 --> Model Class Initialized
INFO - 2016-02-23 13:43:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:43:12 --> Pagination Class Initialized
INFO - 2016-02-23 13:43:12 --> Helper loaded: text_helper
INFO - 2016-02-23 13:43:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:43:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:43:12 --> Final output sent to browser
DEBUG - 2016-02-23 16:43:12 --> Total execution time: 1.1560
INFO - 2016-02-23 13:46:17 --> Config Class Initialized
INFO - 2016-02-23 13:46:17 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:46:17 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:46:17 --> Utf8 Class Initialized
INFO - 2016-02-23 13:46:17 --> URI Class Initialized
DEBUG - 2016-02-23 13:46:17 --> No URI present. Default controller set.
INFO - 2016-02-23 13:46:17 --> Router Class Initialized
INFO - 2016-02-23 13:46:17 --> Output Class Initialized
INFO - 2016-02-23 13:46:17 --> Security Class Initialized
DEBUG - 2016-02-23 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:46:17 --> Input Class Initialized
INFO - 2016-02-23 13:46:17 --> Language Class Initialized
INFO - 2016-02-23 13:46:17 --> Loader Class Initialized
INFO - 2016-02-23 13:46:17 --> Helper loaded: url_helper
INFO - 2016-02-23 13:46:17 --> Helper loaded: file_helper
INFO - 2016-02-23 13:46:17 --> Helper loaded: date_helper
INFO - 2016-02-23 13:46:17 --> Helper loaded: form_helper
INFO - 2016-02-23 13:46:17 --> Database Driver Class Initialized
INFO - 2016-02-23 13:46:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:46:18 --> Controller Class Initialized
INFO - 2016-02-23 13:46:18 --> Model Class Initialized
INFO - 2016-02-23 13:46:18 --> Model Class Initialized
INFO - 2016-02-23 13:46:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:46:18 --> Pagination Class Initialized
INFO - 2016-02-23 13:46:18 --> Helper loaded: text_helper
INFO - 2016-02-23 13:46:18 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:46:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:46:18 --> Final output sent to browser
DEBUG - 2016-02-23 16:46:18 --> Total execution time: 1.1331
INFO - 2016-02-23 13:46:19 --> Config Class Initialized
INFO - 2016-02-23 13:46:19 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:46:19 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:46:19 --> Utf8 Class Initialized
INFO - 2016-02-23 13:46:19 --> URI Class Initialized
INFO - 2016-02-23 13:46:19 --> Router Class Initialized
INFO - 2016-02-23 13:46:19 --> Output Class Initialized
INFO - 2016-02-23 13:46:19 --> Security Class Initialized
DEBUG - 2016-02-23 13:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:46:19 --> Input Class Initialized
INFO - 2016-02-23 13:46:19 --> Language Class Initialized
INFO - 2016-02-23 13:46:19 --> Loader Class Initialized
INFO - 2016-02-23 13:46:19 --> Helper loaded: url_helper
INFO - 2016-02-23 13:46:19 --> Helper loaded: file_helper
INFO - 2016-02-23 13:46:19 --> Helper loaded: date_helper
INFO - 2016-02-23 13:46:19 --> Helper loaded: form_helper
INFO - 2016-02-23 13:46:19 --> Database Driver Class Initialized
INFO - 2016-02-23 13:46:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:46:20 --> Controller Class Initialized
INFO - 2016-02-23 13:46:20 --> Model Class Initialized
INFO - 2016-02-23 13:46:20 --> Model Class Initialized
INFO - 2016-02-23 13:46:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:46:20 --> Pagination Class Initialized
INFO - 2016-02-23 13:46:20 --> Helper loaded: text_helper
INFO - 2016-02-23 13:46:20 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:46:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:46:20 --> Final output sent to browser
DEBUG - 2016-02-23 16:46:20 --> Total execution time: 1.1294
INFO - 2016-02-23 13:46:22 --> Config Class Initialized
INFO - 2016-02-23 13:46:22 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:46:22 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:46:22 --> Utf8 Class Initialized
INFO - 2016-02-23 13:46:22 --> URI Class Initialized
INFO - 2016-02-23 13:46:22 --> Router Class Initialized
INFO - 2016-02-23 13:46:22 --> Output Class Initialized
INFO - 2016-02-23 13:46:22 --> Security Class Initialized
DEBUG - 2016-02-23 13:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:46:22 --> Input Class Initialized
INFO - 2016-02-23 13:46:22 --> Language Class Initialized
INFO - 2016-02-23 13:46:22 --> Loader Class Initialized
INFO - 2016-02-23 13:46:22 --> Helper loaded: url_helper
INFO - 2016-02-23 13:46:22 --> Helper loaded: file_helper
INFO - 2016-02-23 13:46:22 --> Helper loaded: date_helper
INFO - 2016-02-23 13:46:22 --> Helper loaded: form_helper
INFO - 2016-02-23 13:46:22 --> Database Driver Class Initialized
INFO - 2016-02-23 13:46:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:46:23 --> Controller Class Initialized
INFO - 2016-02-23 13:46:23 --> Model Class Initialized
INFO - 2016-02-23 13:46:23 --> Model Class Initialized
INFO - 2016-02-23 13:46:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:46:23 --> Pagination Class Initialized
INFO - 2016-02-23 13:46:23 --> Helper loaded: text_helper
INFO - 2016-02-23 13:46:23 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 16:46:24 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 958
INFO - 2016-02-23 16:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:46:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:46:24 --> Final output sent to browser
DEBUG - 2016-02-23 16:46:24 --> Total execution time: 1.2073
INFO - 2016-02-23 13:49:03 --> Config Class Initialized
INFO - 2016-02-23 13:49:03 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:49:03 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:49:03 --> Utf8 Class Initialized
INFO - 2016-02-23 13:49:03 --> URI Class Initialized
DEBUG - 2016-02-23 13:49:03 --> No URI present. Default controller set.
INFO - 2016-02-23 13:49:03 --> Router Class Initialized
INFO - 2016-02-23 13:49:03 --> Output Class Initialized
INFO - 2016-02-23 13:49:03 --> Security Class Initialized
DEBUG - 2016-02-23 13:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:49:03 --> Input Class Initialized
INFO - 2016-02-23 13:49:03 --> Language Class Initialized
INFO - 2016-02-23 13:49:03 --> Loader Class Initialized
INFO - 2016-02-23 13:49:03 --> Helper loaded: url_helper
INFO - 2016-02-23 13:49:03 --> Helper loaded: file_helper
INFO - 2016-02-23 13:49:03 --> Helper loaded: date_helper
INFO - 2016-02-23 13:49:03 --> Helper loaded: form_helper
INFO - 2016-02-23 13:49:03 --> Database Driver Class Initialized
INFO - 2016-02-23 13:49:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:49:04 --> Controller Class Initialized
INFO - 2016-02-23 13:49:04 --> Model Class Initialized
INFO - 2016-02-23 13:49:05 --> Model Class Initialized
INFO - 2016-02-23 13:49:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:49:05 --> Pagination Class Initialized
INFO - 2016-02-23 13:49:05 --> Helper loaded: text_helper
INFO - 2016-02-23 13:49:05 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:49:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:49:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:49:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:49:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:49:05 --> Final output sent to browser
DEBUG - 2016-02-23 16:49:05 --> Total execution time: 1.1419
INFO - 2016-02-23 13:49:06 --> Config Class Initialized
INFO - 2016-02-23 13:49:06 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:49:06 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:49:06 --> Utf8 Class Initialized
INFO - 2016-02-23 13:49:06 --> URI Class Initialized
INFO - 2016-02-23 13:49:06 --> Router Class Initialized
INFO - 2016-02-23 13:49:06 --> Output Class Initialized
INFO - 2016-02-23 13:49:06 --> Security Class Initialized
DEBUG - 2016-02-23 13:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:49:06 --> Input Class Initialized
INFO - 2016-02-23 13:49:06 --> Language Class Initialized
ERROR - 2016-02-23 13:49:06 --> Severity: Compile Error --> Cannot redeclare Wall::index() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 44
INFO - 2016-02-23 13:49:36 --> Config Class Initialized
INFO - 2016-02-23 13:49:36 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:49:36 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:49:37 --> Utf8 Class Initialized
INFO - 2016-02-23 13:49:37 --> URI Class Initialized
DEBUG - 2016-02-23 13:49:37 --> No URI present. Default controller set.
INFO - 2016-02-23 13:49:37 --> Router Class Initialized
INFO - 2016-02-23 13:49:37 --> Output Class Initialized
INFO - 2016-02-23 13:49:37 --> Security Class Initialized
DEBUG - 2016-02-23 13:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:49:37 --> Input Class Initialized
INFO - 2016-02-23 13:49:37 --> Language Class Initialized
INFO - 2016-02-23 13:49:37 --> Loader Class Initialized
INFO - 2016-02-23 13:49:37 --> Helper loaded: url_helper
INFO - 2016-02-23 13:49:37 --> Helper loaded: file_helper
INFO - 2016-02-23 13:49:37 --> Helper loaded: date_helper
INFO - 2016-02-23 13:49:37 --> Helper loaded: form_helper
INFO - 2016-02-23 13:49:37 --> Database Driver Class Initialized
INFO - 2016-02-23 13:49:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:49:38 --> Controller Class Initialized
INFO - 2016-02-23 13:49:38 --> Model Class Initialized
INFO - 2016-02-23 13:49:38 --> Model Class Initialized
INFO - 2016-02-23 13:49:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:49:38 --> Pagination Class Initialized
INFO - 2016-02-23 13:49:38 --> Helper loaded: text_helper
INFO - 2016-02-23 13:49:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:49:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:49:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:49:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:49:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:49:38 --> Final output sent to browser
DEBUG - 2016-02-23 16:49:38 --> Total execution time: 1.1255
INFO - 2016-02-23 13:49:39 --> Config Class Initialized
INFO - 2016-02-23 13:49:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:49:39 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:49:39 --> Utf8 Class Initialized
INFO - 2016-02-23 13:49:39 --> URI Class Initialized
INFO - 2016-02-23 13:49:39 --> Router Class Initialized
INFO - 2016-02-23 13:49:39 --> Output Class Initialized
INFO - 2016-02-23 13:49:39 --> Security Class Initialized
DEBUG - 2016-02-23 13:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:49:39 --> Input Class Initialized
INFO - 2016-02-23 13:49:39 --> Language Class Initialized
INFO - 2016-02-23 13:49:39 --> Loader Class Initialized
INFO - 2016-02-23 13:49:39 --> Helper loaded: url_helper
INFO - 2016-02-23 13:49:39 --> Helper loaded: file_helper
INFO - 2016-02-23 13:49:39 --> Helper loaded: date_helper
INFO - 2016-02-23 13:49:39 --> Helper loaded: form_helper
INFO - 2016-02-23 13:49:39 --> Database Driver Class Initialized
INFO - 2016-02-23 13:49:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:49:40 --> Controller Class Initialized
INFO - 2016-02-23 13:49:40 --> Model Class Initialized
INFO - 2016-02-23 13:49:40 --> Model Class Initialized
INFO - 2016-02-23 13:49:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:49:40 --> Pagination Class Initialized
INFO - 2016-02-23 13:49:40 --> Helper loaded: text_helper
INFO - 2016-02-23 13:49:40 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:49:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:49:40 --> Final output sent to browser
DEBUG - 2016-02-23 16:49:40 --> Total execution time: 1.1378
INFO - 2016-02-23 13:49:42 --> Config Class Initialized
INFO - 2016-02-23 13:49:42 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:49:42 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:49:42 --> Utf8 Class Initialized
INFO - 2016-02-23 13:49:42 --> URI Class Initialized
INFO - 2016-02-23 13:49:42 --> Router Class Initialized
INFO - 2016-02-23 13:49:42 --> Output Class Initialized
INFO - 2016-02-23 13:49:42 --> Security Class Initialized
DEBUG - 2016-02-23 13:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:49:42 --> Input Class Initialized
INFO - 2016-02-23 13:49:42 --> Language Class Initialized
INFO - 2016-02-23 13:49:42 --> Loader Class Initialized
INFO - 2016-02-23 13:49:42 --> Helper loaded: url_helper
INFO - 2016-02-23 13:49:42 --> Helper loaded: file_helper
INFO - 2016-02-23 13:49:42 --> Helper loaded: date_helper
INFO - 2016-02-23 13:49:42 --> Helper loaded: form_helper
INFO - 2016-02-23 13:49:42 --> Database Driver Class Initialized
INFO - 2016-02-23 13:49:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:49:43 --> Controller Class Initialized
INFO - 2016-02-23 13:49:43 --> Model Class Initialized
INFO - 2016-02-23 13:49:43 --> Model Class Initialized
INFO - 2016-02-23 13:49:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:49:43 --> Pagination Class Initialized
INFO - 2016-02-23 13:49:43 --> Helper loaded: text_helper
INFO - 2016-02-23 13:49:43 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-02-23 16:49:43 --> Severity: Notice --> Array to string conversion C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\system\database\DB_query_builder.php 958
INFO - 2016-02-23 16:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:49:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:49:43 --> Final output sent to browser
DEBUG - 2016-02-23 16:49:43 --> Total execution time: 1.2165
INFO - 2016-02-23 13:53:45 --> Config Class Initialized
INFO - 2016-02-23 13:53:45 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:53:45 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:53:45 --> Utf8 Class Initialized
INFO - 2016-02-23 13:53:45 --> URI Class Initialized
INFO - 2016-02-23 13:53:45 --> Router Class Initialized
INFO - 2016-02-23 13:53:45 --> Output Class Initialized
INFO - 2016-02-23 13:53:45 --> Security Class Initialized
DEBUG - 2016-02-23 13:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:53:45 --> Input Class Initialized
INFO - 2016-02-23 13:53:45 --> Language Class Initialized
INFO - 2016-02-23 13:53:45 --> Loader Class Initialized
INFO - 2016-02-23 13:53:45 --> Helper loaded: url_helper
INFO - 2016-02-23 13:53:45 --> Helper loaded: file_helper
INFO - 2016-02-23 13:53:45 --> Helper loaded: date_helper
INFO - 2016-02-23 13:53:45 --> Helper loaded: form_helper
INFO - 2016-02-23 13:53:45 --> Database Driver Class Initialized
INFO - 2016-02-23 13:53:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:53:46 --> Controller Class Initialized
INFO - 2016-02-23 13:53:46 --> Model Class Initialized
INFO - 2016-02-23 13:53:46 --> Model Class Initialized
INFO - 2016-02-23 13:53:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:53:46 --> Pagination Class Initialized
INFO - 2016-02-23 13:53:46 --> Helper loaded: text_helper
INFO - 2016-02-23 13:53:46 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:53:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:53:46 --> Final output sent to browser
DEBUG - 2016-02-23 16:53:46 --> Total execution time: 1.1727
INFO - 2016-02-23 13:53:49 --> Config Class Initialized
INFO - 2016-02-23 13:53:49 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:53:49 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:53:49 --> Utf8 Class Initialized
INFO - 2016-02-23 13:53:49 --> URI Class Initialized
DEBUG - 2016-02-23 13:53:49 --> No URI present. Default controller set.
INFO - 2016-02-23 13:53:49 --> Router Class Initialized
INFO - 2016-02-23 13:53:49 --> Output Class Initialized
INFO - 2016-02-23 13:53:49 --> Security Class Initialized
DEBUG - 2016-02-23 13:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:53:49 --> Input Class Initialized
INFO - 2016-02-23 13:53:49 --> Language Class Initialized
INFO - 2016-02-23 13:53:49 --> Loader Class Initialized
INFO - 2016-02-23 13:53:49 --> Helper loaded: url_helper
INFO - 2016-02-23 13:53:49 --> Helper loaded: file_helper
INFO - 2016-02-23 13:53:49 --> Helper loaded: date_helper
INFO - 2016-02-23 13:53:49 --> Helper loaded: form_helper
INFO - 2016-02-23 13:53:49 --> Database Driver Class Initialized
INFO - 2016-02-23 13:53:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:53:50 --> Controller Class Initialized
INFO - 2016-02-23 13:53:50 --> Model Class Initialized
INFO - 2016-02-23 13:53:50 --> Model Class Initialized
INFO - 2016-02-23 13:53:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:53:50 --> Pagination Class Initialized
INFO - 2016-02-23 13:53:50 --> Helper loaded: text_helper
INFO - 2016-02-23 13:53:50 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:53:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:53:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:53:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 16:53:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:53:50 --> Final output sent to browser
DEBUG - 2016-02-23 16:53:50 --> Total execution time: 1.1233
INFO - 2016-02-23 13:56:39 --> Config Class Initialized
INFO - 2016-02-23 13:56:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:56:39 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:56:39 --> Utf8 Class Initialized
INFO - 2016-02-23 13:56:39 --> URI Class Initialized
INFO - 2016-02-23 13:56:39 --> Router Class Initialized
INFO - 2016-02-23 13:56:39 --> Output Class Initialized
INFO - 2016-02-23 13:56:39 --> Security Class Initialized
DEBUG - 2016-02-23 13:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:56:39 --> Input Class Initialized
INFO - 2016-02-23 13:56:39 --> Language Class Initialized
INFO - 2016-02-23 13:56:39 --> Loader Class Initialized
INFO - 2016-02-23 13:56:39 --> Helper loaded: url_helper
INFO - 2016-02-23 13:56:39 --> Helper loaded: file_helper
INFO - 2016-02-23 13:56:39 --> Helper loaded: date_helper
INFO - 2016-02-23 13:56:39 --> Helper loaded: form_helper
INFO - 2016-02-23 13:56:39 --> Database Driver Class Initialized
INFO - 2016-02-23 13:56:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:56:40 --> Controller Class Initialized
INFO - 2016-02-23 13:56:40 --> Model Class Initialized
INFO - 2016-02-23 13:56:40 --> Model Class Initialized
INFO - 2016-02-23 13:56:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:56:40 --> Pagination Class Initialized
INFO - 2016-02-23 13:56:40 --> Helper loaded: text_helper
INFO - 2016-02-23 13:56:40 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 16:56:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:56:40 --> Final output sent to browser
DEBUG - 2016-02-23 16:56:40 --> Total execution time: 1.1805
INFO - 2016-02-23 13:56:44 --> Config Class Initialized
INFO - 2016-02-23 13:56:44 --> Hooks Class Initialized
DEBUG - 2016-02-23 13:56:44 --> UTF-8 Support Enabled
INFO - 2016-02-23 13:56:44 --> Utf8 Class Initialized
INFO - 2016-02-23 13:56:44 --> URI Class Initialized
INFO - 2016-02-23 13:56:44 --> Router Class Initialized
INFO - 2016-02-23 13:56:44 --> Output Class Initialized
INFO - 2016-02-23 13:56:44 --> Security Class Initialized
DEBUG - 2016-02-23 13:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 13:56:44 --> Input Class Initialized
INFO - 2016-02-23 13:56:44 --> Language Class Initialized
INFO - 2016-02-23 13:56:44 --> Loader Class Initialized
INFO - 2016-02-23 13:56:44 --> Helper loaded: url_helper
INFO - 2016-02-23 13:56:44 --> Helper loaded: file_helper
INFO - 2016-02-23 13:56:44 --> Helper loaded: date_helper
INFO - 2016-02-23 13:56:44 --> Helper loaded: form_helper
INFO - 2016-02-23 13:56:44 --> Database Driver Class Initialized
INFO - 2016-02-23 13:56:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 13:56:45 --> Controller Class Initialized
INFO - 2016-02-23 13:56:45 --> Model Class Initialized
INFO - 2016-02-23 13:56:45 --> Model Class Initialized
INFO - 2016-02-23 13:56:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 13:56:45 --> Pagination Class Initialized
INFO - 2016-02-23 13:56:45 --> Helper loaded: text_helper
INFO - 2016-02-23 13:56:45 --> Helper loaded: cookie_helper
INFO - 2016-02-23 16:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 16:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 16:56:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 16:56:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 16:56:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 16:56:46 --> Final output sent to browser
DEBUG - 2016-02-23 16:56:46 --> Total execution time: 1.2028
INFO - 2016-02-23 14:02:42 --> Config Class Initialized
INFO - 2016-02-23 14:02:42 --> Hooks Class Initialized
DEBUG - 2016-02-23 14:02:42 --> UTF-8 Support Enabled
INFO - 2016-02-23 14:02:42 --> Utf8 Class Initialized
INFO - 2016-02-23 14:02:42 --> URI Class Initialized
INFO - 2016-02-23 14:02:42 --> Router Class Initialized
INFO - 2016-02-23 14:02:42 --> Output Class Initialized
INFO - 2016-02-23 14:02:42 --> Security Class Initialized
DEBUG - 2016-02-23 14:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 14:02:42 --> Input Class Initialized
INFO - 2016-02-23 14:02:42 --> Language Class Initialized
INFO - 2016-02-23 14:02:42 --> Loader Class Initialized
INFO - 2016-02-23 14:02:42 --> Helper loaded: url_helper
INFO - 2016-02-23 14:02:42 --> Helper loaded: file_helper
INFO - 2016-02-23 14:02:42 --> Helper loaded: date_helper
INFO - 2016-02-23 14:02:42 --> Helper loaded: form_helper
INFO - 2016-02-23 14:02:42 --> Database Driver Class Initialized
INFO - 2016-02-23 14:02:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 14:02:43 --> Controller Class Initialized
INFO - 2016-02-23 14:02:43 --> Model Class Initialized
INFO - 2016-02-23 14:02:43 --> Model Class Initialized
INFO - 2016-02-23 14:02:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 14:02:43 --> Pagination Class Initialized
INFO - 2016-02-23 14:02:43 --> Helper loaded: text_helper
INFO - 2016-02-23 14:02:43 --> Helper loaded: cookie_helper
INFO - 2016-02-23 17:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 17:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 17:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 17:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 17:02:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 17:02:43 --> Final output sent to browser
DEBUG - 2016-02-23 17:02:43 --> Total execution time: 1.2477
INFO - 2016-02-23 14:07:55 --> Config Class Initialized
INFO - 2016-02-23 14:07:55 --> Hooks Class Initialized
DEBUG - 2016-02-23 14:07:55 --> UTF-8 Support Enabled
INFO - 2016-02-23 14:07:55 --> Utf8 Class Initialized
INFO - 2016-02-23 14:07:55 --> URI Class Initialized
INFO - 2016-02-23 14:07:55 --> Router Class Initialized
INFO - 2016-02-23 14:07:55 --> Output Class Initialized
INFO - 2016-02-23 14:07:55 --> Security Class Initialized
DEBUG - 2016-02-23 14:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 14:07:55 --> Input Class Initialized
INFO - 2016-02-23 14:07:55 --> Language Class Initialized
INFO - 2016-02-23 14:07:55 --> Loader Class Initialized
INFO - 2016-02-23 14:07:55 --> Helper loaded: url_helper
INFO - 2016-02-23 14:07:55 --> Helper loaded: file_helper
INFO - 2016-02-23 14:07:55 --> Helper loaded: date_helper
INFO - 2016-02-23 14:07:55 --> Helper loaded: form_helper
INFO - 2016-02-23 14:07:55 --> Database Driver Class Initialized
INFO - 2016-02-23 14:07:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 14:07:56 --> Controller Class Initialized
INFO - 2016-02-23 14:07:56 --> Model Class Initialized
INFO - 2016-02-23 14:07:56 --> Model Class Initialized
INFO - 2016-02-23 14:07:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 14:07:56 --> Pagination Class Initialized
INFO - 2016-02-23 14:07:56 --> Helper loaded: text_helper
INFO - 2016-02-23 14:07:56 --> Helper loaded: cookie_helper
INFO - 2016-02-23 17:07:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 17:07:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 17:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 17:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 17:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 17:07:57 --> Final output sent to browser
DEBUG - 2016-02-23 17:07:57 --> Total execution time: 1.2162
INFO - 2016-02-23 14:08:34 --> Config Class Initialized
INFO - 2016-02-23 14:08:34 --> Hooks Class Initialized
DEBUG - 2016-02-23 14:08:34 --> UTF-8 Support Enabled
INFO - 2016-02-23 14:08:34 --> Utf8 Class Initialized
INFO - 2016-02-23 14:08:34 --> URI Class Initialized
INFO - 2016-02-23 14:08:34 --> Router Class Initialized
INFO - 2016-02-23 14:08:34 --> Output Class Initialized
INFO - 2016-02-23 14:08:34 --> Security Class Initialized
DEBUG - 2016-02-23 14:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 14:08:34 --> Input Class Initialized
INFO - 2016-02-23 14:08:34 --> Language Class Initialized
INFO - 2016-02-23 14:08:34 --> Loader Class Initialized
INFO - 2016-02-23 14:08:34 --> Helper loaded: url_helper
INFO - 2016-02-23 14:08:34 --> Helper loaded: file_helper
INFO - 2016-02-23 14:08:34 --> Helper loaded: date_helper
INFO - 2016-02-23 14:08:34 --> Helper loaded: form_helper
INFO - 2016-02-23 14:08:34 --> Database Driver Class Initialized
INFO - 2016-02-23 14:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 14:08:35 --> Controller Class Initialized
INFO - 2016-02-23 14:08:35 --> Model Class Initialized
INFO - 2016-02-23 14:08:35 --> Model Class Initialized
INFO - 2016-02-23 14:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 14:08:35 --> Pagination Class Initialized
INFO - 2016-02-23 14:08:35 --> Helper loaded: text_helper
INFO - 2016-02-23 14:08:35 --> Helper loaded: cookie_helper
INFO - 2016-02-23 17:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 17:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 17:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 17:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 17:08:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 17:08:36 --> Final output sent to browser
DEBUG - 2016-02-23 17:08:36 --> Total execution time: 1.1762
INFO - 2016-02-23 14:21:04 --> Config Class Initialized
INFO - 2016-02-23 14:21:04 --> Hooks Class Initialized
DEBUG - 2016-02-23 14:21:04 --> UTF-8 Support Enabled
INFO - 2016-02-23 14:21:04 --> Utf8 Class Initialized
INFO - 2016-02-23 14:21:04 --> URI Class Initialized
INFO - 2016-02-23 14:21:04 --> Router Class Initialized
INFO - 2016-02-23 14:21:04 --> Output Class Initialized
INFO - 2016-02-23 14:21:04 --> Security Class Initialized
DEBUG - 2016-02-23 14:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 14:21:04 --> Input Class Initialized
INFO - 2016-02-23 14:21:04 --> Language Class Initialized
INFO - 2016-02-23 14:21:04 --> Loader Class Initialized
INFO - 2016-02-23 14:21:04 --> Helper loaded: url_helper
INFO - 2016-02-23 14:21:04 --> Helper loaded: file_helper
INFO - 2016-02-23 14:21:04 --> Helper loaded: date_helper
INFO - 2016-02-23 14:21:04 --> Helper loaded: form_helper
INFO - 2016-02-23 14:21:04 --> Database Driver Class Initialized
INFO - 2016-02-23 14:21:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 14:21:05 --> Controller Class Initialized
INFO - 2016-02-23 14:21:05 --> Model Class Initialized
INFO - 2016-02-23 14:21:05 --> Model Class Initialized
INFO - 2016-02-23 14:21:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 14:21:05 --> Pagination Class Initialized
INFO - 2016-02-23 14:21:06 --> Helper loaded: text_helper
INFO - 2016-02-23 14:21:06 --> Helper loaded: cookie_helper
INFO - 2016-02-23 17:21:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 17:21:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 17:21:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 17:21:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 17:21:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 17:21:06 --> Final output sent to browser
DEBUG - 2016-02-23 17:21:06 --> Total execution time: 1.2169
INFO - 2016-02-23 14:22:35 --> Config Class Initialized
INFO - 2016-02-23 14:22:35 --> Hooks Class Initialized
DEBUG - 2016-02-23 14:22:35 --> UTF-8 Support Enabled
INFO - 2016-02-23 14:22:35 --> Utf8 Class Initialized
INFO - 2016-02-23 14:22:35 --> URI Class Initialized
INFO - 2016-02-23 14:22:35 --> Router Class Initialized
INFO - 2016-02-23 14:22:35 --> Output Class Initialized
INFO - 2016-02-23 14:22:36 --> Security Class Initialized
DEBUG - 2016-02-23 14:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 14:22:36 --> Input Class Initialized
INFO - 2016-02-23 14:22:36 --> Language Class Initialized
INFO - 2016-02-23 14:22:36 --> Loader Class Initialized
INFO - 2016-02-23 14:22:36 --> Helper loaded: url_helper
INFO - 2016-02-23 14:22:36 --> Helper loaded: file_helper
INFO - 2016-02-23 14:22:36 --> Helper loaded: date_helper
INFO - 2016-02-23 14:22:36 --> Helper loaded: form_helper
INFO - 2016-02-23 14:22:36 --> Database Driver Class Initialized
INFO - 2016-02-23 14:22:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 14:22:37 --> Controller Class Initialized
INFO - 2016-02-23 14:22:37 --> Model Class Initialized
INFO - 2016-02-23 14:22:37 --> Model Class Initialized
INFO - 2016-02-23 14:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 14:22:37 --> Pagination Class Initialized
INFO - 2016-02-23 14:22:37 --> Helper loaded: text_helper
INFO - 2016-02-23 14:22:37 --> Helper loaded: cookie_helper
INFO - 2016-02-23 17:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 17:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 17:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 17:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 17:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 17:22:37 --> Final output sent to browser
DEBUG - 2016-02-23 17:22:37 --> Total execution time: 1.1865
INFO - 2016-02-23 14:44:11 --> Config Class Initialized
INFO - 2016-02-23 14:44:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 14:44:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 14:44:11 --> Utf8 Class Initialized
INFO - 2016-02-23 14:44:11 --> URI Class Initialized
INFO - 2016-02-23 14:44:11 --> Router Class Initialized
INFO - 2016-02-23 14:44:11 --> Output Class Initialized
INFO - 2016-02-23 14:44:11 --> Security Class Initialized
DEBUG - 2016-02-23 14:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 14:44:11 --> Input Class Initialized
INFO - 2016-02-23 14:44:11 --> Language Class Initialized
INFO - 2016-02-23 14:44:11 --> Loader Class Initialized
INFO - 2016-02-23 14:44:11 --> Helper loaded: url_helper
INFO - 2016-02-23 14:44:11 --> Helper loaded: file_helper
INFO - 2016-02-23 14:44:11 --> Helper loaded: date_helper
INFO - 2016-02-23 14:44:11 --> Helper loaded: form_helper
INFO - 2016-02-23 14:44:11 --> Database Driver Class Initialized
INFO - 2016-02-23 14:44:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 14:44:12 --> Controller Class Initialized
INFO - 2016-02-23 14:44:12 --> Model Class Initialized
INFO - 2016-02-23 14:44:12 --> Model Class Initialized
INFO - 2016-02-23 14:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 14:44:12 --> Pagination Class Initialized
INFO - 2016-02-23 14:44:12 --> Helper loaded: text_helper
INFO - 2016-02-23 14:44:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 17:44:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 17:44:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 17:44:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 17:44:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 17:44:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 17:44:13 --> Final output sent to browser
DEBUG - 2016-02-23 17:44:13 --> Total execution time: 1.2629
INFO - 2016-02-23 14:44:58 --> Config Class Initialized
INFO - 2016-02-23 14:44:58 --> Hooks Class Initialized
DEBUG - 2016-02-23 14:44:58 --> UTF-8 Support Enabled
INFO - 2016-02-23 14:44:58 --> Utf8 Class Initialized
INFO - 2016-02-23 14:44:58 --> URI Class Initialized
INFO - 2016-02-23 14:44:58 --> Router Class Initialized
INFO - 2016-02-23 14:44:58 --> Output Class Initialized
INFO - 2016-02-23 14:44:58 --> Security Class Initialized
DEBUG - 2016-02-23 14:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 14:44:58 --> Input Class Initialized
INFO - 2016-02-23 14:44:58 --> Language Class Initialized
INFO - 2016-02-23 14:44:58 --> Loader Class Initialized
INFO - 2016-02-23 14:44:58 --> Helper loaded: url_helper
INFO - 2016-02-23 14:44:58 --> Helper loaded: file_helper
INFO - 2016-02-23 14:44:58 --> Helper loaded: date_helper
INFO - 2016-02-23 14:44:58 --> Helper loaded: form_helper
INFO - 2016-02-23 14:44:58 --> Database Driver Class Initialized
INFO - 2016-02-23 14:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 14:44:59 --> Controller Class Initialized
INFO - 2016-02-23 14:44:59 --> Model Class Initialized
INFO - 2016-02-23 14:44:59 --> Model Class Initialized
INFO - 2016-02-23 14:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 14:44:59 --> Pagination Class Initialized
INFO - 2016-02-23 14:44:59 --> Helper loaded: text_helper
INFO - 2016-02-23 14:44:59 --> Helper loaded: cookie_helper
INFO - 2016-02-23 17:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 17:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 17:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 17:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 17:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 17:44:59 --> Final output sent to browser
DEBUG - 2016-02-23 17:44:59 --> Total execution time: 1.1722
INFO - 2016-02-23 18:03:37 --> Config Class Initialized
INFO - 2016-02-23 18:03:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:03:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:03:37 --> Utf8 Class Initialized
INFO - 2016-02-23 18:03:37 --> URI Class Initialized
DEBUG - 2016-02-23 18:03:37 --> No URI present. Default controller set.
INFO - 2016-02-23 18:03:37 --> Router Class Initialized
INFO - 2016-02-23 18:03:37 --> Output Class Initialized
INFO - 2016-02-23 18:03:37 --> Security Class Initialized
DEBUG - 2016-02-23 18:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:03:37 --> Input Class Initialized
INFO - 2016-02-23 18:03:37 --> Language Class Initialized
INFO - 2016-02-23 18:03:37 --> Loader Class Initialized
INFO - 2016-02-23 18:03:37 --> Helper loaded: url_helper
INFO - 2016-02-23 18:03:37 --> Helper loaded: file_helper
INFO - 2016-02-23 18:03:37 --> Helper loaded: date_helper
INFO - 2016-02-23 18:03:37 --> Helper loaded: form_helper
INFO - 2016-02-23 18:03:37 --> Database Driver Class Initialized
INFO - 2016-02-23 18:03:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:03:38 --> Controller Class Initialized
INFO - 2016-02-23 18:03:38 --> Model Class Initialized
INFO - 2016-02-23 18:03:38 --> Model Class Initialized
INFO - 2016-02-23 18:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:03:38 --> Pagination Class Initialized
INFO - 2016-02-23 18:03:38 --> Helper loaded: text_helper
INFO - 2016-02-23 18:03:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:03:38 --> Final output sent to browser
DEBUG - 2016-02-23 21:03:38 --> Total execution time: 1.1787
INFO - 2016-02-23 18:03:48 --> Config Class Initialized
INFO - 2016-02-23 18:03:48 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:03:48 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:03:48 --> Utf8 Class Initialized
INFO - 2016-02-23 18:03:48 --> URI Class Initialized
INFO - 2016-02-23 18:03:48 --> Router Class Initialized
INFO - 2016-02-23 18:03:48 --> Output Class Initialized
INFO - 2016-02-23 18:03:48 --> Security Class Initialized
DEBUG - 2016-02-23 18:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:03:48 --> Input Class Initialized
INFO - 2016-02-23 18:03:48 --> Language Class Initialized
INFO - 2016-02-23 18:03:48 --> Loader Class Initialized
INFO - 2016-02-23 18:03:48 --> Helper loaded: url_helper
INFO - 2016-02-23 18:03:48 --> Helper loaded: file_helper
INFO - 2016-02-23 18:03:48 --> Helper loaded: date_helper
INFO - 2016-02-23 18:03:48 --> Helper loaded: form_helper
INFO - 2016-02-23 18:03:48 --> Database Driver Class Initialized
INFO - 2016-02-23 18:03:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:03:49 --> Controller Class Initialized
INFO - 2016-02-23 18:03:49 --> Model Class Initialized
INFO - 2016-02-23 18:03:49 --> Model Class Initialized
INFO - 2016-02-23 18:03:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:03:49 --> Pagination Class Initialized
INFO - 2016-02-23 18:03:49 --> Helper loaded: text_helper
INFO - 2016-02-23 18:03:49 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 21:03:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:03:49 --> Final output sent to browser
DEBUG - 2016-02-23 21:03:49 --> Total execution time: 1.1535
INFO - 2016-02-23 18:04:07 --> Config Class Initialized
INFO - 2016-02-23 18:04:07 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:04:07 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:04:07 --> Utf8 Class Initialized
INFO - 2016-02-23 18:04:07 --> URI Class Initialized
INFO - 2016-02-23 18:04:07 --> Router Class Initialized
INFO - 2016-02-23 18:04:07 --> Output Class Initialized
INFO - 2016-02-23 18:04:07 --> Security Class Initialized
DEBUG - 2016-02-23 18:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:04:07 --> Input Class Initialized
INFO - 2016-02-23 18:04:07 --> Language Class Initialized
INFO - 2016-02-23 18:04:07 --> Loader Class Initialized
INFO - 2016-02-23 18:04:07 --> Helper loaded: url_helper
INFO - 2016-02-23 18:04:07 --> Helper loaded: file_helper
INFO - 2016-02-23 18:04:08 --> Helper loaded: date_helper
INFO - 2016-02-23 18:04:08 --> Helper loaded: form_helper
INFO - 2016-02-23 18:04:08 --> Database Driver Class Initialized
INFO - 2016-02-23 18:04:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:04:09 --> Controller Class Initialized
INFO - 2016-02-23 18:04:09 --> Model Class Initialized
INFO - 2016-02-23 18:04:09 --> Model Class Initialized
INFO - 2016-02-23 18:04:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:04:09 --> Pagination Class Initialized
INFO - 2016-02-23 18:04:09 --> Helper loaded: text_helper
INFO - 2016-02-23 18:04:09 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 21:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 21:04:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:04:09 --> Final output sent to browser
DEBUG - 2016-02-23 21:04:09 --> Total execution time: 1.1776
INFO - 2016-02-23 18:04:10 --> Config Class Initialized
INFO - 2016-02-23 18:04:10 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:04:10 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:04:10 --> Utf8 Class Initialized
INFO - 2016-02-23 18:04:10 --> URI Class Initialized
INFO - 2016-02-23 18:04:10 --> Router Class Initialized
INFO - 2016-02-23 18:04:10 --> Output Class Initialized
INFO - 2016-02-23 18:04:10 --> Security Class Initialized
DEBUG - 2016-02-23 18:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:04:10 --> Input Class Initialized
INFO - 2016-02-23 18:04:10 --> Language Class Initialized
INFO - 2016-02-23 18:04:10 --> Loader Class Initialized
INFO - 2016-02-23 18:04:10 --> Helper loaded: url_helper
INFO - 2016-02-23 18:04:10 --> Helper loaded: file_helper
INFO - 2016-02-23 18:04:10 --> Helper loaded: date_helper
INFO - 2016-02-23 18:04:10 --> Helper loaded: form_helper
INFO - 2016-02-23 18:04:10 --> Database Driver Class Initialized
INFO - 2016-02-23 18:04:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:04:12 --> Controller Class Initialized
INFO - 2016-02-23 18:04:12 --> Model Class Initialized
INFO - 2016-02-23 18:04:12 --> Model Class Initialized
INFO - 2016-02-23 18:04:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:04:12 --> Pagination Class Initialized
INFO - 2016-02-23 18:04:12 --> Helper loaded: text_helper
INFO - 2016-02-23 18:04:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:04:12 --> Final output sent to browser
DEBUG - 2016-02-23 21:04:12 --> Total execution time: 1.1297
INFO - 2016-02-23 18:04:38 --> Config Class Initialized
INFO - 2016-02-23 18:04:38 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:04:38 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:04:38 --> Utf8 Class Initialized
INFO - 2016-02-23 18:04:38 --> URI Class Initialized
DEBUG - 2016-02-23 18:04:38 --> No URI present. Default controller set.
INFO - 2016-02-23 18:04:38 --> Router Class Initialized
INFO - 2016-02-23 18:04:38 --> Output Class Initialized
INFO - 2016-02-23 18:04:38 --> Security Class Initialized
DEBUG - 2016-02-23 18:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:04:38 --> Input Class Initialized
INFO - 2016-02-23 18:04:38 --> Language Class Initialized
INFO - 2016-02-23 18:04:38 --> Loader Class Initialized
INFO - 2016-02-23 18:04:38 --> Helper loaded: url_helper
INFO - 2016-02-23 18:04:38 --> Helper loaded: file_helper
INFO - 2016-02-23 18:04:38 --> Helper loaded: date_helper
INFO - 2016-02-23 18:04:38 --> Helper loaded: form_helper
INFO - 2016-02-23 18:04:38 --> Database Driver Class Initialized
INFO - 2016-02-23 18:04:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:04:39 --> Controller Class Initialized
INFO - 2016-02-23 18:04:39 --> Model Class Initialized
INFO - 2016-02-23 18:04:39 --> Model Class Initialized
INFO - 2016-02-23 18:04:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:04:39 --> Pagination Class Initialized
INFO - 2016-02-23 18:04:39 --> Helper loaded: text_helper
INFO - 2016-02-23 18:04:39 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:04:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:04:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:04:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:04:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:04:39 --> Final output sent to browser
DEBUG - 2016-02-23 21:04:39 --> Total execution time: 1.1189
INFO - 2016-02-23 18:10:25 --> Config Class Initialized
INFO - 2016-02-23 18:10:25 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:10:25 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:10:25 --> Utf8 Class Initialized
INFO - 2016-02-23 18:10:25 --> URI Class Initialized
INFO - 2016-02-23 18:10:25 --> Router Class Initialized
INFO - 2016-02-23 18:10:25 --> Output Class Initialized
INFO - 2016-02-23 18:10:25 --> Security Class Initialized
DEBUG - 2016-02-23 18:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:10:25 --> Input Class Initialized
INFO - 2016-02-23 18:10:26 --> Language Class Initialized
INFO - 2016-02-23 18:10:26 --> Loader Class Initialized
INFO - 2016-02-23 18:10:26 --> Helper loaded: url_helper
INFO - 2016-02-23 18:10:26 --> Helper loaded: file_helper
INFO - 2016-02-23 18:10:26 --> Helper loaded: date_helper
INFO - 2016-02-23 18:10:26 --> Helper loaded: form_helper
INFO - 2016-02-23 18:10:26 --> Database Driver Class Initialized
INFO - 2016-02-23 18:10:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:10:27 --> Controller Class Initialized
INFO - 2016-02-23 18:10:27 --> Model Class Initialized
INFO - 2016-02-23 18:10:27 --> Model Class Initialized
INFO - 2016-02-23 18:10:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:10:27 --> Pagination Class Initialized
INFO - 2016-02-23 18:10:27 --> Helper loaded: text_helper
INFO - 2016-02-23 18:10:27 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 21:10:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:10:27 --> Final output sent to browser
DEBUG - 2016-02-23 21:10:27 --> Total execution time: 1.1093
INFO - 2016-02-23 18:10:29 --> Config Class Initialized
INFO - 2016-02-23 18:10:29 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:10:29 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:10:29 --> Utf8 Class Initialized
INFO - 2016-02-23 18:10:29 --> URI Class Initialized
INFO - 2016-02-23 18:10:29 --> Router Class Initialized
INFO - 2016-02-23 18:10:29 --> Output Class Initialized
INFO - 2016-02-23 18:10:29 --> Security Class Initialized
DEBUG - 2016-02-23 18:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:10:29 --> Input Class Initialized
INFO - 2016-02-23 18:10:29 --> Language Class Initialized
INFO - 2016-02-23 18:10:30 --> Loader Class Initialized
INFO - 2016-02-23 18:10:30 --> Helper loaded: url_helper
INFO - 2016-02-23 18:10:30 --> Helper loaded: file_helper
INFO - 2016-02-23 18:10:30 --> Helper loaded: date_helper
INFO - 2016-02-23 18:10:30 --> Helper loaded: form_helper
INFO - 2016-02-23 18:10:30 --> Database Driver Class Initialized
INFO - 2016-02-23 18:10:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:10:31 --> Controller Class Initialized
INFO - 2016-02-23 18:10:31 --> Model Class Initialized
INFO - 2016-02-23 18:10:31 --> Model Class Initialized
INFO - 2016-02-23 18:10:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:10:31 --> Pagination Class Initialized
INFO - 2016-02-23 18:10:31 --> Helper loaded: text_helper
INFO - 2016-02-23 18:10:31 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 21:10:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:10:31 --> Final output sent to browser
DEBUG - 2016-02-23 21:10:31 --> Total execution time: 1.2915
INFO - 2016-02-23 18:10:39 --> Config Class Initialized
INFO - 2016-02-23 18:10:39 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:10:39 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:10:39 --> Utf8 Class Initialized
INFO - 2016-02-23 18:10:39 --> URI Class Initialized
INFO - 2016-02-23 18:10:39 --> Router Class Initialized
INFO - 2016-02-23 18:10:39 --> Output Class Initialized
INFO - 2016-02-23 18:10:39 --> Security Class Initialized
DEBUG - 2016-02-23 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:10:39 --> Input Class Initialized
INFO - 2016-02-23 18:10:39 --> Language Class Initialized
INFO - 2016-02-23 18:10:39 --> Loader Class Initialized
INFO - 2016-02-23 18:10:39 --> Helper loaded: url_helper
INFO - 2016-02-23 18:10:39 --> Helper loaded: file_helper
INFO - 2016-02-23 18:10:39 --> Helper loaded: date_helper
INFO - 2016-02-23 18:10:39 --> Helper loaded: form_helper
INFO - 2016-02-23 18:10:39 --> Database Driver Class Initialized
INFO - 2016-02-23 18:10:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:10:40 --> Controller Class Initialized
INFO - 2016-02-23 18:10:40 --> Model Class Initialized
INFO - 2016-02-23 18:10:40 --> Model Class Initialized
INFO - 2016-02-23 18:10:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:10:40 --> Pagination Class Initialized
INFO - 2016-02-23 18:10:40 --> Helper loaded: text_helper
INFO - 2016-02-23 18:10:40 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:10:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:10:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:10:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 21:10:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 21:10:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:10:40 --> Final output sent to browser
DEBUG - 2016-02-23 21:10:40 --> Total execution time: 1.1995
INFO - 2016-02-23 18:10:44 --> Config Class Initialized
INFO - 2016-02-23 18:10:44 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:10:44 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:10:44 --> Utf8 Class Initialized
INFO - 2016-02-23 18:10:44 --> URI Class Initialized
INFO - 2016-02-23 18:10:44 --> Router Class Initialized
INFO - 2016-02-23 18:10:44 --> Output Class Initialized
INFO - 2016-02-23 18:10:44 --> Security Class Initialized
DEBUG - 2016-02-23 18:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:10:44 --> Input Class Initialized
INFO - 2016-02-23 18:10:44 --> Language Class Initialized
INFO - 2016-02-23 18:10:44 --> Loader Class Initialized
INFO - 2016-02-23 18:10:44 --> Helper loaded: url_helper
INFO - 2016-02-23 18:10:44 --> Helper loaded: file_helper
INFO - 2016-02-23 18:10:44 --> Helper loaded: date_helper
INFO - 2016-02-23 18:10:44 --> Helper loaded: form_helper
INFO - 2016-02-23 18:10:44 --> Database Driver Class Initialized
INFO - 2016-02-23 18:10:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:10:45 --> Controller Class Initialized
INFO - 2016-02-23 18:10:45 --> Model Class Initialized
INFO - 2016-02-23 18:10:45 --> Model Class Initialized
INFO - 2016-02-23 18:10:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:10:45 --> Pagination Class Initialized
INFO - 2016-02-23 18:10:45 --> Helper loaded: text_helper
INFO - 2016-02-23 18:10:45 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:10:45 --> Final output sent to browser
DEBUG - 2016-02-23 21:10:45 --> Total execution time: 1.1069
INFO - 2016-02-23 18:11:01 --> Config Class Initialized
INFO - 2016-02-23 18:11:01 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:01 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:01 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:01 --> URI Class Initialized
INFO - 2016-02-23 18:11:01 --> Router Class Initialized
INFO - 2016-02-23 18:11:01 --> Output Class Initialized
INFO - 2016-02-23 18:11:01 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:01 --> Input Class Initialized
INFO - 2016-02-23 18:11:01 --> Language Class Initialized
INFO - 2016-02-23 18:11:01 --> Loader Class Initialized
INFO - 2016-02-23 18:11:01 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:01 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:01 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:01 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:01 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:02 --> Controller Class Initialized
INFO - 2016-02-23 18:11:02 --> Model Class Initialized
INFO - 2016-02-23 18:11:02 --> Model Class Initialized
INFO - 2016-02-23 18:11:02 --> Form Validation Class Initialized
INFO - 2016-02-23 18:11:02 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:03 --> Config Class Initialized
INFO - 2016-02-23 18:11:03 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:03 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:03 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:03 --> URI Class Initialized
INFO - 2016-02-23 18:11:03 --> Router Class Initialized
INFO - 2016-02-23 18:11:03 --> Output Class Initialized
INFO - 2016-02-23 18:11:03 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:03 --> Input Class Initialized
INFO - 2016-02-23 18:11:03 --> Language Class Initialized
INFO - 2016-02-23 18:11:03 --> Loader Class Initialized
INFO - 2016-02-23 18:11:03 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:03 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:03 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:03 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:03 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:04 --> Controller Class Initialized
INFO - 2016-02-23 18:11:04 --> Model Class Initialized
INFO - 2016-02-23 18:11:04 --> Model Class Initialized
INFO - 2016-02-23 18:11:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:11:04 --> Pagination Class Initialized
INFO - 2016-02-23 18:11:04 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:04 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 21:11:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:11:04 --> Final output sent to browser
DEBUG - 2016-02-23 21:11:04 --> Total execution time: 1.1427
INFO - 2016-02-23 18:11:05 --> Config Class Initialized
INFO - 2016-02-23 18:11:05 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:05 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:05 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:05 --> URI Class Initialized
INFO - 2016-02-23 18:11:05 --> Router Class Initialized
INFO - 2016-02-23 18:11:05 --> Output Class Initialized
INFO - 2016-02-23 18:11:05 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:05 --> Input Class Initialized
INFO - 2016-02-23 18:11:05 --> Language Class Initialized
INFO - 2016-02-23 18:11:05 --> Loader Class Initialized
INFO - 2016-02-23 18:11:06 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:06 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:06 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:06 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:06 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:07 --> Controller Class Initialized
INFO - 2016-02-23 18:11:07 --> Model Class Initialized
INFO - 2016-02-23 18:11:07 --> Model Class Initialized
INFO - 2016-02-23 18:11:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:11:07 --> Pagination Class Initialized
INFO - 2016-02-23 18:11:07 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:07 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:11:07 --> Final output sent to browser
DEBUG - 2016-02-23 21:11:07 --> Total execution time: 1.3243
INFO - 2016-02-23 18:11:11 --> Config Class Initialized
INFO - 2016-02-23 18:11:11 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:11 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:11 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:11 --> URI Class Initialized
INFO - 2016-02-23 18:11:11 --> Router Class Initialized
INFO - 2016-02-23 18:11:11 --> Output Class Initialized
INFO - 2016-02-23 18:11:11 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:11 --> Input Class Initialized
INFO - 2016-02-23 18:11:11 --> Language Class Initialized
INFO - 2016-02-23 18:11:11 --> Loader Class Initialized
INFO - 2016-02-23 18:11:11 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:11 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:11 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:11 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:11 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:12 --> Controller Class Initialized
INFO - 2016-02-23 18:11:12 --> Model Class Initialized
INFO - 2016-02-23 18:11:12 --> Model Class Initialized
INFO - 2016-02-23 18:11:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:11:12 --> Pagination Class Initialized
INFO - 2016-02-23 18:11:12 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:12 --> Helper loaded: cookie_helper
INFO - 2016-02-23 18:11:21 --> Config Class Initialized
INFO - 2016-02-23 18:11:21 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:21 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:21 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:21 --> URI Class Initialized
INFO - 2016-02-23 18:11:21 --> Router Class Initialized
INFO - 2016-02-23 18:11:21 --> Output Class Initialized
INFO - 2016-02-23 18:11:21 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:21 --> Input Class Initialized
INFO - 2016-02-23 18:11:21 --> Language Class Initialized
INFO - 2016-02-23 18:11:21 --> Loader Class Initialized
INFO - 2016-02-23 18:11:21 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:21 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:21 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:21 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:21 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:22 --> Controller Class Initialized
INFO - 2016-02-23 18:11:22 --> Model Class Initialized
INFO - 2016-02-23 18:11:22 --> Model Class Initialized
INFO - 2016-02-23 18:11:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:11:22 --> Pagination Class Initialized
INFO - 2016-02-23 18:11:22 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:22 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:11:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:11:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:11:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 21:11:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:11:22 --> Final output sent to browser
DEBUG - 2016-02-23 21:11:22 --> Total execution time: 1.1567
INFO - 2016-02-23 18:11:23 --> Config Class Initialized
INFO - 2016-02-23 18:11:23 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:23 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:23 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:23 --> URI Class Initialized
INFO - 2016-02-23 18:11:23 --> Router Class Initialized
INFO - 2016-02-23 18:11:23 --> Output Class Initialized
INFO - 2016-02-23 18:11:23 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:23 --> Input Class Initialized
INFO - 2016-02-23 18:11:23 --> Language Class Initialized
INFO - 2016-02-23 18:11:23 --> Loader Class Initialized
INFO - 2016-02-23 18:11:23 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:23 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:23 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:23 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:23 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:24 --> Controller Class Initialized
INFO - 2016-02-23 18:11:24 --> Model Class Initialized
INFO - 2016-02-23 18:11:24 --> Model Class Initialized
INFO - 2016-02-23 18:11:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:11:24 --> Pagination Class Initialized
INFO - 2016-02-23 18:11:24 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:24 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:11:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:11:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:11:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-02-23 21:11:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-02-23 21:11:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:11:24 --> Final output sent to browser
DEBUG - 2016-02-23 21:11:24 --> Total execution time: 1.1358
INFO - 2016-02-23 18:11:29 --> Config Class Initialized
INFO - 2016-02-23 18:11:29 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:29 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:29 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:29 --> URI Class Initialized
INFO - 2016-02-23 18:11:29 --> Router Class Initialized
INFO - 2016-02-23 18:11:29 --> Output Class Initialized
INFO - 2016-02-23 18:11:29 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:29 --> Input Class Initialized
INFO - 2016-02-23 18:11:29 --> Language Class Initialized
INFO - 2016-02-23 18:11:29 --> Loader Class Initialized
INFO - 2016-02-23 18:11:29 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:29 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:29 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:29 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:29 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:30 --> Controller Class Initialized
INFO - 2016-02-23 18:11:30 --> Model Class Initialized
INFO - 2016-02-23 18:11:30 --> Model Class Initialized
INFO - 2016-02-23 18:11:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:11:30 --> Pagination Class Initialized
INFO - 2016-02-23 18:11:30 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:30 --> Helper loaded: cookie_helper
INFO - 2016-02-23 18:11:40 --> Config Class Initialized
INFO - 2016-02-23 18:11:40 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:40 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:40 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:40 --> URI Class Initialized
INFO - 2016-02-23 18:11:40 --> Router Class Initialized
INFO - 2016-02-23 18:11:40 --> Output Class Initialized
INFO - 2016-02-23 18:11:40 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:40 --> Input Class Initialized
INFO - 2016-02-23 18:11:40 --> Language Class Initialized
INFO - 2016-02-23 18:11:40 --> Loader Class Initialized
INFO - 2016-02-23 18:11:40 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:40 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:40 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:40 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:40 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:41 --> Controller Class Initialized
INFO - 2016-02-23 18:11:41 --> Model Class Initialized
INFO - 2016-02-23 18:11:41 --> Model Class Initialized
INFO - 2016-02-23 18:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:11:41 --> Pagination Class Initialized
INFO - 2016-02-23 18:11:41 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:41 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-02-23 21:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:11:41 --> Final output sent to browser
DEBUG - 2016-02-23 21:11:41 --> Total execution time: 1.1440
INFO - 2016-02-23 18:11:43 --> Config Class Initialized
INFO - 2016-02-23 18:11:43 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:11:43 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:11:43 --> Utf8 Class Initialized
INFO - 2016-02-23 18:11:43 --> URI Class Initialized
DEBUG - 2016-02-23 18:11:43 --> No URI present. Default controller set.
INFO - 2016-02-23 18:11:43 --> Router Class Initialized
INFO - 2016-02-23 18:11:43 --> Output Class Initialized
INFO - 2016-02-23 18:11:43 --> Security Class Initialized
DEBUG - 2016-02-23 18:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:11:43 --> Input Class Initialized
INFO - 2016-02-23 18:11:43 --> Language Class Initialized
INFO - 2016-02-23 18:11:43 --> Loader Class Initialized
INFO - 2016-02-23 18:11:43 --> Helper loaded: url_helper
INFO - 2016-02-23 18:11:43 --> Helper loaded: file_helper
INFO - 2016-02-23 18:11:43 --> Helper loaded: date_helper
INFO - 2016-02-23 18:11:43 --> Helper loaded: form_helper
INFO - 2016-02-23 18:11:43 --> Database Driver Class Initialized
INFO - 2016-02-23 18:11:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:11:44 --> Controller Class Initialized
INFO - 2016-02-23 18:11:44 --> Model Class Initialized
INFO - 2016-02-23 18:11:44 --> Model Class Initialized
INFO - 2016-02-23 18:11:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:11:44 --> Pagination Class Initialized
INFO - 2016-02-23 18:11:44 --> Helper loaded: text_helper
INFO - 2016-02-23 18:11:44 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:11:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:11:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:11:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:11:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:11:44 --> Final output sent to browser
DEBUG - 2016-02-23 21:11:44 --> Total execution time: 1.1386
INFO - 2016-02-23 18:16:14 --> Config Class Initialized
INFO - 2016-02-23 18:16:14 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:16:14 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:16:14 --> Utf8 Class Initialized
INFO - 2016-02-23 18:16:14 --> URI Class Initialized
DEBUG - 2016-02-23 18:16:14 --> No URI present. Default controller set.
INFO - 2016-02-23 18:16:14 --> Router Class Initialized
INFO - 2016-02-23 18:16:14 --> Output Class Initialized
INFO - 2016-02-23 18:16:15 --> Security Class Initialized
DEBUG - 2016-02-23 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:16:15 --> Input Class Initialized
INFO - 2016-02-23 18:16:15 --> Language Class Initialized
INFO - 2016-02-23 18:16:15 --> Loader Class Initialized
INFO - 2016-02-23 18:16:15 --> Helper loaded: url_helper
INFO - 2016-02-23 18:16:15 --> Helper loaded: file_helper
INFO - 2016-02-23 18:16:15 --> Helper loaded: date_helper
INFO - 2016-02-23 18:16:15 --> Helper loaded: form_helper
INFO - 2016-02-23 18:16:15 --> Database Driver Class Initialized
INFO - 2016-02-23 18:16:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:16:16 --> Controller Class Initialized
INFO - 2016-02-23 18:16:16 --> Model Class Initialized
INFO - 2016-02-23 18:16:16 --> Model Class Initialized
INFO - 2016-02-23 18:16:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:16:16 --> Pagination Class Initialized
INFO - 2016-02-23 18:16:16 --> Helper loaded: text_helper
INFO - 2016-02-23 18:16:16 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:16:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:16:16 --> Final output sent to browser
DEBUG - 2016-02-23 21:16:16 --> Total execution time: 1.1651
INFO - 2016-02-23 18:16:37 --> Config Class Initialized
INFO - 2016-02-23 18:16:37 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:16:37 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:16:37 --> Utf8 Class Initialized
INFO - 2016-02-23 18:16:37 --> URI Class Initialized
DEBUG - 2016-02-23 18:16:37 --> No URI present. Default controller set.
INFO - 2016-02-23 18:16:37 --> Router Class Initialized
INFO - 2016-02-23 18:16:37 --> Output Class Initialized
INFO - 2016-02-23 18:16:37 --> Security Class Initialized
DEBUG - 2016-02-23 18:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:16:37 --> Input Class Initialized
INFO - 2016-02-23 18:16:37 --> Language Class Initialized
INFO - 2016-02-23 18:16:37 --> Loader Class Initialized
INFO - 2016-02-23 18:16:37 --> Helper loaded: url_helper
INFO - 2016-02-23 18:16:37 --> Helper loaded: file_helper
INFO - 2016-02-23 18:16:37 --> Helper loaded: date_helper
INFO - 2016-02-23 18:16:37 --> Helper loaded: form_helper
INFO - 2016-02-23 18:16:37 --> Database Driver Class Initialized
INFO - 2016-02-23 18:16:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:16:38 --> Controller Class Initialized
INFO - 2016-02-23 18:16:38 --> Model Class Initialized
INFO - 2016-02-23 18:16:38 --> Model Class Initialized
INFO - 2016-02-23 18:16:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:16:38 --> Pagination Class Initialized
INFO - 2016-02-23 18:16:38 --> Helper loaded: text_helper
INFO - 2016-02-23 18:16:38 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:16:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:16:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:16:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:16:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:16:38 --> Final output sent to browser
DEBUG - 2016-02-23 21:16:38 --> Total execution time: 1.1890
INFO - 2016-02-23 18:17:35 --> Config Class Initialized
INFO - 2016-02-23 18:17:35 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:17:35 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:17:35 --> Utf8 Class Initialized
INFO - 2016-02-23 18:17:35 --> URI Class Initialized
DEBUG - 2016-02-23 18:17:35 --> No URI present. Default controller set.
INFO - 2016-02-23 18:17:35 --> Router Class Initialized
INFO - 2016-02-23 18:17:35 --> Output Class Initialized
INFO - 2016-02-23 18:17:35 --> Security Class Initialized
DEBUG - 2016-02-23 18:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:17:35 --> Input Class Initialized
INFO - 2016-02-23 18:17:35 --> Language Class Initialized
INFO - 2016-02-23 18:17:35 --> Loader Class Initialized
INFO - 2016-02-23 18:17:35 --> Helper loaded: url_helper
INFO - 2016-02-23 18:17:35 --> Helper loaded: file_helper
INFO - 2016-02-23 18:17:35 --> Helper loaded: date_helper
INFO - 2016-02-23 18:17:35 --> Helper loaded: form_helper
INFO - 2016-02-23 18:17:35 --> Database Driver Class Initialized
INFO - 2016-02-23 18:17:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:17:36 --> Controller Class Initialized
INFO - 2016-02-23 18:17:36 --> Model Class Initialized
INFO - 2016-02-23 18:17:36 --> Model Class Initialized
INFO - 2016-02-23 18:17:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:17:36 --> Pagination Class Initialized
INFO - 2016-02-23 18:17:36 --> Helper loaded: text_helper
INFO - 2016-02-23 18:17:36 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:17:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:17:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:17:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:17:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:17:36 --> Final output sent to browser
DEBUG - 2016-02-23 21:17:36 --> Total execution time: 1.1494
INFO - 2016-02-23 18:17:58 --> Config Class Initialized
INFO - 2016-02-23 18:17:58 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:17:58 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:17:58 --> Utf8 Class Initialized
INFO - 2016-02-23 18:17:58 --> URI Class Initialized
DEBUG - 2016-02-23 18:17:58 --> No URI present. Default controller set.
INFO - 2016-02-23 18:17:58 --> Router Class Initialized
INFO - 2016-02-23 18:17:58 --> Output Class Initialized
INFO - 2016-02-23 18:17:58 --> Security Class Initialized
DEBUG - 2016-02-23 18:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:17:58 --> Input Class Initialized
INFO - 2016-02-23 18:17:58 --> Language Class Initialized
INFO - 2016-02-23 18:17:58 --> Loader Class Initialized
INFO - 2016-02-23 18:17:58 --> Helper loaded: url_helper
INFO - 2016-02-23 18:17:58 --> Helper loaded: file_helper
INFO - 2016-02-23 18:17:58 --> Helper loaded: date_helper
INFO - 2016-02-23 18:17:58 --> Helper loaded: form_helper
INFO - 2016-02-23 18:17:58 --> Database Driver Class Initialized
INFO - 2016-02-23 18:17:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:17:59 --> Controller Class Initialized
INFO - 2016-02-23 18:17:59 --> Model Class Initialized
INFO - 2016-02-23 18:17:59 --> Model Class Initialized
INFO - 2016-02-23 18:17:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:17:59 --> Pagination Class Initialized
INFO - 2016-02-23 18:17:59 --> Helper loaded: text_helper
INFO - 2016-02-23 18:17:59 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:17:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:17:59 --> Final output sent to browser
DEBUG - 2016-02-23 21:17:59 --> Total execution time: 1.1652
INFO - 2016-02-23 18:18:25 --> Config Class Initialized
INFO - 2016-02-23 18:18:25 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:18:25 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:18:25 --> Utf8 Class Initialized
INFO - 2016-02-23 18:18:25 --> URI Class Initialized
DEBUG - 2016-02-23 18:18:25 --> No URI present. Default controller set.
INFO - 2016-02-23 18:18:25 --> Router Class Initialized
INFO - 2016-02-23 18:18:25 --> Output Class Initialized
INFO - 2016-02-23 18:18:25 --> Security Class Initialized
DEBUG - 2016-02-23 18:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:18:25 --> Input Class Initialized
INFO - 2016-02-23 18:18:25 --> Language Class Initialized
INFO - 2016-02-23 18:18:25 --> Loader Class Initialized
INFO - 2016-02-23 18:18:25 --> Helper loaded: url_helper
INFO - 2016-02-23 18:18:25 --> Helper loaded: file_helper
INFO - 2016-02-23 18:18:25 --> Helper loaded: date_helper
INFO - 2016-02-23 18:18:25 --> Helper loaded: form_helper
INFO - 2016-02-23 18:18:25 --> Database Driver Class Initialized
INFO - 2016-02-23 18:18:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:18:26 --> Controller Class Initialized
INFO - 2016-02-23 18:18:26 --> Model Class Initialized
INFO - 2016-02-23 18:18:26 --> Model Class Initialized
INFO - 2016-02-23 18:18:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:18:26 --> Pagination Class Initialized
INFO - 2016-02-23 18:18:27 --> Helper loaded: text_helper
INFO - 2016-02-23 18:18:27 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:18:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:18:27 --> Final output sent to browser
DEBUG - 2016-02-23 21:18:27 --> Total execution time: 1.1566
INFO - 2016-02-23 18:18:32 --> Config Class Initialized
INFO - 2016-02-23 18:18:32 --> Hooks Class Initialized
DEBUG - 2016-02-23 18:18:32 --> UTF-8 Support Enabled
INFO - 2016-02-23 18:18:32 --> Utf8 Class Initialized
INFO - 2016-02-23 18:18:32 --> URI Class Initialized
DEBUG - 2016-02-23 18:18:32 --> No URI present. Default controller set.
INFO - 2016-02-23 18:18:32 --> Router Class Initialized
INFO - 2016-02-23 18:18:32 --> Output Class Initialized
INFO - 2016-02-23 18:18:32 --> Security Class Initialized
DEBUG - 2016-02-23 18:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-02-23 18:18:32 --> Input Class Initialized
INFO - 2016-02-23 18:18:32 --> Language Class Initialized
INFO - 2016-02-23 18:18:32 --> Loader Class Initialized
INFO - 2016-02-23 18:18:32 --> Helper loaded: url_helper
INFO - 2016-02-23 18:18:32 --> Helper loaded: file_helper
INFO - 2016-02-23 18:18:32 --> Helper loaded: date_helper
INFO - 2016-02-23 18:18:32 --> Helper loaded: form_helper
INFO - 2016-02-23 18:18:32 --> Database Driver Class Initialized
INFO - 2016-02-23 18:18:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-02-23 18:18:33 --> Controller Class Initialized
INFO - 2016-02-23 18:18:33 --> Model Class Initialized
INFO - 2016-02-23 18:18:33 --> Model Class Initialized
INFO - 2016-02-23 18:18:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-02-23 18:18:33 --> Pagination Class Initialized
INFO - 2016-02-23 18:18:33 --> Helper loaded: text_helper
INFO - 2016-02-23 18:18:33 --> Helper loaded: cookie_helper
INFO - 2016-02-23 21:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-02-23 21:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-02-23 21:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-02-23 21:18:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-02-23 21:18:33 --> Final output sent to browser
DEBUG - 2016-02-23 21:18:33 --> Total execution time: 1.1641
