<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-07 06:41:54 --> Config Class Initialized
INFO - 2016-03-07 06:41:54 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:41:54 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:41:54 --> Utf8 Class Initialized
INFO - 2016-03-07 06:41:54 --> URI Class Initialized
INFO - 2016-03-07 06:41:54 --> Router Class Initialized
INFO - 2016-03-07 06:41:54 --> Output Class Initialized
INFO - 2016-03-07 06:41:54 --> Security Class Initialized
DEBUG - 2016-03-07 06:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:41:54 --> Input Class Initialized
INFO - 2016-03-07 06:41:54 --> Language Class Initialized
INFO - 2016-03-07 06:41:54 --> Loader Class Initialized
INFO - 2016-03-07 06:41:54 --> Helper loaded: url_helper
INFO - 2016-03-07 06:41:54 --> Helper loaded: file_helper
INFO - 2016-03-07 06:41:54 --> Helper loaded: date_helper
INFO - 2016-03-07 06:41:54 --> Helper loaded: form_helper
INFO - 2016-03-07 06:41:54 --> Database Driver Class Initialized
INFO - 2016-03-07 06:41:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:41:55 --> Controller Class Initialized
INFO - 2016-03-07 06:41:55 --> Model Class Initialized
INFO - 2016-03-07 06:41:55 --> Model Class Initialized
INFO - 2016-03-07 06:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:41:55 --> Pagination Class Initialized
INFO - 2016-03-07 06:41:55 --> Helper loaded: text_helper
INFO - 2016-03-07 06:41:55 --> Helper loaded: cookie_helper
INFO - 2016-03-07 06:41:55 --> Form Validation Class Initialized
INFO - 2016-03-07 09:41:55 --> Upload Class Initialized
INFO - 2016-03-07 09:41:55 --> Language file loaded: language/english/upload_lang.php
ERROR - 2016-03-07 09:41:55 --> A problem was encountered while attempting to move the uploaded file to the final destination.
INFO - 2016-03-07 09:41:55 --> Final output sent to browser
DEBUG - 2016-03-07 09:41:55 --> Total execution time: 1.2366
INFO - 2016-03-07 06:42:15 --> Config Class Initialized
INFO - 2016-03-07 06:42:15 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:42:15 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:42:15 --> Utf8 Class Initialized
INFO - 2016-03-07 06:42:15 --> URI Class Initialized
INFO - 2016-03-07 06:42:15 --> Router Class Initialized
INFO - 2016-03-07 06:42:15 --> Output Class Initialized
INFO - 2016-03-07 06:42:15 --> Security Class Initialized
DEBUG - 2016-03-07 06:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:42:15 --> Input Class Initialized
INFO - 2016-03-07 06:42:15 --> Language Class Initialized
INFO - 2016-03-07 06:42:15 --> Loader Class Initialized
INFO - 2016-03-07 06:42:15 --> Helper loaded: url_helper
INFO - 2016-03-07 06:42:15 --> Helper loaded: file_helper
INFO - 2016-03-07 06:42:15 --> Helper loaded: date_helper
INFO - 2016-03-07 06:42:15 --> Helper loaded: form_helper
INFO - 2016-03-07 06:42:15 --> Database Driver Class Initialized
INFO - 2016-03-07 06:42:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:42:16 --> Controller Class Initialized
INFO - 2016-03-07 06:42:16 --> Model Class Initialized
INFO - 2016-03-07 06:42:16 --> Model Class Initialized
INFO - 2016-03-07 06:42:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:42:16 --> Pagination Class Initialized
INFO - 2016-03-07 06:42:16 --> Helper loaded: text_helper
INFO - 2016-03-07 06:42:16 --> Helper loaded: cookie_helper
INFO - 2016-03-07 06:42:16 --> Form Validation Class Initialized
INFO - 2016-03-07 09:42:16 --> Upload Class Initialized
INFO - 2016-03-07 09:42:16 --> Image Lib Class Initialized
DEBUG - 2016-03-07 09:42:16 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 09:42:16 --> Final output sent to browser
DEBUG - 2016-03-07 09:42:16 --> Total execution time: 1.2822
INFO - 2016-03-07 06:42:29 --> Config Class Initialized
INFO - 2016-03-07 06:42:29 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:42:29 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:42:29 --> Utf8 Class Initialized
INFO - 2016-03-07 06:42:29 --> URI Class Initialized
INFO - 2016-03-07 06:42:29 --> Router Class Initialized
INFO - 2016-03-07 06:42:29 --> Output Class Initialized
INFO - 2016-03-07 06:42:29 --> Security Class Initialized
DEBUG - 2016-03-07 06:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:42:29 --> Input Class Initialized
INFO - 2016-03-07 06:42:29 --> Language Class Initialized
INFO - 2016-03-07 06:42:29 --> Loader Class Initialized
INFO - 2016-03-07 06:42:29 --> Helper loaded: url_helper
INFO - 2016-03-07 06:42:29 --> Helper loaded: file_helper
INFO - 2016-03-07 06:42:29 --> Helper loaded: date_helper
INFO - 2016-03-07 06:42:29 --> Helper loaded: form_helper
INFO - 2016-03-07 06:42:29 --> Database Driver Class Initialized
INFO - 2016-03-07 06:42:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:42:30 --> Controller Class Initialized
INFO - 2016-03-07 06:42:30 --> Model Class Initialized
INFO - 2016-03-07 06:42:30 --> Model Class Initialized
INFO - 2016-03-07 06:42:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:42:30 --> Pagination Class Initialized
INFO - 2016-03-07 06:42:30 --> Helper loaded: text_helper
INFO - 2016-03-07 06:42:30 --> Helper loaded: cookie_helper
INFO - 2016-03-07 06:42:30 --> Form Validation Class Initialized
INFO - 2016-03-07 09:42:30 --> Upload Class Initialized
INFO - 2016-03-07 09:42:30 --> Image Lib Class Initialized
DEBUG - 2016-03-07 09:42:30 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 09:42:30 --> Final output sent to browser
DEBUG - 2016-03-07 09:42:30 --> Total execution time: 1.1525
INFO - 2016-03-07 06:43:15 --> Config Class Initialized
INFO - 2016-03-07 06:43:15 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:43:15 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:43:15 --> Utf8 Class Initialized
INFO - 2016-03-07 06:43:15 --> URI Class Initialized
INFO - 2016-03-07 06:43:15 --> Router Class Initialized
INFO - 2016-03-07 06:43:15 --> Output Class Initialized
INFO - 2016-03-07 06:43:15 --> Security Class Initialized
DEBUG - 2016-03-07 06:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:43:15 --> Input Class Initialized
INFO - 2016-03-07 06:43:15 --> Language Class Initialized
INFO - 2016-03-07 06:43:15 --> Loader Class Initialized
INFO - 2016-03-07 06:43:15 --> Helper loaded: url_helper
INFO - 2016-03-07 06:43:15 --> Helper loaded: file_helper
INFO - 2016-03-07 06:43:15 --> Helper loaded: date_helper
INFO - 2016-03-07 06:43:15 --> Helper loaded: form_helper
INFO - 2016-03-07 06:43:15 --> Database Driver Class Initialized
INFO - 2016-03-07 06:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:43:16 --> Controller Class Initialized
INFO - 2016-03-07 06:43:16 --> Model Class Initialized
INFO - 2016-03-07 06:43:16 --> Model Class Initialized
INFO - 2016-03-07 06:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:43:16 --> Pagination Class Initialized
INFO - 2016-03-07 06:43:16 --> Helper loaded: text_helper
INFO - 2016-03-07 06:43:16 --> Helper loaded: cookie_helper
INFO - 2016-03-07 06:43:16 --> Form Validation Class Initialized
INFO - 2016-03-07 09:43:16 --> Upload Class Initialized
INFO - 2016-03-07 09:43:16 --> Image Lib Class Initialized
DEBUG - 2016-03-07 09:43:16 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 09:43:16 --> Final output sent to browser
DEBUG - 2016-03-07 09:43:16 --> Total execution time: 1.1907
INFO - 2016-03-07 06:43:45 --> Config Class Initialized
INFO - 2016-03-07 06:43:45 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:43:45 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:43:45 --> Utf8 Class Initialized
INFO - 2016-03-07 06:43:45 --> URI Class Initialized
INFO - 2016-03-07 06:43:45 --> Router Class Initialized
INFO - 2016-03-07 06:43:45 --> Output Class Initialized
INFO - 2016-03-07 06:43:45 --> Security Class Initialized
DEBUG - 2016-03-07 06:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:43:45 --> Input Class Initialized
INFO - 2016-03-07 06:43:45 --> Language Class Initialized
INFO - 2016-03-07 06:43:45 --> Loader Class Initialized
INFO - 2016-03-07 06:43:45 --> Helper loaded: url_helper
INFO - 2016-03-07 06:43:45 --> Helper loaded: file_helper
INFO - 2016-03-07 06:43:45 --> Helper loaded: date_helper
INFO - 2016-03-07 06:43:45 --> Helper loaded: form_helper
INFO - 2016-03-07 06:43:45 --> Database Driver Class Initialized
INFO - 2016-03-07 06:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:43:46 --> Controller Class Initialized
INFO - 2016-03-07 06:43:46 --> Model Class Initialized
INFO - 2016-03-07 06:43:46 --> Model Class Initialized
INFO - 2016-03-07 06:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:43:46 --> Pagination Class Initialized
INFO - 2016-03-07 06:43:46 --> Helper loaded: text_helper
INFO - 2016-03-07 06:43:46 --> Helper loaded: cookie_helper
INFO - 2016-03-07 06:43:46 --> Form Validation Class Initialized
INFO - 2016-03-07 09:43:46 --> Upload Class Initialized
INFO - 2016-03-07 09:43:46 --> Image Lib Class Initialized
DEBUG - 2016-03-07 09:43:46 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 09:43:46 --> Final output sent to browser
DEBUG - 2016-03-07 09:43:46 --> Total execution time: 1.1831
INFO - 2016-03-07 06:44:03 --> Config Class Initialized
INFO - 2016-03-07 06:44:03 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:44:03 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:44:03 --> Utf8 Class Initialized
INFO - 2016-03-07 06:44:03 --> URI Class Initialized
INFO - 2016-03-07 06:44:03 --> Router Class Initialized
INFO - 2016-03-07 06:44:03 --> Output Class Initialized
INFO - 2016-03-07 06:44:03 --> Security Class Initialized
DEBUG - 2016-03-07 06:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:44:03 --> Input Class Initialized
INFO - 2016-03-07 06:44:03 --> Language Class Initialized
INFO - 2016-03-07 06:44:03 --> Loader Class Initialized
INFO - 2016-03-07 06:44:03 --> Helper loaded: url_helper
INFO - 2016-03-07 06:44:03 --> Helper loaded: file_helper
INFO - 2016-03-07 06:44:03 --> Helper loaded: date_helper
INFO - 2016-03-07 06:44:03 --> Helper loaded: form_helper
INFO - 2016-03-07 06:44:03 --> Database Driver Class Initialized
INFO - 2016-03-07 06:44:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:44:04 --> Controller Class Initialized
INFO - 2016-03-07 06:44:04 --> Model Class Initialized
INFO - 2016-03-07 06:44:04 --> Model Class Initialized
INFO - 2016-03-07 06:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:44:04 --> Pagination Class Initialized
INFO - 2016-03-07 06:44:04 --> Helper loaded: text_helper
INFO - 2016-03-07 06:44:04 --> Helper loaded: cookie_helper
INFO - 2016-03-07 06:44:04 --> Form Validation Class Initialized
INFO - 2016-03-07 09:44:04 --> Upload Class Initialized
INFO - 2016-03-07 09:44:04 --> Image Lib Class Initialized
DEBUG - 2016-03-07 09:44:04 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 09:44:04 --> Final output sent to browser
DEBUG - 2016-03-07 09:44:04 --> Total execution time: 1.2084
INFO - 2016-03-07 06:44:11 --> Config Class Initialized
INFO - 2016-03-07 06:44:11 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:44:11 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:44:11 --> Utf8 Class Initialized
INFO - 2016-03-07 06:44:11 --> URI Class Initialized
INFO - 2016-03-07 06:44:11 --> Router Class Initialized
INFO - 2016-03-07 06:44:11 --> Output Class Initialized
INFO - 2016-03-07 06:44:11 --> Security Class Initialized
DEBUG - 2016-03-07 06:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:44:11 --> Input Class Initialized
INFO - 2016-03-07 06:44:11 --> Language Class Initialized
INFO - 2016-03-07 06:44:11 --> Loader Class Initialized
INFO - 2016-03-07 06:44:11 --> Helper loaded: url_helper
INFO - 2016-03-07 06:44:11 --> Helper loaded: file_helper
INFO - 2016-03-07 06:44:11 --> Helper loaded: date_helper
INFO - 2016-03-07 06:44:11 --> Helper loaded: form_helper
INFO - 2016-03-07 06:44:11 --> Database Driver Class Initialized
INFO - 2016-03-07 06:44:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:44:12 --> Controller Class Initialized
INFO - 2016-03-07 06:44:12 --> Model Class Initialized
INFO - 2016-03-07 06:44:12 --> Model Class Initialized
INFO - 2016-03-07 06:44:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:44:12 --> Pagination Class Initialized
INFO - 2016-03-07 06:44:12 --> Helper loaded: text_helper
INFO - 2016-03-07 06:44:13 --> Helper loaded: cookie_helper
ERROR - 2016-03-07 09:44:13 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 181
INFO - 2016-03-07 06:44:13 --> Config Class Initialized
INFO - 2016-03-07 06:44:13 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:44:13 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:44:13 --> Utf8 Class Initialized
INFO - 2016-03-07 06:44:13 --> URI Class Initialized
INFO - 2016-03-07 06:44:13 --> Router Class Initialized
INFO - 2016-03-07 06:44:13 --> Output Class Initialized
INFO - 2016-03-07 06:44:13 --> Security Class Initialized
DEBUG - 2016-03-07 06:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:44:13 --> Input Class Initialized
INFO - 2016-03-07 06:44:13 --> Language Class Initialized
INFO - 2016-03-07 06:44:13 --> Loader Class Initialized
INFO - 2016-03-07 06:44:13 --> Helper loaded: url_helper
INFO - 2016-03-07 06:44:13 --> Helper loaded: file_helper
INFO - 2016-03-07 06:44:13 --> Helper loaded: date_helper
INFO - 2016-03-07 06:44:13 --> Helper loaded: form_helper
INFO - 2016-03-07 06:44:13 --> Database Driver Class Initialized
INFO - 2016-03-07 06:44:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:44:14 --> Controller Class Initialized
INFO - 2016-03-07 06:44:14 --> Model Class Initialized
INFO - 2016-03-07 06:44:14 --> Model Class Initialized
INFO - 2016-03-07 06:44:14 --> Form Validation Class Initialized
INFO - 2016-03-07 06:44:14 --> Helper loaded: text_helper
INFO - 2016-03-07 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-03-07 06:44:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 06:44:14 --> Final output sent to browser
DEBUG - 2016-03-07 06:44:14 --> Total execution time: 1.1449
INFO - 2016-03-07 06:44:36 --> Config Class Initialized
INFO - 2016-03-07 06:44:36 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:44:36 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:44:36 --> Utf8 Class Initialized
INFO - 2016-03-07 06:44:37 --> URI Class Initialized
INFO - 2016-03-07 06:44:37 --> Router Class Initialized
INFO - 2016-03-07 06:44:37 --> Output Class Initialized
INFO - 2016-03-07 06:44:37 --> Security Class Initialized
DEBUG - 2016-03-07 06:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:44:37 --> Input Class Initialized
INFO - 2016-03-07 06:44:37 --> Language Class Initialized
INFO - 2016-03-07 06:44:37 --> Loader Class Initialized
INFO - 2016-03-07 06:44:37 --> Helper loaded: url_helper
INFO - 2016-03-07 06:44:37 --> Helper loaded: file_helper
INFO - 2016-03-07 06:44:37 --> Helper loaded: date_helper
INFO - 2016-03-07 06:44:37 --> Helper loaded: form_helper
INFO - 2016-03-07 06:44:37 --> Database Driver Class Initialized
INFO - 2016-03-07 06:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:44:38 --> Controller Class Initialized
INFO - 2016-03-07 06:44:38 --> Model Class Initialized
INFO - 2016-03-07 06:44:38 --> Model Class Initialized
INFO - 2016-03-07 06:44:38 --> Form Validation Class Initialized
INFO - 2016-03-07 06:44:38 --> Helper loaded: text_helper
INFO - 2016-03-07 06:44:38 --> Final output sent to browser
DEBUG - 2016-03-07 06:44:38 --> Total execution time: 1.0894
INFO - 2016-03-07 06:44:56 --> Config Class Initialized
INFO - 2016-03-07 06:44:56 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:44:56 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:44:56 --> Utf8 Class Initialized
INFO - 2016-03-07 06:44:56 --> URI Class Initialized
INFO - 2016-03-07 06:44:56 --> Router Class Initialized
INFO - 2016-03-07 06:44:56 --> Output Class Initialized
INFO - 2016-03-07 06:44:56 --> Security Class Initialized
DEBUG - 2016-03-07 06:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:44:56 --> Input Class Initialized
INFO - 2016-03-07 06:44:56 --> Language Class Initialized
INFO - 2016-03-07 06:44:56 --> Loader Class Initialized
INFO - 2016-03-07 06:44:56 --> Helper loaded: url_helper
INFO - 2016-03-07 06:44:56 --> Helper loaded: file_helper
INFO - 2016-03-07 06:44:56 --> Helper loaded: date_helper
INFO - 2016-03-07 06:44:56 --> Helper loaded: form_helper
INFO - 2016-03-07 06:44:56 --> Database Driver Class Initialized
INFO - 2016-03-07 06:44:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:44:57 --> Controller Class Initialized
INFO - 2016-03-07 06:44:57 --> Model Class Initialized
INFO - 2016-03-07 06:44:57 --> Model Class Initialized
INFO - 2016-03-07 06:44:57 --> Form Validation Class Initialized
INFO - 2016-03-07 06:44:57 --> Helper loaded: text_helper
INFO - 2016-03-07 06:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 06:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 06:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\signin.php
INFO - 2016-03-07 06:44:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 06:44:57 --> Final output sent to browser
DEBUG - 2016-03-07 06:44:57 --> Total execution time: 1.1137
INFO - 2016-03-07 06:45:00 --> Config Class Initialized
INFO - 2016-03-07 06:45:00 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:45:00 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:45:00 --> Utf8 Class Initialized
INFO - 2016-03-07 06:45:00 --> URI Class Initialized
DEBUG - 2016-03-07 06:45:00 --> No URI present. Default controller set.
INFO - 2016-03-07 06:45:00 --> Router Class Initialized
INFO - 2016-03-07 06:45:00 --> Output Class Initialized
INFO - 2016-03-07 06:45:00 --> Security Class Initialized
DEBUG - 2016-03-07 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:45:00 --> Input Class Initialized
INFO - 2016-03-07 06:45:00 --> Language Class Initialized
INFO - 2016-03-07 06:45:00 --> Loader Class Initialized
INFO - 2016-03-07 06:45:00 --> Helper loaded: url_helper
INFO - 2016-03-07 06:45:00 --> Helper loaded: file_helper
INFO - 2016-03-07 06:45:00 --> Helper loaded: date_helper
INFO - 2016-03-07 06:45:00 --> Helper loaded: form_helper
INFO - 2016-03-07 06:45:00 --> Database Driver Class Initialized
INFO - 2016-03-07 06:45:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:45:01 --> Controller Class Initialized
INFO - 2016-03-07 06:45:01 --> Model Class Initialized
INFO - 2016-03-07 06:45:01 --> Model Class Initialized
INFO - 2016-03-07 06:45:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:45:01 --> Pagination Class Initialized
INFO - 2016-03-07 06:45:01 --> Helper loaded: text_helper
INFO - 2016-03-07 06:45:01 --> Helper loaded: cookie_helper
INFO - 2016-03-07 09:45:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 09:45:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 09:45:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 09:45:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 09:45:01 --> Final output sent to browser
DEBUG - 2016-03-07 09:45:01 --> Total execution time: 1.1216
INFO - 2016-03-07 06:45:06 --> Config Class Initialized
INFO - 2016-03-07 06:45:06 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:45:06 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:45:06 --> Utf8 Class Initialized
INFO - 2016-03-07 06:45:06 --> URI Class Initialized
INFO - 2016-03-07 06:45:06 --> Router Class Initialized
INFO - 2016-03-07 06:45:06 --> Output Class Initialized
INFO - 2016-03-07 06:45:06 --> Security Class Initialized
DEBUG - 2016-03-07 06:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:45:06 --> Input Class Initialized
INFO - 2016-03-07 06:45:06 --> Language Class Initialized
INFO - 2016-03-07 06:45:06 --> Loader Class Initialized
INFO - 2016-03-07 06:45:06 --> Helper loaded: url_helper
INFO - 2016-03-07 06:45:06 --> Helper loaded: file_helper
INFO - 2016-03-07 06:45:06 --> Helper loaded: date_helper
INFO - 2016-03-07 06:45:06 --> Helper loaded: form_helper
INFO - 2016-03-07 06:45:06 --> Database Driver Class Initialized
INFO - 2016-03-07 06:45:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:45:07 --> Controller Class Initialized
INFO - 2016-03-07 06:45:07 --> Model Class Initialized
INFO - 2016-03-07 06:45:07 --> Model Class Initialized
INFO - 2016-03-07 06:45:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:45:07 --> Pagination Class Initialized
INFO - 2016-03-07 06:45:07 --> Helper loaded: text_helper
INFO - 2016-03-07 06:45:07 --> Helper loaded: cookie_helper
INFO - 2016-03-07 09:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 09:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 09:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 09:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 09:45:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 09:45:07 --> Final output sent to browser
DEBUG - 2016-03-07 09:45:07 --> Total execution time: 1.1450
INFO - 2016-03-07 06:45:11 --> Config Class Initialized
INFO - 2016-03-07 06:45:11 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:45:11 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:45:11 --> Utf8 Class Initialized
INFO - 2016-03-07 06:45:11 --> URI Class Initialized
INFO - 2016-03-07 06:45:11 --> Router Class Initialized
INFO - 2016-03-07 06:45:11 --> Output Class Initialized
INFO - 2016-03-07 06:45:11 --> Security Class Initialized
DEBUG - 2016-03-07 06:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:45:11 --> Input Class Initialized
INFO - 2016-03-07 06:45:11 --> Language Class Initialized
INFO - 2016-03-07 06:45:11 --> Loader Class Initialized
INFO - 2016-03-07 06:45:11 --> Helper loaded: url_helper
INFO - 2016-03-07 06:45:11 --> Helper loaded: file_helper
INFO - 2016-03-07 06:45:11 --> Helper loaded: date_helper
INFO - 2016-03-07 06:45:11 --> Helper loaded: form_helper
INFO - 2016-03-07 06:45:11 --> Database Driver Class Initialized
INFO - 2016-03-07 06:45:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:45:12 --> Controller Class Initialized
INFO - 2016-03-07 06:45:12 --> Model Class Initialized
INFO - 2016-03-07 06:45:12 --> Model Class Initialized
INFO - 2016-03-07 06:45:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:45:12 --> Pagination Class Initialized
INFO - 2016-03-07 06:45:12 --> Helper loaded: text_helper
INFO - 2016-03-07 06:45:12 --> Helper loaded: cookie_helper
INFO - 2016-03-07 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 09:45:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 09:45:12 --> Final output sent to browser
DEBUG - 2016-03-07 09:45:12 --> Total execution time: 1.1340
INFO - 2016-03-07 06:45:36 --> Config Class Initialized
INFO - 2016-03-07 06:45:36 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:45:36 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:45:36 --> Utf8 Class Initialized
INFO - 2016-03-07 06:45:36 --> URI Class Initialized
INFO - 2016-03-07 06:45:36 --> Router Class Initialized
INFO - 2016-03-07 06:45:36 --> Output Class Initialized
INFO - 2016-03-07 06:45:36 --> Security Class Initialized
DEBUG - 2016-03-07 06:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:45:36 --> Input Class Initialized
INFO - 2016-03-07 06:45:36 --> Language Class Initialized
INFO - 2016-03-07 06:45:36 --> Loader Class Initialized
INFO - 2016-03-07 06:45:36 --> Helper loaded: url_helper
INFO - 2016-03-07 06:45:36 --> Helper loaded: file_helper
INFO - 2016-03-07 06:45:36 --> Helper loaded: date_helper
INFO - 2016-03-07 06:45:36 --> Helper loaded: form_helper
INFO - 2016-03-07 06:45:36 --> Database Driver Class Initialized
INFO - 2016-03-07 06:45:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:45:37 --> Controller Class Initialized
INFO - 2016-03-07 06:45:37 --> Model Class Initialized
INFO - 2016-03-07 06:45:37 --> Model Class Initialized
INFO - 2016-03-07 06:45:37 --> Form Validation Class Initialized
INFO - 2016-03-07 06:45:37 --> Helper loaded: text_helper
INFO - 2016-03-07 06:45:37 --> Final output sent to browser
DEBUG - 2016-03-07 06:45:37 --> Total execution time: 1.1198
INFO - 2016-03-07 06:45:46 --> Config Class Initialized
INFO - 2016-03-07 06:45:46 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:45:46 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:45:46 --> Utf8 Class Initialized
INFO - 2016-03-07 06:45:46 --> URI Class Initialized
INFO - 2016-03-07 06:45:46 --> Router Class Initialized
INFO - 2016-03-07 06:45:46 --> Output Class Initialized
INFO - 2016-03-07 06:45:46 --> Security Class Initialized
DEBUG - 2016-03-07 06:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:45:46 --> Input Class Initialized
INFO - 2016-03-07 06:45:46 --> Language Class Initialized
INFO - 2016-03-07 06:45:46 --> Loader Class Initialized
INFO - 2016-03-07 06:45:46 --> Helper loaded: url_helper
INFO - 2016-03-07 06:45:47 --> Helper loaded: file_helper
INFO - 2016-03-07 06:45:47 --> Helper loaded: date_helper
INFO - 2016-03-07 06:45:47 --> Helper loaded: form_helper
INFO - 2016-03-07 06:45:47 --> Database Driver Class Initialized
INFO - 2016-03-07 06:45:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:45:48 --> Controller Class Initialized
INFO - 2016-03-07 06:45:48 --> Model Class Initialized
INFO - 2016-03-07 06:45:48 --> Model Class Initialized
INFO - 2016-03-07 06:45:48 --> Form Validation Class Initialized
INFO - 2016-03-07 06:45:48 --> Helper loaded: text_helper
INFO - 2016-03-07 06:45:48 --> Final output sent to browser
DEBUG - 2016-03-07 06:45:48 --> Total execution time: 1.0984
INFO - 2016-03-07 06:45:56 --> Config Class Initialized
INFO - 2016-03-07 06:45:56 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:45:56 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:45:56 --> Utf8 Class Initialized
INFO - 2016-03-07 06:45:56 --> URI Class Initialized
INFO - 2016-03-07 06:45:56 --> Router Class Initialized
INFO - 2016-03-07 06:45:56 --> Output Class Initialized
INFO - 2016-03-07 06:45:56 --> Security Class Initialized
DEBUG - 2016-03-07 06:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:45:56 --> Input Class Initialized
INFO - 2016-03-07 06:45:56 --> Language Class Initialized
INFO - 2016-03-07 06:45:56 --> Loader Class Initialized
INFO - 2016-03-07 06:45:56 --> Helper loaded: url_helper
INFO - 2016-03-07 06:45:56 --> Helper loaded: file_helper
INFO - 2016-03-07 06:45:56 --> Helper loaded: date_helper
INFO - 2016-03-07 06:45:56 --> Helper loaded: form_helper
INFO - 2016-03-07 06:45:56 --> Database Driver Class Initialized
INFO - 2016-03-07 06:45:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:45:57 --> Controller Class Initialized
INFO - 2016-03-07 06:45:57 --> Model Class Initialized
INFO - 2016-03-07 06:45:57 --> Model Class Initialized
INFO - 2016-03-07 06:45:57 --> Form Validation Class Initialized
INFO - 2016-03-07 06:45:57 --> Helper loaded: text_helper
INFO - 2016-03-07 06:45:57 --> Final output sent to browser
DEBUG - 2016-03-07 06:45:57 --> Total execution time: 1.0961
INFO - 2016-03-07 06:46:02 --> Config Class Initialized
INFO - 2016-03-07 06:46:02 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:46:02 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:46:02 --> Utf8 Class Initialized
INFO - 2016-03-07 06:46:02 --> URI Class Initialized
INFO - 2016-03-07 06:46:02 --> Router Class Initialized
INFO - 2016-03-07 06:46:02 --> Output Class Initialized
INFO - 2016-03-07 06:46:02 --> Security Class Initialized
DEBUG - 2016-03-07 06:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:46:02 --> Input Class Initialized
INFO - 2016-03-07 06:46:02 --> Language Class Initialized
INFO - 2016-03-07 06:46:02 --> Loader Class Initialized
INFO - 2016-03-07 06:46:02 --> Helper loaded: url_helper
INFO - 2016-03-07 06:46:02 --> Helper loaded: file_helper
INFO - 2016-03-07 06:46:02 --> Helper loaded: date_helper
INFO - 2016-03-07 06:46:02 --> Helper loaded: form_helper
INFO - 2016-03-07 06:46:02 --> Database Driver Class Initialized
INFO - 2016-03-07 06:46:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:46:03 --> Controller Class Initialized
INFO - 2016-03-07 06:46:03 --> Model Class Initialized
INFO - 2016-03-07 06:46:03 --> Model Class Initialized
INFO - 2016-03-07 06:46:03 --> Form Validation Class Initialized
INFO - 2016-03-07 06:46:03 --> Helper loaded: text_helper
INFO - 2016-03-07 06:46:04 --> Final output sent to browser
DEBUG - 2016-03-07 06:46:04 --> Total execution time: 1.1551
INFO - 2016-03-07 06:46:04 --> Config Class Initialized
INFO - 2016-03-07 06:46:04 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:46:04 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:46:04 --> Utf8 Class Initialized
INFO - 2016-03-07 06:46:04 --> URI Class Initialized
INFO - 2016-03-07 06:46:04 --> Router Class Initialized
INFO - 2016-03-07 06:46:04 --> Output Class Initialized
INFO - 2016-03-07 06:46:04 --> Security Class Initialized
DEBUG - 2016-03-07 06:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:46:04 --> Input Class Initialized
INFO - 2016-03-07 06:46:04 --> Language Class Initialized
INFO - 2016-03-07 06:46:04 --> Loader Class Initialized
INFO - 2016-03-07 06:46:04 --> Helper loaded: url_helper
INFO - 2016-03-07 06:46:04 --> Helper loaded: file_helper
INFO - 2016-03-07 06:46:04 --> Helper loaded: date_helper
INFO - 2016-03-07 06:46:04 --> Helper loaded: form_helper
INFO - 2016-03-07 06:46:04 --> Database Driver Class Initialized
INFO - 2016-03-07 06:46:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:46:05 --> Controller Class Initialized
INFO - 2016-03-07 06:46:05 --> Model Class Initialized
INFO - 2016-03-07 06:46:05 --> Model Class Initialized
INFO - 2016-03-07 06:46:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:46:05 --> Pagination Class Initialized
INFO - 2016-03-07 06:46:05 --> Helper loaded: text_helper
INFO - 2016-03-07 06:46:05 --> Helper loaded: cookie_helper
INFO - 2016-03-07 09:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 09:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 09:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 09:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 09:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 09:46:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 09:46:05 --> Final output sent to browser
DEBUG - 2016-03-07 09:46:05 --> Total execution time: 1.1145
INFO - 2016-03-07 06:46:08 --> Config Class Initialized
INFO - 2016-03-07 06:46:08 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:46:08 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:46:08 --> Utf8 Class Initialized
INFO - 2016-03-07 06:46:08 --> URI Class Initialized
INFO - 2016-03-07 06:46:08 --> Router Class Initialized
INFO - 2016-03-07 06:46:08 --> Output Class Initialized
INFO - 2016-03-07 06:46:08 --> Security Class Initialized
DEBUG - 2016-03-07 06:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:46:08 --> Input Class Initialized
INFO - 2016-03-07 06:46:08 --> Language Class Initialized
INFO - 2016-03-07 06:46:08 --> Loader Class Initialized
INFO - 2016-03-07 06:46:08 --> Helper loaded: url_helper
INFO - 2016-03-07 06:46:08 --> Helper loaded: file_helper
INFO - 2016-03-07 06:46:08 --> Helper loaded: date_helper
INFO - 2016-03-07 06:46:08 --> Helper loaded: form_helper
INFO - 2016-03-07 06:46:08 --> Database Driver Class Initialized
INFO - 2016-03-07 06:46:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:46:09 --> Controller Class Initialized
INFO - 2016-03-07 06:46:09 --> Model Class Initialized
INFO - 2016-03-07 06:46:09 --> Model Class Initialized
INFO - 2016-03-07 06:46:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:46:09 --> Pagination Class Initialized
INFO - 2016-03-07 06:46:09 --> Helper loaded: text_helper
INFO - 2016-03-07 06:46:09 --> Helper loaded: cookie_helper
INFO - 2016-03-07 09:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 09:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 09:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-07 09:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 09:46:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 09:46:09 --> Final output sent to browser
DEBUG - 2016-03-07 09:46:09 --> Total execution time: 1.1240
INFO - 2016-03-07 06:46:33 --> Config Class Initialized
INFO - 2016-03-07 06:46:33 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:46:33 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:46:33 --> Utf8 Class Initialized
INFO - 2016-03-07 06:46:33 --> URI Class Initialized
INFO - 2016-03-07 06:46:33 --> Router Class Initialized
INFO - 2016-03-07 06:46:33 --> Output Class Initialized
INFO - 2016-03-07 06:46:33 --> Security Class Initialized
DEBUG - 2016-03-07 06:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:46:33 --> Input Class Initialized
INFO - 2016-03-07 06:46:33 --> Language Class Initialized
INFO - 2016-03-07 06:46:33 --> Loader Class Initialized
INFO - 2016-03-07 06:46:33 --> Helper loaded: url_helper
INFO - 2016-03-07 06:46:33 --> Helper loaded: file_helper
INFO - 2016-03-07 06:46:33 --> Helper loaded: date_helper
INFO - 2016-03-07 06:46:33 --> Helper loaded: form_helper
INFO - 2016-03-07 06:46:33 --> Database Driver Class Initialized
INFO - 2016-03-07 06:46:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:46:34 --> Controller Class Initialized
INFO - 2016-03-07 06:46:34 --> Model Class Initialized
INFO - 2016-03-07 06:46:34 --> Model Class Initialized
INFO - 2016-03-07 06:46:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:46:34 --> Pagination Class Initialized
INFO - 2016-03-07 06:46:34 --> Helper loaded: text_helper
INFO - 2016-03-07 06:46:34 --> Helper loaded: cookie_helper
INFO - 2016-03-07 06:46:34 --> Form Validation Class Initialized
INFO - 2016-03-07 09:46:34 --> Upload Class Initialized
INFO - 2016-03-07 09:46:34 --> Image Lib Class Initialized
DEBUG - 2016-03-07 09:46:34 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 09:46:34 --> Final output sent to browser
DEBUG - 2016-03-07 09:46:34 --> Total execution time: 1.3559
INFO - 2016-03-07 06:47:15 --> Config Class Initialized
INFO - 2016-03-07 06:47:15 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:47:15 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:47:15 --> Utf8 Class Initialized
INFO - 2016-03-07 06:47:15 --> URI Class Initialized
INFO - 2016-03-07 06:47:15 --> Router Class Initialized
INFO - 2016-03-07 06:47:15 --> Output Class Initialized
INFO - 2016-03-07 06:47:15 --> Security Class Initialized
DEBUG - 2016-03-07 06:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:47:15 --> Input Class Initialized
INFO - 2016-03-07 06:47:15 --> Language Class Initialized
INFO - 2016-03-07 06:47:15 --> Loader Class Initialized
INFO - 2016-03-07 06:47:15 --> Helper loaded: url_helper
INFO - 2016-03-07 06:47:15 --> Helper loaded: file_helper
INFO - 2016-03-07 06:47:15 --> Helper loaded: date_helper
INFO - 2016-03-07 06:47:15 --> Helper loaded: form_helper
INFO - 2016-03-07 06:47:15 --> Database Driver Class Initialized
INFO - 2016-03-07 06:47:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:47:16 --> Controller Class Initialized
INFO - 2016-03-07 06:47:16 --> Model Class Initialized
INFO - 2016-03-07 06:47:16 --> Model Class Initialized
INFO - 2016-03-07 06:47:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:47:16 --> Pagination Class Initialized
INFO - 2016-03-07 06:47:16 --> Helper loaded: text_helper
INFO - 2016-03-07 06:47:16 --> Helper loaded: cookie_helper
ERROR - 2016-03-07 09:47:16 --> Severity: Warning --> Missing argument 1 for Picture::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\picture.php 181
INFO - 2016-03-07 09:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 09:47:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 09:47:16 --> Form Validation Class Initialized
INFO - 2016-03-07 09:47:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-07 06:47:16 --> Config Class Initialized
INFO - 2016-03-07 06:47:16 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:47:16 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:47:16 --> Utf8 Class Initialized
INFO - 2016-03-07 06:47:16 --> URI Class Initialized
INFO - 2016-03-07 06:47:16 --> Router Class Initialized
INFO - 2016-03-07 06:47:16 --> Output Class Initialized
INFO - 2016-03-07 06:47:16 --> Security Class Initialized
DEBUG - 2016-03-07 06:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:47:16 --> Input Class Initialized
INFO - 2016-03-07 06:47:16 --> Language Class Initialized
INFO - 2016-03-07 06:47:16 --> Loader Class Initialized
INFO - 2016-03-07 06:47:16 --> Helper loaded: url_helper
INFO - 2016-03-07 06:47:16 --> Helper loaded: file_helper
INFO - 2016-03-07 06:47:16 --> Helper loaded: date_helper
INFO - 2016-03-07 06:47:16 --> Helper loaded: form_helper
INFO - 2016-03-07 06:47:16 --> Database Driver Class Initialized
INFO - 2016-03-07 06:47:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:47:17 --> Controller Class Initialized
INFO - 2016-03-07 06:47:17 --> Model Class Initialized
INFO - 2016-03-07 06:47:17 --> Model Class Initialized
INFO - 2016-03-07 06:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:47:17 --> Pagination Class Initialized
INFO - 2016-03-07 06:47:17 --> Helper loaded: text_helper
INFO - 2016-03-07 06:47:17 --> Helper loaded: cookie_helper
INFO - 2016-03-07 09:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 09:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 09:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 09:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 09:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 09:47:17 --> Final output sent to browser
DEBUG - 2016-03-07 09:47:17 --> Total execution time: 1.1590
INFO - 2016-03-07 06:49:07 --> Config Class Initialized
INFO - 2016-03-07 06:49:07 --> Hooks Class Initialized
DEBUG - 2016-03-07 06:49:07 --> UTF-8 Support Enabled
INFO - 2016-03-07 06:49:07 --> Utf8 Class Initialized
INFO - 2016-03-07 06:49:07 --> URI Class Initialized
INFO - 2016-03-07 06:49:07 --> Router Class Initialized
INFO - 2016-03-07 06:49:07 --> Output Class Initialized
INFO - 2016-03-07 06:49:07 --> Security Class Initialized
DEBUG - 2016-03-07 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 06:49:07 --> Input Class Initialized
INFO - 2016-03-07 06:49:07 --> Language Class Initialized
INFO - 2016-03-07 06:49:07 --> Loader Class Initialized
INFO - 2016-03-07 06:49:07 --> Helper loaded: url_helper
INFO - 2016-03-07 06:49:07 --> Helper loaded: file_helper
INFO - 2016-03-07 06:49:07 --> Helper loaded: date_helper
INFO - 2016-03-07 06:49:07 --> Helper loaded: form_helper
INFO - 2016-03-07 06:49:07 --> Database Driver Class Initialized
INFO - 2016-03-07 06:49:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 06:49:08 --> Controller Class Initialized
INFO - 2016-03-07 06:49:08 --> Model Class Initialized
INFO - 2016-03-07 06:49:08 --> Model Class Initialized
INFO - 2016-03-07 06:49:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 06:49:08 --> Pagination Class Initialized
INFO - 2016-03-07 06:49:08 --> Helper loaded: text_helper
INFO - 2016-03-07 06:49:08 --> Helper loaded: cookie_helper
INFO - 2016-03-07 09:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 09:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 09:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 09:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 09:49:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 09:49:08 --> Final output sent to browser
DEBUG - 2016-03-07 09:49:08 --> Total execution time: 1.1526
INFO - 2016-03-07 07:01:27 --> Config Class Initialized
INFO - 2016-03-07 07:01:27 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:01:27 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:01:27 --> Utf8 Class Initialized
INFO - 2016-03-07 07:01:27 --> URI Class Initialized
DEBUG - 2016-03-07 07:01:27 --> No URI present. Default controller set.
INFO - 2016-03-07 07:01:27 --> Router Class Initialized
INFO - 2016-03-07 07:01:27 --> Output Class Initialized
INFO - 2016-03-07 07:01:27 --> Security Class Initialized
DEBUG - 2016-03-07 07:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:01:27 --> Input Class Initialized
INFO - 2016-03-07 07:01:27 --> Language Class Initialized
INFO - 2016-03-07 07:01:27 --> Loader Class Initialized
INFO - 2016-03-07 07:01:27 --> Helper loaded: url_helper
INFO - 2016-03-07 07:01:27 --> Helper loaded: file_helper
INFO - 2016-03-07 07:01:27 --> Helper loaded: date_helper
INFO - 2016-03-07 07:01:27 --> Helper loaded: form_helper
INFO - 2016-03-07 07:01:27 --> Database Driver Class Initialized
INFO - 2016-03-07 07:01:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:01:28 --> Controller Class Initialized
INFO - 2016-03-07 07:01:28 --> Model Class Initialized
INFO - 2016-03-07 07:01:28 --> Model Class Initialized
INFO - 2016-03-07 07:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:01:28 --> Pagination Class Initialized
INFO - 2016-03-07 07:01:28 --> Helper loaded: text_helper
INFO - 2016-03-07 07:01:28 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 10:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:01:28 --> Final output sent to browser
DEBUG - 2016-03-07 10:01:28 --> Total execution time: 1.1398
INFO - 2016-03-07 07:01:30 --> Config Class Initialized
INFO - 2016-03-07 07:01:30 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:01:30 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:01:30 --> Utf8 Class Initialized
INFO - 2016-03-07 07:01:30 --> URI Class Initialized
INFO - 2016-03-07 07:01:30 --> Router Class Initialized
INFO - 2016-03-07 07:01:30 --> Output Class Initialized
INFO - 2016-03-07 07:01:30 --> Security Class Initialized
DEBUG - 2016-03-07 07:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:01:30 --> Input Class Initialized
INFO - 2016-03-07 07:01:30 --> Language Class Initialized
INFO - 2016-03-07 07:01:30 --> Loader Class Initialized
INFO - 2016-03-07 07:01:30 --> Helper loaded: url_helper
INFO - 2016-03-07 07:01:30 --> Helper loaded: file_helper
INFO - 2016-03-07 07:01:30 --> Helper loaded: date_helper
INFO - 2016-03-07 07:01:30 --> Helper loaded: form_helper
INFO - 2016-03-07 07:01:30 --> Database Driver Class Initialized
INFO - 2016-03-07 07:01:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:01:31 --> Controller Class Initialized
INFO - 2016-03-07 07:01:31 --> Model Class Initialized
INFO - 2016-03-07 07:01:31 --> Model Class Initialized
INFO - 2016-03-07 07:01:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:01:31 --> Pagination Class Initialized
INFO - 2016-03-07 07:01:31 --> Helper loaded: text_helper
INFO - 2016-03-07 07:01:31 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-07 10:01:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php 16
INFO - 2016-03-07 10:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 10:01:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:01:31 --> Final output sent to browser
DEBUG - 2016-03-07 10:01:31 --> Total execution time: 1.1183
INFO - 2016-03-07 07:08:04 --> Config Class Initialized
INFO - 2016-03-07 07:08:04 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:08:04 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:08:04 --> Utf8 Class Initialized
INFO - 2016-03-07 07:08:04 --> URI Class Initialized
INFO - 2016-03-07 07:08:04 --> Router Class Initialized
INFO - 2016-03-07 07:08:04 --> Output Class Initialized
INFO - 2016-03-07 07:08:04 --> Security Class Initialized
DEBUG - 2016-03-07 07:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:08:04 --> Input Class Initialized
INFO - 2016-03-07 07:08:04 --> Language Class Initialized
INFO - 2016-03-07 07:08:04 --> Loader Class Initialized
INFO - 2016-03-07 07:08:04 --> Helper loaded: url_helper
INFO - 2016-03-07 07:08:04 --> Helper loaded: file_helper
INFO - 2016-03-07 07:08:04 --> Helper loaded: date_helper
INFO - 2016-03-07 07:08:04 --> Helper loaded: form_helper
INFO - 2016-03-07 07:08:04 --> Database Driver Class Initialized
INFO - 2016-03-07 07:08:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:08:05 --> Controller Class Initialized
INFO - 2016-03-07 07:08:05 --> Model Class Initialized
INFO - 2016-03-07 07:08:05 --> Model Class Initialized
INFO - 2016-03-07 07:08:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:08:05 --> Pagination Class Initialized
INFO - 2016-03-07 07:08:05 --> Helper loaded: text_helper
INFO - 2016-03-07 07:08:05 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:08:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:08:05 --> Final output sent to browser
DEBUG - 2016-03-07 10:08:05 --> Total execution time: 1.1272
INFO - 2016-03-07 07:08:39 --> Config Class Initialized
INFO - 2016-03-07 07:08:39 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:08:39 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:08:39 --> Utf8 Class Initialized
INFO - 2016-03-07 07:08:39 --> URI Class Initialized
INFO - 2016-03-07 07:08:39 --> Router Class Initialized
INFO - 2016-03-07 07:08:39 --> Output Class Initialized
INFO - 2016-03-07 07:08:39 --> Security Class Initialized
DEBUG - 2016-03-07 07:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:08:39 --> Input Class Initialized
INFO - 2016-03-07 07:08:39 --> Language Class Initialized
INFO - 2016-03-07 07:08:39 --> Loader Class Initialized
INFO - 2016-03-07 07:08:39 --> Helper loaded: url_helper
INFO - 2016-03-07 07:08:39 --> Helper loaded: file_helper
INFO - 2016-03-07 07:08:39 --> Helper loaded: date_helper
INFO - 2016-03-07 07:08:39 --> Helper loaded: form_helper
INFO - 2016-03-07 07:08:39 --> Database Driver Class Initialized
INFO - 2016-03-07 07:08:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:08:40 --> Controller Class Initialized
INFO - 2016-03-07 07:08:40 --> Model Class Initialized
INFO - 2016-03-07 07:08:40 --> Model Class Initialized
INFO - 2016-03-07 07:08:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:08:40 --> Pagination Class Initialized
INFO - 2016-03-07 07:08:40 --> Helper loaded: text_helper
INFO - 2016-03-07 07:08:40 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:08:40 --> Form Validation Class Initialized
INFO - 2016-03-07 10:08:40 --> Upload Class Initialized
INFO - 2016-03-07 10:08:40 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:08:40 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:08:40 --> Final output sent to browser
DEBUG - 2016-03-07 10:08:40 --> Total execution time: 1.1852
INFO - 2016-03-07 07:08:56 --> Config Class Initialized
INFO - 2016-03-07 07:08:56 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:08:56 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:08:56 --> Utf8 Class Initialized
INFO - 2016-03-07 07:08:56 --> URI Class Initialized
INFO - 2016-03-07 07:08:56 --> Router Class Initialized
INFO - 2016-03-07 07:08:56 --> Output Class Initialized
INFO - 2016-03-07 07:08:56 --> Security Class Initialized
DEBUG - 2016-03-07 07:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:08:56 --> Input Class Initialized
INFO - 2016-03-07 07:08:56 --> Language Class Initialized
INFO - 2016-03-07 07:08:56 --> Loader Class Initialized
INFO - 2016-03-07 07:08:56 --> Helper loaded: url_helper
INFO - 2016-03-07 07:08:56 --> Helper loaded: file_helper
INFO - 2016-03-07 07:08:56 --> Helper loaded: date_helper
INFO - 2016-03-07 07:08:56 --> Helper loaded: form_helper
INFO - 2016-03-07 07:08:56 --> Database Driver Class Initialized
INFO - 2016-03-07 07:08:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:08:57 --> Controller Class Initialized
INFO - 2016-03-07 07:08:57 --> Model Class Initialized
INFO - 2016-03-07 07:08:57 --> Model Class Initialized
INFO - 2016-03-07 07:08:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:08:57 --> Pagination Class Initialized
INFO - 2016-03-07 07:08:57 --> Helper loaded: text_helper
INFO - 2016-03-07 07:08:57 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:08:57 --> Form Validation Class Initialized
INFO - 2016-03-07 10:08:57 --> Upload Class Initialized
INFO - 2016-03-07 10:08:57 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:08:57 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:08:57 --> Final output sent to browser
DEBUG - 2016-03-07 10:08:57 --> Total execution time: 1.2366
INFO - 2016-03-07 07:09:09 --> Config Class Initialized
INFO - 2016-03-07 07:09:09 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:09:09 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:09:09 --> Utf8 Class Initialized
INFO - 2016-03-07 07:09:09 --> URI Class Initialized
INFO - 2016-03-07 07:09:09 --> Router Class Initialized
INFO - 2016-03-07 07:09:09 --> Output Class Initialized
INFO - 2016-03-07 07:09:09 --> Security Class Initialized
DEBUG - 2016-03-07 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:09:09 --> Input Class Initialized
INFO - 2016-03-07 07:09:09 --> Language Class Initialized
INFO - 2016-03-07 07:09:09 --> Loader Class Initialized
INFO - 2016-03-07 07:09:09 --> Helper loaded: url_helper
INFO - 2016-03-07 07:09:09 --> Helper loaded: file_helper
INFO - 2016-03-07 07:09:09 --> Helper loaded: date_helper
INFO - 2016-03-07 07:09:10 --> Helper loaded: form_helper
INFO - 2016-03-07 07:09:10 --> Database Driver Class Initialized
INFO - 2016-03-07 07:09:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:09:11 --> Controller Class Initialized
INFO - 2016-03-07 07:09:11 --> Model Class Initialized
INFO - 2016-03-07 07:09:11 --> Model Class Initialized
INFO - 2016-03-07 07:09:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:09:11 --> Pagination Class Initialized
INFO - 2016-03-07 07:09:11 --> Helper loaded: text_helper
INFO - 2016-03-07 07:09:11 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:09:11 --> Form Validation Class Initialized
INFO - 2016-03-07 10:09:11 --> Upload Class Initialized
INFO - 2016-03-07 10:09:11 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:09:11 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:09:11 --> Final output sent to browser
DEBUG - 2016-03-07 10:09:11 --> Total execution time: 1.1944
INFO - 2016-03-07 07:09:28 --> Config Class Initialized
INFO - 2016-03-07 07:09:28 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:09:28 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:09:28 --> Utf8 Class Initialized
INFO - 2016-03-07 07:09:28 --> URI Class Initialized
INFO - 2016-03-07 07:09:28 --> Router Class Initialized
INFO - 2016-03-07 07:09:28 --> Output Class Initialized
INFO - 2016-03-07 07:09:28 --> Security Class Initialized
DEBUG - 2016-03-07 07:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:09:28 --> Input Class Initialized
INFO - 2016-03-07 07:09:28 --> Language Class Initialized
INFO - 2016-03-07 07:09:28 --> Loader Class Initialized
INFO - 2016-03-07 07:09:28 --> Helper loaded: url_helper
INFO - 2016-03-07 07:09:28 --> Helper loaded: file_helper
INFO - 2016-03-07 07:09:28 --> Helper loaded: date_helper
INFO - 2016-03-07 07:09:28 --> Helper loaded: form_helper
INFO - 2016-03-07 07:09:28 --> Database Driver Class Initialized
INFO - 2016-03-07 07:09:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:09:29 --> Controller Class Initialized
INFO - 2016-03-07 07:09:29 --> Model Class Initialized
INFO - 2016-03-07 07:09:29 --> Model Class Initialized
INFO - 2016-03-07 07:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:09:29 --> Pagination Class Initialized
INFO - 2016-03-07 07:09:29 --> Helper loaded: text_helper
INFO - 2016-03-07 07:09:29 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:09:29 --> Form Validation Class Initialized
INFO - 2016-03-07 10:09:29 --> Upload Class Initialized
INFO - 2016-03-07 10:09:29 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:09:29 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:09:29 --> Final output sent to browser
DEBUG - 2016-03-07 10:09:29 --> Total execution time: 1.2635
INFO - 2016-03-07 07:10:00 --> Config Class Initialized
INFO - 2016-03-07 07:10:00 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:10:00 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:10:00 --> Utf8 Class Initialized
INFO - 2016-03-07 07:10:00 --> URI Class Initialized
INFO - 2016-03-07 07:10:00 --> Router Class Initialized
INFO - 2016-03-07 07:10:00 --> Output Class Initialized
INFO - 2016-03-07 07:10:00 --> Security Class Initialized
DEBUG - 2016-03-07 07:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:10:00 --> Input Class Initialized
INFO - 2016-03-07 07:10:00 --> Language Class Initialized
INFO - 2016-03-07 07:10:00 --> Loader Class Initialized
INFO - 2016-03-07 07:10:00 --> Helper loaded: url_helper
INFO - 2016-03-07 07:10:00 --> Helper loaded: file_helper
INFO - 2016-03-07 07:10:00 --> Helper loaded: date_helper
INFO - 2016-03-07 07:10:00 --> Helper loaded: form_helper
INFO - 2016-03-07 07:10:00 --> Database Driver Class Initialized
INFO - 2016-03-07 07:10:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:10:01 --> Controller Class Initialized
INFO - 2016-03-07 07:10:01 --> Model Class Initialized
INFO - 2016-03-07 07:10:01 --> Model Class Initialized
INFO - 2016-03-07 07:10:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:10:01 --> Pagination Class Initialized
INFO - 2016-03-07 07:10:01 --> Helper loaded: text_helper
INFO - 2016-03-07 07:10:01 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:10:01 --> Form Validation Class Initialized
INFO - 2016-03-07 10:10:01 --> Upload Class Initialized
INFO - 2016-03-07 10:10:01 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:10:01 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:10:01 --> Final output sent to browser
DEBUG - 2016-03-07 10:10:01 --> Total execution time: 1.1748
INFO - 2016-03-07 07:11:40 --> Config Class Initialized
INFO - 2016-03-07 07:11:40 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:11:40 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:11:40 --> Utf8 Class Initialized
INFO - 2016-03-07 07:11:40 --> URI Class Initialized
INFO - 2016-03-07 07:11:40 --> Router Class Initialized
INFO - 2016-03-07 07:11:40 --> Output Class Initialized
INFO - 2016-03-07 07:11:40 --> Security Class Initialized
DEBUG - 2016-03-07 07:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:11:40 --> Input Class Initialized
INFO - 2016-03-07 07:11:40 --> Language Class Initialized
INFO - 2016-03-07 07:11:40 --> Loader Class Initialized
INFO - 2016-03-07 07:11:40 --> Helper loaded: url_helper
INFO - 2016-03-07 07:11:40 --> Helper loaded: file_helper
INFO - 2016-03-07 07:11:40 --> Helper loaded: date_helper
INFO - 2016-03-07 07:11:40 --> Helper loaded: form_helper
INFO - 2016-03-07 07:11:40 --> Database Driver Class Initialized
INFO - 2016-03-07 07:11:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:11:41 --> Controller Class Initialized
INFO - 2016-03-07 07:11:41 --> Model Class Initialized
INFO - 2016-03-07 07:11:41 --> Model Class Initialized
INFO - 2016-03-07 07:11:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:11:41 --> Pagination Class Initialized
INFO - 2016-03-07 07:11:41 --> Helper loaded: text_helper
INFO - 2016-03-07 07:11:41 --> Helper loaded: cookie_helper
ERROR - 2016-03-07 10:11:41 --> Severity: Warning --> Missing argument 1 for Car::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\car.php 181
INFO - 2016-03-07 10:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:11:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:11:41 --> Form Validation Class Initialized
INFO - 2016-03-07 10:11:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-07 07:11:41 --> Config Class Initialized
INFO - 2016-03-07 07:11:41 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:11:41 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:11:41 --> Utf8 Class Initialized
INFO - 2016-03-07 07:11:41 --> URI Class Initialized
INFO - 2016-03-07 07:11:41 --> Router Class Initialized
INFO - 2016-03-07 07:11:41 --> Output Class Initialized
INFO - 2016-03-07 07:11:41 --> Security Class Initialized
DEBUG - 2016-03-07 07:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:11:41 --> Input Class Initialized
INFO - 2016-03-07 07:11:41 --> Language Class Initialized
INFO - 2016-03-07 07:11:41 --> Loader Class Initialized
INFO - 2016-03-07 07:11:41 --> Helper loaded: url_helper
INFO - 2016-03-07 07:11:41 --> Helper loaded: file_helper
INFO - 2016-03-07 07:11:41 --> Helper loaded: date_helper
INFO - 2016-03-07 07:11:41 --> Helper loaded: form_helper
INFO - 2016-03-07 07:11:41 --> Database Driver Class Initialized
INFO - 2016-03-07 07:11:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:11:42 --> Controller Class Initialized
INFO - 2016-03-07 07:11:42 --> Model Class Initialized
INFO - 2016-03-07 07:11:42 --> Model Class Initialized
INFO - 2016-03-07 07:11:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:11:42 --> Pagination Class Initialized
INFO - 2016-03-07 07:11:42 --> Helper loaded: text_helper
INFO - 2016-03-07 07:11:42 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 10:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:11:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:11:42 --> Final output sent to browser
DEBUG - 2016-03-07 10:11:42 --> Total execution time: 1.2355
INFO - 2016-03-07 07:11:42 --> Config Class Initialized
INFO - 2016-03-07 07:11:42 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:11:42 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:11:42 --> Utf8 Class Initialized
INFO - 2016-03-07 07:11:42 --> URI Class Initialized
INFO - 2016-03-07 07:11:42 --> Router Class Initialized
INFO - 2016-03-07 07:11:42 --> Output Class Initialized
INFO - 2016-03-07 07:11:42 --> Security Class Initialized
DEBUG - 2016-03-07 07:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:11:42 --> Input Class Initialized
INFO - 2016-03-07 07:11:42 --> Language Class Initialized
INFO - 2016-03-07 07:11:42 --> Loader Class Initialized
INFO - 2016-03-07 07:11:42 --> Helper loaded: url_helper
INFO - 2016-03-07 07:11:42 --> Helper loaded: file_helper
INFO - 2016-03-07 07:11:42 --> Helper loaded: date_helper
INFO - 2016-03-07 07:11:42 --> Helper loaded: form_helper
INFO - 2016-03-07 07:11:42 --> Database Driver Class Initialized
INFO - 2016-03-07 07:11:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:11:43 --> Controller Class Initialized
INFO - 2016-03-07 07:11:43 --> User Agent Class Initialized
INFO - 2016-03-07 07:11:43 --> Final output sent to browser
DEBUG - 2016-03-07 07:11:43 --> Total execution time: 1.1676
INFO - 2016-03-07 07:12:03 --> Config Class Initialized
INFO - 2016-03-07 07:12:03 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:12:03 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:12:03 --> Utf8 Class Initialized
INFO - 2016-03-07 07:12:03 --> URI Class Initialized
INFO - 2016-03-07 07:12:03 --> Router Class Initialized
INFO - 2016-03-07 07:12:03 --> Output Class Initialized
INFO - 2016-03-07 07:12:03 --> Security Class Initialized
DEBUG - 2016-03-07 07:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:12:03 --> Input Class Initialized
INFO - 2016-03-07 07:12:03 --> Language Class Initialized
INFO - 2016-03-07 07:12:03 --> Loader Class Initialized
INFO - 2016-03-07 07:12:03 --> Helper loaded: url_helper
INFO - 2016-03-07 07:12:03 --> Helper loaded: file_helper
INFO - 2016-03-07 07:12:03 --> Helper loaded: date_helper
INFO - 2016-03-07 07:12:03 --> Helper loaded: form_helper
INFO - 2016-03-07 07:12:03 --> Database Driver Class Initialized
INFO - 2016-03-07 07:12:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:12:04 --> Controller Class Initialized
INFO - 2016-03-07 07:12:04 --> Model Class Initialized
INFO - 2016-03-07 07:12:04 --> Model Class Initialized
INFO - 2016-03-07 07:12:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:12:04 --> Pagination Class Initialized
INFO - 2016-03-07 07:12:04 --> Helper loaded: text_helper
INFO - 2016-03-07 07:12:04 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 10:12:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:12:04 --> Final output sent to browser
DEBUG - 2016-03-07 10:12:04 --> Total execution time: 1.1163
INFO - 2016-03-07 07:12:08 --> Config Class Initialized
INFO - 2016-03-07 07:12:08 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:12:08 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:12:08 --> Utf8 Class Initialized
INFO - 2016-03-07 07:12:08 --> URI Class Initialized
INFO - 2016-03-07 07:12:08 --> Router Class Initialized
INFO - 2016-03-07 07:12:08 --> Output Class Initialized
INFO - 2016-03-07 07:12:08 --> Security Class Initialized
DEBUG - 2016-03-07 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:12:08 --> Input Class Initialized
INFO - 2016-03-07 07:12:08 --> Language Class Initialized
INFO - 2016-03-07 07:12:08 --> Loader Class Initialized
INFO - 2016-03-07 07:12:08 --> Helper loaded: url_helper
INFO - 2016-03-07 07:12:08 --> Helper loaded: file_helper
INFO - 2016-03-07 07:12:08 --> Helper loaded: date_helper
INFO - 2016-03-07 07:12:08 --> Helper loaded: form_helper
INFO - 2016-03-07 07:12:08 --> Database Driver Class Initialized
INFO - 2016-03-07 07:12:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:12:09 --> Controller Class Initialized
INFO - 2016-03-07 07:12:09 --> Model Class Initialized
INFO - 2016-03-07 07:12:09 --> Model Class Initialized
INFO - 2016-03-07 07:12:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:12:09 --> Pagination Class Initialized
INFO - 2016-03-07 07:12:09 --> Helper loaded: text_helper
INFO - 2016-03-07 07:12:09 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:12:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:12:09 --> Final output sent to browser
DEBUG - 2016-03-07 10:12:09 --> Total execution time: 1.1358
INFO - 2016-03-07 07:12:13 --> Config Class Initialized
INFO - 2016-03-07 07:12:13 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:12:13 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:12:13 --> Utf8 Class Initialized
INFO - 2016-03-07 07:12:13 --> URI Class Initialized
INFO - 2016-03-07 07:12:13 --> Router Class Initialized
INFO - 2016-03-07 07:12:13 --> Output Class Initialized
INFO - 2016-03-07 07:12:13 --> Security Class Initialized
DEBUG - 2016-03-07 07:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:12:13 --> Input Class Initialized
INFO - 2016-03-07 07:12:13 --> Language Class Initialized
INFO - 2016-03-07 07:12:13 --> Loader Class Initialized
INFO - 2016-03-07 07:12:13 --> Helper loaded: url_helper
INFO - 2016-03-07 07:12:13 --> Helper loaded: file_helper
INFO - 2016-03-07 07:12:13 --> Helper loaded: date_helper
INFO - 2016-03-07 07:12:13 --> Helper loaded: form_helper
INFO - 2016-03-07 07:12:13 --> Database Driver Class Initialized
INFO - 2016-03-07 07:12:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:12:14 --> Controller Class Initialized
INFO - 2016-03-07 07:12:14 --> Model Class Initialized
INFO - 2016-03-07 07:12:14 --> Model Class Initialized
INFO - 2016-03-07 07:12:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:12:14 --> Pagination Class Initialized
INFO - 2016-03-07 07:12:14 --> Helper loaded: text_helper
INFO - 2016-03-07 07:12:14 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 10:12:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:12:14 --> Final output sent to browser
DEBUG - 2016-03-07 10:12:14 --> Total execution time: 1.2482
INFO - 2016-03-07 07:15:06 --> Config Class Initialized
INFO - 2016-03-07 07:15:06 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:15:06 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:15:06 --> Utf8 Class Initialized
INFO - 2016-03-07 07:15:06 --> URI Class Initialized
INFO - 2016-03-07 07:15:06 --> Router Class Initialized
INFO - 2016-03-07 07:15:06 --> Output Class Initialized
INFO - 2016-03-07 07:15:06 --> Security Class Initialized
DEBUG - 2016-03-07 07:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:15:06 --> Input Class Initialized
INFO - 2016-03-07 07:15:06 --> Language Class Initialized
INFO - 2016-03-07 07:15:06 --> Loader Class Initialized
INFO - 2016-03-07 07:15:06 --> Helper loaded: url_helper
INFO - 2016-03-07 07:15:06 --> Helper loaded: file_helper
INFO - 2016-03-07 07:15:06 --> Helper loaded: date_helper
INFO - 2016-03-07 07:15:06 --> Helper loaded: form_helper
INFO - 2016-03-07 07:15:06 --> Database Driver Class Initialized
INFO - 2016-03-07 07:15:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:15:07 --> Controller Class Initialized
INFO - 2016-03-07 07:15:07 --> Model Class Initialized
INFO - 2016-03-07 07:15:07 --> Model Class Initialized
INFO - 2016-03-07 07:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:15:07 --> Pagination Class Initialized
INFO - 2016-03-07 07:15:07 --> Helper loaded: text_helper
INFO - 2016-03-07 07:15:07 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 10:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:15:07 --> Final output sent to browser
DEBUG - 2016-03-07 10:15:07 --> Total execution time: 1.1438
INFO - 2016-03-07 07:15:11 --> Config Class Initialized
INFO - 2016-03-07 07:15:11 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:15:11 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:15:11 --> Utf8 Class Initialized
INFO - 2016-03-07 07:15:11 --> URI Class Initialized
INFO - 2016-03-07 07:15:11 --> Router Class Initialized
INFO - 2016-03-07 07:15:11 --> Output Class Initialized
INFO - 2016-03-07 07:15:11 --> Security Class Initialized
DEBUG - 2016-03-07 07:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:15:11 --> Input Class Initialized
INFO - 2016-03-07 07:15:11 --> Language Class Initialized
INFO - 2016-03-07 07:15:11 --> Loader Class Initialized
INFO - 2016-03-07 07:15:11 --> Helper loaded: url_helper
INFO - 2016-03-07 07:15:11 --> Helper loaded: file_helper
INFO - 2016-03-07 07:15:11 --> Helper loaded: date_helper
INFO - 2016-03-07 07:15:11 --> Helper loaded: form_helper
INFO - 2016-03-07 07:15:11 --> Database Driver Class Initialized
INFO - 2016-03-07 07:15:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:15:12 --> Controller Class Initialized
INFO - 2016-03-07 07:15:12 --> Model Class Initialized
INFO - 2016-03-07 07:15:12 --> Model Class Initialized
INFO - 2016-03-07 07:15:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:15:12 --> Pagination Class Initialized
INFO - 2016-03-07 07:15:12 --> Helper loaded: text_helper
INFO - 2016-03-07 07:15:12 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:15:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:15:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-07 10:15:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-03-07 10:15:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-03-07 10:15:12 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-03-07 10:15:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-03-07 10:15:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:15:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:15:12 --> Final output sent to browser
DEBUG - 2016-03-07 10:15:12 --> Total execution time: 1.1840
INFO - 2016-03-07 07:19:21 --> Config Class Initialized
INFO - 2016-03-07 07:19:21 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:19:21 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:19:21 --> Utf8 Class Initialized
INFO - 2016-03-07 07:19:21 --> URI Class Initialized
INFO - 2016-03-07 07:19:21 --> Router Class Initialized
INFO - 2016-03-07 07:19:21 --> Output Class Initialized
INFO - 2016-03-07 07:19:21 --> Security Class Initialized
DEBUG - 2016-03-07 07:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:19:21 --> Input Class Initialized
INFO - 2016-03-07 07:19:21 --> Language Class Initialized
INFO - 2016-03-07 07:19:21 --> Loader Class Initialized
INFO - 2016-03-07 07:19:21 --> Helper loaded: url_helper
INFO - 2016-03-07 07:19:21 --> Helper loaded: file_helper
INFO - 2016-03-07 07:19:21 --> Helper loaded: date_helper
INFO - 2016-03-07 07:19:21 --> Helper loaded: form_helper
INFO - 2016-03-07 07:19:21 --> Database Driver Class Initialized
INFO - 2016-03-07 07:19:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:19:22 --> Controller Class Initialized
INFO - 2016-03-07 07:19:22 --> Model Class Initialized
INFO - 2016-03-07 07:19:22 --> Model Class Initialized
INFO - 2016-03-07 07:19:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:19:22 --> Pagination Class Initialized
INFO - 2016-03-07 07:19:22 --> Helper loaded: text_helper
INFO - 2016-03-07 07:19:22 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 10:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:19:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:19:22 --> Final output sent to browser
DEBUG - 2016-03-07 10:19:22 --> Total execution time: 1.2268
INFO - 2016-03-07 07:19:43 --> Config Class Initialized
INFO - 2016-03-07 07:19:43 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:19:43 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:19:43 --> Utf8 Class Initialized
INFO - 2016-03-07 07:19:43 --> URI Class Initialized
INFO - 2016-03-07 07:19:43 --> Router Class Initialized
INFO - 2016-03-07 07:19:43 --> Output Class Initialized
INFO - 2016-03-07 07:19:43 --> Security Class Initialized
DEBUG - 2016-03-07 07:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:19:43 --> Input Class Initialized
INFO - 2016-03-07 07:19:43 --> Language Class Initialized
INFO - 2016-03-07 07:19:43 --> Loader Class Initialized
INFO - 2016-03-07 07:19:43 --> Helper loaded: url_helper
INFO - 2016-03-07 07:19:43 --> Helper loaded: file_helper
INFO - 2016-03-07 07:19:43 --> Helper loaded: date_helper
INFO - 2016-03-07 07:19:43 --> Helper loaded: form_helper
INFO - 2016-03-07 07:19:43 --> Database Driver Class Initialized
INFO - 2016-03-07 07:19:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:19:44 --> Controller Class Initialized
INFO - 2016-03-07 07:19:44 --> Model Class Initialized
INFO - 2016-03-07 07:19:44 --> Model Class Initialized
INFO - 2016-03-07 07:19:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:19:44 --> Pagination Class Initialized
INFO - 2016-03-07 07:19:44 --> Helper loaded: text_helper
INFO - 2016-03-07 07:19:44 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-07 10:19:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-03-07 10:19:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-03-07 10:19:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-03-07 10:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-03-07 10:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:19:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:19:44 --> Final output sent to browser
DEBUG - 2016-03-07 10:19:44 --> Total execution time: 1.1337
INFO - 2016-03-07 07:20:42 --> Config Class Initialized
INFO - 2016-03-07 07:20:43 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:20:43 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:20:43 --> Utf8 Class Initialized
INFO - 2016-03-07 07:20:43 --> URI Class Initialized
INFO - 2016-03-07 07:20:43 --> Router Class Initialized
INFO - 2016-03-07 07:20:43 --> Output Class Initialized
INFO - 2016-03-07 07:20:43 --> Security Class Initialized
DEBUG - 2016-03-07 07:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:20:43 --> Input Class Initialized
INFO - 2016-03-07 07:20:43 --> Language Class Initialized
INFO - 2016-03-07 07:20:43 --> Loader Class Initialized
INFO - 2016-03-07 07:20:43 --> Helper loaded: url_helper
INFO - 2016-03-07 07:20:43 --> Helper loaded: file_helper
INFO - 2016-03-07 07:20:43 --> Helper loaded: date_helper
INFO - 2016-03-07 07:20:43 --> Helper loaded: form_helper
INFO - 2016-03-07 07:20:43 --> Database Driver Class Initialized
INFO - 2016-03-07 07:20:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:20:44 --> Controller Class Initialized
INFO - 2016-03-07 07:20:44 --> Model Class Initialized
INFO - 2016-03-07 07:20:44 --> Model Class Initialized
INFO - 2016-03-07 07:20:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:20:44 --> Pagination Class Initialized
INFO - 2016-03-07 07:20:44 --> Helper loaded: text_helper
INFO - 2016-03-07 07:20:44 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-07 10:20:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-03-07 10:20:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-03-07 10:20:44 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-03-07 10:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-03-07 10:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:20:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:20:44 --> Final output sent to browser
DEBUG - 2016-03-07 10:20:44 --> Total execution time: 1.1377
INFO - 2016-03-07 07:21:30 --> Config Class Initialized
INFO - 2016-03-07 07:21:30 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:21:30 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:21:30 --> Utf8 Class Initialized
INFO - 2016-03-07 07:21:30 --> URI Class Initialized
INFO - 2016-03-07 07:21:30 --> Router Class Initialized
INFO - 2016-03-07 07:21:30 --> Output Class Initialized
INFO - 2016-03-07 07:21:30 --> Security Class Initialized
DEBUG - 2016-03-07 07:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:21:30 --> Input Class Initialized
INFO - 2016-03-07 07:21:30 --> Language Class Initialized
INFO - 2016-03-07 07:21:30 --> Loader Class Initialized
INFO - 2016-03-07 07:21:30 --> Helper loaded: url_helper
INFO - 2016-03-07 07:21:30 --> Helper loaded: file_helper
INFO - 2016-03-07 07:21:30 --> Helper loaded: date_helper
INFO - 2016-03-07 07:21:30 --> Helper loaded: form_helper
INFO - 2016-03-07 07:21:30 --> Database Driver Class Initialized
INFO - 2016-03-07 07:21:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:21:31 --> Controller Class Initialized
INFO - 2016-03-07 07:21:31 --> Model Class Initialized
INFO - 2016-03-07 07:21:31 --> Model Class Initialized
INFO - 2016-03-07 07:21:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:21:31 --> Pagination Class Initialized
INFO - 2016-03-07 07:21:31 --> Helper loaded: text_helper
INFO - 2016-03-07 07:21:31 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-07 10:21:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-03-07 10:21:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-03-07 10:21:31 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-03-07 10:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-03-07 10:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:21:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:21:31 --> Final output sent to browser
DEBUG - 2016-03-07 10:21:31 --> Total execution time: 1.1266
INFO - 2016-03-07 07:22:35 --> Config Class Initialized
INFO - 2016-03-07 07:22:35 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:22:35 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:22:35 --> Utf8 Class Initialized
INFO - 2016-03-07 07:22:36 --> URI Class Initialized
INFO - 2016-03-07 07:22:36 --> Router Class Initialized
INFO - 2016-03-07 07:22:36 --> Output Class Initialized
INFO - 2016-03-07 07:22:36 --> Security Class Initialized
DEBUG - 2016-03-07 07:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:22:36 --> Input Class Initialized
INFO - 2016-03-07 07:22:36 --> Language Class Initialized
INFO - 2016-03-07 07:22:36 --> Loader Class Initialized
INFO - 2016-03-07 07:22:36 --> Helper loaded: url_helper
INFO - 2016-03-07 07:22:36 --> Helper loaded: file_helper
INFO - 2016-03-07 07:22:36 --> Helper loaded: date_helper
INFO - 2016-03-07 07:22:36 --> Helper loaded: form_helper
INFO - 2016-03-07 07:22:36 --> Database Driver Class Initialized
INFO - 2016-03-07 07:22:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:22:37 --> Controller Class Initialized
INFO - 2016-03-07 07:22:37 --> Model Class Initialized
INFO - 2016-03-07 07:22:37 --> Model Class Initialized
INFO - 2016-03-07 07:22:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:22:37 --> Pagination Class Initialized
INFO - 2016-03-07 07:22:37 --> Helper loaded: text_helper
INFO - 2016-03-07 07:22:37 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-07 10:22:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-03-07 10:22:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-03-07 10:22:37 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-03-07 10:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-03-07 10:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:22:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:22:37 --> Final output sent to browser
DEBUG - 2016-03-07 10:22:37 --> Total execution time: 1.1564
INFO - 2016-03-07 07:23:44 --> Config Class Initialized
INFO - 2016-03-07 07:23:44 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:23:44 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:23:44 --> Utf8 Class Initialized
INFO - 2016-03-07 07:23:44 --> URI Class Initialized
INFO - 2016-03-07 07:23:44 --> Router Class Initialized
INFO - 2016-03-07 07:23:44 --> Output Class Initialized
INFO - 2016-03-07 07:23:44 --> Security Class Initialized
DEBUG - 2016-03-07 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:23:44 --> Input Class Initialized
INFO - 2016-03-07 07:23:44 --> Language Class Initialized
INFO - 2016-03-07 07:23:44 --> Loader Class Initialized
INFO - 2016-03-07 07:23:44 --> Helper loaded: url_helper
INFO - 2016-03-07 07:23:44 --> Helper loaded: file_helper
INFO - 2016-03-07 07:23:44 --> Helper loaded: date_helper
INFO - 2016-03-07 07:23:44 --> Helper loaded: form_helper
INFO - 2016-03-07 07:23:44 --> Database Driver Class Initialized
INFO - 2016-03-07 07:23:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:23:45 --> Controller Class Initialized
INFO - 2016-03-07 07:23:45 --> Model Class Initialized
INFO - 2016-03-07 07:23:45 --> Model Class Initialized
INFO - 2016-03-07 07:23:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:23:45 --> Pagination Class Initialized
INFO - 2016-03-07 07:23:45 --> Helper loaded: text_helper
INFO - 2016-03-07 07:23:45 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-07 10:23:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-03-07 10:23:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-03-07 10:23:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-03-07 10:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-03-07 10:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:23:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:23:45 --> Final output sent to browser
DEBUG - 2016-03-07 10:23:45 --> Total execution time: 1.1572
INFO - 2016-03-07 07:24:06 --> Config Class Initialized
INFO - 2016-03-07 07:24:06 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:24:06 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:24:06 --> Utf8 Class Initialized
INFO - 2016-03-07 07:24:06 --> URI Class Initialized
INFO - 2016-03-07 07:24:06 --> Router Class Initialized
INFO - 2016-03-07 07:24:06 --> Output Class Initialized
INFO - 2016-03-07 07:24:06 --> Security Class Initialized
DEBUG - 2016-03-07 07:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:24:06 --> Input Class Initialized
INFO - 2016-03-07 07:24:06 --> Language Class Initialized
INFO - 2016-03-07 07:24:06 --> Loader Class Initialized
INFO - 2016-03-07 07:24:06 --> Helper loaded: url_helper
INFO - 2016-03-07 07:24:06 --> Helper loaded: file_helper
INFO - 2016-03-07 07:24:06 --> Helper loaded: date_helper
INFO - 2016-03-07 07:24:06 --> Helper loaded: form_helper
INFO - 2016-03-07 07:24:06 --> Database Driver Class Initialized
INFO - 2016-03-07 07:24:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:24:07 --> Controller Class Initialized
INFO - 2016-03-07 07:24:07 --> Model Class Initialized
INFO - 2016-03-07 07:24:07 --> Model Class Initialized
INFO - 2016-03-07 07:24:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:24:07 --> Pagination Class Initialized
INFO - 2016-03-07 07:24:07 --> Helper loaded: text_helper
INFO - 2016-03-07 07:24:07 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-07 10:24:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 5
ERROR - 2016-03-07 10:24:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 9
ERROR - 2016-03-07 10:24:07 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php 13
INFO - 2016-03-07 10:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-03-07 10:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:24:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:24:07 --> Final output sent to browser
DEBUG - 2016-03-07 10:24:07 --> Total execution time: 1.2601
INFO - 2016-03-07 07:24:13 --> Config Class Initialized
INFO - 2016-03-07 07:24:13 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:24:13 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:24:13 --> Utf8 Class Initialized
INFO - 2016-03-07 07:24:13 --> URI Class Initialized
INFO - 2016-03-07 07:24:13 --> Router Class Initialized
INFO - 2016-03-07 07:24:13 --> Output Class Initialized
INFO - 2016-03-07 07:24:13 --> Security Class Initialized
DEBUG - 2016-03-07 07:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:24:13 --> Input Class Initialized
INFO - 2016-03-07 07:24:13 --> Language Class Initialized
INFO - 2016-03-07 07:24:13 --> Loader Class Initialized
INFO - 2016-03-07 07:24:13 --> Helper loaded: url_helper
INFO - 2016-03-07 07:24:13 --> Helper loaded: file_helper
INFO - 2016-03-07 07:24:13 --> Helper loaded: date_helper
INFO - 2016-03-07 07:24:13 --> Helper loaded: form_helper
INFO - 2016-03-07 07:24:13 --> Database Driver Class Initialized
INFO - 2016-03-07 07:24:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:24:14 --> Controller Class Initialized
INFO - 2016-03-07 07:24:14 --> Model Class Initialized
INFO - 2016-03-07 07:24:14 --> Model Class Initialized
INFO - 2016-03-07 07:24:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:24:14 --> Pagination Class Initialized
INFO - 2016-03-07 07:24:14 --> Helper loaded: text_helper
INFO - 2016-03-07 07:24:14 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 10:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:24:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:24:14 --> Final output sent to browser
DEBUG - 2016-03-07 10:24:14 --> Total execution time: 1.2114
INFO - 2016-03-07 07:24:16 --> Config Class Initialized
INFO - 2016-03-07 07:24:16 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:24:16 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:24:16 --> Utf8 Class Initialized
INFO - 2016-03-07 07:24:16 --> URI Class Initialized
INFO - 2016-03-07 07:24:16 --> Router Class Initialized
INFO - 2016-03-07 07:24:16 --> Output Class Initialized
INFO - 2016-03-07 07:24:16 --> Security Class Initialized
DEBUG - 2016-03-07 07:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:24:16 --> Input Class Initialized
INFO - 2016-03-07 07:24:16 --> Language Class Initialized
INFO - 2016-03-07 07:24:16 --> Loader Class Initialized
INFO - 2016-03-07 07:24:16 --> Helper loaded: url_helper
INFO - 2016-03-07 07:24:17 --> Helper loaded: file_helper
INFO - 2016-03-07 07:24:17 --> Helper loaded: date_helper
INFO - 2016-03-07 07:24:17 --> Helper loaded: form_helper
INFO - 2016-03-07 07:24:17 --> Database Driver Class Initialized
INFO - 2016-03-07 07:24:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:24:18 --> Controller Class Initialized
INFO - 2016-03-07 07:24:18 --> Model Class Initialized
INFO - 2016-03-07 07:24:18 --> Model Class Initialized
INFO - 2016-03-07 07:24:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:24:18 --> Pagination Class Initialized
INFO - 2016-03-07 07:24:18 --> Helper loaded: text_helper
INFO - 2016-03-07 07:24:18 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\modify.php
INFO - 2016-03-07 10:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:24:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:24:18 --> Final output sent to browser
DEBUG - 2016-03-07 10:24:18 --> Total execution time: 1.1205
INFO - 2016-03-07 07:24:28 --> Config Class Initialized
INFO - 2016-03-07 07:24:28 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:24:28 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:24:28 --> Utf8 Class Initialized
INFO - 2016-03-07 07:24:28 --> URI Class Initialized
INFO - 2016-03-07 07:24:28 --> Router Class Initialized
INFO - 2016-03-07 07:24:28 --> Output Class Initialized
INFO - 2016-03-07 07:24:28 --> Security Class Initialized
DEBUG - 2016-03-07 07:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:24:28 --> Input Class Initialized
INFO - 2016-03-07 07:24:28 --> Language Class Initialized
INFO - 2016-03-07 07:24:28 --> Loader Class Initialized
INFO - 2016-03-07 07:24:28 --> Helper loaded: url_helper
INFO - 2016-03-07 07:24:28 --> Helper loaded: file_helper
INFO - 2016-03-07 07:24:28 --> Helper loaded: date_helper
INFO - 2016-03-07 07:24:28 --> Helper loaded: form_helper
INFO - 2016-03-07 07:24:28 --> Database Driver Class Initialized
INFO - 2016-03-07 07:24:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:24:29 --> Controller Class Initialized
INFO - 2016-03-07 07:24:29 --> Model Class Initialized
INFO - 2016-03-07 07:24:29 --> Model Class Initialized
INFO - 2016-03-07 07:24:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:24:29 --> Pagination Class Initialized
INFO - 2016-03-07 07:24:29 --> Helper loaded: text_helper
INFO - 2016-03-07 07:24:29 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:24:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:24:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 07:24:30 --> Config Class Initialized
INFO - 2016-03-07 07:24:30 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:24:30 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:24:30 --> Utf8 Class Initialized
INFO - 2016-03-07 07:24:30 --> URI Class Initialized
INFO - 2016-03-07 07:24:30 --> Router Class Initialized
INFO - 2016-03-07 07:24:30 --> Output Class Initialized
INFO - 2016-03-07 07:24:30 --> Security Class Initialized
DEBUG - 2016-03-07 07:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:24:30 --> Input Class Initialized
INFO - 2016-03-07 07:24:30 --> Language Class Initialized
INFO - 2016-03-07 07:24:30 --> Loader Class Initialized
INFO - 2016-03-07 07:24:30 --> Helper loaded: url_helper
INFO - 2016-03-07 07:24:30 --> Helper loaded: file_helper
INFO - 2016-03-07 07:24:30 --> Helper loaded: date_helper
INFO - 2016-03-07 07:24:30 --> Helper loaded: form_helper
INFO - 2016-03-07 07:24:30 --> Database Driver Class Initialized
INFO - 2016-03-07 07:24:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:24:31 --> Controller Class Initialized
INFO - 2016-03-07 07:24:31 --> Model Class Initialized
INFO - 2016-03-07 07:24:31 --> Model Class Initialized
INFO - 2016-03-07 07:24:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:24:31 --> Pagination Class Initialized
INFO - 2016-03-07 07:24:31 --> Helper loaded: text_helper
INFO - 2016-03-07 07:24:31 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:24:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:24:31 --> Final output sent to browser
DEBUG - 2016-03-07 10:24:31 --> Total execution time: 1.2029
INFO - 2016-03-07 07:29:23 --> Config Class Initialized
INFO - 2016-03-07 07:29:23 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:29:23 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:29:23 --> Utf8 Class Initialized
INFO - 2016-03-07 07:29:23 --> URI Class Initialized
DEBUG - 2016-03-07 07:29:23 --> No URI present. Default controller set.
INFO - 2016-03-07 07:29:23 --> Router Class Initialized
INFO - 2016-03-07 07:29:23 --> Output Class Initialized
INFO - 2016-03-07 07:29:23 --> Security Class Initialized
DEBUG - 2016-03-07 07:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:29:23 --> Input Class Initialized
INFO - 2016-03-07 07:29:23 --> Language Class Initialized
INFO - 2016-03-07 07:29:23 --> Loader Class Initialized
INFO - 2016-03-07 07:29:23 --> Helper loaded: url_helper
INFO - 2016-03-07 07:29:23 --> Helper loaded: file_helper
INFO - 2016-03-07 07:29:23 --> Helper loaded: date_helper
INFO - 2016-03-07 07:29:23 --> Helper loaded: form_helper
INFO - 2016-03-07 07:29:23 --> Database Driver Class Initialized
INFO - 2016-03-07 07:29:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:29:24 --> Controller Class Initialized
INFO - 2016-03-07 07:29:24 --> Model Class Initialized
INFO - 2016-03-07 07:29:24 --> Model Class Initialized
INFO - 2016-03-07 07:29:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:29:24 --> Pagination Class Initialized
INFO - 2016-03-07 07:29:24 --> Helper loaded: text_helper
INFO - 2016-03-07 07:29:24 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 10:29:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:29:24 --> Final output sent to browser
DEBUG - 2016-03-07 10:29:24 --> Total execution time: 1.1439
INFO - 2016-03-07 07:29:50 --> Config Class Initialized
INFO - 2016-03-07 07:29:50 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:29:50 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:29:50 --> Utf8 Class Initialized
INFO - 2016-03-07 07:29:50 --> URI Class Initialized
INFO - 2016-03-07 07:29:50 --> Router Class Initialized
INFO - 2016-03-07 07:29:50 --> Output Class Initialized
INFO - 2016-03-07 07:29:50 --> Security Class Initialized
DEBUG - 2016-03-07 07:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:29:50 --> Input Class Initialized
INFO - 2016-03-07 07:29:50 --> Language Class Initialized
INFO - 2016-03-07 07:29:50 --> Loader Class Initialized
INFO - 2016-03-07 07:29:50 --> Helper loaded: url_helper
INFO - 2016-03-07 07:29:50 --> Helper loaded: file_helper
INFO - 2016-03-07 07:29:50 --> Helper loaded: date_helper
INFO - 2016-03-07 07:29:50 --> Helper loaded: form_helper
INFO - 2016-03-07 07:29:50 --> Database Driver Class Initialized
INFO - 2016-03-07 07:29:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:29:51 --> Controller Class Initialized
INFO - 2016-03-07 07:29:51 --> Model Class Initialized
INFO - 2016-03-07 07:29:51 --> Model Class Initialized
INFO - 2016-03-07 07:29:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:29:51 --> Pagination Class Initialized
INFO - 2016-03-07 07:29:51 --> Helper loaded: text_helper
INFO - 2016-03-07 07:29:51 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 10:29:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:29:51 --> Final output sent to browser
DEBUG - 2016-03-07 10:29:51 --> Total execution time: 1.1694
INFO - 2016-03-07 07:35:22 --> Config Class Initialized
INFO - 2016-03-07 07:35:22 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:35:22 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:35:22 --> Utf8 Class Initialized
INFO - 2016-03-07 07:35:22 --> URI Class Initialized
INFO - 2016-03-07 07:35:22 --> Router Class Initialized
INFO - 2016-03-07 07:35:22 --> Output Class Initialized
INFO - 2016-03-07 07:35:22 --> Security Class Initialized
DEBUG - 2016-03-07 07:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:35:22 --> Input Class Initialized
INFO - 2016-03-07 07:35:22 --> Language Class Initialized
INFO - 2016-03-07 07:35:22 --> Loader Class Initialized
INFO - 2016-03-07 07:35:22 --> Helper loaded: url_helper
INFO - 2016-03-07 07:35:23 --> Helper loaded: file_helper
INFO - 2016-03-07 07:35:23 --> Helper loaded: date_helper
INFO - 2016-03-07 07:35:23 --> Helper loaded: form_helper
INFO - 2016-03-07 07:35:23 --> Database Driver Class Initialized
INFO - 2016-03-07 07:35:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:35:24 --> Controller Class Initialized
INFO - 2016-03-07 07:35:24 --> Model Class Initialized
INFO - 2016-03-07 07:35:24 --> Model Class Initialized
INFO - 2016-03-07 07:35:24 --> Form Validation Class Initialized
INFO - 2016-03-07 07:35:24 --> Helper loaded: text_helper
INFO - 2016-03-07 07:35:24 --> Config Class Initialized
INFO - 2016-03-07 07:35:24 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:35:24 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:35:24 --> Utf8 Class Initialized
INFO - 2016-03-07 07:35:24 --> URI Class Initialized
DEBUG - 2016-03-07 07:35:24 --> No URI present. Default controller set.
INFO - 2016-03-07 07:35:24 --> Router Class Initialized
INFO - 2016-03-07 07:35:24 --> Output Class Initialized
INFO - 2016-03-07 07:35:24 --> Security Class Initialized
DEBUG - 2016-03-07 07:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:35:24 --> Input Class Initialized
INFO - 2016-03-07 07:35:24 --> Language Class Initialized
INFO - 2016-03-07 07:35:24 --> Loader Class Initialized
INFO - 2016-03-07 07:35:24 --> Helper loaded: url_helper
INFO - 2016-03-07 07:35:24 --> Helper loaded: file_helper
INFO - 2016-03-07 07:35:24 --> Helper loaded: date_helper
INFO - 2016-03-07 07:35:24 --> Helper loaded: form_helper
INFO - 2016-03-07 07:35:24 --> Database Driver Class Initialized
INFO - 2016-03-07 07:35:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:35:25 --> Controller Class Initialized
INFO - 2016-03-07 07:35:25 --> Model Class Initialized
INFO - 2016-03-07 07:35:25 --> Model Class Initialized
INFO - 2016-03-07 07:35:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:35:25 --> Pagination Class Initialized
INFO - 2016-03-07 07:35:25 --> Helper loaded: text_helper
INFO - 2016-03-07 07:35:25 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:35:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:35:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:35:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 10:35:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:35:25 --> Final output sent to browser
DEBUG - 2016-03-07 10:35:25 --> Total execution time: 1.1222
INFO - 2016-03-07 07:35:53 --> Config Class Initialized
INFO - 2016-03-07 07:35:53 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:35:53 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:35:53 --> Utf8 Class Initialized
INFO - 2016-03-07 07:35:53 --> URI Class Initialized
INFO - 2016-03-07 07:35:53 --> Router Class Initialized
INFO - 2016-03-07 07:35:53 --> Output Class Initialized
INFO - 2016-03-07 07:35:53 --> Security Class Initialized
DEBUG - 2016-03-07 07:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:35:53 --> Input Class Initialized
INFO - 2016-03-07 07:35:53 --> Language Class Initialized
INFO - 2016-03-07 07:35:53 --> Loader Class Initialized
INFO - 2016-03-07 07:35:53 --> Helper loaded: url_helper
INFO - 2016-03-07 07:35:53 --> Helper loaded: file_helper
INFO - 2016-03-07 07:35:53 --> Helper loaded: date_helper
INFO - 2016-03-07 07:35:53 --> Helper loaded: form_helper
INFO - 2016-03-07 07:35:53 --> Database Driver Class Initialized
INFO - 2016-03-07 07:35:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:35:54 --> Controller Class Initialized
INFO - 2016-03-07 07:35:54 --> Model Class Initialized
INFO - 2016-03-07 07:35:54 --> Model Class Initialized
INFO - 2016-03-07 07:35:54 --> Form Validation Class Initialized
INFO - 2016-03-07 07:35:54 --> Helper loaded: text_helper
INFO - 2016-03-07 07:35:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-07 07:35:54 --> Final output sent to browser
DEBUG - 2016-03-07 07:35:54 --> Total execution time: 1.3488
INFO - 2016-03-07 07:35:57 --> Config Class Initialized
INFO - 2016-03-07 07:35:57 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:35:57 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:35:57 --> Utf8 Class Initialized
INFO - 2016-03-07 07:35:57 --> URI Class Initialized
DEBUG - 2016-03-07 07:35:57 --> No URI present. Default controller set.
INFO - 2016-03-07 07:35:58 --> Router Class Initialized
INFO - 2016-03-07 07:35:58 --> Output Class Initialized
INFO - 2016-03-07 07:35:58 --> Security Class Initialized
DEBUG - 2016-03-07 07:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:35:58 --> Input Class Initialized
INFO - 2016-03-07 07:35:58 --> Language Class Initialized
INFO - 2016-03-07 07:35:58 --> Loader Class Initialized
INFO - 2016-03-07 07:35:58 --> Helper loaded: url_helper
INFO - 2016-03-07 07:35:58 --> Helper loaded: file_helper
INFO - 2016-03-07 07:35:58 --> Helper loaded: date_helper
INFO - 2016-03-07 07:35:58 --> Helper loaded: form_helper
INFO - 2016-03-07 07:35:58 --> Database Driver Class Initialized
INFO - 2016-03-07 07:35:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:35:59 --> Controller Class Initialized
INFO - 2016-03-07 07:35:59 --> Model Class Initialized
INFO - 2016-03-07 07:35:59 --> Model Class Initialized
INFO - 2016-03-07 07:35:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:35:59 --> Pagination Class Initialized
INFO - 2016-03-07 07:35:59 --> Helper loaded: text_helper
INFO - 2016-03-07 07:35:59 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:35:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:35:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:35:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 10:35:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:35:59 --> Final output sent to browser
DEBUG - 2016-03-07 10:35:59 --> Total execution time: 1.2319
INFO - 2016-03-07 07:36:02 --> Config Class Initialized
INFO - 2016-03-07 07:36:02 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:36:02 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:36:02 --> Utf8 Class Initialized
INFO - 2016-03-07 07:36:02 --> URI Class Initialized
INFO - 2016-03-07 07:36:02 --> Router Class Initialized
INFO - 2016-03-07 07:36:02 --> Output Class Initialized
INFO - 2016-03-07 07:36:02 --> Security Class Initialized
DEBUG - 2016-03-07 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:36:02 --> Input Class Initialized
INFO - 2016-03-07 07:36:02 --> Language Class Initialized
INFO - 2016-03-07 07:36:02 --> Loader Class Initialized
INFO - 2016-03-07 07:36:02 --> Helper loaded: url_helper
INFO - 2016-03-07 07:36:02 --> Helper loaded: file_helper
INFO - 2016-03-07 07:36:02 --> Helper loaded: date_helper
INFO - 2016-03-07 07:36:02 --> Helper loaded: form_helper
INFO - 2016-03-07 07:36:02 --> Database Driver Class Initialized
INFO - 2016-03-07 07:36:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:36:03 --> Controller Class Initialized
INFO - 2016-03-07 07:36:03 --> Model Class Initialized
INFO - 2016-03-07 07:36:03 --> Model Class Initialized
INFO - 2016-03-07 07:36:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:36:03 --> Pagination Class Initialized
INFO - 2016-03-07 07:36:03 --> Helper loaded: text_helper
INFO - 2016-03-07 07:36:03 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:36:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:36:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:36:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:36:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:36:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 10:36:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:36:03 --> Final output sent to browser
DEBUG - 2016-03-07 10:36:03 --> Total execution time: 1.1395
INFO - 2016-03-07 07:36:23 --> Config Class Initialized
INFO - 2016-03-07 07:36:23 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:36:23 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:36:23 --> Utf8 Class Initialized
INFO - 2016-03-07 07:36:23 --> URI Class Initialized
INFO - 2016-03-07 07:36:23 --> Router Class Initialized
INFO - 2016-03-07 07:36:23 --> Output Class Initialized
INFO - 2016-03-07 07:36:23 --> Security Class Initialized
DEBUG - 2016-03-07 07:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:36:23 --> Input Class Initialized
INFO - 2016-03-07 07:36:23 --> Language Class Initialized
INFO - 2016-03-07 07:36:23 --> Loader Class Initialized
INFO - 2016-03-07 07:36:23 --> Helper loaded: url_helper
INFO - 2016-03-07 07:36:23 --> Helper loaded: file_helper
INFO - 2016-03-07 07:36:23 --> Helper loaded: date_helper
INFO - 2016-03-07 07:36:23 --> Helper loaded: form_helper
INFO - 2016-03-07 07:36:23 --> Database Driver Class Initialized
INFO - 2016-03-07 07:36:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:36:24 --> Controller Class Initialized
INFO - 2016-03-07 07:36:24 --> Model Class Initialized
INFO - 2016-03-07 07:36:24 --> Model Class Initialized
INFO - 2016-03-07 07:36:24 --> Form Validation Class Initialized
INFO - 2016-03-07 07:36:24 --> Helper loaded: text_helper
INFO - 2016-03-07 07:36:24 --> Final output sent to browser
DEBUG - 2016-03-07 07:36:24 --> Total execution time: 1.2504
INFO - 2016-03-07 07:36:24 --> Config Class Initialized
INFO - 2016-03-07 07:36:24 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:36:24 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:36:24 --> Utf8 Class Initialized
INFO - 2016-03-07 07:36:24 --> URI Class Initialized
INFO - 2016-03-07 07:36:24 --> Router Class Initialized
INFO - 2016-03-07 07:36:24 --> Output Class Initialized
INFO - 2016-03-07 07:36:24 --> Security Class Initialized
DEBUG - 2016-03-07 07:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:36:24 --> Input Class Initialized
INFO - 2016-03-07 07:36:24 --> Language Class Initialized
INFO - 2016-03-07 07:36:24 --> Loader Class Initialized
INFO - 2016-03-07 07:36:24 --> Helper loaded: url_helper
INFO - 2016-03-07 07:36:25 --> Helper loaded: file_helper
INFO - 2016-03-07 07:36:25 --> Helper loaded: date_helper
INFO - 2016-03-07 07:36:25 --> Helper loaded: form_helper
INFO - 2016-03-07 07:36:25 --> Database Driver Class Initialized
INFO - 2016-03-07 07:36:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:36:26 --> Controller Class Initialized
INFO - 2016-03-07 07:36:26 --> Model Class Initialized
INFO - 2016-03-07 07:36:26 --> Model Class Initialized
INFO - 2016-03-07 07:36:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:36:26 --> Pagination Class Initialized
INFO - 2016-03-07 07:36:26 --> Helper loaded: text_helper
INFO - 2016-03-07 07:36:26 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 10:36:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:36:26 --> Final output sent to browser
DEBUG - 2016-03-07 10:36:26 --> Total execution time: 1.1419
INFO - 2016-03-07 07:36:27 --> Config Class Initialized
INFO - 2016-03-07 07:36:27 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:36:27 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:36:27 --> Utf8 Class Initialized
INFO - 2016-03-07 07:36:27 --> URI Class Initialized
INFO - 2016-03-07 07:36:27 --> Router Class Initialized
INFO - 2016-03-07 07:36:27 --> Output Class Initialized
INFO - 2016-03-07 07:36:27 --> Security Class Initialized
DEBUG - 2016-03-07 07:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:36:27 --> Input Class Initialized
INFO - 2016-03-07 07:36:27 --> Language Class Initialized
INFO - 2016-03-07 07:36:27 --> Loader Class Initialized
INFO - 2016-03-07 07:36:27 --> Helper loaded: url_helper
INFO - 2016-03-07 07:36:27 --> Helper loaded: file_helper
INFO - 2016-03-07 07:36:27 --> Helper loaded: date_helper
INFO - 2016-03-07 07:36:27 --> Helper loaded: form_helper
INFO - 2016-03-07 07:36:27 --> Database Driver Class Initialized
INFO - 2016-03-07 07:36:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:36:28 --> Controller Class Initialized
INFO - 2016-03-07 07:36:28 --> Model Class Initialized
INFO - 2016-03-07 07:36:28 --> Model Class Initialized
INFO - 2016-03-07 07:36:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:36:28 --> Pagination Class Initialized
INFO - 2016-03-07 07:36:28 --> Helper loaded: text_helper
INFO - 2016-03-07 07:36:28 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-07 10:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:36:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:36:28 --> Final output sent to browser
DEBUG - 2016-03-07 10:36:28 --> Total execution time: 1.1195
INFO - 2016-03-07 07:42:51 --> Config Class Initialized
INFO - 2016-03-07 07:42:51 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:42:51 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:42:51 --> Utf8 Class Initialized
INFO - 2016-03-07 07:42:51 --> URI Class Initialized
INFO - 2016-03-07 07:42:51 --> Router Class Initialized
INFO - 2016-03-07 07:42:51 --> Output Class Initialized
INFO - 2016-03-07 07:42:51 --> Security Class Initialized
DEBUG - 2016-03-07 07:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:42:51 --> Input Class Initialized
INFO - 2016-03-07 07:42:51 --> Language Class Initialized
INFO - 2016-03-07 07:42:51 --> Loader Class Initialized
INFO - 2016-03-07 07:42:51 --> Helper loaded: url_helper
INFO - 2016-03-07 07:42:51 --> Helper loaded: file_helper
INFO - 2016-03-07 07:42:51 --> Helper loaded: date_helper
INFO - 2016-03-07 07:42:51 --> Helper loaded: form_helper
INFO - 2016-03-07 07:42:51 --> Database Driver Class Initialized
INFO - 2016-03-07 07:42:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:42:52 --> Controller Class Initialized
INFO - 2016-03-07 07:42:52 --> Model Class Initialized
INFO - 2016-03-07 07:42:52 --> Model Class Initialized
INFO - 2016-03-07 07:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:42:52 --> Pagination Class Initialized
INFO - 2016-03-07 07:42:52 --> Helper loaded: text_helper
INFO - 2016-03-07 07:42:52 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:42:52 --> Form Validation Class Initialized
INFO - 2016-03-07 10:42:52 --> Upload Class Initialized
INFO - 2016-03-07 10:42:52 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:42:52 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:42:52 --> Final output sent to browser
DEBUG - 2016-03-07 10:42:52 --> Total execution time: 1.1580
INFO - 2016-03-07 07:42:59 --> Config Class Initialized
INFO - 2016-03-07 07:42:59 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:42:59 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:42:59 --> Utf8 Class Initialized
INFO - 2016-03-07 07:42:59 --> URI Class Initialized
INFO - 2016-03-07 07:42:59 --> Router Class Initialized
INFO - 2016-03-07 07:42:59 --> Output Class Initialized
INFO - 2016-03-07 07:42:59 --> Security Class Initialized
DEBUG - 2016-03-07 07:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:42:59 --> Input Class Initialized
INFO - 2016-03-07 07:42:59 --> Language Class Initialized
INFO - 2016-03-07 07:42:59 --> Loader Class Initialized
INFO - 2016-03-07 07:42:59 --> Helper loaded: url_helper
INFO - 2016-03-07 07:42:59 --> Helper loaded: file_helper
INFO - 2016-03-07 07:42:59 --> Helper loaded: date_helper
INFO - 2016-03-07 07:42:59 --> Helper loaded: form_helper
INFO - 2016-03-07 07:42:59 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:00 --> Controller Class Initialized
INFO - 2016-03-07 07:43:00 --> Model Class Initialized
INFO - 2016-03-07 07:43:00 --> Model Class Initialized
INFO - 2016-03-07 07:43:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:00 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:00 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:00 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:00 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:00 --> Upload Class Initialized
INFO - 2016-03-07 10:43:00 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:00 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:00 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:00 --> Total execution time: 1.1776
INFO - 2016-03-07 07:43:05 --> Config Class Initialized
INFO - 2016-03-07 07:43:05 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:43:05 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:43:05 --> Utf8 Class Initialized
INFO - 2016-03-07 07:43:05 --> URI Class Initialized
INFO - 2016-03-07 07:43:05 --> Router Class Initialized
INFO - 2016-03-07 07:43:05 --> Output Class Initialized
INFO - 2016-03-07 07:43:05 --> Security Class Initialized
DEBUG - 2016-03-07 07:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:43:05 --> Input Class Initialized
INFO - 2016-03-07 07:43:05 --> Language Class Initialized
INFO - 2016-03-07 07:43:05 --> Loader Class Initialized
INFO - 2016-03-07 07:43:05 --> Helper loaded: url_helper
INFO - 2016-03-07 07:43:05 --> Helper loaded: file_helper
INFO - 2016-03-07 07:43:05 --> Helper loaded: date_helper
INFO - 2016-03-07 07:43:05 --> Helper loaded: form_helper
INFO - 2016-03-07 07:43:05 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:06 --> Controller Class Initialized
INFO - 2016-03-07 07:43:06 --> Model Class Initialized
INFO - 2016-03-07 07:43:06 --> Model Class Initialized
INFO - 2016-03-07 07:43:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:06 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:06 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:06 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:06 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:06 --> Upload Class Initialized
INFO - 2016-03-07 10:43:06 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:06 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:06 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:06 --> Total execution time: 1.1858
INFO - 2016-03-07 07:43:12 --> Config Class Initialized
INFO - 2016-03-07 07:43:12 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:43:12 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:43:12 --> Utf8 Class Initialized
INFO - 2016-03-07 07:43:12 --> URI Class Initialized
INFO - 2016-03-07 07:43:12 --> Router Class Initialized
INFO - 2016-03-07 07:43:12 --> Output Class Initialized
INFO - 2016-03-07 07:43:12 --> Security Class Initialized
DEBUG - 2016-03-07 07:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:43:12 --> Input Class Initialized
INFO - 2016-03-07 07:43:12 --> Language Class Initialized
INFO - 2016-03-07 07:43:12 --> Loader Class Initialized
INFO - 2016-03-07 07:43:12 --> Helper loaded: url_helper
INFO - 2016-03-07 07:43:12 --> Helper loaded: file_helper
INFO - 2016-03-07 07:43:12 --> Helper loaded: date_helper
INFO - 2016-03-07 07:43:12 --> Helper loaded: form_helper
INFO - 2016-03-07 07:43:12 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:13 --> Controller Class Initialized
INFO - 2016-03-07 07:43:13 --> Model Class Initialized
INFO - 2016-03-07 07:43:13 --> Model Class Initialized
INFO - 2016-03-07 07:43:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:13 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:13 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:13 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:13 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:13 --> Upload Class Initialized
INFO - 2016-03-07 10:43:13 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:13 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:13 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:13 --> Total execution time: 1.2420
INFO - 2016-03-07 07:43:21 --> Config Class Initialized
INFO - 2016-03-07 07:43:21 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:43:21 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:43:21 --> Utf8 Class Initialized
INFO - 2016-03-07 07:43:21 --> URI Class Initialized
INFO - 2016-03-07 07:43:21 --> Router Class Initialized
INFO - 2016-03-07 07:43:21 --> Output Class Initialized
INFO - 2016-03-07 07:43:21 --> Security Class Initialized
DEBUG - 2016-03-07 07:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:43:21 --> Input Class Initialized
INFO - 2016-03-07 07:43:21 --> Language Class Initialized
INFO - 2016-03-07 07:43:21 --> Loader Class Initialized
INFO - 2016-03-07 07:43:21 --> Helper loaded: url_helper
INFO - 2016-03-07 07:43:21 --> Helper loaded: file_helper
INFO - 2016-03-07 07:43:21 --> Helper loaded: date_helper
INFO - 2016-03-07 07:43:21 --> Helper loaded: form_helper
INFO - 2016-03-07 07:43:21 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:22 --> Controller Class Initialized
INFO - 2016-03-07 07:43:22 --> Model Class Initialized
INFO - 2016-03-07 07:43:22 --> Model Class Initialized
INFO - 2016-03-07 07:43:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:22 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:22 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:22 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:22 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:22 --> Upload Class Initialized
INFO - 2016-03-07 10:43:22 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:22 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:22 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:22 --> Total execution time: 1.1607
INFO - 2016-03-07 07:43:29 --> Config Class Initialized
INFO - 2016-03-07 07:43:29 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:43:29 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:43:29 --> Utf8 Class Initialized
INFO - 2016-03-07 07:43:29 --> URI Class Initialized
INFO - 2016-03-07 07:43:29 --> Router Class Initialized
INFO - 2016-03-07 07:43:29 --> Output Class Initialized
INFO - 2016-03-07 07:43:29 --> Security Class Initialized
DEBUG - 2016-03-07 07:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:43:29 --> Input Class Initialized
INFO - 2016-03-07 07:43:29 --> Language Class Initialized
INFO - 2016-03-07 07:43:29 --> Loader Class Initialized
INFO - 2016-03-07 07:43:29 --> Helper loaded: url_helper
INFO - 2016-03-07 07:43:29 --> Helper loaded: file_helper
INFO - 2016-03-07 07:43:29 --> Helper loaded: date_helper
INFO - 2016-03-07 07:43:29 --> Helper loaded: form_helper
INFO - 2016-03-07 07:43:29 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:30 --> Controller Class Initialized
INFO - 2016-03-07 07:43:30 --> Model Class Initialized
INFO - 2016-03-07 07:43:30 --> Model Class Initialized
INFO - 2016-03-07 07:43:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:30 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:30 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:30 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:30 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:30 --> Upload Class Initialized
INFO - 2016-03-07 10:43:30 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:30 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:30 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:30 --> Total execution time: 1.2040
INFO - 2016-03-07 07:43:36 --> Config Class Initialized
INFO - 2016-03-07 07:43:36 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:43:36 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:43:36 --> Utf8 Class Initialized
INFO - 2016-03-07 07:43:36 --> URI Class Initialized
INFO - 2016-03-07 07:43:36 --> Router Class Initialized
INFO - 2016-03-07 07:43:36 --> Output Class Initialized
INFO - 2016-03-07 07:43:36 --> Security Class Initialized
DEBUG - 2016-03-07 07:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:43:36 --> Input Class Initialized
INFO - 2016-03-07 07:43:36 --> Language Class Initialized
INFO - 2016-03-07 07:43:36 --> Loader Class Initialized
INFO - 2016-03-07 07:43:36 --> Helper loaded: url_helper
INFO - 2016-03-07 07:43:36 --> Helper loaded: file_helper
INFO - 2016-03-07 07:43:36 --> Helper loaded: date_helper
INFO - 2016-03-07 07:43:36 --> Helper loaded: form_helper
INFO - 2016-03-07 07:43:36 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:37 --> Controller Class Initialized
INFO - 2016-03-07 07:43:37 --> Model Class Initialized
INFO - 2016-03-07 07:43:37 --> Model Class Initialized
INFO - 2016-03-07 07:43:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:37 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:37 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:37 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:37 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:37 --> Upload Class Initialized
INFO - 2016-03-07 10:43:37 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:37 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:37 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:37 --> Total execution time: 1.1839
INFO - 2016-03-07 07:43:43 --> Config Class Initialized
INFO - 2016-03-07 07:43:43 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:43:43 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:43:43 --> Utf8 Class Initialized
INFO - 2016-03-07 07:43:43 --> URI Class Initialized
INFO - 2016-03-07 07:43:43 --> Router Class Initialized
INFO - 2016-03-07 07:43:43 --> Output Class Initialized
INFO - 2016-03-07 07:43:43 --> Security Class Initialized
DEBUG - 2016-03-07 07:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:43:43 --> Input Class Initialized
INFO - 2016-03-07 07:43:43 --> Language Class Initialized
INFO - 2016-03-07 07:43:43 --> Loader Class Initialized
INFO - 2016-03-07 07:43:43 --> Helper loaded: url_helper
INFO - 2016-03-07 07:43:43 --> Helper loaded: file_helper
INFO - 2016-03-07 07:43:43 --> Helper loaded: date_helper
INFO - 2016-03-07 07:43:43 --> Helper loaded: form_helper
INFO - 2016-03-07 07:43:43 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:44 --> Controller Class Initialized
INFO - 2016-03-07 07:43:44 --> Model Class Initialized
INFO - 2016-03-07 07:43:44 --> Model Class Initialized
INFO - 2016-03-07 07:43:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:44 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:44 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:44 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:44 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:44 --> Upload Class Initialized
INFO - 2016-03-07 10:43:44 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:44 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:44 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:44 --> Total execution time: 1.1493
INFO - 2016-03-07 07:43:50 --> Config Class Initialized
INFO - 2016-03-07 07:43:50 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:43:50 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:43:50 --> Utf8 Class Initialized
INFO - 2016-03-07 07:43:50 --> URI Class Initialized
INFO - 2016-03-07 07:43:50 --> Router Class Initialized
INFO - 2016-03-07 07:43:50 --> Output Class Initialized
INFO - 2016-03-07 07:43:50 --> Security Class Initialized
DEBUG - 2016-03-07 07:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:43:50 --> Input Class Initialized
INFO - 2016-03-07 07:43:50 --> Language Class Initialized
INFO - 2016-03-07 07:43:50 --> Loader Class Initialized
INFO - 2016-03-07 07:43:50 --> Helper loaded: url_helper
INFO - 2016-03-07 07:43:50 --> Helper loaded: file_helper
INFO - 2016-03-07 07:43:50 --> Helper loaded: date_helper
INFO - 2016-03-07 07:43:50 --> Helper loaded: form_helper
INFO - 2016-03-07 07:43:50 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:51 --> Controller Class Initialized
INFO - 2016-03-07 07:43:51 --> Model Class Initialized
INFO - 2016-03-07 07:43:51 --> Model Class Initialized
INFO - 2016-03-07 07:43:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:51 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:51 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:51 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:51 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:51 --> Upload Class Initialized
INFO - 2016-03-07 10:43:51 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:51 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:51 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:51 --> Total execution time: 1.2084
INFO - 2016-03-07 07:43:58 --> Config Class Initialized
INFO - 2016-03-07 07:43:58 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:43:58 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:43:58 --> Utf8 Class Initialized
INFO - 2016-03-07 07:43:58 --> URI Class Initialized
INFO - 2016-03-07 07:43:58 --> Router Class Initialized
INFO - 2016-03-07 07:43:58 --> Output Class Initialized
INFO - 2016-03-07 07:43:58 --> Security Class Initialized
DEBUG - 2016-03-07 07:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:43:58 --> Input Class Initialized
INFO - 2016-03-07 07:43:58 --> Language Class Initialized
INFO - 2016-03-07 07:43:58 --> Loader Class Initialized
INFO - 2016-03-07 07:43:58 --> Helper loaded: url_helper
INFO - 2016-03-07 07:43:58 --> Helper loaded: file_helper
INFO - 2016-03-07 07:43:58 --> Helper loaded: date_helper
INFO - 2016-03-07 07:43:58 --> Helper loaded: form_helper
INFO - 2016-03-07 07:43:58 --> Database Driver Class Initialized
INFO - 2016-03-07 07:43:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:43:59 --> Controller Class Initialized
INFO - 2016-03-07 07:43:59 --> Model Class Initialized
INFO - 2016-03-07 07:43:59 --> Model Class Initialized
INFO - 2016-03-07 07:43:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:43:59 --> Pagination Class Initialized
INFO - 2016-03-07 07:43:59 --> Helper loaded: text_helper
INFO - 2016-03-07 07:43:59 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:43:59 --> Form Validation Class Initialized
INFO - 2016-03-07 10:43:59 --> Upload Class Initialized
INFO - 2016-03-07 10:43:59 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:43:59 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:43:59 --> Final output sent to browser
DEBUG - 2016-03-07 10:43:59 --> Total execution time: 1.1580
INFO - 2016-03-07 07:44:05 --> Config Class Initialized
INFO - 2016-03-07 07:44:05 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:44:05 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:44:05 --> Utf8 Class Initialized
INFO - 2016-03-07 07:44:05 --> URI Class Initialized
INFO - 2016-03-07 07:44:05 --> Router Class Initialized
INFO - 2016-03-07 07:44:05 --> Output Class Initialized
INFO - 2016-03-07 07:44:05 --> Security Class Initialized
DEBUG - 2016-03-07 07:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:44:05 --> Input Class Initialized
INFO - 2016-03-07 07:44:05 --> Language Class Initialized
INFO - 2016-03-07 07:44:05 --> Loader Class Initialized
INFO - 2016-03-07 07:44:05 --> Helper loaded: url_helper
INFO - 2016-03-07 07:44:05 --> Helper loaded: file_helper
INFO - 2016-03-07 07:44:05 --> Helper loaded: date_helper
INFO - 2016-03-07 07:44:05 --> Helper loaded: form_helper
INFO - 2016-03-07 07:44:05 --> Database Driver Class Initialized
INFO - 2016-03-07 07:44:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:44:06 --> Controller Class Initialized
INFO - 2016-03-07 07:44:06 --> Model Class Initialized
INFO - 2016-03-07 07:44:06 --> Model Class Initialized
INFO - 2016-03-07 07:44:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:44:06 --> Pagination Class Initialized
INFO - 2016-03-07 07:44:06 --> Helper loaded: text_helper
INFO - 2016-03-07 07:44:06 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:44:06 --> Form Validation Class Initialized
INFO - 2016-03-07 10:44:06 --> Upload Class Initialized
INFO - 2016-03-07 10:44:06 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:44:06 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:44:06 --> Final output sent to browser
DEBUG - 2016-03-07 10:44:06 --> Total execution time: 1.1924
INFO - 2016-03-07 07:44:13 --> Config Class Initialized
INFO - 2016-03-07 07:44:13 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:44:13 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:44:13 --> Utf8 Class Initialized
INFO - 2016-03-07 07:44:13 --> URI Class Initialized
INFO - 2016-03-07 07:44:13 --> Router Class Initialized
INFO - 2016-03-07 07:44:13 --> Output Class Initialized
INFO - 2016-03-07 07:44:13 --> Security Class Initialized
DEBUG - 2016-03-07 07:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:44:13 --> Input Class Initialized
INFO - 2016-03-07 07:44:13 --> Language Class Initialized
INFO - 2016-03-07 07:44:13 --> Loader Class Initialized
INFO - 2016-03-07 07:44:13 --> Helper loaded: url_helper
INFO - 2016-03-07 07:44:13 --> Helper loaded: file_helper
INFO - 2016-03-07 07:44:13 --> Helper loaded: date_helper
INFO - 2016-03-07 07:44:13 --> Helper loaded: form_helper
INFO - 2016-03-07 07:44:13 --> Database Driver Class Initialized
INFO - 2016-03-07 07:44:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:44:15 --> Controller Class Initialized
INFO - 2016-03-07 07:44:15 --> Model Class Initialized
INFO - 2016-03-07 07:44:15 --> Model Class Initialized
INFO - 2016-03-07 07:44:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:44:15 --> Pagination Class Initialized
INFO - 2016-03-07 07:44:15 --> Helper loaded: text_helper
INFO - 2016-03-07 07:44:15 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:44:15 --> Form Validation Class Initialized
INFO - 2016-03-07 10:44:15 --> Upload Class Initialized
INFO - 2016-03-07 10:44:15 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:44:15 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:44:15 --> Final output sent to browser
DEBUG - 2016-03-07 10:44:15 --> Total execution time: 1.1937
INFO - 2016-03-07 07:44:21 --> Config Class Initialized
INFO - 2016-03-07 07:44:21 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:44:21 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:44:21 --> Utf8 Class Initialized
INFO - 2016-03-07 07:44:21 --> URI Class Initialized
INFO - 2016-03-07 07:44:21 --> Router Class Initialized
INFO - 2016-03-07 07:44:21 --> Output Class Initialized
INFO - 2016-03-07 07:44:21 --> Security Class Initialized
DEBUG - 2016-03-07 07:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:44:21 --> Input Class Initialized
INFO - 2016-03-07 07:44:21 --> Language Class Initialized
INFO - 2016-03-07 07:44:21 --> Loader Class Initialized
INFO - 2016-03-07 07:44:21 --> Helper loaded: url_helper
INFO - 2016-03-07 07:44:21 --> Helper loaded: file_helper
INFO - 2016-03-07 07:44:21 --> Helper loaded: date_helper
INFO - 2016-03-07 07:44:21 --> Helper loaded: form_helper
INFO - 2016-03-07 07:44:21 --> Database Driver Class Initialized
INFO - 2016-03-07 07:44:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:44:22 --> Controller Class Initialized
INFO - 2016-03-07 07:44:22 --> Model Class Initialized
INFO - 2016-03-07 07:44:22 --> Model Class Initialized
INFO - 2016-03-07 07:44:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:44:22 --> Pagination Class Initialized
INFO - 2016-03-07 07:44:22 --> Helper loaded: text_helper
INFO - 2016-03-07 07:44:22 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:44:22 --> Form Validation Class Initialized
INFO - 2016-03-07 10:44:22 --> Upload Class Initialized
INFO - 2016-03-07 10:44:22 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:44:22 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:44:22 --> Final output sent to browser
DEBUG - 2016-03-07 10:44:22 --> Total execution time: 1.2234
INFO - 2016-03-07 07:44:30 --> Config Class Initialized
INFO - 2016-03-07 07:44:30 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:44:30 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:44:30 --> Utf8 Class Initialized
INFO - 2016-03-07 07:44:30 --> URI Class Initialized
INFO - 2016-03-07 07:44:30 --> Router Class Initialized
INFO - 2016-03-07 07:44:30 --> Output Class Initialized
INFO - 2016-03-07 07:44:30 --> Security Class Initialized
DEBUG - 2016-03-07 07:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:44:30 --> Input Class Initialized
INFO - 2016-03-07 07:44:30 --> Language Class Initialized
INFO - 2016-03-07 07:44:30 --> Loader Class Initialized
INFO - 2016-03-07 07:44:30 --> Helper loaded: url_helper
INFO - 2016-03-07 07:44:30 --> Helper loaded: file_helper
INFO - 2016-03-07 07:44:30 --> Helper loaded: date_helper
INFO - 2016-03-07 07:44:30 --> Helper loaded: form_helper
INFO - 2016-03-07 07:44:30 --> Database Driver Class Initialized
INFO - 2016-03-07 07:44:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:44:31 --> Controller Class Initialized
INFO - 2016-03-07 07:44:31 --> Model Class Initialized
INFO - 2016-03-07 07:44:31 --> Model Class Initialized
INFO - 2016-03-07 07:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:44:31 --> Pagination Class Initialized
INFO - 2016-03-07 07:44:31 --> Helper loaded: text_helper
INFO - 2016-03-07 07:44:31 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:44:31 --> Form Validation Class Initialized
INFO - 2016-03-07 10:44:31 --> Upload Class Initialized
INFO - 2016-03-07 10:44:31 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:44:31 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:44:31 --> Final output sent to browser
DEBUG - 2016-03-07 10:44:31 --> Total execution time: 1.2137
INFO - 2016-03-07 07:44:37 --> Config Class Initialized
INFO - 2016-03-07 07:44:37 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:44:37 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:44:37 --> Utf8 Class Initialized
INFO - 2016-03-07 07:44:37 --> URI Class Initialized
INFO - 2016-03-07 07:44:37 --> Router Class Initialized
INFO - 2016-03-07 07:44:37 --> Output Class Initialized
INFO - 2016-03-07 07:44:37 --> Security Class Initialized
DEBUG - 2016-03-07 07:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:44:37 --> Input Class Initialized
INFO - 2016-03-07 07:44:37 --> Language Class Initialized
INFO - 2016-03-07 07:44:37 --> Loader Class Initialized
INFO - 2016-03-07 07:44:37 --> Helper loaded: url_helper
INFO - 2016-03-07 07:44:37 --> Helper loaded: file_helper
INFO - 2016-03-07 07:44:37 --> Helper loaded: date_helper
INFO - 2016-03-07 07:44:37 --> Helper loaded: form_helper
INFO - 2016-03-07 07:44:37 --> Database Driver Class Initialized
INFO - 2016-03-07 07:44:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:44:38 --> Controller Class Initialized
INFO - 2016-03-07 07:44:38 --> Model Class Initialized
INFO - 2016-03-07 07:44:38 --> Model Class Initialized
INFO - 2016-03-07 07:44:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:44:38 --> Pagination Class Initialized
INFO - 2016-03-07 07:44:38 --> Helper loaded: text_helper
INFO - 2016-03-07 07:44:38 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:44:38 --> Form Validation Class Initialized
INFO - 2016-03-07 10:44:38 --> Upload Class Initialized
INFO - 2016-03-07 10:44:38 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:44:38 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:44:38 --> Final output sent to browser
DEBUG - 2016-03-07 10:44:38 --> Total execution time: 1.1592
INFO - 2016-03-07 07:44:44 --> Config Class Initialized
INFO - 2016-03-07 07:44:44 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:44:44 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:44:44 --> Utf8 Class Initialized
INFO - 2016-03-07 07:44:44 --> URI Class Initialized
INFO - 2016-03-07 07:44:44 --> Router Class Initialized
INFO - 2016-03-07 07:44:44 --> Output Class Initialized
INFO - 2016-03-07 07:44:44 --> Security Class Initialized
DEBUG - 2016-03-07 07:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:44:44 --> Input Class Initialized
INFO - 2016-03-07 07:44:44 --> Language Class Initialized
INFO - 2016-03-07 07:44:44 --> Loader Class Initialized
INFO - 2016-03-07 07:44:44 --> Helper loaded: url_helper
INFO - 2016-03-07 07:44:44 --> Helper loaded: file_helper
INFO - 2016-03-07 07:44:44 --> Helper loaded: date_helper
INFO - 2016-03-07 07:44:44 --> Helper loaded: form_helper
INFO - 2016-03-07 07:44:44 --> Database Driver Class Initialized
INFO - 2016-03-07 07:44:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:44:45 --> Controller Class Initialized
INFO - 2016-03-07 07:44:45 --> Model Class Initialized
INFO - 2016-03-07 07:44:45 --> Model Class Initialized
INFO - 2016-03-07 07:44:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:44:45 --> Pagination Class Initialized
INFO - 2016-03-07 07:44:45 --> Helper loaded: text_helper
INFO - 2016-03-07 07:44:45 --> Helper loaded: cookie_helper
INFO - 2016-03-07 07:44:45 --> Form Validation Class Initialized
INFO - 2016-03-07 10:44:45 --> Upload Class Initialized
INFO - 2016-03-07 10:44:45 --> Image Lib Class Initialized
DEBUG - 2016-03-07 10:44:45 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-07 10:44:45 --> Final output sent to browser
DEBUG - 2016-03-07 10:44:45 --> Total execution time: 1.1662
INFO - 2016-03-07 07:45:43 --> Config Class Initialized
INFO - 2016-03-07 07:45:43 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:45:43 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:45:43 --> Utf8 Class Initialized
INFO - 2016-03-07 07:45:43 --> URI Class Initialized
INFO - 2016-03-07 07:45:43 --> Router Class Initialized
INFO - 2016-03-07 07:45:43 --> Output Class Initialized
INFO - 2016-03-07 07:45:43 --> Security Class Initialized
DEBUG - 2016-03-07 07:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:45:43 --> Input Class Initialized
INFO - 2016-03-07 07:45:43 --> Language Class Initialized
INFO - 2016-03-07 07:45:44 --> Loader Class Initialized
INFO - 2016-03-07 07:45:44 --> Helper loaded: url_helper
INFO - 2016-03-07 07:45:44 --> Helper loaded: file_helper
INFO - 2016-03-07 07:45:44 --> Helper loaded: date_helper
INFO - 2016-03-07 07:45:44 --> Helper loaded: form_helper
INFO - 2016-03-07 07:45:44 --> Database Driver Class Initialized
INFO - 2016-03-07 07:45:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:45:45 --> Controller Class Initialized
INFO - 2016-03-07 07:45:45 --> Model Class Initialized
INFO - 2016-03-07 07:45:45 --> Model Class Initialized
INFO - 2016-03-07 07:45:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:45:45 --> Pagination Class Initialized
INFO - 2016-03-07 07:45:45 --> Helper loaded: text_helper
INFO - 2016-03-07 07:45:45 --> Helper loaded: cookie_helper
ERROR - 2016-03-07 10:45:45 --> Severity: Warning --> Missing argument 1 for Car::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\car.php 181
INFO - 2016-03-07 10:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:45:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:45:45 --> Form Validation Class Initialized
INFO - 2016-03-07 10:45:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-07 07:45:45 --> Config Class Initialized
INFO - 2016-03-07 07:45:45 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:45:45 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:45:45 --> Utf8 Class Initialized
INFO - 2016-03-07 07:45:45 --> URI Class Initialized
INFO - 2016-03-07 07:45:45 --> Router Class Initialized
INFO - 2016-03-07 07:45:45 --> Output Class Initialized
INFO - 2016-03-07 07:45:45 --> Security Class Initialized
DEBUG - 2016-03-07 07:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:45:45 --> Input Class Initialized
INFO - 2016-03-07 07:45:45 --> Language Class Initialized
INFO - 2016-03-07 07:45:45 --> Loader Class Initialized
INFO - 2016-03-07 07:45:45 --> Helper loaded: url_helper
INFO - 2016-03-07 07:45:45 --> Helper loaded: file_helper
INFO - 2016-03-07 07:45:45 --> Helper loaded: date_helper
INFO - 2016-03-07 07:45:45 --> Helper loaded: form_helper
INFO - 2016-03-07 07:45:45 --> Database Driver Class Initialized
INFO - 2016-03-07 07:45:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:45:46 --> Controller Class Initialized
INFO - 2016-03-07 07:45:46 --> Model Class Initialized
INFO - 2016-03-07 07:45:46 --> Model Class Initialized
INFO - 2016-03-07 07:45:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:45:46 --> Pagination Class Initialized
INFO - 2016-03-07 07:45:46 --> Helper loaded: text_helper
INFO - 2016-03-07 07:45:46 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 10:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:45:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:45:46 --> Final output sent to browser
DEBUG - 2016-03-07 10:45:46 --> Total execution time: 1.2202
INFO - 2016-03-07 07:46:01 --> Config Class Initialized
INFO - 2016-03-07 07:46:01 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:46:01 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:46:01 --> Utf8 Class Initialized
INFO - 2016-03-07 07:46:01 --> URI Class Initialized
INFO - 2016-03-07 07:46:01 --> Router Class Initialized
INFO - 2016-03-07 07:46:01 --> Output Class Initialized
INFO - 2016-03-07 07:46:01 --> Security Class Initialized
DEBUG - 2016-03-07 07:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:46:01 --> Input Class Initialized
INFO - 2016-03-07 07:46:02 --> Language Class Initialized
INFO - 2016-03-07 07:46:02 --> Loader Class Initialized
INFO - 2016-03-07 07:46:02 --> Helper loaded: url_helper
INFO - 2016-03-07 07:46:02 --> Helper loaded: file_helper
INFO - 2016-03-07 07:46:02 --> Helper loaded: date_helper
INFO - 2016-03-07 07:46:02 --> Helper loaded: form_helper
INFO - 2016-03-07 07:46:02 --> Database Driver Class Initialized
INFO - 2016-03-07 07:46:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:46:03 --> Controller Class Initialized
INFO - 2016-03-07 07:46:03 --> Model Class Initialized
INFO - 2016-03-07 07:46:03 --> Model Class Initialized
INFO - 2016-03-07 07:46:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:46:03 --> Pagination Class Initialized
INFO - 2016-03-07 07:46:03 --> Helper loaded: text_helper
INFO - 2016-03-07 07:46:03 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 10:46:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:46:03 --> Final output sent to browser
DEBUG - 2016-03-07 10:46:03 --> Total execution time: 1.1444
INFO - 2016-03-07 07:47:07 --> Config Class Initialized
INFO - 2016-03-07 07:47:07 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:47:07 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:47:07 --> Utf8 Class Initialized
INFO - 2016-03-07 07:47:07 --> URI Class Initialized
DEBUG - 2016-03-07 07:47:07 --> No URI present. Default controller set.
INFO - 2016-03-07 07:47:07 --> Router Class Initialized
INFO - 2016-03-07 07:47:07 --> Output Class Initialized
INFO - 2016-03-07 07:47:07 --> Security Class Initialized
DEBUG - 2016-03-07 07:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:47:07 --> Input Class Initialized
INFO - 2016-03-07 07:47:07 --> Language Class Initialized
INFO - 2016-03-07 07:47:07 --> Loader Class Initialized
INFO - 2016-03-07 07:47:07 --> Helper loaded: url_helper
INFO - 2016-03-07 07:47:07 --> Helper loaded: file_helper
INFO - 2016-03-07 07:47:07 --> Helper loaded: date_helper
INFO - 2016-03-07 07:47:07 --> Helper loaded: form_helper
INFO - 2016-03-07 07:47:07 --> Database Driver Class Initialized
INFO - 2016-03-07 07:47:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:47:08 --> Controller Class Initialized
INFO - 2016-03-07 07:47:08 --> Model Class Initialized
INFO - 2016-03-07 07:47:08 --> Model Class Initialized
INFO - 2016-03-07 07:47:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:47:08 --> Pagination Class Initialized
INFO - 2016-03-07 07:47:08 --> Helper loaded: text_helper
INFO - 2016-03-07 07:47:08 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:47:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:47:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:47:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 10:47:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:47:08 --> Final output sent to browser
DEBUG - 2016-03-07 10:47:08 --> Total execution time: 1.1284
INFO - 2016-03-07 07:47:16 --> Config Class Initialized
INFO - 2016-03-07 07:47:16 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:47:16 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:47:16 --> Utf8 Class Initialized
INFO - 2016-03-07 07:47:16 --> URI Class Initialized
INFO - 2016-03-07 07:47:16 --> Router Class Initialized
INFO - 2016-03-07 07:47:16 --> Output Class Initialized
INFO - 2016-03-07 07:47:16 --> Security Class Initialized
DEBUG - 2016-03-07 07:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:47:16 --> Input Class Initialized
INFO - 2016-03-07 07:47:16 --> Language Class Initialized
INFO - 2016-03-07 07:47:16 --> Loader Class Initialized
INFO - 2016-03-07 07:47:16 --> Helper loaded: url_helper
INFO - 2016-03-07 07:47:16 --> Helper loaded: file_helper
INFO - 2016-03-07 07:47:16 --> Helper loaded: date_helper
INFO - 2016-03-07 07:47:16 --> Helper loaded: form_helper
INFO - 2016-03-07 07:47:16 --> Database Driver Class Initialized
INFO - 2016-03-07 07:47:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:47:17 --> Controller Class Initialized
INFO - 2016-03-07 07:47:17 --> Model Class Initialized
INFO - 2016-03-07 07:47:17 --> Model Class Initialized
INFO - 2016-03-07 07:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:47:17 --> Pagination Class Initialized
INFO - 2016-03-07 07:47:17 --> Helper loaded: text_helper
INFO - 2016-03-07 07:47:17 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 10:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 10:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:47:17 --> Final output sent to browser
DEBUG - 2016-03-07 10:47:17 --> Total execution time: 1.2197
INFO - 2016-03-07 07:47:27 --> Config Class Initialized
INFO - 2016-03-07 07:47:27 --> Hooks Class Initialized
DEBUG - 2016-03-07 07:47:27 --> UTF-8 Support Enabled
INFO - 2016-03-07 07:47:27 --> Utf8 Class Initialized
INFO - 2016-03-07 07:47:27 --> URI Class Initialized
INFO - 2016-03-07 07:47:27 --> Router Class Initialized
INFO - 2016-03-07 07:47:27 --> Output Class Initialized
INFO - 2016-03-07 07:47:27 --> Security Class Initialized
DEBUG - 2016-03-07 07:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 07:47:27 --> Input Class Initialized
INFO - 2016-03-07 07:47:27 --> Language Class Initialized
INFO - 2016-03-07 07:47:27 --> Loader Class Initialized
INFO - 2016-03-07 07:47:27 --> Helper loaded: url_helper
INFO - 2016-03-07 07:47:27 --> Helper loaded: file_helper
INFO - 2016-03-07 07:47:27 --> Helper loaded: date_helper
INFO - 2016-03-07 07:47:27 --> Helper loaded: form_helper
INFO - 2016-03-07 07:47:27 --> Database Driver Class Initialized
INFO - 2016-03-07 07:47:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 07:47:28 --> Controller Class Initialized
INFO - 2016-03-07 07:47:28 --> Model Class Initialized
INFO - 2016-03-07 07:47:28 --> Model Class Initialized
INFO - 2016-03-07 07:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 07:47:28 --> Pagination Class Initialized
INFO - 2016-03-07 07:47:28 --> Helper loaded: text_helper
INFO - 2016-03-07 07:47:28 --> Helper loaded: cookie_helper
INFO - 2016-03-07 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 10:47:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 10:47:28 --> Final output sent to browser
DEBUG - 2016-03-07 10:47:28 --> Total execution time: 1.1613
INFO - 2016-03-07 08:20:32 --> Config Class Initialized
INFO - 2016-03-07 08:20:32 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:20:32 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:20:32 --> Utf8 Class Initialized
INFO - 2016-03-07 08:20:32 --> URI Class Initialized
INFO - 2016-03-07 08:20:32 --> Router Class Initialized
INFO - 2016-03-07 08:20:32 --> Output Class Initialized
INFO - 2016-03-07 08:20:32 --> Security Class Initialized
DEBUG - 2016-03-07 08:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:20:32 --> Input Class Initialized
INFO - 2016-03-07 08:20:32 --> Language Class Initialized
INFO - 2016-03-07 08:20:32 --> Loader Class Initialized
INFO - 2016-03-07 08:20:32 --> Helper loaded: url_helper
INFO - 2016-03-07 08:20:32 --> Helper loaded: file_helper
INFO - 2016-03-07 08:20:32 --> Helper loaded: date_helper
INFO - 2016-03-07 08:20:32 --> Helper loaded: form_helper
INFO - 2016-03-07 08:20:32 --> Database Driver Class Initialized
INFO - 2016-03-07 08:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:20:33 --> Controller Class Initialized
INFO - 2016-03-07 08:20:33 --> Model Class Initialized
INFO - 2016-03-07 08:20:33 --> Model Class Initialized
INFO - 2016-03-07 08:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:20:33 --> Pagination Class Initialized
INFO - 2016-03-07 08:20:34 --> Helper loaded: text_helper
INFO - 2016-03-07 08:20:34 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:20:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:20:34 --> Final output sent to browser
DEBUG - 2016-03-07 11:20:34 --> Total execution time: 1.2095
INFO - 2016-03-07 08:20:57 --> Config Class Initialized
INFO - 2016-03-07 08:20:57 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:20:57 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:20:57 --> Utf8 Class Initialized
INFO - 2016-03-07 08:20:57 --> URI Class Initialized
INFO - 2016-03-07 08:20:57 --> Router Class Initialized
INFO - 2016-03-07 08:20:57 --> Output Class Initialized
INFO - 2016-03-07 08:20:57 --> Security Class Initialized
DEBUG - 2016-03-07 08:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:20:57 --> Input Class Initialized
INFO - 2016-03-07 08:20:57 --> Language Class Initialized
INFO - 2016-03-07 08:20:57 --> Loader Class Initialized
INFO - 2016-03-07 08:20:57 --> Helper loaded: url_helper
INFO - 2016-03-07 08:20:57 --> Helper loaded: file_helper
INFO - 2016-03-07 08:20:57 --> Helper loaded: date_helper
INFO - 2016-03-07 08:20:57 --> Helper loaded: form_helper
INFO - 2016-03-07 08:20:57 --> Database Driver Class Initialized
INFO - 2016-03-07 08:20:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:20:59 --> Controller Class Initialized
INFO - 2016-03-07 08:20:59 --> Model Class Initialized
INFO - 2016-03-07 08:20:59 --> Model Class Initialized
INFO - 2016-03-07 08:20:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:20:59 --> Pagination Class Initialized
INFO - 2016-03-07 08:20:59 --> Helper loaded: text_helper
INFO - 2016-03-07 08:20:59 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:20:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:20:59 --> Final output sent to browser
DEBUG - 2016-03-07 11:20:59 --> Total execution time: 1.1632
INFO - 2016-03-07 08:21:03 --> Config Class Initialized
INFO - 2016-03-07 08:21:03 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:21:03 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:21:03 --> Utf8 Class Initialized
INFO - 2016-03-07 08:21:03 --> URI Class Initialized
INFO - 2016-03-07 08:21:03 --> Router Class Initialized
INFO - 2016-03-07 08:21:03 --> Output Class Initialized
INFO - 2016-03-07 08:21:03 --> Security Class Initialized
DEBUG - 2016-03-07 08:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:21:03 --> Input Class Initialized
INFO - 2016-03-07 08:21:03 --> Language Class Initialized
INFO - 2016-03-07 08:21:03 --> Loader Class Initialized
INFO - 2016-03-07 08:21:03 --> Helper loaded: url_helper
INFO - 2016-03-07 08:21:03 --> Helper loaded: file_helper
INFO - 2016-03-07 08:21:03 --> Helper loaded: date_helper
INFO - 2016-03-07 08:21:03 --> Helper loaded: form_helper
INFO - 2016-03-07 08:21:03 --> Database Driver Class Initialized
INFO - 2016-03-07 08:21:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:21:04 --> Controller Class Initialized
INFO - 2016-03-07 08:21:04 --> Model Class Initialized
INFO - 2016-03-07 08:21:04 --> Model Class Initialized
INFO - 2016-03-07 08:21:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:21:04 --> Pagination Class Initialized
INFO - 2016-03-07 08:21:04 --> Helper loaded: text_helper
INFO - 2016-03-07 08:21:04 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:21:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:21:04 --> Final output sent to browser
DEBUG - 2016-03-07 11:21:04 --> Total execution time: 1.1630
INFO - 2016-03-07 08:21:06 --> Config Class Initialized
INFO - 2016-03-07 08:21:06 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:21:06 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:21:06 --> Utf8 Class Initialized
INFO - 2016-03-07 08:21:06 --> URI Class Initialized
INFO - 2016-03-07 08:21:06 --> Router Class Initialized
INFO - 2016-03-07 08:21:06 --> Output Class Initialized
INFO - 2016-03-07 08:21:06 --> Security Class Initialized
DEBUG - 2016-03-07 08:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:21:06 --> Input Class Initialized
INFO - 2016-03-07 08:21:06 --> Language Class Initialized
INFO - 2016-03-07 08:21:06 --> Loader Class Initialized
INFO - 2016-03-07 08:21:06 --> Helper loaded: url_helper
INFO - 2016-03-07 08:21:06 --> Helper loaded: file_helper
INFO - 2016-03-07 08:21:06 --> Helper loaded: date_helper
INFO - 2016-03-07 08:21:06 --> Helper loaded: form_helper
INFO - 2016-03-07 08:21:06 --> Database Driver Class Initialized
INFO - 2016-03-07 08:21:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:21:07 --> Controller Class Initialized
INFO - 2016-03-07 08:21:07 --> Model Class Initialized
INFO - 2016-03-07 08:21:07 --> Model Class Initialized
INFO - 2016-03-07 08:21:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:21:07 --> Pagination Class Initialized
INFO - 2016-03-07 08:21:07 --> Helper loaded: text_helper
INFO - 2016-03-07 08:21:07 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:21:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:21:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:21:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:21:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:21:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:21:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:21:07 --> Final output sent to browser
DEBUG - 2016-03-07 11:21:07 --> Total execution time: 1.1399
INFO - 2016-03-07 08:21:16 --> Config Class Initialized
INFO - 2016-03-07 08:21:16 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:21:16 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:21:16 --> Utf8 Class Initialized
INFO - 2016-03-07 08:21:16 --> URI Class Initialized
INFO - 2016-03-07 08:21:16 --> Router Class Initialized
INFO - 2016-03-07 08:21:16 --> Output Class Initialized
INFO - 2016-03-07 08:21:16 --> Security Class Initialized
DEBUG - 2016-03-07 08:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:21:16 --> Input Class Initialized
INFO - 2016-03-07 08:21:16 --> Language Class Initialized
INFO - 2016-03-07 08:21:16 --> Loader Class Initialized
INFO - 2016-03-07 08:21:16 --> Helper loaded: url_helper
INFO - 2016-03-07 08:21:16 --> Helper loaded: file_helper
INFO - 2016-03-07 08:21:16 --> Helper loaded: date_helper
INFO - 2016-03-07 08:21:16 --> Helper loaded: form_helper
INFO - 2016-03-07 08:21:16 --> Database Driver Class Initialized
INFO - 2016-03-07 08:21:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:21:17 --> Controller Class Initialized
INFO - 2016-03-07 08:21:17 --> Model Class Initialized
INFO - 2016-03-07 08:21:17 --> Model Class Initialized
INFO - 2016-03-07 08:21:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:21:17 --> Pagination Class Initialized
INFO - 2016-03-07 08:21:17 --> Helper loaded: text_helper
INFO - 2016-03-07 08:21:17 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:21:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:21:17 --> Final output sent to browser
DEBUG - 2016-03-07 11:21:17 --> Total execution time: 1.1881
INFO - 2016-03-07 08:21:20 --> Config Class Initialized
INFO - 2016-03-07 08:21:20 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:21:20 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:21:20 --> Utf8 Class Initialized
INFO - 2016-03-07 08:21:20 --> URI Class Initialized
INFO - 2016-03-07 08:21:20 --> Router Class Initialized
INFO - 2016-03-07 08:21:20 --> Output Class Initialized
INFO - 2016-03-07 08:21:20 --> Security Class Initialized
DEBUG - 2016-03-07 08:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:21:20 --> Input Class Initialized
INFO - 2016-03-07 08:21:20 --> Language Class Initialized
INFO - 2016-03-07 08:21:20 --> Loader Class Initialized
INFO - 2016-03-07 08:21:20 --> Helper loaded: url_helper
INFO - 2016-03-07 08:21:20 --> Helper loaded: file_helper
INFO - 2016-03-07 08:21:20 --> Helper loaded: date_helper
INFO - 2016-03-07 08:21:20 --> Helper loaded: form_helper
INFO - 2016-03-07 08:21:20 --> Database Driver Class Initialized
INFO - 2016-03-07 08:21:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:21:21 --> Controller Class Initialized
INFO - 2016-03-07 08:21:21 --> Model Class Initialized
INFO - 2016-03-07 08:21:21 --> Model Class Initialized
INFO - 2016-03-07 08:21:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:21:21 --> Pagination Class Initialized
INFO - 2016-03-07 08:21:21 --> Helper loaded: text_helper
INFO - 2016-03-07 08:21:21 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 11:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 11:21:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:21:21 --> Final output sent to browser
DEBUG - 2016-03-07 11:21:21 --> Total execution time: 1.2014
INFO - 2016-03-07 08:21:57 --> Config Class Initialized
INFO - 2016-03-07 08:21:57 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:21:57 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:21:57 --> Utf8 Class Initialized
INFO - 2016-03-07 08:21:57 --> URI Class Initialized
INFO - 2016-03-07 08:21:57 --> Router Class Initialized
INFO - 2016-03-07 08:21:57 --> Output Class Initialized
INFO - 2016-03-07 08:21:57 --> Security Class Initialized
DEBUG - 2016-03-07 08:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:21:57 --> Input Class Initialized
INFO - 2016-03-07 08:21:57 --> Language Class Initialized
INFO - 2016-03-07 08:21:57 --> Loader Class Initialized
INFO - 2016-03-07 08:21:57 --> Helper loaded: url_helper
INFO - 2016-03-07 08:21:57 --> Helper loaded: file_helper
INFO - 2016-03-07 08:21:57 --> Helper loaded: date_helper
INFO - 2016-03-07 08:21:57 --> Helper loaded: form_helper
INFO - 2016-03-07 08:21:57 --> Database Driver Class Initialized
INFO - 2016-03-07 08:21:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:21:58 --> Controller Class Initialized
INFO - 2016-03-07 08:21:58 --> User Agent Class Initialized
INFO - 2016-03-07 08:21:58 --> Final output sent to browser
DEBUG - 2016-03-07 08:21:58 --> Total execution time: 1.0866
INFO - 2016-03-07 08:31:36 --> Config Class Initialized
INFO - 2016-03-07 08:31:36 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:31:36 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:31:36 --> Utf8 Class Initialized
INFO - 2016-03-07 08:31:36 --> URI Class Initialized
INFO - 2016-03-07 08:31:36 --> Router Class Initialized
INFO - 2016-03-07 08:31:36 --> Output Class Initialized
INFO - 2016-03-07 08:31:36 --> Security Class Initialized
DEBUG - 2016-03-07 08:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:31:36 --> Input Class Initialized
INFO - 2016-03-07 08:31:36 --> Language Class Initialized
INFO - 2016-03-07 08:31:36 --> Loader Class Initialized
INFO - 2016-03-07 08:31:36 --> Helper loaded: url_helper
INFO - 2016-03-07 08:31:36 --> Helper loaded: file_helper
INFO - 2016-03-07 08:31:36 --> Helper loaded: date_helper
INFO - 2016-03-07 08:31:36 --> Helper loaded: form_helper
INFO - 2016-03-07 08:31:36 --> Database Driver Class Initialized
INFO - 2016-03-07 08:31:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:31:37 --> Controller Class Initialized
INFO - 2016-03-07 08:31:38 --> Model Class Initialized
INFO - 2016-03-07 08:31:38 --> Model Class Initialized
INFO - 2016-03-07 08:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:31:38 --> Pagination Class Initialized
INFO - 2016-03-07 08:31:38 --> Helper loaded: text_helper
INFO - 2016-03-07 08:31:38 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:31:38 --> Final output sent to browser
DEBUG - 2016-03-07 11:31:38 --> Total execution time: 1.1779
INFO - 2016-03-07 08:31:39 --> Config Class Initialized
INFO - 2016-03-07 08:31:39 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:31:39 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:31:39 --> Utf8 Class Initialized
INFO - 2016-03-07 08:31:39 --> URI Class Initialized
INFO - 2016-03-07 08:31:39 --> Router Class Initialized
INFO - 2016-03-07 08:31:39 --> Output Class Initialized
INFO - 2016-03-07 08:31:39 --> Security Class Initialized
DEBUG - 2016-03-07 08:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:31:39 --> Input Class Initialized
INFO - 2016-03-07 08:31:39 --> Language Class Initialized
INFO - 2016-03-07 08:31:39 --> Loader Class Initialized
INFO - 2016-03-07 08:31:39 --> Helper loaded: url_helper
INFO - 2016-03-07 08:31:39 --> Helper loaded: file_helper
INFO - 2016-03-07 08:31:39 --> Helper loaded: date_helper
INFO - 2016-03-07 08:31:39 --> Helper loaded: form_helper
INFO - 2016-03-07 08:31:39 --> Database Driver Class Initialized
INFO - 2016-03-07 08:31:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:31:40 --> Controller Class Initialized
INFO - 2016-03-07 08:31:40 --> Model Class Initialized
INFO - 2016-03-07 08:31:40 --> Model Class Initialized
INFO - 2016-03-07 08:31:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:31:40 --> Pagination Class Initialized
INFO - 2016-03-07 08:31:40 --> Helper loaded: text_helper
INFO - 2016-03-07 08:31:40 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 11:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 11:31:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:31:40 --> Final output sent to browser
DEBUG - 2016-03-07 11:31:40 --> Total execution time: 1.1997
INFO - 2016-03-07 08:31:42 --> Config Class Initialized
INFO - 2016-03-07 08:31:42 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:31:42 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:31:42 --> Utf8 Class Initialized
INFO - 2016-03-07 08:31:42 --> URI Class Initialized
INFO - 2016-03-07 08:31:42 --> Router Class Initialized
INFO - 2016-03-07 08:31:42 --> Output Class Initialized
INFO - 2016-03-07 08:31:42 --> Security Class Initialized
DEBUG - 2016-03-07 08:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:31:42 --> Input Class Initialized
INFO - 2016-03-07 08:31:42 --> Language Class Initialized
INFO - 2016-03-07 08:31:42 --> Loader Class Initialized
INFO - 2016-03-07 08:31:42 --> Helper loaded: url_helper
INFO - 2016-03-07 08:31:42 --> Helper loaded: file_helper
INFO - 2016-03-07 08:31:42 --> Helper loaded: date_helper
INFO - 2016-03-07 08:31:42 --> Helper loaded: form_helper
INFO - 2016-03-07 08:31:42 --> Database Driver Class Initialized
INFO - 2016-03-07 08:31:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:31:43 --> Controller Class Initialized
INFO - 2016-03-07 08:31:43 --> Model Class Initialized
INFO - 2016-03-07 08:31:43 --> Model Class Initialized
INFO - 2016-03-07 08:31:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:31:43 --> Pagination Class Initialized
INFO - 2016-03-07 08:31:43 --> Helper loaded: text_helper
INFO - 2016-03-07 08:31:43 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:31:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:31:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:31:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:31:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:31:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:31:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:31:43 --> Final output sent to browser
DEBUG - 2016-03-07 11:31:43 --> Total execution time: 1.1509
INFO - 2016-03-07 08:34:41 --> Config Class Initialized
INFO - 2016-03-07 08:34:41 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:34:41 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:34:41 --> Utf8 Class Initialized
INFO - 2016-03-07 08:34:41 --> URI Class Initialized
INFO - 2016-03-07 08:34:41 --> Router Class Initialized
INFO - 2016-03-07 08:34:41 --> Output Class Initialized
INFO - 2016-03-07 08:34:41 --> Security Class Initialized
DEBUG - 2016-03-07 08:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:34:41 --> Input Class Initialized
INFO - 2016-03-07 08:34:41 --> Language Class Initialized
INFO - 2016-03-07 08:34:41 --> Loader Class Initialized
INFO - 2016-03-07 08:34:41 --> Helper loaded: url_helper
INFO - 2016-03-07 08:34:41 --> Helper loaded: file_helper
INFO - 2016-03-07 08:34:41 --> Helper loaded: date_helper
INFO - 2016-03-07 08:34:41 --> Helper loaded: form_helper
INFO - 2016-03-07 08:34:41 --> Database Driver Class Initialized
INFO - 2016-03-07 08:34:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:34:42 --> Controller Class Initialized
INFO - 2016-03-07 08:34:42 --> Model Class Initialized
INFO - 2016-03-07 08:34:42 --> Model Class Initialized
INFO - 2016-03-07 08:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:34:42 --> Pagination Class Initialized
INFO - 2016-03-07 08:34:42 --> Helper loaded: text_helper
INFO - 2016-03-07 08:34:42 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:34:42 --> Final output sent to browser
DEBUG - 2016-03-07 11:34:42 --> Total execution time: 1.2546
INFO - 2016-03-07 08:38:39 --> Config Class Initialized
INFO - 2016-03-07 08:38:39 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:38:39 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:38:39 --> Utf8 Class Initialized
INFO - 2016-03-07 08:38:39 --> URI Class Initialized
INFO - 2016-03-07 08:38:39 --> Router Class Initialized
INFO - 2016-03-07 08:38:39 --> Output Class Initialized
INFO - 2016-03-07 08:38:39 --> Security Class Initialized
DEBUG - 2016-03-07 08:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:38:39 --> Input Class Initialized
INFO - 2016-03-07 08:38:39 --> Language Class Initialized
INFO - 2016-03-07 08:38:39 --> Loader Class Initialized
INFO - 2016-03-07 08:38:39 --> Helper loaded: url_helper
INFO - 2016-03-07 08:38:39 --> Helper loaded: file_helper
INFO - 2016-03-07 08:38:39 --> Helper loaded: date_helper
INFO - 2016-03-07 08:38:39 --> Helper loaded: form_helper
INFO - 2016-03-07 08:38:39 --> Database Driver Class Initialized
INFO - 2016-03-07 08:38:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:38:40 --> Controller Class Initialized
INFO - 2016-03-07 08:38:40 --> Model Class Initialized
INFO - 2016-03-07 08:38:40 --> Model Class Initialized
INFO - 2016-03-07 08:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:38:40 --> Pagination Class Initialized
INFO - 2016-03-07 08:38:40 --> Helper loaded: text_helper
INFO - 2016-03-07 08:38:40 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:38:40 --> Final output sent to browser
DEBUG - 2016-03-07 11:38:40 --> Total execution time: 1.1605
INFO - 2016-03-07 08:40:51 --> Config Class Initialized
INFO - 2016-03-07 08:40:51 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:40:51 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:40:51 --> Utf8 Class Initialized
INFO - 2016-03-07 08:40:51 --> URI Class Initialized
INFO - 2016-03-07 08:40:51 --> Router Class Initialized
INFO - 2016-03-07 08:40:51 --> Output Class Initialized
INFO - 2016-03-07 08:40:51 --> Security Class Initialized
DEBUG - 2016-03-07 08:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:40:51 --> Input Class Initialized
INFO - 2016-03-07 08:40:51 --> Language Class Initialized
INFO - 2016-03-07 08:40:51 --> Loader Class Initialized
INFO - 2016-03-07 08:40:51 --> Helper loaded: url_helper
INFO - 2016-03-07 08:40:51 --> Helper loaded: file_helper
INFO - 2016-03-07 08:40:51 --> Helper loaded: date_helper
INFO - 2016-03-07 08:40:51 --> Helper loaded: form_helper
INFO - 2016-03-07 08:40:51 --> Database Driver Class Initialized
INFO - 2016-03-07 08:40:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:40:52 --> Controller Class Initialized
INFO - 2016-03-07 08:40:52 --> Model Class Initialized
INFO - 2016-03-07 08:40:52 --> Model Class Initialized
INFO - 2016-03-07 08:40:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:40:52 --> Pagination Class Initialized
INFO - 2016-03-07 08:40:52 --> Helper loaded: text_helper
INFO - 2016-03-07 08:40:52 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:40:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:40:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:40:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:40:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:40:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:40:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:40:52 --> Final output sent to browser
DEBUG - 2016-03-07 11:40:52 --> Total execution time: 1.1380
INFO - 2016-03-07 08:41:15 --> Config Class Initialized
INFO - 2016-03-07 08:41:15 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:41:15 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:41:15 --> Utf8 Class Initialized
INFO - 2016-03-07 08:41:15 --> URI Class Initialized
INFO - 2016-03-07 08:41:15 --> Router Class Initialized
INFO - 2016-03-07 08:41:15 --> Output Class Initialized
INFO - 2016-03-07 08:41:15 --> Security Class Initialized
DEBUG - 2016-03-07 08:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:41:15 --> Input Class Initialized
INFO - 2016-03-07 08:41:15 --> Language Class Initialized
INFO - 2016-03-07 08:41:15 --> Loader Class Initialized
INFO - 2016-03-07 08:41:15 --> Helper loaded: url_helper
INFO - 2016-03-07 08:41:15 --> Helper loaded: file_helper
INFO - 2016-03-07 08:41:15 --> Helper loaded: date_helper
INFO - 2016-03-07 08:41:15 --> Helper loaded: form_helper
INFO - 2016-03-07 08:41:15 --> Database Driver Class Initialized
INFO - 2016-03-07 08:41:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:41:16 --> Controller Class Initialized
INFO - 2016-03-07 08:41:16 --> Model Class Initialized
INFO - 2016-03-07 08:41:16 --> Model Class Initialized
INFO - 2016-03-07 08:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:41:16 --> Pagination Class Initialized
INFO - 2016-03-07 08:41:16 --> Helper loaded: text_helper
INFO - 2016-03-07 08:41:16 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:41:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:41:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:41:17 --> Final output sent to browser
DEBUG - 2016-03-07 11:41:17 --> Total execution time: 1.2334
INFO - 2016-03-07 08:41:29 --> Config Class Initialized
INFO - 2016-03-07 08:41:29 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:41:29 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:41:29 --> Utf8 Class Initialized
INFO - 2016-03-07 08:41:29 --> URI Class Initialized
INFO - 2016-03-07 08:41:29 --> Router Class Initialized
INFO - 2016-03-07 08:41:29 --> Output Class Initialized
INFO - 2016-03-07 08:41:29 --> Security Class Initialized
DEBUG - 2016-03-07 08:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:41:29 --> Input Class Initialized
INFO - 2016-03-07 08:41:29 --> Language Class Initialized
INFO - 2016-03-07 08:41:29 --> Loader Class Initialized
INFO - 2016-03-07 08:41:29 --> Helper loaded: url_helper
INFO - 2016-03-07 08:41:29 --> Helper loaded: file_helper
INFO - 2016-03-07 08:41:29 --> Helper loaded: date_helper
INFO - 2016-03-07 08:41:29 --> Helper loaded: form_helper
INFO - 2016-03-07 08:41:29 --> Database Driver Class Initialized
INFO - 2016-03-07 08:41:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:41:30 --> Controller Class Initialized
INFO - 2016-03-07 08:41:30 --> Model Class Initialized
INFO - 2016-03-07 08:41:30 --> Model Class Initialized
INFO - 2016-03-07 08:41:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:41:30 --> Pagination Class Initialized
INFO - 2016-03-07 08:41:30 --> Helper loaded: text_helper
INFO - 2016-03-07 08:41:30 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:41:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:41:30 --> Final output sent to browser
DEBUG - 2016-03-07 11:41:30 --> Total execution time: 1.1863
INFO - 2016-03-07 08:43:02 --> Config Class Initialized
INFO - 2016-03-07 08:43:02 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:43:02 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:43:02 --> Utf8 Class Initialized
INFO - 2016-03-07 08:43:02 --> URI Class Initialized
INFO - 2016-03-07 08:43:02 --> Router Class Initialized
INFO - 2016-03-07 08:43:02 --> Output Class Initialized
INFO - 2016-03-07 08:43:02 --> Security Class Initialized
DEBUG - 2016-03-07 08:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:43:02 --> Input Class Initialized
INFO - 2016-03-07 08:43:02 --> Language Class Initialized
INFO - 2016-03-07 08:43:02 --> Loader Class Initialized
INFO - 2016-03-07 08:43:02 --> Helper loaded: url_helper
INFO - 2016-03-07 08:43:02 --> Helper loaded: file_helper
INFO - 2016-03-07 08:43:02 --> Helper loaded: date_helper
INFO - 2016-03-07 08:43:02 --> Helper loaded: form_helper
INFO - 2016-03-07 08:43:02 --> Database Driver Class Initialized
INFO - 2016-03-07 08:43:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:43:03 --> Controller Class Initialized
INFO - 2016-03-07 08:43:03 --> Model Class Initialized
INFO - 2016-03-07 08:43:03 --> Model Class Initialized
INFO - 2016-03-07 08:43:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:43:03 --> Pagination Class Initialized
INFO - 2016-03-07 08:43:03 --> Helper loaded: text_helper
INFO - 2016-03-07 08:43:03 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 11:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 11:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 11:43:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:43:03 --> Final output sent to browser
DEBUG - 2016-03-07 11:43:03 --> Total execution time: 1.2280
INFO - 2016-03-07 08:43:15 --> Config Class Initialized
INFO - 2016-03-07 08:43:15 --> Hooks Class Initialized
DEBUG - 2016-03-07 08:43:15 --> UTF-8 Support Enabled
INFO - 2016-03-07 08:43:15 --> Utf8 Class Initialized
INFO - 2016-03-07 08:43:15 --> URI Class Initialized
DEBUG - 2016-03-07 08:43:15 --> No URI present. Default controller set.
INFO - 2016-03-07 08:43:15 --> Router Class Initialized
INFO - 2016-03-07 08:43:15 --> Output Class Initialized
INFO - 2016-03-07 08:43:15 --> Security Class Initialized
DEBUG - 2016-03-07 08:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 08:43:15 --> Input Class Initialized
INFO - 2016-03-07 08:43:15 --> Language Class Initialized
INFO - 2016-03-07 08:43:15 --> Loader Class Initialized
INFO - 2016-03-07 08:43:15 --> Helper loaded: url_helper
INFO - 2016-03-07 08:43:15 --> Helper loaded: file_helper
INFO - 2016-03-07 08:43:15 --> Helper loaded: date_helper
INFO - 2016-03-07 08:43:15 --> Helper loaded: form_helper
INFO - 2016-03-07 08:43:15 --> Database Driver Class Initialized
INFO - 2016-03-07 08:43:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 08:43:16 --> Controller Class Initialized
INFO - 2016-03-07 08:43:16 --> Model Class Initialized
INFO - 2016-03-07 08:43:16 --> Model Class Initialized
INFO - 2016-03-07 08:43:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 08:43:16 --> Pagination Class Initialized
INFO - 2016-03-07 08:43:16 --> Helper loaded: text_helper
INFO - 2016-03-07 08:43:16 --> Helper loaded: cookie_helper
INFO - 2016-03-07 11:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 11:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 11:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 11:43:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 11:43:16 --> Final output sent to browser
DEBUG - 2016-03-07 11:43:16 --> Total execution time: 1.1713
INFO - 2016-03-07 09:46:44 --> Config Class Initialized
INFO - 2016-03-07 09:46:44 --> Hooks Class Initialized
DEBUG - 2016-03-07 09:46:44 --> UTF-8 Support Enabled
INFO - 2016-03-07 09:46:44 --> Utf8 Class Initialized
INFO - 2016-03-07 09:46:44 --> URI Class Initialized
DEBUG - 2016-03-07 09:46:44 --> No URI present. Default controller set.
INFO - 2016-03-07 09:46:44 --> Router Class Initialized
INFO - 2016-03-07 09:46:44 --> Output Class Initialized
INFO - 2016-03-07 09:46:44 --> Security Class Initialized
DEBUG - 2016-03-07 09:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 09:46:44 --> Input Class Initialized
INFO - 2016-03-07 09:46:44 --> Language Class Initialized
INFO - 2016-03-07 09:46:44 --> Loader Class Initialized
INFO - 2016-03-07 09:46:44 --> Helper loaded: url_helper
INFO - 2016-03-07 09:46:44 --> Helper loaded: file_helper
INFO - 2016-03-07 09:46:44 --> Helper loaded: date_helper
INFO - 2016-03-07 09:46:44 --> Helper loaded: form_helper
INFO - 2016-03-07 09:46:44 --> Database Driver Class Initialized
INFO - 2016-03-07 09:46:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 09:46:45 --> Controller Class Initialized
INFO - 2016-03-07 09:46:45 --> Model Class Initialized
INFO - 2016-03-07 09:46:45 --> Model Class Initialized
INFO - 2016-03-07 09:46:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 09:46:45 --> Pagination Class Initialized
INFO - 2016-03-07 09:46:45 --> Helper loaded: text_helper
INFO - 2016-03-07 09:46:45 --> Helper loaded: cookie_helper
INFO - 2016-03-07 12:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 12:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 12:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 12:46:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 12:46:45 --> Final output sent to browser
DEBUG - 2016-03-07 12:46:45 --> Total execution time: 1.6422
INFO - 2016-03-07 09:48:59 --> Config Class Initialized
INFO - 2016-03-07 09:48:59 --> Hooks Class Initialized
DEBUG - 2016-03-07 09:48:59 --> UTF-8 Support Enabled
INFO - 2016-03-07 09:48:59 --> Utf8 Class Initialized
INFO - 2016-03-07 09:48:59 --> URI Class Initialized
DEBUG - 2016-03-07 09:48:59 --> No URI present. Default controller set.
INFO - 2016-03-07 09:48:59 --> Router Class Initialized
INFO - 2016-03-07 09:48:59 --> Output Class Initialized
INFO - 2016-03-07 09:48:59 --> Security Class Initialized
DEBUG - 2016-03-07 09:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 09:48:59 --> Input Class Initialized
INFO - 2016-03-07 09:48:59 --> Language Class Initialized
INFO - 2016-03-07 09:48:59 --> Loader Class Initialized
INFO - 2016-03-07 09:48:59 --> Helper loaded: url_helper
INFO - 2016-03-07 09:48:59 --> Helper loaded: file_helper
INFO - 2016-03-07 09:48:59 --> Helper loaded: date_helper
INFO - 2016-03-07 09:48:59 --> Helper loaded: form_helper
INFO - 2016-03-07 09:48:59 --> Database Driver Class Initialized
INFO - 2016-03-07 09:49:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 09:49:00 --> Controller Class Initialized
INFO - 2016-03-07 09:49:00 --> Model Class Initialized
INFO - 2016-03-07 09:49:00 --> Model Class Initialized
INFO - 2016-03-07 09:49:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 09:49:00 --> Pagination Class Initialized
INFO - 2016-03-07 09:49:00 --> Helper loaded: text_helper
INFO - 2016-03-07 09:49:00 --> Helper loaded: cookie_helper
INFO - 2016-03-07 12:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 12:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 12:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 12:49:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 12:49:00 --> Final output sent to browser
DEBUG - 2016-03-07 12:49:00 --> Total execution time: 1.1260
INFO - 2016-03-07 09:50:43 --> Config Class Initialized
INFO - 2016-03-07 09:50:43 --> Hooks Class Initialized
DEBUG - 2016-03-07 09:50:43 --> UTF-8 Support Enabled
INFO - 2016-03-07 09:50:43 --> Utf8 Class Initialized
INFO - 2016-03-07 09:50:43 --> URI Class Initialized
DEBUG - 2016-03-07 09:50:43 --> No URI present. Default controller set.
INFO - 2016-03-07 09:50:43 --> Router Class Initialized
INFO - 2016-03-07 09:50:43 --> Output Class Initialized
INFO - 2016-03-07 09:50:43 --> Security Class Initialized
DEBUG - 2016-03-07 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 09:50:43 --> Input Class Initialized
INFO - 2016-03-07 09:50:43 --> Language Class Initialized
INFO - 2016-03-07 09:50:43 --> Loader Class Initialized
INFO - 2016-03-07 09:50:43 --> Helper loaded: url_helper
INFO - 2016-03-07 09:50:43 --> Helper loaded: file_helper
INFO - 2016-03-07 09:50:43 --> Helper loaded: date_helper
INFO - 2016-03-07 09:50:43 --> Helper loaded: form_helper
INFO - 2016-03-07 09:50:43 --> Database Driver Class Initialized
INFO - 2016-03-07 09:50:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 09:50:44 --> Controller Class Initialized
INFO - 2016-03-07 09:50:44 --> Model Class Initialized
INFO - 2016-03-07 09:50:44 --> Model Class Initialized
INFO - 2016-03-07 09:50:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 09:50:44 --> Pagination Class Initialized
INFO - 2016-03-07 09:50:44 --> Helper loaded: text_helper
INFO - 2016-03-07 09:50:44 --> Helper loaded: cookie_helper
INFO - 2016-03-07 12:50:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 12:50:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 12:50:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 12:50:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 12:50:44 --> Final output sent to browser
DEBUG - 2016-03-07 12:50:44 --> Total execution time: 1.1459
INFO - 2016-03-07 09:50:45 --> Config Class Initialized
INFO - 2016-03-07 09:50:45 --> Hooks Class Initialized
DEBUG - 2016-03-07 09:50:45 --> UTF-8 Support Enabled
INFO - 2016-03-07 09:50:45 --> Utf8 Class Initialized
INFO - 2016-03-07 09:50:45 --> URI Class Initialized
INFO - 2016-03-07 09:50:45 --> Router Class Initialized
INFO - 2016-03-07 09:50:45 --> Output Class Initialized
INFO - 2016-03-07 09:50:45 --> Security Class Initialized
DEBUG - 2016-03-07 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 09:50:45 --> Input Class Initialized
INFO - 2016-03-07 09:50:45 --> Language Class Initialized
INFO - 2016-03-07 09:50:45 --> Loader Class Initialized
INFO - 2016-03-07 09:50:45 --> Helper loaded: url_helper
INFO - 2016-03-07 09:50:45 --> Helper loaded: file_helper
INFO - 2016-03-07 09:50:45 --> Helper loaded: date_helper
INFO - 2016-03-07 09:50:45 --> Helper loaded: form_helper
INFO - 2016-03-07 09:50:45 --> Database Driver Class Initialized
INFO - 2016-03-07 09:50:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 09:50:46 --> Controller Class Initialized
INFO - 2016-03-07 09:50:46 --> User Agent Class Initialized
INFO - 2016-03-07 09:50:46 --> Final output sent to browser
DEBUG - 2016-03-07 09:50:46 --> Total execution time: 1.1394
INFO - 2016-03-07 09:51:18 --> Config Class Initialized
INFO - 2016-03-07 09:51:18 --> Hooks Class Initialized
DEBUG - 2016-03-07 09:51:18 --> UTF-8 Support Enabled
INFO - 2016-03-07 09:51:18 --> Utf8 Class Initialized
INFO - 2016-03-07 09:51:18 --> URI Class Initialized
DEBUG - 2016-03-07 09:51:18 --> No URI present. Default controller set.
INFO - 2016-03-07 09:51:18 --> Router Class Initialized
INFO - 2016-03-07 09:51:18 --> Output Class Initialized
INFO - 2016-03-07 09:51:18 --> Security Class Initialized
DEBUG - 2016-03-07 09:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 09:51:18 --> Input Class Initialized
INFO - 2016-03-07 09:51:18 --> Language Class Initialized
INFO - 2016-03-07 09:51:18 --> Loader Class Initialized
INFO - 2016-03-07 09:51:18 --> Helper loaded: url_helper
INFO - 2016-03-07 09:51:18 --> Helper loaded: file_helper
INFO - 2016-03-07 09:51:18 --> Helper loaded: date_helper
INFO - 2016-03-07 09:51:18 --> Helper loaded: form_helper
INFO - 2016-03-07 09:51:18 --> Database Driver Class Initialized
INFO - 2016-03-07 09:51:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 09:51:19 --> Controller Class Initialized
INFO - 2016-03-07 09:51:19 --> Model Class Initialized
INFO - 2016-03-07 09:51:19 --> Model Class Initialized
INFO - 2016-03-07 09:51:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 09:51:19 --> Pagination Class Initialized
INFO - 2016-03-07 09:51:19 --> Helper loaded: text_helper
INFO - 2016-03-07 09:51:19 --> Helper loaded: cookie_helper
INFO - 2016-03-07 12:51:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 12:51:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 12:51:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 12:51:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 12:51:19 --> Final output sent to browser
DEBUG - 2016-03-07 12:51:19 --> Total execution time: 1.1891
INFO - 2016-03-07 09:59:13 --> Config Class Initialized
INFO - 2016-03-07 09:59:13 --> Hooks Class Initialized
DEBUG - 2016-03-07 09:59:13 --> UTF-8 Support Enabled
INFO - 2016-03-07 09:59:13 --> Utf8 Class Initialized
INFO - 2016-03-07 09:59:13 --> URI Class Initialized
DEBUG - 2016-03-07 09:59:13 --> No URI present. Default controller set.
INFO - 2016-03-07 09:59:13 --> Router Class Initialized
INFO - 2016-03-07 09:59:13 --> Output Class Initialized
INFO - 2016-03-07 09:59:13 --> Security Class Initialized
DEBUG - 2016-03-07 09:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 09:59:13 --> Input Class Initialized
INFO - 2016-03-07 09:59:13 --> Language Class Initialized
INFO - 2016-03-07 09:59:13 --> Loader Class Initialized
INFO - 2016-03-07 09:59:13 --> Helper loaded: url_helper
INFO - 2016-03-07 09:59:13 --> Helper loaded: file_helper
INFO - 2016-03-07 09:59:13 --> Helper loaded: date_helper
INFO - 2016-03-07 09:59:13 --> Helper loaded: form_helper
INFO - 2016-03-07 09:59:13 --> Database Driver Class Initialized
INFO - 2016-03-07 09:59:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 09:59:14 --> Controller Class Initialized
INFO - 2016-03-07 09:59:14 --> Model Class Initialized
INFO - 2016-03-07 09:59:14 --> Model Class Initialized
INFO - 2016-03-07 09:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 09:59:14 --> Pagination Class Initialized
INFO - 2016-03-07 09:59:14 --> Helper loaded: text_helper
INFO - 2016-03-07 09:59:14 --> Helper loaded: cookie_helper
INFO - 2016-03-07 12:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 12:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 12:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 12:59:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 12:59:14 --> Final output sent to browser
DEBUG - 2016-03-07 12:59:14 --> Total execution time: 1.1360
INFO - 2016-03-07 09:59:31 --> Config Class Initialized
INFO - 2016-03-07 09:59:31 --> Hooks Class Initialized
DEBUG - 2016-03-07 09:59:31 --> UTF-8 Support Enabled
INFO - 2016-03-07 09:59:31 --> Utf8 Class Initialized
INFO - 2016-03-07 09:59:31 --> URI Class Initialized
DEBUG - 2016-03-07 09:59:31 --> No URI present. Default controller set.
INFO - 2016-03-07 09:59:31 --> Router Class Initialized
INFO - 2016-03-07 09:59:31 --> Output Class Initialized
INFO - 2016-03-07 09:59:31 --> Security Class Initialized
DEBUG - 2016-03-07 09:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 09:59:31 --> Input Class Initialized
INFO - 2016-03-07 09:59:31 --> Language Class Initialized
INFO - 2016-03-07 09:59:31 --> Loader Class Initialized
INFO - 2016-03-07 09:59:31 --> Helper loaded: url_helper
INFO - 2016-03-07 09:59:31 --> Helper loaded: file_helper
INFO - 2016-03-07 09:59:31 --> Helper loaded: date_helper
INFO - 2016-03-07 09:59:31 --> Helper loaded: form_helper
INFO - 2016-03-07 09:59:31 --> Database Driver Class Initialized
INFO - 2016-03-07 09:59:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 09:59:32 --> Controller Class Initialized
INFO - 2016-03-07 09:59:32 --> Model Class Initialized
INFO - 2016-03-07 09:59:32 --> Model Class Initialized
INFO - 2016-03-07 09:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 09:59:32 --> Pagination Class Initialized
INFO - 2016-03-07 09:59:32 --> Helper loaded: text_helper
INFO - 2016-03-07 09:59:32 --> Helper loaded: cookie_helper
INFO - 2016-03-07 12:59:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 12:59:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 12:59:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 12:59:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 12:59:32 --> Final output sent to browser
DEBUG - 2016-03-07 12:59:32 --> Total execution time: 1.1495
INFO - 2016-03-07 10:00:25 --> Config Class Initialized
INFO - 2016-03-07 10:00:25 --> Hooks Class Initialized
DEBUG - 2016-03-07 10:00:25 --> UTF-8 Support Enabled
INFO - 2016-03-07 10:00:25 --> Utf8 Class Initialized
INFO - 2016-03-07 10:00:25 --> URI Class Initialized
DEBUG - 2016-03-07 10:00:26 --> No URI present. Default controller set.
INFO - 2016-03-07 10:00:26 --> Router Class Initialized
INFO - 2016-03-07 10:00:26 --> Output Class Initialized
INFO - 2016-03-07 10:00:26 --> Security Class Initialized
DEBUG - 2016-03-07 10:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 10:00:26 --> Input Class Initialized
INFO - 2016-03-07 10:00:26 --> Language Class Initialized
INFO - 2016-03-07 10:00:26 --> Loader Class Initialized
INFO - 2016-03-07 10:00:26 --> Helper loaded: url_helper
INFO - 2016-03-07 10:00:26 --> Helper loaded: file_helper
INFO - 2016-03-07 10:00:26 --> Helper loaded: date_helper
INFO - 2016-03-07 10:00:26 --> Helper loaded: form_helper
INFO - 2016-03-07 10:00:26 --> Database Driver Class Initialized
INFO - 2016-03-07 10:00:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 10:00:27 --> Controller Class Initialized
INFO - 2016-03-07 10:00:27 --> Model Class Initialized
INFO - 2016-03-07 10:00:27 --> Model Class Initialized
INFO - 2016-03-07 10:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 10:00:27 --> Pagination Class Initialized
INFO - 2016-03-07 10:00:27 --> Helper loaded: text_helper
INFO - 2016-03-07 10:00:27 --> Helper loaded: cookie_helper
INFO - 2016-03-07 13:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 13:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 13:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 13:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 13:00:27 --> Final output sent to browser
DEBUG - 2016-03-07 13:00:27 --> Total execution time: 1.1295
INFO - 2016-03-07 10:03:07 --> Config Class Initialized
INFO - 2016-03-07 10:03:07 --> Hooks Class Initialized
DEBUG - 2016-03-07 10:03:07 --> UTF-8 Support Enabled
INFO - 2016-03-07 10:03:07 --> Utf8 Class Initialized
INFO - 2016-03-07 10:03:07 --> URI Class Initialized
DEBUG - 2016-03-07 10:03:07 --> No URI present. Default controller set.
INFO - 2016-03-07 10:03:07 --> Router Class Initialized
INFO - 2016-03-07 10:03:07 --> Output Class Initialized
INFO - 2016-03-07 10:03:07 --> Security Class Initialized
DEBUG - 2016-03-07 10:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 10:03:07 --> Input Class Initialized
INFO - 2016-03-07 10:03:07 --> Language Class Initialized
INFO - 2016-03-07 10:03:07 --> Loader Class Initialized
INFO - 2016-03-07 10:03:07 --> Helper loaded: url_helper
INFO - 2016-03-07 10:03:07 --> Helper loaded: file_helper
INFO - 2016-03-07 10:03:07 --> Helper loaded: date_helper
INFO - 2016-03-07 10:03:07 --> Helper loaded: form_helper
INFO - 2016-03-07 10:03:07 --> Database Driver Class Initialized
INFO - 2016-03-07 10:03:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 10:03:08 --> Controller Class Initialized
INFO - 2016-03-07 10:03:08 --> Model Class Initialized
INFO - 2016-03-07 10:03:08 --> Model Class Initialized
INFO - 2016-03-07 10:03:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 10:03:08 --> Pagination Class Initialized
INFO - 2016-03-07 10:03:08 --> Helper loaded: text_helper
INFO - 2016-03-07 10:03:08 --> Helper loaded: cookie_helper
INFO - 2016-03-07 13:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 13:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 13:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 13:03:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 13:03:08 --> Final output sent to browser
DEBUG - 2016-03-07 13:03:09 --> Total execution time: 1.1932
INFO - 2016-03-07 10:20:50 --> Config Class Initialized
INFO - 2016-03-07 10:20:50 --> Hooks Class Initialized
DEBUG - 2016-03-07 10:20:50 --> UTF-8 Support Enabled
INFO - 2016-03-07 10:20:50 --> Utf8 Class Initialized
INFO - 2016-03-07 10:20:50 --> URI Class Initialized
DEBUG - 2016-03-07 10:20:50 --> No URI present. Default controller set.
INFO - 2016-03-07 10:20:50 --> Router Class Initialized
INFO - 2016-03-07 10:20:50 --> Output Class Initialized
INFO - 2016-03-07 10:20:50 --> Security Class Initialized
DEBUG - 2016-03-07 10:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 10:20:50 --> Input Class Initialized
INFO - 2016-03-07 10:20:50 --> Language Class Initialized
INFO - 2016-03-07 10:20:50 --> Loader Class Initialized
INFO - 2016-03-07 10:20:50 --> Helper loaded: url_helper
INFO - 2016-03-07 10:20:50 --> Helper loaded: file_helper
INFO - 2016-03-07 10:20:50 --> Helper loaded: date_helper
INFO - 2016-03-07 10:20:50 --> Helper loaded: form_helper
INFO - 2016-03-07 10:20:50 --> Database Driver Class Initialized
INFO - 2016-03-07 10:20:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 10:20:51 --> Controller Class Initialized
INFO - 2016-03-07 10:20:51 --> Model Class Initialized
INFO - 2016-03-07 10:20:51 --> Model Class Initialized
INFO - 2016-03-07 10:20:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 10:20:51 --> Pagination Class Initialized
INFO - 2016-03-07 10:20:51 --> Helper loaded: text_helper
INFO - 2016-03-07 10:20:51 --> Helper loaded: cookie_helper
INFO - 2016-03-07 13:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 13:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 13:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 13:20:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 13:20:51 --> Final output sent to browser
DEBUG - 2016-03-07 13:20:51 --> Total execution time: 1.1617
INFO - 2016-03-07 14:00:25 --> Config Class Initialized
INFO - 2016-03-07 14:00:25 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:00:25 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:00:25 --> Utf8 Class Initialized
INFO - 2016-03-07 14:00:25 --> URI Class Initialized
INFO - 2016-03-07 14:00:25 --> Router Class Initialized
INFO - 2016-03-07 14:00:25 --> Output Class Initialized
INFO - 2016-03-07 14:00:25 --> Security Class Initialized
DEBUG - 2016-03-07 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:00:25 --> Input Class Initialized
INFO - 2016-03-07 14:00:25 --> Language Class Initialized
INFO - 2016-03-07 14:00:25 --> Loader Class Initialized
INFO - 2016-03-07 14:00:25 --> Helper loaded: url_helper
INFO - 2016-03-07 14:00:25 --> Helper loaded: file_helper
INFO - 2016-03-07 14:00:25 --> Helper loaded: date_helper
INFO - 2016-03-07 14:00:25 --> Helper loaded: form_helper
INFO - 2016-03-07 14:00:25 --> Database Driver Class Initialized
INFO - 2016-03-07 14:00:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:00:26 --> Controller Class Initialized
INFO - 2016-03-07 14:00:26 --> Model Class Initialized
INFO - 2016-03-07 14:00:26 --> Model Class Initialized
INFO - 2016-03-07 14:00:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:00:26 --> Pagination Class Initialized
INFO - 2016-03-07 14:00:26 --> Helper loaded: text_helper
INFO - 2016-03-07 14:00:26 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:00:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:00:27 --> Final output sent to browser
DEBUG - 2016-03-07 17:00:27 --> Total execution time: 1.1730
INFO - 2016-03-07 14:00:54 --> Config Class Initialized
INFO - 2016-03-07 14:00:54 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:00:54 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:00:54 --> Utf8 Class Initialized
INFO - 2016-03-07 14:00:54 --> URI Class Initialized
INFO - 2016-03-07 14:00:54 --> Router Class Initialized
INFO - 2016-03-07 14:00:54 --> Output Class Initialized
INFO - 2016-03-07 14:00:54 --> Security Class Initialized
DEBUG - 2016-03-07 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:00:54 --> Input Class Initialized
INFO - 2016-03-07 14:00:54 --> Language Class Initialized
INFO - 2016-03-07 14:00:54 --> Loader Class Initialized
INFO - 2016-03-07 14:00:54 --> Helper loaded: url_helper
INFO - 2016-03-07 14:00:54 --> Helper loaded: file_helper
INFO - 2016-03-07 14:00:54 --> Helper loaded: date_helper
INFO - 2016-03-07 14:00:54 --> Helper loaded: form_helper
INFO - 2016-03-07 14:00:54 --> Database Driver Class Initialized
INFO - 2016-03-07 14:00:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:00:55 --> Controller Class Initialized
INFO - 2016-03-07 14:00:55 --> Model Class Initialized
INFO - 2016-03-07 14:00:55 --> Model Class Initialized
INFO - 2016-03-07 14:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:00:55 --> Pagination Class Initialized
INFO - 2016-03-07 14:00:55 --> Helper loaded: text_helper
INFO - 2016-03-07 14:00:55 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:00:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:00:55 --> Final output sent to browser
DEBUG - 2016-03-07 17:00:55 --> Total execution time: 1.1373
INFO - 2016-03-07 14:01:13 --> Config Class Initialized
INFO - 2016-03-07 14:01:13 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:01:13 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:01:13 --> Utf8 Class Initialized
INFO - 2016-03-07 14:01:13 --> URI Class Initialized
INFO - 2016-03-07 14:01:13 --> Router Class Initialized
INFO - 2016-03-07 14:01:13 --> Output Class Initialized
INFO - 2016-03-07 14:01:13 --> Security Class Initialized
DEBUG - 2016-03-07 14:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:01:13 --> Input Class Initialized
INFO - 2016-03-07 14:01:13 --> Language Class Initialized
INFO - 2016-03-07 14:01:13 --> Loader Class Initialized
INFO - 2016-03-07 14:01:13 --> Helper loaded: url_helper
INFO - 2016-03-07 14:01:13 --> Helper loaded: file_helper
INFO - 2016-03-07 14:01:13 --> Helper loaded: date_helper
INFO - 2016-03-07 14:01:13 --> Helper loaded: form_helper
INFO - 2016-03-07 14:01:13 --> Database Driver Class Initialized
INFO - 2016-03-07 14:01:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:01:14 --> Controller Class Initialized
INFO - 2016-03-07 14:01:14 --> Model Class Initialized
INFO - 2016-03-07 14:01:14 --> Model Class Initialized
INFO - 2016-03-07 14:01:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:01:14 --> Pagination Class Initialized
INFO - 2016-03-07 14:01:14 --> Helper loaded: text_helper
INFO - 2016-03-07 14:01:14 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:01:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:01:14 --> Final output sent to browser
DEBUG - 2016-03-07 17:01:14 --> Total execution time: 1.1160
INFO - 2016-03-07 14:01:23 --> Config Class Initialized
INFO - 2016-03-07 14:01:23 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:01:23 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:01:23 --> Utf8 Class Initialized
INFO - 2016-03-07 14:01:23 --> URI Class Initialized
INFO - 2016-03-07 14:01:23 --> Router Class Initialized
INFO - 2016-03-07 14:01:23 --> Output Class Initialized
INFO - 2016-03-07 14:01:23 --> Security Class Initialized
DEBUG - 2016-03-07 14:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:01:23 --> Input Class Initialized
INFO - 2016-03-07 14:01:23 --> Language Class Initialized
INFO - 2016-03-07 14:01:23 --> Loader Class Initialized
INFO - 2016-03-07 14:01:23 --> Helper loaded: url_helper
INFO - 2016-03-07 14:01:23 --> Helper loaded: file_helper
INFO - 2016-03-07 14:01:23 --> Helper loaded: date_helper
INFO - 2016-03-07 14:01:23 --> Helper loaded: form_helper
INFO - 2016-03-07 14:01:23 --> Database Driver Class Initialized
INFO - 2016-03-07 14:01:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:01:24 --> Controller Class Initialized
INFO - 2016-03-07 14:01:24 --> Model Class Initialized
INFO - 2016-03-07 14:01:24 --> Model Class Initialized
INFO - 2016-03-07 14:01:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:01:25 --> Pagination Class Initialized
INFO - 2016-03-07 14:01:25 --> Helper loaded: text_helper
INFO - 2016-03-07 14:01:25 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:01:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:01:25 --> Final output sent to browser
DEBUG - 2016-03-07 17:01:25 --> Total execution time: 1.1520
INFO - 2016-03-07 14:01:27 --> Config Class Initialized
INFO - 2016-03-07 14:01:27 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:01:27 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:01:27 --> Utf8 Class Initialized
INFO - 2016-03-07 14:01:27 --> URI Class Initialized
INFO - 2016-03-07 14:01:27 --> Router Class Initialized
INFO - 2016-03-07 14:01:27 --> Output Class Initialized
INFO - 2016-03-07 14:01:27 --> Security Class Initialized
DEBUG - 2016-03-07 14:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:01:27 --> Input Class Initialized
INFO - 2016-03-07 14:01:27 --> Language Class Initialized
INFO - 2016-03-07 14:01:27 --> Loader Class Initialized
INFO - 2016-03-07 14:01:27 --> Helper loaded: url_helper
INFO - 2016-03-07 14:01:27 --> Helper loaded: file_helper
INFO - 2016-03-07 14:01:27 --> Helper loaded: date_helper
INFO - 2016-03-07 14:01:27 --> Helper loaded: form_helper
INFO - 2016-03-07 14:01:27 --> Database Driver Class Initialized
INFO - 2016-03-07 14:01:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:01:28 --> Controller Class Initialized
INFO - 2016-03-07 14:01:28 --> Model Class Initialized
INFO - 2016-03-07 14:01:28 --> Model Class Initialized
INFO - 2016-03-07 14:01:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:01:28 --> Pagination Class Initialized
INFO - 2016-03-07 14:01:28 --> Helper loaded: text_helper
INFO - 2016-03-07 14:01:28 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:01:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:01:28 --> Final output sent to browser
DEBUG - 2016-03-07 17:01:28 --> Total execution time: 1.1473
INFO - 2016-03-07 14:01:33 --> Config Class Initialized
INFO - 2016-03-07 14:01:33 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:01:33 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:01:33 --> Utf8 Class Initialized
INFO - 2016-03-07 14:01:33 --> URI Class Initialized
INFO - 2016-03-07 14:01:33 --> Router Class Initialized
INFO - 2016-03-07 14:01:33 --> Output Class Initialized
INFO - 2016-03-07 14:01:33 --> Security Class Initialized
DEBUG - 2016-03-07 14:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:01:33 --> Input Class Initialized
INFO - 2016-03-07 14:01:33 --> Language Class Initialized
INFO - 2016-03-07 14:01:33 --> Loader Class Initialized
INFO - 2016-03-07 14:01:33 --> Helper loaded: url_helper
INFO - 2016-03-07 14:01:33 --> Helper loaded: file_helper
INFO - 2016-03-07 14:01:33 --> Helper loaded: date_helper
INFO - 2016-03-07 14:01:33 --> Helper loaded: form_helper
INFO - 2016-03-07 14:01:33 --> Database Driver Class Initialized
INFO - 2016-03-07 14:01:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:01:35 --> Controller Class Initialized
INFO - 2016-03-07 14:01:35 --> Model Class Initialized
INFO - 2016-03-07 14:01:35 --> Model Class Initialized
INFO - 2016-03-07 14:01:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:01:35 --> Pagination Class Initialized
INFO - 2016-03-07 14:01:35 --> Helper loaded: text_helper
INFO - 2016-03-07 14:01:35 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:01:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:01:35 --> Final output sent to browser
DEBUG - 2016-03-07 17:01:35 --> Total execution time: 1.1450
INFO - 2016-03-07 14:01:39 --> Config Class Initialized
INFO - 2016-03-07 14:01:39 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:01:39 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:01:39 --> Utf8 Class Initialized
INFO - 2016-03-07 14:01:39 --> URI Class Initialized
INFO - 2016-03-07 14:01:39 --> Router Class Initialized
INFO - 2016-03-07 14:01:39 --> Output Class Initialized
INFO - 2016-03-07 14:01:39 --> Security Class Initialized
DEBUG - 2016-03-07 14:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:01:39 --> Input Class Initialized
INFO - 2016-03-07 14:01:39 --> Language Class Initialized
INFO - 2016-03-07 14:01:39 --> Loader Class Initialized
INFO - 2016-03-07 14:01:39 --> Helper loaded: url_helper
INFO - 2016-03-07 14:01:39 --> Helper loaded: file_helper
INFO - 2016-03-07 14:01:39 --> Helper loaded: date_helper
INFO - 2016-03-07 14:01:39 --> Helper loaded: form_helper
INFO - 2016-03-07 14:01:39 --> Database Driver Class Initialized
INFO - 2016-03-07 14:01:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:01:40 --> Controller Class Initialized
INFO - 2016-03-07 14:01:40 --> Model Class Initialized
INFO - 2016-03-07 14:01:40 --> Model Class Initialized
INFO - 2016-03-07 14:01:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:01:40 --> Pagination Class Initialized
INFO - 2016-03-07 14:01:40 --> Helper loaded: text_helper
INFO - 2016-03-07 14:01:40 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 17:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 17:01:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:01:40 --> Final output sent to browser
DEBUG - 2016-03-07 17:01:40 --> Total execution time: 1.1816
INFO - 2016-03-07 14:01:41 --> Config Class Initialized
INFO - 2016-03-07 14:01:41 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:01:41 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:01:41 --> Utf8 Class Initialized
INFO - 2016-03-07 14:01:41 --> URI Class Initialized
INFO - 2016-03-07 14:01:41 --> Router Class Initialized
INFO - 2016-03-07 14:01:41 --> Output Class Initialized
INFO - 2016-03-07 14:01:41 --> Security Class Initialized
DEBUG - 2016-03-07 14:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:01:41 --> Input Class Initialized
INFO - 2016-03-07 14:01:41 --> Language Class Initialized
INFO - 2016-03-07 14:01:41 --> Loader Class Initialized
INFO - 2016-03-07 14:01:41 --> Helper loaded: url_helper
INFO - 2016-03-07 14:01:41 --> Helper loaded: file_helper
INFO - 2016-03-07 14:01:41 --> Helper loaded: date_helper
INFO - 2016-03-07 14:01:41 --> Helper loaded: form_helper
INFO - 2016-03-07 14:01:41 --> Database Driver Class Initialized
INFO - 2016-03-07 14:01:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:01:42 --> Controller Class Initialized
INFO - 2016-03-07 14:01:42 --> User Agent Class Initialized
INFO - 2016-03-07 14:01:42 --> Final output sent to browser
DEBUG - 2016-03-07 14:01:42 --> Total execution time: 1.1110
INFO - 2016-03-07 14:01:54 --> Config Class Initialized
INFO - 2016-03-07 14:01:54 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:01:54 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:01:54 --> Utf8 Class Initialized
INFO - 2016-03-07 14:01:54 --> URI Class Initialized
INFO - 2016-03-07 14:01:54 --> Router Class Initialized
INFO - 2016-03-07 14:01:54 --> Output Class Initialized
INFO - 2016-03-07 14:01:54 --> Security Class Initialized
DEBUG - 2016-03-07 14:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:01:54 --> Input Class Initialized
INFO - 2016-03-07 14:01:54 --> Language Class Initialized
INFO - 2016-03-07 14:01:54 --> Loader Class Initialized
INFO - 2016-03-07 14:01:54 --> Helper loaded: url_helper
INFO - 2016-03-07 14:01:54 --> Helper loaded: file_helper
INFO - 2016-03-07 14:01:54 --> Helper loaded: date_helper
INFO - 2016-03-07 14:01:54 --> Helper loaded: form_helper
INFO - 2016-03-07 14:01:54 --> Database Driver Class Initialized
INFO - 2016-03-07 14:01:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:01:55 --> Controller Class Initialized
INFO - 2016-03-07 14:01:55 --> Model Class Initialized
INFO - 2016-03-07 14:01:55 --> Model Class Initialized
INFO - 2016-03-07 14:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:01:55 --> Pagination Class Initialized
INFO - 2016-03-07 14:01:55 --> Helper loaded: text_helper
INFO - 2016-03-07 14:01:55 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:01:56 --> Final output sent to browser
DEBUG - 2016-03-07 17:01:56 --> Total execution time: 1.1141
INFO - 2016-03-07 14:01:59 --> Config Class Initialized
INFO - 2016-03-07 14:01:59 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:01:59 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:01:59 --> Utf8 Class Initialized
INFO - 2016-03-07 14:01:59 --> URI Class Initialized
INFO - 2016-03-07 14:01:59 --> Router Class Initialized
INFO - 2016-03-07 14:01:59 --> Output Class Initialized
INFO - 2016-03-07 14:01:59 --> Security Class Initialized
DEBUG - 2016-03-07 14:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:01:59 --> Input Class Initialized
INFO - 2016-03-07 14:01:59 --> Language Class Initialized
INFO - 2016-03-07 14:01:59 --> Loader Class Initialized
INFO - 2016-03-07 14:01:59 --> Helper loaded: url_helper
INFO - 2016-03-07 14:01:59 --> Helper loaded: file_helper
INFO - 2016-03-07 14:01:59 --> Helper loaded: date_helper
INFO - 2016-03-07 14:01:59 --> Helper loaded: form_helper
INFO - 2016-03-07 14:01:59 --> Database Driver Class Initialized
INFO - 2016-03-07 14:02:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:02:00 --> Controller Class Initialized
INFO - 2016-03-07 14:02:00 --> Model Class Initialized
INFO - 2016-03-07 14:02:00 --> Model Class Initialized
INFO - 2016-03-07 14:02:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:02:00 --> Pagination Class Initialized
INFO - 2016-03-07 14:02:00 --> Helper loaded: text_helper
INFO - 2016-03-07 14:02:00 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:02:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:02:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:02:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 17:02:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 17:02:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:02:00 --> Final output sent to browser
DEBUG - 2016-03-07 17:02:00 --> Total execution time: 1.1709
INFO - 2016-03-07 14:08:12 --> Config Class Initialized
INFO - 2016-03-07 14:08:12 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:08:12 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:08:12 --> Utf8 Class Initialized
INFO - 2016-03-07 14:08:12 --> URI Class Initialized
INFO - 2016-03-07 14:08:12 --> Router Class Initialized
INFO - 2016-03-07 14:08:12 --> Output Class Initialized
INFO - 2016-03-07 14:08:12 --> Security Class Initialized
DEBUG - 2016-03-07 14:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:08:12 --> Input Class Initialized
INFO - 2016-03-07 14:08:12 --> Language Class Initialized
INFO - 2016-03-07 14:08:12 --> Loader Class Initialized
INFO - 2016-03-07 14:08:12 --> Helper loaded: url_helper
INFO - 2016-03-07 14:08:12 --> Helper loaded: file_helper
INFO - 2016-03-07 14:08:12 --> Helper loaded: date_helper
INFO - 2016-03-07 14:08:12 --> Helper loaded: form_helper
INFO - 2016-03-07 14:08:12 --> Database Driver Class Initialized
INFO - 2016-03-07 14:08:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:08:13 --> Controller Class Initialized
INFO - 2016-03-07 14:08:13 --> Model Class Initialized
INFO - 2016-03-07 14:08:13 --> Model Class Initialized
INFO - 2016-03-07 14:08:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:08:13 --> Pagination Class Initialized
INFO - 2016-03-07 14:08:13 --> Helper loaded: text_helper
INFO - 2016-03-07 14:08:13 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:08:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:08:13 --> Final output sent to browser
DEBUG - 2016-03-07 17:08:13 --> Total execution time: 1.1876
INFO - 2016-03-07 14:08:23 --> Config Class Initialized
INFO - 2016-03-07 14:08:23 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:08:23 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:08:23 --> Utf8 Class Initialized
INFO - 2016-03-07 14:08:23 --> URI Class Initialized
INFO - 2016-03-07 14:08:23 --> Router Class Initialized
INFO - 2016-03-07 14:08:23 --> Output Class Initialized
INFO - 2016-03-07 14:08:23 --> Security Class Initialized
DEBUG - 2016-03-07 14:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:08:23 --> Input Class Initialized
INFO - 2016-03-07 14:08:23 --> Language Class Initialized
INFO - 2016-03-07 14:08:23 --> Loader Class Initialized
INFO - 2016-03-07 14:08:23 --> Helper loaded: url_helper
INFO - 2016-03-07 14:08:23 --> Helper loaded: file_helper
INFO - 2016-03-07 14:08:23 --> Helper loaded: date_helper
INFO - 2016-03-07 14:08:23 --> Helper loaded: form_helper
INFO - 2016-03-07 14:08:23 --> Database Driver Class Initialized
INFO - 2016-03-07 14:08:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:08:24 --> Controller Class Initialized
INFO - 2016-03-07 14:08:24 --> Model Class Initialized
INFO - 2016-03-07 14:08:24 --> Model Class Initialized
INFO - 2016-03-07 14:08:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:08:24 --> Pagination Class Initialized
INFO - 2016-03-07 14:08:24 --> Helper loaded: text_helper
INFO - 2016-03-07 14:08:24 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:08:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:08:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:08:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:08:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:08:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:08:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:08:25 --> Final output sent to browser
DEBUG - 2016-03-07 17:08:25 --> Total execution time: 1.1545
INFO - 2016-03-07 14:08:34 --> Config Class Initialized
INFO - 2016-03-07 14:08:34 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:08:34 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:08:34 --> Utf8 Class Initialized
INFO - 2016-03-07 14:08:34 --> URI Class Initialized
INFO - 2016-03-07 14:08:34 --> Router Class Initialized
INFO - 2016-03-07 14:08:34 --> Output Class Initialized
INFO - 2016-03-07 14:08:34 --> Security Class Initialized
DEBUG - 2016-03-07 14:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:08:34 --> Input Class Initialized
INFO - 2016-03-07 14:08:34 --> Language Class Initialized
INFO - 2016-03-07 14:08:34 --> Loader Class Initialized
INFO - 2016-03-07 14:08:34 --> Helper loaded: url_helper
INFO - 2016-03-07 14:08:34 --> Helper loaded: file_helper
INFO - 2016-03-07 14:08:34 --> Helper loaded: date_helper
INFO - 2016-03-07 14:08:34 --> Helper loaded: form_helper
INFO - 2016-03-07 14:08:34 --> Database Driver Class Initialized
INFO - 2016-03-07 14:08:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:08:35 --> Controller Class Initialized
INFO - 2016-03-07 14:08:35 --> Model Class Initialized
INFO - 2016-03-07 14:08:35 --> Model Class Initialized
INFO - 2016-03-07 14:08:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:08:35 --> Pagination Class Initialized
INFO - 2016-03-07 14:08:35 --> Helper loaded: text_helper
INFO - 2016-03-07 14:08:35 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:08:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:08:35 --> Final output sent to browser
DEBUG - 2016-03-07 17:08:35 --> Total execution time: 1.1649
INFO - 2016-03-07 14:08:55 --> Config Class Initialized
INFO - 2016-03-07 14:08:55 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:08:55 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:08:55 --> Utf8 Class Initialized
INFO - 2016-03-07 14:08:55 --> URI Class Initialized
INFO - 2016-03-07 14:08:55 --> Router Class Initialized
INFO - 2016-03-07 14:08:55 --> Output Class Initialized
INFO - 2016-03-07 14:08:55 --> Security Class Initialized
DEBUG - 2016-03-07 14:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:08:55 --> Input Class Initialized
INFO - 2016-03-07 14:08:55 --> Language Class Initialized
INFO - 2016-03-07 14:08:55 --> Loader Class Initialized
INFO - 2016-03-07 14:08:55 --> Helper loaded: url_helper
INFO - 2016-03-07 14:08:55 --> Helper loaded: file_helper
INFO - 2016-03-07 14:08:55 --> Helper loaded: date_helper
INFO - 2016-03-07 14:08:55 --> Helper loaded: form_helper
INFO - 2016-03-07 14:08:55 --> Database Driver Class Initialized
INFO - 2016-03-07 14:08:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:08:56 --> Controller Class Initialized
INFO - 2016-03-07 14:08:56 --> Model Class Initialized
INFO - 2016-03-07 14:08:56 --> Model Class Initialized
INFO - 2016-03-07 14:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:08:56 --> Pagination Class Initialized
INFO - 2016-03-07 14:08:56 --> Helper loaded: text_helper
INFO - 2016-03-07 14:08:56 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:08:56 --> Final output sent to browser
DEBUG - 2016-03-07 17:08:56 --> Total execution time: 1.1593
INFO - 2016-03-07 14:13:05 --> Config Class Initialized
INFO - 2016-03-07 14:13:05 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:13:05 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:13:05 --> Utf8 Class Initialized
INFO - 2016-03-07 14:13:05 --> URI Class Initialized
INFO - 2016-03-07 14:13:05 --> Router Class Initialized
INFO - 2016-03-07 14:13:05 --> Output Class Initialized
INFO - 2016-03-07 14:13:05 --> Security Class Initialized
DEBUG - 2016-03-07 14:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:13:05 --> Input Class Initialized
INFO - 2016-03-07 14:13:05 --> Language Class Initialized
INFO - 2016-03-07 14:13:05 --> Loader Class Initialized
INFO - 2016-03-07 14:13:05 --> Helper loaded: url_helper
INFO - 2016-03-07 14:13:05 --> Helper loaded: file_helper
INFO - 2016-03-07 14:13:05 --> Helper loaded: date_helper
INFO - 2016-03-07 14:13:05 --> Helper loaded: form_helper
INFO - 2016-03-07 14:13:05 --> Database Driver Class Initialized
INFO - 2016-03-07 14:13:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:13:06 --> Controller Class Initialized
INFO - 2016-03-07 14:13:06 --> Model Class Initialized
INFO - 2016-03-07 14:13:06 --> Model Class Initialized
INFO - 2016-03-07 14:13:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:13:06 --> Pagination Class Initialized
INFO - 2016-03-07 14:13:06 --> Helper loaded: text_helper
INFO - 2016-03-07 14:13:06 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:13:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:13:06 --> Final output sent to browser
DEBUG - 2016-03-07 17:13:06 --> Total execution time: 1.1438
INFO - 2016-03-07 14:13:09 --> Config Class Initialized
INFO - 2016-03-07 14:13:09 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:13:09 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:13:09 --> Utf8 Class Initialized
INFO - 2016-03-07 14:13:09 --> URI Class Initialized
INFO - 2016-03-07 14:13:09 --> Router Class Initialized
INFO - 2016-03-07 14:13:09 --> Output Class Initialized
INFO - 2016-03-07 14:13:09 --> Security Class Initialized
DEBUG - 2016-03-07 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:13:09 --> Input Class Initialized
INFO - 2016-03-07 14:13:09 --> Language Class Initialized
INFO - 2016-03-07 14:13:09 --> Loader Class Initialized
INFO - 2016-03-07 14:13:09 --> Helper loaded: url_helper
INFO - 2016-03-07 14:13:09 --> Helper loaded: file_helper
INFO - 2016-03-07 14:13:09 --> Helper loaded: date_helper
INFO - 2016-03-07 14:13:09 --> Helper loaded: form_helper
INFO - 2016-03-07 14:13:09 --> Database Driver Class Initialized
INFO - 2016-03-07 14:13:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:13:10 --> Controller Class Initialized
INFO - 2016-03-07 14:13:10 --> Model Class Initialized
INFO - 2016-03-07 14:13:10 --> Model Class Initialized
INFO - 2016-03-07 14:13:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:13:10 --> Pagination Class Initialized
INFO - 2016-03-07 14:13:10 --> Helper loaded: text_helper
INFO - 2016-03-07 14:13:10 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:13:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:13:10 --> Final output sent to browser
DEBUG - 2016-03-07 17:13:10 --> Total execution time: 1.1353
INFO - 2016-03-07 14:13:15 --> Config Class Initialized
INFO - 2016-03-07 14:13:15 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:13:15 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:13:15 --> Utf8 Class Initialized
INFO - 2016-03-07 14:13:15 --> URI Class Initialized
INFO - 2016-03-07 14:13:15 --> Router Class Initialized
INFO - 2016-03-07 14:13:15 --> Output Class Initialized
INFO - 2016-03-07 14:13:15 --> Security Class Initialized
DEBUG - 2016-03-07 14:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:13:15 --> Input Class Initialized
INFO - 2016-03-07 14:13:15 --> Language Class Initialized
INFO - 2016-03-07 14:13:15 --> Loader Class Initialized
INFO - 2016-03-07 14:13:15 --> Helper loaded: url_helper
INFO - 2016-03-07 14:13:15 --> Helper loaded: file_helper
INFO - 2016-03-07 14:13:15 --> Helper loaded: date_helper
INFO - 2016-03-07 14:13:15 --> Helper loaded: form_helper
INFO - 2016-03-07 14:13:15 --> Database Driver Class Initialized
INFO - 2016-03-07 14:13:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:13:16 --> Controller Class Initialized
INFO - 2016-03-07 14:13:16 --> Model Class Initialized
INFO - 2016-03-07 14:13:16 --> Model Class Initialized
INFO - 2016-03-07 14:13:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:13:16 --> Pagination Class Initialized
INFO - 2016-03-07 14:13:16 --> Helper loaded: text_helper
INFO - 2016-03-07 14:13:16 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 17:13:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:13:16 --> Final output sent to browser
DEBUG - 2016-03-07 17:13:16 --> Total execution time: 1.1513
INFO - 2016-03-07 14:16:29 --> Config Class Initialized
INFO - 2016-03-07 14:16:29 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:16:29 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:16:29 --> Utf8 Class Initialized
INFO - 2016-03-07 14:16:29 --> URI Class Initialized
INFO - 2016-03-07 14:16:29 --> Router Class Initialized
INFO - 2016-03-07 14:16:29 --> Output Class Initialized
INFO - 2016-03-07 14:16:29 --> Security Class Initialized
DEBUG - 2016-03-07 14:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:16:29 --> Input Class Initialized
INFO - 2016-03-07 14:16:29 --> Language Class Initialized
INFO - 2016-03-07 14:16:29 --> Loader Class Initialized
INFO - 2016-03-07 14:16:29 --> Helper loaded: url_helper
INFO - 2016-03-07 14:16:29 --> Helper loaded: file_helper
INFO - 2016-03-07 14:16:29 --> Helper loaded: date_helper
INFO - 2016-03-07 14:16:29 --> Helper loaded: form_helper
INFO - 2016-03-07 14:16:29 --> Database Driver Class Initialized
INFO - 2016-03-07 14:16:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:16:30 --> Controller Class Initialized
INFO - 2016-03-07 14:16:30 --> Model Class Initialized
INFO - 2016-03-07 14:16:30 --> Model Class Initialized
INFO - 2016-03-07 14:16:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:16:30 --> Pagination Class Initialized
INFO - 2016-03-07 14:16:30 --> Helper loaded: text_helper
INFO - 2016-03-07 14:16:30 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 17:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 17:16:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:16:30 --> Final output sent to browser
DEBUG - 2016-03-07 17:16:30 --> Total execution time: 1.2188
INFO - 2016-03-07 14:17:20 --> Config Class Initialized
INFO - 2016-03-07 14:17:20 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:17:20 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:17:20 --> Utf8 Class Initialized
INFO - 2016-03-07 14:17:20 --> URI Class Initialized
INFO - 2016-03-07 14:17:20 --> Router Class Initialized
INFO - 2016-03-07 14:17:20 --> Output Class Initialized
INFO - 2016-03-07 14:17:20 --> Security Class Initialized
DEBUG - 2016-03-07 14:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:17:20 --> Input Class Initialized
INFO - 2016-03-07 14:17:20 --> Language Class Initialized
INFO - 2016-03-07 14:17:20 --> Loader Class Initialized
INFO - 2016-03-07 14:17:20 --> Helper loaded: url_helper
INFO - 2016-03-07 14:17:20 --> Helper loaded: file_helper
INFO - 2016-03-07 14:17:20 --> Helper loaded: date_helper
INFO - 2016-03-07 14:17:20 --> Helper loaded: form_helper
INFO - 2016-03-07 14:17:20 --> Database Driver Class Initialized
INFO - 2016-03-07 14:17:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:17:21 --> Controller Class Initialized
INFO - 2016-03-07 14:17:21 --> Model Class Initialized
INFO - 2016-03-07 14:17:21 --> Model Class Initialized
INFO - 2016-03-07 14:17:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:17:21 --> Pagination Class Initialized
INFO - 2016-03-07 14:17:21 --> Helper loaded: text_helper
INFO - 2016-03-07 14:17:21 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 17:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 17:17:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:17:21 --> Final output sent to browser
DEBUG - 2016-03-07 17:17:21 --> Total execution time: 1.1947
INFO - 2016-03-07 14:17:29 --> Config Class Initialized
INFO - 2016-03-07 14:17:29 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:17:29 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:17:29 --> Utf8 Class Initialized
INFO - 2016-03-07 14:17:29 --> URI Class Initialized
DEBUG - 2016-03-07 14:17:29 --> No URI present. Default controller set.
INFO - 2016-03-07 14:17:29 --> Router Class Initialized
INFO - 2016-03-07 14:17:29 --> Output Class Initialized
INFO - 2016-03-07 14:17:29 --> Security Class Initialized
DEBUG - 2016-03-07 14:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:17:29 --> Input Class Initialized
INFO - 2016-03-07 14:17:29 --> Language Class Initialized
INFO - 2016-03-07 14:17:29 --> Loader Class Initialized
INFO - 2016-03-07 14:17:29 --> Helper loaded: url_helper
INFO - 2016-03-07 14:17:29 --> Helper loaded: file_helper
INFO - 2016-03-07 14:17:29 --> Helper loaded: date_helper
INFO - 2016-03-07 14:17:29 --> Helper loaded: form_helper
INFO - 2016-03-07 14:17:29 --> Database Driver Class Initialized
INFO - 2016-03-07 14:17:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:17:30 --> Controller Class Initialized
INFO - 2016-03-07 14:17:30 --> Model Class Initialized
INFO - 2016-03-07 14:17:30 --> Model Class Initialized
INFO - 2016-03-07 14:17:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:17:30 --> Pagination Class Initialized
INFO - 2016-03-07 14:17:30 --> Helper loaded: text_helper
INFO - 2016-03-07 14:17:30 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 17:17:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:17:30 --> Final output sent to browser
DEBUG - 2016-03-07 17:17:30 --> Total execution time: 1.1413
INFO - 2016-03-07 14:24:59 --> Config Class Initialized
INFO - 2016-03-07 14:24:59 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:24:59 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:24:59 --> Utf8 Class Initialized
INFO - 2016-03-07 14:24:59 --> URI Class Initialized
INFO - 2016-03-07 14:24:59 --> Router Class Initialized
INFO - 2016-03-07 14:24:59 --> Output Class Initialized
INFO - 2016-03-07 14:24:59 --> Security Class Initialized
DEBUG - 2016-03-07 14:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:24:59 --> Input Class Initialized
INFO - 2016-03-07 14:24:59 --> Language Class Initialized
INFO - 2016-03-07 14:24:59 --> Loader Class Initialized
INFO - 2016-03-07 14:24:59 --> Helper loaded: url_helper
INFO - 2016-03-07 14:24:59 --> Helper loaded: file_helper
INFO - 2016-03-07 14:24:59 --> Helper loaded: date_helper
INFO - 2016-03-07 14:24:59 --> Helper loaded: form_helper
INFO - 2016-03-07 14:24:59 --> Database Driver Class Initialized
INFO - 2016-03-07 14:25:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:25:00 --> Controller Class Initialized
INFO - 2016-03-07 14:25:00 --> Model Class Initialized
INFO - 2016-03-07 14:25:00 --> Model Class Initialized
INFO - 2016-03-07 14:25:00 --> Form Validation Class Initialized
INFO - 2016-03-07 14:25:00 --> Helper loaded: text_helper
INFO - 2016-03-07 14:25:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-07 14:25:00 --> Unable to find callback validation rule: getByEmail
ERROR - 2016-03-07 14:25:00 --> Could not find the language line "form_validation_getByEmail"
INFO - 2016-03-07 14:25:00 --> Final output sent to browser
DEBUG - 2016-03-07 14:25:00 --> Total execution time: 1.1731
INFO - 2016-03-07 14:28:05 --> Config Class Initialized
INFO - 2016-03-07 14:28:05 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:28:05 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:28:05 --> Utf8 Class Initialized
INFO - 2016-03-07 14:28:05 --> URI Class Initialized
DEBUG - 2016-03-07 14:28:05 --> No URI present. Default controller set.
INFO - 2016-03-07 14:28:05 --> Router Class Initialized
INFO - 2016-03-07 14:28:05 --> Output Class Initialized
INFO - 2016-03-07 14:28:05 --> Security Class Initialized
DEBUG - 2016-03-07 14:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:28:05 --> Input Class Initialized
INFO - 2016-03-07 14:28:05 --> Language Class Initialized
INFO - 2016-03-07 14:28:05 --> Loader Class Initialized
INFO - 2016-03-07 14:28:05 --> Helper loaded: url_helper
INFO - 2016-03-07 14:28:05 --> Helper loaded: file_helper
INFO - 2016-03-07 14:28:05 --> Helper loaded: date_helper
INFO - 2016-03-07 14:28:05 --> Helper loaded: form_helper
INFO - 2016-03-07 14:28:05 --> Database Driver Class Initialized
INFO - 2016-03-07 14:28:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:28:06 --> Controller Class Initialized
INFO - 2016-03-07 14:28:06 --> Model Class Initialized
INFO - 2016-03-07 14:28:06 --> Model Class Initialized
INFO - 2016-03-07 14:28:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:28:06 --> Pagination Class Initialized
INFO - 2016-03-07 14:28:06 --> Helper loaded: text_helper
INFO - 2016-03-07 14:28:06 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 17:28:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:28:06 --> Final output sent to browser
DEBUG - 2016-03-07 17:28:06 --> Total execution time: 1.1430
INFO - 2016-03-07 14:28:27 --> Config Class Initialized
INFO - 2016-03-07 14:28:27 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:28:27 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:28:27 --> Utf8 Class Initialized
INFO - 2016-03-07 14:28:27 --> URI Class Initialized
INFO - 2016-03-07 14:28:27 --> Router Class Initialized
INFO - 2016-03-07 14:28:27 --> Output Class Initialized
INFO - 2016-03-07 14:28:27 --> Security Class Initialized
DEBUG - 2016-03-07 14:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:28:27 --> Input Class Initialized
INFO - 2016-03-07 14:28:27 --> Language Class Initialized
INFO - 2016-03-07 14:28:27 --> Loader Class Initialized
INFO - 2016-03-07 14:28:27 --> Helper loaded: url_helper
INFO - 2016-03-07 14:28:27 --> Helper loaded: file_helper
INFO - 2016-03-07 14:28:27 --> Helper loaded: date_helper
INFO - 2016-03-07 14:28:27 --> Helper loaded: form_helper
INFO - 2016-03-07 14:28:27 --> Database Driver Class Initialized
INFO - 2016-03-07 14:28:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:28:28 --> Controller Class Initialized
INFO - 2016-03-07 14:28:28 --> Model Class Initialized
INFO - 2016-03-07 14:28:28 --> Model Class Initialized
INFO - 2016-03-07 14:28:28 --> Form Validation Class Initialized
INFO - 2016-03-07 14:28:28 --> Helper loaded: text_helper
INFO - 2016-03-07 14:28:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-07 14:28:28 --> Unable to find callback validation rule: getByEmail
ERROR - 2016-03-07 14:28:28 --> Could not find the language line "form_validation_getByEmail"
INFO - 2016-03-07 14:28:28 --> Final output sent to browser
DEBUG - 2016-03-07 14:28:28 --> Total execution time: 1.1339
INFO - 2016-03-07 14:29:32 --> Config Class Initialized
INFO - 2016-03-07 14:29:32 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:29:32 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:29:32 --> Utf8 Class Initialized
INFO - 2016-03-07 14:29:32 --> URI Class Initialized
DEBUG - 2016-03-07 14:29:32 --> No URI present. Default controller set.
INFO - 2016-03-07 14:29:32 --> Router Class Initialized
INFO - 2016-03-07 14:29:32 --> Output Class Initialized
INFO - 2016-03-07 14:29:32 --> Security Class Initialized
DEBUG - 2016-03-07 14:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:29:32 --> Input Class Initialized
INFO - 2016-03-07 14:29:32 --> Language Class Initialized
INFO - 2016-03-07 14:29:32 --> Loader Class Initialized
INFO - 2016-03-07 14:29:32 --> Helper loaded: url_helper
INFO - 2016-03-07 14:29:32 --> Helper loaded: file_helper
INFO - 2016-03-07 14:29:32 --> Helper loaded: date_helper
INFO - 2016-03-07 14:29:32 --> Helper loaded: form_helper
INFO - 2016-03-07 14:29:32 --> Database Driver Class Initialized
INFO - 2016-03-07 14:29:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:29:33 --> Controller Class Initialized
INFO - 2016-03-07 14:29:33 --> Model Class Initialized
INFO - 2016-03-07 14:29:33 --> Model Class Initialized
INFO - 2016-03-07 14:29:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:29:33 --> Pagination Class Initialized
INFO - 2016-03-07 14:29:33 --> Helper loaded: text_helper
INFO - 2016-03-07 14:29:33 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:29:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:29:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:29:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 17:29:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:29:33 --> Final output sent to browser
DEBUG - 2016-03-07 17:29:33 --> Total execution time: 1.2148
INFO - 2016-03-07 14:29:53 --> Config Class Initialized
INFO - 2016-03-07 14:29:53 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:29:53 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:29:53 --> Utf8 Class Initialized
INFO - 2016-03-07 14:29:53 --> URI Class Initialized
INFO - 2016-03-07 14:29:53 --> Router Class Initialized
INFO - 2016-03-07 14:29:53 --> Output Class Initialized
INFO - 2016-03-07 14:29:53 --> Security Class Initialized
DEBUG - 2016-03-07 14:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:29:53 --> Input Class Initialized
INFO - 2016-03-07 14:29:53 --> Language Class Initialized
INFO - 2016-03-07 14:29:53 --> Loader Class Initialized
INFO - 2016-03-07 14:29:53 --> Helper loaded: url_helper
INFO - 2016-03-07 14:29:53 --> Helper loaded: file_helper
INFO - 2016-03-07 14:29:53 --> Helper loaded: date_helper
INFO - 2016-03-07 14:29:53 --> Helper loaded: form_helper
INFO - 2016-03-07 14:29:53 --> Database Driver Class Initialized
INFO - 2016-03-07 14:29:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:29:55 --> Controller Class Initialized
INFO - 2016-03-07 14:29:55 --> Model Class Initialized
INFO - 2016-03-07 14:29:55 --> Model Class Initialized
INFO - 2016-03-07 14:29:55 --> Form Validation Class Initialized
INFO - 2016-03-07 14:29:55 --> Helper loaded: text_helper
INFO - 2016-03-07 14:29:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-07 14:29:55 --> Unable to find callback validation rule: getByEmail
ERROR - 2016-03-07 14:29:55 --> Could not find the language line "form_validation_getByEmail"
INFO - 2016-03-07 14:29:55 --> Final output sent to browser
DEBUG - 2016-03-07 14:29:55 --> Total execution time: 1.1574
INFO - 2016-03-07 14:30:49 --> Config Class Initialized
INFO - 2016-03-07 14:30:49 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:30:49 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:30:49 --> Utf8 Class Initialized
INFO - 2016-03-07 14:30:49 --> URI Class Initialized
DEBUG - 2016-03-07 14:30:49 --> No URI present. Default controller set.
INFO - 2016-03-07 14:30:49 --> Router Class Initialized
INFO - 2016-03-07 14:30:49 --> Output Class Initialized
INFO - 2016-03-07 14:30:49 --> Security Class Initialized
DEBUG - 2016-03-07 14:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:30:49 --> Input Class Initialized
INFO - 2016-03-07 14:30:49 --> Language Class Initialized
INFO - 2016-03-07 14:30:49 --> Loader Class Initialized
INFO - 2016-03-07 14:30:49 --> Helper loaded: url_helper
INFO - 2016-03-07 14:30:49 --> Helper loaded: file_helper
INFO - 2016-03-07 14:30:49 --> Helper loaded: date_helper
INFO - 2016-03-07 14:30:49 --> Helper loaded: form_helper
INFO - 2016-03-07 14:30:49 --> Database Driver Class Initialized
INFO - 2016-03-07 14:30:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:30:50 --> Controller Class Initialized
INFO - 2016-03-07 14:30:50 --> Model Class Initialized
INFO - 2016-03-07 14:30:50 --> Model Class Initialized
INFO - 2016-03-07 14:30:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:30:50 --> Pagination Class Initialized
INFO - 2016-03-07 14:30:50 --> Helper loaded: text_helper
INFO - 2016-03-07 14:30:50 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 17:30:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:30:50 --> Final output sent to browser
DEBUG - 2016-03-07 17:30:50 --> Total execution time: 1.1661
INFO - 2016-03-07 14:31:07 --> Config Class Initialized
INFO - 2016-03-07 14:31:07 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:31:07 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:31:07 --> Utf8 Class Initialized
INFO - 2016-03-07 14:31:07 --> URI Class Initialized
INFO - 2016-03-07 14:31:07 --> Router Class Initialized
INFO - 2016-03-07 14:31:07 --> Output Class Initialized
INFO - 2016-03-07 14:31:07 --> Security Class Initialized
DEBUG - 2016-03-07 14:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:31:07 --> Input Class Initialized
INFO - 2016-03-07 14:31:07 --> Language Class Initialized
INFO - 2016-03-07 14:31:07 --> Loader Class Initialized
INFO - 2016-03-07 14:31:07 --> Helper loaded: url_helper
INFO - 2016-03-07 14:31:07 --> Helper loaded: file_helper
INFO - 2016-03-07 14:31:07 --> Helper loaded: date_helper
INFO - 2016-03-07 14:31:07 --> Helper loaded: form_helper
INFO - 2016-03-07 14:31:07 --> Database Driver Class Initialized
INFO - 2016-03-07 14:31:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:31:08 --> Controller Class Initialized
INFO - 2016-03-07 14:31:08 --> Model Class Initialized
INFO - 2016-03-07 14:31:08 --> Model Class Initialized
INFO - 2016-03-07 14:31:08 --> Form Validation Class Initialized
INFO - 2016-03-07 14:31:08 --> Helper loaded: text_helper
INFO - 2016-03-07 14:31:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-07 14:31:08 --> Unable to find callback validation rule: getByEmail
ERROR - 2016-03-07 14:31:08 --> Could not find the language line "form_validation_getByEmail"
INFO - 2016-03-07 14:31:08 --> Final output sent to browser
DEBUG - 2016-03-07 14:31:08 --> Total execution time: 1.1310
INFO - 2016-03-07 14:32:36 --> Config Class Initialized
INFO - 2016-03-07 14:32:36 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:32:36 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:32:36 --> Utf8 Class Initialized
INFO - 2016-03-07 14:32:36 --> URI Class Initialized
DEBUG - 2016-03-07 14:32:36 --> No URI present. Default controller set.
INFO - 2016-03-07 14:32:36 --> Router Class Initialized
INFO - 2016-03-07 14:32:36 --> Output Class Initialized
INFO - 2016-03-07 14:32:36 --> Security Class Initialized
DEBUG - 2016-03-07 14:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:32:36 --> Input Class Initialized
INFO - 2016-03-07 14:32:36 --> Language Class Initialized
INFO - 2016-03-07 14:32:36 --> Loader Class Initialized
INFO - 2016-03-07 14:32:36 --> Helper loaded: url_helper
INFO - 2016-03-07 14:32:36 --> Helper loaded: file_helper
INFO - 2016-03-07 14:32:36 --> Helper loaded: date_helper
INFO - 2016-03-07 14:32:36 --> Helper loaded: form_helper
INFO - 2016-03-07 14:32:36 --> Database Driver Class Initialized
INFO - 2016-03-07 14:32:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:32:37 --> Controller Class Initialized
INFO - 2016-03-07 14:32:37 --> Model Class Initialized
INFO - 2016-03-07 14:32:37 --> Model Class Initialized
INFO - 2016-03-07 14:32:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:32:37 --> Pagination Class Initialized
INFO - 2016-03-07 14:32:37 --> Helper loaded: text_helper
INFO - 2016-03-07 14:32:37 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 17:32:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:32:37 --> Final output sent to browser
DEBUG - 2016-03-07 17:32:37 --> Total execution time: 1.1287
INFO - 2016-03-07 14:33:00 --> Config Class Initialized
INFO - 2016-03-07 14:33:00 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:33:00 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:33:00 --> Utf8 Class Initialized
INFO - 2016-03-07 14:33:00 --> URI Class Initialized
INFO - 2016-03-07 14:33:00 --> Router Class Initialized
INFO - 2016-03-07 14:33:00 --> Output Class Initialized
INFO - 2016-03-07 14:33:00 --> Security Class Initialized
DEBUG - 2016-03-07 14:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:33:00 --> Input Class Initialized
INFO - 2016-03-07 14:33:00 --> Language Class Initialized
INFO - 2016-03-07 14:33:00 --> Loader Class Initialized
INFO - 2016-03-07 14:33:00 --> Helper loaded: url_helper
INFO - 2016-03-07 14:33:00 --> Helper loaded: file_helper
INFO - 2016-03-07 14:33:00 --> Helper loaded: date_helper
INFO - 2016-03-07 14:33:00 --> Helper loaded: form_helper
INFO - 2016-03-07 14:33:00 --> Database Driver Class Initialized
INFO - 2016-03-07 14:33:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:33:01 --> Controller Class Initialized
INFO - 2016-03-07 14:33:01 --> Model Class Initialized
INFO - 2016-03-07 14:33:01 --> Model Class Initialized
INFO - 2016-03-07 14:33:01 --> Form Validation Class Initialized
INFO - 2016-03-07 14:33:01 --> Helper loaded: text_helper
INFO - 2016-03-07 14:33:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-07 14:33:01 --> Unable to find callback validation rule: getByEmail
ERROR - 2016-03-07 14:33:01 --> Could not find the language line "form_validation_getByEmail"
INFO - 2016-03-07 14:33:01 --> Final output sent to browser
DEBUG - 2016-03-07 14:33:01 --> Total execution time: 1.1479
INFO - 2016-03-07 14:35:14 --> Config Class Initialized
INFO - 2016-03-07 14:35:14 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:35:14 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:35:14 --> Utf8 Class Initialized
INFO - 2016-03-07 14:35:14 --> URI Class Initialized
DEBUG - 2016-03-07 14:35:14 --> No URI present. Default controller set.
INFO - 2016-03-07 14:35:14 --> Router Class Initialized
INFO - 2016-03-07 14:35:14 --> Output Class Initialized
INFO - 2016-03-07 14:35:14 --> Security Class Initialized
DEBUG - 2016-03-07 14:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:35:14 --> Input Class Initialized
INFO - 2016-03-07 14:35:14 --> Language Class Initialized
INFO - 2016-03-07 14:35:14 --> Loader Class Initialized
INFO - 2016-03-07 14:35:14 --> Helper loaded: url_helper
INFO - 2016-03-07 14:35:14 --> Helper loaded: file_helper
INFO - 2016-03-07 14:35:14 --> Helper loaded: date_helper
INFO - 2016-03-07 14:35:14 --> Helper loaded: form_helper
INFO - 2016-03-07 14:35:14 --> Database Driver Class Initialized
INFO - 2016-03-07 14:35:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:35:15 --> Controller Class Initialized
INFO - 2016-03-07 14:35:15 --> Model Class Initialized
INFO - 2016-03-07 14:35:15 --> Model Class Initialized
INFO - 2016-03-07 14:35:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:35:15 --> Pagination Class Initialized
INFO - 2016-03-07 14:35:15 --> Helper loaded: text_helper
INFO - 2016-03-07 14:35:15 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 17:35:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:35:15 --> Final output sent to browser
DEBUG - 2016-03-07 17:35:15 --> Total execution time: 1.1452
INFO - 2016-03-07 14:35:40 --> Config Class Initialized
INFO - 2016-03-07 14:35:40 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:35:40 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:35:40 --> Utf8 Class Initialized
INFO - 2016-03-07 14:35:40 --> URI Class Initialized
INFO - 2016-03-07 14:35:40 --> Router Class Initialized
INFO - 2016-03-07 14:35:40 --> Output Class Initialized
INFO - 2016-03-07 14:35:40 --> Security Class Initialized
DEBUG - 2016-03-07 14:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:35:40 --> Input Class Initialized
INFO - 2016-03-07 14:35:40 --> Language Class Initialized
INFO - 2016-03-07 14:35:40 --> Loader Class Initialized
INFO - 2016-03-07 14:35:40 --> Helper loaded: url_helper
INFO - 2016-03-07 14:35:40 --> Helper loaded: file_helper
INFO - 2016-03-07 14:35:40 --> Helper loaded: date_helper
INFO - 2016-03-07 14:35:40 --> Helper loaded: form_helper
INFO - 2016-03-07 14:35:40 --> Database Driver Class Initialized
INFO - 2016-03-07 14:35:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:35:41 --> Controller Class Initialized
INFO - 2016-03-07 14:35:41 --> Model Class Initialized
INFO - 2016-03-07 14:35:41 --> Model Class Initialized
INFO - 2016-03-07 14:35:41 --> Form Validation Class Initialized
INFO - 2016-03-07 14:35:41 --> Helper loaded: text_helper
INFO - 2016-03-07 14:35:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-07 14:35:41 --> Unable to find callback validation rule: getByEmail
ERROR - 2016-03-07 14:35:41 --> Could not find the language line "form_validation_getByEmail"
INFO - 2016-03-07 14:35:41 --> Final output sent to browser
DEBUG - 2016-03-07 14:35:41 --> Total execution time: 1.1421
INFO - 2016-03-07 14:37:45 --> Config Class Initialized
INFO - 2016-03-07 14:37:45 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:37:45 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:37:45 --> Utf8 Class Initialized
INFO - 2016-03-07 14:37:45 --> URI Class Initialized
DEBUG - 2016-03-07 14:37:45 --> No URI present. Default controller set.
INFO - 2016-03-07 14:37:45 --> Router Class Initialized
INFO - 2016-03-07 14:37:45 --> Output Class Initialized
INFO - 2016-03-07 14:37:45 --> Security Class Initialized
DEBUG - 2016-03-07 14:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:37:45 --> Input Class Initialized
INFO - 2016-03-07 14:37:45 --> Language Class Initialized
INFO - 2016-03-07 14:37:45 --> Loader Class Initialized
INFO - 2016-03-07 14:37:45 --> Helper loaded: url_helper
INFO - 2016-03-07 14:37:45 --> Helper loaded: file_helper
INFO - 2016-03-07 14:37:45 --> Helper loaded: date_helper
INFO - 2016-03-07 14:37:45 --> Helper loaded: form_helper
INFO - 2016-03-07 14:37:45 --> Database Driver Class Initialized
INFO - 2016-03-07 14:37:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:37:46 --> Controller Class Initialized
INFO - 2016-03-07 14:37:46 --> Model Class Initialized
INFO - 2016-03-07 14:37:46 --> Model Class Initialized
INFO - 2016-03-07 14:37:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:37:46 --> Pagination Class Initialized
INFO - 2016-03-07 14:37:46 --> Helper loaded: text_helper
INFO - 2016-03-07 14:37:46 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-07 17:37:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:37:46 --> Final output sent to browser
DEBUG - 2016-03-07 17:37:46 --> Total execution time: 1.1420
INFO - 2016-03-07 14:38:04 --> Config Class Initialized
INFO - 2016-03-07 14:38:04 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:38:04 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:38:04 --> Utf8 Class Initialized
INFO - 2016-03-07 14:38:04 --> URI Class Initialized
INFO - 2016-03-07 14:38:04 --> Router Class Initialized
INFO - 2016-03-07 14:38:04 --> Output Class Initialized
INFO - 2016-03-07 14:38:04 --> Security Class Initialized
DEBUG - 2016-03-07 14:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:38:04 --> Input Class Initialized
INFO - 2016-03-07 14:38:04 --> Language Class Initialized
INFO - 2016-03-07 14:38:04 --> Loader Class Initialized
INFO - 2016-03-07 14:38:05 --> Helper loaded: url_helper
INFO - 2016-03-07 14:38:05 --> Helper loaded: file_helper
INFO - 2016-03-07 14:38:05 --> Helper loaded: date_helper
INFO - 2016-03-07 14:38:05 --> Helper loaded: form_helper
INFO - 2016-03-07 14:38:05 --> Database Driver Class Initialized
INFO - 2016-03-07 14:38:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:38:06 --> Controller Class Initialized
INFO - 2016-03-07 14:38:06 --> Model Class Initialized
INFO - 2016-03-07 14:38:06 --> Model Class Initialized
INFO - 2016-03-07 14:38:06 --> Form Validation Class Initialized
INFO - 2016-03-07 14:38:06 --> Helper loaded: text_helper
INFO - 2016-03-07 14:38:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-03-07 14:38:06 --> Unable to find callback validation rule: getByEmail
INFO - 2016-03-07 14:38:06 --> Final output sent to browser
DEBUG - 2016-03-07 14:38:06 --> Total execution time: 1.1221
INFO - 2016-03-07 14:38:39 --> Config Class Initialized
INFO - 2016-03-07 14:38:39 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:38:39 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:38:39 --> Utf8 Class Initialized
INFO - 2016-03-07 14:38:39 --> URI Class Initialized
INFO - 2016-03-07 14:38:39 --> Router Class Initialized
INFO - 2016-03-07 14:38:39 --> Output Class Initialized
INFO - 2016-03-07 14:38:39 --> Security Class Initialized
DEBUG - 2016-03-07 14:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:38:39 --> Input Class Initialized
INFO - 2016-03-07 14:38:39 --> Language Class Initialized
INFO - 2016-03-07 14:38:39 --> Loader Class Initialized
INFO - 2016-03-07 14:38:39 --> Helper loaded: url_helper
INFO - 2016-03-07 14:38:39 --> Helper loaded: file_helper
INFO - 2016-03-07 14:38:39 --> Helper loaded: date_helper
INFO - 2016-03-07 14:38:39 --> Helper loaded: form_helper
INFO - 2016-03-07 14:38:39 --> Database Driver Class Initialized
INFO - 2016-03-07 14:38:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:38:40 --> Controller Class Initialized
INFO - 2016-03-07 14:38:40 --> Model Class Initialized
INFO - 2016-03-07 14:38:40 --> Model Class Initialized
INFO - 2016-03-07 14:38:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:38:40 --> Pagination Class Initialized
INFO - 2016-03-07 14:38:40 --> Helper loaded: text_helper
INFO - 2016-03-07 14:38:40 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:38:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:38:40 --> Final output sent to browser
DEBUG - 2016-03-07 17:38:40 --> Total execution time: 1.1800
INFO - 2016-03-07 14:39:42 --> Config Class Initialized
INFO - 2016-03-07 14:39:42 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:39:42 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:39:42 --> Utf8 Class Initialized
INFO - 2016-03-07 14:39:42 --> URI Class Initialized
INFO - 2016-03-07 14:39:42 --> Router Class Initialized
INFO - 2016-03-07 14:39:42 --> Output Class Initialized
INFO - 2016-03-07 14:39:42 --> Security Class Initialized
DEBUG - 2016-03-07 14:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:39:42 --> Input Class Initialized
INFO - 2016-03-07 14:39:42 --> Language Class Initialized
INFO - 2016-03-07 14:39:42 --> Loader Class Initialized
INFO - 2016-03-07 14:39:42 --> Helper loaded: url_helper
INFO - 2016-03-07 14:39:42 --> Helper loaded: file_helper
INFO - 2016-03-07 14:39:42 --> Helper loaded: date_helper
INFO - 2016-03-07 14:39:42 --> Helper loaded: form_helper
INFO - 2016-03-07 14:39:42 --> Database Driver Class Initialized
INFO - 2016-03-07 14:39:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:39:43 --> Controller Class Initialized
INFO - 2016-03-07 14:39:43 --> Model Class Initialized
INFO - 2016-03-07 14:39:43 --> Model Class Initialized
INFO - 2016-03-07 14:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:39:43 --> Pagination Class Initialized
INFO - 2016-03-07 14:39:43 --> Helper loaded: text_helper
INFO - 2016-03-07 14:39:43 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:39:43 --> Final output sent to browser
DEBUG - 2016-03-07 17:39:43 --> Total execution time: 1.1348
INFO - 2016-03-07 14:40:50 --> Config Class Initialized
INFO - 2016-03-07 14:40:50 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:40:50 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:40:50 --> Utf8 Class Initialized
INFO - 2016-03-07 14:40:50 --> URI Class Initialized
INFO - 2016-03-07 14:40:50 --> Router Class Initialized
INFO - 2016-03-07 14:40:50 --> Output Class Initialized
INFO - 2016-03-07 14:40:50 --> Security Class Initialized
DEBUG - 2016-03-07 14:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:40:50 --> Input Class Initialized
INFO - 2016-03-07 14:40:50 --> Language Class Initialized
INFO - 2016-03-07 14:40:50 --> Loader Class Initialized
INFO - 2016-03-07 14:40:50 --> Helper loaded: url_helper
INFO - 2016-03-07 14:40:50 --> Helper loaded: file_helper
INFO - 2016-03-07 14:40:50 --> Helper loaded: date_helper
INFO - 2016-03-07 14:40:50 --> Helper loaded: form_helper
INFO - 2016-03-07 14:40:50 --> Database Driver Class Initialized
INFO - 2016-03-07 14:40:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:40:51 --> Controller Class Initialized
INFO - 2016-03-07 14:40:51 --> Model Class Initialized
INFO - 2016-03-07 14:40:51 --> Model Class Initialized
INFO - 2016-03-07 14:40:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:40:51 --> Pagination Class Initialized
INFO - 2016-03-07 14:40:51 --> Helper loaded: text_helper
INFO - 2016-03-07 14:40:51 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:40:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:40:51 --> Final output sent to browser
DEBUG - 2016-03-07 17:40:51 --> Total execution time: 1.1389
INFO - 2016-03-07 14:40:54 --> Config Class Initialized
INFO - 2016-03-07 14:40:54 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:40:54 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:40:54 --> Utf8 Class Initialized
INFO - 2016-03-07 14:40:54 --> URI Class Initialized
INFO - 2016-03-07 14:40:54 --> Router Class Initialized
INFO - 2016-03-07 14:40:54 --> Output Class Initialized
INFO - 2016-03-07 14:40:54 --> Security Class Initialized
DEBUG - 2016-03-07 14:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:40:54 --> Input Class Initialized
INFO - 2016-03-07 14:40:54 --> Language Class Initialized
INFO - 2016-03-07 14:40:54 --> Loader Class Initialized
INFO - 2016-03-07 14:40:54 --> Helper loaded: url_helper
INFO - 2016-03-07 14:40:54 --> Helper loaded: file_helper
INFO - 2016-03-07 14:40:54 --> Helper loaded: date_helper
INFO - 2016-03-07 14:40:54 --> Helper loaded: form_helper
INFO - 2016-03-07 14:40:54 --> Database Driver Class Initialized
INFO - 2016-03-07 14:40:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:40:55 --> Controller Class Initialized
INFO - 2016-03-07 14:40:55 --> Model Class Initialized
INFO - 2016-03-07 14:40:55 --> Model Class Initialized
INFO - 2016-03-07 14:40:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:40:55 --> Pagination Class Initialized
INFO - 2016-03-07 14:40:55 --> Helper loaded: text_helper
INFO - 2016-03-07 14:40:55 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\thumbnail.php
INFO - 2016-03-07 17:40:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:40:55 --> Final output sent to browser
DEBUG - 2016-03-07 17:40:55 --> Total execution time: 1.1452
INFO - 2016-03-07 14:40:58 --> Config Class Initialized
INFO - 2016-03-07 14:40:58 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:40:58 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:40:58 --> Utf8 Class Initialized
INFO - 2016-03-07 14:40:58 --> URI Class Initialized
INFO - 2016-03-07 14:40:58 --> Router Class Initialized
INFO - 2016-03-07 14:40:58 --> Output Class Initialized
INFO - 2016-03-07 14:40:58 --> Security Class Initialized
DEBUG - 2016-03-07 14:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:40:58 --> Input Class Initialized
INFO - 2016-03-07 14:40:58 --> Language Class Initialized
INFO - 2016-03-07 14:40:58 --> Loader Class Initialized
INFO - 2016-03-07 14:40:58 --> Helper loaded: url_helper
INFO - 2016-03-07 14:40:58 --> Helper loaded: file_helper
INFO - 2016-03-07 14:40:58 --> Helper loaded: date_helper
INFO - 2016-03-07 14:40:58 --> Helper loaded: form_helper
INFO - 2016-03-07 14:40:58 --> Database Driver Class Initialized
INFO - 2016-03-07 14:40:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:40:59 --> Controller Class Initialized
INFO - 2016-03-07 14:40:59 --> Model Class Initialized
INFO - 2016-03-07 14:40:59 --> Model Class Initialized
INFO - 2016-03-07 14:40:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:40:59 --> Pagination Class Initialized
INFO - 2016-03-07 14:40:59 --> Helper loaded: text_helper
INFO - 2016-03-07 14:40:59 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:40:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:40:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:40:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:40:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:40:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:40:59 --> Final output sent to browser
DEBUG - 2016-03-07 17:40:59 --> Total execution time: 1.1578
INFO - 2016-03-07 14:41:53 --> Config Class Initialized
INFO - 2016-03-07 14:41:53 --> Hooks Class Initialized
DEBUG - 2016-03-07 14:41:53 --> UTF-8 Support Enabled
INFO - 2016-03-07 14:41:53 --> Utf8 Class Initialized
INFO - 2016-03-07 14:41:53 --> URI Class Initialized
INFO - 2016-03-07 14:41:53 --> Router Class Initialized
INFO - 2016-03-07 14:41:53 --> Output Class Initialized
INFO - 2016-03-07 14:41:53 --> Security Class Initialized
DEBUG - 2016-03-07 14:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 14:41:53 --> Input Class Initialized
INFO - 2016-03-07 14:41:53 --> Language Class Initialized
INFO - 2016-03-07 14:41:53 --> Loader Class Initialized
INFO - 2016-03-07 14:41:53 --> Helper loaded: url_helper
INFO - 2016-03-07 14:41:53 --> Helper loaded: file_helper
INFO - 2016-03-07 14:41:53 --> Helper loaded: date_helper
INFO - 2016-03-07 14:41:53 --> Helper loaded: form_helper
INFO - 2016-03-07 14:41:53 --> Database Driver Class Initialized
INFO - 2016-03-07 14:41:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 14:41:54 --> Controller Class Initialized
INFO - 2016-03-07 14:41:54 --> Model Class Initialized
INFO - 2016-03-07 14:41:54 --> Model Class Initialized
INFO - 2016-03-07 14:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 14:41:54 --> Pagination Class Initialized
INFO - 2016-03-07 14:41:54 --> Helper loaded: text_helper
INFO - 2016-03-07 14:41:54 --> Helper loaded: cookie_helper
INFO - 2016-03-07 17:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 17:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 17:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 17:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 17:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 17:41:54 --> Final output sent to browser
DEBUG - 2016-03-07 17:41:54 --> Total execution time: 1.1272
INFO - 2016-03-07 17:36:58 --> Config Class Initialized
INFO - 2016-03-07 17:36:58 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:36:58 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:36:58 --> Utf8 Class Initialized
INFO - 2016-03-07 17:36:58 --> URI Class Initialized
INFO - 2016-03-07 17:36:58 --> Router Class Initialized
INFO - 2016-03-07 17:36:58 --> Output Class Initialized
INFO - 2016-03-07 17:36:58 --> Security Class Initialized
DEBUG - 2016-03-07 17:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:36:58 --> Input Class Initialized
INFO - 2016-03-07 17:36:58 --> Language Class Initialized
INFO - 2016-03-07 17:36:58 --> Loader Class Initialized
INFO - 2016-03-07 17:36:58 --> Helper loaded: url_helper
INFO - 2016-03-07 17:36:58 --> Helper loaded: file_helper
INFO - 2016-03-07 17:36:58 --> Helper loaded: date_helper
INFO - 2016-03-07 17:36:58 --> Helper loaded: form_helper
INFO - 2016-03-07 17:36:58 --> Database Driver Class Initialized
INFO - 2016-03-07 17:36:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:36:59 --> Controller Class Initialized
INFO - 2016-03-07 17:36:59 --> Model Class Initialized
INFO - 2016-03-07 17:36:59 --> Model Class Initialized
INFO - 2016-03-07 17:36:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:36:59 --> Pagination Class Initialized
INFO - 2016-03-07 17:36:59 --> Helper loaded: text_helper
INFO - 2016-03-07 17:36:59 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:36:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:36:59 --> Final output sent to browser
DEBUG - 2016-03-07 20:36:59 --> Total execution time: 1.1346
INFO - 2016-03-07 17:37:11 --> Config Class Initialized
INFO - 2016-03-07 17:37:11 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:37:11 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:37:11 --> Utf8 Class Initialized
INFO - 2016-03-07 17:37:11 --> URI Class Initialized
INFO - 2016-03-07 17:37:11 --> Router Class Initialized
INFO - 2016-03-07 17:37:11 --> Output Class Initialized
INFO - 2016-03-07 17:37:11 --> Security Class Initialized
DEBUG - 2016-03-07 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:37:11 --> Input Class Initialized
INFO - 2016-03-07 17:37:11 --> Language Class Initialized
INFO - 2016-03-07 17:37:11 --> Loader Class Initialized
INFO - 2016-03-07 17:37:11 --> Helper loaded: url_helper
INFO - 2016-03-07 17:37:11 --> Helper loaded: file_helper
INFO - 2016-03-07 17:37:11 --> Helper loaded: date_helper
INFO - 2016-03-07 17:37:11 --> Helper loaded: form_helper
INFO - 2016-03-07 17:37:11 --> Database Driver Class Initialized
INFO - 2016-03-07 17:37:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:37:12 --> Controller Class Initialized
INFO - 2016-03-07 17:37:12 --> Model Class Initialized
INFO - 2016-03-07 17:37:12 --> Model Class Initialized
INFO - 2016-03-07 17:37:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:37:12 --> Pagination Class Initialized
INFO - 2016-03-07 17:37:12 --> Helper loaded: text_helper
INFO - 2016-03-07 17:37:12 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:37:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:37:12 --> Final output sent to browser
DEBUG - 2016-03-07 20:37:12 --> Total execution time: 1.1784
INFO - 2016-03-07 17:37:12 --> Config Class Initialized
INFO - 2016-03-07 17:37:12 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:37:12 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:37:12 --> Utf8 Class Initialized
INFO - 2016-03-07 17:37:12 --> URI Class Initialized
INFO - 2016-03-07 17:37:12 --> Router Class Initialized
INFO - 2016-03-07 17:37:12 --> Output Class Initialized
INFO - 2016-03-07 17:37:12 --> Security Class Initialized
DEBUG - 2016-03-07 17:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:37:12 --> Input Class Initialized
INFO - 2016-03-07 17:37:12 --> Language Class Initialized
INFO - 2016-03-07 17:37:12 --> Loader Class Initialized
INFO - 2016-03-07 17:37:12 --> Helper loaded: url_helper
INFO - 2016-03-07 17:37:12 --> Helper loaded: file_helper
INFO - 2016-03-07 17:37:12 --> Helper loaded: date_helper
INFO - 2016-03-07 17:37:12 --> Helper loaded: form_helper
INFO - 2016-03-07 17:37:12 --> Database Driver Class Initialized
INFO - 2016-03-07 17:37:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:37:14 --> Controller Class Initialized
INFO - 2016-03-07 17:37:14 --> User Agent Class Initialized
INFO - 2016-03-07 17:37:14 --> Final output sent to browser
DEBUG - 2016-03-07 17:37:14 --> Total execution time: 1.1149
INFO - 2016-03-07 17:38:09 --> Config Class Initialized
INFO - 2016-03-07 17:38:09 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:38:09 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:38:09 --> Utf8 Class Initialized
INFO - 2016-03-07 17:38:09 --> URI Class Initialized
INFO - 2016-03-07 17:38:09 --> Router Class Initialized
INFO - 2016-03-07 17:38:09 --> Output Class Initialized
INFO - 2016-03-07 17:38:09 --> Security Class Initialized
DEBUG - 2016-03-07 17:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:38:09 --> Input Class Initialized
INFO - 2016-03-07 17:38:09 --> Language Class Initialized
INFO - 2016-03-07 17:38:09 --> Loader Class Initialized
INFO - 2016-03-07 17:38:09 --> Helper loaded: url_helper
INFO - 2016-03-07 17:38:09 --> Helper loaded: file_helper
INFO - 2016-03-07 17:38:09 --> Helper loaded: date_helper
INFO - 2016-03-07 17:38:09 --> Helper loaded: form_helper
INFO - 2016-03-07 17:38:09 --> Database Driver Class Initialized
INFO - 2016-03-07 17:38:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:38:10 --> Controller Class Initialized
INFO - 2016-03-07 17:38:10 --> Model Class Initialized
INFO - 2016-03-07 17:38:10 --> Model Class Initialized
INFO - 2016-03-07 17:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:38:10 --> Pagination Class Initialized
INFO - 2016-03-07 17:38:10 --> Helper loaded: text_helper
INFO - 2016-03-07 17:38:10 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:38:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:38:10 --> Final output sent to browser
DEBUG - 2016-03-07 20:38:10 --> Total execution time: 1.2174
INFO - 2016-03-07 17:38:10 --> Config Class Initialized
INFO - 2016-03-07 17:38:10 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:38:10 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:38:10 --> Utf8 Class Initialized
INFO - 2016-03-07 17:38:10 --> URI Class Initialized
INFO - 2016-03-07 17:38:10 --> Router Class Initialized
INFO - 2016-03-07 17:38:10 --> Output Class Initialized
INFO - 2016-03-07 17:38:10 --> Security Class Initialized
DEBUG - 2016-03-07 17:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:38:10 --> Input Class Initialized
INFO - 2016-03-07 17:38:10 --> Language Class Initialized
INFO - 2016-03-07 17:38:10 --> Loader Class Initialized
INFO - 2016-03-07 17:38:10 --> Helper loaded: url_helper
INFO - 2016-03-07 17:38:10 --> Helper loaded: file_helper
INFO - 2016-03-07 17:38:10 --> Helper loaded: date_helper
INFO - 2016-03-07 17:38:10 --> Helper loaded: form_helper
INFO - 2016-03-07 17:38:10 --> Database Driver Class Initialized
INFO - 2016-03-07 17:38:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:38:11 --> Controller Class Initialized
INFO - 2016-03-07 17:38:11 --> User Agent Class Initialized
INFO - 2016-03-07 17:38:11 --> Final output sent to browser
DEBUG - 2016-03-07 17:38:11 --> Total execution time: 1.1065
INFO - 2016-03-07 17:38:29 --> Config Class Initialized
INFO - 2016-03-07 17:38:29 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:38:29 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:38:29 --> Utf8 Class Initialized
INFO - 2016-03-07 17:38:29 --> URI Class Initialized
INFO - 2016-03-07 17:38:29 --> Router Class Initialized
INFO - 2016-03-07 17:38:29 --> Output Class Initialized
INFO - 2016-03-07 17:38:29 --> Security Class Initialized
DEBUG - 2016-03-07 17:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:38:29 --> Input Class Initialized
INFO - 2016-03-07 17:38:29 --> Language Class Initialized
INFO - 2016-03-07 17:38:29 --> Loader Class Initialized
INFO - 2016-03-07 17:38:29 --> Helper loaded: url_helper
INFO - 2016-03-07 17:38:29 --> Helper loaded: file_helper
INFO - 2016-03-07 17:38:29 --> Helper loaded: date_helper
INFO - 2016-03-07 17:38:29 --> Helper loaded: form_helper
INFO - 2016-03-07 17:38:29 --> Database Driver Class Initialized
INFO - 2016-03-07 17:38:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:38:30 --> Controller Class Initialized
INFO - 2016-03-07 17:38:30 --> Model Class Initialized
INFO - 2016-03-07 17:38:30 --> Model Class Initialized
INFO - 2016-03-07 17:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:38:30 --> Pagination Class Initialized
INFO - 2016-03-07 17:38:30 --> Helper loaded: text_helper
INFO - 2016-03-07 17:38:30 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:38:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:38:30 --> Final output sent to browser
DEBUG - 2016-03-07 20:38:30 --> Total execution time: 1.1890
INFO - 2016-03-07 17:38:42 --> Config Class Initialized
INFO - 2016-03-07 17:38:42 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:38:42 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:38:42 --> Utf8 Class Initialized
INFO - 2016-03-07 17:38:42 --> URI Class Initialized
INFO - 2016-03-07 17:38:42 --> Router Class Initialized
INFO - 2016-03-07 17:38:42 --> Output Class Initialized
INFO - 2016-03-07 17:38:42 --> Security Class Initialized
DEBUG - 2016-03-07 17:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:38:42 --> Input Class Initialized
INFO - 2016-03-07 17:38:42 --> Language Class Initialized
INFO - 2016-03-07 17:38:42 --> Loader Class Initialized
INFO - 2016-03-07 17:38:42 --> Helper loaded: url_helper
INFO - 2016-03-07 17:38:42 --> Helper loaded: file_helper
INFO - 2016-03-07 17:38:42 --> Helper loaded: date_helper
INFO - 2016-03-07 17:38:42 --> Helper loaded: form_helper
INFO - 2016-03-07 17:38:42 --> Database Driver Class Initialized
INFO - 2016-03-07 17:38:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:38:43 --> Controller Class Initialized
INFO - 2016-03-07 17:38:43 --> Model Class Initialized
INFO - 2016-03-07 17:38:43 --> Model Class Initialized
INFO - 2016-03-07 17:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:38:43 --> Pagination Class Initialized
INFO - 2016-03-07 17:38:43 --> Helper loaded: text_helper
INFO - 2016-03-07 17:38:43 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:38:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:38:43 --> Final output sent to browser
DEBUG - 2016-03-07 20:38:43 --> Total execution time: 1.1791
INFO - 2016-03-07 17:39:39 --> Config Class Initialized
INFO - 2016-03-07 17:39:39 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:39:39 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:39:39 --> Utf8 Class Initialized
INFO - 2016-03-07 17:39:39 --> URI Class Initialized
INFO - 2016-03-07 17:39:39 --> Router Class Initialized
INFO - 2016-03-07 17:39:39 --> Output Class Initialized
INFO - 2016-03-07 17:39:39 --> Security Class Initialized
DEBUG - 2016-03-07 17:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:39:39 --> Input Class Initialized
INFO - 2016-03-07 17:39:39 --> Language Class Initialized
INFO - 2016-03-07 17:39:39 --> Loader Class Initialized
INFO - 2016-03-07 17:39:39 --> Helper loaded: url_helper
INFO - 2016-03-07 17:39:39 --> Helper loaded: file_helper
INFO - 2016-03-07 17:39:39 --> Helper loaded: date_helper
INFO - 2016-03-07 17:39:39 --> Helper loaded: form_helper
INFO - 2016-03-07 17:39:39 --> Database Driver Class Initialized
INFO - 2016-03-07 17:39:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:39:40 --> Controller Class Initialized
INFO - 2016-03-07 17:39:40 --> Model Class Initialized
INFO - 2016-03-07 17:39:40 --> Model Class Initialized
INFO - 2016-03-07 17:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:39:40 --> Pagination Class Initialized
INFO - 2016-03-07 17:39:40 --> Helper loaded: text_helper
INFO - 2016-03-07 17:39:40 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:39:40 --> Final output sent to browser
DEBUG - 2016-03-07 20:39:40 --> Total execution time: 1.1787
INFO - 2016-03-07 17:40:34 --> Config Class Initialized
INFO - 2016-03-07 17:40:34 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:40:34 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:40:34 --> Utf8 Class Initialized
INFO - 2016-03-07 17:40:34 --> URI Class Initialized
INFO - 2016-03-07 17:40:34 --> Router Class Initialized
INFO - 2016-03-07 17:40:34 --> Output Class Initialized
INFO - 2016-03-07 17:40:34 --> Security Class Initialized
DEBUG - 2016-03-07 17:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:40:34 --> Input Class Initialized
INFO - 2016-03-07 17:40:34 --> Language Class Initialized
INFO - 2016-03-07 17:40:34 --> Loader Class Initialized
INFO - 2016-03-07 17:40:34 --> Helper loaded: url_helper
INFO - 2016-03-07 17:40:34 --> Helper loaded: file_helper
INFO - 2016-03-07 17:40:34 --> Helper loaded: date_helper
INFO - 2016-03-07 17:40:34 --> Helper loaded: form_helper
INFO - 2016-03-07 17:40:34 --> Database Driver Class Initialized
INFO - 2016-03-07 17:40:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:40:35 --> Controller Class Initialized
INFO - 2016-03-07 17:40:35 --> Model Class Initialized
INFO - 2016-03-07 17:40:35 --> Model Class Initialized
INFO - 2016-03-07 17:40:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:40:35 --> Pagination Class Initialized
INFO - 2016-03-07 17:40:35 --> Helper loaded: text_helper
INFO - 2016-03-07 17:40:35 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:40:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:40:35 --> Final output sent to browser
DEBUG - 2016-03-07 20:40:35 --> Total execution time: 1.1599
INFO - 2016-03-07 17:41:00 --> Config Class Initialized
INFO - 2016-03-07 17:41:00 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:41:00 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:41:00 --> Utf8 Class Initialized
INFO - 2016-03-07 17:41:00 --> URI Class Initialized
INFO - 2016-03-07 17:41:00 --> Router Class Initialized
INFO - 2016-03-07 17:41:00 --> Output Class Initialized
INFO - 2016-03-07 17:41:00 --> Security Class Initialized
DEBUG - 2016-03-07 17:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:41:00 --> Input Class Initialized
INFO - 2016-03-07 17:41:00 --> Language Class Initialized
INFO - 2016-03-07 17:41:00 --> Loader Class Initialized
INFO - 2016-03-07 17:41:00 --> Helper loaded: url_helper
INFO - 2016-03-07 17:41:00 --> Helper loaded: file_helper
INFO - 2016-03-07 17:41:00 --> Helper loaded: date_helper
INFO - 2016-03-07 17:41:00 --> Helper loaded: form_helper
INFO - 2016-03-07 17:41:00 --> Database Driver Class Initialized
INFO - 2016-03-07 17:41:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:41:01 --> Controller Class Initialized
INFO - 2016-03-07 17:41:01 --> Model Class Initialized
INFO - 2016-03-07 17:41:01 --> Model Class Initialized
INFO - 2016-03-07 17:41:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:41:01 --> Pagination Class Initialized
INFO - 2016-03-07 17:41:01 --> Helper loaded: text_helper
INFO - 2016-03-07 17:41:01 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:41:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:41:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:41:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:41:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:41:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:41:01 --> Final output sent to browser
DEBUG - 2016-03-07 20:41:01 --> Total execution time: 1.1899
INFO - 2016-03-07 17:41:53 --> Config Class Initialized
INFO - 2016-03-07 17:41:53 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:41:53 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:41:53 --> Utf8 Class Initialized
INFO - 2016-03-07 17:41:53 --> URI Class Initialized
INFO - 2016-03-07 17:41:53 --> Router Class Initialized
INFO - 2016-03-07 17:41:53 --> Output Class Initialized
INFO - 2016-03-07 17:41:53 --> Security Class Initialized
DEBUG - 2016-03-07 17:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:41:53 --> Input Class Initialized
INFO - 2016-03-07 17:41:53 --> Language Class Initialized
INFO - 2016-03-07 17:41:53 --> Loader Class Initialized
INFO - 2016-03-07 17:41:53 --> Helper loaded: url_helper
INFO - 2016-03-07 17:41:53 --> Helper loaded: file_helper
INFO - 2016-03-07 17:41:53 --> Helper loaded: date_helper
INFO - 2016-03-07 17:41:53 --> Helper loaded: form_helper
INFO - 2016-03-07 17:41:53 --> Database Driver Class Initialized
INFO - 2016-03-07 17:41:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:41:54 --> Controller Class Initialized
INFO - 2016-03-07 17:41:54 --> Model Class Initialized
INFO - 2016-03-07 17:41:54 --> Model Class Initialized
INFO - 2016-03-07 17:41:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:41:54 --> Pagination Class Initialized
INFO - 2016-03-07 17:41:54 --> Helper loaded: text_helper
INFO - 2016-03-07 17:41:54 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:41:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:41:54 --> Final output sent to browser
DEBUG - 2016-03-07 20:41:54 --> Total execution time: 1.1592
INFO - 2016-03-07 17:43:08 --> Config Class Initialized
INFO - 2016-03-07 17:43:08 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:43:08 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:43:08 --> Utf8 Class Initialized
INFO - 2016-03-07 17:43:08 --> URI Class Initialized
INFO - 2016-03-07 17:43:08 --> Router Class Initialized
INFO - 2016-03-07 17:43:08 --> Output Class Initialized
INFO - 2016-03-07 17:43:08 --> Security Class Initialized
DEBUG - 2016-03-07 17:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:43:08 --> Input Class Initialized
INFO - 2016-03-07 17:43:08 --> Language Class Initialized
INFO - 2016-03-07 17:43:08 --> Loader Class Initialized
INFO - 2016-03-07 17:43:08 --> Helper loaded: url_helper
INFO - 2016-03-07 17:43:08 --> Helper loaded: file_helper
INFO - 2016-03-07 17:43:08 --> Helper loaded: date_helper
INFO - 2016-03-07 17:43:08 --> Helper loaded: form_helper
INFO - 2016-03-07 17:43:08 --> Database Driver Class Initialized
INFO - 2016-03-07 17:43:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:43:09 --> Controller Class Initialized
INFO - 2016-03-07 17:43:09 --> Model Class Initialized
INFO - 2016-03-07 17:43:09 --> Model Class Initialized
INFO - 2016-03-07 17:43:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:43:09 --> Pagination Class Initialized
INFO - 2016-03-07 17:43:09 --> Helper loaded: text_helper
INFO - 2016-03-07 17:43:09 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:43:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:43:09 --> Final output sent to browser
DEBUG - 2016-03-07 20:43:09 --> Total execution time: 1.1681
INFO - 2016-03-07 17:43:32 --> Config Class Initialized
INFO - 2016-03-07 17:43:32 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:43:32 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:43:32 --> Utf8 Class Initialized
INFO - 2016-03-07 17:43:32 --> URI Class Initialized
INFO - 2016-03-07 17:43:32 --> Router Class Initialized
INFO - 2016-03-07 17:43:32 --> Output Class Initialized
INFO - 2016-03-07 17:43:32 --> Security Class Initialized
DEBUG - 2016-03-07 17:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:43:32 --> Input Class Initialized
INFO - 2016-03-07 17:43:32 --> Language Class Initialized
INFO - 2016-03-07 17:43:32 --> Loader Class Initialized
INFO - 2016-03-07 17:43:32 --> Helper loaded: url_helper
INFO - 2016-03-07 17:43:32 --> Helper loaded: file_helper
INFO - 2016-03-07 17:43:32 --> Helper loaded: date_helper
INFO - 2016-03-07 17:43:32 --> Helper loaded: form_helper
INFO - 2016-03-07 17:43:32 --> Database Driver Class Initialized
INFO - 2016-03-07 17:43:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:43:33 --> Controller Class Initialized
INFO - 2016-03-07 17:43:33 --> Model Class Initialized
INFO - 2016-03-07 17:43:33 --> Model Class Initialized
INFO - 2016-03-07 17:43:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:43:33 --> Pagination Class Initialized
INFO - 2016-03-07 17:43:33 --> Helper loaded: text_helper
INFO - 2016-03-07 17:43:33 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:43:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:43:33 --> Final output sent to browser
DEBUG - 2016-03-07 20:43:33 --> Total execution time: 1.1595
INFO - 2016-03-07 17:43:41 --> Config Class Initialized
INFO - 2016-03-07 17:43:41 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:43:41 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:43:41 --> Utf8 Class Initialized
INFO - 2016-03-07 17:43:41 --> URI Class Initialized
INFO - 2016-03-07 17:43:41 --> Router Class Initialized
INFO - 2016-03-07 17:43:41 --> Output Class Initialized
INFO - 2016-03-07 17:43:41 --> Security Class Initialized
DEBUG - 2016-03-07 17:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:43:41 --> Input Class Initialized
INFO - 2016-03-07 17:43:41 --> Language Class Initialized
INFO - 2016-03-07 17:43:41 --> Loader Class Initialized
INFO - 2016-03-07 17:43:41 --> Helper loaded: url_helper
INFO - 2016-03-07 17:43:41 --> Helper loaded: file_helper
INFO - 2016-03-07 17:43:41 --> Helper loaded: date_helper
INFO - 2016-03-07 17:43:41 --> Helper loaded: form_helper
INFO - 2016-03-07 17:43:41 --> Database Driver Class Initialized
INFO - 2016-03-07 17:43:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:43:42 --> Controller Class Initialized
INFO - 2016-03-07 17:43:42 --> Model Class Initialized
INFO - 2016-03-07 17:43:42 --> Model Class Initialized
INFO - 2016-03-07 17:43:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:43:42 --> Pagination Class Initialized
INFO - 2016-03-07 17:43:42 --> Helper loaded: text_helper
INFO - 2016-03-07 17:43:42 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:43:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:43:42 --> Final output sent to browser
DEBUG - 2016-03-07 20:43:42 --> Total execution time: 1.1421
INFO - 2016-03-07 17:43:45 --> Config Class Initialized
INFO - 2016-03-07 17:43:45 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:43:45 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:43:45 --> Utf8 Class Initialized
INFO - 2016-03-07 17:43:45 --> URI Class Initialized
INFO - 2016-03-07 17:43:45 --> Router Class Initialized
INFO - 2016-03-07 17:43:45 --> Output Class Initialized
INFO - 2016-03-07 17:43:45 --> Security Class Initialized
DEBUG - 2016-03-07 17:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:43:45 --> Input Class Initialized
INFO - 2016-03-07 17:43:45 --> Language Class Initialized
INFO - 2016-03-07 17:43:45 --> Loader Class Initialized
INFO - 2016-03-07 17:43:45 --> Helper loaded: url_helper
INFO - 2016-03-07 17:43:45 --> Helper loaded: file_helper
INFO - 2016-03-07 17:43:45 --> Helper loaded: date_helper
INFO - 2016-03-07 17:43:45 --> Helper loaded: form_helper
INFO - 2016-03-07 17:43:45 --> Database Driver Class Initialized
INFO - 2016-03-07 17:43:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:43:46 --> Controller Class Initialized
INFO - 2016-03-07 17:43:46 --> Model Class Initialized
INFO - 2016-03-07 17:43:46 --> Model Class Initialized
INFO - 2016-03-07 17:43:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:43:46 --> Pagination Class Initialized
INFO - 2016-03-07 17:43:46 --> Helper loaded: text_helper
INFO - 2016-03-07 17:43:46 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 20:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 20:43:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:43:46 --> Final output sent to browser
DEBUG - 2016-03-07 20:43:46 --> Total execution time: 1.1951
INFO - 2016-03-07 17:44:54 --> Config Class Initialized
INFO - 2016-03-07 17:44:54 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:44:54 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:44:54 --> Utf8 Class Initialized
INFO - 2016-03-07 17:44:54 --> URI Class Initialized
INFO - 2016-03-07 17:44:54 --> Router Class Initialized
INFO - 2016-03-07 17:44:54 --> Output Class Initialized
INFO - 2016-03-07 17:44:54 --> Security Class Initialized
DEBUG - 2016-03-07 17:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:44:54 --> Input Class Initialized
INFO - 2016-03-07 17:44:54 --> Language Class Initialized
INFO - 2016-03-07 17:44:54 --> Loader Class Initialized
INFO - 2016-03-07 17:44:54 --> Helper loaded: url_helper
INFO - 2016-03-07 17:44:54 --> Helper loaded: file_helper
INFO - 2016-03-07 17:44:54 --> Helper loaded: date_helper
INFO - 2016-03-07 17:44:54 --> Helper loaded: form_helper
INFO - 2016-03-07 17:44:54 --> Database Driver Class Initialized
INFO - 2016-03-07 17:44:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:44:55 --> Controller Class Initialized
INFO - 2016-03-07 17:44:55 --> Model Class Initialized
INFO - 2016-03-07 17:44:55 --> Model Class Initialized
INFO - 2016-03-07 17:44:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:44:55 --> Pagination Class Initialized
INFO - 2016-03-07 17:44:55 --> Helper loaded: text_helper
INFO - 2016-03-07 17:44:55 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:44:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:44:55 --> Final output sent to browser
DEBUG - 2016-03-07 20:44:55 --> Total execution time: 1.1405
INFO - 2016-03-07 17:44:58 --> Config Class Initialized
INFO - 2016-03-07 17:44:58 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:44:58 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:44:58 --> Utf8 Class Initialized
INFO - 2016-03-07 17:44:58 --> URI Class Initialized
INFO - 2016-03-07 17:44:58 --> Router Class Initialized
INFO - 2016-03-07 17:44:58 --> Output Class Initialized
INFO - 2016-03-07 17:44:58 --> Security Class Initialized
DEBUG - 2016-03-07 17:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:44:58 --> Input Class Initialized
INFO - 2016-03-07 17:44:58 --> Language Class Initialized
INFO - 2016-03-07 17:44:58 --> Loader Class Initialized
INFO - 2016-03-07 17:44:58 --> Helper loaded: url_helper
INFO - 2016-03-07 17:44:58 --> Helper loaded: file_helper
INFO - 2016-03-07 17:44:58 --> Helper loaded: date_helper
INFO - 2016-03-07 17:44:58 --> Helper loaded: form_helper
INFO - 2016-03-07 17:44:58 --> Database Driver Class Initialized
INFO - 2016-03-07 17:44:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:44:59 --> Controller Class Initialized
INFO - 2016-03-07 17:44:59 --> Model Class Initialized
INFO - 2016-03-07 17:44:59 --> Model Class Initialized
INFO - 2016-03-07 17:44:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:44:59 --> Pagination Class Initialized
INFO - 2016-03-07 17:44:59 --> Helper loaded: text_helper
INFO - 2016-03-07 17:44:59 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 20:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 20:44:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:44:59 --> Final output sent to browser
DEBUG - 2016-03-07 20:44:59 --> Total execution time: 1.2026
INFO - 2016-03-07 17:50:47 --> Config Class Initialized
INFO - 2016-03-07 17:50:47 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:50:47 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:50:47 --> Utf8 Class Initialized
INFO - 2016-03-07 17:50:47 --> URI Class Initialized
INFO - 2016-03-07 17:50:47 --> Router Class Initialized
INFO - 2016-03-07 17:50:47 --> Output Class Initialized
INFO - 2016-03-07 17:50:47 --> Security Class Initialized
DEBUG - 2016-03-07 17:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:50:47 --> Input Class Initialized
INFO - 2016-03-07 17:50:47 --> Language Class Initialized
INFO - 2016-03-07 17:50:47 --> Loader Class Initialized
INFO - 2016-03-07 17:50:47 --> Helper loaded: url_helper
INFO - 2016-03-07 17:50:47 --> Helper loaded: file_helper
INFO - 2016-03-07 17:50:47 --> Helper loaded: date_helper
INFO - 2016-03-07 17:50:47 --> Helper loaded: form_helper
INFO - 2016-03-07 17:50:47 --> Database Driver Class Initialized
INFO - 2016-03-07 17:50:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:50:48 --> Controller Class Initialized
INFO - 2016-03-07 17:50:48 --> Model Class Initialized
INFO - 2016-03-07 17:50:48 --> Model Class Initialized
INFO - 2016-03-07 17:50:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:50:48 --> Pagination Class Initialized
INFO - 2016-03-07 17:50:48 --> Helper loaded: text_helper
INFO - 2016-03-07 17:50:48 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 20:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 20:50:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:50:48 --> Final output sent to browser
DEBUG - 2016-03-07 20:50:48 --> Total execution time: 1.1733
INFO - 2016-03-07 17:51:15 --> Config Class Initialized
INFO - 2016-03-07 17:51:15 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:51:15 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:51:15 --> Utf8 Class Initialized
INFO - 2016-03-07 17:51:15 --> URI Class Initialized
INFO - 2016-03-07 17:51:15 --> Router Class Initialized
INFO - 2016-03-07 17:51:15 --> Output Class Initialized
INFO - 2016-03-07 17:51:15 --> Security Class Initialized
DEBUG - 2016-03-07 17:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:51:15 --> Input Class Initialized
INFO - 2016-03-07 17:51:15 --> Language Class Initialized
INFO - 2016-03-07 17:51:15 --> Loader Class Initialized
INFO - 2016-03-07 17:51:15 --> Helper loaded: url_helper
INFO - 2016-03-07 17:51:15 --> Helper loaded: file_helper
INFO - 2016-03-07 17:51:15 --> Helper loaded: date_helper
INFO - 2016-03-07 17:51:15 --> Helper loaded: form_helper
INFO - 2016-03-07 17:51:15 --> Database Driver Class Initialized
INFO - 2016-03-07 17:51:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:51:16 --> Controller Class Initialized
INFO - 2016-03-07 17:51:16 --> Model Class Initialized
INFO - 2016-03-07 17:51:16 --> Model Class Initialized
INFO - 2016-03-07 17:51:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:51:16 --> Pagination Class Initialized
INFO - 2016-03-07 17:51:16 --> Helper loaded: text_helper
INFO - 2016-03-07 17:51:16 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:51:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:51:17 --> Final output sent to browser
DEBUG - 2016-03-07 20:51:17 --> Total execution time: 1.1128
INFO - 2016-03-07 17:51:26 --> Config Class Initialized
INFO - 2016-03-07 17:51:26 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:51:26 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:51:26 --> Utf8 Class Initialized
INFO - 2016-03-07 17:51:26 --> URI Class Initialized
INFO - 2016-03-07 17:51:26 --> Router Class Initialized
INFO - 2016-03-07 17:51:26 --> Output Class Initialized
INFO - 2016-03-07 17:51:26 --> Security Class Initialized
DEBUG - 2016-03-07 17:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:51:26 --> Input Class Initialized
INFO - 2016-03-07 17:51:26 --> Language Class Initialized
INFO - 2016-03-07 17:51:26 --> Loader Class Initialized
INFO - 2016-03-07 17:51:26 --> Helper loaded: url_helper
INFO - 2016-03-07 17:51:26 --> Helper loaded: file_helper
INFO - 2016-03-07 17:51:26 --> Helper loaded: date_helper
INFO - 2016-03-07 17:51:26 --> Helper loaded: form_helper
INFO - 2016-03-07 17:51:26 --> Database Driver Class Initialized
INFO - 2016-03-07 17:51:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:51:27 --> Controller Class Initialized
INFO - 2016-03-07 17:51:27 --> Model Class Initialized
INFO - 2016-03-07 17:51:27 --> Model Class Initialized
INFO - 2016-03-07 17:51:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:51:27 --> Pagination Class Initialized
INFO - 2016-03-07 17:51:27 --> Helper loaded: text_helper
INFO - 2016-03-07 17:51:27 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:51:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:51:27 --> Final output sent to browser
DEBUG - 2016-03-07 20:51:27 --> Total execution time: 1.1364
INFO - 2016-03-07 17:51:33 --> Config Class Initialized
INFO - 2016-03-07 17:51:33 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:51:33 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:51:33 --> Utf8 Class Initialized
INFO - 2016-03-07 17:51:33 --> URI Class Initialized
INFO - 2016-03-07 17:51:33 --> Router Class Initialized
INFO - 2016-03-07 17:51:33 --> Output Class Initialized
INFO - 2016-03-07 17:51:33 --> Security Class Initialized
DEBUG - 2016-03-07 17:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:51:33 --> Input Class Initialized
INFO - 2016-03-07 17:51:33 --> Language Class Initialized
INFO - 2016-03-07 17:51:33 --> Loader Class Initialized
INFO - 2016-03-07 17:51:33 --> Helper loaded: url_helper
INFO - 2016-03-07 17:51:33 --> Helper loaded: file_helper
INFO - 2016-03-07 17:51:33 --> Helper loaded: date_helper
INFO - 2016-03-07 17:51:33 --> Helper loaded: form_helper
INFO - 2016-03-07 17:51:33 --> Database Driver Class Initialized
INFO - 2016-03-07 17:51:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:51:34 --> Controller Class Initialized
INFO - 2016-03-07 17:51:34 --> Model Class Initialized
INFO - 2016-03-07 17:51:34 --> Model Class Initialized
INFO - 2016-03-07 17:51:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:51:34 --> Pagination Class Initialized
INFO - 2016-03-07 17:51:34 --> Helper loaded: text_helper
INFO - 2016-03-07 17:51:34 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:51:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:51:34 --> Final output sent to browser
DEBUG - 2016-03-07 20:51:34 --> Total execution time: 1.1985
INFO - 2016-03-07 17:51:35 --> Config Class Initialized
INFO - 2016-03-07 17:51:35 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:51:35 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:51:35 --> Utf8 Class Initialized
INFO - 2016-03-07 17:51:35 --> URI Class Initialized
INFO - 2016-03-07 17:51:35 --> Router Class Initialized
INFO - 2016-03-07 17:51:35 --> Output Class Initialized
INFO - 2016-03-07 17:51:35 --> Security Class Initialized
DEBUG - 2016-03-07 17:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:51:35 --> Input Class Initialized
INFO - 2016-03-07 17:51:35 --> Language Class Initialized
INFO - 2016-03-07 17:51:35 --> Loader Class Initialized
INFO - 2016-03-07 17:51:35 --> Helper loaded: url_helper
INFO - 2016-03-07 17:51:35 --> Helper loaded: file_helper
INFO - 2016-03-07 17:51:35 --> Helper loaded: date_helper
INFO - 2016-03-07 17:51:35 --> Helper loaded: form_helper
INFO - 2016-03-07 17:51:35 --> Database Driver Class Initialized
INFO - 2016-03-07 17:51:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:51:36 --> Controller Class Initialized
INFO - 2016-03-07 17:51:36 --> Model Class Initialized
INFO - 2016-03-07 17:51:36 --> Model Class Initialized
INFO - 2016-03-07 17:51:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:51:36 --> Pagination Class Initialized
INFO - 2016-03-07 17:51:36 --> Helper loaded: text_helper
INFO - 2016-03-07 17:51:36 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:51:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:51:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:51:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 20:51:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 20:51:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:51:36 --> Final output sent to browser
DEBUG - 2016-03-07 20:51:36 --> Total execution time: 1.2090
INFO - 2016-03-07 17:51:40 --> Config Class Initialized
INFO - 2016-03-07 17:51:40 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:51:40 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:51:40 --> Utf8 Class Initialized
INFO - 2016-03-07 17:51:40 --> URI Class Initialized
INFO - 2016-03-07 17:51:40 --> Router Class Initialized
INFO - 2016-03-07 17:51:40 --> Output Class Initialized
INFO - 2016-03-07 17:51:40 --> Security Class Initialized
DEBUG - 2016-03-07 17:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:51:40 --> Input Class Initialized
INFO - 2016-03-07 17:51:40 --> Language Class Initialized
INFO - 2016-03-07 17:51:40 --> Loader Class Initialized
INFO - 2016-03-07 17:51:40 --> Helper loaded: url_helper
INFO - 2016-03-07 17:51:40 --> Helper loaded: file_helper
INFO - 2016-03-07 17:51:40 --> Helper loaded: date_helper
INFO - 2016-03-07 17:51:40 --> Helper loaded: form_helper
INFO - 2016-03-07 17:51:40 --> Database Driver Class Initialized
INFO - 2016-03-07 17:51:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:51:41 --> Controller Class Initialized
INFO - 2016-03-07 17:51:41 --> Model Class Initialized
INFO - 2016-03-07 17:51:41 --> Model Class Initialized
INFO - 2016-03-07 17:51:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:51:41 --> Pagination Class Initialized
INFO - 2016-03-07 17:51:41 --> Helper loaded: text_helper
INFO - 2016-03-07 17:51:41 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:51:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:51:41 --> Final output sent to browser
DEBUG - 2016-03-07 20:51:41 --> Total execution time: 1.1796
INFO - 2016-03-07 17:51:50 --> Config Class Initialized
INFO - 2016-03-07 17:51:50 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:51:50 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:51:50 --> Utf8 Class Initialized
INFO - 2016-03-07 17:51:50 --> URI Class Initialized
INFO - 2016-03-07 17:51:50 --> Router Class Initialized
INFO - 2016-03-07 17:51:50 --> Output Class Initialized
INFO - 2016-03-07 17:51:50 --> Security Class Initialized
DEBUG - 2016-03-07 17:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:51:50 --> Input Class Initialized
INFO - 2016-03-07 17:51:50 --> Language Class Initialized
INFO - 2016-03-07 17:51:50 --> Loader Class Initialized
INFO - 2016-03-07 17:51:50 --> Helper loaded: url_helper
INFO - 2016-03-07 17:51:50 --> Helper loaded: file_helper
INFO - 2016-03-07 17:51:50 --> Helper loaded: date_helper
INFO - 2016-03-07 17:51:50 --> Helper loaded: form_helper
INFO - 2016-03-07 17:51:50 --> Database Driver Class Initialized
INFO - 2016-03-07 17:51:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:51:51 --> Controller Class Initialized
INFO - 2016-03-07 17:51:51 --> Model Class Initialized
INFO - 2016-03-07 17:51:51 --> Model Class Initialized
INFO - 2016-03-07 17:51:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:51:51 --> Pagination Class Initialized
INFO - 2016-03-07 17:51:52 --> Helper loaded: text_helper
INFO - 2016-03-07 17:51:52 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:51:52 --> Final output sent to browser
DEBUG - 2016-03-07 20:51:52 --> Total execution time: 1.1318
INFO - 2016-03-07 17:51:57 --> Config Class Initialized
INFO - 2016-03-07 17:51:57 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:51:57 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:51:57 --> Utf8 Class Initialized
INFO - 2016-03-07 17:51:57 --> URI Class Initialized
INFO - 2016-03-07 17:51:57 --> Router Class Initialized
INFO - 2016-03-07 17:51:57 --> Output Class Initialized
INFO - 2016-03-07 17:51:57 --> Security Class Initialized
DEBUG - 2016-03-07 17:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:51:57 --> Input Class Initialized
INFO - 2016-03-07 17:51:57 --> Language Class Initialized
INFO - 2016-03-07 17:51:57 --> Loader Class Initialized
INFO - 2016-03-07 17:51:57 --> Helper loaded: url_helper
INFO - 2016-03-07 17:51:57 --> Helper loaded: file_helper
INFO - 2016-03-07 17:51:57 --> Helper loaded: date_helper
INFO - 2016-03-07 17:51:57 --> Helper loaded: form_helper
INFO - 2016-03-07 17:51:57 --> Database Driver Class Initialized
INFO - 2016-03-07 17:51:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:51:58 --> Controller Class Initialized
INFO - 2016-03-07 17:51:58 --> Model Class Initialized
INFO - 2016-03-07 17:51:58 --> Model Class Initialized
INFO - 2016-03-07 17:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:51:58 --> Pagination Class Initialized
INFO - 2016-03-07 17:51:58 --> Helper loaded: text_helper
INFO - 2016-03-07 17:51:58 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:51:58 --> Final output sent to browser
DEBUG - 2016-03-07 20:51:58 --> Total execution time: 1.1369
INFO - 2016-03-07 17:52:11 --> Config Class Initialized
INFO - 2016-03-07 17:52:11 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:52:11 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:52:11 --> Utf8 Class Initialized
INFO - 2016-03-07 17:52:11 --> URI Class Initialized
INFO - 2016-03-07 17:52:11 --> Router Class Initialized
INFO - 2016-03-07 17:52:11 --> Output Class Initialized
INFO - 2016-03-07 17:52:11 --> Security Class Initialized
DEBUG - 2016-03-07 17:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:52:11 --> Input Class Initialized
INFO - 2016-03-07 17:52:11 --> Language Class Initialized
INFO - 2016-03-07 17:52:11 --> Loader Class Initialized
INFO - 2016-03-07 17:52:11 --> Helper loaded: url_helper
INFO - 2016-03-07 17:52:11 --> Helper loaded: file_helper
INFO - 2016-03-07 17:52:11 --> Helper loaded: date_helper
INFO - 2016-03-07 17:52:11 --> Helper loaded: form_helper
INFO - 2016-03-07 17:52:11 --> Database Driver Class Initialized
INFO - 2016-03-07 17:52:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:52:12 --> Controller Class Initialized
INFO - 2016-03-07 17:52:12 --> Model Class Initialized
INFO - 2016-03-07 17:52:12 --> Model Class Initialized
INFO - 2016-03-07 17:52:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:52:12 --> Pagination Class Initialized
INFO - 2016-03-07 17:52:12 --> Helper loaded: text_helper
INFO - 2016-03-07 17:52:12 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:52:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:52:12 --> Final output sent to browser
DEBUG - 2016-03-07 20:52:12 --> Total execution time: 1.1907
INFO - 2016-03-07 17:52:14 --> Config Class Initialized
INFO - 2016-03-07 17:52:14 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:52:14 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:52:14 --> Utf8 Class Initialized
INFO - 2016-03-07 17:52:14 --> URI Class Initialized
INFO - 2016-03-07 17:52:14 --> Router Class Initialized
INFO - 2016-03-07 17:52:14 --> Output Class Initialized
INFO - 2016-03-07 17:52:14 --> Security Class Initialized
DEBUG - 2016-03-07 17:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:52:14 --> Input Class Initialized
INFO - 2016-03-07 17:52:14 --> Language Class Initialized
INFO - 2016-03-07 17:52:14 --> Loader Class Initialized
INFO - 2016-03-07 17:52:14 --> Helper loaded: url_helper
INFO - 2016-03-07 17:52:14 --> Helper loaded: file_helper
INFO - 2016-03-07 17:52:14 --> Helper loaded: date_helper
INFO - 2016-03-07 17:52:14 --> Helper loaded: form_helper
INFO - 2016-03-07 17:52:14 --> Database Driver Class Initialized
INFO - 2016-03-07 17:52:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:52:15 --> Controller Class Initialized
INFO - 2016-03-07 17:52:15 --> Model Class Initialized
INFO - 2016-03-07 17:52:15 --> Model Class Initialized
INFO - 2016-03-07 17:52:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:52:15 --> Pagination Class Initialized
INFO - 2016-03-07 17:52:15 --> Helper loaded: text_helper
INFO - 2016-03-07 17:52:15 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:52:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:52:15 --> Final output sent to browser
DEBUG - 2016-03-07 20:52:15 --> Total execution time: 1.1165
INFO - 2016-03-07 17:52:17 --> Config Class Initialized
INFO - 2016-03-07 17:52:17 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:52:17 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:52:17 --> Utf8 Class Initialized
INFO - 2016-03-07 17:52:17 --> URI Class Initialized
INFO - 2016-03-07 17:52:17 --> Router Class Initialized
INFO - 2016-03-07 17:52:17 --> Output Class Initialized
INFO - 2016-03-07 17:52:17 --> Security Class Initialized
DEBUG - 2016-03-07 17:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:52:17 --> Input Class Initialized
INFO - 2016-03-07 17:52:17 --> Language Class Initialized
INFO - 2016-03-07 17:52:17 --> Loader Class Initialized
INFO - 2016-03-07 17:52:17 --> Helper loaded: url_helper
INFO - 2016-03-07 17:52:17 --> Helper loaded: file_helper
INFO - 2016-03-07 17:52:17 --> Helper loaded: date_helper
INFO - 2016-03-07 17:52:17 --> Helper loaded: form_helper
INFO - 2016-03-07 17:52:17 --> Database Driver Class Initialized
INFO - 2016-03-07 17:52:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:52:18 --> Controller Class Initialized
INFO - 2016-03-07 17:52:18 --> Model Class Initialized
INFO - 2016-03-07 17:52:18 --> Model Class Initialized
INFO - 2016-03-07 17:52:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:52:18 --> Pagination Class Initialized
INFO - 2016-03-07 17:52:18 --> Helper loaded: text_helper
INFO - 2016-03-07 17:52:18 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-07 20:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\list_side.php
INFO - 2016-03-07 20:52:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:52:18 --> Final output sent to browser
DEBUG - 2016-03-07 20:52:18 --> Total execution time: 1.1511
INFO - 2016-03-07 17:53:12 --> Config Class Initialized
INFO - 2016-03-07 17:53:12 --> Hooks Class Initialized
DEBUG - 2016-03-07 17:53:12 --> UTF-8 Support Enabled
INFO - 2016-03-07 17:53:12 --> Utf8 Class Initialized
INFO - 2016-03-07 17:53:12 --> URI Class Initialized
INFO - 2016-03-07 17:53:12 --> Router Class Initialized
INFO - 2016-03-07 17:53:12 --> Output Class Initialized
INFO - 2016-03-07 17:53:12 --> Security Class Initialized
DEBUG - 2016-03-07 17:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-07 17:53:12 --> Input Class Initialized
INFO - 2016-03-07 17:53:12 --> Language Class Initialized
INFO - 2016-03-07 17:53:12 --> Loader Class Initialized
INFO - 2016-03-07 17:53:12 --> Helper loaded: url_helper
INFO - 2016-03-07 17:53:12 --> Helper loaded: file_helper
INFO - 2016-03-07 17:53:12 --> Helper loaded: date_helper
INFO - 2016-03-07 17:53:12 --> Helper loaded: form_helper
INFO - 2016-03-07 17:53:12 --> Database Driver Class Initialized
INFO - 2016-03-07 17:53:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-07 17:53:13 --> Controller Class Initialized
INFO - 2016-03-07 17:53:13 --> Model Class Initialized
INFO - 2016-03-07 17:53:13 --> Model Class Initialized
INFO - 2016-03-07 17:53:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-07 17:53:13 --> Pagination Class Initialized
INFO - 2016-03-07 17:53:13 --> Helper loaded: text_helper
INFO - 2016-03-07 17:53:13 --> Helper loaded: cookie_helper
INFO - 2016-03-07 20:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-07 20:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-07 20:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-07 20:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-07 20:53:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-07 20:53:13 --> Final output sent to browser
DEBUG - 2016-03-07 20:53:13 --> Total execution time: 1.2260
