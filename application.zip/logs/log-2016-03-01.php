<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-03-01 04:52:19 --> Config Class Initialized
INFO - 2016-03-01 04:52:19 --> Hooks Class Initialized
DEBUG - 2016-03-01 04:52:19 --> UTF-8 Support Enabled
INFO - 2016-03-01 04:52:19 --> Utf8 Class Initialized
INFO - 2016-03-01 04:52:19 --> URI Class Initialized
INFO - 2016-03-01 04:52:19 --> Router Class Initialized
INFO - 2016-03-01 04:52:19 --> Output Class Initialized
INFO - 2016-03-01 04:52:19 --> Security Class Initialized
DEBUG - 2016-03-01 04:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 04:52:19 --> Input Class Initialized
INFO - 2016-03-01 04:52:19 --> Language Class Initialized
INFO - 2016-03-01 04:52:19 --> Loader Class Initialized
INFO - 2016-03-01 04:52:19 --> Helper loaded: url_helper
INFO - 2016-03-01 04:52:19 --> Helper loaded: file_helper
INFO - 2016-03-01 04:52:19 --> Helper loaded: date_helper
INFO - 2016-03-01 04:52:19 --> Helper loaded: form_helper
INFO - 2016-03-01 04:52:19 --> Database Driver Class Initialized
INFO - 2016-03-01 04:52:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 04:52:20 --> Controller Class Initialized
INFO - 2016-03-01 04:52:20 --> Model Class Initialized
INFO - 2016-03-01 04:52:20 --> Model Class Initialized
INFO - 2016-03-01 04:52:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 04:52:20 --> Pagination Class Initialized
INFO - 2016-03-01 04:52:20 --> Helper loaded: text_helper
INFO - 2016-03-01 04:52:20 --> Helper loaded: cookie_helper
INFO - 2016-03-01 07:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 07:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 07:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 07:52:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 07:52:20 --> Final output sent to browser
DEBUG - 2016-03-01 07:52:20 --> Total execution time: 1.1932
INFO - 2016-03-01 04:53:22 --> Config Class Initialized
INFO - 2016-03-01 04:53:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 04:53:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 04:53:22 --> Utf8 Class Initialized
INFO - 2016-03-01 04:53:22 --> URI Class Initialized
INFO - 2016-03-01 04:53:22 --> Router Class Initialized
INFO - 2016-03-01 04:53:22 --> Output Class Initialized
INFO - 2016-03-01 04:53:22 --> Security Class Initialized
DEBUG - 2016-03-01 04:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 04:53:22 --> Input Class Initialized
INFO - 2016-03-01 04:53:22 --> Language Class Initialized
INFO - 2016-03-01 04:53:22 --> Loader Class Initialized
INFO - 2016-03-01 04:53:22 --> Helper loaded: url_helper
INFO - 2016-03-01 04:53:22 --> Helper loaded: file_helper
INFO - 2016-03-01 04:53:22 --> Helper loaded: date_helper
INFO - 2016-03-01 04:53:22 --> Helper loaded: form_helper
INFO - 2016-03-01 04:53:22 --> Database Driver Class Initialized
INFO - 2016-03-01 04:53:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 04:53:23 --> Controller Class Initialized
INFO - 2016-03-01 04:53:23 --> Model Class Initialized
INFO - 2016-03-01 04:53:23 --> Model Class Initialized
INFO - 2016-03-01 04:53:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 04:53:23 --> Pagination Class Initialized
INFO - 2016-03-01 04:53:23 --> Helper loaded: text_helper
INFO - 2016-03-01 04:53:23 --> Helper loaded: cookie_helper
INFO - 2016-03-01 07:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 07:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 07:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 07:53:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 07:53:23 --> Final output sent to browser
DEBUG - 2016-03-01 07:53:23 --> Total execution time: 1.1723
INFO - 2016-03-01 04:53:55 --> Config Class Initialized
INFO - 2016-03-01 04:53:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 04:53:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 04:53:55 --> Utf8 Class Initialized
INFO - 2016-03-01 04:53:55 --> URI Class Initialized
INFO - 2016-03-01 04:53:55 --> Router Class Initialized
INFO - 2016-03-01 04:53:55 --> Output Class Initialized
INFO - 2016-03-01 04:53:55 --> Security Class Initialized
DEBUG - 2016-03-01 04:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 04:53:55 --> Input Class Initialized
INFO - 2016-03-01 04:53:55 --> Language Class Initialized
INFO - 2016-03-01 04:53:55 --> Loader Class Initialized
INFO - 2016-03-01 04:53:55 --> Helper loaded: url_helper
INFO - 2016-03-01 04:53:55 --> Helper loaded: file_helper
INFO - 2016-03-01 04:53:55 --> Helper loaded: date_helper
INFO - 2016-03-01 04:53:55 --> Helper loaded: form_helper
INFO - 2016-03-01 04:53:55 --> Database Driver Class Initialized
INFO - 2016-03-01 04:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 04:53:56 --> Controller Class Initialized
INFO - 2016-03-01 04:53:56 --> Model Class Initialized
INFO - 2016-03-01 04:53:56 --> Model Class Initialized
INFO - 2016-03-01 04:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 04:53:56 --> Pagination Class Initialized
INFO - 2016-03-01 04:53:56 --> Helper loaded: text_helper
INFO - 2016-03-01 04:53:56 --> Helper loaded: cookie_helper
INFO - 2016-03-01 07:53:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:53:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 07:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 07:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 07:53:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 07:53:57 --> Final output sent to browser
DEBUG - 2016-03-01 07:53:57 --> Total execution time: 1.2327
INFO - 2016-03-01 04:54:23 --> Config Class Initialized
INFO - 2016-03-01 04:54:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 04:54:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 04:54:23 --> Utf8 Class Initialized
INFO - 2016-03-01 04:54:23 --> URI Class Initialized
INFO - 2016-03-01 04:54:23 --> Router Class Initialized
INFO - 2016-03-01 04:54:23 --> Output Class Initialized
INFO - 2016-03-01 04:54:23 --> Security Class Initialized
DEBUG - 2016-03-01 04:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 04:54:23 --> Input Class Initialized
INFO - 2016-03-01 04:54:23 --> Language Class Initialized
INFO - 2016-03-01 04:54:23 --> Loader Class Initialized
INFO - 2016-03-01 04:54:23 --> Helper loaded: url_helper
INFO - 2016-03-01 04:54:23 --> Helper loaded: file_helper
INFO - 2016-03-01 04:54:23 --> Helper loaded: date_helper
INFO - 2016-03-01 04:54:23 --> Helper loaded: form_helper
INFO - 2016-03-01 04:54:23 --> Database Driver Class Initialized
INFO - 2016-03-01 04:54:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 04:54:24 --> Controller Class Initialized
INFO - 2016-03-01 04:54:24 --> Model Class Initialized
INFO - 2016-03-01 04:54:24 --> Model Class Initialized
INFO - 2016-03-01 04:54:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 04:54:24 --> Pagination Class Initialized
INFO - 2016-03-01 04:54:24 --> Helper loaded: text_helper
INFO - 2016-03-01 04:54:24 --> Helper loaded: cookie_helper
INFO - 2016-03-01 07:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 07:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 07:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 07:54:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 07:54:24 --> Final output sent to browser
DEBUG - 2016-03-01 07:54:24 --> Total execution time: 1.1874
INFO - 2016-03-01 04:54:57 --> Config Class Initialized
INFO - 2016-03-01 04:54:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 04:54:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 04:54:57 --> Utf8 Class Initialized
INFO - 2016-03-01 04:54:57 --> URI Class Initialized
INFO - 2016-03-01 04:54:57 --> Router Class Initialized
INFO - 2016-03-01 04:54:57 --> Output Class Initialized
INFO - 2016-03-01 04:54:57 --> Security Class Initialized
DEBUG - 2016-03-01 04:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 04:54:57 --> Input Class Initialized
INFO - 2016-03-01 04:54:57 --> Language Class Initialized
INFO - 2016-03-01 04:54:57 --> Loader Class Initialized
INFO - 2016-03-01 04:54:57 --> Helper loaded: url_helper
INFO - 2016-03-01 04:54:57 --> Helper loaded: file_helper
INFO - 2016-03-01 04:54:57 --> Helper loaded: date_helper
INFO - 2016-03-01 04:54:57 --> Helper loaded: form_helper
INFO - 2016-03-01 04:54:57 --> Database Driver Class Initialized
INFO - 2016-03-01 04:54:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 04:54:58 --> Controller Class Initialized
INFO - 2016-03-01 04:54:58 --> Model Class Initialized
INFO - 2016-03-01 04:54:58 --> Model Class Initialized
INFO - 2016-03-01 04:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 04:54:58 --> Pagination Class Initialized
INFO - 2016-03-01 04:54:58 --> Helper loaded: text_helper
INFO - 2016-03-01 04:54:58 --> Helper loaded: cookie_helper
INFO - 2016-03-01 07:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 07:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 07:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 07:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 07:54:58 --> Final output sent to browser
DEBUG - 2016-03-01 07:54:58 --> Total execution time: 1.1810
INFO - 2016-03-01 04:57:14 --> Config Class Initialized
INFO - 2016-03-01 04:57:14 --> Hooks Class Initialized
DEBUG - 2016-03-01 04:57:14 --> UTF-8 Support Enabled
INFO - 2016-03-01 04:57:14 --> Utf8 Class Initialized
INFO - 2016-03-01 04:57:14 --> URI Class Initialized
INFO - 2016-03-01 04:57:14 --> Router Class Initialized
INFO - 2016-03-01 04:57:14 --> Output Class Initialized
INFO - 2016-03-01 04:57:14 --> Security Class Initialized
DEBUG - 2016-03-01 04:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 04:57:14 --> Input Class Initialized
INFO - 2016-03-01 04:57:14 --> Language Class Initialized
INFO - 2016-03-01 04:57:14 --> Loader Class Initialized
INFO - 2016-03-01 04:57:14 --> Helper loaded: url_helper
INFO - 2016-03-01 04:57:14 --> Helper loaded: file_helper
INFO - 2016-03-01 04:57:14 --> Helper loaded: date_helper
INFO - 2016-03-01 04:57:14 --> Helper loaded: form_helper
INFO - 2016-03-01 04:57:14 --> Database Driver Class Initialized
INFO - 2016-03-01 04:57:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 04:57:15 --> Controller Class Initialized
INFO - 2016-03-01 04:57:15 --> Model Class Initialized
INFO - 2016-03-01 04:57:15 --> Model Class Initialized
INFO - 2016-03-01 04:57:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 04:57:15 --> Pagination Class Initialized
INFO - 2016-03-01 04:57:15 --> Helper loaded: text_helper
INFO - 2016-03-01 04:57:15 --> Helper loaded: cookie_helper
INFO - 2016-03-01 07:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:57:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 07:57:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 07:57:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 07:57:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 07:57:16 --> Final output sent to browser
DEBUG - 2016-03-01 07:57:16 --> Total execution time: 1.2290
INFO - 2016-03-01 04:57:37 --> Config Class Initialized
INFO - 2016-03-01 04:57:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 04:57:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 04:57:37 --> Utf8 Class Initialized
INFO - 2016-03-01 04:57:37 --> URI Class Initialized
INFO - 2016-03-01 04:57:37 --> Router Class Initialized
INFO - 2016-03-01 04:57:37 --> Output Class Initialized
INFO - 2016-03-01 04:57:37 --> Security Class Initialized
DEBUG - 2016-03-01 04:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 04:57:37 --> Input Class Initialized
INFO - 2016-03-01 04:57:37 --> Language Class Initialized
INFO - 2016-03-01 04:57:37 --> Loader Class Initialized
INFO - 2016-03-01 04:57:37 --> Helper loaded: url_helper
INFO - 2016-03-01 04:57:37 --> Helper loaded: file_helper
INFO - 2016-03-01 04:57:37 --> Helper loaded: date_helper
INFO - 2016-03-01 04:57:37 --> Helper loaded: form_helper
INFO - 2016-03-01 04:57:37 --> Database Driver Class Initialized
INFO - 2016-03-01 04:57:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 04:57:38 --> Controller Class Initialized
INFO - 2016-03-01 04:57:38 --> Model Class Initialized
INFO - 2016-03-01 04:57:38 --> Model Class Initialized
INFO - 2016-03-01 04:57:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 04:57:38 --> Pagination Class Initialized
INFO - 2016-03-01 04:57:38 --> Helper loaded: text_helper
INFO - 2016-03-01 04:57:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 07:57:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:57:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 07:57:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 07:57:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 07:57:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 07:57:38 --> Final output sent to browser
DEBUG - 2016-03-01 07:57:38 --> Total execution time: 1.2034
INFO - 2016-03-01 04:59:10 --> Config Class Initialized
INFO - 2016-03-01 04:59:10 --> Hooks Class Initialized
DEBUG - 2016-03-01 04:59:10 --> UTF-8 Support Enabled
INFO - 2016-03-01 04:59:10 --> Utf8 Class Initialized
INFO - 2016-03-01 04:59:10 --> URI Class Initialized
INFO - 2016-03-01 04:59:10 --> Router Class Initialized
INFO - 2016-03-01 04:59:10 --> Output Class Initialized
INFO - 2016-03-01 04:59:10 --> Security Class Initialized
DEBUG - 2016-03-01 04:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 04:59:10 --> Input Class Initialized
INFO - 2016-03-01 04:59:10 --> Language Class Initialized
INFO - 2016-03-01 04:59:10 --> Loader Class Initialized
INFO - 2016-03-01 04:59:10 --> Helper loaded: url_helper
INFO - 2016-03-01 04:59:10 --> Helper loaded: file_helper
INFO - 2016-03-01 04:59:10 --> Helper loaded: date_helper
INFO - 2016-03-01 04:59:10 --> Helper loaded: form_helper
INFO - 2016-03-01 04:59:10 --> Database Driver Class Initialized
INFO - 2016-03-01 04:59:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 04:59:11 --> Controller Class Initialized
INFO - 2016-03-01 04:59:11 --> Model Class Initialized
INFO - 2016-03-01 04:59:11 --> Model Class Initialized
INFO - 2016-03-01 04:59:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 04:59:11 --> Pagination Class Initialized
INFO - 2016-03-01 04:59:11 --> Helper loaded: text_helper
INFO - 2016-03-01 04:59:11 --> Helper loaded: cookie_helper
INFO - 2016-03-01 07:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:59:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 07:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 07:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 07:59:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 07:59:12 --> Final output sent to browser
DEBUG - 2016-03-01 07:59:12 --> Total execution time: 1.4410
INFO - 2016-03-01 05:02:20 --> Config Class Initialized
INFO - 2016-03-01 05:02:20 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:02:20 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:02:20 --> Utf8 Class Initialized
INFO - 2016-03-01 05:02:20 --> URI Class Initialized
INFO - 2016-03-01 05:02:20 --> Router Class Initialized
INFO - 2016-03-01 05:02:20 --> Output Class Initialized
INFO - 2016-03-01 05:02:20 --> Security Class Initialized
DEBUG - 2016-03-01 05:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:02:20 --> Input Class Initialized
INFO - 2016-03-01 05:02:20 --> Language Class Initialized
INFO - 2016-03-01 05:02:20 --> Loader Class Initialized
INFO - 2016-03-01 05:02:20 --> Helper loaded: url_helper
INFO - 2016-03-01 05:02:20 --> Helper loaded: file_helper
INFO - 2016-03-01 05:02:20 --> Helper loaded: date_helper
INFO - 2016-03-01 05:02:20 --> Helper loaded: form_helper
INFO - 2016-03-01 05:02:20 --> Database Driver Class Initialized
INFO - 2016-03-01 05:02:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:02:22 --> Controller Class Initialized
INFO - 2016-03-01 05:02:22 --> Model Class Initialized
INFO - 2016-03-01 05:02:22 --> Model Class Initialized
INFO - 2016-03-01 05:02:22 --> Form Validation Class Initialized
INFO - 2016-03-01 05:02:22 --> Helper loaded: text_helper
INFO - 2016-03-01 05:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 05:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 05:02:22 --> Final output sent to browser
DEBUG - 2016-03-01 05:02:22 --> Total execution time: 1.1228
INFO - 2016-03-01 05:02:24 --> Config Class Initialized
INFO - 2016-03-01 05:02:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:02:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:02:24 --> Utf8 Class Initialized
INFO - 2016-03-01 05:02:24 --> URI Class Initialized
INFO - 2016-03-01 05:02:24 --> Router Class Initialized
INFO - 2016-03-01 05:02:24 --> Output Class Initialized
INFO - 2016-03-01 05:02:24 --> Security Class Initialized
DEBUG - 2016-03-01 05:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:02:24 --> Input Class Initialized
INFO - 2016-03-01 05:02:24 --> Language Class Initialized
INFO - 2016-03-01 05:02:24 --> Loader Class Initialized
INFO - 2016-03-01 05:02:24 --> Helper loaded: url_helper
INFO - 2016-03-01 05:02:24 --> Helper loaded: file_helper
INFO - 2016-03-01 05:02:24 --> Helper loaded: date_helper
INFO - 2016-03-01 05:02:24 --> Helper loaded: form_helper
INFO - 2016-03-01 05:02:24 --> Database Driver Class Initialized
INFO - 2016-03-01 05:02:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:02:25 --> Controller Class Initialized
INFO - 2016-03-01 05:02:25 --> Model Class Initialized
INFO - 2016-03-01 05:02:25 --> Model Class Initialized
INFO - 2016-03-01 05:02:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:02:25 --> Pagination Class Initialized
INFO - 2016-03-01 05:02:25 --> Helper loaded: text_helper
INFO - 2016-03-01 05:02:25 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:02:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:02:25 --> Final output sent to browser
DEBUG - 2016-03-01 08:02:25 --> Total execution time: 1.1634
INFO - 2016-03-01 05:03:09 --> Config Class Initialized
INFO - 2016-03-01 05:03:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:03:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:03:09 --> Utf8 Class Initialized
INFO - 2016-03-01 05:03:09 --> URI Class Initialized
INFO - 2016-03-01 05:03:09 --> Router Class Initialized
INFO - 2016-03-01 05:03:09 --> Output Class Initialized
INFO - 2016-03-01 05:03:09 --> Security Class Initialized
DEBUG - 2016-03-01 05:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:03:09 --> Input Class Initialized
INFO - 2016-03-01 05:03:09 --> Language Class Initialized
INFO - 2016-03-01 05:03:09 --> Loader Class Initialized
INFO - 2016-03-01 05:03:09 --> Helper loaded: url_helper
INFO - 2016-03-01 05:03:09 --> Helper loaded: file_helper
INFO - 2016-03-01 05:03:09 --> Helper loaded: date_helper
INFO - 2016-03-01 05:03:09 --> Helper loaded: form_helper
INFO - 2016-03-01 05:03:09 --> Database Driver Class Initialized
INFO - 2016-03-01 05:03:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:03:10 --> Controller Class Initialized
INFO - 2016-03-01 05:03:10 --> Model Class Initialized
INFO - 2016-03-01 05:03:10 --> Model Class Initialized
INFO - 2016-03-01 05:03:10 --> Form Validation Class Initialized
INFO - 2016-03-01 05:03:10 --> Helper loaded: text_helper
INFO - 2016-03-01 05:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 05:03:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 05:03:10 --> Final output sent to browser
DEBUG - 2016-03-01 05:03:10 --> Total execution time: 1.0796
INFO - 2016-03-01 05:03:11 --> Config Class Initialized
INFO - 2016-03-01 05:03:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:03:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:03:11 --> Utf8 Class Initialized
INFO - 2016-03-01 05:03:11 --> URI Class Initialized
INFO - 2016-03-01 05:03:11 --> Router Class Initialized
INFO - 2016-03-01 05:03:11 --> Output Class Initialized
INFO - 2016-03-01 05:03:11 --> Security Class Initialized
DEBUG - 2016-03-01 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:03:11 --> Input Class Initialized
INFO - 2016-03-01 05:03:11 --> Language Class Initialized
INFO - 2016-03-01 05:03:11 --> Loader Class Initialized
INFO - 2016-03-01 05:03:11 --> Helper loaded: url_helper
INFO - 2016-03-01 05:03:11 --> Helper loaded: file_helper
INFO - 2016-03-01 05:03:11 --> Helper loaded: date_helper
INFO - 2016-03-01 05:03:11 --> Helper loaded: form_helper
INFO - 2016-03-01 05:03:11 --> Database Driver Class Initialized
INFO - 2016-03-01 05:03:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:03:12 --> Controller Class Initialized
INFO - 2016-03-01 05:03:12 --> Model Class Initialized
INFO - 2016-03-01 05:03:12 --> Model Class Initialized
INFO - 2016-03-01 05:03:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:03:12 --> Pagination Class Initialized
INFO - 2016-03-01 05:03:12 --> Helper loaded: text_helper
INFO - 2016-03-01 05:03:12 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:03:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:03:12 --> Final output sent to browser
DEBUG - 2016-03-01 08:03:12 --> Total execution time: 1.1676
INFO - 2016-03-01 05:05:54 --> Config Class Initialized
INFO - 2016-03-01 05:05:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:05:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:05:54 --> Utf8 Class Initialized
INFO - 2016-03-01 05:05:54 --> URI Class Initialized
INFO - 2016-03-01 05:05:54 --> Router Class Initialized
INFO - 2016-03-01 05:05:54 --> Output Class Initialized
INFO - 2016-03-01 05:05:54 --> Security Class Initialized
DEBUG - 2016-03-01 05:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:05:54 --> Input Class Initialized
INFO - 2016-03-01 05:05:54 --> Language Class Initialized
INFO - 2016-03-01 05:05:54 --> Loader Class Initialized
INFO - 2016-03-01 05:05:54 --> Helper loaded: url_helper
INFO - 2016-03-01 05:05:54 --> Helper loaded: file_helper
INFO - 2016-03-01 05:05:54 --> Helper loaded: date_helper
INFO - 2016-03-01 05:05:54 --> Helper loaded: form_helper
INFO - 2016-03-01 05:05:54 --> Database Driver Class Initialized
INFO - 2016-03-01 05:05:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:05:55 --> Controller Class Initialized
INFO - 2016-03-01 05:05:55 --> Model Class Initialized
INFO - 2016-03-01 05:05:55 --> Model Class Initialized
INFO - 2016-03-01 05:05:55 --> Form Validation Class Initialized
INFO - 2016-03-01 05:05:55 --> Helper loaded: text_helper
INFO - 2016-03-01 05:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 05:05:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 05:05:55 --> Final output sent to browser
DEBUG - 2016-03-01 05:05:55 --> Total execution time: 1.1465
INFO - 2016-03-01 05:06:24 --> Config Class Initialized
INFO - 2016-03-01 05:06:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:06:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:06:24 --> Utf8 Class Initialized
INFO - 2016-03-01 05:06:24 --> URI Class Initialized
INFO - 2016-03-01 05:06:24 --> Router Class Initialized
INFO - 2016-03-01 05:06:24 --> Output Class Initialized
INFO - 2016-03-01 05:06:24 --> Security Class Initialized
DEBUG - 2016-03-01 05:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:06:24 --> Input Class Initialized
INFO - 2016-03-01 05:06:24 --> Language Class Initialized
INFO - 2016-03-01 05:06:24 --> Loader Class Initialized
INFO - 2016-03-01 05:06:24 --> Helper loaded: url_helper
INFO - 2016-03-01 05:06:24 --> Helper loaded: file_helper
INFO - 2016-03-01 05:06:24 --> Helper loaded: date_helper
INFO - 2016-03-01 05:06:24 --> Helper loaded: form_helper
INFO - 2016-03-01 05:06:24 --> Database Driver Class Initialized
INFO - 2016-03-01 05:06:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:06:25 --> Controller Class Initialized
INFO - 2016-03-01 05:06:25 --> Model Class Initialized
INFO - 2016-03-01 05:06:25 --> Model Class Initialized
INFO - 2016-03-01 05:06:25 --> Form Validation Class Initialized
INFO - 2016-03-01 05:06:25 --> Helper loaded: text_helper
INFO - 2016-03-01 05:06:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 05:06:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 05:06:25 --> Final output sent to browser
DEBUG - 2016-03-01 05:06:25 --> Total execution time: 1.1369
INFO - 2016-03-01 05:06:26 --> Config Class Initialized
INFO - 2016-03-01 05:06:26 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:06:26 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:06:26 --> Utf8 Class Initialized
INFO - 2016-03-01 05:06:26 --> URI Class Initialized
INFO - 2016-03-01 05:06:26 --> Router Class Initialized
INFO - 2016-03-01 05:06:26 --> Output Class Initialized
INFO - 2016-03-01 05:06:26 --> Security Class Initialized
DEBUG - 2016-03-01 05:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:06:26 --> Input Class Initialized
INFO - 2016-03-01 05:06:26 --> Language Class Initialized
INFO - 2016-03-01 05:06:26 --> Loader Class Initialized
INFO - 2016-03-01 05:06:26 --> Helper loaded: url_helper
INFO - 2016-03-01 05:06:26 --> Helper loaded: file_helper
INFO - 2016-03-01 05:06:26 --> Helper loaded: date_helper
INFO - 2016-03-01 05:06:26 --> Helper loaded: form_helper
INFO - 2016-03-01 05:06:26 --> Database Driver Class Initialized
INFO - 2016-03-01 05:06:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:06:27 --> Controller Class Initialized
INFO - 2016-03-01 05:06:27 --> Model Class Initialized
INFO - 2016-03-01 05:06:27 --> Model Class Initialized
INFO - 2016-03-01 05:06:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:06:27 --> Pagination Class Initialized
INFO - 2016-03-01 05:06:27 --> Helper loaded: text_helper
INFO - 2016-03-01 05:06:27 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:06:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:06:27 --> Final output sent to browser
DEBUG - 2016-03-01 08:06:27 --> Total execution time: 1.2018
INFO - 2016-03-01 05:07:03 --> Config Class Initialized
INFO - 2016-03-01 05:07:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:07:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:07:03 --> Utf8 Class Initialized
INFO - 2016-03-01 05:07:03 --> URI Class Initialized
INFO - 2016-03-01 05:07:03 --> Router Class Initialized
INFO - 2016-03-01 05:07:03 --> Output Class Initialized
INFO - 2016-03-01 05:07:03 --> Security Class Initialized
DEBUG - 2016-03-01 05:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:07:03 --> Input Class Initialized
INFO - 2016-03-01 05:07:03 --> Language Class Initialized
INFO - 2016-03-01 05:07:03 --> Loader Class Initialized
INFO - 2016-03-01 05:07:03 --> Helper loaded: url_helper
INFO - 2016-03-01 05:07:03 --> Helper loaded: file_helper
INFO - 2016-03-01 05:07:03 --> Helper loaded: date_helper
INFO - 2016-03-01 05:07:03 --> Helper loaded: form_helper
INFO - 2016-03-01 05:07:03 --> Database Driver Class Initialized
INFO - 2016-03-01 05:07:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:07:04 --> Controller Class Initialized
INFO - 2016-03-01 05:07:04 --> Model Class Initialized
INFO - 2016-03-01 05:07:04 --> Model Class Initialized
INFO - 2016-03-01 05:07:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:07:04 --> Pagination Class Initialized
INFO - 2016-03-01 05:07:04 --> Helper loaded: text_helper
INFO - 2016-03-01 05:07:04 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:07:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:07:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:07:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:07:05 --> Final output sent to browser
DEBUG - 2016-03-01 08:07:05 --> Total execution time: 1.3304
INFO - 2016-03-01 05:08:52 --> Config Class Initialized
INFO - 2016-03-01 05:08:52 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:08:52 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:08:52 --> Utf8 Class Initialized
INFO - 2016-03-01 05:08:52 --> URI Class Initialized
INFO - 2016-03-01 05:08:52 --> Router Class Initialized
INFO - 2016-03-01 05:08:52 --> Output Class Initialized
INFO - 2016-03-01 05:08:52 --> Security Class Initialized
DEBUG - 2016-03-01 05:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:08:52 --> Input Class Initialized
INFO - 2016-03-01 05:08:52 --> Language Class Initialized
INFO - 2016-03-01 05:08:52 --> Loader Class Initialized
INFO - 2016-03-01 05:08:52 --> Helper loaded: url_helper
INFO - 2016-03-01 05:08:52 --> Helper loaded: file_helper
INFO - 2016-03-01 05:08:52 --> Helper loaded: date_helper
INFO - 2016-03-01 05:08:52 --> Helper loaded: form_helper
INFO - 2016-03-01 05:08:52 --> Database Driver Class Initialized
INFO - 2016-03-01 05:08:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:08:53 --> Controller Class Initialized
INFO - 2016-03-01 05:08:53 --> Model Class Initialized
INFO - 2016-03-01 05:08:53 --> Model Class Initialized
INFO - 2016-03-01 05:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:08:53 --> Pagination Class Initialized
INFO - 2016-03-01 05:08:53 --> Helper loaded: text_helper
INFO - 2016-03-01 05:08:53 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:08:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:08:53 --> Final output sent to browser
DEBUG - 2016-03-01 08:08:53 --> Total execution time: 1.2019
INFO - 2016-03-01 05:09:07 --> Config Class Initialized
INFO - 2016-03-01 05:09:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:09:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:09:07 --> Utf8 Class Initialized
INFO - 2016-03-01 05:09:07 --> URI Class Initialized
INFO - 2016-03-01 05:09:07 --> Router Class Initialized
INFO - 2016-03-01 05:09:07 --> Output Class Initialized
INFO - 2016-03-01 05:09:07 --> Security Class Initialized
DEBUG - 2016-03-01 05:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:09:07 --> Input Class Initialized
INFO - 2016-03-01 05:09:07 --> Language Class Initialized
INFO - 2016-03-01 05:09:07 --> Loader Class Initialized
INFO - 2016-03-01 05:09:07 --> Helper loaded: url_helper
INFO - 2016-03-01 05:09:07 --> Helper loaded: file_helper
INFO - 2016-03-01 05:09:07 --> Helper loaded: date_helper
INFO - 2016-03-01 05:09:07 --> Helper loaded: form_helper
INFO - 2016-03-01 05:09:07 --> Database Driver Class Initialized
INFO - 2016-03-01 05:09:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:09:08 --> Controller Class Initialized
INFO - 2016-03-01 05:09:08 --> Model Class Initialized
INFO - 2016-03-01 05:09:08 --> Model Class Initialized
INFO - 2016-03-01 05:09:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:09:08 --> Pagination Class Initialized
INFO - 2016-03-01 05:09:08 --> Helper loaded: text_helper
INFO - 2016-03-01 05:09:08 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:09:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:09:08 --> Final output sent to browser
DEBUG - 2016-03-01 08:09:08 --> Total execution time: 1.2015
INFO - 2016-03-01 05:09:43 --> Config Class Initialized
INFO - 2016-03-01 05:09:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:09:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:09:43 --> Utf8 Class Initialized
INFO - 2016-03-01 05:09:43 --> URI Class Initialized
INFO - 2016-03-01 05:09:43 --> Router Class Initialized
INFO - 2016-03-01 05:09:43 --> Output Class Initialized
INFO - 2016-03-01 05:09:43 --> Security Class Initialized
DEBUG - 2016-03-01 05:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:09:43 --> Input Class Initialized
INFO - 2016-03-01 05:09:43 --> Language Class Initialized
INFO - 2016-03-01 05:09:43 --> Loader Class Initialized
INFO - 2016-03-01 05:09:43 --> Helper loaded: url_helper
INFO - 2016-03-01 05:09:43 --> Helper loaded: file_helper
INFO - 2016-03-01 05:09:43 --> Helper loaded: date_helper
INFO - 2016-03-01 05:09:43 --> Helper loaded: form_helper
INFO - 2016-03-01 05:09:43 --> Database Driver Class Initialized
INFO - 2016-03-01 05:09:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:09:44 --> Controller Class Initialized
INFO - 2016-03-01 05:09:44 --> Model Class Initialized
INFO - 2016-03-01 05:09:44 --> Model Class Initialized
INFO - 2016-03-01 05:09:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:09:44 --> Pagination Class Initialized
INFO - 2016-03-01 05:09:44 --> Helper loaded: text_helper
INFO - 2016-03-01 05:09:44 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:09:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:09:44 --> Final output sent to browser
DEBUG - 2016-03-01 08:09:44 --> Total execution time: 1.2216
INFO - 2016-03-01 05:11:09 --> Config Class Initialized
INFO - 2016-03-01 05:11:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:11:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:11:09 --> Utf8 Class Initialized
INFO - 2016-03-01 05:11:09 --> URI Class Initialized
INFO - 2016-03-01 05:11:09 --> Router Class Initialized
INFO - 2016-03-01 05:11:09 --> Output Class Initialized
INFO - 2016-03-01 05:11:09 --> Security Class Initialized
DEBUG - 2016-03-01 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:11:09 --> Input Class Initialized
INFO - 2016-03-01 05:11:09 --> Language Class Initialized
INFO - 2016-03-01 05:11:09 --> Loader Class Initialized
INFO - 2016-03-01 05:11:09 --> Helper loaded: url_helper
INFO - 2016-03-01 05:11:09 --> Helper loaded: file_helper
INFO - 2016-03-01 05:11:09 --> Helper loaded: date_helper
INFO - 2016-03-01 05:11:09 --> Helper loaded: form_helper
INFO - 2016-03-01 05:11:09 --> Database Driver Class Initialized
INFO - 2016-03-01 05:11:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:11:10 --> Controller Class Initialized
INFO - 2016-03-01 05:11:10 --> Model Class Initialized
INFO - 2016-03-01 05:11:10 --> Model Class Initialized
INFO - 2016-03-01 05:11:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:11:10 --> Pagination Class Initialized
INFO - 2016-03-01 05:11:10 --> Helper loaded: text_helper
INFO - 2016-03-01 05:11:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:11:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:11:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:11:11 --> Final output sent to browser
DEBUG - 2016-03-01 08:11:11 --> Total execution time: 1.2222
INFO - 2016-03-01 05:11:50 --> Config Class Initialized
INFO - 2016-03-01 05:11:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:11:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:11:50 --> Utf8 Class Initialized
INFO - 2016-03-01 05:11:50 --> URI Class Initialized
INFO - 2016-03-01 05:11:50 --> Router Class Initialized
INFO - 2016-03-01 05:11:50 --> Output Class Initialized
INFO - 2016-03-01 05:11:50 --> Security Class Initialized
DEBUG - 2016-03-01 05:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:11:50 --> Input Class Initialized
INFO - 2016-03-01 05:11:50 --> Language Class Initialized
INFO - 2016-03-01 05:11:50 --> Loader Class Initialized
INFO - 2016-03-01 05:11:50 --> Helper loaded: url_helper
INFO - 2016-03-01 05:11:50 --> Helper loaded: file_helper
INFO - 2016-03-01 05:11:50 --> Helper loaded: date_helper
INFO - 2016-03-01 05:11:50 --> Helper loaded: form_helper
INFO - 2016-03-01 05:11:50 --> Database Driver Class Initialized
INFO - 2016-03-01 05:11:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:11:51 --> Controller Class Initialized
INFO - 2016-03-01 05:11:51 --> Model Class Initialized
INFO - 2016-03-01 05:11:51 --> Model Class Initialized
INFO - 2016-03-01 05:11:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:11:51 --> Pagination Class Initialized
INFO - 2016-03-01 05:11:51 --> Helper loaded: text_helper
INFO - 2016-03-01 05:11:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:11:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:11:51 --> Final output sent to browser
DEBUG - 2016-03-01 08:11:51 --> Total execution time: 1.2208
INFO - 2016-03-01 05:12:36 --> Config Class Initialized
INFO - 2016-03-01 05:12:36 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:12:36 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:12:36 --> Utf8 Class Initialized
INFO - 2016-03-01 05:12:36 --> URI Class Initialized
INFO - 2016-03-01 05:12:36 --> Router Class Initialized
INFO - 2016-03-01 05:12:36 --> Output Class Initialized
INFO - 2016-03-01 05:12:36 --> Security Class Initialized
DEBUG - 2016-03-01 05:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:12:36 --> Input Class Initialized
INFO - 2016-03-01 05:12:36 --> Language Class Initialized
INFO - 2016-03-01 05:12:36 --> Loader Class Initialized
INFO - 2016-03-01 05:12:36 --> Helper loaded: url_helper
INFO - 2016-03-01 05:12:36 --> Helper loaded: file_helper
INFO - 2016-03-01 05:12:36 --> Helper loaded: date_helper
INFO - 2016-03-01 05:12:36 --> Helper loaded: form_helper
INFO - 2016-03-01 05:12:36 --> Database Driver Class Initialized
INFO - 2016-03-01 05:12:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:12:37 --> Controller Class Initialized
INFO - 2016-03-01 05:12:37 --> Model Class Initialized
INFO - 2016-03-01 05:12:37 --> Model Class Initialized
INFO - 2016-03-01 05:12:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:12:37 --> Pagination Class Initialized
INFO - 2016-03-01 05:12:37 --> Helper loaded: text_helper
INFO - 2016-03-01 05:12:37 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:12:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:12:37 --> Final output sent to browser
DEBUG - 2016-03-01 08:12:37 --> Total execution time: 1.2006
INFO - 2016-03-01 05:12:51 --> Config Class Initialized
INFO - 2016-03-01 05:12:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:12:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:12:51 --> Utf8 Class Initialized
INFO - 2016-03-01 05:12:51 --> URI Class Initialized
INFO - 2016-03-01 05:12:51 --> Router Class Initialized
INFO - 2016-03-01 05:12:51 --> Output Class Initialized
INFO - 2016-03-01 05:12:51 --> Security Class Initialized
DEBUG - 2016-03-01 05:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:12:51 --> Input Class Initialized
INFO - 2016-03-01 05:12:51 --> Language Class Initialized
INFO - 2016-03-01 05:12:51 --> Loader Class Initialized
INFO - 2016-03-01 05:12:51 --> Helper loaded: url_helper
INFO - 2016-03-01 05:12:51 --> Helper loaded: file_helper
INFO - 2016-03-01 05:12:51 --> Helper loaded: date_helper
INFO - 2016-03-01 05:12:51 --> Helper loaded: form_helper
INFO - 2016-03-01 05:12:51 --> Database Driver Class Initialized
INFO - 2016-03-01 05:12:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:12:52 --> Controller Class Initialized
INFO - 2016-03-01 05:12:52 --> Model Class Initialized
INFO - 2016-03-01 05:12:52 --> Model Class Initialized
INFO - 2016-03-01 05:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:12:52 --> Pagination Class Initialized
INFO - 2016-03-01 05:12:52 --> Helper loaded: text_helper
INFO - 2016-03-01 05:12:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:12:52 --> Final output sent to browser
DEBUG - 2016-03-01 08:12:52 --> Total execution time: 1.2102
INFO - 2016-03-01 05:13:22 --> Config Class Initialized
INFO - 2016-03-01 05:13:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:13:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:13:22 --> Utf8 Class Initialized
INFO - 2016-03-01 05:13:22 --> URI Class Initialized
INFO - 2016-03-01 05:13:22 --> Router Class Initialized
INFO - 2016-03-01 05:13:22 --> Output Class Initialized
INFO - 2016-03-01 05:13:22 --> Security Class Initialized
DEBUG - 2016-03-01 05:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:13:22 --> Input Class Initialized
INFO - 2016-03-01 05:13:22 --> Language Class Initialized
INFO - 2016-03-01 05:13:22 --> Loader Class Initialized
INFO - 2016-03-01 05:13:22 --> Helper loaded: url_helper
INFO - 2016-03-01 05:13:22 --> Helper loaded: file_helper
INFO - 2016-03-01 05:13:22 --> Helper loaded: date_helper
INFO - 2016-03-01 05:13:22 --> Helper loaded: form_helper
INFO - 2016-03-01 05:13:22 --> Database Driver Class Initialized
INFO - 2016-03-01 05:13:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:13:23 --> Controller Class Initialized
INFO - 2016-03-01 05:13:23 --> Model Class Initialized
INFO - 2016-03-01 05:13:23 --> Model Class Initialized
INFO - 2016-03-01 05:13:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:13:23 --> Pagination Class Initialized
INFO - 2016-03-01 05:13:23 --> Helper loaded: text_helper
INFO - 2016-03-01 05:13:23 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:13:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:13:23 --> Final output sent to browser
DEBUG - 2016-03-01 08:13:23 --> Total execution time: 1.2151
INFO - 2016-03-01 05:14:35 --> Config Class Initialized
INFO - 2016-03-01 05:14:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:14:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:14:35 --> Utf8 Class Initialized
INFO - 2016-03-01 05:14:35 --> URI Class Initialized
INFO - 2016-03-01 05:14:35 --> Router Class Initialized
INFO - 2016-03-01 05:14:35 --> Output Class Initialized
INFO - 2016-03-01 05:14:35 --> Security Class Initialized
DEBUG - 2016-03-01 05:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:14:35 --> Input Class Initialized
INFO - 2016-03-01 05:14:35 --> Language Class Initialized
INFO - 2016-03-01 05:14:35 --> Loader Class Initialized
INFO - 2016-03-01 05:14:35 --> Helper loaded: url_helper
INFO - 2016-03-01 05:14:35 --> Helper loaded: file_helper
INFO - 2016-03-01 05:14:35 --> Helper loaded: date_helper
INFO - 2016-03-01 05:14:35 --> Helper loaded: form_helper
INFO - 2016-03-01 05:14:35 --> Database Driver Class Initialized
INFO - 2016-03-01 05:14:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:14:36 --> Controller Class Initialized
INFO - 2016-03-01 05:14:36 --> Model Class Initialized
INFO - 2016-03-01 05:14:36 --> Model Class Initialized
INFO - 2016-03-01 05:14:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:14:36 --> Pagination Class Initialized
INFO - 2016-03-01 05:14:36 --> Helper loaded: text_helper
INFO - 2016-03-01 05:14:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:14:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:14:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:14:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:14:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:14:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:14:36 --> Final output sent to browser
DEBUG - 2016-03-01 08:14:36 --> Total execution time: 1.1979
INFO - 2016-03-01 05:16:01 --> Config Class Initialized
INFO - 2016-03-01 05:16:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:16:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:16:01 --> Utf8 Class Initialized
INFO - 2016-03-01 05:16:01 --> URI Class Initialized
INFO - 2016-03-01 05:16:01 --> Router Class Initialized
INFO - 2016-03-01 05:16:01 --> Output Class Initialized
INFO - 2016-03-01 05:16:01 --> Security Class Initialized
DEBUG - 2016-03-01 05:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:16:01 --> Input Class Initialized
INFO - 2016-03-01 05:16:01 --> Language Class Initialized
INFO - 2016-03-01 05:16:01 --> Loader Class Initialized
INFO - 2016-03-01 05:16:01 --> Helper loaded: url_helper
INFO - 2016-03-01 05:16:01 --> Helper loaded: file_helper
INFO - 2016-03-01 05:16:01 --> Helper loaded: date_helper
INFO - 2016-03-01 05:16:01 --> Helper loaded: form_helper
INFO - 2016-03-01 05:16:01 --> Database Driver Class Initialized
INFO - 2016-03-01 05:16:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:16:02 --> Controller Class Initialized
INFO - 2016-03-01 05:16:02 --> Model Class Initialized
INFO - 2016-03-01 05:16:02 --> Model Class Initialized
INFO - 2016-03-01 05:16:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:16:02 --> Pagination Class Initialized
INFO - 2016-03-01 05:16:02 --> Helper loaded: text_helper
INFO - 2016-03-01 05:16:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:16:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:16:02 --> Final output sent to browser
DEBUG - 2016-03-01 08:16:02 --> Total execution time: 1.2210
INFO - 2016-03-01 05:16:21 --> Config Class Initialized
INFO - 2016-03-01 05:16:21 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:16:21 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:16:21 --> Utf8 Class Initialized
INFO - 2016-03-01 05:16:21 --> URI Class Initialized
INFO - 2016-03-01 05:16:21 --> Router Class Initialized
INFO - 2016-03-01 05:16:21 --> Output Class Initialized
INFO - 2016-03-01 05:16:21 --> Security Class Initialized
DEBUG - 2016-03-01 05:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:16:21 --> Input Class Initialized
INFO - 2016-03-01 05:16:21 --> Language Class Initialized
INFO - 2016-03-01 05:16:21 --> Loader Class Initialized
INFO - 2016-03-01 05:16:21 --> Helper loaded: url_helper
INFO - 2016-03-01 05:16:21 --> Helper loaded: file_helper
INFO - 2016-03-01 05:16:21 --> Helper loaded: date_helper
INFO - 2016-03-01 05:16:21 --> Helper loaded: form_helper
INFO - 2016-03-01 05:16:21 --> Database Driver Class Initialized
INFO - 2016-03-01 05:16:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:16:22 --> Controller Class Initialized
INFO - 2016-03-01 05:16:22 --> Model Class Initialized
INFO - 2016-03-01 05:16:22 --> Model Class Initialized
INFO - 2016-03-01 05:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:16:22 --> Pagination Class Initialized
INFO - 2016-03-01 05:16:22 --> Helper loaded: text_helper
INFO - 2016-03-01 05:16:22 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:16:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:16:22 --> Final output sent to browser
DEBUG - 2016-03-01 08:16:22 --> Total execution time: 1.2052
INFO - 2016-03-01 05:18:33 --> Config Class Initialized
INFO - 2016-03-01 05:18:33 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:18:33 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:18:33 --> Utf8 Class Initialized
INFO - 2016-03-01 05:18:33 --> URI Class Initialized
INFO - 2016-03-01 05:18:33 --> Router Class Initialized
INFO - 2016-03-01 05:18:33 --> Output Class Initialized
INFO - 2016-03-01 05:18:33 --> Security Class Initialized
DEBUG - 2016-03-01 05:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:18:33 --> Input Class Initialized
INFO - 2016-03-01 05:18:33 --> Language Class Initialized
INFO - 2016-03-01 05:18:33 --> Loader Class Initialized
INFO - 2016-03-01 05:18:33 --> Helper loaded: url_helper
INFO - 2016-03-01 05:18:33 --> Helper loaded: file_helper
INFO - 2016-03-01 05:18:33 --> Helper loaded: date_helper
INFO - 2016-03-01 05:18:33 --> Helper loaded: form_helper
INFO - 2016-03-01 05:18:33 --> Database Driver Class Initialized
INFO - 2016-03-01 05:18:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:18:34 --> Controller Class Initialized
INFO - 2016-03-01 05:18:34 --> Model Class Initialized
INFO - 2016-03-01 05:18:34 --> Model Class Initialized
INFO - 2016-03-01 05:18:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:18:34 --> Pagination Class Initialized
INFO - 2016-03-01 05:18:34 --> Helper loaded: text_helper
INFO - 2016-03-01 05:18:34 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:18:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:18:34 --> Final output sent to browser
DEBUG - 2016-03-01 08:18:34 --> Total execution time: 1.2120
INFO - 2016-03-01 05:19:14 --> Config Class Initialized
INFO - 2016-03-01 05:19:14 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:19:14 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:19:14 --> Utf8 Class Initialized
INFO - 2016-03-01 05:19:14 --> URI Class Initialized
INFO - 2016-03-01 05:19:14 --> Router Class Initialized
INFO - 2016-03-01 05:19:14 --> Output Class Initialized
INFO - 2016-03-01 05:19:14 --> Security Class Initialized
DEBUG - 2016-03-01 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:19:14 --> Input Class Initialized
INFO - 2016-03-01 05:19:14 --> Language Class Initialized
INFO - 2016-03-01 05:19:14 --> Loader Class Initialized
INFO - 2016-03-01 05:19:14 --> Helper loaded: url_helper
INFO - 2016-03-01 05:19:14 --> Helper loaded: file_helper
INFO - 2016-03-01 05:19:14 --> Helper loaded: date_helper
INFO - 2016-03-01 05:19:14 --> Helper loaded: form_helper
INFO - 2016-03-01 05:19:14 --> Database Driver Class Initialized
INFO - 2016-03-01 05:19:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:19:15 --> Controller Class Initialized
INFO - 2016-03-01 05:19:15 --> Model Class Initialized
INFO - 2016-03-01 05:19:15 --> Model Class Initialized
INFO - 2016-03-01 05:19:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:19:15 --> Pagination Class Initialized
INFO - 2016-03-01 05:19:15 --> Helper loaded: text_helper
INFO - 2016-03-01 05:19:15 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:19:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:19:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:19:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:19:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:19:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:19:15 --> Final output sent to browser
DEBUG - 2016-03-01 08:19:15 --> Total execution time: 1.2001
INFO - 2016-03-01 05:20:05 --> Config Class Initialized
INFO - 2016-03-01 05:20:05 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:20:05 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:20:05 --> Utf8 Class Initialized
INFO - 2016-03-01 05:20:05 --> URI Class Initialized
INFO - 2016-03-01 05:20:05 --> Router Class Initialized
INFO - 2016-03-01 05:20:05 --> Output Class Initialized
INFO - 2016-03-01 05:20:05 --> Security Class Initialized
DEBUG - 2016-03-01 05:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:20:05 --> Input Class Initialized
INFO - 2016-03-01 05:20:05 --> Language Class Initialized
INFO - 2016-03-01 05:20:05 --> Loader Class Initialized
INFO - 2016-03-01 05:20:05 --> Helper loaded: url_helper
INFO - 2016-03-01 05:20:05 --> Helper loaded: file_helper
INFO - 2016-03-01 05:20:05 --> Helper loaded: date_helper
INFO - 2016-03-01 05:20:05 --> Helper loaded: form_helper
INFO - 2016-03-01 05:20:05 --> Database Driver Class Initialized
INFO - 2016-03-01 05:20:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:20:06 --> Controller Class Initialized
INFO - 2016-03-01 05:20:06 --> Model Class Initialized
INFO - 2016-03-01 05:20:06 --> Model Class Initialized
INFO - 2016-03-01 05:20:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:20:06 --> Pagination Class Initialized
INFO - 2016-03-01 05:20:06 --> Helper loaded: text_helper
INFO - 2016-03-01 05:20:06 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:20:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:20:06 --> Final output sent to browser
DEBUG - 2016-03-01 08:20:06 --> Total execution time: 1.2425
INFO - 2016-03-01 05:20:38 --> Config Class Initialized
INFO - 2016-03-01 05:20:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:20:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:20:38 --> Utf8 Class Initialized
INFO - 2016-03-01 05:20:38 --> URI Class Initialized
INFO - 2016-03-01 05:20:38 --> Router Class Initialized
INFO - 2016-03-01 05:20:38 --> Output Class Initialized
INFO - 2016-03-01 05:20:38 --> Security Class Initialized
DEBUG - 2016-03-01 05:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:20:38 --> Input Class Initialized
INFO - 2016-03-01 05:20:38 --> Language Class Initialized
INFO - 2016-03-01 05:20:38 --> Loader Class Initialized
INFO - 2016-03-01 05:20:38 --> Helper loaded: url_helper
INFO - 2016-03-01 05:20:38 --> Helper loaded: file_helper
INFO - 2016-03-01 05:20:38 --> Helper loaded: date_helper
INFO - 2016-03-01 05:20:38 --> Helper loaded: form_helper
INFO - 2016-03-01 05:20:38 --> Database Driver Class Initialized
INFO - 2016-03-01 05:20:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:20:39 --> Controller Class Initialized
INFO - 2016-03-01 05:20:39 --> Model Class Initialized
INFO - 2016-03-01 05:20:39 --> Model Class Initialized
INFO - 2016-03-01 05:20:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:20:39 --> Pagination Class Initialized
INFO - 2016-03-01 05:20:39 --> Helper loaded: text_helper
INFO - 2016-03-01 05:20:39 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:20:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:20:39 --> Final output sent to browser
DEBUG - 2016-03-01 08:20:39 --> Total execution time: 1.2080
INFO - 2016-03-01 05:21:11 --> Config Class Initialized
INFO - 2016-03-01 05:21:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:21:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:21:11 --> Utf8 Class Initialized
INFO - 2016-03-01 05:21:11 --> URI Class Initialized
INFO - 2016-03-01 05:21:11 --> Router Class Initialized
INFO - 2016-03-01 05:21:11 --> Output Class Initialized
INFO - 2016-03-01 05:21:11 --> Security Class Initialized
DEBUG - 2016-03-01 05:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:21:11 --> Input Class Initialized
INFO - 2016-03-01 05:21:11 --> Language Class Initialized
INFO - 2016-03-01 05:21:11 --> Loader Class Initialized
INFO - 2016-03-01 05:21:11 --> Helper loaded: url_helper
INFO - 2016-03-01 05:21:11 --> Helper loaded: file_helper
INFO - 2016-03-01 05:21:11 --> Helper loaded: date_helper
INFO - 2016-03-01 05:21:11 --> Helper loaded: form_helper
INFO - 2016-03-01 05:21:11 --> Database Driver Class Initialized
INFO - 2016-03-01 05:21:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:21:12 --> Controller Class Initialized
INFO - 2016-03-01 05:21:12 --> Model Class Initialized
INFO - 2016-03-01 05:21:12 --> Model Class Initialized
INFO - 2016-03-01 05:21:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:21:12 --> Pagination Class Initialized
INFO - 2016-03-01 05:21:12 --> Helper loaded: text_helper
INFO - 2016-03-01 05:21:12 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:21:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:21:12 --> Final output sent to browser
DEBUG - 2016-03-01 08:21:12 --> Total execution time: 1.1723
INFO - 2016-03-01 05:21:28 --> Config Class Initialized
INFO - 2016-03-01 05:21:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:21:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:21:28 --> Utf8 Class Initialized
INFO - 2016-03-01 05:21:28 --> URI Class Initialized
INFO - 2016-03-01 05:21:28 --> Router Class Initialized
INFO - 2016-03-01 05:21:28 --> Output Class Initialized
INFO - 2016-03-01 05:21:28 --> Security Class Initialized
DEBUG - 2016-03-01 05:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:21:28 --> Input Class Initialized
INFO - 2016-03-01 05:21:28 --> Language Class Initialized
INFO - 2016-03-01 05:21:28 --> Loader Class Initialized
INFO - 2016-03-01 05:21:28 --> Helper loaded: url_helper
INFO - 2016-03-01 05:21:28 --> Helper loaded: file_helper
INFO - 2016-03-01 05:21:28 --> Helper loaded: date_helper
INFO - 2016-03-01 05:21:28 --> Helper loaded: form_helper
INFO - 2016-03-01 05:21:28 --> Database Driver Class Initialized
INFO - 2016-03-01 05:21:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:21:29 --> Controller Class Initialized
INFO - 2016-03-01 05:21:29 --> Model Class Initialized
INFO - 2016-03-01 05:21:29 --> Model Class Initialized
INFO - 2016-03-01 05:21:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:21:29 --> Pagination Class Initialized
INFO - 2016-03-01 05:21:29 --> Helper loaded: text_helper
INFO - 2016-03-01 05:21:29 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:21:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:21:29 --> Final output sent to browser
DEBUG - 2016-03-01 08:21:29 --> Total execution time: 1.2136
INFO - 2016-03-01 05:21:47 --> Config Class Initialized
INFO - 2016-03-01 05:21:47 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:21:47 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:21:47 --> Utf8 Class Initialized
INFO - 2016-03-01 05:21:47 --> URI Class Initialized
INFO - 2016-03-01 05:21:47 --> Router Class Initialized
INFO - 2016-03-01 05:21:47 --> Output Class Initialized
INFO - 2016-03-01 05:21:47 --> Security Class Initialized
DEBUG - 2016-03-01 05:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:21:47 --> Input Class Initialized
INFO - 2016-03-01 05:21:47 --> Language Class Initialized
INFO - 2016-03-01 05:21:47 --> Loader Class Initialized
INFO - 2016-03-01 05:21:47 --> Helper loaded: url_helper
INFO - 2016-03-01 05:21:47 --> Helper loaded: file_helper
INFO - 2016-03-01 05:21:47 --> Helper loaded: date_helper
INFO - 2016-03-01 05:21:47 --> Helper loaded: form_helper
INFO - 2016-03-01 05:21:47 --> Database Driver Class Initialized
INFO - 2016-03-01 05:21:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:21:48 --> Controller Class Initialized
INFO - 2016-03-01 05:21:48 --> Model Class Initialized
INFO - 2016-03-01 05:21:48 --> Model Class Initialized
INFO - 2016-03-01 05:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:21:48 --> Pagination Class Initialized
INFO - 2016-03-01 05:21:48 --> Helper loaded: text_helper
INFO - 2016-03-01 05:21:48 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:21:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:21:48 --> Final output sent to browser
DEBUG - 2016-03-01 08:21:48 --> Total execution time: 1.1543
INFO - 2016-03-01 05:21:55 --> Config Class Initialized
INFO - 2016-03-01 05:21:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:21:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:21:55 --> Utf8 Class Initialized
INFO - 2016-03-01 05:21:55 --> URI Class Initialized
INFO - 2016-03-01 05:21:55 --> Router Class Initialized
INFO - 2016-03-01 05:21:55 --> Output Class Initialized
INFO - 2016-03-01 05:21:55 --> Security Class Initialized
DEBUG - 2016-03-01 05:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:21:55 --> Input Class Initialized
INFO - 2016-03-01 05:21:55 --> Language Class Initialized
INFO - 2016-03-01 05:21:55 --> Loader Class Initialized
INFO - 2016-03-01 05:21:55 --> Helper loaded: url_helper
INFO - 2016-03-01 05:21:55 --> Helper loaded: file_helper
INFO - 2016-03-01 05:21:55 --> Helper loaded: date_helper
INFO - 2016-03-01 05:21:55 --> Helper loaded: form_helper
INFO - 2016-03-01 05:21:55 --> Database Driver Class Initialized
INFO - 2016-03-01 05:21:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:21:57 --> Controller Class Initialized
INFO - 2016-03-01 05:21:57 --> Model Class Initialized
INFO - 2016-03-01 05:21:57 --> Model Class Initialized
INFO - 2016-03-01 05:21:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:21:57 --> Pagination Class Initialized
INFO - 2016-03-01 05:21:57 --> Helper loaded: text_helper
INFO - 2016-03-01 05:21:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:21:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:21:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:21:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:21:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:21:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:21:57 --> Final output sent to browser
DEBUG - 2016-03-01 08:21:57 --> Total execution time: 1.2434
INFO - 2016-03-01 05:22:24 --> Config Class Initialized
INFO - 2016-03-01 05:22:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:22:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:22:24 --> Utf8 Class Initialized
INFO - 2016-03-01 05:22:24 --> URI Class Initialized
INFO - 2016-03-01 05:22:24 --> Router Class Initialized
INFO - 2016-03-01 05:22:24 --> Output Class Initialized
INFO - 2016-03-01 05:22:24 --> Security Class Initialized
DEBUG - 2016-03-01 05:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:22:24 --> Input Class Initialized
INFO - 2016-03-01 05:22:24 --> Language Class Initialized
INFO - 2016-03-01 05:22:24 --> Loader Class Initialized
INFO - 2016-03-01 05:22:24 --> Helper loaded: url_helper
INFO - 2016-03-01 05:22:24 --> Helper loaded: file_helper
INFO - 2016-03-01 05:22:24 --> Helper loaded: date_helper
INFO - 2016-03-01 05:22:24 --> Helper loaded: form_helper
INFO - 2016-03-01 05:22:24 --> Database Driver Class Initialized
INFO - 2016-03-01 05:22:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:22:25 --> Controller Class Initialized
INFO - 2016-03-01 05:22:25 --> Model Class Initialized
INFO - 2016-03-01 05:22:25 --> Model Class Initialized
INFO - 2016-03-01 05:22:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:22:25 --> Pagination Class Initialized
INFO - 2016-03-01 05:22:25 --> Helper loaded: text_helper
INFO - 2016-03-01 05:22:25 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:22:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:22:25 --> Final output sent to browser
DEBUG - 2016-03-01 08:22:25 --> Total execution time: 1.2211
INFO - 2016-03-01 05:23:09 --> Config Class Initialized
INFO - 2016-03-01 05:23:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:23:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:23:09 --> Utf8 Class Initialized
INFO - 2016-03-01 05:23:09 --> URI Class Initialized
INFO - 2016-03-01 05:23:09 --> Router Class Initialized
INFO - 2016-03-01 05:23:09 --> Output Class Initialized
INFO - 2016-03-01 05:23:09 --> Security Class Initialized
DEBUG - 2016-03-01 05:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:23:09 --> Input Class Initialized
INFO - 2016-03-01 05:23:09 --> Language Class Initialized
INFO - 2016-03-01 05:23:09 --> Loader Class Initialized
INFO - 2016-03-01 05:23:09 --> Helper loaded: url_helper
INFO - 2016-03-01 05:23:09 --> Helper loaded: file_helper
INFO - 2016-03-01 05:23:09 --> Helper loaded: date_helper
INFO - 2016-03-01 05:23:09 --> Helper loaded: form_helper
INFO - 2016-03-01 05:23:09 --> Database Driver Class Initialized
INFO - 2016-03-01 05:23:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:23:10 --> Controller Class Initialized
INFO - 2016-03-01 05:23:10 --> Model Class Initialized
INFO - 2016-03-01 05:23:10 --> Model Class Initialized
INFO - 2016-03-01 05:23:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:23:10 --> Pagination Class Initialized
INFO - 2016-03-01 05:23:10 --> Helper loaded: text_helper
INFO - 2016-03-01 05:23:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:23:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:23:10 --> Final output sent to browser
DEBUG - 2016-03-01 08:23:10 --> Total execution time: 1.1894
INFO - 2016-03-01 05:26:41 --> Config Class Initialized
INFO - 2016-03-01 05:26:41 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:26:41 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:26:41 --> Utf8 Class Initialized
INFO - 2016-03-01 05:26:41 --> URI Class Initialized
INFO - 2016-03-01 05:26:41 --> Router Class Initialized
INFO - 2016-03-01 05:26:41 --> Output Class Initialized
INFO - 2016-03-01 05:26:41 --> Security Class Initialized
DEBUG - 2016-03-01 05:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:26:41 --> Input Class Initialized
INFO - 2016-03-01 05:26:41 --> Language Class Initialized
INFO - 2016-03-01 05:26:41 --> Loader Class Initialized
INFO - 2016-03-01 05:26:41 --> Helper loaded: url_helper
INFO - 2016-03-01 05:26:41 --> Helper loaded: file_helper
INFO - 2016-03-01 05:26:41 --> Helper loaded: date_helper
INFO - 2016-03-01 05:26:41 --> Helper loaded: form_helper
INFO - 2016-03-01 05:26:41 --> Database Driver Class Initialized
INFO - 2016-03-01 05:26:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:26:42 --> Controller Class Initialized
INFO - 2016-03-01 05:26:42 --> Model Class Initialized
INFO - 2016-03-01 05:26:42 --> Model Class Initialized
INFO - 2016-03-01 05:26:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:26:42 --> Pagination Class Initialized
INFO - 2016-03-01 05:26:42 --> Helper loaded: text_helper
INFO - 2016-03-01 05:26:42 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:26:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:26:42 --> Final output sent to browser
DEBUG - 2016-03-01 08:26:42 --> Total execution time: 1.1991
INFO - 2016-03-01 05:27:16 --> Config Class Initialized
INFO - 2016-03-01 05:27:16 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:27:16 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:27:16 --> Utf8 Class Initialized
INFO - 2016-03-01 05:27:16 --> URI Class Initialized
INFO - 2016-03-01 05:27:16 --> Router Class Initialized
INFO - 2016-03-01 05:27:16 --> Output Class Initialized
INFO - 2016-03-01 05:27:16 --> Security Class Initialized
DEBUG - 2016-03-01 05:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:27:16 --> Input Class Initialized
INFO - 2016-03-01 05:27:17 --> Language Class Initialized
INFO - 2016-03-01 05:27:17 --> Loader Class Initialized
INFO - 2016-03-01 05:27:17 --> Helper loaded: url_helper
INFO - 2016-03-01 05:27:17 --> Helper loaded: file_helper
INFO - 2016-03-01 05:27:17 --> Helper loaded: date_helper
INFO - 2016-03-01 05:27:17 --> Helper loaded: form_helper
INFO - 2016-03-01 05:27:17 --> Database Driver Class Initialized
INFO - 2016-03-01 05:27:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:27:18 --> Controller Class Initialized
INFO - 2016-03-01 05:27:18 --> Model Class Initialized
INFO - 2016-03-01 05:27:18 --> Model Class Initialized
INFO - 2016-03-01 05:27:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:27:18 --> Pagination Class Initialized
INFO - 2016-03-01 05:27:18 --> Helper loaded: text_helper
INFO - 2016-03-01 05:27:18 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:27:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:27:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:27:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:27:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:27:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:27:18 --> Final output sent to browser
DEBUG - 2016-03-01 08:27:18 --> Total execution time: 1.1739
INFO - 2016-03-01 05:27:34 --> Config Class Initialized
INFO - 2016-03-01 05:27:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:27:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:27:34 --> Utf8 Class Initialized
INFO - 2016-03-01 05:27:34 --> URI Class Initialized
INFO - 2016-03-01 05:27:34 --> Router Class Initialized
INFO - 2016-03-01 05:27:34 --> Output Class Initialized
INFO - 2016-03-01 05:27:34 --> Security Class Initialized
DEBUG - 2016-03-01 05:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:27:34 --> Input Class Initialized
INFO - 2016-03-01 05:27:34 --> Language Class Initialized
INFO - 2016-03-01 05:27:34 --> Loader Class Initialized
INFO - 2016-03-01 05:27:34 --> Helper loaded: url_helper
INFO - 2016-03-01 05:27:34 --> Helper loaded: file_helper
INFO - 2016-03-01 05:27:34 --> Helper loaded: date_helper
INFO - 2016-03-01 05:27:34 --> Helper loaded: form_helper
INFO - 2016-03-01 05:27:34 --> Database Driver Class Initialized
INFO - 2016-03-01 05:27:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:27:35 --> Controller Class Initialized
INFO - 2016-03-01 05:27:35 --> Model Class Initialized
INFO - 2016-03-01 05:27:35 --> Model Class Initialized
INFO - 2016-03-01 05:27:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:27:35 --> Pagination Class Initialized
INFO - 2016-03-01 05:27:35 --> Helper loaded: text_helper
INFO - 2016-03-01 05:27:35 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:27:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:27:35 --> Final output sent to browser
DEBUG - 2016-03-01 08:27:35 --> Total execution time: 1.2619
INFO - 2016-03-01 05:28:37 --> Config Class Initialized
INFO - 2016-03-01 05:28:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:28:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:28:37 --> Utf8 Class Initialized
INFO - 2016-03-01 05:28:37 --> URI Class Initialized
INFO - 2016-03-01 05:28:37 --> Router Class Initialized
INFO - 2016-03-01 05:28:37 --> Output Class Initialized
INFO - 2016-03-01 05:28:37 --> Security Class Initialized
DEBUG - 2016-03-01 05:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:28:37 --> Input Class Initialized
INFO - 2016-03-01 05:28:37 --> Language Class Initialized
INFO - 2016-03-01 05:28:37 --> Loader Class Initialized
INFO - 2016-03-01 05:28:37 --> Helper loaded: url_helper
INFO - 2016-03-01 05:28:37 --> Helper loaded: file_helper
INFO - 2016-03-01 05:28:37 --> Helper loaded: date_helper
INFO - 2016-03-01 05:28:37 --> Helper loaded: form_helper
INFO - 2016-03-01 05:28:37 --> Database Driver Class Initialized
INFO - 2016-03-01 05:28:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:28:38 --> Controller Class Initialized
INFO - 2016-03-01 05:28:38 --> Model Class Initialized
INFO - 2016-03-01 05:28:38 --> Model Class Initialized
INFO - 2016-03-01 05:28:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:28:38 --> Pagination Class Initialized
INFO - 2016-03-01 05:28:38 --> Helper loaded: text_helper
INFO - 2016-03-01 05:28:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:28:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:28:38 --> Final output sent to browser
DEBUG - 2016-03-01 08:28:38 --> Total execution time: 1.2384
INFO - 2016-03-01 05:30:12 --> Config Class Initialized
INFO - 2016-03-01 05:30:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:30:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:30:12 --> Utf8 Class Initialized
INFO - 2016-03-01 05:30:12 --> URI Class Initialized
INFO - 2016-03-01 05:30:12 --> Router Class Initialized
INFO - 2016-03-01 05:30:12 --> Output Class Initialized
INFO - 2016-03-01 05:30:12 --> Security Class Initialized
DEBUG - 2016-03-01 05:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:30:12 --> Input Class Initialized
INFO - 2016-03-01 05:30:12 --> Language Class Initialized
INFO - 2016-03-01 05:30:12 --> Loader Class Initialized
INFO - 2016-03-01 05:30:12 --> Helper loaded: url_helper
INFO - 2016-03-01 05:30:12 --> Helper loaded: file_helper
INFO - 2016-03-01 05:30:12 --> Helper loaded: date_helper
INFO - 2016-03-01 05:30:12 --> Helper loaded: form_helper
INFO - 2016-03-01 05:30:12 --> Database Driver Class Initialized
INFO - 2016-03-01 05:30:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:30:13 --> Controller Class Initialized
INFO - 2016-03-01 05:30:13 --> Model Class Initialized
INFO - 2016-03-01 05:30:13 --> Model Class Initialized
INFO - 2016-03-01 05:30:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:30:13 --> Pagination Class Initialized
INFO - 2016-03-01 05:30:13 --> Helper loaded: text_helper
INFO - 2016-03-01 05:30:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:30:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:30:13 --> Final output sent to browser
DEBUG - 2016-03-01 08:30:13 --> Total execution time: 1.1703
INFO - 2016-03-01 05:30:22 --> Config Class Initialized
INFO - 2016-03-01 05:30:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:30:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:30:22 --> Utf8 Class Initialized
INFO - 2016-03-01 05:30:22 --> URI Class Initialized
INFO - 2016-03-01 05:30:22 --> Router Class Initialized
INFO - 2016-03-01 05:30:22 --> Output Class Initialized
INFO - 2016-03-01 05:30:22 --> Security Class Initialized
DEBUG - 2016-03-01 05:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:30:22 --> Input Class Initialized
INFO - 2016-03-01 05:30:22 --> Language Class Initialized
INFO - 2016-03-01 05:30:22 --> Loader Class Initialized
INFO - 2016-03-01 05:30:22 --> Helper loaded: url_helper
INFO - 2016-03-01 05:30:22 --> Helper loaded: file_helper
INFO - 2016-03-01 05:30:22 --> Helper loaded: date_helper
INFO - 2016-03-01 05:30:22 --> Helper loaded: form_helper
INFO - 2016-03-01 05:30:22 --> Database Driver Class Initialized
INFO - 2016-03-01 05:30:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:30:23 --> Controller Class Initialized
INFO - 2016-03-01 05:30:23 --> Model Class Initialized
INFO - 2016-03-01 05:30:23 --> Model Class Initialized
INFO - 2016-03-01 05:30:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:30:23 --> Pagination Class Initialized
INFO - 2016-03-01 05:30:23 --> Helper loaded: text_helper
INFO - 2016-03-01 05:30:23 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:30:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:30:23 --> Final output sent to browser
DEBUG - 2016-03-01 08:30:23 --> Total execution time: 1.1850
INFO - 2016-03-01 05:30:25 --> Config Class Initialized
INFO - 2016-03-01 05:30:25 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:30:25 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:30:25 --> Utf8 Class Initialized
INFO - 2016-03-01 05:30:25 --> URI Class Initialized
INFO - 2016-03-01 05:30:25 --> Router Class Initialized
INFO - 2016-03-01 05:30:25 --> Output Class Initialized
INFO - 2016-03-01 05:30:25 --> Security Class Initialized
DEBUG - 2016-03-01 05:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:30:25 --> Input Class Initialized
INFO - 2016-03-01 05:30:25 --> Language Class Initialized
INFO - 2016-03-01 05:30:25 --> Loader Class Initialized
INFO - 2016-03-01 05:30:25 --> Helper loaded: url_helper
INFO - 2016-03-01 05:30:25 --> Helper loaded: file_helper
INFO - 2016-03-01 05:30:25 --> Helper loaded: date_helper
INFO - 2016-03-01 05:30:25 --> Helper loaded: form_helper
INFO - 2016-03-01 05:30:25 --> Database Driver Class Initialized
INFO - 2016-03-01 05:30:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:30:26 --> Controller Class Initialized
INFO - 2016-03-01 05:30:26 --> Model Class Initialized
INFO - 2016-03-01 05:30:26 --> Model Class Initialized
INFO - 2016-03-01 05:30:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:30:26 --> Pagination Class Initialized
INFO - 2016-03-01 05:30:26 --> Helper loaded: text_helper
INFO - 2016-03-01 05:30:26 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:30:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:30:26 --> Final output sent to browser
DEBUG - 2016-03-01 08:30:26 --> Total execution time: 1.2231
INFO - 2016-03-01 05:30:50 --> Config Class Initialized
INFO - 2016-03-01 05:30:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:30:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:30:50 --> Utf8 Class Initialized
INFO - 2016-03-01 05:30:50 --> URI Class Initialized
INFO - 2016-03-01 05:30:50 --> Router Class Initialized
INFO - 2016-03-01 05:30:50 --> Output Class Initialized
INFO - 2016-03-01 05:30:50 --> Security Class Initialized
DEBUG - 2016-03-01 05:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:30:50 --> Input Class Initialized
INFO - 2016-03-01 05:30:50 --> Language Class Initialized
INFO - 2016-03-01 05:30:50 --> Loader Class Initialized
INFO - 2016-03-01 05:30:50 --> Helper loaded: url_helper
INFO - 2016-03-01 05:30:50 --> Helper loaded: file_helper
INFO - 2016-03-01 05:30:50 --> Helper loaded: date_helper
INFO - 2016-03-01 05:30:50 --> Helper loaded: form_helper
INFO - 2016-03-01 05:30:50 --> Database Driver Class Initialized
INFO - 2016-03-01 05:30:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:30:51 --> Controller Class Initialized
INFO - 2016-03-01 05:30:51 --> Model Class Initialized
INFO - 2016-03-01 05:30:51 --> Model Class Initialized
INFO - 2016-03-01 05:30:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:30:51 --> Pagination Class Initialized
INFO - 2016-03-01 05:30:51 --> Helper loaded: text_helper
INFO - 2016-03-01 05:30:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:30:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:30:51 --> Final output sent to browser
DEBUG - 2016-03-01 08:30:51 --> Total execution time: 1.2203
INFO - 2016-03-01 05:31:37 --> Config Class Initialized
INFO - 2016-03-01 05:31:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:31:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:31:37 --> Utf8 Class Initialized
INFO - 2016-03-01 05:31:37 --> URI Class Initialized
INFO - 2016-03-01 05:31:37 --> Router Class Initialized
INFO - 2016-03-01 05:31:37 --> Output Class Initialized
INFO - 2016-03-01 05:31:37 --> Security Class Initialized
DEBUG - 2016-03-01 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:31:37 --> Input Class Initialized
INFO - 2016-03-01 05:31:37 --> Language Class Initialized
INFO - 2016-03-01 05:31:37 --> Loader Class Initialized
INFO - 2016-03-01 05:31:37 --> Helper loaded: url_helper
INFO - 2016-03-01 05:31:37 --> Helper loaded: file_helper
INFO - 2016-03-01 05:31:37 --> Helper loaded: date_helper
INFO - 2016-03-01 05:31:37 --> Helper loaded: form_helper
INFO - 2016-03-01 05:31:37 --> Database Driver Class Initialized
INFO - 2016-03-01 05:31:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:31:38 --> Controller Class Initialized
INFO - 2016-03-01 05:31:38 --> Model Class Initialized
INFO - 2016-03-01 05:31:38 --> Model Class Initialized
INFO - 2016-03-01 05:31:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:31:38 --> Pagination Class Initialized
INFO - 2016-03-01 05:31:38 --> Helper loaded: text_helper
INFO - 2016-03-01 05:31:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:31:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:31:38 --> Final output sent to browser
DEBUG - 2016-03-01 08:31:38 --> Total execution time: 1.2244
INFO - 2016-03-01 05:32:19 --> Config Class Initialized
INFO - 2016-03-01 05:32:19 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:32:19 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:32:19 --> Utf8 Class Initialized
INFO - 2016-03-01 05:32:19 --> URI Class Initialized
INFO - 2016-03-01 05:32:19 --> Router Class Initialized
INFO - 2016-03-01 05:32:19 --> Output Class Initialized
INFO - 2016-03-01 05:32:19 --> Security Class Initialized
DEBUG - 2016-03-01 05:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:32:19 --> Input Class Initialized
INFO - 2016-03-01 05:32:19 --> Language Class Initialized
INFO - 2016-03-01 05:32:19 --> Loader Class Initialized
INFO - 2016-03-01 05:32:19 --> Helper loaded: url_helper
INFO - 2016-03-01 05:32:19 --> Helper loaded: file_helper
INFO - 2016-03-01 05:32:19 --> Helper loaded: date_helper
INFO - 2016-03-01 05:32:19 --> Helper loaded: form_helper
INFO - 2016-03-01 05:32:19 --> Database Driver Class Initialized
INFO - 2016-03-01 05:32:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:32:20 --> Controller Class Initialized
INFO - 2016-03-01 05:32:20 --> Model Class Initialized
INFO - 2016-03-01 05:32:20 --> Model Class Initialized
INFO - 2016-03-01 05:32:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:32:20 --> Pagination Class Initialized
INFO - 2016-03-01 05:32:20 --> Helper loaded: text_helper
INFO - 2016-03-01 05:32:20 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:32:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:32:20 --> Final output sent to browser
DEBUG - 2016-03-01 08:32:20 --> Total execution time: 1.1641
INFO - 2016-03-01 05:33:27 --> Config Class Initialized
INFO - 2016-03-01 05:33:27 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:33:27 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:33:27 --> Utf8 Class Initialized
INFO - 2016-03-01 05:33:27 --> URI Class Initialized
INFO - 2016-03-01 05:33:27 --> Router Class Initialized
INFO - 2016-03-01 05:33:27 --> Output Class Initialized
INFO - 2016-03-01 05:33:27 --> Security Class Initialized
DEBUG - 2016-03-01 05:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:33:27 --> Input Class Initialized
INFO - 2016-03-01 05:33:27 --> Language Class Initialized
INFO - 2016-03-01 05:33:27 --> Loader Class Initialized
INFO - 2016-03-01 05:33:27 --> Helper loaded: url_helper
INFO - 2016-03-01 05:33:27 --> Helper loaded: file_helper
INFO - 2016-03-01 05:33:27 --> Helper loaded: date_helper
INFO - 2016-03-01 05:33:27 --> Helper loaded: form_helper
INFO - 2016-03-01 05:33:27 --> Database Driver Class Initialized
INFO - 2016-03-01 05:33:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:33:28 --> Controller Class Initialized
INFO - 2016-03-01 05:33:28 --> Model Class Initialized
INFO - 2016-03-01 05:33:28 --> Model Class Initialized
INFO - 2016-03-01 05:33:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:33:28 --> Pagination Class Initialized
INFO - 2016-03-01 05:33:28 --> Helper loaded: text_helper
INFO - 2016-03-01 05:33:28 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:33:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:33:28 --> Final output sent to browser
DEBUG - 2016-03-01 08:33:28 --> Total execution time: 1.1874
INFO - 2016-03-01 05:34:09 --> Config Class Initialized
INFO - 2016-03-01 05:34:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:34:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:34:09 --> Utf8 Class Initialized
INFO - 2016-03-01 05:34:09 --> URI Class Initialized
INFO - 2016-03-01 05:34:09 --> Router Class Initialized
INFO - 2016-03-01 05:34:09 --> Output Class Initialized
INFO - 2016-03-01 05:34:09 --> Security Class Initialized
DEBUG - 2016-03-01 05:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:34:09 --> Input Class Initialized
INFO - 2016-03-01 05:34:09 --> Language Class Initialized
INFO - 2016-03-01 05:34:09 --> Loader Class Initialized
INFO - 2016-03-01 05:34:09 --> Helper loaded: url_helper
INFO - 2016-03-01 05:34:09 --> Helper loaded: file_helper
INFO - 2016-03-01 05:34:09 --> Helper loaded: date_helper
INFO - 2016-03-01 05:34:09 --> Helper loaded: form_helper
INFO - 2016-03-01 05:34:09 --> Database Driver Class Initialized
INFO - 2016-03-01 05:34:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:34:10 --> Controller Class Initialized
INFO - 2016-03-01 05:34:10 --> Model Class Initialized
INFO - 2016-03-01 05:34:10 --> Model Class Initialized
INFO - 2016-03-01 05:34:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:34:10 --> Pagination Class Initialized
INFO - 2016-03-01 05:34:10 --> Helper loaded: text_helper
INFO - 2016-03-01 05:34:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:34:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:34:10 --> Final output sent to browser
DEBUG - 2016-03-01 08:34:10 --> Total execution time: 1.2207
INFO - 2016-03-01 05:34:44 --> Config Class Initialized
INFO - 2016-03-01 05:34:44 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:34:44 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:34:44 --> Utf8 Class Initialized
INFO - 2016-03-01 05:34:44 --> URI Class Initialized
INFO - 2016-03-01 05:34:44 --> Router Class Initialized
INFO - 2016-03-01 05:34:44 --> Output Class Initialized
INFO - 2016-03-01 05:34:44 --> Security Class Initialized
DEBUG - 2016-03-01 05:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:34:44 --> Input Class Initialized
INFO - 2016-03-01 05:34:44 --> Language Class Initialized
INFO - 2016-03-01 05:34:44 --> Loader Class Initialized
INFO - 2016-03-01 05:34:44 --> Helper loaded: url_helper
INFO - 2016-03-01 05:34:44 --> Helper loaded: file_helper
INFO - 2016-03-01 05:34:44 --> Helper loaded: date_helper
INFO - 2016-03-01 05:34:44 --> Helper loaded: form_helper
INFO - 2016-03-01 05:34:44 --> Database Driver Class Initialized
INFO - 2016-03-01 05:34:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:34:45 --> Controller Class Initialized
INFO - 2016-03-01 05:34:45 --> Model Class Initialized
INFO - 2016-03-01 05:34:45 --> Model Class Initialized
INFO - 2016-03-01 05:34:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:34:45 --> Pagination Class Initialized
INFO - 2016-03-01 05:34:45 --> Helper loaded: text_helper
INFO - 2016-03-01 05:34:45 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:34:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:34:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:34:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:34:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:34:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:34:45 --> Final output sent to browser
DEBUG - 2016-03-01 08:34:45 --> Total execution time: 1.2219
INFO - 2016-03-01 05:35:12 --> Config Class Initialized
INFO - 2016-03-01 05:35:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:35:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:35:12 --> Utf8 Class Initialized
INFO - 2016-03-01 05:35:12 --> URI Class Initialized
INFO - 2016-03-01 05:35:12 --> Router Class Initialized
INFO - 2016-03-01 05:35:12 --> Output Class Initialized
INFO - 2016-03-01 05:35:12 --> Security Class Initialized
DEBUG - 2016-03-01 05:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:35:12 --> Input Class Initialized
INFO - 2016-03-01 05:35:12 --> Language Class Initialized
INFO - 2016-03-01 05:35:12 --> Loader Class Initialized
INFO - 2016-03-01 05:35:12 --> Helper loaded: url_helper
INFO - 2016-03-01 05:35:12 --> Helper loaded: file_helper
INFO - 2016-03-01 05:35:12 --> Helper loaded: date_helper
INFO - 2016-03-01 05:35:12 --> Helper loaded: form_helper
INFO - 2016-03-01 05:35:12 --> Database Driver Class Initialized
INFO - 2016-03-01 05:35:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:35:13 --> Controller Class Initialized
INFO - 2016-03-01 05:35:13 --> Model Class Initialized
INFO - 2016-03-01 05:35:13 --> Model Class Initialized
INFO - 2016-03-01 05:35:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:35:13 --> Pagination Class Initialized
INFO - 2016-03-01 05:35:13 --> Helper loaded: text_helper
INFO - 2016-03-01 05:35:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:35:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:35:14 --> Final output sent to browser
DEBUG - 2016-03-01 08:35:14 --> Total execution time: 1.2056
INFO - 2016-03-01 05:35:46 --> Config Class Initialized
INFO - 2016-03-01 05:35:46 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:35:46 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:35:46 --> Utf8 Class Initialized
INFO - 2016-03-01 05:35:46 --> URI Class Initialized
INFO - 2016-03-01 05:35:46 --> Router Class Initialized
INFO - 2016-03-01 05:35:46 --> Output Class Initialized
INFO - 2016-03-01 05:35:46 --> Security Class Initialized
DEBUG - 2016-03-01 05:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:35:46 --> Input Class Initialized
INFO - 2016-03-01 05:35:46 --> Language Class Initialized
INFO - 2016-03-01 05:35:46 --> Loader Class Initialized
INFO - 2016-03-01 05:35:46 --> Helper loaded: url_helper
INFO - 2016-03-01 05:35:46 --> Helper loaded: file_helper
INFO - 2016-03-01 05:35:46 --> Helper loaded: date_helper
INFO - 2016-03-01 05:35:46 --> Helper loaded: form_helper
INFO - 2016-03-01 05:35:46 --> Database Driver Class Initialized
INFO - 2016-03-01 05:35:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:35:47 --> Controller Class Initialized
INFO - 2016-03-01 05:35:47 --> Model Class Initialized
INFO - 2016-03-01 05:35:47 --> Model Class Initialized
INFO - 2016-03-01 05:35:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:35:47 --> Pagination Class Initialized
INFO - 2016-03-01 05:35:47 --> Helper loaded: text_helper
INFO - 2016-03-01 05:35:47 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:35:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:35:47 --> Final output sent to browser
DEBUG - 2016-03-01 08:35:47 --> Total execution time: 1.2354
INFO - 2016-03-01 05:36:32 --> Config Class Initialized
INFO - 2016-03-01 05:36:32 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:36:32 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:36:32 --> Utf8 Class Initialized
INFO - 2016-03-01 05:36:32 --> URI Class Initialized
INFO - 2016-03-01 05:36:32 --> Router Class Initialized
INFO - 2016-03-01 05:36:32 --> Output Class Initialized
INFO - 2016-03-01 05:36:32 --> Security Class Initialized
DEBUG - 2016-03-01 05:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:36:32 --> Input Class Initialized
INFO - 2016-03-01 05:36:32 --> Language Class Initialized
INFO - 2016-03-01 05:36:32 --> Loader Class Initialized
INFO - 2016-03-01 05:36:32 --> Helper loaded: url_helper
INFO - 2016-03-01 05:36:32 --> Helper loaded: file_helper
INFO - 2016-03-01 05:36:32 --> Helper loaded: date_helper
INFO - 2016-03-01 05:36:32 --> Helper loaded: form_helper
INFO - 2016-03-01 05:36:32 --> Database Driver Class Initialized
INFO - 2016-03-01 05:36:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:36:33 --> Controller Class Initialized
INFO - 2016-03-01 05:36:33 --> Model Class Initialized
INFO - 2016-03-01 05:36:33 --> Model Class Initialized
INFO - 2016-03-01 05:36:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:36:33 --> Pagination Class Initialized
INFO - 2016-03-01 05:36:33 --> Helper loaded: text_helper
INFO - 2016-03-01 05:36:33 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:36:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:36:33 --> Final output sent to browser
DEBUG - 2016-03-01 08:36:33 --> Total execution time: 1.2186
INFO - 2016-03-01 05:37:03 --> Config Class Initialized
INFO - 2016-03-01 05:37:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:37:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:37:03 --> Utf8 Class Initialized
INFO - 2016-03-01 05:37:03 --> URI Class Initialized
INFO - 2016-03-01 05:37:03 --> Router Class Initialized
INFO - 2016-03-01 05:37:03 --> Output Class Initialized
INFO - 2016-03-01 05:37:03 --> Security Class Initialized
DEBUG - 2016-03-01 05:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:37:03 --> Input Class Initialized
INFO - 2016-03-01 05:37:03 --> Language Class Initialized
INFO - 2016-03-01 05:37:03 --> Loader Class Initialized
INFO - 2016-03-01 05:37:03 --> Helper loaded: url_helper
INFO - 2016-03-01 05:37:03 --> Helper loaded: file_helper
INFO - 2016-03-01 05:37:03 --> Helper loaded: date_helper
INFO - 2016-03-01 05:37:03 --> Helper loaded: form_helper
INFO - 2016-03-01 05:37:03 --> Database Driver Class Initialized
INFO - 2016-03-01 05:37:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:37:04 --> Controller Class Initialized
INFO - 2016-03-01 05:37:04 --> Model Class Initialized
INFO - 2016-03-01 05:37:04 --> Model Class Initialized
INFO - 2016-03-01 05:37:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:37:04 --> Pagination Class Initialized
INFO - 2016-03-01 05:37:04 --> Helper loaded: text_helper
INFO - 2016-03-01 05:37:04 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:37:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:37:04 --> Final output sent to browser
DEBUG - 2016-03-01 08:37:04 --> Total execution time: 1.1983
INFO - 2016-03-01 05:40:38 --> Config Class Initialized
INFO - 2016-03-01 05:40:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:40:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:40:38 --> Utf8 Class Initialized
INFO - 2016-03-01 05:40:38 --> URI Class Initialized
INFO - 2016-03-01 05:40:38 --> Router Class Initialized
INFO - 2016-03-01 05:40:38 --> Output Class Initialized
INFO - 2016-03-01 05:40:38 --> Security Class Initialized
DEBUG - 2016-03-01 05:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:40:38 --> Input Class Initialized
INFO - 2016-03-01 05:40:38 --> Language Class Initialized
INFO - 2016-03-01 05:40:38 --> Loader Class Initialized
INFO - 2016-03-01 05:40:38 --> Helper loaded: url_helper
INFO - 2016-03-01 05:40:38 --> Helper loaded: file_helper
INFO - 2016-03-01 05:40:38 --> Helper loaded: date_helper
INFO - 2016-03-01 05:40:38 --> Helper loaded: form_helper
INFO - 2016-03-01 05:40:38 --> Database Driver Class Initialized
INFO - 2016-03-01 05:40:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:40:39 --> Controller Class Initialized
INFO - 2016-03-01 05:40:39 --> Model Class Initialized
INFO - 2016-03-01 05:40:39 --> Model Class Initialized
INFO - 2016-03-01 05:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:40:39 --> Pagination Class Initialized
INFO - 2016-03-01 05:40:39 --> Helper loaded: text_helper
INFO - 2016-03-01 05:40:39 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:40:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:40:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:40:40 --> Final output sent to browser
DEBUG - 2016-03-01 08:40:40 --> Total execution time: 1.2273
INFO - 2016-03-01 05:41:36 --> Config Class Initialized
INFO - 2016-03-01 05:41:36 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:41:36 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:41:36 --> Utf8 Class Initialized
INFO - 2016-03-01 05:41:36 --> URI Class Initialized
INFO - 2016-03-01 05:41:36 --> Router Class Initialized
INFO - 2016-03-01 05:41:36 --> Output Class Initialized
INFO - 2016-03-01 05:41:36 --> Security Class Initialized
DEBUG - 2016-03-01 05:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:41:36 --> Input Class Initialized
INFO - 2016-03-01 05:41:36 --> Language Class Initialized
INFO - 2016-03-01 05:41:36 --> Loader Class Initialized
INFO - 2016-03-01 05:41:36 --> Helper loaded: url_helper
INFO - 2016-03-01 05:41:36 --> Helper loaded: file_helper
INFO - 2016-03-01 05:41:36 --> Helper loaded: date_helper
INFO - 2016-03-01 05:41:36 --> Helper loaded: form_helper
INFO - 2016-03-01 05:41:36 --> Database Driver Class Initialized
INFO - 2016-03-01 05:41:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:41:38 --> Controller Class Initialized
INFO - 2016-03-01 05:41:38 --> Model Class Initialized
INFO - 2016-03-01 05:41:38 --> Model Class Initialized
INFO - 2016-03-01 05:41:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:41:38 --> Pagination Class Initialized
INFO - 2016-03-01 05:41:38 --> Helper loaded: text_helper
INFO - 2016-03-01 05:41:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:41:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:41:38 --> Final output sent to browser
DEBUG - 2016-03-01 08:41:38 --> Total execution time: 1.2068
INFO - 2016-03-01 05:43:23 --> Config Class Initialized
INFO - 2016-03-01 05:43:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:43:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:43:23 --> Utf8 Class Initialized
INFO - 2016-03-01 05:43:23 --> URI Class Initialized
INFO - 2016-03-01 05:43:23 --> Router Class Initialized
INFO - 2016-03-01 05:43:23 --> Output Class Initialized
INFO - 2016-03-01 05:43:23 --> Security Class Initialized
DEBUG - 2016-03-01 05:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:43:23 --> Input Class Initialized
INFO - 2016-03-01 05:43:23 --> Language Class Initialized
INFO - 2016-03-01 05:43:23 --> Loader Class Initialized
INFO - 2016-03-01 05:43:23 --> Helper loaded: url_helper
INFO - 2016-03-01 05:43:23 --> Helper loaded: file_helper
INFO - 2016-03-01 05:43:23 --> Helper loaded: date_helper
INFO - 2016-03-01 05:43:23 --> Helper loaded: form_helper
INFO - 2016-03-01 05:43:23 --> Database Driver Class Initialized
INFO - 2016-03-01 05:43:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:43:24 --> Controller Class Initialized
INFO - 2016-03-01 05:43:24 --> Model Class Initialized
INFO - 2016-03-01 05:43:24 --> Model Class Initialized
INFO - 2016-03-01 05:43:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:43:24 --> Pagination Class Initialized
INFO - 2016-03-01 05:43:24 --> Helper loaded: text_helper
INFO - 2016-03-01 05:43:24 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:43:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:43:24 --> Final output sent to browser
DEBUG - 2016-03-01 08:43:24 --> Total execution time: 1.2074
INFO - 2016-03-01 05:44:35 --> Config Class Initialized
INFO - 2016-03-01 05:44:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:44:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:44:35 --> Utf8 Class Initialized
INFO - 2016-03-01 05:44:35 --> URI Class Initialized
INFO - 2016-03-01 05:44:35 --> Router Class Initialized
INFO - 2016-03-01 05:44:35 --> Output Class Initialized
INFO - 2016-03-01 05:44:35 --> Security Class Initialized
DEBUG - 2016-03-01 05:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:44:35 --> Input Class Initialized
INFO - 2016-03-01 05:44:35 --> Language Class Initialized
INFO - 2016-03-01 05:44:35 --> Loader Class Initialized
INFO - 2016-03-01 05:44:35 --> Helper loaded: url_helper
INFO - 2016-03-01 05:44:35 --> Helper loaded: file_helper
INFO - 2016-03-01 05:44:35 --> Helper loaded: date_helper
INFO - 2016-03-01 05:44:35 --> Helper loaded: form_helper
INFO - 2016-03-01 05:44:35 --> Database Driver Class Initialized
INFO - 2016-03-01 05:44:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:44:36 --> Controller Class Initialized
INFO - 2016-03-01 05:44:36 --> Model Class Initialized
INFO - 2016-03-01 05:44:36 --> Model Class Initialized
INFO - 2016-03-01 05:44:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:44:36 --> Pagination Class Initialized
INFO - 2016-03-01 05:44:36 --> Helper loaded: text_helper
INFO - 2016-03-01 05:44:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:44:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:44:36 --> Final output sent to browser
DEBUG - 2016-03-01 08:44:36 --> Total execution time: 1.2498
INFO - 2016-03-01 05:46:51 --> Config Class Initialized
INFO - 2016-03-01 05:46:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:46:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:46:51 --> Utf8 Class Initialized
INFO - 2016-03-01 05:46:51 --> URI Class Initialized
INFO - 2016-03-01 05:46:51 --> Router Class Initialized
INFO - 2016-03-01 05:46:51 --> Output Class Initialized
INFO - 2016-03-01 05:46:51 --> Security Class Initialized
DEBUG - 2016-03-01 05:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:46:51 --> Input Class Initialized
INFO - 2016-03-01 05:46:51 --> Language Class Initialized
INFO - 2016-03-01 05:46:51 --> Loader Class Initialized
INFO - 2016-03-01 05:46:51 --> Helper loaded: url_helper
INFO - 2016-03-01 05:46:51 --> Helper loaded: file_helper
INFO - 2016-03-01 05:46:51 --> Helper loaded: date_helper
INFO - 2016-03-01 05:46:51 --> Helper loaded: form_helper
INFO - 2016-03-01 05:46:51 --> Database Driver Class Initialized
INFO - 2016-03-01 05:46:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:46:52 --> Controller Class Initialized
INFO - 2016-03-01 05:46:52 --> Model Class Initialized
INFO - 2016-03-01 05:46:52 --> Model Class Initialized
INFO - 2016-03-01 05:46:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:46:52 --> Pagination Class Initialized
INFO - 2016-03-01 05:46:52 --> Helper loaded: text_helper
INFO - 2016-03-01 05:46:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:46:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:46:52 --> Final output sent to browser
DEBUG - 2016-03-01 08:46:52 --> Total execution time: 1.1948
INFO - 2016-03-01 05:47:01 --> Config Class Initialized
INFO - 2016-03-01 05:47:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:47:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:47:01 --> Utf8 Class Initialized
INFO - 2016-03-01 05:47:01 --> URI Class Initialized
INFO - 2016-03-01 05:47:01 --> Router Class Initialized
INFO - 2016-03-01 05:47:01 --> Output Class Initialized
INFO - 2016-03-01 05:47:01 --> Security Class Initialized
DEBUG - 2016-03-01 05:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:47:01 --> Input Class Initialized
INFO - 2016-03-01 05:47:01 --> Language Class Initialized
INFO - 2016-03-01 05:47:01 --> Loader Class Initialized
INFO - 2016-03-01 05:47:01 --> Helper loaded: url_helper
INFO - 2016-03-01 05:47:01 --> Helper loaded: file_helper
INFO - 2016-03-01 05:47:01 --> Helper loaded: date_helper
INFO - 2016-03-01 05:47:01 --> Helper loaded: form_helper
INFO - 2016-03-01 05:47:01 --> Database Driver Class Initialized
INFO - 2016-03-01 05:47:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:47:02 --> Controller Class Initialized
INFO - 2016-03-01 05:47:02 --> Model Class Initialized
INFO - 2016-03-01 05:47:02 --> Model Class Initialized
INFO - 2016-03-01 05:47:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:47:02 --> Pagination Class Initialized
INFO - 2016-03-01 05:47:02 --> Helper loaded: text_helper
INFO - 2016-03-01 05:47:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:47:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:47:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:47:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:47:03 --> Final output sent to browser
DEBUG - 2016-03-01 08:47:03 --> Total execution time: 1.1509
INFO - 2016-03-01 05:49:46 --> Config Class Initialized
INFO - 2016-03-01 05:49:46 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:49:46 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:49:46 --> Utf8 Class Initialized
INFO - 2016-03-01 05:49:46 --> URI Class Initialized
INFO - 2016-03-01 05:49:46 --> Router Class Initialized
INFO - 2016-03-01 05:49:46 --> Output Class Initialized
INFO - 2016-03-01 05:49:46 --> Security Class Initialized
DEBUG - 2016-03-01 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:49:46 --> Input Class Initialized
INFO - 2016-03-01 05:49:46 --> Language Class Initialized
INFO - 2016-03-01 05:49:46 --> Loader Class Initialized
INFO - 2016-03-01 05:49:46 --> Helper loaded: url_helper
INFO - 2016-03-01 05:49:46 --> Helper loaded: file_helper
INFO - 2016-03-01 05:49:46 --> Helper loaded: date_helper
INFO - 2016-03-01 05:49:46 --> Helper loaded: form_helper
INFO - 2016-03-01 05:49:46 --> Database Driver Class Initialized
INFO - 2016-03-01 05:49:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:49:47 --> Controller Class Initialized
INFO - 2016-03-01 05:49:47 --> Model Class Initialized
INFO - 2016-03-01 05:49:47 --> Model Class Initialized
INFO - 2016-03-01 05:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:49:47 --> Pagination Class Initialized
INFO - 2016-03-01 05:49:47 --> Helper loaded: text_helper
INFO - 2016-03-01 05:49:47 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:49:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:49:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:49:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:49:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:49:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:49:47 --> Final output sent to browser
DEBUG - 2016-03-01 08:49:47 --> Total execution time: 1.1837
INFO - 2016-03-01 05:50:32 --> Config Class Initialized
INFO - 2016-03-01 05:50:32 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:50:32 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:50:32 --> Utf8 Class Initialized
INFO - 2016-03-01 05:50:32 --> URI Class Initialized
INFO - 2016-03-01 05:50:32 --> Router Class Initialized
INFO - 2016-03-01 05:50:32 --> Output Class Initialized
INFO - 2016-03-01 05:50:32 --> Security Class Initialized
DEBUG - 2016-03-01 05:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:50:32 --> Input Class Initialized
INFO - 2016-03-01 05:50:32 --> Language Class Initialized
INFO - 2016-03-01 05:50:32 --> Loader Class Initialized
INFO - 2016-03-01 05:50:32 --> Helper loaded: url_helper
INFO - 2016-03-01 05:50:32 --> Helper loaded: file_helper
INFO - 2016-03-01 05:50:32 --> Helper loaded: date_helper
INFO - 2016-03-01 05:50:32 --> Helper loaded: form_helper
INFO - 2016-03-01 05:50:32 --> Database Driver Class Initialized
INFO - 2016-03-01 05:50:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:50:33 --> Controller Class Initialized
INFO - 2016-03-01 05:50:33 --> Model Class Initialized
INFO - 2016-03-01 05:50:33 --> Model Class Initialized
INFO - 2016-03-01 05:50:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:50:33 --> Pagination Class Initialized
INFO - 2016-03-01 05:50:33 --> Helper loaded: text_helper
INFO - 2016-03-01 05:50:33 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:50:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:50:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:50:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:50:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:50:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:50:33 --> Final output sent to browser
DEBUG - 2016-03-01 08:50:33 --> Total execution time: 1.1995
INFO - 2016-03-01 05:51:06 --> Config Class Initialized
INFO - 2016-03-01 05:51:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:51:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:51:06 --> Utf8 Class Initialized
INFO - 2016-03-01 05:51:06 --> URI Class Initialized
INFO - 2016-03-01 05:51:06 --> Router Class Initialized
INFO - 2016-03-01 05:51:06 --> Output Class Initialized
INFO - 2016-03-01 05:51:06 --> Security Class Initialized
DEBUG - 2016-03-01 05:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:51:06 --> Input Class Initialized
INFO - 2016-03-01 05:51:06 --> Language Class Initialized
INFO - 2016-03-01 05:51:06 --> Loader Class Initialized
INFO - 2016-03-01 05:51:06 --> Helper loaded: url_helper
INFO - 2016-03-01 05:51:06 --> Helper loaded: file_helper
INFO - 2016-03-01 05:51:06 --> Helper loaded: date_helper
INFO - 2016-03-01 05:51:06 --> Helper loaded: form_helper
INFO - 2016-03-01 05:51:06 --> Database Driver Class Initialized
INFO - 2016-03-01 05:51:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:51:07 --> Controller Class Initialized
INFO - 2016-03-01 05:51:07 --> Model Class Initialized
INFO - 2016-03-01 05:51:07 --> Model Class Initialized
INFO - 2016-03-01 05:51:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:51:07 --> Pagination Class Initialized
INFO - 2016-03-01 05:51:07 --> Helper loaded: text_helper
INFO - 2016-03-01 05:51:07 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:51:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:51:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:51:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:51:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:51:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:51:07 --> Final output sent to browser
DEBUG - 2016-03-01 08:51:07 --> Total execution time: 1.1944
INFO - 2016-03-01 05:51:25 --> Config Class Initialized
INFO - 2016-03-01 05:51:25 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:51:25 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:51:25 --> Utf8 Class Initialized
INFO - 2016-03-01 05:51:25 --> URI Class Initialized
INFO - 2016-03-01 05:51:25 --> Router Class Initialized
INFO - 2016-03-01 05:51:25 --> Output Class Initialized
INFO - 2016-03-01 05:51:25 --> Security Class Initialized
DEBUG - 2016-03-01 05:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:51:25 --> Input Class Initialized
INFO - 2016-03-01 05:51:25 --> Language Class Initialized
INFO - 2016-03-01 05:51:25 --> Loader Class Initialized
INFO - 2016-03-01 05:51:25 --> Helper loaded: url_helper
INFO - 2016-03-01 05:51:25 --> Helper loaded: file_helper
INFO - 2016-03-01 05:51:25 --> Helper loaded: date_helper
INFO - 2016-03-01 05:51:25 --> Helper loaded: form_helper
INFO - 2016-03-01 05:51:25 --> Database Driver Class Initialized
INFO - 2016-03-01 05:51:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:51:26 --> Controller Class Initialized
INFO - 2016-03-01 05:51:26 --> Model Class Initialized
INFO - 2016-03-01 05:51:26 --> Model Class Initialized
INFO - 2016-03-01 05:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:51:26 --> Pagination Class Initialized
INFO - 2016-03-01 05:51:26 --> Helper loaded: text_helper
INFO - 2016-03-01 05:51:26 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:51:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:51:26 --> Final output sent to browser
DEBUG - 2016-03-01 08:51:26 --> Total execution time: 1.1673
INFO - 2016-03-01 05:53:26 --> Config Class Initialized
INFO - 2016-03-01 05:53:26 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:53:26 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:53:26 --> Utf8 Class Initialized
INFO - 2016-03-01 05:53:26 --> URI Class Initialized
INFO - 2016-03-01 05:53:26 --> Router Class Initialized
INFO - 2016-03-01 05:53:26 --> Output Class Initialized
INFO - 2016-03-01 05:53:26 --> Security Class Initialized
DEBUG - 2016-03-01 05:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:53:26 --> Input Class Initialized
INFO - 2016-03-01 05:53:26 --> Language Class Initialized
INFO - 2016-03-01 05:53:26 --> Loader Class Initialized
INFO - 2016-03-01 05:53:26 --> Helper loaded: url_helper
INFO - 2016-03-01 05:53:26 --> Helper loaded: file_helper
INFO - 2016-03-01 05:53:26 --> Helper loaded: date_helper
INFO - 2016-03-01 05:53:26 --> Helper loaded: form_helper
INFO - 2016-03-01 05:53:26 --> Database Driver Class Initialized
INFO - 2016-03-01 05:53:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:53:27 --> Controller Class Initialized
INFO - 2016-03-01 05:53:27 --> Model Class Initialized
INFO - 2016-03-01 05:53:27 --> Model Class Initialized
INFO - 2016-03-01 05:53:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:53:27 --> Pagination Class Initialized
INFO - 2016-03-01 05:53:27 --> Helper loaded: text_helper
INFO - 2016-03-01 05:53:27 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:53:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:53:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:53:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:53:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:53:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:53:27 --> Final output sent to browser
DEBUG - 2016-03-01 08:53:27 --> Total execution time: 1.1943
INFO - 2016-03-01 05:54:06 --> Config Class Initialized
INFO - 2016-03-01 05:54:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:54:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:54:06 --> Utf8 Class Initialized
INFO - 2016-03-01 05:54:06 --> URI Class Initialized
INFO - 2016-03-01 05:54:06 --> Router Class Initialized
INFO - 2016-03-01 05:54:06 --> Output Class Initialized
INFO - 2016-03-01 05:54:06 --> Security Class Initialized
DEBUG - 2016-03-01 05:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:54:06 --> Input Class Initialized
INFO - 2016-03-01 05:54:06 --> Language Class Initialized
INFO - 2016-03-01 05:54:06 --> Loader Class Initialized
INFO - 2016-03-01 05:54:06 --> Helper loaded: url_helper
INFO - 2016-03-01 05:54:06 --> Helper loaded: file_helper
INFO - 2016-03-01 05:54:06 --> Helper loaded: date_helper
INFO - 2016-03-01 05:54:06 --> Helper loaded: form_helper
INFO - 2016-03-01 05:54:06 --> Database Driver Class Initialized
INFO - 2016-03-01 05:54:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:54:08 --> Controller Class Initialized
INFO - 2016-03-01 05:54:08 --> Model Class Initialized
INFO - 2016-03-01 05:54:08 --> Model Class Initialized
INFO - 2016-03-01 05:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:54:08 --> Pagination Class Initialized
INFO - 2016-03-01 05:54:08 --> Helper loaded: text_helper
INFO - 2016-03-01 05:54:08 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:54:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:54:08 --> Final output sent to browser
DEBUG - 2016-03-01 08:54:08 --> Total execution time: 1.2610
INFO - 2016-03-01 05:54:45 --> Config Class Initialized
INFO - 2016-03-01 05:54:45 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:54:45 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:54:45 --> Utf8 Class Initialized
INFO - 2016-03-01 05:54:45 --> URI Class Initialized
INFO - 2016-03-01 05:54:45 --> Router Class Initialized
INFO - 2016-03-01 05:54:45 --> Output Class Initialized
INFO - 2016-03-01 05:54:45 --> Security Class Initialized
DEBUG - 2016-03-01 05:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:54:45 --> Input Class Initialized
INFO - 2016-03-01 05:54:45 --> Language Class Initialized
INFO - 2016-03-01 05:54:45 --> Loader Class Initialized
INFO - 2016-03-01 05:54:45 --> Helper loaded: url_helper
INFO - 2016-03-01 05:54:46 --> Helper loaded: file_helper
INFO - 2016-03-01 05:54:46 --> Helper loaded: date_helper
INFO - 2016-03-01 05:54:46 --> Helper loaded: form_helper
INFO - 2016-03-01 05:54:46 --> Database Driver Class Initialized
INFO - 2016-03-01 05:54:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:54:47 --> Controller Class Initialized
INFO - 2016-03-01 05:54:47 --> Model Class Initialized
INFO - 2016-03-01 05:54:47 --> Model Class Initialized
INFO - 2016-03-01 05:54:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:54:47 --> Pagination Class Initialized
INFO - 2016-03-01 05:54:47 --> Helper loaded: text_helper
INFO - 2016-03-01 05:54:47 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:54:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:54:47 --> Final output sent to browser
DEBUG - 2016-03-01 08:54:47 --> Total execution time: 1.2282
INFO - 2016-03-01 05:55:22 --> Config Class Initialized
INFO - 2016-03-01 05:55:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 05:55:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 05:55:22 --> Utf8 Class Initialized
INFO - 2016-03-01 05:55:22 --> URI Class Initialized
INFO - 2016-03-01 05:55:22 --> Router Class Initialized
INFO - 2016-03-01 05:55:22 --> Output Class Initialized
INFO - 2016-03-01 05:55:22 --> Security Class Initialized
DEBUG - 2016-03-01 05:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 05:55:22 --> Input Class Initialized
INFO - 2016-03-01 05:55:22 --> Language Class Initialized
INFO - 2016-03-01 05:55:22 --> Loader Class Initialized
INFO - 2016-03-01 05:55:22 --> Helper loaded: url_helper
INFO - 2016-03-01 05:55:22 --> Helper loaded: file_helper
INFO - 2016-03-01 05:55:22 --> Helper loaded: date_helper
INFO - 2016-03-01 05:55:22 --> Helper loaded: form_helper
INFO - 2016-03-01 05:55:22 --> Database Driver Class Initialized
INFO - 2016-03-01 05:55:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 05:55:23 --> Controller Class Initialized
INFO - 2016-03-01 05:55:23 --> Model Class Initialized
INFO - 2016-03-01 05:55:23 --> Model Class Initialized
INFO - 2016-03-01 05:55:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 05:55:23 --> Pagination Class Initialized
INFO - 2016-03-01 05:55:23 --> Helper loaded: text_helper
INFO - 2016-03-01 05:55:23 --> Helper loaded: cookie_helper
INFO - 2016-03-01 08:55:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:55:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 08:55:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 08:55:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 08:55:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 08:55:23 --> Final output sent to browser
DEBUG - 2016-03-01 08:55:23 --> Total execution time: 1.1679
INFO - 2016-03-01 06:46:24 --> Config Class Initialized
INFO - 2016-03-01 06:46:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 06:46:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 06:46:24 --> Utf8 Class Initialized
INFO - 2016-03-01 06:46:24 --> URI Class Initialized
INFO - 2016-03-01 06:46:24 --> Router Class Initialized
INFO - 2016-03-01 06:46:24 --> Output Class Initialized
INFO - 2016-03-01 06:46:24 --> Security Class Initialized
DEBUG - 2016-03-01 06:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 06:46:24 --> Input Class Initialized
INFO - 2016-03-01 06:46:24 --> Language Class Initialized
INFO - 2016-03-01 06:46:24 --> Loader Class Initialized
INFO - 2016-03-01 06:46:24 --> Helper loaded: url_helper
INFO - 2016-03-01 06:46:24 --> Helper loaded: file_helper
INFO - 2016-03-01 06:46:24 --> Helper loaded: date_helper
INFO - 2016-03-01 06:46:24 --> Helper loaded: form_helper
INFO - 2016-03-01 06:46:24 --> Database Driver Class Initialized
INFO - 2016-03-01 06:46:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 06:46:25 --> Controller Class Initialized
INFO - 2016-03-01 06:46:25 --> Model Class Initialized
INFO - 2016-03-01 06:46:25 --> Model Class Initialized
INFO - 2016-03-01 06:46:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 06:46:25 --> Pagination Class Initialized
INFO - 2016-03-01 06:46:25 --> Helper loaded: text_helper
INFO - 2016-03-01 06:46:25 --> Helper loaded: cookie_helper
INFO - 2016-03-01 09:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 09:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 09:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 09:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 09:46:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 09:46:25 --> Final output sent to browser
DEBUG - 2016-03-01 09:46:25 --> Total execution time: 1.2210
INFO - 2016-03-01 06:50:23 --> Config Class Initialized
INFO - 2016-03-01 06:50:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 06:50:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 06:50:23 --> Utf8 Class Initialized
INFO - 2016-03-01 06:50:23 --> URI Class Initialized
INFO - 2016-03-01 06:50:23 --> Router Class Initialized
INFO - 2016-03-01 06:50:23 --> Output Class Initialized
INFO - 2016-03-01 06:50:23 --> Security Class Initialized
DEBUG - 2016-03-01 06:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 06:50:23 --> Input Class Initialized
INFO - 2016-03-01 06:50:23 --> Language Class Initialized
INFO - 2016-03-01 06:50:23 --> Loader Class Initialized
INFO - 2016-03-01 06:50:23 --> Helper loaded: url_helper
INFO - 2016-03-01 06:50:23 --> Helper loaded: file_helper
INFO - 2016-03-01 06:50:23 --> Helper loaded: date_helper
INFO - 2016-03-01 06:50:23 --> Helper loaded: form_helper
INFO - 2016-03-01 06:50:23 --> Database Driver Class Initialized
INFO - 2016-03-01 06:50:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 06:50:24 --> Controller Class Initialized
INFO - 2016-03-01 06:50:24 --> Model Class Initialized
INFO - 2016-03-01 06:50:24 --> Model Class Initialized
INFO - 2016-03-01 06:50:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 06:50:24 --> Pagination Class Initialized
INFO - 2016-03-01 06:50:24 --> Helper loaded: text_helper
INFO - 2016-03-01 06:50:24 --> Helper loaded: cookie_helper
INFO - 2016-03-01 09:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 09:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 09:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 09:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 09:50:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 09:50:24 --> Final output sent to browser
DEBUG - 2016-03-01 09:50:24 --> Total execution time: 1.1972
INFO - 2016-03-01 06:51:12 --> Config Class Initialized
INFO - 2016-03-01 06:51:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 06:51:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 06:51:12 --> Utf8 Class Initialized
INFO - 2016-03-01 06:51:12 --> URI Class Initialized
INFO - 2016-03-01 06:51:12 --> Router Class Initialized
INFO - 2016-03-01 06:51:12 --> Output Class Initialized
INFO - 2016-03-01 06:51:12 --> Security Class Initialized
DEBUG - 2016-03-01 06:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 06:51:12 --> Input Class Initialized
INFO - 2016-03-01 06:51:12 --> Language Class Initialized
INFO - 2016-03-01 06:51:12 --> Loader Class Initialized
INFO - 2016-03-01 06:51:12 --> Helper loaded: url_helper
INFO - 2016-03-01 06:51:12 --> Helper loaded: file_helper
INFO - 2016-03-01 06:51:12 --> Helper loaded: date_helper
INFO - 2016-03-01 06:51:12 --> Helper loaded: form_helper
INFO - 2016-03-01 06:51:12 --> Database Driver Class Initialized
INFO - 2016-03-01 06:51:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 06:51:13 --> Controller Class Initialized
INFO - 2016-03-01 06:51:13 --> Model Class Initialized
INFO - 2016-03-01 06:51:13 --> Model Class Initialized
INFO - 2016-03-01 06:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 06:51:13 --> Pagination Class Initialized
INFO - 2016-03-01 06:51:13 --> Helper loaded: text_helper
INFO - 2016-03-01 06:51:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 09:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 09:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 09:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 09:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 09:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 09:51:13 --> Final output sent to browser
DEBUG - 2016-03-01 09:51:13 --> Total execution time: 1.1987
INFO - 2016-03-01 07:07:56 --> Config Class Initialized
INFO - 2016-03-01 07:07:56 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:07:56 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:07:56 --> Utf8 Class Initialized
INFO - 2016-03-01 07:07:56 --> URI Class Initialized
INFO - 2016-03-01 07:07:56 --> Router Class Initialized
INFO - 2016-03-01 07:07:56 --> Output Class Initialized
INFO - 2016-03-01 07:07:56 --> Security Class Initialized
DEBUG - 2016-03-01 07:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:07:56 --> Input Class Initialized
INFO - 2016-03-01 07:07:56 --> Language Class Initialized
INFO - 2016-03-01 07:07:56 --> Loader Class Initialized
INFO - 2016-03-01 07:07:56 --> Helper loaded: url_helper
INFO - 2016-03-01 07:07:56 --> Helper loaded: file_helper
INFO - 2016-03-01 07:07:56 --> Helper loaded: date_helper
INFO - 2016-03-01 07:07:56 --> Helper loaded: form_helper
INFO - 2016-03-01 07:07:56 --> Database Driver Class Initialized
INFO - 2016-03-01 07:07:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:07:57 --> Controller Class Initialized
INFO - 2016-03-01 07:07:57 --> Model Class Initialized
INFO - 2016-03-01 07:07:57 --> Model Class Initialized
INFO - 2016-03-01 07:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:07:57 --> Pagination Class Initialized
INFO - 2016-03-01 07:07:57 --> Helper loaded: text_helper
INFO - 2016-03-01 07:07:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 10:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 10:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:07:57 --> Final output sent to browser
DEBUG - 2016-03-01 10:07:57 --> Total execution time: 1.2425
INFO - 2016-03-01 07:07:58 --> Config Class Initialized
INFO - 2016-03-01 07:07:58 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:07:58 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:07:58 --> Utf8 Class Initialized
INFO - 2016-03-01 07:07:58 --> URI Class Initialized
DEBUG - 2016-03-01 07:07:58 --> No URI present. Default controller set.
INFO - 2016-03-01 07:07:58 --> Router Class Initialized
INFO - 2016-03-01 07:07:58 --> Output Class Initialized
INFO - 2016-03-01 07:07:58 --> Security Class Initialized
DEBUG - 2016-03-01 07:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:07:58 --> Input Class Initialized
INFO - 2016-03-01 07:07:58 --> Language Class Initialized
INFO - 2016-03-01 07:07:58 --> Loader Class Initialized
INFO - 2016-03-01 07:07:58 --> Helper loaded: url_helper
INFO - 2016-03-01 07:07:58 --> Helper loaded: file_helper
INFO - 2016-03-01 07:07:58 --> Helper loaded: date_helper
INFO - 2016-03-01 07:07:58 --> Helper loaded: form_helper
INFO - 2016-03-01 07:07:58 --> Database Driver Class Initialized
INFO - 2016-03-01 07:07:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:07:59 --> Controller Class Initialized
INFO - 2016-03-01 07:07:59 --> Model Class Initialized
INFO - 2016-03-01 07:07:59 --> Model Class Initialized
INFO - 2016-03-01 07:07:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:07:59 --> Pagination Class Initialized
INFO - 2016-03-01 07:07:59 --> Helper loaded: text_helper
INFO - 2016-03-01 07:07:59 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:07:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:07:59 --> Final output sent to browser
DEBUG - 2016-03-01 10:07:59 --> Total execution time: 1.1479
INFO - 2016-03-01 07:08:21 --> Config Class Initialized
INFO - 2016-03-01 07:08:21 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:08:21 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:08:21 --> Utf8 Class Initialized
INFO - 2016-03-01 07:08:21 --> URI Class Initialized
INFO - 2016-03-01 07:08:21 --> Router Class Initialized
INFO - 2016-03-01 07:08:21 --> Output Class Initialized
INFO - 2016-03-01 07:08:21 --> Security Class Initialized
DEBUG - 2016-03-01 07:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:08:21 --> Input Class Initialized
INFO - 2016-03-01 07:08:21 --> Language Class Initialized
ERROR - 2016-03-01 07:08:21 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 61
INFO - 2016-03-01 07:08:55 --> Config Class Initialized
INFO - 2016-03-01 07:08:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:08:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:08:55 --> Utf8 Class Initialized
INFO - 2016-03-01 07:08:55 --> URI Class Initialized
DEBUG - 2016-03-01 07:08:55 --> No URI present. Default controller set.
INFO - 2016-03-01 07:08:55 --> Router Class Initialized
INFO - 2016-03-01 07:08:55 --> Output Class Initialized
INFO - 2016-03-01 07:08:55 --> Security Class Initialized
DEBUG - 2016-03-01 07:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:08:55 --> Input Class Initialized
INFO - 2016-03-01 07:08:55 --> Language Class Initialized
INFO - 2016-03-01 07:08:55 --> Loader Class Initialized
INFO - 2016-03-01 07:08:55 --> Helper loaded: url_helper
INFO - 2016-03-01 07:08:55 --> Helper loaded: file_helper
INFO - 2016-03-01 07:08:55 --> Helper loaded: date_helper
INFO - 2016-03-01 07:08:55 --> Helper loaded: form_helper
INFO - 2016-03-01 07:08:55 --> Database Driver Class Initialized
INFO - 2016-03-01 07:08:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:08:56 --> Controller Class Initialized
INFO - 2016-03-01 07:08:56 --> Model Class Initialized
INFO - 2016-03-01 07:08:56 --> Model Class Initialized
INFO - 2016-03-01 07:08:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:08:56 --> Pagination Class Initialized
INFO - 2016-03-01 07:08:56 --> Helper loaded: text_helper
INFO - 2016-03-01 07:08:56 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:08:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:08:56 --> Final output sent to browser
DEBUG - 2016-03-01 10:08:56 --> Total execution time: 1.1417
INFO - 2016-03-01 07:08:57 --> Config Class Initialized
INFO - 2016-03-01 07:08:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:08:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:08:57 --> Utf8 Class Initialized
INFO - 2016-03-01 07:08:57 --> URI Class Initialized
INFO - 2016-03-01 07:08:57 --> Router Class Initialized
INFO - 2016-03-01 07:08:57 --> Output Class Initialized
INFO - 2016-03-01 07:08:57 --> Security Class Initialized
DEBUG - 2016-03-01 07:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:08:57 --> Input Class Initialized
INFO - 2016-03-01 07:08:57 --> Language Class Initialized
INFO - 2016-03-01 07:08:57 --> Loader Class Initialized
INFO - 2016-03-01 07:08:57 --> Helper loaded: url_helper
INFO - 2016-03-01 07:08:57 --> Helper loaded: file_helper
INFO - 2016-03-01 07:08:57 --> Helper loaded: date_helper
INFO - 2016-03-01 07:08:57 --> Helper loaded: form_helper
INFO - 2016-03-01 07:08:57 --> Database Driver Class Initialized
INFO - 2016-03-01 07:08:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:08:58 --> Controller Class Initialized
INFO - 2016-03-01 07:08:58 --> Model Class Initialized
INFO - 2016-03-01 07:08:58 --> Model Class Initialized
INFO - 2016-03-01 07:08:58 --> Form Validation Class Initialized
INFO - 2016-03-01 07:08:58 --> Helper loaded: text_helper
INFO - 2016-03-01 07:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 07:08:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 07:08:58 --> Final output sent to browser
DEBUG - 2016-03-01 07:08:58 --> Total execution time: 1.1308
INFO - 2016-03-01 07:08:59 --> Config Class Initialized
INFO - 2016-03-01 07:08:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:08:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:08:59 --> Utf8 Class Initialized
INFO - 2016-03-01 07:08:59 --> URI Class Initialized
DEBUG - 2016-03-01 07:08:59 --> No URI present. Default controller set.
INFO - 2016-03-01 07:08:59 --> Router Class Initialized
INFO - 2016-03-01 07:08:59 --> Output Class Initialized
INFO - 2016-03-01 07:08:59 --> Security Class Initialized
DEBUG - 2016-03-01 07:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:08:59 --> Input Class Initialized
INFO - 2016-03-01 07:08:59 --> Language Class Initialized
INFO - 2016-03-01 07:08:59 --> Loader Class Initialized
INFO - 2016-03-01 07:08:59 --> Helper loaded: url_helper
INFO - 2016-03-01 07:08:59 --> Helper loaded: file_helper
INFO - 2016-03-01 07:08:59 --> Helper loaded: date_helper
INFO - 2016-03-01 07:08:59 --> Helper loaded: form_helper
INFO - 2016-03-01 07:08:59 --> Database Driver Class Initialized
INFO - 2016-03-01 07:09:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:09:00 --> Controller Class Initialized
INFO - 2016-03-01 07:09:00 --> Model Class Initialized
INFO - 2016-03-01 07:09:00 --> Model Class Initialized
INFO - 2016-03-01 07:09:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:09:00 --> Pagination Class Initialized
INFO - 2016-03-01 07:09:00 --> Helper loaded: text_helper
INFO - 2016-03-01 07:09:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:09:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:09:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:09:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:09:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:09:00 --> Final output sent to browser
DEBUG - 2016-03-01 10:09:00 --> Total execution time: 1.1710
INFO - 2016-03-01 07:09:41 --> Config Class Initialized
INFO - 2016-03-01 07:09:41 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:09:41 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:09:41 --> Utf8 Class Initialized
INFO - 2016-03-01 07:09:41 --> URI Class Initialized
INFO - 2016-03-01 07:09:41 --> Router Class Initialized
INFO - 2016-03-01 07:09:41 --> Output Class Initialized
INFO - 2016-03-01 07:09:41 --> Security Class Initialized
DEBUG - 2016-03-01 07:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:09:41 --> Input Class Initialized
INFO - 2016-03-01 07:09:41 --> Language Class Initialized
INFO - 2016-03-01 07:09:41 --> Loader Class Initialized
INFO - 2016-03-01 07:09:41 --> Helper loaded: url_helper
INFO - 2016-03-01 07:09:41 --> Helper loaded: file_helper
INFO - 2016-03-01 07:09:41 --> Helper loaded: date_helper
INFO - 2016-03-01 07:09:41 --> Helper loaded: form_helper
INFO - 2016-03-01 07:09:41 --> Database Driver Class Initialized
INFO - 2016-03-01 07:09:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:09:42 --> Controller Class Initialized
INFO - 2016-03-01 07:09:42 --> Model Class Initialized
INFO - 2016-03-01 07:09:42 --> Model Class Initialized
INFO - 2016-03-01 07:09:42 --> Form Validation Class Initialized
INFO - 2016-03-01 07:09:42 --> Helper loaded: text_helper
INFO - 2016-03-01 07:09:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-01 07:09:42 --> Severity: Warning --> json_encode() expects at least 1 parameter, 0 given C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 58
INFO - 2016-03-01 07:09:42 --> Final output sent to browser
DEBUG - 2016-03-01 07:09:42 --> Total execution time: 1.3291
INFO - 2016-03-01 07:10:06 --> Config Class Initialized
INFO - 2016-03-01 07:10:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:10:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:10:06 --> Utf8 Class Initialized
INFO - 2016-03-01 07:10:06 --> URI Class Initialized
DEBUG - 2016-03-01 07:10:06 --> No URI present. Default controller set.
INFO - 2016-03-01 07:10:06 --> Router Class Initialized
INFO - 2016-03-01 07:10:06 --> Output Class Initialized
INFO - 2016-03-01 07:10:06 --> Security Class Initialized
DEBUG - 2016-03-01 07:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:10:06 --> Input Class Initialized
INFO - 2016-03-01 07:10:06 --> Language Class Initialized
INFO - 2016-03-01 07:10:06 --> Loader Class Initialized
INFO - 2016-03-01 07:10:06 --> Helper loaded: url_helper
INFO - 2016-03-01 07:10:06 --> Helper loaded: file_helper
INFO - 2016-03-01 07:10:06 --> Helper loaded: date_helper
INFO - 2016-03-01 07:10:06 --> Helper loaded: form_helper
INFO - 2016-03-01 07:10:06 --> Database Driver Class Initialized
INFO - 2016-03-01 07:10:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:10:07 --> Controller Class Initialized
INFO - 2016-03-01 07:10:07 --> Model Class Initialized
INFO - 2016-03-01 07:10:07 --> Model Class Initialized
INFO - 2016-03-01 07:10:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:10:07 --> Pagination Class Initialized
INFO - 2016-03-01 07:10:07 --> Helper loaded: text_helper
INFO - 2016-03-01 07:10:07 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:10:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:10:07 --> Final output sent to browser
DEBUG - 2016-03-01 10:10:07 --> Total execution time: 1.1098
INFO - 2016-03-01 07:10:38 --> Config Class Initialized
INFO - 2016-03-01 07:10:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:10:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:10:38 --> Utf8 Class Initialized
INFO - 2016-03-01 07:10:38 --> URI Class Initialized
INFO - 2016-03-01 07:10:38 --> Router Class Initialized
INFO - 2016-03-01 07:10:38 --> Output Class Initialized
INFO - 2016-03-01 07:10:38 --> Security Class Initialized
DEBUG - 2016-03-01 07:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:10:38 --> Input Class Initialized
INFO - 2016-03-01 07:10:38 --> Language Class Initialized
INFO - 2016-03-01 07:10:38 --> Loader Class Initialized
INFO - 2016-03-01 07:10:38 --> Helper loaded: url_helper
INFO - 2016-03-01 07:10:38 --> Helper loaded: file_helper
INFO - 2016-03-01 07:10:38 --> Helper loaded: date_helper
INFO - 2016-03-01 07:10:38 --> Helper loaded: form_helper
INFO - 2016-03-01 07:10:38 --> Database Driver Class Initialized
INFO - 2016-03-01 07:10:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:10:39 --> Controller Class Initialized
INFO - 2016-03-01 07:10:39 --> Model Class Initialized
INFO - 2016-03-01 07:10:39 --> Model Class Initialized
INFO - 2016-03-01 07:10:39 --> Form Validation Class Initialized
INFO - 2016-03-01 07:10:39 --> Helper loaded: text_helper
INFO - 2016-03-01 07:10:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:10:39 --> Final output sent to browser
DEBUG - 2016-03-01 07:10:39 --> Total execution time: 1.1207
INFO - 2016-03-01 07:18:00 --> Config Class Initialized
INFO - 2016-03-01 07:18:00 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:18:00 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:18:00 --> Utf8 Class Initialized
INFO - 2016-03-01 07:18:00 --> URI Class Initialized
DEBUG - 2016-03-01 07:18:00 --> No URI present. Default controller set.
INFO - 2016-03-01 07:18:00 --> Router Class Initialized
INFO - 2016-03-01 07:18:00 --> Output Class Initialized
INFO - 2016-03-01 07:18:00 --> Security Class Initialized
DEBUG - 2016-03-01 07:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:18:00 --> Input Class Initialized
INFO - 2016-03-01 07:18:00 --> Language Class Initialized
INFO - 2016-03-01 07:18:00 --> Loader Class Initialized
INFO - 2016-03-01 07:18:00 --> Helper loaded: url_helper
INFO - 2016-03-01 07:18:00 --> Helper loaded: file_helper
INFO - 2016-03-01 07:18:00 --> Helper loaded: date_helper
INFO - 2016-03-01 07:18:00 --> Helper loaded: form_helper
INFO - 2016-03-01 07:18:00 --> Database Driver Class Initialized
INFO - 2016-03-01 07:18:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:18:01 --> Controller Class Initialized
INFO - 2016-03-01 07:18:01 --> Model Class Initialized
INFO - 2016-03-01 07:18:01 --> Model Class Initialized
INFO - 2016-03-01 07:18:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:18:01 --> Pagination Class Initialized
INFO - 2016-03-01 07:18:01 --> Helper loaded: text_helper
INFO - 2016-03-01 07:18:01 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:18:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:18:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:18:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:18:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:18:01 --> Final output sent to browser
DEBUG - 2016-03-01 10:18:01 --> Total execution time: 1.1962
INFO - 2016-03-01 07:20:28 --> Config Class Initialized
INFO - 2016-03-01 07:20:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:20:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:20:28 --> Utf8 Class Initialized
INFO - 2016-03-01 07:20:28 --> URI Class Initialized
DEBUG - 2016-03-01 07:20:28 --> No URI present. Default controller set.
INFO - 2016-03-01 07:20:28 --> Router Class Initialized
INFO - 2016-03-01 07:20:28 --> Output Class Initialized
INFO - 2016-03-01 07:20:28 --> Security Class Initialized
DEBUG - 2016-03-01 07:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:20:28 --> Input Class Initialized
INFO - 2016-03-01 07:20:28 --> Language Class Initialized
INFO - 2016-03-01 07:20:28 --> Loader Class Initialized
INFO - 2016-03-01 07:20:28 --> Helper loaded: url_helper
INFO - 2016-03-01 07:20:28 --> Helper loaded: file_helper
INFO - 2016-03-01 07:20:28 --> Helper loaded: date_helper
INFO - 2016-03-01 07:20:28 --> Helper loaded: form_helper
INFO - 2016-03-01 07:20:28 --> Database Driver Class Initialized
INFO - 2016-03-01 07:20:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:20:29 --> Controller Class Initialized
INFO - 2016-03-01 07:20:29 --> Model Class Initialized
INFO - 2016-03-01 07:20:29 --> Model Class Initialized
INFO - 2016-03-01 07:20:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:20:29 --> Pagination Class Initialized
INFO - 2016-03-01 07:20:29 --> Helper loaded: text_helper
INFO - 2016-03-01 07:20:29 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:20:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:20:29 --> Final output sent to browser
DEBUG - 2016-03-01 10:20:29 --> Total execution time: 1.1925
INFO - 2016-03-01 07:20:42 --> Config Class Initialized
INFO - 2016-03-01 07:20:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:20:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:20:42 --> Utf8 Class Initialized
INFO - 2016-03-01 07:20:42 --> URI Class Initialized
INFO - 2016-03-01 07:20:42 --> Router Class Initialized
INFO - 2016-03-01 07:20:42 --> Output Class Initialized
INFO - 2016-03-01 07:20:42 --> Security Class Initialized
DEBUG - 2016-03-01 07:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:20:42 --> Input Class Initialized
INFO - 2016-03-01 07:20:42 --> Language Class Initialized
INFO - 2016-03-01 07:20:42 --> Loader Class Initialized
INFO - 2016-03-01 07:20:42 --> Helper loaded: url_helper
INFO - 2016-03-01 07:20:42 --> Helper loaded: file_helper
INFO - 2016-03-01 07:20:42 --> Helper loaded: date_helper
INFO - 2016-03-01 07:20:42 --> Helper loaded: form_helper
INFO - 2016-03-01 07:20:42 --> Database Driver Class Initialized
INFO - 2016-03-01 07:20:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:20:43 --> Controller Class Initialized
INFO - 2016-03-01 07:20:43 --> Model Class Initialized
INFO - 2016-03-01 07:20:43 --> Model Class Initialized
INFO - 2016-03-01 07:20:43 --> Form Validation Class Initialized
INFO - 2016-03-01 07:20:43 --> Helper loaded: text_helper
INFO - 2016-03-01 07:20:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:20:43 --> Final output sent to browser
DEBUG - 2016-03-01 07:20:43 --> Total execution time: 1.1003
INFO - 2016-03-01 07:22:34 --> Config Class Initialized
INFO - 2016-03-01 07:22:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:22:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:22:34 --> Utf8 Class Initialized
INFO - 2016-03-01 07:22:34 --> URI Class Initialized
DEBUG - 2016-03-01 07:22:34 --> No URI present. Default controller set.
INFO - 2016-03-01 07:22:34 --> Router Class Initialized
INFO - 2016-03-01 07:22:34 --> Output Class Initialized
INFO - 2016-03-01 07:22:34 --> Security Class Initialized
DEBUG - 2016-03-01 07:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:22:34 --> Input Class Initialized
INFO - 2016-03-01 07:22:34 --> Language Class Initialized
INFO - 2016-03-01 07:22:34 --> Loader Class Initialized
INFO - 2016-03-01 07:22:34 --> Helper loaded: url_helper
INFO - 2016-03-01 07:22:34 --> Helper loaded: file_helper
INFO - 2016-03-01 07:22:34 --> Helper loaded: date_helper
INFO - 2016-03-01 07:22:34 --> Helper loaded: form_helper
INFO - 2016-03-01 07:22:34 --> Database Driver Class Initialized
INFO - 2016-03-01 07:22:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:22:36 --> Controller Class Initialized
INFO - 2016-03-01 07:22:36 --> Model Class Initialized
INFO - 2016-03-01 07:22:36 --> Model Class Initialized
INFO - 2016-03-01 07:22:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:22:36 --> Pagination Class Initialized
INFO - 2016-03-01 07:22:36 --> Helper loaded: text_helper
INFO - 2016-03-01 07:22:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:22:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:22:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:22:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:22:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:22:36 --> Final output sent to browser
DEBUG - 2016-03-01 10:22:36 --> Total execution time: 1.1593
INFO - 2016-03-01 07:23:01 --> Config Class Initialized
INFO - 2016-03-01 07:23:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:23:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:23:01 --> Utf8 Class Initialized
INFO - 2016-03-01 07:23:01 --> URI Class Initialized
INFO - 2016-03-01 07:23:01 --> Router Class Initialized
INFO - 2016-03-01 07:23:01 --> Output Class Initialized
INFO - 2016-03-01 07:23:01 --> Security Class Initialized
DEBUG - 2016-03-01 07:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:23:01 --> Input Class Initialized
INFO - 2016-03-01 07:23:01 --> Language Class Initialized
INFO - 2016-03-01 07:23:01 --> Loader Class Initialized
INFO - 2016-03-01 07:23:01 --> Helper loaded: url_helper
INFO - 2016-03-01 07:23:01 --> Helper loaded: file_helper
INFO - 2016-03-01 07:23:01 --> Helper loaded: date_helper
INFO - 2016-03-01 07:23:01 --> Helper loaded: form_helper
INFO - 2016-03-01 07:23:01 --> Database Driver Class Initialized
INFO - 2016-03-01 07:23:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:23:02 --> Controller Class Initialized
INFO - 2016-03-01 07:23:02 --> Model Class Initialized
INFO - 2016-03-01 07:23:02 --> Model Class Initialized
INFO - 2016-03-01 07:23:02 --> Form Validation Class Initialized
INFO - 2016-03-01 07:23:02 --> Helper loaded: text_helper
INFO - 2016-03-01 07:23:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:23:02 --> Final output sent to browser
DEBUG - 2016-03-01 07:23:02 --> Total execution time: 1.1228
INFO - 2016-03-01 07:24:31 --> Config Class Initialized
INFO - 2016-03-01 07:24:31 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:24:31 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:24:31 --> Utf8 Class Initialized
INFO - 2016-03-01 07:24:31 --> URI Class Initialized
DEBUG - 2016-03-01 07:24:31 --> No URI present. Default controller set.
INFO - 2016-03-01 07:24:31 --> Router Class Initialized
INFO - 2016-03-01 07:24:31 --> Output Class Initialized
INFO - 2016-03-01 07:24:31 --> Security Class Initialized
DEBUG - 2016-03-01 07:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:24:31 --> Input Class Initialized
INFO - 2016-03-01 07:24:31 --> Language Class Initialized
INFO - 2016-03-01 07:24:31 --> Loader Class Initialized
INFO - 2016-03-01 07:24:31 --> Helper loaded: url_helper
INFO - 2016-03-01 07:24:31 --> Helper loaded: file_helper
INFO - 2016-03-01 07:24:31 --> Helper loaded: date_helper
INFO - 2016-03-01 07:24:31 --> Helper loaded: form_helper
INFO - 2016-03-01 07:24:31 --> Database Driver Class Initialized
INFO - 2016-03-01 07:24:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:24:32 --> Controller Class Initialized
INFO - 2016-03-01 07:24:32 --> Model Class Initialized
INFO - 2016-03-01 07:24:32 --> Model Class Initialized
INFO - 2016-03-01 07:24:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:24:32 --> Pagination Class Initialized
INFO - 2016-03-01 07:24:32 --> Helper loaded: text_helper
INFO - 2016-03-01 07:24:32 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:24:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:24:32 --> Final output sent to browser
DEBUG - 2016-03-01 10:24:32 --> Total execution time: 1.1640
INFO - 2016-03-01 07:24:45 --> Config Class Initialized
INFO - 2016-03-01 07:24:45 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:24:45 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:24:45 --> Utf8 Class Initialized
INFO - 2016-03-01 07:24:45 --> URI Class Initialized
INFO - 2016-03-01 07:24:45 --> Router Class Initialized
INFO - 2016-03-01 07:24:45 --> Output Class Initialized
INFO - 2016-03-01 07:24:45 --> Security Class Initialized
DEBUG - 2016-03-01 07:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:24:45 --> Input Class Initialized
INFO - 2016-03-01 07:24:45 --> Language Class Initialized
INFO - 2016-03-01 07:24:45 --> Loader Class Initialized
INFO - 2016-03-01 07:24:45 --> Helper loaded: url_helper
INFO - 2016-03-01 07:24:45 --> Helper loaded: file_helper
INFO - 2016-03-01 07:24:45 --> Helper loaded: date_helper
INFO - 2016-03-01 07:24:45 --> Helper loaded: form_helper
INFO - 2016-03-01 07:24:45 --> Database Driver Class Initialized
INFO - 2016-03-01 07:24:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:24:46 --> Controller Class Initialized
INFO - 2016-03-01 07:24:46 --> Model Class Initialized
INFO - 2016-03-01 07:24:46 --> Model Class Initialized
INFO - 2016-03-01 07:24:46 --> Form Validation Class Initialized
INFO - 2016-03-01 07:24:46 --> Helper loaded: text_helper
INFO - 2016-03-01 07:24:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:24:46 --> Final output sent to browser
DEBUG - 2016-03-01 07:24:46 --> Total execution time: 1.1143
INFO - 2016-03-01 07:25:06 --> Config Class Initialized
INFO - 2016-03-01 07:25:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:25:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:25:06 --> Utf8 Class Initialized
INFO - 2016-03-01 07:25:06 --> URI Class Initialized
DEBUG - 2016-03-01 07:25:06 --> No URI present. Default controller set.
INFO - 2016-03-01 07:25:06 --> Router Class Initialized
INFO - 2016-03-01 07:25:06 --> Output Class Initialized
INFO - 2016-03-01 07:25:06 --> Security Class Initialized
DEBUG - 2016-03-01 07:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:25:06 --> Input Class Initialized
INFO - 2016-03-01 07:25:06 --> Language Class Initialized
INFO - 2016-03-01 07:25:06 --> Loader Class Initialized
INFO - 2016-03-01 07:25:06 --> Helper loaded: url_helper
INFO - 2016-03-01 07:25:06 --> Helper loaded: file_helper
INFO - 2016-03-01 07:25:06 --> Helper loaded: date_helper
INFO - 2016-03-01 07:25:06 --> Helper loaded: form_helper
INFO - 2016-03-01 07:25:06 --> Database Driver Class Initialized
INFO - 2016-03-01 07:25:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:25:07 --> Controller Class Initialized
INFO - 2016-03-01 07:25:07 --> Model Class Initialized
INFO - 2016-03-01 07:25:07 --> Model Class Initialized
INFO - 2016-03-01 07:25:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:25:07 --> Pagination Class Initialized
INFO - 2016-03-01 07:25:07 --> Helper loaded: text_helper
INFO - 2016-03-01 07:25:07 --> Helper loaded: cookie_helper
ERROR - 2016-03-01 10:25:07 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php 261
INFO - 2016-03-01 07:25:20 --> Config Class Initialized
INFO - 2016-03-01 07:25:20 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:25:20 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:25:20 --> Utf8 Class Initialized
INFO - 2016-03-01 07:25:20 --> URI Class Initialized
DEBUG - 2016-03-01 07:25:20 --> No URI present. Default controller set.
INFO - 2016-03-01 07:25:20 --> Router Class Initialized
INFO - 2016-03-01 07:25:20 --> Output Class Initialized
INFO - 2016-03-01 07:25:20 --> Security Class Initialized
DEBUG - 2016-03-01 07:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:25:20 --> Input Class Initialized
INFO - 2016-03-01 07:25:20 --> Language Class Initialized
INFO - 2016-03-01 07:25:20 --> Loader Class Initialized
INFO - 2016-03-01 07:25:20 --> Helper loaded: url_helper
INFO - 2016-03-01 07:25:20 --> Helper loaded: file_helper
INFO - 2016-03-01 07:25:20 --> Helper loaded: date_helper
INFO - 2016-03-01 07:25:20 --> Helper loaded: form_helper
INFO - 2016-03-01 07:25:20 --> Database Driver Class Initialized
INFO - 2016-03-01 07:25:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:25:21 --> Controller Class Initialized
INFO - 2016-03-01 07:25:21 --> Model Class Initialized
INFO - 2016-03-01 07:25:21 --> Model Class Initialized
INFO - 2016-03-01 07:25:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:25:21 --> Pagination Class Initialized
INFO - 2016-03-01 07:25:21 --> Helper loaded: text_helper
INFO - 2016-03-01 07:25:21 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:25:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:25:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:25:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:25:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:25:21 --> Final output sent to browser
DEBUG - 2016-03-01 10:25:21 --> Total execution time: 1.1865
INFO - 2016-03-01 07:25:30 --> Config Class Initialized
INFO - 2016-03-01 07:25:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:25:30 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:25:30 --> Utf8 Class Initialized
INFO - 2016-03-01 07:25:30 --> URI Class Initialized
INFO - 2016-03-01 07:25:30 --> Router Class Initialized
INFO - 2016-03-01 07:25:30 --> Output Class Initialized
INFO - 2016-03-01 07:25:30 --> Security Class Initialized
DEBUG - 2016-03-01 07:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:25:30 --> Input Class Initialized
INFO - 2016-03-01 07:25:30 --> Language Class Initialized
INFO - 2016-03-01 07:25:30 --> Loader Class Initialized
INFO - 2016-03-01 07:25:30 --> Helper loaded: url_helper
INFO - 2016-03-01 07:25:30 --> Helper loaded: file_helper
INFO - 2016-03-01 07:25:30 --> Helper loaded: date_helper
INFO - 2016-03-01 07:25:30 --> Helper loaded: form_helper
INFO - 2016-03-01 07:25:30 --> Database Driver Class Initialized
INFO - 2016-03-01 07:25:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:25:31 --> Controller Class Initialized
INFO - 2016-03-01 07:25:31 --> Model Class Initialized
INFO - 2016-03-01 07:25:31 --> Model Class Initialized
INFO - 2016-03-01 07:25:31 --> Form Validation Class Initialized
INFO - 2016-03-01 07:25:31 --> Helper loaded: text_helper
INFO - 2016-03-01 07:25:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:25:31 --> Final output sent to browser
DEBUG - 2016-03-01 07:25:31 --> Total execution time: 1.1113
INFO - 2016-03-01 07:28:13 --> Config Class Initialized
INFO - 2016-03-01 07:28:13 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:28:13 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:28:13 --> Utf8 Class Initialized
INFO - 2016-03-01 07:28:13 --> URI Class Initialized
DEBUG - 2016-03-01 07:28:13 --> No URI present. Default controller set.
INFO - 2016-03-01 07:28:13 --> Router Class Initialized
INFO - 2016-03-01 07:28:13 --> Output Class Initialized
INFO - 2016-03-01 07:28:13 --> Security Class Initialized
DEBUG - 2016-03-01 07:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:28:13 --> Input Class Initialized
INFO - 2016-03-01 07:28:13 --> Language Class Initialized
INFO - 2016-03-01 07:28:13 --> Loader Class Initialized
INFO - 2016-03-01 07:28:13 --> Helper loaded: url_helper
INFO - 2016-03-01 07:28:13 --> Helper loaded: file_helper
INFO - 2016-03-01 07:28:13 --> Helper loaded: date_helper
INFO - 2016-03-01 07:28:13 --> Helper loaded: form_helper
INFO - 2016-03-01 07:28:13 --> Database Driver Class Initialized
INFO - 2016-03-01 07:28:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:28:14 --> Controller Class Initialized
INFO - 2016-03-01 07:28:14 --> Model Class Initialized
INFO - 2016-03-01 07:28:14 --> Model Class Initialized
INFO - 2016-03-01 07:28:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:28:14 --> Pagination Class Initialized
INFO - 2016-03-01 07:28:14 --> Helper loaded: text_helper
INFO - 2016-03-01 07:28:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:28:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:28:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:28:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:28:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:28:14 --> Final output sent to browser
DEBUG - 2016-03-01 10:28:14 --> Total execution time: 1.1657
INFO - 2016-03-01 07:28:24 --> Config Class Initialized
INFO - 2016-03-01 07:28:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:28:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:28:24 --> Utf8 Class Initialized
INFO - 2016-03-01 07:28:24 --> URI Class Initialized
INFO - 2016-03-01 07:28:24 --> Router Class Initialized
INFO - 2016-03-01 07:28:24 --> Output Class Initialized
INFO - 2016-03-01 07:28:24 --> Security Class Initialized
DEBUG - 2016-03-01 07:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:28:24 --> Input Class Initialized
INFO - 2016-03-01 07:28:24 --> Language Class Initialized
INFO - 2016-03-01 07:28:24 --> Loader Class Initialized
INFO - 2016-03-01 07:28:24 --> Helper loaded: url_helper
INFO - 2016-03-01 07:28:24 --> Helper loaded: file_helper
INFO - 2016-03-01 07:28:24 --> Helper loaded: date_helper
INFO - 2016-03-01 07:28:24 --> Helper loaded: form_helper
INFO - 2016-03-01 07:28:24 --> Database Driver Class Initialized
INFO - 2016-03-01 07:28:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:28:25 --> Controller Class Initialized
INFO - 2016-03-01 07:28:25 --> Model Class Initialized
INFO - 2016-03-01 07:28:25 --> Model Class Initialized
INFO - 2016-03-01 07:28:25 --> Form Validation Class Initialized
INFO - 2016-03-01 07:28:25 --> Helper loaded: text_helper
INFO - 2016-03-01 07:28:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:28:25 --> Final output sent to browser
DEBUG - 2016-03-01 07:28:25 --> Total execution time: 1.1288
INFO - 2016-03-01 07:31:11 --> Config Class Initialized
INFO - 2016-03-01 07:31:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:31:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:31:11 --> Utf8 Class Initialized
INFO - 2016-03-01 07:31:11 --> URI Class Initialized
DEBUG - 2016-03-01 07:31:11 --> No URI present. Default controller set.
INFO - 2016-03-01 07:31:11 --> Router Class Initialized
INFO - 2016-03-01 07:31:11 --> Output Class Initialized
INFO - 2016-03-01 07:31:11 --> Security Class Initialized
DEBUG - 2016-03-01 07:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:31:11 --> Input Class Initialized
INFO - 2016-03-01 07:31:11 --> Language Class Initialized
INFO - 2016-03-01 07:31:11 --> Loader Class Initialized
INFO - 2016-03-01 07:31:11 --> Helper loaded: url_helper
INFO - 2016-03-01 07:31:11 --> Helper loaded: file_helper
INFO - 2016-03-01 07:31:11 --> Helper loaded: date_helper
INFO - 2016-03-01 07:31:11 --> Helper loaded: form_helper
INFO - 2016-03-01 07:31:11 --> Database Driver Class Initialized
INFO - 2016-03-01 07:31:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:31:12 --> Controller Class Initialized
INFO - 2016-03-01 07:31:12 --> Model Class Initialized
INFO - 2016-03-01 07:31:12 --> Model Class Initialized
INFO - 2016-03-01 07:31:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:31:12 --> Pagination Class Initialized
INFO - 2016-03-01 07:31:12 --> Helper loaded: text_helper
INFO - 2016-03-01 07:31:12 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:31:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:31:12 --> Final output sent to browser
DEBUG - 2016-03-01 10:31:12 --> Total execution time: 1.1584
INFO - 2016-03-01 07:31:21 --> Config Class Initialized
INFO - 2016-03-01 07:31:21 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:31:21 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:31:21 --> Utf8 Class Initialized
INFO - 2016-03-01 07:31:21 --> URI Class Initialized
INFO - 2016-03-01 07:31:21 --> Router Class Initialized
INFO - 2016-03-01 07:31:21 --> Output Class Initialized
INFO - 2016-03-01 07:31:21 --> Security Class Initialized
DEBUG - 2016-03-01 07:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:31:21 --> Input Class Initialized
INFO - 2016-03-01 07:31:21 --> Language Class Initialized
INFO - 2016-03-01 07:31:21 --> Loader Class Initialized
INFO - 2016-03-01 07:31:21 --> Helper loaded: url_helper
INFO - 2016-03-01 07:31:21 --> Helper loaded: file_helper
INFO - 2016-03-01 07:31:21 --> Helper loaded: date_helper
INFO - 2016-03-01 07:31:21 --> Helper loaded: form_helper
INFO - 2016-03-01 07:31:21 --> Database Driver Class Initialized
INFO - 2016-03-01 07:31:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:31:22 --> Controller Class Initialized
INFO - 2016-03-01 07:31:22 --> Model Class Initialized
INFO - 2016-03-01 07:31:22 --> Model Class Initialized
INFO - 2016-03-01 07:31:22 --> Form Validation Class Initialized
INFO - 2016-03-01 07:31:22 --> Helper loaded: text_helper
INFO - 2016-03-01 07:31:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:31:22 --> Final output sent to browser
DEBUG - 2016-03-01 07:31:22 --> Total execution time: 1.1204
INFO - 2016-03-01 07:33:34 --> Config Class Initialized
INFO - 2016-03-01 07:33:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:33:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:33:34 --> Utf8 Class Initialized
INFO - 2016-03-01 07:33:34 --> URI Class Initialized
DEBUG - 2016-03-01 07:33:34 --> No URI present. Default controller set.
INFO - 2016-03-01 07:33:34 --> Router Class Initialized
INFO - 2016-03-01 07:33:34 --> Output Class Initialized
INFO - 2016-03-01 07:33:34 --> Security Class Initialized
DEBUG - 2016-03-01 07:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:33:34 --> Input Class Initialized
INFO - 2016-03-01 07:33:34 --> Language Class Initialized
INFO - 2016-03-01 07:33:34 --> Loader Class Initialized
INFO - 2016-03-01 07:33:34 --> Helper loaded: url_helper
INFO - 2016-03-01 07:33:34 --> Helper loaded: file_helper
INFO - 2016-03-01 07:33:34 --> Helper loaded: date_helper
INFO - 2016-03-01 07:33:34 --> Helper loaded: form_helper
INFO - 2016-03-01 07:33:34 --> Database Driver Class Initialized
INFO - 2016-03-01 07:33:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:33:35 --> Controller Class Initialized
INFO - 2016-03-01 07:33:35 --> Model Class Initialized
INFO - 2016-03-01 07:33:35 --> Model Class Initialized
INFO - 2016-03-01 07:33:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:33:35 --> Pagination Class Initialized
INFO - 2016-03-01 07:33:35 --> Helper loaded: text_helper
INFO - 2016-03-01 07:33:35 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:33:35 --> Final output sent to browser
DEBUG - 2016-03-01 10:33:35 --> Total execution time: 1.1794
INFO - 2016-03-01 07:33:43 --> Config Class Initialized
INFO - 2016-03-01 07:33:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:33:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:33:43 --> Utf8 Class Initialized
INFO - 2016-03-01 07:33:43 --> URI Class Initialized
INFO - 2016-03-01 07:33:43 --> Router Class Initialized
INFO - 2016-03-01 07:33:43 --> Output Class Initialized
INFO - 2016-03-01 07:33:43 --> Security Class Initialized
DEBUG - 2016-03-01 07:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:33:43 --> Input Class Initialized
INFO - 2016-03-01 07:33:43 --> Language Class Initialized
ERROR - 2016-03-01 07:33:43 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 58
INFO - 2016-03-01 07:33:50 --> Config Class Initialized
INFO - 2016-03-01 07:33:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:33:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:33:50 --> Utf8 Class Initialized
INFO - 2016-03-01 07:33:50 --> URI Class Initialized
INFO - 2016-03-01 07:33:50 --> Router Class Initialized
INFO - 2016-03-01 07:33:50 --> Output Class Initialized
INFO - 2016-03-01 07:33:50 --> Security Class Initialized
DEBUG - 2016-03-01 07:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:33:50 --> Input Class Initialized
INFO - 2016-03-01 07:33:50 --> Language Class Initialized
ERROR - 2016-03-01 07:33:50 --> Severity: Parsing Error --> syntax error, unexpected '$result' (T_VARIABLE) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 58
INFO - 2016-03-01 07:34:03 --> Config Class Initialized
INFO - 2016-03-01 07:34:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:34:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:34:03 --> Utf8 Class Initialized
INFO - 2016-03-01 07:34:03 --> URI Class Initialized
INFO - 2016-03-01 07:34:03 --> Router Class Initialized
INFO - 2016-03-01 07:34:03 --> Output Class Initialized
INFO - 2016-03-01 07:34:03 --> Security Class Initialized
DEBUG - 2016-03-01 07:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:34:03 --> Input Class Initialized
INFO - 2016-03-01 07:34:03 --> Language Class Initialized
INFO - 2016-03-01 07:34:03 --> Loader Class Initialized
INFO - 2016-03-01 07:34:03 --> Helper loaded: url_helper
INFO - 2016-03-01 07:34:03 --> Helper loaded: file_helper
INFO - 2016-03-01 07:34:03 --> Helper loaded: date_helper
INFO - 2016-03-01 07:34:03 --> Helper loaded: form_helper
INFO - 2016-03-01 07:34:03 --> Database Driver Class Initialized
INFO - 2016-03-01 07:34:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:34:04 --> Controller Class Initialized
INFO - 2016-03-01 07:34:04 --> Model Class Initialized
INFO - 2016-03-01 07:34:04 --> Model Class Initialized
INFO - 2016-03-01 07:34:04 --> Form Validation Class Initialized
INFO - 2016-03-01 07:34:04 --> Helper loaded: text_helper
INFO - 2016-03-01 07:34:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:34:04 --> Final output sent to browser
DEBUG - 2016-03-01 07:34:04 --> Total execution time: 1.1093
INFO - 2016-03-01 07:34:55 --> Config Class Initialized
INFO - 2016-03-01 07:34:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:34:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:34:55 --> Utf8 Class Initialized
INFO - 2016-03-01 07:34:55 --> URI Class Initialized
DEBUG - 2016-03-01 07:34:55 --> No URI present. Default controller set.
INFO - 2016-03-01 07:34:55 --> Router Class Initialized
INFO - 2016-03-01 07:34:55 --> Output Class Initialized
INFO - 2016-03-01 07:34:55 --> Security Class Initialized
DEBUG - 2016-03-01 07:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:34:55 --> Input Class Initialized
INFO - 2016-03-01 07:34:55 --> Language Class Initialized
INFO - 2016-03-01 07:34:55 --> Loader Class Initialized
INFO - 2016-03-01 07:34:55 --> Helper loaded: url_helper
INFO - 2016-03-01 07:34:55 --> Helper loaded: file_helper
INFO - 2016-03-01 07:34:55 --> Helper loaded: date_helper
INFO - 2016-03-01 07:34:55 --> Helper loaded: form_helper
INFO - 2016-03-01 07:34:55 --> Database Driver Class Initialized
INFO - 2016-03-01 07:34:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:34:56 --> Controller Class Initialized
INFO - 2016-03-01 07:34:56 --> Model Class Initialized
INFO - 2016-03-01 07:34:57 --> Model Class Initialized
INFO - 2016-03-01 07:34:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:34:57 --> Pagination Class Initialized
INFO - 2016-03-01 07:34:57 --> Helper loaded: text_helper
INFO - 2016-03-01 07:34:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:34:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:34:57 --> Final output sent to browser
DEBUG - 2016-03-01 10:34:57 --> Total execution time: 1.1451
INFO - 2016-03-01 07:35:03 --> Config Class Initialized
INFO - 2016-03-01 07:35:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:35:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:35:03 --> Utf8 Class Initialized
INFO - 2016-03-01 07:35:03 --> URI Class Initialized
INFO - 2016-03-01 07:35:03 --> Router Class Initialized
INFO - 2016-03-01 07:35:03 --> Output Class Initialized
INFO - 2016-03-01 07:35:03 --> Security Class Initialized
DEBUG - 2016-03-01 07:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:35:03 --> Input Class Initialized
INFO - 2016-03-01 07:35:03 --> Language Class Initialized
INFO - 2016-03-01 07:35:03 --> Loader Class Initialized
INFO - 2016-03-01 07:35:03 --> Helper loaded: url_helper
INFO - 2016-03-01 07:35:03 --> Helper loaded: file_helper
INFO - 2016-03-01 07:35:03 --> Helper loaded: date_helper
INFO - 2016-03-01 07:35:03 --> Helper loaded: form_helper
INFO - 2016-03-01 07:35:03 --> Database Driver Class Initialized
INFO - 2016-03-01 07:35:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:35:04 --> Controller Class Initialized
INFO - 2016-03-01 07:35:04 --> Model Class Initialized
INFO - 2016-03-01 07:35:04 --> Model Class Initialized
INFO - 2016-03-01 07:35:04 --> Form Validation Class Initialized
INFO - 2016-03-01 07:35:04 --> Helper loaded: text_helper
INFO - 2016-03-01 07:35:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:35:04 --> Final output sent to browser
DEBUG - 2016-03-01 07:35:04 --> Total execution time: 1.1222
INFO - 2016-03-01 07:38:52 --> Config Class Initialized
INFO - 2016-03-01 07:38:52 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:38:52 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:38:52 --> Utf8 Class Initialized
INFO - 2016-03-01 07:38:52 --> URI Class Initialized
INFO - 2016-03-01 07:38:52 --> Router Class Initialized
INFO - 2016-03-01 07:38:52 --> Output Class Initialized
INFO - 2016-03-01 07:38:52 --> Security Class Initialized
DEBUG - 2016-03-01 07:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:38:52 --> Input Class Initialized
INFO - 2016-03-01 07:38:52 --> Language Class Initialized
INFO - 2016-03-01 07:38:52 --> Loader Class Initialized
INFO - 2016-03-01 07:38:52 --> Helper loaded: url_helper
INFO - 2016-03-01 07:38:52 --> Helper loaded: file_helper
INFO - 2016-03-01 07:38:52 --> Helper loaded: date_helper
INFO - 2016-03-01 07:38:52 --> Helper loaded: form_helper
INFO - 2016-03-01 07:38:52 --> Database Driver Class Initialized
INFO - 2016-03-01 07:38:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:38:53 --> Controller Class Initialized
INFO - 2016-03-01 07:38:53 --> Model Class Initialized
INFO - 2016-03-01 07:38:53 --> Model Class Initialized
INFO - 2016-03-01 07:38:53 --> Form Validation Class Initialized
INFO - 2016-03-01 07:38:53 --> Helper loaded: text_helper
INFO - 2016-03-01 07:38:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:38:53 --> Final output sent to browser
DEBUG - 2016-03-01 07:38:53 --> Total execution time: 1.1101
INFO - 2016-03-01 07:38:58 --> Config Class Initialized
INFO - 2016-03-01 07:38:58 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:38:58 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:38:58 --> Utf8 Class Initialized
INFO - 2016-03-01 07:38:58 --> URI Class Initialized
DEBUG - 2016-03-01 07:38:58 --> No URI present. Default controller set.
INFO - 2016-03-01 07:38:58 --> Router Class Initialized
INFO - 2016-03-01 07:38:58 --> Output Class Initialized
INFO - 2016-03-01 07:38:58 --> Security Class Initialized
DEBUG - 2016-03-01 07:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:38:58 --> Input Class Initialized
INFO - 2016-03-01 07:38:58 --> Language Class Initialized
INFO - 2016-03-01 07:38:58 --> Loader Class Initialized
INFO - 2016-03-01 07:38:58 --> Helper loaded: url_helper
INFO - 2016-03-01 07:38:58 --> Helper loaded: file_helper
INFO - 2016-03-01 07:38:58 --> Helper loaded: date_helper
INFO - 2016-03-01 07:38:58 --> Helper loaded: form_helper
INFO - 2016-03-01 07:38:58 --> Database Driver Class Initialized
INFO - 2016-03-01 07:38:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:38:59 --> Controller Class Initialized
INFO - 2016-03-01 07:38:59 --> Model Class Initialized
INFO - 2016-03-01 07:38:59 --> Model Class Initialized
INFO - 2016-03-01 07:38:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:38:59 --> Pagination Class Initialized
INFO - 2016-03-01 07:38:59 --> Helper loaded: text_helper
INFO - 2016-03-01 07:38:59 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:38:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:38:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:38:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:38:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:38:59 --> Final output sent to browser
DEBUG - 2016-03-01 10:38:59 --> Total execution time: 1.2008
INFO - 2016-03-01 07:39:08 --> Config Class Initialized
INFO - 2016-03-01 07:39:08 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:39:08 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:39:08 --> Utf8 Class Initialized
INFO - 2016-03-01 07:39:08 --> URI Class Initialized
INFO - 2016-03-01 07:39:08 --> Router Class Initialized
INFO - 2016-03-01 07:39:08 --> Output Class Initialized
INFO - 2016-03-01 07:39:08 --> Security Class Initialized
DEBUG - 2016-03-01 07:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:39:08 --> Input Class Initialized
INFO - 2016-03-01 07:39:08 --> Language Class Initialized
INFO - 2016-03-01 07:39:08 --> Loader Class Initialized
INFO - 2016-03-01 07:39:08 --> Helper loaded: url_helper
INFO - 2016-03-01 07:39:08 --> Helper loaded: file_helper
INFO - 2016-03-01 07:39:08 --> Helper loaded: date_helper
INFO - 2016-03-01 07:39:08 --> Helper loaded: form_helper
INFO - 2016-03-01 07:39:08 --> Database Driver Class Initialized
INFO - 2016-03-01 07:39:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:39:09 --> Controller Class Initialized
INFO - 2016-03-01 07:39:09 --> Model Class Initialized
INFO - 2016-03-01 07:39:09 --> Model Class Initialized
INFO - 2016-03-01 07:39:09 --> Form Validation Class Initialized
INFO - 2016-03-01 07:39:09 --> Helper loaded: text_helper
INFO - 2016-03-01 07:39:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:39:09 --> Final output sent to browser
DEBUG - 2016-03-01 07:39:09 --> Total execution time: 1.1326
INFO - 2016-03-01 07:41:22 --> Config Class Initialized
INFO - 2016-03-01 07:41:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:41:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:41:22 --> Utf8 Class Initialized
INFO - 2016-03-01 07:41:22 --> URI Class Initialized
DEBUG - 2016-03-01 07:41:22 --> No URI present. Default controller set.
INFO - 2016-03-01 07:41:22 --> Router Class Initialized
INFO - 2016-03-01 07:41:22 --> Output Class Initialized
INFO - 2016-03-01 07:41:22 --> Security Class Initialized
DEBUG - 2016-03-01 07:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:41:22 --> Input Class Initialized
INFO - 2016-03-01 07:41:22 --> Language Class Initialized
INFO - 2016-03-01 07:41:22 --> Loader Class Initialized
INFO - 2016-03-01 07:41:22 --> Helper loaded: url_helper
INFO - 2016-03-01 07:41:22 --> Helper loaded: file_helper
INFO - 2016-03-01 07:41:22 --> Helper loaded: date_helper
INFO - 2016-03-01 07:41:22 --> Helper loaded: form_helper
INFO - 2016-03-01 07:41:22 --> Database Driver Class Initialized
INFO - 2016-03-01 07:41:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:41:23 --> Controller Class Initialized
INFO - 2016-03-01 07:41:23 --> Model Class Initialized
INFO - 2016-03-01 07:41:23 --> Model Class Initialized
INFO - 2016-03-01 07:41:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:41:23 --> Pagination Class Initialized
INFO - 2016-03-01 07:41:23 --> Helper loaded: text_helper
INFO - 2016-03-01 07:41:23 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:41:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:41:23 --> Final output sent to browser
DEBUG - 2016-03-01 10:41:23 --> Total execution time: 1.1666
INFO - 2016-03-01 07:41:33 --> Config Class Initialized
INFO - 2016-03-01 07:41:33 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:41:33 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:41:33 --> Utf8 Class Initialized
INFO - 2016-03-01 07:41:33 --> URI Class Initialized
DEBUG - 2016-03-01 07:41:33 --> No URI present. Default controller set.
INFO - 2016-03-01 07:41:33 --> Router Class Initialized
INFO - 2016-03-01 07:41:33 --> Output Class Initialized
INFO - 2016-03-01 07:41:33 --> Security Class Initialized
DEBUG - 2016-03-01 07:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:41:33 --> Input Class Initialized
INFO - 2016-03-01 07:41:33 --> Language Class Initialized
INFO - 2016-03-01 07:41:33 --> Loader Class Initialized
INFO - 2016-03-01 07:41:33 --> Helper loaded: url_helper
INFO - 2016-03-01 07:41:33 --> Helper loaded: file_helper
INFO - 2016-03-01 07:41:33 --> Helper loaded: date_helper
INFO - 2016-03-01 07:41:33 --> Helper loaded: form_helper
INFO - 2016-03-01 07:41:33 --> Database Driver Class Initialized
INFO - 2016-03-01 07:41:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:41:34 --> Controller Class Initialized
INFO - 2016-03-01 07:41:34 --> Model Class Initialized
INFO - 2016-03-01 07:41:34 --> Model Class Initialized
INFO - 2016-03-01 07:41:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:41:34 --> Pagination Class Initialized
INFO - 2016-03-01 07:41:34 --> Helper loaded: text_helper
INFO - 2016-03-01 07:41:34 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:41:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:41:34 --> Final output sent to browser
DEBUG - 2016-03-01 10:41:34 --> Total execution time: 1.1634
INFO - 2016-03-01 07:41:40 --> Config Class Initialized
INFO - 2016-03-01 07:41:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:41:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:41:40 --> Utf8 Class Initialized
INFO - 2016-03-01 07:41:40 --> URI Class Initialized
INFO - 2016-03-01 07:41:40 --> Router Class Initialized
INFO - 2016-03-01 07:41:40 --> Output Class Initialized
INFO - 2016-03-01 07:41:40 --> Security Class Initialized
DEBUG - 2016-03-01 07:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:41:40 --> Input Class Initialized
INFO - 2016-03-01 07:41:40 --> Language Class Initialized
INFO - 2016-03-01 07:41:40 --> Loader Class Initialized
INFO - 2016-03-01 07:41:40 --> Helper loaded: url_helper
INFO - 2016-03-01 07:41:40 --> Helper loaded: file_helper
INFO - 2016-03-01 07:41:40 --> Helper loaded: date_helper
INFO - 2016-03-01 07:41:40 --> Helper loaded: form_helper
INFO - 2016-03-01 07:41:40 --> Database Driver Class Initialized
INFO - 2016-03-01 07:41:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:41:41 --> Controller Class Initialized
INFO - 2016-03-01 07:41:41 --> Model Class Initialized
INFO - 2016-03-01 07:41:41 --> Model Class Initialized
INFO - 2016-03-01 07:41:41 --> Form Validation Class Initialized
INFO - 2016-03-01 07:41:41 --> Helper loaded: text_helper
INFO - 2016-03-01 07:41:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:41:41 --> Final output sent to browser
DEBUG - 2016-03-01 07:41:41 --> Total execution time: 1.1078
INFO - 2016-03-01 07:44:28 --> Config Class Initialized
INFO - 2016-03-01 07:44:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:44:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:44:28 --> Utf8 Class Initialized
INFO - 2016-03-01 07:44:28 --> URI Class Initialized
DEBUG - 2016-03-01 07:44:28 --> No URI present. Default controller set.
INFO - 2016-03-01 07:44:28 --> Router Class Initialized
INFO - 2016-03-01 07:44:28 --> Output Class Initialized
INFO - 2016-03-01 07:44:28 --> Security Class Initialized
DEBUG - 2016-03-01 07:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:44:28 --> Input Class Initialized
INFO - 2016-03-01 07:44:28 --> Language Class Initialized
INFO - 2016-03-01 07:44:28 --> Loader Class Initialized
INFO - 2016-03-01 07:44:28 --> Helper loaded: url_helper
INFO - 2016-03-01 07:44:28 --> Helper loaded: file_helper
INFO - 2016-03-01 07:44:28 --> Helper loaded: date_helper
INFO - 2016-03-01 07:44:28 --> Helper loaded: form_helper
INFO - 2016-03-01 07:44:28 --> Database Driver Class Initialized
INFO - 2016-03-01 07:44:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:44:29 --> Controller Class Initialized
INFO - 2016-03-01 07:44:29 --> Model Class Initialized
INFO - 2016-03-01 07:44:29 --> Model Class Initialized
INFO - 2016-03-01 07:44:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:44:29 --> Pagination Class Initialized
INFO - 2016-03-01 07:44:29 --> Helper loaded: text_helper
INFO - 2016-03-01 07:44:29 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:44:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:44:29 --> Final output sent to browser
DEBUG - 2016-03-01 10:44:29 --> Total execution time: 1.1545
INFO - 2016-03-01 07:44:54 --> Config Class Initialized
INFO - 2016-03-01 07:44:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:44:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:44:54 --> Utf8 Class Initialized
INFO - 2016-03-01 07:44:54 --> URI Class Initialized
DEBUG - 2016-03-01 07:44:54 --> No URI present. Default controller set.
INFO - 2016-03-01 07:44:54 --> Router Class Initialized
INFO - 2016-03-01 07:44:54 --> Output Class Initialized
INFO - 2016-03-01 07:44:54 --> Security Class Initialized
DEBUG - 2016-03-01 07:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:44:54 --> Input Class Initialized
INFO - 2016-03-01 07:44:54 --> Language Class Initialized
INFO - 2016-03-01 07:44:54 --> Loader Class Initialized
INFO - 2016-03-01 07:44:54 --> Helper loaded: url_helper
INFO - 2016-03-01 07:44:54 --> Helper loaded: file_helper
INFO - 2016-03-01 07:44:54 --> Helper loaded: date_helper
INFO - 2016-03-01 07:44:54 --> Helper loaded: form_helper
INFO - 2016-03-01 07:44:54 --> Database Driver Class Initialized
INFO - 2016-03-01 07:44:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:44:56 --> Controller Class Initialized
INFO - 2016-03-01 07:44:56 --> Model Class Initialized
INFO - 2016-03-01 07:44:56 --> Model Class Initialized
INFO - 2016-03-01 07:44:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:44:56 --> Pagination Class Initialized
INFO - 2016-03-01 07:44:56 --> Helper loaded: text_helper
INFO - 2016-03-01 07:44:56 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:44:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:44:56 --> Final output sent to browser
DEBUG - 2016-03-01 10:44:56 --> Total execution time: 1.1742
INFO - 2016-03-01 07:48:22 --> Config Class Initialized
INFO - 2016-03-01 07:48:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:48:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:48:22 --> Utf8 Class Initialized
INFO - 2016-03-01 07:48:22 --> URI Class Initialized
DEBUG - 2016-03-01 07:48:22 --> No URI present. Default controller set.
INFO - 2016-03-01 07:48:22 --> Router Class Initialized
INFO - 2016-03-01 07:48:22 --> Output Class Initialized
INFO - 2016-03-01 07:48:22 --> Security Class Initialized
DEBUG - 2016-03-01 07:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:48:22 --> Input Class Initialized
INFO - 2016-03-01 07:48:22 --> Language Class Initialized
INFO - 2016-03-01 07:48:22 --> Loader Class Initialized
INFO - 2016-03-01 07:48:22 --> Helper loaded: url_helper
INFO - 2016-03-01 07:48:22 --> Helper loaded: file_helper
INFO - 2016-03-01 07:48:22 --> Helper loaded: date_helper
INFO - 2016-03-01 07:48:22 --> Helper loaded: form_helper
INFO - 2016-03-01 07:48:22 --> Database Driver Class Initialized
INFO - 2016-03-01 07:48:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:48:23 --> Controller Class Initialized
INFO - 2016-03-01 07:48:24 --> Model Class Initialized
INFO - 2016-03-01 07:48:24 --> Model Class Initialized
INFO - 2016-03-01 07:48:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:48:24 --> Pagination Class Initialized
INFO - 2016-03-01 07:48:24 --> Helper loaded: text_helper
INFO - 2016-03-01 07:48:24 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:48:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:48:24 --> Final output sent to browser
DEBUG - 2016-03-01 10:48:24 --> Total execution time: 1.1542
INFO - 2016-03-01 07:48:38 --> Config Class Initialized
INFO - 2016-03-01 07:48:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:48:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:48:38 --> Utf8 Class Initialized
INFO - 2016-03-01 07:48:38 --> URI Class Initialized
INFO - 2016-03-01 07:48:38 --> Router Class Initialized
INFO - 2016-03-01 07:48:38 --> Output Class Initialized
INFO - 2016-03-01 07:48:38 --> Security Class Initialized
DEBUG - 2016-03-01 07:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:48:38 --> Input Class Initialized
INFO - 2016-03-01 07:48:38 --> Language Class Initialized
INFO - 2016-03-01 07:48:38 --> Loader Class Initialized
INFO - 2016-03-01 07:48:38 --> Helper loaded: url_helper
INFO - 2016-03-01 07:48:38 --> Helper loaded: file_helper
INFO - 2016-03-01 07:48:38 --> Helper loaded: date_helper
INFO - 2016-03-01 07:48:38 --> Helper loaded: form_helper
INFO - 2016-03-01 07:48:38 --> Database Driver Class Initialized
INFO - 2016-03-01 07:48:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:48:39 --> Controller Class Initialized
INFO - 2016-03-01 07:48:39 --> Model Class Initialized
INFO - 2016-03-01 07:48:39 --> Model Class Initialized
INFO - 2016-03-01 07:48:39 --> Form Validation Class Initialized
INFO - 2016-03-01 07:48:39 --> Helper loaded: text_helper
INFO - 2016-03-01 07:48:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:48:39 --> Final output sent to browser
DEBUG - 2016-03-01 07:48:39 --> Total execution time: 1.1710
INFO - 2016-03-01 07:57:48 --> Config Class Initialized
INFO - 2016-03-01 07:57:49 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:57:49 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:57:49 --> Utf8 Class Initialized
INFO - 2016-03-01 07:57:49 --> URI Class Initialized
DEBUG - 2016-03-01 07:57:49 --> No URI present. Default controller set.
INFO - 2016-03-01 07:57:49 --> Router Class Initialized
INFO - 2016-03-01 07:57:49 --> Output Class Initialized
INFO - 2016-03-01 07:57:49 --> Security Class Initialized
DEBUG - 2016-03-01 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:57:49 --> Input Class Initialized
INFO - 2016-03-01 07:57:49 --> Language Class Initialized
INFO - 2016-03-01 07:57:49 --> Loader Class Initialized
INFO - 2016-03-01 07:57:49 --> Helper loaded: url_helper
INFO - 2016-03-01 07:57:49 --> Helper loaded: file_helper
INFO - 2016-03-01 07:57:49 --> Helper loaded: date_helper
INFO - 2016-03-01 07:57:49 --> Helper loaded: form_helper
INFO - 2016-03-01 07:57:49 --> Database Driver Class Initialized
INFO - 2016-03-01 07:57:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:57:50 --> Controller Class Initialized
INFO - 2016-03-01 07:57:50 --> Model Class Initialized
INFO - 2016-03-01 07:57:50 --> Model Class Initialized
INFO - 2016-03-01 07:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 07:57:50 --> Pagination Class Initialized
INFO - 2016-03-01 07:57:50 --> Helper loaded: text_helper
INFO - 2016-03-01 07:57:50 --> Helper loaded: cookie_helper
INFO - 2016-03-01 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 10:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 10:57:50 --> Final output sent to browser
DEBUG - 2016-03-01 10:57:50 --> Total execution time: 1.5295
INFO - 2016-03-01 07:58:00 --> Config Class Initialized
INFO - 2016-03-01 07:58:00 --> Hooks Class Initialized
DEBUG - 2016-03-01 07:58:00 --> UTF-8 Support Enabled
INFO - 2016-03-01 07:58:00 --> Utf8 Class Initialized
INFO - 2016-03-01 07:58:00 --> URI Class Initialized
INFO - 2016-03-01 07:58:00 --> Router Class Initialized
INFO - 2016-03-01 07:58:00 --> Output Class Initialized
INFO - 2016-03-01 07:58:00 --> Security Class Initialized
DEBUG - 2016-03-01 07:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 07:58:00 --> Input Class Initialized
INFO - 2016-03-01 07:58:00 --> Language Class Initialized
INFO - 2016-03-01 07:58:00 --> Loader Class Initialized
INFO - 2016-03-01 07:58:00 --> Helper loaded: url_helper
INFO - 2016-03-01 07:58:00 --> Helper loaded: file_helper
INFO - 2016-03-01 07:58:00 --> Helper loaded: date_helper
INFO - 2016-03-01 07:58:00 --> Helper loaded: form_helper
INFO - 2016-03-01 07:58:00 --> Database Driver Class Initialized
INFO - 2016-03-01 07:58:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 07:58:01 --> Controller Class Initialized
INFO - 2016-03-01 07:58:01 --> Model Class Initialized
INFO - 2016-03-01 07:58:01 --> Model Class Initialized
INFO - 2016-03-01 07:58:01 --> Form Validation Class Initialized
INFO - 2016-03-01 07:58:01 --> Helper loaded: text_helper
INFO - 2016-03-01 07:58:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 07:58:01 --> Final output sent to browser
DEBUG - 2016-03-01 07:58:01 --> Total execution time: 1.1818
INFO - 2016-03-01 08:01:47 --> Config Class Initialized
INFO - 2016-03-01 08:01:47 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:01:47 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:01:47 --> Utf8 Class Initialized
INFO - 2016-03-01 08:01:47 --> URI Class Initialized
DEBUG - 2016-03-01 08:01:47 --> No URI present. Default controller set.
INFO - 2016-03-01 08:01:47 --> Router Class Initialized
INFO - 2016-03-01 08:01:47 --> Output Class Initialized
INFO - 2016-03-01 08:01:47 --> Security Class Initialized
DEBUG - 2016-03-01 08:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:01:47 --> Input Class Initialized
INFO - 2016-03-01 08:01:47 --> Language Class Initialized
INFO - 2016-03-01 08:01:48 --> Loader Class Initialized
INFO - 2016-03-01 08:01:48 --> Helper loaded: url_helper
INFO - 2016-03-01 08:01:48 --> Helper loaded: file_helper
INFO - 2016-03-01 08:01:48 --> Helper loaded: date_helper
INFO - 2016-03-01 08:01:48 --> Helper loaded: form_helper
INFO - 2016-03-01 08:01:48 --> Database Driver Class Initialized
INFO - 2016-03-01 08:01:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:01:49 --> Controller Class Initialized
INFO - 2016-03-01 08:01:49 --> Model Class Initialized
INFO - 2016-03-01 08:01:49 --> Model Class Initialized
INFO - 2016-03-01 08:01:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:01:49 --> Pagination Class Initialized
INFO - 2016-03-01 08:01:49 --> Helper loaded: text_helper
INFO - 2016-03-01 08:01:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:01:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:01:49 --> Final output sent to browser
DEBUG - 2016-03-01 11:01:49 --> Total execution time: 2.3722
INFO - 2016-03-01 08:02:06 --> Config Class Initialized
INFO - 2016-03-01 08:02:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:02:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:02:06 --> Utf8 Class Initialized
INFO - 2016-03-01 08:02:06 --> URI Class Initialized
INFO - 2016-03-01 08:02:06 --> Router Class Initialized
INFO - 2016-03-01 08:02:06 --> Output Class Initialized
INFO - 2016-03-01 08:02:06 --> Security Class Initialized
DEBUG - 2016-03-01 08:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:02:06 --> Input Class Initialized
INFO - 2016-03-01 08:02:06 --> Language Class Initialized
ERROR - 2016-03-01 08:02:06 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 63
INFO - 2016-03-01 08:02:21 --> Config Class Initialized
INFO - 2016-03-01 08:02:21 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:02:21 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:02:21 --> Utf8 Class Initialized
INFO - 2016-03-01 08:02:21 --> URI Class Initialized
DEBUG - 2016-03-01 08:02:21 --> No URI present. Default controller set.
INFO - 2016-03-01 08:02:21 --> Router Class Initialized
INFO - 2016-03-01 08:02:21 --> Output Class Initialized
INFO - 2016-03-01 08:02:21 --> Security Class Initialized
DEBUG - 2016-03-01 08:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:02:21 --> Input Class Initialized
INFO - 2016-03-01 08:02:21 --> Language Class Initialized
INFO - 2016-03-01 08:02:21 --> Loader Class Initialized
INFO - 2016-03-01 08:02:21 --> Helper loaded: url_helper
INFO - 2016-03-01 08:02:21 --> Helper loaded: file_helper
INFO - 2016-03-01 08:02:21 --> Helper loaded: date_helper
INFO - 2016-03-01 08:02:21 --> Helper loaded: form_helper
INFO - 2016-03-01 08:02:21 --> Database Driver Class Initialized
INFO - 2016-03-01 08:02:22 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:02:22 --> Controller Class Initialized
INFO - 2016-03-01 08:02:22 --> Model Class Initialized
INFO - 2016-03-01 08:02:22 --> Model Class Initialized
INFO - 2016-03-01 08:02:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:02:22 --> Pagination Class Initialized
INFO - 2016-03-01 08:02:22 --> Helper loaded: text_helper
INFO - 2016-03-01 08:02:22 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:02:22 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:02:22 --> Final output sent to browser
DEBUG - 2016-03-01 11:02:22 --> Total execution time: 1.2823
INFO - 2016-03-01 08:02:28 --> Config Class Initialized
INFO - 2016-03-01 08:02:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:02:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:02:28 --> Utf8 Class Initialized
INFO - 2016-03-01 08:02:28 --> URI Class Initialized
INFO - 2016-03-01 08:02:28 --> Router Class Initialized
INFO - 2016-03-01 08:02:28 --> Output Class Initialized
INFO - 2016-03-01 08:02:29 --> Security Class Initialized
DEBUG - 2016-03-01 08:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:02:29 --> Input Class Initialized
INFO - 2016-03-01 08:02:29 --> Language Class Initialized
ERROR - 2016-03-01 08:02:29 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 62
INFO - 2016-03-01 08:02:48 --> Config Class Initialized
INFO - 2016-03-01 08:02:48 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:02:48 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:02:48 --> Utf8 Class Initialized
INFO - 2016-03-01 08:02:48 --> URI Class Initialized
DEBUG - 2016-03-01 08:02:48 --> No URI present. Default controller set.
INFO - 2016-03-01 08:02:48 --> Router Class Initialized
INFO - 2016-03-01 08:02:48 --> Output Class Initialized
INFO - 2016-03-01 08:02:48 --> Security Class Initialized
DEBUG - 2016-03-01 08:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:02:48 --> Input Class Initialized
INFO - 2016-03-01 08:02:48 --> Language Class Initialized
INFO - 2016-03-01 08:02:48 --> Loader Class Initialized
INFO - 2016-03-01 08:02:48 --> Helper loaded: url_helper
INFO - 2016-03-01 08:02:48 --> Helper loaded: file_helper
INFO - 2016-03-01 08:02:48 --> Helper loaded: date_helper
INFO - 2016-03-01 08:02:48 --> Helper loaded: form_helper
INFO - 2016-03-01 08:02:48 --> Database Driver Class Initialized
INFO - 2016-03-01 08:02:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:02:49 --> Controller Class Initialized
INFO - 2016-03-01 08:02:49 --> Model Class Initialized
INFO - 2016-03-01 08:02:49 --> Model Class Initialized
INFO - 2016-03-01 08:02:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:02:49 --> Pagination Class Initialized
INFO - 2016-03-01 08:02:49 --> Helper loaded: text_helper
INFO - 2016-03-01 08:02:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:02:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:02:49 --> Final output sent to browser
DEBUG - 2016-03-01 11:02:49 --> Total execution time: 1.1638
INFO - 2016-03-01 08:02:55 --> Config Class Initialized
INFO - 2016-03-01 08:02:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:02:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:02:55 --> Utf8 Class Initialized
INFO - 2016-03-01 08:02:55 --> URI Class Initialized
INFO - 2016-03-01 08:02:55 --> Router Class Initialized
INFO - 2016-03-01 08:02:55 --> Output Class Initialized
INFO - 2016-03-01 08:02:55 --> Security Class Initialized
DEBUG - 2016-03-01 08:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:02:55 --> Input Class Initialized
INFO - 2016-03-01 08:02:55 --> Language Class Initialized
ERROR - 2016-03-01 08:02:55 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 62
INFO - 2016-03-01 08:04:50 --> Config Class Initialized
INFO - 2016-03-01 08:04:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:04:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:04:50 --> Utf8 Class Initialized
INFO - 2016-03-01 08:04:51 --> URI Class Initialized
DEBUG - 2016-03-01 08:04:51 --> No URI present. Default controller set.
INFO - 2016-03-01 08:04:51 --> Router Class Initialized
INFO - 2016-03-01 08:04:51 --> Output Class Initialized
INFO - 2016-03-01 08:04:51 --> Security Class Initialized
DEBUG - 2016-03-01 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:04:51 --> Input Class Initialized
INFO - 2016-03-01 08:04:51 --> Language Class Initialized
INFO - 2016-03-01 08:04:51 --> Loader Class Initialized
INFO - 2016-03-01 08:04:51 --> Helper loaded: url_helper
INFO - 2016-03-01 08:04:51 --> Helper loaded: file_helper
INFO - 2016-03-01 08:04:51 --> Helper loaded: date_helper
INFO - 2016-03-01 08:04:51 --> Helper loaded: form_helper
INFO - 2016-03-01 08:04:51 --> Database Driver Class Initialized
INFO - 2016-03-01 08:04:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:04:52 --> Controller Class Initialized
INFO - 2016-03-01 08:04:52 --> Model Class Initialized
INFO - 2016-03-01 08:04:52 --> Model Class Initialized
INFO - 2016-03-01 08:04:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:04:52 --> Pagination Class Initialized
INFO - 2016-03-01 08:04:52 --> Helper loaded: text_helper
INFO - 2016-03-01 08:04:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:04:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:04:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:04:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:04:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:04:52 --> Final output sent to browser
DEBUG - 2016-03-01 11:04:52 --> Total execution time: 1.8554
INFO - 2016-03-01 08:06:20 --> Config Class Initialized
INFO - 2016-03-01 08:06:20 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:06:20 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:06:20 --> Utf8 Class Initialized
INFO - 2016-03-01 08:06:20 --> URI Class Initialized
DEBUG - 2016-03-01 08:06:20 --> No URI present. Default controller set.
INFO - 2016-03-01 08:06:20 --> Router Class Initialized
INFO - 2016-03-01 08:06:20 --> Output Class Initialized
INFO - 2016-03-01 08:06:20 --> Security Class Initialized
DEBUG - 2016-03-01 08:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:06:20 --> Input Class Initialized
INFO - 2016-03-01 08:06:20 --> Language Class Initialized
INFO - 2016-03-01 08:06:20 --> Loader Class Initialized
INFO - 2016-03-01 08:06:20 --> Helper loaded: url_helper
INFO - 2016-03-01 08:06:20 --> Helper loaded: file_helper
INFO - 2016-03-01 08:06:20 --> Helper loaded: date_helper
INFO - 2016-03-01 08:06:20 --> Helper loaded: form_helper
INFO - 2016-03-01 08:06:20 --> Database Driver Class Initialized
INFO - 2016-03-01 08:06:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:06:21 --> Controller Class Initialized
INFO - 2016-03-01 08:06:21 --> Model Class Initialized
INFO - 2016-03-01 08:06:21 --> Model Class Initialized
INFO - 2016-03-01 08:06:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:06:21 --> Pagination Class Initialized
INFO - 2016-03-01 08:06:21 --> Helper loaded: text_helper
INFO - 2016-03-01 08:06:21 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:06:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:06:21 --> Final output sent to browser
DEBUG - 2016-03-01 11:06:21 --> Total execution time: 1.2460
INFO - 2016-03-01 08:06:30 --> Config Class Initialized
INFO - 2016-03-01 08:06:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:06:30 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:06:30 --> Utf8 Class Initialized
INFO - 2016-03-01 08:06:30 --> URI Class Initialized
INFO - 2016-03-01 08:06:30 --> Router Class Initialized
INFO - 2016-03-01 08:06:30 --> Output Class Initialized
INFO - 2016-03-01 08:06:30 --> Security Class Initialized
DEBUG - 2016-03-01 08:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:06:30 --> Input Class Initialized
INFO - 2016-03-01 08:06:30 --> Language Class Initialized
ERROR - 2016-03-01 08:06:30 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\auth.php 64
INFO - 2016-03-01 08:06:57 --> Config Class Initialized
INFO - 2016-03-01 08:06:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:06:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:06:57 --> Utf8 Class Initialized
INFO - 2016-03-01 08:06:57 --> URI Class Initialized
DEBUG - 2016-03-01 08:06:57 --> No URI present. Default controller set.
INFO - 2016-03-01 08:06:57 --> Router Class Initialized
INFO - 2016-03-01 08:06:57 --> Output Class Initialized
INFO - 2016-03-01 08:06:57 --> Security Class Initialized
DEBUG - 2016-03-01 08:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:06:57 --> Input Class Initialized
INFO - 2016-03-01 08:06:57 --> Language Class Initialized
INFO - 2016-03-01 08:06:57 --> Loader Class Initialized
INFO - 2016-03-01 08:06:57 --> Helper loaded: url_helper
INFO - 2016-03-01 08:06:57 --> Helper loaded: file_helper
INFO - 2016-03-01 08:06:57 --> Helper loaded: date_helper
INFO - 2016-03-01 08:06:57 --> Helper loaded: form_helper
INFO - 2016-03-01 08:06:57 --> Database Driver Class Initialized
INFO - 2016-03-01 08:06:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:06:58 --> Controller Class Initialized
INFO - 2016-03-01 08:06:58 --> Model Class Initialized
INFO - 2016-03-01 08:06:58 --> Model Class Initialized
INFO - 2016-03-01 08:06:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:06:58 --> Pagination Class Initialized
INFO - 2016-03-01 08:06:58 --> Helper loaded: text_helper
INFO - 2016-03-01 08:06:58 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:06:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:06:59 --> Final output sent to browser
DEBUG - 2016-03-01 11:06:59 --> Total execution time: 1.1757
INFO - 2016-03-01 08:07:04 --> Config Class Initialized
INFO - 2016-03-01 08:07:04 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:07:04 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:07:04 --> Utf8 Class Initialized
INFO - 2016-03-01 08:07:04 --> URI Class Initialized
INFO - 2016-03-01 08:07:04 --> Router Class Initialized
INFO - 2016-03-01 08:07:04 --> Output Class Initialized
INFO - 2016-03-01 08:07:04 --> Security Class Initialized
DEBUG - 2016-03-01 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:07:04 --> Input Class Initialized
INFO - 2016-03-01 08:07:04 --> Language Class Initialized
INFO - 2016-03-01 08:07:04 --> Loader Class Initialized
INFO - 2016-03-01 08:07:04 --> Helper loaded: url_helper
INFO - 2016-03-01 08:07:04 --> Helper loaded: file_helper
INFO - 2016-03-01 08:07:04 --> Helper loaded: date_helper
INFO - 2016-03-01 08:07:04 --> Helper loaded: form_helper
INFO - 2016-03-01 08:07:04 --> Database Driver Class Initialized
INFO - 2016-03-01 08:07:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:07:05 --> Controller Class Initialized
INFO - 2016-03-01 08:07:05 --> Model Class Initialized
INFO - 2016-03-01 08:07:05 --> Model Class Initialized
INFO - 2016-03-01 08:07:05 --> Form Validation Class Initialized
INFO - 2016-03-01 08:07:05 --> Helper loaded: text_helper
INFO - 2016-03-01 08:07:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:07:05 --> Final output sent to browser
DEBUG - 2016-03-01 08:07:05 --> Total execution time: 1.1431
INFO - 2016-03-01 08:07:39 --> Config Class Initialized
INFO - 2016-03-01 08:07:39 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:07:39 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:07:39 --> Utf8 Class Initialized
INFO - 2016-03-01 08:07:39 --> URI Class Initialized
DEBUG - 2016-03-01 08:07:39 --> No URI present. Default controller set.
INFO - 2016-03-01 08:07:39 --> Router Class Initialized
INFO - 2016-03-01 08:07:39 --> Output Class Initialized
INFO - 2016-03-01 08:07:39 --> Security Class Initialized
DEBUG - 2016-03-01 08:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:07:39 --> Input Class Initialized
INFO - 2016-03-01 08:07:39 --> Language Class Initialized
INFO - 2016-03-01 08:07:39 --> Loader Class Initialized
INFO - 2016-03-01 08:07:39 --> Helper loaded: url_helper
INFO - 2016-03-01 08:07:39 --> Helper loaded: file_helper
INFO - 2016-03-01 08:07:39 --> Helper loaded: date_helper
INFO - 2016-03-01 08:07:39 --> Helper loaded: form_helper
INFO - 2016-03-01 08:07:39 --> Database Driver Class Initialized
INFO - 2016-03-01 08:07:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:07:40 --> Controller Class Initialized
INFO - 2016-03-01 08:07:40 --> Model Class Initialized
INFO - 2016-03-01 08:07:40 --> Model Class Initialized
INFO - 2016-03-01 08:07:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:07:40 --> Pagination Class Initialized
INFO - 2016-03-01 08:07:40 --> Helper loaded: text_helper
INFO - 2016-03-01 08:07:40 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:07:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:07:40 --> Final output sent to browser
DEBUG - 2016-03-01 11:07:40 --> Total execution time: 1.1761
INFO - 2016-03-01 08:07:43 --> Config Class Initialized
INFO - 2016-03-01 08:07:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:07:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:07:43 --> Utf8 Class Initialized
INFO - 2016-03-01 08:07:43 --> URI Class Initialized
DEBUG - 2016-03-01 08:07:43 --> No URI present. Default controller set.
INFO - 2016-03-01 08:07:43 --> Router Class Initialized
INFO - 2016-03-01 08:07:43 --> Output Class Initialized
INFO - 2016-03-01 08:07:43 --> Security Class Initialized
DEBUG - 2016-03-01 08:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:07:43 --> Input Class Initialized
INFO - 2016-03-01 08:07:43 --> Language Class Initialized
INFO - 2016-03-01 08:07:43 --> Loader Class Initialized
INFO - 2016-03-01 08:07:43 --> Helper loaded: url_helper
INFO - 2016-03-01 08:07:43 --> Helper loaded: file_helper
INFO - 2016-03-01 08:07:43 --> Helper loaded: date_helper
INFO - 2016-03-01 08:07:43 --> Helper loaded: form_helper
INFO - 2016-03-01 08:07:43 --> Database Driver Class Initialized
INFO - 2016-03-01 08:07:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:07:44 --> Controller Class Initialized
INFO - 2016-03-01 08:07:44 --> Model Class Initialized
INFO - 2016-03-01 08:07:44 --> Model Class Initialized
INFO - 2016-03-01 08:07:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:07:44 --> Pagination Class Initialized
INFO - 2016-03-01 08:07:44 --> Helper loaded: text_helper
INFO - 2016-03-01 08:07:44 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:07:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:07:44 --> Final output sent to browser
DEBUG - 2016-03-01 11:07:44 --> Total execution time: 1.2124
INFO - 2016-03-01 08:09:30 --> Config Class Initialized
INFO - 2016-03-01 08:09:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:09:30 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:09:30 --> Utf8 Class Initialized
INFO - 2016-03-01 08:09:30 --> URI Class Initialized
DEBUG - 2016-03-01 08:09:30 --> No URI present. Default controller set.
INFO - 2016-03-01 08:09:30 --> Router Class Initialized
INFO - 2016-03-01 08:09:30 --> Output Class Initialized
INFO - 2016-03-01 08:09:30 --> Security Class Initialized
DEBUG - 2016-03-01 08:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:09:30 --> Input Class Initialized
INFO - 2016-03-01 08:09:30 --> Language Class Initialized
INFO - 2016-03-01 08:09:30 --> Loader Class Initialized
INFO - 2016-03-01 08:09:30 --> Helper loaded: url_helper
INFO - 2016-03-01 08:09:30 --> Helper loaded: file_helper
INFO - 2016-03-01 08:09:30 --> Helper loaded: date_helper
INFO - 2016-03-01 08:09:30 --> Helper loaded: form_helper
INFO - 2016-03-01 08:09:30 --> Database Driver Class Initialized
INFO - 2016-03-01 08:09:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:09:31 --> Controller Class Initialized
INFO - 2016-03-01 08:09:31 --> Model Class Initialized
INFO - 2016-03-01 08:09:31 --> Model Class Initialized
INFO - 2016-03-01 08:09:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:09:31 --> Pagination Class Initialized
INFO - 2016-03-01 08:09:31 --> Helper loaded: text_helper
INFO - 2016-03-01 08:09:31 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:09:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:09:31 --> Final output sent to browser
DEBUG - 2016-03-01 11:09:31 --> Total execution time: 1.1720
INFO - 2016-03-01 08:09:38 --> Config Class Initialized
INFO - 2016-03-01 08:09:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:09:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:09:38 --> Utf8 Class Initialized
INFO - 2016-03-01 08:09:38 --> URI Class Initialized
INFO - 2016-03-01 08:09:38 --> Router Class Initialized
INFO - 2016-03-01 08:09:38 --> Output Class Initialized
INFO - 2016-03-01 08:09:38 --> Security Class Initialized
DEBUG - 2016-03-01 08:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:09:38 --> Input Class Initialized
INFO - 2016-03-01 08:09:38 --> Language Class Initialized
INFO - 2016-03-01 08:09:38 --> Loader Class Initialized
INFO - 2016-03-01 08:09:38 --> Helper loaded: url_helper
INFO - 2016-03-01 08:09:38 --> Helper loaded: file_helper
INFO - 2016-03-01 08:09:38 --> Helper loaded: date_helper
INFO - 2016-03-01 08:09:38 --> Helper loaded: form_helper
INFO - 2016-03-01 08:09:38 --> Database Driver Class Initialized
INFO - 2016-03-01 08:09:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:09:39 --> Controller Class Initialized
INFO - 2016-03-01 08:09:39 --> Model Class Initialized
INFO - 2016-03-01 08:09:39 --> Model Class Initialized
INFO - 2016-03-01 08:09:39 --> Form Validation Class Initialized
INFO - 2016-03-01 08:09:39 --> Helper loaded: text_helper
INFO - 2016-03-01 08:09:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:09:39 --> Final output sent to browser
DEBUG - 2016-03-01 08:09:39 --> Total execution time: 1.1403
INFO - 2016-03-01 08:32:34 --> Config Class Initialized
INFO - 2016-03-01 08:32:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:32:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:32:34 --> Utf8 Class Initialized
INFO - 2016-03-01 08:32:34 --> URI Class Initialized
DEBUG - 2016-03-01 08:32:34 --> No URI present. Default controller set.
INFO - 2016-03-01 08:32:34 --> Router Class Initialized
INFO - 2016-03-01 08:32:34 --> Output Class Initialized
INFO - 2016-03-01 08:32:34 --> Security Class Initialized
DEBUG - 2016-03-01 08:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:32:34 --> Input Class Initialized
INFO - 2016-03-01 08:32:34 --> Language Class Initialized
INFO - 2016-03-01 08:32:34 --> Loader Class Initialized
INFO - 2016-03-01 08:32:34 --> Helper loaded: url_helper
INFO - 2016-03-01 08:32:34 --> Helper loaded: file_helper
INFO - 2016-03-01 08:32:34 --> Helper loaded: date_helper
INFO - 2016-03-01 08:32:34 --> Helper loaded: form_helper
INFO - 2016-03-01 08:32:34 --> Database Driver Class Initialized
INFO - 2016-03-01 08:32:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:32:35 --> Controller Class Initialized
INFO - 2016-03-01 08:32:35 --> Model Class Initialized
INFO - 2016-03-01 08:32:35 --> Model Class Initialized
INFO - 2016-03-01 08:32:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:32:35 --> Pagination Class Initialized
INFO - 2016-03-01 08:32:35 --> Helper loaded: text_helper
INFO - 2016-03-01 08:32:35 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:32:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:32:35 --> Final output sent to browser
DEBUG - 2016-03-01 11:32:35 --> Total execution time: 1.1717
INFO - 2016-03-01 08:34:54 --> Config Class Initialized
INFO - 2016-03-01 08:34:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:34:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:34:54 --> Utf8 Class Initialized
INFO - 2016-03-01 08:34:54 --> URI Class Initialized
DEBUG - 2016-03-01 08:34:54 --> No URI present. Default controller set.
INFO - 2016-03-01 08:34:54 --> Router Class Initialized
INFO - 2016-03-01 08:34:54 --> Output Class Initialized
INFO - 2016-03-01 08:34:54 --> Security Class Initialized
DEBUG - 2016-03-01 08:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:34:54 --> Input Class Initialized
INFO - 2016-03-01 08:34:54 --> Language Class Initialized
INFO - 2016-03-01 08:34:54 --> Loader Class Initialized
INFO - 2016-03-01 08:34:54 --> Helper loaded: url_helper
INFO - 2016-03-01 08:34:54 --> Helper loaded: file_helper
INFO - 2016-03-01 08:34:54 --> Helper loaded: date_helper
INFO - 2016-03-01 08:34:54 --> Helper loaded: form_helper
INFO - 2016-03-01 08:34:54 --> Database Driver Class Initialized
INFO - 2016-03-01 08:34:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:34:55 --> Controller Class Initialized
INFO - 2016-03-01 08:34:55 --> Model Class Initialized
INFO - 2016-03-01 08:34:55 --> Model Class Initialized
INFO - 2016-03-01 08:34:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:34:55 --> Pagination Class Initialized
INFO - 2016-03-01 08:34:55 --> Helper loaded: text_helper
INFO - 2016-03-01 08:34:55 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:34:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:34:55 --> Final output sent to browser
DEBUG - 2016-03-01 11:34:55 --> Total execution time: 1.1979
INFO - 2016-03-01 08:35:10 --> Config Class Initialized
INFO - 2016-03-01 08:35:10 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:35:10 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:35:10 --> Utf8 Class Initialized
INFO - 2016-03-01 08:35:10 --> URI Class Initialized
INFO - 2016-03-01 08:35:10 --> Router Class Initialized
INFO - 2016-03-01 08:35:10 --> Output Class Initialized
INFO - 2016-03-01 08:35:10 --> Security Class Initialized
DEBUG - 2016-03-01 08:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:35:10 --> Input Class Initialized
INFO - 2016-03-01 08:35:10 --> Language Class Initialized
INFO - 2016-03-01 08:35:10 --> Loader Class Initialized
INFO - 2016-03-01 08:35:10 --> Helper loaded: url_helper
INFO - 2016-03-01 08:35:10 --> Helper loaded: file_helper
INFO - 2016-03-01 08:35:10 --> Helper loaded: date_helper
INFO - 2016-03-01 08:35:11 --> Helper loaded: form_helper
INFO - 2016-03-01 08:35:11 --> Database Driver Class Initialized
INFO - 2016-03-01 08:35:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:35:12 --> Controller Class Initialized
INFO - 2016-03-01 08:35:12 --> Model Class Initialized
INFO - 2016-03-01 08:35:12 --> Model Class Initialized
INFO - 2016-03-01 08:35:12 --> Form Validation Class Initialized
INFO - 2016-03-01 08:35:12 --> Helper loaded: text_helper
INFO - 2016-03-01 08:35:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:35:12 --> Final output sent to browser
DEBUG - 2016-03-01 08:35:12 --> Total execution time: 1.1967
INFO - 2016-03-01 08:36:54 --> Config Class Initialized
INFO - 2016-03-01 08:36:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:36:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:36:54 --> Utf8 Class Initialized
INFO - 2016-03-01 08:36:54 --> URI Class Initialized
DEBUG - 2016-03-01 08:36:54 --> No URI present. Default controller set.
INFO - 2016-03-01 08:36:54 --> Router Class Initialized
INFO - 2016-03-01 08:36:54 --> Output Class Initialized
INFO - 2016-03-01 08:36:54 --> Security Class Initialized
DEBUG - 2016-03-01 08:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:36:54 --> Input Class Initialized
INFO - 2016-03-01 08:36:54 --> Language Class Initialized
INFO - 2016-03-01 08:36:54 --> Loader Class Initialized
INFO - 2016-03-01 08:36:54 --> Helper loaded: url_helper
INFO - 2016-03-01 08:36:54 --> Helper loaded: file_helper
INFO - 2016-03-01 08:36:54 --> Helper loaded: date_helper
INFO - 2016-03-01 08:36:54 --> Helper loaded: form_helper
INFO - 2016-03-01 08:36:54 --> Database Driver Class Initialized
INFO - 2016-03-01 08:36:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:36:55 --> Controller Class Initialized
INFO - 2016-03-01 08:36:55 --> Model Class Initialized
INFO - 2016-03-01 08:36:55 --> Model Class Initialized
INFO - 2016-03-01 08:36:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:36:55 --> Pagination Class Initialized
INFO - 2016-03-01 08:36:55 --> Helper loaded: text_helper
INFO - 2016-03-01 08:36:55 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:36:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:36:55 --> Final output sent to browser
DEBUG - 2016-03-01 11:36:55 --> Total execution time: 1.1630
INFO - 2016-03-01 08:37:02 --> Config Class Initialized
INFO - 2016-03-01 08:37:02 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:37:02 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:37:02 --> Utf8 Class Initialized
INFO - 2016-03-01 08:37:02 --> URI Class Initialized
INFO - 2016-03-01 08:37:02 --> Router Class Initialized
INFO - 2016-03-01 08:37:02 --> Output Class Initialized
INFO - 2016-03-01 08:37:02 --> Security Class Initialized
DEBUG - 2016-03-01 08:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:37:02 --> Input Class Initialized
INFO - 2016-03-01 08:37:02 --> Language Class Initialized
INFO - 2016-03-01 08:37:02 --> Loader Class Initialized
INFO - 2016-03-01 08:37:02 --> Helper loaded: url_helper
INFO - 2016-03-01 08:37:02 --> Helper loaded: file_helper
INFO - 2016-03-01 08:37:02 --> Helper loaded: date_helper
INFO - 2016-03-01 08:37:02 --> Helper loaded: form_helper
INFO - 2016-03-01 08:37:02 --> Database Driver Class Initialized
INFO - 2016-03-01 08:37:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:37:03 --> Controller Class Initialized
INFO - 2016-03-01 08:37:03 --> Model Class Initialized
INFO - 2016-03-01 08:37:03 --> Model Class Initialized
INFO - 2016-03-01 08:37:03 --> Form Validation Class Initialized
INFO - 2016-03-01 08:37:03 --> Helper loaded: text_helper
INFO - 2016-03-01 08:37:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:37:03 --> Final output sent to browser
DEBUG - 2016-03-01 08:37:03 --> Total execution time: 1.1219
INFO - 2016-03-01 08:37:15 --> Config Class Initialized
INFO - 2016-03-01 08:37:15 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:37:15 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:37:15 --> Utf8 Class Initialized
INFO - 2016-03-01 08:37:15 --> URI Class Initialized
DEBUG - 2016-03-01 08:37:15 --> No URI present. Default controller set.
INFO - 2016-03-01 08:37:15 --> Router Class Initialized
INFO - 2016-03-01 08:37:15 --> Output Class Initialized
INFO - 2016-03-01 08:37:15 --> Security Class Initialized
DEBUG - 2016-03-01 08:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:37:15 --> Input Class Initialized
INFO - 2016-03-01 08:37:15 --> Language Class Initialized
INFO - 2016-03-01 08:37:15 --> Loader Class Initialized
INFO - 2016-03-01 08:37:15 --> Helper loaded: url_helper
INFO - 2016-03-01 08:37:15 --> Helper loaded: file_helper
INFO - 2016-03-01 08:37:15 --> Helper loaded: date_helper
INFO - 2016-03-01 08:37:15 --> Helper loaded: form_helper
INFO - 2016-03-01 08:37:15 --> Database Driver Class Initialized
INFO - 2016-03-01 08:37:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:37:16 --> Controller Class Initialized
INFO - 2016-03-01 08:37:16 --> Model Class Initialized
INFO - 2016-03-01 08:37:16 --> Model Class Initialized
INFO - 2016-03-01 08:37:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:37:16 --> Pagination Class Initialized
INFO - 2016-03-01 08:37:16 --> Helper loaded: text_helper
INFO - 2016-03-01 08:37:16 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:37:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:37:16 --> Final output sent to browser
DEBUG - 2016-03-01 11:37:16 --> Total execution time: 1.1567
INFO - 2016-03-01 08:37:23 --> Config Class Initialized
INFO - 2016-03-01 08:37:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:37:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:37:23 --> Utf8 Class Initialized
INFO - 2016-03-01 08:37:23 --> URI Class Initialized
INFO - 2016-03-01 08:37:23 --> Router Class Initialized
INFO - 2016-03-01 08:37:23 --> Output Class Initialized
INFO - 2016-03-01 08:37:23 --> Security Class Initialized
DEBUG - 2016-03-01 08:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:37:23 --> Input Class Initialized
INFO - 2016-03-01 08:37:23 --> Language Class Initialized
INFO - 2016-03-01 08:37:23 --> Loader Class Initialized
INFO - 2016-03-01 08:37:23 --> Helper loaded: url_helper
INFO - 2016-03-01 08:37:23 --> Helper loaded: file_helper
INFO - 2016-03-01 08:37:23 --> Helper loaded: date_helper
INFO - 2016-03-01 08:37:23 --> Helper loaded: form_helper
INFO - 2016-03-01 08:37:23 --> Database Driver Class Initialized
INFO - 2016-03-01 08:37:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:37:25 --> Controller Class Initialized
INFO - 2016-03-01 08:37:25 --> Model Class Initialized
INFO - 2016-03-01 08:37:25 --> Model Class Initialized
INFO - 2016-03-01 08:37:25 --> Form Validation Class Initialized
INFO - 2016-03-01 08:37:25 --> Helper loaded: text_helper
INFO - 2016-03-01 08:37:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:37:25 --> Final output sent to browser
DEBUG - 2016-03-01 08:37:25 --> Total execution time: 1.1282
INFO - 2016-03-01 08:38:00 --> Config Class Initialized
INFO - 2016-03-01 08:38:00 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:38:00 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:38:00 --> Utf8 Class Initialized
INFO - 2016-03-01 08:38:00 --> URI Class Initialized
DEBUG - 2016-03-01 08:38:00 --> No URI present. Default controller set.
INFO - 2016-03-01 08:38:00 --> Router Class Initialized
INFO - 2016-03-01 08:38:00 --> Output Class Initialized
INFO - 2016-03-01 08:38:00 --> Security Class Initialized
DEBUG - 2016-03-01 08:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:38:00 --> Input Class Initialized
INFO - 2016-03-01 08:38:00 --> Language Class Initialized
INFO - 2016-03-01 08:38:00 --> Loader Class Initialized
INFO - 2016-03-01 08:38:00 --> Helper loaded: url_helper
INFO - 2016-03-01 08:38:00 --> Helper loaded: file_helper
INFO - 2016-03-01 08:38:00 --> Helper loaded: date_helper
INFO - 2016-03-01 08:38:00 --> Helper loaded: form_helper
INFO - 2016-03-01 08:38:00 --> Database Driver Class Initialized
INFO - 2016-03-01 08:38:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:38:01 --> Controller Class Initialized
INFO - 2016-03-01 08:38:01 --> Model Class Initialized
INFO - 2016-03-01 08:38:01 --> Model Class Initialized
INFO - 2016-03-01 08:38:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:38:01 --> Pagination Class Initialized
INFO - 2016-03-01 08:38:01 --> Helper loaded: text_helper
INFO - 2016-03-01 08:38:01 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:38:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:38:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:38:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:38:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:38:01 --> Final output sent to browser
DEBUG - 2016-03-01 11:38:01 --> Total execution time: 1.1229
INFO - 2016-03-01 08:38:07 --> Config Class Initialized
INFO - 2016-03-01 08:38:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:38:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:38:07 --> Utf8 Class Initialized
INFO - 2016-03-01 08:38:07 --> URI Class Initialized
INFO - 2016-03-01 08:38:07 --> Router Class Initialized
INFO - 2016-03-01 08:38:07 --> Output Class Initialized
INFO - 2016-03-01 08:38:07 --> Security Class Initialized
DEBUG - 2016-03-01 08:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:38:07 --> Input Class Initialized
INFO - 2016-03-01 08:38:07 --> Language Class Initialized
INFO - 2016-03-01 08:38:07 --> Loader Class Initialized
INFO - 2016-03-01 08:38:07 --> Helper loaded: url_helper
INFO - 2016-03-01 08:38:07 --> Helper loaded: file_helper
INFO - 2016-03-01 08:38:07 --> Helper loaded: date_helper
INFO - 2016-03-01 08:38:07 --> Helper loaded: form_helper
INFO - 2016-03-01 08:38:07 --> Database Driver Class Initialized
INFO - 2016-03-01 08:38:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:38:08 --> Controller Class Initialized
INFO - 2016-03-01 08:38:08 --> Model Class Initialized
INFO - 2016-03-01 08:38:08 --> Model Class Initialized
INFO - 2016-03-01 08:38:08 --> Form Validation Class Initialized
INFO - 2016-03-01 08:38:08 --> Helper loaded: text_helper
INFO - 2016-03-01 08:38:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:38:08 --> Final output sent to browser
DEBUG - 2016-03-01 08:38:08 --> Total execution time: 1.1509
INFO - 2016-03-01 08:39:42 --> Config Class Initialized
INFO - 2016-03-01 08:39:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:39:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:39:42 --> Utf8 Class Initialized
INFO - 2016-03-01 08:39:42 --> URI Class Initialized
DEBUG - 2016-03-01 08:39:42 --> No URI present. Default controller set.
INFO - 2016-03-01 08:39:42 --> Router Class Initialized
INFO - 2016-03-01 08:39:42 --> Output Class Initialized
INFO - 2016-03-01 08:39:42 --> Security Class Initialized
DEBUG - 2016-03-01 08:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:39:42 --> Input Class Initialized
INFO - 2016-03-01 08:39:42 --> Language Class Initialized
INFO - 2016-03-01 08:39:42 --> Loader Class Initialized
INFO - 2016-03-01 08:39:42 --> Helper loaded: url_helper
INFO - 2016-03-01 08:39:42 --> Helper loaded: file_helper
INFO - 2016-03-01 08:39:42 --> Helper loaded: date_helper
INFO - 2016-03-01 08:39:42 --> Helper loaded: form_helper
INFO - 2016-03-01 08:39:42 --> Database Driver Class Initialized
INFO - 2016-03-01 08:39:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:39:43 --> Controller Class Initialized
INFO - 2016-03-01 08:39:43 --> Model Class Initialized
INFO - 2016-03-01 08:39:43 --> Model Class Initialized
INFO - 2016-03-01 08:39:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:39:43 --> Pagination Class Initialized
INFO - 2016-03-01 08:39:43 --> Helper loaded: text_helper
INFO - 2016-03-01 08:39:43 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:39:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:39:43 --> Final output sent to browser
DEBUG - 2016-03-01 11:39:43 --> Total execution time: 1.1597
INFO - 2016-03-01 08:39:49 --> Config Class Initialized
INFO - 2016-03-01 08:39:49 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:39:49 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:39:49 --> Utf8 Class Initialized
INFO - 2016-03-01 08:39:49 --> URI Class Initialized
INFO - 2016-03-01 08:39:49 --> Router Class Initialized
INFO - 2016-03-01 08:39:49 --> Output Class Initialized
INFO - 2016-03-01 08:39:49 --> Security Class Initialized
DEBUG - 2016-03-01 08:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:39:49 --> Input Class Initialized
INFO - 2016-03-01 08:39:49 --> Language Class Initialized
INFO - 2016-03-01 08:39:49 --> Loader Class Initialized
INFO - 2016-03-01 08:39:49 --> Helper loaded: url_helper
INFO - 2016-03-01 08:39:49 --> Helper loaded: file_helper
INFO - 2016-03-01 08:39:49 --> Helper loaded: date_helper
INFO - 2016-03-01 08:39:49 --> Helper loaded: form_helper
INFO - 2016-03-01 08:39:49 --> Database Driver Class Initialized
INFO - 2016-03-01 08:39:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:39:50 --> Controller Class Initialized
INFO - 2016-03-01 08:39:50 --> Model Class Initialized
INFO - 2016-03-01 08:39:50 --> Model Class Initialized
INFO - 2016-03-01 08:39:50 --> Form Validation Class Initialized
INFO - 2016-03-01 08:39:50 --> Helper loaded: text_helper
INFO - 2016-03-01 08:39:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:39:50 --> Final output sent to browser
DEBUG - 2016-03-01 08:39:50 --> Total execution time: 1.1586
INFO - 2016-03-01 08:39:59 --> Config Class Initialized
INFO - 2016-03-01 08:39:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:39:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:39:59 --> Utf8 Class Initialized
INFO - 2016-03-01 08:39:59 --> URI Class Initialized
DEBUG - 2016-03-01 08:39:59 --> No URI present. Default controller set.
INFO - 2016-03-01 08:39:59 --> Router Class Initialized
INFO - 2016-03-01 08:39:59 --> Output Class Initialized
INFO - 2016-03-01 08:39:59 --> Security Class Initialized
DEBUG - 2016-03-01 08:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:39:59 --> Input Class Initialized
INFO - 2016-03-01 08:39:59 --> Language Class Initialized
INFO - 2016-03-01 08:39:59 --> Loader Class Initialized
INFO - 2016-03-01 08:39:59 --> Helper loaded: url_helper
INFO - 2016-03-01 08:39:59 --> Helper loaded: file_helper
INFO - 2016-03-01 08:39:59 --> Helper loaded: date_helper
INFO - 2016-03-01 08:39:59 --> Helper loaded: form_helper
INFO - 2016-03-01 08:39:59 --> Database Driver Class Initialized
INFO - 2016-03-01 08:40:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:40:00 --> Controller Class Initialized
INFO - 2016-03-01 08:40:00 --> Model Class Initialized
INFO - 2016-03-01 08:40:00 --> Model Class Initialized
INFO - 2016-03-01 08:40:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:40:00 --> Pagination Class Initialized
INFO - 2016-03-01 08:40:00 --> Helper loaded: text_helper
INFO - 2016-03-01 08:40:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:40:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:40:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:40:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:40:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:40:00 --> Final output sent to browser
DEBUG - 2016-03-01 11:40:00 --> Total execution time: 1.1778
INFO - 2016-03-01 08:40:07 --> Config Class Initialized
INFO - 2016-03-01 08:40:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:40:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:40:07 --> Utf8 Class Initialized
INFO - 2016-03-01 08:40:07 --> URI Class Initialized
INFO - 2016-03-01 08:40:07 --> Router Class Initialized
INFO - 2016-03-01 08:40:07 --> Output Class Initialized
INFO - 2016-03-01 08:40:07 --> Security Class Initialized
DEBUG - 2016-03-01 08:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:40:07 --> Input Class Initialized
INFO - 2016-03-01 08:40:07 --> Language Class Initialized
INFO - 2016-03-01 08:40:07 --> Loader Class Initialized
INFO - 2016-03-01 08:40:07 --> Helper loaded: url_helper
INFO - 2016-03-01 08:40:07 --> Helper loaded: file_helper
INFO - 2016-03-01 08:40:07 --> Helper loaded: date_helper
INFO - 2016-03-01 08:40:07 --> Helper loaded: form_helper
INFO - 2016-03-01 08:40:07 --> Database Driver Class Initialized
INFO - 2016-03-01 08:40:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:40:08 --> Controller Class Initialized
INFO - 2016-03-01 08:40:08 --> Model Class Initialized
INFO - 2016-03-01 08:40:08 --> Model Class Initialized
INFO - 2016-03-01 08:40:08 --> Form Validation Class Initialized
INFO - 2016-03-01 08:40:08 --> Helper loaded: text_helper
INFO - 2016-03-01 08:40:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:40:08 --> Final output sent to browser
DEBUG - 2016-03-01 08:40:08 --> Total execution time: 1.1446
INFO - 2016-03-01 08:46:45 --> Config Class Initialized
INFO - 2016-03-01 08:46:45 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:46:45 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:46:45 --> Utf8 Class Initialized
INFO - 2016-03-01 08:46:45 --> URI Class Initialized
DEBUG - 2016-03-01 08:46:45 --> No URI present. Default controller set.
INFO - 2016-03-01 08:46:45 --> Router Class Initialized
INFO - 2016-03-01 08:46:45 --> Output Class Initialized
INFO - 2016-03-01 08:46:45 --> Security Class Initialized
DEBUG - 2016-03-01 08:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:46:45 --> Input Class Initialized
INFO - 2016-03-01 08:46:45 --> Language Class Initialized
INFO - 2016-03-01 08:46:45 --> Loader Class Initialized
INFO - 2016-03-01 08:46:45 --> Helper loaded: url_helper
INFO - 2016-03-01 08:46:45 --> Helper loaded: file_helper
INFO - 2016-03-01 08:46:45 --> Helper loaded: date_helper
INFO - 2016-03-01 08:46:45 --> Helper loaded: form_helper
INFO - 2016-03-01 08:46:45 --> Database Driver Class Initialized
INFO - 2016-03-01 08:46:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:46:46 --> Controller Class Initialized
INFO - 2016-03-01 08:46:46 --> Model Class Initialized
INFO - 2016-03-01 08:46:46 --> Model Class Initialized
INFO - 2016-03-01 08:46:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:46:46 --> Pagination Class Initialized
INFO - 2016-03-01 08:46:46 --> Helper loaded: text_helper
INFO - 2016-03-01 08:46:46 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:46:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:46:46 --> Final output sent to browser
DEBUG - 2016-03-01 11:46:46 --> Total execution time: 1.1479
INFO - 2016-03-01 08:46:53 --> Config Class Initialized
INFO - 2016-03-01 08:46:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:46:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:46:53 --> Utf8 Class Initialized
INFO - 2016-03-01 08:46:53 --> URI Class Initialized
INFO - 2016-03-01 08:46:53 --> Router Class Initialized
INFO - 2016-03-01 08:46:53 --> Output Class Initialized
INFO - 2016-03-01 08:46:53 --> Security Class Initialized
DEBUG - 2016-03-01 08:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:46:53 --> Input Class Initialized
INFO - 2016-03-01 08:46:53 --> Language Class Initialized
INFO - 2016-03-01 08:46:53 --> Loader Class Initialized
INFO - 2016-03-01 08:46:53 --> Helper loaded: url_helper
INFO - 2016-03-01 08:46:53 --> Helper loaded: file_helper
INFO - 2016-03-01 08:46:53 --> Helper loaded: date_helper
INFO - 2016-03-01 08:46:53 --> Helper loaded: form_helper
INFO - 2016-03-01 08:46:53 --> Database Driver Class Initialized
INFO - 2016-03-01 08:46:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:46:54 --> Controller Class Initialized
INFO - 2016-03-01 08:46:54 --> Model Class Initialized
INFO - 2016-03-01 08:46:54 --> Model Class Initialized
INFO - 2016-03-01 08:46:54 --> Form Validation Class Initialized
INFO - 2016-03-01 08:46:54 --> Helper loaded: text_helper
INFO - 2016-03-01 08:46:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:46:54 --> Final output sent to browser
DEBUG - 2016-03-01 08:46:54 --> Total execution time: 1.1197
INFO - 2016-03-01 08:48:22 --> Config Class Initialized
INFO - 2016-03-01 08:48:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:48:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:48:22 --> Utf8 Class Initialized
INFO - 2016-03-01 08:48:22 --> URI Class Initialized
INFO - 2016-03-01 08:48:22 --> Router Class Initialized
INFO - 2016-03-01 08:48:22 --> Output Class Initialized
INFO - 2016-03-01 08:48:22 --> Security Class Initialized
DEBUG - 2016-03-01 08:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:48:22 --> Input Class Initialized
INFO - 2016-03-01 08:48:22 --> Language Class Initialized
INFO - 2016-03-01 08:48:22 --> Loader Class Initialized
INFO - 2016-03-01 08:48:22 --> Helper loaded: url_helper
INFO - 2016-03-01 08:48:22 --> Helper loaded: file_helper
INFO - 2016-03-01 08:48:22 --> Helper loaded: date_helper
INFO - 2016-03-01 08:48:22 --> Helper loaded: form_helper
INFO - 2016-03-01 08:48:22 --> Database Driver Class Initialized
INFO - 2016-03-01 08:48:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:48:23 --> Controller Class Initialized
INFO - 2016-03-01 08:48:23 --> Model Class Initialized
INFO - 2016-03-01 08:48:23 --> Model Class Initialized
INFO - 2016-03-01 08:48:23 --> Form Validation Class Initialized
INFO - 2016-03-01 08:48:23 --> Helper loaded: text_helper
INFO - 2016-03-01 08:48:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:48:23 --> Final output sent to browser
DEBUG - 2016-03-01 08:48:23 --> Total execution time: 1.1244
INFO - 2016-03-01 08:50:33 --> Config Class Initialized
INFO - 2016-03-01 08:50:33 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:50:33 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:50:33 --> Utf8 Class Initialized
INFO - 2016-03-01 08:50:33 --> URI Class Initialized
DEBUG - 2016-03-01 08:50:33 --> No URI present. Default controller set.
INFO - 2016-03-01 08:50:33 --> Router Class Initialized
INFO - 2016-03-01 08:50:33 --> Output Class Initialized
INFO - 2016-03-01 08:50:33 --> Security Class Initialized
DEBUG - 2016-03-01 08:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:50:33 --> Input Class Initialized
INFO - 2016-03-01 08:50:33 --> Language Class Initialized
INFO - 2016-03-01 08:50:33 --> Loader Class Initialized
INFO - 2016-03-01 08:50:33 --> Helper loaded: url_helper
INFO - 2016-03-01 08:50:33 --> Helper loaded: file_helper
INFO - 2016-03-01 08:50:33 --> Helper loaded: date_helper
INFO - 2016-03-01 08:50:33 --> Helper loaded: form_helper
INFO - 2016-03-01 08:50:33 --> Database Driver Class Initialized
INFO - 2016-03-01 08:50:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:50:34 --> Controller Class Initialized
INFO - 2016-03-01 08:50:34 --> Model Class Initialized
INFO - 2016-03-01 08:50:34 --> Model Class Initialized
INFO - 2016-03-01 08:50:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:50:34 --> Pagination Class Initialized
INFO - 2016-03-01 08:50:34 --> Helper loaded: text_helper
INFO - 2016-03-01 08:50:34 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:50:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:50:34 --> Final output sent to browser
DEBUG - 2016-03-01 11:50:34 --> Total execution time: 1.1820
INFO - 2016-03-01 08:50:41 --> Config Class Initialized
INFO - 2016-03-01 08:50:41 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:50:41 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:50:41 --> Utf8 Class Initialized
INFO - 2016-03-01 08:50:41 --> URI Class Initialized
INFO - 2016-03-01 08:50:41 --> Router Class Initialized
INFO - 2016-03-01 08:50:41 --> Output Class Initialized
INFO - 2016-03-01 08:50:41 --> Security Class Initialized
DEBUG - 2016-03-01 08:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:50:41 --> Input Class Initialized
INFO - 2016-03-01 08:50:41 --> Language Class Initialized
INFO - 2016-03-01 08:50:41 --> Loader Class Initialized
INFO - 2016-03-01 08:50:41 --> Helper loaded: url_helper
INFO - 2016-03-01 08:50:41 --> Helper loaded: file_helper
INFO - 2016-03-01 08:50:41 --> Helper loaded: date_helper
INFO - 2016-03-01 08:50:41 --> Helper loaded: form_helper
INFO - 2016-03-01 08:50:41 --> Database Driver Class Initialized
INFO - 2016-03-01 08:50:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:50:42 --> Controller Class Initialized
INFO - 2016-03-01 08:50:42 --> Model Class Initialized
INFO - 2016-03-01 08:50:42 --> Model Class Initialized
INFO - 2016-03-01 08:50:42 --> Form Validation Class Initialized
INFO - 2016-03-01 08:50:42 --> Helper loaded: text_helper
INFO - 2016-03-01 08:50:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:50:42 --> Final output sent to browser
DEBUG - 2016-03-01 08:50:42 --> Total execution time: 1.1312
INFO - 2016-03-01 08:50:50 --> Config Class Initialized
INFO - 2016-03-01 08:50:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:50:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:50:50 --> Utf8 Class Initialized
INFO - 2016-03-01 08:50:50 --> URI Class Initialized
DEBUG - 2016-03-01 08:50:50 --> No URI present. Default controller set.
INFO - 2016-03-01 08:50:50 --> Router Class Initialized
INFO - 2016-03-01 08:50:50 --> Output Class Initialized
INFO - 2016-03-01 08:50:50 --> Security Class Initialized
DEBUG - 2016-03-01 08:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:50:50 --> Input Class Initialized
INFO - 2016-03-01 08:50:50 --> Language Class Initialized
INFO - 2016-03-01 08:50:50 --> Loader Class Initialized
INFO - 2016-03-01 08:50:50 --> Helper loaded: url_helper
INFO - 2016-03-01 08:50:50 --> Helper loaded: file_helper
INFO - 2016-03-01 08:50:50 --> Helper loaded: date_helper
INFO - 2016-03-01 08:50:50 --> Helper loaded: form_helper
INFO - 2016-03-01 08:50:50 --> Database Driver Class Initialized
INFO - 2016-03-01 08:50:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:50:51 --> Controller Class Initialized
INFO - 2016-03-01 08:50:51 --> Model Class Initialized
INFO - 2016-03-01 08:50:51 --> Model Class Initialized
INFO - 2016-03-01 08:50:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:50:51 --> Pagination Class Initialized
INFO - 2016-03-01 08:50:51 --> Helper loaded: text_helper
INFO - 2016-03-01 08:50:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:50:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:50:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:50:52 --> Final output sent to browser
DEBUG - 2016-03-01 11:50:52 --> Total execution time: 1.1535
INFO - 2016-03-01 08:50:59 --> Config Class Initialized
INFO - 2016-03-01 08:50:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:50:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:50:59 --> Utf8 Class Initialized
INFO - 2016-03-01 08:50:59 --> URI Class Initialized
INFO - 2016-03-01 08:50:59 --> Router Class Initialized
INFO - 2016-03-01 08:50:59 --> Output Class Initialized
INFO - 2016-03-01 08:50:59 --> Security Class Initialized
DEBUG - 2016-03-01 08:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:50:59 --> Input Class Initialized
INFO - 2016-03-01 08:50:59 --> Language Class Initialized
INFO - 2016-03-01 08:50:59 --> Loader Class Initialized
INFO - 2016-03-01 08:50:59 --> Helper loaded: url_helper
INFO - 2016-03-01 08:50:59 --> Helper loaded: file_helper
INFO - 2016-03-01 08:50:59 --> Helper loaded: date_helper
INFO - 2016-03-01 08:50:59 --> Helper loaded: form_helper
INFO - 2016-03-01 08:50:59 --> Database Driver Class Initialized
INFO - 2016-03-01 08:51:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:51:00 --> Controller Class Initialized
INFO - 2016-03-01 08:51:00 --> Model Class Initialized
INFO - 2016-03-01 08:51:00 --> Model Class Initialized
INFO - 2016-03-01 08:51:00 --> Form Validation Class Initialized
INFO - 2016-03-01 08:51:00 --> Helper loaded: text_helper
INFO - 2016-03-01 08:51:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:51:00 --> Final output sent to browser
DEBUG - 2016-03-01 08:51:00 --> Total execution time: 1.1506
INFO - 2016-03-01 08:51:17 --> Config Class Initialized
INFO - 2016-03-01 08:51:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:51:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:51:17 --> Utf8 Class Initialized
INFO - 2016-03-01 08:51:17 --> URI Class Initialized
INFO - 2016-03-01 08:51:17 --> Router Class Initialized
INFO - 2016-03-01 08:51:17 --> Output Class Initialized
INFO - 2016-03-01 08:51:17 --> Security Class Initialized
DEBUG - 2016-03-01 08:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:51:17 --> Input Class Initialized
INFO - 2016-03-01 08:51:17 --> Language Class Initialized
INFO - 2016-03-01 08:51:17 --> Loader Class Initialized
INFO - 2016-03-01 08:51:17 --> Helper loaded: url_helper
INFO - 2016-03-01 08:51:17 --> Helper loaded: file_helper
INFO - 2016-03-01 08:51:17 --> Helper loaded: date_helper
INFO - 2016-03-01 08:51:17 --> Helper loaded: form_helper
INFO - 2016-03-01 08:51:17 --> Database Driver Class Initialized
INFO - 2016-03-01 08:51:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:51:18 --> Controller Class Initialized
INFO - 2016-03-01 08:51:18 --> Model Class Initialized
INFO - 2016-03-01 08:51:18 --> Model Class Initialized
INFO - 2016-03-01 08:51:18 --> Form Validation Class Initialized
INFO - 2016-03-01 08:51:18 --> Helper loaded: text_helper
INFO - 2016-03-01 08:51:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:51:18 --> Final output sent to browser
DEBUG - 2016-03-01 08:51:18 --> Total execution time: 1.1868
INFO - 2016-03-01 08:53:03 --> Config Class Initialized
INFO - 2016-03-01 08:53:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:53:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:53:03 --> Utf8 Class Initialized
INFO - 2016-03-01 08:53:03 --> URI Class Initialized
DEBUG - 2016-03-01 08:53:03 --> No URI present. Default controller set.
INFO - 2016-03-01 08:53:03 --> Router Class Initialized
INFO - 2016-03-01 08:53:03 --> Output Class Initialized
INFO - 2016-03-01 08:53:03 --> Security Class Initialized
DEBUG - 2016-03-01 08:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:53:03 --> Input Class Initialized
INFO - 2016-03-01 08:53:03 --> Language Class Initialized
INFO - 2016-03-01 08:53:03 --> Loader Class Initialized
INFO - 2016-03-01 08:53:03 --> Helper loaded: url_helper
INFO - 2016-03-01 08:53:03 --> Helper loaded: file_helper
INFO - 2016-03-01 08:53:03 --> Helper loaded: date_helper
INFO - 2016-03-01 08:53:03 --> Helper loaded: form_helper
INFO - 2016-03-01 08:53:03 --> Database Driver Class Initialized
INFO - 2016-03-01 08:53:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:53:04 --> Controller Class Initialized
INFO - 2016-03-01 08:53:04 --> Model Class Initialized
INFO - 2016-03-01 08:53:04 --> Model Class Initialized
INFO - 2016-03-01 08:53:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:53:04 --> Pagination Class Initialized
INFO - 2016-03-01 08:53:04 --> Helper loaded: text_helper
INFO - 2016-03-01 08:53:04 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:53:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:53:04 --> Final output sent to browser
DEBUG - 2016-03-01 11:53:04 --> Total execution time: 1.1486
INFO - 2016-03-01 08:53:11 --> Config Class Initialized
INFO - 2016-03-01 08:53:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:53:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:53:11 --> Utf8 Class Initialized
INFO - 2016-03-01 08:53:11 --> URI Class Initialized
INFO - 2016-03-01 08:53:11 --> Router Class Initialized
INFO - 2016-03-01 08:53:11 --> Output Class Initialized
INFO - 2016-03-01 08:53:11 --> Security Class Initialized
DEBUG - 2016-03-01 08:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:53:11 --> Input Class Initialized
INFO - 2016-03-01 08:53:11 --> Language Class Initialized
INFO - 2016-03-01 08:53:11 --> Loader Class Initialized
INFO - 2016-03-01 08:53:11 --> Helper loaded: url_helper
INFO - 2016-03-01 08:53:11 --> Helper loaded: file_helper
INFO - 2016-03-01 08:53:11 --> Helper loaded: date_helper
INFO - 2016-03-01 08:53:11 --> Helper loaded: form_helper
INFO - 2016-03-01 08:53:11 --> Database Driver Class Initialized
INFO - 2016-03-01 08:53:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:53:12 --> Controller Class Initialized
INFO - 2016-03-01 08:53:12 --> Model Class Initialized
INFO - 2016-03-01 08:53:12 --> Model Class Initialized
INFO - 2016-03-01 08:53:12 --> Form Validation Class Initialized
INFO - 2016-03-01 08:53:12 --> Helper loaded: text_helper
INFO - 2016-03-01 08:53:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:53:12 --> Final output sent to browser
DEBUG - 2016-03-01 08:53:12 --> Total execution time: 1.1355
INFO - 2016-03-01 08:53:46 --> Config Class Initialized
INFO - 2016-03-01 08:53:46 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:53:46 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:53:46 --> Utf8 Class Initialized
INFO - 2016-03-01 08:53:46 --> URI Class Initialized
DEBUG - 2016-03-01 08:53:46 --> No URI present. Default controller set.
INFO - 2016-03-01 08:53:46 --> Router Class Initialized
INFO - 2016-03-01 08:53:46 --> Output Class Initialized
INFO - 2016-03-01 08:53:46 --> Security Class Initialized
DEBUG - 2016-03-01 08:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:53:46 --> Input Class Initialized
INFO - 2016-03-01 08:53:46 --> Language Class Initialized
INFO - 2016-03-01 08:53:46 --> Loader Class Initialized
INFO - 2016-03-01 08:53:46 --> Helper loaded: url_helper
INFO - 2016-03-01 08:53:46 --> Helper loaded: file_helper
INFO - 2016-03-01 08:53:46 --> Helper loaded: date_helper
INFO - 2016-03-01 08:53:46 --> Helper loaded: form_helper
INFO - 2016-03-01 08:53:46 --> Database Driver Class Initialized
INFO - 2016-03-01 08:53:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:53:47 --> Controller Class Initialized
INFO - 2016-03-01 08:53:47 --> Model Class Initialized
INFO - 2016-03-01 08:53:47 --> Model Class Initialized
INFO - 2016-03-01 08:53:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:53:47 --> Pagination Class Initialized
INFO - 2016-03-01 08:53:47 --> Helper loaded: text_helper
INFO - 2016-03-01 08:53:47 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:53:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:53:47 --> Final output sent to browser
DEBUG - 2016-03-01 11:53:47 --> Total execution time: 1.1671
INFO - 2016-03-01 08:53:57 --> Config Class Initialized
INFO - 2016-03-01 08:53:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:53:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:53:57 --> Utf8 Class Initialized
INFO - 2016-03-01 08:53:57 --> URI Class Initialized
INFO - 2016-03-01 08:53:57 --> Router Class Initialized
INFO - 2016-03-01 08:53:57 --> Output Class Initialized
INFO - 2016-03-01 08:53:57 --> Security Class Initialized
DEBUG - 2016-03-01 08:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:53:57 --> Input Class Initialized
INFO - 2016-03-01 08:53:57 --> Language Class Initialized
INFO - 2016-03-01 08:53:57 --> Loader Class Initialized
INFO - 2016-03-01 08:53:57 --> Helper loaded: url_helper
INFO - 2016-03-01 08:53:57 --> Helper loaded: file_helper
INFO - 2016-03-01 08:53:57 --> Helper loaded: date_helper
INFO - 2016-03-01 08:53:57 --> Helper loaded: form_helper
INFO - 2016-03-01 08:53:57 --> Database Driver Class Initialized
INFO - 2016-03-01 08:53:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:53:58 --> Controller Class Initialized
INFO - 2016-03-01 08:53:58 --> Model Class Initialized
INFO - 2016-03-01 08:53:58 --> Model Class Initialized
INFO - 2016-03-01 08:53:58 --> Form Validation Class Initialized
INFO - 2016-03-01 08:53:58 --> Helper loaded: text_helper
INFO - 2016-03-01 08:53:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:53:58 --> Final output sent to browser
DEBUG - 2016-03-01 08:53:58 --> Total execution time: 1.1743
INFO - 2016-03-01 08:54:09 --> Config Class Initialized
INFO - 2016-03-01 08:54:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:54:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:54:09 --> Utf8 Class Initialized
INFO - 2016-03-01 08:54:09 --> URI Class Initialized
DEBUG - 2016-03-01 08:54:09 --> No URI present. Default controller set.
INFO - 2016-03-01 08:54:09 --> Router Class Initialized
INFO - 2016-03-01 08:54:09 --> Output Class Initialized
INFO - 2016-03-01 08:54:09 --> Security Class Initialized
DEBUG - 2016-03-01 08:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:54:09 --> Input Class Initialized
INFO - 2016-03-01 08:54:09 --> Language Class Initialized
INFO - 2016-03-01 08:54:09 --> Loader Class Initialized
INFO - 2016-03-01 08:54:09 --> Helper loaded: url_helper
INFO - 2016-03-01 08:54:09 --> Helper loaded: file_helper
INFO - 2016-03-01 08:54:09 --> Helper loaded: date_helper
INFO - 2016-03-01 08:54:09 --> Helper loaded: form_helper
INFO - 2016-03-01 08:54:09 --> Database Driver Class Initialized
INFO - 2016-03-01 08:54:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:54:10 --> Controller Class Initialized
INFO - 2016-03-01 08:54:10 --> Model Class Initialized
INFO - 2016-03-01 08:54:10 --> Model Class Initialized
INFO - 2016-03-01 08:54:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:54:10 --> Pagination Class Initialized
INFO - 2016-03-01 08:54:10 --> Helper loaded: text_helper
INFO - 2016-03-01 08:54:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:54:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:54:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:54:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:54:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:54:11 --> Final output sent to browser
DEBUG - 2016-03-01 11:54:11 --> Total execution time: 1.1963
INFO - 2016-03-01 08:54:17 --> Config Class Initialized
INFO - 2016-03-01 08:54:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:54:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:54:17 --> Utf8 Class Initialized
INFO - 2016-03-01 08:54:17 --> URI Class Initialized
INFO - 2016-03-01 08:54:17 --> Router Class Initialized
INFO - 2016-03-01 08:54:17 --> Output Class Initialized
INFO - 2016-03-01 08:54:17 --> Security Class Initialized
DEBUG - 2016-03-01 08:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:54:17 --> Input Class Initialized
INFO - 2016-03-01 08:54:17 --> Language Class Initialized
INFO - 2016-03-01 08:54:17 --> Loader Class Initialized
INFO - 2016-03-01 08:54:17 --> Helper loaded: url_helper
INFO - 2016-03-01 08:54:17 --> Helper loaded: file_helper
INFO - 2016-03-01 08:54:17 --> Helper loaded: date_helper
INFO - 2016-03-01 08:54:17 --> Helper loaded: form_helper
INFO - 2016-03-01 08:54:17 --> Database Driver Class Initialized
INFO - 2016-03-01 08:54:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:54:18 --> Controller Class Initialized
INFO - 2016-03-01 08:54:18 --> Model Class Initialized
INFO - 2016-03-01 08:54:18 --> Model Class Initialized
INFO - 2016-03-01 08:54:18 --> Form Validation Class Initialized
INFO - 2016-03-01 08:54:18 --> Helper loaded: text_helper
INFO - 2016-03-01 08:54:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:54:18 --> Final output sent to browser
DEBUG - 2016-03-01 08:54:18 --> Total execution time: 1.1151
INFO - 2016-03-01 08:54:30 --> Config Class Initialized
INFO - 2016-03-01 08:54:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:54:30 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:54:30 --> Utf8 Class Initialized
INFO - 2016-03-01 08:54:30 --> URI Class Initialized
DEBUG - 2016-03-01 08:54:30 --> No URI present. Default controller set.
INFO - 2016-03-01 08:54:30 --> Router Class Initialized
INFO - 2016-03-01 08:54:30 --> Output Class Initialized
INFO - 2016-03-01 08:54:30 --> Security Class Initialized
DEBUG - 2016-03-01 08:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:54:30 --> Input Class Initialized
INFO - 2016-03-01 08:54:30 --> Language Class Initialized
INFO - 2016-03-01 08:54:30 --> Loader Class Initialized
INFO - 2016-03-01 08:54:30 --> Helper loaded: url_helper
INFO - 2016-03-01 08:54:30 --> Helper loaded: file_helper
INFO - 2016-03-01 08:54:30 --> Helper loaded: date_helper
INFO - 2016-03-01 08:54:30 --> Helper loaded: form_helper
INFO - 2016-03-01 08:54:30 --> Database Driver Class Initialized
INFO - 2016-03-01 08:54:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:54:31 --> Controller Class Initialized
INFO - 2016-03-01 08:54:31 --> Model Class Initialized
INFO - 2016-03-01 08:54:31 --> Model Class Initialized
INFO - 2016-03-01 08:54:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:54:31 --> Pagination Class Initialized
INFO - 2016-03-01 08:54:31 --> Helper loaded: text_helper
INFO - 2016-03-01 08:54:31 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:54:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:54:31 --> Final output sent to browser
DEBUG - 2016-03-01 11:54:31 --> Total execution time: 1.1509
INFO - 2016-03-01 08:54:38 --> Config Class Initialized
INFO - 2016-03-01 08:54:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:54:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:54:38 --> Utf8 Class Initialized
INFO - 2016-03-01 08:54:38 --> URI Class Initialized
INFO - 2016-03-01 08:54:38 --> Router Class Initialized
INFO - 2016-03-01 08:54:38 --> Output Class Initialized
INFO - 2016-03-01 08:54:38 --> Security Class Initialized
DEBUG - 2016-03-01 08:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:54:38 --> Input Class Initialized
INFO - 2016-03-01 08:54:38 --> Language Class Initialized
INFO - 2016-03-01 08:54:38 --> Loader Class Initialized
INFO - 2016-03-01 08:54:38 --> Helper loaded: url_helper
INFO - 2016-03-01 08:54:38 --> Helper loaded: file_helper
INFO - 2016-03-01 08:54:38 --> Helper loaded: date_helper
INFO - 2016-03-01 08:54:38 --> Helper loaded: form_helper
INFO - 2016-03-01 08:54:38 --> Database Driver Class Initialized
INFO - 2016-03-01 08:54:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:54:39 --> Controller Class Initialized
INFO - 2016-03-01 08:54:39 --> Model Class Initialized
INFO - 2016-03-01 08:54:39 --> Model Class Initialized
INFO - 2016-03-01 08:54:39 --> Form Validation Class Initialized
INFO - 2016-03-01 08:54:39 --> Helper loaded: text_helper
INFO - 2016-03-01 08:54:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:54:39 --> Final output sent to browser
DEBUG - 2016-03-01 08:54:39 --> Total execution time: 1.1540
INFO - 2016-03-01 08:55:07 --> Config Class Initialized
INFO - 2016-03-01 08:55:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:55:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:55:07 --> Utf8 Class Initialized
INFO - 2016-03-01 08:55:07 --> URI Class Initialized
INFO - 2016-03-01 08:55:07 --> Router Class Initialized
INFO - 2016-03-01 08:55:07 --> Output Class Initialized
INFO - 2016-03-01 08:55:07 --> Security Class Initialized
DEBUG - 2016-03-01 08:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:55:07 --> Input Class Initialized
INFO - 2016-03-01 08:55:07 --> Language Class Initialized
INFO - 2016-03-01 08:55:07 --> Loader Class Initialized
INFO - 2016-03-01 08:55:07 --> Helper loaded: url_helper
INFO - 2016-03-01 08:55:07 --> Helper loaded: file_helper
INFO - 2016-03-01 08:55:07 --> Helper loaded: date_helper
INFO - 2016-03-01 08:55:07 --> Helper loaded: form_helper
INFO - 2016-03-01 08:55:07 --> Database Driver Class Initialized
INFO - 2016-03-01 08:55:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:55:08 --> Controller Class Initialized
INFO - 2016-03-01 08:55:08 --> Model Class Initialized
INFO - 2016-03-01 08:55:08 --> Model Class Initialized
INFO - 2016-03-01 08:55:08 --> Form Validation Class Initialized
INFO - 2016-03-01 08:55:08 --> Helper loaded: text_helper
INFO - 2016-03-01 08:55:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 08:55:08 --> Final output sent to browser
DEBUG - 2016-03-01 08:55:08 --> Total execution time: 1.2812
INFO - 2016-03-01 08:57:42 --> Config Class Initialized
INFO - 2016-03-01 08:57:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:57:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:57:42 --> Utf8 Class Initialized
INFO - 2016-03-01 08:57:42 --> URI Class Initialized
DEBUG - 2016-03-01 08:57:42 --> No URI present. Default controller set.
INFO - 2016-03-01 08:57:42 --> Router Class Initialized
INFO - 2016-03-01 08:57:42 --> Output Class Initialized
INFO - 2016-03-01 08:57:42 --> Security Class Initialized
DEBUG - 2016-03-01 08:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:57:42 --> Input Class Initialized
INFO - 2016-03-01 08:57:42 --> Language Class Initialized
INFO - 2016-03-01 08:57:42 --> Loader Class Initialized
INFO - 2016-03-01 08:57:42 --> Helper loaded: url_helper
INFO - 2016-03-01 08:57:42 --> Helper loaded: file_helper
INFO - 2016-03-01 08:57:42 --> Helper loaded: date_helper
INFO - 2016-03-01 08:57:42 --> Helper loaded: form_helper
INFO - 2016-03-01 08:57:42 --> Database Driver Class Initialized
INFO - 2016-03-01 08:57:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:57:43 --> Controller Class Initialized
INFO - 2016-03-01 08:57:43 --> Model Class Initialized
INFO - 2016-03-01 08:57:43 --> Model Class Initialized
INFO - 2016-03-01 08:57:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:57:43 --> Pagination Class Initialized
INFO - 2016-03-01 08:57:43 --> Helper loaded: text_helper
INFO - 2016-03-01 08:57:43 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:57:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:57:43 --> Final output sent to browser
DEBUG - 2016-03-01 11:57:43 --> Total execution time: 1.1855
INFO - 2016-03-01 08:57:46 --> Config Class Initialized
INFO - 2016-03-01 08:57:46 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:57:46 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:57:46 --> Utf8 Class Initialized
INFO - 2016-03-01 08:57:46 --> URI Class Initialized
INFO - 2016-03-01 08:57:46 --> Router Class Initialized
INFO - 2016-03-01 08:57:46 --> Output Class Initialized
INFO - 2016-03-01 08:57:46 --> Security Class Initialized
DEBUG - 2016-03-01 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:57:46 --> Input Class Initialized
INFO - 2016-03-01 08:57:46 --> Language Class Initialized
INFO - 2016-03-01 08:57:46 --> Loader Class Initialized
INFO - 2016-03-01 08:57:46 --> Helper loaded: url_helper
INFO - 2016-03-01 08:57:46 --> Helper loaded: file_helper
INFO - 2016-03-01 08:57:46 --> Helper loaded: date_helper
INFO - 2016-03-01 08:57:46 --> Helper loaded: form_helper
INFO - 2016-03-01 08:57:46 --> Database Driver Class Initialized
INFO - 2016-03-01 08:57:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:57:47 --> Controller Class Initialized
INFO - 2016-03-01 08:57:47 --> Model Class Initialized
INFO - 2016-03-01 08:57:47 --> Model Class Initialized
INFO - 2016-03-01 08:57:47 --> Form Validation Class Initialized
INFO - 2016-03-01 08:57:47 --> Helper loaded: text_helper
INFO - 2016-03-01 08:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 08:57:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 08:57:47 --> Final output sent to browser
DEBUG - 2016-03-01 08:57:47 --> Total execution time: 1.1208
INFO - 2016-03-01 08:57:49 --> Config Class Initialized
INFO - 2016-03-01 08:57:49 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:57:49 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:57:49 --> Utf8 Class Initialized
INFO - 2016-03-01 08:57:49 --> URI Class Initialized
DEBUG - 2016-03-01 08:57:49 --> No URI present. Default controller set.
INFO - 2016-03-01 08:57:49 --> Router Class Initialized
INFO - 2016-03-01 08:57:49 --> Output Class Initialized
INFO - 2016-03-01 08:57:49 --> Security Class Initialized
DEBUG - 2016-03-01 08:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:57:49 --> Input Class Initialized
INFO - 2016-03-01 08:57:49 --> Language Class Initialized
INFO - 2016-03-01 08:57:49 --> Loader Class Initialized
INFO - 2016-03-01 08:57:49 --> Helper loaded: url_helper
INFO - 2016-03-01 08:57:49 --> Helper loaded: file_helper
INFO - 2016-03-01 08:57:49 --> Helper loaded: date_helper
INFO - 2016-03-01 08:57:49 --> Helper loaded: form_helper
INFO - 2016-03-01 08:57:49 --> Database Driver Class Initialized
INFO - 2016-03-01 08:57:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:57:50 --> Controller Class Initialized
INFO - 2016-03-01 08:57:50 --> Model Class Initialized
INFO - 2016-03-01 08:57:50 --> Model Class Initialized
INFO - 2016-03-01 08:57:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:57:50 --> Pagination Class Initialized
INFO - 2016-03-01 08:57:50 --> Helper loaded: text_helper
INFO - 2016-03-01 08:57:50 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 11:57:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:57:50 --> Final output sent to browser
DEBUG - 2016-03-01 11:57:50 --> Total execution time: 1.1302
INFO - 2016-03-01 08:57:55 --> Config Class Initialized
INFO - 2016-03-01 08:57:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:57:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:57:55 --> Utf8 Class Initialized
INFO - 2016-03-01 08:57:55 --> URI Class Initialized
INFO - 2016-03-01 08:57:55 --> Router Class Initialized
INFO - 2016-03-01 08:57:55 --> Output Class Initialized
INFO - 2016-03-01 08:57:55 --> Security Class Initialized
DEBUG - 2016-03-01 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:57:55 --> Input Class Initialized
INFO - 2016-03-01 08:57:55 --> Language Class Initialized
INFO - 2016-03-01 08:57:55 --> Loader Class Initialized
INFO - 2016-03-01 08:57:55 --> Helper loaded: url_helper
INFO - 2016-03-01 08:57:55 --> Helper loaded: file_helper
INFO - 2016-03-01 08:57:55 --> Helper loaded: date_helper
INFO - 2016-03-01 08:57:55 --> Helper loaded: form_helper
INFO - 2016-03-01 08:57:55 --> Database Driver Class Initialized
INFO - 2016-03-01 08:57:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:57:56 --> Controller Class Initialized
INFO - 2016-03-01 08:57:56 --> Model Class Initialized
INFO - 2016-03-01 08:57:56 --> Model Class Initialized
INFO - 2016-03-01 08:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:57:56 --> Pagination Class Initialized
INFO - 2016-03-01 08:57:56 --> Helper loaded: text_helper
INFO - 2016-03-01 08:57:56 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 11:57:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:57:56 --> Final output sent to browser
DEBUG - 2016-03-01 11:57:56 --> Total execution time: 1.1213
INFO - 2016-03-01 08:57:58 --> Config Class Initialized
INFO - 2016-03-01 08:57:58 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:57:58 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:57:58 --> Utf8 Class Initialized
INFO - 2016-03-01 08:57:58 --> URI Class Initialized
INFO - 2016-03-01 08:57:58 --> Router Class Initialized
INFO - 2016-03-01 08:57:58 --> Output Class Initialized
INFO - 2016-03-01 08:57:58 --> Security Class Initialized
DEBUG - 2016-03-01 08:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:57:58 --> Input Class Initialized
INFO - 2016-03-01 08:57:58 --> Language Class Initialized
INFO - 2016-03-01 08:57:58 --> Loader Class Initialized
INFO - 2016-03-01 08:57:58 --> Helper loaded: url_helper
INFO - 2016-03-01 08:57:58 --> Helper loaded: file_helper
INFO - 2016-03-01 08:57:58 --> Helper loaded: date_helper
INFO - 2016-03-01 08:57:58 --> Helper loaded: form_helper
INFO - 2016-03-01 08:57:58 --> Database Driver Class Initialized
INFO - 2016-03-01 08:57:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:57:59 --> Controller Class Initialized
INFO - 2016-03-01 08:57:59 --> Model Class Initialized
INFO - 2016-03-01 08:57:59 --> Model Class Initialized
INFO - 2016-03-01 08:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:57:59 --> Pagination Class Initialized
INFO - 2016-03-01 08:57:59 --> Helper loaded: text_helper
INFO - 2016-03-01 08:57:59 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 11:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 11:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:57:59 --> Final output sent to browser
DEBUG - 2016-03-01 11:57:59 --> Total execution time: 1.1672
INFO - 2016-03-01 08:59:06 --> Config Class Initialized
INFO - 2016-03-01 08:59:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:59:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:59:06 --> Utf8 Class Initialized
INFO - 2016-03-01 08:59:06 --> URI Class Initialized
INFO - 2016-03-01 08:59:06 --> Router Class Initialized
INFO - 2016-03-01 08:59:06 --> Output Class Initialized
INFO - 2016-03-01 08:59:06 --> Security Class Initialized
DEBUG - 2016-03-01 08:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:59:06 --> Input Class Initialized
INFO - 2016-03-01 08:59:06 --> Language Class Initialized
INFO - 2016-03-01 08:59:06 --> Loader Class Initialized
INFO - 2016-03-01 08:59:06 --> Helper loaded: url_helper
INFO - 2016-03-01 08:59:06 --> Helper loaded: file_helper
INFO - 2016-03-01 08:59:06 --> Helper loaded: date_helper
INFO - 2016-03-01 08:59:06 --> Helper loaded: form_helper
INFO - 2016-03-01 08:59:06 --> Database Driver Class Initialized
INFO - 2016-03-01 08:59:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:59:07 --> Controller Class Initialized
INFO - 2016-03-01 08:59:07 --> Model Class Initialized
INFO - 2016-03-01 08:59:07 --> Model Class Initialized
INFO - 2016-03-01 08:59:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:59:07 --> Pagination Class Initialized
INFO - 2016-03-01 08:59:07 --> Helper loaded: text_helper
INFO - 2016-03-01 08:59:07 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 11:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 11:59:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 11:59:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:59:08 --> Final output sent to browser
DEBUG - 2016-03-01 11:59:08 --> Total execution time: 1.2464
INFO - 2016-03-01 08:59:41 --> Config Class Initialized
INFO - 2016-03-01 08:59:41 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:59:41 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:59:41 --> Utf8 Class Initialized
INFO - 2016-03-01 08:59:41 --> URI Class Initialized
INFO - 2016-03-01 08:59:41 --> Router Class Initialized
INFO - 2016-03-01 08:59:41 --> Output Class Initialized
INFO - 2016-03-01 08:59:41 --> Security Class Initialized
DEBUG - 2016-03-01 08:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:59:41 --> Input Class Initialized
INFO - 2016-03-01 08:59:41 --> Language Class Initialized
INFO - 2016-03-01 08:59:41 --> Loader Class Initialized
INFO - 2016-03-01 08:59:41 --> Helper loaded: url_helper
INFO - 2016-03-01 08:59:41 --> Helper loaded: file_helper
INFO - 2016-03-01 08:59:41 --> Helper loaded: date_helper
INFO - 2016-03-01 08:59:41 --> Helper loaded: form_helper
INFO - 2016-03-01 08:59:41 --> Database Driver Class Initialized
INFO - 2016-03-01 08:59:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:59:42 --> Controller Class Initialized
INFO - 2016-03-01 08:59:42 --> Model Class Initialized
INFO - 2016-03-01 08:59:42 --> Model Class Initialized
INFO - 2016-03-01 08:59:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:59:42 --> Pagination Class Initialized
INFO - 2016-03-01 08:59:42 --> Helper loaded: text_helper
INFO - 2016-03-01 08:59:42 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:59:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:59:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 11:59:42 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 11:59:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 11:59:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 11:59:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:59:42 --> Final output sent to browser
DEBUG - 2016-03-01 11:59:42 --> Total execution time: 1.1499
INFO - 2016-03-01 08:59:44 --> Config Class Initialized
INFO - 2016-03-01 08:59:44 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:59:44 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:59:44 --> Utf8 Class Initialized
INFO - 2016-03-01 08:59:44 --> URI Class Initialized
INFO - 2016-03-01 08:59:44 --> Router Class Initialized
INFO - 2016-03-01 08:59:44 --> Output Class Initialized
INFO - 2016-03-01 08:59:44 --> Security Class Initialized
DEBUG - 2016-03-01 08:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:59:44 --> Input Class Initialized
INFO - 2016-03-01 08:59:44 --> Language Class Initialized
INFO - 2016-03-01 08:59:44 --> Loader Class Initialized
INFO - 2016-03-01 08:59:44 --> Helper loaded: url_helper
INFO - 2016-03-01 08:59:44 --> Helper loaded: file_helper
INFO - 2016-03-01 08:59:44 --> Helper loaded: date_helper
INFO - 2016-03-01 08:59:44 --> Helper loaded: form_helper
INFO - 2016-03-01 08:59:44 --> Database Driver Class Initialized
INFO - 2016-03-01 08:59:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:59:45 --> Controller Class Initialized
INFO - 2016-03-01 08:59:45 --> Model Class Initialized
INFO - 2016-03-01 08:59:45 --> Model Class Initialized
INFO - 2016-03-01 08:59:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:59:45 --> Pagination Class Initialized
INFO - 2016-03-01 08:59:45 --> Helper loaded: text_helper
INFO - 2016-03-01 08:59:45 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 11:59:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 11:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 11:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 11:59:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:59:45 --> Final output sent to browser
DEBUG - 2016-03-01 11:59:45 --> Total execution time: 1.1389
INFO - 2016-03-01 08:59:49 --> Config Class Initialized
INFO - 2016-03-01 08:59:49 --> Hooks Class Initialized
DEBUG - 2016-03-01 08:59:49 --> UTF-8 Support Enabled
INFO - 2016-03-01 08:59:49 --> Utf8 Class Initialized
INFO - 2016-03-01 08:59:49 --> URI Class Initialized
INFO - 2016-03-01 08:59:50 --> Router Class Initialized
INFO - 2016-03-01 08:59:50 --> Output Class Initialized
INFO - 2016-03-01 08:59:50 --> Security Class Initialized
DEBUG - 2016-03-01 08:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 08:59:50 --> Input Class Initialized
INFO - 2016-03-01 08:59:50 --> Language Class Initialized
INFO - 2016-03-01 08:59:50 --> Loader Class Initialized
INFO - 2016-03-01 08:59:50 --> Helper loaded: url_helper
INFO - 2016-03-01 08:59:50 --> Helper loaded: file_helper
INFO - 2016-03-01 08:59:50 --> Helper loaded: date_helper
INFO - 2016-03-01 08:59:50 --> Helper loaded: form_helper
INFO - 2016-03-01 08:59:50 --> Database Driver Class Initialized
INFO - 2016-03-01 08:59:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 08:59:51 --> Controller Class Initialized
INFO - 2016-03-01 08:59:51 --> Model Class Initialized
INFO - 2016-03-01 08:59:51 --> Model Class Initialized
INFO - 2016-03-01 08:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 08:59:51 --> Pagination Class Initialized
INFO - 2016-03-01 08:59:51 --> Helper loaded: text_helper
INFO - 2016-03-01 08:59:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 11:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 11:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 11:59:51 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 11:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 11:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 11:59:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 11:59:51 --> Final output sent to browser
DEBUG - 2016-03-01 11:59:51 --> Total execution time: 1.1672
INFO - 2016-03-01 09:00:26 --> Config Class Initialized
INFO - 2016-03-01 09:00:26 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:00:26 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:00:26 --> Utf8 Class Initialized
INFO - 2016-03-01 09:00:26 --> URI Class Initialized
INFO - 2016-03-01 09:00:26 --> Router Class Initialized
INFO - 2016-03-01 09:00:26 --> Output Class Initialized
INFO - 2016-03-01 09:00:26 --> Security Class Initialized
DEBUG - 2016-03-01 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:00:26 --> Input Class Initialized
INFO - 2016-03-01 09:00:26 --> Language Class Initialized
INFO - 2016-03-01 09:00:26 --> Loader Class Initialized
INFO - 2016-03-01 09:00:26 --> Helper loaded: url_helper
INFO - 2016-03-01 09:00:26 --> Helper loaded: file_helper
INFO - 2016-03-01 09:00:26 --> Helper loaded: date_helper
INFO - 2016-03-01 09:00:26 --> Helper loaded: form_helper
INFO - 2016-03-01 09:00:26 --> Database Driver Class Initialized
INFO - 2016-03-01 09:00:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:00:27 --> Controller Class Initialized
INFO - 2016-03-01 09:00:27 --> Model Class Initialized
INFO - 2016-03-01 09:00:27 --> Model Class Initialized
INFO - 2016-03-01 09:00:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:00:27 --> Pagination Class Initialized
INFO - 2016-03-01 09:00:27 --> Helper loaded: text_helper
INFO - 2016-03-01 09:00:27 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:00:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:00:27 --> Final output sent to browser
DEBUG - 2016-03-01 12:00:27 --> Total execution time: 1.1504
INFO - 2016-03-01 09:00:57 --> Config Class Initialized
INFO - 2016-03-01 09:00:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:00:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:00:57 --> Utf8 Class Initialized
INFO - 2016-03-01 09:00:57 --> URI Class Initialized
INFO - 2016-03-01 09:00:57 --> Router Class Initialized
INFO - 2016-03-01 09:00:57 --> Output Class Initialized
INFO - 2016-03-01 09:00:57 --> Security Class Initialized
DEBUG - 2016-03-01 09:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:00:57 --> Input Class Initialized
INFO - 2016-03-01 09:00:57 --> Language Class Initialized
INFO - 2016-03-01 09:00:57 --> Loader Class Initialized
INFO - 2016-03-01 09:00:57 --> Helper loaded: url_helper
INFO - 2016-03-01 09:00:57 --> Helper loaded: file_helper
INFO - 2016-03-01 09:00:57 --> Helper loaded: date_helper
INFO - 2016-03-01 09:00:57 --> Helper loaded: form_helper
INFO - 2016-03-01 09:00:57 --> Database Driver Class Initialized
INFO - 2016-03-01 09:00:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:00:58 --> Controller Class Initialized
INFO - 2016-03-01 09:00:58 --> Model Class Initialized
INFO - 2016-03-01 09:00:58 --> Model Class Initialized
INFO - 2016-03-01 09:00:58 --> Form Validation Class Initialized
INFO - 2016-03-01 09:00:58 --> Helper loaded: text_helper
INFO - 2016-03-01 09:00:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:00:58 --> Final output sent to browser
DEBUG - 2016-03-01 09:00:58 --> Total execution time: 1.2239
INFO - 2016-03-01 09:00:59 --> Config Class Initialized
INFO - 2016-03-01 09:00:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:00:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:00:59 --> Utf8 Class Initialized
INFO - 2016-03-01 09:00:59 --> URI Class Initialized
INFO - 2016-03-01 09:00:59 --> Router Class Initialized
INFO - 2016-03-01 09:00:59 --> Output Class Initialized
INFO - 2016-03-01 09:00:59 --> Security Class Initialized
DEBUG - 2016-03-01 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:00:59 --> Input Class Initialized
INFO - 2016-03-01 09:00:59 --> Language Class Initialized
ERROR - 2016-03-01 09:00:59 --> 404 Page Not Found: Localhost/index
INFO - 2016-03-01 09:01:16 --> Config Class Initialized
INFO - 2016-03-01 09:01:16 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:01:16 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:01:16 --> Utf8 Class Initialized
INFO - 2016-03-01 09:01:16 --> URI Class Initialized
INFO - 2016-03-01 09:01:16 --> Router Class Initialized
INFO - 2016-03-01 09:01:16 --> Output Class Initialized
INFO - 2016-03-01 09:01:16 --> Security Class Initialized
DEBUG - 2016-03-01 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:01:16 --> Input Class Initialized
INFO - 2016-03-01 09:01:16 --> Language Class Initialized
ERROR - 2016-03-01 09:01:16 --> 404 Page Not Found: Localhost/index
INFO - 2016-03-01 09:01:25 --> Config Class Initialized
INFO - 2016-03-01 09:01:25 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:01:25 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:01:25 --> Utf8 Class Initialized
INFO - 2016-03-01 09:01:25 --> URI Class Initialized
INFO - 2016-03-01 09:01:25 --> Router Class Initialized
INFO - 2016-03-01 09:01:25 --> Output Class Initialized
INFO - 2016-03-01 09:01:25 --> Security Class Initialized
DEBUG - 2016-03-01 09:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:01:25 --> Input Class Initialized
INFO - 2016-03-01 09:01:25 --> Language Class Initialized
INFO - 2016-03-01 09:01:25 --> Loader Class Initialized
INFO - 2016-03-01 09:01:25 --> Helper loaded: url_helper
INFO - 2016-03-01 09:01:25 --> Helper loaded: file_helper
INFO - 2016-03-01 09:01:25 --> Helper loaded: date_helper
INFO - 2016-03-01 09:01:25 --> Helper loaded: form_helper
INFO - 2016-03-01 09:01:25 --> Database Driver Class Initialized
INFO - 2016-03-01 09:01:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:01:26 --> Controller Class Initialized
INFO - 2016-03-01 09:01:26 --> Model Class Initialized
INFO - 2016-03-01 09:01:26 --> Model Class Initialized
INFO - 2016-03-01 09:01:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:01:26 --> Pagination Class Initialized
INFO - 2016-03-01 09:01:26 --> Helper loaded: text_helper
INFO - 2016-03-01 09:01:26 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:01:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:01:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:01:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:01:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:01:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:01:26 --> Final output sent to browser
DEBUG - 2016-03-01 12:01:26 --> Total execution time: 1.2190
INFO - 2016-03-01 09:01:54 --> Config Class Initialized
INFO - 2016-03-01 09:01:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:01:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:01:54 --> Utf8 Class Initialized
INFO - 2016-03-01 09:01:54 --> URI Class Initialized
INFO - 2016-03-01 09:01:54 --> Router Class Initialized
INFO - 2016-03-01 09:01:54 --> Output Class Initialized
INFO - 2016-03-01 09:01:54 --> Security Class Initialized
DEBUG - 2016-03-01 09:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:01:54 --> Input Class Initialized
INFO - 2016-03-01 09:01:54 --> Language Class Initialized
INFO - 2016-03-01 09:01:54 --> Loader Class Initialized
INFO - 2016-03-01 09:01:54 --> Helper loaded: url_helper
INFO - 2016-03-01 09:01:54 --> Helper loaded: file_helper
INFO - 2016-03-01 09:01:54 --> Helper loaded: date_helper
INFO - 2016-03-01 09:01:54 --> Helper loaded: form_helper
INFO - 2016-03-01 09:01:54 --> Database Driver Class Initialized
INFO - 2016-03-01 09:01:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:01:55 --> Controller Class Initialized
INFO - 2016-03-01 09:01:55 --> Model Class Initialized
INFO - 2016-03-01 09:01:55 --> Model Class Initialized
INFO - 2016-03-01 09:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:01:55 --> Pagination Class Initialized
INFO - 2016-03-01 09:01:55 --> Helper loaded: text_helper
INFO - 2016-03-01 09:01:55 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:01:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 12:01:55 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 12:01:55 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 12:01:55 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 12:01:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 12:01:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 12:01:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 12:01:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 12:01:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 12:01:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 12:01:56 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 12:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:01:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:01:56 --> Final output sent to browser
DEBUG - 2016-03-01 12:01:56 --> Total execution time: 1.1589
INFO - 2016-03-01 09:03:02 --> Config Class Initialized
INFO - 2016-03-01 09:03:02 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:03:02 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:03:02 --> Utf8 Class Initialized
INFO - 2016-03-01 09:03:02 --> URI Class Initialized
DEBUG - 2016-03-01 09:03:02 --> No URI present. Default controller set.
INFO - 2016-03-01 09:03:02 --> Router Class Initialized
INFO - 2016-03-01 09:03:02 --> Output Class Initialized
INFO - 2016-03-01 09:03:02 --> Security Class Initialized
DEBUG - 2016-03-01 09:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:03:02 --> Input Class Initialized
INFO - 2016-03-01 09:03:02 --> Language Class Initialized
INFO - 2016-03-01 09:03:02 --> Loader Class Initialized
INFO - 2016-03-01 09:03:02 --> Helper loaded: url_helper
INFO - 2016-03-01 09:03:02 --> Helper loaded: file_helper
INFO - 2016-03-01 09:03:02 --> Helper loaded: date_helper
INFO - 2016-03-01 09:03:02 --> Helper loaded: form_helper
INFO - 2016-03-01 09:03:02 --> Database Driver Class Initialized
INFO - 2016-03-01 09:03:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:03:03 --> Controller Class Initialized
INFO - 2016-03-01 09:03:03 --> Model Class Initialized
INFO - 2016-03-01 09:03:03 --> Model Class Initialized
INFO - 2016-03-01 09:03:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:03:03 --> Pagination Class Initialized
INFO - 2016-03-01 09:03:03 --> Helper loaded: text_helper
INFO - 2016-03-01 09:03:03 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 12:03:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:03:03 --> Final output sent to browser
DEBUG - 2016-03-01 12:03:03 --> Total execution time: 1.1214
INFO - 2016-03-01 09:03:07 --> Config Class Initialized
INFO - 2016-03-01 09:03:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:03:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:03:07 --> Utf8 Class Initialized
INFO - 2016-03-01 09:03:07 --> URI Class Initialized
INFO - 2016-03-01 09:03:07 --> Router Class Initialized
INFO - 2016-03-01 09:03:07 --> Output Class Initialized
INFO - 2016-03-01 09:03:07 --> Security Class Initialized
DEBUG - 2016-03-01 09:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:03:08 --> Input Class Initialized
INFO - 2016-03-01 09:03:08 --> Language Class Initialized
INFO - 2016-03-01 09:03:08 --> Loader Class Initialized
INFO - 2016-03-01 09:03:08 --> Helper loaded: url_helper
INFO - 2016-03-01 09:03:08 --> Helper loaded: file_helper
INFO - 2016-03-01 09:03:08 --> Helper loaded: date_helper
INFO - 2016-03-01 09:03:08 --> Helper loaded: form_helper
INFO - 2016-03-01 09:03:08 --> Database Driver Class Initialized
INFO - 2016-03-01 09:03:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:03:09 --> Controller Class Initialized
INFO - 2016-03-01 09:03:09 --> Model Class Initialized
INFO - 2016-03-01 09:03:09 --> Model Class Initialized
INFO - 2016-03-01 09:03:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:03:09 --> Pagination Class Initialized
INFO - 2016-03-01 09:03:09 --> Helper loaded: text_helper
INFO - 2016-03-01 09:03:09 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:03:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:03:09 --> Final output sent to browser
DEBUG - 2016-03-01 12:03:09 --> Total execution time: 1.1691
INFO - 2016-03-01 09:03:10 --> Config Class Initialized
INFO - 2016-03-01 09:03:10 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:03:10 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:03:10 --> Utf8 Class Initialized
INFO - 2016-03-01 09:03:10 --> URI Class Initialized
INFO - 2016-03-01 09:03:10 --> Router Class Initialized
INFO - 2016-03-01 09:03:10 --> Output Class Initialized
INFO - 2016-03-01 09:03:10 --> Security Class Initialized
DEBUG - 2016-03-01 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:03:10 --> Input Class Initialized
INFO - 2016-03-01 09:03:10 --> Language Class Initialized
INFO - 2016-03-01 09:03:10 --> Loader Class Initialized
INFO - 2016-03-01 09:03:10 --> Helper loaded: url_helper
INFO - 2016-03-01 09:03:10 --> Helper loaded: file_helper
INFO - 2016-03-01 09:03:10 --> Helper loaded: date_helper
INFO - 2016-03-01 09:03:10 --> Helper loaded: form_helper
INFO - 2016-03-01 09:03:10 --> Database Driver Class Initialized
INFO - 2016-03-01 09:03:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:03:11 --> Controller Class Initialized
INFO - 2016-03-01 09:03:11 --> Model Class Initialized
INFO - 2016-03-01 09:03:11 --> Model Class Initialized
INFO - 2016-03-01 09:03:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:03:11 --> Pagination Class Initialized
INFO - 2016-03-01 09:03:11 --> Helper loaded: text_helper
INFO - 2016-03-01 09:03:11 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:03:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:03:11 --> Final output sent to browser
DEBUG - 2016-03-01 12:03:11 --> Total execution time: 1.1827
INFO - 2016-03-01 09:03:37 --> Config Class Initialized
INFO - 2016-03-01 09:03:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:03:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:03:37 --> Utf8 Class Initialized
INFO - 2016-03-01 09:03:37 --> URI Class Initialized
INFO - 2016-03-01 09:03:37 --> Router Class Initialized
INFO - 2016-03-01 09:03:37 --> Output Class Initialized
INFO - 2016-03-01 09:03:37 --> Security Class Initialized
DEBUG - 2016-03-01 09:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:03:37 --> Input Class Initialized
INFO - 2016-03-01 09:03:37 --> Language Class Initialized
INFO - 2016-03-01 09:03:37 --> Loader Class Initialized
INFO - 2016-03-01 09:03:37 --> Helper loaded: url_helper
INFO - 2016-03-01 09:03:37 --> Helper loaded: file_helper
INFO - 2016-03-01 09:03:37 --> Helper loaded: date_helper
INFO - 2016-03-01 09:03:37 --> Helper loaded: form_helper
INFO - 2016-03-01 09:03:37 --> Database Driver Class Initialized
INFO - 2016-03-01 09:03:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:03:38 --> Controller Class Initialized
INFO - 2016-03-01 09:03:38 --> Model Class Initialized
INFO - 2016-03-01 09:03:38 --> Model Class Initialized
INFO - 2016-03-01 09:03:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:03:38 --> Pagination Class Initialized
INFO - 2016-03-01 09:03:38 --> Helper loaded: text_helper
INFO - 2016-03-01 09:03:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 12:03:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 12:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:03:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:03:38 --> Final output sent to browser
DEBUG - 2016-03-01 12:03:38 --> Total execution time: 1.1673
INFO - 2016-03-01 09:04:48 --> Config Class Initialized
INFO - 2016-03-01 09:04:48 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:04:48 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:04:48 --> Utf8 Class Initialized
INFO - 2016-03-01 09:04:48 --> URI Class Initialized
INFO - 2016-03-01 09:04:48 --> Router Class Initialized
INFO - 2016-03-01 09:04:48 --> Output Class Initialized
INFO - 2016-03-01 09:04:48 --> Security Class Initialized
DEBUG - 2016-03-01 09:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:04:48 --> Input Class Initialized
INFO - 2016-03-01 09:04:48 --> Language Class Initialized
INFO - 2016-03-01 09:04:48 --> Loader Class Initialized
INFO - 2016-03-01 09:04:48 --> Helper loaded: url_helper
INFO - 2016-03-01 09:04:48 --> Helper loaded: file_helper
INFO - 2016-03-01 09:04:48 --> Helper loaded: date_helper
INFO - 2016-03-01 09:04:48 --> Helper loaded: form_helper
INFO - 2016-03-01 09:04:48 --> Database Driver Class Initialized
INFO - 2016-03-01 09:04:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:04:49 --> Controller Class Initialized
INFO - 2016-03-01 09:04:49 --> Model Class Initialized
INFO - 2016-03-01 09:04:49 --> Model Class Initialized
INFO - 2016-03-01 09:04:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:04:49 --> Pagination Class Initialized
INFO - 2016-03-01 09:04:49 --> Helper loaded: text_helper
INFO - 2016-03-01 09:04:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:04:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:04:49 --> Final output sent to browser
DEBUG - 2016-03-01 12:04:49 --> Total execution time: 1.2522
INFO - 2016-03-01 09:05:09 --> Config Class Initialized
INFO - 2016-03-01 09:05:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:05:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:05:09 --> Utf8 Class Initialized
INFO - 2016-03-01 09:05:09 --> URI Class Initialized
INFO - 2016-03-01 09:05:09 --> Router Class Initialized
INFO - 2016-03-01 09:05:09 --> Output Class Initialized
INFO - 2016-03-01 09:05:09 --> Security Class Initialized
DEBUG - 2016-03-01 09:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:05:09 --> Input Class Initialized
INFO - 2016-03-01 09:05:09 --> Language Class Initialized
INFO - 2016-03-01 09:05:09 --> Loader Class Initialized
INFO - 2016-03-01 09:05:09 --> Helper loaded: url_helper
INFO - 2016-03-01 09:05:09 --> Helper loaded: file_helper
INFO - 2016-03-01 09:05:09 --> Helper loaded: date_helper
INFO - 2016-03-01 09:05:09 --> Helper loaded: form_helper
INFO - 2016-03-01 09:05:09 --> Database Driver Class Initialized
INFO - 2016-03-01 09:05:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:05:10 --> Controller Class Initialized
INFO - 2016-03-01 09:05:10 --> Model Class Initialized
INFO - 2016-03-01 09:05:10 --> Model Class Initialized
INFO - 2016-03-01 09:05:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:05:10 --> Pagination Class Initialized
INFO - 2016-03-01 09:05:10 --> Helper loaded: text_helper
INFO - 2016-03-01 09:05:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 12:05:10 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 12:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:05:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:05:10 --> Final output sent to browser
DEBUG - 2016-03-01 12:05:10 --> Total execution time: 1.1785
INFO - 2016-03-01 09:05:42 --> Config Class Initialized
INFO - 2016-03-01 09:05:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:05:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:05:42 --> Utf8 Class Initialized
INFO - 2016-03-01 09:05:42 --> URI Class Initialized
INFO - 2016-03-01 09:05:42 --> Router Class Initialized
INFO - 2016-03-01 09:05:42 --> Output Class Initialized
INFO - 2016-03-01 09:05:42 --> Security Class Initialized
DEBUG - 2016-03-01 09:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:05:42 --> Input Class Initialized
INFO - 2016-03-01 09:05:42 --> Language Class Initialized
INFO - 2016-03-01 09:05:42 --> Loader Class Initialized
INFO - 2016-03-01 09:05:42 --> Helper loaded: url_helper
INFO - 2016-03-01 09:05:42 --> Helper loaded: file_helper
INFO - 2016-03-01 09:05:42 --> Helper loaded: date_helper
INFO - 2016-03-01 09:05:42 --> Helper loaded: form_helper
INFO - 2016-03-01 09:05:42 --> Database Driver Class Initialized
INFO - 2016-03-01 09:05:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:05:43 --> Controller Class Initialized
INFO - 2016-03-01 09:05:43 --> Model Class Initialized
INFO - 2016-03-01 09:05:43 --> Model Class Initialized
INFO - 2016-03-01 09:05:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:05:43 --> Pagination Class Initialized
INFO - 2016-03-01 09:05:43 --> Helper loaded: text_helper
INFO - 2016-03-01 09:05:43 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:05:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:05:43 --> Final output sent to browser
DEBUG - 2016-03-01 12:05:43 --> Total execution time: 1.1658
INFO - 2016-03-01 09:06:10 --> Config Class Initialized
INFO - 2016-03-01 09:06:10 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:06:10 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:06:10 --> Utf8 Class Initialized
INFO - 2016-03-01 09:06:10 --> URI Class Initialized
INFO - 2016-03-01 09:06:10 --> Router Class Initialized
INFO - 2016-03-01 09:06:10 --> Output Class Initialized
INFO - 2016-03-01 09:06:10 --> Security Class Initialized
DEBUG - 2016-03-01 09:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:06:10 --> Input Class Initialized
INFO - 2016-03-01 09:06:10 --> Language Class Initialized
INFO - 2016-03-01 09:06:10 --> Loader Class Initialized
INFO - 2016-03-01 09:06:10 --> Helper loaded: url_helper
INFO - 2016-03-01 09:06:10 --> Helper loaded: file_helper
INFO - 2016-03-01 09:06:10 --> Helper loaded: date_helper
INFO - 2016-03-01 09:06:10 --> Helper loaded: form_helper
INFO - 2016-03-01 09:06:10 --> Database Driver Class Initialized
INFO - 2016-03-01 09:06:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:06:11 --> Controller Class Initialized
INFO - 2016-03-01 09:06:11 --> Model Class Initialized
INFO - 2016-03-01 09:06:11 --> Model Class Initialized
INFO - 2016-03-01 09:06:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:06:11 --> Pagination Class Initialized
INFO - 2016-03-01 09:06:11 --> Helper loaded: text_helper
INFO - 2016-03-01 09:06:11 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 12:06:11 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 12:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:06:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:06:11 --> Final output sent to browser
DEBUG - 2016-03-01 12:06:11 --> Total execution time: 1.1718
INFO - 2016-03-01 09:07:17 --> Config Class Initialized
INFO - 2016-03-01 09:07:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:07:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:07:17 --> Utf8 Class Initialized
INFO - 2016-03-01 09:07:17 --> URI Class Initialized
INFO - 2016-03-01 09:07:17 --> Router Class Initialized
INFO - 2016-03-01 09:07:17 --> Output Class Initialized
INFO - 2016-03-01 09:07:17 --> Security Class Initialized
DEBUG - 2016-03-01 09:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:07:17 --> Input Class Initialized
INFO - 2016-03-01 09:07:17 --> Language Class Initialized
INFO - 2016-03-01 09:07:17 --> Loader Class Initialized
INFO - 2016-03-01 09:07:17 --> Helper loaded: url_helper
INFO - 2016-03-01 09:07:17 --> Helper loaded: file_helper
INFO - 2016-03-01 09:07:17 --> Helper loaded: date_helper
INFO - 2016-03-01 09:07:17 --> Helper loaded: form_helper
INFO - 2016-03-01 09:07:17 --> Database Driver Class Initialized
INFO - 2016-03-01 09:07:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:07:18 --> Controller Class Initialized
INFO - 2016-03-01 09:07:18 --> Model Class Initialized
INFO - 2016-03-01 09:07:18 --> Model Class Initialized
INFO - 2016-03-01 09:07:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:07:18 --> Pagination Class Initialized
INFO - 2016-03-01 09:07:18 --> Helper loaded: text_helper
INFO - 2016-03-01 09:07:18 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:07:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:07:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:07:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:07:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:07:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:07:18 --> Final output sent to browser
DEBUG - 2016-03-01 12:07:18 --> Total execution time: 1.1624
INFO - 2016-03-01 09:07:37 --> Config Class Initialized
INFO - 2016-03-01 09:07:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:07:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:07:37 --> Utf8 Class Initialized
INFO - 2016-03-01 09:07:37 --> URI Class Initialized
INFO - 2016-03-01 09:07:37 --> Router Class Initialized
INFO - 2016-03-01 09:07:37 --> Output Class Initialized
INFO - 2016-03-01 09:07:37 --> Security Class Initialized
DEBUG - 2016-03-01 09:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:07:37 --> Input Class Initialized
INFO - 2016-03-01 09:07:37 --> Language Class Initialized
INFO - 2016-03-01 09:07:37 --> Loader Class Initialized
INFO - 2016-03-01 09:07:37 --> Helper loaded: url_helper
INFO - 2016-03-01 09:07:37 --> Helper loaded: file_helper
INFO - 2016-03-01 09:07:37 --> Helper loaded: date_helper
INFO - 2016-03-01 09:07:37 --> Helper loaded: form_helper
INFO - 2016-03-01 09:07:37 --> Database Driver Class Initialized
INFO - 2016-03-01 09:07:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:07:38 --> Controller Class Initialized
INFO - 2016-03-01 09:07:38 --> Model Class Initialized
INFO - 2016-03-01 09:07:38 --> Model Class Initialized
INFO - 2016-03-01 09:07:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:07:38 --> Pagination Class Initialized
INFO - 2016-03-01 09:07:38 --> Helper loaded: text_helper
INFO - 2016-03-01 09:07:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 12:07:38 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:07:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:07:38 --> Final output sent to browser
DEBUG - 2016-03-01 12:07:38 --> Total execution time: 1.1724
INFO - 2016-03-01 09:10:17 --> Config Class Initialized
INFO - 2016-03-01 09:10:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:10:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:10:17 --> Utf8 Class Initialized
INFO - 2016-03-01 09:10:17 --> URI Class Initialized
INFO - 2016-03-01 09:10:17 --> Router Class Initialized
INFO - 2016-03-01 09:10:17 --> Output Class Initialized
INFO - 2016-03-01 09:10:17 --> Security Class Initialized
DEBUG - 2016-03-01 09:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:10:17 --> Input Class Initialized
INFO - 2016-03-01 09:10:17 --> Language Class Initialized
INFO - 2016-03-01 09:10:17 --> Loader Class Initialized
INFO - 2016-03-01 09:10:17 --> Helper loaded: url_helper
INFO - 2016-03-01 09:10:17 --> Helper loaded: file_helper
INFO - 2016-03-01 09:10:17 --> Helper loaded: date_helper
INFO - 2016-03-01 09:10:17 --> Helper loaded: form_helper
INFO - 2016-03-01 09:10:17 --> Database Driver Class Initialized
INFO - 2016-03-01 09:10:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:10:18 --> Controller Class Initialized
INFO - 2016-03-01 09:10:18 --> Model Class Initialized
INFO - 2016-03-01 09:10:18 --> Model Class Initialized
INFO - 2016-03-01 09:10:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:10:18 --> Pagination Class Initialized
INFO - 2016-03-01 09:10:18 --> Helper loaded: text_helper
INFO - 2016-03-01 09:10:18 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:10:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:10:18 --> Final output sent to browser
DEBUG - 2016-03-01 12:10:18 --> Total execution time: 1.1991
INFO - 2016-03-01 09:10:43 --> Config Class Initialized
INFO - 2016-03-01 09:10:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:10:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:10:43 --> Utf8 Class Initialized
INFO - 2016-03-01 09:10:43 --> URI Class Initialized
INFO - 2016-03-01 09:10:43 --> Router Class Initialized
INFO - 2016-03-01 09:10:43 --> Output Class Initialized
INFO - 2016-03-01 09:10:43 --> Security Class Initialized
DEBUG - 2016-03-01 09:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:10:43 --> Input Class Initialized
INFO - 2016-03-01 09:10:43 --> Language Class Initialized
INFO - 2016-03-01 09:10:43 --> Loader Class Initialized
INFO - 2016-03-01 09:10:43 --> Helper loaded: url_helper
INFO - 2016-03-01 09:10:43 --> Helper loaded: file_helper
INFO - 2016-03-01 09:10:43 --> Helper loaded: date_helper
INFO - 2016-03-01 09:10:43 --> Helper loaded: form_helper
INFO - 2016-03-01 09:10:43 --> Database Driver Class Initialized
INFO - 2016-03-01 09:10:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:10:44 --> Controller Class Initialized
INFO - 2016-03-01 09:10:44 --> Model Class Initialized
INFO - 2016-03-01 09:10:44 --> Model Class Initialized
INFO - 2016-03-01 09:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:10:45 --> Pagination Class Initialized
INFO - 2016-03-01 09:10:45 --> Helper loaded: text_helper
INFO - 2016-03-01 09:10:45 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:10:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:10:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 12:10:45 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 12:10:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:10:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:10:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:10:45 --> Final output sent to browser
DEBUG - 2016-03-01 12:10:45 --> Total execution time: 1.1698
INFO - 2016-03-01 09:12:27 --> Config Class Initialized
INFO - 2016-03-01 09:12:27 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:12:27 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:12:27 --> Utf8 Class Initialized
INFO - 2016-03-01 09:12:27 --> URI Class Initialized
INFO - 2016-03-01 09:12:27 --> Router Class Initialized
INFO - 2016-03-01 09:12:27 --> Output Class Initialized
INFO - 2016-03-01 09:12:27 --> Security Class Initialized
DEBUG - 2016-03-01 09:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:12:27 --> Input Class Initialized
INFO - 2016-03-01 09:12:27 --> Language Class Initialized
INFO - 2016-03-01 09:12:27 --> Loader Class Initialized
INFO - 2016-03-01 09:12:27 --> Helper loaded: url_helper
INFO - 2016-03-01 09:12:27 --> Helper loaded: file_helper
INFO - 2016-03-01 09:12:27 --> Helper loaded: date_helper
INFO - 2016-03-01 09:12:27 --> Helper loaded: form_helper
INFO - 2016-03-01 09:12:27 --> Database Driver Class Initialized
INFO - 2016-03-01 09:12:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:12:28 --> Controller Class Initialized
INFO - 2016-03-01 09:12:28 --> Model Class Initialized
INFO - 2016-03-01 09:12:28 --> Model Class Initialized
INFO - 2016-03-01 09:12:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:12:28 --> Pagination Class Initialized
INFO - 2016-03-01 09:12:28 --> Helper loaded: text_helper
INFO - 2016-03-01 09:12:28 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:12:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:12:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:12:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:12:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:12:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:12:28 --> Final output sent to browser
DEBUG - 2016-03-01 12:12:28 --> Total execution time: 1.1839
INFO - 2016-03-01 09:12:43 --> Config Class Initialized
INFO - 2016-03-01 09:12:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:12:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:12:43 --> Utf8 Class Initialized
INFO - 2016-03-01 09:12:43 --> URI Class Initialized
INFO - 2016-03-01 09:12:43 --> Router Class Initialized
INFO - 2016-03-01 09:12:43 --> Output Class Initialized
INFO - 2016-03-01 09:12:43 --> Security Class Initialized
DEBUG - 2016-03-01 09:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:12:43 --> Input Class Initialized
INFO - 2016-03-01 09:12:43 --> Language Class Initialized
INFO - 2016-03-01 09:12:43 --> Loader Class Initialized
INFO - 2016-03-01 09:12:43 --> Helper loaded: url_helper
INFO - 2016-03-01 09:12:43 --> Helper loaded: file_helper
INFO - 2016-03-01 09:12:43 --> Helper loaded: date_helper
INFO - 2016-03-01 09:12:43 --> Helper loaded: form_helper
INFO - 2016-03-01 09:12:43 --> Database Driver Class Initialized
INFO - 2016-03-01 09:12:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:12:44 --> Controller Class Initialized
INFO - 2016-03-01 09:12:44 --> Model Class Initialized
INFO - 2016-03-01 09:12:44 --> Model Class Initialized
INFO - 2016-03-01 09:12:44 --> Form Validation Class Initialized
INFO - 2016-03-01 09:12:44 --> Helper loaded: text_helper
INFO - 2016-03-01 09:12:44 --> Final output sent to browser
DEBUG - 2016-03-01 09:12:44 --> Total execution time: 1.1950
INFO - 2016-03-01 09:12:44 --> Config Class Initialized
INFO - 2016-03-01 09:12:44 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:12:44 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:12:44 --> Utf8 Class Initialized
INFO - 2016-03-01 09:12:44 --> URI Class Initialized
INFO - 2016-03-01 09:12:44 --> Router Class Initialized
INFO - 2016-03-01 09:12:44 --> Output Class Initialized
INFO - 2016-03-01 09:12:44 --> Security Class Initialized
DEBUG - 2016-03-01 09:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:12:44 --> Input Class Initialized
INFO - 2016-03-01 09:12:44 --> Language Class Initialized
INFO - 2016-03-01 09:12:44 --> Loader Class Initialized
INFO - 2016-03-01 09:12:44 --> Helper loaded: url_helper
INFO - 2016-03-01 09:12:44 --> Helper loaded: file_helper
INFO - 2016-03-01 09:12:44 --> Helper loaded: date_helper
INFO - 2016-03-01 09:12:44 --> Helper loaded: form_helper
INFO - 2016-03-01 09:12:44 --> Database Driver Class Initialized
INFO - 2016-03-01 09:12:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:12:45 --> Controller Class Initialized
INFO - 2016-03-01 09:12:45 --> Model Class Initialized
INFO - 2016-03-01 09:12:45 --> Model Class Initialized
INFO - 2016-03-01 09:12:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:12:45 --> Pagination Class Initialized
INFO - 2016-03-01 09:12:45 --> Helper loaded: text_helper
INFO - 2016-03-01 09:12:45 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:12:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:12:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:12:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:12:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:12:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:12:45 --> Final output sent to browser
DEBUG - 2016-03-01 12:12:45 --> Total execution time: 1.1910
INFO - 2016-03-01 09:12:50 --> Config Class Initialized
INFO - 2016-03-01 09:12:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:12:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:12:50 --> Utf8 Class Initialized
INFO - 2016-03-01 09:12:50 --> URI Class Initialized
INFO - 2016-03-01 09:12:50 --> Router Class Initialized
INFO - 2016-03-01 09:12:50 --> Output Class Initialized
INFO - 2016-03-01 09:12:50 --> Security Class Initialized
DEBUG - 2016-03-01 09:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:12:50 --> Input Class Initialized
INFO - 2016-03-01 09:12:50 --> Language Class Initialized
INFO - 2016-03-01 09:12:50 --> Loader Class Initialized
INFO - 2016-03-01 09:12:50 --> Helper loaded: url_helper
INFO - 2016-03-01 09:12:50 --> Helper loaded: file_helper
INFO - 2016-03-01 09:12:50 --> Helper loaded: date_helper
INFO - 2016-03-01 09:12:50 --> Helper loaded: form_helper
INFO - 2016-03-01 09:12:50 --> Database Driver Class Initialized
INFO - 2016-03-01 09:12:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:12:51 --> Controller Class Initialized
INFO - 2016-03-01 09:12:51 --> Model Class Initialized
INFO - 2016-03-01 09:12:51 --> Model Class Initialized
INFO - 2016-03-01 09:12:51 --> Form Validation Class Initialized
INFO - 2016-03-01 09:12:51 --> Helper loaded: text_helper
INFO - 2016-03-01 09:12:51 --> Config Class Initialized
INFO - 2016-03-01 09:12:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:12:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:12:51 --> Utf8 Class Initialized
INFO - 2016-03-01 09:12:51 --> URI Class Initialized
DEBUG - 2016-03-01 09:12:51 --> No URI present. Default controller set.
INFO - 2016-03-01 09:12:51 --> Router Class Initialized
INFO - 2016-03-01 09:12:51 --> Output Class Initialized
INFO - 2016-03-01 09:12:51 --> Security Class Initialized
DEBUG - 2016-03-01 09:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:12:51 --> Input Class Initialized
INFO - 2016-03-01 09:12:51 --> Language Class Initialized
INFO - 2016-03-01 09:12:51 --> Loader Class Initialized
INFO - 2016-03-01 09:12:51 --> Helper loaded: url_helper
INFO - 2016-03-01 09:12:51 --> Helper loaded: file_helper
INFO - 2016-03-01 09:12:51 --> Helper loaded: date_helper
INFO - 2016-03-01 09:12:51 --> Helper loaded: form_helper
INFO - 2016-03-01 09:12:51 --> Database Driver Class Initialized
INFO - 2016-03-01 09:12:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:12:52 --> Controller Class Initialized
INFO - 2016-03-01 09:12:52 --> Model Class Initialized
INFO - 2016-03-01 09:12:52 --> Model Class Initialized
INFO - 2016-03-01 09:12:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:12:52 --> Pagination Class Initialized
INFO - 2016-03-01 09:12:52 --> Helper loaded: text_helper
INFO - 2016-03-01 09:12:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:12:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 12:12:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:12:53 --> Final output sent to browser
DEBUG - 2016-03-01 12:12:53 --> Total execution time: 1.1243
INFO - 2016-03-01 09:14:06 --> Config Class Initialized
INFO - 2016-03-01 09:14:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:14:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:14:06 --> Utf8 Class Initialized
INFO - 2016-03-01 09:14:06 --> URI Class Initialized
INFO - 2016-03-01 09:14:06 --> Router Class Initialized
INFO - 2016-03-01 09:14:06 --> Output Class Initialized
INFO - 2016-03-01 09:14:06 --> Security Class Initialized
DEBUG - 2016-03-01 09:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:14:06 --> Input Class Initialized
INFO - 2016-03-01 09:14:06 --> Language Class Initialized
INFO - 2016-03-01 09:14:06 --> Loader Class Initialized
INFO - 2016-03-01 09:14:06 --> Helper loaded: url_helper
INFO - 2016-03-01 09:14:06 --> Helper loaded: file_helper
INFO - 2016-03-01 09:14:06 --> Helper loaded: date_helper
INFO - 2016-03-01 09:14:06 --> Helper loaded: form_helper
INFO - 2016-03-01 09:14:06 --> Database Driver Class Initialized
INFO - 2016-03-01 09:14:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:14:07 --> Controller Class Initialized
INFO - 2016-03-01 09:14:07 --> Model Class Initialized
INFO - 2016-03-01 09:14:07 --> Model Class Initialized
INFO - 2016-03-01 09:14:07 --> Form Validation Class Initialized
INFO - 2016-03-01 09:14:07 --> Helper loaded: text_helper
INFO - 2016-03-01 09:14:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-03-01 09:14:07 --> Query error: Duplicate entry 'babara@hotmail.com' for key 'email_idx' - Invalid query: INSERT INTO `user` (`nickname`, `email`, `password`, created) VALUES ('lasd', 'babara@hotmail.com', '$2y$10$jo1qKj732zkfkMNTCLq/w.NAUwW.6VfitjQNdFvYHVFFfj5mOptTC', NOW())
INFO - 2016-03-01 09:14:07 --> Language file loaded: language/english/db_lang.php
INFO - 2016-03-01 09:14:44 --> Config Class Initialized
INFO - 2016-03-01 09:14:44 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:14:44 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:14:44 --> Utf8 Class Initialized
INFO - 2016-03-01 09:14:44 --> URI Class Initialized
DEBUG - 2016-03-01 09:14:44 --> No URI present. Default controller set.
INFO - 2016-03-01 09:14:44 --> Router Class Initialized
INFO - 2016-03-01 09:14:44 --> Output Class Initialized
INFO - 2016-03-01 09:14:44 --> Security Class Initialized
DEBUG - 2016-03-01 09:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:14:44 --> Input Class Initialized
INFO - 2016-03-01 09:14:44 --> Language Class Initialized
INFO - 2016-03-01 09:14:44 --> Loader Class Initialized
INFO - 2016-03-01 09:14:44 --> Helper loaded: url_helper
INFO - 2016-03-01 09:14:44 --> Helper loaded: file_helper
INFO - 2016-03-01 09:14:44 --> Helper loaded: date_helper
INFO - 2016-03-01 09:14:44 --> Helper loaded: form_helper
INFO - 2016-03-01 09:14:44 --> Database Driver Class Initialized
INFO - 2016-03-01 09:14:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:14:45 --> Controller Class Initialized
INFO - 2016-03-01 09:14:45 --> Model Class Initialized
INFO - 2016-03-01 09:14:45 --> Model Class Initialized
INFO - 2016-03-01 09:14:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:14:45 --> Pagination Class Initialized
INFO - 2016-03-01 09:14:45 --> Helper loaded: text_helper
INFO - 2016-03-01 09:14:45 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 12:14:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:14:45 --> Final output sent to browser
DEBUG - 2016-03-01 12:14:45 --> Total execution time: 1.1711
INFO - 2016-03-01 09:15:07 --> Config Class Initialized
INFO - 2016-03-01 09:15:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:15:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:15:07 --> Utf8 Class Initialized
INFO - 2016-03-01 09:15:07 --> URI Class Initialized
INFO - 2016-03-01 09:15:07 --> Router Class Initialized
INFO - 2016-03-01 09:15:07 --> Output Class Initialized
INFO - 2016-03-01 09:15:07 --> Security Class Initialized
DEBUG - 2016-03-01 09:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:15:07 --> Input Class Initialized
INFO - 2016-03-01 09:15:07 --> Language Class Initialized
INFO - 2016-03-01 09:15:07 --> Loader Class Initialized
INFO - 2016-03-01 09:15:07 --> Helper loaded: url_helper
INFO - 2016-03-01 09:15:07 --> Helper loaded: file_helper
INFO - 2016-03-01 09:15:07 --> Helper loaded: date_helper
INFO - 2016-03-01 09:15:07 --> Helper loaded: form_helper
INFO - 2016-03-01 09:15:07 --> Database Driver Class Initialized
INFO - 2016-03-01 09:15:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:15:08 --> Controller Class Initialized
INFO - 2016-03-01 09:15:08 --> Model Class Initialized
INFO - 2016-03-01 09:15:08 --> Model Class Initialized
INFO - 2016-03-01 09:15:08 --> Form Validation Class Initialized
INFO - 2016-03-01 09:15:08 --> Helper loaded: text_helper
INFO - 2016-03-01 09:15:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:15:08 --> Final output sent to browser
DEBUG - 2016-03-01 09:15:08 --> Total execution time: 1.2416
INFO - 2016-03-01 09:15:08 --> Config Class Initialized
INFO - 2016-03-01 09:15:08 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:15:08 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:15:08 --> Utf8 Class Initialized
INFO - 2016-03-01 09:15:08 --> URI Class Initialized
INFO - 2016-03-01 09:15:08 --> Router Class Initialized
INFO - 2016-03-01 09:15:08 --> Output Class Initialized
INFO - 2016-03-01 09:15:08 --> Security Class Initialized
DEBUG - 2016-03-01 09:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:15:08 --> Input Class Initialized
INFO - 2016-03-01 09:15:08 --> Language Class Initialized
ERROR - 2016-03-01 09:15:08 --> 404 Page Not Found: Undefined/index
INFO - 2016-03-01 09:16:12 --> Config Class Initialized
INFO - 2016-03-01 09:16:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:16:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:16:12 --> Utf8 Class Initialized
INFO - 2016-03-01 09:16:12 --> URI Class Initialized
DEBUG - 2016-03-01 09:16:12 --> No URI present. Default controller set.
INFO - 2016-03-01 09:16:12 --> Router Class Initialized
INFO - 2016-03-01 09:16:12 --> Output Class Initialized
INFO - 2016-03-01 09:16:12 --> Security Class Initialized
DEBUG - 2016-03-01 09:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:16:12 --> Input Class Initialized
INFO - 2016-03-01 09:16:12 --> Language Class Initialized
INFO - 2016-03-01 09:16:12 --> Loader Class Initialized
INFO - 2016-03-01 09:16:12 --> Helper loaded: url_helper
INFO - 2016-03-01 09:16:12 --> Helper loaded: file_helper
INFO - 2016-03-01 09:16:12 --> Helper loaded: date_helper
INFO - 2016-03-01 09:16:12 --> Helper loaded: form_helper
INFO - 2016-03-01 09:16:12 --> Database Driver Class Initialized
INFO - 2016-03-01 09:16:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:16:13 --> Controller Class Initialized
INFO - 2016-03-01 09:16:13 --> Model Class Initialized
INFO - 2016-03-01 09:16:13 --> Model Class Initialized
INFO - 2016-03-01 09:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:16:13 --> Pagination Class Initialized
INFO - 2016-03-01 09:16:13 --> Helper loaded: text_helper
INFO - 2016-03-01 09:16:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 12:16:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:16:13 --> Final output sent to browser
DEBUG - 2016-03-01 12:16:13 --> Total execution time: 1.1288
INFO - 2016-03-01 09:16:31 --> Config Class Initialized
INFO - 2016-03-01 09:16:31 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:16:31 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:16:31 --> Utf8 Class Initialized
INFO - 2016-03-01 09:16:31 --> URI Class Initialized
INFO - 2016-03-01 09:16:31 --> Router Class Initialized
INFO - 2016-03-01 09:16:31 --> Output Class Initialized
INFO - 2016-03-01 09:16:31 --> Security Class Initialized
DEBUG - 2016-03-01 09:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:16:31 --> Input Class Initialized
INFO - 2016-03-01 09:16:31 --> Language Class Initialized
INFO - 2016-03-01 09:16:31 --> Loader Class Initialized
INFO - 2016-03-01 09:16:31 --> Helper loaded: url_helper
INFO - 2016-03-01 09:16:31 --> Helper loaded: file_helper
INFO - 2016-03-01 09:16:31 --> Helper loaded: date_helper
INFO - 2016-03-01 09:16:31 --> Helper loaded: form_helper
INFO - 2016-03-01 09:16:31 --> Database Driver Class Initialized
INFO - 2016-03-01 09:16:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:16:32 --> Controller Class Initialized
INFO - 2016-03-01 09:16:32 --> Model Class Initialized
INFO - 2016-03-01 09:16:32 --> Model Class Initialized
INFO - 2016-03-01 09:16:32 --> Form Validation Class Initialized
INFO - 2016-03-01 09:16:32 --> Helper loaded: text_helper
INFO - 2016-03-01 09:16:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:16:32 --> Final output sent to browser
DEBUG - 2016-03-01 09:16:32 --> Total execution time: 1.2450
INFO - 2016-03-01 09:16:32 --> Config Class Initialized
INFO - 2016-03-01 09:16:32 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:16:32 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:16:32 --> Utf8 Class Initialized
INFO - 2016-03-01 09:16:32 --> URI Class Initialized
INFO - 2016-03-01 09:16:32 --> Router Class Initialized
INFO - 2016-03-01 09:16:32 --> Output Class Initialized
INFO - 2016-03-01 09:16:32 --> Security Class Initialized
DEBUG - 2016-03-01 09:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:16:32 --> Input Class Initialized
INFO - 2016-03-01 09:16:32 --> Language Class Initialized
INFO - 2016-03-01 09:16:32 --> Loader Class Initialized
INFO - 2016-03-01 09:16:32 --> Helper loaded: url_helper
INFO - 2016-03-01 09:16:32 --> Helper loaded: file_helper
INFO - 2016-03-01 09:16:32 --> Helper loaded: date_helper
INFO - 2016-03-01 09:16:32 --> Helper loaded: form_helper
INFO - 2016-03-01 09:16:32 --> Database Driver Class Initialized
INFO - 2016-03-01 09:16:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:16:33 --> Controller Class Initialized
INFO - 2016-03-01 09:16:33 --> Model Class Initialized
INFO - 2016-03-01 09:16:34 --> Model Class Initialized
INFO - 2016-03-01 09:16:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:16:34 --> Pagination Class Initialized
INFO - 2016-03-01 09:16:34 --> Helper loaded: text_helper
INFO - 2016-03-01 09:16:34 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:16:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:16:34 --> Final output sent to browser
DEBUG - 2016-03-01 12:16:34 --> Total execution time: 1.1428
INFO - 2016-03-01 09:16:50 --> Config Class Initialized
INFO - 2016-03-01 09:16:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:16:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:16:50 --> Utf8 Class Initialized
INFO - 2016-03-01 09:16:50 --> URI Class Initialized
INFO - 2016-03-01 09:16:50 --> Router Class Initialized
INFO - 2016-03-01 09:16:50 --> Output Class Initialized
INFO - 2016-03-01 09:16:50 --> Security Class Initialized
DEBUG - 2016-03-01 09:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:16:50 --> Input Class Initialized
INFO - 2016-03-01 09:16:50 --> Language Class Initialized
INFO - 2016-03-01 09:16:50 --> Loader Class Initialized
INFO - 2016-03-01 09:16:50 --> Helper loaded: url_helper
INFO - 2016-03-01 09:16:50 --> Helper loaded: file_helper
INFO - 2016-03-01 09:16:50 --> Helper loaded: date_helper
INFO - 2016-03-01 09:16:50 --> Helper loaded: form_helper
INFO - 2016-03-01 09:16:50 --> Database Driver Class Initialized
INFO - 2016-03-01 09:16:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:16:51 --> Controller Class Initialized
INFO - 2016-03-01 09:16:51 --> Model Class Initialized
INFO - 2016-03-01 09:16:51 --> Model Class Initialized
INFO - 2016-03-01 09:16:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:16:51 --> Pagination Class Initialized
INFO - 2016-03-01 09:16:51 --> Helper loaded: text_helper
INFO - 2016-03-01 09:16:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:16:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:16:51 --> Final output sent to browser
DEBUG - 2016-03-01 12:16:51 --> Total execution time: 1.2244
INFO - 2016-03-01 09:17:07 --> Config Class Initialized
INFO - 2016-03-01 09:17:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:17:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:17:07 --> Utf8 Class Initialized
INFO - 2016-03-01 09:17:07 --> URI Class Initialized
INFO - 2016-03-01 09:17:07 --> Router Class Initialized
INFO - 2016-03-01 09:17:07 --> Output Class Initialized
INFO - 2016-03-01 09:17:07 --> Security Class Initialized
DEBUG - 2016-03-01 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:17:07 --> Input Class Initialized
INFO - 2016-03-01 09:17:07 --> Language Class Initialized
INFO - 2016-03-01 09:17:07 --> Loader Class Initialized
INFO - 2016-03-01 09:17:07 --> Helper loaded: url_helper
INFO - 2016-03-01 09:17:07 --> Helper loaded: file_helper
INFO - 2016-03-01 09:17:07 --> Helper loaded: date_helper
INFO - 2016-03-01 09:17:07 --> Helper loaded: form_helper
INFO - 2016-03-01 09:17:07 --> Database Driver Class Initialized
INFO - 2016-03-01 09:17:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:17:08 --> Controller Class Initialized
INFO - 2016-03-01 09:17:08 --> Model Class Initialized
INFO - 2016-03-01 09:17:08 --> Model Class Initialized
INFO - 2016-03-01 09:17:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:17:08 --> Pagination Class Initialized
INFO - 2016-03-01 09:17:08 --> Helper loaded: text_helper
INFO - 2016-03-01 09:17:08 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 12:17:08 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 12:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 12:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 12:17:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:17:08 --> Final output sent to browser
DEBUG - 2016-03-01 12:17:08 --> Total execution time: 1.2575
INFO - 2016-03-01 09:21:17 --> Config Class Initialized
INFO - 2016-03-01 09:21:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:21:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:21:17 --> Utf8 Class Initialized
INFO - 2016-03-01 09:21:17 --> URI Class Initialized
INFO - 2016-03-01 09:21:17 --> Router Class Initialized
INFO - 2016-03-01 09:21:17 --> Output Class Initialized
INFO - 2016-03-01 09:21:17 --> Security Class Initialized
DEBUG - 2016-03-01 09:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:21:17 --> Input Class Initialized
INFO - 2016-03-01 09:21:17 --> Language Class Initialized
INFO - 2016-03-01 09:21:17 --> Loader Class Initialized
INFO - 2016-03-01 09:21:17 --> Helper loaded: url_helper
INFO - 2016-03-01 09:21:17 --> Helper loaded: file_helper
INFO - 2016-03-01 09:21:17 --> Helper loaded: date_helper
INFO - 2016-03-01 09:21:17 --> Helper loaded: form_helper
INFO - 2016-03-01 09:21:17 --> Database Driver Class Initialized
INFO - 2016-03-01 09:21:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:21:18 --> Controller Class Initialized
INFO - 2016-03-01 09:21:18 --> Model Class Initialized
INFO - 2016-03-01 09:21:18 --> Model Class Initialized
INFO - 2016-03-01 09:21:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:21:18 --> Pagination Class Initialized
INFO - 2016-03-01 09:21:18 --> Helper loaded: text_helper
INFO - 2016-03-01 09:21:18 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:21:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:21:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:21:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:21:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:21:18 --> Final output sent to browser
DEBUG - 2016-03-01 12:21:18 --> Total execution time: 1.1680
INFO - 2016-03-01 09:21:40 --> Config Class Initialized
INFO - 2016-03-01 09:21:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:21:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:21:40 --> Utf8 Class Initialized
INFO - 2016-03-01 09:21:40 --> URI Class Initialized
INFO - 2016-03-01 09:21:40 --> Router Class Initialized
INFO - 2016-03-01 09:21:40 --> Output Class Initialized
INFO - 2016-03-01 09:21:40 --> Security Class Initialized
DEBUG - 2016-03-01 09:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:21:40 --> Input Class Initialized
INFO - 2016-03-01 09:21:40 --> Language Class Initialized
INFO - 2016-03-01 09:21:40 --> Loader Class Initialized
INFO - 2016-03-01 09:21:40 --> Helper loaded: url_helper
INFO - 2016-03-01 09:21:40 --> Helper loaded: file_helper
INFO - 2016-03-01 09:21:40 --> Helper loaded: date_helper
INFO - 2016-03-01 09:21:40 --> Helper loaded: form_helper
INFO - 2016-03-01 09:21:40 --> Database Driver Class Initialized
INFO - 2016-03-01 09:21:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:21:41 --> Controller Class Initialized
INFO - 2016-03-01 09:21:41 --> Model Class Initialized
INFO - 2016-03-01 09:21:41 --> Model Class Initialized
INFO - 2016-03-01 09:21:41 --> Form Validation Class Initialized
INFO - 2016-03-01 09:21:41 --> Helper loaded: text_helper
INFO - 2016-03-01 09:21:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:21:41 --> Final output sent to browser
DEBUG - 2016-03-01 09:21:41 --> Total execution time: 1.2513
INFO - 2016-03-01 09:21:41 --> Config Class Initialized
INFO - 2016-03-01 09:21:41 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:21:41 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:21:41 --> Utf8 Class Initialized
INFO - 2016-03-01 09:21:41 --> URI Class Initialized
INFO - 2016-03-01 09:21:41 --> Router Class Initialized
INFO - 2016-03-01 09:21:41 --> Output Class Initialized
INFO - 2016-03-01 09:21:41 --> Security Class Initialized
DEBUG - 2016-03-01 09:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:21:41 --> Input Class Initialized
INFO - 2016-03-01 09:21:41 --> Language Class Initialized
ERROR - 2016-03-01 09:21:41 --> 404 Page Not Found: Null/index
INFO - 2016-03-01 09:23:18 --> Config Class Initialized
INFO - 2016-03-01 09:23:18 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:23:18 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:23:18 --> Utf8 Class Initialized
INFO - 2016-03-01 09:23:18 --> URI Class Initialized
INFO - 2016-03-01 09:23:18 --> Router Class Initialized
INFO - 2016-03-01 09:23:18 --> Output Class Initialized
INFO - 2016-03-01 09:23:18 --> Security Class Initialized
DEBUG - 2016-03-01 09:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:23:18 --> Input Class Initialized
INFO - 2016-03-01 09:23:18 --> Language Class Initialized
INFO - 2016-03-01 09:23:18 --> Loader Class Initialized
INFO - 2016-03-01 09:23:18 --> Helper loaded: url_helper
INFO - 2016-03-01 09:23:18 --> Helper loaded: file_helper
INFO - 2016-03-01 09:23:18 --> Helper loaded: date_helper
INFO - 2016-03-01 09:23:18 --> Helper loaded: form_helper
INFO - 2016-03-01 09:23:18 --> Database Driver Class Initialized
INFO - 2016-03-01 09:23:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:23:20 --> Controller Class Initialized
INFO - 2016-03-01 09:23:20 --> Model Class Initialized
INFO - 2016-03-01 09:23:20 --> Model Class Initialized
INFO - 2016-03-01 09:23:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:23:20 --> Pagination Class Initialized
INFO - 2016-03-01 09:23:20 --> Helper loaded: text_helper
INFO - 2016-03-01 09:23:20 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:23:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:23:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:23:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:23:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:23:20 --> Final output sent to browser
DEBUG - 2016-03-01 12:23:20 --> Total execution time: 1.1780
INFO - 2016-03-01 09:23:51 --> Config Class Initialized
INFO - 2016-03-01 09:23:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:23:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:23:51 --> Utf8 Class Initialized
INFO - 2016-03-01 09:23:51 --> URI Class Initialized
INFO - 2016-03-01 09:23:51 --> Router Class Initialized
INFO - 2016-03-01 09:23:51 --> Output Class Initialized
INFO - 2016-03-01 09:23:51 --> Security Class Initialized
DEBUG - 2016-03-01 09:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:23:51 --> Input Class Initialized
INFO - 2016-03-01 09:23:51 --> Language Class Initialized
INFO - 2016-03-01 09:23:51 --> Loader Class Initialized
INFO - 2016-03-01 09:23:51 --> Helper loaded: url_helper
INFO - 2016-03-01 09:23:51 --> Helper loaded: file_helper
INFO - 2016-03-01 09:23:51 --> Helper loaded: date_helper
INFO - 2016-03-01 09:23:51 --> Helper loaded: form_helper
INFO - 2016-03-01 09:23:51 --> Database Driver Class Initialized
INFO - 2016-03-01 09:23:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:23:52 --> Controller Class Initialized
INFO - 2016-03-01 09:23:52 --> Model Class Initialized
INFO - 2016-03-01 09:23:52 --> Model Class Initialized
INFO - 2016-03-01 09:23:52 --> Form Validation Class Initialized
INFO - 2016-03-01 09:23:52 --> Helper loaded: text_helper
INFO - 2016-03-01 09:23:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:23:53 --> Final output sent to browser
DEBUG - 2016-03-01 09:23:53 --> Total execution time: 1.2360
INFO - 2016-03-01 09:23:53 --> Config Class Initialized
INFO - 2016-03-01 09:23:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:23:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:23:53 --> Utf8 Class Initialized
INFO - 2016-03-01 09:23:53 --> URI Class Initialized
INFO - 2016-03-01 09:23:53 --> Router Class Initialized
INFO - 2016-03-01 09:23:53 --> Output Class Initialized
INFO - 2016-03-01 09:23:53 --> Security Class Initialized
DEBUG - 2016-03-01 09:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:23:53 --> Input Class Initialized
INFO - 2016-03-01 09:23:53 --> Language Class Initialized
ERROR - 2016-03-01 09:23:53 --> 404 Page Not Found: Null/index
INFO - 2016-03-01 09:25:12 --> Config Class Initialized
INFO - 2016-03-01 09:25:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:25:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:25:12 --> Utf8 Class Initialized
INFO - 2016-03-01 09:25:12 --> URI Class Initialized
INFO - 2016-03-01 09:25:12 --> Router Class Initialized
INFO - 2016-03-01 09:25:12 --> Output Class Initialized
INFO - 2016-03-01 09:25:12 --> Security Class Initialized
DEBUG - 2016-03-01 09:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:25:12 --> Input Class Initialized
INFO - 2016-03-01 09:25:12 --> Language Class Initialized
ERROR - 2016-03-01 09:25:12 --> 404 Page Not Found: Null/index
INFO - 2016-03-01 09:25:14 --> Config Class Initialized
INFO - 2016-03-01 09:25:14 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:25:14 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:25:14 --> Utf8 Class Initialized
INFO - 2016-03-01 09:25:14 --> URI Class Initialized
INFO - 2016-03-01 09:25:14 --> Router Class Initialized
INFO - 2016-03-01 09:25:14 --> Output Class Initialized
INFO - 2016-03-01 09:25:14 --> Security Class Initialized
DEBUG - 2016-03-01 09:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:25:14 --> Input Class Initialized
INFO - 2016-03-01 09:25:14 --> Language Class Initialized
INFO - 2016-03-01 09:25:14 --> Loader Class Initialized
INFO - 2016-03-01 09:25:14 --> Helper loaded: url_helper
INFO - 2016-03-01 09:25:14 --> Helper loaded: file_helper
INFO - 2016-03-01 09:25:14 --> Helper loaded: date_helper
INFO - 2016-03-01 09:25:14 --> Helper loaded: form_helper
INFO - 2016-03-01 09:25:14 --> Database Driver Class Initialized
INFO - 2016-03-01 09:25:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:25:15 --> Controller Class Initialized
INFO - 2016-03-01 09:25:15 --> Model Class Initialized
INFO - 2016-03-01 09:25:15 --> Model Class Initialized
INFO - 2016-03-01 09:25:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:25:15 --> Pagination Class Initialized
INFO - 2016-03-01 09:25:15 --> Helper loaded: text_helper
INFO - 2016-03-01 09:25:15 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:25:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:25:15 --> Final output sent to browser
DEBUG - 2016-03-01 12:25:15 --> Total execution time: 1.1645
INFO - 2016-03-01 09:25:40 --> Config Class Initialized
INFO - 2016-03-01 09:25:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:25:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:25:40 --> Utf8 Class Initialized
INFO - 2016-03-01 09:25:40 --> URI Class Initialized
INFO - 2016-03-01 09:25:40 --> Router Class Initialized
INFO - 2016-03-01 09:25:40 --> Output Class Initialized
INFO - 2016-03-01 09:25:40 --> Security Class Initialized
DEBUG - 2016-03-01 09:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:25:40 --> Input Class Initialized
INFO - 2016-03-01 09:25:40 --> Language Class Initialized
INFO - 2016-03-01 09:25:40 --> Loader Class Initialized
INFO - 2016-03-01 09:25:40 --> Helper loaded: url_helper
INFO - 2016-03-01 09:25:40 --> Helper loaded: file_helper
INFO - 2016-03-01 09:25:40 --> Helper loaded: date_helper
INFO - 2016-03-01 09:25:40 --> Helper loaded: form_helper
INFO - 2016-03-01 09:25:40 --> Database Driver Class Initialized
INFO - 2016-03-01 09:25:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:25:41 --> Controller Class Initialized
INFO - 2016-03-01 09:25:41 --> Model Class Initialized
INFO - 2016-03-01 09:25:41 --> Model Class Initialized
INFO - 2016-03-01 09:25:41 --> Form Validation Class Initialized
INFO - 2016-03-01 09:25:41 --> Helper loaded: text_helper
INFO - 2016-03-01 09:25:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:25:41 --> Final output sent to browser
DEBUG - 2016-03-01 09:25:41 --> Total execution time: 1.2387
INFO - 2016-03-01 09:25:42 --> Config Class Initialized
INFO - 2016-03-01 09:25:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:25:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:25:42 --> Utf8 Class Initialized
INFO - 2016-03-01 09:25:42 --> URI Class Initialized
INFO - 2016-03-01 09:25:42 --> Router Class Initialized
INFO - 2016-03-01 09:25:42 --> Output Class Initialized
INFO - 2016-03-01 09:25:42 --> Security Class Initialized
DEBUG - 2016-03-01 09:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:25:42 --> Input Class Initialized
INFO - 2016-03-01 09:25:42 --> Language Class Initialized
ERROR - 2016-03-01 09:25:42 --> 404 Page Not Found: Null/index
INFO - 2016-03-01 09:29:05 --> Config Class Initialized
INFO - 2016-03-01 09:29:05 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:29:05 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:29:05 --> Utf8 Class Initialized
INFO - 2016-03-01 09:29:05 --> URI Class Initialized
INFO - 2016-03-01 09:29:05 --> Router Class Initialized
INFO - 2016-03-01 09:29:05 --> Output Class Initialized
INFO - 2016-03-01 09:29:05 --> Security Class Initialized
DEBUG - 2016-03-01 09:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:29:05 --> Input Class Initialized
INFO - 2016-03-01 09:29:05 --> Language Class Initialized
INFO - 2016-03-01 09:29:05 --> Loader Class Initialized
INFO - 2016-03-01 09:29:05 --> Helper loaded: url_helper
INFO - 2016-03-01 09:29:05 --> Helper loaded: file_helper
INFO - 2016-03-01 09:29:05 --> Helper loaded: date_helper
INFO - 2016-03-01 09:29:05 --> Helper loaded: form_helper
INFO - 2016-03-01 09:29:05 --> Database Driver Class Initialized
INFO - 2016-03-01 09:29:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:29:06 --> Controller Class Initialized
INFO - 2016-03-01 09:29:06 --> Model Class Initialized
INFO - 2016-03-01 09:29:06 --> Model Class Initialized
INFO - 2016-03-01 09:29:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:29:06 --> Pagination Class Initialized
INFO - 2016-03-01 09:29:06 --> Helper loaded: text_helper
INFO - 2016-03-01 09:29:06 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:29:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:29:06 --> Final output sent to browser
DEBUG - 2016-03-01 12:29:06 --> Total execution time: 1.1846
INFO - 2016-03-01 09:30:34 --> Config Class Initialized
INFO - 2016-03-01 09:30:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:30:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:30:34 --> Utf8 Class Initialized
INFO - 2016-03-01 09:30:34 --> URI Class Initialized
INFO - 2016-03-01 09:30:34 --> Router Class Initialized
INFO - 2016-03-01 09:30:34 --> Output Class Initialized
INFO - 2016-03-01 09:30:34 --> Security Class Initialized
DEBUG - 2016-03-01 09:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:30:34 --> Input Class Initialized
INFO - 2016-03-01 09:30:34 --> Language Class Initialized
INFO - 2016-03-01 09:30:34 --> Loader Class Initialized
INFO - 2016-03-01 09:30:34 --> Helper loaded: url_helper
INFO - 2016-03-01 09:30:34 --> Helper loaded: file_helper
INFO - 2016-03-01 09:30:34 --> Helper loaded: date_helper
INFO - 2016-03-01 09:30:34 --> Helper loaded: form_helper
INFO - 2016-03-01 09:30:34 --> Database Driver Class Initialized
INFO - 2016-03-01 09:30:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:30:35 --> Controller Class Initialized
INFO - 2016-03-01 09:30:35 --> Model Class Initialized
INFO - 2016-03-01 09:30:35 --> Model Class Initialized
INFO - 2016-03-01 09:30:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:30:35 --> Pagination Class Initialized
INFO - 2016-03-01 09:30:35 --> Helper loaded: text_helper
INFO - 2016-03-01 09:30:35 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:30:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:30:35 --> Final output sent to browser
DEBUG - 2016-03-01 12:30:35 --> Total execution time: 1.1641
INFO - 2016-03-01 09:30:50 --> Config Class Initialized
INFO - 2016-03-01 09:30:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:30:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:30:50 --> Utf8 Class Initialized
INFO - 2016-03-01 09:30:50 --> URI Class Initialized
INFO - 2016-03-01 09:30:50 --> Router Class Initialized
INFO - 2016-03-01 09:30:50 --> Output Class Initialized
INFO - 2016-03-01 09:30:50 --> Security Class Initialized
DEBUG - 2016-03-01 09:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:30:50 --> Input Class Initialized
INFO - 2016-03-01 09:30:50 --> Language Class Initialized
INFO - 2016-03-01 09:30:50 --> Loader Class Initialized
INFO - 2016-03-01 09:30:50 --> Helper loaded: url_helper
INFO - 2016-03-01 09:30:50 --> Helper loaded: file_helper
INFO - 2016-03-01 09:30:50 --> Helper loaded: date_helper
INFO - 2016-03-01 09:30:50 --> Helper loaded: form_helper
INFO - 2016-03-01 09:30:50 --> Database Driver Class Initialized
INFO - 2016-03-01 09:30:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:30:51 --> Controller Class Initialized
INFO - 2016-03-01 09:30:51 --> Model Class Initialized
INFO - 2016-03-01 09:30:51 --> Model Class Initialized
INFO - 2016-03-01 09:30:51 --> Form Validation Class Initialized
INFO - 2016-03-01 09:30:51 --> Helper loaded: text_helper
INFO - 2016-03-01 09:30:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:30:51 --> Final output sent to browser
DEBUG - 2016-03-01 09:30:51 --> Total execution time: 1.2662
INFO - 2016-03-01 09:30:51 --> Config Class Initialized
INFO - 2016-03-01 09:30:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:30:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:30:51 --> Utf8 Class Initialized
INFO - 2016-03-01 09:30:51 --> URI Class Initialized
INFO - 2016-03-01 09:30:51 --> Router Class Initialized
INFO - 2016-03-01 09:30:51 --> Output Class Initialized
INFO - 2016-03-01 09:30:51 --> Security Class Initialized
DEBUG - 2016-03-01 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:30:51 --> Input Class Initialized
INFO - 2016-03-01 09:30:51 --> Language Class Initialized
ERROR - 2016-03-01 09:30:51 --> 404 Page Not Found: Null/index
INFO - 2016-03-01 09:31:56 --> Config Class Initialized
INFO - 2016-03-01 09:31:56 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:31:56 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:31:56 --> Utf8 Class Initialized
INFO - 2016-03-01 09:31:56 --> URI Class Initialized
INFO - 2016-03-01 09:31:56 --> Router Class Initialized
INFO - 2016-03-01 09:31:56 --> Output Class Initialized
INFO - 2016-03-01 09:31:56 --> Security Class Initialized
DEBUG - 2016-03-01 09:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:31:56 --> Input Class Initialized
INFO - 2016-03-01 09:31:56 --> Language Class Initialized
INFO - 2016-03-01 09:31:56 --> Loader Class Initialized
INFO - 2016-03-01 09:31:56 --> Helper loaded: url_helper
INFO - 2016-03-01 09:31:56 --> Helper loaded: file_helper
INFO - 2016-03-01 09:31:56 --> Helper loaded: date_helper
INFO - 2016-03-01 09:31:56 --> Helper loaded: form_helper
INFO - 2016-03-01 09:31:56 --> Database Driver Class Initialized
INFO - 2016-03-01 09:31:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:31:57 --> Controller Class Initialized
INFO - 2016-03-01 09:31:57 --> Model Class Initialized
INFO - 2016-03-01 09:31:57 --> Model Class Initialized
INFO - 2016-03-01 09:31:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:31:57 --> Pagination Class Initialized
INFO - 2016-03-01 09:31:57 --> Helper loaded: text_helper
INFO - 2016-03-01 09:31:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:31:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:31:57 --> Final output sent to browser
DEBUG - 2016-03-01 12:31:57 --> Total execution time: 1.1657
INFO - 2016-03-01 09:32:14 --> Config Class Initialized
INFO - 2016-03-01 09:32:14 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:32:14 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:32:14 --> Utf8 Class Initialized
INFO - 2016-03-01 09:32:14 --> URI Class Initialized
INFO - 2016-03-01 09:32:14 --> Router Class Initialized
INFO - 2016-03-01 09:32:14 --> Output Class Initialized
INFO - 2016-03-01 09:32:14 --> Security Class Initialized
DEBUG - 2016-03-01 09:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:32:14 --> Input Class Initialized
INFO - 2016-03-01 09:32:14 --> Language Class Initialized
INFO - 2016-03-01 09:32:14 --> Loader Class Initialized
INFO - 2016-03-01 09:32:14 --> Helper loaded: url_helper
INFO - 2016-03-01 09:32:14 --> Helper loaded: file_helper
INFO - 2016-03-01 09:32:14 --> Helper loaded: date_helper
INFO - 2016-03-01 09:32:14 --> Helper loaded: form_helper
INFO - 2016-03-01 09:32:14 --> Database Driver Class Initialized
INFO - 2016-03-01 09:32:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:32:15 --> Controller Class Initialized
INFO - 2016-03-01 09:32:15 --> Model Class Initialized
INFO - 2016-03-01 09:32:15 --> Model Class Initialized
INFO - 2016-03-01 09:32:15 --> Form Validation Class Initialized
INFO - 2016-03-01 09:32:15 --> Helper loaded: text_helper
INFO - 2016-03-01 09:32:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:32:15 --> Final output sent to browser
DEBUG - 2016-03-01 09:32:15 --> Total execution time: 1.2370
INFO - 2016-03-01 09:32:44 --> Config Class Initialized
INFO - 2016-03-01 09:32:44 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:32:44 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:32:44 --> Utf8 Class Initialized
INFO - 2016-03-01 09:32:44 --> URI Class Initialized
INFO - 2016-03-01 09:32:44 --> Router Class Initialized
INFO - 2016-03-01 09:32:44 --> Output Class Initialized
INFO - 2016-03-01 09:32:44 --> Security Class Initialized
DEBUG - 2016-03-01 09:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:32:44 --> Input Class Initialized
INFO - 2016-03-01 09:32:44 --> Language Class Initialized
INFO - 2016-03-01 09:32:44 --> Loader Class Initialized
INFO - 2016-03-01 09:32:44 --> Helper loaded: url_helper
INFO - 2016-03-01 09:32:44 --> Helper loaded: file_helper
INFO - 2016-03-01 09:32:44 --> Helper loaded: date_helper
INFO - 2016-03-01 09:32:44 --> Helper loaded: form_helper
INFO - 2016-03-01 09:32:44 --> Database Driver Class Initialized
INFO - 2016-03-01 09:32:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:32:45 --> Controller Class Initialized
INFO - 2016-03-01 09:32:45 --> Model Class Initialized
INFO - 2016-03-01 09:32:45 --> Model Class Initialized
INFO - 2016-03-01 09:32:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:32:45 --> Pagination Class Initialized
INFO - 2016-03-01 09:32:45 --> Helper loaded: text_helper
INFO - 2016-03-01 09:32:45 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 12:32:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:32:45 --> Final output sent to browser
DEBUG - 2016-03-01 12:32:45 --> Total execution time: 1.1623
INFO - 2016-03-01 09:32:58 --> Config Class Initialized
INFO - 2016-03-01 09:32:58 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:32:58 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:32:58 --> Utf8 Class Initialized
INFO - 2016-03-01 09:32:58 --> URI Class Initialized
INFO - 2016-03-01 09:32:58 --> Router Class Initialized
INFO - 2016-03-01 09:32:58 --> Output Class Initialized
INFO - 2016-03-01 09:32:58 --> Security Class Initialized
DEBUG - 2016-03-01 09:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:32:58 --> Input Class Initialized
INFO - 2016-03-01 09:32:58 --> Language Class Initialized
INFO - 2016-03-01 09:32:58 --> Loader Class Initialized
INFO - 2016-03-01 09:32:58 --> Helper loaded: url_helper
INFO - 2016-03-01 09:32:58 --> Helper loaded: file_helper
INFO - 2016-03-01 09:32:58 --> Helper loaded: date_helper
INFO - 2016-03-01 09:32:58 --> Helper loaded: form_helper
INFO - 2016-03-01 09:32:58 --> Database Driver Class Initialized
INFO - 2016-03-01 09:32:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:32:59 --> Controller Class Initialized
INFO - 2016-03-01 09:32:59 --> Model Class Initialized
INFO - 2016-03-01 09:32:59 --> Model Class Initialized
INFO - 2016-03-01 09:32:59 --> Form Validation Class Initialized
INFO - 2016-03-01 09:32:59 --> Helper loaded: text_helper
INFO - 2016-03-01 09:32:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:32:59 --> Final output sent to browser
DEBUG - 2016-03-01 09:32:59 --> Total execution time: 1.2217
INFO - 2016-03-01 09:32:59 --> Config Class Initialized
INFO - 2016-03-01 09:32:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:32:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:32:59 --> Utf8 Class Initialized
INFO - 2016-03-01 09:32:59 --> URI Class Initialized
DEBUG - 2016-03-01 09:32:59 --> No URI present. Default controller set.
INFO - 2016-03-01 09:32:59 --> Router Class Initialized
INFO - 2016-03-01 09:32:59 --> Output Class Initialized
INFO - 2016-03-01 09:32:59 --> Security Class Initialized
DEBUG - 2016-03-01 09:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:32:59 --> Input Class Initialized
INFO - 2016-03-01 09:32:59 --> Language Class Initialized
INFO - 2016-03-01 09:32:59 --> Loader Class Initialized
INFO - 2016-03-01 09:32:59 --> Helper loaded: url_helper
INFO - 2016-03-01 09:32:59 --> Helper loaded: file_helper
INFO - 2016-03-01 09:32:59 --> Helper loaded: date_helper
INFO - 2016-03-01 09:32:59 --> Helper loaded: form_helper
INFO - 2016-03-01 09:32:59 --> Database Driver Class Initialized
INFO - 2016-03-01 09:33:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:33:00 --> Controller Class Initialized
INFO - 2016-03-01 09:33:00 --> Model Class Initialized
INFO - 2016-03-01 09:33:00 --> Model Class Initialized
INFO - 2016-03-01 09:33:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:33:00 --> Pagination Class Initialized
INFO - 2016-03-01 09:33:00 --> Helper loaded: text_helper
INFO - 2016-03-01 09:33:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:33:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:33:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:33:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 12:33:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:33:00 --> Final output sent to browser
DEBUG - 2016-03-01 12:33:00 --> Total execution time: 1.1615
INFO - 2016-03-01 09:36:37 --> Config Class Initialized
INFO - 2016-03-01 09:36:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:36:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:36:37 --> Utf8 Class Initialized
INFO - 2016-03-01 09:36:37 --> URI Class Initialized
DEBUG - 2016-03-01 09:36:37 --> No URI present. Default controller set.
INFO - 2016-03-01 09:36:37 --> Router Class Initialized
INFO - 2016-03-01 09:36:37 --> Output Class Initialized
INFO - 2016-03-01 09:36:37 --> Security Class Initialized
DEBUG - 2016-03-01 09:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:36:37 --> Input Class Initialized
INFO - 2016-03-01 09:36:37 --> Language Class Initialized
INFO - 2016-03-01 09:36:37 --> Loader Class Initialized
INFO - 2016-03-01 09:36:37 --> Helper loaded: url_helper
INFO - 2016-03-01 09:36:37 --> Helper loaded: file_helper
INFO - 2016-03-01 09:36:37 --> Helper loaded: date_helper
INFO - 2016-03-01 09:36:37 --> Helper loaded: form_helper
INFO - 2016-03-01 09:36:37 --> Database Driver Class Initialized
INFO - 2016-03-01 09:36:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:36:38 --> Controller Class Initialized
INFO - 2016-03-01 09:36:38 --> Model Class Initialized
INFO - 2016-03-01 09:36:38 --> Model Class Initialized
INFO - 2016-03-01 09:36:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:36:38 --> Pagination Class Initialized
INFO - 2016-03-01 09:36:38 --> Helper loaded: text_helper
INFO - 2016-03-01 09:36:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 12:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:36:39 --> Final output sent to browser
DEBUG - 2016-03-01 12:36:39 --> Total execution time: 1.1605
INFO - 2016-03-01 09:36:56 --> Config Class Initialized
INFO - 2016-03-01 09:36:56 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:36:56 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:36:56 --> Utf8 Class Initialized
INFO - 2016-03-01 09:36:56 --> URI Class Initialized
INFO - 2016-03-01 09:36:56 --> Router Class Initialized
INFO - 2016-03-01 09:36:56 --> Output Class Initialized
INFO - 2016-03-01 09:36:56 --> Security Class Initialized
DEBUG - 2016-03-01 09:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:36:56 --> Input Class Initialized
INFO - 2016-03-01 09:36:56 --> Language Class Initialized
INFO - 2016-03-01 09:36:56 --> Loader Class Initialized
INFO - 2016-03-01 09:36:56 --> Helper loaded: url_helper
INFO - 2016-03-01 09:36:56 --> Helper loaded: file_helper
INFO - 2016-03-01 09:36:56 --> Helper loaded: date_helper
INFO - 2016-03-01 09:36:56 --> Helper loaded: form_helper
INFO - 2016-03-01 09:36:56 --> Database Driver Class Initialized
INFO - 2016-03-01 09:36:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:36:57 --> Controller Class Initialized
INFO - 2016-03-01 09:36:57 --> Model Class Initialized
INFO - 2016-03-01 09:36:57 --> Model Class Initialized
INFO - 2016-03-01 09:36:57 --> Form Validation Class Initialized
INFO - 2016-03-01 09:36:57 --> Helper loaded: text_helper
INFO - 2016-03-01 09:36:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 09:36:57 --> Final output sent to browser
DEBUG - 2016-03-01 09:36:57 --> Total execution time: 1.2123
INFO - 2016-03-01 09:36:59 --> Config Class Initialized
INFO - 2016-03-01 09:36:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 09:36:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 09:36:59 --> Utf8 Class Initialized
INFO - 2016-03-01 09:36:59 --> URI Class Initialized
DEBUG - 2016-03-01 09:36:59 --> No URI present. Default controller set.
INFO - 2016-03-01 09:36:59 --> Router Class Initialized
INFO - 2016-03-01 09:36:59 --> Output Class Initialized
INFO - 2016-03-01 09:36:59 --> Security Class Initialized
DEBUG - 2016-03-01 09:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 09:36:59 --> Input Class Initialized
INFO - 2016-03-01 09:36:59 --> Language Class Initialized
INFO - 2016-03-01 09:36:59 --> Loader Class Initialized
INFO - 2016-03-01 09:36:59 --> Helper loaded: url_helper
INFO - 2016-03-01 09:36:59 --> Helper loaded: file_helper
INFO - 2016-03-01 09:36:59 --> Helper loaded: date_helper
INFO - 2016-03-01 09:36:59 --> Helper loaded: form_helper
INFO - 2016-03-01 09:36:59 --> Database Driver Class Initialized
INFO - 2016-03-01 09:37:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 09:37:00 --> Controller Class Initialized
INFO - 2016-03-01 09:37:00 --> Model Class Initialized
INFO - 2016-03-01 09:37:00 --> Model Class Initialized
INFO - 2016-03-01 09:37:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 09:37:00 --> Pagination Class Initialized
INFO - 2016-03-01 09:37:00 --> Helper loaded: text_helper
INFO - 2016-03-01 09:37:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 12:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 12:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 12:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 12:37:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 12:37:00 --> Final output sent to browser
DEBUG - 2016-03-01 12:37:00 --> Total execution time: 1.1284
INFO - 2016-03-01 10:07:40 --> Config Class Initialized
INFO - 2016-03-01 10:07:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:07:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:07:40 --> Utf8 Class Initialized
INFO - 2016-03-01 10:07:40 --> URI Class Initialized
DEBUG - 2016-03-01 10:07:40 --> No URI present. Default controller set.
INFO - 2016-03-01 10:07:40 --> Router Class Initialized
INFO - 2016-03-01 10:07:40 --> Output Class Initialized
INFO - 2016-03-01 10:07:40 --> Security Class Initialized
DEBUG - 2016-03-01 10:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:07:40 --> Input Class Initialized
INFO - 2016-03-01 10:07:40 --> Language Class Initialized
INFO - 2016-03-01 10:07:40 --> Loader Class Initialized
INFO - 2016-03-01 10:07:40 --> Helper loaded: url_helper
INFO - 2016-03-01 10:07:40 --> Helper loaded: file_helper
INFO - 2016-03-01 10:07:40 --> Helper loaded: date_helper
INFO - 2016-03-01 10:07:40 --> Helper loaded: form_helper
INFO - 2016-03-01 10:07:40 --> Database Driver Class Initialized
INFO - 2016-03-01 10:07:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:07:41 --> Controller Class Initialized
INFO - 2016-03-01 10:07:41 --> Model Class Initialized
INFO - 2016-03-01 10:07:41 --> Model Class Initialized
INFO - 2016-03-01 10:07:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:07:41 --> Pagination Class Initialized
INFO - 2016-03-01 10:07:41 --> Helper loaded: text_helper
INFO - 2016-03-01 10:07:41 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:07:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:07:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:07:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 13:07:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:07:41 --> Final output sent to browser
DEBUG - 2016-03-01 13:07:41 --> Total execution time: 1.1490
INFO - 2016-03-01 10:08:33 --> Config Class Initialized
INFO - 2016-03-01 10:08:33 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:08:33 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:08:33 --> Utf8 Class Initialized
INFO - 2016-03-01 10:08:33 --> URI Class Initialized
INFO - 2016-03-01 10:08:33 --> Router Class Initialized
INFO - 2016-03-01 10:08:33 --> Output Class Initialized
INFO - 2016-03-01 10:08:33 --> Security Class Initialized
DEBUG - 2016-03-01 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:08:33 --> Input Class Initialized
INFO - 2016-03-01 10:08:33 --> Language Class Initialized
INFO - 2016-03-01 10:08:33 --> Loader Class Initialized
INFO - 2016-03-01 10:08:33 --> Helper loaded: url_helper
INFO - 2016-03-01 10:08:33 --> Helper loaded: file_helper
INFO - 2016-03-01 10:08:33 --> Helper loaded: date_helper
INFO - 2016-03-01 10:08:33 --> Helper loaded: form_helper
INFO - 2016-03-01 10:08:33 --> Database Driver Class Initialized
INFO - 2016-03-01 10:08:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:08:34 --> Controller Class Initialized
INFO - 2016-03-01 10:08:34 --> Model Class Initialized
INFO - 2016-03-01 10:08:34 --> Model Class Initialized
INFO - 2016-03-01 10:08:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:08:34 --> Pagination Class Initialized
INFO - 2016-03-01 10:08:34 --> Helper loaded: text_helper
INFO - 2016-03-01 10:08:34 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:08:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:08:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:08:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 13:08:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:08:34 --> Final output sent to browser
DEBUG - 2016-03-01 13:08:34 --> Total execution time: 1.1356
INFO - 2016-03-01 10:08:37 --> Config Class Initialized
INFO - 2016-03-01 10:08:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:08:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:08:37 --> Utf8 Class Initialized
INFO - 2016-03-01 10:08:37 --> URI Class Initialized
INFO - 2016-03-01 10:08:37 --> Router Class Initialized
INFO - 2016-03-01 10:08:37 --> Output Class Initialized
INFO - 2016-03-01 10:08:37 --> Security Class Initialized
DEBUG - 2016-03-01 10:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:08:37 --> Input Class Initialized
INFO - 2016-03-01 10:08:37 --> Language Class Initialized
INFO - 2016-03-01 10:08:37 --> Loader Class Initialized
INFO - 2016-03-01 10:08:37 --> Helper loaded: url_helper
INFO - 2016-03-01 10:08:37 --> Helper loaded: file_helper
INFO - 2016-03-01 10:08:37 --> Helper loaded: date_helper
INFO - 2016-03-01 10:08:37 --> Helper loaded: form_helper
INFO - 2016-03-01 10:08:37 --> Database Driver Class Initialized
INFO - 2016-03-01 10:08:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:08:38 --> Controller Class Initialized
INFO - 2016-03-01 10:08:38 --> Model Class Initialized
INFO - 2016-03-01 10:08:38 --> Model Class Initialized
INFO - 2016-03-01 10:08:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:08:38 --> Pagination Class Initialized
INFO - 2016-03-01 10:08:38 --> Helper loaded: text_helper
INFO - 2016-03-01 10:08:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 13:08:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:08:38 --> Final output sent to browser
DEBUG - 2016-03-01 13:08:38 --> Total execution time: 1.1265
INFO - 2016-03-01 10:08:40 --> Config Class Initialized
INFO - 2016-03-01 10:08:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:08:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:08:40 --> Utf8 Class Initialized
INFO - 2016-03-01 10:08:40 --> URI Class Initialized
INFO - 2016-03-01 10:08:40 --> Router Class Initialized
INFO - 2016-03-01 10:08:40 --> Output Class Initialized
INFO - 2016-03-01 10:08:40 --> Security Class Initialized
DEBUG - 2016-03-01 10:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:08:40 --> Input Class Initialized
INFO - 2016-03-01 10:08:40 --> Language Class Initialized
INFO - 2016-03-01 10:08:40 --> Loader Class Initialized
INFO - 2016-03-01 10:08:40 --> Helper loaded: url_helper
INFO - 2016-03-01 10:08:40 --> Helper loaded: file_helper
INFO - 2016-03-01 10:08:40 --> Helper loaded: date_helper
INFO - 2016-03-01 10:08:40 --> Helper loaded: form_helper
INFO - 2016-03-01 10:08:40 --> Database Driver Class Initialized
INFO - 2016-03-01 10:08:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:08:41 --> Controller Class Initialized
INFO - 2016-03-01 10:08:41 --> Model Class Initialized
INFO - 2016-03-01 10:08:41 --> Model Class Initialized
INFO - 2016-03-01 10:08:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:08:41 --> Pagination Class Initialized
INFO - 2016-03-01 10:08:41 --> Helper loaded: text_helper
INFO - 2016-03-01 10:08:41 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 13:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:08:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:08:41 --> Final output sent to browser
DEBUG - 2016-03-01 13:08:41 --> Total execution time: 1.2255
INFO - 2016-03-01 10:47:16 --> Config Class Initialized
INFO - 2016-03-01 10:47:16 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:47:16 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:47:16 --> Utf8 Class Initialized
INFO - 2016-03-01 10:47:16 --> URI Class Initialized
DEBUG - 2016-03-01 10:47:16 --> No URI present. Default controller set.
INFO - 2016-03-01 10:47:16 --> Router Class Initialized
INFO - 2016-03-01 10:47:16 --> Output Class Initialized
INFO - 2016-03-01 10:47:16 --> Security Class Initialized
DEBUG - 2016-03-01 10:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:47:16 --> Input Class Initialized
INFO - 2016-03-01 10:47:16 --> Language Class Initialized
INFO - 2016-03-01 10:47:16 --> Loader Class Initialized
INFO - 2016-03-01 10:47:16 --> Helper loaded: url_helper
INFO - 2016-03-01 10:47:16 --> Helper loaded: file_helper
INFO - 2016-03-01 10:47:16 --> Helper loaded: date_helper
INFO - 2016-03-01 10:47:16 --> Helper loaded: form_helper
INFO - 2016-03-01 10:47:16 --> Database Driver Class Initialized
INFO - 2016-03-01 10:47:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:47:17 --> Controller Class Initialized
INFO - 2016-03-01 10:47:17 --> Model Class Initialized
INFO - 2016-03-01 10:47:17 --> Model Class Initialized
INFO - 2016-03-01 10:47:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:47:17 --> Pagination Class Initialized
INFO - 2016-03-01 10:47:17 --> Helper loaded: text_helper
INFO - 2016-03-01 10:47:17 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 13:47:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:47:17 --> Final output sent to browser
DEBUG - 2016-03-01 13:47:17 --> Total execution time: 1.1317
INFO - 2016-03-01 10:47:29 --> Config Class Initialized
INFO - 2016-03-01 10:47:29 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:47:29 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:47:29 --> Utf8 Class Initialized
INFO - 2016-03-01 10:47:29 --> URI Class Initialized
INFO - 2016-03-01 10:47:29 --> Router Class Initialized
INFO - 2016-03-01 10:47:29 --> Output Class Initialized
INFO - 2016-03-01 10:47:29 --> Security Class Initialized
DEBUG - 2016-03-01 10:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:47:29 --> Input Class Initialized
INFO - 2016-03-01 10:47:29 --> Language Class Initialized
INFO - 2016-03-01 10:47:29 --> Loader Class Initialized
INFO - 2016-03-01 10:47:29 --> Helper loaded: url_helper
INFO - 2016-03-01 10:47:29 --> Helper loaded: file_helper
INFO - 2016-03-01 10:47:29 --> Helper loaded: date_helper
INFO - 2016-03-01 10:47:29 --> Helper loaded: form_helper
INFO - 2016-03-01 10:47:29 --> Database Driver Class Initialized
INFO - 2016-03-01 10:47:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:47:30 --> Controller Class Initialized
INFO - 2016-03-01 10:47:30 --> Model Class Initialized
INFO - 2016-03-01 10:47:30 --> Model Class Initialized
INFO - 2016-03-01 10:47:30 --> Form Validation Class Initialized
INFO - 2016-03-01 10:47:30 --> Helper loaded: text_helper
INFO - 2016-03-01 10:47:30 --> Final output sent to browser
DEBUG - 2016-03-01 10:47:30 --> Total execution time: 1.1991
INFO - 2016-03-01 10:47:30 --> Config Class Initialized
INFO - 2016-03-01 10:47:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:47:30 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:47:30 --> Utf8 Class Initialized
INFO - 2016-03-01 10:47:30 --> URI Class Initialized
DEBUG - 2016-03-01 10:47:30 --> No URI present. Default controller set.
INFO - 2016-03-01 10:47:30 --> Router Class Initialized
INFO - 2016-03-01 10:47:30 --> Output Class Initialized
INFO - 2016-03-01 10:47:30 --> Security Class Initialized
DEBUG - 2016-03-01 10:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:47:30 --> Input Class Initialized
INFO - 2016-03-01 10:47:30 --> Language Class Initialized
INFO - 2016-03-01 10:47:30 --> Loader Class Initialized
INFO - 2016-03-01 10:47:30 --> Helper loaded: url_helper
INFO - 2016-03-01 10:47:30 --> Helper loaded: file_helper
INFO - 2016-03-01 10:47:30 --> Helper loaded: date_helper
INFO - 2016-03-01 10:47:30 --> Helper loaded: form_helper
INFO - 2016-03-01 10:47:30 --> Database Driver Class Initialized
INFO - 2016-03-01 10:47:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:47:31 --> Controller Class Initialized
INFO - 2016-03-01 10:47:31 --> Model Class Initialized
INFO - 2016-03-01 10:47:31 --> Model Class Initialized
INFO - 2016-03-01 10:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:47:31 --> Pagination Class Initialized
INFO - 2016-03-01 10:47:31 --> Helper loaded: text_helper
INFO - 2016-03-01 10:47:31 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 13:47:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:47:31 --> Final output sent to browser
DEBUG - 2016-03-01 13:47:31 --> Total execution time: 1.1664
INFO - 2016-03-01 10:47:34 --> Config Class Initialized
INFO - 2016-03-01 10:47:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:47:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:47:35 --> Utf8 Class Initialized
INFO - 2016-03-01 10:47:35 --> URI Class Initialized
INFO - 2016-03-01 10:47:35 --> Router Class Initialized
INFO - 2016-03-01 10:47:35 --> Output Class Initialized
INFO - 2016-03-01 10:47:35 --> Security Class Initialized
DEBUG - 2016-03-01 10:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:47:35 --> Input Class Initialized
INFO - 2016-03-01 10:47:35 --> Language Class Initialized
INFO - 2016-03-01 10:47:35 --> Loader Class Initialized
INFO - 2016-03-01 10:47:35 --> Helper loaded: url_helper
INFO - 2016-03-01 10:47:35 --> Helper loaded: file_helper
INFO - 2016-03-01 10:47:35 --> Helper loaded: date_helper
INFO - 2016-03-01 10:47:35 --> Helper loaded: form_helper
INFO - 2016-03-01 10:47:35 --> Database Driver Class Initialized
INFO - 2016-03-01 10:47:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:47:36 --> Controller Class Initialized
INFO - 2016-03-01 10:47:36 --> Model Class Initialized
INFO - 2016-03-01 10:47:36 --> Model Class Initialized
INFO - 2016-03-01 10:47:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:47:36 --> Pagination Class Initialized
INFO - 2016-03-01 10:47:36 --> Helper loaded: text_helper
INFO - 2016-03-01 10:47:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 13:47:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:47:36 --> Final output sent to browser
DEBUG - 2016-03-01 13:47:36 --> Total execution time: 1.1776
INFO - 2016-03-01 10:47:38 --> Config Class Initialized
INFO - 2016-03-01 10:47:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:47:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:47:38 --> Utf8 Class Initialized
INFO - 2016-03-01 10:47:38 --> URI Class Initialized
INFO - 2016-03-01 10:47:38 --> Router Class Initialized
INFO - 2016-03-01 10:47:38 --> Output Class Initialized
INFO - 2016-03-01 10:47:38 --> Security Class Initialized
DEBUG - 2016-03-01 10:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:47:38 --> Input Class Initialized
INFO - 2016-03-01 10:47:38 --> Language Class Initialized
INFO - 2016-03-01 10:47:38 --> Loader Class Initialized
INFO - 2016-03-01 10:47:38 --> Helper loaded: url_helper
INFO - 2016-03-01 10:47:38 --> Helper loaded: file_helper
INFO - 2016-03-01 10:47:38 --> Helper loaded: date_helper
INFO - 2016-03-01 10:47:38 --> Helper loaded: form_helper
INFO - 2016-03-01 10:47:38 --> Database Driver Class Initialized
INFO - 2016-03-01 10:47:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:47:39 --> Controller Class Initialized
INFO - 2016-03-01 10:47:39 --> Model Class Initialized
INFO - 2016-03-01 10:47:39 --> Model Class Initialized
INFO - 2016-03-01 10:47:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:47:39 --> Pagination Class Initialized
INFO - 2016-03-01 10:47:39 --> Helper loaded: text_helper
INFO - 2016-03-01 10:47:39 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:47:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:47:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 13:47:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:47:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:47:40 --> Final output sent to browser
DEBUG - 2016-03-01 13:47:40 --> Total execution time: 1.1700
INFO - 2016-03-01 10:47:43 --> Config Class Initialized
INFO - 2016-03-01 10:47:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:47:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:47:43 --> Utf8 Class Initialized
INFO - 2016-03-01 10:47:43 --> URI Class Initialized
INFO - 2016-03-01 10:47:43 --> Router Class Initialized
INFO - 2016-03-01 10:47:43 --> Output Class Initialized
INFO - 2016-03-01 10:47:43 --> Security Class Initialized
DEBUG - 2016-03-01 10:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:47:43 --> Input Class Initialized
INFO - 2016-03-01 10:47:43 --> Language Class Initialized
INFO - 2016-03-01 10:47:43 --> Loader Class Initialized
INFO - 2016-03-01 10:47:43 --> Helper loaded: url_helper
INFO - 2016-03-01 10:47:43 --> Helper loaded: file_helper
INFO - 2016-03-01 10:47:43 --> Helper loaded: date_helper
INFO - 2016-03-01 10:47:43 --> Helper loaded: form_helper
INFO - 2016-03-01 10:47:43 --> Database Driver Class Initialized
INFO - 2016-03-01 10:47:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:47:44 --> Controller Class Initialized
INFO - 2016-03-01 10:47:44 --> Model Class Initialized
INFO - 2016-03-01 10:47:44 --> Model Class Initialized
INFO - 2016-03-01 10:47:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:47:44 --> Pagination Class Initialized
INFO - 2016-03-01 10:47:44 --> Helper loaded: text_helper
INFO - 2016-03-01 10:47:44 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 13:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:47:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:47:44 --> Final output sent to browser
DEBUG - 2016-03-01 13:47:44 --> Total execution time: 1.1465
INFO - 2016-03-01 10:47:44 --> Config Class Initialized
INFO - 2016-03-01 10:47:44 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:47:44 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:47:44 --> Utf8 Class Initialized
INFO - 2016-03-01 10:47:44 --> URI Class Initialized
INFO - 2016-03-01 10:47:44 --> Router Class Initialized
INFO - 2016-03-01 10:47:44 --> Output Class Initialized
INFO - 2016-03-01 10:47:44 --> Security Class Initialized
DEBUG - 2016-03-01 10:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:47:44 --> Input Class Initialized
INFO - 2016-03-01 10:47:44 --> Language Class Initialized
INFO - 2016-03-01 10:47:44 --> Loader Class Initialized
INFO - 2016-03-01 10:47:44 --> Helper loaded: url_helper
INFO - 2016-03-01 10:47:44 --> Helper loaded: file_helper
INFO - 2016-03-01 10:47:44 --> Helper loaded: date_helper
INFO - 2016-03-01 10:47:44 --> Helper loaded: form_helper
INFO - 2016-03-01 10:47:44 --> Database Driver Class Initialized
INFO - 2016-03-01 10:47:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:47:45 --> Controller Class Initialized
INFO - 2016-03-01 10:47:45 --> Model Class Initialized
INFO - 2016-03-01 10:47:45 --> Model Class Initialized
INFO - 2016-03-01 10:47:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:47:45 --> Pagination Class Initialized
INFO - 2016-03-01 10:47:45 --> Helper loaded: text_helper
INFO - 2016-03-01 10:47:45 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 13:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:47:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:47:45 --> Final output sent to browser
DEBUG - 2016-03-01 13:47:45 --> Total execution time: 1.1834
INFO - 2016-03-01 10:54:12 --> Config Class Initialized
INFO - 2016-03-01 10:54:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:54:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:54:12 --> Utf8 Class Initialized
INFO - 2016-03-01 10:54:12 --> URI Class Initialized
INFO - 2016-03-01 10:54:12 --> Router Class Initialized
INFO - 2016-03-01 10:54:12 --> Output Class Initialized
INFO - 2016-03-01 10:54:12 --> Security Class Initialized
DEBUG - 2016-03-01 10:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:54:12 --> Input Class Initialized
INFO - 2016-03-01 10:54:12 --> Language Class Initialized
INFO - 2016-03-01 10:54:12 --> Loader Class Initialized
INFO - 2016-03-01 10:54:12 --> Helper loaded: url_helper
INFO - 2016-03-01 10:54:12 --> Helper loaded: file_helper
INFO - 2016-03-01 10:54:12 --> Helper loaded: date_helper
INFO - 2016-03-01 10:54:12 --> Helper loaded: form_helper
INFO - 2016-03-01 10:54:12 --> Database Driver Class Initialized
INFO - 2016-03-01 10:54:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:54:13 --> Controller Class Initialized
INFO - 2016-03-01 10:54:13 --> Model Class Initialized
INFO - 2016-03-01 10:54:13 --> Model Class Initialized
INFO - 2016-03-01 10:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:54:13 --> Pagination Class Initialized
INFO - 2016-03-01 10:54:13 --> Helper loaded: text_helper
INFO - 2016-03-01 10:54:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 13:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:54:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:54:13 --> Final output sent to browser
DEBUG - 2016-03-01 13:54:13 --> Total execution time: 1.1304
INFO - 2016-03-01 10:54:13 --> Config Class Initialized
INFO - 2016-03-01 10:54:13 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:54:13 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:54:13 --> Utf8 Class Initialized
INFO - 2016-03-01 10:54:13 --> URI Class Initialized
INFO - 2016-03-01 10:54:13 --> Router Class Initialized
INFO - 2016-03-01 10:54:13 --> Output Class Initialized
INFO - 2016-03-01 10:54:13 --> Security Class Initialized
DEBUG - 2016-03-01 10:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:54:13 --> Input Class Initialized
INFO - 2016-03-01 10:54:13 --> Language Class Initialized
INFO - 2016-03-01 10:54:13 --> Loader Class Initialized
INFO - 2016-03-01 10:54:13 --> Helper loaded: url_helper
INFO - 2016-03-01 10:54:13 --> Helper loaded: file_helper
INFO - 2016-03-01 10:54:13 --> Helper loaded: date_helper
INFO - 2016-03-01 10:54:13 --> Helper loaded: form_helper
INFO - 2016-03-01 10:54:13 --> Database Driver Class Initialized
INFO - 2016-03-01 10:54:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:54:14 --> Controller Class Initialized
INFO - 2016-03-01 10:54:14 --> Model Class Initialized
INFO - 2016-03-01 10:54:14 --> Model Class Initialized
INFO - 2016-03-01 10:54:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:54:14 --> Pagination Class Initialized
INFO - 2016-03-01 10:54:14 --> Helper loaded: text_helper
INFO - 2016-03-01 10:54:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 13:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:54:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:54:14 --> Final output sent to browser
DEBUG - 2016-03-01 13:54:14 --> Total execution time: 1.1487
INFO - 2016-03-01 10:54:56 --> Config Class Initialized
INFO - 2016-03-01 10:54:56 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:54:56 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:54:56 --> Utf8 Class Initialized
INFO - 2016-03-01 10:54:56 --> URI Class Initialized
INFO - 2016-03-01 10:54:56 --> Router Class Initialized
INFO - 2016-03-01 10:54:56 --> Output Class Initialized
INFO - 2016-03-01 10:54:56 --> Security Class Initialized
DEBUG - 2016-03-01 10:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:54:56 --> Input Class Initialized
INFO - 2016-03-01 10:54:56 --> Language Class Initialized
INFO - 2016-03-01 10:54:56 --> Loader Class Initialized
INFO - 2016-03-01 10:54:56 --> Helper loaded: url_helper
INFO - 2016-03-01 10:54:56 --> Helper loaded: file_helper
INFO - 2016-03-01 10:54:56 --> Helper loaded: date_helper
INFO - 2016-03-01 10:54:56 --> Helper loaded: form_helper
INFO - 2016-03-01 10:54:56 --> Database Driver Class Initialized
INFO - 2016-03-01 10:54:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:54:57 --> Controller Class Initialized
INFO - 2016-03-01 10:54:57 --> Model Class Initialized
INFO - 2016-03-01 10:54:57 --> Model Class Initialized
INFO - 2016-03-01 10:54:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:54:57 --> Pagination Class Initialized
INFO - 2016-03-01 10:54:57 --> Helper loaded: text_helper
INFO - 2016-03-01 10:54:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 13:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:54:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:54:57 --> Final output sent to browser
DEBUG - 2016-03-01 13:54:57 --> Total execution time: 1.1680
INFO - 2016-03-01 10:54:57 --> Config Class Initialized
INFO - 2016-03-01 10:54:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:54:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:54:57 --> Utf8 Class Initialized
INFO - 2016-03-01 10:54:57 --> URI Class Initialized
INFO - 2016-03-01 10:54:57 --> Router Class Initialized
INFO - 2016-03-01 10:54:57 --> Output Class Initialized
INFO - 2016-03-01 10:54:57 --> Security Class Initialized
DEBUG - 2016-03-01 10:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:54:57 --> Input Class Initialized
INFO - 2016-03-01 10:54:57 --> Language Class Initialized
INFO - 2016-03-01 10:54:57 --> Loader Class Initialized
INFO - 2016-03-01 10:54:57 --> Helper loaded: url_helper
INFO - 2016-03-01 10:54:57 --> Helper loaded: file_helper
INFO - 2016-03-01 10:54:57 --> Helper loaded: date_helper
INFO - 2016-03-01 10:54:57 --> Helper loaded: form_helper
INFO - 2016-03-01 10:54:57 --> Database Driver Class Initialized
INFO - 2016-03-01 10:54:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:54:58 --> Controller Class Initialized
INFO - 2016-03-01 10:54:58 --> Model Class Initialized
INFO - 2016-03-01 10:54:58 --> Model Class Initialized
INFO - 2016-03-01 10:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:54:58 --> Pagination Class Initialized
INFO - 2016-03-01 10:54:58 --> Helper loaded: text_helper
INFO - 2016-03-01 10:54:58 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 13:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:54:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:54:59 --> Final output sent to browser
DEBUG - 2016-03-01 13:54:59 --> Total execution time: 1.1660
INFO - 2016-03-01 10:59:42 --> Config Class Initialized
INFO - 2016-03-01 10:59:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:59:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:59:42 --> Utf8 Class Initialized
INFO - 2016-03-01 10:59:42 --> URI Class Initialized
INFO - 2016-03-01 10:59:42 --> Router Class Initialized
INFO - 2016-03-01 10:59:42 --> Output Class Initialized
INFO - 2016-03-01 10:59:42 --> Security Class Initialized
DEBUG - 2016-03-01 10:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:59:42 --> Input Class Initialized
INFO - 2016-03-01 10:59:42 --> Language Class Initialized
INFO - 2016-03-01 10:59:42 --> Loader Class Initialized
INFO - 2016-03-01 10:59:42 --> Helper loaded: url_helper
INFO - 2016-03-01 10:59:42 --> Helper loaded: file_helper
INFO - 2016-03-01 10:59:42 --> Helper loaded: date_helper
INFO - 2016-03-01 10:59:42 --> Helper loaded: form_helper
INFO - 2016-03-01 10:59:42 --> Database Driver Class Initialized
INFO - 2016-03-01 10:59:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:59:43 --> Controller Class Initialized
INFO - 2016-03-01 10:59:43 --> Model Class Initialized
INFO - 2016-03-01 10:59:43 --> Model Class Initialized
INFO - 2016-03-01 10:59:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:59:43 --> Pagination Class Initialized
INFO - 2016-03-01 10:59:43 --> Helper loaded: text_helper
INFO - 2016-03-01 10:59:43 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:59:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:59:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:59:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 13:59:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:59:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:59:43 --> Final output sent to browser
DEBUG - 2016-03-01 13:59:43 --> Total execution time: 1.1199
INFO - 2016-03-01 10:59:43 --> Config Class Initialized
INFO - 2016-03-01 10:59:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 10:59:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 10:59:43 --> Utf8 Class Initialized
INFO - 2016-03-01 10:59:43 --> URI Class Initialized
INFO - 2016-03-01 10:59:43 --> Router Class Initialized
INFO - 2016-03-01 10:59:43 --> Output Class Initialized
INFO - 2016-03-01 10:59:43 --> Security Class Initialized
DEBUG - 2016-03-01 10:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 10:59:43 --> Input Class Initialized
INFO - 2016-03-01 10:59:43 --> Language Class Initialized
INFO - 2016-03-01 10:59:43 --> Loader Class Initialized
INFO - 2016-03-01 10:59:43 --> Helper loaded: url_helper
INFO - 2016-03-01 10:59:43 --> Helper loaded: file_helper
INFO - 2016-03-01 10:59:43 --> Helper loaded: date_helper
INFO - 2016-03-01 10:59:43 --> Helper loaded: form_helper
INFO - 2016-03-01 10:59:43 --> Database Driver Class Initialized
INFO - 2016-03-01 10:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 10:59:44 --> Controller Class Initialized
INFO - 2016-03-01 10:59:44 --> Model Class Initialized
INFO - 2016-03-01 10:59:44 --> Model Class Initialized
INFO - 2016-03-01 10:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 10:59:44 --> Pagination Class Initialized
INFO - 2016-03-01 10:59:44 --> Helper loaded: text_helper
INFO - 2016-03-01 10:59:44 --> Helper loaded: cookie_helper
INFO - 2016-03-01 13:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 13:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 13:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 13:59:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 13:59:44 --> Final output sent to browser
DEBUG - 2016-03-01 13:59:44 --> Total execution time: 1.1219
INFO - 2016-03-01 11:00:59 --> Config Class Initialized
INFO - 2016-03-01 11:00:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:00:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:00:59 --> Utf8 Class Initialized
INFO - 2016-03-01 11:00:59 --> URI Class Initialized
INFO - 2016-03-01 11:00:59 --> Router Class Initialized
INFO - 2016-03-01 11:00:59 --> Output Class Initialized
INFO - 2016-03-01 11:00:59 --> Security Class Initialized
DEBUG - 2016-03-01 11:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:00:59 --> Input Class Initialized
INFO - 2016-03-01 11:00:59 --> Language Class Initialized
INFO - 2016-03-01 11:00:59 --> Loader Class Initialized
INFO - 2016-03-01 11:00:59 --> Helper loaded: url_helper
INFO - 2016-03-01 11:00:59 --> Helper loaded: file_helper
INFO - 2016-03-01 11:00:59 --> Helper loaded: date_helper
INFO - 2016-03-01 11:00:59 --> Helper loaded: form_helper
INFO - 2016-03-01 11:00:59 --> Database Driver Class Initialized
INFO - 2016-03-01 11:01:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:01:00 --> Controller Class Initialized
INFO - 2016-03-01 11:01:00 --> Model Class Initialized
INFO - 2016-03-01 11:01:00 --> Model Class Initialized
INFO - 2016-03-01 11:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:01:00 --> Pagination Class Initialized
INFO - 2016-03-01 11:01:00 --> Helper loaded: text_helper
INFO - 2016-03-01 11:01:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:01:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:01:00 --> Final output sent to browser
DEBUG - 2016-03-01 14:01:00 --> Total execution time: 1.1970
INFO - 2016-03-01 11:01:01 --> Config Class Initialized
INFO - 2016-03-01 11:01:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:01:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:01:01 --> Utf8 Class Initialized
INFO - 2016-03-01 11:01:01 --> URI Class Initialized
INFO - 2016-03-01 11:01:01 --> Router Class Initialized
INFO - 2016-03-01 11:01:01 --> Output Class Initialized
INFO - 2016-03-01 11:01:01 --> Security Class Initialized
DEBUG - 2016-03-01 11:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:01:01 --> Input Class Initialized
INFO - 2016-03-01 11:01:01 --> Language Class Initialized
INFO - 2016-03-01 11:01:01 --> Loader Class Initialized
INFO - 2016-03-01 11:01:01 --> Helper loaded: url_helper
INFO - 2016-03-01 11:01:01 --> Helper loaded: file_helper
INFO - 2016-03-01 11:01:01 --> Helper loaded: date_helper
INFO - 2016-03-01 11:01:01 --> Helper loaded: form_helper
INFO - 2016-03-01 11:01:01 --> Database Driver Class Initialized
INFO - 2016-03-01 11:01:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:01:02 --> Controller Class Initialized
INFO - 2016-03-01 11:01:02 --> Model Class Initialized
INFO - 2016-03-01 11:01:02 --> Model Class Initialized
INFO - 2016-03-01 11:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:01:02 --> Pagination Class Initialized
INFO - 2016-03-01 11:01:02 --> Helper loaded: text_helper
INFO - 2016-03-01 11:01:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:01:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:01:02 --> Final output sent to browser
DEBUG - 2016-03-01 14:01:02 --> Total execution time: 1.1527
INFO - 2016-03-01 11:03:51 --> Config Class Initialized
INFO - 2016-03-01 11:03:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:03:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:03:51 --> Utf8 Class Initialized
INFO - 2016-03-01 11:03:51 --> URI Class Initialized
INFO - 2016-03-01 11:03:51 --> Router Class Initialized
INFO - 2016-03-01 11:03:51 --> Output Class Initialized
INFO - 2016-03-01 11:03:51 --> Security Class Initialized
DEBUG - 2016-03-01 11:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:03:51 --> Input Class Initialized
INFO - 2016-03-01 11:03:51 --> Language Class Initialized
INFO - 2016-03-01 11:03:51 --> Loader Class Initialized
INFO - 2016-03-01 11:03:51 --> Helper loaded: url_helper
INFO - 2016-03-01 11:03:51 --> Helper loaded: file_helper
INFO - 2016-03-01 11:03:51 --> Helper loaded: date_helper
INFO - 2016-03-01 11:03:51 --> Helper loaded: form_helper
INFO - 2016-03-01 11:03:51 --> Database Driver Class Initialized
INFO - 2016-03-01 11:03:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:03:52 --> Controller Class Initialized
INFO - 2016-03-01 11:03:52 --> Model Class Initialized
INFO - 2016-03-01 11:03:52 --> Model Class Initialized
INFO - 2016-03-01 11:03:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:03:52 --> Pagination Class Initialized
INFO - 2016-03-01 11:03:52 --> Helper loaded: text_helper
INFO - 2016-03-01 11:03:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:03:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:03:52 --> Final output sent to browser
DEBUG - 2016-03-01 14:03:52 --> Total execution time: 1.1609
INFO - 2016-03-01 11:03:52 --> Config Class Initialized
INFO - 2016-03-01 11:03:52 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:03:52 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:03:52 --> Utf8 Class Initialized
INFO - 2016-03-01 11:03:52 --> URI Class Initialized
INFO - 2016-03-01 11:03:52 --> Router Class Initialized
INFO - 2016-03-01 11:03:52 --> Output Class Initialized
INFO - 2016-03-01 11:03:52 --> Security Class Initialized
DEBUG - 2016-03-01 11:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:03:52 --> Input Class Initialized
INFO - 2016-03-01 11:03:52 --> Language Class Initialized
INFO - 2016-03-01 11:03:52 --> Loader Class Initialized
INFO - 2016-03-01 11:03:52 --> Helper loaded: url_helper
INFO - 2016-03-01 11:03:52 --> Helper loaded: file_helper
INFO - 2016-03-01 11:03:52 --> Helper loaded: date_helper
INFO - 2016-03-01 11:03:52 --> Helper loaded: form_helper
INFO - 2016-03-01 11:03:52 --> Database Driver Class Initialized
INFO - 2016-03-01 11:03:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:03:53 --> Controller Class Initialized
INFO - 2016-03-01 11:03:53 --> Model Class Initialized
INFO - 2016-03-01 11:03:53 --> Model Class Initialized
INFO - 2016-03-01 11:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:03:53 --> Pagination Class Initialized
INFO - 2016-03-01 11:03:53 --> Helper loaded: text_helper
INFO - 2016-03-01 11:03:53 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:03:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:03:53 --> Final output sent to browser
DEBUG - 2016-03-01 14:03:53 --> Total execution time: 1.1349
INFO - 2016-03-01 11:04:58 --> Config Class Initialized
INFO - 2016-03-01 11:04:58 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:04:58 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:04:58 --> Utf8 Class Initialized
INFO - 2016-03-01 11:04:59 --> URI Class Initialized
INFO - 2016-03-01 11:04:59 --> Router Class Initialized
INFO - 2016-03-01 11:04:59 --> Output Class Initialized
INFO - 2016-03-01 11:04:59 --> Security Class Initialized
DEBUG - 2016-03-01 11:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:04:59 --> Input Class Initialized
INFO - 2016-03-01 11:04:59 --> Language Class Initialized
INFO - 2016-03-01 11:04:59 --> Loader Class Initialized
INFO - 2016-03-01 11:04:59 --> Helper loaded: url_helper
INFO - 2016-03-01 11:04:59 --> Helper loaded: file_helper
INFO - 2016-03-01 11:04:59 --> Helper loaded: date_helper
INFO - 2016-03-01 11:04:59 --> Helper loaded: form_helper
INFO - 2016-03-01 11:04:59 --> Database Driver Class Initialized
INFO - 2016-03-01 11:05:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:05:00 --> Controller Class Initialized
INFO - 2016-03-01 11:05:00 --> Model Class Initialized
INFO - 2016-03-01 11:05:00 --> Model Class Initialized
INFO - 2016-03-01 11:05:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:05:00 --> Pagination Class Initialized
INFO - 2016-03-01 11:05:00 --> Helper loaded: text_helper
INFO - 2016-03-01 11:05:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:05:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:05:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:05:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:05:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:05:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:05:00 --> Final output sent to browser
DEBUG - 2016-03-01 14:05:00 --> Total execution time: 1.1448
INFO - 2016-03-01 11:05:00 --> Config Class Initialized
INFO - 2016-03-01 11:05:00 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:05:00 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:05:00 --> Utf8 Class Initialized
INFO - 2016-03-01 11:05:00 --> URI Class Initialized
INFO - 2016-03-01 11:05:00 --> Router Class Initialized
INFO - 2016-03-01 11:05:00 --> Output Class Initialized
INFO - 2016-03-01 11:05:00 --> Security Class Initialized
DEBUG - 2016-03-01 11:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:05:00 --> Input Class Initialized
INFO - 2016-03-01 11:05:00 --> Language Class Initialized
INFO - 2016-03-01 11:05:00 --> Loader Class Initialized
INFO - 2016-03-01 11:05:00 --> Helper loaded: url_helper
INFO - 2016-03-01 11:05:00 --> Helper loaded: file_helper
INFO - 2016-03-01 11:05:00 --> Helper loaded: date_helper
INFO - 2016-03-01 11:05:00 --> Helper loaded: form_helper
INFO - 2016-03-01 11:05:00 --> Database Driver Class Initialized
INFO - 2016-03-01 11:05:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:05:01 --> Controller Class Initialized
INFO - 2016-03-01 11:05:01 --> Model Class Initialized
INFO - 2016-03-01 11:05:01 --> Model Class Initialized
INFO - 2016-03-01 11:05:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:05:01 --> Pagination Class Initialized
INFO - 2016-03-01 11:05:01 --> Helper loaded: text_helper
INFO - 2016-03-01 11:05:01 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:05:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:05:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:05:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:05:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:05:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:05:01 --> Final output sent to browser
DEBUG - 2016-03-01 14:05:01 --> Total execution time: 1.1663
INFO - 2016-03-01 11:06:09 --> Config Class Initialized
INFO - 2016-03-01 11:06:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:06:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:06:09 --> Utf8 Class Initialized
INFO - 2016-03-01 11:06:09 --> URI Class Initialized
INFO - 2016-03-01 11:06:09 --> Router Class Initialized
INFO - 2016-03-01 11:06:09 --> Output Class Initialized
INFO - 2016-03-01 11:06:09 --> Security Class Initialized
DEBUG - 2016-03-01 11:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:06:09 --> Input Class Initialized
INFO - 2016-03-01 11:06:09 --> Language Class Initialized
INFO - 2016-03-01 11:06:09 --> Loader Class Initialized
INFO - 2016-03-01 11:06:09 --> Helper loaded: url_helper
INFO - 2016-03-01 11:06:09 --> Helper loaded: file_helper
INFO - 2016-03-01 11:06:09 --> Helper loaded: date_helper
INFO - 2016-03-01 11:06:09 --> Helper loaded: form_helper
INFO - 2016-03-01 11:06:09 --> Database Driver Class Initialized
INFO - 2016-03-01 11:06:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:06:10 --> Controller Class Initialized
INFO - 2016-03-01 11:06:10 --> Model Class Initialized
INFO - 2016-03-01 11:06:10 --> Model Class Initialized
INFO - 2016-03-01 11:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:06:10 --> Pagination Class Initialized
INFO - 2016-03-01 11:06:10 --> Helper loaded: text_helper
INFO - 2016-03-01 11:06:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:06:10 --> Final output sent to browser
DEBUG - 2016-03-01 14:06:10 --> Total execution time: 1.1404
INFO - 2016-03-01 11:06:11 --> Config Class Initialized
INFO - 2016-03-01 11:06:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:06:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:06:11 --> Utf8 Class Initialized
INFO - 2016-03-01 11:06:11 --> URI Class Initialized
INFO - 2016-03-01 11:06:11 --> Router Class Initialized
INFO - 2016-03-01 11:06:11 --> Output Class Initialized
INFO - 2016-03-01 11:06:11 --> Security Class Initialized
DEBUG - 2016-03-01 11:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:06:11 --> Input Class Initialized
INFO - 2016-03-01 11:06:11 --> Language Class Initialized
INFO - 2016-03-01 11:06:11 --> Loader Class Initialized
INFO - 2016-03-01 11:06:11 --> Helper loaded: url_helper
INFO - 2016-03-01 11:06:11 --> Helper loaded: file_helper
INFO - 2016-03-01 11:06:11 --> Helper loaded: date_helper
INFO - 2016-03-01 11:06:11 --> Helper loaded: form_helper
INFO - 2016-03-01 11:06:11 --> Database Driver Class Initialized
INFO - 2016-03-01 11:06:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:06:12 --> Controller Class Initialized
INFO - 2016-03-01 11:06:12 --> Model Class Initialized
INFO - 2016-03-01 11:06:12 --> Model Class Initialized
INFO - 2016-03-01 11:06:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:06:12 --> Pagination Class Initialized
INFO - 2016-03-01 11:06:12 --> Helper loaded: text_helper
INFO - 2016-03-01 11:06:12 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:06:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:06:12 --> Final output sent to browser
DEBUG - 2016-03-01 14:06:12 --> Total execution time: 1.1533
INFO - 2016-03-01 11:07:54 --> Config Class Initialized
INFO - 2016-03-01 11:07:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:07:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:07:54 --> Utf8 Class Initialized
INFO - 2016-03-01 11:07:54 --> URI Class Initialized
INFO - 2016-03-01 11:07:54 --> Router Class Initialized
INFO - 2016-03-01 11:07:54 --> Output Class Initialized
INFO - 2016-03-01 11:07:54 --> Security Class Initialized
DEBUG - 2016-03-01 11:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:07:54 --> Input Class Initialized
INFO - 2016-03-01 11:07:54 --> Language Class Initialized
INFO - 2016-03-01 11:07:54 --> Loader Class Initialized
INFO - 2016-03-01 11:07:54 --> Helper loaded: url_helper
INFO - 2016-03-01 11:07:54 --> Helper loaded: file_helper
INFO - 2016-03-01 11:07:54 --> Helper loaded: date_helper
INFO - 2016-03-01 11:07:54 --> Helper loaded: form_helper
INFO - 2016-03-01 11:07:54 --> Database Driver Class Initialized
INFO - 2016-03-01 11:07:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:07:55 --> Controller Class Initialized
INFO - 2016-03-01 11:07:55 --> Model Class Initialized
INFO - 2016-03-01 11:07:55 --> Model Class Initialized
INFO - 2016-03-01 11:07:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:07:55 --> Pagination Class Initialized
INFO - 2016-03-01 11:07:55 --> Helper loaded: text_helper
INFO - 2016-03-01 11:07:55 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:07:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:07:55 --> Final output sent to browser
DEBUG - 2016-03-01 14:07:55 --> Total execution time: 1.1538
INFO - 2016-03-01 11:07:56 --> Config Class Initialized
INFO - 2016-03-01 11:07:56 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:07:56 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:07:56 --> Utf8 Class Initialized
INFO - 2016-03-01 11:07:56 --> URI Class Initialized
INFO - 2016-03-01 11:07:56 --> Router Class Initialized
INFO - 2016-03-01 11:07:56 --> Output Class Initialized
INFO - 2016-03-01 11:07:56 --> Security Class Initialized
DEBUG - 2016-03-01 11:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:07:56 --> Input Class Initialized
INFO - 2016-03-01 11:07:56 --> Language Class Initialized
INFO - 2016-03-01 11:07:56 --> Loader Class Initialized
INFO - 2016-03-01 11:07:56 --> Helper loaded: url_helper
INFO - 2016-03-01 11:07:56 --> Helper loaded: file_helper
INFO - 2016-03-01 11:07:56 --> Helper loaded: date_helper
INFO - 2016-03-01 11:07:56 --> Helper loaded: form_helper
INFO - 2016-03-01 11:07:56 --> Database Driver Class Initialized
INFO - 2016-03-01 11:07:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:07:57 --> Controller Class Initialized
INFO - 2016-03-01 11:07:57 --> Model Class Initialized
INFO - 2016-03-01 11:07:57 --> Model Class Initialized
INFO - 2016-03-01 11:07:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:07:57 --> Pagination Class Initialized
INFO - 2016-03-01 11:07:57 --> Helper loaded: text_helper
INFO - 2016-03-01 11:07:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:07:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:07:57 --> Final output sent to browser
DEBUG - 2016-03-01 14:07:57 --> Total execution time: 1.1567
INFO - 2016-03-01 11:09:26 --> Config Class Initialized
INFO - 2016-03-01 11:09:26 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:09:26 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:09:26 --> Utf8 Class Initialized
INFO - 2016-03-01 11:09:26 --> URI Class Initialized
INFO - 2016-03-01 11:09:26 --> Router Class Initialized
INFO - 2016-03-01 11:09:26 --> Output Class Initialized
INFO - 2016-03-01 11:09:26 --> Security Class Initialized
DEBUG - 2016-03-01 11:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:09:26 --> Input Class Initialized
INFO - 2016-03-01 11:09:26 --> Language Class Initialized
INFO - 2016-03-01 11:09:26 --> Loader Class Initialized
INFO - 2016-03-01 11:09:26 --> Helper loaded: url_helper
INFO - 2016-03-01 11:09:26 --> Helper loaded: file_helper
INFO - 2016-03-01 11:09:26 --> Helper loaded: date_helper
INFO - 2016-03-01 11:09:26 --> Helper loaded: form_helper
INFO - 2016-03-01 11:09:26 --> Database Driver Class Initialized
INFO - 2016-03-01 11:09:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:09:27 --> Controller Class Initialized
INFO - 2016-03-01 11:09:27 --> Model Class Initialized
INFO - 2016-03-01 11:09:27 --> Model Class Initialized
INFO - 2016-03-01 11:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:09:27 --> Pagination Class Initialized
INFO - 2016-03-01 11:09:27 --> Helper loaded: text_helper
INFO - 2016-03-01 11:09:27 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:09:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:09:27 --> Final output sent to browser
DEBUG - 2016-03-01 14:09:27 --> Total execution time: 1.1600
INFO - 2016-03-01 11:09:28 --> Config Class Initialized
INFO - 2016-03-01 11:09:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:09:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:09:28 --> Utf8 Class Initialized
INFO - 2016-03-01 11:09:28 --> URI Class Initialized
INFO - 2016-03-01 11:09:28 --> Router Class Initialized
INFO - 2016-03-01 11:09:28 --> Output Class Initialized
INFO - 2016-03-01 11:09:28 --> Security Class Initialized
DEBUG - 2016-03-01 11:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:09:28 --> Input Class Initialized
INFO - 2016-03-01 11:09:28 --> Language Class Initialized
INFO - 2016-03-01 11:09:28 --> Loader Class Initialized
INFO - 2016-03-01 11:09:28 --> Helper loaded: url_helper
INFO - 2016-03-01 11:09:28 --> Helper loaded: file_helper
INFO - 2016-03-01 11:09:28 --> Helper loaded: date_helper
INFO - 2016-03-01 11:09:28 --> Helper loaded: form_helper
INFO - 2016-03-01 11:09:28 --> Database Driver Class Initialized
INFO - 2016-03-01 11:09:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:09:29 --> Controller Class Initialized
INFO - 2016-03-01 11:09:29 --> Model Class Initialized
INFO - 2016-03-01 11:09:29 --> Model Class Initialized
INFO - 2016-03-01 11:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:09:29 --> Pagination Class Initialized
INFO - 2016-03-01 11:09:29 --> Helper loaded: text_helper
INFO - 2016-03-01 11:09:29 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:09:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:09:29 --> Final output sent to browser
DEBUG - 2016-03-01 14:09:29 --> Total execution time: 1.1197
INFO - 2016-03-01 11:10:48 --> Config Class Initialized
INFO - 2016-03-01 11:10:48 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:10:48 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:10:48 --> Utf8 Class Initialized
INFO - 2016-03-01 11:10:48 --> URI Class Initialized
INFO - 2016-03-01 11:10:48 --> Router Class Initialized
INFO - 2016-03-01 11:10:48 --> Output Class Initialized
INFO - 2016-03-01 11:10:48 --> Security Class Initialized
DEBUG - 2016-03-01 11:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:10:48 --> Input Class Initialized
INFO - 2016-03-01 11:10:48 --> Language Class Initialized
INFO - 2016-03-01 11:10:48 --> Loader Class Initialized
INFO - 2016-03-01 11:10:48 --> Helper loaded: url_helper
INFO - 2016-03-01 11:10:48 --> Helper loaded: file_helper
INFO - 2016-03-01 11:10:48 --> Helper loaded: date_helper
INFO - 2016-03-01 11:10:48 --> Helper loaded: form_helper
INFO - 2016-03-01 11:10:48 --> Database Driver Class Initialized
INFO - 2016-03-01 11:10:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:10:49 --> Controller Class Initialized
INFO - 2016-03-01 11:10:49 --> Model Class Initialized
INFO - 2016-03-01 11:10:49 --> Model Class Initialized
INFO - 2016-03-01 11:10:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:10:49 --> Pagination Class Initialized
INFO - 2016-03-01 11:10:49 --> Helper loaded: text_helper
INFO - 2016-03-01 11:10:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:10:49 --> Upload Class Initialized
INFO - 2016-03-01 14:10:49 --> Image Lib Class Initialized
DEBUG - 2016-03-01 14:10:49 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-01 14:10:49 --> Final output sent to browser
DEBUG - 2016-03-01 14:10:49 --> Total execution time: 1.5188
INFO - 2016-03-01 11:15:59 --> Config Class Initialized
INFO - 2016-03-01 11:15:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:15:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:15:59 --> Utf8 Class Initialized
INFO - 2016-03-01 11:15:59 --> URI Class Initialized
INFO - 2016-03-01 11:15:59 --> Router Class Initialized
INFO - 2016-03-01 11:15:59 --> Output Class Initialized
INFO - 2016-03-01 11:15:59 --> Security Class Initialized
DEBUG - 2016-03-01 11:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:15:59 --> Input Class Initialized
INFO - 2016-03-01 11:15:59 --> Language Class Initialized
INFO - 2016-03-01 11:15:59 --> Loader Class Initialized
INFO - 2016-03-01 11:15:59 --> Helper loaded: url_helper
INFO - 2016-03-01 11:15:59 --> Helper loaded: file_helper
INFO - 2016-03-01 11:15:59 --> Helper loaded: date_helper
INFO - 2016-03-01 11:15:59 --> Helper loaded: form_helper
INFO - 2016-03-01 11:15:59 --> Database Driver Class Initialized
INFO - 2016-03-01 11:16:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:16:00 --> Controller Class Initialized
INFO - 2016-03-01 11:16:00 --> Model Class Initialized
INFO - 2016-03-01 11:16:00 --> Model Class Initialized
INFO - 2016-03-01 11:16:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:16:00 --> Pagination Class Initialized
INFO - 2016-03-01 11:16:00 --> Helper loaded: text_helper
INFO - 2016-03-01 11:16:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:16:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:16:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:16:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:16:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:16:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:16:00 --> Final output sent to browser
DEBUG - 2016-03-01 14:16:00 --> Total execution time: 1.1516
INFO - 2016-03-01 11:16:00 --> Config Class Initialized
INFO - 2016-03-01 11:16:00 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:16:00 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:16:00 --> Utf8 Class Initialized
INFO - 2016-03-01 11:16:00 --> URI Class Initialized
INFO - 2016-03-01 11:16:00 --> Router Class Initialized
INFO - 2016-03-01 11:16:00 --> Output Class Initialized
INFO - 2016-03-01 11:16:00 --> Security Class Initialized
DEBUG - 2016-03-01 11:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:16:00 --> Input Class Initialized
INFO - 2016-03-01 11:16:00 --> Language Class Initialized
INFO - 2016-03-01 11:16:00 --> Loader Class Initialized
INFO - 2016-03-01 11:16:00 --> Helper loaded: url_helper
INFO - 2016-03-01 11:16:00 --> Helper loaded: file_helper
INFO - 2016-03-01 11:16:00 --> Helper loaded: date_helper
INFO - 2016-03-01 11:16:00 --> Helper loaded: form_helper
INFO - 2016-03-01 11:16:00 --> Database Driver Class Initialized
INFO - 2016-03-01 11:16:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:16:01 --> Controller Class Initialized
INFO - 2016-03-01 11:16:01 --> Model Class Initialized
INFO - 2016-03-01 11:16:01 --> Model Class Initialized
INFO - 2016-03-01 11:16:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:16:01 --> Pagination Class Initialized
INFO - 2016-03-01 11:16:01 --> Helper loaded: text_helper
INFO - 2016-03-01 11:16:01 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:16:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:16:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:16:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:16:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:16:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:16:01 --> Final output sent to browser
DEBUG - 2016-03-01 14:16:01 --> Total execution time: 1.1333
INFO - 2016-03-01 11:16:12 --> Config Class Initialized
INFO - 2016-03-01 11:16:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:16:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:16:12 --> Utf8 Class Initialized
INFO - 2016-03-01 11:16:12 --> URI Class Initialized
INFO - 2016-03-01 11:16:12 --> Router Class Initialized
INFO - 2016-03-01 11:16:12 --> Output Class Initialized
INFO - 2016-03-01 11:16:12 --> Security Class Initialized
DEBUG - 2016-03-01 11:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:16:12 --> Input Class Initialized
INFO - 2016-03-01 11:16:12 --> Language Class Initialized
INFO - 2016-03-01 11:16:12 --> Loader Class Initialized
INFO - 2016-03-01 11:16:12 --> Helper loaded: url_helper
INFO - 2016-03-01 11:16:12 --> Helper loaded: file_helper
INFO - 2016-03-01 11:16:12 --> Helper loaded: date_helper
INFO - 2016-03-01 11:16:12 --> Helper loaded: form_helper
INFO - 2016-03-01 11:16:12 --> Database Driver Class Initialized
INFO - 2016-03-01 11:16:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:16:14 --> Controller Class Initialized
INFO - 2016-03-01 11:16:14 --> Model Class Initialized
INFO - 2016-03-01 11:16:14 --> Model Class Initialized
INFO - 2016-03-01 11:16:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:16:14 --> Pagination Class Initialized
INFO - 2016-03-01 11:16:14 --> Helper loaded: text_helper
INFO - 2016-03-01 11:16:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:16:14 --> Upload Class Initialized
INFO - 2016-03-01 14:16:14 --> Image Lib Class Initialized
DEBUG - 2016-03-01 14:16:14 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-01 14:16:14 --> Final output sent to browser
DEBUG - 2016-03-01 14:16:14 --> Total execution time: 1.3715
INFO - 2016-03-01 11:21:13 --> Config Class Initialized
INFO - 2016-03-01 11:21:13 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:21:13 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:21:13 --> Utf8 Class Initialized
INFO - 2016-03-01 11:21:13 --> URI Class Initialized
INFO - 2016-03-01 11:21:13 --> Router Class Initialized
INFO - 2016-03-01 11:21:13 --> Output Class Initialized
INFO - 2016-03-01 11:21:13 --> Security Class Initialized
DEBUG - 2016-03-01 11:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:21:13 --> Input Class Initialized
INFO - 2016-03-01 11:21:13 --> Language Class Initialized
INFO - 2016-03-01 11:21:13 --> Loader Class Initialized
INFO - 2016-03-01 11:21:13 --> Helper loaded: url_helper
INFO - 2016-03-01 11:21:13 --> Helper loaded: file_helper
INFO - 2016-03-01 11:21:13 --> Helper loaded: date_helper
INFO - 2016-03-01 11:21:13 --> Helper loaded: form_helper
INFO - 2016-03-01 11:21:13 --> Database Driver Class Initialized
INFO - 2016-03-01 11:21:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:21:14 --> Controller Class Initialized
INFO - 2016-03-01 11:21:14 --> Model Class Initialized
INFO - 2016-03-01 11:21:14 --> Model Class Initialized
INFO - 2016-03-01 11:21:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:21:14 --> Pagination Class Initialized
INFO - 2016-03-01 11:21:14 --> Helper loaded: text_helper
INFO - 2016-03-01 11:21:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:21:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:21:14 --> Final output sent to browser
DEBUG - 2016-03-01 14:21:14 --> Total execution time: 1.1549
INFO - 2016-03-01 11:21:14 --> Config Class Initialized
INFO - 2016-03-01 11:21:14 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:21:14 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:21:14 --> Utf8 Class Initialized
INFO - 2016-03-01 11:21:14 --> URI Class Initialized
INFO - 2016-03-01 11:21:14 --> Router Class Initialized
INFO - 2016-03-01 11:21:14 --> Output Class Initialized
INFO - 2016-03-01 11:21:14 --> Security Class Initialized
DEBUG - 2016-03-01 11:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:21:14 --> Input Class Initialized
INFO - 2016-03-01 11:21:14 --> Language Class Initialized
INFO - 2016-03-01 11:21:14 --> Loader Class Initialized
INFO - 2016-03-01 11:21:14 --> Helper loaded: url_helper
INFO - 2016-03-01 11:21:14 --> Helper loaded: file_helper
INFO - 2016-03-01 11:21:14 --> Helper loaded: date_helper
INFO - 2016-03-01 11:21:14 --> Helper loaded: form_helper
INFO - 2016-03-01 11:21:14 --> Database Driver Class Initialized
INFO - 2016-03-01 11:21:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:21:15 --> Controller Class Initialized
INFO - 2016-03-01 11:21:15 --> Model Class Initialized
INFO - 2016-03-01 11:21:15 --> Model Class Initialized
INFO - 2016-03-01 11:21:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:21:15 --> Pagination Class Initialized
INFO - 2016-03-01 11:21:15 --> Helper loaded: text_helper
INFO - 2016-03-01 11:21:15 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:21:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:21:15 --> Final output sent to browser
DEBUG - 2016-03-01 14:21:15 --> Total execution time: 1.1467
INFO - 2016-03-01 11:22:39 --> Config Class Initialized
INFO - 2016-03-01 11:22:39 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:22:39 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:22:39 --> Utf8 Class Initialized
INFO - 2016-03-01 11:22:39 --> URI Class Initialized
INFO - 2016-03-01 11:22:39 --> Router Class Initialized
INFO - 2016-03-01 11:22:39 --> Output Class Initialized
INFO - 2016-03-01 11:22:39 --> Security Class Initialized
DEBUG - 2016-03-01 11:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:22:39 --> Input Class Initialized
INFO - 2016-03-01 11:22:39 --> Language Class Initialized
INFO - 2016-03-01 11:22:39 --> Loader Class Initialized
INFO - 2016-03-01 11:22:39 --> Helper loaded: url_helper
INFO - 2016-03-01 11:22:39 --> Helper loaded: file_helper
INFO - 2016-03-01 11:22:39 --> Helper loaded: date_helper
INFO - 2016-03-01 11:22:39 --> Helper loaded: form_helper
INFO - 2016-03-01 11:22:39 --> Database Driver Class Initialized
INFO - 2016-03-01 11:22:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:22:40 --> Controller Class Initialized
INFO - 2016-03-01 11:22:40 --> Model Class Initialized
INFO - 2016-03-01 11:22:40 --> Model Class Initialized
INFO - 2016-03-01 11:22:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:22:40 --> Pagination Class Initialized
INFO - 2016-03-01 11:22:40 --> Helper loaded: text_helper
INFO - 2016-03-01 11:22:40 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:22:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:22:40 --> Final output sent to browser
DEBUG - 2016-03-01 14:22:40 --> Total execution time: 1.1489
INFO - 2016-03-01 11:22:40 --> Config Class Initialized
INFO - 2016-03-01 11:22:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:22:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:22:40 --> Utf8 Class Initialized
INFO - 2016-03-01 11:22:40 --> URI Class Initialized
INFO - 2016-03-01 11:22:40 --> Router Class Initialized
INFO - 2016-03-01 11:22:40 --> Output Class Initialized
INFO - 2016-03-01 11:22:40 --> Security Class Initialized
DEBUG - 2016-03-01 11:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:22:40 --> Input Class Initialized
INFO - 2016-03-01 11:22:40 --> Language Class Initialized
INFO - 2016-03-01 11:22:40 --> Loader Class Initialized
INFO - 2016-03-01 11:22:40 --> Helper loaded: url_helper
INFO - 2016-03-01 11:22:40 --> Helper loaded: file_helper
INFO - 2016-03-01 11:22:40 --> Helper loaded: date_helper
INFO - 2016-03-01 11:22:40 --> Helper loaded: form_helper
INFO - 2016-03-01 11:22:40 --> Database Driver Class Initialized
INFO - 2016-03-01 11:22:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:22:41 --> Controller Class Initialized
INFO - 2016-03-01 11:22:41 --> Model Class Initialized
INFO - 2016-03-01 11:22:41 --> Model Class Initialized
INFO - 2016-03-01 11:22:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:22:41 --> Pagination Class Initialized
INFO - 2016-03-01 11:22:41 --> Helper loaded: text_helper
INFO - 2016-03-01 11:22:41 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:22:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:22:41 --> Final output sent to browser
DEBUG - 2016-03-01 14:22:41 --> Total execution time: 1.1448
INFO - 2016-03-01 11:22:55 --> Config Class Initialized
INFO - 2016-03-01 11:22:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:22:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:22:55 --> Utf8 Class Initialized
INFO - 2016-03-01 11:22:55 --> URI Class Initialized
INFO - 2016-03-01 11:22:55 --> Router Class Initialized
INFO - 2016-03-01 11:22:55 --> Output Class Initialized
INFO - 2016-03-01 11:22:55 --> Security Class Initialized
DEBUG - 2016-03-01 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:22:55 --> Input Class Initialized
INFO - 2016-03-01 11:22:55 --> Language Class Initialized
INFO - 2016-03-01 11:22:55 --> Loader Class Initialized
INFO - 2016-03-01 11:22:55 --> Helper loaded: url_helper
INFO - 2016-03-01 11:22:55 --> Helper loaded: file_helper
INFO - 2016-03-01 11:22:55 --> Helper loaded: date_helper
INFO - 2016-03-01 11:22:55 --> Helper loaded: form_helper
INFO - 2016-03-01 11:22:55 --> Database Driver Class Initialized
INFO - 2016-03-01 11:22:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:22:56 --> Controller Class Initialized
INFO - 2016-03-01 11:22:56 --> Model Class Initialized
INFO - 2016-03-01 11:22:56 --> Model Class Initialized
INFO - 2016-03-01 11:22:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:22:56 --> Pagination Class Initialized
INFO - 2016-03-01 11:22:56 --> Helper loaded: text_helper
INFO - 2016-03-01 11:22:56 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:22:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:22:56 --> Final output sent to browser
DEBUG - 2016-03-01 14:22:56 --> Total execution time: 1.1587
INFO - 2016-03-01 11:22:56 --> Config Class Initialized
INFO - 2016-03-01 11:22:56 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:22:56 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:22:56 --> Utf8 Class Initialized
INFO - 2016-03-01 11:22:56 --> URI Class Initialized
INFO - 2016-03-01 11:22:56 --> Router Class Initialized
INFO - 2016-03-01 11:22:56 --> Output Class Initialized
INFO - 2016-03-01 11:22:56 --> Security Class Initialized
DEBUG - 2016-03-01 11:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:22:56 --> Input Class Initialized
INFO - 2016-03-01 11:22:56 --> Language Class Initialized
INFO - 2016-03-01 11:22:56 --> Loader Class Initialized
INFO - 2016-03-01 11:22:56 --> Helper loaded: url_helper
INFO - 2016-03-01 11:22:56 --> Helper loaded: file_helper
INFO - 2016-03-01 11:22:56 --> Helper loaded: date_helper
INFO - 2016-03-01 11:22:56 --> Helper loaded: form_helper
INFO - 2016-03-01 11:22:56 --> Database Driver Class Initialized
INFO - 2016-03-01 11:22:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:22:57 --> Controller Class Initialized
INFO - 2016-03-01 11:22:57 --> Model Class Initialized
INFO - 2016-03-01 11:22:57 --> Model Class Initialized
INFO - 2016-03-01 11:22:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:22:57 --> Pagination Class Initialized
INFO - 2016-03-01 11:22:57 --> Helper loaded: text_helper
INFO - 2016-03-01 11:22:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:22:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:22:57 --> Final output sent to browser
DEBUG - 2016-03-01 14:22:57 --> Total execution time: 1.1975
INFO - 2016-03-01 11:23:09 --> Config Class Initialized
INFO - 2016-03-01 11:23:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:23:10 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:23:10 --> Utf8 Class Initialized
INFO - 2016-03-01 11:23:10 --> URI Class Initialized
INFO - 2016-03-01 11:23:10 --> Router Class Initialized
INFO - 2016-03-01 11:23:10 --> Output Class Initialized
INFO - 2016-03-01 11:23:10 --> Security Class Initialized
DEBUG - 2016-03-01 11:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:23:10 --> Input Class Initialized
INFO - 2016-03-01 11:23:10 --> Language Class Initialized
INFO - 2016-03-01 11:23:10 --> Loader Class Initialized
INFO - 2016-03-01 11:23:10 --> Helper loaded: url_helper
INFO - 2016-03-01 11:23:10 --> Helper loaded: file_helper
INFO - 2016-03-01 11:23:10 --> Helper loaded: date_helper
INFO - 2016-03-01 11:23:10 --> Helper loaded: form_helper
INFO - 2016-03-01 11:23:10 --> Database Driver Class Initialized
INFO - 2016-03-01 11:23:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:23:11 --> Controller Class Initialized
INFO - 2016-03-01 11:23:11 --> Model Class Initialized
INFO - 2016-03-01 11:23:11 --> Model Class Initialized
INFO - 2016-03-01 11:23:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:23:11 --> Pagination Class Initialized
INFO - 2016-03-01 11:23:11 --> Helper loaded: text_helper
INFO - 2016-03-01 11:23:11 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:23:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:23:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:23:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:23:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:23:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:23:11 --> Final output sent to browser
DEBUG - 2016-03-01 14:23:11 --> Total execution time: 1.1420
INFO - 2016-03-01 11:23:11 --> Config Class Initialized
INFO - 2016-03-01 11:23:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:23:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:23:11 --> Utf8 Class Initialized
INFO - 2016-03-01 11:23:11 --> URI Class Initialized
INFO - 2016-03-01 11:23:11 --> Router Class Initialized
INFO - 2016-03-01 11:23:11 --> Output Class Initialized
INFO - 2016-03-01 11:23:11 --> Security Class Initialized
DEBUG - 2016-03-01 11:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:23:11 --> Input Class Initialized
INFO - 2016-03-01 11:23:11 --> Language Class Initialized
INFO - 2016-03-01 11:23:11 --> Loader Class Initialized
INFO - 2016-03-01 11:23:11 --> Helper loaded: url_helper
INFO - 2016-03-01 11:23:11 --> Helper loaded: file_helper
INFO - 2016-03-01 11:23:11 --> Helper loaded: date_helper
INFO - 2016-03-01 11:23:11 --> Helper loaded: form_helper
INFO - 2016-03-01 11:23:11 --> Database Driver Class Initialized
INFO - 2016-03-01 11:23:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:23:12 --> Controller Class Initialized
INFO - 2016-03-01 11:23:12 --> Model Class Initialized
INFO - 2016-03-01 11:23:12 --> Model Class Initialized
INFO - 2016-03-01 11:23:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:23:12 --> Pagination Class Initialized
INFO - 2016-03-01 11:23:12 --> Helper loaded: text_helper
INFO - 2016-03-01 11:23:12 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:23:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:23:12 --> Final output sent to browser
DEBUG - 2016-03-01 14:23:12 --> Total execution time: 1.1549
INFO - 2016-03-01 11:23:29 --> Config Class Initialized
INFO - 2016-03-01 11:23:29 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:23:29 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:23:29 --> Utf8 Class Initialized
INFO - 2016-03-01 11:23:29 --> URI Class Initialized
DEBUG - 2016-03-01 11:23:29 --> No URI present. Default controller set.
INFO - 2016-03-01 11:23:29 --> Router Class Initialized
INFO - 2016-03-01 11:23:29 --> Output Class Initialized
INFO - 2016-03-01 11:23:29 --> Security Class Initialized
DEBUG - 2016-03-01 11:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:23:29 --> Input Class Initialized
INFO - 2016-03-01 11:23:29 --> Language Class Initialized
INFO - 2016-03-01 11:23:29 --> Loader Class Initialized
INFO - 2016-03-01 11:23:29 --> Helper loaded: url_helper
INFO - 2016-03-01 11:23:29 --> Helper loaded: file_helper
INFO - 2016-03-01 11:23:29 --> Helper loaded: date_helper
INFO - 2016-03-01 11:23:29 --> Helper loaded: form_helper
INFO - 2016-03-01 11:23:29 --> Database Driver Class Initialized
INFO - 2016-03-01 11:23:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:23:31 --> Controller Class Initialized
INFO - 2016-03-01 11:23:31 --> Model Class Initialized
INFO - 2016-03-01 11:23:31 --> Model Class Initialized
INFO - 2016-03-01 11:23:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:23:31 --> Pagination Class Initialized
INFO - 2016-03-01 11:23:31 --> Helper loaded: text_helper
INFO - 2016-03-01 11:23:31 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:23:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:23:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:23:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 14:23:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:23:31 --> Final output sent to browser
DEBUG - 2016-03-01 14:23:31 --> Total execution time: 1.1545
INFO - 2016-03-01 11:23:33 --> Config Class Initialized
INFO - 2016-03-01 11:23:33 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:23:33 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:23:33 --> Utf8 Class Initialized
INFO - 2016-03-01 11:23:33 --> URI Class Initialized
INFO - 2016-03-01 11:23:33 --> Router Class Initialized
INFO - 2016-03-01 11:23:33 --> Output Class Initialized
INFO - 2016-03-01 11:23:33 --> Security Class Initialized
DEBUG - 2016-03-01 11:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:23:33 --> Input Class Initialized
INFO - 2016-03-01 11:23:33 --> Language Class Initialized
INFO - 2016-03-01 11:23:33 --> Loader Class Initialized
INFO - 2016-03-01 11:23:33 --> Helper loaded: url_helper
INFO - 2016-03-01 11:23:33 --> Helper loaded: file_helper
INFO - 2016-03-01 11:23:33 --> Helper loaded: date_helper
INFO - 2016-03-01 11:23:33 --> Helper loaded: form_helper
INFO - 2016-03-01 11:23:33 --> Database Driver Class Initialized
INFO - 2016-03-01 11:23:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:23:34 --> Controller Class Initialized
INFO - 2016-03-01 11:23:34 --> Model Class Initialized
INFO - 2016-03-01 11:23:34 --> Model Class Initialized
INFO - 2016-03-01 11:23:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:23:34 --> Pagination Class Initialized
INFO - 2016-03-01 11:23:34 --> Helper loaded: text_helper
INFO - 2016-03-01 11:23:34 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:23:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:23:34 --> Final output sent to browser
DEBUG - 2016-03-01 14:23:34 --> Total execution time: 1.1554
INFO - 2016-03-01 11:23:35 --> Config Class Initialized
INFO - 2016-03-01 11:23:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:23:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:23:35 --> Utf8 Class Initialized
INFO - 2016-03-01 11:23:35 --> URI Class Initialized
INFO - 2016-03-01 11:23:35 --> Router Class Initialized
INFO - 2016-03-01 11:23:35 --> Output Class Initialized
INFO - 2016-03-01 11:23:35 --> Security Class Initialized
DEBUG - 2016-03-01 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:23:35 --> Input Class Initialized
INFO - 2016-03-01 11:23:35 --> Language Class Initialized
INFO - 2016-03-01 11:23:35 --> Loader Class Initialized
INFO - 2016-03-01 11:23:35 --> Helper loaded: url_helper
INFO - 2016-03-01 11:23:35 --> Helper loaded: file_helper
INFO - 2016-03-01 11:23:35 --> Helper loaded: date_helper
INFO - 2016-03-01 11:23:35 --> Helper loaded: form_helper
INFO - 2016-03-01 11:23:35 --> Database Driver Class Initialized
INFO - 2016-03-01 11:23:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:23:36 --> Controller Class Initialized
INFO - 2016-03-01 11:23:36 --> Model Class Initialized
INFO - 2016-03-01 11:23:36 --> Model Class Initialized
INFO - 2016-03-01 11:23:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:23:36 --> Pagination Class Initialized
INFO - 2016-03-01 11:23:36 --> Helper loaded: text_helper
INFO - 2016-03-01 11:23:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:23:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:23:36 --> Final output sent to browser
DEBUG - 2016-03-01 14:23:36 --> Total execution time: 1.1207
INFO - 2016-03-01 11:23:40 --> Config Class Initialized
INFO - 2016-03-01 11:23:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:23:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:23:40 --> Utf8 Class Initialized
INFO - 2016-03-01 11:23:40 --> URI Class Initialized
INFO - 2016-03-01 11:23:40 --> Router Class Initialized
INFO - 2016-03-01 11:23:40 --> Output Class Initialized
INFO - 2016-03-01 11:23:40 --> Security Class Initialized
DEBUG - 2016-03-01 11:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:23:40 --> Input Class Initialized
INFO - 2016-03-01 11:23:40 --> Language Class Initialized
INFO - 2016-03-01 11:23:40 --> Loader Class Initialized
INFO - 2016-03-01 11:23:40 --> Helper loaded: url_helper
INFO - 2016-03-01 11:23:40 --> Helper loaded: file_helper
INFO - 2016-03-01 11:23:40 --> Helper loaded: date_helper
INFO - 2016-03-01 11:23:40 --> Helper loaded: form_helper
INFO - 2016-03-01 11:23:40 --> Database Driver Class Initialized
INFO - 2016-03-01 11:23:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:23:41 --> Controller Class Initialized
INFO - 2016-03-01 11:23:41 --> Model Class Initialized
INFO - 2016-03-01 11:23:41 --> Model Class Initialized
INFO - 2016-03-01 11:23:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:23:41 --> Pagination Class Initialized
INFO - 2016-03-01 11:23:41 --> Helper loaded: text_helper
INFO - 2016-03-01 11:23:41 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:23:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:23:41 --> Final output sent to browser
DEBUG - 2016-03-01 14:23:41 --> Total execution time: 1.3094
INFO - 2016-03-01 11:25:00 --> Config Class Initialized
INFO - 2016-03-01 11:25:00 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:25:00 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:25:00 --> Utf8 Class Initialized
INFO - 2016-03-01 11:25:00 --> URI Class Initialized
DEBUG - 2016-03-01 11:25:00 --> No URI present. Default controller set.
INFO - 2016-03-01 11:25:00 --> Router Class Initialized
INFO - 2016-03-01 11:25:00 --> Output Class Initialized
INFO - 2016-03-01 11:25:00 --> Security Class Initialized
DEBUG - 2016-03-01 11:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:25:00 --> Input Class Initialized
INFO - 2016-03-01 11:25:00 --> Language Class Initialized
INFO - 2016-03-01 11:25:00 --> Loader Class Initialized
INFO - 2016-03-01 11:25:00 --> Helper loaded: url_helper
INFO - 2016-03-01 11:25:00 --> Helper loaded: file_helper
INFO - 2016-03-01 11:25:00 --> Helper loaded: date_helper
INFO - 2016-03-01 11:25:00 --> Helper loaded: form_helper
INFO - 2016-03-01 11:25:00 --> Database Driver Class Initialized
INFO - 2016-03-01 11:25:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:25:01 --> Controller Class Initialized
INFO - 2016-03-01 11:25:01 --> Model Class Initialized
INFO - 2016-03-01 11:25:01 --> Model Class Initialized
INFO - 2016-03-01 11:25:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:25:01 --> Pagination Class Initialized
INFO - 2016-03-01 11:25:01 --> Helper loaded: text_helper
INFO - 2016-03-01 11:25:01 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 14:25:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:25:01 --> Final output sent to browser
DEBUG - 2016-03-01 14:25:01 --> Total execution time: 1.1336
INFO - 2016-03-01 11:29:45 --> Config Class Initialized
INFO - 2016-03-01 11:29:45 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:29:45 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:29:45 --> Utf8 Class Initialized
INFO - 2016-03-01 11:29:45 --> URI Class Initialized
INFO - 2016-03-01 11:29:45 --> Router Class Initialized
INFO - 2016-03-01 11:29:45 --> Output Class Initialized
INFO - 2016-03-01 11:29:45 --> Security Class Initialized
DEBUG - 2016-03-01 11:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:29:45 --> Input Class Initialized
INFO - 2016-03-01 11:29:45 --> Language Class Initialized
INFO - 2016-03-01 11:29:45 --> Loader Class Initialized
INFO - 2016-03-01 11:29:45 --> Helper loaded: url_helper
INFO - 2016-03-01 11:29:45 --> Helper loaded: file_helper
INFO - 2016-03-01 11:29:45 --> Helper loaded: date_helper
INFO - 2016-03-01 11:29:45 --> Helper loaded: form_helper
INFO - 2016-03-01 11:29:45 --> Database Driver Class Initialized
INFO - 2016-03-01 11:29:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:29:46 --> Controller Class Initialized
INFO - 2016-03-01 11:29:46 --> Model Class Initialized
INFO - 2016-03-01 11:29:46 --> Model Class Initialized
INFO - 2016-03-01 11:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:29:46 --> Pagination Class Initialized
INFO - 2016-03-01 11:29:46 --> Helper loaded: text_helper
INFO - 2016-03-01 11:29:46 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:29:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:29:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:29:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:29:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:29:46 --> Final output sent to browser
DEBUG - 2016-03-01 14:29:46 --> Total execution time: 1.1610
INFO - 2016-03-01 11:29:47 --> Config Class Initialized
INFO - 2016-03-01 11:29:47 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:29:47 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:29:47 --> Utf8 Class Initialized
INFO - 2016-03-01 11:29:47 --> URI Class Initialized
INFO - 2016-03-01 11:29:47 --> Router Class Initialized
INFO - 2016-03-01 11:29:47 --> Output Class Initialized
INFO - 2016-03-01 11:29:47 --> Security Class Initialized
DEBUG - 2016-03-01 11:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:29:47 --> Input Class Initialized
INFO - 2016-03-01 11:29:47 --> Language Class Initialized
INFO - 2016-03-01 11:29:47 --> Loader Class Initialized
INFO - 2016-03-01 11:29:47 --> Helper loaded: url_helper
INFO - 2016-03-01 11:29:47 --> Helper loaded: file_helper
INFO - 2016-03-01 11:29:47 --> Helper loaded: date_helper
INFO - 2016-03-01 11:29:47 --> Helper loaded: form_helper
INFO - 2016-03-01 11:29:47 --> Database Driver Class Initialized
INFO - 2016-03-01 11:29:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:29:48 --> Controller Class Initialized
INFO - 2016-03-01 11:29:48 --> Model Class Initialized
INFO - 2016-03-01 11:29:48 --> Model Class Initialized
INFO - 2016-03-01 11:29:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:29:49 --> Pagination Class Initialized
INFO - 2016-03-01 11:29:49 --> Helper loaded: text_helper
INFO - 2016-03-01 11:29:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:29:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:29:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:29:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:29:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:29:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:29:49 --> Final output sent to browser
DEBUG - 2016-03-01 14:29:49 --> Total execution time: 1.1027
INFO - 2016-03-01 11:29:49 --> Config Class Initialized
INFO - 2016-03-01 11:29:49 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:29:49 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:29:49 --> Utf8 Class Initialized
INFO - 2016-03-01 11:29:49 --> URI Class Initialized
INFO - 2016-03-01 11:29:49 --> Router Class Initialized
INFO - 2016-03-01 11:29:49 --> Output Class Initialized
INFO - 2016-03-01 11:29:49 --> Security Class Initialized
DEBUG - 2016-03-01 11:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:29:49 --> Input Class Initialized
INFO - 2016-03-01 11:29:49 --> Language Class Initialized
INFO - 2016-03-01 11:29:49 --> Loader Class Initialized
INFO - 2016-03-01 11:29:49 --> Helper loaded: url_helper
INFO - 2016-03-01 11:29:49 --> Helper loaded: file_helper
INFO - 2016-03-01 11:29:49 --> Helper loaded: date_helper
INFO - 2016-03-01 11:29:49 --> Helper loaded: form_helper
INFO - 2016-03-01 11:29:49 --> Database Driver Class Initialized
INFO - 2016-03-01 11:29:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:29:50 --> Controller Class Initialized
INFO - 2016-03-01 11:29:50 --> Model Class Initialized
INFO - 2016-03-01 11:29:50 --> Model Class Initialized
INFO - 2016-03-01 11:29:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:29:50 --> Pagination Class Initialized
INFO - 2016-03-01 11:29:50 --> Helper loaded: text_helper
INFO - 2016-03-01 11:29:50 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:29:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:29:50 --> Final output sent to browser
DEBUG - 2016-03-01 14:29:50 --> Total execution time: 1.1543
INFO - 2016-03-01 11:30:55 --> Config Class Initialized
INFO - 2016-03-01 11:30:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:30:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:30:55 --> Utf8 Class Initialized
INFO - 2016-03-01 11:30:55 --> URI Class Initialized
INFO - 2016-03-01 11:30:55 --> Router Class Initialized
INFO - 2016-03-01 11:30:55 --> Output Class Initialized
INFO - 2016-03-01 11:30:55 --> Security Class Initialized
DEBUG - 2016-03-01 11:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:30:55 --> Input Class Initialized
INFO - 2016-03-01 11:30:55 --> Language Class Initialized
INFO - 2016-03-01 11:30:55 --> Loader Class Initialized
INFO - 2016-03-01 11:30:55 --> Helper loaded: url_helper
INFO - 2016-03-01 11:30:55 --> Helper loaded: file_helper
INFO - 2016-03-01 11:30:55 --> Helper loaded: date_helper
INFO - 2016-03-01 11:30:55 --> Helper loaded: form_helper
INFO - 2016-03-01 11:30:55 --> Database Driver Class Initialized
INFO - 2016-03-01 11:30:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:30:57 --> Controller Class Initialized
INFO - 2016-03-01 11:30:57 --> Model Class Initialized
INFO - 2016-03-01 11:30:57 --> Model Class Initialized
INFO - 2016-03-01 11:30:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:30:57 --> Pagination Class Initialized
INFO - 2016-03-01 11:30:57 --> Helper loaded: text_helper
INFO - 2016-03-01 11:30:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:30:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:30:57 --> Final output sent to browser
DEBUG - 2016-03-01 14:30:57 --> Total execution time: 1.1589
INFO - 2016-03-01 11:30:57 --> Config Class Initialized
INFO - 2016-03-01 11:30:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:30:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:30:57 --> Utf8 Class Initialized
INFO - 2016-03-01 11:30:57 --> URI Class Initialized
INFO - 2016-03-01 11:30:57 --> Router Class Initialized
INFO - 2016-03-01 11:30:57 --> Output Class Initialized
INFO - 2016-03-01 11:30:57 --> Security Class Initialized
DEBUG - 2016-03-01 11:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:30:57 --> Input Class Initialized
INFO - 2016-03-01 11:30:57 --> Language Class Initialized
INFO - 2016-03-01 11:30:57 --> Loader Class Initialized
INFO - 2016-03-01 11:30:57 --> Helper loaded: url_helper
INFO - 2016-03-01 11:30:57 --> Helper loaded: file_helper
INFO - 2016-03-01 11:30:57 --> Helper loaded: date_helper
INFO - 2016-03-01 11:30:57 --> Helper loaded: form_helper
INFO - 2016-03-01 11:30:57 --> Database Driver Class Initialized
INFO - 2016-03-01 11:30:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:30:58 --> Controller Class Initialized
INFO - 2016-03-01 11:30:58 --> Model Class Initialized
INFO - 2016-03-01 11:30:58 --> Model Class Initialized
INFO - 2016-03-01 11:30:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:30:58 --> Pagination Class Initialized
INFO - 2016-03-01 11:30:58 --> Helper loaded: text_helper
INFO - 2016-03-01 11:30:58 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:30:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:30:58 --> Final output sent to browser
DEBUG - 2016-03-01 14:30:58 --> Total execution time: 1.1547
INFO - 2016-03-01 11:31:50 --> Config Class Initialized
INFO - 2016-03-01 11:31:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:31:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:31:50 --> Utf8 Class Initialized
INFO - 2016-03-01 11:31:50 --> URI Class Initialized
INFO - 2016-03-01 11:31:50 --> Router Class Initialized
INFO - 2016-03-01 11:31:50 --> Output Class Initialized
INFO - 2016-03-01 11:31:50 --> Security Class Initialized
DEBUG - 2016-03-01 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:31:50 --> Input Class Initialized
INFO - 2016-03-01 11:31:50 --> Language Class Initialized
INFO - 2016-03-01 11:31:50 --> Loader Class Initialized
INFO - 2016-03-01 11:31:50 --> Helper loaded: url_helper
INFO - 2016-03-01 11:31:50 --> Helper loaded: file_helper
INFO - 2016-03-01 11:31:50 --> Helper loaded: date_helper
INFO - 2016-03-01 11:31:50 --> Helper loaded: form_helper
INFO - 2016-03-01 11:31:50 --> Database Driver Class Initialized
INFO - 2016-03-01 11:31:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:31:51 --> Controller Class Initialized
INFO - 2016-03-01 11:31:51 --> Model Class Initialized
INFO - 2016-03-01 11:31:51 --> Model Class Initialized
INFO - 2016-03-01 11:31:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:31:51 --> Pagination Class Initialized
INFO - 2016-03-01 11:31:51 --> Helper loaded: text_helper
INFO - 2016-03-01 11:31:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 14:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:31:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:31:51 --> Final output sent to browser
DEBUG - 2016-03-01 14:31:51 --> Total execution time: 1.2051
INFO - 2016-03-01 11:51:02 --> Config Class Initialized
INFO - 2016-03-01 11:51:02 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:02 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:02 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:02 --> URI Class Initialized
DEBUG - 2016-03-01 11:51:02 --> No URI present. Default controller set.
INFO - 2016-03-01 11:51:02 --> Router Class Initialized
INFO - 2016-03-01 11:51:02 --> Output Class Initialized
INFO - 2016-03-01 11:51:02 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:02 --> Input Class Initialized
INFO - 2016-03-01 11:51:02 --> Language Class Initialized
INFO - 2016-03-01 11:51:02 --> Loader Class Initialized
INFO - 2016-03-01 11:51:02 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:02 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:02 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:02 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:02 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:03 --> Controller Class Initialized
INFO - 2016-03-01 11:51:03 --> Model Class Initialized
INFO - 2016-03-01 11:51:03 --> Model Class Initialized
INFO - 2016-03-01 11:51:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:03 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:03 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:03 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 14:51:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:03 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:03 --> Total execution time: 1.1977
INFO - 2016-03-01 11:51:09 --> Config Class Initialized
INFO - 2016-03-01 11:51:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:09 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:09 --> URI Class Initialized
INFO - 2016-03-01 11:51:09 --> Router Class Initialized
INFO - 2016-03-01 11:51:09 --> Output Class Initialized
INFO - 2016-03-01 11:51:09 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:09 --> Input Class Initialized
INFO - 2016-03-01 11:51:09 --> Language Class Initialized
INFO - 2016-03-01 11:51:09 --> Loader Class Initialized
INFO - 2016-03-01 11:51:09 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:09 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:09 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:09 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:09 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:10 --> Controller Class Initialized
INFO - 2016-03-01 11:51:10 --> Model Class Initialized
INFO - 2016-03-01 11:51:10 --> Model Class Initialized
INFO - 2016-03-01 11:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:10 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:10 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:51:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:10 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:10 --> Total execution time: 1.1312
INFO - 2016-03-01 11:51:12 --> Config Class Initialized
INFO - 2016-03-01 11:51:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:12 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:12 --> URI Class Initialized
INFO - 2016-03-01 11:51:12 --> Router Class Initialized
INFO - 2016-03-01 11:51:12 --> Output Class Initialized
INFO - 2016-03-01 11:51:12 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:12 --> Input Class Initialized
INFO - 2016-03-01 11:51:12 --> Language Class Initialized
INFO - 2016-03-01 11:51:12 --> Loader Class Initialized
INFO - 2016-03-01 11:51:12 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:12 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:12 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:12 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:12 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:13 --> Controller Class Initialized
INFO - 2016-03-01 11:51:13 --> Model Class Initialized
INFO - 2016-03-01 11:51:13 --> Model Class Initialized
INFO - 2016-03-01 11:51:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:13 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:13 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:51:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:13 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:13 --> Total execution time: 1.0977
INFO - 2016-03-01 11:51:16 --> Config Class Initialized
INFO - 2016-03-01 11:51:16 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:16 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:16 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:16 --> URI Class Initialized
INFO - 2016-03-01 11:51:16 --> Router Class Initialized
INFO - 2016-03-01 11:51:16 --> Output Class Initialized
INFO - 2016-03-01 11:51:16 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:16 --> Input Class Initialized
INFO - 2016-03-01 11:51:16 --> Language Class Initialized
INFO - 2016-03-01 11:51:16 --> Loader Class Initialized
INFO - 2016-03-01 11:51:16 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:16 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:16 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:16 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:16 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:17 --> Controller Class Initialized
INFO - 2016-03-01 11:51:17 --> Model Class Initialized
INFO - 2016-03-01 11:51:17 --> Model Class Initialized
INFO - 2016-03-01 11:51:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:17 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:17 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:17 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:51:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:17 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:17 --> Total execution time: 1.1633
INFO - 2016-03-01 11:51:19 --> Config Class Initialized
INFO - 2016-03-01 11:51:19 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:19 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:19 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:19 --> URI Class Initialized
INFO - 2016-03-01 11:51:19 --> Router Class Initialized
INFO - 2016-03-01 11:51:19 --> Output Class Initialized
INFO - 2016-03-01 11:51:19 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:19 --> Input Class Initialized
INFO - 2016-03-01 11:51:19 --> Language Class Initialized
INFO - 2016-03-01 11:51:19 --> Loader Class Initialized
INFO - 2016-03-01 11:51:19 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:19 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:19 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:19 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:19 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:20 --> Controller Class Initialized
INFO - 2016-03-01 11:51:20 --> Model Class Initialized
INFO - 2016-03-01 11:51:20 --> Model Class Initialized
INFO - 2016-03-01 11:51:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:20 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:20 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:20 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:51:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:20 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:20 --> Total execution time: 1.1221
INFO - 2016-03-01 11:51:22 --> Config Class Initialized
INFO - 2016-03-01 11:51:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:22 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:22 --> URI Class Initialized
INFO - 2016-03-01 11:51:22 --> Router Class Initialized
INFO - 2016-03-01 11:51:22 --> Output Class Initialized
INFO - 2016-03-01 11:51:22 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:22 --> Input Class Initialized
INFO - 2016-03-01 11:51:22 --> Language Class Initialized
INFO - 2016-03-01 11:51:22 --> Loader Class Initialized
INFO - 2016-03-01 11:51:22 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:22 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:22 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:22 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:22 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:23 --> Controller Class Initialized
INFO - 2016-03-01 11:51:23 --> Model Class Initialized
INFO - 2016-03-01 11:51:23 --> Model Class Initialized
INFO - 2016-03-01 11:51:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:23 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:23 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:23 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 14:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:51:23 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:23 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:23 --> Total execution time: 1.1920
INFO - 2016-03-01 11:51:23 --> Config Class Initialized
INFO - 2016-03-01 11:51:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:23 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:23 --> URI Class Initialized
INFO - 2016-03-01 11:51:23 --> Router Class Initialized
INFO - 2016-03-01 11:51:23 --> Output Class Initialized
INFO - 2016-03-01 11:51:23 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:23 --> Input Class Initialized
INFO - 2016-03-01 11:51:23 --> Language Class Initialized
ERROR - 2016-03-01 11:51:23 --> 404 Page Not Found: Static/user
INFO - 2016-03-01 11:51:48 --> Config Class Initialized
INFO - 2016-03-01 11:51:48 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:48 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:48 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:48 --> URI Class Initialized
INFO - 2016-03-01 11:51:48 --> Router Class Initialized
INFO - 2016-03-01 11:51:48 --> Output Class Initialized
INFO - 2016-03-01 11:51:48 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:48 --> Input Class Initialized
INFO - 2016-03-01 11:51:48 --> Language Class Initialized
INFO - 2016-03-01 11:51:48 --> Loader Class Initialized
INFO - 2016-03-01 11:51:48 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:48 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:48 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:48 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:48 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:49 --> Controller Class Initialized
INFO - 2016-03-01 11:51:49 --> Model Class Initialized
INFO - 2016-03-01 11:51:49 --> Model Class Initialized
INFO - 2016-03-01 11:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:49 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:49 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:51:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:49 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:49 --> Total execution time: 1.1331
INFO - 2016-03-01 11:51:51 --> Config Class Initialized
INFO - 2016-03-01 11:51:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:51 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:51 --> URI Class Initialized
INFO - 2016-03-01 11:51:51 --> Router Class Initialized
INFO - 2016-03-01 11:51:51 --> Output Class Initialized
INFO - 2016-03-01 11:51:51 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:51 --> Input Class Initialized
INFO - 2016-03-01 11:51:51 --> Language Class Initialized
INFO - 2016-03-01 11:51:51 --> Loader Class Initialized
INFO - 2016-03-01 11:51:51 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:51 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:51 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:51 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:51 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:52 --> Controller Class Initialized
INFO - 2016-03-01 11:51:52 --> Model Class Initialized
INFO - 2016-03-01 11:51:52 --> Model Class Initialized
INFO - 2016-03-01 11:51:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:52 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:52 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:51:52 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:52 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:52 --> Total execution time: 1.1283
INFO - 2016-03-01 11:51:57 --> Config Class Initialized
INFO - 2016-03-01 11:51:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:51:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:51:57 --> Utf8 Class Initialized
INFO - 2016-03-01 11:51:57 --> URI Class Initialized
INFO - 2016-03-01 11:51:57 --> Router Class Initialized
INFO - 2016-03-01 11:51:57 --> Output Class Initialized
INFO - 2016-03-01 11:51:57 --> Security Class Initialized
DEBUG - 2016-03-01 11:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:51:57 --> Input Class Initialized
INFO - 2016-03-01 11:51:57 --> Language Class Initialized
INFO - 2016-03-01 11:51:57 --> Loader Class Initialized
INFO - 2016-03-01 11:51:57 --> Helper loaded: url_helper
INFO - 2016-03-01 11:51:57 --> Helper loaded: file_helper
INFO - 2016-03-01 11:51:57 --> Helper loaded: date_helper
INFO - 2016-03-01 11:51:57 --> Helper loaded: form_helper
INFO - 2016-03-01 11:51:57 --> Database Driver Class Initialized
INFO - 2016-03-01 11:51:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:51:58 --> Controller Class Initialized
INFO - 2016-03-01 11:51:58 --> Model Class Initialized
INFO - 2016-03-01 11:51:58 --> Model Class Initialized
INFO - 2016-03-01 11:51:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:51:58 --> Pagination Class Initialized
INFO - 2016-03-01 11:51:58 --> Helper loaded: text_helper
INFO - 2016-03-01 11:51:58 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 14:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:51:58 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:51:58 --> Final output sent to browser
DEBUG - 2016-03-01 14:51:58 --> Total execution time: 1.1795
INFO - 2016-03-01 11:52:31 --> Config Class Initialized
INFO - 2016-03-01 11:52:31 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:52:31 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:52:31 --> Utf8 Class Initialized
INFO - 2016-03-01 11:52:31 --> URI Class Initialized
INFO - 2016-03-01 11:52:31 --> Router Class Initialized
INFO - 2016-03-01 11:52:31 --> Output Class Initialized
INFO - 2016-03-01 11:52:31 --> Security Class Initialized
DEBUG - 2016-03-01 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:52:31 --> Input Class Initialized
INFO - 2016-03-01 11:52:31 --> Language Class Initialized
INFO - 2016-03-01 11:52:31 --> Loader Class Initialized
INFO - 2016-03-01 11:52:31 --> Helper loaded: url_helper
INFO - 2016-03-01 11:52:31 --> Helper loaded: file_helper
INFO - 2016-03-01 11:52:31 --> Helper loaded: date_helper
INFO - 2016-03-01 11:52:31 --> Helper loaded: form_helper
INFO - 2016-03-01 11:52:31 --> Database Driver Class Initialized
INFO - 2016-03-01 11:52:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:52:32 --> Controller Class Initialized
INFO - 2016-03-01 11:52:32 --> Model Class Initialized
INFO - 2016-03-01 11:52:32 --> Model Class Initialized
INFO - 2016-03-01 11:52:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:52:33 --> Pagination Class Initialized
INFO - 2016-03-01 11:52:33 --> Helper loaded: text_helper
INFO - 2016-03-01 11:52:33 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 14:52:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:52:33 --> Final output sent to browser
DEBUG - 2016-03-01 14:52:33 --> Total execution time: 1.1381
INFO - 2016-03-01 11:52:35 --> Config Class Initialized
INFO - 2016-03-01 11:52:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 11:52:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 11:52:35 --> Utf8 Class Initialized
INFO - 2016-03-01 11:52:35 --> URI Class Initialized
INFO - 2016-03-01 11:52:35 --> Router Class Initialized
INFO - 2016-03-01 11:52:35 --> Output Class Initialized
INFO - 2016-03-01 11:52:35 --> Security Class Initialized
DEBUG - 2016-03-01 11:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 11:52:35 --> Input Class Initialized
INFO - 2016-03-01 11:52:35 --> Language Class Initialized
INFO - 2016-03-01 11:52:35 --> Loader Class Initialized
INFO - 2016-03-01 11:52:35 --> Helper loaded: url_helper
INFO - 2016-03-01 11:52:35 --> Helper loaded: file_helper
INFO - 2016-03-01 11:52:35 --> Helper loaded: date_helper
INFO - 2016-03-01 11:52:35 --> Helper loaded: form_helper
INFO - 2016-03-01 11:52:35 --> Database Driver Class Initialized
INFO - 2016-03-01 11:52:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 11:52:36 --> Controller Class Initialized
INFO - 2016-03-01 11:52:36 --> Model Class Initialized
INFO - 2016-03-01 11:52:36 --> Model Class Initialized
INFO - 2016-03-01 11:52:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 11:52:36 --> Pagination Class Initialized
INFO - 2016-03-01 11:52:36 --> Helper loaded: text_helper
INFO - 2016-03-01 11:52:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 14:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 14:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 14:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 14:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 14:52:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 14:52:36 --> Final output sent to browser
DEBUG - 2016-03-01 14:52:36 --> Total execution time: 1.1698
INFO - 2016-03-01 13:04:32 --> Config Class Initialized
INFO - 2016-03-01 13:04:32 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:04:32 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:04:32 --> Utf8 Class Initialized
INFO - 2016-03-01 13:04:32 --> URI Class Initialized
INFO - 2016-03-01 13:04:32 --> Router Class Initialized
INFO - 2016-03-01 13:04:32 --> Output Class Initialized
INFO - 2016-03-01 13:04:32 --> Security Class Initialized
DEBUG - 2016-03-01 13:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:04:32 --> Input Class Initialized
INFO - 2016-03-01 13:04:32 --> Language Class Initialized
INFO - 2016-03-01 13:04:32 --> Loader Class Initialized
INFO - 2016-03-01 13:04:32 --> Helper loaded: url_helper
INFO - 2016-03-01 13:04:32 --> Helper loaded: file_helper
INFO - 2016-03-01 13:04:32 --> Helper loaded: date_helper
INFO - 2016-03-01 13:04:33 --> Helper loaded: form_helper
INFO - 2016-03-01 13:04:33 --> Database Driver Class Initialized
INFO - 2016-03-01 13:04:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:04:34 --> Controller Class Initialized
INFO - 2016-03-01 13:04:34 --> Model Class Initialized
INFO - 2016-03-01 13:04:34 --> Model Class Initialized
INFO - 2016-03-01 13:04:34 --> Form Validation Class Initialized
INFO - 2016-03-01 13:04:34 --> Helper loaded: text_helper
INFO - 2016-03-01 13:04:34 --> Config Class Initialized
INFO - 2016-03-01 13:04:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:04:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:04:34 --> Utf8 Class Initialized
INFO - 2016-03-01 13:04:34 --> URI Class Initialized
DEBUG - 2016-03-01 13:04:34 --> No URI present. Default controller set.
INFO - 2016-03-01 13:04:34 --> Router Class Initialized
INFO - 2016-03-01 13:04:34 --> Output Class Initialized
INFO - 2016-03-01 13:04:34 --> Security Class Initialized
DEBUG - 2016-03-01 13:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:04:34 --> Input Class Initialized
INFO - 2016-03-01 13:04:34 --> Language Class Initialized
INFO - 2016-03-01 13:04:34 --> Loader Class Initialized
INFO - 2016-03-01 13:04:34 --> Helper loaded: url_helper
INFO - 2016-03-01 13:04:34 --> Helper loaded: file_helper
INFO - 2016-03-01 13:04:34 --> Helper loaded: date_helper
INFO - 2016-03-01 13:04:34 --> Helper loaded: form_helper
INFO - 2016-03-01 13:04:34 --> Database Driver Class Initialized
INFO - 2016-03-01 13:04:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:04:35 --> Controller Class Initialized
INFO - 2016-03-01 13:04:35 --> Model Class Initialized
INFO - 2016-03-01 13:04:35 --> Model Class Initialized
INFO - 2016-03-01 13:04:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:04:35 --> Pagination Class Initialized
INFO - 2016-03-01 13:04:35 --> Helper loaded: text_helper
INFO - 2016-03-01 13:04:35 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:04:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:04:35 --> Final output sent to browser
DEBUG - 2016-03-01 16:04:35 --> Total execution time: 1.2067
INFO - 2016-03-01 13:06:08 --> Config Class Initialized
INFO - 2016-03-01 13:06:08 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:06:08 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:06:08 --> Utf8 Class Initialized
INFO - 2016-03-01 13:06:08 --> URI Class Initialized
DEBUG - 2016-03-01 13:06:08 --> No URI present. Default controller set.
INFO - 2016-03-01 13:06:08 --> Router Class Initialized
INFO - 2016-03-01 13:06:08 --> Output Class Initialized
INFO - 2016-03-01 13:06:08 --> Security Class Initialized
DEBUG - 2016-03-01 13:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:06:08 --> Input Class Initialized
INFO - 2016-03-01 13:06:08 --> Language Class Initialized
INFO - 2016-03-01 13:06:09 --> Loader Class Initialized
INFO - 2016-03-01 13:06:09 --> Helper loaded: url_helper
INFO - 2016-03-01 13:06:09 --> Helper loaded: file_helper
INFO - 2016-03-01 13:06:09 --> Helper loaded: date_helper
INFO - 2016-03-01 13:06:09 --> Helper loaded: form_helper
INFO - 2016-03-01 13:06:09 --> Database Driver Class Initialized
INFO - 2016-03-01 13:06:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:06:10 --> Controller Class Initialized
INFO - 2016-03-01 13:06:10 --> Model Class Initialized
INFO - 2016-03-01 13:06:10 --> Model Class Initialized
INFO - 2016-03-01 13:06:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:06:10 --> Pagination Class Initialized
INFO - 2016-03-01 13:06:10 --> Helper loaded: text_helper
INFO - 2016-03-01 13:06:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:06:10 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:06:10 --> Final output sent to browser
DEBUG - 2016-03-01 16:06:10 --> Total execution time: 1.2880
INFO - 2016-03-01 13:07:12 --> Config Class Initialized
INFO - 2016-03-01 13:07:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:07:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:07:12 --> Utf8 Class Initialized
INFO - 2016-03-01 13:07:12 --> URI Class Initialized
DEBUG - 2016-03-01 13:07:12 --> No URI present. Default controller set.
INFO - 2016-03-01 13:07:12 --> Router Class Initialized
INFO - 2016-03-01 13:07:12 --> Output Class Initialized
INFO - 2016-03-01 13:07:12 --> Security Class Initialized
DEBUG - 2016-03-01 13:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:07:12 --> Input Class Initialized
INFO - 2016-03-01 13:07:12 --> Language Class Initialized
INFO - 2016-03-01 13:07:12 --> Loader Class Initialized
INFO - 2016-03-01 13:07:12 --> Helper loaded: url_helper
INFO - 2016-03-01 13:07:12 --> Helper loaded: file_helper
INFO - 2016-03-01 13:07:12 --> Helper loaded: date_helper
INFO - 2016-03-01 13:07:12 --> Helper loaded: form_helper
INFO - 2016-03-01 13:07:12 --> Database Driver Class Initialized
INFO - 2016-03-01 13:07:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:07:13 --> Controller Class Initialized
INFO - 2016-03-01 13:07:13 --> Model Class Initialized
INFO - 2016-03-01 13:07:13 --> Model Class Initialized
INFO - 2016-03-01 13:07:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:07:13 --> Pagination Class Initialized
INFO - 2016-03-01 13:07:13 --> Helper loaded: text_helper
INFO - 2016-03-01 13:07:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:07:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:07:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:07:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:07:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:07:13 --> Final output sent to browser
DEBUG - 2016-03-01 16:07:13 --> Total execution time: 1.1207
INFO - 2016-03-01 13:07:53 --> Config Class Initialized
INFO - 2016-03-01 13:07:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:07:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:07:53 --> Utf8 Class Initialized
INFO - 2016-03-01 13:07:53 --> URI Class Initialized
DEBUG - 2016-03-01 13:07:53 --> No URI present. Default controller set.
INFO - 2016-03-01 13:07:53 --> Router Class Initialized
INFO - 2016-03-01 13:07:53 --> Output Class Initialized
INFO - 2016-03-01 13:07:53 --> Security Class Initialized
DEBUG - 2016-03-01 13:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:07:53 --> Input Class Initialized
INFO - 2016-03-01 13:07:53 --> Language Class Initialized
INFO - 2016-03-01 13:07:53 --> Loader Class Initialized
INFO - 2016-03-01 13:07:53 --> Helper loaded: url_helper
INFO - 2016-03-01 13:07:53 --> Helper loaded: file_helper
INFO - 2016-03-01 13:07:53 --> Helper loaded: date_helper
INFO - 2016-03-01 13:07:53 --> Helper loaded: form_helper
INFO - 2016-03-01 13:07:53 --> Database Driver Class Initialized
INFO - 2016-03-01 13:07:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:07:54 --> Controller Class Initialized
INFO - 2016-03-01 13:07:54 --> Model Class Initialized
INFO - 2016-03-01 13:07:54 --> Model Class Initialized
INFO - 2016-03-01 13:07:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:07:54 --> Pagination Class Initialized
INFO - 2016-03-01 13:07:54 --> Helper loaded: text_helper
INFO - 2016-03-01 13:07:54 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:07:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:07:54 --> Final output sent to browser
DEBUG - 2016-03-01 16:07:54 --> Total execution time: 1.1271
INFO - 2016-03-01 13:10:45 --> Config Class Initialized
INFO - 2016-03-01 13:10:45 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:10:45 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:10:45 --> Utf8 Class Initialized
INFO - 2016-03-01 13:10:45 --> URI Class Initialized
DEBUG - 2016-03-01 13:10:45 --> No URI present. Default controller set.
INFO - 2016-03-01 13:10:45 --> Router Class Initialized
INFO - 2016-03-01 13:10:45 --> Output Class Initialized
INFO - 2016-03-01 13:10:45 --> Security Class Initialized
DEBUG - 2016-03-01 13:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:10:45 --> Input Class Initialized
INFO - 2016-03-01 13:10:45 --> Language Class Initialized
INFO - 2016-03-01 13:10:45 --> Loader Class Initialized
INFO - 2016-03-01 13:10:45 --> Helper loaded: url_helper
INFO - 2016-03-01 13:10:45 --> Helper loaded: file_helper
INFO - 2016-03-01 13:10:45 --> Helper loaded: date_helper
INFO - 2016-03-01 13:10:45 --> Helper loaded: form_helper
INFO - 2016-03-01 13:10:45 --> Database Driver Class Initialized
INFO - 2016-03-01 13:10:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:10:46 --> Controller Class Initialized
INFO - 2016-03-01 13:10:46 --> Model Class Initialized
INFO - 2016-03-01 13:10:46 --> Model Class Initialized
INFO - 2016-03-01 13:10:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:10:46 --> Pagination Class Initialized
INFO - 2016-03-01 13:10:46 --> Helper loaded: text_helper
INFO - 2016-03-01 13:10:46 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:10:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:10:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:10:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:10:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:10:46 --> Final output sent to browser
DEBUG - 2016-03-01 16:10:46 --> Total execution time: 1.1593
INFO - 2016-03-01 13:14:08 --> Config Class Initialized
INFO - 2016-03-01 13:14:08 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:14:08 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:14:08 --> Utf8 Class Initialized
INFO - 2016-03-01 13:14:08 --> URI Class Initialized
DEBUG - 2016-03-01 13:14:08 --> No URI present. Default controller set.
INFO - 2016-03-01 13:14:08 --> Router Class Initialized
INFO - 2016-03-01 13:14:08 --> Output Class Initialized
INFO - 2016-03-01 13:14:08 --> Security Class Initialized
DEBUG - 2016-03-01 13:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:14:08 --> Input Class Initialized
INFO - 2016-03-01 13:14:08 --> Language Class Initialized
INFO - 2016-03-01 13:14:08 --> Loader Class Initialized
INFO - 2016-03-01 13:14:08 --> Helper loaded: url_helper
INFO - 2016-03-01 13:14:08 --> Helper loaded: file_helper
INFO - 2016-03-01 13:14:08 --> Helper loaded: date_helper
INFO - 2016-03-01 13:14:08 --> Helper loaded: form_helper
INFO - 2016-03-01 13:14:08 --> Database Driver Class Initialized
INFO - 2016-03-01 13:14:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:14:09 --> Controller Class Initialized
INFO - 2016-03-01 13:14:09 --> Model Class Initialized
INFO - 2016-03-01 13:14:09 --> Model Class Initialized
INFO - 2016-03-01 13:14:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:14:09 --> Pagination Class Initialized
INFO - 2016-03-01 13:14:09 --> Helper loaded: text_helper
INFO - 2016-03-01 13:14:09 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:14:09 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:14:09 --> Final output sent to browser
DEBUG - 2016-03-01 16:14:09 --> Total execution time: 1.1122
INFO - 2016-03-01 13:14:33 --> Config Class Initialized
INFO - 2016-03-01 13:14:33 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:14:33 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:14:33 --> Utf8 Class Initialized
INFO - 2016-03-01 13:14:33 --> URI Class Initialized
DEBUG - 2016-03-01 13:14:33 --> No URI present. Default controller set.
INFO - 2016-03-01 13:14:33 --> Router Class Initialized
INFO - 2016-03-01 13:14:33 --> Output Class Initialized
INFO - 2016-03-01 13:14:33 --> Security Class Initialized
DEBUG - 2016-03-01 13:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:14:33 --> Input Class Initialized
INFO - 2016-03-01 13:14:33 --> Language Class Initialized
INFO - 2016-03-01 13:14:33 --> Loader Class Initialized
INFO - 2016-03-01 13:14:33 --> Helper loaded: url_helper
INFO - 2016-03-01 13:14:33 --> Helper loaded: file_helper
INFO - 2016-03-01 13:14:33 --> Helper loaded: date_helper
INFO - 2016-03-01 13:14:33 --> Helper loaded: form_helper
INFO - 2016-03-01 13:14:33 --> Database Driver Class Initialized
INFO - 2016-03-01 13:14:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:14:34 --> Controller Class Initialized
INFO - 2016-03-01 13:14:34 --> Model Class Initialized
INFO - 2016-03-01 13:14:34 --> Model Class Initialized
INFO - 2016-03-01 13:14:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:14:34 --> Pagination Class Initialized
INFO - 2016-03-01 13:14:34 --> Helper loaded: text_helper
INFO - 2016-03-01 13:14:34 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:14:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:14:34 --> Final output sent to browser
DEBUG - 2016-03-01 16:14:34 --> Total execution time: 1.1137
INFO - 2016-03-01 13:15:06 --> Config Class Initialized
INFO - 2016-03-01 13:15:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:15:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:15:06 --> Utf8 Class Initialized
INFO - 2016-03-01 13:15:06 --> URI Class Initialized
INFO - 2016-03-01 13:15:06 --> Router Class Initialized
INFO - 2016-03-01 13:15:06 --> Output Class Initialized
INFO - 2016-03-01 13:15:06 --> Security Class Initialized
DEBUG - 2016-03-01 13:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:15:06 --> Input Class Initialized
INFO - 2016-03-01 13:15:06 --> Language Class Initialized
INFO - 2016-03-01 13:15:06 --> Loader Class Initialized
INFO - 2016-03-01 13:15:06 --> Helper loaded: url_helper
INFO - 2016-03-01 13:15:06 --> Helper loaded: file_helper
INFO - 2016-03-01 13:15:06 --> Helper loaded: date_helper
INFO - 2016-03-01 13:15:06 --> Helper loaded: form_helper
INFO - 2016-03-01 13:15:06 --> Database Driver Class Initialized
INFO - 2016-03-01 13:15:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:15:07 --> Controller Class Initialized
INFO - 2016-03-01 13:15:07 --> Model Class Initialized
INFO - 2016-03-01 13:15:07 --> Model Class Initialized
INFO - 2016-03-01 13:15:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:15:07 --> Pagination Class Initialized
INFO - 2016-03-01 13:15:07 --> Helper loaded: text_helper
INFO - 2016-03-01 13:15:07 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:15:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:15:07 --> Final output sent to browser
DEBUG - 2016-03-01 16:15:07 --> Total execution time: 1.2246
INFO - 2016-03-01 13:25:48 --> Config Class Initialized
INFO - 2016-03-01 13:25:48 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:25:48 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:25:48 --> Utf8 Class Initialized
INFO - 2016-03-01 13:25:49 --> URI Class Initialized
INFO - 2016-03-01 13:25:49 --> Router Class Initialized
INFO - 2016-03-01 13:25:49 --> Output Class Initialized
INFO - 2016-03-01 13:25:49 --> Security Class Initialized
DEBUG - 2016-03-01 13:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:25:49 --> Input Class Initialized
INFO - 2016-03-01 13:25:49 --> Language Class Initialized
INFO - 2016-03-01 13:25:49 --> Loader Class Initialized
INFO - 2016-03-01 13:25:49 --> Helper loaded: url_helper
INFO - 2016-03-01 13:25:49 --> Helper loaded: file_helper
INFO - 2016-03-01 13:25:49 --> Helper loaded: date_helper
INFO - 2016-03-01 13:25:49 --> Helper loaded: form_helper
INFO - 2016-03-01 13:25:49 --> Database Driver Class Initialized
INFO - 2016-03-01 13:25:50 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:25:50 --> Controller Class Initialized
INFO - 2016-03-01 13:25:50 --> Model Class Initialized
INFO - 2016-03-01 13:25:50 --> Model Class Initialized
INFO - 2016-03-01 13:25:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:25:50 --> Pagination Class Initialized
INFO - 2016-03-01 13:25:50 --> Helper loaded: text_helper
INFO - 2016-03-01 13:25:50 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:25:50 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:25:50 --> Final output sent to browser
DEBUG - 2016-03-01 16:25:50 --> Total execution time: 1.6041
INFO - 2016-03-01 13:25:56 --> Config Class Initialized
INFO - 2016-03-01 13:25:56 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:25:56 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:25:56 --> Utf8 Class Initialized
INFO - 2016-03-01 13:25:56 --> URI Class Initialized
INFO - 2016-03-01 13:25:56 --> Router Class Initialized
INFO - 2016-03-01 13:25:56 --> Output Class Initialized
INFO - 2016-03-01 13:25:56 --> Security Class Initialized
DEBUG - 2016-03-01 13:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:25:56 --> Input Class Initialized
INFO - 2016-03-01 13:25:56 --> Language Class Initialized
INFO - 2016-03-01 13:25:56 --> Loader Class Initialized
INFO - 2016-03-01 13:25:56 --> Helper loaded: url_helper
INFO - 2016-03-01 13:25:56 --> Helper loaded: file_helper
INFO - 2016-03-01 13:25:56 --> Helper loaded: date_helper
INFO - 2016-03-01 13:25:56 --> Helper loaded: form_helper
INFO - 2016-03-01 13:25:56 --> Database Driver Class Initialized
INFO - 2016-03-01 13:25:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:25:57 --> Controller Class Initialized
INFO - 2016-03-01 13:25:57 --> Model Class Initialized
INFO - 2016-03-01 13:25:57 --> Model Class Initialized
INFO - 2016-03-01 13:25:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:25:57 --> Pagination Class Initialized
INFO - 2016-03-01 13:25:57 --> Helper loaded: text_helper
INFO - 2016-03-01 13:25:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:25:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:25:57 --> Final output sent to browser
DEBUG - 2016-03-01 16:25:57 --> Total execution time: 1.2265
INFO - 2016-03-01 13:26:12 --> Config Class Initialized
INFO - 2016-03-01 13:26:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:26:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:26:12 --> Utf8 Class Initialized
INFO - 2016-03-01 13:26:12 --> URI Class Initialized
INFO - 2016-03-01 13:26:12 --> Router Class Initialized
INFO - 2016-03-01 13:26:12 --> Output Class Initialized
INFO - 2016-03-01 13:26:12 --> Security Class Initialized
DEBUG - 2016-03-01 13:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:26:12 --> Input Class Initialized
INFO - 2016-03-01 13:26:12 --> Language Class Initialized
INFO - 2016-03-01 13:26:12 --> Loader Class Initialized
INFO - 2016-03-01 13:26:12 --> Helper loaded: url_helper
INFO - 2016-03-01 13:26:12 --> Helper loaded: file_helper
INFO - 2016-03-01 13:26:12 --> Helper loaded: date_helper
INFO - 2016-03-01 13:26:12 --> Helper loaded: form_helper
INFO - 2016-03-01 13:26:12 --> Database Driver Class Initialized
INFO - 2016-03-01 13:26:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:26:13 --> Controller Class Initialized
INFO - 2016-03-01 13:26:13 --> Model Class Initialized
INFO - 2016-03-01 13:26:13 --> Model Class Initialized
INFO - 2016-03-01 13:26:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:26:13 --> Pagination Class Initialized
INFO - 2016-03-01 13:26:13 --> Helper loaded: text_helper
INFO - 2016-03-01 13:26:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:26:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:26:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:26:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:26:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:26:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:26:13 --> Final output sent to browser
DEBUG - 2016-03-01 16:26:13 --> Total execution time: 1.2152
INFO - 2016-03-01 13:29:54 --> Config Class Initialized
INFO - 2016-03-01 13:29:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:29:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:29:54 --> Utf8 Class Initialized
INFO - 2016-03-01 13:29:54 --> URI Class Initialized
INFO - 2016-03-01 13:29:54 --> Router Class Initialized
INFO - 2016-03-01 13:29:54 --> Output Class Initialized
INFO - 2016-03-01 13:29:54 --> Security Class Initialized
DEBUG - 2016-03-01 13:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:29:54 --> Input Class Initialized
INFO - 2016-03-01 13:29:54 --> Language Class Initialized
INFO - 2016-03-01 13:29:54 --> Loader Class Initialized
INFO - 2016-03-01 13:29:55 --> Helper loaded: url_helper
INFO - 2016-03-01 13:29:55 --> Helper loaded: file_helper
INFO - 2016-03-01 13:29:55 --> Helper loaded: date_helper
INFO - 2016-03-01 13:29:55 --> Helper loaded: form_helper
INFO - 2016-03-01 13:29:55 --> Database Driver Class Initialized
INFO - 2016-03-01 13:29:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:29:56 --> Controller Class Initialized
INFO - 2016-03-01 13:29:56 --> Model Class Initialized
INFO - 2016-03-01 13:29:56 --> Model Class Initialized
INFO - 2016-03-01 13:29:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:29:56 --> Pagination Class Initialized
INFO - 2016-03-01 13:29:56 --> Helper loaded: text_helper
INFO - 2016-03-01 13:29:56 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:29:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:29:56 --> Final output sent to browser
DEBUG - 2016-03-01 16:29:56 --> Total execution time: 1.2994
INFO - 2016-03-01 13:32:24 --> Config Class Initialized
INFO - 2016-03-01 13:32:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:32:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:32:24 --> Utf8 Class Initialized
INFO - 2016-03-01 13:32:24 --> URI Class Initialized
INFO - 2016-03-01 13:32:24 --> Router Class Initialized
INFO - 2016-03-01 13:32:24 --> Output Class Initialized
INFO - 2016-03-01 13:32:24 --> Security Class Initialized
DEBUG - 2016-03-01 13:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:32:24 --> Input Class Initialized
INFO - 2016-03-01 13:32:24 --> Language Class Initialized
INFO - 2016-03-01 13:32:24 --> Loader Class Initialized
INFO - 2016-03-01 13:32:24 --> Helper loaded: url_helper
INFO - 2016-03-01 13:32:24 --> Helper loaded: file_helper
INFO - 2016-03-01 13:32:24 --> Helper loaded: date_helper
INFO - 2016-03-01 13:32:24 --> Helper loaded: form_helper
INFO - 2016-03-01 13:32:24 --> Database Driver Class Initialized
INFO - 2016-03-01 13:32:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:32:25 --> Controller Class Initialized
INFO - 2016-03-01 13:32:25 --> Model Class Initialized
INFO - 2016-03-01 13:32:25 --> Model Class Initialized
INFO - 2016-03-01 13:32:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:32:25 --> Pagination Class Initialized
INFO - 2016-03-01 13:32:25 --> Helper loaded: text_helper
INFO - 2016-03-01 13:32:25 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:32:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:32:25 --> Final output sent to browser
DEBUG - 2016-03-01 16:32:25 --> Total execution time: 1.2039
INFO - 2016-03-01 13:36:51 --> Config Class Initialized
INFO - 2016-03-01 13:36:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:36:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:36:51 --> Utf8 Class Initialized
INFO - 2016-03-01 13:36:51 --> URI Class Initialized
INFO - 2016-03-01 13:36:51 --> Router Class Initialized
INFO - 2016-03-01 13:36:51 --> Output Class Initialized
INFO - 2016-03-01 13:36:51 --> Security Class Initialized
DEBUG - 2016-03-01 13:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:36:51 --> Input Class Initialized
INFO - 2016-03-01 13:36:51 --> Language Class Initialized
INFO - 2016-03-01 13:36:51 --> Loader Class Initialized
INFO - 2016-03-01 13:36:51 --> Helper loaded: url_helper
INFO - 2016-03-01 13:36:51 --> Helper loaded: file_helper
INFO - 2016-03-01 13:36:51 --> Helper loaded: date_helper
INFO - 2016-03-01 13:36:51 --> Helper loaded: form_helper
INFO - 2016-03-01 13:36:52 --> Database Driver Class Initialized
INFO - 2016-03-01 13:36:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:36:53 --> Controller Class Initialized
INFO - 2016-03-01 13:36:53 --> Model Class Initialized
INFO - 2016-03-01 13:36:53 --> Model Class Initialized
INFO - 2016-03-01 13:36:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:36:53 --> Pagination Class Initialized
INFO - 2016-03-01 13:36:53 --> Helper loaded: text_helper
INFO - 2016-03-01 13:36:53 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:36:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:36:53 --> Final output sent to browser
DEBUG - 2016-03-01 16:36:53 --> Total execution time: 1.1820
INFO - 2016-03-01 13:38:28 --> Config Class Initialized
INFO - 2016-03-01 13:38:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:38:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:38:28 --> Utf8 Class Initialized
INFO - 2016-03-01 13:38:28 --> URI Class Initialized
INFO - 2016-03-01 13:38:28 --> Router Class Initialized
INFO - 2016-03-01 13:38:28 --> Output Class Initialized
INFO - 2016-03-01 13:38:28 --> Security Class Initialized
DEBUG - 2016-03-01 13:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:38:28 --> Input Class Initialized
INFO - 2016-03-01 13:38:28 --> Language Class Initialized
INFO - 2016-03-01 13:38:28 --> Loader Class Initialized
INFO - 2016-03-01 13:38:28 --> Helper loaded: url_helper
INFO - 2016-03-01 13:38:28 --> Helper loaded: file_helper
INFO - 2016-03-01 13:38:28 --> Helper loaded: date_helper
INFO - 2016-03-01 13:38:28 --> Helper loaded: form_helper
INFO - 2016-03-01 13:38:28 --> Database Driver Class Initialized
INFO - 2016-03-01 13:38:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:38:29 --> Controller Class Initialized
INFO - 2016-03-01 13:38:29 --> Model Class Initialized
INFO - 2016-03-01 13:38:29 --> Model Class Initialized
INFO - 2016-03-01 13:38:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:38:29 --> Pagination Class Initialized
INFO - 2016-03-01 13:38:29 --> Helper loaded: text_helper
INFO - 2016-03-01 13:38:29 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:38:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:38:29 --> Final output sent to browser
DEBUG - 2016-03-01 16:38:29 --> Total execution time: 1.2996
INFO - 2016-03-01 13:41:06 --> Config Class Initialized
INFO - 2016-03-01 13:41:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:41:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:41:06 --> Utf8 Class Initialized
INFO - 2016-03-01 13:41:06 --> URI Class Initialized
DEBUG - 2016-03-01 13:41:06 --> No URI present. Default controller set.
INFO - 2016-03-01 13:41:06 --> Router Class Initialized
INFO - 2016-03-01 13:41:06 --> Output Class Initialized
INFO - 2016-03-01 13:41:06 --> Security Class Initialized
DEBUG - 2016-03-01 13:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:41:06 --> Input Class Initialized
INFO - 2016-03-01 13:41:06 --> Language Class Initialized
INFO - 2016-03-01 13:41:06 --> Loader Class Initialized
INFO - 2016-03-01 13:41:06 --> Helper loaded: url_helper
INFO - 2016-03-01 13:41:06 --> Helper loaded: file_helper
INFO - 2016-03-01 13:41:06 --> Helper loaded: date_helper
INFO - 2016-03-01 13:41:06 --> Helper loaded: form_helper
INFO - 2016-03-01 13:41:06 --> Database Driver Class Initialized
INFO - 2016-03-01 13:41:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:41:07 --> Controller Class Initialized
INFO - 2016-03-01 13:41:07 --> Model Class Initialized
INFO - 2016-03-01 13:41:07 --> Model Class Initialized
INFO - 2016-03-01 13:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:41:07 --> Pagination Class Initialized
INFO - 2016-03-01 13:41:07 --> Helper loaded: text_helper
INFO - 2016-03-01 13:41:07 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:41:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:41:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:41:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:41:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:41:07 --> Final output sent to browser
DEBUG - 2016-03-01 16:41:07 --> Total execution time: 1.1220
INFO - 2016-03-01 13:41:15 --> Config Class Initialized
INFO - 2016-03-01 13:41:15 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:41:15 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:41:15 --> Utf8 Class Initialized
INFO - 2016-03-01 13:41:15 --> URI Class Initialized
INFO - 2016-03-01 13:41:15 --> Router Class Initialized
INFO - 2016-03-01 13:41:15 --> Output Class Initialized
INFO - 2016-03-01 13:41:15 --> Security Class Initialized
DEBUG - 2016-03-01 13:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:41:15 --> Input Class Initialized
INFO - 2016-03-01 13:41:15 --> Language Class Initialized
INFO - 2016-03-01 13:41:15 --> Loader Class Initialized
INFO - 2016-03-01 13:41:15 --> Helper loaded: url_helper
INFO - 2016-03-01 13:41:15 --> Helper loaded: file_helper
INFO - 2016-03-01 13:41:15 --> Helper loaded: date_helper
INFO - 2016-03-01 13:41:15 --> Helper loaded: form_helper
INFO - 2016-03-01 13:41:15 --> Database Driver Class Initialized
INFO - 2016-03-01 13:41:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:41:16 --> Controller Class Initialized
INFO - 2016-03-01 13:41:16 --> Model Class Initialized
INFO - 2016-03-01 13:41:16 --> Model Class Initialized
INFO - 2016-03-01 13:41:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:41:16 --> Pagination Class Initialized
INFO - 2016-03-01 13:41:16 --> Helper loaded: text_helper
INFO - 2016-03-01 13:41:16 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 16:41:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:41:16 --> Final output sent to browser
DEBUG - 2016-03-01 16:41:16 --> Total execution time: 1.1196
INFO - 2016-03-01 13:42:43 --> Config Class Initialized
INFO - 2016-03-01 13:42:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:42:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:42:43 --> Utf8 Class Initialized
INFO - 2016-03-01 13:42:43 --> URI Class Initialized
INFO - 2016-03-01 13:42:43 --> Router Class Initialized
INFO - 2016-03-01 13:42:43 --> Output Class Initialized
INFO - 2016-03-01 13:42:43 --> Security Class Initialized
DEBUG - 2016-03-01 13:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:42:43 --> Input Class Initialized
INFO - 2016-03-01 13:42:43 --> Language Class Initialized
INFO - 2016-03-01 13:42:43 --> Loader Class Initialized
INFO - 2016-03-01 13:42:43 --> Helper loaded: url_helper
INFO - 2016-03-01 13:42:43 --> Helper loaded: file_helper
INFO - 2016-03-01 13:42:43 --> Helper loaded: date_helper
INFO - 2016-03-01 13:42:43 --> Helper loaded: form_helper
INFO - 2016-03-01 13:42:43 --> Database Driver Class Initialized
INFO - 2016-03-01 13:42:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:42:44 --> Controller Class Initialized
INFO - 2016-03-01 13:42:44 --> Model Class Initialized
INFO - 2016-03-01 13:42:44 --> Model Class Initialized
INFO - 2016-03-01 13:42:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:42:44 --> Pagination Class Initialized
INFO - 2016-03-01 13:42:44 --> Helper loaded: text_helper
INFO - 2016-03-01 13:42:44 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:42:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:42:44 --> Final output sent to browser
DEBUG - 2016-03-01 16:42:44 --> Total execution time: 1.2068
INFO - 2016-03-01 13:43:28 --> Config Class Initialized
INFO - 2016-03-01 13:43:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:43:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:43:28 --> Utf8 Class Initialized
INFO - 2016-03-01 13:43:28 --> URI Class Initialized
INFO - 2016-03-01 13:43:28 --> Router Class Initialized
INFO - 2016-03-01 13:43:28 --> Output Class Initialized
INFO - 2016-03-01 13:43:28 --> Security Class Initialized
DEBUG - 2016-03-01 13:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:43:28 --> Input Class Initialized
INFO - 2016-03-01 13:43:28 --> Language Class Initialized
INFO - 2016-03-01 13:43:28 --> Loader Class Initialized
INFO - 2016-03-01 13:43:28 --> Helper loaded: url_helper
INFO - 2016-03-01 13:43:28 --> Helper loaded: file_helper
INFO - 2016-03-01 13:43:28 --> Helper loaded: date_helper
INFO - 2016-03-01 13:43:28 --> Helper loaded: form_helper
INFO - 2016-03-01 13:43:28 --> Database Driver Class Initialized
INFO - 2016-03-01 13:43:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:43:29 --> Controller Class Initialized
INFO - 2016-03-01 13:43:29 --> Model Class Initialized
INFO - 2016-03-01 13:43:29 --> Model Class Initialized
INFO - 2016-03-01 13:43:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:43:29 --> Pagination Class Initialized
INFO - 2016-03-01 13:43:29 --> Helper loaded: text_helper
INFO - 2016-03-01 13:43:29 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:43:29 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:43:30 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:43:30 --> Final output sent to browser
DEBUG - 2016-03-01 16:43:30 --> Total execution time: 1.2053
INFO - 2016-03-01 13:44:03 --> Config Class Initialized
INFO - 2016-03-01 13:44:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:44:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:44:03 --> Utf8 Class Initialized
INFO - 2016-03-01 13:44:03 --> URI Class Initialized
INFO - 2016-03-01 13:44:03 --> Router Class Initialized
INFO - 2016-03-01 13:44:03 --> Output Class Initialized
INFO - 2016-03-01 13:44:03 --> Security Class Initialized
DEBUG - 2016-03-01 13:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:44:03 --> Input Class Initialized
INFO - 2016-03-01 13:44:03 --> Language Class Initialized
INFO - 2016-03-01 13:44:03 --> Loader Class Initialized
INFO - 2016-03-01 13:44:03 --> Helper loaded: url_helper
INFO - 2016-03-01 13:44:03 --> Helper loaded: file_helper
INFO - 2016-03-01 13:44:03 --> Helper loaded: date_helper
INFO - 2016-03-01 13:44:03 --> Helper loaded: form_helper
INFO - 2016-03-01 13:44:03 --> Database Driver Class Initialized
INFO - 2016-03-01 13:44:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:44:04 --> Controller Class Initialized
INFO - 2016-03-01 13:44:04 --> Model Class Initialized
INFO - 2016-03-01 13:44:04 --> Model Class Initialized
INFO - 2016-03-01 13:44:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:44:04 --> Pagination Class Initialized
INFO - 2016-03-01 13:44:04 --> Helper loaded: text_helper
INFO - 2016-03-01 13:44:04 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:44:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:44:04 --> Final output sent to browser
DEBUG - 2016-03-01 16:44:04 --> Total execution time: 1.1794
INFO - 2016-03-01 13:46:04 --> Config Class Initialized
INFO - 2016-03-01 13:46:04 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:46:04 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:46:04 --> Utf8 Class Initialized
INFO - 2016-03-01 13:46:04 --> URI Class Initialized
INFO - 2016-03-01 13:46:04 --> Router Class Initialized
INFO - 2016-03-01 13:46:04 --> Output Class Initialized
INFO - 2016-03-01 13:46:04 --> Security Class Initialized
DEBUG - 2016-03-01 13:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:46:05 --> Input Class Initialized
INFO - 2016-03-01 13:46:05 --> Language Class Initialized
INFO - 2016-03-01 13:46:05 --> Loader Class Initialized
INFO - 2016-03-01 13:46:05 --> Helper loaded: url_helper
INFO - 2016-03-01 13:46:05 --> Helper loaded: file_helper
INFO - 2016-03-01 13:46:05 --> Helper loaded: date_helper
INFO - 2016-03-01 13:46:05 --> Helper loaded: form_helper
INFO - 2016-03-01 13:46:05 --> Database Driver Class Initialized
INFO - 2016-03-01 13:46:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:46:06 --> Controller Class Initialized
INFO - 2016-03-01 13:46:06 --> Model Class Initialized
INFO - 2016-03-01 13:46:06 --> Model Class Initialized
INFO - 2016-03-01 13:46:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:46:06 --> Pagination Class Initialized
INFO - 2016-03-01 13:46:06 --> Helper loaded: text_helper
INFO - 2016-03-01 13:46:06 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:46:06 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:46:06 --> Final output sent to browser
DEBUG - 2016-03-01 16:46:06 --> Total execution time: 1.2286
INFO - 2016-03-01 13:47:36 --> Config Class Initialized
INFO - 2016-03-01 13:47:36 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:47:36 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:47:36 --> Utf8 Class Initialized
INFO - 2016-03-01 13:47:36 --> URI Class Initialized
INFO - 2016-03-01 13:47:36 --> Router Class Initialized
INFO - 2016-03-01 13:47:36 --> Output Class Initialized
INFO - 2016-03-01 13:47:36 --> Security Class Initialized
DEBUG - 2016-03-01 13:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:47:36 --> Input Class Initialized
INFO - 2016-03-01 13:47:36 --> Language Class Initialized
INFO - 2016-03-01 13:47:36 --> Loader Class Initialized
INFO - 2016-03-01 13:47:36 --> Helper loaded: url_helper
INFO - 2016-03-01 13:47:36 --> Helper loaded: file_helper
INFO - 2016-03-01 13:47:36 --> Helper loaded: date_helper
INFO - 2016-03-01 13:47:36 --> Helper loaded: form_helper
INFO - 2016-03-01 13:47:36 --> Database Driver Class Initialized
INFO - 2016-03-01 13:47:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:47:37 --> Controller Class Initialized
INFO - 2016-03-01 13:47:37 --> Model Class Initialized
INFO - 2016-03-01 13:47:37 --> Model Class Initialized
INFO - 2016-03-01 13:47:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:47:37 --> Pagination Class Initialized
INFO - 2016-03-01 13:47:37 --> Helper loaded: text_helper
INFO - 2016-03-01 13:47:37 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:47:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:47:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:47:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:47:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:47:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:47:37 --> Final output sent to browser
DEBUG - 2016-03-01 16:47:37 --> Total execution time: 1.2639
INFO - 2016-03-01 13:48:04 --> Config Class Initialized
INFO - 2016-03-01 13:48:04 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:48:04 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:48:04 --> Utf8 Class Initialized
INFO - 2016-03-01 13:48:04 --> URI Class Initialized
INFO - 2016-03-01 13:48:04 --> Router Class Initialized
INFO - 2016-03-01 13:48:04 --> Output Class Initialized
INFO - 2016-03-01 13:48:04 --> Security Class Initialized
DEBUG - 2016-03-01 13:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:48:04 --> Input Class Initialized
INFO - 2016-03-01 13:48:04 --> Language Class Initialized
INFO - 2016-03-01 13:48:04 --> Loader Class Initialized
INFO - 2016-03-01 13:48:04 --> Helper loaded: url_helper
INFO - 2016-03-01 13:48:04 --> Helper loaded: file_helper
INFO - 2016-03-01 13:48:04 --> Helper loaded: date_helper
INFO - 2016-03-01 13:48:04 --> Helper loaded: form_helper
INFO - 2016-03-01 13:48:04 --> Database Driver Class Initialized
INFO - 2016-03-01 13:48:05 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:48:05 --> Controller Class Initialized
INFO - 2016-03-01 13:48:05 --> Model Class Initialized
INFO - 2016-03-01 13:48:05 --> Model Class Initialized
INFO - 2016-03-01 13:48:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:48:05 --> Pagination Class Initialized
INFO - 2016-03-01 13:48:05 --> Helper loaded: text_helper
INFO - 2016-03-01 13:48:05 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:48:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:48:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:48:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:48:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:48:05 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:48:05 --> Final output sent to browser
DEBUG - 2016-03-01 16:48:05 --> Total execution time: 1.1954
INFO - 2016-03-01 13:50:01 --> Config Class Initialized
INFO - 2016-03-01 13:50:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:50:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:50:01 --> Utf8 Class Initialized
INFO - 2016-03-01 13:50:01 --> URI Class Initialized
INFO - 2016-03-01 13:50:01 --> Router Class Initialized
INFO - 2016-03-01 13:50:01 --> Output Class Initialized
INFO - 2016-03-01 13:50:01 --> Security Class Initialized
DEBUG - 2016-03-01 13:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:50:01 --> Input Class Initialized
INFO - 2016-03-01 13:50:01 --> Language Class Initialized
INFO - 2016-03-01 13:50:01 --> Loader Class Initialized
INFO - 2016-03-01 13:50:01 --> Helper loaded: url_helper
INFO - 2016-03-01 13:50:01 --> Helper loaded: file_helper
INFO - 2016-03-01 13:50:01 --> Helper loaded: date_helper
INFO - 2016-03-01 13:50:01 --> Helper loaded: form_helper
INFO - 2016-03-01 13:50:01 --> Database Driver Class Initialized
INFO - 2016-03-01 13:50:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:50:02 --> Controller Class Initialized
INFO - 2016-03-01 13:50:02 --> Model Class Initialized
INFO - 2016-03-01 13:50:02 --> Model Class Initialized
INFO - 2016-03-01 13:50:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:50:02 --> Pagination Class Initialized
INFO - 2016-03-01 13:50:02 --> Helper loaded: text_helper
INFO - 2016-03-01 13:50:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:50:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:50:02 --> Final output sent to browser
DEBUG - 2016-03-01 16:50:02 --> Total execution time: 1.1785
INFO - 2016-03-01 13:52:43 --> Config Class Initialized
INFO - 2016-03-01 13:52:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:52:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:52:43 --> Utf8 Class Initialized
INFO - 2016-03-01 13:52:43 --> URI Class Initialized
INFO - 2016-03-01 13:52:43 --> Router Class Initialized
INFO - 2016-03-01 13:52:43 --> Output Class Initialized
INFO - 2016-03-01 13:52:43 --> Security Class Initialized
DEBUG - 2016-03-01 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:52:43 --> Input Class Initialized
INFO - 2016-03-01 13:52:43 --> Language Class Initialized
INFO - 2016-03-01 13:52:43 --> Loader Class Initialized
INFO - 2016-03-01 13:52:43 --> Helper loaded: url_helper
INFO - 2016-03-01 13:52:43 --> Helper loaded: file_helper
INFO - 2016-03-01 13:52:43 --> Helper loaded: date_helper
INFO - 2016-03-01 13:52:43 --> Helper loaded: form_helper
INFO - 2016-03-01 13:52:43 --> Database Driver Class Initialized
INFO - 2016-03-01 13:52:44 --> Config Class Initialized
INFO - 2016-03-01 13:52:44 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:52:44 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:52:44 --> Utf8 Class Initialized
INFO - 2016-03-01 13:52:44 --> URI Class Initialized
INFO - 2016-03-01 13:52:44 --> Router Class Initialized
INFO - 2016-03-01 13:52:44 --> Output Class Initialized
INFO - 2016-03-01 13:52:44 --> Security Class Initialized
DEBUG - 2016-03-01 13:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:52:44 --> Input Class Initialized
INFO - 2016-03-01 13:52:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:52:44 --> Language Class Initialized
INFO - 2016-03-01 13:52:44 --> Controller Class Initialized
INFO - 2016-03-01 13:52:44 --> Model Class Initialized
INFO - 2016-03-01 13:52:44 --> Loader Class Initialized
INFO - 2016-03-01 13:52:44 --> Model Class Initialized
INFO - 2016-03-01 13:52:44 --> Helper loaded: url_helper
INFO - 2016-03-01 13:52:44 --> Form Validation Class Initialized
INFO - 2016-03-01 13:52:44 --> Helper loaded: file_helper
INFO - 2016-03-01 13:52:44 --> Helper loaded: text_helper
INFO - 2016-03-01 13:52:44 --> Helper loaded: date_helper
INFO - 2016-03-01 13:52:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:52:44 --> Helper loaded: form_helper
INFO - 2016-03-01 13:52:44 --> Database Driver Class Initialized
INFO - 2016-03-01 13:52:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 13:52:44 --> Final output sent to browser
DEBUG - 2016-03-01 13:52:44 --> Total execution time: 1.1026
INFO - 2016-03-01 13:52:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:52:45 --> Controller Class Initialized
INFO - 2016-03-01 13:52:45 --> Model Class Initialized
INFO - 2016-03-01 13:52:45 --> Model Class Initialized
INFO - 2016-03-01 13:52:45 --> Form Validation Class Initialized
INFO - 2016-03-01 13:52:45 --> Helper loaded: text_helper
INFO - 2016-03-01 13:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 13:52:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 13:52:45 --> Final output sent to browser
DEBUG - 2016-03-01 13:52:45 --> Total execution time: 1.0948
INFO - 2016-03-01 13:52:47 --> Config Class Initialized
INFO - 2016-03-01 13:52:47 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:52:47 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:52:47 --> Utf8 Class Initialized
INFO - 2016-03-01 13:52:47 --> URI Class Initialized
INFO - 2016-03-01 13:52:47 --> Router Class Initialized
INFO - 2016-03-01 13:52:47 --> Output Class Initialized
INFO - 2016-03-01 13:52:47 --> Security Class Initialized
DEBUG - 2016-03-01 13:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:52:47 --> Input Class Initialized
INFO - 2016-03-01 13:52:47 --> Language Class Initialized
INFO - 2016-03-01 13:52:47 --> Loader Class Initialized
INFO - 2016-03-01 13:52:47 --> Helper loaded: url_helper
INFO - 2016-03-01 13:52:47 --> Helper loaded: file_helper
INFO - 2016-03-01 13:52:47 --> Helper loaded: date_helper
INFO - 2016-03-01 13:52:47 --> Helper loaded: form_helper
INFO - 2016-03-01 13:52:47 --> Database Driver Class Initialized
INFO - 2016-03-01 13:52:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:52:48 --> Controller Class Initialized
INFO - 2016-03-01 13:52:48 --> Model Class Initialized
INFO - 2016-03-01 13:52:48 --> Model Class Initialized
INFO - 2016-03-01 13:52:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:52:48 --> Pagination Class Initialized
INFO - 2016-03-01 13:52:48 --> Helper loaded: text_helper
INFO - 2016-03-01 13:52:48 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:52:48 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:52:48 --> Final output sent to browser
DEBUG - 2016-03-01 16:52:48 --> Total execution time: 1.2143
INFO - 2016-03-01 13:53:40 --> Config Class Initialized
INFO - 2016-03-01 13:53:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:53:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:53:40 --> Utf8 Class Initialized
INFO - 2016-03-01 13:53:40 --> URI Class Initialized
INFO - 2016-03-01 13:53:40 --> Router Class Initialized
INFO - 2016-03-01 13:53:40 --> Output Class Initialized
INFO - 2016-03-01 13:53:40 --> Security Class Initialized
DEBUG - 2016-03-01 13:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:53:40 --> Input Class Initialized
INFO - 2016-03-01 13:53:40 --> Language Class Initialized
INFO - 2016-03-01 13:53:40 --> Loader Class Initialized
INFO - 2016-03-01 13:53:41 --> Helper loaded: url_helper
INFO - 2016-03-01 13:53:41 --> Helper loaded: file_helper
INFO - 2016-03-01 13:53:41 --> Helper loaded: date_helper
INFO - 2016-03-01 13:53:41 --> Helper loaded: form_helper
INFO - 2016-03-01 13:53:41 --> Database Driver Class Initialized
INFO - 2016-03-01 13:53:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:53:42 --> Controller Class Initialized
INFO - 2016-03-01 13:53:42 --> Model Class Initialized
INFO - 2016-03-01 13:53:42 --> Model Class Initialized
INFO - 2016-03-01 13:53:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:53:42 --> Pagination Class Initialized
INFO - 2016-03-01 13:53:42 --> Helper loaded: text_helper
INFO - 2016-03-01 13:53:42 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:53:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:53:42 --> Final output sent to browser
DEBUG - 2016-03-01 16:53:42 --> Total execution time: 1.1884
INFO - 2016-03-01 13:54:15 --> Config Class Initialized
INFO - 2016-03-01 13:54:15 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:54:15 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:54:15 --> Utf8 Class Initialized
INFO - 2016-03-01 13:54:15 --> URI Class Initialized
INFO - 2016-03-01 13:54:15 --> Router Class Initialized
INFO - 2016-03-01 13:54:15 --> Output Class Initialized
INFO - 2016-03-01 13:54:15 --> Security Class Initialized
DEBUG - 2016-03-01 13:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:54:15 --> Input Class Initialized
INFO - 2016-03-01 13:54:15 --> Language Class Initialized
INFO - 2016-03-01 13:54:15 --> Loader Class Initialized
INFO - 2016-03-01 13:54:15 --> Helper loaded: url_helper
INFO - 2016-03-01 13:54:15 --> Helper loaded: file_helper
INFO - 2016-03-01 13:54:15 --> Helper loaded: date_helper
INFO - 2016-03-01 13:54:15 --> Helper loaded: form_helper
INFO - 2016-03-01 13:54:15 --> Database Driver Class Initialized
INFO - 2016-03-01 13:54:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:54:16 --> Controller Class Initialized
INFO - 2016-03-01 13:54:16 --> Model Class Initialized
INFO - 2016-03-01 13:54:16 --> Model Class Initialized
INFO - 2016-03-01 13:54:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:54:16 --> Pagination Class Initialized
INFO - 2016-03-01 13:54:16 --> Helper loaded: text_helper
INFO - 2016-03-01 13:54:16 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:54:16 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:54:16 --> Final output sent to browser
DEBUG - 2016-03-01 16:54:16 --> Total execution time: 1.2394
INFO - 2016-03-01 13:54:17 --> Config Class Initialized
INFO - 2016-03-01 13:54:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:54:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:54:17 --> Utf8 Class Initialized
INFO - 2016-03-01 13:54:17 --> URI Class Initialized
DEBUG - 2016-03-01 13:54:17 --> No URI present. Default controller set.
INFO - 2016-03-01 13:54:17 --> Router Class Initialized
INFO - 2016-03-01 13:54:17 --> Output Class Initialized
INFO - 2016-03-01 13:54:17 --> Security Class Initialized
DEBUG - 2016-03-01 13:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:54:17 --> Input Class Initialized
INFO - 2016-03-01 13:54:17 --> Language Class Initialized
INFO - 2016-03-01 13:54:18 --> Loader Class Initialized
INFO - 2016-03-01 13:54:18 --> Helper loaded: url_helper
INFO - 2016-03-01 13:54:18 --> Helper loaded: file_helper
INFO - 2016-03-01 13:54:18 --> Helper loaded: date_helper
INFO - 2016-03-01 13:54:18 --> Helper loaded: form_helper
INFO - 2016-03-01 13:54:18 --> Database Driver Class Initialized
INFO - 2016-03-01 13:54:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:54:19 --> Controller Class Initialized
INFO - 2016-03-01 13:54:19 --> Model Class Initialized
INFO - 2016-03-01 13:54:19 --> Model Class Initialized
INFO - 2016-03-01 13:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:54:19 --> Pagination Class Initialized
INFO - 2016-03-01 13:54:19 --> Helper loaded: text_helper
INFO - 2016-03-01 13:54:19 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:54:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:54:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:54:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:54:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:54:19 --> Final output sent to browser
DEBUG - 2016-03-01 16:54:19 --> Total execution time: 1.1590
INFO - 2016-03-01 13:54:40 --> Config Class Initialized
INFO - 2016-03-01 13:54:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:54:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:54:40 --> Utf8 Class Initialized
INFO - 2016-03-01 13:54:40 --> URI Class Initialized
INFO - 2016-03-01 13:54:40 --> Router Class Initialized
INFO - 2016-03-01 13:54:40 --> Output Class Initialized
INFO - 2016-03-01 13:54:40 --> Security Class Initialized
DEBUG - 2016-03-01 13:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:54:40 --> Input Class Initialized
INFO - 2016-03-01 13:54:40 --> Language Class Initialized
INFO - 2016-03-01 13:54:40 --> Loader Class Initialized
INFO - 2016-03-01 13:54:40 --> Helper loaded: url_helper
INFO - 2016-03-01 13:54:40 --> Helper loaded: file_helper
INFO - 2016-03-01 13:54:40 --> Helper loaded: date_helper
INFO - 2016-03-01 13:54:40 --> Helper loaded: form_helper
INFO - 2016-03-01 13:54:40 --> Database Driver Class Initialized
INFO - 2016-03-01 13:54:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:54:41 --> Controller Class Initialized
INFO - 2016-03-01 13:54:41 --> Model Class Initialized
INFO - 2016-03-01 13:54:41 --> Model Class Initialized
INFO - 2016-03-01 13:54:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:54:41 --> Pagination Class Initialized
INFO - 2016-03-01 13:54:41 --> Helper loaded: text_helper
INFO - 2016-03-01 13:54:41 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 16:54:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:54:41 --> Final output sent to browser
DEBUG - 2016-03-01 16:54:41 --> Total execution time: 1.1113
INFO - 2016-03-01 13:54:43 --> Config Class Initialized
INFO - 2016-03-01 13:54:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:54:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:54:43 --> Utf8 Class Initialized
INFO - 2016-03-01 13:54:43 --> URI Class Initialized
INFO - 2016-03-01 13:54:43 --> Router Class Initialized
INFO - 2016-03-01 13:54:43 --> Output Class Initialized
INFO - 2016-03-01 13:54:43 --> Security Class Initialized
DEBUG - 2016-03-01 13:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:54:43 --> Input Class Initialized
INFO - 2016-03-01 13:54:43 --> Language Class Initialized
INFO - 2016-03-01 13:54:43 --> Loader Class Initialized
INFO - 2016-03-01 13:54:43 --> Helper loaded: url_helper
INFO - 2016-03-01 13:54:43 --> Helper loaded: file_helper
INFO - 2016-03-01 13:54:43 --> Helper loaded: date_helper
INFO - 2016-03-01 13:54:43 --> Helper loaded: form_helper
INFO - 2016-03-01 13:54:43 --> Database Driver Class Initialized
INFO - 2016-03-01 13:54:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:54:44 --> Controller Class Initialized
INFO - 2016-03-01 13:54:44 --> Model Class Initialized
INFO - 2016-03-01 13:54:44 --> Model Class Initialized
INFO - 2016-03-01 13:54:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:54:44 --> Pagination Class Initialized
INFO - 2016-03-01 13:54:44 --> Helper loaded: text_helper
INFO - 2016-03-01 13:54:44 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:54:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:54:44 --> Final output sent to browser
DEBUG - 2016-03-01 16:54:44 --> Total execution time: 1.1492
INFO - 2016-03-01 13:57:24 --> Config Class Initialized
INFO - 2016-03-01 13:57:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:57:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:57:24 --> Utf8 Class Initialized
INFO - 2016-03-01 13:57:24 --> URI Class Initialized
DEBUG - 2016-03-01 13:57:24 --> No URI present. Default controller set.
INFO - 2016-03-01 13:57:24 --> Router Class Initialized
INFO - 2016-03-01 13:57:24 --> Output Class Initialized
INFO - 2016-03-01 13:57:24 --> Security Class Initialized
DEBUG - 2016-03-01 13:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:57:24 --> Input Class Initialized
INFO - 2016-03-01 13:57:24 --> Language Class Initialized
INFO - 2016-03-01 13:57:24 --> Loader Class Initialized
INFO - 2016-03-01 13:57:24 --> Helper loaded: url_helper
INFO - 2016-03-01 13:57:24 --> Helper loaded: file_helper
INFO - 2016-03-01 13:57:24 --> Helper loaded: date_helper
INFO - 2016-03-01 13:57:24 --> Helper loaded: form_helper
INFO - 2016-03-01 13:57:24 --> Database Driver Class Initialized
INFO - 2016-03-01 13:57:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:57:25 --> Controller Class Initialized
INFO - 2016-03-01 13:57:25 --> Model Class Initialized
INFO - 2016-03-01 13:57:25 --> Model Class Initialized
INFO - 2016-03-01 13:57:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:57:25 --> Pagination Class Initialized
INFO - 2016-03-01 13:57:25 --> Helper loaded: text_helper
INFO - 2016-03-01 13:57:25 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:57:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:57:25 --> Final output sent to browser
DEBUG - 2016-03-01 16:57:25 --> Total execution time: 1.1092
INFO - 2016-03-01 13:57:33 --> Config Class Initialized
INFO - 2016-03-01 13:57:33 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:57:33 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:57:33 --> Utf8 Class Initialized
INFO - 2016-03-01 13:57:33 --> URI Class Initialized
INFO - 2016-03-01 13:57:33 --> Router Class Initialized
INFO - 2016-03-01 13:57:33 --> Output Class Initialized
INFO - 2016-03-01 13:57:33 --> Security Class Initialized
DEBUG - 2016-03-01 13:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:57:33 --> Input Class Initialized
INFO - 2016-03-01 13:57:33 --> Language Class Initialized
INFO - 2016-03-01 13:57:33 --> Loader Class Initialized
INFO - 2016-03-01 13:57:33 --> Helper loaded: url_helper
INFO - 2016-03-01 13:57:33 --> Helper loaded: file_helper
INFO - 2016-03-01 13:57:33 --> Helper loaded: date_helper
INFO - 2016-03-01 13:57:33 --> Helper loaded: form_helper
INFO - 2016-03-01 13:57:33 --> Database Driver Class Initialized
INFO - 2016-03-01 13:57:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:57:34 --> Controller Class Initialized
INFO - 2016-03-01 13:57:34 --> Model Class Initialized
INFO - 2016-03-01 13:57:34 --> Model Class Initialized
INFO - 2016-03-01 13:57:34 --> Form Validation Class Initialized
INFO - 2016-03-01 13:57:34 --> Helper loaded: text_helper
INFO - 2016-03-01 13:57:35 --> Final output sent to browser
DEBUG - 2016-03-01 13:57:35 --> Total execution time: 1.1824
INFO - 2016-03-01 13:57:35 --> Config Class Initialized
INFO - 2016-03-01 13:57:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:57:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:57:35 --> Utf8 Class Initialized
INFO - 2016-03-01 13:57:35 --> URI Class Initialized
DEBUG - 2016-03-01 13:57:35 --> No URI present. Default controller set.
INFO - 2016-03-01 13:57:35 --> Router Class Initialized
INFO - 2016-03-01 13:57:35 --> Output Class Initialized
INFO - 2016-03-01 13:57:35 --> Security Class Initialized
DEBUG - 2016-03-01 13:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:57:35 --> Input Class Initialized
INFO - 2016-03-01 13:57:35 --> Language Class Initialized
INFO - 2016-03-01 13:57:35 --> Loader Class Initialized
INFO - 2016-03-01 13:57:35 --> Helper loaded: url_helper
INFO - 2016-03-01 13:57:35 --> Helper loaded: file_helper
INFO - 2016-03-01 13:57:35 --> Helper loaded: date_helper
INFO - 2016-03-01 13:57:35 --> Helper loaded: form_helper
INFO - 2016-03-01 13:57:35 --> Database Driver Class Initialized
INFO - 2016-03-01 13:57:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:57:36 --> Controller Class Initialized
INFO - 2016-03-01 13:57:36 --> Model Class Initialized
INFO - 2016-03-01 13:57:36 --> Model Class Initialized
INFO - 2016-03-01 13:57:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:57:36 --> Pagination Class Initialized
INFO - 2016-03-01 13:57:36 --> Helper loaded: text_helper
INFO - 2016-03-01 13:57:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:57:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:57:36 --> Final output sent to browser
DEBUG - 2016-03-01 16:57:36 --> Total execution time: 1.1408
INFO - 2016-03-01 13:57:58 --> Config Class Initialized
INFO - 2016-03-01 13:57:58 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:57:58 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:57:58 --> Utf8 Class Initialized
INFO - 2016-03-01 13:57:58 --> URI Class Initialized
DEBUG - 2016-03-01 13:57:58 --> No URI present. Default controller set.
INFO - 2016-03-01 13:57:58 --> Router Class Initialized
INFO - 2016-03-01 13:57:58 --> Output Class Initialized
INFO - 2016-03-01 13:57:58 --> Security Class Initialized
DEBUG - 2016-03-01 13:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:57:58 --> Input Class Initialized
INFO - 2016-03-01 13:57:58 --> Language Class Initialized
INFO - 2016-03-01 13:57:58 --> Loader Class Initialized
INFO - 2016-03-01 13:57:58 --> Helper loaded: url_helper
INFO - 2016-03-01 13:57:58 --> Helper loaded: file_helper
INFO - 2016-03-01 13:57:58 --> Helper loaded: date_helper
INFO - 2016-03-01 13:57:58 --> Helper loaded: form_helper
INFO - 2016-03-01 13:57:58 --> Database Driver Class Initialized
INFO - 2016-03-01 13:57:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:57:59 --> Controller Class Initialized
INFO - 2016-03-01 13:57:59 --> Model Class Initialized
INFO - 2016-03-01 13:57:59 --> Model Class Initialized
INFO - 2016-03-01 13:57:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:57:59 --> Pagination Class Initialized
INFO - 2016-03-01 13:57:59 --> Helper loaded: text_helper
INFO - 2016-03-01 13:57:59 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 16:57:59 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:57:59 --> Final output sent to browser
DEBUG - 2016-03-01 16:57:59 --> Total execution time: 1.1043
INFO - 2016-03-01 13:58:03 --> Config Class Initialized
INFO - 2016-03-01 13:58:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:58:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:58:03 --> Utf8 Class Initialized
INFO - 2016-03-01 13:58:03 --> URI Class Initialized
INFO - 2016-03-01 13:58:03 --> Router Class Initialized
INFO - 2016-03-01 13:58:03 --> Output Class Initialized
INFO - 2016-03-01 13:58:03 --> Security Class Initialized
DEBUG - 2016-03-01 13:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:58:03 --> Input Class Initialized
INFO - 2016-03-01 13:58:03 --> Language Class Initialized
INFO - 2016-03-01 13:58:03 --> Loader Class Initialized
INFO - 2016-03-01 13:58:03 --> Helper loaded: url_helper
INFO - 2016-03-01 13:58:03 --> Helper loaded: file_helper
INFO - 2016-03-01 13:58:03 --> Helper loaded: date_helper
INFO - 2016-03-01 13:58:03 --> Helper loaded: form_helper
INFO - 2016-03-01 13:58:03 --> Database Driver Class Initialized
INFO - 2016-03-01 13:58:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:58:04 --> Controller Class Initialized
INFO - 2016-03-01 13:58:04 --> Model Class Initialized
INFO - 2016-03-01 13:58:04 --> Model Class Initialized
INFO - 2016-03-01 13:58:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:58:04 --> Pagination Class Initialized
INFO - 2016-03-01 13:58:04 --> Helper loaded: text_helper
INFO - 2016-03-01 13:58:04 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:58:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:58:04 --> Final output sent to browser
DEBUG - 2016-03-01 16:58:04 --> Total execution time: 1.1533
INFO - 2016-03-01 13:58:07 --> Config Class Initialized
INFO - 2016-03-01 13:58:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:58:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:58:07 --> Utf8 Class Initialized
INFO - 2016-03-01 13:58:07 --> URI Class Initialized
INFO - 2016-03-01 13:58:07 --> Router Class Initialized
INFO - 2016-03-01 13:58:07 --> Output Class Initialized
INFO - 2016-03-01 13:58:07 --> Security Class Initialized
DEBUG - 2016-03-01 13:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:58:07 --> Input Class Initialized
INFO - 2016-03-01 13:58:07 --> Language Class Initialized
INFO - 2016-03-01 13:58:07 --> Loader Class Initialized
INFO - 2016-03-01 13:58:07 --> Helper loaded: url_helper
INFO - 2016-03-01 13:58:07 --> Helper loaded: file_helper
INFO - 2016-03-01 13:58:07 --> Helper loaded: date_helper
INFO - 2016-03-01 13:58:07 --> Helper loaded: form_helper
INFO - 2016-03-01 13:58:07 --> Database Driver Class Initialized
INFO - 2016-03-01 13:58:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:58:08 --> Controller Class Initialized
INFO - 2016-03-01 13:58:08 --> Model Class Initialized
INFO - 2016-03-01 13:58:08 --> Model Class Initialized
INFO - 2016-03-01 13:58:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:58:08 --> Pagination Class Initialized
INFO - 2016-03-01 13:58:08 --> Helper loaded: text_helper
INFO - 2016-03-01 13:58:08 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\add.php
INFO - 2016-03-01 16:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:58:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:58:08 --> Final output sent to browser
DEBUG - 2016-03-01 16:58:08 --> Total execution time: 1.1209
INFO - 2016-03-01 13:59:13 --> Config Class Initialized
INFO - 2016-03-01 13:59:13 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:59:13 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:59:13 --> Utf8 Class Initialized
INFO - 2016-03-01 13:59:13 --> URI Class Initialized
INFO - 2016-03-01 13:59:13 --> Router Class Initialized
INFO - 2016-03-01 13:59:13 --> Output Class Initialized
INFO - 2016-03-01 13:59:13 --> Security Class Initialized
DEBUG - 2016-03-01 13:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:59:13 --> Input Class Initialized
INFO - 2016-03-01 13:59:13 --> Language Class Initialized
INFO - 2016-03-01 13:59:13 --> Loader Class Initialized
INFO - 2016-03-01 13:59:13 --> Helper loaded: url_helper
INFO - 2016-03-01 13:59:13 --> Helper loaded: file_helper
INFO - 2016-03-01 13:59:13 --> Helper loaded: date_helper
INFO - 2016-03-01 13:59:13 --> Helper loaded: form_helper
INFO - 2016-03-01 13:59:13 --> Database Driver Class Initialized
INFO - 2016-03-01 13:59:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:59:14 --> Controller Class Initialized
INFO - 2016-03-01 13:59:14 --> Model Class Initialized
INFO - 2016-03-01 13:59:14 --> Model Class Initialized
INFO - 2016-03-01 13:59:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:59:14 --> Pagination Class Initialized
INFO - 2016-03-01 13:59:14 --> Helper loaded: text_helper
INFO - 2016-03-01 13:59:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:59:14 --> Upload Class Initialized
INFO - 2016-03-01 16:59:14 --> Image Lib Class Initialized
DEBUG - 2016-03-01 16:59:14 --> Image_lib class already loaded. Second attempt ignored.
INFO - 2016-03-01 16:59:14 --> Final output sent to browser
DEBUG - 2016-03-01 16:59:14 --> Total execution time: 1.4157
INFO - 2016-03-01 13:59:36 --> Config Class Initialized
INFO - 2016-03-01 13:59:36 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:59:36 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:59:36 --> Utf8 Class Initialized
INFO - 2016-03-01 13:59:36 --> URI Class Initialized
INFO - 2016-03-01 13:59:36 --> Router Class Initialized
INFO - 2016-03-01 13:59:36 --> Output Class Initialized
INFO - 2016-03-01 13:59:36 --> Security Class Initialized
DEBUG - 2016-03-01 13:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:59:36 --> Input Class Initialized
INFO - 2016-03-01 13:59:36 --> Language Class Initialized
INFO - 2016-03-01 13:59:36 --> Loader Class Initialized
INFO - 2016-03-01 13:59:36 --> Helper loaded: url_helper
INFO - 2016-03-01 13:59:36 --> Helper loaded: file_helper
INFO - 2016-03-01 13:59:36 --> Helper loaded: date_helper
INFO - 2016-03-01 13:59:36 --> Helper loaded: form_helper
INFO - 2016-03-01 13:59:36 --> Database Driver Class Initialized
INFO - 2016-03-01 13:59:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:59:37 --> Controller Class Initialized
INFO - 2016-03-01 13:59:37 --> Model Class Initialized
INFO - 2016-03-01 13:59:37 --> Model Class Initialized
INFO - 2016-03-01 13:59:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:59:37 --> Pagination Class Initialized
INFO - 2016-03-01 13:59:37 --> Helper loaded: text_helper
INFO - 2016-03-01 13:59:37 --> Helper loaded: cookie_helper
ERROR - 2016-03-01 16:59:37 --> Severity: Warning --> Missing argument 1 for Wall::add() C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\controllers\wall.php 165
INFO - 2016-03-01 16:59:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:59:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:59:37 --> Form Validation Class Initialized
INFO - 2016-03-01 16:59:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 13:59:38 --> Config Class Initialized
INFO - 2016-03-01 13:59:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 13:59:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 13:59:38 --> Utf8 Class Initialized
INFO - 2016-03-01 13:59:38 --> URI Class Initialized
INFO - 2016-03-01 13:59:38 --> Router Class Initialized
INFO - 2016-03-01 13:59:38 --> Output Class Initialized
INFO - 2016-03-01 13:59:38 --> Security Class Initialized
DEBUG - 2016-03-01 13:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 13:59:38 --> Input Class Initialized
INFO - 2016-03-01 13:59:38 --> Language Class Initialized
INFO - 2016-03-01 13:59:38 --> Loader Class Initialized
INFO - 2016-03-01 13:59:38 --> Helper loaded: url_helper
INFO - 2016-03-01 13:59:38 --> Helper loaded: file_helper
INFO - 2016-03-01 13:59:38 --> Helper loaded: date_helper
INFO - 2016-03-01 13:59:38 --> Helper loaded: form_helper
INFO - 2016-03-01 13:59:38 --> Database Driver Class Initialized
INFO - 2016-03-01 13:59:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 13:59:39 --> Controller Class Initialized
INFO - 2016-03-01 13:59:39 --> Model Class Initialized
INFO - 2016-03-01 13:59:39 --> Model Class Initialized
INFO - 2016-03-01 13:59:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 13:59:39 --> Pagination Class Initialized
INFO - 2016-03-01 13:59:39 --> Helper loaded: text_helper
INFO - 2016-03-01 13:59:39 --> Helper loaded: cookie_helper
INFO - 2016-03-01 16:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 16:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 16:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 16:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 16:59:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 16:59:39 --> Final output sent to browser
DEBUG - 2016-03-01 16:59:39 --> Total execution time: 1.2136
INFO - 2016-03-01 14:00:13 --> Config Class Initialized
INFO - 2016-03-01 14:00:13 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:00:13 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:00:13 --> Utf8 Class Initialized
INFO - 2016-03-01 14:00:13 --> URI Class Initialized
INFO - 2016-03-01 14:00:13 --> Router Class Initialized
INFO - 2016-03-01 14:00:13 --> Output Class Initialized
INFO - 2016-03-01 14:00:13 --> Security Class Initialized
DEBUG - 2016-03-01 14:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:00:13 --> Input Class Initialized
INFO - 2016-03-01 14:00:13 --> Language Class Initialized
INFO - 2016-03-01 14:00:13 --> Loader Class Initialized
INFO - 2016-03-01 14:00:13 --> Helper loaded: url_helper
INFO - 2016-03-01 14:00:13 --> Helper loaded: file_helper
INFO - 2016-03-01 14:00:13 --> Helper loaded: date_helper
INFO - 2016-03-01 14:00:13 --> Helper loaded: form_helper
INFO - 2016-03-01 14:00:13 --> Database Driver Class Initialized
INFO - 2016-03-01 14:00:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:00:14 --> Controller Class Initialized
INFO - 2016-03-01 14:00:14 --> Model Class Initialized
INFO - 2016-03-01 14:00:14 --> Model Class Initialized
INFO - 2016-03-01 14:00:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:00:14 --> Pagination Class Initialized
INFO - 2016-03-01 14:00:14 --> Helper loaded: text_helper
INFO - 2016-03-01 14:00:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 17:00:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:00:14 --> Final output sent to browser
DEBUG - 2016-03-01 17:00:14 --> Total execution time: 1.0962
INFO - 2016-03-01 14:00:16 --> Config Class Initialized
INFO - 2016-03-01 14:00:16 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:00:16 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:00:16 --> Utf8 Class Initialized
INFO - 2016-03-01 14:00:16 --> URI Class Initialized
INFO - 2016-03-01 14:00:16 --> Router Class Initialized
INFO - 2016-03-01 14:00:16 --> Output Class Initialized
INFO - 2016-03-01 14:00:16 --> Security Class Initialized
DEBUG - 2016-03-01 14:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:00:16 --> Input Class Initialized
INFO - 2016-03-01 14:00:16 --> Language Class Initialized
INFO - 2016-03-01 14:00:16 --> Loader Class Initialized
INFO - 2016-03-01 14:00:16 --> Helper loaded: url_helper
INFO - 2016-03-01 14:00:16 --> Helper loaded: file_helper
INFO - 2016-03-01 14:00:16 --> Helper loaded: date_helper
INFO - 2016-03-01 14:00:16 --> Helper loaded: form_helper
INFO - 2016-03-01 14:00:16 --> Database Driver Class Initialized
INFO - 2016-03-01 14:00:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:00:17 --> Controller Class Initialized
INFO - 2016-03-01 14:00:17 --> Model Class Initialized
INFO - 2016-03-01 14:00:17 --> Model Class Initialized
INFO - 2016-03-01 14:00:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:00:17 --> Pagination Class Initialized
INFO - 2016-03-01 14:00:17 --> Helper loaded: text_helper
INFO - 2016-03-01 14:00:17 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:00:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:00:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:00:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:00:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:00:18 --> Final output sent to browser
DEBUG - 2016-03-01 17:00:18 --> Total execution time: 1.2920
INFO - 2016-03-01 14:00:20 --> Config Class Initialized
INFO - 2016-03-01 14:00:20 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:00:20 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:00:20 --> Utf8 Class Initialized
INFO - 2016-03-01 14:00:20 --> URI Class Initialized
INFO - 2016-03-01 14:00:20 --> Router Class Initialized
INFO - 2016-03-01 14:00:20 --> Output Class Initialized
INFO - 2016-03-01 14:00:20 --> Security Class Initialized
DEBUG - 2016-03-01 14:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:00:20 --> Input Class Initialized
INFO - 2016-03-01 14:00:20 --> Language Class Initialized
INFO - 2016-03-01 14:00:20 --> Loader Class Initialized
INFO - 2016-03-01 14:00:20 --> Helper loaded: url_helper
INFO - 2016-03-01 14:00:20 --> Helper loaded: file_helper
INFO - 2016-03-01 14:00:20 --> Helper loaded: date_helper
INFO - 2016-03-01 14:00:20 --> Helper loaded: form_helper
INFO - 2016-03-01 14:00:20 --> Database Driver Class Initialized
INFO - 2016-03-01 14:00:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:00:21 --> Controller Class Initialized
INFO - 2016-03-01 14:00:21 --> Model Class Initialized
INFO - 2016-03-01 14:00:21 --> Model Class Initialized
INFO - 2016-03-01 14:00:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:00:21 --> Pagination Class Initialized
INFO - 2016-03-01 14:00:21 --> Helper loaded: text_helper
INFO - 2016-03-01 14:00:21 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 17:00:21 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:00:21 --> Final output sent to browser
DEBUG - 2016-03-01 17:00:21 --> Total execution time: 1.1129
INFO - 2016-03-01 14:00:23 --> Config Class Initialized
INFO - 2016-03-01 14:00:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:00:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:00:23 --> Utf8 Class Initialized
INFO - 2016-03-01 14:00:23 --> URI Class Initialized
INFO - 2016-03-01 14:00:23 --> Router Class Initialized
INFO - 2016-03-01 14:00:23 --> Output Class Initialized
INFO - 2016-03-01 14:00:23 --> Security Class Initialized
DEBUG - 2016-03-01 14:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:00:23 --> Input Class Initialized
INFO - 2016-03-01 14:00:23 --> Language Class Initialized
INFO - 2016-03-01 14:00:23 --> Loader Class Initialized
INFO - 2016-03-01 14:00:23 --> Helper loaded: url_helper
INFO - 2016-03-01 14:00:23 --> Helper loaded: file_helper
INFO - 2016-03-01 14:00:23 --> Helper loaded: date_helper
INFO - 2016-03-01 14:00:23 --> Helper loaded: form_helper
INFO - 2016-03-01 14:00:23 --> Database Driver Class Initialized
INFO - 2016-03-01 14:00:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:00:25 --> Controller Class Initialized
INFO - 2016-03-01 14:00:25 --> Model Class Initialized
INFO - 2016-03-01 14:00:25 --> Model Class Initialized
INFO - 2016-03-01 14:00:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:00:25 --> Pagination Class Initialized
INFO - 2016-03-01 14:00:25 --> Helper loaded: text_helper
INFO - 2016-03-01 14:00:25 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:00:25 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:00:25 --> Final output sent to browser
DEBUG - 2016-03-01 17:00:25 --> Total execution time: 1.1546
INFO - 2016-03-01 14:12:02 --> Config Class Initialized
INFO - 2016-03-01 14:12:02 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:12:02 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:12:02 --> Utf8 Class Initialized
INFO - 2016-03-01 14:12:02 --> URI Class Initialized
INFO - 2016-03-01 14:12:02 --> Router Class Initialized
INFO - 2016-03-01 14:12:02 --> Output Class Initialized
INFO - 2016-03-01 14:12:02 --> Security Class Initialized
DEBUG - 2016-03-01 14:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:12:02 --> Input Class Initialized
INFO - 2016-03-01 14:12:02 --> Language Class Initialized
INFO - 2016-03-01 14:12:02 --> Loader Class Initialized
INFO - 2016-03-01 14:12:02 --> Helper loaded: url_helper
INFO - 2016-03-01 14:12:02 --> Helper loaded: file_helper
INFO - 2016-03-01 14:12:02 --> Helper loaded: date_helper
INFO - 2016-03-01 14:12:02 --> Helper loaded: form_helper
INFO - 2016-03-01 14:12:02 --> Database Driver Class Initialized
INFO - 2016-03-01 14:12:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:12:03 --> Controller Class Initialized
INFO - 2016-03-01 14:12:03 --> Model Class Initialized
INFO - 2016-03-01 14:12:03 --> Model Class Initialized
INFO - 2016-03-01 14:12:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:12:03 --> Pagination Class Initialized
INFO - 2016-03-01 14:12:03 --> Helper loaded: text_helper
INFO - 2016-03-01 14:12:03 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:12:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:12:03 --> Final output sent to browser
DEBUG - 2016-03-01 17:12:03 --> Total execution time: 1.1567
INFO - 2016-03-01 14:13:46 --> Config Class Initialized
INFO - 2016-03-01 14:13:46 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:13:46 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:13:46 --> Utf8 Class Initialized
INFO - 2016-03-01 14:13:46 --> URI Class Initialized
DEBUG - 2016-03-01 14:13:46 --> No URI present. Default controller set.
INFO - 2016-03-01 14:13:46 --> Router Class Initialized
INFO - 2016-03-01 14:13:46 --> Output Class Initialized
INFO - 2016-03-01 14:13:46 --> Security Class Initialized
DEBUG - 2016-03-01 14:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:13:46 --> Input Class Initialized
INFO - 2016-03-01 14:13:46 --> Language Class Initialized
INFO - 2016-03-01 14:13:46 --> Loader Class Initialized
INFO - 2016-03-01 14:13:46 --> Helper loaded: url_helper
INFO - 2016-03-01 14:13:46 --> Helper loaded: file_helper
INFO - 2016-03-01 14:13:46 --> Helper loaded: date_helper
INFO - 2016-03-01 14:13:46 --> Helper loaded: form_helper
INFO - 2016-03-01 14:13:46 --> Database Driver Class Initialized
INFO - 2016-03-01 14:13:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:13:47 --> Controller Class Initialized
INFO - 2016-03-01 14:13:47 --> Model Class Initialized
INFO - 2016-03-01 14:13:47 --> Model Class Initialized
INFO - 2016-03-01 14:13:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:13:47 --> Pagination Class Initialized
INFO - 2016-03-01 14:13:47 --> Helper loaded: text_helper
INFO - 2016-03-01 14:13:47 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 17:13:47 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:13:47 --> Final output sent to browser
DEBUG - 2016-03-01 17:13:47 --> Total execution time: 1.1140
INFO - 2016-03-01 14:20:34 --> Config Class Initialized
INFO - 2016-03-01 14:20:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:20:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:20:34 --> Utf8 Class Initialized
INFO - 2016-03-01 14:20:34 --> URI Class Initialized
INFO - 2016-03-01 14:20:34 --> Router Class Initialized
INFO - 2016-03-01 14:20:34 --> Output Class Initialized
INFO - 2016-03-01 14:20:34 --> Security Class Initialized
DEBUG - 2016-03-01 14:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:20:34 --> Input Class Initialized
INFO - 2016-03-01 14:20:34 --> Language Class Initialized
INFO - 2016-03-01 14:20:34 --> Loader Class Initialized
INFO - 2016-03-01 14:20:34 --> Helper loaded: url_helper
INFO - 2016-03-01 14:20:34 --> Helper loaded: file_helper
INFO - 2016-03-01 14:20:34 --> Helper loaded: date_helper
INFO - 2016-03-01 14:20:34 --> Helper loaded: form_helper
INFO - 2016-03-01 14:20:34 --> Database Driver Class Initialized
INFO - 2016-03-01 14:20:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:20:35 --> Controller Class Initialized
INFO - 2016-03-01 14:20:35 --> Model Class Initialized
INFO - 2016-03-01 14:20:35 --> Model Class Initialized
INFO - 2016-03-01 14:20:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:20:35 --> Pagination Class Initialized
INFO - 2016-03-01 14:20:35 --> Helper loaded: text_helper
INFO - 2016-03-01 14:20:35 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:20:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:20:35 --> Final output sent to browser
DEBUG - 2016-03-01 17:20:35 --> Total execution time: 1.1755
INFO - 2016-03-01 14:25:18 --> Config Class Initialized
INFO - 2016-03-01 14:25:18 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:25:18 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:25:18 --> Utf8 Class Initialized
INFO - 2016-03-01 14:25:18 --> URI Class Initialized
INFO - 2016-03-01 14:25:18 --> Router Class Initialized
INFO - 2016-03-01 14:25:18 --> Output Class Initialized
INFO - 2016-03-01 14:25:18 --> Security Class Initialized
DEBUG - 2016-03-01 14:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:25:18 --> Input Class Initialized
INFO - 2016-03-01 14:25:18 --> Language Class Initialized
INFO - 2016-03-01 14:25:18 --> Loader Class Initialized
INFO - 2016-03-01 14:25:18 --> Helper loaded: url_helper
INFO - 2016-03-01 14:25:18 --> Helper loaded: file_helper
INFO - 2016-03-01 14:25:18 --> Helper loaded: date_helper
INFO - 2016-03-01 14:25:18 --> Helper loaded: form_helper
INFO - 2016-03-01 14:25:18 --> Database Driver Class Initialized
INFO - 2016-03-01 14:25:19 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:25:19 --> Controller Class Initialized
INFO - 2016-03-01 14:25:19 --> Model Class Initialized
INFO - 2016-03-01 14:25:19 --> Model Class Initialized
INFO - 2016-03-01 14:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:25:19 --> Pagination Class Initialized
INFO - 2016-03-01 14:25:19 --> Helper loaded: text_helper
INFO - 2016-03-01 14:25:19 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:25:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:25:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:25:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:25:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:25:19 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:25:19 --> Final output sent to browser
DEBUG - 2016-03-01 17:25:19 --> Total execution time: 1.1807
INFO - 2016-03-01 14:25:40 --> Config Class Initialized
INFO - 2016-03-01 14:25:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:25:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:25:40 --> Utf8 Class Initialized
INFO - 2016-03-01 14:25:40 --> URI Class Initialized
INFO - 2016-03-01 14:25:40 --> Router Class Initialized
INFO - 2016-03-01 14:25:40 --> Output Class Initialized
INFO - 2016-03-01 14:25:40 --> Security Class Initialized
DEBUG - 2016-03-01 14:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:25:40 --> Input Class Initialized
INFO - 2016-03-01 14:25:40 --> Language Class Initialized
INFO - 2016-03-01 14:25:40 --> Loader Class Initialized
INFO - 2016-03-01 14:25:40 --> Helper loaded: url_helper
INFO - 2016-03-01 14:25:40 --> Helper loaded: file_helper
INFO - 2016-03-01 14:25:40 --> Helper loaded: date_helper
INFO - 2016-03-01 14:25:40 --> Helper loaded: form_helper
INFO - 2016-03-01 14:25:40 --> Database Driver Class Initialized
INFO - 2016-03-01 14:25:41 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:25:41 --> Controller Class Initialized
INFO - 2016-03-01 14:25:41 --> Model Class Initialized
INFO - 2016-03-01 14:25:41 --> Model Class Initialized
INFO - 2016-03-01 14:25:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:25:41 --> Pagination Class Initialized
INFO - 2016-03-01 14:25:41 --> Helper loaded: text_helper
INFO - 2016-03-01 14:25:41 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:25:41 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:25:41 --> Final output sent to browser
DEBUG - 2016-03-01 17:25:41 --> Total execution time: 1.1636
INFO - 2016-03-01 14:25:53 --> Config Class Initialized
INFO - 2016-03-01 14:25:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:25:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:25:53 --> Utf8 Class Initialized
INFO - 2016-03-01 14:25:53 --> URI Class Initialized
INFO - 2016-03-01 14:25:53 --> Router Class Initialized
INFO - 2016-03-01 14:25:53 --> Output Class Initialized
INFO - 2016-03-01 14:25:53 --> Security Class Initialized
DEBUG - 2016-03-01 14:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:25:53 --> Input Class Initialized
INFO - 2016-03-01 14:25:53 --> Language Class Initialized
INFO - 2016-03-01 14:25:53 --> Loader Class Initialized
INFO - 2016-03-01 14:25:53 --> Helper loaded: url_helper
INFO - 2016-03-01 14:25:53 --> Helper loaded: file_helper
INFO - 2016-03-01 14:25:53 --> Helper loaded: date_helper
INFO - 2016-03-01 14:25:53 --> Helper loaded: form_helper
INFO - 2016-03-01 14:25:53 --> Database Driver Class Initialized
INFO - 2016-03-01 14:25:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:25:55 --> Controller Class Initialized
INFO - 2016-03-01 14:25:55 --> Model Class Initialized
INFO - 2016-03-01 14:25:55 --> Model Class Initialized
INFO - 2016-03-01 14:25:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:25:55 --> Pagination Class Initialized
INFO - 2016-03-01 14:25:55 --> Helper loaded: text_helper
INFO - 2016-03-01 14:25:55 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:25:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:25:55 --> Final output sent to browser
DEBUG - 2016-03-01 17:25:55 --> Total execution time: 1.1884
INFO - 2016-03-01 14:26:36 --> Config Class Initialized
INFO - 2016-03-01 14:26:36 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:26:36 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:26:36 --> Utf8 Class Initialized
INFO - 2016-03-01 14:26:36 --> URI Class Initialized
INFO - 2016-03-01 14:26:36 --> Router Class Initialized
INFO - 2016-03-01 14:26:36 --> Output Class Initialized
INFO - 2016-03-01 14:26:36 --> Security Class Initialized
DEBUG - 2016-03-01 14:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:26:36 --> Input Class Initialized
INFO - 2016-03-01 14:26:36 --> Language Class Initialized
INFO - 2016-03-01 14:26:36 --> Loader Class Initialized
INFO - 2016-03-01 14:26:36 --> Helper loaded: url_helper
INFO - 2016-03-01 14:26:36 --> Helper loaded: file_helper
INFO - 2016-03-01 14:26:36 --> Helper loaded: date_helper
INFO - 2016-03-01 14:26:36 --> Helper loaded: form_helper
INFO - 2016-03-01 14:26:36 --> Database Driver Class Initialized
INFO - 2016-03-01 14:26:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:26:37 --> Controller Class Initialized
INFO - 2016-03-01 14:26:37 --> Model Class Initialized
INFO - 2016-03-01 14:26:37 --> Model Class Initialized
INFO - 2016-03-01 14:26:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:26:37 --> Pagination Class Initialized
INFO - 2016-03-01 14:26:37 --> Helper loaded: text_helper
INFO - 2016-03-01 14:26:37 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:26:37 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:26:37 --> Final output sent to browser
DEBUG - 2016-03-01 17:26:37 --> Total execution time: 1.1649
INFO - 2016-03-01 14:26:59 --> Config Class Initialized
INFO - 2016-03-01 14:26:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:26:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:26:59 --> Utf8 Class Initialized
INFO - 2016-03-01 14:26:59 --> URI Class Initialized
INFO - 2016-03-01 14:26:59 --> Router Class Initialized
INFO - 2016-03-01 14:26:59 --> Output Class Initialized
INFO - 2016-03-01 14:26:59 --> Security Class Initialized
DEBUG - 2016-03-01 14:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:26:59 --> Input Class Initialized
INFO - 2016-03-01 14:26:59 --> Language Class Initialized
INFO - 2016-03-01 14:26:59 --> Loader Class Initialized
INFO - 2016-03-01 14:26:59 --> Helper loaded: url_helper
INFO - 2016-03-01 14:26:59 --> Helper loaded: file_helper
INFO - 2016-03-01 14:26:59 --> Helper loaded: date_helper
INFO - 2016-03-01 14:26:59 --> Helper loaded: form_helper
INFO - 2016-03-01 14:26:59 --> Database Driver Class Initialized
INFO - 2016-03-01 14:27:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:27:00 --> Controller Class Initialized
INFO - 2016-03-01 14:27:00 --> Model Class Initialized
INFO - 2016-03-01 14:27:00 --> Model Class Initialized
INFO - 2016-03-01 14:27:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:27:00 --> Pagination Class Initialized
INFO - 2016-03-01 14:27:00 --> Helper loaded: text_helper
INFO - 2016-03-01 14:27:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:27:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:27:00 --> Final output sent to browser
DEBUG - 2016-03-01 17:27:00 --> Total execution time: 1.1742
INFO - 2016-03-01 14:27:03 --> Config Class Initialized
INFO - 2016-03-01 14:27:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:27:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:27:03 --> Utf8 Class Initialized
INFO - 2016-03-01 14:27:03 --> URI Class Initialized
INFO - 2016-03-01 14:27:03 --> Router Class Initialized
INFO - 2016-03-01 14:27:03 --> Output Class Initialized
INFO - 2016-03-01 14:27:03 --> Security Class Initialized
DEBUG - 2016-03-01 14:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:27:03 --> Input Class Initialized
INFO - 2016-03-01 14:27:03 --> Language Class Initialized
INFO - 2016-03-01 14:27:03 --> Loader Class Initialized
INFO - 2016-03-01 14:27:03 --> Helper loaded: url_helper
INFO - 2016-03-01 14:27:03 --> Helper loaded: file_helper
INFO - 2016-03-01 14:27:03 --> Helper loaded: date_helper
INFO - 2016-03-01 14:27:03 --> Helper loaded: form_helper
INFO - 2016-03-01 14:27:03 --> Database Driver Class Initialized
INFO - 2016-03-01 14:27:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:27:04 --> Controller Class Initialized
INFO - 2016-03-01 14:27:04 --> Model Class Initialized
INFO - 2016-03-01 14:27:04 --> Model Class Initialized
INFO - 2016-03-01 14:27:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:27:04 --> Pagination Class Initialized
INFO - 2016-03-01 14:27:04 --> Helper loaded: text_helper
INFO - 2016-03-01 14:27:04 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:27:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:27:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:27:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:27:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:27:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:27:04 --> Final output sent to browser
DEBUG - 2016-03-01 17:27:04 --> Total execution time: 1.3126
INFO - 2016-03-01 14:38:34 --> Config Class Initialized
INFO - 2016-03-01 14:38:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:38:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:38:34 --> Utf8 Class Initialized
INFO - 2016-03-01 14:38:34 --> URI Class Initialized
INFO - 2016-03-01 14:38:34 --> Router Class Initialized
INFO - 2016-03-01 14:38:34 --> Output Class Initialized
INFO - 2016-03-01 14:38:34 --> Security Class Initialized
DEBUG - 2016-03-01 14:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:38:34 --> Input Class Initialized
INFO - 2016-03-01 14:38:34 --> Language Class Initialized
INFO - 2016-03-01 14:38:34 --> Loader Class Initialized
INFO - 2016-03-01 14:38:34 --> Helper loaded: url_helper
INFO - 2016-03-01 14:38:34 --> Helper loaded: file_helper
INFO - 2016-03-01 14:38:34 --> Helper loaded: date_helper
INFO - 2016-03-01 14:38:34 --> Helper loaded: form_helper
INFO - 2016-03-01 14:38:34 --> Database Driver Class Initialized
INFO - 2016-03-01 14:38:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:38:35 --> Controller Class Initialized
INFO - 2016-03-01 14:38:35 --> Model Class Initialized
INFO - 2016-03-01 14:38:35 --> Model Class Initialized
INFO - 2016-03-01 14:38:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:38:35 --> Pagination Class Initialized
INFO - 2016-03-01 14:38:35 --> Helper loaded: text_helper
INFO - 2016-03-01 14:38:35 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:38:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:38:35 --> Final output sent to browser
DEBUG - 2016-03-01 17:38:35 --> Total execution time: 1.6800
INFO - 2016-03-01 14:38:38 --> Config Class Initialized
INFO - 2016-03-01 14:38:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:38:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:38:38 --> Utf8 Class Initialized
INFO - 2016-03-01 14:38:38 --> URI Class Initialized
DEBUG - 2016-03-01 14:38:38 --> No URI present. Default controller set.
INFO - 2016-03-01 14:38:38 --> Router Class Initialized
INFO - 2016-03-01 14:38:38 --> Output Class Initialized
INFO - 2016-03-01 14:38:38 --> Security Class Initialized
DEBUG - 2016-03-01 14:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:38:38 --> Input Class Initialized
INFO - 2016-03-01 14:38:38 --> Language Class Initialized
INFO - 2016-03-01 14:38:38 --> Loader Class Initialized
INFO - 2016-03-01 14:38:38 --> Helper loaded: url_helper
INFO - 2016-03-01 14:38:38 --> Helper loaded: file_helper
INFO - 2016-03-01 14:38:38 --> Helper loaded: date_helper
INFO - 2016-03-01 14:38:38 --> Helper loaded: form_helper
INFO - 2016-03-01 14:38:38 --> Database Driver Class Initialized
INFO - 2016-03-01 14:38:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:38:39 --> Controller Class Initialized
INFO - 2016-03-01 14:38:39 --> Model Class Initialized
INFO - 2016-03-01 14:38:39 --> Model Class Initialized
INFO - 2016-03-01 14:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:38:39 --> Pagination Class Initialized
INFO - 2016-03-01 14:38:39 --> Helper loaded: text_helper
INFO - 2016-03-01 14:38:39 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:38:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:38:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:38:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 17:38:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:38:39 --> Final output sent to browser
DEBUG - 2016-03-01 17:38:39 --> Total execution time: 1.1946
INFO - 2016-03-01 14:38:52 --> Config Class Initialized
INFO - 2016-03-01 14:38:52 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:38:52 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:38:52 --> Utf8 Class Initialized
INFO - 2016-03-01 14:38:52 --> URI Class Initialized
INFO - 2016-03-01 14:38:52 --> Router Class Initialized
INFO - 2016-03-01 14:38:52 --> Output Class Initialized
INFO - 2016-03-01 14:38:52 --> Security Class Initialized
DEBUG - 2016-03-01 14:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:38:52 --> Input Class Initialized
INFO - 2016-03-01 14:38:52 --> Language Class Initialized
INFO - 2016-03-01 14:38:52 --> Loader Class Initialized
INFO - 2016-03-01 14:38:52 --> Helper loaded: url_helper
INFO - 2016-03-01 14:38:52 --> Helper loaded: file_helper
INFO - 2016-03-01 14:38:52 --> Helper loaded: date_helper
INFO - 2016-03-01 14:38:52 --> Helper loaded: form_helper
INFO - 2016-03-01 14:38:52 --> Database Driver Class Initialized
INFO - 2016-03-01 14:38:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:38:53 --> Controller Class Initialized
INFO - 2016-03-01 14:38:53 --> Model Class Initialized
INFO - 2016-03-01 14:38:53 --> Model Class Initialized
INFO - 2016-03-01 14:38:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:38:53 --> Pagination Class Initialized
INFO - 2016-03-01 14:38:53 --> Helper loaded: text_helper
INFO - 2016-03-01 14:38:53 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:38:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:38:53 --> Final output sent to browser
DEBUG - 2016-03-01 17:38:53 --> Total execution time: 1.1814
INFO - 2016-03-01 14:38:54 --> Config Class Initialized
INFO - 2016-03-01 14:38:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:38:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:38:54 --> Utf8 Class Initialized
INFO - 2016-03-01 14:38:54 --> URI Class Initialized
INFO - 2016-03-01 14:38:54 --> Router Class Initialized
INFO - 2016-03-01 14:38:54 --> Output Class Initialized
INFO - 2016-03-01 14:38:54 --> Security Class Initialized
DEBUG - 2016-03-01 14:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:38:54 --> Input Class Initialized
INFO - 2016-03-01 14:38:54 --> Language Class Initialized
INFO - 2016-03-01 14:38:54 --> Loader Class Initialized
INFO - 2016-03-01 14:38:54 --> Helper loaded: url_helper
INFO - 2016-03-01 14:38:54 --> Helper loaded: file_helper
INFO - 2016-03-01 14:38:54 --> Helper loaded: date_helper
INFO - 2016-03-01 14:38:54 --> Helper loaded: form_helper
INFO - 2016-03-01 14:38:54 --> Database Driver Class Initialized
INFO - 2016-03-01 14:38:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:38:55 --> Controller Class Initialized
INFO - 2016-03-01 14:38:55 --> Model Class Initialized
INFO - 2016-03-01 14:38:55 --> Model Class Initialized
INFO - 2016-03-01 14:38:55 --> Form Validation Class Initialized
INFO - 2016-03-01 14:38:55 --> Helper loaded: text_helper
INFO - 2016-03-01 14:38:55 --> Config Class Initialized
INFO - 2016-03-01 14:38:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:38:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:38:55 --> Utf8 Class Initialized
INFO - 2016-03-01 14:38:55 --> URI Class Initialized
DEBUG - 2016-03-01 14:38:55 --> No URI present. Default controller set.
INFO - 2016-03-01 14:38:55 --> Router Class Initialized
INFO - 2016-03-01 14:38:55 --> Output Class Initialized
INFO - 2016-03-01 14:38:55 --> Security Class Initialized
DEBUG - 2016-03-01 14:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:38:55 --> Input Class Initialized
INFO - 2016-03-01 14:38:55 --> Language Class Initialized
INFO - 2016-03-01 14:38:55 --> Loader Class Initialized
INFO - 2016-03-01 14:38:55 --> Helper loaded: url_helper
INFO - 2016-03-01 14:38:55 --> Helper loaded: file_helper
INFO - 2016-03-01 14:38:55 --> Helper loaded: date_helper
INFO - 2016-03-01 14:38:55 --> Helper loaded: form_helper
INFO - 2016-03-01 14:38:55 --> Database Driver Class Initialized
INFO - 2016-03-01 14:38:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:38:57 --> Controller Class Initialized
INFO - 2016-03-01 14:38:57 --> Model Class Initialized
INFO - 2016-03-01 14:38:57 --> Model Class Initialized
INFO - 2016-03-01 14:38:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:38:57 --> Pagination Class Initialized
INFO - 2016-03-01 14:38:57 --> Helper loaded: text_helper
INFO - 2016-03-01 14:38:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:38:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:38:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:38:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 17:38:57 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:38:57 --> Final output sent to browser
DEBUG - 2016-03-01 17:38:57 --> Total execution time: 1.2305
INFO - 2016-03-01 14:38:58 --> Config Class Initialized
INFO - 2016-03-01 14:38:58 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:38:58 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:38:58 --> Utf8 Class Initialized
INFO - 2016-03-01 14:38:58 --> URI Class Initialized
INFO - 2016-03-01 14:38:58 --> Router Class Initialized
INFO - 2016-03-01 14:38:58 --> Output Class Initialized
INFO - 2016-03-01 14:38:58 --> Security Class Initialized
DEBUG - 2016-03-01 14:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:38:58 --> Input Class Initialized
INFO - 2016-03-01 14:38:59 --> Language Class Initialized
INFO - 2016-03-01 14:38:59 --> Loader Class Initialized
INFO - 2016-03-01 14:38:59 --> Helper loaded: url_helper
INFO - 2016-03-01 14:38:59 --> Helper loaded: file_helper
INFO - 2016-03-01 14:38:59 --> Helper loaded: date_helper
INFO - 2016-03-01 14:38:59 --> Helper loaded: form_helper
INFO - 2016-03-01 14:38:59 --> Database Driver Class Initialized
INFO - 2016-03-01 14:39:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:39:00 --> Controller Class Initialized
INFO - 2016-03-01 14:39:00 --> Model Class Initialized
INFO - 2016-03-01 14:39:00 --> Model Class Initialized
INFO - 2016-03-01 14:39:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:39:00 --> Pagination Class Initialized
INFO - 2016-03-01 14:39:00 --> Helper loaded: text_helper
INFO - 2016-03-01 14:39:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:39:00 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:39:00 --> Final output sent to browser
DEBUG - 2016-03-01 17:39:00 --> Total execution time: 1.1856
INFO - 2016-03-01 14:39:01 --> Config Class Initialized
INFO - 2016-03-01 14:39:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:39:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:39:01 --> Utf8 Class Initialized
INFO - 2016-03-01 14:39:01 --> URI Class Initialized
INFO - 2016-03-01 14:39:01 --> Router Class Initialized
INFO - 2016-03-01 14:39:01 --> Output Class Initialized
INFO - 2016-03-01 14:39:01 --> Security Class Initialized
DEBUG - 2016-03-01 14:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:39:01 --> Input Class Initialized
INFO - 2016-03-01 14:39:01 --> Language Class Initialized
INFO - 2016-03-01 14:39:01 --> Loader Class Initialized
INFO - 2016-03-01 14:39:01 --> Helper loaded: url_helper
INFO - 2016-03-01 14:39:01 --> Helper loaded: file_helper
INFO - 2016-03-01 14:39:01 --> Helper loaded: date_helper
INFO - 2016-03-01 14:39:01 --> Helper loaded: form_helper
INFO - 2016-03-01 14:39:01 --> Database Driver Class Initialized
INFO - 2016-03-01 14:39:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:39:02 --> Controller Class Initialized
INFO - 2016-03-01 14:39:02 --> Model Class Initialized
INFO - 2016-03-01 14:39:02 --> Model Class Initialized
INFO - 2016-03-01 14:39:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:39:02 --> Pagination Class Initialized
INFO - 2016-03-01 14:39:02 --> Helper loaded: text_helper
INFO - 2016-03-01 14:39:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 17:39:02 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 17:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:39:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:39:02 --> Final output sent to browser
DEBUG - 2016-03-01 17:39:02 --> Total execution time: 1.2253
INFO - 2016-03-01 14:39:38 --> Config Class Initialized
INFO - 2016-03-01 14:39:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:39:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:39:38 --> Utf8 Class Initialized
INFO - 2016-03-01 14:39:38 --> URI Class Initialized
DEBUG - 2016-03-01 14:39:38 --> No URI present. Default controller set.
INFO - 2016-03-01 14:39:38 --> Router Class Initialized
INFO - 2016-03-01 14:39:38 --> Output Class Initialized
INFO - 2016-03-01 14:39:38 --> Security Class Initialized
DEBUG - 2016-03-01 14:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:39:38 --> Input Class Initialized
INFO - 2016-03-01 14:39:38 --> Language Class Initialized
INFO - 2016-03-01 14:39:38 --> Loader Class Initialized
INFO - 2016-03-01 14:39:38 --> Helper loaded: url_helper
INFO - 2016-03-01 14:39:38 --> Helper loaded: file_helper
INFO - 2016-03-01 14:39:38 --> Helper loaded: date_helper
INFO - 2016-03-01 14:39:38 --> Helper loaded: form_helper
INFO - 2016-03-01 14:39:38 --> Database Driver Class Initialized
INFO - 2016-03-01 14:39:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:39:40 --> Controller Class Initialized
INFO - 2016-03-01 14:39:40 --> Model Class Initialized
INFO - 2016-03-01 14:39:40 --> Model Class Initialized
INFO - 2016-03-01 14:39:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:39:40 --> Pagination Class Initialized
INFO - 2016-03-01 14:39:40 --> Helper loaded: text_helper
INFO - 2016-03-01 14:39:40 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 17:39:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:39:40 --> Final output sent to browser
DEBUG - 2016-03-01 17:39:40 --> Total execution time: 1.5089
INFO - 2016-03-01 14:39:41 --> Config Class Initialized
INFO - 2016-03-01 14:39:41 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:39:41 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:39:41 --> Utf8 Class Initialized
INFO - 2016-03-01 14:39:41 --> URI Class Initialized
INFO - 2016-03-01 14:39:41 --> Router Class Initialized
INFO - 2016-03-01 14:39:41 --> Output Class Initialized
INFO - 2016-03-01 14:39:41 --> Security Class Initialized
DEBUG - 2016-03-01 14:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:39:41 --> Input Class Initialized
INFO - 2016-03-01 14:39:41 --> Language Class Initialized
INFO - 2016-03-01 14:39:41 --> Loader Class Initialized
INFO - 2016-03-01 14:39:41 --> Helper loaded: url_helper
INFO - 2016-03-01 14:39:41 --> Helper loaded: file_helper
INFO - 2016-03-01 14:39:41 --> Helper loaded: date_helper
INFO - 2016-03-01 14:39:41 --> Helper loaded: form_helper
INFO - 2016-03-01 14:39:41 --> Database Driver Class Initialized
INFO - 2016-03-01 14:39:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:39:42 --> Controller Class Initialized
INFO - 2016-03-01 14:39:42 --> Model Class Initialized
INFO - 2016-03-01 14:39:42 --> Model Class Initialized
INFO - 2016-03-01 14:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:39:42 --> Pagination Class Initialized
INFO - 2016-03-01 14:39:42 --> Helper loaded: text_helper
INFO - 2016-03-01 14:39:42 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:39:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:39:42 --> Final output sent to browser
DEBUG - 2016-03-01 17:39:42 --> Total execution time: 1.2119
INFO - 2016-03-01 14:39:44 --> Config Class Initialized
INFO - 2016-03-01 14:39:44 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:39:44 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:39:44 --> Utf8 Class Initialized
INFO - 2016-03-01 14:39:44 --> URI Class Initialized
INFO - 2016-03-01 14:39:44 --> Router Class Initialized
INFO - 2016-03-01 14:39:44 --> Output Class Initialized
INFO - 2016-03-01 14:39:44 --> Security Class Initialized
DEBUG - 2016-03-01 14:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:39:44 --> Input Class Initialized
INFO - 2016-03-01 14:39:44 --> Language Class Initialized
INFO - 2016-03-01 14:39:44 --> Loader Class Initialized
INFO - 2016-03-01 14:39:44 --> Helper loaded: url_helper
INFO - 2016-03-01 14:39:44 --> Helper loaded: file_helper
INFO - 2016-03-01 14:39:44 --> Helper loaded: date_helper
INFO - 2016-03-01 14:39:44 --> Helper loaded: form_helper
INFO - 2016-03-01 14:39:44 --> Database Driver Class Initialized
INFO - 2016-03-01 14:39:45 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:39:45 --> Controller Class Initialized
INFO - 2016-03-01 14:39:45 --> Model Class Initialized
INFO - 2016-03-01 14:39:45 --> Model Class Initialized
INFO - 2016-03-01 14:39:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:39:45 --> Pagination Class Initialized
INFO - 2016-03-01 14:39:45 --> Helper loaded: text_helper
INFO - 2016-03-01 14:39:45 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:39:45 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:39:46 --> Final output sent to browser
DEBUG - 2016-03-01 17:39:46 --> Total execution time: 1.2446
INFO - 2016-03-01 14:39:47 --> Config Class Initialized
INFO - 2016-03-01 14:39:47 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:39:47 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:39:47 --> Utf8 Class Initialized
INFO - 2016-03-01 14:39:47 --> URI Class Initialized
INFO - 2016-03-01 14:39:47 --> Router Class Initialized
INFO - 2016-03-01 14:39:47 --> Output Class Initialized
INFO - 2016-03-01 14:39:47 --> Security Class Initialized
DEBUG - 2016-03-01 14:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:39:47 --> Input Class Initialized
INFO - 2016-03-01 14:39:47 --> Language Class Initialized
INFO - 2016-03-01 14:39:47 --> Loader Class Initialized
INFO - 2016-03-01 14:39:47 --> Helper loaded: url_helper
INFO - 2016-03-01 14:39:47 --> Helper loaded: file_helper
INFO - 2016-03-01 14:39:48 --> Helper loaded: date_helper
INFO - 2016-03-01 14:39:48 --> Helper loaded: form_helper
INFO - 2016-03-01 14:39:48 --> Database Driver Class Initialized
INFO - 2016-03-01 14:39:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:39:49 --> Controller Class Initialized
INFO - 2016-03-01 14:39:49 --> Model Class Initialized
INFO - 2016-03-01 14:39:49 --> Model Class Initialized
INFO - 2016-03-01 14:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:39:49 --> Pagination Class Initialized
INFO - 2016-03-01 14:39:49 --> Helper loaded: text_helper
INFO - 2016-03-01 14:39:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:39:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:39:49 --> Final output sent to browser
DEBUG - 2016-03-01 17:39:49 --> Total execution time: 1.3978
INFO - 2016-03-01 14:39:50 --> Config Class Initialized
INFO - 2016-03-01 14:39:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 14:39:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 14:39:50 --> Utf8 Class Initialized
INFO - 2016-03-01 14:39:50 --> URI Class Initialized
INFO - 2016-03-01 14:39:50 --> Router Class Initialized
INFO - 2016-03-01 14:39:50 --> Output Class Initialized
INFO - 2016-03-01 14:39:50 --> Security Class Initialized
DEBUG - 2016-03-01 14:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 14:39:50 --> Input Class Initialized
INFO - 2016-03-01 14:39:50 --> Language Class Initialized
INFO - 2016-03-01 14:39:50 --> Loader Class Initialized
INFO - 2016-03-01 14:39:50 --> Helper loaded: url_helper
INFO - 2016-03-01 14:39:50 --> Helper loaded: file_helper
INFO - 2016-03-01 14:39:50 --> Helper loaded: date_helper
INFO - 2016-03-01 14:39:50 --> Helper loaded: form_helper
INFO - 2016-03-01 14:39:50 --> Database Driver Class Initialized
INFO - 2016-03-01 14:39:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 14:39:51 --> Controller Class Initialized
INFO - 2016-03-01 14:39:51 --> Model Class Initialized
INFO - 2016-03-01 14:39:51 --> Model Class Initialized
INFO - 2016-03-01 14:39:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 14:39:51 --> Pagination Class Initialized
INFO - 2016-03-01 14:39:51 --> Helper loaded: text_helper
INFO - 2016-03-01 14:39:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 17:39:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 17:39:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 17:39:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 17:39:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 17:39:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 17:39:51 --> Final output sent to browser
DEBUG - 2016-03-01 17:39:51 --> Total execution time: 1.2193
INFO - 2016-03-01 16:33:30 --> Config Class Initialized
INFO - 2016-03-01 16:33:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:33:31 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:33:31 --> Utf8 Class Initialized
INFO - 2016-03-01 16:33:31 --> URI Class Initialized
INFO - 2016-03-01 16:33:31 --> Router Class Initialized
INFO - 2016-03-01 16:33:31 --> Output Class Initialized
INFO - 2016-03-01 16:33:31 --> Security Class Initialized
DEBUG - 2016-03-01 16:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:33:31 --> Input Class Initialized
INFO - 2016-03-01 16:33:31 --> Language Class Initialized
INFO - 2016-03-01 16:33:31 --> Loader Class Initialized
INFO - 2016-03-01 16:33:32 --> Helper loaded: url_helper
INFO - 2016-03-01 16:33:32 --> Helper loaded: file_helper
INFO - 2016-03-01 16:33:32 --> Helper loaded: date_helper
INFO - 2016-03-01 16:33:32 --> Helper loaded: form_helper
INFO - 2016-03-01 16:33:32 --> Database Driver Class Initialized
INFO - 2016-03-01 16:33:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:33:34 --> Controller Class Initialized
INFO - 2016-03-01 16:33:34 --> Model Class Initialized
INFO - 2016-03-01 16:33:34 --> Model Class Initialized
INFO - 2016-03-01 16:33:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:33:34 --> Pagination Class Initialized
INFO - 2016-03-01 16:33:34 --> Helper loaded: text_helper
INFO - 2016-03-01 16:33:34 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:33:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:33:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:33:35 --> Final output sent to browser
DEBUG - 2016-03-01 19:33:35 --> Total execution time: 5.2808
INFO - 2016-03-01 16:33:40 --> Config Class Initialized
INFO - 2016-03-01 16:33:40 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:33:40 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:33:40 --> Utf8 Class Initialized
INFO - 2016-03-01 16:33:40 --> URI Class Initialized
DEBUG - 2016-03-01 16:33:40 --> No URI present. Default controller set.
INFO - 2016-03-01 16:33:40 --> Router Class Initialized
INFO - 2016-03-01 16:33:40 --> Output Class Initialized
INFO - 2016-03-01 16:33:41 --> Security Class Initialized
DEBUG - 2016-03-01 16:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:33:41 --> Input Class Initialized
INFO - 2016-03-01 16:33:41 --> Language Class Initialized
INFO - 2016-03-01 16:33:41 --> Loader Class Initialized
INFO - 2016-03-01 16:33:41 --> Helper loaded: url_helper
INFO - 2016-03-01 16:33:41 --> Helper loaded: file_helper
INFO - 2016-03-01 16:33:41 --> Helper loaded: date_helper
INFO - 2016-03-01 16:33:41 --> Helper loaded: form_helper
INFO - 2016-03-01 16:33:41 --> Database Driver Class Initialized
INFO - 2016-03-01 16:33:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:33:42 --> Controller Class Initialized
INFO - 2016-03-01 16:33:42 --> Model Class Initialized
INFO - 2016-03-01 16:33:42 --> Model Class Initialized
INFO - 2016-03-01 16:33:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:33:42 --> Pagination Class Initialized
INFO - 2016-03-01 16:33:42 --> Helper loaded: text_helper
INFO - 2016-03-01 16:33:42 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 19:33:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:33:42 --> Final output sent to browser
DEBUG - 2016-03-01 19:33:42 --> Total execution time: 1.2685
INFO - 2016-03-01 16:33:53 --> Config Class Initialized
INFO - 2016-03-01 16:33:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:33:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:33:53 --> Utf8 Class Initialized
INFO - 2016-03-01 16:33:53 --> URI Class Initialized
INFO - 2016-03-01 16:33:53 --> Router Class Initialized
INFO - 2016-03-01 16:33:53 --> Output Class Initialized
INFO - 2016-03-01 16:33:53 --> Security Class Initialized
DEBUG - 2016-03-01 16:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:33:53 --> Input Class Initialized
INFO - 2016-03-01 16:33:53 --> Language Class Initialized
INFO - 2016-03-01 16:33:53 --> Loader Class Initialized
INFO - 2016-03-01 16:33:53 --> Helper loaded: url_helper
INFO - 2016-03-01 16:33:53 --> Helper loaded: file_helper
INFO - 2016-03-01 16:33:53 --> Helper loaded: date_helper
INFO - 2016-03-01 16:33:53 --> Helper loaded: form_helper
INFO - 2016-03-01 16:33:53 --> Database Driver Class Initialized
INFO - 2016-03-01 16:33:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:33:54 --> Controller Class Initialized
INFO - 2016-03-01 16:33:54 --> Model Class Initialized
INFO - 2016-03-01 16:33:54 --> Model Class Initialized
INFO - 2016-03-01 16:33:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:33:54 --> Pagination Class Initialized
INFO - 2016-03-01 16:33:54 --> Helper loaded: text_helper
INFO - 2016-03-01 16:33:54 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:33:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:33:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:33:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:33:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:33:54 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:33:54 --> Final output sent to browser
DEBUG - 2016-03-01 19:33:54 --> Total execution time: 1.3809
INFO - 2016-03-01 16:34:01 --> Config Class Initialized
INFO - 2016-03-01 16:34:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:34:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:34:01 --> Utf8 Class Initialized
INFO - 2016-03-01 16:34:01 --> URI Class Initialized
DEBUG - 2016-03-01 16:34:01 --> No URI present. Default controller set.
INFO - 2016-03-01 16:34:01 --> Router Class Initialized
INFO - 2016-03-01 16:34:01 --> Output Class Initialized
INFO - 2016-03-01 16:34:01 --> Security Class Initialized
DEBUG - 2016-03-01 16:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:34:01 --> Input Class Initialized
INFO - 2016-03-01 16:34:01 --> Language Class Initialized
INFO - 2016-03-01 16:34:01 --> Loader Class Initialized
INFO - 2016-03-01 16:34:01 --> Helper loaded: url_helper
INFO - 2016-03-01 16:34:01 --> Helper loaded: file_helper
INFO - 2016-03-01 16:34:01 --> Helper loaded: date_helper
INFO - 2016-03-01 16:34:01 --> Helper loaded: form_helper
INFO - 2016-03-01 16:34:01 --> Database Driver Class Initialized
INFO - 2016-03-01 16:34:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:34:02 --> Controller Class Initialized
INFO - 2016-03-01 16:34:02 --> Model Class Initialized
INFO - 2016-03-01 16:34:02 --> Model Class Initialized
INFO - 2016-03-01 16:34:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:34:02 --> Pagination Class Initialized
INFO - 2016-03-01 16:34:02 --> Helper loaded: text_helper
INFO - 2016-03-01 16:34:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 19:34:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:34:02 --> Final output sent to browser
DEBUG - 2016-03-01 19:34:02 --> Total execution time: 1.1723
INFO - 2016-03-01 16:34:13 --> Config Class Initialized
INFO - 2016-03-01 16:34:13 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:34:13 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:34:13 --> Utf8 Class Initialized
INFO - 2016-03-01 16:34:13 --> URI Class Initialized
INFO - 2016-03-01 16:34:13 --> Router Class Initialized
INFO - 2016-03-01 16:34:13 --> Output Class Initialized
INFO - 2016-03-01 16:34:13 --> Security Class Initialized
DEBUG - 2016-03-01 16:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:34:13 --> Input Class Initialized
INFO - 2016-03-01 16:34:13 --> Language Class Initialized
INFO - 2016-03-01 16:34:13 --> Loader Class Initialized
INFO - 2016-03-01 16:34:13 --> Helper loaded: url_helper
INFO - 2016-03-01 16:34:13 --> Helper loaded: file_helper
INFO - 2016-03-01 16:34:13 --> Helper loaded: date_helper
INFO - 2016-03-01 16:34:13 --> Helper loaded: form_helper
INFO - 2016-03-01 16:34:13 --> Database Driver Class Initialized
INFO - 2016-03-01 16:34:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:34:14 --> Controller Class Initialized
INFO - 2016-03-01 16:34:14 --> Model Class Initialized
INFO - 2016-03-01 16:34:14 --> Model Class Initialized
INFO - 2016-03-01 16:34:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:34:14 --> Pagination Class Initialized
INFO - 2016-03-01 16:34:14 --> Helper loaded: text_helper
INFO - 2016-03-01 16:34:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 19:34:14 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:34:14 --> Final output sent to browser
DEBUG - 2016-03-01 19:34:14 --> Total execution time: 1.1766
INFO - 2016-03-01 16:34:17 --> Config Class Initialized
INFO - 2016-03-01 16:34:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:34:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:34:17 --> Utf8 Class Initialized
INFO - 2016-03-01 16:34:17 --> URI Class Initialized
INFO - 2016-03-01 16:34:17 --> Router Class Initialized
INFO - 2016-03-01 16:34:17 --> Output Class Initialized
INFO - 2016-03-01 16:34:17 --> Security Class Initialized
DEBUG - 2016-03-01 16:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:34:17 --> Input Class Initialized
INFO - 2016-03-01 16:34:17 --> Language Class Initialized
INFO - 2016-03-01 16:34:17 --> Loader Class Initialized
INFO - 2016-03-01 16:34:17 --> Helper loaded: url_helper
INFO - 2016-03-01 16:34:17 --> Helper loaded: file_helper
INFO - 2016-03-01 16:34:17 --> Helper loaded: date_helper
INFO - 2016-03-01 16:34:17 --> Helper loaded: form_helper
INFO - 2016-03-01 16:34:17 --> Database Driver Class Initialized
INFO - 2016-03-01 16:34:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:34:18 --> Controller Class Initialized
INFO - 2016-03-01 16:34:18 --> Model Class Initialized
INFO - 2016-03-01 16:34:18 --> Model Class Initialized
INFO - 2016-03-01 16:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:34:18 --> Pagination Class Initialized
INFO - 2016-03-01 16:34:18 --> Helper loaded: text_helper
INFO - 2016-03-01 16:34:18 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:34:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:34:18 --> Final output sent to browser
DEBUG - 2016-03-01 19:34:18 --> Total execution time: 1.1868
INFO - 2016-03-01 16:34:26 --> Config Class Initialized
INFO - 2016-03-01 16:34:26 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:34:26 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:34:26 --> Utf8 Class Initialized
INFO - 2016-03-01 16:34:26 --> URI Class Initialized
INFO - 2016-03-01 16:34:26 --> Router Class Initialized
INFO - 2016-03-01 16:34:27 --> Output Class Initialized
INFO - 2016-03-01 16:34:27 --> Security Class Initialized
DEBUG - 2016-03-01 16:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:34:27 --> Input Class Initialized
INFO - 2016-03-01 16:34:27 --> Language Class Initialized
INFO - 2016-03-01 16:34:27 --> Loader Class Initialized
INFO - 2016-03-01 16:34:27 --> Helper loaded: url_helper
INFO - 2016-03-01 16:34:27 --> Helper loaded: file_helper
INFO - 2016-03-01 16:34:27 --> Helper loaded: date_helper
INFO - 2016-03-01 16:34:27 --> Helper loaded: form_helper
INFO - 2016-03-01 16:34:27 --> Database Driver Class Initialized
INFO - 2016-03-01 16:34:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:34:28 --> Controller Class Initialized
INFO - 2016-03-01 16:34:28 --> Model Class Initialized
INFO - 2016-03-01 16:34:28 --> Model Class Initialized
INFO - 2016-03-01 16:34:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:34:28 --> Pagination Class Initialized
INFO - 2016-03-01 16:34:28 --> Helper loaded: text_helper
INFO - 2016-03-01 16:34:28 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 19:34:28 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:34:28 --> Final output sent to browser
DEBUG - 2016-03-01 19:34:28 --> Total execution time: 1.1427
INFO - 2016-03-01 16:34:30 --> Config Class Initialized
INFO - 2016-03-01 16:34:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:34:30 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:34:30 --> Utf8 Class Initialized
INFO - 2016-03-01 16:34:30 --> URI Class Initialized
INFO - 2016-03-01 16:34:30 --> Router Class Initialized
INFO - 2016-03-01 16:34:30 --> Output Class Initialized
INFO - 2016-03-01 16:34:30 --> Security Class Initialized
DEBUG - 2016-03-01 16:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:34:30 --> Input Class Initialized
INFO - 2016-03-01 16:34:30 --> Language Class Initialized
INFO - 2016-03-01 16:34:30 --> Loader Class Initialized
INFO - 2016-03-01 16:34:30 --> Helper loaded: url_helper
INFO - 2016-03-01 16:34:30 --> Helper loaded: file_helper
INFO - 2016-03-01 16:34:30 --> Helper loaded: date_helper
INFO - 2016-03-01 16:34:30 --> Helper loaded: form_helper
INFO - 2016-03-01 16:34:30 --> Database Driver Class Initialized
INFO - 2016-03-01 16:34:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:34:31 --> Controller Class Initialized
INFO - 2016-03-01 16:34:31 --> Model Class Initialized
INFO - 2016-03-01 16:34:31 --> Model Class Initialized
INFO - 2016-03-01 16:34:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:34:31 --> Pagination Class Initialized
INFO - 2016-03-01 16:34:31 --> Helper loaded: text_helper
INFO - 2016-03-01 16:34:31 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:34:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:34:31 --> Final output sent to browser
DEBUG - 2016-03-01 19:34:31 --> Total execution time: 1.2381
INFO - 2016-03-01 16:34:38 --> Config Class Initialized
INFO - 2016-03-01 16:34:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:34:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:34:38 --> Utf8 Class Initialized
INFO - 2016-03-01 16:34:38 --> URI Class Initialized
INFO - 2016-03-01 16:34:38 --> Router Class Initialized
INFO - 2016-03-01 16:34:38 --> Output Class Initialized
INFO - 2016-03-01 16:34:38 --> Security Class Initialized
DEBUG - 2016-03-01 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:34:38 --> Input Class Initialized
INFO - 2016-03-01 16:34:38 --> Language Class Initialized
INFO - 2016-03-01 16:34:38 --> Loader Class Initialized
INFO - 2016-03-01 16:34:38 --> Helper loaded: url_helper
INFO - 2016-03-01 16:34:38 --> Helper loaded: file_helper
INFO - 2016-03-01 16:34:38 --> Helper loaded: date_helper
INFO - 2016-03-01 16:34:38 --> Helper loaded: form_helper
INFO - 2016-03-01 16:34:38 --> Database Driver Class Initialized
INFO - 2016-03-01 16:34:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:34:39 --> Controller Class Initialized
INFO - 2016-03-01 16:34:39 --> Model Class Initialized
INFO - 2016-03-01 16:34:39 --> Model Class Initialized
INFO - 2016-03-01 16:34:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:34:39 --> Pagination Class Initialized
INFO - 2016-03-01 16:34:39 --> Helper loaded: text_helper
INFO - 2016-03-01 16:34:39 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:34:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:34:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:34:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 19:34:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:34:39 --> Final output sent to browser
DEBUG - 2016-03-01 19:34:39 --> Total execution time: 1.1214
INFO - 2016-03-01 16:34:41 --> Config Class Initialized
INFO - 2016-03-01 16:34:41 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:34:41 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:34:41 --> Utf8 Class Initialized
INFO - 2016-03-01 16:34:41 --> URI Class Initialized
INFO - 2016-03-01 16:34:41 --> Router Class Initialized
INFO - 2016-03-01 16:34:41 --> Output Class Initialized
INFO - 2016-03-01 16:34:41 --> Security Class Initialized
DEBUG - 2016-03-01 16:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:34:41 --> Input Class Initialized
INFO - 2016-03-01 16:34:41 --> Language Class Initialized
INFO - 2016-03-01 16:34:41 --> Loader Class Initialized
INFO - 2016-03-01 16:34:41 --> Helper loaded: url_helper
INFO - 2016-03-01 16:34:41 --> Helper loaded: file_helper
INFO - 2016-03-01 16:34:41 --> Helper loaded: date_helper
INFO - 2016-03-01 16:34:41 --> Helper loaded: form_helper
INFO - 2016-03-01 16:34:41 --> Database Driver Class Initialized
INFO - 2016-03-01 16:34:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:34:42 --> Controller Class Initialized
INFO - 2016-03-01 16:34:42 --> Model Class Initialized
INFO - 2016-03-01 16:34:42 --> Model Class Initialized
INFO - 2016-03-01 16:34:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:34:42 --> Pagination Class Initialized
INFO - 2016-03-01 16:34:42 --> Helper loaded: text_helper
INFO - 2016-03-01 16:34:42 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:34:42 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:34:42 --> Final output sent to browser
DEBUG - 2016-03-01 19:34:42 --> Total execution time: 1.1715
INFO - 2016-03-01 16:36:03 --> Config Class Initialized
INFO - 2016-03-01 16:36:03 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:36:03 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:36:03 --> Utf8 Class Initialized
INFO - 2016-03-01 16:36:03 --> URI Class Initialized
INFO - 2016-03-01 16:36:03 --> Router Class Initialized
INFO - 2016-03-01 16:36:03 --> Output Class Initialized
INFO - 2016-03-01 16:36:03 --> Security Class Initialized
DEBUG - 2016-03-01 16:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:36:03 --> Input Class Initialized
INFO - 2016-03-01 16:36:03 --> Language Class Initialized
INFO - 2016-03-01 16:36:03 --> Loader Class Initialized
INFO - 2016-03-01 16:36:03 --> Helper loaded: url_helper
INFO - 2016-03-01 16:36:03 --> Helper loaded: file_helper
INFO - 2016-03-01 16:36:03 --> Helper loaded: date_helper
INFO - 2016-03-01 16:36:03 --> Helper loaded: form_helper
INFO - 2016-03-01 16:36:03 --> Database Driver Class Initialized
INFO - 2016-03-01 16:36:04 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:36:04 --> Controller Class Initialized
INFO - 2016-03-01 16:36:04 --> Model Class Initialized
INFO - 2016-03-01 16:36:04 --> Model Class Initialized
INFO - 2016-03-01 16:36:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:36:04 --> Pagination Class Initialized
INFO - 2016-03-01 16:36:04 --> Helper loaded: text_helper
INFO - 2016-03-01 16:36:04 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 19:36:04 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 19:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:36:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:36:04 --> Final output sent to browser
DEBUG - 2016-03-01 19:36:04 --> Total execution time: 1.2286
INFO - 2016-03-01 16:36:11 --> Config Class Initialized
INFO - 2016-03-01 16:36:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:36:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:36:11 --> Utf8 Class Initialized
INFO - 2016-03-01 16:36:11 --> URI Class Initialized
INFO - 2016-03-01 16:36:11 --> Router Class Initialized
INFO - 2016-03-01 16:36:11 --> Output Class Initialized
INFO - 2016-03-01 16:36:11 --> Security Class Initialized
DEBUG - 2016-03-01 16:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:36:11 --> Input Class Initialized
INFO - 2016-03-01 16:36:11 --> Language Class Initialized
INFO - 2016-03-01 16:36:11 --> Loader Class Initialized
INFO - 2016-03-01 16:36:11 --> Helper loaded: url_helper
INFO - 2016-03-01 16:36:11 --> Helper loaded: file_helper
INFO - 2016-03-01 16:36:11 --> Helper loaded: date_helper
INFO - 2016-03-01 16:36:11 --> Helper loaded: form_helper
INFO - 2016-03-01 16:36:11 --> Database Driver Class Initialized
INFO - 2016-03-01 16:36:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:36:12 --> Controller Class Initialized
INFO - 2016-03-01 16:36:12 --> Model Class Initialized
INFO - 2016-03-01 16:36:12 --> Model Class Initialized
INFO - 2016-03-01 16:36:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:36:12 --> Pagination Class Initialized
INFO - 2016-03-01 16:36:12 --> Helper loaded: text_helper
INFO - 2016-03-01 16:36:12 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:36:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:36:12 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 19:36:13 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 19:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:36:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:36:13 --> Final output sent to browser
DEBUG - 2016-03-01 19:36:13 --> Total execution time: 1.1746
INFO - 2016-03-01 16:36:26 --> Config Class Initialized
INFO - 2016-03-01 16:36:26 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:36:26 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:36:26 --> Utf8 Class Initialized
INFO - 2016-03-01 16:36:26 --> URI Class Initialized
INFO - 2016-03-01 16:36:26 --> Router Class Initialized
INFO - 2016-03-01 16:36:26 --> Output Class Initialized
INFO - 2016-03-01 16:36:26 --> Security Class Initialized
DEBUG - 2016-03-01 16:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:36:26 --> Input Class Initialized
INFO - 2016-03-01 16:36:26 --> Language Class Initialized
INFO - 2016-03-01 16:36:26 --> Loader Class Initialized
INFO - 2016-03-01 16:36:26 --> Helper loaded: url_helper
INFO - 2016-03-01 16:36:26 --> Helper loaded: file_helper
INFO - 2016-03-01 16:36:26 --> Helper loaded: date_helper
INFO - 2016-03-01 16:36:26 --> Helper loaded: form_helper
INFO - 2016-03-01 16:36:26 --> Database Driver Class Initialized
INFO - 2016-03-01 16:36:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:36:27 --> Controller Class Initialized
INFO - 2016-03-01 16:36:27 --> Model Class Initialized
INFO - 2016-03-01 16:36:27 --> Model Class Initialized
INFO - 2016-03-01 16:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:36:27 --> Pagination Class Initialized
INFO - 2016-03-01 16:36:27 --> Helper loaded: text_helper
INFO - 2016-03-01 16:36:27 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:36:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:36:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 19:36:27 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 19:36:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:36:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:36:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:36:27 --> Final output sent to browser
DEBUG - 2016-03-01 19:36:27 --> Total execution time: 1.2329
INFO - 2016-03-01 16:36:38 --> Config Class Initialized
INFO - 2016-03-01 16:36:38 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:36:38 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:36:38 --> Utf8 Class Initialized
INFO - 2016-03-01 16:36:38 --> URI Class Initialized
INFO - 2016-03-01 16:36:38 --> Router Class Initialized
INFO - 2016-03-01 16:36:38 --> Output Class Initialized
INFO - 2016-03-01 16:36:38 --> Security Class Initialized
DEBUG - 2016-03-01 16:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:36:38 --> Input Class Initialized
INFO - 2016-03-01 16:36:38 --> Language Class Initialized
INFO - 2016-03-01 16:36:38 --> Loader Class Initialized
INFO - 2016-03-01 16:36:38 --> Helper loaded: url_helper
INFO - 2016-03-01 16:36:38 --> Helper loaded: file_helper
INFO - 2016-03-01 16:36:38 --> Helper loaded: date_helper
INFO - 2016-03-01 16:36:38 --> Helper loaded: form_helper
INFO - 2016-03-01 16:36:38 --> Database Driver Class Initialized
INFO - 2016-03-01 16:36:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:36:39 --> Controller Class Initialized
INFO - 2016-03-01 16:36:39 --> Model Class Initialized
INFO - 2016-03-01 16:36:39 --> Model Class Initialized
INFO - 2016-03-01 16:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:36:39 --> Pagination Class Initialized
INFO - 2016-03-01 16:36:39 --> Helper loaded: text_helper
INFO - 2016-03-01 16:36:39 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 19:36:39 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 19:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:36:39 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:36:39 --> Final output sent to browser
DEBUG - 2016-03-01 19:36:39 --> Total execution time: 1.1674
INFO - 2016-03-01 16:38:05 --> Config Class Initialized
INFO - 2016-03-01 16:38:05 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:38:05 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:38:05 --> Utf8 Class Initialized
INFO - 2016-03-01 16:38:05 --> URI Class Initialized
INFO - 2016-03-01 16:38:05 --> Router Class Initialized
INFO - 2016-03-01 16:38:05 --> Output Class Initialized
INFO - 2016-03-01 16:38:05 --> Security Class Initialized
DEBUG - 2016-03-01 16:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:38:05 --> Input Class Initialized
INFO - 2016-03-01 16:38:05 --> Language Class Initialized
INFO - 2016-03-01 16:38:05 --> Loader Class Initialized
INFO - 2016-03-01 16:38:05 --> Helper loaded: url_helper
INFO - 2016-03-01 16:38:05 --> Helper loaded: file_helper
INFO - 2016-03-01 16:38:05 --> Helper loaded: date_helper
INFO - 2016-03-01 16:38:05 --> Helper loaded: form_helper
INFO - 2016-03-01 16:38:05 --> Database Driver Class Initialized
INFO - 2016-03-01 16:38:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:38:06 --> Controller Class Initialized
INFO - 2016-03-01 16:38:06 --> Model Class Initialized
INFO - 2016-03-01 16:38:06 --> Model Class Initialized
INFO - 2016-03-01 16:38:06 --> Form Validation Class Initialized
INFO - 2016-03-01 16:38:06 --> Helper loaded: text_helper
INFO - 2016-03-01 16:38:07 --> Final output sent to browser
DEBUG - 2016-03-01 16:38:07 --> Total execution time: 1.2059
INFO - 2016-03-01 16:38:19 --> Config Class Initialized
INFO - 2016-03-01 16:38:19 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:38:19 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:38:19 --> Utf8 Class Initialized
INFO - 2016-03-01 16:38:19 --> URI Class Initialized
INFO - 2016-03-01 16:38:19 --> Router Class Initialized
INFO - 2016-03-01 16:38:19 --> Output Class Initialized
INFO - 2016-03-01 16:38:19 --> Security Class Initialized
DEBUG - 2016-03-01 16:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:38:19 --> Input Class Initialized
INFO - 2016-03-01 16:38:19 --> Language Class Initialized
INFO - 2016-03-01 16:38:19 --> Loader Class Initialized
INFO - 2016-03-01 16:38:19 --> Helper loaded: url_helper
INFO - 2016-03-01 16:38:19 --> Helper loaded: file_helper
INFO - 2016-03-01 16:38:19 --> Helper loaded: date_helper
INFO - 2016-03-01 16:38:19 --> Helper loaded: form_helper
INFO - 2016-03-01 16:38:19 --> Database Driver Class Initialized
INFO - 2016-03-01 16:38:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:38:20 --> Controller Class Initialized
INFO - 2016-03-01 16:38:20 --> Model Class Initialized
INFO - 2016-03-01 16:38:20 --> Model Class Initialized
INFO - 2016-03-01 16:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:38:20 --> Pagination Class Initialized
INFO - 2016-03-01 16:38:20 --> Helper loaded: text_helper
INFO - 2016-03-01 16:38:20 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 3
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 5
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 6
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 7
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 12
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 17
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 21
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 47
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 49
ERROR - 2016-03-01 19:38:20 --> Severity: Notice --> Trying to get property of non-object C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php 108
INFO - 2016-03-01 19:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:38:20 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:38:20 --> Final output sent to browser
DEBUG - 2016-03-01 19:38:20 --> Total execution time: 1.2435
INFO - 2016-03-01 16:39:10 --> Config Class Initialized
INFO - 2016-03-01 16:39:10 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:39:10 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:39:10 --> Utf8 Class Initialized
INFO - 2016-03-01 16:39:10 --> URI Class Initialized
DEBUG - 2016-03-01 16:39:10 --> No URI present. Default controller set.
INFO - 2016-03-01 16:39:10 --> Router Class Initialized
INFO - 2016-03-01 16:39:10 --> Output Class Initialized
INFO - 2016-03-01 16:39:10 --> Security Class Initialized
DEBUG - 2016-03-01 16:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:39:10 --> Input Class Initialized
INFO - 2016-03-01 16:39:10 --> Language Class Initialized
INFO - 2016-03-01 16:39:10 --> Loader Class Initialized
INFO - 2016-03-01 16:39:10 --> Helper loaded: url_helper
INFO - 2016-03-01 16:39:10 --> Helper loaded: file_helper
INFO - 2016-03-01 16:39:10 --> Helper loaded: date_helper
INFO - 2016-03-01 16:39:10 --> Helper loaded: form_helper
INFO - 2016-03-01 16:39:10 --> Database Driver Class Initialized
INFO - 2016-03-01 16:39:11 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:39:11 --> Controller Class Initialized
INFO - 2016-03-01 16:39:11 --> Model Class Initialized
INFO - 2016-03-01 16:39:11 --> Model Class Initialized
INFO - 2016-03-01 16:39:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:39:11 --> Pagination Class Initialized
INFO - 2016-03-01 16:39:11 --> Helper loaded: text_helper
INFO - 2016-03-01 16:39:11 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 19:39:11 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:39:11 --> Final output sent to browser
DEBUG - 2016-03-01 19:39:11 --> Total execution time: 1.1454
INFO - 2016-03-01 16:39:27 --> Config Class Initialized
INFO - 2016-03-01 16:39:27 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:39:27 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:39:27 --> Utf8 Class Initialized
INFO - 2016-03-01 16:39:27 --> URI Class Initialized
INFO - 2016-03-01 16:39:27 --> Router Class Initialized
INFO - 2016-03-01 16:39:27 --> Output Class Initialized
INFO - 2016-03-01 16:39:27 --> Security Class Initialized
DEBUG - 2016-03-01 16:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:39:27 --> Input Class Initialized
INFO - 2016-03-01 16:39:27 --> Language Class Initialized
INFO - 2016-03-01 16:39:27 --> Loader Class Initialized
INFO - 2016-03-01 16:39:27 --> Helper loaded: url_helper
INFO - 2016-03-01 16:39:27 --> Helper loaded: file_helper
INFO - 2016-03-01 16:39:27 --> Helper loaded: date_helper
INFO - 2016-03-01 16:39:27 --> Helper loaded: form_helper
INFO - 2016-03-01 16:39:27 --> Database Driver Class Initialized
INFO - 2016-03-01 16:39:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:39:28 --> Controller Class Initialized
INFO - 2016-03-01 16:39:28 --> Model Class Initialized
INFO - 2016-03-01 16:39:28 --> Model Class Initialized
INFO - 2016-03-01 16:39:28 --> Form Validation Class Initialized
INFO - 2016-03-01 16:39:28 --> Helper loaded: text_helper
INFO - 2016-03-01 16:39:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 16:39:28 --> Final output sent to browser
DEBUG - 2016-03-01 16:39:28 --> Total execution time: 1.3521
INFO - 2016-03-01 16:39:37 --> Config Class Initialized
INFO - 2016-03-01 16:39:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:39:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:39:37 --> Utf8 Class Initialized
INFO - 2016-03-01 16:39:37 --> URI Class Initialized
DEBUG - 2016-03-01 16:39:37 --> No URI present. Default controller set.
INFO - 2016-03-01 16:39:37 --> Router Class Initialized
INFO - 2016-03-01 16:39:37 --> Output Class Initialized
INFO - 2016-03-01 16:39:37 --> Security Class Initialized
DEBUG - 2016-03-01 16:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:39:37 --> Input Class Initialized
INFO - 2016-03-01 16:39:37 --> Language Class Initialized
INFO - 2016-03-01 16:39:37 --> Loader Class Initialized
INFO - 2016-03-01 16:39:37 --> Helper loaded: url_helper
INFO - 2016-03-01 16:39:37 --> Helper loaded: file_helper
INFO - 2016-03-01 16:39:37 --> Helper loaded: date_helper
INFO - 2016-03-01 16:39:37 --> Helper loaded: form_helper
INFO - 2016-03-01 16:39:37 --> Database Driver Class Initialized
INFO - 2016-03-01 16:39:38 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:39:38 --> Controller Class Initialized
INFO - 2016-03-01 16:39:38 --> Model Class Initialized
INFO - 2016-03-01 16:39:38 --> Model Class Initialized
INFO - 2016-03-01 16:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:39:38 --> Pagination Class Initialized
INFO - 2016-03-01 16:39:38 --> Helper loaded: text_helper
INFO - 2016-03-01 16:39:38 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 19:39:38 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:39:38 --> Final output sent to browser
DEBUG - 2016-03-01 19:39:38 --> Total execution time: 1.1661
INFO - 2016-03-01 16:39:51 --> Config Class Initialized
INFO - 2016-03-01 16:39:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:39:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:39:51 --> Utf8 Class Initialized
INFO - 2016-03-01 16:39:51 --> URI Class Initialized
INFO - 2016-03-01 16:39:51 --> Router Class Initialized
INFO - 2016-03-01 16:39:51 --> Output Class Initialized
INFO - 2016-03-01 16:39:51 --> Security Class Initialized
DEBUG - 2016-03-01 16:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:39:51 --> Input Class Initialized
INFO - 2016-03-01 16:39:51 --> Language Class Initialized
INFO - 2016-03-01 16:39:51 --> Loader Class Initialized
INFO - 2016-03-01 16:39:51 --> Helper loaded: url_helper
INFO - 2016-03-01 16:39:51 --> Helper loaded: file_helper
INFO - 2016-03-01 16:39:51 --> Helper loaded: date_helper
INFO - 2016-03-01 16:39:51 --> Helper loaded: form_helper
INFO - 2016-03-01 16:39:51 --> Database Driver Class Initialized
INFO - 2016-03-01 16:39:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:39:52 --> Controller Class Initialized
INFO - 2016-03-01 16:39:52 --> Model Class Initialized
INFO - 2016-03-01 16:39:52 --> Model Class Initialized
INFO - 2016-03-01 16:39:52 --> Form Validation Class Initialized
INFO - 2016-03-01 16:39:52 --> Helper loaded: text_helper
INFO - 2016-03-01 16:39:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-03-01 16:39:52 --> Final output sent to browser
DEBUG - 2016-03-01 16:39:52 --> Total execution time: 1.1231
INFO - 2016-03-01 16:40:00 --> Config Class Initialized
INFO - 2016-03-01 16:40:00 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:40:00 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:40:00 --> Utf8 Class Initialized
INFO - 2016-03-01 16:40:00 --> URI Class Initialized
INFO - 2016-03-01 16:40:00 --> Router Class Initialized
INFO - 2016-03-01 16:40:00 --> Output Class Initialized
INFO - 2016-03-01 16:40:00 --> Security Class Initialized
DEBUG - 2016-03-01 16:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:40:00 --> Input Class Initialized
INFO - 2016-03-01 16:40:00 --> Language Class Initialized
INFO - 2016-03-01 16:40:00 --> Loader Class Initialized
INFO - 2016-03-01 16:40:00 --> Helper loaded: url_helper
INFO - 2016-03-01 16:40:00 --> Helper loaded: file_helper
INFO - 2016-03-01 16:40:00 --> Helper loaded: date_helper
INFO - 2016-03-01 16:40:00 --> Helper loaded: form_helper
INFO - 2016-03-01 16:40:00 --> Database Driver Class Initialized
INFO - 2016-03-01 16:40:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:40:01 --> Controller Class Initialized
INFO - 2016-03-01 16:40:01 --> Model Class Initialized
INFO - 2016-03-01 16:40:01 --> Model Class Initialized
INFO - 2016-03-01 16:40:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:40:01 --> Pagination Class Initialized
INFO - 2016-03-01 16:40:01 --> Helper loaded: text_helper
INFO - 2016-03-01 16:40:01 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:40:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:40:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:40:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 19:40:01 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:40:01 --> Final output sent to browser
DEBUG - 2016-03-01 19:40:01 --> Total execution time: 1.1383
INFO - 2016-03-01 16:40:06 --> Config Class Initialized
INFO - 2016-03-01 16:40:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:40:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:40:06 --> Utf8 Class Initialized
INFO - 2016-03-01 16:40:06 --> URI Class Initialized
INFO - 2016-03-01 16:40:06 --> Router Class Initialized
INFO - 2016-03-01 16:40:06 --> Output Class Initialized
INFO - 2016-03-01 16:40:06 --> Security Class Initialized
DEBUG - 2016-03-01 16:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:40:06 --> Input Class Initialized
INFO - 2016-03-01 16:40:06 --> Language Class Initialized
INFO - 2016-03-01 16:40:06 --> Loader Class Initialized
INFO - 2016-03-01 16:40:06 --> Helper loaded: url_helper
INFO - 2016-03-01 16:40:06 --> Helper loaded: file_helper
INFO - 2016-03-01 16:40:06 --> Helper loaded: date_helper
INFO - 2016-03-01 16:40:06 --> Helper loaded: form_helper
INFO - 2016-03-01 16:40:06 --> Database Driver Class Initialized
INFO - 2016-03-01 16:40:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:40:07 --> Controller Class Initialized
INFO - 2016-03-01 16:40:07 --> Model Class Initialized
INFO - 2016-03-01 16:40:07 --> Model Class Initialized
INFO - 2016-03-01 16:40:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:40:07 --> Pagination Class Initialized
INFO - 2016-03-01 16:40:07 --> Helper loaded: text_helper
INFO - 2016-03-01 16:40:07 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:40:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:40:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:40:07 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:40:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:40:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:40:08 --> Final output sent to browser
DEBUG - 2016-03-01 19:40:08 --> Total execution time: 1.2522
INFO - 2016-03-01 16:40:59 --> Config Class Initialized
INFO - 2016-03-01 16:40:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:40:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:40:59 --> Utf8 Class Initialized
INFO - 2016-03-01 16:40:59 --> URI Class Initialized
INFO - 2016-03-01 16:40:59 --> Router Class Initialized
INFO - 2016-03-01 16:40:59 --> Output Class Initialized
INFO - 2016-03-01 16:40:59 --> Security Class Initialized
DEBUG - 2016-03-01 16:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:40:59 --> Input Class Initialized
INFO - 2016-03-01 16:40:59 --> Language Class Initialized
INFO - 2016-03-01 16:40:59 --> Loader Class Initialized
INFO - 2016-03-01 16:40:59 --> Helper loaded: url_helper
INFO - 2016-03-01 16:40:59 --> Helper loaded: file_helper
INFO - 2016-03-01 16:40:59 --> Helper loaded: date_helper
INFO - 2016-03-01 16:40:59 --> Helper loaded: form_helper
INFO - 2016-03-01 16:40:59 --> Database Driver Class Initialized
INFO - 2016-03-01 16:41:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:41:00 --> Controller Class Initialized
INFO - 2016-03-01 16:41:00 --> Model Class Initialized
INFO - 2016-03-01 16:41:00 --> Model Class Initialized
INFO - 2016-03-01 16:41:00 --> Form Validation Class Initialized
INFO - 2016-03-01 16:41:00 --> Helper loaded: text_helper
INFO - 2016-03-01 16:41:01 --> Final output sent to browser
DEBUG - 2016-03-01 16:41:01 --> Total execution time: 1.4017
INFO - 2016-03-01 16:41:01 --> Config Class Initialized
INFO - 2016-03-01 16:41:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:41:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:41:01 --> Utf8 Class Initialized
INFO - 2016-03-01 16:41:01 --> URI Class Initialized
INFO - 2016-03-01 16:41:01 --> Router Class Initialized
INFO - 2016-03-01 16:41:01 --> Output Class Initialized
INFO - 2016-03-01 16:41:01 --> Security Class Initialized
DEBUG - 2016-03-01 16:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:41:01 --> Input Class Initialized
INFO - 2016-03-01 16:41:01 --> Language Class Initialized
INFO - 2016-03-01 16:41:01 --> Loader Class Initialized
INFO - 2016-03-01 16:41:01 --> Helper loaded: url_helper
INFO - 2016-03-01 16:41:01 --> Helper loaded: file_helper
INFO - 2016-03-01 16:41:01 --> Helper loaded: date_helper
INFO - 2016-03-01 16:41:01 --> Helper loaded: form_helper
INFO - 2016-03-01 16:41:01 --> Database Driver Class Initialized
INFO - 2016-03-01 16:41:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:41:02 --> Controller Class Initialized
INFO - 2016-03-01 16:41:02 --> Model Class Initialized
INFO - 2016-03-01 16:41:02 --> Model Class Initialized
INFO - 2016-03-01 16:41:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:41:02 --> Pagination Class Initialized
INFO - 2016-03-01 16:41:02 --> Helper loaded: text_helper
INFO - 2016-03-01 16:41:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:41:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:41:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:41:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:41:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:41:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:41:02 --> Final output sent to browser
DEBUG - 2016-03-01 19:41:02 --> Total execution time: 1.1709
INFO - 2016-03-01 16:41:25 --> Config Class Initialized
INFO - 2016-03-01 16:41:25 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:41:25 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:41:25 --> Utf8 Class Initialized
INFO - 2016-03-01 16:41:25 --> URI Class Initialized
DEBUG - 2016-03-01 16:41:25 --> No URI present. Default controller set.
INFO - 2016-03-01 16:41:25 --> Router Class Initialized
INFO - 2016-03-01 16:41:25 --> Output Class Initialized
INFO - 2016-03-01 16:41:25 --> Security Class Initialized
DEBUG - 2016-03-01 16:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:41:25 --> Input Class Initialized
INFO - 2016-03-01 16:41:25 --> Language Class Initialized
INFO - 2016-03-01 16:41:25 --> Loader Class Initialized
INFO - 2016-03-01 16:41:25 --> Helper loaded: url_helper
INFO - 2016-03-01 16:41:25 --> Helper loaded: file_helper
INFO - 2016-03-01 16:41:25 --> Helper loaded: date_helper
INFO - 2016-03-01 16:41:25 --> Helper loaded: form_helper
INFO - 2016-03-01 16:41:25 --> Database Driver Class Initialized
INFO - 2016-03-01 16:41:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:41:26 --> Controller Class Initialized
INFO - 2016-03-01 16:41:26 --> Model Class Initialized
INFO - 2016-03-01 16:41:26 --> Model Class Initialized
INFO - 2016-03-01 16:41:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:41:26 --> Pagination Class Initialized
INFO - 2016-03-01 16:41:26 --> Helper loaded: text_helper
INFO - 2016-03-01 16:41:26 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 19:41:26 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:41:26 --> Final output sent to browser
DEBUG - 2016-03-01 19:41:26 --> Total execution time: 1.1665
INFO - 2016-03-01 16:41:48 --> Config Class Initialized
INFO - 2016-03-01 16:41:48 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:41:48 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:41:48 --> Utf8 Class Initialized
INFO - 2016-03-01 16:41:48 --> URI Class Initialized
INFO - 2016-03-01 16:41:48 --> Router Class Initialized
INFO - 2016-03-01 16:41:48 --> Output Class Initialized
INFO - 2016-03-01 16:41:48 --> Security Class Initialized
DEBUG - 2016-03-01 16:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:41:48 --> Input Class Initialized
INFO - 2016-03-01 16:41:48 --> Language Class Initialized
INFO - 2016-03-01 16:41:48 --> Loader Class Initialized
INFO - 2016-03-01 16:41:48 --> Helper loaded: url_helper
INFO - 2016-03-01 16:41:48 --> Helper loaded: file_helper
INFO - 2016-03-01 16:41:48 --> Helper loaded: date_helper
INFO - 2016-03-01 16:41:48 --> Helper loaded: form_helper
INFO - 2016-03-01 16:41:48 --> Database Driver Class Initialized
INFO - 2016-03-01 16:41:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:41:49 --> Controller Class Initialized
INFO - 2016-03-01 16:41:49 --> Model Class Initialized
INFO - 2016-03-01 16:41:49 --> Model Class Initialized
INFO - 2016-03-01 16:41:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:41:49 --> Pagination Class Initialized
INFO - 2016-03-01 16:41:49 --> Helper loaded: text_helper
INFO - 2016-03-01 16:41:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:41:49 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:41:49 --> Final output sent to browser
DEBUG - 2016-03-01 19:41:49 --> Total execution time: 1.8067
INFO - 2016-03-01 16:48:11 --> Config Class Initialized
INFO - 2016-03-01 16:48:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:48:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:48:11 --> Utf8 Class Initialized
INFO - 2016-03-01 16:48:11 --> URI Class Initialized
INFO - 2016-03-01 16:48:11 --> Router Class Initialized
INFO - 2016-03-01 16:48:11 --> Output Class Initialized
INFO - 2016-03-01 16:48:11 --> Security Class Initialized
DEBUG - 2016-03-01 16:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:48:11 --> Input Class Initialized
INFO - 2016-03-01 16:48:11 --> Language Class Initialized
INFO - 2016-03-01 16:48:11 --> Loader Class Initialized
INFO - 2016-03-01 16:48:11 --> Helper loaded: url_helper
INFO - 2016-03-01 16:48:11 --> Helper loaded: file_helper
INFO - 2016-03-01 16:48:11 --> Helper loaded: date_helper
INFO - 2016-03-01 16:48:11 --> Helper loaded: form_helper
INFO - 2016-03-01 16:48:11 --> Database Driver Class Initialized
INFO - 2016-03-01 16:48:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:48:12 --> Controller Class Initialized
INFO - 2016-03-01 16:48:12 --> Model Class Initialized
INFO - 2016-03-01 16:48:12 --> Model Class Initialized
INFO - 2016-03-01 16:48:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:48:12 --> Pagination Class Initialized
INFO - 2016-03-01 16:48:12 --> Helper loaded: text_helper
INFO - 2016-03-01 16:48:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:48:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:48:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:48:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:48:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:48:13 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:48:13 --> Final output sent to browser
DEBUG - 2016-03-01 19:48:13 --> Total execution time: 1.2261
INFO - 2016-03-01 16:48:14 --> Config Class Initialized
INFO - 2016-03-01 16:48:14 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:48:14 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:48:14 --> Utf8 Class Initialized
INFO - 2016-03-01 16:48:14 --> URI Class Initialized
DEBUG - 2016-03-01 16:48:14 --> No URI present. Default controller set.
INFO - 2016-03-01 16:48:14 --> Router Class Initialized
INFO - 2016-03-01 16:48:14 --> Output Class Initialized
INFO - 2016-03-01 16:48:14 --> Security Class Initialized
DEBUG - 2016-03-01 16:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:48:14 --> Input Class Initialized
INFO - 2016-03-01 16:48:14 --> Language Class Initialized
INFO - 2016-03-01 16:48:14 --> Loader Class Initialized
INFO - 2016-03-01 16:48:14 --> Helper loaded: url_helper
INFO - 2016-03-01 16:48:14 --> Helper loaded: file_helper
INFO - 2016-03-01 16:48:14 --> Helper loaded: date_helper
INFO - 2016-03-01 16:48:14 --> Helper loaded: form_helper
INFO - 2016-03-01 16:48:14 --> Database Driver Class Initialized
INFO - 2016-03-01 16:48:15 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:48:15 --> Controller Class Initialized
INFO - 2016-03-01 16:48:15 --> Model Class Initialized
INFO - 2016-03-01 16:48:15 --> Model Class Initialized
INFO - 2016-03-01 16:48:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:48:15 --> Pagination Class Initialized
INFO - 2016-03-01 16:48:15 --> Helper loaded: text_helper
INFO - 2016-03-01 16:48:15 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:48:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:48:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:48:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 19:48:15 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:48:15 --> Final output sent to browser
DEBUG - 2016-03-01 19:48:15 --> Total execution time: 1.1414
INFO - 2016-03-01 16:48:17 --> Config Class Initialized
INFO - 2016-03-01 16:48:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:48:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:48:17 --> Utf8 Class Initialized
INFO - 2016-03-01 16:48:17 --> URI Class Initialized
INFO - 2016-03-01 16:48:17 --> Router Class Initialized
INFO - 2016-03-01 16:48:17 --> Output Class Initialized
INFO - 2016-03-01 16:48:17 --> Security Class Initialized
DEBUG - 2016-03-01 16:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:48:17 --> Input Class Initialized
INFO - 2016-03-01 16:48:17 --> Language Class Initialized
INFO - 2016-03-01 16:48:17 --> Loader Class Initialized
INFO - 2016-03-01 16:48:17 --> Helper loaded: url_helper
INFO - 2016-03-01 16:48:17 --> Helper loaded: file_helper
INFO - 2016-03-01 16:48:17 --> Helper loaded: date_helper
INFO - 2016-03-01 16:48:17 --> Helper loaded: form_helper
INFO - 2016-03-01 16:48:17 --> Database Driver Class Initialized
INFO - 2016-03-01 16:48:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:48:18 --> Controller Class Initialized
INFO - 2016-03-01 16:48:18 --> Model Class Initialized
INFO - 2016-03-01 16:48:18 --> Model Class Initialized
INFO - 2016-03-01 16:48:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:48:18 --> Pagination Class Initialized
INFO - 2016-03-01 16:48:18 --> Helper loaded: text_helper
INFO - 2016-03-01 16:48:18 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 19:48:18 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:48:18 --> Final output sent to browser
DEBUG - 2016-03-01 19:48:18 --> Total execution time: 1.0924
INFO - 2016-03-01 16:48:32 --> Config Class Initialized
INFO - 2016-03-01 16:48:32 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:48:32 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:48:32 --> Utf8 Class Initialized
INFO - 2016-03-01 16:48:32 --> URI Class Initialized
INFO - 2016-03-01 16:48:32 --> Router Class Initialized
INFO - 2016-03-01 16:48:32 --> Output Class Initialized
INFO - 2016-03-01 16:48:32 --> Security Class Initialized
DEBUG - 2016-03-01 16:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:48:32 --> Input Class Initialized
INFO - 2016-03-01 16:48:32 --> Language Class Initialized
INFO - 2016-03-01 16:48:32 --> Loader Class Initialized
INFO - 2016-03-01 16:48:32 --> Helper loaded: url_helper
INFO - 2016-03-01 16:48:32 --> Helper loaded: file_helper
INFO - 2016-03-01 16:48:32 --> Helper loaded: date_helper
INFO - 2016-03-01 16:48:32 --> Helper loaded: form_helper
INFO - 2016-03-01 16:48:32 --> Database Driver Class Initialized
INFO - 2016-03-01 16:48:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:48:33 --> Controller Class Initialized
INFO - 2016-03-01 16:48:33 --> Model Class Initialized
INFO - 2016-03-01 16:48:33 --> Model Class Initialized
INFO - 2016-03-01 16:48:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:48:33 --> Pagination Class Initialized
INFO - 2016-03-01 16:48:33 --> Helper loaded: text_helper
INFO - 2016-03-01 16:48:33 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 19:48:33 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:48:33 --> Final output sent to browser
DEBUG - 2016-03-01 19:48:33 --> Total execution time: 1.1639
INFO - 2016-03-01 16:48:34 --> Config Class Initialized
INFO - 2016-03-01 16:48:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:48:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:48:34 --> Utf8 Class Initialized
INFO - 2016-03-01 16:48:34 --> URI Class Initialized
INFO - 2016-03-01 16:48:34 --> Router Class Initialized
INFO - 2016-03-01 16:48:34 --> Output Class Initialized
INFO - 2016-03-01 16:48:34 --> Security Class Initialized
DEBUG - 2016-03-01 16:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:48:34 --> Input Class Initialized
INFO - 2016-03-01 16:48:34 --> Language Class Initialized
INFO - 2016-03-01 16:48:34 --> Loader Class Initialized
INFO - 2016-03-01 16:48:34 --> Helper loaded: url_helper
INFO - 2016-03-01 16:48:34 --> Helper loaded: file_helper
INFO - 2016-03-01 16:48:34 --> Helper loaded: date_helper
INFO - 2016-03-01 16:48:34 --> Helper loaded: form_helper
INFO - 2016-03-01 16:48:34 --> Database Driver Class Initialized
INFO - 2016-03-01 16:48:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:48:36 --> Controller Class Initialized
INFO - 2016-03-01 16:48:36 --> Model Class Initialized
INFO - 2016-03-01 16:48:36 --> Model Class Initialized
INFO - 2016-03-01 16:48:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:48:36 --> Pagination Class Initialized
INFO - 2016-03-01 16:48:36 --> Helper loaded: text_helper
INFO - 2016-03-01 16:48:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:48:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:48:36 --> Final output sent to browser
DEBUG - 2016-03-01 19:48:36 --> Total execution time: 1.2139
INFO - 2016-03-01 16:48:41 --> Config Class Initialized
INFO - 2016-03-01 16:48:41 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:48:41 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:48:41 --> Utf8 Class Initialized
INFO - 2016-03-01 16:48:41 --> URI Class Initialized
INFO - 2016-03-01 16:48:41 --> Router Class Initialized
INFO - 2016-03-01 16:48:41 --> Output Class Initialized
INFO - 2016-03-01 16:48:41 --> Security Class Initialized
DEBUG - 2016-03-01 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:48:41 --> Input Class Initialized
INFO - 2016-03-01 16:48:41 --> Language Class Initialized
INFO - 2016-03-01 16:48:41 --> Loader Class Initialized
INFO - 2016-03-01 16:48:41 --> Helper loaded: url_helper
INFO - 2016-03-01 16:48:41 --> Helper loaded: file_helper
INFO - 2016-03-01 16:48:41 --> Helper loaded: date_helper
INFO - 2016-03-01 16:48:41 --> Helper loaded: form_helper
INFO - 2016-03-01 16:48:41 --> Database Driver Class Initialized
INFO - 2016-03-01 16:48:42 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:48:42 --> Controller Class Initialized
INFO - 2016-03-01 16:48:42 --> Model Class Initialized
INFO - 2016-03-01 16:48:42 --> Model Class Initialized
INFO - 2016-03-01 16:48:42 --> Form Validation Class Initialized
INFO - 2016-03-01 16:48:42 --> Helper loaded: text_helper
INFO - 2016-03-01 16:48:42 --> Config Class Initialized
INFO - 2016-03-01 16:48:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:48:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:48:42 --> Utf8 Class Initialized
INFO - 2016-03-01 16:48:42 --> URI Class Initialized
DEBUG - 2016-03-01 16:48:42 --> No URI present. Default controller set.
INFO - 2016-03-01 16:48:42 --> Router Class Initialized
INFO - 2016-03-01 16:48:42 --> Output Class Initialized
INFO - 2016-03-01 16:48:42 --> Security Class Initialized
DEBUG - 2016-03-01 16:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:48:42 --> Input Class Initialized
INFO - 2016-03-01 16:48:42 --> Language Class Initialized
INFO - 2016-03-01 16:48:42 --> Loader Class Initialized
INFO - 2016-03-01 16:48:42 --> Helper loaded: url_helper
INFO - 2016-03-01 16:48:42 --> Helper loaded: file_helper
INFO - 2016-03-01 16:48:42 --> Helper loaded: date_helper
INFO - 2016-03-01 16:48:42 --> Helper loaded: form_helper
INFO - 2016-03-01 16:48:42 --> Database Driver Class Initialized
INFO - 2016-03-01 16:48:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:48:43 --> Controller Class Initialized
INFO - 2016-03-01 16:48:43 --> Model Class Initialized
INFO - 2016-03-01 16:48:43 --> Model Class Initialized
INFO - 2016-03-01 16:48:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:48:43 --> Pagination Class Initialized
INFO - 2016-03-01 16:48:43 --> Helper loaded: text_helper
INFO - 2016-03-01 16:48:43 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:48:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:48:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:48:43 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 19:48:44 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:48:44 --> Final output sent to browser
DEBUG - 2016-03-01 19:48:44 --> Total execution time: 1.2290
INFO - 2016-03-01 16:48:45 --> Config Class Initialized
INFO - 2016-03-01 16:48:45 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:48:45 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:48:45 --> Utf8 Class Initialized
INFO - 2016-03-01 16:48:45 --> URI Class Initialized
INFO - 2016-03-01 16:48:45 --> Router Class Initialized
INFO - 2016-03-01 16:48:45 --> Output Class Initialized
INFO - 2016-03-01 16:48:45 --> Security Class Initialized
DEBUG - 2016-03-01 16:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:48:45 --> Input Class Initialized
INFO - 2016-03-01 16:48:45 --> Language Class Initialized
INFO - 2016-03-01 16:48:45 --> Loader Class Initialized
INFO - 2016-03-01 16:48:45 --> Helper loaded: url_helper
INFO - 2016-03-01 16:48:45 --> Helper loaded: file_helper
INFO - 2016-03-01 16:48:45 --> Helper loaded: date_helper
INFO - 2016-03-01 16:48:45 --> Helper loaded: form_helper
INFO - 2016-03-01 16:48:45 --> Database Driver Class Initialized
INFO - 2016-03-01 16:48:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:48:46 --> Controller Class Initialized
INFO - 2016-03-01 16:48:46 --> Model Class Initialized
INFO - 2016-03-01 16:48:46 --> Model Class Initialized
INFO - 2016-03-01 16:48:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:48:46 --> Pagination Class Initialized
INFO - 2016-03-01 16:48:46 --> Helper loaded: text_helper
INFO - 2016-03-01 16:48:46 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:48:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:48:46 --> Final output sent to browser
DEBUG - 2016-03-01 19:48:46 --> Total execution time: 1.1593
INFO - 2016-03-01 16:49:50 --> Config Class Initialized
INFO - 2016-03-01 16:49:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 16:49:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 16:49:50 --> Utf8 Class Initialized
INFO - 2016-03-01 16:49:50 --> URI Class Initialized
INFO - 2016-03-01 16:49:50 --> Router Class Initialized
INFO - 2016-03-01 16:49:50 --> Output Class Initialized
INFO - 2016-03-01 16:49:50 --> Security Class Initialized
DEBUG - 2016-03-01 16:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 16:49:50 --> Input Class Initialized
INFO - 2016-03-01 16:49:50 --> Language Class Initialized
INFO - 2016-03-01 16:49:50 --> Loader Class Initialized
INFO - 2016-03-01 16:49:50 --> Helper loaded: url_helper
INFO - 2016-03-01 16:49:50 --> Helper loaded: file_helper
INFO - 2016-03-01 16:49:50 --> Helper loaded: date_helper
INFO - 2016-03-01 16:49:50 --> Helper loaded: form_helper
INFO - 2016-03-01 16:49:50 --> Database Driver Class Initialized
INFO - 2016-03-01 16:49:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 16:49:51 --> Controller Class Initialized
INFO - 2016-03-01 16:49:51 --> Model Class Initialized
INFO - 2016-03-01 16:49:51 --> Model Class Initialized
INFO - 2016-03-01 16:49:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 16:49:51 --> Pagination Class Initialized
INFO - 2016-03-01 16:49:51 --> Helper loaded: text_helper
INFO - 2016-03-01 16:49:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 19:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 19:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 19:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 19:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 19:49:51 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 19:49:51 --> Final output sent to browser
DEBUG - 2016-03-01 19:49:51 --> Total execution time: 1.2191
INFO - 2016-03-01 17:03:01 --> Config Class Initialized
INFO - 2016-03-01 17:03:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 17:03:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 17:03:01 --> Utf8 Class Initialized
INFO - 2016-03-01 17:03:01 --> URI Class Initialized
INFO - 2016-03-01 17:03:01 --> Router Class Initialized
INFO - 2016-03-01 17:03:01 --> Output Class Initialized
INFO - 2016-03-01 17:03:01 --> Security Class Initialized
DEBUG - 2016-03-01 17:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 17:03:01 --> Input Class Initialized
INFO - 2016-03-01 17:03:01 --> Language Class Initialized
INFO - 2016-03-01 17:03:01 --> Loader Class Initialized
INFO - 2016-03-01 17:03:01 --> Helper loaded: url_helper
INFO - 2016-03-01 17:03:01 --> Helper loaded: file_helper
INFO - 2016-03-01 17:03:01 --> Helper loaded: date_helper
INFO - 2016-03-01 17:03:01 --> Helper loaded: form_helper
INFO - 2016-03-01 17:03:01 --> Database Driver Class Initialized
INFO - 2016-03-01 17:03:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 17:03:02 --> Controller Class Initialized
INFO - 2016-03-01 17:03:02 --> Model Class Initialized
INFO - 2016-03-01 17:03:02 --> Model Class Initialized
INFO - 2016-03-01 17:03:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 17:03:02 --> Pagination Class Initialized
INFO - 2016-03-01 17:03:02 --> Helper loaded: text_helper
INFO - 2016-03-01 17:03:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 20:03:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 20:03:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 20:03:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 20:03:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 20:03:02 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 20:03:02 --> Final output sent to browser
DEBUG - 2016-03-01 20:03:02 --> Total execution time: 1.1730
INFO - 2016-03-01 17:04:30 --> Config Class Initialized
INFO - 2016-03-01 17:04:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 17:04:30 --> UTF-8 Support Enabled
INFO - 2016-03-01 17:04:30 --> Utf8 Class Initialized
INFO - 2016-03-01 17:04:30 --> URI Class Initialized
INFO - 2016-03-01 17:04:30 --> Router Class Initialized
INFO - 2016-03-01 17:04:30 --> Output Class Initialized
INFO - 2016-03-01 17:04:30 --> Security Class Initialized
DEBUG - 2016-03-01 17:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 17:04:30 --> Input Class Initialized
INFO - 2016-03-01 17:04:30 --> Language Class Initialized
INFO - 2016-03-01 17:04:30 --> Loader Class Initialized
INFO - 2016-03-01 17:04:30 --> Helper loaded: url_helper
INFO - 2016-03-01 17:04:30 --> Helper loaded: file_helper
INFO - 2016-03-01 17:04:30 --> Helper loaded: date_helper
INFO - 2016-03-01 17:04:30 --> Helper loaded: form_helper
INFO - 2016-03-01 17:04:30 --> Database Driver Class Initialized
INFO - 2016-03-01 17:04:31 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 17:04:31 --> Controller Class Initialized
INFO - 2016-03-01 17:04:31 --> Model Class Initialized
INFO - 2016-03-01 17:04:31 --> Model Class Initialized
INFO - 2016-03-01 17:04:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 17:04:31 --> Pagination Class Initialized
INFO - 2016-03-01 17:04:31 --> Helper loaded: text_helper
INFO - 2016-03-01 17:04:31 --> Helper loaded: cookie_helper
INFO - 2016-03-01 20:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 20:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 20:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 20:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 20:04:31 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 20:04:31 --> Final output sent to browser
DEBUG - 2016-03-01 20:04:31 --> Total execution time: 1.2412
INFO - 2016-03-01 17:04:54 --> Config Class Initialized
INFO - 2016-03-01 17:04:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 17:04:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 17:04:54 --> Utf8 Class Initialized
INFO - 2016-03-01 17:04:54 --> URI Class Initialized
INFO - 2016-03-01 17:04:54 --> Router Class Initialized
INFO - 2016-03-01 17:04:54 --> Output Class Initialized
INFO - 2016-03-01 17:04:54 --> Security Class Initialized
DEBUG - 2016-03-01 17:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 17:04:54 --> Input Class Initialized
INFO - 2016-03-01 17:04:54 --> Language Class Initialized
INFO - 2016-03-01 17:04:54 --> Loader Class Initialized
INFO - 2016-03-01 17:04:54 --> Helper loaded: url_helper
INFO - 2016-03-01 17:04:54 --> Helper loaded: file_helper
INFO - 2016-03-01 17:04:54 --> Helper loaded: date_helper
INFO - 2016-03-01 17:04:54 --> Helper loaded: form_helper
INFO - 2016-03-01 17:04:54 --> Database Driver Class Initialized
INFO - 2016-03-01 17:04:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 17:04:55 --> Controller Class Initialized
INFO - 2016-03-01 17:04:55 --> Model Class Initialized
INFO - 2016-03-01 17:04:55 --> Model Class Initialized
INFO - 2016-03-01 17:04:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 17:04:55 --> Pagination Class Initialized
INFO - 2016-03-01 17:04:55 --> Helper loaded: text_helper
INFO - 2016-03-01 17:04:55 --> Helper loaded: cookie_helper
INFO - 2016-03-01 20:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 20:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 20:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 20:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 20:04:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 20:04:55 --> Final output sent to browser
DEBUG - 2016-03-01 20:04:55 --> Total execution time: 1.2553
INFO - 2016-03-01 17:05:52 --> Config Class Initialized
INFO - 2016-03-01 17:05:52 --> Hooks Class Initialized
DEBUG - 2016-03-01 17:05:52 --> UTF-8 Support Enabled
INFO - 2016-03-01 17:05:52 --> Utf8 Class Initialized
INFO - 2016-03-01 17:05:52 --> URI Class Initialized
INFO - 2016-03-01 17:05:52 --> Router Class Initialized
INFO - 2016-03-01 17:05:52 --> Output Class Initialized
INFO - 2016-03-01 17:05:52 --> Security Class Initialized
DEBUG - 2016-03-01 17:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 17:05:52 --> Input Class Initialized
INFO - 2016-03-01 17:05:52 --> Language Class Initialized
INFO - 2016-03-01 17:05:52 --> Loader Class Initialized
INFO - 2016-03-01 17:05:52 --> Helper loaded: url_helper
INFO - 2016-03-01 17:05:52 --> Helper loaded: file_helper
INFO - 2016-03-01 17:05:52 --> Helper loaded: date_helper
INFO - 2016-03-01 17:05:52 --> Helper loaded: form_helper
INFO - 2016-03-01 17:05:52 --> Database Driver Class Initialized
INFO - 2016-03-01 17:05:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 17:05:53 --> Controller Class Initialized
INFO - 2016-03-01 17:05:53 --> Model Class Initialized
INFO - 2016-03-01 17:05:53 --> Model Class Initialized
INFO - 2016-03-01 17:05:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 17:05:53 --> Pagination Class Initialized
INFO - 2016-03-01 17:05:53 --> Helper loaded: text_helper
INFO - 2016-03-01 17:05:53 --> Helper loaded: cookie_helper
INFO - 2016-03-01 20:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 20:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 20:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 20:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 20:05:53 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 20:05:54 --> Final output sent to browser
DEBUG - 2016-03-01 20:05:54 --> Total execution time: 1.2384
INFO - 2016-03-01 17:07:15 --> Config Class Initialized
INFO - 2016-03-01 17:07:15 --> Hooks Class Initialized
DEBUG - 2016-03-01 17:07:15 --> UTF-8 Support Enabled
INFO - 2016-03-01 17:07:15 --> Utf8 Class Initialized
INFO - 2016-03-01 17:07:15 --> URI Class Initialized
INFO - 2016-03-01 17:07:15 --> Router Class Initialized
INFO - 2016-03-01 17:07:15 --> Output Class Initialized
INFO - 2016-03-01 17:07:15 --> Security Class Initialized
DEBUG - 2016-03-01 17:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 17:07:15 --> Input Class Initialized
INFO - 2016-03-01 17:07:15 --> Language Class Initialized
INFO - 2016-03-01 17:07:15 --> Loader Class Initialized
INFO - 2016-03-01 17:07:15 --> Helper loaded: url_helper
INFO - 2016-03-01 17:07:15 --> Helper loaded: file_helper
INFO - 2016-03-01 17:07:15 --> Helper loaded: date_helper
INFO - 2016-03-01 17:07:15 --> Helper loaded: form_helper
INFO - 2016-03-01 17:07:15 --> Database Driver Class Initialized
INFO - 2016-03-01 17:07:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 17:07:17 --> Controller Class Initialized
INFO - 2016-03-01 17:07:17 --> Model Class Initialized
INFO - 2016-03-01 17:07:17 --> Model Class Initialized
INFO - 2016-03-01 17:07:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 17:07:17 --> Pagination Class Initialized
INFO - 2016-03-01 17:07:17 --> Helper loaded: text_helper
INFO - 2016-03-01 17:07:17 --> Helper loaded: cookie_helper
INFO - 2016-03-01 20:07:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 20:07:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 20:07:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 20:07:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 20:07:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 20:07:17 --> Final output sent to browser
DEBUG - 2016-03-01 20:07:17 --> Total execution time: 1.2159
INFO - 2016-03-01 20:32:34 --> Config Class Initialized
INFO - 2016-03-01 20:32:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:32:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:32:35 --> Utf8 Class Initialized
INFO - 2016-03-01 20:32:35 --> URI Class Initialized
DEBUG - 2016-03-01 20:32:35 --> No URI present. Default controller set.
INFO - 2016-03-01 20:32:35 --> Router Class Initialized
INFO - 2016-03-01 20:32:35 --> Output Class Initialized
INFO - 2016-03-01 20:32:35 --> Security Class Initialized
DEBUG - 2016-03-01 20:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:32:35 --> Input Class Initialized
INFO - 2016-03-01 20:32:35 --> Language Class Initialized
INFO - 2016-03-01 20:32:35 --> Loader Class Initialized
INFO - 2016-03-01 20:32:35 --> Helper loaded: url_helper
INFO - 2016-03-01 20:32:35 --> Helper loaded: file_helper
INFO - 2016-03-01 20:32:35 --> Helper loaded: date_helper
INFO - 2016-03-01 20:32:35 --> Helper loaded: form_helper
INFO - 2016-03-01 20:32:35 --> Database Driver Class Initialized
INFO - 2016-03-01 20:32:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:32:36 --> Controller Class Initialized
INFO - 2016-03-01 20:32:36 --> Model Class Initialized
INFO - 2016-03-01 20:32:36 --> Model Class Initialized
INFO - 2016-03-01 20:32:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:32:36 --> Pagination Class Initialized
INFO - 2016-03-01 20:32:36 --> Helper loaded: text_helper
INFO - 2016-03-01 20:32:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:32:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:32:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:32:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\home.php
INFO - 2016-03-01 23:32:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:32:37 --> Final output sent to browser
DEBUG - 2016-03-01 23:32:37 --> Total execution time: 2.0343
INFO - 2016-03-01 20:32:54 --> Config Class Initialized
INFO - 2016-03-01 20:32:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:32:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:32:54 --> Utf8 Class Initialized
INFO - 2016-03-01 20:32:54 --> URI Class Initialized
INFO - 2016-03-01 20:32:54 --> Router Class Initialized
INFO - 2016-03-01 20:32:54 --> Output Class Initialized
INFO - 2016-03-01 20:32:54 --> Security Class Initialized
DEBUG - 2016-03-01 20:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:32:54 --> Input Class Initialized
INFO - 2016-03-01 20:32:54 --> Language Class Initialized
INFO - 2016-03-01 20:32:54 --> Loader Class Initialized
INFO - 2016-03-01 20:32:54 --> Helper loaded: url_helper
INFO - 2016-03-01 20:32:54 --> Helper loaded: file_helper
INFO - 2016-03-01 20:32:54 --> Helper loaded: date_helper
INFO - 2016-03-01 20:32:54 --> Helper loaded: form_helper
INFO - 2016-03-01 20:32:54 --> Database Driver Class Initialized
INFO - 2016-03-01 20:32:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:32:55 --> Controller Class Initialized
INFO - 2016-03-01 20:32:55 --> Model Class Initialized
INFO - 2016-03-01 20:32:55 --> Model Class Initialized
INFO - 2016-03-01 20:32:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:32:55 --> Pagination Class Initialized
INFO - 2016-03-01 20:32:55 --> Helper loaded: text_helper
INFO - 2016-03-01 20:32:55 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 23:32:55 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:32:55 --> Final output sent to browser
DEBUG - 2016-03-01 23:32:55 --> Total execution time: 1.2138
INFO - 2016-03-01 20:33:02 --> Config Class Initialized
INFO - 2016-03-01 20:33:02 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:33:02 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:33:02 --> Utf8 Class Initialized
INFO - 2016-03-01 20:33:02 --> URI Class Initialized
INFO - 2016-03-01 20:33:02 --> Router Class Initialized
INFO - 2016-03-01 20:33:02 --> Output Class Initialized
INFO - 2016-03-01 20:33:02 --> Security Class Initialized
DEBUG - 2016-03-01 20:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:33:02 --> Input Class Initialized
INFO - 2016-03-01 20:33:02 --> Language Class Initialized
INFO - 2016-03-01 20:33:02 --> Loader Class Initialized
INFO - 2016-03-01 20:33:02 --> Helper loaded: url_helper
INFO - 2016-03-01 20:33:02 --> Helper loaded: file_helper
INFO - 2016-03-01 20:33:02 --> Helper loaded: date_helper
INFO - 2016-03-01 20:33:02 --> Helper loaded: form_helper
INFO - 2016-03-01 20:33:02 --> Database Driver Class Initialized
INFO - 2016-03-01 20:33:03 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:33:03 --> Controller Class Initialized
INFO - 2016-03-01 20:33:03 --> Model Class Initialized
INFO - 2016-03-01 20:33:03 --> Model Class Initialized
INFO - 2016-03-01 20:33:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:33:03 --> Pagination Class Initialized
INFO - 2016-03-01 20:33:03 --> Helper loaded: text_helper
INFO - 2016-03-01 20:33:03 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:33:03 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 23:33:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 23:33:04 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:33:04 --> Final output sent to browser
DEBUG - 2016-03-01 23:33:04 --> Total execution time: 1.3076
INFO - 2016-03-01 20:34:45 --> Config Class Initialized
INFO - 2016-03-01 20:34:45 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:34:45 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:34:45 --> Utf8 Class Initialized
INFO - 2016-03-01 20:34:45 --> URI Class Initialized
INFO - 2016-03-01 20:34:45 --> Router Class Initialized
INFO - 2016-03-01 20:34:45 --> Output Class Initialized
INFO - 2016-03-01 20:34:45 --> Security Class Initialized
DEBUG - 2016-03-01 20:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:34:45 --> Input Class Initialized
INFO - 2016-03-01 20:34:45 --> Language Class Initialized
INFO - 2016-03-01 20:34:45 --> Loader Class Initialized
INFO - 2016-03-01 20:34:45 --> Helper loaded: url_helper
INFO - 2016-03-01 20:34:45 --> Helper loaded: file_helper
INFO - 2016-03-01 20:34:45 --> Helper loaded: date_helper
INFO - 2016-03-01 20:34:45 --> Helper loaded: form_helper
INFO - 2016-03-01 20:34:45 --> Database Driver Class Initialized
INFO - 2016-03-01 20:34:46 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:34:46 --> Controller Class Initialized
INFO - 2016-03-01 20:34:46 --> Model Class Initialized
INFO - 2016-03-01 20:34:46 --> Model Class Initialized
INFO - 2016-03-01 20:34:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:34:46 --> Pagination Class Initialized
INFO - 2016-03-01 20:34:46 --> Helper loaded: text_helper
INFO - 2016-03-01 20:34:46 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:34:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:34:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:34:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 23:34:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 23:34:46 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:34:46 --> Final output sent to browser
DEBUG - 2016-03-01 23:34:46 --> Total execution time: 1.2054
INFO - 2016-03-01 20:37:55 --> Config Class Initialized
INFO - 2016-03-01 20:37:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:37:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:37:55 --> Utf8 Class Initialized
INFO - 2016-03-01 20:37:55 --> URI Class Initialized
INFO - 2016-03-01 20:37:55 --> Router Class Initialized
INFO - 2016-03-01 20:37:55 --> Output Class Initialized
INFO - 2016-03-01 20:37:55 --> Security Class Initialized
DEBUG - 2016-03-01 20:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:37:55 --> Input Class Initialized
INFO - 2016-03-01 20:37:55 --> Language Class Initialized
INFO - 2016-03-01 20:37:55 --> Loader Class Initialized
INFO - 2016-03-01 20:37:55 --> Helper loaded: url_helper
INFO - 2016-03-01 20:37:55 --> Helper loaded: file_helper
INFO - 2016-03-01 20:37:55 --> Helper loaded: date_helper
INFO - 2016-03-01 20:37:55 --> Helper loaded: form_helper
INFO - 2016-03-01 20:37:55 --> Database Driver Class Initialized
INFO - 2016-03-01 20:37:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:37:56 --> Controller Class Initialized
INFO - 2016-03-01 20:37:56 --> Model Class Initialized
INFO - 2016-03-01 20:37:56 --> Model Class Initialized
INFO - 2016-03-01 20:37:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:37:56 --> Pagination Class Initialized
INFO - 2016-03-01 20:37:56 --> Helper loaded: text_helper
INFO - 2016-03-01 20:37:56 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 23:37:56 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:37:56 --> Final output sent to browser
DEBUG - 2016-03-01 23:37:56 --> Total execution time: 1.1721
INFO - 2016-03-01 20:38:07 --> Config Class Initialized
INFO - 2016-03-01 20:38:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:38:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:38:07 --> Utf8 Class Initialized
INFO - 2016-03-01 20:38:07 --> URI Class Initialized
INFO - 2016-03-01 20:38:07 --> Router Class Initialized
INFO - 2016-03-01 20:38:07 --> Output Class Initialized
INFO - 2016-03-01 20:38:07 --> Security Class Initialized
DEBUG - 2016-03-01 20:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:38:07 --> Input Class Initialized
INFO - 2016-03-01 20:38:07 --> Language Class Initialized
INFO - 2016-03-01 20:38:07 --> Loader Class Initialized
INFO - 2016-03-01 20:38:07 --> Helper loaded: url_helper
INFO - 2016-03-01 20:38:07 --> Helper loaded: file_helper
INFO - 2016-03-01 20:38:07 --> Helper loaded: date_helper
INFO - 2016-03-01 20:38:07 --> Helper loaded: form_helper
INFO - 2016-03-01 20:38:07 --> Database Driver Class Initialized
INFO - 2016-03-01 20:38:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:38:08 --> Controller Class Initialized
INFO - 2016-03-01 20:38:08 --> Model Class Initialized
INFO - 2016-03-01 20:38:08 --> Model Class Initialized
INFO - 2016-03-01 20:38:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:38:08 --> Pagination Class Initialized
INFO - 2016-03-01 20:38:08 --> Helper loaded: text_helper
INFO - 2016-03-01 20:38:08 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 23:38:08 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:38:08 --> Final output sent to browser
DEBUG - 2016-03-01 23:38:08 --> Total execution time: 1.1453
INFO - 2016-03-01 20:38:22 --> Config Class Initialized
INFO - 2016-03-01 20:38:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:38:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:38:22 --> Utf8 Class Initialized
INFO - 2016-03-01 20:38:22 --> URI Class Initialized
INFO - 2016-03-01 20:38:22 --> Router Class Initialized
INFO - 2016-03-01 20:38:22 --> Output Class Initialized
INFO - 2016-03-01 20:38:22 --> Security Class Initialized
DEBUG - 2016-03-01 20:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:38:22 --> Input Class Initialized
INFO - 2016-03-01 20:38:22 --> Language Class Initialized
INFO - 2016-03-01 20:38:22 --> Loader Class Initialized
INFO - 2016-03-01 20:38:22 --> Helper loaded: url_helper
INFO - 2016-03-01 20:38:22 --> Helper loaded: file_helper
INFO - 2016-03-01 20:38:22 --> Helper loaded: date_helper
INFO - 2016-03-01 20:38:22 --> Helper loaded: form_helper
INFO - 2016-03-01 20:38:22 --> Database Driver Class Initialized
INFO - 2016-03-01 20:38:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:38:23 --> Controller Class Initialized
INFO - 2016-03-01 20:38:23 --> Model Class Initialized
INFO - 2016-03-01 20:38:24 --> Model Class Initialized
INFO - 2016-03-01 20:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:38:24 --> Pagination Class Initialized
INFO - 2016-03-01 20:38:24 --> Helper loaded: text_helper
INFO - 2016-03-01 20:38:24 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\board_list.php
INFO - 2016-03-01 23:38:24 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:38:24 --> Final output sent to browser
DEBUG - 2016-03-01 23:38:24 --> Total execution time: 1.1484
INFO - 2016-03-01 20:38:26 --> Config Class Initialized
INFO - 2016-03-01 20:38:26 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:38:26 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:38:26 --> Utf8 Class Initialized
INFO - 2016-03-01 20:38:26 --> URI Class Initialized
INFO - 2016-03-01 20:38:26 --> Router Class Initialized
INFO - 2016-03-01 20:38:26 --> Output Class Initialized
INFO - 2016-03-01 20:38:26 --> Security Class Initialized
DEBUG - 2016-03-01 20:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:38:26 --> Input Class Initialized
INFO - 2016-03-01 20:38:26 --> Language Class Initialized
INFO - 2016-03-01 20:38:26 --> Loader Class Initialized
INFO - 2016-03-01 20:38:26 --> Helper loaded: url_helper
INFO - 2016-03-01 20:38:26 --> Helper loaded: file_helper
INFO - 2016-03-01 20:38:26 --> Helper loaded: date_helper
INFO - 2016-03-01 20:38:26 --> Helper loaded: form_helper
INFO - 2016-03-01 20:38:26 --> Database Driver Class Initialized
INFO - 2016-03-01 20:38:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:38:27 --> Controller Class Initialized
INFO - 2016-03-01 20:38:27 --> Model Class Initialized
INFO - 2016-03-01 20:38:27 --> Model Class Initialized
INFO - 2016-03-01 20:38:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:38:27 --> Pagination Class Initialized
INFO - 2016-03-01 20:38:27 --> Helper loaded: text_helper
INFO - 2016-03-01 20:38:27 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:38:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:38:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:38:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 23:38:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 23:38:27 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:38:27 --> Final output sent to browser
DEBUG - 2016-03-01 23:38:27 --> Total execution time: 1.1980
INFO - 2016-03-01 20:49:31 --> Config Class Initialized
INFO - 2016-03-01 20:49:31 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:49:31 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:49:31 --> Utf8 Class Initialized
INFO - 2016-03-01 20:49:31 --> URI Class Initialized
INFO - 2016-03-01 20:49:31 --> Router Class Initialized
INFO - 2016-03-01 20:49:31 --> Output Class Initialized
INFO - 2016-03-01 20:49:31 --> Security Class Initialized
DEBUG - 2016-03-01 20:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:49:31 --> Input Class Initialized
INFO - 2016-03-01 20:49:31 --> Language Class Initialized
INFO - 2016-03-01 20:49:31 --> Loader Class Initialized
INFO - 2016-03-01 20:49:31 --> Helper loaded: url_helper
INFO - 2016-03-01 20:49:31 --> Helper loaded: file_helper
INFO - 2016-03-01 20:49:31 --> Helper loaded: date_helper
INFO - 2016-03-01 20:49:31 --> Helper loaded: form_helper
INFO - 2016-03-01 20:49:31 --> Database Driver Class Initialized
INFO - 2016-03-01 20:49:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:49:32 --> Controller Class Initialized
INFO - 2016-03-01 20:49:32 --> Model Class Initialized
INFO - 2016-03-01 20:49:32 --> Model Class Initialized
INFO - 2016-03-01 20:49:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:49:32 --> Pagination Class Initialized
INFO - 2016-03-01 20:49:32 --> Helper loaded: text_helper
INFO - 2016-03-01 20:49:32 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 23:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 23:49:32 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:49:32 --> Final output sent to browser
DEBUG - 2016-03-01 23:49:32 --> Total execution time: 1.2417
INFO - 2016-03-01 20:50:34 --> Config Class Initialized
INFO - 2016-03-01 20:50:34 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:50:34 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:50:34 --> Utf8 Class Initialized
INFO - 2016-03-01 20:50:34 --> URI Class Initialized
INFO - 2016-03-01 20:50:34 --> Router Class Initialized
INFO - 2016-03-01 20:50:34 --> Output Class Initialized
INFO - 2016-03-01 20:50:34 --> Security Class Initialized
DEBUG - 2016-03-01 20:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:50:34 --> Input Class Initialized
INFO - 2016-03-01 20:50:34 --> Language Class Initialized
INFO - 2016-03-01 20:50:34 --> Loader Class Initialized
INFO - 2016-03-01 20:50:34 --> Helper loaded: url_helper
INFO - 2016-03-01 20:50:34 --> Helper loaded: file_helper
INFO - 2016-03-01 20:50:34 --> Helper loaded: date_helper
INFO - 2016-03-01 20:50:34 --> Helper loaded: form_helper
INFO - 2016-03-01 20:50:34 --> Database Driver Class Initialized
INFO - 2016-03-01 20:50:35 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:50:35 --> Controller Class Initialized
INFO - 2016-03-01 20:50:35 --> Model Class Initialized
INFO - 2016-03-01 20:50:35 --> Model Class Initialized
INFO - 2016-03-01 20:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:50:35 --> Pagination Class Initialized
INFO - 2016-03-01 20:50:35 --> Helper loaded: text_helper
INFO - 2016-03-01 20:50:35 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 23:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 23:50:35 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:50:35 --> Final output sent to browser
DEBUG - 2016-03-01 23:50:35 --> Total execution time: 1.2549
INFO - 2016-03-01 20:51:39 --> Config Class Initialized
INFO - 2016-03-01 20:51:39 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:51:39 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:51:39 --> Utf8 Class Initialized
INFO - 2016-03-01 20:51:39 --> URI Class Initialized
INFO - 2016-03-01 20:51:39 --> Router Class Initialized
INFO - 2016-03-01 20:51:39 --> Output Class Initialized
INFO - 2016-03-01 20:51:39 --> Security Class Initialized
DEBUG - 2016-03-01 20:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:51:39 --> Input Class Initialized
INFO - 2016-03-01 20:51:39 --> Language Class Initialized
INFO - 2016-03-01 20:51:39 --> Loader Class Initialized
INFO - 2016-03-01 20:51:39 --> Helper loaded: url_helper
INFO - 2016-03-01 20:51:39 --> Helper loaded: file_helper
INFO - 2016-03-01 20:51:39 --> Helper loaded: date_helper
INFO - 2016-03-01 20:51:39 --> Helper loaded: form_helper
INFO - 2016-03-01 20:51:39 --> Database Driver Class Initialized
INFO - 2016-03-01 20:51:40 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:51:40 --> Controller Class Initialized
INFO - 2016-03-01 20:51:40 --> Model Class Initialized
INFO - 2016-03-01 20:51:40 --> Model Class Initialized
INFO - 2016-03-01 20:51:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:51:40 --> Pagination Class Initialized
INFO - 2016-03-01 20:51:40 --> Helper loaded: text_helper
INFO - 2016-03-01 20:51:40 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:51:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:51:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:51:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 23:51:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 23:51:40 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:51:40 --> Final output sent to browser
DEBUG - 2016-03-01 23:51:40 --> Total execution time: 1.1342
INFO - 2016-03-01 20:54:16 --> Config Class Initialized
INFO - 2016-03-01 20:54:16 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:54:16 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:54:16 --> Utf8 Class Initialized
INFO - 2016-03-01 20:54:16 --> URI Class Initialized
INFO - 2016-03-01 20:54:16 --> Router Class Initialized
INFO - 2016-03-01 20:54:16 --> Output Class Initialized
INFO - 2016-03-01 20:54:16 --> Security Class Initialized
DEBUG - 2016-03-01 20:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:54:16 --> Input Class Initialized
INFO - 2016-03-01 20:54:16 --> Language Class Initialized
INFO - 2016-03-01 20:54:16 --> Loader Class Initialized
INFO - 2016-03-01 20:54:16 --> Helper loaded: url_helper
INFO - 2016-03-01 20:54:16 --> Helper loaded: file_helper
INFO - 2016-03-01 20:54:16 --> Helper loaded: date_helper
INFO - 2016-03-01 20:54:16 --> Helper loaded: form_helper
INFO - 2016-03-01 20:54:16 --> Database Driver Class Initialized
INFO - 2016-03-01 20:54:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:54:17 --> Controller Class Initialized
INFO - 2016-03-01 20:54:17 --> Model Class Initialized
INFO - 2016-03-01 20:54:17 --> Model Class Initialized
INFO - 2016-03-01 20:54:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:54:17 --> Pagination Class Initialized
INFO - 2016-03-01 20:54:17 --> Helper loaded: text_helper
INFO - 2016-03-01 20:54:17 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 23:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 23:54:17 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:54:17 --> Final output sent to browser
DEBUG - 2016-03-01 23:54:17 --> Total execution time: 1.1743
INFO - 2016-03-01 20:54:35 --> Config Class Initialized
INFO - 2016-03-01 20:54:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 20:54:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 20:54:35 --> Utf8 Class Initialized
INFO - 2016-03-01 20:54:35 --> URI Class Initialized
INFO - 2016-03-01 20:54:35 --> Router Class Initialized
INFO - 2016-03-01 20:54:35 --> Output Class Initialized
INFO - 2016-03-01 20:54:35 --> Security Class Initialized
DEBUG - 2016-03-01 20:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 20:54:35 --> Input Class Initialized
INFO - 2016-03-01 20:54:35 --> Language Class Initialized
INFO - 2016-03-01 20:54:35 --> Loader Class Initialized
INFO - 2016-03-01 20:54:35 --> Helper loaded: url_helper
INFO - 2016-03-01 20:54:35 --> Helper loaded: file_helper
INFO - 2016-03-01 20:54:35 --> Helper loaded: date_helper
INFO - 2016-03-01 20:54:35 --> Helper loaded: form_helper
INFO - 2016-03-01 20:54:35 --> Database Driver Class Initialized
INFO - 2016-03-01 20:54:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 20:54:36 --> Controller Class Initialized
INFO - 2016-03-01 20:54:36 --> Model Class Initialized
INFO - 2016-03-01 20:54:36 --> Model Class Initialized
INFO - 2016-03-01 20:54:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 20:54:36 --> Pagination Class Initialized
INFO - 2016-03-01 20:54:36 --> Helper loaded: text_helper
INFO - 2016-03-01 20:54:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 23:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 23:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\head.php
INFO - 2016-03-01 23:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\get.php
INFO - 2016-03-01 23:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\main.php
INFO - 2016-03-01 23:54:36 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\footer.php
INFO - 2016-03-01 23:54:36 --> Final output sent to browser
DEBUG - 2016-03-01 23:54:36 --> Total execution time: 1.1986
INFO - 2016-03-01 21:05:42 --> Config Class Initialized
INFO - 2016-03-01 21:05:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:05:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:05:42 --> Utf8 Class Initialized
INFO - 2016-03-01 21:05:42 --> URI Class Initialized
DEBUG - 2016-03-01 21:05:42 --> No URI present. Default controller set.
INFO - 2016-03-01 21:05:42 --> Router Class Initialized
INFO - 2016-03-01 21:05:42 --> Output Class Initialized
INFO - 2016-03-01 21:05:42 --> Security Class Initialized
DEBUG - 2016-03-01 21:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:05:42 --> Input Class Initialized
INFO - 2016-03-01 21:05:42 --> Language Class Initialized
INFO - 2016-03-01 21:05:42 --> Loader Class Initialized
INFO - 2016-03-01 21:05:42 --> Helper loaded: url_helper
INFO - 2016-03-01 21:05:42 --> Helper loaded: file_helper
INFO - 2016-03-01 21:05:42 --> Helper loaded: date_helper
INFO - 2016-03-01 21:05:42 --> Helper loaded: form_helper
INFO - 2016-03-01 21:05:42 --> Database Driver Class Initialized
INFO - 2016-03-01 21:05:43 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:05:43 --> Controller Class Initialized
INFO - 2016-03-01 21:05:43 --> Model Class Initialized
INFO - 2016-03-01 21:05:43 --> Model Class Initialized
INFO - 2016-03-01 21:05:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:05:43 --> Pagination Class Initialized
INFO - 2016-03-01 21:05:43 --> Helper loaded: text_helper
INFO - 2016-03-01 21:05:43 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:06:00 --> Config Class Initialized
INFO - 2016-03-01 21:06:00 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:06:00 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:06:00 --> Utf8 Class Initialized
INFO - 2016-03-01 21:06:00 --> URI Class Initialized
DEBUG - 2016-03-01 21:06:00 --> No URI present. Default controller set.
INFO - 2016-03-01 21:06:00 --> Router Class Initialized
INFO - 2016-03-01 21:06:00 --> Output Class Initialized
INFO - 2016-03-01 21:06:00 --> Security Class Initialized
DEBUG - 2016-03-01 21:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:06:00 --> Input Class Initialized
INFO - 2016-03-01 21:06:00 --> Language Class Initialized
INFO - 2016-03-01 21:06:00 --> Loader Class Initialized
INFO - 2016-03-01 21:06:00 --> Helper loaded: url_helper
INFO - 2016-03-01 21:06:00 --> Helper loaded: file_helper
INFO - 2016-03-01 21:06:00 --> Helper loaded: date_helper
INFO - 2016-03-01 21:06:00 --> Helper loaded: form_helper
INFO - 2016-03-01 21:06:00 --> Database Driver Class Initialized
INFO - 2016-03-01 21:06:01 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:06:01 --> Controller Class Initialized
INFO - 2016-03-01 21:06:01 --> Model Class Initialized
INFO - 2016-03-01 21:06:01 --> Model Class Initialized
INFO - 2016-03-01 21:06:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:06:01 --> Pagination Class Initialized
INFO - 2016-03-01 21:06:01 --> Helper loaded: text_helper
INFO - 2016-03-01 21:06:01 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:09:23 --> Config Class Initialized
INFO - 2016-03-01 21:09:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:09:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:09:23 --> Utf8 Class Initialized
INFO - 2016-03-01 21:09:23 --> URI Class Initialized
INFO - 2016-03-01 21:09:23 --> Router Class Initialized
INFO - 2016-03-01 21:09:23 --> Output Class Initialized
INFO - 2016-03-01 21:09:23 --> Security Class Initialized
DEBUG - 2016-03-01 21:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:09:23 --> Input Class Initialized
INFO - 2016-03-01 21:09:23 --> Language Class Initialized
INFO - 2016-03-01 21:09:23 --> Loader Class Initialized
INFO - 2016-03-01 21:09:23 --> Helper loaded: url_helper
INFO - 2016-03-01 21:09:23 --> Helper loaded: file_helper
INFO - 2016-03-01 21:09:23 --> Helper loaded: date_helper
INFO - 2016-03-01 21:09:23 --> Helper loaded: form_helper
INFO - 2016-03-01 21:09:23 --> Database Driver Class Initialized
INFO - 2016-03-01 21:09:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:09:24 --> Controller Class Initialized
INFO - 2016-03-01 21:09:24 --> Model Class Initialized
INFO - 2016-03-01 21:09:24 --> Model Class Initialized
INFO - 2016-03-01 21:09:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:09:24 --> Pagination Class Initialized
INFO - 2016-03-01 21:09:24 --> Helper loaded: text_helper
INFO - 2016-03-01 21:09:24 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:17:36 --> Config Class Initialized
INFO - 2016-03-01 21:17:36 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:17:36 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:17:36 --> Utf8 Class Initialized
INFO - 2016-03-01 21:17:36 --> URI Class Initialized
INFO - 2016-03-01 21:17:36 --> Router Class Initialized
INFO - 2016-03-01 21:17:36 --> Output Class Initialized
INFO - 2016-03-01 21:17:36 --> Security Class Initialized
DEBUG - 2016-03-01 21:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:17:36 --> Input Class Initialized
INFO - 2016-03-01 21:17:36 --> Language Class Initialized
INFO - 2016-03-01 21:17:36 --> Loader Class Initialized
INFO - 2016-03-01 21:17:36 --> Helper loaded: url_helper
INFO - 2016-03-01 21:17:36 --> Helper loaded: file_helper
INFO - 2016-03-01 21:17:36 --> Helper loaded: date_helper
INFO - 2016-03-01 21:17:36 --> Helper loaded: form_helper
INFO - 2016-03-01 21:17:36 --> Database Driver Class Initialized
INFO - 2016-03-01 21:17:37 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:17:37 --> Controller Class Initialized
INFO - 2016-03-01 21:17:37 --> Model Class Initialized
INFO - 2016-03-01 21:17:37 --> Model Class Initialized
INFO - 2016-03-01 21:17:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:17:37 --> Pagination Class Initialized
INFO - 2016-03-01 21:17:37 --> Helper loaded: text_helper
INFO - 2016-03-01 21:17:37 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:19:46 --> Config Class Initialized
INFO - 2016-03-01 21:19:46 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:19:46 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:19:46 --> Utf8 Class Initialized
INFO - 2016-03-01 21:19:46 --> URI Class Initialized
DEBUG - 2016-03-01 21:19:46 --> No URI present. Default controller set.
INFO - 2016-03-01 21:19:46 --> Router Class Initialized
INFO - 2016-03-01 21:19:46 --> Output Class Initialized
INFO - 2016-03-01 21:19:46 --> Security Class Initialized
DEBUG - 2016-03-01 21:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:19:46 --> Input Class Initialized
INFO - 2016-03-01 21:19:46 --> Language Class Initialized
INFO - 2016-03-01 21:19:46 --> Loader Class Initialized
INFO - 2016-03-01 21:19:46 --> Helper loaded: url_helper
INFO - 2016-03-01 21:19:46 --> Helper loaded: file_helper
INFO - 2016-03-01 21:19:46 --> Helper loaded: date_helper
INFO - 2016-03-01 21:19:46 --> Helper loaded: form_helper
INFO - 2016-03-01 21:19:46 --> Database Driver Class Initialized
INFO - 2016-03-01 21:19:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:19:47 --> Controller Class Initialized
INFO - 2016-03-01 21:19:47 --> Model Class Initialized
INFO - 2016-03-01 21:19:47 --> Model Class Initialized
INFO - 2016-03-01 21:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:19:47 --> Pagination Class Initialized
INFO - 2016-03-01 21:19:47 --> Helper loaded: text_helper
INFO - 2016-03-01 21:19:47 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:23:22 --> Config Class Initialized
INFO - 2016-03-01 21:23:22 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:23:22 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:23:22 --> Utf8 Class Initialized
INFO - 2016-03-01 21:23:22 --> URI Class Initialized
INFO - 2016-03-01 21:23:22 --> Router Class Initialized
INFO - 2016-03-01 21:23:22 --> Output Class Initialized
INFO - 2016-03-01 21:23:22 --> Security Class Initialized
DEBUG - 2016-03-01 21:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:23:22 --> Input Class Initialized
INFO - 2016-03-01 21:23:22 --> Language Class Initialized
INFO - 2016-03-01 21:23:22 --> Loader Class Initialized
INFO - 2016-03-01 21:23:22 --> Helper loaded: url_helper
INFO - 2016-03-01 21:23:22 --> Helper loaded: file_helper
INFO - 2016-03-01 21:23:22 --> Helper loaded: date_helper
INFO - 2016-03-01 21:23:22 --> Helper loaded: form_helper
INFO - 2016-03-01 21:23:22 --> Database Driver Class Initialized
INFO - 2016-03-01 21:23:23 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:23:23 --> Controller Class Initialized
INFO - 2016-03-01 21:23:23 --> Model Class Initialized
INFO - 2016-03-01 21:23:23 --> Model Class Initialized
INFO - 2016-03-01 21:23:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:23:23 --> Pagination Class Initialized
INFO - 2016-03-01 21:23:23 --> Helper loaded: text_helper
INFO - 2016-03-01 21:23:23 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:24:57 --> Config Class Initialized
INFO - 2016-03-01 21:24:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:24:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:24:57 --> Utf8 Class Initialized
INFO - 2016-03-01 21:24:57 --> URI Class Initialized
INFO - 2016-03-01 21:24:57 --> Router Class Initialized
INFO - 2016-03-01 21:24:57 --> Output Class Initialized
INFO - 2016-03-01 21:24:57 --> Security Class Initialized
DEBUG - 2016-03-01 21:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:24:57 --> Input Class Initialized
INFO - 2016-03-01 21:24:57 --> Language Class Initialized
INFO - 2016-03-01 21:24:57 --> Loader Class Initialized
INFO - 2016-03-01 21:24:57 --> Helper loaded: url_helper
INFO - 2016-03-01 21:24:57 --> Helper loaded: file_helper
INFO - 2016-03-01 21:24:57 --> Helper loaded: date_helper
INFO - 2016-03-01 21:24:57 --> Helper loaded: form_helper
INFO - 2016-03-01 21:24:57 --> Database Driver Class Initialized
INFO - 2016-03-01 21:24:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:24:58 --> Controller Class Initialized
INFO - 2016-03-01 21:24:58 --> Model Class Initialized
INFO - 2016-03-01 21:24:58 --> Model Class Initialized
INFO - 2016-03-01 21:24:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:24:58 --> Pagination Class Initialized
INFO - 2016-03-01 21:24:58 --> Helper loaded: text_helper
INFO - 2016-03-01 21:24:58 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:31:28 --> Config Class Initialized
INFO - 2016-03-01 21:31:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:31:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:31:28 --> Utf8 Class Initialized
INFO - 2016-03-01 21:31:28 --> URI Class Initialized
INFO - 2016-03-01 21:31:28 --> Router Class Initialized
INFO - 2016-03-01 21:31:28 --> Output Class Initialized
INFO - 2016-03-01 21:31:28 --> Security Class Initialized
DEBUG - 2016-03-01 21:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:31:28 --> Input Class Initialized
INFO - 2016-03-01 21:31:28 --> Language Class Initialized
INFO - 2016-03-01 21:31:28 --> Loader Class Initialized
INFO - 2016-03-01 21:31:28 --> Helper loaded: url_helper
INFO - 2016-03-01 21:31:28 --> Helper loaded: file_helper
INFO - 2016-03-01 21:31:28 --> Helper loaded: date_helper
INFO - 2016-03-01 21:31:28 --> Helper loaded: form_helper
INFO - 2016-03-01 21:31:28 --> Database Driver Class Initialized
INFO - 2016-03-01 21:31:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:31:29 --> Controller Class Initialized
INFO - 2016-03-01 21:31:29 --> Model Class Initialized
INFO - 2016-03-01 21:31:29 --> Model Class Initialized
INFO - 2016-03-01 21:31:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:31:29 --> Pagination Class Initialized
INFO - 2016-03-01 21:31:29 --> Helper loaded: text_helper
INFO - 2016-03-01 21:31:29 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:32:16 --> Config Class Initialized
INFO - 2016-03-01 21:32:16 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:32:16 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:32:16 --> Utf8 Class Initialized
INFO - 2016-03-01 21:32:16 --> URI Class Initialized
INFO - 2016-03-01 21:32:16 --> Router Class Initialized
INFO - 2016-03-01 21:32:16 --> Output Class Initialized
INFO - 2016-03-01 21:32:16 --> Security Class Initialized
DEBUG - 2016-03-01 21:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:32:16 --> Input Class Initialized
INFO - 2016-03-01 21:32:16 --> Language Class Initialized
INFO - 2016-03-01 21:32:16 --> Loader Class Initialized
INFO - 2016-03-01 21:32:16 --> Helper loaded: url_helper
INFO - 2016-03-01 21:32:16 --> Helper loaded: file_helper
INFO - 2016-03-01 21:32:16 --> Helper loaded: date_helper
INFO - 2016-03-01 21:32:16 --> Helper loaded: form_helper
INFO - 2016-03-01 21:32:16 --> Database Driver Class Initialized
INFO - 2016-03-01 21:32:17 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:32:17 --> Controller Class Initialized
INFO - 2016-03-01 21:32:17 --> Model Class Initialized
INFO - 2016-03-01 21:32:17 --> Model Class Initialized
INFO - 2016-03-01 21:32:17 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:32:17 --> Pagination Class Initialized
INFO - 2016-03-01 21:32:17 --> Helper loaded: text_helper
INFO - 2016-03-01 21:32:17 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:32:55 --> Config Class Initialized
INFO - 2016-03-01 21:32:55 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:32:55 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:32:55 --> Utf8 Class Initialized
INFO - 2016-03-01 21:32:55 --> URI Class Initialized
INFO - 2016-03-01 21:32:55 --> Router Class Initialized
INFO - 2016-03-01 21:32:55 --> Output Class Initialized
INFO - 2016-03-01 21:32:55 --> Security Class Initialized
DEBUG - 2016-03-01 21:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:32:55 --> Input Class Initialized
INFO - 2016-03-01 21:32:55 --> Language Class Initialized
INFO - 2016-03-01 21:32:55 --> Loader Class Initialized
INFO - 2016-03-01 21:32:55 --> Helper loaded: url_helper
INFO - 2016-03-01 21:32:55 --> Helper loaded: file_helper
INFO - 2016-03-01 21:32:55 --> Helper loaded: date_helper
INFO - 2016-03-01 21:32:55 --> Helper loaded: form_helper
INFO - 2016-03-01 21:32:55 --> Database Driver Class Initialized
INFO - 2016-03-01 21:32:56 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:32:56 --> Controller Class Initialized
INFO - 2016-03-01 21:32:56 --> Model Class Initialized
INFO - 2016-03-01 21:32:56 --> Model Class Initialized
INFO - 2016-03-01 21:32:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:32:56 --> Pagination Class Initialized
INFO - 2016-03-01 21:32:56 --> Helper loaded: text_helper
INFO - 2016-03-01 21:32:56 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:35:19 --> Config Class Initialized
INFO - 2016-03-01 21:35:19 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:35:19 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:35:19 --> Utf8 Class Initialized
INFO - 2016-03-01 21:35:19 --> URI Class Initialized
DEBUG - 2016-03-01 21:35:19 --> No URI present. Default controller set.
INFO - 2016-03-01 21:35:19 --> Router Class Initialized
INFO - 2016-03-01 21:35:19 --> Output Class Initialized
INFO - 2016-03-01 21:35:19 --> Security Class Initialized
DEBUG - 2016-03-01 21:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:35:19 --> Input Class Initialized
INFO - 2016-03-01 21:35:19 --> Language Class Initialized
INFO - 2016-03-01 21:35:19 --> Loader Class Initialized
INFO - 2016-03-01 21:35:19 --> Helper loaded: url_helper
INFO - 2016-03-01 21:35:19 --> Helper loaded: file_helper
INFO - 2016-03-01 21:35:19 --> Helper loaded: date_helper
INFO - 2016-03-01 21:35:19 --> Helper loaded: form_helper
INFO - 2016-03-01 21:35:19 --> Database Driver Class Initialized
INFO - 2016-03-01 21:35:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:35:20 --> Controller Class Initialized
INFO - 2016-03-01 21:35:20 --> Model Class Initialized
INFO - 2016-03-01 21:35:20 --> Model Class Initialized
INFO - 2016-03-01 21:35:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:35:20 --> Pagination Class Initialized
INFO - 2016-03-01 21:35:20 --> Helper loaded: text_helper
INFO - 2016-03-01 21:35:20 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:35:23 --> Config Class Initialized
INFO - 2016-03-01 21:35:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:35:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:35:23 --> Utf8 Class Initialized
INFO - 2016-03-01 21:35:23 --> URI Class Initialized
INFO - 2016-03-01 21:35:23 --> Router Class Initialized
INFO - 2016-03-01 21:35:23 --> Output Class Initialized
INFO - 2016-03-01 21:35:23 --> Security Class Initialized
DEBUG - 2016-03-01 21:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:35:23 --> Input Class Initialized
INFO - 2016-03-01 21:35:23 --> Language Class Initialized
INFO - 2016-03-01 21:35:23 --> Loader Class Initialized
INFO - 2016-03-01 21:35:23 --> Helper loaded: url_helper
INFO - 2016-03-01 21:35:23 --> Helper loaded: file_helper
INFO - 2016-03-01 21:35:23 --> Helper loaded: date_helper
INFO - 2016-03-01 21:35:23 --> Helper loaded: form_helper
INFO - 2016-03-01 21:35:23 --> Database Driver Class Initialized
INFO - 2016-03-01 21:35:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:35:24 --> Controller Class Initialized
INFO - 2016-03-01 21:35:24 --> Model Class Initialized
INFO - 2016-03-01 21:35:24 --> Model Class Initialized
INFO - 2016-03-01 21:35:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:35:24 --> Pagination Class Initialized
INFO - 2016-03-01 21:35:24 --> Helper loaded: text_helper
INFO - 2016-03-01 21:35:24 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:36:37 --> Config Class Initialized
INFO - 2016-03-01 21:36:37 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:36:37 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:36:37 --> Utf8 Class Initialized
INFO - 2016-03-01 21:36:37 --> URI Class Initialized
INFO - 2016-03-01 21:36:37 --> Router Class Initialized
INFO - 2016-03-01 21:36:37 --> Output Class Initialized
INFO - 2016-03-01 21:36:37 --> Security Class Initialized
DEBUG - 2016-03-01 21:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:36:37 --> Input Class Initialized
INFO - 2016-03-01 21:36:37 --> Language Class Initialized
INFO - 2016-03-01 21:36:37 --> Loader Class Initialized
INFO - 2016-03-01 21:36:37 --> Helper loaded: url_helper
INFO - 2016-03-01 21:36:37 --> Helper loaded: file_helper
INFO - 2016-03-01 21:36:37 --> Helper loaded: date_helper
INFO - 2016-03-01 21:36:37 --> Helper loaded: form_helper
INFO - 2016-03-01 21:36:37 --> Database Driver Class Initialized
INFO - 2016-03-01 21:36:39 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:36:39 --> Controller Class Initialized
INFO - 2016-03-01 21:36:39 --> Model Class Initialized
INFO - 2016-03-01 21:36:39 --> Model Class Initialized
INFO - 2016-03-01 21:36:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:36:39 --> Pagination Class Initialized
INFO - 2016-03-01 21:36:39 --> Helper loaded: text_helper
INFO - 2016-03-01 21:36:39 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:37:56 --> Config Class Initialized
INFO - 2016-03-01 21:37:56 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:37:56 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:37:56 --> Utf8 Class Initialized
INFO - 2016-03-01 21:37:56 --> URI Class Initialized
INFO - 2016-03-01 21:37:56 --> Router Class Initialized
INFO - 2016-03-01 21:37:56 --> Output Class Initialized
INFO - 2016-03-01 21:37:56 --> Security Class Initialized
DEBUG - 2016-03-01 21:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:37:56 --> Input Class Initialized
INFO - 2016-03-01 21:37:56 --> Language Class Initialized
INFO - 2016-03-01 21:37:56 --> Loader Class Initialized
INFO - 2016-03-01 21:37:56 --> Helper loaded: url_helper
INFO - 2016-03-01 21:37:56 --> Helper loaded: file_helper
INFO - 2016-03-01 21:37:56 --> Helper loaded: date_helper
INFO - 2016-03-01 21:37:56 --> Helper loaded: form_helper
INFO - 2016-03-01 21:37:56 --> Database Driver Class Initialized
INFO - 2016-03-01 21:37:57 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:37:57 --> Controller Class Initialized
INFO - 2016-03-01 21:37:57 --> Model Class Initialized
INFO - 2016-03-01 21:37:57 --> Model Class Initialized
INFO - 2016-03-01 21:37:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:37:57 --> Pagination Class Initialized
INFO - 2016-03-01 21:37:57 --> Helper loaded: text_helper
INFO - 2016-03-01 21:37:57 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:38:19 --> Config Class Initialized
INFO - 2016-03-01 21:38:19 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:38:19 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:38:19 --> Utf8 Class Initialized
INFO - 2016-03-01 21:38:19 --> URI Class Initialized
INFO - 2016-03-01 21:38:19 --> Router Class Initialized
INFO - 2016-03-01 21:38:19 --> Output Class Initialized
INFO - 2016-03-01 21:38:19 --> Security Class Initialized
DEBUG - 2016-03-01 21:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:38:19 --> Input Class Initialized
INFO - 2016-03-01 21:38:19 --> Language Class Initialized
INFO - 2016-03-01 21:38:19 --> Loader Class Initialized
INFO - 2016-03-01 21:38:19 --> Helper loaded: url_helper
INFO - 2016-03-01 21:38:19 --> Helper loaded: file_helper
INFO - 2016-03-01 21:38:19 --> Helper loaded: date_helper
INFO - 2016-03-01 21:38:19 --> Helper loaded: form_helper
INFO - 2016-03-01 21:38:19 --> Database Driver Class Initialized
INFO - 2016-03-01 21:38:20 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:38:20 --> Controller Class Initialized
INFO - 2016-03-01 21:38:20 --> Model Class Initialized
INFO - 2016-03-01 21:38:20 --> Model Class Initialized
INFO - 2016-03-01 21:38:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:38:20 --> Pagination Class Initialized
INFO - 2016-03-01 21:38:20 --> Helper loaded: text_helper
INFO - 2016-03-01 21:38:20 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:39:09 --> Config Class Initialized
INFO - 2016-03-01 21:39:09 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:39:09 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:39:09 --> Utf8 Class Initialized
INFO - 2016-03-01 21:39:09 --> URI Class Initialized
INFO - 2016-03-01 21:39:09 --> Router Class Initialized
INFO - 2016-03-01 21:39:09 --> Output Class Initialized
INFO - 2016-03-01 21:39:09 --> Security Class Initialized
DEBUG - 2016-03-01 21:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:39:09 --> Input Class Initialized
INFO - 2016-03-01 21:39:09 --> Language Class Initialized
INFO - 2016-03-01 21:39:09 --> Loader Class Initialized
INFO - 2016-03-01 21:39:09 --> Helper loaded: url_helper
INFO - 2016-03-01 21:39:09 --> Helper loaded: file_helper
INFO - 2016-03-01 21:39:09 --> Helper loaded: date_helper
INFO - 2016-03-01 21:39:09 --> Helper loaded: form_helper
INFO - 2016-03-01 21:39:09 --> Database Driver Class Initialized
INFO - 2016-03-01 21:39:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:39:10 --> Controller Class Initialized
INFO - 2016-03-01 21:39:10 --> Model Class Initialized
INFO - 2016-03-01 21:39:10 --> Model Class Initialized
INFO - 2016-03-01 21:39:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:39:10 --> Pagination Class Initialized
INFO - 2016-03-01 21:39:10 --> Helper loaded: text_helper
INFO - 2016-03-01 21:39:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:39:13 --> Config Class Initialized
INFO - 2016-03-01 21:39:13 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:39:13 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:39:13 --> Utf8 Class Initialized
INFO - 2016-03-01 21:39:13 --> URI Class Initialized
INFO - 2016-03-01 21:39:13 --> Router Class Initialized
INFO - 2016-03-01 21:39:13 --> Output Class Initialized
INFO - 2016-03-01 21:39:13 --> Security Class Initialized
DEBUG - 2016-03-01 21:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:39:13 --> Input Class Initialized
INFO - 2016-03-01 21:39:13 --> Language Class Initialized
INFO - 2016-03-01 21:39:13 --> Loader Class Initialized
INFO - 2016-03-01 21:39:13 --> Helper loaded: url_helper
INFO - 2016-03-01 21:39:13 --> Helper loaded: file_helper
INFO - 2016-03-01 21:39:13 --> Helper loaded: date_helper
INFO - 2016-03-01 21:39:13 --> Helper loaded: form_helper
INFO - 2016-03-01 21:39:13 --> Database Driver Class Initialized
INFO - 2016-03-01 21:39:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:39:14 --> Controller Class Initialized
INFO - 2016-03-01 21:39:14 --> Model Class Initialized
INFO - 2016-03-01 21:39:14 --> Model Class Initialized
INFO - 2016-03-01 21:39:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:39:14 --> Pagination Class Initialized
INFO - 2016-03-01 21:39:14 --> Helper loaded: text_helper
INFO - 2016-03-01 21:39:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:40:13 --> Config Class Initialized
INFO - 2016-03-01 21:40:13 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:40:13 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:40:13 --> Utf8 Class Initialized
INFO - 2016-03-01 21:40:13 --> URI Class Initialized
INFO - 2016-03-01 21:40:13 --> Router Class Initialized
INFO - 2016-03-01 21:40:13 --> Output Class Initialized
INFO - 2016-03-01 21:40:13 --> Security Class Initialized
DEBUG - 2016-03-01 21:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:40:13 --> Input Class Initialized
INFO - 2016-03-01 21:40:13 --> Language Class Initialized
INFO - 2016-03-01 21:40:13 --> Loader Class Initialized
INFO - 2016-03-01 21:40:13 --> Helper loaded: url_helper
INFO - 2016-03-01 21:40:13 --> Helper loaded: file_helper
INFO - 2016-03-01 21:40:13 --> Helper loaded: date_helper
INFO - 2016-03-01 21:40:13 --> Helper loaded: form_helper
INFO - 2016-03-01 21:40:13 --> Database Driver Class Initialized
INFO - 2016-03-01 21:40:14 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:40:14 --> Controller Class Initialized
INFO - 2016-03-01 21:40:14 --> Model Class Initialized
INFO - 2016-03-01 21:40:14 --> Model Class Initialized
INFO - 2016-03-01 21:40:14 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:40:14 --> Pagination Class Initialized
INFO - 2016-03-01 21:40:14 --> Helper loaded: text_helper
INFO - 2016-03-01 21:40:14 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:41:06 --> Config Class Initialized
INFO - 2016-03-01 21:41:06 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:41:06 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:41:06 --> Utf8 Class Initialized
INFO - 2016-03-01 21:41:06 --> URI Class Initialized
INFO - 2016-03-01 21:41:06 --> Router Class Initialized
INFO - 2016-03-01 21:41:06 --> Output Class Initialized
INFO - 2016-03-01 21:41:06 --> Security Class Initialized
DEBUG - 2016-03-01 21:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:41:06 --> Input Class Initialized
INFO - 2016-03-01 21:41:06 --> Language Class Initialized
INFO - 2016-03-01 21:41:06 --> Loader Class Initialized
INFO - 2016-03-01 21:41:06 --> Helper loaded: url_helper
INFO - 2016-03-01 21:41:06 --> Helper loaded: file_helper
INFO - 2016-03-01 21:41:06 --> Helper loaded: date_helper
INFO - 2016-03-01 21:41:06 --> Helper loaded: form_helper
INFO - 2016-03-01 21:41:06 --> Database Driver Class Initialized
INFO - 2016-03-01 21:41:07 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:41:07 --> Controller Class Initialized
INFO - 2016-03-01 21:41:07 --> Model Class Initialized
INFO - 2016-03-01 21:41:07 --> Model Class Initialized
INFO - 2016-03-01 21:41:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:41:07 --> Pagination Class Initialized
INFO - 2016-03-01 21:41:07 --> Helper loaded: text_helper
INFO - 2016-03-01 21:41:07 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:41:54 --> Config Class Initialized
INFO - 2016-03-01 21:41:54 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:41:54 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:41:54 --> Utf8 Class Initialized
INFO - 2016-03-01 21:41:54 --> URI Class Initialized
INFO - 2016-03-01 21:41:54 --> Router Class Initialized
INFO - 2016-03-01 21:41:54 --> Output Class Initialized
INFO - 2016-03-01 21:41:54 --> Security Class Initialized
DEBUG - 2016-03-01 21:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:41:54 --> Input Class Initialized
INFO - 2016-03-01 21:41:54 --> Language Class Initialized
INFO - 2016-03-01 21:41:54 --> Loader Class Initialized
INFO - 2016-03-01 21:41:54 --> Helper loaded: url_helper
INFO - 2016-03-01 21:41:54 --> Helper loaded: file_helper
INFO - 2016-03-01 21:41:54 --> Helper loaded: date_helper
INFO - 2016-03-01 21:41:54 --> Helper loaded: form_helper
INFO - 2016-03-01 21:41:54 --> Database Driver Class Initialized
INFO - 2016-03-01 21:41:55 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:41:55 --> Controller Class Initialized
INFO - 2016-03-01 21:41:55 --> Model Class Initialized
INFO - 2016-03-01 21:41:55 --> Model Class Initialized
INFO - 2016-03-01 21:41:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:41:55 --> Pagination Class Initialized
INFO - 2016-03-01 21:41:55 --> Helper loaded: text_helper
INFO - 2016-03-01 21:41:55 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:42:33 --> Config Class Initialized
INFO - 2016-03-01 21:42:33 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:42:33 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:42:33 --> Utf8 Class Initialized
INFO - 2016-03-01 21:42:33 --> URI Class Initialized
INFO - 2016-03-01 21:42:33 --> Router Class Initialized
INFO - 2016-03-01 21:42:33 --> Output Class Initialized
INFO - 2016-03-01 21:42:33 --> Security Class Initialized
DEBUG - 2016-03-01 21:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:42:33 --> Input Class Initialized
INFO - 2016-03-01 21:42:33 --> Language Class Initialized
INFO - 2016-03-01 21:42:33 --> Loader Class Initialized
INFO - 2016-03-01 21:42:33 --> Helper loaded: url_helper
INFO - 2016-03-01 21:42:33 --> Helper loaded: file_helper
INFO - 2016-03-01 21:42:33 --> Helper loaded: date_helper
INFO - 2016-03-01 21:42:33 --> Helper loaded: form_helper
INFO - 2016-03-01 21:42:33 --> Database Driver Class Initialized
INFO - 2016-03-01 21:42:34 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:42:34 --> Controller Class Initialized
INFO - 2016-03-01 21:42:34 --> Model Class Initialized
INFO - 2016-03-01 21:42:34 --> Model Class Initialized
INFO - 2016-03-01 21:42:34 --> Form Validation Class Initialized
INFO - 2016-03-01 21:42:34 --> Helper loaded: text_helper
INFO - 2016-03-01 21:42:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\top.php
INFO - 2016-03-01 21:42:34 --> File loaded: C:\Bitnami\wampstack-5.5.28-0\apache2\htdocs\application\views\register.php
INFO - 2016-03-01 21:42:34 --> Final output sent to browser
DEBUG - 2016-03-01 21:42:34 --> Total execution time: 1.1441
INFO - 2016-03-01 21:42:35 --> Config Class Initialized
INFO - 2016-03-01 21:42:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:42:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:42:35 --> Utf8 Class Initialized
INFO - 2016-03-01 21:42:35 --> URI Class Initialized
INFO - 2016-03-01 21:42:35 --> Router Class Initialized
INFO - 2016-03-01 21:42:35 --> Output Class Initialized
INFO - 2016-03-01 21:42:35 --> Security Class Initialized
DEBUG - 2016-03-01 21:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:42:35 --> Input Class Initialized
INFO - 2016-03-01 21:42:35 --> Language Class Initialized
INFO - 2016-03-01 21:42:35 --> Loader Class Initialized
INFO - 2016-03-01 21:42:35 --> Helper loaded: url_helper
INFO - 2016-03-01 21:42:35 --> Helper loaded: file_helper
INFO - 2016-03-01 21:42:35 --> Helper loaded: date_helper
INFO - 2016-03-01 21:42:35 --> Helper loaded: form_helper
INFO - 2016-03-01 21:42:35 --> Database Driver Class Initialized
INFO - 2016-03-01 21:42:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:42:36 --> Controller Class Initialized
INFO - 2016-03-01 21:42:36 --> Model Class Initialized
INFO - 2016-03-01 21:42:36 --> Model Class Initialized
INFO - 2016-03-01 21:42:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:42:36 --> Pagination Class Initialized
INFO - 2016-03-01 21:42:36 --> Helper loaded: text_helper
INFO - 2016-03-01 21:42:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:42:51 --> Config Class Initialized
INFO - 2016-03-01 21:42:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:42:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:42:51 --> Utf8 Class Initialized
INFO - 2016-03-01 21:42:51 --> URI Class Initialized
INFO - 2016-03-01 21:42:51 --> Router Class Initialized
INFO - 2016-03-01 21:42:51 --> Output Class Initialized
INFO - 2016-03-01 21:42:51 --> Security Class Initialized
DEBUG - 2016-03-01 21:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:42:51 --> Input Class Initialized
INFO - 2016-03-01 21:42:51 --> Language Class Initialized
INFO - 2016-03-01 21:42:51 --> Loader Class Initialized
INFO - 2016-03-01 21:42:51 --> Helper loaded: url_helper
INFO - 2016-03-01 21:42:51 --> Helper loaded: file_helper
INFO - 2016-03-01 21:42:51 --> Helper loaded: date_helper
INFO - 2016-03-01 21:42:51 --> Helper loaded: form_helper
INFO - 2016-03-01 21:42:51 --> Database Driver Class Initialized
INFO - 2016-03-01 21:42:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:42:52 --> Controller Class Initialized
INFO - 2016-03-01 21:42:52 --> Model Class Initialized
INFO - 2016-03-01 21:42:52 --> Model Class Initialized
INFO - 2016-03-01 21:42:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:42:52 --> Pagination Class Initialized
INFO - 2016-03-01 21:42:52 --> Helper loaded: text_helper
INFO - 2016-03-01 21:42:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:43:51 --> Config Class Initialized
INFO - 2016-03-01 21:43:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:43:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:43:51 --> Utf8 Class Initialized
INFO - 2016-03-01 21:43:51 --> URI Class Initialized
INFO - 2016-03-01 21:43:51 --> Router Class Initialized
INFO - 2016-03-01 21:43:51 --> Output Class Initialized
INFO - 2016-03-01 21:43:51 --> Security Class Initialized
DEBUG - 2016-03-01 21:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:43:51 --> Input Class Initialized
INFO - 2016-03-01 21:43:51 --> Language Class Initialized
INFO - 2016-03-01 21:43:51 --> Loader Class Initialized
INFO - 2016-03-01 21:43:51 --> Helper loaded: url_helper
INFO - 2016-03-01 21:43:51 --> Helper loaded: file_helper
INFO - 2016-03-01 21:43:51 --> Helper loaded: date_helper
INFO - 2016-03-01 21:43:51 --> Helper loaded: form_helper
INFO - 2016-03-01 21:43:51 --> Database Driver Class Initialized
INFO - 2016-03-01 21:43:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:43:52 --> Controller Class Initialized
INFO - 2016-03-01 21:43:52 --> Model Class Initialized
INFO - 2016-03-01 21:43:52 --> Model Class Initialized
INFO - 2016-03-01 21:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:43:52 --> Pagination Class Initialized
INFO - 2016-03-01 21:43:52 --> Helper loaded: text_helper
INFO - 2016-03-01 21:43:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:44:29 --> Config Class Initialized
INFO - 2016-03-01 21:44:29 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:44:29 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:44:29 --> Utf8 Class Initialized
INFO - 2016-03-01 21:44:29 --> URI Class Initialized
INFO - 2016-03-01 21:44:29 --> Router Class Initialized
INFO - 2016-03-01 21:44:29 --> Output Class Initialized
INFO - 2016-03-01 21:44:29 --> Security Class Initialized
DEBUG - 2016-03-01 21:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:44:29 --> Input Class Initialized
INFO - 2016-03-01 21:44:29 --> Language Class Initialized
INFO - 2016-03-01 21:44:29 --> Loader Class Initialized
INFO - 2016-03-01 21:44:29 --> Helper loaded: url_helper
INFO - 2016-03-01 21:44:29 --> Helper loaded: file_helper
INFO - 2016-03-01 21:44:29 --> Helper loaded: date_helper
INFO - 2016-03-01 21:44:29 --> Helper loaded: form_helper
INFO - 2016-03-01 21:44:29 --> Database Driver Class Initialized
INFO - 2016-03-01 21:44:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:44:30 --> Controller Class Initialized
INFO - 2016-03-01 21:44:30 --> Model Class Initialized
INFO - 2016-03-01 21:44:30 --> Model Class Initialized
INFO - 2016-03-01 21:44:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:44:31 --> Pagination Class Initialized
INFO - 2016-03-01 21:44:31 --> Helper loaded: text_helper
INFO - 2016-03-01 21:44:31 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:44:59 --> Config Class Initialized
INFO - 2016-03-01 21:44:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:44:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:44:59 --> Utf8 Class Initialized
INFO - 2016-03-01 21:44:59 --> URI Class Initialized
INFO - 2016-03-01 21:44:59 --> Router Class Initialized
INFO - 2016-03-01 21:44:59 --> Output Class Initialized
INFO - 2016-03-01 21:44:59 --> Security Class Initialized
DEBUG - 2016-03-01 21:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:44:59 --> Input Class Initialized
INFO - 2016-03-01 21:44:59 --> Language Class Initialized
INFO - 2016-03-01 21:44:59 --> Loader Class Initialized
INFO - 2016-03-01 21:44:59 --> Helper loaded: url_helper
INFO - 2016-03-01 21:44:59 --> Helper loaded: file_helper
INFO - 2016-03-01 21:44:59 --> Helper loaded: date_helper
INFO - 2016-03-01 21:44:59 --> Helper loaded: form_helper
INFO - 2016-03-01 21:44:59 --> Database Driver Class Initialized
INFO - 2016-03-01 21:45:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:45:00 --> Controller Class Initialized
INFO - 2016-03-01 21:45:00 --> Model Class Initialized
INFO - 2016-03-01 21:45:00 --> Model Class Initialized
INFO - 2016-03-01 21:45:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:45:00 --> Pagination Class Initialized
INFO - 2016-03-01 21:45:00 --> Helper loaded: text_helper
INFO - 2016-03-01 21:45:00 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:45:24 --> Config Class Initialized
INFO - 2016-03-01 21:45:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:45:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:45:24 --> Utf8 Class Initialized
INFO - 2016-03-01 21:45:24 --> URI Class Initialized
INFO - 2016-03-01 21:45:24 --> Router Class Initialized
INFO - 2016-03-01 21:45:24 --> Output Class Initialized
INFO - 2016-03-01 21:45:24 --> Security Class Initialized
DEBUG - 2016-03-01 21:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:45:24 --> Input Class Initialized
INFO - 2016-03-01 21:45:24 --> Language Class Initialized
INFO - 2016-03-01 21:45:24 --> Loader Class Initialized
INFO - 2016-03-01 21:45:24 --> Helper loaded: url_helper
INFO - 2016-03-01 21:45:24 --> Helper loaded: file_helper
INFO - 2016-03-01 21:45:24 --> Helper loaded: date_helper
INFO - 2016-03-01 21:45:24 --> Helper loaded: form_helper
INFO - 2016-03-01 21:45:24 --> Database Driver Class Initialized
INFO - 2016-03-01 21:45:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:45:25 --> Controller Class Initialized
INFO - 2016-03-01 21:45:25 --> Model Class Initialized
INFO - 2016-03-01 21:45:25 --> Model Class Initialized
INFO - 2016-03-01 21:45:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:45:25 --> Pagination Class Initialized
INFO - 2016-03-01 21:45:25 --> Helper loaded: text_helper
INFO - 2016-03-01 21:45:25 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:46:20 --> Config Class Initialized
INFO - 2016-03-01 21:46:20 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:46:20 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:46:20 --> Utf8 Class Initialized
INFO - 2016-03-01 21:46:20 --> URI Class Initialized
DEBUG - 2016-03-01 21:46:20 --> No URI present. Default controller set.
INFO - 2016-03-01 21:46:20 --> Router Class Initialized
INFO - 2016-03-01 21:46:20 --> Output Class Initialized
INFO - 2016-03-01 21:46:20 --> Security Class Initialized
DEBUG - 2016-03-01 21:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:46:20 --> Input Class Initialized
INFO - 2016-03-01 21:46:20 --> Language Class Initialized
INFO - 2016-03-01 21:46:20 --> Loader Class Initialized
INFO - 2016-03-01 21:46:20 --> Helper loaded: url_helper
INFO - 2016-03-01 21:46:20 --> Helper loaded: file_helper
INFO - 2016-03-01 21:46:20 --> Helper loaded: date_helper
INFO - 2016-03-01 21:46:20 --> Helper loaded: form_helper
INFO - 2016-03-01 21:46:20 --> Database Driver Class Initialized
INFO - 2016-03-01 21:46:21 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:46:21 --> Controller Class Initialized
INFO - 2016-03-01 21:46:21 --> Model Class Initialized
INFO - 2016-03-01 21:46:21 --> Model Class Initialized
INFO - 2016-03-01 21:46:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:46:21 --> Pagination Class Initialized
INFO - 2016-03-01 21:46:21 --> Helper loaded: text_helper
INFO - 2016-03-01 21:46:21 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:49:46 --> Config Class Initialized
INFO - 2016-03-01 21:49:46 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:49:46 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:49:46 --> Utf8 Class Initialized
INFO - 2016-03-01 21:49:46 --> URI Class Initialized
DEBUG - 2016-03-01 21:49:46 --> No URI present. Default controller set.
INFO - 2016-03-01 21:49:46 --> Router Class Initialized
INFO - 2016-03-01 21:49:46 --> Output Class Initialized
INFO - 2016-03-01 21:49:46 --> Security Class Initialized
DEBUG - 2016-03-01 21:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:49:46 --> Input Class Initialized
INFO - 2016-03-01 21:49:46 --> Language Class Initialized
INFO - 2016-03-01 21:49:46 --> Loader Class Initialized
INFO - 2016-03-01 21:49:46 --> Helper loaded: url_helper
INFO - 2016-03-01 21:49:46 --> Helper loaded: file_helper
INFO - 2016-03-01 21:49:46 --> Helper loaded: date_helper
INFO - 2016-03-01 21:49:46 --> Helper loaded: form_helper
INFO - 2016-03-01 21:49:46 --> Database Driver Class Initialized
INFO - 2016-03-01 21:49:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:49:47 --> Controller Class Initialized
INFO - 2016-03-01 21:49:47 --> Model Class Initialized
INFO - 2016-03-01 21:49:47 --> Model Class Initialized
INFO - 2016-03-01 21:49:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:49:47 --> Pagination Class Initialized
INFO - 2016-03-01 21:49:47 --> Helper loaded: text_helper
INFO - 2016-03-01 21:49:47 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:59:43 --> Config Class Initialized
INFO - 2016-03-01 21:59:43 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:59:43 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:59:43 --> Utf8 Class Initialized
INFO - 2016-03-01 21:59:43 --> URI Class Initialized
INFO - 2016-03-01 21:59:43 --> Router Class Initialized
INFO - 2016-03-01 21:59:43 --> Output Class Initialized
INFO - 2016-03-01 21:59:43 --> Security Class Initialized
DEBUG - 2016-03-01 21:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:59:43 --> Input Class Initialized
INFO - 2016-03-01 21:59:43 --> Language Class Initialized
INFO - 2016-03-01 21:59:43 --> Loader Class Initialized
INFO - 2016-03-01 21:59:43 --> Helper loaded: url_helper
INFO - 2016-03-01 21:59:43 --> Helper loaded: file_helper
INFO - 2016-03-01 21:59:43 --> Helper loaded: date_helper
INFO - 2016-03-01 21:59:43 --> Helper loaded: form_helper
INFO - 2016-03-01 21:59:43 --> Database Driver Class Initialized
INFO - 2016-03-01 21:59:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:59:44 --> Controller Class Initialized
INFO - 2016-03-01 21:59:44 --> Model Class Initialized
INFO - 2016-03-01 21:59:44 --> Model Class Initialized
INFO - 2016-03-01 21:59:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:59:44 --> Pagination Class Initialized
INFO - 2016-03-01 21:59:44 --> Helper loaded: text_helper
INFO - 2016-03-01 21:59:44 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:59:47 --> Config Class Initialized
INFO - 2016-03-01 21:59:47 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:59:47 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:59:47 --> Utf8 Class Initialized
INFO - 2016-03-01 21:59:47 --> URI Class Initialized
INFO - 2016-03-01 21:59:47 --> Router Class Initialized
INFO - 2016-03-01 21:59:47 --> Output Class Initialized
INFO - 2016-03-01 21:59:47 --> Security Class Initialized
DEBUG - 2016-03-01 21:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:59:47 --> Input Class Initialized
INFO - 2016-03-01 21:59:47 --> Language Class Initialized
INFO - 2016-03-01 21:59:47 --> Loader Class Initialized
INFO - 2016-03-01 21:59:47 --> Helper loaded: url_helper
INFO - 2016-03-01 21:59:47 --> Helper loaded: file_helper
INFO - 2016-03-01 21:59:47 --> Helper loaded: date_helper
INFO - 2016-03-01 21:59:47 --> Helper loaded: form_helper
INFO - 2016-03-01 21:59:47 --> Database Driver Class Initialized
INFO - 2016-03-01 21:59:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:59:48 --> Controller Class Initialized
INFO - 2016-03-01 21:59:48 --> Model Class Initialized
INFO - 2016-03-01 21:59:48 --> Model Class Initialized
INFO - 2016-03-01 21:59:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:59:48 --> Pagination Class Initialized
INFO - 2016-03-01 21:59:48 --> Helper loaded: text_helper
INFO - 2016-03-01 21:59:48 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:59:50 --> Config Class Initialized
INFO - 2016-03-01 21:59:50 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:59:50 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:59:50 --> Utf8 Class Initialized
INFO - 2016-03-01 21:59:50 --> URI Class Initialized
INFO - 2016-03-01 21:59:50 --> Router Class Initialized
INFO - 2016-03-01 21:59:50 --> Output Class Initialized
INFO - 2016-03-01 21:59:50 --> Security Class Initialized
DEBUG - 2016-03-01 21:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:59:50 --> Input Class Initialized
INFO - 2016-03-01 21:59:50 --> Language Class Initialized
INFO - 2016-03-01 21:59:50 --> Loader Class Initialized
INFO - 2016-03-01 21:59:50 --> Helper loaded: url_helper
INFO - 2016-03-01 21:59:50 --> Helper loaded: file_helper
INFO - 2016-03-01 21:59:50 --> Helper loaded: date_helper
INFO - 2016-03-01 21:59:50 --> Helper loaded: form_helper
INFO - 2016-03-01 21:59:50 --> Database Driver Class Initialized
INFO - 2016-03-01 21:59:51 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:59:51 --> Controller Class Initialized
INFO - 2016-03-01 21:59:51 --> Model Class Initialized
INFO - 2016-03-01 21:59:51 --> Model Class Initialized
INFO - 2016-03-01 21:59:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:59:51 --> Pagination Class Initialized
INFO - 2016-03-01 21:59:51 --> Helper loaded: text_helper
INFO - 2016-03-01 21:59:51 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:59:53 --> Config Class Initialized
INFO - 2016-03-01 21:59:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:59:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:59:53 --> Utf8 Class Initialized
INFO - 2016-03-01 21:59:53 --> URI Class Initialized
INFO - 2016-03-01 21:59:53 --> Router Class Initialized
INFO - 2016-03-01 21:59:53 --> Output Class Initialized
INFO - 2016-03-01 21:59:53 --> Security Class Initialized
DEBUG - 2016-03-01 21:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:59:53 --> Input Class Initialized
INFO - 2016-03-01 21:59:53 --> Language Class Initialized
INFO - 2016-03-01 21:59:53 --> Loader Class Initialized
INFO - 2016-03-01 21:59:53 --> Helper loaded: url_helper
INFO - 2016-03-01 21:59:53 --> Helper loaded: file_helper
INFO - 2016-03-01 21:59:53 --> Helper loaded: date_helper
INFO - 2016-03-01 21:59:53 --> Helper loaded: form_helper
INFO - 2016-03-01 21:59:53 --> Database Driver Class Initialized
INFO - 2016-03-01 21:59:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:59:54 --> Controller Class Initialized
INFO - 2016-03-01 21:59:54 --> Model Class Initialized
INFO - 2016-03-01 21:59:54 --> Model Class Initialized
INFO - 2016-03-01 21:59:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:59:54 --> Pagination Class Initialized
INFO - 2016-03-01 21:59:54 --> Helper loaded: text_helper
INFO - 2016-03-01 21:59:54 --> Helper loaded: cookie_helper
INFO - 2016-03-01 21:59:58 --> Config Class Initialized
INFO - 2016-03-01 21:59:58 --> Hooks Class Initialized
DEBUG - 2016-03-01 21:59:58 --> UTF-8 Support Enabled
INFO - 2016-03-01 21:59:58 --> Utf8 Class Initialized
INFO - 2016-03-01 21:59:58 --> URI Class Initialized
INFO - 2016-03-01 21:59:58 --> Router Class Initialized
INFO - 2016-03-01 21:59:58 --> Output Class Initialized
INFO - 2016-03-01 21:59:58 --> Security Class Initialized
DEBUG - 2016-03-01 21:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 21:59:58 --> Input Class Initialized
INFO - 2016-03-01 21:59:58 --> Language Class Initialized
INFO - 2016-03-01 21:59:58 --> Loader Class Initialized
INFO - 2016-03-01 21:59:58 --> Helper loaded: url_helper
INFO - 2016-03-01 21:59:58 --> Helper loaded: file_helper
INFO - 2016-03-01 21:59:58 --> Helper loaded: date_helper
INFO - 2016-03-01 21:59:58 --> Helper loaded: form_helper
INFO - 2016-03-01 21:59:58 --> Database Driver Class Initialized
INFO - 2016-03-01 21:59:59 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 21:59:59 --> Controller Class Initialized
INFO - 2016-03-01 21:59:59 --> Model Class Initialized
INFO - 2016-03-01 21:59:59 --> Model Class Initialized
INFO - 2016-03-01 21:59:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 21:59:59 --> Pagination Class Initialized
INFO - 2016-03-01 21:59:59 --> Helper loaded: text_helper
INFO - 2016-03-01 21:59:59 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:00:01 --> Config Class Initialized
INFO - 2016-03-01 22:00:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:00:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:00:01 --> Utf8 Class Initialized
INFO - 2016-03-01 22:00:01 --> URI Class Initialized
INFO - 2016-03-01 22:00:01 --> Router Class Initialized
INFO - 2016-03-01 22:00:01 --> Output Class Initialized
INFO - 2016-03-01 22:00:01 --> Security Class Initialized
DEBUG - 2016-03-01 22:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:00:01 --> Input Class Initialized
INFO - 2016-03-01 22:00:01 --> Language Class Initialized
INFO - 2016-03-01 22:00:01 --> Loader Class Initialized
INFO - 2016-03-01 22:00:01 --> Helper loaded: url_helper
INFO - 2016-03-01 22:00:01 --> Helper loaded: file_helper
INFO - 2016-03-01 22:00:01 --> Helper loaded: date_helper
INFO - 2016-03-01 22:00:01 --> Helper loaded: form_helper
INFO - 2016-03-01 22:00:01 --> Database Driver Class Initialized
INFO - 2016-03-01 22:00:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:00:02 --> Controller Class Initialized
INFO - 2016-03-01 22:00:02 --> Model Class Initialized
INFO - 2016-03-01 22:00:02 --> Model Class Initialized
INFO - 2016-03-01 22:00:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:00:02 --> Pagination Class Initialized
INFO - 2016-03-01 22:00:02 --> Helper loaded: text_helper
INFO - 2016-03-01 22:00:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:03:35 --> Config Class Initialized
INFO - 2016-03-01 22:03:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:03:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:03:35 --> Utf8 Class Initialized
INFO - 2016-03-01 22:03:35 --> URI Class Initialized
INFO - 2016-03-01 22:03:35 --> Router Class Initialized
INFO - 2016-03-01 22:03:35 --> Output Class Initialized
INFO - 2016-03-01 22:03:35 --> Security Class Initialized
DEBUG - 2016-03-01 22:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:03:35 --> Input Class Initialized
INFO - 2016-03-01 22:03:35 --> Language Class Initialized
INFO - 2016-03-01 22:03:35 --> Loader Class Initialized
INFO - 2016-03-01 22:03:35 --> Helper loaded: url_helper
INFO - 2016-03-01 22:03:35 --> Helper loaded: file_helper
INFO - 2016-03-01 22:03:35 --> Helper loaded: date_helper
INFO - 2016-03-01 22:03:35 --> Helper loaded: form_helper
INFO - 2016-03-01 22:03:35 --> Database Driver Class Initialized
INFO - 2016-03-01 22:03:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:03:36 --> Controller Class Initialized
INFO - 2016-03-01 22:03:36 --> Model Class Initialized
INFO - 2016-03-01 22:03:36 --> Model Class Initialized
INFO - 2016-03-01 22:03:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:03:36 --> Pagination Class Initialized
INFO - 2016-03-01 22:03:36 --> Helper loaded: text_helper
INFO - 2016-03-01 22:03:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:03:52 --> Config Class Initialized
INFO - 2016-03-01 22:03:52 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:03:52 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:03:52 --> Utf8 Class Initialized
INFO - 2016-03-01 22:03:52 --> URI Class Initialized
INFO - 2016-03-01 22:03:52 --> Router Class Initialized
INFO - 2016-03-01 22:03:52 --> Output Class Initialized
INFO - 2016-03-01 22:03:52 --> Security Class Initialized
DEBUG - 2016-03-01 22:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:03:52 --> Input Class Initialized
INFO - 2016-03-01 22:03:52 --> Language Class Initialized
INFO - 2016-03-01 22:03:52 --> Loader Class Initialized
INFO - 2016-03-01 22:03:52 --> Helper loaded: url_helper
INFO - 2016-03-01 22:03:52 --> Helper loaded: file_helper
INFO - 2016-03-01 22:03:52 --> Helper loaded: date_helper
INFO - 2016-03-01 22:03:52 --> Helper loaded: form_helper
INFO - 2016-03-01 22:03:52 --> Database Driver Class Initialized
INFO - 2016-03-01 22:03:53 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:03:53 --> Controller Class Initialized
INFO - 2016-03-01 22:03:53 --> Model Class Initialized
INFO - 2016-03-01 22:03:53 --> Model Class Initialized
INFO - 2016-03-01 22:03:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:03:53 --> Pagination Class Initialized
INFO - 2016-03-01 22:03:53 --> Helper loaded: text_helper
INFO - 2016-03-01 22:03:53 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:04:15 --> Config Class Initialized
INFO - 2016-03-01 22:04:15 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:04:15 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:04:15 --> Utf8 Class Initialized
INFO - 2016-03-01 22:04:15 --> URI Class Initialized
INFO - 2016-03-01 22:04:15 --> Router Class Initialized
INFO - 2016-03-01 22:04:15 --> Output Class Initialized
INFO - 2016-03-01 22:04:15 --> Security Class Initialized
DEBUG - 2016-03-01 22:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:04:15 --> Input Class Initialized
INFO - 2016-03-01 22:04:15 --> Language Class Initialized
INFO - 2016-03-01 22:04:15 --> Loader Class Initialized
INFO - 2016-03-01 22:04:15 --> Helper loaded: url_helper
INFO - 2016-03-01 22:04:15 --> Helper loaded: file_helper
INFO - 2016-03-01 22:04:15 --> Helper loaded: date_helper
INFO - 2016-03-01 22:04:15 --> Helper loaded: form_helper
INFO - 2016-03-01 22:04:15 --> Database Driver Class Initialized
INFO - 2016-03-01 22:04:16 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:04:16 --> Controller Class Initialized
INFO - 2016-03-01 22:04:16 --> Model Class Initialized
INFO - 2016-03-01 22:04:16 --> Model Class Initialized
INFO - 2016-03-01 22:04:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:04:16 --> Pagination Class Initialized
INFO - 2016-03-01 22:04:16 --> Helper loaded: text_helper
INFO - 2016-03-01 22:04:16 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:05:31 --> Config Class Initialized
INFO - 2016-03-01 22:05:31 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:05:31 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:05:31 --> Utf8 Class Initialized
INFO - 2016-03-01 22:05:31 --> URI Class Initialized
INFO - 2016-03-01 22:05:31 --> Router Class Initialized
INFO - 2016-03-01 22:05:31 --> Output Class Initialized
INFO - 2016-03-01 22:05:31 --> Security Class Initialized
DEBUG - 2016-03-01 22:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:05:31 --> Input Class Initialized
INFO - 2016-03-01 22:05:31 --> Language Class Initialized
INFO - 2016-03-01 22:05:31 --> Loader Class Initialized
INFO - 2016-03-01 22:05:31 --> Helper loaded: url_helper
INFO - 2016-03-01 22:05:31 --> Helper loaded: file_helper
INFO - 2016-03-01 22:05:31 --> Helper loaded: date_helper
INFO - 2016-03-01 22:05:31 --> Helper loaded: form_helper
INFO - 2016-03-01 22:05:31 --> Database Driver Class Initialized
INFO - 2016-03-01 22:05:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:05:32 --> Controller Class Initialized
INFO - 2016-03-01 22:05:32 --> Model Class Initialized
INFO - 2016-03-01 22:05:32 --> Model Class Initialized
INFO - 2016-03-01 22:05:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:05:32 --> Pagination Class Initialized
INFO - 2016-03-01 22:05:32 --> Helper loaded: text_helper
INFO - 2016-03-01 22:05:32 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:08:47 --> Config Class Initialized
INFO - 2016-03-01 22:08:47 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:08:47 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:08:47 --> Utf8 Class Initialized
INFO - 2016-03-01 22:08:47 --> URI Class Initialized
INFO - 2016-03-01 22:08:47 --> Router Class Initialized
INFO - 2016-03-01 22:08:47 --> Output Class Initialized
INFO - 2016-03-01 22:08:47 --> Security Class Initialized
DEBUG - 2016-03-01 22:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:08:47 --> Input Class Initialized
INFO - 2016-03-01 22:08:47 --> Language Class Initialized
INFO - 2016-03-01 22:08:47 --> Loader Class Initialized
INFO - 2016-03-01 22:08:47 --> Helper loaded: url_helper
INFO - 2016-03-01 22:08:47 --> Helper loaded: file_helper
INFO - 2016-03-01 22:08:47 --> Helper loaded: date_helper
INFO - 2016-03-01 22:08:47 --> Helper loaded: form_helper
INFO - 2016-03-01 22:08:47 --> Database Driver Class Initialized
INFO - 2016-03-01 22:08:48 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:08:48 --> Controller Class Initialized
INFO - 2016-03-01 22:08:48 --> Model Class Initialized
INFO - 2016-03-01 22:08:48 --> Model Class Initialized
INFO - 2016-03-01 22:08:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:08:48 --> Pagination Class Initialized
INFO - 2016-03-01 22:08:48 --> Helper loaded: text_helper
INFO - 2016-03-01 22:08:48 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:09:26 --> Config Class Initialized
INFO - 2016-03-01 22:09:26 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:09:26 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:09:26 --> Utf8 Class Initialized
INFO - 2016-03-01 22:09:26 --> URI Class Initialized
INFO - 2016-03-01 22:09:26 --> Router Class Initialized
INFO - 2016-03-01 22:09:26 --> Output Class Initialized
INFO - 2016-03-01 22:09:26 --> Security Class Initialized
DEBUG - 2016-03-01 22:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:09:26 --> Input Class Initialized
INFO - 2016-03-01 22:09:26 --> Language Class Initialized
INFO - 2016-03-01 22:09:26 --> Loader Class Initialized
INFO - 2016-03-01 22:09:26 --> Helper loaded: url_helper
INFO - 2016-03-01 22:09:26 --> Helper loaded: file_helper
INFO - 2016-03-01 22:09:26 --> Helper loaded: date_helper
INFO - 2016-03-01 22:09:26 --> Helper loaded: form_helper
INFO - 2016-03-01 22:09:26 --> Database Driver Class Initialized
INFO - 2016-03-01 22:09:27 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:09:27 --> Controller Class Initialized
INFO - 2016-03-01 22:09:27 --> Model Class Initialized
INFO - 2016-03-01 22:09:27 --> Model Class Initialized
INFO - 2016-03-01 22:09:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:09:27 --> Pagination Class Initialized
INFO - 2016-03-01 22:09:27 --> Helper loaded: text_helper
INFO - 2016-03-01 22:09:27 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:10:42 --> Config Class Initialized
INFO - 2016-03-01 22:10:42 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:10:42 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:10:42 --> Utf8 Class Initialized
INFO - 2016-03-01 22:10:42 --> URI Class Initialized
INFO - 2016-03-01 22:10:42 --> Router Class Initialized
INFO - 2016-03-01 22:10:42 --> Output Class Initialized
INFO - 2016-03-01 22:10:42 --> Security Class Initialized
DEBUG - 2016-03-01 22:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:10:42 --> Input Class Initialized
INFO - 2016-03-01 22:10:42 --> Language Class Initialized
INFO - 2016-03-01 22:10:42 --> Loader Class Initialized
INFO - 2016-03-01 22:10:42 --> Helper loaded: url_helper
INFO - 2016-03-01 22:10:42 --> Helper loaded: file_helper
INFO - 2016-03-01 22:10:42 --> Helper loaded: date_helper
INFO - 2016-03-01 22:10:42 --> Helper loaded: form_helper
INFO - 2016-03-01 22:10:43 --> Database Driver Class Initialized
INFO - 2016-03-01 22:10:44 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:10:44 --> Controller Class Initialized
INFO - 2016-03-01 22:10:44 --> Model Class Initialized
INFO - 2016-03-01 22:10:44 --> Model Class Initialized
INFO - 2016-03-01 22:10:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:10:44 --> Pagination Class Initialized
INFO - 2016-03-01 22:10:44 --> Helper loaded: text_helper
INFO - 2016-03-01 22:10:44 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:15:35 --> Config Class Initialized
INFO - 2016-03-01 22:15:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:15:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:15:35 --> Utf8 Class Initialized
INFO - 2016-03-01 22:15:35 --> URI Class Initialized
INFO - 2016-03-01 22:15:35 --> Router Class Initialized
INFO - 2016-03-01 22:15:35 --> Output Class Initialized
INFO - 2016-03-01 22:15:35 --> Security Class Initialized
DEBUG - 2016-03-01 22:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:15:35 --> Input Class Initialized
INFO - 2016-03-01 22:15:35 --> Language Class Initialized
INFO - 2016-03-01 22:15:35 --> Loader Class Initialized
INFO - 2016-03-01 22:15:35 --> Helper loaded: url_helper
INFO - 2016-03-01 22:15:35 --> Helper loaded: file_helper
INFO - 2016-03-01 22:15:35 --> Helper loaded: date_helper
INFO - 2016-03-01 22:15:35 --> Helper loaded: form_helper
INFO - 2016-03-01 22:15:35 --> Database Driver Class Initialized
INFO - 2016-03-01 22:15:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:15:36 --> Controller Class Initialized
INFO - 2016-03-01 22:15:36 --> Model Class Initialized
INFO - 2016-03-01 22:15:36 --> Model Class Initialized
INFO - 2016-03-01 22:15:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:15:36 --> Pagination Class Initialized
INFO - 2016-03-01 22:15:36 --> Helper loaded: text_helper
INFO - 2016-03-01 22:15:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:16:11 --> Config Class Initialized
INFO - 2016-03-01 22:16:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:16:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:16:11 --> Utf8 Class Initialized
INFO - 2016-03-01 22:16:11 --> URI Class Initialized
INFO - 2016-03-01 22:16:11 --> Router Class Initialized
INFO - 2016-03-01 22:16:11 --> Output Class Initialized
INFO - 2016-03-01 22:16:11 --> Security Class Initialized
DEBUG - 2016-03-01 22:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:16:11 --> Input Class Initialized
INFO - 2016-03-01 22:16:11 --> Language Class Initialized
INFO - 2016-03-01 22:16:11 --> Loader Class Initialized
INFO - 2016-03-01 22:16:11 --> Helper loaded: url_helper
INFO - 2016-03-01 22:16:11 --> Helper loaded: file_helper
INFO - 2016-03-01 22:16:11 --> Helper loaded: date_helper
INFO - 2016-03-01 22:16:11 --> Helper loaded: form_helper
INFO - 2016-03-01 22:16:11 --> Database Driver Class Initialized
INFO - 2016-03-01 22:16:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:16:12 --> Controller Class Initialized
INFO - 2016-03-01 22:16:13 --> Model Class Initialized
INFO - 2016-03-01 22:16:13 --> Model Class Initialized
INFO - 2016-03-01 22:16:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:16:13 --> Pagination Class Initialized
INFO - 2016-03-01 22:16:13 --> Helper loaded: text_helper
INFO - 2016-03-01 22:16:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:16:24 --> Config Class Initialized
INFO - 2016-03-01 22:16:24 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:16:24 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:16:24 --> Utf8 Class Initialized
INFO - 2016-03-01 22:16:24 --> URI Class Initialized
INFO - 2016-03-01 22:16:24 --> Router Class Initialized
INFO - 2016-03-01 22:16:24 --> Output Class Initialized
INFO - 2016-03-01 22:16:24 --> Security Class Initialized
DEBUG - 2016-03-01 22:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:16:24 --> Input Class Initialized
INFO - 2016-03-01 22:16:24 --> Language Class Initialized
INFO - 2016-03-01 22:16:24 --> Loader Class Initialized
INFO - 2016-03-01 22:16:24 --> Helper loaded: url_helper
INFO - 2016-03-01 22:16:24 --> Helper loaded: file_helper
INFO - 2016-03-01 22:16:24 --> Helper loaded: date_helper
INFO - 2016-03-01 22:16:24 --> Helper loaded: form_helper
INFO - 2016-03-01 22:16:24 --> Database Driver Class Initialized
INFO - 2016-03-01 22:16:25 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:16:25 --> Controller Class Initialized
INFO - 2016-03-01 22:16:25 --> Model Class Initialized
INFO - 2016-03-01 22:16:25 --> Model Class Initialized
INFO - 2016-03-01 22:16:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:16:25 --> Pagination Class Initialized
INFO - 2016-03-01 22:16:25 --> Helper loaded: text_helper
INFO - 2016-03-01 22:16:25 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:16:27 --> Config Class Initialized
INFO - 2016-03-01 22:16:27 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:16:27 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:16:27 --> Utf8 Class Initialized
INFO - 2016-03-01 22:16:27 --> URI Class Initialized
INFO - 2016-03-01 22:16:27 --> Router Class Initialized
INFO - 2016-03-01 22:16:27 --> Output Class Initialized
INFO - 2016-03-01 22:16:27 --> Security Class Initialized
DEBUG - 2016-03-01 22:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:16:27 --> Input Class Initialized
INFO - 2016-03-01 22:16:27 --> Language Class Initialized
INFO - 2016-03-01 22:16:27 --> Loader Class Initialized
INFO - 2016-03-01 22:16:27 --> Helper loaded: url_helper
INFO - 2016-03-01 22:16:27 --> Helper loaded: file_helper
INFO - 2016-03-01 22:16:27 --> Helper loaded: date_helper
INFO - 2016-03-01 22:16:27 --> Helper loaded: form_helper
INFO - 2016-03-01 22:16:27 --> Database Driver Class Initialized
INFO - 2016-03-01 22:16:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:16:28 --> Controller Class Initialized
INFO - 2016-03-01 22:16:28 --> Model Class Initialized
INFO - 2016-03-01 22:16:28 --> Model Class Initialized
INFO - 2016-03-01 22:16:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:16:28 --> Pagination Class Initialized
INFO - 2016-03-01 22:16:29 --> Helper loaded: text_helper
INFO - 2016-03-01 22:16:29 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:16:31 --> Config Class Initialized
INFO - 2016-03-01 22:16:31 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:16:31 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:16:31 --> Utf8 Class Initialized
INFO - 2016-03-01 22:16:31 --> URI Class Initialized
INFO - 2016-03-01 22:16:31 --> Router Class Initialized
INFO - 2016-03-01 22:16:31 --> Output Class Initialized
INFO - 2016-03-01 22:16:31 --> Security Class Initialized
DEBUG - 2016-03-01 22:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:16:31 --> Input Class Initialized
INFO - 2016-03-01 22:16:31 --> Language Class Initialized
INFO - 2016-03-01 22:16:31 --> Loader Class Initialized
INFO - 2016-03-01 22:16:31 --> Helper loaded: url_helper
INFO - 2016-03-01 22:16:31 --> Helper loaded: file_helper
INFO - 2016-03-01 22:16:31 --> Helper loaded: date_helper
INFO - 2016-03-01 22:16:31 --> Helper loaded: form_helper
INFO - 2016-03-01 22:16:31 --> Database Driver Class Initialized
INFO - 2016-03-01 22:16:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:16:32 --> Controller Class Initialized
INFO - 2016-03-01 22:16:32 --> Model Class Initialized
INFO - 2016-03-01 22:16:32 --> Model Class Initialized
INFO - 2016-03-01 22:16:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:16:32 --> Pagination Class Initialized
INFO - 2016-03-01 22:16:32 --> Helper loaded: text_helper
INFO - 2016-03-01 22:16:32 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:17:08 --> Config Class Initialized
INFO - 2016-03-01 22:17:08 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:17:08 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:17:08 --> Utf8 Class Initialized
INFO - 2016-03-01 22:17:08 --> URI Class Initialized
INFO - 2016-03-01 22:17:08 --> Router Class Initialized
INFO - 2016-03-01 22:17:08 --> Output Class Initialized
INFO - 2016-03-01 22:17:08 --> Security Class Initialized
DEBUG - 2016-03-01 22:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:17:08 --> Input Class Initialized
INFO - 2016-03-01 22:17:08 --> Language Class Initialized
INFO - 2016-03-01 22:17:08 --> Loader Class Initialized
INFO - 2016-03-01 22:17:08 --> Helper loaded: url_helper
INFO - 2016-03-01 22:17:08 --> Helper loaded: file_helper
INFO - 2016-03-01 22:17:08 --> Helper loaded: date_helper
INFO - 2016-03-01 22:17:08 --> Helper loaded: form_helper
INFO - 2016-03-01 22:17:08 --> Database Driver Class Initialized
INFO - 2016-03-01 22:17:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:17:09 --> Controller Class Initialized
INFO - 2016-03-01 22:17:09 --> Model Class Initialized
INFO - 2016-03-01 22:17:09 --> Model Class Initialized
INFO - 2016-03-01 22:17:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:17:09 --> Pagination Class Initialized
INFO - 2016-03-01 22:17:09 --> Helper loaded: text_helper
INFO - 2016-03-01 22:17:09 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:18:12 --> Config Class Initialized
INFO - 2016-03-01 22:18:12 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:18:12 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:18:12 --> Utf8 Class Initialized
INFO - 2016-03-01 22:18:12 --> URI Class Initialized
INFO - 2016-03-01 22:18:12 --> Router Class Initialized
INFO - 2016-03-01 22:18:12 --> Output Class Initialized
INFO - 2016-03-01 22:18:12 --> Security Class Initialized
DEBUG - 2016-03-01 22:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:18:12 --> Input Class Initialized
INFO - 2016-03-01 22:18:12 --> Language Class Initialized
INFO - 2016-03-01 22:18:12 --> Loader Class Initialized
INFO - 2016-03-01 22:18:12 --> Helper loaded: url_helper
INFO - 2016-03-01 22:18:12 --> Helper loaded: file_helper
INFO - 2016-03-01 22:18:12 --> Helper loaded: date_helper
INFO - 2016-03-01 22:18:12 --> Helper loaded: form_helper
INFO - 2016-03-01 22:18:12 --> Database Driver Class Initialized
INFO - 2016-03-01 22:18:13 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:18:13 --> Controller Class Initialized
INFO - 2016-03-01 22:18:13 --> Model Class Initialized
INFO - 2016-03-01 22:18:13 --> Model Class Initialized
INFO - 2016-03-01 22:18:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:18:13 --> Pagination Class Initialized
INFO - 2016-03-01 22:18:13 --> Helper loaded: text_helper
INFO - 2016-03-01 22:18:13 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:19:28 --> Config Class Initialized
INFO - 2016-03-01 22:19:28 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:19:28 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:19:28 --> Utf8 Class Initialized
INFO - 2016-03-01 22:19:28 --> URI Class Initialized
INFO - 2016-03-01 22:19:28 --> Router Class Initialized
INFO - 2016-03-01 22:19:28 --> Output Class Initialized
INFO - 2016-03-01 22:19:28 --> Security Class Initialized
DEBUG - 2016-03-01 22:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:19:28 --> Input Class Initialized
INFO - 2016-03-01 22:19:28 --> Language Class Initialized
INFO - 2016-03-01 22:19:28 --> Loader Class Initialized
INFO - 2016-03-01 22:19:28 --> Helper loaded: url_helper
INFO - 2016-03-01 22:19:28 --> Helper loaded: file_helper
INFO - 2016-03-01 22:19:28 --> Helper loaded: date_helper
INFO - 2016-03-01 22:19:28 --> Helper loaded: form_helper
INFO - 2016-03-01 22:19:28 --> Database Driver Class Initialized
INFO - 2016-03-01 22:19:29 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:19:29 --> Controller Class Initialized
INFO - 2016-03-01 22:19:30 --> Model Class Initialized
INFO - 2016-03-01 22:19:30 --> Model Class Initialized
INFO - 2016-03-01 22:19:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:19:30 --> Pagination Class Initialized
INFO - 2016-03-01 22:19:30 --> Helper loaded: text_helper
INFO - 2016-03-01 22:19:30 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:19:46 --> Config Class Initialized
INFO - 2016-03-01 22:19:46 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:19:46 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:19:46 --> Utf8 Class Initialized
INFO - 2016-03-01 22:19:46 --> URI Class Initialized
INFO - 2016-03-01 22:19:46 --> Router Class Initialized
INFO - 2016-03-01 22:19:46 --> Output Class Initialized
INFO - 2016-03-01 22:19:46 --> Security Class Initialized
DEBUG - 2016-03-01 22:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:19:46 --> Input Class Initialized
INFO - 2016-03-01 22:19:46 --> Language Class Initialized
INFO - 2016-03-01 22:19:46 --> Loader Class Initialized
INFO - 2016-03-01 22:19:46 --> Helper loaded: url_helper
INFO - 2016-03-01 22:19:46 --> Helper loaded: file_helper
INFO - 2016-03-01 22:19:46 --> Helper loaded: date_helper
INFO - 2016-03-01 22:19:46 --> Helper loaded: form_helper
INFO - 2016-03-01 22:19:46 --> Database Driver Class Initialized
INFO - 2016-03-01 22:19:47 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:19:47 --> Controller Class Initialized
INFO - 2016-03-01 22:19:47 --> Model Class Initialized
INFO - 2016-03-01 22:19:47 --> Model Class Initialized
INFO - 2016-03-01 22:19:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:19:47 --> Pagination Class Initialized
INFO - 2016-03-01 22:19:47 --> Helper loaded: text_helper
INFO - 2016-03-01 22:19:47 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:20:32 --> Config Class Initialized
INFO - 2016-03-01 22:20:32 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:20:32 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:20:32 --> Utf8 Class Initialized
INFO - 2016-03-01 22:20:32 --> URI Class Initialized
INFO - 2016-03-01 22:20:32 --> Router Class Initialized
INFO - 2016-03-01 22:20:32 --> Output Class Initialized
INFO - 2016-03-01 22:20:32 --> Security Class Initialized
DEBUG - 2016-03-01 22:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:20:32 --> Input Class Initialized
INFO - 2016-03-01 22:20:32 --> Language Class Initialized
INFO - 2016-03-01 22:20:32 --> Loader Class Initialized
INFO - 2016-03-01 22:20:32 --> Helper loaded: url_helper
INFO - 2016-03-01 22:20:32 --> Helper loaded: file_helper
INFO - 2016-03-01 22:20:32 --> Helper loaded: date_helper
INFO - 2016-03-01 22:20:32 --> Helper loaded: form_helper
INFO - 2016-03-01 22:20:32 --> Database Driver Class Initialized
INFO - 2016-03-01 22:20:33 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:20:33 --> Controller Class Initialized
INFO - 2016-03-01 22:20:33 --> Model Class Initialized
INFO - 2016-03-01 22:20:33 --> Model Class Initialized
INFO - 2016-03-01 22:20:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:20:33 --> Pagination Class Initialized
INFO - 2016-03-01 22:20:33 --> Helper loaded: text_helper
INFO - 2016-03-01 22:20:33 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:23:25 --> Config Class Initialized
INFO - 2016-03-01 22:23:25 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:23:25 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:23:25 --> Utf8 Class Initialized
INFO - 2016-03-01 22:23:25 --> URI Class Initialized
INFO - 2016-03-01 22:23:25 --> Router Class Initialized
INFO - 2016-03-01 22:23:25 --> Output Class Initialized
INFO - 2016-03-01 22:23:25 --> Security Class Initialized
DEBUG - 2016-03-01 22:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:23:25 --> Input Class Initialized
INFO - 2016-03-01 22:23:25 --> Language Class Initialized
INFO - 2016-03-01 22:23:25 --> Loader Class Initialized
INFO - 2016-03-01 22:23:25 --> Helper loaded: url_helper
INFO - 2016-03-01 22:23:25 --> Helper loaded: file_helper
INFO - 2016-03-01 22:23:25 --> Helper loaded: date_helper
INFO - 2016-03-01 22:23:25 --> Helper loaded: form_helper
INFO - 2016-03-01 22:23:25 --> Database Driver Class Initialized
INFO - 2016-03-01 22:23:26 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:23:26 --> Controller Class Initialized
INFO - 2016-03-01 22:23:26 --> Model Class Initialized
INFO - 2016-03-01 22:23:26 --> Model Class Initialized
INFO - 2016-03-01 22:23:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:23:26 --> Pagination Class Initialized
INFO - 2016-03-01 22:23:26 --> Helper loaded: text_helper
INFO - 2016-03-01 22:23:26 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:24:29 --> Config Class Initialized
INFO - 2016-03-01 22:24:29 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:24:29 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:24:29 --> Utf8 Class Initialized
INFO - 2016-03-01 22:24:29 --> URI Class Initialized
INFO - 2016-03-01 22:24:29 --> Router Class Initialized
INFO - 2016-03-01 22:24:29 --> Output Class Initialized
INFO - 2016-03-01 22:24:29 --> Security Class Initialized
DEBUG - 2016-03-01 22:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:24:29 --> Input Class Initialized
INFO - 2016-03-01 22:24:29 --> Language Class Initialized
INFO - 2016-03-01 22:24:29 --> Loader Class Initialized
INFO - 2016-03-01 22:24:29 --> Helper loaded: url_helper
INFO - 2016-03-01 22:24:29 --> Helper loaded: file_helper
INFO - 2016-03-01 22:24:29 --> Helper loaded: date_helper
INFO - 2016-03-01 22:24:29 --> Helper loaded: form_helper
INFO - 2016-03-01 22:24:29 --> Database Driver Class Initialized
INFO - 2016-03-01 22:24:30 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:24:30 --> Controller Class Initialized
INFO - 2016-03-01 22:24:30 --> Model Class Initialized
INFO - 2016-03-01 22:24:30 --> Model Class Initialized
INFO - 2016-03-01 22:24:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:24:30 --> Pagination Class Initialized
INFO - 2016-03-01 22:24:30 --> Helper loaded: text_helper
INFO - 2016-03-01 22:24:30 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:26:08 --> Config Class Initialized
INFO - 2016-03-01 22:26:08 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:26:08 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:26:08 --> Utf8 Class Initialized
INFO - 2016-03-01 22:26:08 --> URI Class Initialized
INFO - 2016-03-01 22:26:08 --> Router Class Initialized
INFO - 2016-03-01 22:26:08 --> Output Class Initialized
INFO - 2016-03-01 22:26:08 --> Security Class Initialized
DEBUG - 2016-03-01 22:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:26:08 --> Input Class Initialized
INFO - 2016-03-01 22:26:08 --> Language Class Initialized
INFO - 2016-03-01 22:26:08 --> Loader Class Initialized
INFO - 2016-03-01 22:26:08 --> Helper loaded: url_helper
INFO - 2016-03-01 22:26:08 --> Helper loaded: file_helper
INFO - 2016-03-01 22:26:08 --> Helper loaded: date_helper
INFO - 2016-03-01 22:26:08 --> Helper loaded: form_helper
INFO - 2016-03-01 22:26:08 --> Database Driver Class Initialized
INFO - 2016-03-01 22:26:10 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:26:10 --> Controller Class Initialized
INFO - 2016-03-01 22:26:10 --> Model Class Initialized
INFO - 2016-03-01 22:26:10 --> Model Class Initialized
INFO - 2016-03-01 22:26:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:26:10 --> Pagination Class Initialized
INFO - 2016-03-01 22:26:10 --> Helper loaded: text_helper
INFO - 2016-03-01 22:26:10 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:26:30 --> Config Class Initialized
INFO - 2016-03-01 22:26:30 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:26:30 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:26:30 --> Utf8 Class Initialized
INFO - 2016-03-01 22:26:30 --> URI Class Initialized
INFO - 2016-03-01 22:26:30 --> Router Class Initialized
INFO - 2016-03-01 22:26:30 --> Output Class Initialized
INFO - 2016-03-01 22:26:30 --> Security Class Initialized
DEBUG - 2016-03-01 22:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:26:30 --> Input Class Initialized
INFO - 2016-03-01 22:26:30 --> Language Class Initialized
INFO - 2016-03-01 22:26:30 --> Loader Class Initialized
INFO - 2016-03-01 22:26:30 --> Helper loaded: url_helper
INFO - 2016-03-01 22:26:30 --> Helper loaded: file_helper
INFO - 2016-03-01 22:26:30 --> Helper loaded: date_helper
INFO - 2016-03-01 22:26:30 --> Helper loaded: form_helper
INFO - 2016-03-01 22:26:30 --> Database Driver Class Initialized
INFO - 2016-03-01 22:26:32 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:26:32 --> Controller Class Initialized
INFO - 2016-03-01 22:26:32 --> Model Class Initialized
INFO - 2016-03-01 22:26:32 --> Model Class Initialized
INFO - 2016-03-01 22:26:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:26:32 --> Pagination Class Initialized
INFO - 2016-03-01 22:26:32 --> Helper loaded: text_helper
INFO - 2016-03-01 22:26:32 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:27:08 --> Config Class Initialized
INFO - 2016-03-01 22:27:08 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:27:08 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:27:08 --> Utf8 Class Initialized
INFO - 2016-03-01 22:27:08 --> URI Class Initialized
INFO - 2016-03-01 22:27:08 --> Router Class Initialized
INFO - 2016-03-01 22:27:08 --> Output Class Initialized
INFO - 2016-03-01 22:27:08 --> Security Class Initialized
DEBUG - 2016-03-01 22:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:27:08 --> Input Class Initialized
INFO - 2016-03-01 22:27:08 --> Language Class Initialized
INFO - 2016-03-01 22:27:08 --> Loader Class Initialized
INFO - 2016-03-01 22:27:08 --> Helper loaded: url_helper
INFO - 2016-03-01 22:27:08 --> Helper loaded: file_helper
INFO - 2016-03-01 22:27:08 --> Helper loaded: date_helper
INFO - 2016-03-01 22:27:08 --> Helper loaded: form_helper
INFO - 2016-03-01 22:27:08 --> Database Driver Class Initialized
INFO - 2016-03-01 22:27:09 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:27:09 --> Controller Class Initialized
INFO - 2016-03-01 22:27:09 --> Model Class Initialized
INFO - 2016-03-01 22:27:09 --> Model Class Initialized
INFO - 2016-03-01 22:27:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:27:09 --> Pagination Class Initialized
INFO - 2016-03-01 22:27:09 --> Helper loaded: text_helper
INFO - 2016-03-01 22:27:09 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:28:27 --> Config Class Initialized
INFO - 2016-03-01 22:28:27 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:28:27 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:28:27 --> Utf8 Class Initialized
INFO - 2016-03-01 22:28:27 --> URI Class Initialized
INFO - 2016-03-01 22:28:27 --> Router Class Initialized
INFO - 2016-03-01 22:28:27 --> Output Class Initialized
INFO - 2016-03-01 22:28:27 --> Security Class Initialized
DEBUG - 2016-03-01 22:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:28:27 --> Input Class Initialized
INFO - 2016-03-01 22:28:27 --> Language Class Initialized
INFO - 2016-03-01 22:28:27 --> Loader Class Initialized
INFO - 2016-03-01 22:28:27 --> Helper loaded: url_helper
INFO - 2016-03-01 22:28:27 --> Helper loaded: file_helper
INFO - 2016-03-01 22:28:27 --> Helper loaded: date_helper
INFO - 2016-03-01 22:28:27 --> Helper loaded: form_helper
INFO - 2016-03-01 22:28:27 --> Database Driver Class Initialized
INFO - 2016-03-01 22:28:28 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:28:28 --> Controller Class Initialized
INFO - 2016-03-01 22:28:28 --> Model Class Initialized
INFO - 2016-03-01 22:28:28 --> Model Class Initialized
INFO - 2016-03-01 22:28:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:28:28 --> Pagination Class Initialized
INFO - 2016-03-01 22:28:28 --> Helper loaded: text_helper
INFO - 2016-03-01 22:28:28 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:29:11 --> Config Class Initialized
INFO - 2016-03-01 22:29:11 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:29:11 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:29:11 --> Utf8 Class Initialized
INFO - 2016-03-01 22:29:11 --> URI Class Initialized
INFO - 2016-03-01 22:29:11 --> Router Class Initialized
INFO - 2016-03-01 22:29:11 --> Output Class Initialized
INFO - 2016-03-01 22:29:11 --> Security Class Initialized
DEBUG - 2016-03-01 22:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:29:11 --> Input Class Initialized
INFO - 2016-03-01 22:29:11 --> Language Class Initialized
INFO - 2016-03-01 22:29:11 --> Loader Class Initialized
INFO - 2016-03-01 22:29:11 --> Helper loaded: url_helper
INFO - 2016-03-01 22:29:11 --> Helper loaded: file_helper
INFO - 2016-03-01 22:29:11 --> Helper loaded: date_helper
INFO - 2016-03-01 22:29:11 --> Helper loaded: form_helper
INFO - 2016-03-01 22:29:11 --> Database Driver Class Initialized
INFO - 2016-03-01 22:29:12 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:29:12 --> Controller Class Initialized
INFO - 2016-03-01 22:29:12 --> Model Class Initialized
INFO - 2016-03-01 22:29:12 --> Model Class Initialized
INFO - 2016-03-01 22:29:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:29:12 --> Pagination Class Initialized
INFO - 2016-03-01 22:29:12 --> Helper loaded: text_helper
INFO - 2016-03-01 22:29:12 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:29:35 --> Config Class Initialized
INFO - 2016-03-01 22:29:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:29:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:29:35 --> Utf8 Class Initialized
INFO - 2016-03-01 22:29:35 --> URI Class Initialized
INFO - 2016-03-01 22:29:35 --> Router Class Initialized
INFO - 2016-03-01 22:29:35 --> Output Class Initialized
INFO - 2016-03-01 22:29:35 --> Security Class Initialized
DEBUG - 2016-03-01 22:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:29:35 --> Input Class Initialized
INFO - 2016-03-01 22:29:35 --> Language Class Initialized
INFO - 2016-03-01 22:29:35 --> Loader Class Initialized
INFO - 2016-03-01 22:29:35 --> Helper loaded: url_helper
INFO - 2016-03-01 22:29:35 --> Helper loaded: file_helper
INFO - 2016-03-01 22:29:35 --> Helper loaded: date_helper
INFO - 2016-03-01 22:29:35 --> Helper loaded: form_helper
INFO - 2016-03-01 22:29:35 --> Database Driver Class Initialized
INFO - 2016-03-01 22:29:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:29:36 --> Controller Class Initialized
INFO - 2016-03-01 22:29:36 --> Model Class Initialized
INFO - 2016-03-01 22:29:36 --> Model Class Initialized
INFO - 2016-03-01 22:29:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:29:36 --> Pagination Class Initialized
INFO - 2016-03-01 22:29:36 --> Helper loaded: text_helper
INFO - 2016-03-01 22:29:36 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:29:53 --> Config Class Initialized
INFO - 2016-03-01 22:29:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:29:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:29:53 --> Utf8 Class Initialized
INFO - 2016-03-01 22:29:53 --> URI Class Initialized
INFO - 2016-03-01 22:29:53 --> Router Class Initialized
INFO - 2016-03-01 22:29:53 --> Output Class Initialized
INFO - 2016-03-01 22:29:53 --> Security Class Initialized
DEBUG - 2016-03-01 22:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:29:53 --> Input Class Initialized
INFO - 2016-03-01 22:29:53 --> Language Class Initialized
INFO - 2016-03-01 22:29:53 --> Loader Class Initialized
INFO - 2016-03-01 22:29:53 --> Helper loaded: url_helper
INFO - 2016-03-01 22:29:53 --> Helper loaded: file_helper
INFO - 2016-03-01 22:29:53 --> Helper loaded: date_helper
INFO - 2016-03-01 22:29:53 --> Helper loaded: form_helper
INFO - 2016-03-01 22:29:53 --> Database Driver Class Initialized
INFO - 2016-03-01 22:29:54 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:29:54 --> Controller Class Initialized
INFO - 2016-03-01 22:29:54 --> Model Class Initialized
INFO - 2016-03-01 22:29:54 --> Model Class Initialized
INFO - 2016-03-01 22:29:54 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:29:54 --> Pagination Class Initialized
INFO - 2016-03-01 22:29:54 --> Helper loaded: text_helper
INFO - 2016-03-01 22:29:54 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:30:05 --> Config Class Initialized
INFO - 2016-03-01 22:30:05 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:30:05 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:30:05 --> Utf8 Class Initialized
INFO - 2016-03-01 22:30:05 --> URI Class Initialized
INFO - 2016-03-01 22:30:05 --> Router Class Initialized
INFO - 2016-03-01 22:30:05 --> Output Class Initialized
INFO - 2016-03-01 22:30:05 --> Security Class Initialized
DEBUG - 2016-03-01 22:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:30:05 --> Input Class Initialized
INFO - 2016-03-01 22:30:05 --> Language Class Initialized
INFO - 2016-03-01 22:30:05 --> Loader Class Initialized
INFO - 2016-03-01 22:30:05 --> Helper loaded: url_helper
INFO - 2016-03-01 22:30:05 --> Helper loaded: file_helper
INFO - 2016-03-01 22:30:05 --> Helper loaded: date_helper
INFO - 2016-03-01 22:30:05 --> Helper loaded: form_helper
INFO - 2016-03-01 22:30:05 --> Database Driver Class Initialized
INFO - 2016-03-01 22:30:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:30:06 --> Controller Class Initialized
INFO - 2016-03-01 22:30:06 --> Model Class Initialized
INFO - 2016-03-01 22:30:06 --> Model Class Initialized
INFO - 2016-03-01 22:30:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:30:06 --> Pagination Class Initialized
INFO - 2016-03-01 22:30:06 --> Helper loaded: text_helper
INFO - 2016-03-01 22:30:06 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:31:17 --> Config Class Initialized
INFO - 2016-03-01 22:31:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:31:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:31:17 --> Utf8 Class Initialized
INFO - 2016-03-01 22:31:17 --> URI Class Initialized
INFO - 2016-03-01 22:31:17 --> Router Class Initialized
INFO - 2016-03-01 22:31:17 --> Output Class Initialized
INFO - 2016-03-01 22:31:17 --> Security Class Initialized
DEBUG - 2016-03-01 22:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:31:17 --> Input Class Initialized
INFO - 2016-03-01 22:31:17 --> Language Class Initialized
INFO - 2016-03-01 22:31:17 --> Loader Class Initialized
INFO - 2016-03-01 22:31:17 --> Helper loaded: url_helper
INFO - 2016-03-01 22:31:17 --> Helper loaded: file_helper
INFO - 2016-03-01 22:31:17 --> Helper loaded: date_helper
INFO - 2016-03-01 22:31:17 --> Helper loaded: form_helper
INFO - 2016-03-01 22:31:17 --> Database Driver Class Initialized
INFO - 2016-03-01 22:31:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:31:18 --> Controller Class Initialized
INFO - 2016-03-01 22:31:18 --> Model Class Initialized
INFO - 2016-03-01 22:31:18 --> Model Class Initialized
INFO - 2016-03-01 22:31:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:31:18 --> Pagination Class Initialized
INFO - 2016-03-01 22:31:18 --> Helper loaded: text_helper
INFO - 2016-03-01 22:31:18 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:33:05 --> Config Class Initialized
INFO - 2016-03-01 22:33:05 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:33:05 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:33:05 --> Utf8 Class Initialized
INFO - 2016-03-01 22:33:05 --> URI Class Initialized
INFO - 2016-03-01 22:33:05 --> Router Class Initialized
INFO - 2016-03-01 22:33:05 --> Output Class Initialized
INFO - 2016-03-01 22:33:05 --> Security Class Initialized
DEBUG - 2016-03-01 22:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:33:05 --> Input Class Initialized
INFO - 2016-03-01 22:33:05 --> Language Class Initialized
INFO - 2016-03-01 22:33:05 --> Loader Class Initialized
INFO - 2016-03-01 22:33:05 --> Helper loaded: url_helper
INFO - 2016-03-01 22:33:05 --> Helper loaded: file_helper
INFO - 2016-03-01 22:33:05 --> Helper loaded: date_helper
INFO - 2016-03-01 22:33:05 --> Helper loaded: form_helper
INFO - 2016-03-01 22:33:05 --> Database Driver Class Initialized
INFO - 2016-03-01 22:33:06 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:33:06 --> Controller Class Initialized
INFO - 2016-03-01 22:33:06 --> Model Class Initialized
INFO - 2016-03-01 22:33:06 --> Model Class Initialized
INFO - 2016-03-01 22:33:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:33:06 --> Pagination Class Initialized
INFO - 2016-03-01 22:33:06 --> Helper loaded: text_helper
INFO - 2016-03-01 22:33:06 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:34:17 --> Config Class Initialized
INFO - 2016-03-01 22:34:17 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:34:17 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:34:17 --> Utf8 Class Initialized
INFO - 2016-03-01 22:34:17 --> URI Class Initialized
INFO - 2016-03-01 22:34:17 --> Router Class Initialized
INFO - 2016-03-01 22:34:17 --> Output Class Initialized
INFO - 2016-03-01 22:34:17 --> Security Class Initialized
DEBUG - 2016-03-01 22:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:34:17 --> Input Class Initialized
INFO - 2016-03-01 22:34:17 --> Language Class Initialized
INFO - 2016-03-01 22:34:17 --> Loader Class Initialized
INFO - 2016-03-01 22:34:17 --> Helper loaded: url_helper
INFO - 2016-03-01 22:34:17 --> Helper loaded: file_helper
INFO - 2016-03-01 22:34:17 --> Helper loaded: date_helper
INFO - 2016-03-01 22:34:17 --> Helper loaded: form_helper
INFO - 2016-03-01 22:34:17 --> Database Driver Class Initialized
INFO - 2016-03-01 22:34:18 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:34:18 --> Controller Class Initialized
INFO - 2016-03-01 22:34:18 --> Model Class Initialized
INFO - 2016-03-01 22:34:18 --> Model Class Initialized
INFO - 2016-03-01 22:34:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:34:18 --> Pagination Class Initialized
INFO - 2016-03-01 22:34:18 --> Helper loaded: text_helper
INFO - 2016-03-01 22:34:18 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:34:35 --> Config Class Initialized
INFO - 2016-03-01 22:34:35 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:34:35 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:34:35 --> Utf8 Class Initialized
INFO - 2016-03-01 22:34:35 --> URI Class Initialized
INFO - 2016-03-01 22:34:35 --> Router Class Initialized
INFO - 2016-03-01 22:34:35 --> Output Class Initialized
INFO - 2016-03-01 22:34:35 --> Security Class Initialized
DEBUG - 2016-03-01 22:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:34:35 --> Input Class Initialized
INFO - 2016-03-01 22:34:35 --> Language Class Initialized
INFO - 2016-03-01 22:34:35 --> Loader Class Initialized
INFO - 2016-03-01 22:34:35 --> Helper loaded: url_helper
INFO - 2016-03-01 22:34:35 --> Helper loaded: file_helper
INFO - 2016-03-01 22:34:35 --> Helper loaded: date_helper
INFO - 2016-03-01 22:34:35 --> Helper loaded: form_helper
INFO - 2016-03-01 22:34:35 --> Database Driver Class Initialized
INFO - 2016-03-01 22:34:36 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:34:37 --> Controller Class Initialized
INFO - 2016-03-01 22:34:37 --> Model Class Initialized
INFO - 2016-03-01 22:34:37 --> Model Class Initialized
INFO - 2016-03-01 22:34:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:34:37 --> Pagination Class Initialized
INFO - 2016-03-01 22:34:37 --> Helper loaded: text_helper
INFO - 2016-03-01 22:34:37 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:35:59 --> Config Class Initialized
INFO - 2016-03-01 22:35:59 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:35:59 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:35:59 --> Utf8 Class Initialized
INFO - 2016-03-01 22:35:59 --> URI Class Initialized
INFO - 2016-03-01 22:35:59 --> Router Class Initialized
INFO - 2016-03-01 22:35:59 --> Output Class Initialized
INFO - 2016-03-01 22:35:59 --> Security Class Initialized
DEBUG - 2016-03-01 22:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:35:59 --> Input Class Initialized
INFO - 2016-03-01 22:35:59 --> Language Class Initialized
INFO - 2016-03-01 22:35:59 --> Loader Class Initialized
INFO - 2016-03-01 22:35:59 --> Helper loaded: url_helper
INFO - 2016-03-01 22:35:59 --> Helper loaded: file_helper
INFO - 2016-03-01 22:35:59 --> Helper loaded: date_helper
INFO - 2016-03-01 22:35:59 --> Helper loaded: form_helper
INFO - 2016-03-01 22:35:59 --> Database Driver Class Initialized
INFO - 2016-03-01 22:36:00 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:36:00 --> Controller Class Initialized
INFO - 2016-03-01 22:36:00 --> Model Class Initialized
INFO - 2016-03-01 22:36:00 --> Model Class Initialized
INFO - 2016-03-01 22:36:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:36:01 --> Pagination Class Initialized
INFO - 2016-03-01 22:36:01 --> Helper loaded: text_helper
INFO - 2016-03-01 22:36:01 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:36:07 --> Config Class Initialized
INFO - 2016-03-01 22:36:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:36:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:36:07 --> Utf8 Class Initialized
INFO - 2016-03-01 22:36:07 --> URI Class Initialized
INFO - 2016-03-01 22:36:07 --> Router Class Initialized
INFO - 2016-03-01 22:36:07 --> Output Class Initialized
INFO - 2016-03-01 22:36:07 --> Security Class Initialized
DEBUG - 2016-03-01 22:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:36:07 --> Input Class Initialized
INFO - 2016-03-01 22:36:07 --> Language Class Initialized
INFO - 2016-03-01 22:36:07 --> Loader Class Initialized
INFO - 2016-03-01 22:36:07 --> Helper loaded: url_helper
INFO - 2016-03-01 22:36:07 --> Helper loaded: file_helper
INFO - 2016-03-01 22:36:07 --> Helper loaded: date_helper
INFO - 2016-03-01 22:36:07 --> Helper loaded: form_helper
INFO - 2016-03-01 22:36:07 --> Database Driver Class Initialized
INFO - 2016-03-01 22:36:08 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:36:08 --> Controller Class Initialized
INFO - 2016-03-01 22:36:08 --> Model Class Initialized
INFO - 2016-03-01 22:36:08 --> Model Class Initialized
INFO - 2016-03-01 22:36:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:36:08 --> Pagination Class Initialized
INFO - 2016-03-01 22:36:08 --> Helper loaded: text_helper
INFO - 2016-03-01 22:36:08 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:37:23 --> Config Class Initialized
INFO - 2016-03-01 22:37:23 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:37:23 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:37:23 --> Utf8 Class Initialized
INFO - 2016-03-01 22:37:23 --> URI Class Initialized
INFO - 2016-03-01 22:37:23 --> Router Class Initialized
INFO - 2016-03-01 22:37:23 --> Output Class Initialized
INFO - 2016-03-01 22:37:23 --> Security Class Initialized
DEBUG - 2016-03-01 22:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:37:23 --> Input Class Initialized
INFO - 2016-03-01 22:37:23 --> Language Class Initialized
INFO - 2016-03-01 22:37:23 --> Loader Class Initialized
INFO - 2016-03-01 22:37:23 --> Helper loaded: url_helper
INFO - 2016-03-01 22:37:23 --> Helper loaded: file_helper
INFO - 2016-03-01 22:37:23 --> Helper loaded: date_helper
INFO - 2016-03-01 22:37:23 --> Helper loaded: form_helper
INFO - 2016-03-01 22:37:23 --> Database Driver Class Initialized
INFO - 2016-03-01 22:37:24 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:37:24 --> Controller Class Initialized
INFO - 2016-03-01 22:37:24 --> Model Class Initialized
INFO - 2016-03-01 22:37:24 --> Model Class Initialized
INFO - 2016-03-01 22:37:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:37:24 --> Pagination Class Initialized
INFO - 2016-03-01 22:37:24 --> Helper loaded: text_helper
INFO - 2016-03-01 22:37:24 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:37:48 --> Config Class Initialized
INFO - 2016-03-01 22:37:48 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:37:48 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:37:48 --> Utf8 Class Initialized
INFO - 2016-03-01 22:37:48 --> URI Class Initialized
DEBUG - 2016-03-01 22:37:48 --> No URI present. Default controller set.
INFO - 2016-03-01 22:37:48 --> Router Class Initialized
INFO - 2016-03-01 22:37:48 --> Output Class Initialized
INFO - 2016-03-01 22:37:48 --> Security Class Initialized
DEBUG - 2016-03-01 22:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:37:48 --> Input Class Initialized
INFO - 2016-03-01 22:37:48 --> Language Class Initialized
INFO - 2016-03-01 22:37:48 --> Loader Class Initialized
INFO - 2016-03-01 22:37:48 --> Helper loaded: url_helper
INFO - 2016-03-01 22:37:48 --> Helper loaded: file_helper
INFO - 2016-03-01 22:37:48 --> Helper loaded: date_helper
INFO - 2016-03-01 22:37:48 --> Helper loaded: form_helper
INFO - 2016-03-01 22:37:48 --> Database Driver Class Initialized
INFO - 2016-03-01 22:37:49 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:37:49 --> Controller Class Initialized
INFO - 2016-03-01 22:37:49 --> Model Class Initialized
INFO - 2016-03-01 22:37:49 --> Model Class Initialized
INFO - 2016-03-01 22:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:37:49 --> Pagination Class Initialized
INFO - 2016-03-01 22:37:49 --> Helper loaded: text_helper
INFO - 2016-03-01 22:37:49 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:43:51 --> Config Class Initialized
INFO - 2016-03-01 22:43:51 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:43:51 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:43:51 --> Utf8 Class Initialized
INFO - 2016-03-01 22:43:51 --> URI Class Initialized
DEBUG - 2016-03-01 22:43:51 --> No URI present. Default controller set.
INFO - 2016-03-01 22:43:51 --> Router Class Initialized
INFO - 2016-03-01 22:43:51 --> Output Class Initialized
INFO - 2016-03-01 22:43:51 --> Security Class Initialized
DEBUG - 2016-03-01 22:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:43:51 --> Input Class Initialized
INFO - 2016-03-01 22:43:51 --> Language Class Initialized
INFO - 2016-03-01 22:43:51 --> Loader Class Initialized
INFO - 2016-03-01 22:43:51 --> Helper loaded: url_helper
INFO - 2016-03-01 22:43:51 --> Helper loaded: file_helper
INFO - 2016-03-01 22:43:51 --> Helper loaded: date_helper
INFO - 2016-03-01 22:43:51 --> Helper loaded: form_helper
INFO - 2016-03-01 22:43:51 --> Database Driver Class Initialized
INFO - 2016-03-01 22:43:52 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:43:52 --> Controller Class Initialized
INFO - 2016-03-01 22:43:52 --> Model Class Initialized
INFO - 2016-03-01 22:43:52 --> Model Class Initialized
INFO - 2016-03-01 22:43:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:43:52 --> Pagination Class Initialized
INFO - 2016-03-01 22:43:52 --> Helper loaded: text_helper
INFO - 2016-03-01 22:43:52 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:43:53 --> Config Class Initialized
INFO - 2016-03-01 22:43:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:43:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:43:53 --> Utf8 Class Initialized
INFO - 2016-03-01 22:43:53 --> URI Class Initialized
INFO - 2016-03-01 22:43:53 --> Router Class Initialized
INFO - 2016-03-01 22:43:53 --> Output Class Initialized
INFO - 2016-03-01 22:43:53 --> Security Class Initialized
DEBUG - 2016-03-01 22:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:43:53 --> Input Class Initialized
INFO - 2016-03-01 22:43:53 --> Language Class Initialized
ERROR - 2016-03-01 22:43:53 --> 404 Page Not Found: Static/lib
INFO - 2016-03-01 22:43:53 --> Config Class Initialized
INFO - 2016-03-01 22:43:53 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:43:53 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:43:53 --> Utf8 Class Initialized
INFO - 2016-03-01 22:43:53 --> URI Class Initialized
INFO - 2016-03-01 22:43:53 --> Router Class Initialized
INFO - 2016-03-01 22:43:53 --> Output Class Initialized
INFO - 2016-03-01 22:43:53 --> Security Class Initialized
DEBUG - 2016-03-01 22:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:43:53 --> Input Class Initialized
INFO - 2016-03-01 22:43:53 --> Language Class Initialized
ERROR - 2016-03-01 22:43:53 --> 404 Page Not Found: Static/lib
INFO - 2016-03-01 22:44:01 --> Config Class Initialized
INFO - 2016-03-01 22:44:01 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:44:01 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:44:01 --> Utf8 Class Initialized
INFO - 2016-03-01 22:44:01 --> URI Class Initialized
DEBUG - 2016-03-01 22:44:01 --> No URI present. Default controller set.
INFO - 2016-03-01 22:44:01 --> Router Class Initialized
INFO - 2016-03-01 22:44:01 --> Output Class Initialized
INFO - 2016-03-01 22:44:01 --> Security Class Initialized
DEBUG - 2016-03-01 22:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:44:01 --> Input Class Initialized
INFO - 2016-03-01 22:44:01 --> Language Class Initialized
INFO - 2016-03-01 22:44:01 --> Loader Class Initialized
INFO - 2016-03-01 22:44:01 --> Helper loaded: url_helper
INFO - 2016-03-01 22:44:01 --> Helper loaded: file_helper
INFO - 2016-03-01 22:44:01 --> Helper loaded: date_helper
INFO - 2016-03-01 22:44:01 --> Helper loaded: form_helper
INFO - 2016-03-01 22:44:01 --> Database Driver Class Initialized
INFO - 2016-03-01 22:44:02 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:44:02 --> Controller Class Initialized
INFO - 2016-03-01 22:44:02 --> Model Class Initialized
INFO - 2016-03-01 22:44:02 --> Model Class Initialized
INFO - 2016-03-01 22:44:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:44:02 --> Pagination Class Initialized
INFO - 2016-03-01 22:44:02 --> Helper loaded: text_helper
INFO - 2016-03-01 22:44:02 --> Helper loaded: cookie_helper
INFO - 2016-03-01 22:44:02 --> Config Class Initialized
INFO - 2016-03-01 22:44:02 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:44:02 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:44:02 --> Utf8 Class Initialized
INFO - 2016-03-01 22:44:02 --> URI Class Initialized
INFO - 2016-03-01 22:44:02 --> Router Class Initialized
INFO - 2016-03-01 22:44:02 --> Output Class Initialized
INFO - 2016-03-01 22:44:02 --> Security Class Initialized
DEBUG - 2016-03-01 22:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:44:02 --> Input Class Initialized
INFO - 2016-03-01 22:44:02 --> Language Class Initialized
ERROR - 2016-03-01 22:44:02 --> 404 Page Not Found: Static/lib
INFO - 2016-03-01 22:44:07 --> Config Class Initialized
INFO - 2016-03-01 22:44:07 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:44:07 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:44:07 --> Utf8 Class Initialized
INFO - 2016-03-01 22:44:07 --> URI Class Initialized
INFO - 2016-03-01 22:44:07 --> Router Class Initialized
INFO - 2016-03-01 22:44:07 --> Output Class Initialized
INFO - 2016-03-01 22:44:07 --> Security Class Initialized
DEBUG - 2016-03-01 22:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:44:07 --> Input Class Initialized
INFO - 2016-03-01 22:44:07 --> Language Class Initialized
ERROR - 2016-03-01 22:44:07 --> 404 Page Not Found: Static/lib
INFO - 2016-03-01 22:44:57 --> Config Class Initialized
INFO - 2016-03-01 22:44:57 --> Hooks Class Initialized
DEBUG - 2016-03-01 22:44:57 --> UTF-8 Support Enabled
INFO - 2016-03-01 22:44:57 --> Utf8 Class Initialized
INFO - 2016-03-01 22:44:57 --> URI Class Initialized
DEBUG - 2016-03-01 22:44:57 --> No URI present. Default controller set.
INFO - 2016-03-01 22:44:57 --> Router Class Initialized
INFO - 2016-03-01 22:44:57 --> Output Class Initialized
INFO - 2016-03-01 22:44:57 --> Security Class Initialized
DEBUG - 2016-03-01 22:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-03-01 22:44:57 --> Input Class Initialized
INFO - 2016-03-01 22:44:57 --> Language Class Initialized
INFO - 2016-03-01 22:44:57 --> Loader Class Initialized
INFO - 2016-03-01 22:44:57 --> Helper loaded: url_helper
INFO - 2016-03-01 22:44:57 --> Helper loaded: file_helper
INFO - 2016-03-01 22:44:57 --> Helper loaded: date_helper
INFO - 2016-03-01 22:44:57 --> Helper loaded: form_helper
INFO - 2016-03-01 22:44:57 --> Database Driver Class Initialized
INFO - 2016-03-01 22:44:58 --> Session: Class initialized using 'database' driver.
INFO - 2016-03-01 22:44:58 --> Controller Class Initialized
INFO - 2016-03-01 22:44:58 --> Model Class Initialized
INFO - 2016-03-01 22:44:58 --> Model Class Initialized
INFO - 2016-03-01 22:44:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2016-03-01 22:44:58 --> Pagination Class Initialized
INFO - 2016-03-01 22:44:58 --> Helper loaded: text_helper
INFO - 2016-03-01 22:44:58 --> Helper loaded: cookie_helper
