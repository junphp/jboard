<div class="jumbotron" style="text-align:center">
  <h1>Delete</h1>
  <p><h2>Your request has been processed successfully</h2></p>
  <p><a class="btn btn-primary btn-lg" href="/index.php/jboard/" role="button">Go Back to List</a></p>
</div>
