<div class="container" style="margin-top:70px;">
<div class="row">
<div><h3>keyword :</h3></div>
<table class="table table-hover">
  <tr>
    <td class="col-md-1">No</td>
    <td class="col-md-7">Title</td>
    <td class="col-md-2">Author</td>
    <td class="col-md-1" style="text-align:center">Date</td>
    <td class="col-md-1" style="text-align:center">View</td>
    <td class="col-md-1" style="text-align:center">like</td>
  </tr>

          <tr>
            <td class="col-md-12"colspan="12" style="text-align:center">please enter keyword more than 2 words, try again.</td>
        </tr>

</div>
</div>
