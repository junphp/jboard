<div class="row">
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="/static/user/wtest.png" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="/static/user/wtest.png" alt="...">
    </a>
  </div><div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="/static/user/wtest.png" alt="...">
    </a>
  </div><div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="/static/user/wtest.png" alt="...">
    </a>
  </div>

  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="/static/user/wtest.png" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="/static/user/wtest.png" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="/static/user/wtest.png" alt="...">
    </a>
  </div>
  <div class="col-xs-6 col-md-3">
    <a href="#" class="thumbnail">
      <img src="/static/user/wtest.png" alt="...">
    </a>
  </div>  
</div>
